import React, { useMemo, useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  XCircle,
  RefreshCw,
  AlertCircle,
  Target,
  Brain,
  Zap,
  RotateCcw,
} from 'lucide-react';
import type {
  PracticeAttempt,
  SmartDifficulty,
  SmartQuestion,
  SmartQuestionType,
  SupportedLanguage,
} from '../types';
import { SEED_SMART_QUESTIONS } from '../utils/japaneseData';
import {
  buildAntiRepetitionList,
  computeWeakTopics,
  evaluateSmartAnswer,
  extractReadableError,
} from '../utils/rajuEngine';

interface SmartQuestionGeneratorProps {
  language: SupportedLanguage;
  attempts: PracticeAttempt[];
  initialRevisionTopic?: string | null;
  onRecordAttempt: (attempt: PracticeAttempt) => void;
  onEarnXp: (amount: number) => void;
  onRecordTokens: (tokens: number) => void;
}

const PRESET_TOPICS = [
  'Japanese JLPT N5 Kanji & Particles',
  'Japanese Verb Conjugations (て-form / ます)',
  'CUET Biology — Molecular Basis of Inheritance',
  'CUET Physics — Electrostatics & Optics',
  'CUET Chemistry — Electrochemistry & Kinetics',
  'TypeScript & React State Architecture',
];

const QUESTION_TYPES: Array<{ id: SmartQuestionType; label: string }> = [
  { id: 'mcq', label: 'MCQs' },
  { id: 'fill_blank', label: 'Fill-in-the-Blanks' },
  { id: 'translation', label: 'Translation' },
  { id: 'descriptive', label: 'Descriptive' },
];

export const SmartQuestionGeneratorModule: React.FC<SmartQuestionGeneratorProps> = ({
  language,
  attempts,
  initialRevisionTopic,
  onRecordAttempt,
  onEarnXp,
  onRecordTokens,
}) => {
  const [topic, setTopic] = useState<string>(
    initialRevisionTopic || 'Japanese Kanji & Particles'
  );
  const [difficulty, setDifficulty] = useState<SmartDifficulty>('Beginner');
  const [selectedTypes, setSelectedTypes] = useState<SmartQuestionType[]>([
    'mcq',
    'fill_blank',
    'translation',
    'descriptive',
  ]);
  const [questionCount, setQuestionCount] = useState<number>(6);
  const [questions, setQuestions] = useState<SmartQuestion[]>(SEED_SMART_QUESTIONS);
  const [selectedMcq, setSelectedMcq] = useState<Record<string, number>>({});
  const [textAnswers, setTextAnswers] = useState<Record<string, string>>({});
  const [results, setResults] = useState<
    Record<string, { isCorrect: boolean; feedback: string; aiGraded?: boolean }>
  >({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingSimilarId, setGeneratingSimilarId] = useState<string | null>(null);
  const [gradingId, setGradingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [modeBanner, setModeBanner] = useState<string>('Interactive Seed Deck Ready — Solve any question or generate unlimited fresh AI sets');

  const weakTopics = useMemo(() => computeWeakTopics(attempts), [attempts]);

  const toggleType = (t: SmartQuestionType) => {
    setSelectedTypes((prev) =>
      prev.includes(t)
        ? prev.length > 1
          ? prev.filter((item) => item !== t)
          : prev
        : [...prev, t]
    );
  };

  const generateQuestions = async (opts?: {
    overrideTopic?: string;
    similarTo?: SmartQuestion;
    count?: number;
  }) => {
    const targetTopic = (opts?.overrideTopic ?? topic).trim();
    if (!targetTopic && !opts?.similarTo) {
      setErrorMsg('Please enter or select a topic first.');
      return;
    }

    setErrorMsg(null);
    if (opts?.similarTo) {
      setGeneratingSimilarId(opts.similarTo.id);
    } else {
      setIsGenerating(true);
    }

    try {
      const excludeStems = [
        ...buildAntiRepetitionList(attempts, 12),
        ...questions.map((q) => q.question.slice(0, 120)),
      ].slice(0, 18);

      const res = await fetch('/api/gemini/smart-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: targetTopic,
          difficulty,
          questionTypes: selectedTypes,
          count: opts?.count ?? questionCount,
          language,
          similarTo: opts?.similarTo || null,
          excludeStems,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(extractReadableError(data.error || data, 'Failed to generate questions.'));
      }

      if (Array.isArray(data.questions) && data.questions.length > 0) {
        setQuestions(data.questions);
        setSelectedMcq({});
        setTextAnswers({});
        setResults({});
        setModeBanner(
          opts?.similarTo
            ? `Generated ${data.questions.length} NEW similar questions testing "${opts.similarTo.conceptTag}"`
            : `Generated ${data.questions.length} unique ${difficulty} questions on "${targetTopic}"`
        );
        if (data.usage?.totalTokens) onRecordTokens(data.usage.totalTokens);
        onEarnXp(20);
      } else {
        throw new Error('AI returned an empty question list. Please try again.');
      }
    } catch (err) {
      setErrorMsg(extractReadableError(err, 'Unable to generate questions from Gemini 4 Hydrogen.'));
    } finally {
      setIsGenerating(false);
      setGeneratingSimilarId(null);
    }
  };

  const handleSubmitQuestion = async (q: SmartQuestion) => {
    const pickedIdx = selectedMcq[q.id];
    const typedText = textAnswers[q.id] || '';

    if (q.type === 'mcq' && pickedIdx === undefined) {
      setErrorMsg('Please choose one of the options before checking your answer.');
      return;
    }
    if (q.type !== 'mcq' && !typedText.trim()) {
      setErrorMsg('Please type your answer before checking.');
      return;
    }

    setErrorMsg(null);
    const localEval = evaluateSmartAnswer(q, typedText, pickedIdx);
    let finalEval = { ...localEval, aiGraded: false };

    // For descriptive or translation questions, optionally refine with Gemini grading when online
    if ((q.type === 'descriptive' || q.type === 'translation') && typedText.trim().length > 4) {
      setGradingId(q.id);
      try {
        const res = await fetch('/api/gemini/grade-answer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question: q.question,
            expectedAnswer: q.expectedAnswer,
            userAnswer: typedText,
            language,
          }),
        });
        if (res.ok) {
          const gradeData = await res.json();
          if (typeof gradeData.isCorrect === 'boolean' && gradeData.feedback) {
            finalEval = {
              isCorrect: gradeData.isCorrect,
              feedback: `${gradeData.feedback} (${gradeData.scorePercent ?? (gradeData.isCorrect ? 100 : 40)}%) — ${q.explanation}`,
              aiGraded: true,
            };
          }
          if (gradeData.usage?.totalTokens) onRecordTokens(gradeData.usage.totalTokens);
        }
      } catch {
        // Fallback smoothly to deterministic evaluator
      } finally {
        setGradingId(null);
      }
    }

    setResults((prev) => ({ ...prev, [q.id]: finalEval }));

    const attempt: PracticeAttempt = {
      id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      questionId: q.id,
      topic: q.topic,
      conceptTag: q.conceptTag,
      type: q.type,
      difficulty: q.difficulty,
      questionText: q.question,
      userAnswer: q.type === 'mcq' ? (q.options?.[pickedIdx ?? 0] ?? '') : typedText,
      isCorrect: finalEval.isCorrect,
      timestamp: new Date().toISOString(),
    };
    onRecordAttempt(attempt);
    onEarnXp(finalEval.isCorrect ? 15 : 5);
  };

  const solvedCount = Object.keys(results).length;
  const correctCount = Object.values(results).filter((r) => r.isCorrect).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Smart Question Generator & Practice Engine
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Unlimited adaptive practice across MCQs, Fill-in-Blanks, Translation, and Descriptive questions with Weak-Topic Revision & Similar Question Generation.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono bg-[#0B102B] border border-slate-800 px-3.5 py-2 rounded-xl text-cyan-300 shrink-0">
          <span>Session: {correctCount}/{solvedCount} Correct</span>
        </div>
      </div>

      {/* Generator Control Panel */}
      <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-5">
            <label htmlFor="smart-topic-input" className="block text-xs font-medium text-slate-300 mb-1.5">
              Topic or Concept to Practice
            </label>
            <input
              id="smart-topic-input"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Any topic: Japanese Particles, Kanji, Biology, React..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="lg:col-span-3">
            <label htmlFor="smart-difficulty" className="block text-xs font-medium text-slate-300 mb-1.5">
              Difficulty Level
            </label>
            <select
              id="smart-difficulty"
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as SmartDifficulty)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white"
            >
              <option value="Beginner">Beginner (Foundations)</option>
              <option value="Intermediate">Intermediate (Applied)</option>
              <option value="Advanced">Advanced (Deep Mastery)</option>
              <option value="Expert">Expert (Olympiad / N1)</option>
            </select>
          </div>

          <div className="lg:col-span-2">
            <label htmlFor="smart-count" className="block text-xs font-medium text-slate-300 mb-1.5">
              Count (5–10)
            </label>
            <select
              id="smart-count"
              value={questionCount}
              onChange={(e) => setQuestionCount(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white font-mono"
            >
              <option value={5}>5 Questions</option>
              <option value={6}>6 Questions</option>
              <option value={8}>8 Questions</option>
              <option value={10}>10 Questions</option>
            </select>
          </div>

          <div className="lg:col-span-2 flex items-end">
            <button
              type="button"
              onClick={() => generateQuestions()}
              disabled={isGenerating}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition disabled:opacity-50"
            >
              {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {isGenerating ? 'Generating...' : 'Generate Set'}
            </button>
          </div>
        </div>

        {/* Question Formats & Quick Topic Presets */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/70">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-400">Formats:</span>
            {QUESTION_TYPES.map((qt) => {
              const active = selectedTypes.includes(qt.id);
              return (
                <button
                  key={qt.id}
                  type="button"
                  onClick={() => toggleType(qt.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium border transition ${
                    active
                      ? 'bg-indigo-950/80 border-cyan-400/70 text-cyan-200'
                      : 'bg-[#060919] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {qt.label}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {PRESET_TOPICS.slice(0, 4).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setTopic(p)}
                className="px-2.5 py-1 rounded-lg bg-[#060919] border border-slate-800 hover:border-slate-600 text-[11px] text-slate-300"
              >
                {p.split('—')[0].trim()}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Weak Topics Auto-Revision Bar */}
      {weakTopics.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <Target className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-semibold text-amber-200">
                Weak Topic Detector ({weakTopics.filter((w) => w.isWeak).length} areas below 70% accuracy)
              </p>
              <p className="text-amber-200/80 mt-0.5">
                {weakTopics
                  .slice(0, 3)
                  .map((w) => `${w.topic} (${w.accuracyPercent}%)`)
                  .join(' · ')}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              const weakest = weakTopics[0]?.topic || topic;
              setTopic(weakest);
              generateQuestions({ overrideTopic: `Revision Test on Weak Areas: ${weakest}`, count: 6 });
            }}
            disabled={isGenerating}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Zap className="w-3.5 h-3.5" />
            Auto Revision Test
          </button>
        </div>
      )}

      {errorMsg && (
        <div role="alert" className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button type="button" onClick={() => setErrorMsg(null)} className="underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Status Banner */}
      <div className="flex items-center justify-between text-xs text-slate-300 px-1">
        <span className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-cyan-400" />
          {modeBanner}
        </span>
        <button
          type="button"
          onClick={() => {
            setQuestions(SEED_SMART_QUESTIONS);
            setSelectedMcq({});
            setTextAnswers({});
            setResults({});
            setModeBanner('Restored Seed Question Set');
          }}
          className="text-cyan-300 hover:underline flex items-center gap-1"
        >
          <RotateCcw className="w-3 h-3" />
          Reset Deck
        </button>
      </div>

      {/* Interactive Questions Grid */}
      <div className="space-y-4">
        {questions.map((q, idx) => {
          const result = results[q.id];
          const isMcq = q.type === 'mcq' && Array.isArray(q.options) && q.options.length > 0;
          const isThisSimilarLoading = generatingSimilarId === q.id;
          const isThisGrading = gradingId === q.id;

          return (
            <div
              key={q.id}
              data-testid={`smart-question-card-${idx}`}
              className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs">
                  <span className="px-2.5 py-0.5 rounded-lg bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 font-semibold uppercase">
                    {q.type.replace('_', ' ')}
                  </span>
                  <span className="text-purple-300 font-medium">{q.difficulty}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-300">{q.conceptTag}</span>
                </div>
                <span className="text-xs font-mono text-slate-400">#{idx + 1}</span>
              </div>

              <h3 className="text-base font-bold text-white leading-snug">{q.question}</h3>

              {q.hindiHint && (
                <p className="text-xs text-amber-300/90 bg-amber-950/25 border border-amber-500/20 px-3 py-1.5 rounded-lg">
                  <strong>Hindi Hint:</strong> {q.hindiHint}
                </p>
              )}

              {isMcq ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {q.options!.map((opt, optIdx) => {
                    const picked = selectedMcq[q.id] === optIdx;
                    const isCorrectOpt = q.correctIndex === optIdx;
                    let cls = 'bg-[#060919] border-slate-800 text-slate-200 hover:border-slate-600';
                    if (result) {
                      if (isCorrectOpt) {
                        cls = 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-semibold';
                      } else if (picked) {
                        cls = 'bg-rose-950/70 border-rose-500 text-rose-200';
                      }
                    } else if (picked) {
                      cls = 'bg-indigo-950/80 border-cyan-400 text-white';
                    }

                    return (
                      <button
                        key={optIdx}
                        type="button"
                        disabled={Boolean(result)}
                        onClick={() => setSelectedMcq((prev) => ({ ...prev, [q.id]: optIdx }))}
                        className={`p-3 rounded-xl border text-left text-xs sm:text-sm transition ${cls}`}
                      >
                        <span className="font-mono text-cyan-300 mr-2">{String.fromCharCode(65 + optIdx)}.</span>
                        {opt}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div>
                  <label htmlFor={`answer-input-${q.id}`} className="sr-only">
                    Your answer for question {idx + 1}
                  </label>
                  {q.type === 'descriptive' ? (
                    <textarea
                      id={`answer-input-${q.id}`}
                      rows={3}
                      disabled={Boolean(result)}
                      value={textAnswers[q.id] || ''}
                      onChange={(e) => setTextAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))}
                      placeholder="Write a clear explanation in English, Hindi, or Hinglish..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  ) : (
                    <input
                      id={`answer-input-${q.id}`}
                      type="text"
                      disabled={Boolean(result)}
                      value={textAnswers[q.id] || ''}
                      onChange={(e) => setTextAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))}
                      placeholder={
                        q.type === 'fill_blank'
                          ? 'Type the missing word / Hiragana / particle...'
                          : 'Type your translation...'
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  )}
                </div>
              )}

              {/* Action Bar & Result Feedback */}
              {!result ? (
                <div className="flex items-center justify-end">
                  <button
                    type="button"
                    disabled={isThisGrading}
                    onClick={() => handleSubmitQuestion(q)}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
                  >
                    {isThisGrading ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Evaluating Answer...
                      </>
                    ) : (
                      'Check Answer'
                    )}
                  </button>
                </div>
              ) : (
                <div
                  className={`p-4 rounded-xl border space-y-3 ${
                    result.isCorrect
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-100'
                      : 'bg-rose-950/40 border-rose-500/40 text-rose-100'
                  }`}
                >
                  <div className="flex items-start gap-2.5 text-xs sm:text-sm">
                    {result.isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                    )}
                    <div className="space-y-1">
                      <p className="font-semibold">
                        {result.isCorrect ? 'Correct Answer!' : 'Needs Review'}
                        {result.aiGraded && (
                          <span className="ml-2 text-[11px] font-mono text-cyan-300">· AI Graded</span>
                        )}
                      </p>
                      <p className="text-xs leading-relaxed opacity-95">{result.feedback}</p>
                    </div>
                  </div>

                  {/* Signature Feature: GENERATE SIMILAR QUESTIONS (5–10) */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/10">
                    <span className="text-[11px] text-slate-300">
                      Mastered or missed "{q.conceptTag}"? Practice 5–10 fresh variations:
                    </span>
                    <button
                      type="button"
                      disabled={Boolean(generatingSimilarId)}
                      onClick={() => generateQuestions({ similarTo: q, count: 6 })}
                      className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm disabled:opacity-50"
                    >
                      {isThisSimilarLoading ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Sparkles className="w-3.5 h-3.5" />
                      )}
                      {isThisSimilarLoading ? 'Generating Similar...' : 'GENERATE SIMILAR QUESTIONS'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
