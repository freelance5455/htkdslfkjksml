import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  FileText,
  IndianRupee,
  MessageCircle,
  Phone,
  Plus,
  Search,
  X,
} from 'lucide-react';
import { Client, Invoice, Payment, StudioSettings, TaskItem } from '../types';
import {
  buildWhatsAppReminderMessage,
  buildWhatsAppUrl,
  formatDateShort,
  formatINR,
  getClientPending,
} from '../utils/formatters';

interface ClientsViewProps {
  clients: Client[];
  payments: Payment[];
  invoices: Invoice[];
  tasks: TaskItem[];
  settings: StudioSettings;
  onAddClientClick: () => void;
  onCreateInvoiceForClient: (clientId: string) => void;
  onRecordPaymentForClient: (clientId: string) => void;
}

type ClientFilter = 'all' | 'active' | 'pending' | 'completed';

export const ClientsView: React.FC<ClientsViewProps> = ({
  clients,
  payments,
  invoices,
  tasks,
  settings,
  onAddClientClick,
  onCreateInvoiceForClient,
  onRecordPaymentForClient,
}) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<ClientFilter>('all');
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);

  const filteredClients = useMemo(() => {
    const q = search.trim().toLowerCase();
    return clients.filter((c) => {
      const pending = getClientPending(c);
      if (filter === 'pending' && pending === 0) return false;
      if (filter === 'completed' && pending > 0) return false;
      if (filter === 'active' && c.status !== 'active' && pending === 0) return false;

      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        c.projectType.toLowerCase().includes(q) ||
        c.projectTitle.toLowerCase().includes(q)
      );
    });
  }, [clients, filter, search]);

  const selectedClient = useMemo(
    () => clients.find((c) => c.id === selectedClientId) ?? null,
    [clients, selectedClientId]
  );

  const clientPayments = useMemo(
    () => payments.filter((p) => p.clientId === selectedClientId),
    [payments, selectedClientId]
  );

  const clientInvoices = useMemo(
    () => invoices.filter((i) => i.clientId === selectedClientId),
    [invoices, selectedClientId]
  );

  const clientTasks = useMemo(
    () => tasks.filter((t) => t.clientId === selectedClientId),
    [tasks, selectedClientId]
  );

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-0.5">
          <h1 className="font-display text-2xl font-bold text-[#0F172A]">Clients</h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {clients.length} total · {clients.filter((c) => getClientPending(c) > 0).length} pending
            settlement
          </p>
        </div>

        <button
          type="button"
          onClick={onAddClientClick}
          className="btn-primary h-11 px-4 text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap cursor-pointer"
        >
          <Plus className="w-4 h-4" strokeWidth={1.75} />
          <span>Add Client</span>
        </button>
      </div>

      {/* Search + Segmented Filter (outer 12px, padding 4px -> inner 8px) */}
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search
            className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            strokeWidth={1.75}
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search client, city, or project type..."
            className="w-full h-11 pl-10 pr-4 text-base sm:text-sm field-input"
          />
        </div>

        <div className="flex sm:inline-flex w-full sm:w-auto items-center gap-1 p-1 rounded-[12px] border border-slate-200 bg-white overflow-x-auto">
          {(['all', 'active', 'pending', 'completed'] as ClientFilter[]).map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setFilter(item)}
              className={`flex-1 sm:flex-none px-3 py-2 rounded-[8px] text-xs font-semibold capitalize whitespace-nowrap transition-colors duration-150 ease-out cursor-pointer ${
                filter === item
                  ? 'bg-[#0F172A] text-white'
                  : 'text-slate-600 hover:text-[#0F172A] hover:bg-slate-50'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      {/* Single Unified Surface List with 1px Dividers */}
      <section className="surface-card overflow-hidden">
        {clients.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="font-display text-base font-bold text-[#0F172A]">No clients added yet</p>
            <p className="text-sm text-slate-500 max-w-md mx-auto">
              Add your first client to track project contracts, payments, and invoices.
            </p>
            <button
              type="button"
              onClick={onAddClientClick}
              className="btn-primary px-4 py-2.5 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" strokeWidth={1.75} />
              <span>Add First Client</span>
            </button>
          </div>
        ) : filteredClients.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="text-sm text-slate-500">No clients match your search or filter.</p>
            <button
              type="button"
              onClick={() => {
                setSearch('');
                setFilter('all');
              }}
              className="btn-secondary px-4 py-2 text-xs font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {filteredClients.map((client) => {
              const pending = getClientPending(client);
              const isPaid = pending === 0;
              const initial = client.name.trim().charAt(0).toUpperCase();

              return (
                <button
                  key={client.id}
                  type="button"
                  onClick={() => setSelectedClientId(client.id)}
                  className="w-full px-5 py-4 text-left flex items-center justify-between gap-4 hover:bg-slate-50 transition-colors duration-150 ease-out cursor-pointer"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-10 h-10 rounded-[8px] bg-[#0F172A] flex items-center justify-center font-display text-sm font-bold text-white shrink-0">
                      {initial}
                    </div>
                    <div className="min-w-0 space-y-0.5">
                      <h2 className="font-display text-sm sm:text-base font-bold text-[#0F172A] truncate">
                        {client.name}
                      </h2>
                      <p className="text-xs text-slate-500 truncate">
                        {client.city} · {client.projectType}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 space-y-0.5">
                    <p className="font-display text-sm sm:text-base font-bold text-[#0F172A] tabular-nums">
                      {formatINR(client.totalAmount)}
                    </p>
                    <p
                      className={`text-xs font-semibold tabular-nums ${
                        isPaid ? 'text-emerald-700' : 'text-red-600'
                      }`}
                    >
                      {isPaid ? 'Paid' : `Pending ${formatINR(pending)}`}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>

      {/* Client Detail Modal (One flat white surface, 1px dividers inside) */}
      <AnimatePresence>
        {selectedClient && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16, ease: 'easeOut' }}
            className="fixed inset-0 z-50 bg-slate-900/40 flex items-end sm:items-center justify-center p-0 sm:p-4"
            onClick={() => setSelectedClientId(null)}
          >
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl surface-card rounded-t-[16px] sm:rounded-[16px] p-6 max-h-[90vh] overflow-y-auto shadow-xl divide-y divide-slate-200"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-4 pb-5">
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-12 h-12 rounded-[8px] bg-[#0F172A] flex items-center justify-center font-display text-lg font-bold text-white shrink-0">
                    {selectedClient.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 space-y-0.5">
                    <h2 className="font-display text-xl font-bold text-[#0F172A] truncate">
                      {selectedClient.name}
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-500">
                      {selectedClient.city} · {selectedClient.projectType} ·{' '}
                      {selectedClient.projectTitle}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedClientId(null)}
                  aria-label="Close client profile"
                  className="w-9 h-9 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer shrink-0"
                >
                  <X className="w-4 h-4" strokeWidth={1.75} />
                </button>
              </div>

              {/* Financial Summary & Progress */}
              {(() => {
                const pending = getClientPending(selectedClient);
                const pct =
                  selectedClient.totalAmount > 0
                    ? Math.min(
                        100,
                        Math.round((selectedClient.paidAmount / selectedClient.totalAmount) * 100)
                      )
                    : 100;

                return (
                  <div className="py-5 space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-0.5">
                        <p className="text-xs text-slate-500">Contract Total</p>
                        <p className="font-display text-lg font-bold text-[#0F172A] tabular-nums">
                          {formatINR(selectedClient.totalAmount)}
                        </p>
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-xs text-slate-500">Total Paid</p>
                        <p className="font-display text-lg font-bold text-emerald-700 tabular-nums">
                          {formatINR(selectedClient.paidAmount)}
                        </p>
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-xs text-slate-500">Total Pending</p>
                        <p
                          className={`font-display text-lg font-bold tabular-nums ${
                            pending > 0 ? 'text-red-600' : 'text-[#0F172A]'
                          }`}
                        >
                          {formatINR(pending)}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span>Collection Progress</span>
                        <span className="font-mono font-semibold text-[#0F172A]">{pct}%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-[#0F172A] transition-all duration-200 ease-out"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Direct Communication & Actions */}
              <div className="py-5 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <a
                  href={buildWhatsAppUrl(
                    selectedClient.phone,
                    getClientPending(selectedClient) > 0
                      ? buildWhatsAppReminderMessage(selectedClient, settings)
                      : `Namaste Sir, ${settings.companyName} se ${settings.adminName} bol raha hu. Hope your ${selectedClient.projectTitle} is running great!`
                  )}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-secondary h-10 text-xs font-semibold inline-flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-700" strokeWidth={1.75} />
                  <span>WhatsApp</span>
                </a>

                <a
                  href={`tel:${selectedClient.phone.replace(/\s+/g, '')}`}
                  className="btn-secondary h-10 text-xs font-semibold inline-flex items-center justify-center gap-1.5"
                >
                  <Phone className="w-4 h-4" strokeWidth={1.75} />
                  <span>Call</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    const id = selectedClient.id;
                    setSelectedClientId(null);
                    onCreateInvoiceForClient(id);
                  }}
                  className="btn-primary h-10 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-4 h-4" strokeWidth={1.75} />
                  <span>Create Invoice</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const id = selectedClient.id;
                    setSelectedClientId(null);
                    onRecordPaymentForClient(id);
                  }}
                  className="btn-secondary h-10 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <IndianRupee className="w-4 h-4" strokeWidth={1.75} />
                  <span>Add Payment</span>
                </button>
              </div>

              {/* Notes & History */}
              <div className="pt-5 space-y-5">
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-slate-500">Contact &amp; Notes</p>
                  <p className="text-sm text-[#0F172A]">
                    {selectedClient.notes || 'No project notes added.'}
                  </p>
                  <p className="text-xs text-slate-500 font-mono">{selectedClient.phone}</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-slate-200">
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-slate-500">
                      Payments ({clientPayments.length})
                    </p>
                    {clientPayments.length === 0 ? (
                      <p className="text-xs text-slate-400">No payments recorded yet.</p>
                    ) : (
                      <div className="divide-y divide-slate-100">
                        {clientPayments.map((p) => (
                          <div key={p.id} className="py-2 flex items-center justify-between text-xs">
                            <span className="text-slate-600">
                              {formatDateShort(p.date)} · {p.mode}
                            </span>
                            <span className="font-semibold text-emerald-700 tabular-nums">
                              {formatINR(p.amount)}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-slate-500">
                      Invoices ({clientInvoices.length}) &amp; Tasks ({clientTasks.length})
                    </p>
                    {clientInvoices.length === 0 && clientTasks.length === 0 ? (
                      <p className="text-xs text-slate-400">No invoices or tasks linked yet.</p>
                    ) : (
                      <div className="divide-y divide-slate-100 text-xs">
                        {clientInvoices.map((inv) => (
                          <div key={inv.id} className="py-2 flex items-center justify-between">
                            <span className="text-[#0F172A] font-mono">{inv.invoiceNumber}</span>
                            <span
                              className={
                                inv.status === 'Paid'
                                  ? 'text-emerald-700 font-semibold'
                                  : 'text-red-600 font-semibold'
                              }
                            >
                              {inv.status}
                            </span>
                          </div>
                        ))}
                        {clientTasks.map((tsk) => (
                          <div key={tsk.id} className="py-2 flex items-center justify-between gap-2">
                            <span className="text-slate-700 truncate">{tsk.title}</span>
                            <span className="text-slate-500 uppercase text-[10px] font-semibold">
                              {tsk.stage}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
