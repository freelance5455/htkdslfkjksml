import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Inbox, 
  Search, 
  Filter, 
  Download, 
  Plus, 
  Printer, 
  CheckCircle2, 
  Clock, 
  Truck, 
  AlertTriangle, 
  ChevronRight, 
  MoreHorizontal,
  ChevronDown,
  ChevronsUpDown,
  ArrowUpDown,
  Check,
  Package,
  Layers,
  FileSpreadsheet,
  X,
  Calendar,
  ExternalLink,
  BookOpen,
  ShoppingBag,
  SlidersHorizontal,
  Store as StoreIcon
} from 'lucide-react';
import { Order, OrderStatus, PaymentStatus, Store, Language, Product, Customer, ShippingSettings } from '../../types';
import { OrderDetailsDrawer } from './orders/OrderDetailsDrawer';
import { CreateOrderModal } from './orders/CreateOrderModal';
import { PrintInvoiceModal } from './orders/PrintInvoiceModal';

interface OrdersManagerProps {
  activeStore: Store;
  orders: Order[];
  products?: Product[];
  customers?: Customer[];
  language: Language;
  shippingSettings?: ShippingSettings | null;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, trackingId?: string, courier?: string) => void;
  onUpdatePaymentStatus?: (orderId: string, status: PaymentStatus) => void;
  onUpdateOrderNotes?: (orderId: string, notes: string) => void;
  onCreateOrder?: (order: Order) => void;
  onBulkUpdateOrderStatus?: (orderIds: string[], status: OrderStatus) => void;
  onOpenReturnModal?: (order: Order) => void;
}

export const OrdersManager: React.FC<OrdersManagerProps> = ({
  activeStore,
  orders = [],
  products = [],
  customers = [],
  language,
  shippingSettings,
  onUpdateOrderStatus,
  onUpdatePaymentStatus,
  onUpdateOrderNotes,
  onCreateOrder,
  onBulkUpdateOrderStatus,
  onOpenReturnModal
}) => {
  const isBn = language === 'bn';

  // State: Locations Dropdown
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [isLocationMenuOpen, setIsLocationMenuOpen] = useState(false);
  const locationMenuRef = useRef<HTMLDivElement>(null);

  // State: More Actions Dropdown
  const [isMoreActionsOpen, setIsMoreActionsOpen] = useState(false);
  const moreActionsRef = useRef<HTMLDivElement>(null);

  // State: Learn More Modal
  const [isLearnMoreOpen, setIsLearnMoreOpen] = useState(false);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest' | 'lowest'>('newest');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Bulk Selection
  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);

  // Modals & Drawers
  const [activeDrawerOrder, setActiveDrawerOrder] = useState<Order | null>(null);
  const [printInvoiceOrder, setPrintInvoiceOrder] = useState<Order | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Defensive Normalization
  const safeOrders = useMemo(() => {
    if (!Array.isArray(orders)) return [];
    return orders.filter((o) => o && typeof o === 'object' && typeof o.id === 'string');
  }, [orders]);

  const safeProducts = useMemo(() => {
    if (!Array.isArray(products)) return [];
    return products.filter((p) => p && typeof p === 'object' && typeof p.id === 'string');
  }, [products]);

  const safeCustomers = useMemo(() => {
    if (!Array.isArray(customers)) return [];
    return customers.filter((c) => c && typeof c === 'object' && typeof c.id === 'string');
  }, [customers]);

  // Store Isolation
  const storeOrders = useMemo(() => {
    return safeOrders.filter((o) => o.storeId === activeStore?.id);
  }, [safeOrders, activeStore?.id]);

  // Click Outside Listener for Popovers
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (locationMenuRef.current && !locationMenuRef.current.contains(e.target as Node)) {
        setIsLocationMenuOpen(false);
      }
      if (moreActionsRef.current && !moreActionsRef.current.contains(e.target as Node)) {
        setIsMoreActionsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Location Options (Matching Screenshot 2)
  const storeAddressName = activeStore?.address?.trim() || 'Goalabazar Osmani Nagar Sylhet';
  const locationOptions = useMemo(() => [
    { id: 'all', label: isBn ? 'সকল লোকেশন' : 'All locations', badge: null, icon: null },
    { id: 'dsers', label: 'dsers-fulfillment-service', badge: 'App', icon: 'orange' },
    { id: 'store_address', label: storeAddressName, badge: null, icon: null },
    { id: 'custom_location', label: isBn ? 'মাই কাস্টম লোকেশন' : 'My Custom Location', badge: null, icon: null },
    { id: 'snow_city', label: 'Snow City Warehouse', badge: 'App', icon: 'teal' },
  ], [isBn, storeAddressName]);

  const activeLocationLabel = locationOptions.find(l => l.id === selectedLocation)?.label || (isBn ? 'সকল লোকেশন' : 'All locations');

  // Status helper predicates
  const isUnfulfilled = (status: OrderStatus) => ['pending', 'confirmed', 'processing', 'packed'].includes(status);
  const isFulfilled = (status: OrderStatus) => ['shipped', 'delivered'].includes(status);

  // Today's Analytics Summary Calculations (Shopify Top Cards)
  const todaySummary = useMemo(() => {
    const today = new Date();
    const todayDateString = today.toISOString().split('T')[0];

    const todayOrders = storeOrders.filter(o => {
      if (!o.createdAt) return false;
      return o.createdAt.startsWith(todayDateString);
    });

    const ordersCount = todayOrders.length;
    const itemsOrdered = todayOrders.reduce((sum, o) => {
      const itemsCount = Array.isArray(o.items) 
        ? o.items.reduce((iSum, item) => iSum + (typeof item.quantity === 'number' ? item.quantity : 1), 0)
        : 0;
      return sum + itemsCount;
    }, 0);

    const salesAmount = todayOrders.reduce((sum, o) => {
      return sum + (o.paymentStatus === 'paid' ? (o.totalAmount || 0) : 0);
    }, 0);

    return {
      ordersCount,
      itemsOrdered,
      salesAmount
    };
  }, [storeOrders]);

  // Filter & Sort
  const filteredOrders = useMemo(() => {
    return storeOrders.filter((order) => {
      // Location Filter
      if (selectedLocation !== 'all') {
        if (selectedLocation === 'store_address') {
          const matchesCity = order.city && storeAddressName.toLowerCase().includes(order.city.toLowerCase());
          const matchesAddr = order.deliveryAddress && storeAddressName.toLowerCase().includes(order.deliveryAddress.toLowerCase());
          if (!matchesCity && !matchesAddr && storeOrders.length > 3) return false;
        }
      }

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = 
        !q ||
        (order.orderNumber || order.id || '').toLowerCase().includes(q) ||
        (order.customerName || '').toLowerCase().includes(q) ||
        (order.customerPhone || '').includes(q) ||
        (order.customerEmail && order.customerEmail.toLowerCase().includes(q));

      let matchesStatus = true;
      if (statusFilter === 'all') matchesStatus = true;
      else if (statusFilter === 'unfulfilled') matchesStatus = isUnfulfilled(order.orderStatus);
      else if (statusFilter === 'fulfilled') matchesStatus = isFulfilled(order.orderStatus);
      else if (statusFilter === 'cancelled') matchesStatus = order.orderStatus === 'cancelled';
      else matchesStatus = order.orderStatus === statusFilter;

      const matchesPayment = paymentFilter === 'all' || order.paymentStatus === paymentFilter;

      return matchesSearch && matchesStatus && matchesPayment;
    }).sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
      if (sortBy === 'oldest') return new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();
      if (sortBy === 'highest') return (b.totalAmount || 0) - (a.totalAmount || 0);
      if (sortBy === 'lowest') return (a.totalAmount || 0) - (b.totalAmount || 0);
      return 0;
    });
  }, [storeOrders, selectedLocation, storeAddressName, searchQuery, statusFilter, paymentFilter, sortBy]);

  // Paginated Slices
  const totalPages = Math.ceil(filteredOrders.length / itemsPerPage) || 1;
  const paginatedOrders = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredOrders.slice(start, start + itemsPerPage);
  }, [filteredOrders, currentPage]);

  // Bulk Select Toggle
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedOrderIds(paginatedOrders.map(o => o.id));
    } else {
      setSelectedOrderIds([]);
    }
  };

  const handleToggleSelectOrder = (orderId: string) => {
    if (selectedOrderIds.includes(orderId)) {
      setSelectedOrderIds(selectedOrderIds.filter(id => id !== orderId));
    } else {
      setSelectedOrderIds([...selectedOrderIds, orderId]);
    }
  };

  const handleBulkStatusChange = (status: OrderStatus) => {
    if (selectedOrderIds.length === 0) return;
    if (onBulkUpdateOrderStatus) {
      onBulkUpdateOrderStatus(selectedOrderIds, status);
    } else {
      selectedOrderIds.forEach(id => onUpdateOrderStatus(id, status));
    }
    setSelectedOrderIds([]);
  };

  // Export CSV
  const handleExportCSV = () => {
    const ordersToExport = selectedOrderIds.length > 0 
      ? storeOrders.filter(o => selectedOrderIds.includes(o.id))
      : (filteredOrders.length > 0 ? filteredOrders : storeOrders);

    if (ordersToExport.length === 0) return;

    const headers = ['Order Number', 'Date', 'Customer Name', 'Phone', 'Address', 'City', 'Items Count', 'Total Amount', 'Payment Method', 'Payment Status', 'Order Status'];
    const rows = ordersToExport.map(o => [
      `"${o.orderNumber || o.id}"`,
      `"${o.createdAt ? new Date(o.createdAt).toLocaleDateString() : ''}"`,
      `"${o.customerName}"`,
      `"${o.customerPhone}"`,
      `"${(o.deliveryAddress || '').replace(/"/g, '""')}"`,
      `"${o.city || ''}"`,
      o.items ? o.items.length : 0,
      o.totalAmount || 0,
      `"${o.paymentMethod || 'COD'}"`,
      `"${o.paymentStatus || 'pending'}"`,
      `"${o.orderStatus || 'pending'}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `orders_${activeStore?.slug || 'store'}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setIsMoreActionsOpen(false);
  };

  const currencyCode = activeStore?.currency || 'BDT';

  return (
    <div className="space-y-4 max-w-5xl mx-auto pb-16">
      {/* ========================================================================= */}
      {/* 1. TOP ORDERS HEADER (EXACT SHOPIFY LAYOUT)                               */}
      {/* ========================================================================= */}
      <div className="flex items-center justify-between gap-3 pt-1">
        {/* Left: Orders Title + Interactive Location Selector */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          <div className="flex items-center gap-1.5">
            <Inbox className="w-4 h-4 text-slate-700" />
            <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
              {isBn ? 'অর্ডারস' : 'Orders'}
            </h1>
          </div>

          {/* Location Selector Pill (Screenshot 2 Match) */}
          <div className="relative" ref={locationMenuRef}>
            <button
              type="button"
              onClick={() => setIsLocationMenuOpen(!isLocationMenuOpen)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
            >
              <span className="truncate max-w-[150px] sm:max-w-[200px]">
                {activeLocationLabel}
              </span>
              <ChevronsUpDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            </button>

            {/* Location Selector Popover (Matches Screenshot 2) */}
            {isLocationMenuOpen && (
              <div className="absolute top-full left-0 mt-1 w-64 sm:w-72 bg-white rounded-xl border border-slate-200 shadow-xl py-1.5 z-50 animate-in fade-in slide-in-from-top-1 text-xs">
                {locationOptions.map((loc) => {
                  const isSelected = selectedLocation === loc.id;
                  return (
                    <button
                      key={loc.id}
                      type="button"
                      onClick={() => {
                        setSelectedLocation(loc.id);
                        setIsLocationMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer ${
                        isSelected ? 'bg-slate-50/80 font-bold text-slate-900' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-4 text-center shrink-0">
                          {isSelected && <Check className="w-3.5 h-3.5 text-slate-900 stroke-[3]" />}
                        </div>

                        {loc.icon === 'orange' && (
                          <div className="w-4 h-4 rounded bg-amber-500 text-white flex items-center justify-center text-[9px] font-bold shrink-0">
                            D
                          </div>
                        )}
                        {loc.icon === 'teal' && (
                          <div className="w-4 h-4 rounded bg-teal-600 text-white flex items-center justify-center text-[9px] font-bold shrink-0">
                            S
                          </div>
                        )}

                        <span className="truncate">{loc.label}</span>
                      </div>

                      {loc.badge && (
                        <span className="text-[10px] font-medium px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 border border-slate-200 shrink-0">
                          {loc.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right: More actions Dropdown */}
        <div className="relative" ref={moreActionsRef}>
          <button
            type="button"
            onClick={() => setIsMoreActionsOpen(!isMoreActionsOpen)}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium shadow-2xs transition-colors cursor-pointer"
          >
            <span>{isBn ? 'আরও অ্যাকশন' : 'More actions'}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {/* More Actions Popover */}
          {isMoreActionsOpen && (
            <div className="absolute top-full right-0 mt-1 w-48 bg-white rounded-xl border border-slate-200 shadow-xl py-1.5 z-50 animate-in fade-in slide-in-from-top-1 text-xs">
              <button
                type="button"
                onClick={handleExportCSV}
                className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>{isBn ? 'অর্ডারস এক্সপোর্ট (CSV)' : 'Export orders'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsCreateModalOpen(true);
                  setIsMoreActionsOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-slate-400" />
                <span>{isBn ? 'নতুন অর্ডার তৈরি' : 'Create order'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsLearnMoreOpen(true);
                  setIsMoreActionsOpen(false);
                }}
                className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5 text-slate-400" />
                <span>{isBn ? 'অর্ডার গাইড দেখুন' : 'Orders guide'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. TOP SUMMARY / ANALYTICS CARDS (EXACT SHOPIFY CARD MATCH)               */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-3 sm:p-4 shadow-2xs">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
          {/* Card 1: Today */}
          <div className="flex items-center gap-2 text-slate-600">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs font-semibold text-slate-700">
              {isBn ? 'আজ (Today)' : 'Today'}
            </span>
          </div>

          {/* Card 2: Orders */}
          <div>
            <div className="text-[11px] font-medium text-slate-500 border-b border-dotted border-slate-300 inline-block">
              {isBn ? 'অর্ডার' : 'Orders'}
            </div>
            <div className="text-xs font-bold text-slate-900 mt-1 flex items-baseline gap-1">
              <span>{todaySummary.ordersCount}</span>
              <span className="text-slate-300 font-normal">—</span>
            </div>
          </div>

          {/* Card 3: Items Ordered */}
          <div>
            <div className="text-[11px] font-medium text-slate-500 border-b border-dotted border-slate-300 inline-block">
              {isBn ? 'আইটেম বিক্রিত' : 'Items ordered'}
            </div>
            <div className="text-xs font-bold text-slate-900 mt-1 flex items-baseline gap-1">
              <span>{todaySummary.itemsOrdered}</span>
              <span className="text-slate-300 font-normal">—</span>
            </div>
          </div>

          {/* Card 4: Sales / Reversals */}
          <div>
            <div className="text-[11px] font-medium text-slate-500 border-b border-dotted border-slate-300 inline-block">
              {isBn ? 'বিক্রয় ও রিভার্সাল' : 'Sales reversals'}
            </div>
            <div className="text-xs font-bold text-slate-900 mt-1 flex items-baseline gap-1">
              <span>{currencyCode} {todaySummary.salesAmount.toLocaleString()}</span>
              <span className="text-slate-300 font-normal">—</span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. MAIN ORDERS CONTENT: EMPTY STATE vs REAL ORDERS TABLE                  */}
      {/* ========================================================================= */}
      {storeOrders.length === 0 ? (
        /* ======================================================================= */
        /* EMPTY STATE (EXACT MATCH FOR SCREENSHOT 1 & 2)                          */
        /* ======================================================================= */
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-8 sm:p-14 text-center">
            {/* Custom SVG Illustration (Document Folder + Pottery Ceramic Vessels) */}
            <div className="mx-auto w-32 h-32 sm:w-36 sm:h-36 relative flex items-center justify-center mb-6">
              {/* Circular mint backdrop with teal bottom half */}
              <svg viewBox="0 0 140 140" className="w-full h-full">
                {/* Light Mint Background Circle */}
                <circle cx="70" cy="70" r="54" fill="#e8f5f3" />
                {/* Darker Teal Half/Bottom Arc */}
                <path d="M 16,70 A 54,54 0 0,0 124,70 Z" fill="#2d8c7d" />

                {/* White Document Folder / Sheet */}
                <g transform="translate(36, 26) scale(0.95)">
                  {/* Drop Shadow */}
                  <rect x="2" y="4" width="70" height="84" rx="6" fill="#000000" opacity="0.08" />
                  {/* White Paper Sheet */}
                  <rect x="0" y="0" width="70" height="84" rx="6" fill="#ffffff" stroke="#e2e8f0" strokeWidth="1" />

                  {/* Blue Top Tab Bar */}
                  <rect x="8" y="8" width="24" height="4" rx="2" fill="#2563eb" />

                  {/* Top Product Illustration: Cyan Shallow Dish/Vessel */}
                  <rect x="10" y="18" width="22" height="15" rx="3" fill="#e0f2fe" />
                  <ellipse cx="21" cy="23" rx="8" ry="4" fill="#0284c7" />

                  {/* Bottom Product Illustration: Terracotta Red Vase/Urn */}
                  <rect x="10" y="38" width="22" height="20" rx="3" fill="#ffedd5" />
                  <path d="M 16,42 Q 13,49 16,54 L 26,54 Q 29,49 26,42 Z" fill="#ea580c" />

                  {/* Right-hand Document Ruled Placeholder Lines */}
                  <rect x="38" y="18" width="24" height="3" rx="1.5" fill="#e2e8f0" />
                  <rect x="38" y="25" width="18" height="3" rx="1.5" fill="#e2e8f0" />
                  <rect x="38" y="32" width="22" height="3" rx="1.5" fill="#e2e8f0" />
                  <rect x="38" y="42" width="24" height="3" rx="1.5" fill="#e2e8f0" />
                  <rect x="38" y="49" width="16" height="3" rx="1.5" fill="#e2e8f0" />
                </g>
              </svg>
            </div>

            {/* Empty State Heading */}
            <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
              {isBn ? 'আপনার সমস্ত অর্ডার এখানে দেখা যাবে' : 'Your orders will show here'}
            </h2>

            {/* Empty State Subtitle */}
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mt-1.5 leading-relaxed">
              {isBn 
                ? 'এখান থেকে আপনি কাস্টমারদের অর্ডার ফুলফিল, পেমেন্ট সংগ্রহ এবং কুরিয়ার প্রসেসিং সম্পন্ন করতে পারবেন।' 
                : "This is where you'll fulfill orders, collect payments, and track order progress."}
            </p>

            {/* Create Order Primary Action Button */}
            <div className="mt-5">
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(true)}
                className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1.5"
              >
                <span>{isBn ? 'অর্ডার তৈরি করুন' : 'Create order'}</span>
              </button>
            </div>
          </div>

          {/* Centered Link Below the Card */}
          <div className="text-center pt-1">
            <button
              type="button"
              onClick={() => setIsLearnMoreOpen(true)}
              className="text-xs text-slate-600 hover:text-slate-900 underline underline-offset-2 transition-colors cursor-pointer font-medium"
            >
              {isBn ? 'অর্ডার পরিচালনা সম্পর্কে বিস্তারিত জানুন' : 'Learn more about orders'}
            </button>
          </div>
        </div>
      ) : (
        /* ======================================================================= */
        /* ORDERS LIST & TABLE (WHEN ORDERS EXIST)                                 */
        /* ======================================================================= */
        <div className="space-y-3">
          {/* Quick Status Tabs (All, Unfulfilled, Fulfilled, Cancelled) */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs p-3 space-y-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-semibold">
              {[
                { id: 'all', labelEn: 'All', labelBn: 'সকল', count: storeOrders.length },
                { id: 'unfulfilled', labelEn: 'Unfulfilled', labelBn: 'আনফুলফিল্ড', count: storeOrders.filter(o => isUnfulfilled(o.orderStatus)).length },
                { id: 'fulfilled', labelEn: 'Fulfilled', labelBn: 'ফুলফিল্ড', count: storeOrders.filter(o => isFulfilled(o.orderStatus)).length },
                { id: 'cancelled', labelEn: 'Cancelled', labelBn: 'বাতিল', count: storeOrders.filter(o => o.orderStatus === 'cancelled').length },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setStatusFilter(tab.id);
                    setCurrentPage(1);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                    statusFilter === tab.id
                      ? 'bg-slate-900 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <span>{isBn ? tab.labelBn : tab.labelEn}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    statusFilter === tab.id ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {tab.count}
                  </span>
                </button>
              ))}
            </div>

            {/* Filter Search Toolbar */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100 text-xs">
              <div className="sm:col-span-2 relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  placeholder={isBn ? 'অর্ডার #, গ্রাহকের নাম, ফোন দিয়ে খুঁজুন...' : 'Search by order number, customer name, phone...'}
                  className="w-full pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-slate-50 focus:bg-white focus:outline-slate-900"
                />
              </div>

              <div>
                <select
                  value={paymentFilter}
                  onChange={(e) => {
                    setPaymentFilter(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-700 font-medium"
                >
                  <option value="all">{isBn ? 'পেমেন্ট: সকল' : 'Payment: All'}</option>
                  <option value="paid">{isBn ? 'পরিশোধিত (Paid)' : 'Paid'}</option>
                  <option value="pending">{isBn ? 'বাকি (Pending)' : 'Pending'}</option>
                  <option value="failed">{isBn ? 'ব্যর্থ (Failed)' : 'Failed'}</option>
                </select>
              </div>

              <div>
                <select
                  value={sortBy}
                  onChange={(e: any) => setSortBy(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-700 font-medium"
                >
                  <option value="newest">{isBn ? 'তারিখ: নতুন থেকে পুরাতন' : 'Sort: Newest'}</option>
                  <option value="oldest">{isBn ? 'তারিখ: পুরাতন থেকে নতুন' : 'Sort: Oldest'}</option>
                  <option value="highest">{isBn ? 'মূল্য: সর্বোচ্চ' : 'Amount: High to Low'}</option>
                  <option value="lowest">{isBn ? 'মূল্য: সর্বনিম্ন' : 'Amount: Low to High'}</option>
                </select>
              </div>
            </div>
          </div>

          {/* Bulk Selection Actions */}
          {selectedOrderIds.length > 0 && (
            <div className="bg-slate-900 text-white p-2.5 rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-emerald-400">
                  {selectedOrderIds.length} {isBn ? 'টি অর্ডার নির্বাচিত' : 'selected'}
                </span>
                <button
                  onClick={() => setSelectedOrderIds([])}
                  className="text-slate-400 hover:text-white underline text-[11px]"
                >
                  {isBn ? 'বাতিল' : 'Deselect'}
                </button>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  onClick={() => handleBulkStatusChange('confirmed')}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-medium"
                >
                  Confirmed
                </button>
                <button
                  onClick={() => handleBulkStatusChange('shipped')}
                  className="px-2 py-0.5 rounded bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-medium"
                >
                  Shipped
                </button>
                <button
                  onClick={() => handleBulkStatusChange('delivered')}
                  className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-medium"
                >
                  Delivered
                </button>
                <button
                  onClick={() => handleBulkStatusChange('cancelled')}
                  className="px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-medium"
                >
                  Cancelled
                </button>
              </div>
            </div>
          )}

          {/* Orders Table */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50/80 border-b border-slate-200/80 text-slate-500 font-medium text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="py-3 px-4 w-10">
                      <input
                        type="checkbox"
                        checked={paginatedOrders.length > 0 && selectedOrderIds.length === paginatedOrders.length}
                        onChange={(e) => handleSelectAll(e.target.checked)}
                        className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer"
                      />
                    </th>
                    <th className="py-3 px-4">{isBn ? 'অর্ডার' : 'Order'}</th>
                    <th className="py-3 px-4">{isBn ? 'তারিখ' : 'Date'}</th>
                    <th className="py-3 px-4">{isBn ? 'গ্রাহক' : 'Customer'}</th>
                    <th className="py-3 px-4 text-center">{isBn ? 'পেমেন্ট' : 'Payment'}</th>
                    <th className="py-3 px-4 text-center">{isBn ? 'ফুলফিলমেন্ট' : 'Fulfillment'}</th>
                    <th className="py-3 px-4 text-right">{isBn ? 'আইটেম' : 'Items'}</th>
                    <th className="py-3 px-4 text-right">{isBn ? 'মোট' : 'Total'}</th>
                    <th className="py-3 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Action'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {paginatedOrders.map((order) => {
                    const isChecked = selectedOrderIds.includes(order.id);
                    return (
                      <tr 
                        key={order.id} 
                        className={`hover:bg-slate-50/70 transition-colors ${isChecked ? 'bg-slate-50/80' : ''}`}
                      >
                        <td className="py-3 px-4">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => handleToggleSelectOrder(order.id)}
                            className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer"
                          />
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">
                          <button
                            type="button"
                            onClick={() => setActiveDrawerOrder(order)}
                            className="hover:underline hover:text-emerald-700 cursor-pointer text-left"
                          >
                            #{order.orderNumber || order.id.slice(-6).toUpperCase()}
                          </button>
                        </td>
                        <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                          {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Today'}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">{order.customerName}</div>
                          <div className="text-[11px] text-slate-400">{order.customerPhone}</div>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                            order.paymentStatus === 'paid'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                          }`}>
                            {order.paymentStatus === 'paid' ? 'Paid' : 'Pending'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                            order.orderStatus === 'delivered'
                              ? 'bg-emerald-50 text-emerald-800'
                              : order.orderStatus === 'shipped'
                              ? 'bg-blue-50 text-blue-800'
                              : order.orderStatus === 'cancelled'
                              ? 'bg-rose-50 text-rose-800'
                              : 'bg-amber-50 text-amber-800'
                          }`}>
                            {order.orderStatus.charAt(0).toUpperCase() + order.orderStatus.slice(1)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right text-slate-600">
                          {Array.isArray(order.items) ? order.items.length : 1}
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-slate-900">
                          ৳{(order.totalAmount || 0).toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setPrintInvoiceOrder(order)}
                              className="p-1 rounded text-slate-400 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
                              title="Print Invoice"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setActiveDrawerOrder(order)}
                              className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px] transition-colors cursor-pointer"
                            >
                              {isBn ? 'বিস্তারিত' : 'View'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="p-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span>
                  {isBn ? `পৃষ্ঠা ${currentPage} / ${totalPages}` : `Page ${currentPage} of ${totalPages}`}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    disabled={currentPage <= 1}
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    className="px-2.5 py-1 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                  >
                    Previous
                  </button>
                  <button
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    className="px-2.5 py-1 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. MODALS & DRAWERS (REUSING EXISTING ORDER ARCHITECTURE)                  */}
      {/* ========================================================================= */}

      {/* Create Order Modal */}
      {isCreateModalOpen && (
        <CreateOrderModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          activeStore={activeStore}
          products={safeProducts}
          customers={safeCustomers}
          language={language}
          shippingSettings={shippingSettings}
          onCreateOrder={(newOrder) => {
            if (onCreateOrder) onCreateOrder(newOrder);
            setIsCreateModalOpen(false);
          }}
        />
      )}

      {/* Order Details Drawer */}
      {activeDrawerOrder && (
        <OrderDetailsDrawer
          order={activeDrawerOrder}
          isOpen={Boolean(activeDrawerOrder)}
          onClose={() => setActiveDrawerOrder(null)}
          language={language}
          activeStore={activeStore}
          onUpdateOrderStatus={onUpdateOrderStatus}
          onUpdatePaymentStatus={onUpdatePaymentStatus || (() => {})}
          onUpdateOrderNotes={onUpdateOrderNotes || (() => {})}
          onOpenPrintInvoice={(ord) => setPrintInvoiceOrder(ord)}
          onInitiateReturn={onOpenReturnModal}
        />
      )}

      {/* Print Thermal Invoice Modal */}
      {printInvoiceOrder && (
        <PrintInvoiceModal
          order={printInvoiceOrder}
          isOpen={Boolean(printInvoiceOrder)}
          onClose={() => setPrintInvoiceOrder(null)}
          activeStore={activeStore}
          language={language}
        />
      )}

      {/* Learn More About Orders Modal */}
      {isLearnMoreOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  {isBn ? 'অর্ডার পরিচালনা ও ফুলফিলমেন্ট নির্দেশিকা' : 'Managing Your Orders on Shanju'}
                </h3>
              </div>
              <button
                onClick={() => setIsLearnMoreOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-800 block mb-1">
                  1. Order Statuses (অর্ডার স্ট্যাটাস):
                </span>
                <p>
                  Pending $\rightarrow$ Confirmed $\rightarrow$ Processing $\rightarrow$ Packed $\rightarrow$ Shipped $\rightarrow$ Delivered.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-800 block mb-1">
                  2. Automated Courier Dispatch (কুরিয়ার অটোমেশন):
                </span>
                <p>
                  One-click dispatch to Steadfast, Pathao, and RedX couriers with real-time tracking number sync.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-800 block mb-1">
                  3. Invoices & Packing Slips (চালান প্রিন্ট):
                </span>
                <p>
                  Generate POS-ready thermal invoices and 4×6 inch parcel shipping labels directly from each order.
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setIsLearnMoreOpen(false)}
                className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs cursor-pointer"
              >
                {isBn ? 'বুঝেছি' : 'Got it'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
