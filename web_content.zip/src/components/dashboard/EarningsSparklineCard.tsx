import React from 'react';
import { TrendingUp, Coins } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const EarningsSparklineCard: React.FC = () => {
  const { transactions } = useApp();

  // Generate 7 days sparkline data
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dataPoints = [60, 85, 45, 120, 100, 160, 210];
  const maxVal = Math.max(...dataPoints, 1);
  const minVal = Math.min(...dataPoints, 0);

  const width = 280;
  const height = 64;
  const points = dataPoints.map((val, idx) => {
    const x = (idx / (dataPoints.length - 1)) * width;
    const y = height - ((val - minVal) / (maxVal - minVal || 1)) * (height - 12) - 6;
    return { x, y, val };
  });

  const pathD = points.reduce((acc, pt, idx) => {
    if (idx === 0) return `M ${pt.x} ${pt.y}`;
    const prev = points[idx - 1];
    const cpX1 = prev.x + (pt.x - prev.x) / 2;
    const cpX2 = prev.x + (pt.x - prev.x) / 2;
    return `${acc} C ${cpX1} ${prev.y}, ${cpX2} ${pt.y}, ${pt.x} ${pt.y}`;
  }, '');

  const areaD = `${pathD} L ${width} ${height} L 0 ${height} Z`;

  return (
    <div className="p-2.5 sm:p-4 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-slate-900/90 via-slate-900 to-slate-950 border border-slate-800 shadow-xl space-y-2 sm:space-y-3 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
            <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4" />
          </div>
          <div>
            <h3 className="text-[10px] sm:text-xs font-black uppercase tracking-wider text-slate-200">
              7-Day Earnings Progress
            </h3>
            <span className="text-[9px] sm:text-[11px] text-slate-400">
              Last 7 days coin activity
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1 px-1.5 py-0.5 sm:px-2.5 sm:py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[9px] sm:text-[11px] font-black">
          <span>+32.4%</span>
        </div>
      </div>

      {/* SVG Sparkline Chart */}
      <div className="pt-1 sm:pt-2">
        <div className="relative w-full h-14 sm:h-16">
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
            <defs>
              <linearGradient id="sparklineGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Area fill */}
            <path d={areaD} fill="url(#sparklineGrad)" />

            {/* Line stroke */}
            <path
              d={pathD}
              fill="none"
              stroke="#10b981"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Data points */}
            {points.map((pt, idx) => (
              <g key={idx} className="group/pt cursor-pointer">
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r="3.5"
                  className="fill-slate-900 stroke-emerald-400 stroke-2 transition-all duration-200 hover:r-5 hover:fill-emerald-400"
                />
              </g>
            ))}
          </svg>
        </div>

        {/* Days axis labels */}
        <div className="flex justify-between text-[8px] sm:text-[10px] font-semibold text-slate-500 pt-1 px-1">
          {days.map((day, idx) => (
            <span key={idx}>{day}</span>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between pt-1.5 sm:pt-2 border-t border-slate-800/80 text-[10px] sm:text-xs">
        <span className="text-slate-400">Total this week</span>
        <span className="font-black text-amber-400 flex items-center gap-1">
          <Coins className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
          <span>780 Coins</span>
        </span>
      </div>
    </div>
  );
};
