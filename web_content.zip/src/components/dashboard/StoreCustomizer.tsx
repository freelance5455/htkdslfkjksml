import React, { useState } from 'react';
import { 
  Palette, 
  Type, 
  Image as ImageIcon, 
  Smartphone, 
  Monitor, 
  Tablet, 
  Check, 
  Sparkles, 
  Save, 
  ExternalLink,
  Sliders,
  Eye,
  Megaphone
} from 'lucide-react';
import { Store, StoreTheme, Language } from '../../types';

interface StoreCustomizerProps {
  activeStore: Store;
  language: Language;
  onUpdateStoreTheme: (storeId: string, updatedTheme: Partial<StoreTheme>, storeName?: string) => void;
  onOpenStorefront: () => void;
}

const COLOR_PRESETS = [
  { name: 'Emerald Green', hex: '#059669', accent: '#10b981' },
  { name: 'Royal Blue', hex: '#2563eb', accent: '#3b82f6' },
  { name: 'Ruby Rose', hex: '#e11d48', accent: '#f43f5e' },
  { name: 'Amber Gold', hex: '#d97706', accent: '#f59e0b' },
  { name: 'Deep Purple', hex: '#7c3aed', accent: '#8b5cf6' },
  { name: 'Slate Minimal', hex: '#0f172a', accent: '#334155' },
];

const BANNER_PRESETS = [
  {
    label: 'Fashion & Apparel',
    url: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Gadgets & Tech',
    url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Organic & Grocery',
    url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Minimalist Studio',
    url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80',
  },
];

export const StoreCustomizer: React.FC<StoreCustomizerProps> = ({
  activeStore,
  language,
  onUpdateStoreTheme,
  onOpenStorefront,
}) => {
  const isBn = language === 'bn';

  // Form states
  const [storeName, setStoreName] = useState(activeStore.name);
  const [primaryColor, setPrimaryColor] = useState(activeStore.theme.primaryColor);
  const [accentColor, setAccentColor] = useState(activeStore.theme.accentColor);
  const [showAnnouncement, setShowAnnouncement] = useState(activeStore.theme.showAnnouncement);
  const [announcementText, setAnnouncementText] = useState(activeStore.theme.announcementText);
  const [announcementTextBn, setAnnouncementTextBn] = useState(activeStore.theme.announcementTextBn);
  const [heroHeadline, setHeroHeadline] = useState(activeStore.theme.heroHeadline);
  const [heroHeadlineBn, setHeroHeadlineBn] = useState(activeStore.theme.heroHeadlineBn);
  const [heroSubheadline, setHeroSubheadline] = useState(activeStore.theme.heroSubheadline);
  const [heroSubheadlineBn, setHeroSubheadlineBn] = useState(activeStore.theme.heroSubheadlineBn);
  const [heroBannerImage, setHeroBannerImage] = useState(activeStore.theme.heroBannerImage);
  const [layoutStyle, setLayoutStyle] = useState<StoreTheme['layoutStyle']>(activeStore.theme.layoutStyle);

  // Device preview view mode
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateStoreTheme(
      activeStore.id,
      {
        primaryColor,
        accentColor,
        showAnnouncement,
        announcementText,
        announcementTextBn,
        heroHeadline,
        heroHeadlineBn,
        heroSubheadline,
        heroSubheadlineBn,
        heroBannerImage,
        layoutStyle,
      },
      storeName
    );

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Top Bar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
            {isBn ? 'স্টোর ডিজাইন ও থিম কাস্টমাইজার' : 'Live Storefront Customizer'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'আপনার ব্র্যান্ডের রঙ, নোটিফিকেশন ব্যানার, হিরো সেকশন ও লেআউট লাইভ পরিবর্তন করুন।' 
              : 'Tune your brand identity, announcement banner, typography, and responsive hero banner live.'}
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {savedSuccess && (
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 flex items-center gap-1 animate-in fade-in">
              <Check className="w-3.5 h-3.5" />
              {isBn ? 'সফলভাবে সংরক্ষিত!' : 'Published live!'}
            </span>
          )}

          <button
            id="save-theme-customizer-btn"
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isBn ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save & Publish'}</span>
          </button>

          <button
            id="open-live-customizer-preview-btn"
            onClick={onOpenStorefront}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>{isBn ? 'ফুলস্ক্রিন প্রিভিউ' : 'Fullscreen'}</span>
          </button>
        </div>
      </div>

      {/* Main Split Grid: Controls on Left, Responsive Device Frame on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Customizer Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          <form onSubmit={handleSave} className="space-y-4">
            {/* Store Brand Name */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                {isBn ? 'ব্র্যান্ডের তথ্য' : 'Store Identity'}
              </h2>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isBn ? 'স্টোরের নাম' : 'Store Display Name'}
                </label>
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Color Palette */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isBn ? 'ব্র্যান্ড থিম কালার' : 'Brand Theme Color'}</span>
                </h2>
                <span className="text-[11px] font-mono text-slate-500">{primaryColor}</span>
              </div>

              <div className="grid grid-cols-6 gap-2">
                {COLOR_PRESETS.map((c) => (
                  <button
                    type="button"
                    key={c.name}
                    onClick={() => {
                      setPrimaryColor(c.hex);
                      setAccentColor(c.accent);
                    }}
                    className={`h-9 rounded-xl flex items-center justify-center transition-transform ${
                      primaryColor === c.hex ? 'ring-2 ring-emerald-500 scale-105 shadow' : 'opacity-80 hover:opacity-100'
                    }`}
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  >
                    {primaryColor === c.hex && <Check className="w-4 h-4 text-white" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Announcement Bar */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Megaphone className="w-3.5 h-3.5 text-slate-600" />
                  <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    {isBn ? 'অ্যানাউন্সমেন্ট বার' : 'Top Announcement Bar'}
                  </h2>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showAnnouncement}
                    onChange={(e) => setShowAnnouncement(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {showAnnouncement && (
                <div className="space-y-2 pt-1">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {isBn ? 'ব্যানার টেক্সট (বাংলা)' : 'Announcement Text (Bengali)'}
                    </label>
                    <input
                      type="text"
                      value={announcementTextBn}
                      onChange={(e) => setAnnouncementTextBn(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Announcement Text (English)
                    </label>
                    <input
                      type="text"
                      value={announcementText}
                      onChange={(e) => setAnnouncementText(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Hero Headline & Image */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
              <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-slate-600" />
                <span>{isBn ? 'হিরো ব্যানার ও টেক্সট' : 'Hero Banner & Copy'}</span>
              </h2>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {isBn ? 'প্রধান শিরোনাম (Headline)' : 'Main Headline'}
                </label>
                <input
                  type="text"
                  value={isBn ? heroHeadlineBn : heroHeadline}
                  onChange={(e) => {
                    if (isBn) setHeroHeadlineBn(e.target.value);
                    else setHeroHeadline(e.target.value);
                  }}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {isBn ? 'সাব-টাইটেল (Subtitle)' : 'Subtitle'}
                </label>
                <textarea
                  rows={2}
                  value={isBn ? heroSubheadlineBn : heroSubheadline}
                  onChange={(e) => {
                    if (isBn) setHeroSubheadlineBn(e.target.value);
                    else setHeroSubheadline(e.target.value);
                  }}
                  className="w-full p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                  {isBn ? 'হিরো ব্যাকগ্রাউন্ড ইমেজ' : 'Hero Background Image'}
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {BANNER_PRESETS.map((bp, i) => (
                    <button
                      type="button"
                      key={i}
                      onClick={() => setHeroBannerImage(bp.url)}
                      className={`h-12 rounded-lg overflow-hidden border-2 transition-transform ${
                        heroBannerImage === bp.url ? 'border-emerald-500 scale-105' : 'border-slate-200'
                      }`}
                    >
                      <img src={bp.url} alt={bp.label} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </form>
        </div>

        {/* Live Device Interactive Frame (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 rounded-3xl p-5 border border-slate-800 flex flex-col items-center justify-between">
          {/* Device Controls Bar */}
          <div className="w-full flex items-center justify-between pb-4 border-b border-slate-800 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span className="font-semibold text-slate-200">
                {isBn ? 'লাইভ ডিভাইস ভিউ' : 'Live Responsive Frame'}
              </span>
            </div>

            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setPreviewDevice('desktop')}
                className={`p-1.5 rounded-lg transition-colors ${
                  previewDevice === 'desktop' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Desktop View"
              >
                <Monitor className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setPreviewDevice('tablet')}
                className={`p-1.5 rounded-lg transition-colors ${
                  previewDevice === 'tablet' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Tablet View"
              >
                <Tablet className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setPreviewDevice('mobile')}
                className={`p-1.5 rounded-lg transition-colors ${
                  previewDevice === 'mobile' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Mobile View"
              >
                <Smartphone className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Simulated Device Screen */}
          <div 
            className={`mt-4 bg-white rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 w-full ${
              previewDevice === 'mobile' 
                ? 'max-w-xs border-8 border-slate-800' 
                : previewDevice === 'tablet' 
                ? 'max-w-md border-4 border-slate-800' 
                : 'w-full'
            }`}
          >
            {/* Announcement Banner */}
            {showAnnouncement && (
              <div 
                className="py-1.5 px-3 text-[10px] text-white text-center font-bold truncate transition-colors"
                style={{ backgroundColor: primaryColor }}
              >
                {isBn ? announcementTextBn : announcementText}
              </div>
            )}

            {/* Storefront Nav Header */}
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="font-extrabold text-sm text-slate-900">{storeName}</span>
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
                <span>Shop</span>
                <span>Cart (0)</span>
              </div>
            </div>

            {/* Hero Banner inside preview */}
            <div className="relative h-48 sm:h-60 overflow-hidden flex items-center justify-center p-6 text-center text-white">
              <img
                src={heroBannerImage}
                alt="Banner"
                className="absolute inset-0 w-full h-full object-cover brightness-50"
              />
              <div className="relative z-10 max-w-sm">
                <h3 className="text-base sm:text-lg font-black leading-tight drop-shadow">
                  {isBn ? heroHeadlineBn : heroHeadline}
                </h3>
                <p className="text-[11px] text-slate-200 mt-1 line-clamp-2 drop-shadow">
                  {isBn ? heroSubheadlineBn : heroSubheadline}
                </p>
                <button
                  type="button"
                  className="mt-3 px-4 py-1.5 rounded-lg text-xs font-bold text-white shadow transition-all"
                  style={{ backgroundColor: primaryColor }}
                >
                  {isBn ? 'এখনই কিনুন' : 'Shop Now'}
                </button>
              </div>
            </div>

            {/* Sample Products Grid in Preview */}
            <div className="p-4 bg-slate-50">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                Featured Collection
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-xs">
                  <div className="h-16 bg-slate-100 rounded-lg mb-1.5 overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=300&q=80" 
                      className="w-full h-full object-cover" 
                      alt="Sample" 
                    />
                  </div>
                  <div className="text-[10px] font-bold text-slate-800 truncate">Silk Festive Panjabi</div>
                  <div className="text-[11px] font-black text-slate-900 mt-0.5">৳৩,৪৫০</div>
                </div>

                <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-xs">
                  <div className="h-16 bg-slate-100 rounded-lg mb-1.5 overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=300&q=80" 
                      className="w-full h-full object-cover" 
                      alt="Sample" 
                    />
                  </div>
                  <div className="text-[10px] font-bold text-slate-800 truncate">Jamdani Saree</div>
                  <div className="text-[11px] font-black text-slate-900 mt-0.5">৳৬,৮০০</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 text-center text-[11px] text-slate-400">
            {isBn ? 'প্রিভিউ ডিভাইস পরিবর্তন করে মোবাইল অপটিমাইজেশন নিশ্চিত করুন' : 'Test responsive appearance on mobile, tablet, and desktop'}
          </div>
        </div>
      </div>
    </div>
  );
};
