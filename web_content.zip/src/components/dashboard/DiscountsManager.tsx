import React, { useState } from 'react';
import { 
  Percent, 
  Plus, 
  Tag, 
  Check, 
  Copy, 
  Calendar, 
  Trash2, 
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { Language } from '../../types';

interface DiscountCode {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minPurchase: number;
  usageCount: number;
  status: 'active' | 'expired';
  expiresAt: string;
}

const initialDiscounts: DiscountCode[] = [
  {
    id: 'disc-1',
    code: 'EID2026',
    type: 'percentage',
    value: 15,
    minPurchase: 1000,
    usageCount: 42,
    status: 'active',
    expiresAt: '2026-12-31'
  },
  {
    id: 'disc-2',
    code: 'WELCOME100',
    type: 'fixed',
    value: 100,
    minPurchase: 500,
    usageCount: 88,
    status: 'active',
    expiresAt: '2026-10-30'
  }
];

export const DiscountsManager: React.FC<{ language: Language }> = ({ language }) => {
  const isBn = language === 'bn';
  const [discounts, setDiscounts] = useState<DiscountCode[]>(initialDiscounts);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Form state
  const [newCode, setNewCode] = useState('');
  const [newType, setNewType] = useState<'percentage' | 'fixed'>('percentage');
  const [newValue, setNewValue] = useState(10);
  const [newMinPurchase, setNewMinPurchase] = useState(500);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 1500);
  };

  const handleCreateDiscount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode.trim()) return;
    const item: DiscountCode = {
      id: `disc-${Date.now()}`,
      code: newCode.trim().toUpperCase(),
      type: newType,
      value: Number(newValue),
      minPurchase: Number(newMinPurchase),
      usageCount: 0,
      status: 'active',
      expiresAt: '2026-12-31'
    };
    setDiscounts([item, ...discounts]);
    setNewCode('');
    setIsCreateOpen(false);
  };

  const handleDelete = (id: string) => {
    setDiscounts(discounts.filter(d => d.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Percent className="w-5 h-5 text-emerald-600" />
            <span>{isBn ? 'ডিসকাউন্ট ও কুপন কোডস' : 'Discounts & Coupon Codes'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'গ্রাহকদের জন্য আকর্ষণীয় প্রোমো কোড ও সেলস ভাউচার পরিচালনা করুন।' 
              : 'Create percentage or fixed cash discounts to drive higher checkout conversion.'}
          </p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{isBn ? 'নতুন কুপন তৈরি করুন' : 'Create Discount'}</span>
        </button>
      </div>

      {/* Create Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full p-6 text-xs text-slate-700">
            <h3 className="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Tag className="w-4 h-4 text-emerald-600" />
              <span>{isBn ? 'নতুন ডিসকাউন্ট কুপন যুক্ত করুন' : 'Add New Discount Coupon'}</span>
            </h3>

            <form onSubmit={handleCreateDiscount} className="space-y-4">
              <div>
                <label className="block font-semibold mb-1 text-slate-800">
                  {isBn ? 'কুপন কোড (যেমন: SAVE20)' : 'Discount Code (e.g. SAVE20)'}
                </label>
                <input
                  type="text"
                  required
                  placeholder="EID2026"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl uppercase font-mono font-bold text-slate-900 focus:outline-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-800">
                    {isBn ? 'ডিসকাউন্টের ধরন' : 'Discount Type'}
                  </label>
                  <select
                    value={newType}
                    onChange={(e: any) => setNewType(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white text-slate-800"
                  >
                    <option value="percentage">{isBn ? 'শতাংশ (%)' : 'Percentage (%)'}</option>
                    <option value="fixed">{isBn ? 'নির্দিষ্ট টাকা (৳)' : 'Fixed Amount (৳)'}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-800">
                    {isBn ? 'মান (পরিমাণ)' : 'Discount Value'}
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newValue}
                    onChange={(e) => setNewValue(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-800">
                  {isBn ? 'সর্বনিম্ন ক্রয়ের পরিমাণ (৳)' : 'Minimum Purchase (৳)'}
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={newMinPurchase}
                  onChange={(e) => setNewMinPurchase(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Coupon'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Discounts Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3.5 px-4">{isBn ? 'কুপন কোড' : 'Code'}</th>
                <th className="py-3.5 px-4">{isBn ? 'ডিসকাউন্ট' : 'Discount'}</th>
                <th className="py-3.5 px-4">{isBn ? 'সর্বনিম্ন ক্রয়' : 'Min Spend'}</th>
                <th className="py-3.5 px-4">{isBn ? 'ব্যবহার সংখ্যা' : 'Usage'}</th>
                <th className="py-3.5 px-4">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                <th className="py-3.5 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
              {discounts.map((disc) => (
                <tr key={disc.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {disc.code}
                      </span>
                      <button
                        onClick={() => handleCopy(disc.code)}
                        className="p-1 text-slate-400 hover:text-emerald-600 transition-colors"
                        title="Copy Code"
                      >
                        {copiedCode === disc.code ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-bold text-emerald-600">
                    {disc.type === 'percentage' ? `${disc.value}% ছাড়` : `৳${disc.value} ক্যাশ ছাড়`}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">
                    ৳{disc.minPurchase.toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">
                    {disc.usageCount} {isBn ? 'বার' : 'times'}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {isBn ? 'সক্রিয়' : 'Active'}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => handleDelete(disc.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete coupon"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
