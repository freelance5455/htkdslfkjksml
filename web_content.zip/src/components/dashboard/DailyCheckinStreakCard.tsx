import React, { useState } from 'react';
import { 
  Flame, 
  CheckCircle2, 
  Sparkles, 
  Crown, 
  Gift, 
  Lock, 
  Check, 
  Zap, 
  Calendar,
  ChevronRight,
  TrendingUp
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface DailyCheckinStreakCardProps {
  onOpenStreakModal: () => void;
}

const STREAK_DAYS = [
  { day: 1, baseCoins: 12, isMega: false },
  { day: 2, baseCoins: 20, isMega: false },
  { day: 3, baseCoins: 30, isMega: false },
  { day: 4, baseCoins: 45, isMega: false },
  { day: 5, baseCoins: 60, isMega: false },
  { day: 6, baseCoins: 75, isMega: false },
  { day: 7, baseCoins: 120, isMega: true },
];

export const DailyCheckinStreakCard: React.FC<DailyCheckinStreakCardProps> = ({
  onOpenStreakModal,
}) => {
  const { 
    currentUser, 
    membershipPlans, 
    claimDailyCheckin, 
    hasClaimedDailyToday, 
    systemSettings,
    language 
  } = useApp();

  const [claimMessage, setClaimMessage] = useState<string | null>(null);
  const [justClaimed, setJustClaimed] = useState(false);

  const isClaimedToday = hasClaimedDailyToday();
  const streakDays = currentUser ? (currentUser.checkinStreak || 0) : 0;
  
  const currentPlan = currentUser
    ? membershipPlans.find((p) => p.id === currentUser.membershipTier) || membershipPlans[0]
    : membershipPlans[0];
  const multiplier = currentPlan.rewardMultiplier || 1.0;

  // Active day in the 7-day cycle (1 to 7)
  const currentCycleDay = isClaimedToday 
    ? (streakDays % 7 === 0 ? 7 : streakDays % 7)
    : ((streakDays % 7) + 1);

  // Projected coins for claiming today
  const nextStreak = streakDays + (isClaimedToday ? 0 : 1);
  const streakBonus = Math.min(nextStreak * 2, 20);
  const baseReward = systemSettings.dailyCheckinBaseCoins || 12;
  const projectedCoins = Math.round((baseReward + streakBonus) * multiplier);

  const handleClaim = () => {
    if (isClaimedToday) return;

    const result = claimDailyCheckin();
    setClaimMessage(result.message);

    if (result.success) {
      setJustClaimed(true);
      confetti({
        particleCount: 85,
        spread: 70,
        origin: { y: 0.6 },
      });
      setTimeout(() => {
        setJustClaimed(false);
      }, 4000);
    }
    setTimeout(() => {
      setClaimMessage(null);
    }, 4500);
  };

  const daysUntilMega = 7 - (isClaimedToday ? (streakDays % 7 || 7) : (streakDays % 7));

  return (
    <div className="p-2.5 sm:p-4 md:p-5 rounded-2xl sm:rounded-3xl bg-gradient-to-b from-slate-900/95 via-slate-900/90 to-slate-950 border border-amber-500/25 shadow-xl space-y-2.5 sm:space-y-4 relative overflow-hidden">
      
      {/* Decorative background glow */}
      <div className="absolute top-0 right-0 w-44 h-44 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header section with streak count and multiplier */}
      <div className="flex items-center justify-between gap-2 sm:gap-2.5 relative z-10">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <div className="w-8 h-8 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/25 shrink-0">
            <Flame className="w-4 h-4 sm:w-6 sm:h-6 fill-current animate-pulse text-slate-950" />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
              <h3 className="text-[11px] sm:text-sm font-black text-white flex items-center gap-1">
                <span>Daily Check-in Streak</span>
              </h3>
              <span className="text-[8px] sm:text-[10px] font-black px-1.5 sm:px-2 py-0.2 sm:py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-0.5 shrink-0">
                <span>🔥 {streakDays}d</span>
              </span>
            </div>
            <p className="text-[9px] sm:text-[11px] text-slate-400 truncate">
              Check in daily to build streak & multiply coin bonus
            </p>
          </div>
        </div>

        {/* Tier multiplier pill */}
        <div className="text-right shrink-0">
          <span className="text-[8px] sm:text-[10px] font-bold uppercase tracking-wider block text-slate-400">
            Multiplier
          </span>
          <span className="text-[10px] sm:text-xs font-black text-emerald-400 flex items-center justify-end gap-0.5 sm:gap-1">
            <Zap className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current" />
            <span>{multiplier}x</span>
          </span>
        </div>
      </div>

      {/* 7-Day Visual Progression Cards */}
      <div className="space-y-1 relative z-10">
        <div className="flex items-center justify-between text-[9px] sm:text-[11px] text-slate-400 font-semibold px-0.5">
          <span>7-Day Reward Roadmap</span>
          <button
            type="button"
            onClick={onOpenStreakModal}
            className="text-amber-400 hover:text-amber-300 flex items-center gap-0.5 cursor-pointer text-[9px] sm:text-[11px] font-bold min-h-[32px] sm:min-h-0"
          >
            <span>Rules</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 sm:gap-1.5 pt-0.5">
          {STREAK_DAYS.map((item) => {
            // Status determination
            const isCompleted = isClaimedToday 
              ? item.day <= (streakDays % 7 === 0 ? 7 : streakDays % 7)
              : item.day < ((streakDays % 7) + 1);
            
            const isToday = !isClaimedToday && item.day === ((streakDays % 7) + 1);
            const isFuture = !isCompleted && !isToday;
            const rewardCoins = Math.round(item.baseCoins * multiplier);

            return (
              <div
                key={item.day}
                onClick={isToday ? handleClaim : onOpenStreakModal}
                className={`relative p-0.5 sm:p-2 rounded-xl sm:rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-between min-h-[58px] sm:min-h-[76px] ${
                  isToday
                    ? 'bg-gradient-to-b from-amber-500/25 to-orange-500/15 border-amber-500 ring-2 ring-amber-500/30 shadow-md shadow-amber-500/20 scale-[1.02] z-10'
                    : isCompleted
                    ? 'bg-emerald-500/10 border-emerald-500/35 text-emerald-300'
                    : item.isMega
                    ? 'bg-purple-950/40 border-purple-500/40 text-purple-300'
                    : 'bg-slate-950/70 border-slate-800 text-slate-500 hover:border-slate-700'
                }`}
              >
                {/* Day Tag */}
                <div className="flex items-center gap-0.5">
                  <span className={`text-[7px] sm:text-[9px] uppercase font-black ${
                    isToday ? 'text-amber-300' : isCompleted ? 'text-emerald-400' : item.isMega ? 'text-purple-300' : 'text-slate-400'
                  }`}>
                    D{item.day}
                  </span>
                  {item.isMega && <Crown className="w-2 h-2 sm:w-2.5 sm:h-2.5 text-amber-400 fill-current" />}
                </div>

                {/* Center Icon / Checkmark */}
                <div className="my-0.5">
                  {isCompleted ? (
                    <div className="w-3.5 h-3.5 sm:w-5 sm:h-5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-xs">
                      <Check className="w-2 h-2 sm:w-3 sm:h-3 stroke-[3]" />
                    </div>
                  ) : isToday ? (
                    <div className="w-3.5 h-3.5 sm:w-5 sm:h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black text-[8px] animate-bounce shadow-xs">
                      <Flame className="w-2.5 h-2.5 fill-current" />
                    </div>
                  ) : item.isMega ? (
                    <Gift className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-400 animate-pulse" />
                  ) : (
                    <Lock className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-slate-600" />
                  )}
                </div>

                {/* Coin Reward */}
                <span className={`text-[8px] sm:text-[11px] font-black tracking-tight ${
                  isToday ? 'text-amber-300 font-extrabold' : isCompleted ? 'text-emerald-300' : item.isMega ? 'text-amber-400 font-black' : 'text-slate-400'
                }`}>
                  +{rewardCoins}
                </span>

                {/* Mega Tag for Day 7 */}
                {item.isMega && (
                  <span className="absolute -top-1.5 -right-0.5 px-0.5 sm:px-1 py-0.2 rounded-md bg-amber-500 text-slate-950 text-[7px] font-black uppercase tracking-wider shadow-xs">
                    ★
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Dynamic Milestone / Encouragement message */}
      <div className="p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400 shrink-0" />
          <p className="text-[10px] sm:text-[11px] text-slate-300 truncate">
            {isClaimedToday ? (
              <span>Great job! You claimed Day {currentCycleDay}. Come back tomorrow to continue your streak!</span>
            ) : daysUntilMega > 0 ? (
              <span>Only <strong className="text-amber-300">{daysUntilMega} {daysUntilMega === 1 ? 'day' : 'days'}</strong> away from the <strong>Day 7 Mega Bonus (+{Math.round(150 * multiplier)} Coins)</strong>!</span>
            ) : (
              <span>Today is Day 7! Claim your <strong className="text-amber-300">Mega Jackpot Bonus</strong> now!</span>
            )}
          </p>
        </div>

        <span className="text-[9px] sm:text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 sm:px-2 py-0.5 rounded-md border border-emerald-500/20 shrink-0">
          +{projectedCoins} Coins
        </span>
      </div>

      {/* Claim Message feedback */}
      {claimMessage && (
        <div className="p-2.5 sm:p-3 rounded-xl sm:rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[11px] sm:text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400 shrink-0" />
          <span>{claimMessage}</span>
        </div>
      )}

      {/* Primary Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 sm:gap-2 pt-0.5">
        <button
          type="button"
          onClick={handleClaim}
          disabled={isClaimedToday}
          className={`py-2.5 sm:py-3 px-3 sm:px-4 rounded-xl sm:rounded-2xl font-black text-[11px] sm:text-xs transition-all flex items-center justify-center gap-1.5 sm:gap-2 min-h-[44px] cursor-pointer ${
            isClaimedToday
              ? 'bg-slate-800/80 text-slate-400 border border-slate-700/60 cursor-default'
              : 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:opacity-95 text-slate-950 font-black shadow-lg shadow-amber-500/25 active:scale-95'
          }`}
        >
          {isClaimedToday ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />
              <span>Day {currentCycleDay} Claimed for Today</span>
            </>
          ) : (
            <>
              <Flame className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-950 fill-current animate-bounce" />
              <span>Claim Today's Bonus (+{projectedCoins} Coins)</span>
              <Sparkles className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-slate-950" />
            </>
          )}
        </button>

        <button
          type="button"
          onClick={onOpenStreakModal}
          className="py-2.5 sm:py-3 px-3 sm:px-4 rounded-xl sm:rounded-2xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 font-bold text-[11px] sm:text-xs active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5 sm:gap-2 min-h-[44px]"
        >
          <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400" />
          <span>Open Full Streak Board</span>
        </button>
      </div>

    </div>
  );
};
