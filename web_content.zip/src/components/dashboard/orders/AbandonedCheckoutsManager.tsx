import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  RefreshCw, 
  MessageSquare, 
  Phone, 
  CheckCircle2, 
  Copy, 
  Check, 
  AlertTriangle,
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { AbandonedCheckout, Store, Language, Order } from '../../../types';

interface AbandonedCheckoutsManagerProps {
  checkouts: AbandonedCheckout[];
  activeStore: Store;
  language: Language;
  onUpdateStatus: (id: string, status: 'incomplete' | 'recovered' | 'blocked') => void;
  onRecoverToOrder?: (checkout: AbandonedCheckout) => void;
}

export const AbandonedCheckoutsManager: React.FC<AbandonedCheckoutsManagerProps> = ({
  checkouts,
  activeStore,
  language,
  onUpdateStatus,
  onRecoverToOrder
}) => {
  const isBn = language === 'bn';
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'incomplete' | 'recovered' | 'blocked'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const storeCheckouts = (Array.isArray(checkouts) ? checkouts : []).filter(c => c && c.storeId === activeStore?.id);

  const filtered = storeCheckouts.filter(c => {
    const matchesSearch = 
      (c.customerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.customerPhone || '').includes(searchTerm) ||
      (c.customerEmail || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || c.recoveryStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCopyReminder = (checkout: AbandonedCheckout) => {
    const text = isBn 
      ? `প্রিয় ${checkout.customerName}, আপনার ${activeStore.name}-এর কার্টে কিছু পণ্য সংরক্ষিত আছে। অর্ডারটি সম্পন্ন করতে আমাদের সাথে যোগাযোগ করুন। ধন্যবাদ!`
      : `Dear ${checkout.customerName}, you left some items in your cart at ${activeStore.name}. Contact us or revisit the store to complete your checkout!`;
    navigator.clipboard.writeText(text);
    setCopiedId(checkout.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-amber-500" />
            <span>{isBn ? 'অ্যাব্যান্ডনড চেকআউটস (Abandoned Checkouts)' : 'Abandoned Checkouts'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'যে সকল গ্রাহক কার্টে পণ্য যোগ করে চেকআউট সম্পন্ন করেননি তাদের তালিকা ও রিকভারি স্ট্যাটাস।' 
              : 'Recover lost sales by tracking visitors who entered checkout details but did not place the order.'}
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="font-bold text-slate-700">
            {filtered.length} {isBn ? 'টি সেশন' : 'sessions'}
          </span>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row items-center gap-3">
        <div className="flex-1 flex items-center gap-2 w-full">
          <Search className="w-4 h-4 text-slate-400 ml-2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={isBn ? 'গ্রাহকের নাম বা ফোন দিয়ে খুঁজুন...' : 'Search by customer name or phone...'}
            className="w-full text-xs text-slate-800 bg-transparent focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full sm:w-auto">
          {(['all', 'incomplete', 'recovered', 'blocked'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-colors cursor-pointer ${
                statusFilter === s
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs">
            <ShoppingBag className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <p className="font-bold text-slate-700">{isBn ? 'কোনো অ্যাব্যান্ডনড চেকআউট পাওয়া যায়নি।' : 'No abandoned checkouts found.'}</p>
            <p className="text-slate-400 mt-1">{isBn ? 'গ্রাহকরা যখন চেকআউট পেজে এসে ব্যাক করবে তখন স্বয়ংক্রিয়ভাবে রেকর্ড হবে।' : 'Checkout drops will automatically appear here for sales follow-up.'}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3.5 px-4">Customer</th>
                  <th className="py-3.5 px-4">Contact</th>
                  <th className="py-3.5 px-4">Cart Items</th>
                  <th className="py-3.5 px-4">Cart Value</th>
                  <th className="py-3.5 px-4">Date & Time</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Recovery Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {item.customerName || 'Anonymous Visitor'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      <p>{item.customerPhone || 'N/A'}</p>
                      {item.customerEmail && <p className="text-[10px] text-slate-400">{item.customerEmail}</p>}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {item.items.map(i => `${i.name} (×${i.quantity})`).join(', ') || 'Items in cart'}
                    </td>
                    <td className="py-3.5 px-4 font-black text-slate-900">
                      ৳{item.cartTotal.toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 text-[11px] text-slate-400">
                      {item.createdAt ? new Date(item.createdAt).toLocaleString(isBn ? 'bn-BD' : 'en-US') : 'N/A'}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        item.recoveryStatus === 'recovered'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : item.recoveryStatus === 'blocked'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        {item.recoveryStatus.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleCopyReminder(item)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold transition-colors cursor-pointer"
                          title="Copy SMS/WhatsApp reminder"
                        >
                          {copiedId === item.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedId === item.id ? 'Copied' : 'Reminder'}</span>
                        </button>

                        {item.recoveryStatus !== 'recovered' && (
                          <button
                            onClick={() => onUpdateStatus(item.id, 'recovered')}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold transition-colors cursor-pointer"
                          >
                            Mark Recovered
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
