import React from 'react';
import { X, Printer, Store as StoreIcon, CheckCircle2 } from 'lucide-react';
import { Order, Store, Language } from '../../../types';

interface PrintInvoiceModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  activeStore: Store;
  language: Language;
}

export const PrintInvoiceModal: React.FC<PrintInvoiceModalProps> = ({
  order,
  isOpen,
  onClose,
  activeStore,
  language
}) => {
  const isBn = language === 'bn';
  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-200">
        {/* Modal Controls (Hidden in Print) */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 print:hidden">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800 text-xs">
              {isBn ? 'ইনভয়েস প্রিভিউ ও প্রিন্ট' : 'Invoice Preview & Thermal Print'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{isBn ? 'প্রিন্ট করুন' : 'Print Invoice'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Document */}
        <div id="printable-invoice" className="p-8 sm:p-10 text-slate-900 bg-white font-sans text-xs space-y-6">
          {/* Header */}
          <div className="flex items-start justify-between pb-6 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                  {activeStore.name.slice(0, 1).toUpperCase()}
                </div>
                <h1 className="text-xl font-black tracking-tight text-slate-900">
                  {activeStore.name}
                </h1>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                {activeStore.slug}.shanju.cloud
              </p>
              {activeStore.contactPhone && (
                <p className="text-[11px] text-slate-500">Phone: {activeStore.contactPhone}</p>
              )}
              {activeStore.contactEmail && (
                <p className="text-[11px] text-slate-500">Email: {activeStore.contactEmail}</p>
              )}
            </div>

            <div className="text-right">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Invoice / Challan
              </span>
              <p className="text-base font-black font-mono text-slate-900 mt-2">
                #{order.orderNumber || order.id}
              </p>
              <p className="text-[11px] text-slate-400">
                Date: {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'N/A'}
              </p>
              <p className="text-[11px] text-slate-400 font-bold uppercase">
                Payment: {order.paymentMethod} ({order.paymentStatus})
              </p>
            </div>
          </div>

          {/* Billed To / Shipping Address */}
          <div className="grid grid-cols-2 gap-6 pb-4 border-b border-slate-100">
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Customer Details
              </p>
              <p className="font-bold text-slate-900 text-sm">{order.customerName}</p>
              <p className="text-slate-600">{order.customerPhone}</p>
              {order.customerEmail && <p className="text-slate-600">{order.customerEmail}</p>}
            </div>

            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Delivery Address
              </p>
              <p className="text-slate-800 leading-relaxed font-medium">{order.deliveryAddress}</p>
              <p className="text-slate-500 font-bold">{order.city || 'Bangladesh'}</p>
              {order.courierName && (
                <p className="text-emerald-700 text-[11px] font-semibold mt-1">
                  Courier: {order.courierName} {order.courierTrackingId ? `(#${order.courierTrackingId})` : ''}
                </p>
              )}
            </div>
          </div>

          {/* Items Table */}
          <div className="overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b-2 border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="py-2.5">Item Description</th>
                  <th className="py-2.5 text-center">Qty</th>
                  <th className="py-2.5 text-right">Price</th>
                  <th className="py-2.5 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {order.items.map((item, i) => (
                  <tr key={i}>
                    <td className="py-3">
                      <p className="font-bold text-slate-900">{item.name}</p>
                      {item.sku && <p className="text-[10px] text-slate-400">SKU: {item.sku}</p>}
                    </td>
                    <td className="py-3 text-center font-bold text-slate-900">{item.quantity}</td>
                    <td className="py-3 text-right">৳{item.price.toLocaleString()}</td>
                    <td className="py-3 text-right font-bold text-slate-900">
                      ৳{(item.price * item.quantity).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Summary / Total */}
          <div className="pt-4 border-t border-slate-200 flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-bold text-slate-900">৳{order.subtotal.toLocaleString()}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Discount:</span>
                  <span>- ৳{order.discount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Delivery Charge {order.deliveryZone ? (order.deliveryZone === 'local' ? '(Local)' : '(Outside)') : ''}:</span>
                <span className="font-bold text-slate-900">৳{(order.shippingFee || 0).toLocaleString()}</span>
              </div>
              <div className="pt-2 border-t-2 border-slate-900 flex justify-between font-black text-slate-900 text-base">
                <span>Grand Total:</span>
                <span className="text-emerald-700">৳{order.totalAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Footer Notes */}
          <div className="pt-6 border-t border-slate-100 text-center text-slate-400 text-[10px] space-y-1">
            <p>Thank you for shopping with {activeStore.name}!</p>
            <p className="text-[9px] text-slate-400">
              Powered by Shanju Cloud E-Commerce Engine • All rights reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
