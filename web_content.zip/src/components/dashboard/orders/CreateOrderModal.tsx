import React, { useState, useMemo } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Package, 
  User, 
  MapPin, 
  CreditCard, 
  Check, 
  ShoppingBag,
  Sparkles,
  Search,
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Receipt
} from 'lucide-react';
import { Product, ProductVariant, Customer, Store, Order, OrderItem, PaymentMethod, PaymentStatus, Language, ShippingSettings } from '../../../types';
import { calculateDeliveryCharge, ALL_BD_DISTRICTS, getStoreLocationDistrict, BDDistrict } from '../../../utils/deliveryLocationService';

interface CreateOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeStore: Store;
  products: Product[];
  customers: Customer[];
  language: Language;
  shippingSettings?: ShippingSettings | null;
  onCreateOrder: (order: Order) => void;
}

export const CreateOrderModal: React.FC<CreateOrderModalProps> = ({
  isOpen,
  onClose,
  activeStore,
  products = [],
  customers = [],
  language,
  shippingSettings,
  onCreateOrder
}) => {
  const isBn = language === 'bn';

  // Defensive array checks
  const safeProducts = Array.isArray(products) ? products : [];
  const safeCustomers = Array.isArray(customers) ? customers : [];

  // Filter store products
  const storeProducts = safeProducts.filter(p => p && p.storeId === activeStore?.id);

  // Modal Flow Step: 'edit' or 'review'
  const [currentStep, setCurrentStep] = useState<'edit' | 'review'>('edit');

  // Customer Form states
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  
  const defaultCity = getStoreLocationDistrict(activeStore) || 'Sylhet';
  const [city, setCity] = useState(defaultCity);

  // Items and Pricing
  const [selectedItems, setSelectedItems] = useState<OrderItem[]>([]);
  const [productSearch, setProductSearch] = useState('');
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});
  const [discountAmount, setDiscountAmount] = useState<number>(0);

  const subtotal = useMemo(() => {
    return selectedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [selectedItems]);

  const currentDeliveryResult = useMemo(() => {
    return calculateDeliveryCharge(city, activeStore, shippingSettings, subtotal);
  }, [city, activeStore, shippingSettings, subtotal]);
  
  const [shippingFee, setShippingFee] = useState<number>(() => {
    return calculateDeliveryCharge(defaultCity, activeStore, shippingSettings, 0).charge;
  });
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('pending');
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // When customer is picked from list
  const handleSelectCustomer = (id: string) => {
    setSelectedCustomerId(id);
    if (!id) {
      setCustomerName('');
      setCustomerPhone('');
      setCustomerEmail('');
      setDeliveryAddress('');
      return;
    }
    const found = safeCustomers.find(c => c.id === id);
    if (found) {
      setCustomerName(found.name || '');
      setCustomerPhone(found.phone || '');
      setCustomerEmail(found.email || '');
      const custCity = found.city || defaultCity;
      setCity(custCity);
      const calc = calculateDeliveryCharge(custCity, activeStore, shippingSettings, subtotal);
      setShippingFee(calc.charge);
    }
  };

  const handleCityChange = (newCity: string) => {
    setCity(newCity);
    const calc = calculateDeliveryCharge(newCity, activeStore, shippingSettings, subtotal);
    setShippingFee(calc.charge);
  };

  // Add product to items
  const handleAddProduct = (prod: Product) => {
    setErrorMessage(null);
    const chosenVariantName = selectedVariants[prod.id];
    const variantObj = Array.isArray(prod.variants) && chosenVariantName
      ? prod.variants.find(v => v.name === chosenVariantName || v.id === chosenVariantName)
      : undefined;

    const availableStock = variantObj?.stock !== undefined ? variantObj.stock : prod.stock;
    if (availableStock <= 0) {
      setErrorMessage(isBn ? 'এই পণ্যটি বা ভ্যারিয়েন্টের স্টক শূন্য।' : 'This product variant is out of stock.');
      return;
    }

    const itemPrice = variantObj?.price || prod.price;
    const itemSku = variantObj?.sku || prod.sku;
    const itemKey = `${prod.id}__${chosenVariantName || 'default'}`;

    const existingIndex = selectedItems.findIndex(i => `${i.productId}__${i.variant || 'default'}` === itemKey);
    if (existingIndex > -1) {
      const existing = selectedItems[existingIndex];
      if (existing.quantity >= availableStock) {
        setErrorMessage(isBn ? `স্টকে মাত্র ${availableStock}টি উপলব্ধ আছে।` : `Only ${availableStock} available in stock.`);
        return;
      }
      const updated = [...selectedItems];
      updated[existingIndex].quantity += 1;
      setSelectedItems(updated);
    } else {
      setSelectedItems([
        ...selectedItems,
        {
          productId: prod.id,
          name: isBn ? prod.nameBn || prod.name : prod.name,
          price: itemPrice,
          quantity: 1,
          image: prod.image || 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=100&q=80',
          sku: itemSku,
          variant: chosenVariantName || undefined
        }
      ]);
    }
  };

  const handleUpdateQuantity = (itemIndex: number, qty: number) => {
    setErrorMessage(null);
    const item = selectedItems[itemIndex];
    if (!item) return;

    const prod = storeProducts.find(p => p.id === item.productId);
    const variantObj = prod && Array.isArray(prod.variants) && item.variant
      ? prod.variants.find(v => v.name === item.variant || v.id === item.variant)
      : undefined;

    const maxStock = variantObj?.stock !== undefined ? variantObj.stock : (prod?.stock ?? 999);
    if (qty > maxStock) {
      setErrorMessage(isBn ? `স্টকে মাত্র ${maxStock}টি উপলব্ধ আছে।` : `Cannot exceed available stock of ${maxStock}.`);
      return;
    }

    if (qty <= 0) {
      setSelectedItems(selectedItems.filter((_, idx) => idx !== itemIndex));
    } else {
      setSelectedItems(selectedItems.map((itm, idx) => idx === itemIndex ? { ...itm, quantity: qty } : itm));
    }
  };

  const handleRemoveItem = (itemIndex: number) => {
    setSelectedItems(selectedItems.filter((_, idx) => idx !== itemIndex));
  };

  const totalAmount = Math.max(0, subtotal - discountAmount + shippingFee);

  // Validate and Proceed to Review Step
  const handleProceedToReview = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (selectedItems.length === 0) {
      setErrorMessage(isBn ? 'অনুগ্রহ করে কমপক্ষে একটি পণ্য নির্বাচন করুন।' : 'Please select at least one product.');
      return;
    }
    if (!customerName.trim()) {
      setErrorMessage(isBn ? 'গ্রাহকের নাম আবশ্যক।' : 'Customer name is required.');
      return;
    }
    if (!customerPhone.trim()) {
      setErrorMessage(isBn ? 'গ্রাহকের ফোন নম্বর আবশ্যক।' : 'Customer phone is required.');
      return;
    }
    if (!deliveryAddress.trim()) {
      setErrorMessage(isBn ? 'ডেলিভারি ঠিকানা আবশ্যক।' : 'Delivery address is required.');
      return;
    }

    setCurrentStep('review');
  };

  // Final submit after review
  const handleFinalSubmit = () => {
    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      storeId: activeStore.id,
      customerId: selectedCustomerId || undefined,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail.trim() || `${customerPhone.trim()}@guest.store`,
      deliveryAddress: deliveryAddress.trim(),
      city: city.trim(),
      deliveryZone: currentDeliveryResult.deliveryZone,
      deliveryCharge: shippingFee,
      items: selectedItems,
      subtotal,
      discount: discountAmount,
      shippingFee,
      totalAmount,
      paymentMethod,
      paymentStatus,
      orderStatus: 'confirmed',
      notes: notes.trim() || undefined,
      createdAt: new Date().toISOString()
    };

    onCreateOrder(newOrder);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl overflow-hidden border border-slate-200 text-xs flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-slate-900">
                {currentStep === 'edit'
                  ? (isBn ? 'নতুন কাস্টমার অর্ডার তৈরি করুন' : 'Create New Merchant Order')
                  : (isBn ? 'অর্ডার রিভিউ ও নিশ্চিতকরণ' : 'Review & Confirm Order')}
              </h2>
              <p className="text-[11px] text-slate-400">
                {currentStep === 'edit'
                  ? (isBn ? 'গ্রাহক ও পণ্য নির্বাচন করে তথ্য এন্ট্রি করুন' : 'Customer & product selection for manual/phone orders')
                  : (isBn ? 'তথ্য যাচাই করে অর্ডারটি ডাটাবেজে সংরক্ষণ করুন' : 'Verify all details before saving to orders database')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 font-bold rounded-xl flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {currentStep === 'edit' ? (
            /* STEP 1: EDIT FORM */
            <form id="create-order-form" onSubmit={handleProceedToReview} className="space-y-4">
              {/* 1. Customer Selection */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                    <User className="w-4 h-4 text-emerald-600" />
                    <span>{isBn ? 'গ্রাহকের তথ্য' : 'Customer Information'}</span>
                  </h3>
                  {safeCustomers.length > 0 && (
                    <select
                      value={selectedCustomerId}
                      onChange={(e) => handleSelectCustomer(e.target.value)}
                      className="px-2.5 py-1 text-[11px] border border-slate-300 rounded-lg bg-white font-medium"
                    >
                      <option value="">{isBn ? '-- বিদ্যমান গ্রাহক থেকে নির্বাচন করুন --' : '-- Pick Existing Customer --'}</option>
                      {safeCustomers.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.phone})
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      {isBn ? 'নাম *' : 'Name *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Alim Hossain"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white focus:outline-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      {isBn ? 'মোবাইল নম্বর *' : 'Phone *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="017XXXXXXXX"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white focus:outline-emerald-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      {isBn ? 'ইমেইল (ঐচ্ছিক)' : 'Email (Optional)'}
                    </label>
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="customer@example.com"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white focus:outline-emerald-500"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[11px] font-semibold text-slate-700">
                        {isBn ? 'শহর / জেলা' : 'City / District'}
                      </label>
                      <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        {isBn ? `স্টোর: ${currentDeliveryResult.storeLocationSummary}` : `Store: ${currentDeliveryResult.storeLocationSummary}`}
                      </span>
                    </div>
                    <select
                      value={city}
                      onChange={(e) => handleCityChange(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-semibold text-xs text-slate-900 focus:outline-emerald-500"
                    >
                      {ALL_BD_DISTRICTS.map((dist: BDDistrict) => {
                        const preview = calculateDeliveryCharge(dist.name, activeStore, shippingSettings, subtotal);
                        return (
                          <option key={dist.name} value={dist.name}>
                            {dist.name} ({dist.nameBn}) — {preview.isFreeShipping ? 'Free' : `৳${preview.charge}`} ({preview.isLocal ? (isBn ? 'লোকাল' : 'Local') : (isBn ? 'আউটসাইড' : 'Outside')})
                          </option>
                        );
                      })}
                    </select>
                    <div className="mt-1 text-[11px] text-slate-600 flex items-center justify-between px-0.5">
                      <span className={`font-semibold ${currentDeliveryResult.isLocal ? 'text-emerald-700' : 'text-blue-700'}`}>
                        {isBn ? currentDeliveryResult.zoneDescriptionBn : currentDeliveryResult.zoneDescription}
                      </span>
                      <span className="font-bold text-slate-800">
                        {currentDeliveryResult.isFreeShipping ? (isBn ? 'ফ্রি' : 'Free') : `৳${currentDeliveryResult.charge}`}
                      </span>
                    </div>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      {isBn ? 'সম্পূর্ণ ডেলিভারি ঠিকানা *' : 'Delivery Address *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="House, Road, Area, Thana"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white focus:outline-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* 2. Product Picker */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-3">
                <h3 className="font-bold text-slate-900 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-emerald-600" />
                    <span>{isBn ? 'পণ্য নির্বাচন ও কার্ট' : 'Select Store Products'}</span>
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {selectedItems.length} {isBn ? 'টি আইটেম নির্বাচিত' : 'items added'}
                  </span>
                </h3>

                {/* Product Search */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    placeholder={isBn ? 'পণ্যের নাম বা SKU দিয়ে খুঁজুন...' : 'Search store products by name or SKU...'}
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white focus:outline-emerald-500 text-xs"
                  />
                </div>

                {/* Search Results Dropdown List */}
                {productSearch.trim() && (
                  <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 border border-slate-200 rounded-xl p-1 bg-slate-50">
                    {storeProducts
                      .filter(p => (p.name || '').toLowerCase().includes(productSearch.toLowerCase()) || (p.sku || '').toLowerCase().includes(productSearch.toLowerCase()))
                      .map(prod => {
                        const hasVariants = Array.isArray(prod.variants) && prod.variants.length > 0;
                        const currentChosenVariant = selectedVariants[prod.id] || (hasVariants ? prod.variants![0].name : '');

                        return (
                          <div key={prod.id} className="p-2.5 flex items-center justify-between gap-3 hover:bg-white rounded-lg transition-colors">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <img src={prod.image} alt={prod.name} className="w-9 h-9 rounded-lg object-cover border shrink-0" />
                              <div className="truncate">
                                <p className="font-bold text-slate-900 truncate">{prod.name}</p>
                                <p className="text-[10px] text-slate-400">
                                  ৳{prod.price.toLocaleString()} • Stock: {prod.stock}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              {hasVariants && (
                                <select
                                  value={currentChosenVariant}
                                  onChange={(e) => setSelectedVariants({ ...selectedVariants, [prod.id]: e.target.value })}
                                  className="px-2 py-1 text-[11px] border border-slate-300 rounded-lg bg-white"
                                >
                                  {prod.variants!.map(v => (
                                    <option key={v.id || v.name} value={v.name}>
                                      {v.name} ({v.price ? `৳${v.price}` : `৳${prod.price}`}) - Stock: {v.stock}
                                    </option>
                                  ))}
                                </select>
                              )}

                              <button
                                type="button"
                                onClick={() => handleAddProduct(prod)}
                                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs cursor-pointer shadow-2xs"
                              >
                                + Add
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}

                {/* Selected Items List */}
                {selectedItems.length > 0 ? (
                  <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white">
                    {selectedItems.map((item, idx) => (
                      <div key={`${item.productId}-${idx}`} className="p-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img src={item.image} alt={item.name} className="w-9 h-9 rounded-lg object-cover border shrink-0" />
                          <div className="truncate">
                            <p className="font-bold text-slate-900 truncate">{item.name}</p>
                            <p className="text-[10px] text-slate-400">
                              ৳{item.price.toLocaleString()} each {item.variant ? `• Variant: ${item.variant}` : ''}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          <div className="flex items-center border border-slate-300 rounded-lg">
                            <button
                              type="button"
                              onClick={() => handleUpdateQuantity(idx, item.quantity - 1)}
                              className="px-2 py-0.5 text-slate-600 hover:bg-slate-100 font-bold"
                            >
                              -
                            </button>
                            <span className="px-2 font-bold text-slate-900">{item.quantity}</span>
                            <button
                              type="button"
                              onClick={() => handleUpdateQuantity(idx, item.quantity + 1)}
                              className="px-2 py-0.5 text-slate-600 hover:bg-slate-100 font-bold"
                            >
                              +
                            </button>
                          </div>

                          <span className="font-bold text-slate-900 w-16 text-right">
                            ৳{(item.price * item.quantity).toLocaleString()}
                          </span>

                          <button
                            type="button"
                            onClick={() => handleRemoveItem(idx)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-400 text-center py-4 border border-dashed border-slate-200 rounded-xl">
                    {isBn ? 'এখনো কোনো পণ্য যোগ করা হয়নি। উপরের সার্চ থেকে সিলেক্ট করুন।' : 'No products selected yet. Search above to add.'}
                  </p>
                )}
              </div>

              {/* 3. Discount, Shipping & Payment Settings */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isBn ? 'ডিসকাউন্ট (৳)' : 'Discount (৳)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={discountAmount}
                    onChange={(e) => setDiscountAmount(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-bold"
                  />
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isBn ? 'শিপিং চার্জ (৳)' : 'Shipping Fee (৳)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={shippingFee}
                    onChange={(e) => setShippingFee(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-bold"
                  />
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isBn ? 'পেমেন্ট মেথড' : 'Payment Method'}
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => {
                      const m = e.target.value as PaymentMethod;
                      setPaymentMethod(m);
                      if (m === 'cod') setPaymentStatus('pending');
                      else setPaymentStatus('paid');
                    }}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-bold text-xs"
                  >
                    <option value="cod">Cash on Delivery</option>
                    <option value="bkash">bKash (বিকাশ)</option>
                    <option value="nagad">Nagad (নগদ)</option>
                    <option value="card">Debit / Credit Card</option>
                    <option value="manual">Manual Bank / Wire</option>
                  </select>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isBn ? 'পেমেন্ট স্ট্যাটাস' : 'Payment Status'}
                  </label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-bold text-xs"
                  >
                    <option value="pending">Pending (বাকি / COD)</option>
                    <option value="paid">Paid (পরিশোধিত)</option>
                    <option value="partially_paid">Partially Paid</option>
                  </select>
                </div>
              </div>

              {/* 4. Notes */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isBn ? 'অভ্যন্তরীণ নোটস (ঐচ্ছিক)' : 'Internal Merchant Notes (Optional)'}
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={isBn ? 'যেমন: ডেলিভারির পূর্বে ফোন দিন' : 'e.g. Call before delivery, fragile package'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-slate-50 focus:bg-white focus:outline-emerald-500"
                />
              </div>
            </form>
          ) : (
            /* STEP 2: REVIEW ORDER SCREEN */
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div>
                    <h3 className="font-extrabold text-sm">{isBn ? 'অর্ডারের বিবরণ পর্যালোচনা করুন' : 'Review Order Summary'}</h3>
                    <p className="text-[11px] text-emerald-700">{isBn ? 'নিশ্চিত করার পর স্বয়ংক্রিয়ভাবে স্টক হ্রাস পাবে।' : 'Stock will be deducted from inventory once confirmed.'}</p>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold px-2.5 py-1 bg-white rounded-lg border border-emerald-300">
                  {activeStore.name}
                </span>
              </div>

              {/* Customer and Shipping Details Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-bold text-slate-800 text-[11px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-500" />
                    <span>{isBn ? 'গ্রাহক' : 'Customer'}</span>
                  </h4>
                  <p className="font-bold text-slate-900 text-sm">{customerName}</p>
                  <p className="text-slate-600 font-mono mt-0.5">{customerPhone}</p>
                  {customerEmail && <p className="text-slate-500 mt-0.5">{customerEmail}</p>}
                </div>

                <div>
                  <h4 className="font-bold text-slate-800 text-[11px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    <span>{isBn ? 'ডেলিভারি ঠিকানা' : 'Shipping Address'}</span>
                  </h4>
                  <p className="text-slate-800 leading-relaxed font-medium">{deliveryAddress}</p>
                  <p className="text-slate-500 font-semibold mt-0.5">{city}</p>
                </div>
              </div>

              {/* Items Table Card */}
              <div className="rounded-2xl border border-slate-200 overflow-hidden bg-white">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-[10px] font-bold uppercase">
                    <tr>
                      <th className="py-2.5 px-3">Item</th>
                      <th className="py-2.5 px-3 text-center">Qty</th>
                      <th className="py-2.5 px-3 text-right">Unit Price</th>
                      <th className="py-2.5 px-3 text-right">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {selectedItems.map((item, i) => (
                      <tr key={i}>
                        <td className="py-2.5 px-3 flex items-center gap-2">
                          <img src={item.image} alt={item.name} className="w-8 h-8 rounded object-cover border shrink-0" />
                          <div className="truncate">
                            <span className="font-bold text-slate-900">{item.name}</span>
                            {item.variant && <span className="text-[10px] text-slate-400 block font-normal">Variant: {item.variant}</span>}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold text-slate-800">{item.quantity}</td>
                        <td className="py-2.5 px-3 text-right text-slate-600">৳{item.price.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-slate-900">৳{(item.price * item.quantity).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Payment & Financial Breakdown Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal ({selectedItems.length} items):</span>
                  <span className="font-bold text-slate-900">৳{subtotal.toLocaleString()}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount:</span>
                    <span className="font-bold">- ৳{discountAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Shipping Fee:</span>
                  <span className="font-bold text-slate-900">+ ৳{shippingFee.toLocaleString()}</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm">
                  <span className="font-extrabold text-slate-900">Grand Total:</span>
                  <span className="font-black text-base text-emerald-600">৳{totalAmount.toLocaleString()}</span>
                </div>
                <div className="pt-2 flex items-center gap-3 text-[11px] text-slate-500">
                  <span>Method: <strong className="text-slate-800 uppercase">{paymentMethod}</strong></span>
                  <span>•</span>
                  <span>Payment Status: <strong className="text-slate-800 capitalize">{paymentStatus}</strong></span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold block">{isBn ? 'মোট প্রদেয়' : 'Total Payable'}</span>
            <span className="text-lg font-black text-emerald-400">৳{totalAmount.toLocaleString()}</span>
          </div>

          <div className="flex items-center gap-2">
            {currentStep === 'review' ? (
              <>
                <button
                  type="button"
                  onClick={() => setCurrentStep('edit')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700 cursor-pointer text-xs"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সংশোধন করুন' : 'Back to Edit'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleFinalSubmit}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-lg shadow-emerald-600/30 cursor-pointer text-xs"
                >
                  <Check className="w-4 h-4" />
                  <span>{isBn ? 'অর্ডার নিশ্চিত করুন 🚀' : 'Confirm & Create Order 🚀'}</span>
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700 cursor-pointer text-xs"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  form="create-order-form"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-lg shadow-emerald-600/30 cursor-pointer text-xs"
                >
                  <span>{isBn ? 'অর্ডার রিভিউ করুন' : 'Review Order'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
