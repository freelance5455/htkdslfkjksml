import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Truck, 
  CreditCard, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Package, 
  Copy, 
  Check, 
  ExternalLink,
  Edit,
  FileText,
  RotateCcw,
  Ban
} from 'lucide-react';
import { Order, OrderStatus, PaymentStatus, Language, Store } from '../../../types';

interface OrderDetailsDrawerProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  activeStore: Store;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, trackingId?: string, courier?: string) => void;
  onUpdatePaymentStatus: (orderId: string, status: PaymentStatus) => void;
  onUpdateOrderNotes: (orderId: string, notes: string) => void;
  onOpenPrintInvoice: (order: Order) => void;
  onInitiateReturn?: (order: Order) => void;
}

export const OrderDetailsDrawer: React.FC<OrderDetailsDrawerProps> = ({
  order,
  isOpen,
  onClose,
  language,
  activeStore,
  onUpdateOrderStatus,
  onUpdatePaymentStatus,
  onUpdateOrderNotes,
  onOpenPrintInvoice,
  onInitiateReturn
}) => {
  const isBn = language === 'bn';
  const [trackingNumber, setTrackingNumber] = useState(order?.courierTrackingId || '');
  const [courierName, setCourierName] = useState(order?.courierName || order?.courierProvider || 'Steadfast');
  const [notes, setNotes] = useState(order?.notes || '');
  const [copied, setCopied] = useState(false);
  const [isSavingNotes, setIsSavingNotes] = useState(false);

  if (!isOpen || !order) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveNotes = () => {
    setIsSavingNotes(true);
    onUpdateOrderNotes(order.id, notes);
    setTimeout(() => setIsSavingNotes(false), 800);
  };

  const handleApplyTracking = () => {
    onUpdateOrderStatus(order.id, order.orderStatus, trackingNumber, courierName);
  };

  // Timeline progression state calculation
  const timelineStages = [
    { key: 'pending', labelEn: 'Order Placed', labelBn: 'অর্ডার প্লেস করা হয়েছে', time: order.createdAt },
    { key: 'confirmed', labelEn: 'Order Confirmed', labelBn: 'অর্ডার নিশ্চিত করা হয়েছে' },
    { key: 'processing', labelEn: 'Processing', labelBn: 'প্রস্তুত হচ্ছে' },
    { key: 'packed', labelEn: 'Packed', labelBn: 'প্যাকিং সম্পন্ন হয়েছে' },
    { key: 'shipped', labelEn: 'Handed to Courier', labelBn: 'কুরিয়ারে হস্তান্তর করা হয়েছে' },
    { key: 'delivered', labelEn: 'Delivered', labelBn: 'সফলভাবে ডেলিভারি হয়েছে' },
  ];

  const getStageIndex = (status: OrderStatus) => {
    switch (status) {
      case 'pending': return 0;
      case 'confirmed': return 1;
      case 'processing': return 2;
      case 'packed': return 3;
      case 'shipped': return 4;
      case 'delivered': return 5;
      case 'cancelled': return -1;
      case 'returned': return -2;
      case 'refunded': return -3;
      default: return 0;
    }
  };

  const currentStageIndex = getStageIndex(order.orderStatus);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex justify-end animate-in fade-in">
      <div 
        className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-200"
      >
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-200 sticky top-0 bg-white/95 backdrop-blur-xs z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-slate-800 border border-slate-200">
              <Package className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">
                  {order.orderNumber || order.id}
                </h2>
                <button
                  onClick={() => handleCopy(order.orderNumber || order.id)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                  title="Copy Order ID"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <p className="text-xs text-slate-400">
                {isBn ? 'অর্ডারের তারিখ:' : 'Placed on:'} {order.createdAt ? new Date(order.createdAt).toLocaleString(isBn ? 'bn-BD' : 'en-US') : 'N/A'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenPrintInvoice(order)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{isBn ? 'ইনভয়েস' : 'Print Invoice'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Drawer Body */}
        <div className="p-6 space-y-6 flex-1 text-xs">
          {/* Quick Status Bar */}
          <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                {isBn ? 'অর্ডার স্ট্যাটাস' : 'Fulfillment Status'}
              </span>
              <select
                value={order.orderStatus}
                onChange={(e) => onUpdateOrderStatus(order.id, e.target.value as OrderStatus, trackingNumber, courierName)}
                className="w-full py-1.5 px-2.5 rounded-lg border border-slate-300 bg-white font-bold text-slate-900 focus:outline-emerald-500"
              >
                <option value="pending">{isBn ? 'অপেক্ষমান (Pending)' : 'Pending'}</option>
                <option value="confirmed">{isBn ? 'নিশ্চিত (Confirmed)' : 'Confirmed'}</option>
                <option value="processing">{isBn ? 'প্রস্তুত হচ্ছে (Processing)' : 'Processing'}</option>
                <option value="packed">{isBn ? 'প্যাকড (Packed)' : 'Packed'}</option>
                <option value="shipped">{isBn ? 'শিপড (Shipped)' : 'Shipped'}</option>
                <option value="delivered">{isBn ? 'ডেলিভার্ড (Delivered)' : 'Delivered'}</option>
                <option value="cancelled">{isBn ? 'বাতিল (Cancelled)' : 'Cancelled'}</option>
                <option value="returned">{isBn ? 'রিটার্ন (Returned)' : 'Returned'}</option>
                <option value="refunded">{isBn ? 'রিফান্ডেড (Refunded)' : 'Refunded'}</option>
              </select>
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                {isBn ? 'পেমেন্ট স্ট্যাটাস' : 'Payment Status'}
              </span>
              <select
                value={order.paymentStatus}
                onChange={(e) => onUpdatePaymentStatus(order.id, e.target.value as PaymentStatus)}
                className="w-full py-1.5 px-2.5 rounded-lg border border-slate-300 bg-white font-bold text-slate-900 focus:outline-emerald-500"
              >
                <option value="pending">{isBn ? 'পেন্ডিং (Pending)' : 'Pending'}</option>
                <option value="paid">{isBn ? 'পরিশোধিত (Paid)' : 'Paid'}</option>
                <option value="partially_paid">{isBn ? 'আংশিক পরিশোধিত' : 'Partially Paid'}</option>
                <option value="failed">{isBn ? 'ব্যর্থ (Failed)' : 'Failed'}</option>
                <option value="refunded">{isBn ? 'রিফান্ডেড (Refunded)' : 'Refunded'}</option>
              </select>
            </div>
          </div>

          {/* Order Timeline Visualizer */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white shadow-2xs">
            <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-1.5 text-xs">
              <Clock className="w-4 h-4 text-emerald-600" />
              <span>{isBn ? 'অর্ডার প্রোগ্রেস টাইমলাইন' : 'Order Timeline & Lifecycle'}</span>
            </h3>

            {currentStageIndex < 0 ? (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 font-bold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                <span>
                  {order.orderStatus === 'cancelled' && (isBn ? 'এই অর্ডারটি বাতিল করা হয়েছে।' : 'This order has been Cancelled.')}
                  {order.orderStatus === 'returned' && (isBn ? 'পণ্য রিটার্ন হিসেবে রেকর্ড করা হয়েছে।' : 'This order has been Returned.')}
                  {order.orderStatus === 'refunded' && (isBn ? 'অর্ডারের অর্থ রিফান্ড করা হয়েছে।' : 'This order has been Refunded.')}
                </span>
              </div>
            ) : (
              <div className="relative pl-6 space-y-4 border-l-2 border-slate-200 ml-2 py-1">
                {timelineStages.map((stage, idx) => {
                  const isDone = currentStageIndex >= idx;
                  const isCurrent = currentStageIndex === idx;

                  return (
                    <div key={stage.key} className="relative">
                      <div className={`absolute -left-[31px] top-0.5 w-4 h-4 rounded-full border-2 transition-colors ${
                        isDone 
                          ? 'bg-emerald-500 border-emerald-500 text-white' 
                          : 'bg-white border-slate-300'
                      } flex items-center justify-center`}>
                        {isDone && <Check className="w-2.5 h-2.5 text-white" />}
                      </div>
                      <div className="leading-tight">
                        <span className={`font-bold ${isCurrent ? 'text-emerald-700 font-black' : isDone ? 'text-slate-800' : 'text-slate-400'}`}>
                          {isBn ? stage.labelBn : stage.labelEn}
                        </span>
                        {stage.time && (
                          <span className="block text-[10px] text-slate-400 mt-0.5">{stage.time}</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Ordered Products Table */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white shadow-2xs space-y-3">
            <h3 className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
              <Package className="w-4 h-4 text-emerald-600" />
              <span>{isBn ? 'অর্ডারকৃত পণ্যসমূহ' : 'Ordered Products'} ({order.items.length})</span>
            </h3>

            <div className="divide-y divide-slate-100">
              {order.items.map((item, i) => (
                <div key={i} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img 
                      src={item.image || 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=100&q=80'} 
                      alt={item.name} 
                      className="w-10 h-10 rounded-lg object-cover border border-slate-200 shrink-0" 
                    />
                    <div className="truncate">
                      <p className="font-bold text-slate-900 truncate">{item.name}</p>
                      <p className="text-[10px] text-slate-400 font-mono">
                        {item.sku ? `SKU: ${item.sku}` : ''} {item.variant ? `• ${item.variant}` : ''}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="font-bold text-slate-900">
                      ৳{(item.price * item.quantity).toLocaleString()}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      ৳{item.price.toLocaleString()} × {item.quantity}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Calculations Breakdown */}
            <div className="pt-3 border-t border-slate-100 space-y-1.5 text-slate-600">
              <div className="flex justify-between">
                <span>{isBn ? 'সাবটোটাল' : 'Subtotal'}</span>
                <span className="font-semibold text-slate-900">৳{order.subtotal.toLocaleString()}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>{isBn ? 'ডিসকাউন্ট' : 'Discount'}</span>
                  <span>- ৳{order.discount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>{isBn ? 'শিপিং চার্জ' : 'Shipping Fee'}</span>
                <span>৳{(order.shippingFee || 0).toLocaleString()}</span>
              </div>
              {order.tax !== undefined && order.tax > 0 && (
                <div className="flex justify-between">
                  <span>{isBn ? 'ভ্যাট / ট্যাক্স' : 'Tax'}</span>
                  <span>৳{order.tax.toLocaleString()}</span>
                </div>
              )}
              <div className="pt-2 border-t border-slate-200 flex justify-between font-black text-slate-900 text-sm">
                <span>{isBn ? 'সর্বমোট প্রদেয়' : 'Grand Total'}</span>
                <span className="text-emerald-700">৳{order.totalAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Customer & Shipping Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Customer Details */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-white shadow-2xs space-y-2">
              <h3 className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isBn ? 'গ্রাহকের তথ্য' : 'Customer Info'}</span>
              </h3>
              <p className="font-bold text-slate-900 text-sm">{order.customerName}</p>
              <p className="text-slate-600 flex items-center gap-1.5">
                <Phone className="w-3 h-3 text-slate-400" />
                <span>{order.customerPhone}</span>
              </p>
              {order.customerEmail && (
                <p className="text-slate-600 flex items-center gap-1.5 truncate">
                  <Mail className="w-3 h-3 text-slate-400" />
                  <span>{order.customerEmail}</span>
                </p>
              )}
            </div>

            {/* Delivery Address */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-white shadow-2xs space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isBn ? 'ডেলিভারি ঠিকানা' : 'Shipping Address'}</span>
                </h3>
                {order.deliveryZone && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    order.deliveryZone === 'local' 
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                      : 'bg-blue-100 text-blue-800 border border-blue-200'
                  }`}>
                    {order.deliveryZone === 'local' ? (isBn ? 'লোকাল ডেলিভারি' : 'Local Delivery') : (isBn ? 'স্টোরের বাইরের এলাকা' : 'Outside Store Area')}
                  </span>
                )}
              </div>
              <p className="text-slate-800 leading-relaxed font-medium">
                {order.deliveryAddress || (isBn ? 'ঠিকানা দেওয়া হয়নি' : 'Address not provided')}
              </p>
              {order.city && (
                <p className="text-slate-500 font-semibold">
                  {isBn ? 'শহর / জেলা:' : 'City / District:'} {order.city}
                </p>
              )}
            </div>
          </div>

          {/* Courier & Tracking Assignment */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white shadow-2xs space-y-3">
            <h3 className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
              <Truck className="w-4 h-4 text-emerald-600" />
              <span>{isBn ? 'কুরিয়ার ও ট্র্যাকিং নম্বর' : 'Logistics & Tracking'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {isBn ? 'কুরিয়ার সার্ভিস' : 'Courier Name'}
                </label>
                <select
                  value={courierName}
                  onChange={(e) => setCourierName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-medium"
                >
                  <option value="Steadfast">Steadfast Courier</option>
                  <option value="Pathao">Pathao Courier</option>
                  <option value="RedX">RedX Delivery</option>
                  <option value="Paperfly">Paperfly</option>
                  <option value="Sundarban">Sundarban Courier</option>
                  <option value="SA Paribahan">SA Paribahan</option>
                  <option value="In-house">In-house / Self Delivery</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {isBn ? 'ট্র্যাকিং কোড' : 'Tracking Number / Consignment ID'}
                </label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    placeholder="e.g. SF-982341"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                  <button
                    onClick={handleApplyTracking}
                    className="px-3 py-2 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors"
                  >
                    {isBn ? 'সংরক্ষণ' : 'Save'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Merchant Internal Notes */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white shadow-2xs space-y-2">
            <h3 className="font-bold text-slate-900 flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isBn ? 'মার্চেন্ট নোটস (অভ্যন্তরীণ)' : 'Merchant Internal Notes'}</span>
              </span>
              <button
                onClick={handleSaveNotes}
                disabled={isSavingNotes}
                className="text-emerald-700 hover:text-emerald-800 font-bold"
              >
                {isSavingNotes ? (isBn ? 'সংরক্ষণ হচ্ছে...' : 'Saving...') : (isBn ? 'নোট সেভ করুন' : 'Save Note')}
              </button>
            </h3>

            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={isBn ? 'অর্ডার সম্পর্কিত যেকোনো মন্তব্য বা নির্দেশনা লিখুন...' : 'Add notes regarding customer preference, delivery instruction, etc.'}
              className="w-full p-2.5 border border-slate-300 rounded-xl focus:outline-emerald-500 font-medium"
            />
          </div>
        </div>

        {/* Drawer Footer Actions */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {order.orderStatus !== 'cancelled' && order.orderStatus !== 'delivered' && (
              <button
                onClick={() => onUpdateOrderStatus(order.id, 'cancelled')}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-rose-600 hover:bg-rose-50 border border-rose-200 font-bold text-xs transition-colors cursor-pointer"
              >
                <Ban className="w-3.5 h-3.5" />
                <span>{isBn ? 'অর্ডার বাতিল করুন' : 'Cancel Order'}</span>
              </button>
            )}

            {onInitiateReturn && order.orderStatus === 'delivered' && (
              <button
                onClick={() => onInitiateReturn(order)}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-amber-700 hover:bg-amber-50 border border-amber-200 font-bold text-xs transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{isBn ? 'রিটার্ন প্রসেস করুন' : 'Record Return'}</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {order.orderStatus === 'pending' && (
              <button
                onClick={() => onUpdateOrderStatus(order.id, 'confirmed')}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                {isBn ? 'অর্ডার নিশ্চিত করুন' : 'Confirm Order'}
              </button>
            )}

            {(order.orderStatus === 'confirmed' || order.orderStatus === 'pending') && (
              <button
                onClick={() => onUpdateOrderStatus(order.id, 'processing')}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                {isBn ? 'প্যাকিং শুরু করুন' : 'Mark Processing'}
              </button>
            )}

            {order.orderStatus === 'processing' && (
              <button
                onClick={() => onUpdateOrderStatus(order.id, 'shipped', trackingNumber, courierName)}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                {isBn ? 'শিপড হিসেবে চিহ্নিত করুন' : 'Mark as Shipped'}
              </button>
            )}

            {order.orderStatus === 'shipped' && (
              <button
                onClick={() => onUpdateOrderStatus(order.id, 'delivered')}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                {isBn ? 'ডেলিভারি সম্পন্ন' : 'Mark as Delivered'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
