import React, { useState } from 'react';
import { 
  RotateCcw, 
  Plus, 
  Search, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Package, 
  DollarSign,
  X
} from 'lucide-react';
import { ReturnRefundRecord, Order, Store, Language } from '../../../types';

interface ReturnsRefundsManagerProps {
  returns: ReturnRefundRecord[];
  orders: Order[];
  activeStore: Store;
  language: Language;
  onSaveReturn: (record: ReturnRefundRecord) => void;
  onUpdateReturnStatus: (id: string, status: 'pending' | 'approved' | 'processed' | 'rejected') => void;
}

export const ReturnsRefundsManager: React.FC<ReturnsRefundsManagerProps> = ({
  returns,
  orders,
  activeStore,
  language,
  onSaveReturn,
  onUpdateReturnStatus
}) => {
  const isBn = language === 'bn';
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [selectedOrderId, setSelectedOrderId] = useState('');
  const [returnReason, setReturnReason] = useState('Damaged or Defective Item');
  const [refundAmount, setRefundAmount] = useState<number>(0);
  const [notes, setNotes] = useState('');

  const storeReturns = (Array.isArray(returns) ? returns : []).filter(r => r && r.storeId === activeStore?.id);
  const storeOrders = (Array.isArray(orders) ? orders : []).filter(o => o && o.storeId === activeStore?.id);

  const filtered = storeReturns.filter(r =>
    (r.orderNumber || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (r.customerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (r.customerPhone || '').includes(searchTerm)
  );

  const handleSelectOrder = (orderId: string) => {
    setSelectedOrderId(orderId);
    const order = storeOrders.find(o => o.id === orderId);
    if (order) {
      setRefundAmount(order.totalAmount);
    }
  };

  const handleCreateReturn = (e: React.FormEvent) => {
    e.preventDefault();
    const order = storeOrders.find(o => o.id === selectedOrderId);
    if (!order) return;

    const record: ReturnRefundRecord = {
      id: `ret-${Date.now()}`,
      storeId: activeStore.id,
      orderId: order.id,
      orderNumber: order.orderNumber || order.id,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      items: order.items.map(i => ({
        productId: i.productId,
        name: i.name,
        quantity: i.quantity,
        refundPrice: i.price
      })),
      reason: returnReason,
      notes: notes.trim(),
      refundAmount,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    onSaveReturn(record);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-rose-600" />
            <span>{isBn ? 'রিটার্ন ও রিফান্ড ব্যবস্থাপনা (Returns & Refunds)' : 'Returns & Refunds Management'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'পণ্য ফেরত ও রিফান্ড রিকোয়েস্ট ট্র্যাক করুন। অনুমোদন সম্পন্ন হলে স্বয়ংক্রিয় স্টক পুনরুজ্জীবিত হবে।' 
              : 'Process customer returns and approve refunds with accurate inventory reversal.'}
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{isBn ? 'রিটার্ন রেকর্ড যুক্ত করুন' : 'Record Return / Refund'}</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center gap-2">
        <Search className="w-4 h-4 text-slate-400 ml-2" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder={isBn ? 'অর্ডার নম্বর বা গ্রাহকের নাম দিয়ে রিটার্ন খুঁজুন...' : 'Search returns by order number, customer name...'}
          className="w-full text-xs text-slate-800 bg-transparent focus:outline-hidden"
        />
      </div>

      {/* Returns List */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs">
            <RotateCcw className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <p className="font-bold text-slate-700">{isBn ? 'কোনো রিটার্ন বা রিফান্ড রেকর্ড নেই।' : 'No returns or refunds requested.'}</p>
            <p className="text-slate-400 mt-1">{isBn ? 'ডেলিভারি হওয়া পণ্যে সমস্যা হলে গ্রাহকের রিটার্ন রেকর্ড এন্ট্রি করতে পারবেন।' : 'Customer return claims and adjustments will appear here.'}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Order #</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4">Refund Amount</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                      {r.orderNumber}
                    </td>
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-900">{r.customerName}</p>
                      <p className="text-[11px] text-slate-400">{r.customerPhone}</p>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {r.reason}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-rose-600">
                      ৳{r.refundAmount.toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        r.status === 'processed' || r.status === 'approved'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : r.status === 'rejected'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        {r.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      {r.status === 'pending' && (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onUpdateReturnStatus(r.id, 'approved')}
                            className="px-2.5 py-1 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-700 transition-colors"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => onUpdateReturnStatus(r.id, 'rejected')}
                            className="px-2.5 py-1 bg-slate-200 text-slate-700 font-bold rounded-lg hover:bg-slate-300 transition-colors"
                          >
                            Reject
                          </button>
                        </div>
                      )}
                      {r.status === 'approved' && (
                        <button
                          onClick={() => onUpdateReturnStatus(r.id, 'processed')}
                          className="px-2.5 py-1 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          Mark Processed
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Record Return Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 text-xs text-slate-700 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900">
                {isBn ? 'নতুন রিটার্ন / রিফান্ড এন্ট্রি' : 'Record Return / Refund'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 rounded hover:bg-slate-100">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateReturn} className="space-y-4">
              <div>
                <label className="block font-semibold mb-1">Select Order *</label>
                <select
                  required
                  value={selectedOrderId}
                  onChange={(e) => handleSelectOrder(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white"
                >
                  <option value="">-- Choose Order --</option>
                  {storeOrders.map(o => (
                    <option key={o.id} value={o.id}>
                      {o.orderNumber || o.id} - {o.customerName} (৳{o.totalAmount})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Return Reason</label>
                <select
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl bg-white"
                >
                  <option value="Damaged or Defective Item">Damaged or Defective Item (ক্ষতিগ্রস্ত পণ্য)</option>
                  <option value="Wrong Item Shipped">Wrong Item Shipped (ভুল পণ্য পাঠানো হয়েছে)</option>
                  <option value="Customer Changed Mind">Customer Changed Mind (গ্রাহক পণ্য নিতে অপারগ)</option>
                  <option value="Size / Variant Mismatch">Size / Variant Mismatch (সাইজ অমিল)</option>
                  <option value="Parcel Returned Undelivered">Parcel Returned Undelivered (কুরিয়ার রিটার্ন)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Refund Amount (৳)</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={refundAmount}
                  onChange={(e) => setRefundAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Internal Notes</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Courier return charges to be adjusted"
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 text-white font-bold rounded-xl"
                >
                  Submit Return
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
