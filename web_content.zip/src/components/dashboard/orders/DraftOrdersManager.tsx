import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  SquarePen, 
  Plus, 
  Search, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  User, 
  Package, 
  X,
  CreditCard,
  AlertCircle,
  ChevronsUpDown,
  Check,
  SlidersHorizontal,
  ArrowDown,
  Download,
  BookOpen,
  FileText,
  ChevronRight,
  ShoppingBag,
  ExternalLink,
  Tag,
  MapPin
} from 'lucide-react';
import { DraftOrder, Order, Product, Customer, Store, Language, PaymentMethod, OrderItem, ShippingSettings } from '../../../types';
import { calculateDeliveryCharge, ALL_BD_DISTRICTS, getStoreLocationDistrict, BDDistrict } from '../../../utils/deliveryLocationService';

interface DraftOrdersManagerProps {
  draftOrders: DraftOrder[];
  products: Product[];
  customers: Customer[];
  activeStore: Store;
  language: Language;
  shippingSettings?: ShippingSettings | null;
  onSaveDraftOrder: (draft: DraftOrder) => void;
  onDeleteDraftOrder: (draftId: string) => void;
  onConvertDraftToOrder: (draft: DraftOrder) => void;
}

export const DraftOrdersManager: React.FC<DraftOrdersManagerProps> = ({
  draftOrders = [],
  products = [],
  customers = [],
  activeStore,
  language,
  shippingSettings,
  onSaveDraftOrder,
  onDeleteDraftOrder,
  onConvertDraftToOrder
}) => {
  const isBn = language === 'bn';

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'completed' | 'cancelled'>('all');
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const filterDropdownRef = useRef<HTMLDivElement>(null);

  // Selection
  const [selectedDraftIds, setSelectedDraftIds] = useState<string[]>([]);

  // Modals & Drawers
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [activeDetailsDraft, setActiveDetailsDraft] = useState<DraftOrder | null>(null);
  const [isLearnMoreOpen, setIsLearnMoreOpen] = useState(false);

  // Form states for Create/Edit Modal
  const [editingDraftId, setEditingDraftId] = useState<string | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  
  const defaultCity = useMemo(() => getStoreLocationDistrict(activeStore) || 'Sylhet', [activeStore]);
  const [city, setCity] = useState(defaultCity);
  const [poNumber, setPoNumber] = useState('');
  const [selectedItems, setSelectedItems] = useState<OrderItem[]>([]);
  const [productSearch, setProductSearch] = useState('');
  const [discountAmount, setDiscountAmount] = useState<number>(0);

  const draftSubtotal = useMemo(() => {
    return selectedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [selectedItems]);

  const draftDeliveryResult = useMemo(() => {
    return calculateDeliveryCharge(city, activeStore, shippingSettings, draftSubtotal);
  }, [city, activeStore, shippingSettings, draftSubtotal]);

  const [shippingFee, setShippingFee] = useState<number>(() => {
    return calculateDeliveryCharge(defaultCity, activeStore, shippingSettings, 0).charge;
  });
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  // Click outside to close filter popover
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (filterDropdownRef.current && !filterDropdownRef.current.contains(e.target as Node)) {
        setIsFilterDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Safe data arrays
  const safeProducts = useMemo(() => {
    return (Array.isArray(products) ? products : []).filter(p => p && p.storeId === activeStore?.id);
  }, [products, activeStore?.id]);

  const safeCustomers = useMemo(() => {
    return (Array.isArray(customers) ? customers : []).filter(c => c && c.storeId === activeStore?.id);
  }, [customers, activeStore?.id]);

  const storeDrafts = useMemo(() => {
    return (Array.isArray(draftOrders) ? draftOrders : []).filter(d => d && d.storeId === activeStore?.id);
  }, [draftOrders, activeStore?.id]);

  // Filtered & Sorted Drafts
  const filteredDrafts = useMemo(() => {
    return storeDrafts.filter(draft => {
      // Status Filter
      if (statusFilter !== 'all') {
        const dStatus = draft.status || 'open';
        if (statusFilter === 'open' && dStatus !== 'open' && dStatus !== 'draft') return false;
        if (statusFilter === 'completed' && dStatus !== 'completed' && dStatus !== 'converted') return false;
        if (statusFilter === 'cancelled' && dStatus !== 'cancelled') return false;
      }

      // Search Query Filter
      const q = searchTerm.toLowerCase().trim();
      if (!q) return true;

      const matchesNumber = (draft.orderNumber || '').toLowerCase().includes(q);
      const matchesPo = (draft.poNumber || '').toLowerCase().includes(q);
      const matchesCustomer = (draft.customerName || '').toLowerCase().includes(q);
      const matchesPhone = (draft.customerPhone || '').includes(q);
      const matchesEmail = (draft.customerEmail || '').toLowerCase().includes(q);

      return matchesNumber || matchesPo || matchesCustomer || matchesPhone || matchesEmail;
    }).sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  }, [storeDrafts, statusFilter, searchTerm]);

  // Multi-Select
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedDraftIds(filteredDrafts.map(d => d.id));
    } else {
      setSelectedDraftIds([]);
    }
  };

  const handleToggleSelectDraft = (draftId: string) => {
    if (selectedDraftIds.includes(draftId)) {
      setSelectedDraftIds(selectedDraftIds.filter(id => id !== draftId));
    } else {
      setSelectedDraftIds([...selectedDraftIds, draftId]);
    }
  };

  // CSV Export
  const handleExportCSV = () => {
    const draftsToExport = selectedDraftIds.length > 0 
      ? storeDrafts.filter(d => selectedDraftIds.includes(d.id))
      : filteredDrafts;

    if (draftsToExport.length === 0) return;

    const headers = ['Draft order', 'PO number', 'Date', 'Customer', 'Status', 'Items count', 'Subtotal', 'Discount', 'Shipping', 'Total', 'Notes'];
    const rows = draftsToExport.map(d => [
      `"${d.orderNumber}"`,
      `"${d.poNumber || ''}"`,
      `"${d.createdAt ? new Date(d.createdAt).toLocaleDateString() : ''}"`,
      `"${d.customerName || 'No customer'}"`,
      `"${d.status || 'Open'}"`,
      d.items.length,
      d.subtotal,
      d.discount,
      d.shippingFee,
      d.totalAmount,
      `"${(d.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `draft_orders_${activeStore.slug}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Open Create Modal
  const handleOpenCreateModal = () => {
    setEditingDraftId(null);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerEmail('');
    setDeliveryAddress('');
    setCity(defaultCity);
    setPoNumber('');
    setSelectedItems([]);
    setDiscountAmount(0);
    const initialCalc = calculateDeliveryCharge(defaultCity, activeStore, shippingSettings, 0);
    setShippingFee(initialCalc.charge);
    setPaymentMethod('cod');
    setNotes('');
    setFormError(null);
    setIsCreateModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (draft: DraftOrder) => {
    setEditingDraftId(draft.id);
    setCustomerName(draft.customerName || '');
    setCustomerPhone(draft.customerPhone || '');
    setCustomerEmail(draft.customerEmail || '');
    setDeliveryAddress(draft.deliveryAddress || '');
    const draftCity = draft.city || defaultCity;
    setCity(draftCity);
    setPoNumber(draft.poNumber || '');
    setSelectedItems(draft.items || []);
    setDiscountAmount(draft.discount || 0);
    setShippingFee(draft.shippingFee !== undefined ? draft.shippingFee : calculateDeliveryCharge(draftCity, activeStore, shippingSettings, draft.subtotal).charge);
    setPaymentMethod(draft.paymentMethod || 'cod');
    setNotes(draft.notes || '');
    setFormError(null);
    setActiveDetailsDraft(null);
    setIsCreateModalOpen(true);
  };

  const handleCityChange = (newCity: string) => {
    setCity(newCity);
    const calc = calculateDeliveryCharge(newCity, activeStore, shippingSettings, draftSubtotal);
    setShippingFee(calc.charge);
  };

  // Add product to items
  const handleAddProduct = (prod: Product) => {
    const existing = selectedItems.find(i => i.productId === prod.id);
    if (existing) {
      setSelectedItems(selectedItems.map(i => i.productId === prod.id ? { ...i, quantity: i.quantity + 1 } : i));
    } else {
      setSelectedItems([
        ...selectedItems,
        {
          productId: prod.id,
          name: isBn ? prod.nameBn || prod.name : prod.name,
          price: prod.price,
          quantity: 1,
          image: prod.image,
          sku: prod.sku
        }
      ]);
    }
  };

  // Save Draft Order
  const handleSaveDraft = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedItems.length === 0) {
      setFormError(isBn ? 'কমপক্ষে একটি পণ্য যোগ করুন।' : 'Please add at least one product.');
      return;
    }

    const totalAmount = Math.max(0, draftSubtotal - discountAmount + shippingFee);

    // Generate neat draft number: #D1, #D2, #D3 or existing
    const existingDraftsCount = storeDrafts.length;
    const autoNumber = `#D${existingDraftsCount + 1}`;

    const draft: DraftOrder = {
      id: editingDraftId || `draft-${Date.now()}`,
      orderNumber: editingDraftId 
        ? (storeDrafts.find(d => d.id === editingDraftId)?.orderNumber || autoNumber)
        : autoNumber,
      poNumber: poNumber.trim() || undefined,
      storeId: activeStore.id,
      customerName: customerName.trim() || 'No customer',
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail.trim(),
      deliveryAddress: deliveryAddress.trim(),
      city,
      deliveryZone: draftDeliveryResult.deliveryZone,
      deliveryCharge: shippingFee,
      items: selectedItems,
      subtotal: draftSubtotal,
      discount: discountAmount,
      shippingFee,
      totalAmount,
      paymentMethod,
      notes: notes.trim(),
      status: 'open',
      createdAt: editingDraftId 
        ? (storeDrafts.find(d => d.id === editingDraftId)?.createdAt || new Date().toISOString())
        : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSaveDraftOrder(draft);
    setIsCreateModalOpen(false);
  };

  const currencyCode = activeStore?.currency || 'BDT';

  // Format date helper: Dec 19, 2023
  const formatDate = (isoString?: string) => {
    if (!isoString) return 'Dec 19, 2023';
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return 'Dec 19, 2023';
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto pb-16">
      {/* ========================================================================= */}
      {/* 1. TOP HEADER (EXACT SHOPIFY REFERENCE LAYOUT)                           */}
      {/* ========================================================================= */}
      <div className="flex items-center justify-between gap-3 pt-1">
        {/* Left: Draft icon + Title */}
        <div className="flex items-center gap-2">
          <SquarePen className="w-4 h-4 text-slate-700" />
          <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
            {isBn ? 'ড্রাফট (Drafts)' : 'Drafts'}
          </h1>
        </div>

        {/* Right: Export and Create Order Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
          >
            {isBn ? 'এক্সপোর্ট' : 'Export'}
          </button>

          <button
            type="button"
            onClick={handleOpenCreateModal}
            className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
          >
            {isBn ? 'অর্ডার তৈরি করুন' : 'Create order'}
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. COMPACT TOOLBAR (SEARCH & FILTER ROW - EXACT SHOPIFY STYLE)           */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs p-2 flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {/* Status Filter Dropdown Pill */}
          <div className="relative" ref={filterDropdownRef}>
            <button
              type="button"
              onClick={() => setIsFilterDropdownOpen(!isFilterDropdownOpen)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs shadow-2xs transition-colors cursor-pointer shrink-0"
            >
              <span className="capitalize">{statusFilter === 'all' ? (isBn ? 'সকল' : 'All') : statusFilter}</span>
              <ChevronsUpDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Filter Dropdown Popover */}
            {isFilterDropdownOpen && (
              <div className="absolute top-full left-0 mt-1 w-36 bg-white rounded-xl border border-slate-200 shadow-xl py-1 z-50 animate-in fade-in slide-in-from-top-1 text-xs">
                {(['all', 'open', 'completed', 'cancelled'] as const).map(st => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => {
                      setStatusFilter(st);
                      setIsFilterDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 flex items-center justify-between hover:bg-slate-50 capitalize cursor-pointer ${
                      statusFilter === st ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-700'
                    }`}
                  >
                    <span>{st === 'all' ? (isBn ? 'সকল' : 'All') : st}</span>
                    {statusFilter === st && <Check className="w-3 h-3 text-slate-900" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Search Input Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={isBn ? 'অনুসন্ধান এবং ফিল্টার...' : 'Search and filter'}
              className="w-full pl-8 pr-3 py-1 rounded-lg border border-slate-200 text-xs text-slate-900 placeholder-slate-400 bg-transparent focus:outline-none focus:border-slate-400"
            />
          </div>
        </div>

        {/* View / Column Adjust Icon Button (Screenshot Match) */}
        <div className="shrink-0">
          <button
            type="button"
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
            title="Columns"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. DRAFT ORDERS TABLE (EXACT PROPORTIONS & ROW HEIGHT FROM SCREENSHOT)   */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs overflow-hidden">
        {filteredDrafts.length === 0 ? (
          /* Empty State */
          <div className="py-14 text-center p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
              <SquarePen className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                {searchTerm || statusFilter !== 'all'
                  ? (isBn ? 'কোনো ড্রাফট পাওয়া যায়নি' : 'No draft orders found')
                  : (isBn ? 'আপনার ড্রাফট অর্ডার এখানে দেখা যাবে' : 'Your draft orders will show here')}
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                {isBn 
                  ? 'গ্রাহকদের জন্য কাস্টম ইনভয়েস তৈরি করতে ওপরের বাটনটি ব্যবহার করুন।' 
                  : 'Prepare orders and invoices to send to your customers. Review pricing, add custom items, and collect payment when ready.'}
              </p>
            </div>
            <button
              type="button"
              onClick={handleOpenCreateModal}
              className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors cursor-pointer shadow-2xs"
            >
              {isBn ? 'অর্ডার তৈরি করুন' : 'Create order'}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="border-b border-slate-200/80 bg-slate-50/60 text-slate-500 font-semibold text-[11px]">
                <tr>
                  <th className="py-2.5 px-3.5 w-10">
                    <input
                      type="checkbox"
                      checked={selectedDraftIds.length > 0 && selectedDraftIds.length === filteredDrafts.length}
                      onChange={(e) => handleSelectAll(e.target.checked)}
                      className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer"
                    />
                  </th>
                  <th className="py-2.5 px-3 font-semibold text-slate-700">{isBn ? 'ড্রাফট অর্ডার' : 'Draft order'}</th>
                  <th className="py-2.5 px-3 font-semibold text-slate-700">{isBn ? 'PO নম্বর' : 'PO number'}</th>
                  <th className="py-2.5 px-3 font-semibold text-slate-700 flex items-center gap-1">
                    <span>{isBn ? 'তারিখ' : 'Date'}</span>
                    <ArrowDown className="w-3 h-3 text-slate-400" />
                  </th>
                  <th className="py-2.5 px-3 font-semibold text-slate-700">{isBn ? 'গ্রাহক' : 'Customer'}</th>
                  <th className="py-2.5 px-3 font-semibold text-slate-700">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                  <th className="py-2.5 px-4 text-right font-semibold text-slate-700">{isBn ? 'মোট' : 'Total'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {filteredDrafts.map((draft) => {
                  const isChecked = selectedDraftIds.includes(draft.id);
                  const statusLabel = draft.status === 'completed' || draft.status === 'converted'
                    ? 'Completed'
                    : draft.status === 'cancelled'
                    ? 'Cancelled'
                    : 'Open';

                  return (
                    <tr 
                      key={draft.id} 
                      onClick={() => setActiveDetailsDraft(draft)}
                      className={`hover:bg-slate-50/70 transition-colors cursor-pointer ${
                        isChecked ? 'bg-slate-50/80' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3.5" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleSelectDraft(draft.id)}
                          className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer"
                        />
                      </td>

                      {/* Draft Order Number */}
                      <td className="py-2.5 px-3 font-bold text-slate-900 whitespace-nowrap">
                        {draft.orderNumber}
                      </td>

                      {/* PO Number */}
                      <td className="py-2.5 px-3 text-slate-500 font-mono text-[11px]">
                        {draft.poNumber || ''}
                      </td>

                      {/* Date (Format: Dec 19, 2023) */}
                      <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                        {formatDate(draft.createdAt)}
                      </td>

                      {/* Customer Name */}
                      <td className="py-2.5 px-3 text-slate-800 whitespace-nowrap">
                        {draft.customerName && draft.customerName !== 'No customer' ? (
                          <span className="font-medium text-slate-900">{draft.customerName}</span>
                        ) : (
                          <span className="text-slate-400 font-normal">{isBn ? 'গ্রাহক নেই' : 'No customer'}</span>
                        )}
                      </td>

                      {/* Status Badge (Exact yellow/amber badge with dot from screenshot) */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        {statusLabel === 'Open' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#ffea8a]/50 text-[#5c3b00] border border-[#e0b252]/40">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#b28400]" />
                            {isBn ? 'ওপেন' : 'Open'}
                          </span>
                        ) : statusLabel === 'Completed' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-300/50">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                            {isBn ? 'সম্পন্ন' : 'Completed'}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-600 border border-slate-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                            {isBn ? 'বাতিল' : 'Cancelled'}
                          </span>
                        )}
                      </td>

                      {/* Total Amount (Right-aligned, currency suffix) */}
                      <td className="py-2.5 px-4 text-right font-medium text-slate-900 whitespace-nowrap">
                        ৳{draft.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencyCode}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 4. FOOTER EDUCATIONAL LINK (EXACT SCREENSHOT MATCH)                       */}
      {/* ========================================================================= */}
      <div className="text-center pt-2">
        <button
          type="button"
          onClick={() => setIsLearnMoreOpen(true)}
          className="text-xs text-slate-600 hover:text-slate-900 underline underline-offset-2 transition-colors cursor-pointer font-medium"
        >
          {isBn ? 'ড্রাফট অর্ডার তৈরি সম্পর্কে বিস্তারিত জানুন' : 'Learn more about creating draft orders'}
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 5. DRAFT ORDER DETAILS DRAWER                                             */}
      {/* ========================================================================= */}
      {activeDetailsDraft && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-end">
          <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-200">
            {/* Drawer Header */}
            <div>
              <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-2">
                  <SquarePen className="w-4 h-4 text-slate-700" />
                  <span className="font-bold text-slate-900 text-sm">
                    {activeDetailsDraft.orderNumber}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#ffea8a]/50 text-[#5c3b00] border border-[#e0b252]/40">
                    {activeDetailsDraft.status?.toUpperCase() || 'OPEN'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveDetailsDraft(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Drawer Content */}
              <div className="p-4 space-y-4 text-xs">
                {/* Customer Card */}
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 space-y-1">
                  <div className="flex items-center justify-between text-slate-500 font-semibold text-[11px]">
                    <span>{isBn ? 'গ্রাহক তথ্য' : 'Customer'}</span>
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <p className="font-bold text-slate-900 text-xs">{activeDetailsDraft.customerName || 'No customer'}</p>
                  {activeDetailsDraft.customerPhone && (
                    <p className="text-slate-500">{activeDetailsDraft.customerPhone}</p>
                  )}
                  {activeDetailsDraft.customerEmail && (
                    <p className="text-slate-500">{activeDetailsDraft.customerEmail}</p>
                  )}
                  {activeDetailsDraft.deliveryAddress && (
                    <p className="text-slate-500 pt-1 border-t border-slate-200/60 mt-1">
                      {activeDetailsDraft.deliveryAddress}, {activeDetailsDraft.city}
                    </p>
                  )}
                </div>

                {/* Items List */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-slate-700 text-xs">
                    {isBn ? 'নির্বাচিত পণ্যসমূহ' : 'Items'} ({activeDetailsDraft.items.length})
                  </h4>
                  <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white">
                    {activeDetailsDraft.items.map((it, idx) => (
                      <div key={idx} className="p-2.5 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          {it.image ? (
                            <img src={it.image} alt={it.name} className="w-8 h-8 rounded object-cover border border-slate-200" />
                          ) : (
                            <div className="w-8 h-8 rounded bg-slate-100 flex items-center justify-center text-slate-400">
                              <Package className="w-4 h-4" />
                            </div>
                          )}
                          <div className="truncate">
                            <p className="font-medium text-slate-900 truncate">{it.name}</p>
                            <p className="text-[11px] text-slate-400">৳{it.price} × {it.quantity}</p>
                          </div>
                        </div>
                        <span className="font-bold text-slate-900 shrink-0">
                          ৳{(it.price * it.quantity).toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Financial Breakdown */}
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>{isBn ? 'সাবটোটাল' : 'Subtotal'}</span>
                    <span>৳{activeDetailsDraft.subtotal.toLocaleString()}</span>
                  </div>
                  {activeDetailsDraft.discount > 0 && (
                    <div className="flex justify-between text-emerald-600">
                      <span>{isBn ? 'ডিসকাউন্ট' : 'Discount'}</span>
                      <span>-৳{activeDetailsDraft.discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-500">
                    <span>{isBn ? 'শিপিং চার্জ' : 'Shipping'}</span>
                    <span>৳{activeDetailsDraft.shippingFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-900 font-bold pt-1.5 border-t border-slate-200 text-sm">
                    <span>{isBn ? 'সর্বমোট' : 'Total'}</span>
                    <span>৳{activeDetailsDraft.totalAmount.toLocaleString()} {currencyCode}</span>
                  </div>
                </div>

                {/* Notes & PO */}
                {(activeDetailsDraft.notes || activeDetailsDraft.poNumber) && (
                  <div className="bg-white rounded-xl p-3 border border-slate-200 text-xs space-y-1">
                    {activeDetailsDraft.poNumber && (
                      <p className="text-slate-600">
                        <span className="font-bold text-slate-700">PO Number:</span> {activeDetailsDraft.poNumber}
                      </p>
                    )}
                    {activeDetailsDraft.notes && (
                      <p className="text-slate-500 italic">
                        "{activeDetailsDraft.notes}"
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Drawer Bottom Actions */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 space-y-2">
              <button
                type="button"
                onClick={() => {
                  onConvertDraftToOrder(activeDetailsDraft);
                  setActiveDetailsDraft(null);
                }}
                className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isBn ? 'অর্ডারে রূপান্তর করুন' : 'Convert to real order'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenEditModal(activeDetailsDraft)}
                  className="flex-1 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
                >
                  {isBn ? 'এডিট করুন' : 'Edit draft'}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(isBn ? 'আপনি কি নিশ্চিত যে এই ড্রাফটটি মুছে ফেলতে চান?' : 'Are you sure you want to delete this draft?')) {
                      onDeleteDraftOrder(activeDetailsDraft.id);
                      setActiveDetailsDraft(null);
                    }
                  }}
                  className="p-2 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors cursor-pointer"
                  title="Delete draft"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. CREATE / EDIT DRAFT ORDER MODAL                                       */}
      {/* ========================================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col justify-between shadow-2xl border border-slate-200 overflow-hidden text-xs">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-slate-900 text-sm">
                {editingDraftId ? (isBn ? 'ড্রাফট অর্ডার সম্পাদনা' : 'Edit Draft Order') : (isBn ? 'নতুন ড্রাফট তৈরি করুন' : 'Create Draft Order')}
              </h3>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Form */}
            <form onSubmit={handleSaveDraft} id="draftForm" className="p-5 overflow-y-auto space-y-4">
              {formError && (
                <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Customer Info Section */}
              <div className="space-y-2">
                <span className="font-bold text-slate-800 block text-xs">
                  {isBn ? 'গ্রাহকের বিবরণ' : 'Customer Details'}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder={isBn ? 'গ্রাহকের নাম (ঐচ্ছিক)' : 'Customer name (optional)'}
                    className="p-2 rounded-lg border border-slate-300 text-xs focus:outline-slate-900"
                  />
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder={isBn ? 'ফোন নম্বর' : 'Phone number'}
                    className="p-2 rounded-lg border border-slate-300 text-xs focus:outline-slate-900"
                  />
                  <input
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder={isBn ? 'ইমেইল অ্যাড্রেস' : 'Email address'}
                    className="p-2 rounded-lg border border-slate-300 text-xs focus:outline-slate-900"
                  />
                  <input
                    type="text"
                    value={poNumber}
                    onChange={(e) => setPoNumber(e.target.value)}
                    placeholder="PO number (optional)"
                    className="p-2 rounded-lg border border-slate-300 text-xs focus:outline-slate-900"
                  />
                  <input
                    type="text"
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    placeholder={isBn ? 'ডেলিভারি ঠিকানা' : 'Delivery address'}
                    className="p-2 rounded-lg border border-slate-300 text-xs focus:outline-slate-900"
                  />

                  {/* Store-Location Based City / District Selector */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-semibold text-slate-700">
                        {isBn ? 'শহর / জেলা' : 'City / District'}
                      </label>
                      <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        {isBn ? `স্টোর: ${draftDeliveryResult.storeLocationSummary}` : `Store: ${draftDeliveryResult.storeLocationSummary}`}
                      </span>
                    </div>
                    <select
                      value={city}
                      onChange={(e) => handleCityChange(e.target.value)}
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-slate-900 bg-white"
                    >
                      {ALL_BD_DISTRICTS.map((dist: BDDistrict) => {
                        const preview = calculateDeliveryCharge(dist.name, activeStore, shippingSettings, draftSubtotal);
                        return (
                          <option key={dist.name} value={dist.name}>
                            {dist.name} ({dist.nameBn}) — {preview.isFreeShipping ? 'Free' : `৳${preview.charge}`} ({preview.isLocal ? (isBn ? 'লোকাল' : 'Local') : (isBn ? 'আউটসাইড' : 'Outside')})
                          </option>
                        );
                      })}
                    </select>
                    <div className="mt-1 text-[10px] text-slate-600 flex items-center justify-between px-0.5">
                      <span className={`font-semibold ${draftDeliveryResult.isLocal ? 'text-emerald-700' : 'text-blue-700'}`}>
                        {isBn ? draftDeliveryResult.zoneDescriptionBn : draftDeliveryResult.zoneDescription}
                      </span>
                      <span className="font-bold text-slate-800">
                        {draftDeliveryResult.isFreeShipping ? (isBn ? 'ফ্রি' : 'Free') : `৳${draftDeliveryResult.charge}`}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Product Selection Section */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="font-bold text-slate-800 block text-xs">
                  {isBn ? 'পণ্য যোগ করুন' : 'Add Products'}
                </span>

                {/* Product Search & Quick Pick */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    placeholder={isBn ? 'স্টোর পণ্য খুঁজুন...' : 'Search store products...'}
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-slate-900"
                  />
                </div>

                {productSearch && (
                  <div className="max-h-36 overflow-y-auto border border-slate-200 rounded-lg p-1 divide-y divide-slate-100 bg-white shadow-inner">
                    {safeProducts
                      .filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase()))
                      .slice(0, 5)
                      .map(p => (
                        <div key={p.id} className="p-2 flex items-center justify-between hover:bg-slate-50 rounded">
                          <span className="font-medium text-slate-800">{p.name} (৳{p.price})</span>
                          <button
                            type="button"
                            onClick={() => handleAddProduct(p)}
                            className="px-2 py-1 rounded bg-slate-900 text-white text-[11px] font-medium"
                          >
                            + Add
                          </button>
                        </div>
                      ))}
                  </div>
                )}

                {/* Selected Items List */}
                {selectedItems.length > 0 && (
                  <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl bg-slate-50/50 p-2 space-y-1">
                    {selectedItems.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between gap-2 py-1">
                        <span className="font-medium text-slate-800 truncate">{item.name}</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => {
                              const val = Math.max(1, parseInt(e.target.value) || 1);
                              setSelectedItems(selectedItems.map((it, i) => i === idx ? { ...it, quantity: val } : it));
                            }}
                            className="w-12 p-1 rounded border border-slate-300 text-center text-xs"
                          />
                          <span className="font-bold text-slate-900 w-16 text-right">
                            ৳{(item.price * item.quantity).toLocaleString()}
                          </span>
                          <button
                            type="button"
                            onClick={() => setSelectedItems(selectedItems.filter((_, i) => i !== idx))}
                            className="text-rose-500 hover:text-rose-700 p-1"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Adjustments: Discount & Shipping */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                <div>
                  <label className="text-slate-600 block mb-1">{isBn ? 'ডিসকাউন্ট (৳)' : 'Discount (৳)'}</label>
                  <input
                    type="number"
                    min="0"
                    value={discountAmount}
                    onChange={(e) => setDiscountAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full p-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-slate-600 block">{isBn ? 'শিপিং চার্জ (৳)' : 'Shipping Fee (৳)'}</label>
                    <button
                      type="button"
                      onClick={() => setShippingFee(draftDeliveryResult.charge)}
                      className="text-[10px] text-emerald-600 hover:underline font-bold"
                    >
                      {isBn ? 'অটো রেট দিন' : 'Use Auto Rate'}
                    </button>
                  </div>
                  <input
                    type="number"
                    min="0"
                    value={shippingFee}
                    onChange={(e) => setShippingFee(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full p-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="text-slate-600 block mb-1">{isBn ? 'অর্ডার নোট' : 'Order Notes'}</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={isBn ? 'বিশেষ কোনো নির্দেশনা...' : 'Special notes or customer instructions...'}
                  className="w-full p-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>
            </form>

            {/* Modal Bottom Actions */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="text-xs">
                <span className="text-slate-500">{isBn ? 'আনুমানিক মোট:' : 'Estimated total:'} </span>
                <span className="font-bold text-slate-900 text-sm">
                  ৳{(Math.max(0, selectedItems.reduce((s, i) => s + (i.price * i.quantity), 0) - discountAmount + shippingFee)).toLocaleString()} {currencyCode}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  form="draftForm"
                  className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-2xs"
                >
                  {editingDraftId ? (isBn ? 'হালনাগাদ করুন' : 'Update draft') : (isBn ? 'ড্রাফট সংরক্ষণ' : 'Save draft')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. LEARN MORE ABOUT DRAFT ORDERS MODAL                                    */}
      {/* ========================================================================= */}
      {isLearnMoreOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  {isBn ? 'ড্রাফট অর্ডার গাইড' : 'About Draft Orders on Shanju'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsLearnMoreOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-slate-600 leading-relaxed">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-800 block mb-1">
                  1. Phone & Quotation Orders:
                </span>
                <p>
                  Create manual orders for phone calls, WhatsApp inquiries, or wholesale buyers with custom line items and negotiable discounts.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-800 block mb-1">
                  2. Stock Reservation:
                </span>
                <p>
                  Inventory is not deducted while the order remains in "Open" draft status. Stock will automatically be deducted once you convert it to a real order.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="font-bold text-slate-800 block mb-1">
                  3. Export & Records:
                </span>
                <p>
                  Export all open or completed draft orders directly to CSV for bookkeeping and external accounting.
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setIsLearnMoreOpen(false)}
                className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs cursor-pointer"
              >
                {isBn ? 'বুঝেছি' : 'Got it'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
