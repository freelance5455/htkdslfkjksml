import React, { useState, useMemo } from 'react';
import { 
  Truck, 
  MapPin, 
  Save, 
  Check, 
  ShieldCheck, 
  DollarSign, 
  PackageCheck,
  CheckCircle2,
  Building2,
  Info,
  HelpCircle,
  Compass,
  AlertCircle
} from 'lucide-react';
import { ShippingSettings, Store, Language, StoreLocation } from '../../../types';
import { BD_DIVISIONS, BD_DISTRICTS_FLAT, getStoreLocationDistrict, BDDivision, BDDistrict } from '../../../utils/deliveryLocationService';

interface ShippingDeliverySettingsProps {
  settings: ShippingSettings | null;
  activeStore: Store;
  language: Language;
  onSaveSettings: (settings: ShippingSettings) => void;
  onUpdateStoreLocation?: (storeId: string, location: StoreLocation) => void;
}

export const ShippingDeliverySettings: React.FC<ShippingDeliverySettingsProps> = ({
  settings,
  activeStore,
  language,
  onSaveSettings,
  onUpdateStoreLocation
}) => {
  const isBn = language === 'bn';

  // Initial Store Location resolution
  const initialStoreLocation: StoreLocation = useMemo(() => {
    if (settings?.storeLocation) return settings.storeLocation;
    if (activeStore?.storeLocation) return activeStore.storeLocation;
    
    const fallbackDistrict = getStoreLocationDistrict(activeStore);
    return {
      division: 'Sylhet',
      district: fallbackDistrict || 'Sylhet',
      city: fallbackDistrict || 'Sylhet',
      address: activeStore?.address || 'Goalabazar, Osmani Nagar, Sylhet'
    };
  }, [settings?.storeLocation, activeStore]);

  // Form states
  const [division, setDivision] = useState<string>(initialStoreLocation.division || 'Sylhet');
  const [district, setDistrict] = useState<string>(initialStoreLocation.district || 'Sylhet');
  const [streetAddress, setStreetAddress] = useState<string>(initialStoreLocation.address || activeStore?.address || '');

  const [localCharge, setLocalCharge] = useState<number>(
    settings?.localDeliveryCharge ?? settings?.insideCityCharge ?? 60
  );
  const [outsideCharge, setOutsideCharge] = useState<number>(
    settings?.outsideDeliveryCharge ?? settings?.outsideCityCharge ?? 120
  );
  const [freeThreshold, setFreeThreshold] = useState<number>(
    settings?.freeShippingThreshold ?? 2500
  );
  const [defaultCourier, setDefaultCourier] = useState<string>(
    settings?.defaultCourier ?? 'Steadfast'
  );
  const [isSaved, setIsSaved] = useState(false);

  // Filter districts for the selected division
  const currentDivisionDistricts = useMemo(() => {
    const found = BD_DIVISIONS.find((d: BDDivision) => d.name.toLowerCase() === division.toLowerCase());
    return found ? found.districts : [];
  }, [division]);

  // Handle division change
  const handleDivisionChange = (newDivision: string) => {
    setDivision(newDivision);
    const divObj = BD_DIVISIONS.find((d: BDDivision) => d.name.toLowerCase() === newDivision.toLowerCase());
    if (divObj && divObj.districts.length > 0) {
      setDistrict(divObj.districts[0].name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedStoreLocation: StoreLocation = {
      division,
      district,
      city: district,
      address: streetAddress.trim()
    };

    const updatedSettings: ShippingSettings = {
      storeId: activeStore.id,
      localDeliveryCharge: Number(localCharge),
      outsideDeliveryCharge: Number(outsideCharge),
      insideCityCharge: Number(localCharge), // backwards-compatible alias
      outsideCityCharge: Number(outsideCharge), // backwards-compatible alias
      freeShippingThreshold: Number(freeThreshold),
      defaultCourier,
      availableCouriers: ['Steadfast', 'Pathao', 'RedX', 'Paperfly', 'Sundarban', 'In-house'],
      storeLocation: updatedStoreLocation
    };

    onSaveSettings(updatedSettings);
    if (onUpdateStoreLocation) {
      onUpdateStoreLocation(activeStore.id, updatedStoreLocation);
    }

    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-4xl pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Truck className="w-5 h-5 text-emerald-600" />
            <span>{isBn ? 'স্টোর-লোকেশন ভিত্তিক ডেলিভারি চার্জ ও শিপিং' : 'Store-Location Based Delivery Rates'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'আপনার স্টোরের নিজস্ব লোকেশন অনুযায়ী স্বয়ংক্রিয়ভাবে লোকাল ও আউটসাইড ডেলিভারি ফি নির্ধারিত হবে।' 
              : "Delivery charges are calculated dynamically relative to your merchant store's own location."}
          </p>
        </div>

        {isSaved && (
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
            <Check className="w-4 h-4" />
            <span>{isBn ? 'সফলভাবে সংরক্ষিত!' : 'Settings Saved!'}</span>
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 text-xs text-slate-700">
        {/* SECTION 1: STORE LOCATION SETUP */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-600" />
              <h3 className="font-bold text-slate-900 text-sm">
                {isBn ? '১. স্টোরের নিজস্ব ভৌগোলিক অবস্থান (Store Location)' : '1. Merchant Store Location'}
              </h3>
            </div>
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              {isBn ? `সক্রিয় লোকেশন: ${district}` : `Active Origin: ${district}`}
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            {isBn 
              ? 'ডেলিভারি চার্জ নির্ণয়ের জন্য আপনার স্টোর/গুদামের বিভাগ ও জেলা নির্বাচন করুন। গ্রাহক একই জেলা থেকে অর্ডার করলে লোকাল রেট এবং অন্য জেলা থেকে অর্ডার করলে আউটসাইড রেট প্রযোজ্য হবে।'
              : 'Select the primary division and district where your store/warehouse is located. Customers within this district get the Local rate; outside customers get the Outside rate.'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Division Select */}
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'বিভাগ (Division)' : 'Division'}
              </label>
              <select
                value={division}
                onChange={(e) => handleDivisionChange(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-medium text-xs text-slate-900 focus:outline-emerald-500"
              >
                {BD_DIVISIONS.map((div: BDDivision) => (
                  <option key={div.name} value={div.name}>
                    {div.name} ({div.nameBn})
                  </option>
                ))}
              </select>
            </div>

            {/* District / City Select */}
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'জেলা / প্রধান শহর (District / Store City)' : 'District / City'}
              </label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-bold text-xs text-slate-900 focus:outline-emerald-500"
              >
                {currentDivisionDistricts.map((dist: BDDistrict) => (
                  <option key={dist.name} value={dist.name}>
                    {dist.name} ({dist.nameBn})
                  </option>
                ))}
              </select>
            </div>

            {/* Detailed Street Address / Hub */}
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'স্টোর / ওয়্যারহাউস ঠিকানা (Street / Area / Thana)' : 'Detailed Address / Dispatch Hub'}
              </label>
              <input
                type="text"
                value={streetAddress}
                onChange={(e) => setStreetAddress(e.target.value)}
                placeholder={isBn ? 'যেমন: গোল্লাবাজার, ওসমানী নগর, সিলেট' : 'e.g., Goalabazar, Osmani Nagar, Sylhet'}
                className="w-full px-3.5 py-2 border border-slate-300 rounded-xl bg-white text-xs text-slate-900 focus:outline-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* SECTION 2: DYNAMIC DELIVERY CHARGES */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-3">
            <MapPin className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? '২. ডেলিভারি জোন ও চার্জ কনফিগারেশন' : '2. Dynamic Delivery Zones & Rates'}</span>
          </h3>

          {/* Educational Callout Box */}
          <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200/90 text-slate-700 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div className="text-[11px] leading-relaxed">
              <span className="font-bold text-emerald-900 block">
                {isBn ? `স্টোর অবস্থান: ${district}, ${division}` : `Store Origin: ${district}, ${division}`}
              </span>
              <span>
                {isBn
                  ? `ডেলিভারি চার্জ আপনার স্টোরের অবস্থান (${district}) অনুযায়ী নির্ধারিত হয়। যে সকল গ্রাহক ${district} জেলা থেকে অর্ডার করবেন তারা লোকাল রেট পাবেন। ${district}-এর বাইরের সকল গ্রাহকের জন্য আউটসাইড রেট প্রযোজ্য হবে।`
                  : `Delivery charges are calculated based on your store's location (${district}). Customers ordering within ${district} receive the Local Delivery rate. Customers outside ${district} receive the Outside Store Location rate.`}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* LOCAL DELIVERY RATE */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">
                  {isBn ? 'লোকাল ডেলিভারি চার্জ' : 'Local Delivery Charge'}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  {district} Area
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {isBn 
                  ? `স্টোরের নিজস্ব জেলা (${district})-এর ভেতরে সকল কাস্টমারের জন্য প্রযোজ্য চার্জ`
                  : `Customers in the same city/district (${district}) as the store will be charged this amount.`}
              </p>
              <div className="pt-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900">৳</span>
                  <input
                    type="number"
                    min="0"
                    required
                    value={localCharge}
                    onChange={(e) => setLocalCharge(Number(e.target.value))}
                    className="w-32 px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-black text-sm text-slate-900 focus:outline-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* OUTSIDE STORE LOCATION RATE */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">
                  {isBn ? 'স্টোরের বাইরের এলাকার ডেলিভারি চার্জ' : 'Outside Store Location Charge'}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                  Outside {district}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {isBn 
                  ? `স্টোরের জেলা (${district})-এর বাইরের সকল জেলা ও এলাকার কাস্টমারদের চার্জ`
                  : `Customers outside the store's city/district (${district}) will be charged this amount.`}
              </p>
              <div className="pt-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900">৳</span>
                  <input
                    type="number"
                    min="0"
                    required
                    value={outsideCharge}
                    onChange={(e) => setOutsideCharge(Number(e.target.value))}
                    className="w-32 px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-black text-sm text-slate-900 focus:outline-emerald-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 3: FREE SHIPPING & COURIER LOGISTICS */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-3">
            <PackageCheck className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? '৩. ফ্রি শিপিং থ্রেশহোল্ড ও কুরিয়ার লজিস্টিকস' : '3. Free Shipping Threshold & Preferred Couriers'}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'ফ্রি ডেলিভারি ন্যূনতম কেনাকাটা (৳)' : 'Free Shipping Minimum Threshold (৳)'}
              </label>
              <p className="text-[11px] text-slate-500 mb-2">
                {isBn ? 'এই মূল্যের বেশি অর্ডারে গ্রাহক সম্পূর্ণ ফ্রি ডেলিভারি পাবেন (০ দিলে বন্ধ থাকবে)' : 'Orders above this amount qualify for zero delivery fee automatically (0 to disable)'}
              </p>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-slate-900">৳</span>
                <input
                  type="number"
                  min="0"
                  value={freeThreshold}
                  onChange={(e) => setFreeThreshold(Number(e.target.value))}
                  className="w-full sm:w-48 px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-black text-sm text-slate-900 focus:outline-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'ডিফল্ট কুরিয়ার পার্টনার' : 'Default Courier Partner'}
              </label>
              <p className="text-[11px] text-slate-500 mb-2">
                {isBn ? 'এক-ক্লিকে পার্সেল বুকিংয়ের জন্য প্রধান কুরিয়ার নির্বাচন করুন' : 'Primary carrier for automated single-click consignment dispatch'}
              </p>
              <select
                value={defaultCourier}
                onChange={(e) => setDefaultCourier(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-semibold text-xs text-slate-900 focus:outline-emerald-500"
              >
                <option value="Steadfast">Steadfast Courier (API Integrated)</option>
                <option value="Pathao">Pathao Logistics (API Integrated)</option>
                <option value="RedX">RedX Delivery Network</option>
                <option value="Paperfly">Paperfly Home Delivery</option>
                <option value="Sundarban">Sundarban Courier Service</option>
                <option value="In-house">In-house Delivery Rider</option>
              </select>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
          >
            <Save className="w-4 h-4 text-emerald-400" />
            <span>{isBn ? 'ডেলিভারি সেটিংস সংরক্ষণ করুন' : 'Save Delivery Configuration'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
