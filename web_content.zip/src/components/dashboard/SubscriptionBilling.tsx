import React, { useState } from 'react';
import { 
  CreditCard, 
  Check, 
  Zap, 
  Shield, 
  FileText, 
  Download, 
  Headphones, 
  Clock, 
  MessageSquare, 
  PhoneCall, 
  ExternalLink,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { Language, PricingPlan, Store, PaymentGatewayConfig, SubscriptionPayment } from '../../types';
import { pricingPlans, initialPaymentGateways } from '../../data/initialData';
import { PlanCheckoutModal } from '../billing/PlanCheckoutModal';

interface SubscriptionBillingProps {
  activeStore: Store;
  language: Language;
  gateways?: PaymentGatewayConfig[];
  onUpdatePlan?: (planId: 'starter' | 'growth' | 'enterprise') => void;
  onAddSubscriptionPayment?: (payment: SubscriptionPayment) => void;
  onOpenSupportChat?: () => void;
}

export const SubscriptionBilling: React.FC<SubscriptionBillingProps> = ({
  activeStore,
  language,
  gateways = initialPaymentGateways,
  onUpdatePlan,
  onAddSubscriptionPayment,
  onOpenSupportChat,
}) => {
  const isBn = language === 'bn';
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<PricingPlan | null>(null);
  const [recentInvoices, setRecentInvoices] = useState<Array<{ id: string; title: string; date: string; amount: number; trxId: string }>>([
    { id: 'INV-2026-09-SF', title: 'Growth Subscription (৳500)', date: 'Sep 01, 2026', amount: 500, trxId: 'AAMAR-2026-88192' },
    { id: 'INV-2026-08-SF', title: '1 Month Free Starter Trial (৳0)', date: 'Aug 01, 2026', amount: 0, trxId: 'FREE-TRIAL-89102' },
  ]);

  const currentPlan = pricingPlans.find((p) => p.id === activeStore.plan) || pricingPlans[1];

  const handleSelectPlan = (plan: PricingPlan) => {
    setSelectedPlanForCheckout(plan);
  };

  const handlePaymentSuccess = (payment: SubscriptionPayment) => {
    if (onUpdatePlan) {
      onUpdatePlan(payment.planId);
    }
    if (onAddSubscriptionPayment) {
      onAddSubscriptionPayment(payment);
    }

    setRecentInvoices((prev) => [
      {
        id: payment.id,
        title: `${payment.planName} via ${payment.gateway.toUpperCase()}`,
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
        amount: payment.amount,
        trxId: payment.transactionId,
      },
      ...prev,
    ]);

    setSuccessToast(
      isBn 
        ? `অভিনন্দন! আপনার স্টোর সফলভাবে '${payment.planName}' প্ল্যানে আপগ্রেড হয়েছে (Trx: ${payment.transactionId})।`
        : `Success! Upgraded to '${payment.planName}' tier (Trx: ${payment.transactionId}).`
    );
    setTimeout(() => setSuccessToast(null), 5000);
  };

  // Quota calculation based on tier
  const productQuotaLabel = 
    activeStore.plan === 'starter' 
      ? '9 / 50' 
      : activeStore.plan === 'growth' 
        ? '9 / 200' 
        : '9 / Unlimited';

  const productQuotaPercent = 
    activeStore.plan === 'starter' 
      ? '18%' 
      : activeStore.plan === 'growth' 
        ? '4.5%' 
        : '2%';

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {successToast && (
        <div className="bg-emerald-600 text-white p-4 rounded-2xl shadow-lg flex items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-bold">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button 
            onClick={() => setSuccessToast(null)}
            className="text-xs font-bold underline px-2 py-1 hover:bg-emerald-700 rounded-lg"
          >
            {isBn ? 'ঠিক আছে' : 'Dismiss'}
          </button>
        </div>
      )}

      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
            {isBn ? 'স্টোর প্ল্যান, সাবস্ক্রিপশন ও বিলিং' : 'Subscription Plans & Quota Usage'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'আপনার বর্তমান প্ল্যান, স্টোরেজ সীমা ও ডেডিকেটেড সাপোর্ট সুবিধা।' 
              : 'Manage tier limits, custom domains, transaction fees, and live support.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500">{isBn ? 'সক্রিয় প্ল্যান:' : 'Active Tier:'}</span>
          <span className="px-3.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-black text-xs capitalize border border-emerald-200">
            {currentPlan ? (isBn ? currentPlan.nameBn : currentPlan.name) : `${activeStore.plan} Plan`}
          </span>
        </div>
      </div>

      {/* Live Customer Support Banner (9:00 AM - 11:00 PM) */}
      <div className="rounded-3xl p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 text-white border border-slate-800 shadow-xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="relative z-10 space-y-2 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[11px] border border-emerald-500/30 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{isBn ? 'সরাসরি কাস্টমার সাপোর্ট' : 'Live Customer Support'}</span>
            </span>
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isBn ? 'সকাল ৯:০০ টা থেকে রাত ১১:০০ টা পর্যন্ত' : '9:00 AM - 11:00 PM Daily'}</span>
            </span>
          </div>

          <h2 className="text-lg sm:text-xl font-black text-white">
            {isBn ? 'আমাদের সাপোর্ট টিমের সাথে সরাসরি চ্যাট করুন' : 'Chat Directly With Our Merchant Support Team'}
          </h2>

          <p className="text-xs text-slate-300 leading-relaxed">
            {isBn 
              ? 'স্টোর তৈরি, ২০০ পণ্য আপলোড, ফ্রি সাবডোমেন, বিকাশ/নগদ পেমেন্ট গেটওয়ে বা প্ল্যান আপগ্রেড নিয়ে যেকোনো সহায়তার জন্য সরাসরি আমাদের সাথে চ্যাট করতে পারেন।'
              : 'Get instant assistance with store setup, uploading 200 products, free subdomains, payment gateways, and tier upgrades.'}
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onOpenSupportChat}
            className="py-3 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4 fill-current" />
            <span>{isBn ? 'সাপোর্টে চ্যাট করুন' : 'Start Support Chat'}</span>
          </button>

          <a
            href="https://wa.me/8801700000000"
            target="_blank"
            rel="noopener noreferrer"
            className="py-3 px-4 rounded-2xl bg-slate-800/90 hover:bg-slate-800 text-white font-bold text-xs border border-slate-700 transition-colors flex items-center gap-2"
          >
            <span>WhatsApp</span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </a>
        </div>
      </div>

      {/* Quota & Usage Gauges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex justify-between text-xs font-semibold text-slate-500 mb-2">
            <span>{isBn ? 'ক্যাটালগ পণ্য সীমা' : 'Product Quota'}</span>
            <span className="font-bold text-slate-900">{productQuotaLabel}</span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: productQuotaPercent }}></div>
          </div>
          <div className="mt-2 text-[11px] text-emerald-600 font-medium">
            {activeStore.plan === 'starter' 
              ? (isBn ? '১ মাস ফ্রি ট্রায়ালে ৫০টি পণ্য অন্তর্ভুক্ত' : '50 products included in Free Trial')
              : activeStore.plan === 'growth' 
                ? (isBn ? 'গ্রোথ প্ল্যানে ২০০টি পণ্য অন্তর্ভুক্ত' : '200 products enabled on Growth (৳500/mo)')
                : (isBn ? 'আনলিমিটেড প্রোডাক্ট যুক্ত করার সুবিধা' : 'Unlimited products on Pro Enterprise')}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex justify-between text-xs font-semibold text-slate-500 mb-2">
            <span>{isBn ? 'ডোমেন ও ক্লাউড ব্যান্ডউইথ' : 'Domain & Bandwidth'}</span>
            <span className="font-bold text-slate-900">
              {activeStore.plan === 'enterprise' ? (isBn ? 'কাস্টম ডোমেন' : 'Custom Domain') : (isBn ? 'ফ্রি সাবডোমেন' : 'Free Subdomain')}
            </span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 rounded-full w-[25%]"></div>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {isBn ? `${activeStore.slug}.shanju.cloud সক্রিয়` : `${activeStore.slug}.shanju.cloud active`}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <div className="flex justify-between text-xs font-semibold text-slate-500 mb-2">
            <span>{isBn ? 'প্ল্যাটফর্ম ট্রানজেকশন ফি' : 'Platform Fee'}</span>
            <span className="font-bold text-emerald-600">0% (Zero Fee)</span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full w-[100%]"></div>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {isBn ? 'প্রতি বিক্রয়ে ১০০% মুনাফা আপনার' : 'Keep 100% of your customer earnings'}
          </div>
        </div>
      </div>

      {/* Plan Switcher Grid */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              {isBn ? 'প্ল্যান নির্বাচন ও আপগ্রেড করুন' : 'Select or Upgrade Your Store Plan'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isBn 
                ? 'আপনার ব্যবসার প্রয়োজন অনুযায়ী উপযুক্ত প্যাকেজ বেছে নিন। যেকোনো সময় আপগ্রেড করা যায়।' 
                : 'Choose the best plan tailored to your business scale. Switch anytime.'}
            </p>
          </div>

          <div className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 w-fit">
            {isBn ? '✨ কোনো লক-ইন চুক্তি নেই' : '✨ No lock-in contract'}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {pricingPlans.map((plan) => {
            const isCurrent = plan.id === activeStore.plan;

            return (
              <div
                key={plan.id}
                className={`p-6 rounded-3xl border-2 transition-all flex flex-col justify-between relative ${
                  plan.popular
                    ? 'border-emerald-500 bg-emerald-50/20 shadow-md shadow-emerald-500/10'
                    : isCurrent
                      ? 'border-slate-800 bg-slate-50/50'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-emerald-600 text-white font-black text-[10px] uppercase tracking-wider shadow">
                    {isBn ? 'সর্বাধিক জনপ্রিয়' : 'Recommended'}
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="font-extrabold text-base text-slate-900">
                      {isBn ? plan.nameBn : plan.name}
                    </h3>
                    {isCurrent && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900 text-white">
                        {isBn ? 'বর্তমান প্ল্যান' : 'Current'}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-500 mt-1 min-h-[32px]">
                    {isBn ? plan.taglineBn : plan.tagline}
                  </p>

                  <div className="mt-4 flex items-baseline gap-1.5">
                    <span className="text-3xl font-black text-slate-900">
                      ৳{plan.priceMonthly.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">
                      /{plan.priceMonthly === 0 ? (isBn ? '১ মাস ফ্রি' : '1 Mo Free') : (isBn ? 'মাস' : 'month')}
                    </span>
                  </div>

                  {plan.id === 'growth' && (
                    <div className="mt-2 p-2 rounded-xl bg-emerald-100/70 border border-emerald-200 text-[11px] font-bold text-emerald-900 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                      <span>{isBn ? 'সাপোর্ট: সকাল ৯:০০ টা - রাত ১১:০০ টা' : 'Live Support: 9:00 AM - 11:00 PM'}</span>
                    </div>
                  )}

                  <ul className="mt-5 space-y-2.5 text-xs text-slate-700">
                    {(isBn ? plan.featuresBn : plan.features).map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span className={idx < 3 ? 'font-semibold text-slate-900' : ''}>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100">
                  <button
                    disabled={isCurrent}
                    onClick={() => handleSelectPlan(plan)}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all ${
                      isCurrent
                        ? 'bg-slate-200 text-slate-500 cursor-default'
                        : plan.popular
                          ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md hover:shadow-lg'
                          : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    {isCurrent 
                      ? (isBn ? '✓ আপনার সক্রিয় প্ল্যান' : '✓ Active Tier') 
                      : (isBn ? `এই প্ল্যানে স্যুইচ করুন` : `Select Plan`)}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Invoice History */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          {isBn ? 'বিলিং ও ইনভয়েস ইতিহাস' : 'Recent Invoices & Receipts'}
        </h2>
        <div className="divide-y divide-slate-100 text-xs">
          {recentInvoices.map((inv) => (
            <div key={inv.id} className="py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileText className="w-4 h-4 text-emerald-600" />
                <div>
                  <div className="font-bold text-slate-900 flex items-center gap-2">
                    <span>{inv.id}</span>
                    <span className="text-[10px] font-mono text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                      {inv.trxId}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500">{inv.date} • {inv.title}</div>
                </div>
              </div>
              <button 
                onClick={() => alert(isBn ? `ইনভয়েস ${inv.id} (Trx: ${inv.trxId}) সফলভাবে ডাউনলোড হয়েছে।` : `Invoice ${inv.id} downloaded successfully.`)}
                className="flex items-center gap-1 text-slate-600 hover:text-slate-900 font-semibold"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PDF</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Plan Checkout Modal with AamarPay, Shohoz Pay, and ShurjoPay */}
      {selectedPlanForCheckout && (
        <PlanCheckoutModal
          isOpen={!!selectedPlanForCheckout}
          onClose={() => setSelectedPlanForCheckout(null)}
          language={language}
          plan={selectedPlanForCheckout}
          store={activeStore}
          gateways={gateways}
          billingCycle="monthly"
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
};

