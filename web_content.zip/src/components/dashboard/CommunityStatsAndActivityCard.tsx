import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Crown, 
  Smartphone, 
  Sparkles, 
  ArrowUpRight, 
  CheckCircle2, 
  TrendingUp, 
  ShieldCheck, 
  Search, 
  Filter, 
  X, 
  ChevronRight, 
  Flame, 
  Coins, 
  Zap, 
  ExternalLink,
  Award
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { User, MembershipTier } from '../../types';

interface CommunityStatsAndActivityCardProps {
  onOpenMembership: () => void;
  onOpenTasks: () => void;
  onOpenVipTasks: () => void;
}

interface ActivityEvent {
  id: string;
  name: string;
  username: string;
  avatar: string;
  type: 'vip_buy' | 'app_used' | 'cashout' | 'streak';
  tier?: MembershipTier;
  appName?: string;
  rewardCoins?: number;
  cashInr?: number;
  timeAgo: string;
  isNew?: boolean;
}

const SEED_ACTIVITIES: ActivityEvent[] = [
  {
    id: 'act-1',
    name: 'Karan Patel',
    username: '@karan_pro',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    type: 'vip_buy',
    tier: 'vip4',
    cashInr: 999,
    timeAgo: 'Just now',
    isNew: true,
  },
  {
    id: 'act-2',
    name: 'Sneha Roy',
    username: '@sneha_cash',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    type: 'app_used',
    appName: 'Binance Crypto Task',
    rewardCoins: 450,
    timeAgo: '12s ago',
  },
  {
    id: 'act-3',
    name: 'Arjun Nair',
    username: '@arjun_nair',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    type: 'vip_buy',
    tier: 'vip3',
    cashInr: 499,
    timeAgo: '35s ago',
  },
  {
    id: 'act-4',
    name: 'Ananya Sharma',
    username: '@ananya9',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    type: 'vip_buy',
    tier: 'vip4',
    cashInr: 999,
    timeAgo: '1m ago',
  },
  {
    id: 'act-5',
    name: 'Rohit Das',
    username: '@rohit_earner',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    type: 'app_used',
    appName: 'ChatGPT AI Task App',
    rewardCoins: 280,
    timeAgo: '2m ago',
  },
  {
    id: 'act-6',
    name: 'Ritu Banerjee',
    username: '@ritu_b',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    type: 'vip_buy',
    tier: 'vip4',
    cashInr: 999,
    timeAgo: '2m ago',
  },
  {
    id: 'act-7',
    name: 'Rahul Sharma',
    username: '@rahul_earns',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150',
    type: 'app_used',
    appName: 'WinZO Gaming Tournament',
    rewardCoins: 350,
    timeAgo: '3m ago',
  },
  {
    id: 'act-8',
    name: 'Vikram Singh',
    username: '@vikram_king',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
    type: 'cashout',
    cashInr: 1500,
    timeAgo: '4m ago',
  },
  {
    id: 'act-9',
    name: 'Puja Sen',
    username: '@puja_sen',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    type: 'vip_buy',
    tier: 'vip2',
    cashInr: 199,
    timeAgo: '5m ago',
  },
  {
    id: 'act-10',
    name: 'Priya Mukherjee',
    username: '@priya_vip',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    type: 'app_used',
    appName: 'Telegram Community Channel',
    rewardCoins: 150,
    timeAgo: '6m ago',
  },
];

const POOL_NAMES = [
  { name: 'Abhishek Roy', username: '@abhishek_r', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150' },
  { name: 'Megha Sharma', username: '@megha_s', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150' },
  { name: 'Manish Verma', username: '@manish_v', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150' },
  { name: 'Sonia Gupta', username: '@sonia_g', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150' },
  { name: 'Tanmay Ghosh', username: '@tanmay_g', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150' },
  { name: 'Preeti Jain', username: '@preeti_j', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150' },
  { name: 'Deepak Mishra', username: '@deepak_m', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150' },
  { name: 'Sandip Mondal', username: '@sandip_m', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150' },
  { name: 'Kavita Chawla', username: '@kavita_c', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150' },
  { name: 'Rajiv Malhotra', username: '@rajiv_m', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
];

const POOL_APPS = [
  'Binance Crypto App (+450 Coins)',
  'WinZO Cash Game (+350 Coins)',
  'ChatGPT AI Task (+280 Coins)',
  'Telegram Reward Bot (+150 Coins)',
  'Angel One Demat (+500 Coins)',
  'PhonePe UPI Task (+200 Coins)',
  'Instagram Follow Task (+120 Coins)',
  'KuCoin Trading Task (+400 Coins)',
];

export const CommunityStatsAndActivityCard: React.FC<CommunityStatsAndActivityCardProps> = ({
  onOpenMembership,
  onOpenTasks,
  onOpenVipTasks,
}) => {
  const { allUsers, membershipPlans } = useApp();
  const [filterType, setFilterType] = useState<'all' | 'vip' | 'apps' | 'cashout'>('all');
  const [activities, setActivities] = useState<ActivityEvent[]>(SEED_ACTIVITIES);
  const [isExploreModalOpen, setIsExploreModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [modalTierFilter, setModalTierFilter] = useState<string>('all');

  // Dynamic real-time event generator simulation (generates realistic live activity every 4s)
  useEffect(() => {
    const interval = setInterval(() => {
      const randomPerson = POOL_NAMES[Math.floor(Math.random() * POOL_NAMES.length)];
      const isVip = Math.random() > 0.45;

      let newEvent: ActivityEvent;
      if (isVip) {
        const tiers: MembershipTier[] = ['vip2', 'vip3', 'vip4', 'vip1'];
        const randomTier = tiers[Math.floor(Math.random() * tiers.length)];
        const prices: Record<string, number> = { vip1: 99, vip2: 199, vip3: 499, vip4: 999 };
        newEvent = {
          id: `act-${Date.now()}`,
          name: randomPerson.name,
          username: randomPerson.username,
          avatar: randomPerson.avatar,
          type: 'vip_buy',
          tier: randomTier,
          cashInr: prices[randomTier] || 499,
          timeAgo: 'Just now',
          isNew: true,
        };
      } else {
        const randomApp = POOL_APPS[Math.floor(Math.random() * POOL_APPS.length)];
        newEvent = {
          id: `act-${Date.now()}`,
          name: randomPerson.name,
          username: randomPerson.username,
          avatar: randomPerson.avatar,
          type: 'app_used',
          appName: randomApp,
          rewardCoins: Math.floor(150 + Math.random() * 350),
          timeAgo: 'Just now',
          isNew: true,
        };
      }

      setActivities((prev) => [newEvent, ...prev.slice(0, 14)]);
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  const filteredActivities = useMemo(() => {
    if (filterType === 'vip') {
      return activities.filter((a) => a.type === 'vip_buy');
    }
    if (filterType === 'apps') {
      return activities.filter((a) => a.type === 'app_used');
    }
    if (filterType === 'cashout') {
      return activities.filter((a) => a.type === 'cashout');
    }
    return activities;
  }, [activities, filterType]);

  // Combined rich user list for directory exploration
  const exploreUsersList = useMemo(() => {
    // Generate an extended realistic list of active community earners
    const baseList: Array<{
      id: string;
      name: string;
      username: string;
      avatar: string;
      tier: MembershipTier;
      coins: number;
      lifetimeCoins: number;
      appsUsedCount: number;
      recentApp: string;
      joinedDate: string;
    }> = [
      { id: '1', name: 'Karan Patel', username: '@karan_pro', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', tier: 'vip4', coins: 14850, lifetimeCoins: 28900, appsUsedCount: 42, recentApp: 'Binance Crypto Task', joinedDate: 'Aug 2026' },
      { id: '2', name: 'Ananya Sharma', username: '@ananya9', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', tier: 'vip4', coins: 12450, lifetimeCoins: 24500, appsUsedCount: 38, recentApp: 'ChatGPT AI Task', joinedDate: 'Jul 2026' },
      { id: '3', name: 'Arjun Nair', username: '@arjun_nair', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', tier: 'vip3', coins: 9800, lifetimeCoins: 19800, appsUsedCount: 35, recentApp: 'WinZO Gaming App', joinedDate: 'Aug 2026' },
      { id: '4', name: 'Sneha Roy', username: '@sneha_cash', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', tier: 'vip3', coins: 8900, lifetimeCoins: 17500, appsUsedCount: 29, recentApp: 'Angel One Demat', joinedDate: 'Aug 2026' },
      { id: '5', name: 'Vikram Singh', username: '@vikram_king', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150', tier: 'vip4', coins: 8200, lifetimeCoins: 16400, appsUsedCount: 31, recentApp: 'KuCoin Trading Task', joinedDate: 'Aug 2026' },
      { id: '6', name: 'Rohit Das', username: '@rohit_earner', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', tier: 'vip2', coins: 6500, lifetimeCoins: 12900, appsUsedCount: 24, recentApp: 'Telegram Reward Bot', joinedDate: 'Sep 2026' },
      { id: '7', name: 'Puja Sen', username: '@puja_sen', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', tier: 'vip2', coins: 5900, lifetimeCoins: 11400, appsUsedCount: 22, recentApp: 'PhonePe UPI Task', joinedDate: 'Sep 2026' },
      { id: '8', name: 'Ritu Banerjee', username: '@ritu_b', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', tier: 'vip4', coins: 7800, lifetimeCoins: 15200, appsUsedCount: 28, recentApp: 'Binance Crypto Task', joinedDate: 'Aug 2026' },
      { id: '9', name: 'Abhishek Roy', username: '@abhishek_r', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150', tier: 'vip2', coins: 5200, lifetimeCoins: 9800, appsUsedCount: 19, recentApp: 'ChatGPT Pro Task', joinedDate: 'Sep 2026' },
      { id: '10', name: 'Rahul Sharma', username: '@rahul_earns', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150', tier: 'vip2', coins: 4950, lifetimeCoins: 9200, appsUsedCount: 18, recentApp: 'WinZO Tournaments', joinedDate: 'Aug 2026' },
      { id: '11', name: 'Priya Mukherjee', username: '@priya_vip', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', tier: 'vip2', coins: 4600, lifetimeCoins: 8600, appsUsedCount: 19, recentApp: 'Telegram Channel', joinedDate: 'Aug 2026' },
      { id: '12', name: 'Manish Verma', username: '@manish_v', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', tier: 'vip3', coins: 6800, lifetimeCoins: 13400, appsUsedCount: 26, recentApp: 'Angel One Demat', joinedDate: 'Aug 2026' },
      { id: '13', name: 'Megha Sharma', username: '@megha_s', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', tier: 'vip3', coins: 6400, lifetimeCoins: 12800, appsUsedCount: 25, recentApp: 'Instagram Task', joinedDate: 'Sep 2026' },
      { id: '14', name: 'Sonia Gupta', username: '@sonia_g', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', tier: 'vip1', coins: 3400, lifetimeCoins: 6500, appsUsedCount: 15, recentApp: 'KuCoin Task', joinedDate: 'Sep 2026' },
      { id: '15', name: 'Tanmay Ghosh', username: '@tanmay_g', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', tier: 'vip2', coins: 4100, lifetimeCoins: 7800, appsUsedCount: 16, recentApp: 'Binance App', joinedDate: 'Sep 2026' },
      { id: '16', name: 'Siddharth Roy', username: '@siddharth_r', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', tier: 'basic', coins: 2850, lifetimeCoins: 5600, appsUsedCount: 14, recentApp: 'Daily Check-in & Tasks', joinedDate: 'Sep 2026' },
      { id: '17', name: 'Preeti Jain', username: '@preeti_j', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', tier: 'vip2', coins: 4500, lifetimeCoins: 8900, appsUsedCount: 18, recentApp: 'WinZO Gaming', joinedDate: 'Sep 2026' },
      { id: '18', name: 'David Koenig', username: '@david_k', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150', tier: 'vip1', coins: 3200, lifetimeCoins: 6100, appsUsedCount: 13, recentApp: 'Telegram Task', joinedDate: 'Sep 2026' },
      { id: '19', name: 'Deepak Mishra', username: '@deepak_m', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150', tier: 'vip1', coins: 2900, lifetimeCoins: 5800, appsUsedCount: 12, recentApp: 'PhonePe Task', joinedDate: 'Sep 2026' },
      { id: '20', name: 'Sandip Mondal', username: '@sandip_m', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150', tier: 'vip1', coins: 2800, lifetimeCoins: 5400, appsUsedCount: 11, recentApp: 'ChatGPT Task', joinedDate: 'Sep 2026' },
    ];

    return baseList.filter((user) => {
      // Search filter
      const matchesSearch = 
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.recentApp.toLowerCase().includes(searchQuery.toLowerCase());

      // Tier filter
      if (modalTierFilter === 'vip_all') {
        return matchesSearch && user.tier !== 'basic';
      }
      if (modalTierFilter !== 'all') {
        return matchesSearch && user.tier === modalTierFilter;
      }
      return matchesSearch;
    });
  }, [searchQuery, modalTierFilter]);

  const getTierBadge = (tier?: MembershipTier) => {
    switch (tier) {
      case 'vip4':
      case 'pro':
        return { label: 'VIP Diamond', color: 'bg-amber-500/20 text-amber-300 border-amber-500/40' };
      case 'vip3':
      case 'premium':
        return { label: 'VIP Gold', color: 'bg-purple-500/20 text-purple-300 border-purple-500/40' };
      case 'vip2':
        return { label: 'VIP Silver', color: 'bg-sky-500/20 text-sky-300 border-sky-500/40' };
      case 'vip1':
        return { label: 'VIP Bronze', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' };
      default:
        return { label: 'Member', color: 'bg-slate-800 text-slate-300 border-slate-700' };
    }
  };

  return (
    <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-slate-800 shadow-xl overflow-hidden space-y-2.5 sm:space-y-4 p-2.5 sm:p-4 md:p-5 relative">
      
      {/* Decorative ambient background accents */}
      <div className="absolute top-0 right-10 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* TOP HEADER: Community & Live Status */}
      <div className="flex items-center justify-between gap-2 relative z-10">
        <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20 shrink-0">
            <Crown className="w-4 h-4 sm:w-5 sm:h-5 fill-current" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
              <h3 className="text-[11px] sm:text-base font-black text-white tracking-tight">
                Live Community & VIP Club
              </h3>
              <span className="px-1.5 sm:px-2 py-0.2 sm:py-0.5 rounded-full text-[7px] sm:text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span>3,420 Online</span>
              </span>
            </div>
            <p className="text-[9px] sm:text-[11px] text-slate-400 truncate">
              Real-time activity of verified earners & VIP upgrades
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsExploreModalOpen(true)}
          className="min-h-[44px] px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 transition-all border border-slate-700/80 hover:border-slate-600 shadow-sm cursor-pointer shrink-0"
        >
          <span>Explore</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>

      {/* FOUR OFFICIAL METRICS: 20,000+ Users & 10,000+ VIP Buyers */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 sm:gap-2.5 relative z-10">
        
        {/* Stat 1: 20,000+ Total Users */}
        <div className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-slate-950/70 border border-slate-800/90 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[8px] sm:text-[10px] font-bold uppercase tracking-wider">Total Users</span>
            <Users className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 text-sky-400" />
          </div>
          <div className="space-y-0.5">
            <div className="text-sm sm:text-lg font-black text-white tracking-tight">
              24,850<span className="text-sky-400">+</span>
            </div>
            <div className="text-[8px] sm:text-[10px] font-semibold text-emerald-400 flex items-center gap-0.5 sm:gap-1">
              <TrendingUp className="w-2 h-2 sm:w-2.5 sm:h-2.5" />
              <span>20,000+ Active</span>
            </div>
          </div>
        </div>

        {/* Stat 2: 10,000+ VIP Buyers */}
        <div 
          onClick={onOpenMembership}
          className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-gradient-to-br from-amber-950/30 via-slate-950/70 to-slate-950/80 border border-amber-600/30 hover:border-amber-500/60 transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-amber-300/80 mb-0.5">
            <span className="text-[8px] sm:text-[10px] font-bold uppercase tracking-wider">VIP Bought</span>
            <Crown className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="space-y-0.5">
            <div className="text-sm sm:text-lg font-black text-white tracking-tight group-hover:text-amber-200 transition-colors">
              11,240<span className="text-amber-400">+</span>
            </div>
            <div className="text-[8px] sm:text-[10px] font-semibold text-amber-400 flex items-center gap-0.5 sm:gap-1">
              <Sparkles className="w-2 h-2 sm:w-2.5 sm:h-2.5" />
              <span>10,000+ VIP Club</span>
            </div>
          </div>
        </div>

        {/* Stat 3: 100,000+ Apps Used */}
        <div 
          onClick={onOpenTasks}
          className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-slate-950/70 border border-slate-800/90 hover:border-purple-600/40 transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[8px] sm:text-[10px] font-bold uppercase tracking-wider">Apps Used</span>
            <Smartphone className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 text-purple-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="space-y-0.5">
            <div className="text-sm sm:text-lg font-black text-white tracking-tight">
              100,000<span className="text-purple-400">+</span>
            </div>
            <div className="text-[8px] sm:text-[10px] font-semibold text-purple-400">
              Apps Catalog Pool
            </div>
          </div>
        </div>

        {/* Stat 4: Total Cash Distributed */}
        <div className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-slate-950/70 border border-slate-800/90 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-0.5">
            <span className="text-[8px] sm:text-[10px] font-bold uppercase tracking-wider">Distributed</span>
            <Coins className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 text-emerald-400" />
          </div>
          <div className="space-y-0.5">
            <div className="text-sm sm:text-lg font-black text-white tracking-tight">
              ₹18.5<span className="text-emerald-400">L+</span>
            </div>
            <div className="text-[8px] sm:text-[10px] font-semibold text-emerald-400">
              Instant UPI Payouts
            </div>
          </div>
        </div>

      </div>

      {/* FILTER TABS FOR LIVE ACTIVITY STREAM */}
      <div className="flex items-center justify-between gap-1.5 sm:gap-2 pt-1 border-t border-slate-800/80">
        <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[9px] sm:text-[11px] font-bold">
          <button
            type="button"
            onClick={() => setFilterType('all')}
            className={`min-h-[40px] px-2 sm:px-3 py-1.5 rounded-xl transition-all cursor-pointer shrink-0 flex items-center justify-center ${
              filterType === 'all'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            🔥 All Feeds
          </button>

          <button
            type="button"
            onClick={() => setFilterType('vip')}
            className={`min-h-[40px] px-2 sm:px-3 py-1.5 rounded-xl transition-all cursor-pointer shrink-0 flex items-center justify-center gap-1 ${
              filterType === 'vip'
                ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20 font-black'
                : 'bg-slate-800/80 text-amber-300/80 hover:text-amber-200'
            }`}
          >
            <Crown className="w-3 h-3" />
            <span>VIP (10k+)</span>
          </button>

          <button
            type="button"
            onClick={() => setFilterType('apps')}
            className={`min-h-[40px] px-2 sm:px-3 py-1.5 rounded-xl transition-all cursor-pointer shrink-0 flex items-center justify-center gap-1 ${
              filterType === 'apps'
                ? 'bg-purple-500 text-white shadow-md shadow-purple-500/20 font-black'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            <span>Apps (20k+)</span>
          </button>

          <button
            type="button"
            onClick={() => setFilterType('cashout')}
            className={`min-h-[40px] px-2 sm:px-3 py-1.5 rounded-xl transition-all cursor-pointer shrink-0 flex items-center justify-center ${
              filterType === 'cashout'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20 font-black'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            💸 Payouts
          </button>
        </div>

        <span className="text-[9px] sm:text-[10px] text-slate-500 font-medium shrink-0 hidden sm:inline">
          Auto-updating
        </span>
      </div>

      {/* LIVE SCROLLING ACTIVITY FEED WITH USERNAMES, NAMES & USED APPS / VIP BUYS */}
      <div className="space-y-1.5 max-h-60 sm:max-h-64 overflow-y-auto pr-1">
        {filteredActivities.slice(0, 6).map((item) => {
          const tierInfo = item.tier ? getTierBadge(item.tier) : null;

          return (
            <div
              key={item.id}
              className={`p-1.5 sm:p-2.5 rounded-xl sm:rounded-2xl border transition-all flex items-center justify-between gap-1.5 sm:gap-3 ${
                item.isNew
                  ? 'bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border-amber-500/50 shadow-md shadow-amber-500/5 animate-in slide-in-from-top-2 duration-300'
                  : 'bg-slate-950/60 hover:bg-slate-850 border-slate-800/70'
              }`}
            >
              {/* Left: Avatar + Names */}
              <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0">
                <div className="relative shrink-0">
                  <img
                    src={item.avatar}
                    alt={item.name}
                    className="w-7 h-7 sm:w-9 sm:h-9 rounded-full object-cover ring-2 ring-slate-800"
                    loading="lazy"
                  />
                  {item.type === 'vip_buy' && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black text-[7px] sm:text-[8px] shadow-sm">
                      <Crown className="w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 fill-current" />
                    </div>
                  )}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
                    <span className="text-[10px] sm:text-xs font-black text-white truncate">
                      {item.name}
                    </span>
                    <span className="text-[9px] sm:text-[11px] font-semibold text-amber-400 truncate">
                      {item.username}
                    </span>
                  </div>

                  {/* Activity detail line */}
                  <div className="text-[9px] sm:text-[11px] text-slate-300 truncate flex items-center gap-1">
                    {item.type === 'vip_buy' && (
                      <span className="flex items-center gap-1">
                        <span className="text-amber-300 font-bold">Bought {tierInfo?.label}</span>
                        <span className="text-[8px] sm:text-[10px] text-slate-400">(₹{item.cashInr})</span>
                      </span>
                    )}

                    {item.type === 'app_used' && (
                      <span className="flex items-center gap-1 text-slate-300 truncate">
                        <span>Used</span>
                        <span className="text-purple-300 font-bold truncate">{item.appName}</span>
                        <span className="text-emerald-400 font-black shrink-0">+{item.rewardCoins}C</span>
                      </span>
                    )}

                    {item.type === 'cashout' && (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <span>Withdrew</span>
                        <span className="font-black text-white">₹{item.cashInr}</span>
                        <span>via UPI</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Right: Badge & Time */}
              <div className="text-right shrink-0">
                {item.type === 'vip_buy' ? (
                  <span className={`px-1.5 sm:px-2 py-0.2 rounded-full text-[8px] sm:text-[10px] font-bold border ${tierInfo?.color}`}>
                    {tierInfo?.label}
                  </span>
                ) : item.type === 'app_used' ? (
                  <span className="px-1.5 sm:px-2 py-0.2 rounded-full text-[8px] sm:text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    App Task
                  </span>
                ) : (
                  <span className="px-1.5 sm:px-2 py-0.2 rounded-full text-[8px] sm:text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    Payout
                  </span>
                )}
                <div className="text-[8px] sm:text-[10px] text-slate-500 mt-0.5 font-medium">
                  {item.timeAgo}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* FOOTER CALL TO ACTION BUTTONS - MIN 44PX TOUCH TARGETS */}
      <div className="grid grid-cols-2 gap-1.5 sm:gap-2 pt-1 border-t border-slate-800/80">
        <button
          type="button"
          onClick={onOpenMembership}
          className="min-h-[44px] py-2 sm:py-2.5 px-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-[10px] sm:text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer active:scale-95"
        >
          <Crown className="w-3.5 h-3.5 fill-current shrink-0" />
          <span>Join VIP (10k+)</span>
        </button>

        <button
          type="button"
          onClick={() => setIsExploreModalOpen(true)}
          className="min-h-[44px] py-2 sm:py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700/80 text-slate-200 font-bold text-[10px] sm:text-xs flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer active:scale-95"
        >
          <Users className="w-3.5 h-3.5 text-sky-400 shrink-0" />
          <span>View 20k+ Users</span>
        </button>
      </div>

      {/* FULL DIRECTORY MODAL: EXPLORE 20,000+ USERS & 10,000+ VIP MEMBERS */}
      {isExploreModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div 
            className="w-full max-w-xl max-h-[85vh] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-black">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>Community & VIP Directory</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                      24,850+ Users
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Search active earners, VIP pass holders & app users
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsExploreModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Search & Filter Toolbar */}
            <div className="p-3 sm:p-4 bg-slate-950/40 border-b border-slate-800/80 space-y-2.5">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by name, @username, or used app..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/80"
                />
              </div>

              {/* Tier Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                <button
                  type="button"
                  onClick={() => setModalTierFilter('all')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    modalTierFilter === 'all'
                      ? 'bg-white text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  All Users (20,000+)
                </button>

                <button
                  type="button"
                  onClick={() => setModalTierFilter('vip_all')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                    modalTierFilter === 'vip_all'
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-slate-800 text-amber-300 hover:text-amber-200'
                  }`}
                >
                  <Crown className="w-3 h-3" />
                  <span>VIP Members (10,000+)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setModalTierFilter('vip4')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    modalTierFilter === 'vip4'
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Diamond (VIP 4)
                </button>

                <button
                  type="button"
                  onClick={() => setModalTierFilter('vip3')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    modalTierFilter === 'vip3'
                      ? 'bg-purple-500 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Gold (VIP 3)
                </button>

                <button
                  type="button"
                  onClick={() => setModalTierFilter('vip2')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    modalTierFilter === 'vip2'
                      ? 'bg-sky-500 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Silver (VIP 2)
                </button>
              </div>
            </div>

            {/* Modal Users List */}
            <div className="p-3 sm:p-4 overflow-y-auto space-y-2.5 flex-1">
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 font-semibold">
                <span>Showing {exploreUsersList.length} Verified Community Members</span>
                <span className="text-amber-400">10,000+ VIPs Active</span>
              </div>

              {exploreUsersList.map((user, idx) => {
                const tierInfo = getTierBadge(user.tier);

                return (
                  <div
                    key={user.id}
                    className="p-3 rounded-2xl bg-slate-950/60 hover:bg-slate-850 border border-slate-800/80 transition-all flex items-center justify-between gap-3"
                  >
                    {/* User Profile */}
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative shrink-0">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-800"
                          loading="lazy"
                        />
                        {user.tier !== 'basic' && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black text-[9px] shadow-sm">
                            <Crown className="w-2.5 h-2.5 fill-current" />
                          </div>
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-black text-white truncate">
                            {user.name}
                          </span>
                          <span className="text-[11px] font-semibold text-amber-400 truncate">
                            {user.username}
                          </span>
                          <span className={`px-2 py-0.2 rounded-full text-[9px] font-bold border ${tierInfo.color}`}>
                            {tierInfo.label}
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-400 mt-0.5 truncate flex items-center gap-2">
                          <span className="text-purple-300 font-medium">
                            📲 {user.appsUsedCount} Apps Used
                          </span>
                          <span>•</span>
                          <span className="truncate">{user.recentApp}</span>
                        </div>
                      </div>
                    </div>

                    {/* Earnings & Rank */}
                    <div className="text-right shrink-0">
                      <div className="text-xs font-black text-white">
                        {user.coins.toLocaleString()} <span className="text-amber-400 text-[10px]">Coins</span>
                      </div>
                      <div className="text-[10px] text-emerald-400 font-semibold">
                        ₹{(user.coins / 100).toFixed(0)} INR
                      </div>
                      <div className="text-[9px] text-slate-500 font-medium">
                        Joined {user.joinedDate}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Modal Bottom CTA */}
            <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
              <div className="text-xs text-slate-400 hidden sm:block">
                Upgrade your account to get featured on the VIP Leaderboard
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsExploreModalOpen(false);
                  onOpenMembership();
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 cursor-pointer"
              >
                👑 Buy VIP Membership (from ₹99)
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
