import React, { useState, useEffect, useMemo } from 'react';
import { 
  CreditCard, 
  Clock, 
  CheckCircle2, 
  Search, 
  X, 
  ChevronRight, 
  Smartphone, 
  Building2, 
  TrendingDown, 
  Coins, 
  ShieldCheck, 
  Award, 
  Zap, 
  AlertCircle,
  Copy,
  Check
} from 'lucide-react';

interface WithdrawalDailyHistoryCardProps {
  onOpenWallet: () => void;
}

interface LiveWithdrawal {
  id: string;
  name: string;
  username: string;
  avatar: string;
  amountCoins: number;
  amountInr: number;
  method: 'upi' | 'paytm' | 'phonepe' | 'gpay' | 'bank_transfer';
  accountMasked: string;
  utrRef: string;
  timeAgo: string;
  isNew?: boolean;
}

const SEED_WITHDRAWALS: LiveWithdrawal[] = [
  {
    id: 'w-1',
    name: 'Amit Kumar',
    username: '@amit_kumar',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150',
    amountCoins: 50000,
    amountInr: 500,
    method: 'upi',
    accountMasked: 'amit***@oksbi',
    utrRef: '628905182937',
    timeAgo: 'Just now',
    isNew: true,
  },
  {
    id: 'w-2',
    name: 'Sneha Roy',
    username: '@sneha_cash',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    amountCoins: 100000,
    amountInr: 1000,
    method: 'paytm',
    accountMasked: '98765***10@paytm',
    utrRef: '628902123984',
    timeAgo: '14s ago',
  },
  {
    id: 'w-3',
    name: 'Rohit Das',
    username: '@rohit_earner',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    amountCoins: 25000,
    amountInr: 250,
    method: 'phonepe',
    accountMasked: 'rohit***@ybl',
    utrRef: '628904128392',
    timeAgo: '38s ago',
  },
  {
    id: 'w-4',
    name: 'Priya Mukherjee',
    username: '@priya_vip',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    amountCoins: 200000,
    amountInr: 2000,
    method: 'bank_transfer',
    accountMasked: 'HDFC •••• 8293',
    utrRef: '628901129384',
    timeAgo: '1m ago',
  },
  {
    id: 'w-5',
    name: 'Karan Patel',
    username: '@karan_pro',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    amountCoins: 500000,
    amountInr: 5000,
    method: 'upi',
    accountMasked: 'karan***@okaxis',
    utrRef: '628903102938',
    timeAgo: '2m ago',
  },
  {
    id: 'w-6',
    name: 'Ananya Sharma',
    username: '@ananya9',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    amountCoins: 100000,
    amountInr: 1000,
    method: 'gpay',
    accountMasked: 'ananya***@okaxis',
    utrRef: '628905293847',
    timeAgo: '3m ago',
  },
  {
    id: 'w-7',
    name: 'Vikram Singh',
    username: '@vikram_king',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    amountCoins: 150000,
    amountInr: 1500,
    method: 'phonepe',
    accountMasked: 'vikram***@ybl',
    utrRef: '628901928374',
    timeAgo: '5m ago',
  },
  {
    id: 'w-8',
    name: 'Sonia Gupta',
    username: '@sonia_g',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    amountCoins: 10000,
    amountInr: 100,
    method: 'upi',
    accountMasked: 'sonia***@okicici',
    utrRef: '628904293817',
    timeAgo: '7m ago',
  },
  {
    id: 'w-9',
    name: 'Abhishek Roy',
    username: '@abhishek_r',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
    amountCoins: 50000,
    amountInr: 500,
    method: 'paytm',
    accountMasked: '70034***12@paytm',
    utrRef: '628905128394',
    timeAgo: '9m ago',
  },
  {
    id: 'w-10',
    name: 'Siddharth Roy',
    username: '@siddharth_r',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    amountCoins: 1000000,
    amountInr: 1000,
    method: 'upi',
    accountMasked: 'siddharth***@oksbi',
    utrRef: '628903102931',
    timeAgo: '12m ago',
  },
];

const POOL_NAMES = [
  { name: 'Megha Sharma', username: '@megha_s', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150' },
  { name: 'Manish Verma', username: '@manish_v', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150' },
  { name: 'Tanmay Ghosh', username: '@tanmay_g', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150' },
  { name: 'Preeti Jain', username: '@preeti_j', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150' },
  { name: 'Deepak Mishra', username: '@deepak_m', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150' },
  { name: 'Sandip Mondal', username: '@sandip_m', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150' },
  { name: 'Kavita Chawla', username: '@kavita_c', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150' },
  { name: 'Rajiv Malhotra', username: '@rajiv_m', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
];

const POOL_METHODS: ('upi' | 'paytm' | 'phonepe' | 'gpay' | 'bank_transfer')[] = ['upi', 'paytm', 'phonepe', 'gpay', 'bank_transfer'];
const POOL_HANDLES: Record<string, string[]> = {
  upi: ['oksbi', 'okaxis', 'okicici', 'okhdfcbank'],
  paytm: ['paytm'],
  phonepe: ['ybl', 'ibl'],
  gpay: ['okaxis', 'oksbi'],
  bank_transfer: ['SBI', 'HDFC', 'ICICI', 'PNB'],
};

export const WithdrawalDailyHistoryCard: React.FC<WithdrawalDailyHistoryCardProps> = ({
  onOpenWallet,
}) => {
  const [liveWithdrawals, setLiveWithdrawals] = useState<LiveWithdrawal[]>(SEED_WITHDRAWALS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedUtr, setCopiedUtr] = useState<string | null>(null);
  const [methodFilter, setMethodFilter] = useState<string>('all');

  // Live real-time withdrawal event additions simulation (every 5 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      const person = POOL_NAMES[Math.floor(Math.random() * POOL_NAMES.length)];
      const method = POOL_METHODS[Math.floor(Math.random() * POOL_METHODS.length)];
      
      const coinsList = [10000, 25000, 50000, 100000, 150000, 200000, 500000];
      const coins = coinsList[Math.floor(Math.random() * coinsList.length)];
      const inr = coins / 100;

      let accountMasked = '';
      if (method === 'bank_transfer') {
        const banks = POOL_HANDLES[method];
        accountMasked = `${banks[Math.floor(Math.random() * banks.length)]} •••• ${Math.floor(1000 + Math.random() * 9000)}`;
      } else {
        const handles = POOL_HANDLES[method];
        accountMasked = `${person.username.substring(1, 6)}***@${handles[Math.floor(Math.random() * handles.length)]}`;
      }

      const newWithdrawal: LiveWithdrawal = {
        id: `w-${Date.now()}`,
        name: person.name,
        username: person.username,
        avatar: person.avatar,
        amountCoins: coins,
        amountInr: inr,
        method,
        accountMasked,
        utrRef: `6289${Math.floor(10000000 + Math.random() * 90000000)}`,
        timeAgo: 'Just now',
        isNew: true,
      };

      setLiveWithdrawals((prev) => [newWithdrawal, ...prev.slice(0, 14)]);
    }, 5500);

    return () => clearInterval(interval);
  }, []);

  const handleCopyUtr = (utr: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(utr);
    setCopiedUtr(utr);
    setTimeout(() => setCopiedUtr(null), 2000);
  };

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'upi':
      case 'phonepe':
      case 'gpay':
        return <Smartphone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      case 'paytm':
        return <Smartphone className="w-3.5 h-3.5 text-sky-400 shrink-0" />;
      case 'bank_transfer':
        return <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      default:
        return <CreditCard className="w-3.5 h-3.5 text-purple-400 shrink-0" />;
    }
  };

  const getMethodLabel = (method: string) => {
    switch (method) {
      case 'upi': return 'UPI Instant';
      case 'paytm': return 'Paytm Wallet';
      case 'phonepe': return 'PhonePe';
      case 'gpay': return 'GPay Instant';
      case 'bank_transfer': return 'Bank IMPS/NEFT';
      default: return 'Instant Trans.';
    }
  };

  // Full explore modal filter
  const exploreWithdrawalsList = useMemo(() => {
    // Generate a massive realistic pre-populated dataset of past verified cashouts
    const baseList: LiveWithdrawal[] = [
      { id: 'm-1', name: 'Amit Kumar', username: '@amit_kumar', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150', amountCoins: 50000, amountInr: 500, method: 'upi', accountMasked: 'amit***@oksbi', utrRef: '628905182937', timeAgo: 'Today' },
      { id: 'm-2', name: 'Sneha Roy', username: '@sneha_cash', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', amountCoins: 100000, amountInr: 1000, method: 'paytm', accountMasked: '98765***10@paytm', utrRef: '628902123984', timeAgo: 'Today' },
      { id: 'm-3', name: 'Rohit Das', username: '@rohit_earner', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', amountCoins: 25000, amountInr: 250, method: 'phonepe', accountMasked: 'rohit***@ybl', utrRef: '628904128392', timeAgo: 'Today' },
      { id: 'm-4', name: 'Priya Mukherjee', username: '@priya_vip', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', amountCoins: 200000, amountInr: 2000, method: 'bank_transfer', accountMasked: 'HDFC •••• 8293', utrRef: '628901129384', timeAgo: 'Today' },
      { id: 'm-5', name: 'Karan Patel', username: '@karan_pro', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', amountCoins: 500000, amountInr: 5000, method: 'upi', accountMasked: 'karan***@okaxis', utrRef: '628903102938', timeAgo: 'Today' },
      { id: 'm-6', name: 'Ananya Sharma', username: '@ananya9', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', amountCoins: 100000, amountInr: 1000, method: 'gpay', accountMasked: 'ananya***@okaxis', utrRef: '628905293847', timeAgo: 'Today' },
      { id: 'm-7', name: 'Vikram Singh', username: '@vikram_king', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', amountCoins: 150000, amountInr: 1500, method: 'phonepe', accountMasked: 'vikram***@ybl', utrRef: '628901928374', timeAgo: 'Today' },
      { id: 'm-8', name: 'Sonia Gupta', username: '@sonia_g', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', amountCoins: 10000, amountInr: 100, method: 'upi', accountMasked: 'sonia***@okicici', utrRef: '628904293817', timeAgo: 'Yesterday' },
      { id: 'm-9', name: 'Abhishek Roy', username: '@abhishek_r', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', amountCoins: 50000, amountInr: 500, method: 'paytm', accountMasked: '70034***12@paytm', utrRef: '628905128394', timeAgo: 'Yesterday' },
      { id: 'm-10', name: 'Siddharth Roy', username: '@siddharth_r', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', amountCoins: 1000000, amountInr: 1000, method: 'upi', accountMasked: 'siddharth***@oksbi', utrRef: '628903102931', timeAgo: 'Yesterday' },
      { id: 'm-11', name: 'Megha Sharma', username: '@megha_s', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', amountCoins: 250000, amountInr: 2500, method: 'gpay', accountMasked: 'megha***@okaxis', utrRef: '628904239847', timeAgo: 'Yesterday' },
      { id: 'm-12', name: 'Manish Verma', username: '@manish_v', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', amountCoins: 150000, amountInr: 1500, method: 'bank_transfer', accountMasked: 'SBI •••• 9021', utrRef: '628901239811', timeAgo: 'Yesterday' },
      { id: 'm-13', name: 'Tanmay Ghosh', username: '@tanmay_g', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', amountCoins: 50000, amountInr: 500, method: 'paytm', accountMasked: '98450***29@paytm', utrRef: '628903829487', timeAgo: 'Yesterday' },
      { id: 'm-14', name: 'Preeti Jain', username: '@preeti_j', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', amountCoins: 100000, amountInr: 1000, method: 'phonepe', accountMasked: 'preeti***@ybl', utrRef: '628901829483', timeAgo: 'Yesterday' },
      { id: 'm-15', name: 'Deepak Mishra', username: '@deepak_m', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150', amountCoins: 25000, amountInr: 250, method: 'upi', accountMasked: 'deepak***@okhdfc', utrRef: '628904829381', timeAgo: '2 days ago' },
    ];

    // Combine with current live withdrawals to be 100% up-to-date
    const combined = [...liveWithdrawals.filter(l => l.id.startsWith('w-')), ...baseList];

    return combined.filter((w) => {
      // Search filter
      const matchesSearch = 
        w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        w.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        w.utrRef.includes(searchQuery) ||
        w.accountMasked.toLowerCase().includes(searchQuery.toLowerCase());

      // Method filter
      if (methodFilter !== 'all' && w.method !== methodFilter) {
        return false;
      }

      return matchesSearch;
    });
  }, [searchQuery, methodFilter, liveWithdrawals]);

  return (
    <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-slate-800 shadow-xl overflow-hidden space-y-2.5 sm:space-y-4 p-2.5 sm:p-4 md:p-5 relative">
      
      {/* Decorative background glow elements */}
      <div className="absolute top-0 left-10 w-44 h-44 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-44 h-44 bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* HEADER SECTION WITH LIVE COUNTER */}
      <div className="flex items-center justify-between gap-2 relative z-10">
        <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-gradient-to-tr from-emerald-500 via-emerald-400 to-teal-300 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-emerald-500/20 shrink-0">
            <CreditCard className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="text-xs sm:text-base font-black text-white tracking-tight">
                Daily Withdrawal History
              </h3>
              <span className="px-1.5 sm:px-2 py-0.2 sm:py-0.5 rounded-full text-[8px] sm:text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 animate-pulse shrink-0">
                <span>10,000+ Paid Today</span>
              </span>
            </div>
            <p className="text-[9px] sm:text-[11px] text-slate-400 truncate">
              Live instant payouts verified on blockchain & banking networks
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsModalOpen(true)}
          className="min-h-[44px] px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-[10px] sm:text-[11px] font-bold flex items-center gap-1 transition-all border border-slate-700/80 hover:border-slate-600 shadow-sm cursor-pointer shrink-0"
        >
          <span>Proof Feed</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>

      {/* THREE VERIFIED METRICS BLOCK */}
      <div className="grid grid-cols-3 gap-1.5 sm:gap-2 relative z-10">
        
        <div className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-slate-950/70 border border-slate-800/90 flex flex-col justify-between">
          <span className="text-[8px] sm:text-[10px] font-bold text-slate-500 uppercase tracking-wider">Processed</span>
          <div className="text-xs sm:text-base font-black text-white tracking-tight mt-0.5 sm:mt-1">
            12,840<span className="text-emerald-400">+</span>
          </div>
          <span className="text-[8px] sm:text-[9px] text-emerald-400 font-bold mt-0.5 flex items-center gap-0.5">
            <CheckCircle2 className="w-2.5 h-2.5 fill-current" />
            <span>100% Disbursed</span>
          </span>
        </div>

        <div className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-slate-950/70 border border-slate-800/90 flex flex-col justify-between">
          <span className="text-[8px] sm:text-[10px] font-bold text-slate-500 uppercase tracking-wider">Amount Paid</span>
          <div className="text-xs sm:text-base font-black text-white tracking-tight mt-0.5 sm:mt-1">
            ₹3,18,500<span className="text-emerald-400">+</span>
          </div>
          <span className="text-[8px] sm:text-[9px] text-slate-400 font-semibold mt-0.5">
            Today's Pool Size
          </span>
        </div>

        <div className="p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-slate-950/70 border border-slate-800/90 flex flex-col justify-between">
          <span className="text-[8px] sm:text-[10px] font-bold text-slate-500 uppercase tracking-wider">Payout Speed</span>
          <div className="text-xs sm:text-base font-black text-emerald-400 tracking-tight mt-0.5 sm:mt-1">
            99.9%
          </div>
          <span className="text-[8px] sm:text-[9px] text-emerald-400/90 font-bold mt-0.5 flex items-center gap-0.5">
            <Zap className="w-2.5 h-2.5 fill-current" />
            <span>&lt; 5 Seconds</span>
          </span>
        </div>

      </div>

      {/* LIVE SCROLLING TRANSACTIONS LIST WITH BANK VERIFIED LOGO */}
      <div className="space-y-1.5 sm:space-y-2 max-h-[300px] overflow-y-auto pr-1">
        {liveWithdrawals.slice(0, 5).map((item) => (
          <div
            key={item.id}
            className={`p-2 sm:p-3 rounded-xl sm:rounded-2xl border transition-all flex items-center justify-between gap-2 sm:gap-3 ${
              item.isNew
                ? 'bg-gradient-to-r from-emerald-950/30 via-slate-900 to-slate-900 border-emerald-500/40 shadow-md animate-in slide-in-from-top-2 duration-300'
                : 'bg-slate-950/60 hover:bg-slate-850 border-slate-800/60'
            }`}
          >
            {/* Left: Avatar, Name, Account, Method */}
            <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
              <img
                src={item.avatar}
                alt={item.name}
                className="w-7 h-7 sm:w-9 sm:h-9 rounded-full object-cover ring-2 ring-slate-800 shrink-0"
              />

              <div className="min-w-0 space-y-0.5">
                <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
                  <span className="text-[11px] sm:text-xs font-black text-white truncate">
                    {item.name}
                  </span>
                  <span className="text-[9px] sm:text-[10px] font-semibold text-emerald-400">
                    {item.username}
                  </span>
                  <span className="px-1.5 py-0.2 rounded-full text-[7px] sm:text-[8px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    SUCCESS
                  </span>
                </div>

                <div className="flex items-center gap-1 text-[9px] sm:text-[11px] text-slate-300">
                  {getMethodIcon(item.method)}
                  <span className="font-semibold text-slate-300">
                    {getMethodLabel(item.method)}
                  </span>
                  <span className="text-slate-500">•</span>
                  <span className="font-mono text-slate-400 truncate">{item.accountMasked}</span>
                </div>

                <div 
                  onClick={(e) => handleCopyUtr(item.utrRef, e)}
                  className="text-[8px] sm:text-[10px] text-slate-500 font-mono hover:text-slate-300 transition-colors flex items-center gap-1 cursor-pointer w-fit select-none"
                  title="Click to copy bank reference number"
                >
                  <span>UTR: {item.utrRef}</span>
                  {copiedUtr === item.utrRef ? (
                    <Check className="w-2.5 h-2.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-2.5 h-2.5" />
                  )}
                </div>
              </div>
            </div>

            {/* Right: Cash Paid, Coins Deducted & Timestamp */}
            <div className="text-right shrink-0">
              <div className="text-[11px] sm:text-xs font-black text-white">
                ₹{item.amountInr.toLocaleString()}{' '}
                <span className="text-[9px] sm:text-[10px] font-medium text-slate-400">INR</span>
              </div>
              <div className="text-[9px] sm:text-[10px] font-bold text-slate-400 flex items-center justify-end gap-0.5 mt-0.5">
                <Coins className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-amber-400" />
                <span>{(item.amountCoins).toLocaleString()} C</span>
              </div>
              <div className="text-[8px] sm:text-[9px] text-slate-500 font-medium mt-0.5">
                {item.timeAgo}
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* FOOTER ACTION BUTTONS */}
      <div className="grid grid-cols-2 gap-1.5 sm:gap-2 pt-1.5 sm:pt-2 border-t border-slate-800/80 relative z-10">
        <button
          type="button"
          onClick={onOpenWallet}
          className="min-h-[44px] py-2 sm:py-2.5 px-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-[10px] sm:text-xs shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer active:scale-95"
        >
          <span>Claim Your Payout</span>
          <Zap className="w-3.5 h-3.5 fill-current" />
        </button>

        <button
          type="button"
          onClick={() => setIsModalOpen(true)}
          className="min-h-[44px] py-2 sm:py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700/80 text-slate-200 font-bold text-[10px] sm:text-xs flex items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer active:scale-95"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Explore 10,000+ History</span>
        </button>
      </div>

      {/* EXPLORE MODAL: VIEW ALL 10,000+ VERIFIED WITHDRAWAL TRANSACTIONS */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div 
            className="w-full max-w-xl max-h-[85vh] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-black">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>Verified Payout Ledger</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                      12,840 Paid Today
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Real-time audit of verified UPI, Paytm and Bank transactions
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Search & Filters */}
            <div className="p-3 sm:p-4 bg-slate-950/40 border-b border-slate-800/80 space-y-2.5">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by name, @username, UTR number or masked account..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Payment Methods Filters */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                <button
                  type="button"
                  onClick={() => setMethodFilter('all')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    methodFilter === 'all'
                      ? 'bg-white text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  All Methods (10,000+)
                </button>

                <button
                  type="button"
                  onClick={() => setMethodFilter('upi')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
                    methodFilter === 'upi'
                      ? 'bg-emerald-500 text-slate-950 font-black'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span>UPI Instant</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethodFilter('paytm')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    methodFilter === 'paytm'
                      ? 'bg-sky-500 text-white font-black'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Paytm Wallet
                </button>

                <button
                  type="button"
                  onClick={() => setMethodFilter('phonepe')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    methodFilter === 'phonepe'
                      ? 'bg-purple-500 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  PhonePe
                </button>

                <button
                  type="button"
                  onClick={() => setMethodFilter('bank_transfer')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer shrink-0 ${
                    methodFilter === 'bank_transfer'
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Bank Transfer
                </button>
              </div>
            </div>

            {/* Modal List of Verified Withdrawals */}
            <div className="p-3 sm:p-4 overflow-y-auto space-y-2.5 flex-1 bg-slate-900">
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 font-semibold">
                <span>Verified Bank-Disbursed Payments</span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>99.9% Auto-Approved</span>
                </span>
              </div>

              {exploreWithdrawalsList.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-slate-950/60 hover:bg-slate-850 border border-slate-800/80 transition-all flex items-center justify-between gap-3"
                >
                  {/* Left info */}
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={item.avatar}
                      alt={item.name}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-850 shrink-0"
                    />

                    <div className="min-w-0 space-y-0.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-black text-white truncate">
                          {item.name}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-bold">
                          {item.username}
                        </span>
                        <span className="px-1.5 py-0.2 rounded-full text-[8px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          SUCCESS
                        </span>
                      </div>

                      <div className="flex items-center gap-1 text-[11px] text-slate-300">
                        {getMethodIcon(item.method)}
                        <span className="font-semibold text-slate-300">
                          {getMethodLabel(item.method)}
                        </span>
                        <span className="text-slate-500">•</span>
                        <span className="font-mono text-slate-400">{item.accountMasked}</span>
                      </div>

                      <div 
                        onClick={(e) => handleCopyUtr(item.utrRef, e)}
                        className="text-[10px] text-slate-500 font-mono hover:text-slate-300 transition-colors flex items-center gap-1 cursor-pointer w-fit select-none"
                      >
                        <span>Bank Ref: {item.utrRef}</span>
                        {copiedUtr === item.utrRef ? (
                          <Check className="w-2.5 h-2.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-2.5 h-2.5" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right info */}
                  <div className="text-right shrink-0">
                    <div className="text-xs font-black text-white">
                      ₹{item.amountInr.toLocaleString()} INR
                    </div>
                    <div className="text-[10px] font-bold text-slate-400 flex items-center justify-end gap-0.5 mt-0.5">
                      <Coins className="w-3 h-3 text-amber-400" />
                      <span>{item.amountCoins.toLocaleString()} C</span>
                    </div>
                    <div className="text-[9px] text-slate-500 mt-0.5">
                      {item.timeAgo}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Modal Footer CTA */}
            <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
              <div className="text-xs text-slate-400 hidden sm:block">
                All transactions are verified through official payment gateways.
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsModalOpen(false);
                  onOpenWallet();
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white font-black text-xs shadow-md shadow-emerald-500/20 cursor-pointer"
              >
                💸 Withdraw Your Balance Now
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
