import React, { useState, useMemo } from 'react';
import { 
  ShoppingBag, 
  Package, 
  Users, 
  CheckCircle2, 
  Circle, 
  ArrowRight, 
  ExternalLink, 
  Plus, 
  Truck, 
  Sliders, 
  Globe, 
  ChevronDown, 
  ChevronUp, 
  Layers, 
  ArrowUpRight, 
  Sparkles, 
  Store as StoreIcon, 
  Clock, 
  Tag, 
  Eye, 
  Check, 
  AlertTriangle, 
  X, 
  Bot, 
  Search, 
  CreditCard, 
  RotateCcw,
  Briefcase,
  Compass,
  MapPin,
  Send
} from 'lucide-react';
import { Store, Product, Order, Customer, Language, DashboardTab } from '../../types';

interface DashboardOverviewProps {
  activeStore: Store;
  products: Product[];
  orders: Order[];
  customers?: Customer[];
  userName?: string;
  userEmail?: string;
  language: Language;
  onNavigateTab: (tab: DashboardTab) => void;
  onOpenStorefront: () => void;
  onOpenAddProduct: () => void;
  onUpdateOrderStatus: (orderId: string, status: Order['orderStatus']) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  activeStore,
  products = [],
  orders = [],
  customers = [],
  userName,
  userEmail,
  language,
  onNavigateTab,
  onOpenStorefront,
  onOpenAddProduct,
  onUpdateOrderStatus,
}) => {
  const isBn = language === 'bn';

  // Card Dismissal State
  const [dismissedCards, setDismissedCards] = useState<string[]>([]);
  const [copilotQuery, setCopilotQuery] = useState('');

  const handleDismissCard = (cardId: string) => {
    setDismissedCards((prev) => [...prev, cardId]);
  };

  const handleResetCards = () => {
    setDismissedCards([]);
  };

  // 1. Store Isolation & Real Metric Calculations
  const storeOrders = useMemo(() => {
    if (!Array.isArray(orders)) return [];
    return orders.filter((o) => o && typeof o === 'object' && o.storeId === activeStore?.id);
  }, [orders, activeStore?.id]);

  const storeProducts = useMemo(() => {
    if (!Array.isArray(products)) return [];
    return products.filter((p) => p && typeof p === 'object' && p.storeId === activeStore?.id);
  }, [products, activeStore?.id]);

  const storeCustomers = useMemo(() => {
    if (!Array.isArray(customers)) return [];
    return customers.filter((c) => c && typeof c === 'object' && c.storeId === activeStore?.id);
  }, [customers, activeStore?.id]);

  // Total Sales & Order Statuses
  const totalRevenue = useMemo(() => {
    return storeOrders.reduce((sum, o) => {
      const amount = typeof o.totalAmount === 'number' ? o.totalAmount : 0;
      return sum + (o.paymentStatus === 'paid' ? amount : 0);
    }, 0);
  }, [storeOrders]);

  const totalOrdersCount = storeOrders.length;
  const pendingOrders = storeOrders.filter((o) => o.orderStatus === 'pending');
  const paidOrdersCount = storeOrders.filter((o) => o.paymentStatus === 'paid').length;

  // Real Customer Count
  const totalCustomersCount = useMemo(() => {
    if (storeCustomers.length > 0) return storeCustomers.length;
    const uniquePhones = new Set(
      storeOrders.map((o) => o.customerPhone).filter(Boolean)
    );
    return uniquePhones.size;
  }, [storeCustomers, storeOrders]);

  // Inventory & Stock Calculations
  const totalInventoryUnits = useMemo(() => {
    return storeProducts.reduce((sum, p) => {
      if (Array.isArray(p.variants) && p.variants.length > 0) {
        return sum + p.variants.reduce((vSum, v) => vSum + (typeof v.stock === 'number' ? v.stock : 0), 0);
      }
      return sum + (typeof p.stock === 'number' ? p.stock : 0);
    }, 0);
  }, [storeProducts]);

  const lowStockProducts = useMemo(() => {
    return storeProducts.filter((p) => {
      const stock = typeof p.stock === 'number' ? p.stock : 0;
      return stock <= 5;
    });
  }, [storeProducts]);

  // 2. Dynamic Time-Aware Greeting (Follows device/browser local timezone)
  const greeting = useMemo(() => {
    const now = new Date();
    const localHour = now.getHours();

    let prefixBn = 'শুভ অপরাহ্ন';
    let prefixEn = 'Good afternoon';

    if (localHour >= 5 && localHour < 12) {
      // 5:00 AM – 11:59 AM
      prefixBn = 'শুভ সকাল';
      prefixEn = 'Good morning';
    } else if (localHour >= 12 && localHour < 17) {
      // 12:00 PM – 4:59 PM
      prefixBn = 'শুভ অপরাহ্ন';
      prefixEn = 'Good afternoon';
    } else if (localHour >= 17 && localHour < 21) {
      // 5:00 PM – 8:59 PM
      prefixBn = 'শুভ সন্ধ্যা';
      prefixEn = 'Good evening';
    } else {
      // 9:00 PM – 4:59 AM
      prefixBn = 'শুভ রাত্রি';
      prefixEn = 'Good night';
    }

    const prefix = isBn ? prefixBn : prefixEn;
    return `${prefix}, Shanju`;
  }, [isBn]);

  // 3. Dynamic Setup Tasks & Progress Calculation
  const setupTasks = useMemo(() => [
    {
      id: 'task-1',
      title: isBn ? 'আপনার প্রথম পণ্য যুক্ত করুন' : 'Add your first product',
      isCompleted: storeProducts.length > 0,
    },
    {
      id: 'task-2',
      title: isBn ? 'স্টোর ডিজাইন ও থিম নির্বাচন করুন' : 'Choose your store design',
      isCompleted: Boolean(activeStore?.theme && (activeStore.theme.layoutStyle || activeStore.theme.primaryColor)),
    },
    {
      id: 'task-3',
      title: isBn ? 'কাস্টম ডোমেইন সেটআপ করুন' : 'Get a custom domain',
      isCompleted: Boolean(activeStore?.customDomain),
    },
    {
      id: 'task-4',
      title: isBn ? 'কুরিয়ার ও শিপিং রেট যাচাই করুন' : 'Review shipping rates',
      isCompleted: Boolean(activeStore?.address),
    },
    {
      id: 'task-5',
      title: isBn ? 'বিক্রয় চ্যানেল ও মার্কেটপ্লেস' : 'Sell everywhere',
      isCompleted: storeOrders.length > 0 || activeStore?.status === 'active',
    },
  ], [isBn, storeProducts.length, activeStore, storeOrders.length]);

  const completedTasksCount = setupTasks.filter((t) => t.isCompleted).length;

  // Store domain display
  const storeDomainDisplay = activeStore?.customDomain 
    ? activeStore.customDomain 
    : `${activeStore?.slug || 'store'}.shanju.cloud`;

  const handleCopilotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!copilotQuery.trim()) return;
    onNavigateTab('copilot');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      {/* ========================================================================= */}
      {/* 1. WELCOME GREETING HEADER                                                */}
      {/* ========================================================================= */}
      <div className="pt-1 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            {greeting}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isBn 
              ? 'আপনার স্টোরের আজকের সাম্প্রতিক কার্যক্রম ও ওভারভিউ:' 
              : "Here's what's happening with your store"}
          </p>
        </div>
        <div className="text-[11px] font-mono text-slate-400 hidden sm:block">
          {storeDomainDisplay}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. SHOPIFY-STYLE QUICKSTART HERO AREA WITH MOCKUP & ASSISTANT BAR          */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-6 sm:p-8 text-center relative overflow-hidden">
        {/* Soft decorative background ambient light */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-32 bg-slate-100/70 blur-2xl pointer-events-none rounded-full" />

        {/* Browser Mockup Illustration (EXACT Reference Screenshot Composition) */}
        <div className="max-w-md mx-auto relative mb-6">
          <div className="bg-slate-100/90 rounded-2xl border border-slate-200/90 p-3.5 shadow-inner">
            {/* Top Browser Bar */}
            <div className="flex items-center gap-2 px-3 py-1 bg-white rounded-lg border border-slate-200 text-[11px] font-mono text-slate-600 shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <span className="truncate">{activeStore?.name || 'Quickstart'}</span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-400 truncate">{storeDomainDisplay}</span>
            </div>

            {/* Mockup Store Content Canvas */}
            <div className="mt-3 grid grid-cols-3 gap-2 h-24">
              <div className="bg-white rounded-xl border border-slate-200/70 p-2 shadow-2xs flex flex-col justify-between">
                <div className="w-8 h-2 bg-slate-200 rounded" />
                <div className="w-12 h-1.5 bg-slate-100 rounded" />
              </div>
              <div className="bg-white rounded-xl border border-slate-200/70 p-2 shadow-2xs flex flex-col justify-between">
                <div className="w-8 h-2 bg-slate-200 rounded" />
                <div className="w-10 h-1.5 bg-slate-100 rounded" />
              </div>
              <div className="bg-white rounded-xl border border-slate-200/70 p-2 shadow-2xs flex flex-col justify-between">
                <div className="w-6 h-2 bg-slate-200 rounded" />
                <div className="w-8 h-1.5 bg-slate-100 rounded" />
              </div>
            </div>
          </div>

          {/* Floating Credit Card Badge (Upper right of mockup) */}
          <div className="absolute -top-2 -right-3 transform rotate-6 bg-emerald-800 text-white p-2.5 rounded-xl shadow-lg border border-emerald-700/60 flex items-center gap-2 select-none">
            <div className="w-2.5 h-2 bg-amber-300 rounded-sm" />
            <span className="text-[10px] font-mono tracking-wider font-bold">Shanju Pay</span>
          </div>

          {/* Overlapping Product Cards (Lower center of mockup) */}
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex items-center justify-center -space-x-3">
            <div className="w-11 h-14 bg-gradient-to-tr from-slate-900 to-indigo-900 rounded-xl shadow-md border-2 border-white transform -rotate-12 flex items-center justify-center text-[10px] text-white">
              👕
            </div>
            <div className="w-12 h-15 bg-white rounded-xl shadow-lg border-2 border-slate-200 transform z-10 flex items-center justify-center text-sm">
              👟
            </div>
            <div className="w-11 h-14 bg-gradient-to-tr from-teal-500 to-emerald-600 rounded-xl shadow-md border-2 border-white transform rotate-12 flex items-center justify-center text-[10px] text-white">
              🎒
            </div>
          </div>
        </div>

        {/* Store Title & Status Under Mockup */}
        <div className="mt-8 space-y-1">
          <p className="text-sm sm:text-base text-slate-800 font-medium">
            <button 
              type="button"
              onClick={onOpenStorefront}
              className="underline decoration-slate-300 decoration-1 underline-offset-4 hover:decoration-slate-900 font-semibold cursor-pointer"
            >
              {activeStore?.name || 'Quickstart'}
            </button>
            {' '}
            <span>
              {isBn 
                ? `এ বর্তমানে ${storeProducts.length}টি পণ্য বিক্রির জন্য প্রস্তুত`
                : (storeProducts.length === 1 ? 'has a product to sell' : `has ${storeProducts.length} products to sell`)}
            </span>
          </p>

          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            {isBn ? 'এখন আপনি কোন কাজটি সম্পন্ন করতে চান?' : 'What do you want to work on next?'}
          </h2>
        </div>

        {/* Assistant / Quick Search Container (Exact Reference Box) */}
        <div className="max-w-xl mx-auto mt-5">
          {/* Subtle status notice */}
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 mb-2 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>
              {isBn 
                ? 'শানজু এআই সহকারী সক্রিয় এবং আপনার স্টোর অপ্টিমাইজ করতে প্রস্তুত।' 
                : 'Shanju Copilot is currently active and ready to assist with your store.'}
            </span>
          </div>

          <form onSubmit={handleCopilotSubmit} className="relative bg-white rounded-2xl border border-slate-300 shadow-2xs hover:border-slate-400 focus-within:border-slate-900 transition-colors p-2.5">
            <div className="flex items-center gap-2 px-1">
              <Bot className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                value={copilotQuery}
                onChange={(e) => setCopilotQuery(e.target.value)}
                placeholder={isBn ? 'আপনার স্টোরের থিম কাস্টমাইজ বা পণ্য সাজান...' : 'Customize my current theme'}
                className="w-full text-xs text-slate-900 placeholder-slate-400 focus:outline-none font-medium bg-transparent"
              />
            </div>

            {/* Bottom Actions Row inside the input box */}
            <div className="flex items-center justify-between pt-2 mt-2 border-t border-slate-100 text-[11px] text-slate-500">
              <div className="flex items-center gap-1.5">
                <div className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[9px]">
                  S
                </div>
                <span className="font-semibold text-slate-700">Shanju</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onNavigateTab('customizer')}
                  className="flex items-center gap-1 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>{isBn ? 'রিসেন্ট' : 'Recents'}</span>
                </button>
                <span className="text-slate-200">|</span>
                <button
                  type="submit"
                  className="p-1 rounded-md bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer"
                  title="Submit"
                >
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </form>

          {/* Prompt Suggestion Chips */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 mt-2.5">
            <button
              type="button"
              onClick={() => onNavigateTab('customizer')}
              className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              🎨 {isBn ? 'থিম কাস্টমাইজ' : 'Customize theme'}
            </button>
            <button
              type="button"
              onClick={onOpenAddProduct}
              className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              📦 {isBn ? 'পণ্য যোগ' : 'Add product'}
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('shipping')}
              className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              🚚 {isBn ? 'শিপিং সেটিংস' : 'Review shipping'}
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('settings')}
              className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              🌐 {isBn ? 'কাস্টম ডোমেইন' : 'Custom domain'}
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. SHOPIFY ONBOARDING / SETUP CARDS (EXACT 2-COLUMN RESPONSIVE GRID)      */}
      {/* ========================================================================= */}
      <div className="space-y-4">
        {/* Reset Dismissed Cards button if any were hidden */}
        {dismissedCards.length > 0 && (
          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleResetCards}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer font-medium"
            >
              <RotateCcw className="w-3 h-3 text-slate-400" />
              <span>{isBn ? 'সব কার্ড পুনরায় দেখান' : 'Reset dismissed cards'}</span>
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* CARD 1: Choose your store design */}
          {!dismissedCards.includes('card-1') && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between relative group min-h-[300px]">
              <button
                type="button"
                onClick={() => handleDismissCard('card-1')}
                className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              <div>
                <h3 className="text-sm font-bold text-slate-900 pr-6">
                  {isBn ? 'স্টোর ডিজাইন ও থিম নির্বাচন করুন' : 'Choose your store design'}
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {isBn 
                    ? 'আপনার ব্র্যান্ডের সাথে মানানসই আধুনিক প্রিমিয়াম থিম বেছে নিন এবং রঙ ও ব্যানার কাস্টমাইজ করুন।' 
                    : 'Pick a theme that fits your brand, then customize from there.'}
                </p>
              </div>

              {/* Graphic Illustration (Theme Editor Canvas Mockup) */}
              <div className="my-4 py-2 flex items-center justify-center">
                <div className="relative w-full max-w-[260px] h-28 bg-slate-50 rounded-xl border border-slate-200/80 p-2 flex items-center justify-center overflow-hidden shadow-inner">
                  {/* Left Column Preview */}
                  <div className="w-16 h-20 bg-slate-200 rounded-lg shadow-2xs flex flex-col justify-between p-1.5 transform -rotate-3">
                    <div className="w-6 h-6 bg-slate-300 rounded-full mx-auto" />
                    <div className="w-10 h-1.5 bg-slate-300 rounded mx-auto" />
                  </div>

                  {/* Center Aa typography token */}
                  <div className="mx-2 w-18 h-18 bg-white rounded-xl border border-slate-200 shadow-md flex flex-col items-center justify-center p-2 z-10">
                    <span className="text-2xl font-black text-slate-900 tracking-tighter">Aa</span>
                    <div className="flex gap-0.5 mt-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                    </div>
                  </div>

                  {/* Right Column Banner */}
                  <div className="w-16 h-20 bg-orange-100 rounded-lg border border-orange-200 shadow-2xs p-1.5 flex flex-col justify-center items-center transform rotate-3">
                    <span className="text-sm font-black text-orange-600">CH</span>
                    <span className="text-[8px] font-bold text-orange-500">STYLE</span>
                  </div>
                </div>
              </div>

              {/* Bottom Action Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigateTab('customizer')}
                  className="rounded-full border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-1.5 transition-colors cursor-pointer shadow-2xs"
                >
                  {isBn ? 'থিম কাস্টমাইজ' : 'Choose theme'}
                </button>
              </div>
            </div>
          )}

          {/* CARD 2: Get a custom domain */}
          {!dismissedCards.includes('card-2') && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between relative group min-h-[300px]">
              <button
                type="button"
                onClick={() => handleDismissCard('card-2')}
                className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              <div>
                <h3 className="text-sm font-bold text-slate-900 pr-6">
                  {isBn ? 'কাস্টম ডোমেইন যুক্ত করুন' : 'Get a custom domain'}
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {isBn 
                    ? 'আপনার স্টোরকে গ্রাহকদের কাছে বিশ্বাসযোগ্য করতে নিজস্ব ব্র্যান্ডেড URL যুক্ত করুন।' 
                    : "Give your store a branded URL that's easy to find, trust, and remember."}
                </p>
              </div>

              {/* Graphic Illustration (Domain Browser & Pointer Cursor) */}
              <div className="my-4 py-2 flex items-center justify-center">
                <div className="relative w-full max-w-[260px] h-28 bg-slate-50/70 rounded-xl border border-slate-200/80 p-3 shadow-inner flex flex-col justify-center">
                  {/* Grid patterned notepad representation */}
                  <div className="bg-white rounded-lg border border-slate-200 p-2.5 shadow-2xs flex items-center justify-between">
                    <span className="font-mono text-xs text-slate-400 tracking-wider">
                      ______________.com
                    </span>
                    <Globe className="w-3.5 h-3.5 text-slate-400" />
                  </div>

                  {/* Metallic 3D Pointer Cursor */}
                  <div className="absolute bottom-2 right-6 transform -rotate-12">
                    <div className="w-7 h-7 bg-slate-900 text-white rounded-tl-none rounded-md shadow-lg flex items-center justify-center">
                      <Compass className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Action Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigateTab('settings')}
                  className="rounded-full border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-1.5 transition-colors cursor-pointer shadow-2xs"
                >
                  {isBn ? 'ডোমেইন কনফিগার' : 'Set up domain'}
                </button>
              </div>
            </div>
          )}

          {/* CARD 3: Review shipping rates */}
          {!dismissedCards.includes('card-3') && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between relative group min-h-[300px]">
              <button
                type="button"
                onClick={() => handleDismissCard('card-3')}
                className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              <div>
                <h3 className="text-sm font-bold text-slate-900 pr-6">
                  {isBn ? 'কুরিয়ার ও শিপিং রেট যাচাই করুন' : 'Review shipping rates'}
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {isBn 
                    ? 'ঢাকার ভেতরে ও বাইরে ডেলিভারি চার্জ নির্ধারণ করুন এবং কুরিয়ার ইন্টিগ্রেশন চালু করুন।' 
                    : 'Check the shipping rates set up for you by your courier and delivery settings.'}
                </p>
              </div>

              {/* Graphic Illustration (Delivery Box with Shipping Stickers) */}
              <div className="my-4 py-2 flex items-center justify-center">
                <div className="relative w-full max-w-[260px] h-28 bg-slate-50/70 rounded-xl border border-slate-200/80 p-3 shadow-inner flex items-center justify-center">
                  <div className="w-20 h-20 bg-amber-100/80 rounded-xl border border-amber-300/80 shadow-md relative flex items-center justify-center">
                    <Truck className="w-8 h-8 text-amber-700/80" />
                    {/* Shipping sticker badge */}
                    <div className="absolute -bottom-1 -left-2 bg-white border border-slate-300 px-1.5 py-0.5 rounded shadow-xs text-[8px] font-mono font-bold text-slate-800">
                      ||| || | 60৳
                    </div>
                    {/* Fragile badge */}
                    <div className="absolute -top-1 -right-1 bg-rose-500 text-white text-[7px] font-bold px-1 rounded">
                      EXPRESS
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Action Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigateTab('shipping')}
                  className="rounded-full border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-1.5 transition-colors cursor-pointer shadow-2xs"
                >
                  {isBn ? 'শিপিং সেটিংস' : 'Review rates'}
                </button>
              </div>
            </div>
          )}

          {/* CARD 4: Prepare your store for launch / checklist */}
          {!dismissedCards.includes('card-4') && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between relative group min-h-[300px]">
              <button
                type="button"
                onClick={() => handleDismissCard('card-4')}
                className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              <div>
                {/* Dynamic Task Completion Badge (Matches screenshot circle) */}
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-medium mb-1">
                  <div className="w-3.5 h-3.5 rounded-full border border-slate-400 flex items-center justify-center text-[9px] font-bold text-slate-600">
                    {completedTasksCount}
                  </div>
                  <span>
                    {isBn 
                      ? `৫ টির মধ্যে ${completedTasksCount} টি ধাপ সম্পন্ন` 
                      : `${completedTasksCount} of 5 tasks completed`}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 pr-6">
                  {isBn ? 'স্টোর লঞ্চের প্রস্তুতি সম্পন্ন করুন' : 'Prepare your store for launch'}
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {isBn 
                    ? 'রিটার্ন পলিসি, ক্যানসেলেশন ও আবশ্যকীয় টার্মস কনফিগার করে স্টোর প্রকাশ করুন।' 
                    : 'Set up return and cancellation options for your orders and review store readiness.'}
                </p>
              </div>

              {/* Graphic Illustration (Cardboard Package with Golden Coins) */}
              <div className="my-4 py-2 flex items-center justify-center">
                <div className="relative w-full max-w-[260px] h-28 bg-slate-50/70 rounded-xl border border-slate-200/80 p-3 shadow-inner flex items-center justify-center">
                  <div className="relative">
                    <div className="w-18 h-18 bg-amber-200/70 rounded-xl border border-amber-300 shadow-md flex items-center justify-center">
                      <Package className="w-8 h-8 text-amber-800" />
                    </div>

                    {/* Floating Gold Coin Badges */}
                    <div className="absolute -top-2 -right-3 w-7 h-7 rounded-full bg-amber-400 border border-amber-500 shadow-sm flex items-center justify-center text-[11px] font-black text-amber-900">
                      ৳
                    </div>
                    <div className="absolute bottom-0 -right-2 w-5 h-5 rounded-full bg-amber-300 border border-amber-400 shadow-xs flex items-center justify-center text-[9px] font-black text-amber-900">
                      ✓
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Action Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigateTab('settings')}
                  className="rounded-full border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-1.5 transition-colors cursor-pointer shadow-2xs"
                >
                  {isBn ? 'শুরু করুন' : 'Get started'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* CARD 5: Sell B2B and DTC, in one place (Spanning full width or centered) */}
        {!dismissedCards.includes('card-5') && (
          <div className="max-w-md mx-auto bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between relative group min-h-[290px]">
            <button
              type="button"
              onClick={() => handleDismissCard('card-5')}
              className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>

            <div>
              {/* Task progress indicator */}
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-medium mb-1">
                <div className="w-3.5 h-3.5 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin-none text-[9px]" />
                <span>
                  {isBn ? 'মার্কেটপ্লেস ও রিটেল চ্যানেল' : 'Multichannel commerce'}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 pr-6">
                {isBn ? 'এক জায়গা থেকেই পাইকারি ও খুচরা বিক্রয়' : 'Sell B2B and DTC, in one place'}
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                {isBn 
                  ? 'অনলাইন স্টোরফ্রন্ট, ফেসবুক শপ ও পয়েন্ট-অব-সেল (POS) এক সাথে পরিচালনা করুন।' 
                  : 'Next task: Sell B2B and DTC, all in one place with unified inventory.'}
              </p>
            </div>

            {/* Graphic Illustration (Teal Route Map with Storefront & Briefcase) */}
            <div className="my-4 py-2 flex items-center justify-center">
              <div className="relative w-full max-w-[260px] h-24 bg-emerald-50/80 rounded-xl border border-emerald-200/90 p-3 shadow-inner flex items-center justify-between px-6">
                {/* Store Icon */}
                <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center shadow-sm">
                  <StoreIcon className="w-4 h-4" />
                </div>

                {/* Dotted GPS Route Line */}
                <div className="flex-1 flex items-center justify-center px-2">
                  <div className="w-full border-t-2 border-dashed border-emerald-400 flex items-center justify-center relative">
                    <div className="absolute bg-emerald-600 text-white p-0.5 rounded-full">
                      <ArrowRight className="w-2.5 h-2.5" />
                    </div>
                  </div>
                </div>

                {/* Briefcase Icon */}
                <div className="w-9 h-9 rounded-lg bg-teal-800 text-white flex items-center justify-center shadow-sm">
                  <Briefcase className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Bottom Action Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={() => onNavigateTab('markets')}
                className="rounded-full border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold px-4 py-1.5 transition-colors cursor-pointer shadow-2xs"
              >
                {isBn ? 'রিজিউম' : 'Resume'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 4. STORE PERFORMANCE ANALYTICS SECTION (REAL FIRESTORE DATA)              */}
      {/* ========================================================================= */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">
            {isBn ? 'স্টোর পারফরম্যান্স সারাংশ' : 'Performance summary'}
          </h2>
          <button
            type="button"
            onClick={() => onNavigateTab('analytics')}
            className="text-xs font-medium text-slate-500 hover:text-slate-900 transition-colors inline-flex items-center gap-1 cursor-pointer"
          >
            <span>{isBn ? 'বিশদ অ্যানালিটিক্স' : 'View analytics'}</span>
            <ArrowRight className="w-3 h-3 text-slate-400" />
          </button>
        </div>

        {/* 5 Compact KPI Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* 1. Total Sales */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isBn ? 'মোট বিক্রয়' : 'Total sales'}
            </span>
            <span className="text-lg sm:text-xl font-bold text-slate-900 mt-1 block tracking-tight">
              ৳{totalRevenue.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block truncate">
              {paidOrdersCount} {isBn ? 'পেইড অর্ডার' : 'paid orders'}
            </span>
          </div>

          {/* 2. Total Orders */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isBn ? 'মোট অর্ডার' : 'Orders'}
            </span>
            <span className="text-lg sm:text-xl font-bold text-slate-900 mt-1 block tracking-tight">
              {totalOrdersCount}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block truncate">
              {pendingOrders.length > 0 
                ? `${pendingOrders.length} ${isBn ? 'অপেক্ষমান' : 'pending'}` 
                : (isBn ? 'সব প্রসেসড' : 'Fulfilled')}
            </span>
          </div>

          {/* 3. Products */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isBn ? 'মোট পণ্য' : 'Products'}
            </span>
            <span className="text-lg sm:text-xl font-bold text-slate-900 mt-1 block tracking-tight">
              {storeProducts.length}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block truncate">
              {lowStockProducts.length > 0
                ? `${lowStockProducts.length} ${isBn ? 'কম স্টক' : 'low stock'}`
                : (isBn ? 'পর্যাপ্ত মজুদ' : 'Catalog healthy')}
            </span>
          </div>

          {/* 4. Customers */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isBn ? 'কাস্টমার' : 'Customers'}
            </span>
            <span className="text-lg sm:text-xl font-bold text-slate-900 mt-1 block tracking-tight">
              {totalCustomersCount}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block truncate">
              {isBn ? 'রেজিস্টার্ড ক্রেতা' : 'Customer base'}
            </span>
          </div>

          {/* 5. Inventory Units */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-2xs col-span-2 sm:col-span-1">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isBn ? 'ইনভেন্টরি' : 'Inventory'}
            </span>
            <span className="text-lg sm:text-xl font-bold text-slate-900 mt-1 block tracking-tight">
              {totalInventoryUnits}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block truncate">
              {isBn ? 'মোট একক মজুদ' : 'Units on hand'}
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 5. QUICK ACTIONS                                                          */}
      {/* ========================================================================= */}
      <div className="space-y-3 pt-1">
        <h2 className="text-sm font-bold text-slate-900">
          {isBn ? 'দ্রুত অ্যাকশন' : 'Quick actions'}
        </h2>

        <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs p-3 sm:p-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 text-xs">
            <button
              type="button"
              onClick={onOpenAddProduct}
              className="p-2.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 font-medium text-left flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="truncate">{isBn ? 'পণ্য যোগ' : 'Add product'}</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigateTab('orders')}
              className="p-2.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 font-medium text-left flex items-center gap-2 transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="truncate">{isBn ? 'অর্ডার দেখুন' : 'View orders'}</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigateTab('inventory')}
              className="p-2.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 font-medium text-left flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-purple-600 shrink-0" />
              <span className="truncate">{isBn ? 'ইনভেন্টরি' : 'Inventory'}</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigateTab('customizer')}
              className="p-2.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 font-medium text-left flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span className="truncate">{isBn ? 'কাস্টমাইজ' : 'Customize store'}</span>
            </button>

            <button
              type="button"
              onClick={onOpenStorefront}
              className="p-2.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 font-medium text-left flex items-center gap-2 transition-colors cursor-pointer col-span-2 sm:col-span-1"
            >
              <ExternalLink className="w-3.5 h-3.5 text-slate-600 shrink-0" />
              <span className="truncate">{isBn ? 'স্টোরফ্রন্ট' : 'View storefront'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 6. RECENT ORDERS TABLE                                                    */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              {isBn ? 'সাম্প্রতিক অর্ডারসমূহ' : 'Recent orders'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {isBn 
                ? 'আপনার স্টোরে আসা সাম্প্রতিক কাস্টমার অর্ডারের সারসংক্ষেপ।' 
                : 'Latest customer purchases from your online store.'}
            </p>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors inline-flex items-center gap-1 cursor-pointer"
          >
            <span>{isBn ? 'সব অর্ডার' : 'View all orders'}</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>

        {storeOrders.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs p-6">
            <ShoppingBag className="w-8 h-8 mx-auto text-slate-300 mb-2.5" />
            <p className="font-semibold text-slate-800 text-sm">
              {isBn ? 'এখনো কোনো অর্ডার পাওয়া যায়নি' : 'No orders yet'}
            </p>
            <p className="text-slate-400 mt-1 max-w-sm mx-auto">
              {isBn 
                ? 'গ্রাহকরা যখন আপনার অনলাইন স্টোর থেকে কেনাকাটা করবেন, তখন সেই অর্ডারগুলো এখানে দেখতে পাবেন।' 
                : 'When customers place orders on your online store, they will appear here in real-time.'}
            </p>
            <button
              type="button"
              onClick={onOpenStorefront}
              className="mt-4 px-3.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium transition-colors cursor-pointer shadow-2xs"
            >
              {isBn ? 'স্টোরফ্রন্ট ভিজিট করুন' : 'Visit storefront'}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-slate-50/70 border-b border-slate-100 text-slate-500 font-medium text-[11px] uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-4 font-medium">{isBn ? 'অর্ডার' : 'Order'}</th>
                  <th className="py-2.5 px-4 font-medium">{isBn ? 'গ্রাহক' : 'Customer'}</th>
                  <th className="py-2.5 px-4 font-medium text-right">{isBn ? 'আইটেম' : 'Items'}</th>
                  <th className="py-2.5 px-4 font-medium text-right">{isBn ? 'মোট' : 'Total'}</th>
                  <th className="py-2.5 px-4 font-medium text-center">{isBn ? 'পেমেন্ট' : 'Payment'}</th>
                  <th className="py-2.5 px-4 font-medium text-right">{isBn ? 'ডেলিভারি' : 'Fulfillment'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {storeOrders.slice(0, 5).map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900 text-xs">
                      #{order.id.slice(-6).toUpperCase()}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 text-xs">{order.customerName || 'Customer'}</div>
                      <div className="text-[11px] text-slate-400 font-normal">{order.customerPhone || ''}</div>
                    </td>
                    <td className="py-3 px-4 text-right text-xs">
                      {Array.isArray(order.items) ? order.items.length : 1}
                    </td>
                    <td className="py-3 px-4 text-right font-medium text-slate-900 text-xs">
                      ৳{(order.totalAmount || 0).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-medium ${
                        order.paymentStatus === 'paid'
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-amber-50 text-amber-800'
                      }`}>
                        {order.paymentStatus === 'paid' ? (isBn ? 'পরিশোধিত' : 'Paid') : (isBn ? 'অপরিশোধিত' : 'Pending')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <select
                        value={order.orderStatus}
                        onChange={(e: any) => onUpdateOrderStatus(order.id, e.target.value)}
                        className="text-xs font-normal rounded-md px-2 py-0.5 border border-slate-200 bg-white text-slate-800 focus:outline-none cursor-pointer"
                      >
                        <option value="pending">{isBn ? 'Pending' : 'Pending'}</option>
                        <option value="processing">{isBn ? 'Processing' : 'Processing'}</option>
                        <option value="shipped">{isBn ? 'Shipped' : 'Shipped'}</option>
                        <option value="delivered">{isBn ? 'Delivered' : 'Delivered'}</option>
                        <option value="cancelled">{isBn ? 'Cancelled' : 'Cancelled'}</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
