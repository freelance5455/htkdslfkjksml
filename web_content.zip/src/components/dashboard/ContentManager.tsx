import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  ExternalLink, 
  Check, 
  Edit3, 
  Trash2,
  Globe
} from 'lucide-react';
import { Language } from '../../types';

interface StorePage {
  id: string;
  title: string;
  titleBn: string;
  slug: string;
  updatedAt: string;
  status: 'published' | 'draft';
}

const initialPages: StorePage[] = [
  {
    id: 'page-1',
    title: 'About Our Brand',
    titleBn: 'আমাদের সম্পর্কে',
    slug: 'about-us',
    updatedAt: '2026-09-28',
    status: 'published'
  },
  {
    id: 'page-2',
    title: 'Shipping & Delivery Policy',
    titleBn: 'শিপিং ও ডেলিভারি পলিসি',
    slug: 'shipping-policy',
    updatedAt: '2026-09-29',
    status: 'published'
  },
  {
    id: 'page-3',
    title: 'Returns & Refund Policy',
    titleBn: 'রিটার্ন ও রিফান্ড নীতিমালা',
    slug: 'return-policy',
    updatedAt: '2026-09-25',
    status: 'published'
  },
  {
    id: 'page-4',
    title: 'Privacy & Terms of Service',
    titleBn: 'গোপনীয়তা ও শর্তাবলী',
    slug: 'terms',
    updatedAt: '2026-09-20',
    status: 'published'
  }
];

export const ContentManager: React.FC<{ language: Language }> = ({ language }) => {
  const isBn = language === 'bn';
  const [pages, setPages] = useState<StorePage[]>(initialPages);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTitleBn, setNewTitleBn] = useState('');

  const handleAddPage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const page: StorePage = {
      id: `page-${Date.now()}`,
      title: newTitle.trim(),
      titleBn: newTitleBn.trim() || newTitle.trim(),
      slug: newTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      updatedAt: new Date().toISOString().split('T')[0],
      status: 'published'
    };
    setPages([...pages, page]);
    setNewTitle('');
    setNewTitleBn('');
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-600" />
            <span>{isBn ? 'স্টোর কন্টেন্ট ও পলিসি পেজ' : 'Pages & Store Content'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'আপনার ই-কমার্স স্টোরের পলিসি, ডেলিভারি রুলস এবং তথ্যবহুল পেজ তৈরি করুন।' 
              : 'Manage store legal policies, shipping timelines, and customer trust pages.'}
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{isBn ? 'নতুন পেজ যোগ করুন' : 'Add Page'}</span>
        </button>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full p-6 text-xs text-slate-700">
            <h3 className="text-base font-bold text-slate-900 mb-4">
              {isBn ? 'নতুন পেজ তৈরি করুন' : 'Create New Page'}
            </h3>
            <form onSubmit={handleAddPage} className="space-y-3.5">
              <div>
                <label className="block font-semibold mb-1 text-slate-800">Page Title (English)</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Size Guide & FAQs"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-slate-800">পেজ শিরোনাম (বাংলা)</label>
                <input
                  type="text"
                  placeholder="যেমন: সাইজ গাইড ও প্রশ্নোত্তর"
                  value={newTitleBn}
                  onChange={(e) => setNewTitleBn(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold"
                >
                  {isBn ? 'প্রকাশ করুন' : 'Publish Page'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="divide-y divide-slate-100 text-xs">
          {pages.map((page) => (
            <div key={page.id} className="p-4 sm:px-6 flex items-center justify-between hover:bg-slate-50/70 transition-colors">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-slate-900 text-sm">
                    {isBn ? page.titleBn : page.title}
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {page.status}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px] mt-0.5 font-mono">
                  /{page.slug} • {isBn ? 'আপডেট:' : 'Updated:'} {page.updatedAt}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => alert(isBn ? 'পেজ প্রিভিউ প্রস্তুত আছে' : 'Page preview available')}
                  className="p-2 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                  title="View"
                >
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
