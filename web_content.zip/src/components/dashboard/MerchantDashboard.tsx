import React, { useState } from 'react';
import { 
  Store, 
  Product, 
  Order, 
  Customer, 
  Language, 
  DashboardTab, 
  StoreTheme,
  PaymentGatewayConfig,
  SubscriptionPayment,
  OrderStatus,
  PaymentStatus,
  DraftOrder,
  AbandonedCheckout,
  ReturnRefundRecord,
  ShippingSettings,
  Collection
} from '../../types';
import { MerchantSidebar } from './MerchantSidebar';
import { MerchantTopNav } from './MerchantTopNav';
import { DashboardOverview } from './DashboardOverview';
import { ProductsManager } from './ProductsManager';
import { CollectionsManager } from './collections/CollectionsManager';
import { OrdersManager } from './OrdersManager';
import { CustomersManager } from './CustomersManager';
import { DiscountsManager } from './DiscountsManager';
import { ContentManager } from './ContentManager';
import { MarketsManager } from './MarketsManager';
import { AnalyticsView } from './AnalyticsView';
import { StoreCustomizer } from './StoreCustomizer';
import { AICopilot } from './AICopilot';
import { SubscriptionBilling } from './SubscriptionBilling';
import { StoreSettingsView } from './StoreSettingsView';
import { DraftOrdersManager } from './orders/DraftOrdersManager';
import { AbandonedCheckoutsManager } from './orders/AbandonedCheckoutsManager';
import { ReturnsRefundsManager } from './orders/ReturnsRefundsManager';
import { ShippingDeliverySettings } from './orders/ShippingDeliverySettings';
import { InventoryManager } from './inventory/InventoryManager';
import { LiveSupportChat } from '../support/LiveSupportChat';
import { ErrorBoundary } from '../common/ErrorBoundary';

interface MerchantDashboardProps {
  activeStore: Store;
  stores?: Store[];
  onSelectStore?: (storeId: string) => void;
  products: Product[];
  orders: Order[];
  customers: Customer[];
  draftOrders?: DraftOrder[];
  abandonedCheckouts?: AbandonedCheckout[];
  returnsRefunds?: ReturnRefundRecord[];
  shippingSettings?: ShippingSettings | null;
  language: Language;
  gateways?: PaymentGatewayConfig[];
  onToggleLanguage?: () => void;
  onOpenStorefront: () => void;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  collections?: Collection[];
  onAddCollection?: (collection: Omit<Collection, 'id'>) => void;
  onUpdateCollection?: (collection: Collection) => void;
  onDeleteCollection?: (collectionId: string) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, trackingId?: string, courier?: string) => void;
  onUpdatePaymentStatus?: (orderId: string, status: PaymentStatus) => void;
  onUpdateOrderNotes?: (orderId: string, notes: string) => void;
  onBulkUpdateOrderStatus?: (orderIds: string[], status: OrderStatus) => void;
  onCreateOrder?: (order: Order) => void;
  onSaveDraftOrder?: (draft: DraftOrder) => void;
  onDeleteDraftOrder?: (draftId: string) => void;
  onConvertDraftToOrder?: (draft: DraftOrder) => void;
  onSaveAbandonedCheckout?: (session: AbandonedCheckout) => void;
  onUpdateAbandonedCheckoutStatus?: (id: string, status: 'incomplete' | 'recovered' | 'blocked') => void;
  onSaveReturnRefund?: (record: ReturnRefundRecord) => void;
  onUpdateReturnRefundStatus?: (id: string, status: 'pending' | 'approved' | 'processed' | 'rejected') => void;
  onSaveShippingSettings?: (settings: ShippingSettings) => void;
  onUpdateStoreTheme: (storeId: string, updatedTheme: Partial<StoreTheme>, storeName?: string) => void;
  onUpdateStorePlan?: (storeId: string, newPlan: 'starter' | 'growth' | 'enterprise') => void;
  onAddSubscriptionPayment?: (payment: SubscriptionPayment) => void;
  onLogout: () => void;
  userEmail?: string;
  userName?: string;
}

export const MerchantDashboard: React.FC<MerchantDashboardProps> = ({
  activeStore,
  stores = [],
  onSelectStore,
  products,
  orders,
  customers,
  draftOrders = [],
  abandonedCheckouts = [],
  returnsRefunds = [],
  shippingSettings = null,
  language,
  gateways = [],
  onToggleLanguage,
  onOpenStorefront,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  collections = [],
  onAddCollection,
  onUpdateCollection,
  onDeleteCollection,
  onUpdateOrderStatus,
  onUpdatePaymentStatus,
  onUpdateOrderNotes,
  onBulkUpdateOrderStatus,
  onCreateOrder,
  onSaveDraftOrder,
  onDeleteDraftOrder,
  onConvertDraftToOrder,
  onSaveAbandonedCheckout,
  onUpdateAbandonedCheckoutStatus,
  onSaveReturnRefund,
  onUpdateReturnRefundStatus,
  onSaveShippingSettings,
  onUpdateStoreTheme,
  onUpdateStorePlan,
  onAddSubscriptionPayment,
  onLogout,
  userEmail,
  userName,
}) => {
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isSupportChatOpen, setIsSupportChatOpen] = useState(false);

  const pendingOrdersCount = orders.filter(
    (o) => o.storeId === activeStore.id && o.orderStatus === 'pending'
  ).length;

  const storeProducts = products.filter((p) => p.storeId === activeStore.id);

  return (
    <div className="min-h-screen bg-[#f6f6f7] flex">
      {/* 1. Left Sidebar (Shopify Inspiration: Fixed desktop, drawer on mobile) */}
      <MerchantSidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeStore={activeStore}
        stores={stores}
        onSelectStore={onSelectStore}
        language={language}
        onOpenStorefront={onOpenStorefront}
        onOpenSupportChat={() => setIsSupportChatOpen(true)}
        onLogout={onLogout}
        pendingOrdersCount={pendingOrdersCount}
        totalProductsCount={storeProducts.length}
        isMobileOpen={isMobileSidebarOpen}
        setIsMobileOpen={setIsMobileSidebarOpen}
        userEmail={userEmail}
        userName={userName}
      />

      {/* 2. Main Content Wrapper */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-60">
        {/* Top Header Navigation */}
        <MerchantTopNav
          activeStore={activeStore}
          language={language}
          onToggleLanguage={onToggleLanguage || (() => {})}
          onOpenStorefront={onOpenStorefront}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          onLogout={onLogout}
          onNavigateTab={setActiveTab}
          userEmail={userEmail}
          userName={userName}
          pendingOrdersCount={pendingOrdersCount}
        />

        {/* Dynamic Main Dashboard View Body */}
        <main className="flex-1 p-3 sm:p-5 lg:p-6 w-full">
          {activeTab === 'overview' && (
            <DashboardOverview
              activeStore={activeStore}
              products={products}
              orders={orders}
              customers={customers}
              userName={userName}
              userEmail={userEmail}
              language={language}
              onNavigateTab={setActiveTab}
              onOpenStorefront={onOpenStorefront}
              onOpenAddProduct={() => setActiveTab('products')}
              onUpdateOrderStatus={onUpdateOrderStatus}
            />
          )}

          {activeTab === 'orders' && (
            <ErrorBoundary fallbackTitle={language === 'bn' ? 'অর্ডারসমূহ লোড করতে ত্রুটি হয়েছে' : 'Error loading Orders'}>
              <OrdersManager
                orders={Array.isArray(orders) ? orders : []}
                products={Array.isArray(products) ? products : []}
                customers={Array.isArray(customers) ? customers : []}
                language={language}
                activeStore={activeStore}
                shippingSettings={shippingSettings}
                onUpdateOrderStatus={onUpdateOrderStatus}
                onUpdatePaymentStatus={onUpdatePaymentStatus}
                onUpdateOrderNotes={onUpdateOrderNotes}
                onCreateOrder={onCreateOrder}
                onBulkUpdateOrderStatus={onBulkUpdateOrderStatus}
                onOpenReturnModal={(ord) => setActiveTab('orders_returns')}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'orders_drafts' && (
            <ErrorBoundary fallbackTitle={language === 'bn' ? 'ড্রাফট অর্ডার লোড করতে ত্রুটি হয়েছে' : 'Error loading Draft Orders'}>
              <DraftOrdersManager
                draftOrders={Array.isArray(draftOrders) ? draftOrders : []}
                products={Array.isArray(products) ? products : []}
                customers={Array.isArray(customers) ? customers : []}
                activeStore={activeStore}
                language={language}
                shippingSettings={shippingSettings}
                onSaveDraftOrder={onSaveDraftOrder || (() => {})}
                onDeleteDraftOrder={onDeleteDraftOrder || (() => {})}
                onConvertDraftToOrder={onConvertDraftToOrder || (() => {})}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'orders_abandoned' && (
            <ErrorBoundary fallbackTitle={language === 'bn' ? 'পরিত্যক্ত চেকআউট লোড করতে ত্রুটি হয়েছে' : 'Error loading Abandoned Checkouts'}>
              <AbandonedCheckoutsManager
                checkouts={Array.isArray(abandonedCheckouts) ? abandonedCheckouts : []}
                activeStore={activeStore}
                language={language}
                onUpdateStatus={onUpdateAbandonedCheckoutStatus || (() => {})}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'orders_returns' && (
            <ErrorBoundary fallbackTitle={language === 'bn' ? 'রিটার্ন ও রিফান্ড লোড করতে ত্রুটি হয়েছে' : 'Error loading Returns & Refunds'}>
              <ReturnsRefundsManager
                returns={Array.isArray(returnsRefunds) ? returnsRefunds : []}
                orders={Array.isArray(orders) ? orders : []}
                activeStore={activeStore}
                language={language}
                onSaveReturn={onSaveReturnRefund || (() => {})}
                onUpdateReturnStatus={onUpdateReturnRefundStatus || (() => {})}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'shipping' && (
            <ErrorBoundary fallbackTitle={language === 'bn' ? 'শিপিং সেটিংস লোড করতে ত্রুটি হয়েছে' : 'Error loading Shipping Settings'}>
              <ShippingDeliverySettings
                settings={shippingSettings}
                activeStore={activeStore}
                language={language}
                onSaveSettings={onSaveShippingSettings || (() => {})}
              />
            </ErrorBoundary>
          )}

          {activeTab === 'products_collections' && (
            <ErrorBoundary fallbackTitle={language === 'bn' ? 'কালেকশন লোড করতে ত্রুটি হয়েছে' : 'Error loading Collections'}>
              <CollectionsManager
                activeStore={activeStore}
                collections={Array.isArray(collections) ? collections : []}
                products={products}
                language={language}
                onAddCollection={onAddCollection || (() => {})}
                onUpdateCollection={onUpdateCollection || (() => {})}
                onDeleteCollection={onDeleteCollection || (() => {})}
              />
            </ErrorBoundary>
          )}

          {(activeTab === 'products_inventory' || (activeTab as string) === 'inventory') && (
            <ErrorBoundary fallbackTitle={language === 'bn' ? 'ইনভেন্টরি লোড করতে ত্রুটি হয়েছে' : 'Error loading Inventory'}>
              <InventoryManager
                activeStore={activeStore}
                products={Array.isArray(products) ? products : []}
                orders={Array.isArray(orders) ? orders : []}
                language={language}
                onUpdateProduct={onUpdateProduct}
              />
            </ErrorBoundary>
          )}

          {(activeTab === 'products' || (activeTab.startsWith('products_') && activeTab !== 'products_collections' && activeTab !== 'products_inventory' && (activeTab as string) !== 'inventory')) && (
            <ProductsManager
              products={products}
              language={language}
              activeStore={activeStore}
              onAddProduct={onAddProduct}
              onUpdateProduct={onUpdateProduct}
              onDeleteProduct={onDeleteProduct}
            />
          )}

          {activeTab === 'customers' && (
            <CustomersManager
              customers={customers}
              language={language}
              activeStore={activeStore}
            />
          )}

          {(activeTab === 'growth' || activeTab === 'analytics') && (
            <AnalyticsView
              orders={orders}
              language={language}
              activeStore={activeStore}
            />
          )}

          {activeTab === 'discounts' && (
            <DiscountsManager
              language={language}
            />
          )}

          {(activeTab === 'content' || activeTab === 'flow') && (
            <ContentManager
              language={language}
            />
          )}

          {activeTab === 'markets' && (
            <MarketsManager
              language={language}
              activeStore={activeStore}
            />
          )}

          {(activeTab === 'customizer' || activeTab === 'pos') && (
            <StoreCustomizer
              activeStore={activeStore}
              language={language}
              onUpdateStoreTheme={onUpdateStoreTheme}
              onOpenStorefront={onOpenStorefront}
            />
          )}

          {(activeTab === 'copilot' || activeTab === 'agentic') && (
            <AICopilot
              activeStore={activeStore}
              language={language}
            />
          )}

          {activeTab === 'billing' && (
            <SubscriptionBilling
              activeStore={activeStore}
              language={language}
              onUpdatePlan={(newPlan) => {
                if (onUpdateStorePlan) onUpdateStorePlan(activeStore.id, newPlan);
              }}
              onAddSubscriptionPayment={onAddSubscriptionPayment}
            />
          )}

          {activeTab === 'settings' && (
            <StoreSettingsView
              activeStore={activeStore}
              language={language}
              gateways={gateways}
              shippingSettings={shippingSettings}
              onUpdateStoreTheme={onUpdateStoreTheme}
              onSaveShippingSettings={onSaveShippingSettings}
            />
          )}
        </main>
      </div>

      {/* Real-time Customer Support Live Chat Modal */}
      <LiveSupportChat
        isOpen={isSupportChatOpen}
        onClose={() => setIsSupportChatOpen(false)}
        onToggle={() => setIsSupportChatOpen(!isSupportChatOpen)}
        language={language}
        activeStore={activeStore}
      />
    </div>
  );
};
