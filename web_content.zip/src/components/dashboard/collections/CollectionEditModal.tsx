import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Image as ImageIcon, 
  Upload, 
  Check, 
  AlertCircle, 
  Package, 
  Search,
  Layers,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { 
  Collection, 
  CollectionCondition, 
  CollectionConditionField, 
  CollectionConditionOperator, 
  Product, 
  Store, 
  Language 
} from '../../../types';

interface CollectionEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeStore: Store;
  products: Product[];
  language: Language;
  editingCollection?: Collection | null;
  onSave: (collection: Omit<Collection, 'id'> | Collection) => void;
}

export const CollectionEditModal: React.FC<CollectionEditModalProps> = ({
  isOpen,
  onClose,
  activeStore,
  products,
  language,
  editingCollection,
  onSave
}) => {
  const isBn = language === 'bn';

  // Form states - Default to 'manual' as specified in requirements
  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState('');
  const [type, setType] = useState<'manual' | 'automated'>('manual');
  const [conditionMatch, setConditionMatch] = useState<'all' | 'any'>('all');
  const [conditions, setConditions] = useState<CollectionCondition[]>([
    { field: 'price', operator: 'less_than', value: '800' }
  ]);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [manualSearchQuery, setManualSearchQuery] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Defensive array checks
  const storeProducts = useMemo(() => {
    const list = Array.isArray(products) ? products : [];
    return list.filter((p) => p && p.storeId === activeStore?.id);
  }, [products, activeStore?.id]);

  // Reset or initialize form
  useEffect(() => {
    if (editingCollection) {
      setTitle(editingCollection.title || '');
      setTitleBn(editingCollection.titleBn || '');
      setDescription(editingCollection.description || '');
      setImage(editingCollection.image || '');
      setType(editingCollection.type || 'manual');
      setConditionMatch(editingCollection.conditionMatch || 'all');
      setConditions(
        editingCollection.conditions && editingCollection.conditions.length > 0
          ? editingCollection.conditions
          : [{ field: 'price', operator: 'less_than', value: '800' }]
      );
      setSelectedProductIds(Array.isArray(editingCollection.productIds) ? editingCollection.productIds : []);
    } else {
      setTitle('');
      setTitleBn('');
      setDescription('');
      setImage('');
      setType('manual'); // Default: Manual
      setConditionMatch('all');
      setConditions([
        { field: 'price', operator: 'less_than', value: '800' }
      ]);
      setSelectedProductIds([]);
    }
    setErrorMsg('');
    setManualSearchQuery('');
  }, [editingCollection, isOpen]);

  // Calculate matching products for preview
  const matchingProducts = useMemo(() => {
    if (type === 'manual') {
      return storeProducts.filter((p) => selectedProductIds.includes(p.id));
    }

    if (!conditions || conditions.length === 0) {
      return storeProducts;
    }

    return storeProducts.filter((p) => {
      const matchResults = conditions.map((cond) => {
        const val = (cond.value || '').trim().toLowerCase();
        if (!val) return true;

        switch (cond.field) {
          case 'price': {
            const numVal = parseFloat(val);
            if (isNaN(numVal)) return true;
            const price = p.price || 0;
            if (cond.operator === 'less_than') return price < numVal;
            if (cond.operator === 'less_than_or_equal') return price <= numVal;
            if (cond.operator === 'greater_than') return price > numVal;
            if (cond.operator === 'greater_than_or_equal') return price >= numVal;
            if (cond.operator === 'equals') return price === numVal;
            if (cond.operator === 'not_equals') return price !== numVal;
            return true;
          }
          case 'inventory': {
            const numVal = parseInt(val, 10);
            if (isNaN(numVal)) return true;
            const stock = p.stock || 0;
            if (cond.operator === 'greater_than') return stock > numVal;
            if (cond.operator === 'greater_than_or_equal') return stock >= numVal;
            if (cond.operator === 'less_than') return stock < numVal;
            if (cond.operator === 'less_than_or_equal') return stock <= numVal;
            if (cond.operator === 'equals') return stock === numVal;
            if (cond.operator === 'not_equals') return stock !== numVal;
            return true;
          }
          case 'category': {
            const cat = (p.category || '').toLowerCase();
            if (cond.operator === 'equals') return cat === val;
            if (cond.operator === 'not_equals') return cat !== val;
            if (cond.operator === 'contains') return cat.includes(val);
            if (cond.operator === 'not_contains') return !cat.includes(val);
            if (cond.operator === 'starts_with') return cat.startsWith(val);
            if (cond.operator === 'ends_with') return cat.endsWith(val);
            return true;
          }
          case 'title': {
            const name = (p.name || '').toLowerCase();
            const nameBn = (p.nameBn || '').toLowerCase();
            if (cond.operator === 'contains') return name.includes(val) || nameBn.includes(val);
            if (cond.operator === 'not_contains') return !name.includes(val) && !nameBn.includes(val);
            if (cond.operator === 'equals') return name === val;
            if (cond.operator === 'not_equals') return name !== val;
            if (cond.operator === 'starts_with') return name.startsWith(val);
            if (cond.operator === 'ends_with') return name.endsWith(val);
            return true;
          }
          case 'sku': {
            const sku = (p.sku || '').toLowerCase();
            if (cond.operator === 'contains') return sku.includes(val);
            if (cond.operator === 'not_contains') return !sku.includes(val);
            if (cond.operator === 'equals') return sku === val;
            if (cond.operator === 'not_equals') return sku !== val;
            if (cond.operator === 'starts_with') return sku.startsWith(val);
            if (cond.operator === 'ends_with') return sku.endsWith(val);
            return true;
          }
          case 'status': {
            const status = (p.status || 'active').toLowerCase();
            if (cond.operator === 'equals') return status === val;
            if (cond.operator === 'not_equals') return status !== val;
            return true;
          }
          default:
            return true;
        }
      });

      if (conditionMatch === 'all') {
        return matchResults.every(Boolean);
      } else {
        return matchResults.some(Boolean);
      }
    });
  }, [type, selectedProductIds, storeProducts, conditions, conditionMatch]);

  // Filtered products for manual picker (search by: Title, SKU, Category) - Hook #14 called unconditionally
  const filteredManualProducts = useMemo(() => {
    if (!manualSearchQuery.trim()) return storeProducts;
    const q = manualSearchQuery.toLowerCase().trim();
    return storeProducts.filter((p) => {
      const matchTitle = (p.name || '').toLowerCase().includes(q) || (p.nameBn || '').toLowerCase().includes(q);
      const matchSku = (p.sku || '').toLowerCase().includes(q);
      const matchCat = (p.category || '').toLowerCase().includes(q) || (p.categoryBn || '').toLowerCase().includes(q);
      return matchTitle || matchSku || matchCat;
    });
  }, [storeProducts, manualSearchQuery]);

  // Handlers for condition rows
  const handleAddCondition = () => {
    setConditions([
      ...conditions,
      { field: 'price', operator: 'greater_than', value: '200' }
    ]);
  };

  const handleUpdateCondition = (index: number, updated: Partial<CollectionCondition>) => {
    setConditions(conditions.map((c, i) => (i === index ? { ...c, ...updated } : c)));
  };

  const handleRemoveCondition = (index: number) => {
    if (conditions.length <= 1) return;
    setConditions(conditions.filter((_, i) => i !== index));
  };

  // Image Upload handler
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 800;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          setImage(canvas.toDataURL('image/jpeg', 0.8));
        }
      };
      if (typeof event.target?.result === 'string') {
        img.src = event.target.result;
      }
    };
    reader.readAsDataURL(file);
  };

  // Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg(isBn ? 'অনুগ্রহ করে কালেকশনের শিরোনাম লিখুন।' : 'Please enter a collection title.');
      return;
    }

    const payload = {
      storeId: activeStore.id,
      title: title.trim(),
      titleBn: titleBn.trim() || undefined,
      description: description.trim() || undefined,
      image: image.trim() || undefined,
      type,
      conditionMatch: type === 'automated' ? conditionMatch : undefined,
      conditions: type === 'automated' ? conditions : undefined,
      productIds: type === 'manual' ? selectedProductIds : matchingProducts.map(p => p.id),
      publishedScope: 'web',
      createdAt: editingCollection?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (editingCollection) {
      onSave({
        ...editingCollection,
        ...payload,
      });
    } else {
      onSave(payload);
    }
    onClose();
  };

  // Guard after ALL hooks and handlers
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="h-14 px-5 border-b border-[#e1e3e5] flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-[#1a1a1a]">
                {editingCollection ? (isBn ? 'কালেকশন সম্পাদনা করুন' : 'Edit collection') : (isBn ? 'নতুন কালেকশন তৈরি করুন' : 'Create collection')}
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5 text-xs text-[#202223]">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Title & Description Card */}
          <div className="bg-white rounded-xl border border-[#e1e3e5] p-4 space-y-3.5 shadow-2xs">
            <div>
              <label className="block text-xs font-semibold text-[#202223] mb-1">
                {isBn ? 'শিরোনাম *' : 'Title *'}
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Summer Collection"
                className="w-full px-3 py-2 border border-[#d1d5db] rounded-lg text-xs focus:outline-hidden focus:border-[#008060]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                {isBn ? 'বাংলা শিরোনাম (ঐচ্ছিক)' : 'Bangla Title (Optional)'}
              </label>
              <input
                type="text"
                value={titleBn}
                onChange={(e) => setTitleBn(e.target.value)}
                placeholder="যেমন: গ্রীষ্মকালীন কালেকশন"
                className="w-full px-3 py-2 border border-[#d1d5db] rounded-lg text-xs focus:outline-hidden focus:border-[#008060]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                {isBn ? 'বিবরণ (ঐচ্ছিক)' : 'Description (Optional)'}
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add a summary or description for this collection..."
                className="w-full px-3 py-2 border border-[#d1d5db] rounded-lg text-xs focus:outline-hidden focus:border-[#008060]"
              />
            </div>

            {/* Collection Image */}
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                {isBn ? 'কালেকশন ছবি (ঐচ্ছিক)' : 'Collection Image (Optional)'}
              </label>
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-lg bg-slate-100 border border-[#e1e3e5] flex items-center justify-center overflow-hidden shrink-0">
                  {image ? (
                    <img src={image} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <ImageIcon className="w-6 h-6 text-slate-300" />
                  )}
                </div>
                <div className="flex-1 space-y-1.5">
                  <input
                    type="text"
                    value={image}
                    onChange={(e) => setImage(e.target.value)}
                    placeholder="https://example.com/collection-banner.jpg"
                    className="w-full px-2.5 py-1.5 border border-[#d1d5db] rounded-lg text-xs focus:outline-hidden focus:border-[#008060]"
                  />
                  <div className="flex items-center gap-2">
                    <label className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium cursor-pointer transition-colors">
                      <Upload className="w-3 h-3" />
                      <span>{isBn ? 'ডিভাইস থেকে আপলোড' : 'Upload Image'}</span>
                      <input type="file" accept="image/*" onChange={handleImageFileChange} className="hidden" />
                    </label>
                    {image && (
                      <button
                        type="button"
                        onClick={() => setImage('')}
                        className="text-[11px] text-rose-600 hover:underline cursor-pointer"
                      >
                        {isBn ? 'মুছে ফেলুন' : 'Remove'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Collection Type Selection: Default Manual */}
          <div className="bg-white rounded-xl border border-[#e1e3e5] p-4 space-y-3 shadow-2xs">
            <h3 className="text-xs font-semibold text-[#202223]">
              {isBn ? 'কালেকশনের ধরন' : 'Collection type'}
            </h3>

            <div className="space-y-2">
              {/* Option A: Manual (Default) */}
              <label className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                type === 'manual' 
                  ? 'border-emerald-600 bg-emerald-50/20 shadow-2xs' 
                  : 'border-[#e1e3e5] hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="collectionType"
                  value="manual"
                  checked={type === 'manual'}
                  onChange={() => setType('manual')}
                  className="mt-0.5 text-emerald-600 focus:ring-0 cursor-pointer"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-[#202223]">
                      {isBn ? 'ম্যানুয়াল (Manual)' : 'Manual'}
                    </span>
                    {type === 'manual' && (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                        {isBn ? 'ডিফল্ট' : 'Default'}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#6d7175] mt-0.5 leading-relaxed">
                    {isBn 
                      ? 'পণ্যসমূহকে একটি একটি করে এই কালেকশনে নিজে যুক্ত করুন।' 
                      : 'Add products to this collection one by one. Only products you manually choose will be included.'}
                  </p>
                </div>
              </label>

              {/* Option B: Automated */}
              <label className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                type === 'automated' 
                  ? 'border-emerald-600 bg-emerald-50/20 shadow-2xs' 
                  : 'border-[#e1e3e5] hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="collectionType"
                  value="automated"
                  checked={type === 'automated'}
                  onChange={() => setType('automated')}
                  className="mt-0.5 text-emerald-600 focus:ring-0 cursor-pointer"
                />
                <div className="flex-1">
                  <span className="font-semibold text-xs text-[#202223]">
                    {isBn ? 'অটোমেটেড (Automated)' : 'Automated'}
                  </span>
                  <p className="text-[11px] text-[#6d7175] mt-0.5 leading-relaxed">
                    {isBn 
                      ? 'শর্তাবলীর ভিত্তিতে বিদ্যমান এবং ভবিষ্যতের পণ্যসমূহ স্বয়ংক্রিয়ভাবে যুক্ত হবে।' 
                      : 'Existing and future products that match the conditions you set will automatically be added.'}
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* ================================================================= */}
          {/* MANUAL COLLECTION PRODUCTS SECTION                                 */}
          {/* ================================================================= */}
          {type === 'manual' && (
            <div className="bg-white rounded-xl border border-[#e1e3e5] p-4 space-y-3.5 shadow-2xs">
              <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                <div>
                  <h3 className="text-xs font-semibold text-[#202223]">
                    {isBn ? 'পণ্যসমূহ' : 'Products'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {isBn ? 'এই কালেকশনে যুক্ত করতে পণ্যসমূহ নির্বাচন করুন।' : 'Select products to include in this collection.'}
                  </p>
                </div>

                {/* Selected Products Counter (Required) */}
                <div className="flex items-center gap-1.5 px-3 py-1 bg-[#f1f1f1] rounded-full text-slate-800 text-xs font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Selected products: {selectedProductIds.length}</span>
                </div>
              </div>

              {/* Product Search (by Title, SKU, Category) */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={manualSearchQuery}
                  onChange={(e) => setManualSearchQuery(e.target.value)}
                  placeholder="Search products by title, SKU, or category..."
                  className="w-full pl-8.5 pr-8 py-2 border border-[#d1d5db] rounded-lg text-xs focus:outline-hidden focus:border-[#008060]"
                />
                {manualSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setManualSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Products list with Checkbox, Thumbnail, Title, Status, Inventory */}
              <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100 max-h-60 overflow-y-auto bg-white">
                {filteredManualProducts.length === 0 ? (
                  <div className="p-6 text-center text-slate-400 text-xs">
                    <Package className="w-8 h-8 mx-auto text-slate-300 mb-1.5" />
                    <p>{isBn ? 'কোনো পণ্য পাওয়া যায়নি।' : 'No products found matching your search.'}</p>
                  </div>
                ) : (
                  filteredManualProducts.map((p) => {
                    const isSelected = selectedProductIds.includes(p.id);
                    const stock = p.stock || 0;
                    const status = p.status || 'active';

                    return (
                      <label
                        key={p.id}
                        className={`flex items-center justify-between p-3 hover:bg-[#f9fafb] cursor-pointer transition-colors ${
                          isSelected ? 'bg-emerald-50/20' : ''
                        }`}
                      >
                        {/* Checkbox, Thumbnail & Title */}
                        <div className="flex items-center gap-3 min-w-0 flex-1 pr-3">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {
                              if (isSelected) {
                                setSelectedProductIds(selectedProductIds.filter((id) => id !== p.id));
                              } else {
                                setSelectedProductIds([...selectedProductIds, p.id]);
                              }
                            }}
                            className="rounded-[4px] border-[#c9cccf] text-slate-900 focus:ring-0 w-4 h-4 cursor-pointer shrink-0"
                          />
                          <div className="w-9 h-9 rounded-md bg-slate-50 border border-[#e1e3e5] overflow-hidden shrink-0 flex items-center justify-center">
                            {p.image ? (
                              <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                            ) : (
                              <Package className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-xs font-medium text-[#202223] leading-tight">
                              {p.name}
                            </p>
                            <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-500">
                              {p.sku && <span>SKU: {p.sku}</span>}
                              {p.category && <span>• {p.category}</span>}
                            </div>
                          </div>
                        </div>

                        {/* Status & Inventory */}
                        <div className="flex items-center gap-3 shrink-0">
                          {/* Status Badge */}
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                            status === 'active' 
                              ? 'bg-emerald-100 text-emerald-700' 
                              : 'bg-amber-100 text-amber-700'
                          }`}>
                            {status}
                          </span>

                          {/* Inventory */}
                          <div className="text-right w-20">
                            <span className={`text-[11px] font-medium ${stock > 0 ? 'text-slate-700' : 'text-rose-600'}`}>
                              {stock > 0 ? `${stock} in stock` : 'Out of stock'}
                            </span>
                          </div>
                        </div>
                      </label>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* AUTOMATED COLLECTION CONDITIONS SECTION                           */}
          {/* ================================================================= */}
          {type === 'automated' && (
            <div className="bg-white rounded-xl border border-[#e1e3e5] p-4 space-y-3.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-[#202223]">
                  {isBn ? 'শর্তাবলী (Conditions)' : 'Conditions'}
                </h3>
                <div className="flex items-center gap-3 text-[11px]">
                  <span>Products must match:</span>
                  <label className="inline-flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="conditionMatch"
                      value="all"
                      checked={conditionMatch === 'all'}
                      onChange={() => setConditionMatch('all')}
                      className="text-slate-900 focus:ring-0 cursor-pointer"
                    />
                    <span>All conditions</span>
                  </label>
                  <label className="inline-flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="conditionMatch"
                      value="any"
                      checked={conditionMatch === 'any'}
                      onChange={() => setConditionMatch('any')}
                      className="text-slate-900 focus:ring-0 cursor-pointer"
                    />
                    <span>Any condition</span>
                  </label>
                </div>
              </div>

              {/* Conditions List */}
              <div className="space-y-2.5">
                {conditions.map((cond, index) => (
                  <div key={index} className="flex items-center gap-2">
                    {/* FIELD Dropdown */}
                    <select
                      value={cond.field}
                      onChange={(e) => handleUpdateCondition(index, { field: e.target.value as CollectionConditionField })}
                      className="px-2.5 py-1.5 border border-[#d1d5db] rounded-lg text-xs bg-white text-[#202223] w-36 shrink-0 cursor-pointer"
                    >
                      <option value="title">Product title</option>
                      <option value="category">Category</option>
                      <option value="price">Price</option>
                      <option value="inventory">Inventory</option>
                      <option value="sku">SKU</option>
                      <option value="status">Status</option>
                    </select>

                    {/* OPERATOR Dropdown (Supports all requested operators) */}
                    <select
                      value={cond.operator}
                      onChange={(e) => handleUpdateCondition(index, { operator: e.target.value as CollectionConditionOperator })}
                      className="px-2.5 py-1.5 border border-[#d1d5db] rounded-lg text-xs bg-white text-[#202223] w-48 shrink-0 cursor-pointer"
                    >
                      {cond.field === 'price' || cond.field === 'inventory' ? (
                        <>
                          <option value="equals">is equal to</option>
                          <option value="not_equals">is not equal to</option>
                          <option value="greater_than">greater than</option>
                          <option value="less_than">less than</option>
                          <option value="greater_than_or_equal">greater than or equal to</option>
                          <option value="less_than_or_equal">less than or equal to</option>
                        </>
                      ) : cond.field === 'status' ? (
                        <>
                          <option value="equals">is equal to</option>
                          <option value="not_equals">is not equal to</option>
                        </>
                      ) : (
                        <>
                          <option value="equals">is equal to</option>
                          <option value="not_equals">is not equal to</option>
                          <option value="contains">contains</option>
                          <option value="not_contains">does not contain</option>
                          <option value="starts_with">starts with</option>
                          <option value="ends_with">ends with</option>
                        </>
                      )}
                    </select>

                    {/* VALUE Input */}
                    <div className="flex-1 relative">
                      <input
                        type={cond.field === 'price' || cond.field === 'inventory' ? 'number' : 'text'}
                        value={cond.value}
                        onChange={(e) => handleUpdateCondition(index, { value: e.target.value })}
                        placeholder={cond.field === 'price' ? 'e.g. 800' : cond.field === 'status' ? 'active' : 'Value...'}
                        className="w-full px-2.5 py-1.5 border border-[#d1d5db] rounded-lg text-xs focus:outline-hidden focus:border-[#008060]"
                      />
                    </div>

                    {/* Delete condition */}
                    {conditions.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveCondition(index)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                        title="Delete condition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}

                <button
                  type="button"
                  onClick={handleAddCondition}
                  className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#d1d5db] text-[#202223] hover:bg-slate-50 text-xs font-medium transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Add another condition</span>
                </button>
              </div>

              {/* Matching Summary Badge */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-[#6d7175]">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Matching products under current conditions:</span>
                </span>
                <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-full">
                  {matchingProducts.length} {matchingProducts.length === 1 ? 'product' : 'products'}
                </span>
              </div>
            </div>
          )}

          {/* Action Buttons: Cancel and Save collection */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg border border-[#d1d5db] text-[#202223] hover:bg-slate-50 text-xs font-medium transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#2c2c2c] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              {editingCollection ? 'Save changes' : 'Save collection'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
