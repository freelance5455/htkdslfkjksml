import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { Collection, Language } from '../../../types';

interface DeleteCollectionConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  collection: Collection | null;
  onConfirm: (collectionId: string) => void;
  language: Language;
}

export const DeleteCollectionConfirmModal: React.FC<DeleteCollectionConfirmModalProps> = ({
  isOpen,
  onClose,
  collection,
  onConfirm,
  language
}) => {
  const isBn = language === 'bn';

  if (!isOpen || !collection) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center shrink-0 border border-rose-100">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900 text-sm">
              {isBn ? 'কালেকশন মুছে ফেলতে চান?' : 'Delete collection?'}
            </h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              {isBn 
                ? `আপনি কি নিশ্চিত যে "${collection.title}" কালেকশনটি মুছে ফেলতে চান? এতে থাকা পণ্যসমূহ মুছে যাবে না।`
                : `Are you sure you want to delete "${collection.title}"? Products inside this collection will not be deleted.`}
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 text-xs">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors"
          >
            {isBn ? 'বাতিল' : 'Cancel'}
          </button>
          <button
            type="button"
            onClick={() => {
              onConfirm(collection.id);
              onClose();
            }}
            className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold transition-colors shadow-xs"
          >
            {isBn ? 'মুছে ফেলুন' : 'Delete'}
          </button>
        </div>
      </div>
    </div>
  );
};
