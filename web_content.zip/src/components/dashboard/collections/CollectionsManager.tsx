import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Trash2, 
  Tag, 
  ChevronDown, 
  X, 
  Check, 
  ArrowUpDown, 
  Layers, 
  Columns3, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles,
  ExternalLink,
  Edit3,
  Image as ImageIcon,
  FolderTree
} from 'lucide-react';
import { Collection, Store, Product, Language } from '../../../types';
import { CollectionEditModal } from './CollectionEditModal';
import { DeleteCollectionConfirmModal } from './DeleteCollectionConfirmModal';

interface CollectionsManagerProps {
  activeStore: Store;
  collections: Collection[];
  products: Product[];
  language: Language;
  onAddCollection: (collection: Omit<Collection, 'id'>) => void;
  onUpdateCollection: (collection: Collection) => void;
  onDeleteCollection: (collectionId: string) => void;
  onBulkDeleteCollections?: (collectionIds: string[]) => void;
}

export const CollectionsManager: React.FC<CollectionsManagerProps> = ({
  activeStore,
  collections,
  products,
  language,
  onAddCollection,
  onUpdateCollection,
  onDeleteCollection,
  onBulkDeleteCollections
}) => {
  const isBn = language === 'bn';

  // 1. UI & Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'automated' | 'manual'>('all');
  const [isTypeFilterOpen, setIsTypeFilterOpen] = useState(false);
  const [selectedCollectionIds, setSelectedCollectionIds] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'title_asc' | 'title_desc' | 'products_high' | 'newest'>('title_asc');

  // Pagination (Matches Shopify standard)
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  // 2. Modals
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingCollection, setEditingCollection] = useState<Collection | null>(null);
  const [deletingCollection, setDeletingCollection] = useState<Collection | null>(null);

  // Dropdown ref
  const typeFilterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (typeFilterRef.current && !typeFilterRef.current.contains(event.target as Node)) {
        setIsTypeFilterOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 0. Defensive input normalization
  const safeCollections = useMemo(() => {
    if (!Array.isArray(collections)) return [];
    return collections.filter((c) => c && typeof c === 'object' && typeof c.id === 'string');
  }, [collections]);

  const safeProducts = useMemo(() => {
    if (!Array.isArray(products)) return [];
    return products.filter((p) => p && typeof p === 'object' && typeof p.id === 'string');
  }, [products]);

  // Filter store products
  const storeProducts = useMemo(() => {
    return safeProducts.filter((p) => p && p.storeId === activeStore?.id);
  }, [safeProducts, activeStore?.id]);

  // Filter store collections
  const storeCollections = useMemo(() => {
    return safeCollections.filter((c) => c && c.storeId === activeStore?.id);
  }, [safeCollections, activeStore?.id]);

  // Calculate actual product count for each collection
  const collectionProductCounts = useMemo(() => {
    const counts: Record<string, number> = {};

    storeCollections.forEach((col) => {
      if (!col || !col.id) return;
      if (col.type === 'manual') {
        const pIds = Array.isArray(col.productIds) ? col.productIds : [];
        const validIds = pIds.filter((id) =>
          storeProducts.some((p) => p && p.id === id)
        );
        counts[col.id] = validIds.length;
      } else {
        // Automated Collection Evaluation
        const colConditions = Array.isArray(col.conditions) ? col.conditions : [];
        if (colConditions.length === 0) {
          counts[col.id] = storeProducts.length;
          return;
        }

        const matchCount = storeProducts.filter((p) => {
          if (!p) return false;
          const matchResults = colConditions.map((cond) => {
            if (!cond) return true;
            const val = (cond.value || '').trim().toLowerCase();
            if (!val) return true;

            switch (cond.field) {
              case 'price': {
                const num = parseFloat(val);
                if (isNaN(num)) return true;
                const price = p.price || 0;
                if (cond.operator === 'less_than') return price < num;
                if (cond.operator === 'less_than_or_equal') return price <= num;
                if (cond.operator === 'greater_than') return price > num;
                if (cond.operator === 'greater_than_or_equal') return price >= num;
                if (cond.operator === 'equals') return price === num;
                if (cond.operator === 'not_equals') return price !== num;
                return true;
              }
              case 'inventory': {
                const stock = parseInt(val, 10);
                if (isNaN(stock)) return true;
                const pStock = p.stock || 0;
                if (cond.operator === 'greater_than') return pStock > stock;
                if (cond.operator === 'greater_than_or_equal') return pStock >= stock;
                if (cond.operator === 'less_than') return pStock < stock;
                if (cond.operator === 'less_than_or_equal') return pStock <= stock;
                if (cond.operator === 'equals') return pStock === stock;
                if (cond.operator === 'not_equals') return pStock !== stock;
                return true;
              }
              case 'category': {
                const cat = (p.category || '').toLowerCase();
                if (cond.operator === 'equals') return cat === val;
                if (cond.operator === 'not_equals') return cat !== val;
                if (cond.operator === 'contains') return cat.includes(val);
                if (cond.operator === 'not_contains') return !cat.includes(val);
                if (cond.operator === 'starts_with') return cat.startsWith(val);
                if (cond.operator === 'ends_with') return cat.endsWith(val);
                return true;
              }
              case 'title': {
                const name = (p.name || '').toLowerCase();
                const nameBn = (p.nameBn || '').toLowerCase();
                if (cond.operator === 'contains') return name.includes(val) || nameBn.includes(val);
                if (cond.operator === 'not_contains') return !name.includes(val) && !nameBn.includes(val);
                if (cond.operator === 'equals') return name === val;
                if (cond.operator === 'not_equals') return name !== val;
                if (cond.operator === 'starts_with') return name.startsWith(val);
                if (cond.operator === 'ends_with') return name.endsWith(val);
                return true;
              }
              case 'sku': {
                const sku = (p.sku || '').toLowerCase();
                if (cond.operator === 'contains') return sku.includes(val);
                if (cond.operator === 'not_contains') return !sku.includes(val);
                if (cond.operator === 'equals') return sku === val;
                if (cond.operator === 'not_equals') return sku !== val;
                if (cond.operator === 'starts_with') return sku.startsWith(val);
                if (cond.operator === 'ends_with') return sku.endsWith(val);
                return true;
              }
              case 'status': {
                const status = (p.status || 'active').toLowerCase();
                if (cond.operator === 'equals') return status === val;
                if (cond.operator === 'not_equals') return status !== val;
                return true;
              }
              default:
                return true;
            }
          });

          if (col.conditionMatch === 'all') {
            return matchResults.every(Boolean);
          } else {
            return matchResults.some(Boolean);
          }
        }).length;

        counts[col.id] = matchCount;
      }
    });

    return counts;
  }, [storeCollections, storeProducts]);

  // Format conditions display text (Matches Screenshot: "Price is less than ৳800.00", "Price is greater than ৳200.00")
  const formatConditionText = (cond: { field: string; operator: string; value: string }) => {
    let opText = '';
    switch (cond.operator) {
      case 'less_than': opText = 'is less than'; break;
      case 'less_than_or_equal': opText = 'is less than or equal to'; break;
      case 'greater_than': opText = 'is greater than'; break;
      case 'greater_than_or_equal': opText = 'is greater than or equal to'; break;
      case 'equals': opText = 'is equal to'; break;
      case 'not_equals': opText = 'is not equal to'; break;
      case 'contains': opText = 'contains'; break;
      case 'not_contains': opText = 'does not contain'; break;
      case 'starts_with': opText = 'starts with'; break;
      case 'ends_with': opText = 'ends with'; break;
      default: opText = cond.operator;
    }

    if (cond.field === 'price') {
      const num = parseFloat(cond.value);
      const formattedNum = isNaN(num) ? cond.value : num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      return `Price ${opText} ৳${formattedNum}`;
    }
    if (cond.field === 'inventory') {
      return `Inventory ${opText} ${cond.value}`;
    }
    if (cond.field === 'title') {
      return `Product title ${opText} "${cond.value}"`;
    }
    if (cond.field === 'category') {
      return `Category ${opText} "${cond.value}"`;
    }
    if (cond.field === 'sku') {
      return `SKU ${opText} "${cond.value}"`;
    }
    if (cond.field === 'status') {
      return `Status ${opText} ${cond.value}`;
    }
    return `${cond.field} ${opText} ${cond.value}`;
  };

  // Filtered & Sorted Collections
  const filteredCollections = useMemo(() => {
    return storeCollections
      .filter((col) => {
        // 1. Type filter
        if (typeFilter !== 'all' && col.type !== typeFilter) {
          return false;
        }

        // 2. Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchTitle = col.title?.toLowerCase().includes(q);
          const matchTitleBn = col.titleBn?.includes(q);
          const matchDesc = col.description?.toLowerCase().includes(q);
          if (!matchTitle && !matchTitleBn && !matchDesc) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'title_asc') return (a.title || '').localeCompare(b.title || '');
        if (sortBy === 'title_desc') return (b.title || '').localeCompare(a.title || '');
        if (sortBy === 'products_high') {
          const countA = collectionProductCounts[a.id] || 0;
          const countB = collectionProductCounts[b.id] || 0;
          return countB - countA;
        }
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
      });
  }, [storeCollections, typeFilter, searchQuery, sortBy, collectionProductCounts]);

  // Paginated Collections
  const totalPages = Math.ceil(filteredCollections.length / itemsPerPage) || 1;
  const paginatedCollections = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredCollections.slice(start, start + itemsPerPage);
  }, [filteredCollections, currentPage]);

  // Bulk Selection
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedCollectionIds(paginatedCollections.map((c) => c.id));
    } else {
      setSelectedCollectionIds([]);
    }
  };

  const handleToggleSelect = (collectionId: string) => {
    if (selectedCollectionIds.includes(collectionId)) {
      setSelectedCollectionIds(selectedCollectionIds.filter((id) => id !== collectionId));
    } else {
      setSelectedCollectionIds([...selectedCollectionIds, collectionId]);
    }
  };

  // Bulk Delete
  const handleBulkDelete = () => {
    if (window.confirm(isBn ? 'আপনি কি নির্বাচিত কালেকশনসমূহ মুছে ফেলতে চান? পণ্যসমূহ মুছে যাবে না।' : 'Are you sure you want to delete the selected collections? Products will not be deleted.')) {
      if (onBulkDeleteCollections) {
        onBulkDeleteCollections(selectedCollectionIds);
      } else {
        selectedCollectionIds.forEach((id) => onDeleteCollection(id));
      }
      setSelectedCollectionIds([]);
    }
  };

  const handleOpenAddCollection = () => {
    setEditingCollection(null);
    setIsAddEditModalOpen(true);
  };

  const handleOpenEditCollection = (col: Collection) => {
    setEditingCollection(col);
    setIsAddEditModalOpen(true);
  };

  const handleSaveCollection = (colData: Omit<Collection, 'id'> | Collection) => {
    if ('id' in colData) {
      onUpdateCollection(colData as Collection);
    } else {
      onAddCollection(colData as Omit<Collection, 'id'>);
    }
  };

  return (
    <div className="w-full space-y-3 font-sans text-slate-900 pb-16 animate-in fade-in duration-150">
      {/* ========================================================================= */}
      {/* 1. TOP HEADER (Exact Screenshot: Tag icon + Collections | [ Add collection ]) */}
      {/* ========================================================================= */}
      <div className="flex items-center justify-between pt-1 pb-1">
        {/* Left: Tag Icon + Collections Title */}
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded flex items-center justify-center text-slate-700">
            <Tag className="w-4 h-4" />
          </div>
          <h1 className="text-[15px] font-semibold text-[#1a1a1a] tracking-tight">
            Collections
          </h1>
        </div>

        {/* Right: Add Collection Button (Exact Screenshot: Solid Dark Button) */}
        <button
          onClick={handleOpenAddCollection}
          className="px-3.5 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#2c2c2c] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
        >
          Add collection
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 2. MAIN CARD: TOOLBAR & COLLECTIONS TABLE                                 */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-[#e1e3e5] shadow-2xs overflow-hidden">
        {/* Toolbar Header (Exact Screenshot: [All ▼] [Search and filter] [Layout icon]) */}
        <div className="p-2.5 border-b border-[#e1e3e5] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {/* All Filter Dropdown */}
            <div className="relative shrink-0" ref={typeFilterRef}>
              <button
                onClick={() => setIsTypeFilterOpen(!isTypeFilterOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-50 border border-[#d1d5db] text-[#202223] text-xs font-medium cursor-pointer shadow-2xs shrink-0"
              >
                <span>
                  {typeFilter === 'all' ? 'All' : typeFilter === 'automated' ? 'Automated' : 'Manual'}
                </span>
                <ChevronDown className="w-3 h-3 text-[#5c5f62]" />
              </button>

              {isTypeFilterOpen && (
                <div className="absolute left-0 mt-1 w-36 bg-white rounded-lg shadow-lg border border-[#e1e3e5] py-1 z-30 text-xs font-medium">
                  {(['all', 'automated', 'manual'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => {
                        setTypeFilter(t);
                        setIsTypeFilterOpen(false);
                      }}
                      className={`w-full px-3 py-1.5 text-left capitalize hover:bg-slate-50 cursor-pointer flex items-center justify-between ${
                        typeFilter === t ? 'font-semibold text-slate-900 bg-slate-50' : 'text-slate-700'
                      }`}
                    >
                      <span>{t}</span>
                      {typeFilter === t && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Search and Filter Field */}
            <div className="relative flex-1 min-w-0">
              <Search className="w-3.5 h-3.5 text-[#8c9196] absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search and filter"
                className="w-full pl-8 pr-7 py-1.5 bg-white border border-[#d1d5db] rounded-lg text-xs placeholder:text-[#8c9196] text-[#202223] focus:outline-hidden focus:border-[#008060]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Right: Layout/Column Control Icon (Exact Screenshot Icon) */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => setSortBy(sortBy === 'title_asc' ? 'title_desc' : 'title_asc')}
              className="p-1.5 rounded-lg border border-[#d1d5db] text-[#5c5f62] hover:text-[#202223] hover:bg-slate-50 transition-colors cursor-pointer"
              title="Toggle sort direction"
            >
              <Columns3 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Bulk Action Bar (When rows are checked) */}
        {selectedCollectionIds.length > 0 && (
          <div className="bg-[#1a1a1a] text-white px-4 py-2 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white">
                {selectedCollectionIds.length} selected
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleBulkDelete}
                className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-medium text-[11px]"
              >
                Delete collections
              </button>
              <button
                onClick={() => setSelectedCollectionIds([])}
                className="px-2 text-slate-400 hover:text-white"
              >
                Deselect
              </button>
            </div>
          </div>
        )}

        {/* Empty State (Exact match for Requirement 12) */}
        {paginatedCollections.length === 0 ? (
          <div className="py-14 text-center text-xs p-4">
            <FolderTree className="w-10 h-10 mx-auto text-[#8c9196] mb-2" />
            <p className="font-semibold text-[#202223] text-sm">
              {searchQuery ? 'No collections match your search' : 'No collections yet'}
            </p>
            <p className="text-[#6d7175] mt-1 max-w-sm mx-auto">
              {searchQuery 
                ? 'Try changing your search terms or filters.' 
                : 'Add your first collection to organize your products.'}
            </p>
            <button
              onClick={handleOpenAddCollection}
              className="mt-4 px-3.5 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#2c2c2c] text-white text-xs font-semibold"
            >
              Add collection
            </button>
          </div>
        ) : (
          /* ========================================================================= */
          /* 3. COLLECTIONS TABLE (Exact Screenshot: Checkbox | Title | Products | Conditions) */
          /* ========================================================================= */
          <div className="overflow-x-auto w-full">
            <table className="w-full table-fixed text-left text-xs border-collapse">
              <colgroup>
                <col className="w-[6%]" />
                <col className="w-[42%]" />
                <col className="w-[12%]" />
                <col className="w-[40%]" />
              </colgroup>
              <thead>
                <tr className="border-b border-[#e1e3e5] bg-white text-[#5c5f62] font-medium text-[11px] h-9">
                  <th className="px-2 text-center">
                    <input
                      type="checkbox"
                      checked={selectedCollectionIds.length === paginatedCollections.length && paginatedCollections.length > 0}
                      onChange={(e) => handleSelectAll(e.target.checked)}
                      className="rounded-[4px] border-[#c9cccf] text-slate-900 focus:ring-0 cursor-pointer w-4 h-4"
                    />
                  </th>
                  <th className="px-2.5 font-medium">Title</th>
                  <th className="px-2.5 font-medium">Products</th>
                  <th className="px-2.5 font-medium">Conditions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f1f1] text-[#202223]">
                {paginatedCollections.map((col) => {
                  const isChecked = selectedCollectionIds.includes(col.id);
                  const count = collectionProductCounts[col.id] || 0;
                  const conditionsList = col.conditions || [];

                  return (
                    <tr
                      key={col.id}
                      className={`hover:bg-[#f9fafb] transition-colors group cursor-pointer ${
                        isChecked ? 'bg-[#f4f6f8]' : ''
                      }`}
                      onClick={() => handleOpenEditCollection(col)}
                    >
                      {/* Checkbox */}
                      <td 
                        className="px-2 text-center py-3"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleSelect(col.id)}
                          className="rounded-[4px] border-[#c9cccf] text-slate-900 focus:ring-0 cursor-pointer w-4 h-4"
                        />
                      </td>

                      {/* Thumbnail & Title (Exact Screenshot) */}
                      <td className="px-2.5 py-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-[4px] bg-slate-50 border border-[#e1e3e5] flex items-center justify-center shrink-0 overflow-hidden text-slate-400">
                            {col.image ? (
                              <img src={col.image} alt={col.title} className="w-full h-full object-cover" />
                            ) : (
                              <ImageIcon className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="font-medium text-[#202223] text-xs leading-tight truncate hover:underline">
                              {col.title}
                            </p>
                            {col.titleBn && (
                              <p className="text-[10px] text-slate-400 truncate">
                                {col.titleBn}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Products Count (Exact Screenshot Number) */}
                      <td className="px-2.5 py-3 text-xs font-normal text-[#202223]">
                        {count}
                      </td>

                      {/* Conditions (Exact Screenshot: Multi-line conditions format) */}
                      <td className="px-2.5 py-3 text-[11px] text-[#202223] leading-relaxed">
                        {col.type === 'automated' && conditionsList.length > 0 ? (
                          <div className="space-y-0.5">
                            {conditionsList.map((cond, i) => (
                              <p key={i} className="text-[#202223] truncate">
                                {formatConditionText(cond)}
                              </p>
                            ))}
                          </div>
                        ) : (
                          <span className="text-[#8c9196] font-normal">
                            —
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Learn more about collections link (Exact Screenshot footer link) */}
        <div className="py-4 text-center border-t border-[#f1f1f1]">
          <a
            href="https://help.shopify.com/en/manual/products/collections"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-[#5c5f62] hover:text-[#202223] hover:underline"
          >
            Learn more about collections
          </a>
        </div>

        {/* Footer Bar: Pagination `< 1-50 >` and Sidekick Assistant Badge */}
        {paginatedCollections.length > 0 && (
          <div className="p-2.5 border-t border-[#e1e3e5] bg-white flex items-center justify-between text-xs text-[#5c5f62]">
            <div className="flex items-center gap-1.5">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="p-1 rounded hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="text-xs font-normal text-[#202223]">
                {(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, filteredCollections.length)}
              </span>
              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="p-1 rounded hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Sidekick Assistant Pill */}
            <div className="flex items-center gap-2">
              <button 
                onClick={handleOpenAddCollection}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#f1f1f1] hover:bg-[#e5e5e5] text-[#202223] text-[11px] font-medium cursor-pointer transition-colors shadow-2xs"
              >
                <Sparkles className="w-3 h-3 text-[#7938fc]" />
                <span>Work with Sidekick</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 4. MODALS: ADD / EDIT & DELETE CONFIRMATION                                */}
      {/* ========================================================================= */}
      {isAddEditModalOpen && (
        <CollectionEditModal
          isOpen={isAddEditModalOpen}
          onClose={() => {
            setIsAddEditModalOpen(false);
            setEditingCollection(null);
          }}
          activeStore={activeStore}
          products={storeProducts}
          language={language}
          editingCollection={editingCollection}
          onSave={handleSaveCollection}
        />
      )}

      {deletingCollection && (
        <DeleteCollectionConfirmModal
          isOpen={!!deletingCollection}
          onClose={() => setDeletingCollection(null)}
          collection={deletingCollection}
          onConfirm={onDeleteCollection}
          language={language}
        />
      )}
    </div>
  );
};
