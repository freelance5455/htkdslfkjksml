import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  FileText, 
  CheckCircle2, 
  AlertTriangle, 
  Download, 
  AlertCircle,
  ArrowRight,
  FileSpreadsheet
} from 'lucide-react';
import { Product, Language } from '../../../types';
import { InventoryRowItem } from './BulkInventoryUpdateModal';

interface InventoryImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  language: Language;
  onApplyImport: (updates: { productId: string; variantId?: string; newStock: number }[]) => void;
}

interface ParsedRow {
  rowNum: number;
  rawSku: string;
  rawProductName: string;
  rawVariantName: string;
  rawQuantity: string;
  parsedQuantity: number | null;
  matchedItem: InventoryRowItem | null;
  status: 'valid' | 'invalid_qty' | 'not_found';
  message: string;
}

export const InventoryImportModal: React.FC<InventoryImportModalProps> = ({
  isOpen,
  onClose,
  products,
  language,
  onApplyImport
}) => {
  const isBn = language === 'bn';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<'upload' | 'preview'>('upload');
  const [csvContent, setCsvContent] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [parseError, setParseError] = useState<string>('');

  if (!isOpen) return null;

  // Flatten active store products & variants for quick matching lookup
  const inventoryIndex: InventoryRowItem[] = [];
  products.forEach(p => {
    if (p.variants && p.variants.length > 0) {
      p.variants.forEach(v => {
        inventoryIndex.push({
          id: `${p.id}__${v.id}`,
          productId: p.id,
          variantId: v.id,
          isVariant: true,
          productName: p.name,
          variantName: v.name,
          sku: v.sku || p.sku || '',
          available: v.stock,
          image: p.image,
          category: p.category,
          price: v.price || p.price
        });
      });
    } else {
      inventoryIndex.push({
        id: `${p.id}__main`,
        productId: p.id,
        variantId: undefined,
        isVariant: false,
        productName: p.name,
        variantName: undefined,
        sku: p.sku || '',
        available: p.stock,
        image: p.image,
        category: p.category,
        price: p.price
      });
    }
  });

  const handleDownloadSample = () => {
    const headers = 'SKU,Product Name,Variant Name,Available Quantity\n';
    const sampleData = inventoryIndex.slice(0, 3).map(item => {
      const pName = `"${item.productName.replace(/"/g, '""')}"`;
      const vName = item.variantName ? `"${item.variantName.replace(/"/g, '""')}"` : '""';
      const sku = item.sku || 'SAMPLE-SKU-001';
      return `${sku},${pName},${vName},${item.available + 10}`;
    }).join('\n') || 'AUR-PJ-001,"Artisan Silk Panjabi","Size L",50\nAUR-SR-042,"Jamdani Saree","",25';

    const blob = new Blob([headers + sampleData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'inventory_import_sample.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setParseError('');

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setCsvContent(text);
        parseAndValidateCSV(text);
      }
    };
    reader.readAsText(file);
  };

  const parseAndValidateCSV = (text: string) => {
    try {
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      if (lines.length < 2) {
        setParseError(isBn ? 'সিএসভি ফাইলে কমপক্ষে হেডার ও একটি তথ্য সারি থাকতে হবে।' : 'CSV must contain at least a header row and one data row.');
        return;
      }

      // Parse header line to detect column positions
      const headerCols = lines[0].split(',').map(c => c.trim().toLowerCase().replace(/['"]/g, ''));
      let skuIdx = headerCols.findIndex(c => c.includes('sku'));
      let qtyIdx = headerCols.findIndex(c => c.includes('available') || c.includes('quantity') || c.includes('stock') || c.includes('qty'));
      let prodIdx = headerCols.findIndex(c => c.includes('product') || c.includes('title') || c.includes('name'));
      let variantIdx = headerCols.findIndex(c => c.includes('variant'));

      // Defaults if not named explicitly
      if (skuIdx === -1 && qtyIdx === -1) {
        skuIdx = 0;
        prodIdx = 1;
        variantIdx = 2;
        qtyIdx = 3;
      }

      const rows: ParsedRow[] = [];

      for (let i = 1; i < lines.length; i++) {
        const rawLine = lines[i];
        if (!rawLine) continue;

        // Simple CSV splitter respecting quotes
        const cols: string[] = [];
        let inQuotes = false;
        let currentCol = '';
        for (let charIndex = 0; charIndex < rawLine.length; charIndex++) {
          const char = rawLine[charIndex];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            cols.push(currentCol.trim().replace(/^"|"$/g, ''));
            currentCol = '';
          } else {
            currentCol += char;
          }
        }
        cols.push(currentCol.trim().replace(/^"|"$/g, ''));

        const rawSku = skuIdx >= 0 && cols[skuIdx] ? cols[skuIdx].trim() : '';
        const rawProductName = prodIdx >= 0 && cols[prodIdx] ? cols[prodIdx].trim() : '';
        const rawVariantName = variantIdx >= 0 && cols[variantIdx] ? cols[variantIdx].trim() : '';
        const rawQty = qtyIdx >= 0 && cols[qtyIdx] ? cols[qtyIdx].trim() : '';

        const qtyNum = parseInt(rawQty, 10);
        const isQtyValid = !isNaN(qtyNum) && qtyNum >= 0;

        // Find match in current inventory
        let matched: InventoryRowItem | null = null;
        if (rawSku) {
          matched = inventoryIndex.find(item => item.sku && item.sku.toLowerCase() === rawSku.toLowerCase()) || null;
        }

        if (!matched && rawProductName) {
          matched = inventoryIndex.find(item => {
            const nameMatch = item.productName.toLowerCase() === rawProductName.toLowerCase();
            if (rawVariantName) {
              return nameMatch && item.variantName?.toLowerCase() === rawVariantName.toLowerCase();
            }
            return nameMatch;
          }) || null;
        }

        let status: 'valid' | 'invalid_qty' | 'not_found' = 'valid';
        let message = isBn ? 'সঠিক' : 'Valid match';

        if (!isQtyValid) {
          status = 'invalid_qty';
          message = isBn ? 'ভুল পরিমাণ' : 'Invalid quantity';
        } else if (!matched) {
          status = 'not_found';
          message = isBn ? 'পণ্য বা SKU পাওয়া যায়নি' : 'Product / SKU not found';
        }

        rows.push({
          rowNum: i + 1,
          rawSku,
          rawProductName,
          rawVariantName,
          rawQuantity: rawQty,
          parsedQuantity: isQtyValid ? qtyNum : null,
          matchedItem: matched,
          status,
          message
        });
      }

      setParsedRows(rows);
      setStep('preview');
    } catch (err: any) {
      setParseError(err.message || (isBn ? 'সিএসভি পার্স করতে ব্যর্থ হয়েছে।' : 'Failed to parse CSV file.'));
    }
  };

  const validRows = parsedRows.filter(r => r.status === 'valid' && r.matchedItem && r.parsedQuantity !== null);

  const handleApply = () => {
    if (validRows.length === 0) return;

    const updates = validRows.map(r => ({
      productId: r.matchedItem!.productId,
      variantId: r.matchedItem!.variantId,
      newStock: r.parsedQuantity!
    }));

    onApplyImport(updates);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200/90 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                {isBn ? 'ইনভেন্টরি সিএসভি ইমপোর্ট' : 'Import Inventory via CSV'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {step === 'upload' 
                  ? (isBn ? 'সিএসভি ফাইল আপলোড করুন' : 'Upload or paste inventory CSV')
                  : `${validRows.length} of ${parsedRows.length} ${isBn ? 'টি সারি আপডেট করার জন্য প্রস্তুত' : 'rows ready to update'}`}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {step === 'upload' ? (
            <div className="space-y-4">
              {parseError && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{parseError}</span>
                </div>
              )}

              {/* Dropzone */}
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-200 hover:border-slate-400 rounded-2xl p-8 text-center cursor-pointer bg-slate-50/50 hover:bg-slate-50 transition-colors group"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,text/csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 group-hover:bg-white flex items-center justify-center text-slate-500 group-hover:text-slate-900 mb-3 transition-colors border border-slate-200">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">
                  {fileName || (isBn ? 'সিএসভি ফাইল নির্বাচন করতে ক্লিক করুন' : 'Click to upload inventory CSV')}
                </h4>
                <p className="text-slate-500 text-xs max-w-sm mx-auto">
                  {isBn ? 'কলাম সমূহ: SKU, Product Name, Variant Name, Available Quantity' : 'Columns: SKU, Product Name, Variant Name, Available Quantity'}
                </p>
              </div>

              {/* Sample Download Bar */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs">
                <div className="flex items-center gap-2 text-slate-700 font-medium">
                  <FileText className="w-4 h-4 text-slate-500" />
                  <span>{isBn ? 'ফরম্যাট দেখতে নমুনা সিএসভি ডাউনলোড করুন' : 'Need a template? Download sample CSV'}</span>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadSample}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 font-bold hover:bg-slate-100 transition-colors shadow-2xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>{isBn ? 'নমুনা ফাইল' : 'Sample CSV'}</span>
                </button>
              </div>

              {/* Manual Paste Textarea Fallback */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {isBn ? 'অথবা সরাসরি সিএসভি টেক্সট পেস্ট করুন:' : 'Or paste CSV text directly:'}
                </label>
                <textarea
                  rows={4}
                  value={csvContent}
                  onChange={(e) => setCsvContent(e.target.value)}
                  placeholder={`SKU,Product Name,Variant Name,Available Quantity\nAUR-PJ-001,"Artisan Silk Panjabi","",30`}
                  className="w-full p-3 font-mono text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-900 text-slate-800"
                />
                {csvContent && (
                  <button
                    type="button"
                    onClick={() => parseAndValidateCSV(csvContent)}
                    className="mt-2 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    {isBn ? 'পার্স এবং প্রিভিউ দেখুন' : 'Parse & Validate'}
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* Preview Step */
            <div className="space-y-4">
              {/* Summary Stats */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/80 text-center">
                  <span className="text-[11px] font-semibold text-emerald-800">{isBn ? 'সঠিক সারি' : 'Ready to Update'}</span>
                  <p className="text-xl font-extrabold text-emerald-700">{validRows.length}</p>
                </div>
                <div className="p-3 rounded-xl bg-rose-50/70 border border-rose-200/80 text-center">
                  <span className="text-[11px] font-semibold text-rose-800">{isBn ? 'ত্রুটিযুক্ত সারি' : 'Errors / Skipped'}</span>
                  <p className="text-xl font-extrabold text-rose-700">{parsedRows.length - validRows.length}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-center">
                  <span className="text-[11px] font-semibold text-slate-700">{isBn ? 'মোট সারি' : 'Total Rows'}</span>
                  <p className="text-xl font-extrabold text-slate-800">{parsedRows.length}</p>
                </div>
              </div>

              {/* Table Preview */}
              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <div className="max-h-60 overflow-y-auto">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
                      <tr>
                        <th className="p-2.5">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                        <th className="p-2.5">SKU</th>
                        <th className="p-2.5">{isBn ? 'পণ্য' : 'Product'}</th>
                        <th className="p-2.5 text-right">{isBn ? 'বর্তমান' : 'Current'}</th>
                        <th className="p-2.5 text-right">{isBn ? 'নতুন স্টক' : 'New Stock'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {parsedRows.map((r, idx) => {
                        const isValid = r.status === 'valid';
                        return (
                          <tr key={idx} className={isValid ? 'hover:bg-slate-50/50' : 'bg-rose-50/30'}>
                            <td className="p-2.5">
                              {isValid ? (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-full">
                                  <CheckCircle2 className="w-3 h-3" />
                                  <span>{isBn ? 'সঠিক' : 'Valid'}</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-100/70 px-2 py-0.5 rounded-full" title={r.message}>
                                  <AlertTriangle className="w-3 h-3" />
                                  <span>{r.message}</span>
                                </span>
                              )}
                            </td>
                            <td className="p-2.5 font-mono text-[11px] text-slate-700">
                              {r.rawSku || (r.matchedItem?.sku) || '-'}
                            </td>
                            <td className="p-2.5 max-w-[180px] truncate text-slate-900 font-medium">
                              {r.matchedItem ? (
                                <span>
                                  {r.matchedItem.productName}
                                  {r.matchedItem.variantName ? ` (${r.matchedItem.variantName})` : ''}
                                </span>
                              ) : (
                                <span className="text-slate-400 italic">
                                  {r.rawProductName || (isBn ? 'খুঁজে পাওয়া যায়নি' : 'Unknown')}
                                </span>
                              )}
                            </td>
                            <td className="p-2.5 text-right font-mono text-slate-500">
                              {r.matchedItem ? r.matchedItem.available : '-'}
                            </td>
                            <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                              {r.parsedQuantity !== null ? r.parsedQuantity : '-'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200/80 text-[11px] text-amber-800 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                <span>
                  {isBn 
                    ? 'শুধুমাত্র স্টক সংখ্যা আপডেট করা হবে। পণ্যের নাম, ছবি, মূল্য বা অন্যান্য তথ্য অপরিবর্তিত থাকবে।'
                    : 'Only available inventory quantities will be updated. Product titles, prices, images, and descriptions will remain unchanged.'}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between">
          {step === 'preview' ? (
            <button
              type="button"
              onClick={() => {
                setStep('upload');
                setParsedRows([]);
              }}
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              ← {isBn ? 'ফাইল পরিবর্তন করুন' : 'Back to upload'}
            </button>
          ) : (
            <div />
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
            {step === 'preview' && (
              <button
                type="button"
                onClick={handleApply}
                disabled={validRows.length === 0}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <span>{isBn ? `${validRows.length}টি আপডেট সম্পন্ন করুন` : `Apply ${validRows.length} Updates`}</span>
                <ArrowRight className="w-3.5 h-3.5 text-emerald-400" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
