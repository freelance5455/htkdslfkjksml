import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Search, 
  Download, 
  Upload, 
  Check, 
  X, 
  AlertTriangle, 
  ChevronsUpDown, 
  Plus, 
  Minus, 
  SlidersHorizontal, 
  CheckCircle2, 
  Layers, 
  Package,
  Edit2,
  ExternalLink,
  HelpCircle,
  MapPin
} from 'lucide-react';
import { Product, Store, Language, Order } from '../../../types';
import { InventoryRowItem, BulkInventoryUpdateModal } from './BulkInventoryUpdateModal';
import { InventoryImportModal } from './InventoryImportModal';

interface InventoryManagerProps {
  activeStore: Store;
  products: Product[];
  orders?: Order[];
  language: Language;
  onUpdateProduct: (product: Product) => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({
  activeStore,
  products = [],
  orders = [],
  language,
  onUpdateProduct
}) => {
  const isBn = language === 'bn';

  // 1. Store Isolation & Defensive Normalization
  const storeProducts = useMemo(() => {
    if (!Array.isArray(products)) return [];
    return products.filter((p) => p && typeof p === 'object' && p.storeId === activeStore?.id);
  }, [products, activeStore?.id]);

  // 2. Compute Committed quantities from active unfulfilled orders
  const committedMap = useMemo(() => {
    const map = new Map<string, number>();
    if (!Array.isArray(orders)) return map;

    const openOrders = orders.filter(
      (o) => o && o.storeId === activeStore?.id && ['pending', 'confirmed', 'processing', 'packed'].includes(o.orderStatus)
    );

    openOrders.forEach((ord) => {
      if (Array.isArray(ord.items)) {
        ord.items.forEach((item) => {
          if (!item.productId) return;
          // Match by variant name or id if present
          if (item.variant) {
            const vKey = `${item.productId}__${item.variant}`;
            map.set(vKey, (map.get(vKey) || 0) + (item.quantity || 1));
          }
          // Also track product-level key
          const mainKey = `${item.productId}__main`;
          map.set(mainKey, (map.get(mainKey) || 0) + (item.quantity || 1));
        });
      }
    });

    return map;
  }, [orders, activeStore?.id]);

  // 3. Flatten Products and Variants into Inventory Rows (Shopify Architecture)
  const allInventoryItems: InventoryRowItem[] = useMemo(() => {
    const list: InventoryRowItem[] = [];

    storeProducts.forEach((prod) => {
      if (Array.isArray(prod.variants) && prod.variants.length > 0) {
        prod.variants.forEach((v) => {
          const rawStock = typeof v.stock === 'number' ? v.stock : 0;
          const committed = committedMap.get(`${prod.id}__${v.name}`) || committedMap.get(`${prod.id}__${v.id}`) || 0;
          const available = Math.max(0, rawStock - committed);
          const onHand = rawStock;
          const unavailable = 0;

          list.push({
            id: `${prod.id}__${v.id}`,
            productId: prod.id,
            variantId: v.id,
            isVariant: true,
            productName: prod.name || (isBn ? 'নামবিহীন পণ্য' : 'Untitled Product'),
            variantName: v.name || '',
            sku: v.sku || prod.sku || '',
            available,
            committed,
            onHand,
            unavailable,
            image: prod.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=120&q=80',
            category: prod.category || '',
            price: typeof v.price === 'number' ? v.price : prod.price || 0,
          });
        });
      } else {
        const rawStock = typeof prod.stock === 'number' ? prod.stock : 0;
        const committed = committedMap.get(`${prod.id}__main`) || 0;
        const available = Math.max(0, rawStock - committed);
        const onHand = rawStock;
        const unavailable = 0;

        list.push({
          id: `${prod.id}__main`,
          productId: prod.id,
          variantId: undefined,
          isVariant: false,
          productName: prod.name || (isBn ? 'নামবিহীন পণ্য' : 'Untitled Product'),
          variantName: undefined,
          sku: prod.sku || '',
          available,
          committed,
          onHand,
          unavailable,
          image: prod.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=120&q=80',
          category: prod.category || '',
          price: prod.price || 0,
        });
      }
    });

    return list;
  }, [storeProducts, committedMap, isBn]);

  // 4. Search, Filter & Settings State
  const [searchQuery, setSearchQuery] = useState('');
  const [stockStatusFilter, setStockStatusFilter] = useState<'all' | 'in_stock' | 'low_stock' | 'out_of_stock'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(5);
  const [sortBy, setSortBy] = useState<'name_asc' | 'name_desc' | 'qty_asc' | 'qty_desc' | 'sku_asc'>('name_asc');

  // Popover state
  const [isFilterSettingsOpen, setIsFilterSettingsOpen] = useState(false);
  const filterSettingsRef = useRef<HTMLDivElement>(null);

  // Location selector state (Screenshot: "Goalabazar Osmani Nagar Sylhet ↕")
  const defaultLoc = activeStore?.address 
    ? `${activeStore.name} • ${activeStore.address}`
    : 'Goalabazar Osmani Nagar Sylhet';
  const [selectedLocation, setSelectedLocation] = useState<string>(defaultLoc);
  const [isLocationMenuOpen, setIsLocationMenuOpen] = useState(false);
  const locationMenuRef = useRef<HTMLDivElement>(null);

  // Help modal state ("Learn more about managing inventory")
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);

  // 5. Bulk Selection State
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);

  // 6. Modals State
  const [isBulkUpdateModalOpen, setIsBulkUpdateModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  // 7. Inline Edit State
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editingField, setEditingField] = useState<'available' | 'onHand'>('available');
  const [editingValue, setEditingValue] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (filterSettingsRef.current && !filterSettingsRef.current.contains(event.target as Node)) {
        setIsFilterSettingsOpen(false);
      }
      if (locationMenuRef.current && !locationMenuRef.current.contains(event.target as Node)) {
        setIsLocationMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Auto-hide toast
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Distinct Categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    storeProducts.forEach((p) => {
      if (p.category) set.add(p.category);
    });
    return Array.from(set);
  }, [storeProducts]);

  // 8. Filtered and Sorted Rows
  const filteredItems = useMemo(() => {
    return allInventoryItems
      .filter((item) => {
        // Status filter
        if (stockStatusFilter === 'in_stock' && item.available <= 0) return false;
        if (stockStatusFilter === 'out_of_stock' && item.available !== 0) return false;
        if (stockStatusFilter === 'low_stock' && (item.available <= 0 || item.available > lowStockThreshold)) return false;

        // Category filter
        if (categoryFilter !== 'all' && item.category !== categoryFilter) return false;

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchName = (item.productName || '').toLowerCase().includes(q);
          const matchVariant = (item.variantName || '').toLowerCase().includes(q);
          const matchSku = (item.sku || '').toLowerCase().includes(q);
          if (!matchName && !matchVariant && !matchSku) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'name_asc') return (a.productName || '').localeCompare(b.productName || '');
        if (sortBy === 'name_desc') return (b.productName || '').localeCompare(a.productName || '');
        if (sortBy === 'qty_asc') return a.available - b.available;
        if (sortBy === 'qty_desc') return b.available - a.available;
        if (sortBy === 'sku_asc') return (a.sku || '').localeCompare(b.sku || '');
        return 0;
      });
  }, [allInventoryItems, stockStatusFilter, categoryFilter, lowStockThreshold, searchQuery, sortBy]);

  // Count out of stock and low stock
  const outOfStockCount = useMemo(() => allInventoryItems.filter((i) => i.available === 0).length, [allInventoryItems]);
  const lowStockCount = useMemo(
    () => allInventoryItems.filter((i) => i.available > 0 && i.available <= lowStockThreshold).length,
    [allInventoryItems, lowStockThreshold]
  );

  // 9. Update Stock Handler (Single Row)
  const handleUpdateStock = (item: InventoryRowItem, newQty: number) => {
    const cleanQty = Math.max(0, Math.floor(newQty));
    const parentProd = storeProducts.find((p) => p.id === item.productId);
    if (!parentProd) return;

    if (item.isVariant && item.variantId && Array.isArray(parentProd.variants)) {
      const updatedVariants = parentProd.variants.map((v) => 
        v.id === item.variantId ? { ...v, stock: cleanQty } : v
      );
      const totalStock = updatedVariants.reduce((sum, v) => sum + (v.stock || 0), 0);
      onUpdateProduct({
        ...parentProd,
        stock: totalStock,
        variants: updatedVariants
      });
    } else {
      onUpdateProduct({
        ...parentProd,
        stock: cleanQty
      });
    }

    setToastMessage(isBn ? 'ইনভেন্টরি আপডেট সংরক্ষিত হয়েছে।' : 'Inventory update saved.');
  };

  // 10. Bulk Updates Handler
  const handleApplyBulkUpdate = (action: 'set' | 'add' | 'subtract', value: number) => {
    const selectedRows = allInventoryItems.filter((i) => selectedItemIds.includes(i.id));
    if (selectedRows.length === 0) return;

    const groupedByProduct = new Map<string, InventoryRowItem[]>();
    selectedRows.forEach((row) => {
      const list = groupedByProduct.get(row.productId) || [];
      list.push(row);
      groupedByProduct.set(row.productId, list);
    });

    let updatedCount = 0;

    groupedByProduct.forEach((rows, prodId) => {
      const parentProd = storeProducts.find((p) => p.id === prodId);
      if (!parentProd) return;

      if (Array.isArray(parentProd.variants) && parentProd.variants.length > 0) {
        const variantUpdates = new Map<string, number>();
        rows.forEach((r) => {
          if (r.variantId) {
            let nextQty = r.available;
            if (action === 'set') nextQty = value;
            if (action === 'add') nextQty = r.available + value;
            if (action === 'subtract') nextQty = Math.max(0, r.available - value);
            variantUpdates.set(r.variantId, nextQty);
            updatedCount++;
          }
        });

        const updatedVariants = parentProd.variants.map((v) => {
          if (variantUpdates.has(v.id)) {
            return { ...v, stock: variantUpdates.get(v.id)! };
          }
          return v;
        });

        const totalStock = updatedVariants.reduce((sum, v) => sum + (v.stock || 0), 0);
        onUpdateProduct({
          ...parentProd,
          stock: totalStock,
          variants: updatedVariants
        });
      } else {
        const singleRow = rows[0];
        let nextQty = singleRow.available;
        if (action === 'set') nextQty = value;
        if (action === 'add') nextQty = singleRow.available + value;
        if (action === 'subtract') nextQty = Math.max(0, singleRow.available - value);
        updatedCount++;

        onUpdateProduct({
          ...parentProd,
          stock: nextQty
        });
      }
    });

    setSelectedItemIds([]);
    setToastMessage(
      isBn 
        ? `${updatedCount} টি পণ্যের ইনভেন্টরি সফলভাবে আপডেট হয়েছে।` 
        : `Successfully updated inventory for ${updatedCount} items.`
    );
  };

  // 11. CSV Import Handler
  const handleApplyImport = (updates: { productId: string; variantId?: string; newStock: number }[]) => {
    const grouped = new Map<string, { variantId?: string; newStock: number }[]>();
    updates.forEach((u) => {
      const list = grouped.get(u.productId) || [];
      list.push(u);
      grouped.set(u.productId, list);
    });

    let successCount = 0;

    grouped.forEach((prodUpdates, prodId) => {
      const parentProd = storeProducts.find((p) => p.id === prodId);
      if (!parentProd) return;

      if (Array.isArray(parentProd.variants) && parentProd.variants.length > 0) {
        const vMap = new Map<string, number>();
        prodUpdates.forEach((pu) => {
          if (pu.variantId) {
            vMap.set(pu.variantId, pu.newStock);
            successCount++;
          }
        });

        const updatedVariants = parentProd.variants.map((v) => {
          if (vMap.has(v.id)) {
            return { ...v, stock: vMap.get(v.id)! };
          }
          return v;
        });

        const totalStock = updatedVariants.reduce((sum, v) => sum + (v.stock || 0), 0);
        onUpdateProduct({
          ...parentProd,
          stock: totalStock,
          variants: updatedVariants
        });
      } else {
        const singleUpdate = prodUpdates[0];
        if (singleUpdate) {
          successCount++;
          onUpdateProduct({
            ...parentProd,
            stock: singleUpdate.newStock
          });
        }
      }
    });

    setToastMessage(
      isBn 
        ? `সিএসভি থেকে ${successCount} টি পণ্যের ইনভেন্টরি আপডেট করা হয়েছে।` 
        : `Successfully updated ${successCount} items from CSV.`
    );
  };

  // 12. CSV Export Handler
  const handleExportCSV = (onlySelected = false) => {
    const itemsToExport = onlySelected
      ? allInventoryItems.filter((i) => selectedItemIds.includes(i.id))
      : filteredItems;

    if (itemsToExport.length === 0) return;

    const headers = 'Product Name,Variant Name,SKU,Unavailable,Committed,Available,On hand,Category,Price\n';
    const rows = itemsToExport.map((item) => {
      const pName = `"${(item.productName || '').replace(/"/g, '""')}"`;
      const vName = item.variantName ? `"${item.variantName.replace(/"/g, '""')}"` : '""';
      const sku = item.sku ? `"${item.sku.replace(/"/g, '""')}"` : '""';
      const cat = `"${(item.category || '').replace(/"/g, '""')}"`;
      return `${pName},${vName},${sku},${item.unavailable ?? 0},${item.committed ?? 0},${item.available},${item.onHand ?? item.available},${cat},${item.price || 0}`;
    }).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const storeSlug = activeStore?.slug || 'store';
    const dateStr = new Date().toISOString().split('T')[0];
    link.setAttribute('download', `inventory-${storeSlug}-${dateStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setToastMessage(
      isBn 
        ? `${itemsToExport.length} টি আইটেম এক্সপোর্ট করা হয়েছে।` 
        : `Exported ${itemsToExport.length} inventory items.`
    );
  };

  // Select all visible rows
  const isAllVisibleSelected = filteredItems.length > 0 && filteredItems.every((i) => selectedItemIds.includes(i.id));

  const toggleSelectAll = () => {
    if (isAllVisibleSelected) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(filteredItems.map((i) => i.id));
    }
  };

  const toggleSelectItem = (id: string) => {
    setSelectedItemIds((prev) => 
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const locationLabel = activeStore?.address 
    ? `${activeStore.name} • ${activeStore.address}` 
    : (activeStore?.name ? `${activeStore.name} • Central Hub` : 'Main Location');

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-slate-900 text-white shadow-xl border border-slate-700 text-xs font-medium animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
          <button 
            onClick={() => setToastMessage(null)}
            className="p-1 rounded text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. PAGE HEADER                                                            */}
      {/* ========================================================================= */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            {isBn ? 'ইনভেন্টরি' : 'Inventory'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isBn 
              ? 'আপনার পণ্যের স্টক ও ইনভেন্টরি লেভেল পরিচালনা করুন।' 
              : 'Manage your product inventory and stock levels.'}
          </p>
        </div>

        {/* Small Summary Badges (Low stock / Out of stock if existing) */}
        <div className="flex items-center gap-2 text-xs">
          {outOfStockCount > 0 && (
            <span className="px-2.5 py-1 rounded-md bg-rose-50 border border-rose-200/90 text-rose-700 font-medium flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
              <span>{outOfStockCount} {isBn ? 'স্টক শেষ' : 'out of stock'}</span>
            </span>
          )}
          {lowStockCount > 0 && (
            <span className="px-2.5 py-1 rounded-md bg-amber-50 border border-amber-200/90 text-amber-800 font-medium flex items-center gap-1.5">
              <AlertTriangle className="w-3 h-3 text-amber-600" />
              <span>{lowStockCount} {isBn ? 'কম স্টক' : 'low stock'}</span>
            </span>
          )}
          <span className="px-2.5 py-1 rounded-md bg-slate-100 border border-slate-200 text-slate-700 font-medium">
            {allInventoryItems.length} {isBn ? 'মোট আইটেম' : 'items'}
          </span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. MAIN INVENTORY CARD (Top Bar + Controls + Table - EXACT Screenshot)   */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        {/* Card Header Bar (Screenshot: Inventory icon + Store Location + Export/Import) */}
        <div className="px-4 py-2.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-white">
          {/* Left: Inventory Title & Location Dropdown Pill */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800">
              <Package className="w-3.5 h-3.5 text-slate-600" />
              <span>{isBn ? 'ইনভেন্টরি' : 'Inventory'}</span>
            </div>

            {/* Location Selector Pill with Dropdown */}
            <div className="relative" ref={locationMenuRef}>
              <button
                type="button"
                onClick={() => setIsLocationMenuOpen(!isLocationMenuOpen)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-normal transition-colors cursor-pointer max-w-[260px] truncate"
                title={selectedLocation}
              >
                <span className="truncate">{selectedLocation}</span>
                <ChevronsUpDown className="w-3 h-3 text-slate-400 shrink-0" />
              </button>

              {isLocationMenuOpen && (
                <div className="absolute left-0 mt-1.5 w-72 bg-white rounded-xl shadow-xl border border-slate-200 z-40 p-2 space-y-1 animate-in fade-in duration-100">
                  <div className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    {isBn ? 'স্টোর লোকেশন নির্বাচন করুন' : 'Select Location'}
                  </div>
                  {[
                    { id: 'loc-1', name: 'Goalabazar Osmani Nagar Sylhet', detail: 'Main Fulfillment Depot' },
                    { id: 'loc-2', name: activeStore?.name ? `${activeStore.name} • Hub` : 'Central Hub', detail: activeStore?.address || 'Primary Store Address' },
                    { id: 'loc-3', name: 'Banani Express Center', detail: 'Regional Logistics Hub' },
                    { id: 'loc-all', name: 'All Locations (Combined)', detail: 'Aggregated view across all branches' },
                  ].map((loc) => {
                    const isSelected = selectedLocation === loc.name;
                    return (
                      <button
                        key={loc.id}
                        type="button"
                        onClick={() => {
                          setSelectedLocation(loc.name);
                          setIsLocationMenuOpen(false);
                          setToastMessage(isBn ? `লোকেশন পরিবর্তিত হয়েছে: ${loc.name}` : `Location switched to: ${loc.name}`);
                        }}
                        className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition-colors flex items-start justify-between cursor-pointer ${
                          isSelected ? 'bg-slate-100 font-semibold text-slate-900' : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="min-w-0 pr-2">
                          <p className="truncate text-xs">{loc.name}</p>
                          <p className="text-[10px] text-slate-400 truncate">{loc.detail}</p>
                        </div>
                        {isSelected && <Check className="w-3.5 h-3.5 text-slate-900 shrink-0 mt-0.5" />}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right: Export & Import Buttons (Clean Shopify Buttons) */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleExportCSV(false)}
              className="px-3 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-normal shadow-2xs transition-colors cursor-pointer"
            >
              {isBn ? 'এক্সপোর্ট' : 'Export'}
            </button>
            <button
              type="button"
              onClick={() => setIsImportModalOpen(true)}
              className="px-3 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-normal shadow-2xs transition-colors cursor-pointer"
            >
              {isBn ? 'ইমপোর্ট' : 'Import'}
            </button>
          </div>
        </div>

        {/* Card Controls / Search & Filter Bar (Screenshot: All ↕ + Search + Filter Icon) */}
        <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between gap-2.5 bg-white">
          {/* Left: Product Filter Dropdown Pill */}
          <div className="relative shrink-0">
            <select
              value={stockStatusFilter}
              onChange={(e) => setStockStatusFilter(e.target.value as any)}
              className="h-8 pl-2.5 pr-7 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-normal focus:outline-none focus:ring-1 focus:ring-slate-900 focus:border-slate-900 cursor-pointer appearance-none"
            >
              <option value="all">{isBn ? 'All' : 'All'}</option>
              <option value="in_stock">{isBn ? 'In stock' : 'In stock'}</option>
              <option value="low_stock">{isBn ? `Low stock (≤ ${lowStockThreshold})` : `Low stock (≤ ${lowStockThreshold})`}</option>
              <option value="out_of_stock">{isBn ? 'Out of stock' : 'Out of stock'}</option>
            </select>
            <ChevronsUpDown className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Center: Search Field */}
          <div className="relative flex-1 max-w-2xl">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isBn ? 'Search and filter' : 'Search and filter'}
              className="w-full h-8 pl-8 pr-7 rounded-lg border border-slate-200 bg-white placeholder-slate-400 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:border-slate-900 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Right: Filter / Settings Popover Button */}
          <div className="relative shrink-0" ref={filterSettingsRef}>
            <button
              type="button"
              onClick={() => setIsFilterSettingsOpen(!isFilterSettingsOpen)}
              className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-colors cursor-pointer ${
                isFilterSettingsOpen || categoryFilter !== 'all' || sortBy !== 'name_asc'
                  ? 'border-slate-900 bg-slate-900 text-white'
                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-600'
              }`}
              title={isBn ? 'ফিল্টার সেটিংস' : 'Filter settings'}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </button>

            {/* Filter Settings Popover */}
            {isFilterSettingsOpen && (
              <div className="absolute right-0 mt-2 w-72 p-4 bg-white rounded-xl shadow-xl border border-slate-200 z-30 space-y-3.5 animate-in fade-in duration-100">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="font-semibold text-xs text-slate-900">
                    {isBn ? 'ফিল্টার ও সেটিংস' : 'Filter & Sort'}
                  </span>
                  <button
                    onClick={() => {
                      setCategoryFilter('all');
                      setSortBy('name_asc');
                      setLowStockThreshold(5);
                    }}
                    className="text-[11px] font-medium text-slate-500 hover:text-slate-900 cursor-pointer"
                  >
                    {isBn ? 'রিসেট' : 'Reset'}
                  </button>
                </div>

                {/* Category Filter */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="w-full h-8 px-2.5 rounded-lg border border-slate-200 text-xs font-normal text-slate-800 bg-white focus:outline-none"
                  >
                    <option value="all">{isBn ? 'সকল ক্যাটাগরি' : 'All Categories'}</option>
                    {categories.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                {/* Sort Order */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isBn ? 'সাজানোর ক্রম' : 'Sort By'}
                  </label>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="w-full h-8 px-2.5 rounded-lg border border-slate-200 text-xs font-normal text-slate-800 bg-white focus:outline-none"
                  >
                    <option value="name_asc">{isBn ? 'Product Name (A-Z)' : 'Product Name (A-Z)'}</option>
                    <option value="name_desc">{isBn ? 'Product Name (Z-A)' : 'Product Name (Z-A)'}</option>
                    <option value="qty_asc">{isBn ? 'Available (Low to High)' : 'Available (Low to High)'}</option>
                    <option value="qty_desc">{isBn ? 'Available (High to Low)' : 'Available (High to Low)'}</option>
                    <option value="sku_asc">{isBn ? 'SKU (A-Z)' : 'SKU (A-Z)'}</option>
                  </select>
                </div>

                {/* Low Stock Threshold */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-semibold text-slate-700">
                      {isBn ? 'কম স্টক সীমা' : 'Low Stock Threshold'}
                    </label>
                    <span className="text-xs font-bold text-slate-900">{lowStockThreshold}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="30"
                    value={lowStockThreshold}
                    onChange={(e) => setLowStockThreshold(parseInt(e.target.value) || 5)}
                    className="w-full accent-slate-900 cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bulk Action Bar (When 1+ rows selected) */}
        {selectedItemIds.length > 0 && (
          <div className="px-4 py-2 bg-slate-900 text-white flex items-center justify-between gap-3 animate-in fade-in duration-100">
            <div className="flex items-center gap-2.5 text-xs">
              <span className="font-semibold text-emerald-400">
                {selectedItemIds.length} {isBn ? 'নির্বাচিত' : 'selected'}
              </span>
              <button
                onClick={() => setSelectedItemIds([])}
                className="text-slate-400 hover:text-white underline cursor-pointer text-xs"
              >
                {isBn ? 'সব আনচেক করুন' : 'Deselect all'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleExportCSV(true)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-normal text-slate-200 transition-colors cursor-pointer"
              >
                {isBn ? 'নির্বাচিত এক্সপোর্ট' : 'Export selected'}
              </button>
              <button
                onClick={() => setIsBulkUpdateModalOpen(true)}
                className="px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{isBn ? 'ইনভেন্টরি আপডেট' : 'Update inventory'}</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 3. INVENTORY TABLE                                                        */}
        {/* ========================================================================= */}
        {allInventoryItems.length === 0 ? (
          /* Empty State: No Products in Store */
          <div className="py-16 text-center text-slate-400 text-xs p-6">
            <Package className="w-10 h-10 mx-auto text-slate-300 mb-2.5" />
            <h3 className="font-bold text-slate-800 text-sm">
              {isBn ? 'কোনো পণ্য পাওয়া যায়নি' : 'No products found'}
            </h3>
            <p className="text-slate-500 mt-1 max-w-sm mx-auto text-xs">
              {isBn 
                ? 'ইনভেন্টরি পরিচালনা করতে আপনার স্টোরে প্রথমে পণ্য যোগ করুন।' 
                : 'To manage inventory, add products to your store first.'}
            </p>
          </div>
        ) : filteredItems.length === 0 ? (
          /* Empty State: No Search/Filter Match */
          <div className="py-12 text-center text-slate-400 text-xs p-6">
            <Search className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <h3 className="font-bold text-slate-800 text-sm">
              {isBn ? 'কোনো আইটেম মিলেনি' : 'No matching inventory items'}
            </h3>
            <p className="text-slate-500 mt-1 text-xs">
              {isBn ? 'অনুসন্ধান বা ফিল্টার পরিবর্তন করে পুনরায় চেষ্টা করুন।' : 'Try changing your search terms or filter criteria.'}
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setStockStatusFilter('all');
                setCategoryFilter('all');
              }}
              className="mt-3 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
            >
              {isBn ? 'ফিল্টার পরিষ্কার করুন' : 'Clear filters'}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[700px]">
              {/* Header (Screenshot: Checkbox | Product | SKU | Unavailable | Committed | Available | On hand) */}
              <thead className="border-b border-slate-200 text-slate-600 font-normal text-[12px] bg-white">
                <tr>
                  {/* Checkbox */}
                  <th className="py-2.5 px-3.5 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={isAllVisibleSelected}
                      onChange={toggleSelectAll}
                      className="w-4 h-4 rounded border-slate-300 text-slate-900 focus:ring-0 cursor-pointer"
                    />
                  </th>

                  {/* Product */}
                  <th className="py-2.5 px-3 min-w-[260px] font-medium text-slate-600">
                    {isBn ? 'Product' : 'Product'}
                  </th>

                  {/* SKU */}
                  <th className="py-2.5 px-3 min-w-[140px] font-medium text-slate-600">
                    SKU
                  </th>

                  {/* Unavailable (as visible in screenshot with dotted underline) */}
                  <th className="py-2.5 px-3 w-28 text-right font-medium text-slate-600">
                    <span 
                      className="border-b border-dotted border-slate-400 cursor-help"
                      title={isBn ? 'অপ্রাপ্য বা বিক্রির জন্য প্রস্তুত নয়' : 'Unavailable for sale (draft, reserved, or damaged)'}
                    >
                      {isBn ? 'Unavailable' : 'Unavailable'}
                    </span>
                  </th>

                  {/* Committed (orders placed) */}
                  <th className="py-2.5 px-3 w-28 text-right font-medium text-slate-600">
                    <span 
                      className="cursor-help"
                      title={isBn ? 'অর্ডারের জন্য নির্ধারিত স্টক' : 'Committed to open orders'}
                    >
                      {isBn ? 'Committed' : 'Committed'}
                    </span>
                  </th>

                  {/* Available (available to sell) */}
                  <th className="py-2.5 px-3 w-28 text-right font-medium text-slate-900">
                    <span 
                      className="cursor-help font-semibold"
                      title={isBn ? 'বিক্রির জন্য প্রস্তুত উপলব্ধ মজুদ' : 'Available to sell immediately'}
                    >
                      {isBn ? 'Available' : 'Available'}
                    </span>
                  </th>

                  {/* On hand (total physical inventory) */}
                  <th className="py-2.5 px-3 w-28 text-right font-medium text-slate-600">
                    <span 
                      className="cursor-help"
                      title={isBn ? 'দোকানে বা গুদামে মোট বিদ্যমান স্টক' : 'Total inventory on hand in warehouse'}
                    >
                      {isBn ? 'On hand' : 'On hand'}
                    </span>
                  </th>

                  {/* Actions / Quick Edit */}
                  <th className="py-2.5 px-3 w-16 text-right font-medium text-slate-400">
                    <span className="sr-only">Edit</span>
                  </th>
                </tr>
              </thead>

              {/* Rows */}
              <tbody className="divide-y divide-slate-100 text-[13px]">
                {filteredItems.map((item) => {
                  const isChecked = selectedItemIds.includes(item.id);
                  const isEditingThis = editingItemId === item.id;

                  return (
                    <tr 
                      key={item.id}
                      className={`hover:bg-slate-50/60 transition-colors ${isChecked ? 'bg-slate-50/80' : ''}`}
                    >
                      {/* Checkbox */}
                      <td className="py-2 px-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSelectItem(item.id)}
                          className="w-4 h-4 rounded border-slate-300 text-slate-900 focus:ring-0 cursor-pointer"
                        />
                      </td>

                      {/* Product (Thumbnail + Title + Variant Badge) */}
                      <td className="py-2 px-3">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={item.image}
                            alt={item.productName}
                            className="w-8 h-8 rounded-md border border-slate-200/90 bg-slate-50 object-cover shrink-0"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=120&q=80';
                            }}
                          />
                          <div className="min-w-0">
                            <span className="font-normal text-[13px] text-slate-900 hover:text-blue-600 transition-colors cursor-pointer block truncate">
                              {item.productName}
                            </span>
                            {/* Variant Pill (Exactly as in screenshot: soft gray pill badge below product name) */}
                            {item.isVariant && item.variantName ? (
                              <span className="inline-block mt-0.5 px-1.5 py-0.5 rounded text-[11px] bg-slate-200/80 text-slate-700 font-normal leading-none">
                                {item.variantName}
                              </span>
                            ) : null}
                          </div>
                        </div>
                      </td>

                      {/* SKU (Screenshot: "No SKU" in normal text or actual SKU) */}
                      <td className="py-2 px-3 text-[12px] text-slate-600">
                        {item.sku ? (
                          <span className="font-mono text-slate-700">{item.sku}</span>
                        ) : (
                          <span className="text-slate-500 font-normal">No SKU</span>
                        )}
                      </td>

                      {/* Unavailable (Screenshot shows: 0) */}
                      <td className="py-2 px-3 text-right text-[13px] text-slate-600">
                        {item.unavailable ?? 0}
                      </td>

                      {/* Committed (Screenshot shows: 0 or committed count) */}
                      <td className="py-2 px-3 text-right text-[13px] text-slate-600">
                        {item.committed ?? 0}
                      </td>

                      {/* Available (Interactive edit or numeric display) */}
                      <td className="py-2 px-3 text-right">
                        {isEditingThis && editingField === 'available' ? (
                          <div className="inline-flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-900 shadow-2xs">
                            <input
                              type="number"
                              min="0"
                              autoFocus
                              value={editingValue}
                              onChange={(e) => setEditingValue(parseInt(e.target.value) || 0)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  handleUpdateStock(item, editingValue);
                                  setEditingItemId(null);
                                } else if (e.key === 'Escape') {
                                  setEditingItemId(null);
                                }
                              }}
                              className="w-14 h-6 text-center font-normal text-xs border-0 focus:outline-none text-slate-900"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                handleUpdateStock(item, editingValue);
                                setEditingItemId(null);
                              }}
                              className="p-1 rounded bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer"
                              title={isBn ? 'সংরক্ষণ' : 'Save'}
                            >
                              <Check className="w-3 h-3 text-emerald-400" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingItemId(null)}
                              className="p-1 rounded text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                              title={isBn ? 'বাতিল' : 'Cancel'}
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setEditingItemId(item.id);
                              setEditingField('available');
                              setEditingValue(item.available);
                            }}
                            className="text-[13px] font-normal text-slate-900 hover:bg-slate-100 px-2 py-0.5 rounded cursor-pointer transition-colors"
                            title={isBn ? 'ক্লিক করে সংখ্যা পরিবর্তন করুন' : 'Click to edit available stock'}
                          >
                            {item.available}
                          </button>
                        )}
                      </td>

                      {/* On Hand (total physical stock) */}
                      <td className="py-2 px-3 text-right text-[13px] text-slate-600">
                        {item.onHand ?? item.available}
                      </td>

                      {/* Actions (Inline stepper / edit icon on hover) */}
                      <td className="py-2 px-3 text-right">
                        <div className="inline-flex items-center gap-0.5 opacity-60 hover:opacity-100 transition-opacity">
                          <button
                            type="button"
                            onClick={() => handleUpdateStock(item, item.available - 1)}
                            disabled={item.available <= 0}
                            className="p-1 rounded hover:bg-slate-200 text-slate-500 disabled:opacity-20 disabled:cursor-not-allowed cursor-pointer transition-colors"
                            title={isBn ? '-১' : '-1'}
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUpdateStock(item, item.available + 1)}
                            className="p-1 rounded hover:bg-slate-200 text-slate-500 cursor-pointer transition-colors"
                            title={isBn ? '+১' : '+1'}
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Bottom Section (Screenshot: "Learn more about managing inventory") */}
        <div className="py-6 border-t border-slate-100 text-center bg-white">
          <button
            type="button"
            onClick={() => setIsHelpModalOpen(true)}
            className="text-[12px] text-slate-500 hover:text-slate-900 transition-colors inline-flex items-center gap-1 cursor-pointer underline-offset-2 hover:underline"
          >
            <span>{isBn ? 'ইনভেন্টরি পরিচালনা সম্পর্কে আরও জানুন' : 'Learn more about managing inventory'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. MODALS (Bulk Update, CSV Import & Educational Help Modal)              */}
      {/* ========================================================================= */}
      {isHelpModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-sm text-slate-900">
                  {isBn ? 'ইনভেন্টরি হিসাব প্রণালী' : 'Understanding Inventory Quantities'}
                </h3>
              </div>
              <button
                onClick={() => setIsHelpModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3.5 text-xs text-slate-600">
              <p className="leading-relaxed text-slate-700 font-medium">
                {isBn
                  ? 'আপনার স্টোরে গ্রাহকদের অর্ডার এবং ফিজিক্যাল স্টকের নির্ভুল সমন্বয়ের জন্য শানজু চারটি ইনভেন্টরি স্টেট ব্যবহার করে:'
                  : 'Shanju tracks your inventory across four distinct states to prevent overselling and keep physical counts accurate:'}
              </p>

              <div className="space-y-2.5">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-slate-400" />
                      <span>Unavailable</span>
                    </h4>
                    <span className="text-[10px] font-mono text-slate-500 uppercase">Reserved / Internal</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    {isBn
                      ? 'অপ্রাপ্য মজুদ—যা খসড়া অর্ডারের জন্য সংরক্ষিত অথবা ত্রুটি পরীক্ষার জন্য বিক্রির বাইরে রাখা হয়েছে।'
                      : 'Inventory set aside for draft orders, damaged goods, or quality checks that cannot be purchased by customers.'}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-500" />
                      <span>Committed</span>
                    </h4>
                    <span className="text-[10px] font-mono text-amber-700 font-semibold uppercase">Pending Orders</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    {isBn
                      ? 'অর্ডারে বুক করা পণ্য—যা গ্রাহক অর্ডার করেছেন কিন্তু ডেলিভারির জন্য এখনো গুদাম থেকে বের হয়নি।'
                      : 'Stock promised to customers in open, paid, or processing orders that have not yet shipped.'}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/90">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-bold text-emerald-900 text-xs flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      <span>Available</span>
                    </h4>
                    <span className="text-[10px] font-mono text-emerald-800 font-bold uppercase">Ready to Sell</span>
                  </div>
                  <p className="text-[11px] text-emerald-700 leading-normal">
                    {isBn
                      ? 'সরাসরি বিক্রির জন্য উন্মুক্ত স্টক। গ্রাহকরা এই পরিমাণ পর্যন্ত কিনতে পারবেন।'
                      : 'Inventory available for immediate purchase on your storefront. Formula: On hand minus Committed and Unavailable.'}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      <span>On hand</span>
                    </h4>
                    <span className="text-[10px] font-mono text-slate-600 font-semibold uppercase">Physical Warehouse</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    {isBn
                      ? 'গুদামে বিদ্যমান মোট ফিজিক্যাল মজুদ সংখ্যা (Available + Committed + Unavailable)।'
                      : 'The total number of units physically in your warehouse or store (On hand = Available + Committed + Unavailable).'}
                  </p>
                </div>
              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/70 flex justify-end">
              <button
                type="button"
                onClick={() => setIsHelpModalOpen(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                {isBn ? 'বুঝেছি' : 'Got it'}
              </button>
            </div>
          </div>
        </div>
      )}
      {isBulkUpdateModalOpen && (
        <BulkInventoryUpdateModal
          isOpen={isBulkUpdateModalOpen}
          onClose={() => setIsBulkUpdateModalOpen(false)}
          selectedItemIds={selectedItemIds}
          inventoryItems={allInventoryItems}
          language={language}
          onApplyBulkUpdate={handleApplyBulkUpdate}
        />
      )}

      {isImportModalOpen && (
        <InventoryImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          products={storeProducts}
          language={language}
          onApplyImport={handleApplyImport}
        />
      )}
    </div>
  );
};
