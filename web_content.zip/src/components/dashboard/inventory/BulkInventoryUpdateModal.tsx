import React, { useState } from 'react';
import { X, Layers, Plus, Minus, Check, AlertCircle } from 'lucide-react';
import { Language } from '../../../types';

export interface InventoryRowItem {
  id: string; // Unique key: `${productId}__${variantId || 'main'}`
  productId: string;
  variantId?: string;
  isVariant: boolean;
  productName: string;
  variantName?: string;
  sku: string;
  available: number;
  committed?: number;
  onHand?: number;
  unavailable?: number;
  image: string;
  category: string;
  price: number;
}

interface BulkInventoryUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedItemIds: string[];
  inventoryItems: InventoryRowItem[];
  language: Language;
  onApplyBulkUpdate: (action: 'set' | 'add' | 'subtract', value: number) => void;
}

export const BulkInventoryUpdateModal: React.FC<BulkInventoryUpdateModalProps> = ({
  isOpen,
  onClose,
  selectedItemIds,
  inventoryItems,
  language,
  onApplyBulkUpdate
}) => {
  const isBn = language === 'bn';
  const [actionType, setActionType] = useState<'set' | 'add' | 'subtract'>('set');
  const [quantityValue, setQuantityValue] = useState<number>(10);
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const selectedItems = inventoryItems.filter(item => selectedItemIds.includes(item.id));

  const handleApply = () => {
    if (isNaN(quantityValue) || quantityValue < 0) {
      setErrorMsg(isBn ? 'অনুগ্রহ করে একটি সঠিক সংখ্যা দিন।' : 'Please enter a valid positive number.');
      return;
    }
    onApplyBulkUpdate(actionType, Math.floor(quantityValue));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200/90 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                {isBn ? 'বাল্ক ইনভেন্টরি আপডেট' : 'Bulk Update Inventory'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {selectedItemIds.length} {isBn ? 'টি আইটেম নির্বাচিত' : 'items selected'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-2 text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Action selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              {isBn ? 'অ্যাকশন নির্বাচন করুন' : 'Choose Action'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setActionType('set')}
                className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all text-center ${
                  actionType === 'set'
                    ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                {isBn ? 'সেট স্টক' : 'Set stock'}
              </button>
              <button
                type="button"
                onClick={() => setActionType('add')}
                className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all text-center flex items-center justify-center gap-1 ${
                  actionType === 'add'
                    ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Plus className="w-3 h-3" />
                <span>{isBn ? 'যোগ করুন' : 'Add (+)'}</span>
              </button>
              <button
                type="button"
                onClick={() => setActionType('subtract')}
                className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all text-center flex items-center justify-center gap-1 ${
                  actionType === 'subtract'
                    ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Minus className="w-3 h-3" />
                <span>{isBn ? 'বিয়োগ করুন' : 'Subtract (-)'}</span>
              </button>
            </div>
          </div>

          {/* Quantity Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {actionType === 'set' 
                ? (isBn ? 'নতুন এভেইলেবল পরিমাণ' : 'New Available Quantity')
                : actionType === 'add'
                  ? (isBn ? 'যোগ করার পরিমাণ' : 'Quantity to Add')
                  : (isBn ? 'বিয়োগ করার পরিমাণ' : 'Quantity to Subtract')}
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setQuantityValue(prev => Math.max(0, prev - 1))}
                className="w-10 h-10 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-700 font-bold transition-colors"
              >
                -
              </button>
              <input
                type="number"
                min="0"
                value={quantityValue}
                onChange={(e) => {
                  setErrorMsg('');
                  setQuantityValue(parseInt(e.target.value) || 0);
                }}
                className="flex-1 h-10 px-3 border border-slate-200 rounded-xl text-center font-bold text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-900"
              />
              <button
                type="button"
                onClick={() => setQuantityValue(prev => prev + 1)}
                className="w-10 h-10 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-700 font-bold transition-colors"
              >
                +
              </button>
            </div>
          </div>

          {/* Preview of selected products */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1.5">
              {isBn ? 'নির্বাচিত আইটেমসমূহের প্রিভিউ:' : 'Selected items preview:'}
            </label>
            <div className="max-h-36 overflow-y-auto rounded-xl border border-slate-100 bg-slate-50/50 divide-y divide-slate-100 text-xs">
              {selectedItems.slice(0, 5).map(item => {
                let previewVal = item.available;
                if (actionType === 'set') previewVal = quantityValue;
                if (actionType === 'add') previewVal = item.available + quantityValue;
                if (actionType === 'subtract') previewVal = Math.max(0, item.available - quantityValue);

                return (
                  <div key={item.id} className="p-2 flex items-center justify-between text-slate-700">
                    <span className="truncate max-w-[200px] font-medium text-[11px]">
                      {item.productName} {item.variantName ? `(${item.variantName})` : ''}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      {item.available} → <strong className="text-slate-900">{previewVal}</strong>
                    </span>
                  </div>
                );
              })}
              {selectedItems.length > 5 && (
                <div className="p-2 text-center text-[10px] text-slate-400 italic">
                  + {selectedItems.length - 5} {isBn ? 'টি আরও আইটেম' : 'more items'}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-100 bg-slate-50/70 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          >
            {isBn ? 'বাতিল' : 'Cancel'}
          </button>
          <button
            type="button"
            onClick={handleApply}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white transition-colors shadow-xs flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isBn ? 'আপডেট প্রয়োগ করুন' : 'Apply Updates'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
