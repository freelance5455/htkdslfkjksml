import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  Clock,
  CheckCircle2,
  BookOpen,
  Compass,
  Pill,
  Sparkles,
  ArrowRight,
  Play,
  RotateCcw,
  AlertCircle,
  GraduationCap,
  TrendingUp,
  Layers,
  ChevronLeft,
  Sun,
  Bell,
  Heart,
} from 'lucide-react';
import { getTimeUntilNextPrayer, formatTime24to12 } from '../../utils/prayerCalculator';
import { getDailyQuote } from '../../utils/notifications';
import { getDailyVerse } from '../../data/quranVerses';
import { timeToMinutes } from '../../utils/smartScheduler';

export const Dashboard: React.FC = () => {
  const {
    currentTime,
    scheduleItems,
    prayersToday,
    nextPrayer,
    sunriseTime,
    togglePrayerCompleted,
    medications,
    nextMedicationDose,
    logMedicationDose,
    toggleScheduleItemCompleted,
    subjects,
    setActiveTab,
    generateSmartScheduleAction,
    studyPreferences,
    setShowQuranModal,
    alarms,
  } = useApp();

  const [quote] = useState(() => getDailyQuote());
  const [dailyVerse] = useState(() => getDailyVerse());
  const [showBriefingModal, setShowBriefingModal] = useState(false);

  // Live countdown for next prayer
  const [countdown, setCountdown] = useState<{ hours: number; minutes: number; seconds: number } | null>(null);

  useEffect(() => {
    if (!nextPrayer) return;

    const updateTimer = () => {
      const res = getTimeUntilNextPrayer(nextPrayer);
      setCountdown(res);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [nextPrayer]);

  // Today's schedule items
  const currentDayOfWeek = currentTime.getDay(); // 0 = Sun, ..., 6 = Sat
  const todayScheduleItems = useMemo(() => {
    return scheduleItems
      .filter((item) => item.dayOfWeek === currentDayOfWeek)
      .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
  }, [scheduleItems, currentDayOfWeek]);

  // Daily statistics
  const totalTasksToday = todayScheduleItems.length;
  const completedTasksToday = todayScheduleItems.filter((i) => i.isCompleted).length;
  const completionPercentage = totalTasksToday > 0 ? Math.round((completedTasksToday / totalTasksToday) * 100) : 0;

  // Study hours planned vs completed
  const studyItemsToday = todayScheduleItems.filter((i) => i.type === 'study');
  const plannedStudyMinutes = studyItemsToday.reduce((sum, item) => sum + item.durationMinutes, 0);
  const completedStudyMinutes = studyItemsToday
    .filter((i) => i.isCompleted)
    .reduce((sum, item) => sum + item.durationMinutes, 0);

  const plannedHours = (plannedStudyMinutes / 60).toFixed(1);
  const completedHours = (completedStudyMinutes / 60).toFixed(1);

  // Completed prayers today
  const completedPrayersCount = prayersToday.filter((p) => p.isCompleted && p.id !== 'sunrise').length;

  const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes();

  // Upcoming activities today (remaining)
  const upcomingItems = todayScheduleItems.filter((i) => !i.isCompleted);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner: Greeting, Live Arabic Clock, Date & Briefing Button with Rose Backdrop */}
      <div
        className="rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden transition-all border border-rose-200/20"
        style={{
          background: `linear-gradient(135deg, rgba(190, 24, 93, 0.92) 0%, rgba(225, 29, 72, 0.88) 50%, rgba(136, 19, 55, 0.95) 100%), url('/public/assets/aistudio/images_5d51feea.jpg') center/cover no-repeat`,
        }}
      >
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-rose-100 text-xs font-semibold">
              <Calendar className="w-4 h-4 text-pink-200" />
              <span>
                {currentTime.toLocaleDateString('ar-EG', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
              <span className="opacity-60">·</span>
              <span className="font-mono tabular-nums text-white bg-white/20 backdrop-blur-xs px-2.5 py-0.5 rounded-lg border border-white/20">
                {currentTime.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight drop-shadow-xs">
              أهلاً بك! يومك يبدأ بتنظيم وإشراق
            </h2>

            <p className="text-rose-100/90 text-sm max-w-xl leading-relaxed">
              لديك اليوم <span className="font-bold underline decoration-pink-300">{todayScheduleItems.length} أنشطة</span> مجدولة،
              منها {studyItemsToday.length} جلسات مذاكرة. رتّب أوقاتك وانعم براحة البال والإنتاجية!
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setShowBriefingModal(true)}
              className="px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold backdrop-blur-md border border-white/30 transition-all flex items-center gap-2 shadow-sm"
            >
              <Sparkles className="w-4 h-4 text-pink-200" />
              <span>ملخص اليوم الذكي</span>
            </button>

            <button
              onClick={() => setActiveTab('pomodoro')}
              className="px-4 py-2.5 rounded-xl bg-white text-rose-700 hover:bg-rose-50 text-xs font-bold shadow-md transition-all flex items-center gap-2"
            >
              <Play className="w-4 h-4 text-rose-600 fill-rose-600" />
              <span>بدء جلسة تركيز</span>
            </button>
          </div>
        </div>

        {/* Soft background glow overlay */}
        <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-pink-400/20 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Task Completion Rate */}
        <div className="bg-white dark:bg-[#1a0f18] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-300/70">إنجاز اليوم</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-rose-100">
              {completionPercentage}%
            </span>
            <span className="text-xs text-slate-500 dark:text-rose-300/60">
              ({completedTasksToday} من {totalTasksToday} مهمة)
            </span>
          </div>
          <div className="w-full bg-rose-100/50 dark:bg-rose-950/40 h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-rose-500 to-pink-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>

        {/* Card 2: Study Hours Planned vs Completed */}
        <div className="bg-white dark:bg-[#1a0f18] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-300/70">ساعات المذاكرة</span>
            <div className="w-8 h-8 rounded-lg bg-pink-50 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-rose-100">
              {completedHours}
            </span>
            <span className="text-xs text-slate-500 dark:text-rose-300/60 font-mono">
              / {plannedHours} س منجزة
            </span>
          </div>
          <div className="w-full bg-rose-100/50 dark:bg-rose-950/40 h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-pink-500 to-rose-500 h-full rounded-full transition-all duration-500"
              style={{
                width: `${
                  plannedStudyMinutes > 0
                    ? Math.min(100, Math.round((completedStudyMinutes / plannedStudyMinutes) * 100))
                    : 0
                }%`,
              }}
            />
          </div>
        </div>

        {/* Card 3: Next Prayer & Countdown */}
        <div className="bg-white dark:bg-[#1a0f18] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-300/70">الصلاة القادمة</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Compass className="w-4 h-4" />
            </div>
          </div>
          {nextPrayer ? (
            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-lg font-bold text-slate-900 dark:text-rose-100">
                  صلاة {nextPrayer.nameAr}
                </span>
                <span className="text-xs font-mono font-medium text-slate-500 dark:text-rose-300/70">
                  {formatTime24to12(nextPrayer.time)}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400 font-mono tabular-nums font-semibold">
                <Clock className="w-3.5 h-3.5" />
                <span>
                  متبقي{' '}
                  {countdown
                    ? `${String(countdown.hours).padStart(2, '0')}:${String(countdown.minutes).padStart(
                        2,
                        '0'
                      )}:${String(countdown.seconds).padStart(2, '0')}`
                    : '--:--:--'}
                </span>
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-400">اكتملت صلوات اليوم</div>
          )}
          <div className="mt-2 text-[11px] flex items-center justify-between text-slate-400 dark:text-rose-300/60 pt-1 border-t border-rose-50 dark:border-rose-950/40">
            <span>{completedPrayersCount} من 5 صلوات</span>
            {sunriseTime && (
              <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                <Sun className="w-3 h-3 text-amber-500" />
                الشروق {sunriseTime.formattedTime}
              </span>
            )}
          </div>
        </div>

        {/* Card 4: Next Medication */}
        <div className="bg-white dark:bg-[#1a0f18] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-300/70">الدواء القادم</span>
            <div className="w-8 h-8 rounded-lg bg-pink-50 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center">
              <Pill className="w-4 h-4" />
            </div>
          </div>
          {nextMedicationDose ? (
            <div>
              <div className="font-bold text-sm text-slate-900 dark:text-rose-100 truncate">
                {nextMedicationDose.medication.name}
              </div>
              <div className="text-xs text-slate-500 dark:text-rose-300/70 mb-2">
                {nextMedicationDose.medication.dosage} · {formatTime24to12(nextMedicationDose.time)}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    logMedicationDose(nextMedicationDose.medication.id, nextMedicationDose.time, 'taken')
                  }
                  className="px-2.5 py-1 text-xs font-medium rounded-lg bg-rose-600 hover:bg-rose-700 text-white transition-colors"
                >
                  أخذت الجرعة
                </button>
                <button
                  onClick={() =>
                    logMedicationDose(
                      nextMedicationDose.medication.id,
                      nextMedicationDose.time,
                      'snoozed',
                      'تأجيل 15 دقيقة'
                    )
                  }
                  className="px-2 py-1 text-xs rounded-lg border border-slate-200 dark:border-rose-900/60 text-slate-600 dark:text-rose-300 hover:bg-slate-100 dark:hover:bg-rose-950/40"
                >
                  تأجيل 15د
                </button>
              </div>
            </div>
          ) : (
            <div className="py-2 text-xs text-slate-400">لا توجد جرعات دواء متبقية لليوم</div>
          )}
        </div>
      </div>

      {/* Main Grid: Today's Schedule Timeline & Side Widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Today's Schedule & Tasks */}
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Schedule Section */}
          <div className="bg-white dark:bg-[#1a0f18] rounded-2xl border border-rose-100 dark:border-rose-950/60 p-5 transition-colors shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-rose-100/60 dark:border-rose-950/60">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-rose-100">
                  جدول أنشطة اليوم
                </h3>
                <p className="text-xs text-slate-500 dark:text-rose-300/60">
                  المحاضرات والسكاشن وجلسات المذاكرة المجدولة لليوم
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => generateSmartScheduleAction()}
                  className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/50 hover:bg-rose-100 dark:hover:bg-rose-900/40 transition-colors flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-rose-500" />
                  <span>توزيع ذكي للمذاكرة</span>
                </button>

                <button
                  onClick={() => setActiveTab('schedule')}
                  className="text-xs text-slate-500 hover:text-rose-600 dark:hover:text-rose-300 flex items-center gap-1"
                >
                  <span>عرض الكل</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* List of items */}
            <div className="divide-y divide-rose-100/50 dark:divide-rose-950/40 mt-3">
              {todayScheduleItems.length === 0 ? (
                <div className="py-12 text-center text-slate-400">
                  <Calendar className="w-10 h-10 mx-auto mb-2 text-rose-300 dark:text-rose-900/60" />
                  <p className="text-sm font-medium">لا توجد أنشطة مجدولة اليوم</p>
                  <p className="text-xs mt-1">اضغط على "توزيع ذكي للمذاكرة" لإنشاء جدول مخصص لليوم.</p>
                </div>
              ) : (
                todayScheduleItems.map((item) => {
                  const subject = subjects.find((s) => s.id === item.subjectId);
                  const isCurrent =
                    currentMinutes >= timeToMinutes(item.startTime) &&
                    currentMinutes <= timeToMinutes(item.endTime);

                  return (
                    <div
                      key={item.id}
                      className={`py-3.5 flex items-center justify-between gap-4 transition-colors ${
                        item.isCompleted ? 'opacity-60' : ''
                      } ${isCurrent ? 'bg-rose-50/50 dark:bg-rose-950/30 -mx-3 px-3 rounded-xl' : ''}`}
                    >
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => toggleScheduleItemCompleted(item.id)}
                          className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${
                            item.isCompleted
                              ? 'bg-rose-600 border-rose-600 text-white'
                              : 'border-slate-300 dark:border-rose-900/60 hover:border-rose-500'
                          }`}
                          aria-label={item.isCompleted ? 'مكتملة' : 'غير مكتملة'}
                        >
                          {item.isCompleted && <CheckCircle2 className="w-4 h-4" />}
                        </button>

                        <div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-sm font-semibold ${
                                item.isCompleted
                                  ? 'line-through text-slate-400 dark:text-slate-500'
                                  : 'text-slate-900 dark:text-rose-100'
                              }`}
                            >
                              {item.title}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-900/70 text-rose-800 dark:text-rose-200">
                                جاري الآن
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-rose-300/60 mt-0.5">
                            <span className="font-mono tabular-nums font-medium text-slate-700 dark:text-rose-200">
                              {formatTime24to12(item.startTime)} - {formatTime24to12(item.endTime)}
                            </span>
                            <span>·</span>
                            <span>{item.durationMinutes} دقيقة</span>
                            {subject && (
                              <>
                                <span>·</span>
                                <span style={{ color: subject.color }} className="font-semibold">
                                  {subject.name} ({subject.code})
                                </span>
                              </>
                            )}
                            {item.locationOrNotes && (
                              <>
                                <span>·</span>
                                <span className="truncate max-w-[150px]">{item.locationOrNotes}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Type Badge */}
                      <div className="shrink-0">
                        {item.type === 'lecture' && (
                          <span className="text-xs px-2.5 py-1 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 font-medium">
                            محاضرة
                          </span>
                        )}
                        {item.type === 'section' && (
                          <span className="text-xs px-2.5 py-1 rounded-md bg-pink-50 text-pink-700 dark:bg-pink-950/60 dark:text-pink-300 font-medium">
                            سكشن
                          </span>
                        )}
                        {item.type === 'study' && (
                          <span className="text-xs px-2.5 py-1 rounded-md bg-fuchsia-50 text-fuchsia-700 dark:bg-fuchsia-950/60 dark:text-fuchsia-300 font-medium">
                            مذاكرة
                          </span>
                        )}
                        {item.type === 'break' && (
                          <span className="text-xs px-2.5 py-1 rounded-md bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 font-medium">
                            استراحة
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Daily Quran Verse with Tafseer Card */}
          <div className="bg-gradient-to-br from-rose-950 via-[#1e0a16] to-[#14060e] border border-rose-800/40 text-white rounded-2xl p-5 shadow-xs relative overflow-hidden space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-pink-300" />
                <span className="text-xs font-bold text-pink-300">
                  نفحات قرآنية: آية وتفسيرها ({dailyVerse.surahName} - آية {dailyVerse.ayahNumber})
                </span>
              </div>
              <button
                onClick={() => setShowQuranModal(true)}
                className="text-[11px] text-rose-200 hover:text-white bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-lg backdrop-blur-xs transition-colors"
              >
                فتح الآيات كاملة
              </button>
            </div>

            <div className="text-center font-serif text-lg font-bold text-rose-100 py-1 leading-relaxed">
              ﴿ {dailyVerse.arabicText} ﴾
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-rose-200/90 leading-relaxed">
              <span className="font-bold text-rose-300 ml-1">التفسير الميسر:</span>
              {dailyVerse.tafseer}
            </div>
          </div>

          {/* Motivational Quote of the Day in Deep Rose / Velvet Plum */}
          <div className="bg-gradient-to-br from-[#2a0e19] via-[#1f0913] to-[#14060c] border border-rose-900/40 text-white rounded-2xl p-5 shadow-xs relative overflow-hidden">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-pink-300 shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <div className="text-xs font-semibold text-pink-300">
                  اقتباس اليوم التحفيزي ({quote.category})
                </div>
                <blockquote className="text-sm font-medium leading-relaxed italic text-rose-50">
                  "{quote.quote}"
                </blockquote>
                <div className="text-xs text-rose-300/70 text-left">— {quote.author}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Prayers Status & Quick Organizers */}
        <div className="space-y-6">
          {/* Quick Hub Navigation Cards */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setActiveTab('calendar')}
              className="p-3 rounded-2xl bg-white dark:bg-[#1a0f18] border border-rose-100 dark:border-rose-950/60 shadow-xs hover:border-rose-300 text-center space-y-1 transition-all"
            >
              <Calendar className="w-4 h-4 text-rose-600 mx-auto" />
              <div className="text-[11px] font-bold text-slate-800 dark:text-rose-100">التقويم</div>
            </button>

            <button
              onClick={() => setActiveTab('adhkar')}
              className="p-3 rounded-2xl bg-white dark:bg-[#1a0f18] border border-rose-100 dark:border-rose-950/60 shadow-xs hover:border-rose-300 text-center space-y-1 transition-all"
            >
              <BookOpen className="w-4 h-4 text-pink-600 mx-auto" />
              <div className="text-[11px] font-bold text-slate-800 dark:text-rose-100">الأذكار</div>
            </button>

            <button
              onClick={() => setActiveTab('alarms')}
              className="p-3 rounded-2xl bg-white dark:bg-[#1a0f18] border border-rose-100 dark:border-rose-950/60 shadow-xs hover:border-rose-300 text-center space-y-1 transition-all"
            >
              <Bell className="w-4 h-4 text-rose-600 mx-auto" />
              <div className="text-[11px] font-bold text-slate-800 dark:text-rose-100">المنبهات</div>
            </button>
          </div>

          {/* Daily Prayers Card */}
          <div className="bg-white dark:bg-[#1a0f18] rounded-2xl border border-rose-100 dark:border-rose-950/60 p-5 transition-colors shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100/60 dark:border-rose-950/60 mb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-rose-100">مواقيت الصلاة والشروق</h3>
                <p className="text-xs text-slate-400 dark:text-rose-300/60">مواقيت اليوم مع موعد الشروق</p>
              </div>
              <button
                onClick={() => setActiveTab('prayers')}
                className="text-xs text-rose-600 dark:text-rose-400 hover:underline"
              >
                تعديل المدينة
              </button>
            </div>

            <div className="space-y-2">
              {prayersToday.map((prayer) => {
                if (prayer.id === 'sunrise') {
                  return (
                    <div
                      key="sunrise"
                      className="flex items-center justify-between p-2.5 rounded-xl border border-amber-200/70 dark:border-amber-900/40 bg-amber-50/60 dark:bg-amber-950/20 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <Sun className="w-4 h-4 text-amber-500" />
                        <span className="font-bold text-amber-800 dark:text-amber-200">
                          شروق الشمس (الشروق)
                        </span>
                      </div>
                      <span className="font-mono tabular-nums font-bold text-amber-900 dark:text-amber-100">
                        {prayer.formattedTime}
                      </span>
                    </div>
                  );
                }

                return (
                  <div
                    key={prayer.id}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                      prayer.isCompleted
                        ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/40'
                        : prayer.isNext
                        ? 'bg-rose-50/80 dark:bg-rose-950/40 border-rose-300 dark:border-rose-700 shadow-xs'
                        : 'border-slate-100 dark:border-rose-950/40 hover:bg-rose-50/30 dark:hover:bg-rose-950/30'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <button
                        onClick={() => togglePrayerCompleted(prayer.id)}
                        className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                          prayer.isCompleted
                            ? 'bg-rose-600 border-rose-600 text-white'
                            : 'border-slate-300 dark:border-rose-900/60'
                        }`}
                        aria-label={prayer.nameAr}
                      >
                        {prayer.isCompleted && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </button>

                      <span
                        className={`text-xs font-semibold ${
                          prayer.isCompleted
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : prayer.isNext
                            ? 'text-rose-700 dark:text-rose-300'
                            : 'text-slate-800 dark:text-rose-100'
                        }`}
                      >
                        {prayer.nameAr}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {prayer.isNext && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 dark:bg-rose-900/70 dark:text-rose-200">
                          القادمة
                        </span>
                      )}
                      <span className="text-xs font-mono font-medium text-slate-500 dark:text-rose-300/70">
                        {prayer.formattedTime}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Subjects Progress Snapshot */}
          <div className="bg-white dark:bg-[#1a0f18] rounded-2xl border border-rose-100 dark:border-rose-950/60 p-5 transition-colors shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100/60 dark:border-rose-950/60 mb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-rose-100">المواد الدراسية</h3>
                <p className="text-xs text-slate-400 dark:text-rose-300/60">نسبة التغطية ومواعيد الامتحانات</p>
              </div>
              <button
                onClick={() => setActiveTab('study')}
                className="text-xs text-rose-600 dark:text-rose-400 hover:underline"
              >
                إدارة المواد
              </button>
            </div>

            <div className="space-y-3">
              {subjects.map((sub) => {
                const total = sub.items.length;
                const completed = sub.items.filter((i) => i.isCompleted).length;
                const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

                // Exam countdown
                let daysLeftText = '';
                if (sub.examDate) {
                  const examDate = new Date(sub.examDate);
                  const diff = Math.ceil(
                    (examDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                  );
                  daysLeftText = diff > 0 ? `باقي ${diff} يوم على الامتحان` : 'الامتحان اليوم';
                }

                return (
                  <div key={sub.id} className="p-3 rounded-xl bg-rose-50/40 dark:bg-rose-950/20 border border-rose-100/70 dark:border-rose-900/30">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-rose-100">
                        <span
                          className="w-2.5 h-2.5 rounded-full inline-block"
                          style={{ backgroundColor: sub.color }}
                        />
                        <span className="truncate max-w-[150px]">{sub.name}</span>
                      </div>
                      <span className="font-mono tabular-nums font-semibold text-slate-600 dark:text-rose-300">
                        {pct}%
                      </span>
                    </div>

                    <div className="w-full bg-rose-100/60 dark:bg-rose-950/40 h-1.5 rounded-full overflow-hidden mb-1.5">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{ width: `${pct}%`, backgroundColor: sub.color }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-rose-300/60">
                      <span>{completed} من {total} موضوع تم إنهاؤه</span>
                      {daysLeftText && <span className="text-rose-600 dark:text-rose-400 font-medium">{daysLeftText}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Morning Daily Briefing Modal */}
      {showBriefingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-[#1a0f18] rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-rose-200 dark:border-rose-900/60 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100 dark:border-rose-950/60">
              <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400">
                <Sparkles className="w-5 h-5" />
                <h3 className="font-bold text-base text-slate-900 dark:text-rose-100">
                  ملخص اليوم الذكي (Daily Briefing)
                </h3>
              </div>
              <button
                onClick={() => setShowBriefingModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg"
              >
                ×
              </button>
            </div>

            <div className="space-y-3 text-sm text-slate-600 dark:text-rose-200/90 leading-relaxed">
              <p>
                صباح الخير والإشراق! هذا ملخص سريع لأهم التزاماتك المجدولة لليوم{' '}
                <strong>
                  {currentTime.toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' })}
                </strong>
                :
              </p>

              <div className="p-3 rounded-xl bg-rose-50/50 dark:bg-rose-950/30 border border-rose-200/60 dark:border-rose-900/40 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-rose-200">الالتزامات الكلية:</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">{todayScheduleItems.length} نشاط</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-rose-200">ساعات المذاكرة المخططة:</span>
                  <span className="font-mono font-bold text-rose-600 dark:text-rose-400">{plannedHours} ساعة</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-rose-200">جرعات الأدوية:</span>
                  <span className="font-mono font-bold text-pink-600 dark:text-pink-400">
                    {medications.filter((m) => m.active).length} أدوية مجدولة
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-rose-200">الصلاة القادمة:</span>
                  <span className="font-mono font-bold text-rose-600 dark:text-rose-400">
                    {nextPrayer ? `${nextPrayer.nameAr} (${formatTime24to12(nextPrayer.time)})` : 'مكتملة'}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-800 dark:text-rose-200 text-xs border border-rose-200 dark:border-rose-900/50">
                🌸 <strong>نصيحة اليوم:</strong> ابدأ بأصعب المواد بعد صلاة الفجر أو الصباح الباكر، وخذ استراحات قصيرة بين الجلسات لتجديد طاقتك الذهنية.
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowBriefingModal(false)}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white font-semibold text-xs transition-colors shadow-sm shadow-rose-600/30"
              >
                فهمت، لنبدأ اليوم!
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
