import React, { useState } from 'react';
import { 
  Menu, 
  Search, 
  Bell, 
  Globe, 
  ExternalLink, 
  LogOut, 
  User, 
  Check, 
  Sparkles,
  ShoppingBag,
  Package,
  AlertTriangle,
  Sliders,
  ChevronDown
} from 'lucide-react';
import { Store, Language, DashboardTab } from '../../types';

interface MerchantTopNavProps {
  activeStore: Store;
  language: Language;
  onToggleLanguage: () => void;
  onOpenStorefront: () => void;
  onToggleMobileSidebar: () => void;
  onLogout: () => void;
  onNavigateTab: (tab: DashboardTab) => void;
  userEmail?: string;
  userName?: string;
  pendingOrdersCount: number;
}

export const MerchantTopNav: React.FC<MerchantTopNavProps> = ({
  activeStore,
  language,
  onToggleLanguage,
  onOpenStorefront,
  onToggleMobileSidebar,
  onLogout,
  onNavigateTab,
  userEmail,
  userName,
  pendingOrdersCount
}) => {
  const isBn = language === 'bn';
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 h-16 bg-white border-b border-slate-200/90 px-4 sm:px-6 flex items-center justify-between shadow-xs">
      {/* Left Area: Mobile Menu + Store Identifier */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobileSidebar}
          className="p-2 -ml-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 lg:hidden cursor-pointer"
          title="Toggle Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-900 text-sm sm:text-base tracking-tight truncate max-w-[150px] sm:max-w-[240px]">
            {activeStore.name}
          </span>
          <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/80">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Live Cloud</span>
          </span>
        </div>
      </div>

      {/* Middle Area: Global Search */}
      <div className="hidden md:flex items-center flex-1 max-w-md mx-6">
        <div 
          onClick={() => onNavigateTab('overview')}
          className="w-full flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-150 text-slate-500 border border-slate-200 text-xs transition-colors cursor-pointer"
        >
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <span className="flex-1 text-slate-400 truncate">
            {isBn ? 'পণ্য, অর্ডার বা কাস্টমার খুঁজুন...' : 'Search orders, products, customers...'}
          </span>
          <kbd className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white text-slate-500 border border-slate-200 shadow-2xs">
            ⌘K
          </kbd>
        </div>
      </div>

      {/* Right Area: Actions, Notifications & Profile */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {/* Language Toggle */}
        <button
          onClick={onToggleLanguage}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
          title="Switch Language"
        >
          <Globe className="w-3.5 h-3.5 text-emerald-600" />
          <span>{language === 'en' ? 'বাংলা' : 'EN'}</span>
        </button>

        {/* View Storefront CTA */}
        <button
          onClick={onOpenStorefront}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 transition-all cursor-pointer shadow-2xs"
          title={isBn ? 'লাইভ স্টোরফ্রন্ট দেখুন' : 'View Live Storefront'}
        >
          <ExternalLink className="w-3.5 h-3.5 text-emerald-600" />
          <span className="hidden sm:inline">{isBn ? 'স্টোর দেখুন' : 'View Store'}</span>
        </button>

        {/* Notification Bell Dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
            className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {pendingOrdersCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
            )}
            {pendingOrdersCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500"></span>
            )}
          </button>

          {isNotificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-white border border-slate-200 rounded-2xl shadow-xl p-3 text-xs z-50 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                <span className="font-bold text-slate-900">
                  {isBn ? 'স্টোর নোটিফিকেশন' : 'Store Notifications'}
                </span>
                <span className="text-[10px] text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full">
                  {isBn ? 'লাইভ আপডেট' : 'Live Updates'}
                </span>
              </div>

              <div className="space-y-2">
                <div 
                  onClick={() => {
                    onNavigateTab('orders');
                    setIsNotificationsOpen(false);
                  }}
                  className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer flex items-start gap-2.5"
                >
                  <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                    <ShoppingBag className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">
                      {pendingOrdersCount > 0 
                        ? (isBn ? `${pendingOrdersCount}টি নতুন অর্ডার অপেক্ষমান` : `${pendingOrdersCount} pending orders require fulfillment`)
                        : (isBn ? 'কোনো নতুন পেন্ডিং অর্ডার নেই' : 'All orders are fulfilled')}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {isBn ? 'ক্লিক করে অর্ডার লিস্ট দেখুন' : 'Click to review order tracking'}
                    </p>
                  </div>
                </div>

                <div 
                  onClick={() => {
                    onNavigateTab('customizer');
                    setIsNotificationsOpen(false);
                  }}
                  className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer flex items-start gap-2.5"
                >
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">
                      {isBn ? 'থিম কাস্টমাইজেশন প্রস্তুত' : 'Visual Store Customizer ready'}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {isBn ? 'ব্যানার ও ফন্ট কাস্টমাইজ করুন' : 'Edit hero headlines, colors & fonts'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Merchant User Menu */}
        <div className="relative">
          <button
            onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
            className="flex items-center gap-1.5 p-1 sm:px-2 sm:py-1 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white font-bold text-xs flex items-center justify-center shadow-xs">
              {(userName || userEmail || 'M').slice(0, 1).toUpperCase()}
            </div>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-500 hidden sm:block transition-transform ${isUserMenuOpen ? 'rotate-180' : ''}`} />
          </button>

          {isUserMenuOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-2xl shadow-xl p-2 text-xs z-50 animate-in fade-in slide-in-from-top-2">
              <div className="px-3 py-2 border-b border-slate-100 mb-1">
                <p className="font-bold text-slate-900 truncate">
                  {userName || 'Merchant Admin'}
                </p>
                <p className="text-[11px] text-slate-500 truncate">
                  {userEmail}
                </p>
              </div>

              <button
                onClick={() => {
                  onNavigateTab('settings');
                  setIsUserMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors font-medium cursor-pointer"
              >
                {isBn ? 'স্টোর সেটিংস' : 'Store Settings'}
              </button>

              <button
                onClick={() => {
                  onNavigateTab('billing');
                  setIsUserMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors font-medium cursor-pointer"
              >
                {isBn ? 'প্ল্যান ও সাবস্ক্রিপশন' : 'Plan & Billing'}
              </button>

              <div className="border-t border-slate-100 my-1"></div>

              <button
                onClick={() => {
                  setIsUserMenuOpen(false);
                  onLogout();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-rose-600 hover:bg-rose-50 transition-colors font-semibold cursor-pointer text-left"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-500" />
                <span>{isBn ? 'লগআউট করুন' : 'Sign Out'}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
