import React, { useState, useMemo } from 'react';
import { 
  Settings, 
  Store as StoreIcon, 
  Globe, 
  CreditCard, 
  Truck, 
  ShieldCheck, 
  Check, 
  Save, 
  Key,
  ExternalLink,
  MapPin,
  Building2,
  Info
} from 'lucide-react';
import { Store, Language, PaymentGatewayConfig, ShippingSettings, StoreLocation } from '../../types';
import { BD_DIVISIONS, getStoreLocationDistrict, BDDivision, BDDistrict } from '../../utils/deliveryLocationService';

interface StoreSettingsViewProps {
  activeStore: Store;
  language: Language;
  gateways?: PaymentGatewayConfig[];
  shippingSettings?: ShippingSettings | null;
  onUpdateStoreTheme: (storeId: string, updatedTheme: any, storeName?: string) => void;
  onSaveShippingSettings?: (settings: ShippingSettings) => void;
}

export const StoreSettingsView: React.FC<StoreSettingsViewProps> = ({
  activeStore,
  language,
  gateways = [],
  shippingSettings,
  onUpdateStoreTheme,
  onSaveShippingSettings
}) => {
  const isBn = language === 'bn';
  const [storeName, setStoreName] = useState(activeStore.name);
  const [customDomain, setCustomDomain] = useState(activeStore.customDomain || '');
  const [contactEmail, setContactEmail] = useState(activeStore.contactEmail || 'contact@mybrand.com');
  const [dnsVerified, setDnsVerified] = useState(false);

  // Store Location Resolution
  const initialStoreLocation: StoreLocation = useMemo(() => {
    if (shippingSettings?.storeLocation) return shippingSettings.storeLocation;
    if (activeStore?.storeLocation) return activeStore.storeLocation;
    
    const fallbackDistrict = getStoreLocationDistrict(activeStore);
    return {
      division: 'Sylhet',
      district: fallbackDistrict || 'Sylhet',
      city: fallbackDistrict || 'Sylhet',
      address: activeStore?.address || 'Goalabazar, Osmani Nagar, Sylhet'
    };
  }, [shippingSettings?.storeLocation, activeStore]);

  const [division, setDivision] = useState<string>(initialStoreLocation.division || 'Sylhet');
  const [district, setDistrict] = useState<string>(initialStoreLocation.district || 'Sylhet');
  const [streetAddress, setStreetAddress] = useState<string>(initialStoreLocation.address || activeStore?.address || '');

  // Delivery Charges (configured relative to Store Location)
  const [localCharge, setLocalCharge] = useState<number>(
    shippingSettings?.localDeliveryCharge ?? shippingSettings?.insideCityCharge ?? 60
  );
  const [outsideCharge, setOutsideCharge] = useState<number>(
    shippingSettings?.outsideDeliveryCharge ?? shippingSettings?.outsideCityCharge ?? 120
  );
  const [freeThreshold, setFreeThreshold] = useState<number>(
    shippingSettings?.freeShippingThreshold ?? 2500
  );

  const [steadfastApiKey, setSteadfastApiKey] = useState('sf_live_a89bc30219');
  const [pathaoSecret, setPathaoSecret] = useState('pt_live_990141bc2');
  const [isSaved, setIsSaved] = useState(false);

  // Filter districts for the selected division
  const currentDivisionDistricts = useMemo(() => {
    const found = BD_DIVISIONS.find((d: BDDivision) => d.name.toLowerCase() === division.toLowerCase());
    return found ? found.districts : [];
  }, [division]);

  const handleDivisionChange = (newDivision: string) => {
    setDivision(newDivision);
    const divObj = BD_DIVISIONS.find((d: BDDivision) => d.name.toLowerCase() === newDivision.toLowerCase());
    if (divObj && divObj.districts.length > 0) {
      setDistrict(divObj.districts[0].name);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedStoreLocation: StoreLocation = {
      division,
      district,
      city: district,
      address: streetAddress.trim()
    };

    const updatedSettings: ShippingSettings = {
      storeId: activeStore.id,
      localDeliveryCharge: Number(localCharge),
      outsideDeliveryCharge: Number(outsideCharge),
      insideCityCharge: Number(localCharge),
      outsideCityCharge: Number(outsideCharge),
      freeShippingThreshold: Number(freeThreshold),
      defaultCourier: shippingSettings?.defaultCourier || 'Steadfast',
      availableCouriers: shippingSettings?.availableCouriers || ['Steadfast', 'Pathao', 'RedX', 'Paperfly', 'Sundarban', 'In-house'],
      storeLocation: updatedStoreLocation
    };

    onUpdateStoreTheme(activeStore.id, activeStore.theme, storeName);

    if (onSaveShippingSettings) {
      onSaveShippingSettings(updatedSettings);
    }

    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-4xl pb-16">
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Settings className="w-5 h-5 text-emerald-600" />
            <span>{isBn ? 'স্টোর কনফিগারেশন ও সেটিংস' : 'Store Settings & Configuration'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'স্টোরের ভৌগোলিক অবস্থান, ডাইনামিক ডেলিভারি চার্জ, ডোমেইন ও এপিআই কনফিগার করুন।' 
              : "Configure your store's origin location, dynamic delivery zones, custom domain, and courier APIs."}
          </p>
        </div>

        {isSaved && (
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200 animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>{isBn ? 'সফলভাবে সংরক্ষিত!' : 'Settings Saved!'}</span>
          </span>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* 1. General Store Details */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs text-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <StoreIcon className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'সাধারণ স্টোর তথ্য' : 'General Store Information'}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-slate-800">
                {isBn ? 'স্টোরের নাম' : 'Store Name'}
              </label>
              <input
                type="text"
                required
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-semibold focus:outline-emerald-500"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-800">
                {isBn ? 'কন্টাক্ট ইমেইল' : 'Store Contact Email'}
              </label>
              <input
                type="email"
                required
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 focus:outline-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* 2. STORE LOCATION SETUP */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs text-xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900">
                {isBn ? 'স্টোরের অবস্থান ও ওয়্যারহাউস হাব (Store Location)' : 'Store Location & Dispatch Origin'}
              </h3>
            </div>
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              {isBn ? `সক্রিয় উৎস: ${district}` : `Origin: ${district}`}
            </span>
          </div>

          <p className="text-slate-500 leading-relaxed">
            {isBn 
              ? 'ডেলিভারি চার্জ আপনার স্টোরের অবস্থান অনুযায়ী স্বয়ংক্রিয়ভাবে হিসাব করা হবে। আপনার স্টোরের বিভাগ ও জেলা নির্বাচন করুন।' 
              : "Delivery charges are calculated dynamically relative to your store's origin location. Select the division and district of your dispatch hub."}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Division Select */}
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'বিভাগ (Division)' : 'Division'}
              </label>
              <select
                value={division}
                onChange={(e) => handleDivisionChange(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-medium text-xs text-slate-900 focus:outline-emerald-500"
              >
                {BD_DIVISIONS.map((div: BDDivision) => (
                  <option key={div.name} value={div.name}>
                    {div.name} ({div.nameBn})
                  </option>
                ))}
              </select>
            </div>

            {/* District Select */}
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'জেলা / শহর (District / Store City)' : 'District / City'}
              </label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-bold text-xs text-slate-900 focus:outline-emerald-500"
              >
                {currentDivisionDistricts.map((dist: BDDistrict) => (
                  <option key={dist.name} value={dist.name}>
                    {dist.name} ({dist.nameBn})
                  </option>
                ))}
              </select>
            </div>

            {/* Street Address */}
            <div className="sm:col-span-2">
              <label className="block font-bold text-slate-800 mb-1">
                {isBn ? 'বিস্তারিত ঠিকানা / ওয়্যারহাউস হাব' : 'Detailed Address / Warehouse Hub'}
              </label>
              <input
                type="text"
                value={streetAddress}
                onChange={(e) => setStreetAddress(e.target.value)}
                placeholder={isBn ? 'যেমন: গোল্লাবাজার, ওসমানী নগর, সিলেট' : 'e.g., Goalabazar, Osmani Nagar, Sylhet'}
                className="w-full px-3.5 py-2 border border-slate-300 rounded-xl bg-white text-xs text-slate-900 focus:outline-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* 3. STORE-LOCATION BASED DELIVERY CHARGE CONFIGURATION */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs text-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'ডেলিভারি চার্জ কনফিগারেশন' : 'Delivery Zones & Rates'}</span>
          </h3>

          <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200/90 text-slate-700 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div className="text-[11px] leading-relaxed">
              <span className="font-bold text-emerald-900 block">
                {isBn ? `স্টোর অবস্থান: ${district}` : `Store Origin: ${district}`}
              </span>
              <span>
                {isBn 
                  ? `যে সকল গ্রাহক ${district} জেলা থেকে অর্ডার করবেন তারা লোকাল ডেলিভারি রেট পাবেন। ${district}-এর বাইরের সকল গ্রাহকের জন্য আউটসাইড ডেলিভারি রেট প্রযোজ্য হবে।`
                  : `Customers within ${district} will be charged the Local Delivery rate. Customers outside ${district} will be charged the Outside Store Location rate.`}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Local Delivery Charge */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">
                  {isBn ? 'লোকাল ডেলিভারি চার্জ' : 'Local Delivery Charge'}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  {district}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {isBn 
                  ? `স্টোরের নিজস্ব জেলা (${district})-এর ভেতরের গ্রাহকদের জন্য চার্জ` 
                  : `Customers inside ${district} will be charged this amount.`}
              </p>
              <div className="flex items-center gap-2 pt-1">
                <span className="font-bold text-sm text-slate-900">৳</span>
                <input
                  type="number"
                  min="0"
                  required
                  value={localCharge}
                  onChange={(e) => setLocalCharge(Number(e.target.value))}
                  className="w-32 px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-black text-sm text-slate-900 focus:outline-emerald-500"
                />
              </div>
            </div>

            {/* Outside Store Location Delivery Charge */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">
                  {isBn ? 'স্টোরের বাইরের এলাকার ডেলিভারি চার্জ' : 'Outside Store Location Delivery Charge'}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                  Outside {district}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {isBn 
                  ? `স্টোরের জেলা (${district})-এর বাইরের সকল জেলার গ্রাহকদের জন্য চার্জ` 
                  : `Customers outside ${district} will be charged this amount.`}
              </p>
              <div className="flex items-center gap-2 pt-1">
                <span className="font-bold text-sm text-slate-900">৳</span>
                <input
                  type="number"
                  min="0"
                  required
                  value={outsideCharge}
                  onChange={(e) => setOutsideCharge(Number(e.target.value))}
                  className="w-32 px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-black text-sm text-slate-900 focus:outline-emerald-500"
                />
              </div>
            </div>

            {/* Free Shipping Minimum Threshold */}
            <div className="sm:col-span-2 p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="font-bold text-slate-900 block">
                  {isBn ? 'ফ্রি ডেলিভারি ন্যূনতম কেনাকাটা (৳)' : 'Free Shipping Minimum Threshold (৳)'}
                </span>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {isBn ? 'এই মূল্যের বেশি অর্ডারে গ্রাহক স্বয়ংক্রিয়ভাবে ফ্রি ডেলিভারি পাবেন (০ দিলে বন্ধ থাকবে)' : 'Orders above this amount qualify for zero delivery fee automatically (0 to disable)'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-slate-900">৳</span>
                <input
                  type="number"
                  min="0"
                  value={freeThreshold}
                  onChange={(e) => setFreeThreshold(Number(e.target.value))}
                  className="w-32 px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-black text-sm text-slate-900 focus:outline-emerald-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 4. Custom Domain Settings */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs text-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Globe className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'কাস্টম ডোমেইন ও সাবডোমেন' : 'Custom Domain & Cloud URL'}</span>
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-800">
                {isBn ? 'আপনার নিজস্ব ডোমেইন (যেমন: mybrand.com)' : 'Custom Domain (e.g. yourbrand.com)'}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. stylecraft.com.bd"
                  value={customDomain}
                  onChange={(e) => setCustomDomain(e.target.value)}
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-xl font-mono text-slate-900 focus:outline-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => setDnsVerified(true)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl cursor-pointer"
                >
                  {isBn ? 'যাচাই করুন' : 'Verify DNS'}
                </button>
              </div>
              {dnsVerified && (
                <p className="text-[11px] text-emerald-600 font-semibold mt-1">
                  ✓ {isBn ? 'CNAME রেকর্ড DNS সফলভাবে যাচাই করা হয়েছে।' : 'DNS CNAME verified successfully.'}
                </p>
              )}
              <p className="text-[11px] text-slate-500 mt-1">
                {isBn 
                  ? 'আপনার ডোমেইন প্রোভাইডারে CNAME হিসেবে "cname.shanju.cloud" যুক্ত করুন।' 
                  : 'Point your domain DNS CNAME record to "cname.shanju.cloud" with automated SSL.'}
              </p>
            </div>
          </div>
        </div>

        {/* 5. Courier API Keys */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs text-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Truck className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'কুরিয়ার অটোমেশন এপিআই (Steadfast & Pathao)' : 'Courier API Integration'}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-slate-800">Steadfast Courier API Key</label>
              <input
                type="password"
                value={steadfastApiKey}
                onChange={(e) => setSteadfastApiKey(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
              />
              <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block">✓ Connected</span>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-800">Pathao Merchant Client Secret</label>
              <input
                type="password"
                value={pathaoSecret}
                onChange={(e) => setPathaoSecret(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
              />
              <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block">✓ Connected</span>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
          >
            <Save className="w-4 h-4 text-emerald-400" />
            <span>{isBn ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save Configuration'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
