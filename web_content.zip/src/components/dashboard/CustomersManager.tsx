import React, { useState } from 'react';
import { Users, Search, Phone, Mail, MapPin, ShoppingBag, DollarSign, Award } from 'lucide-react';
import { Customer, Language, Store } from '../../types';

interface CustomersManagerProps {
  activeStore: Store;
  customers: Customer[];
  language: Language;
}

export const CustomersManager: React.FC<CustomersManagerProps> = ({
  activeStore,
  customers,
  language,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const isBn = language === 'bn';

  const filtered = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm) ||
      c.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
            {isBn ? 'গ্রাহক তালিকা ও সিআরএম (Customer CRM)' : 'Customer Directory & Lifetime Value'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'আপনার রিপিট কাস্টমারদের প্রোফাইল, মোট অর্ডার ও যোগাযোগ তথ্য।' 
              : 'Detailed merchant CRM tracking purchase frequency, delivery locations, and VIP status.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500">
            {isBn ? 'মোট নিবন্ধিত ক্রেতা:' : 'Total Buyers:'}
          </span>
          <span className="px-2.5 py-1 rounded-xl bg-slate-900 text-white font-bold text-xs">
            {customers.length}
          </span>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex items-center">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder={isBn ? 'নাম, ফোন বা শহর দিয়ে খুঁজুন...' : 'Search by name, phone, or city...'}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3.5 px-4">{isBn ? 'গ্রাহকের নাম' : 'Customer'}</th>
                <th className="py-3.5 px-4">{isBn ? 'যোগাযোগ' : 'Contact'}</th>
                <th className="py-3.5 px-4">{isBn ? 'শহর / ঠিকানা' : 'City'}</th>
                <th className="py-3.5 px-4">{isBn ? 'মোট অর্ডার' : 'Orders'}</th>
                <th className="py-3.5 px-4">{isBn ? 'মোট খরচ (LTV)' : 'Lifetime Value'}</th>
                <th className="py-3.5 px-4 text-right">{isBn ? 'স্ট্যাটাস' : 'Tier'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((customer) => (
                <tr key={customer.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 text-slate-700 font-bold flex items-center justify-center text-xs">
                        {customer.name.charAt(0)}
                      </div>
                      <div className="font-bold text-slate-900">{customer.name}</div>
                    </div>
                  </td>

                  <td className="py-3.5 px-4">
                    <div className="text-slate-700 font-medium">{customer.phone}</div>
                    <div className="text-[11px] text-slate-400">{customer.email}</div>
                  </td>

                  <td className="py-3.5 px-4 text-slate-700 font-medium">
                    {customer.city}
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="font-bold text-slate-900">{customer.totalOrders}</span>
                    <span className="text-slate-400 text-[11px] ml-1">orders</span>
                  </td>

                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900 text-xs">
                      ৳{customer.totalSpent.toLocaleString()}
                    </div>
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    {customer.status === 'vip' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                        <Award className="w-3 h-3 text-amber-500" />
                        VIP Buyer
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        Active
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
