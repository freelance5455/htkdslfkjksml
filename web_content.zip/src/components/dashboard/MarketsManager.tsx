import React from 'react';
import { Globe, MapPin, DollarSign, CheckCircle2, TrendingUp } from 'lucide-react';
import { Language, Store } from '../../types';

export const MarketsManager: React.FC<{ language: Language; activeStore: Store }> = ({
  language,
  activeStore
}) => {
  const isBn = language === 'bn';

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
          <Globe className="w-5 h-5 text-emerald-600" />
          <span>{isBn ? 'মার্কেটস ও কারেন্সি ব্যবস্থাপনা' : 'Markets & Geographic Regions'}</span>
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          {isBn 
            ? 'নির্দিষ্ট অঞ্চলের ক্রেতাদের জন্য কাস্টম প্রাইসিং, কারেন্সি এবং শিপিং জোন কনফিগার করুন।' 
            : 'Configure targeted currencies, local checkout experiences, and dedicated regional pricing.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Primary Market: Bangladesh */}
        <div className="bg-white p-5 rounded-2xl border-2 border-emerald-500/80 shadow-xs relative">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-xl">🇧🇩</span>
              <h3 className="font-extrabold text-slate-900 text-sm">
                {isBn ? 'বাংলাদেশ (প্রাথমিক মার্কেট)' : 'Bangladesh (Primary Market)'}
              </h3>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              Primary • 100% Volume
            </span>
          </div>

          <p className="text-xs text-slate-600 mb-4">
            {isBn 
              ? 'মুদ্রা: বাংলাদেশী টাকা (BDT ৳) • পেমেন্ট: বিকাশ, নগদ, ক্যাশ অন ডেলিভারি (COD) • কুরিয়ার: স্টিডফাস্ট ও পাঠাও' 
              : 'Currency: Bangladeshi Taka (BDT ৳) • Gateways: bKash, Nagad, COD • Logistics: Steadfast, Pathao'}
          </p>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5 text-emerald-600 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {isBn ? 'সক্রিয় ও যাচাইকৃত' : 'Active & Verified'}
            </span>
            <span className="font-bold text-slate-900">৳{activeStore.currencySymbol || '৳'} BDT</span>
          </div>
        </div>

        {/* Global Market */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-xl">🌐</span>
              <h3 className="font-extrabold text-slate-900 text-sm">
                {isBn ? 'আন্তর্জাতিক মার্কেট (গ্লোবাল)' : 'International (Global Market)'}
              </h3>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
              Cross-border
            </span>
          </div>

          <p className="text-xs text-slate-600 mb-4">
            {isBn 
              ? 'মুদ্রা: মার্কিন ডলার (USD $) • পেমেন্ট: আন্তর্জাতিক ভিসা/মাস্টারকার্ড ও স্ট্রাইপ গেটওয়ে' 
              : 'Currency: US Dollar (USD $) • Gateways: International Visa, Mastercard & SSLCommerz Global'}
          </p>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="text-slate-400 font-medium">
              {isBn ? 'প্রয়োজনে চালু করুন' : 'Configurable on demand'}
            </span>
            <span className="font-bold text-slate-700">$ USD</span>
          </div>
        </div>
      </div>
    </div>
  );
};
