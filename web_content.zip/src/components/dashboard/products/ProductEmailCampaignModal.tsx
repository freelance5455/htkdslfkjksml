import React, { useState } from 'react';
import { 
  Mail, 
  X, 
  Send, 
  CheckCircle2, 
  Users, 
  Tag, 
  Sparkles,
  Calendar,
  Layers
} from 'lucide-react';
import { Product, Store, Language } from '../../../types';

interface ProductEmailCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeStore: Store;
  products: Product[];
  language: Language;
}

export const ProductEmailCampaignModal: React.FC<ProductEmailCampaignModalProps> = ({
  isOpen,
  onClose,
  activeStore,
  products,
  language
}) => {
  const isBn = language === 'bn';
  const [subject, setSubject] = useState(
    isBn 
      ? `🎉 ${activeStore.name}-এর নতুন কালেকশনে বিশেষ অফার!` 
      : `🎉 Special Offer on New Arrivals at ${activeStore.name}!`
  );
  const [audience, setAudience] = useState<'all' | 'repeat' | 'abandoned' | 'subscribers'>('all');
  const [discountCode, setDiscountCode] = useState('EID20');
  const [discountPercent, setDiscountPercent] = useState(15);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(
    products.slice(0, 3).map(p => p.id)
  );
  const [isSent, setIsSent] = useState(false);
  const [isSending, setIsSending] = useState(false);

  if (!isOpen) return null;

  const handleToggleProduct = (id: string) => {
    if (selectedProductIds.includes(id)) {
      setSelectedProductIds(selectedProductIds.filter(pid => pid !== id));
    } else {
      setSelectedProductIds([...selectedProductIds, id]);
    }
  };

  const handleSendCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setIsSent(true);
      setTimeout(() => {
        setIsSent(false);
        onClose();
      }, 2000);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold border border-purple-200">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                {isBn ? 'ইমেইল মার্কেটিং ক্যাম্পেইন তৈরি করুন' : 'Create Product Email Campaign'}
              </h2>
              <p className="text-xs text-slate-500">
                {isBn ? 'গ্রাহকদের কাছে সরাসরি প্রমোশনাল ইমেইল ব্রডকাস্ট করুন' : 'Engage buyers with promotional email newsletters'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {isSent ? (
          <div className="p-10 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-200 animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900">
              {isBn ? 'ক্যাম্পেইন সফলভাবে সিডিউল হয়েছে!' : 'Campaign Scheduled & Dispatched!'}
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {isBn 
                ? 'আপনার নির্বাচিত অডিয়েন্সের নিকট ইমেইল বার্তাটি নির্ধারিত সময় অনুযায়ী প্রেরণ করা হবে।' 
                : 'Your email campaign newsletter has been sent to the campaign queue.'}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSendCampaign} className="p-6 space-y-4 text-xs text-slate-700">
            {/* Subject Line */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {isBn ? 'ইমেইল বিষয় (Subject Line)' : 'Email Subject Line'}
              </label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-emerald-500 font-medium text-slate-900 text-xs"
              />
            </div>

            {/* Target Audience */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {isBn ? 'টার্গেট অডিয়েন্স (Target Audience)' : 'Recipient Segment'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'all', labelEn: 'All Customers', labelBn: 'সকল গ্রাহক', count: '100%' },
                  { id: 'repeat', labelEn: 'Repeat Buyers', labelBn: 'নিয়মিত ক্রেতা', count: 'High LTV' },
                  { id: 'abandoned', labelEn: 'Abandoned Carts', labelBn: 'অ্যাব্যান্ডনড লিড', count: 'High Intent' },
                  { id: 'subscribers', labelEn: 'Newsletter Leads', labelBn: 'নিউজলেটার সাবস্ক্রাইবার', count: 'Opt-in' }
                ].map((aud) => (
                  <button
                    type="button"
                    key={aud.id}
                    onClick={() => setAudience(aud.id as any)}
                    className={`p-2.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      audience === aud.id
                        ? 'border-purple-600 bg-purple-50 text-purple-900 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span>{isBn ? aud.labelBn : aud.labelEn}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-white border border-slate-200 text-slate-500">
                      {aud.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Promo Code & Discount */}
            <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  {isBn ? 'ডিসকাউন্ট কুপন কোড' : 'Promo Coupon Code'}
                </label>
                <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-xl px-2.5 py-1.5">
                  <Tag className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                  <input
                    type="text"
                    value={discountCode}
                    onChange={(e) => setDiscountCode(e.target.value.toUpperCase())}
                    className="w-full font-mono font-bold text-slate-900 focus:outline-hidden text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  {isBn ? 'ডিসকাউন্ট শতাংশ' : 'Discount Percentage (%)'}
                </label>
                <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-xl px-2.5 py-1.5">
                  <span className="font-bold text-slate-600 text-xs">%</span>
                  <input
                    type="number"
                    min="1"
                    max="90"
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(Number(e.target.value))}
                    className="w-full font-bold text-slate-900 focus:outline-hidden text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Featured Products Selection */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                {isBn ? 'হাইলাইট করার জন্য পণ্য নির্বাচন করুন (Featured Products)' : 'Select Featured Products for Email'}
              </label>
              <div className="max-h-40 overflow-y-auto divide-y divide-slate-100 border border-slate-200 rounded-xl bg-white">
                {products.slice(0, 10).map((prod) => {
                  const isChecked = selectedProductIds.includes(prod.id);
                  return (
                    <div
                      key={prod.id}
                      onClick={() => handleToggleProduct(prod.id)}
                      className={`p-2.5 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-colors ${
                        isChecked ? 'bg-purple-50/40' : ''
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <img 
                          src={prod.image} 
                          alt={prod.name} 
                          className="w-8 h-8 rounded-lg object-cover border border-slate-200" 
                        />
                        <div>
                          <p className="font-bold text-slate-900 line-clamp-1">{prod.name}</p>
                          <p className="text-[10px] text-slate-400">৳ {prod.price.toLocaleString()} · {prod.category}</p>
                        </div>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={isChecked} 
                        onChange={() => {}} 
                        className="rounded text-purple-600 cursor-pointer"
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={isSending || selectedProductIds.length === 0}
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:bg-slate-300 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSending ? (isBn ? 'পাঠানো হচ্ছে...' : 'Sending...') : (isBn ? 'ক্যাম্পেইন লঞ্চ করুন' : 'Launch Campaign')}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
