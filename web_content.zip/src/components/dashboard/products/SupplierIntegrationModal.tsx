import React, { useState } from 'react';
import { 
  Globe, 
  X, 
  CheckCircle2, 
  Truck, 
  Layers, 
  ArrowRight, 
  RefreshCw, 
  ShieldCheck, 
  Settings,
  Sparkles
} from 'lucide-react';
import { Store, Language } from '../../../types';

interface SupplierIntegrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeStore: Store;
  language: Language;
}

export const SupplierIntegrationModal: React.FC<SupplierIntegrationModalProps> = ({
  isOpen,
  onClose,
  activeStore,
  language
}) => {
  const isBn = language === 'bn';
  const [activeTab, setActiveTab] = useState<'suppliers' | 'settings'>('suppliers');
  const [markupPercent, setMarkupPercent] = useState<number>(35);
  const [autoSyncInventory, setAutoSyncInventory] = useState(true);
  const [connectedSuppliers, setConnectedSuppliers] = useState<string[]>(['bd_wholesale', 'steadfast_b2b']);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccessMsg, setSyncSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const suppliers = [
    {
      id: 'bd_wholesale',
      name: 'BD Wholesale Hub (Dhaka)',
      category: 'Fashion & Handloom',
      descriptionEn: 'Direct factory sourcing from Narayanganj and Islampur apparel hubs with next-day inventory dispatch.',
      descriptionBn: 'ইসলামপুর ও নারায়ণগঞ্জ টেক্সটাইল হাব থেকে সরাসরি পাইকারি পোশাক সরবরাহ।'
    },
    {
      id: 'steadfast_b2b',
      name: 'Steadfast B2B Merchant Supply',
      category: 'Lifestyle & Electronics',
      descriptionEn: 'Over 5,000 verified fast-selling SKUs with integrated warehouse fulfillment across Bangladesh.',
      descriptionBn: 'সারা দেশে ক্যাশ অন ডেলিভারিসহ ৫ হাজারের বেশি যাচাইকৃত পণ্যের সরবরাহ।'
    },
    {
      id: 'global_direct',
      name: 'Cross-Border Direct (Global/CN)',
      category: 'Gadgets & Accessories',
      descriptionEn: 'Automated catalog sync with international manufacturers with customs clearance included.',
      descriptionBn: 'আন্তর্জাতিক প্রস্তুতকারকদের থেকে সরাসরি পণ্য আমদানি ও কাস্টমস ক্লিয়ারেন্স।'
    }
  ];

  const handleToggleSupplier = (id: string) => {
    if (connectedSuppliers.includes(id)) {
      setConnectedSuppliers(connectedSuppliers.filter(s => s !== id));
    } else {
      setConnectedSuppliers([...connectedSuppliers, id]);
    }
  };

  const handleTriggerSync = () => {
    setIsSyncing(true);
    setSyncSuccessMsg(null);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncSuccessMsg(
        isBn 
          ? 'সাপ্লায়ার ক্যাটালগ ও স্টক ডাটা সফলভাবে সিঙ্ক সম্পন্ন হয়েছে!' 
          : 'Supplier inventory feeds synced successfully! 18 products updated.'
      );
      setTimeout(() => setSyncSuccessMsg(null), 3000);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold border border-blue-200">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                {isBn ? 'সাপ্লায়ার ও ড্রপশিপিং ইন্টিগ্রেশন' : 'Supplier & Sourcing Integration'}
              </h2>
              <p className="text-xs text-slate-500">
                {isBn ? 'পাইকারি সাপ্লায়ারদের সাথে অটো-ইনভেন্টরি সিঙ্ক করুন' : 'Connect wholesale suppliers and automate stock replenishment'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-100 px-6 pt-2 bg-white text-xs font-bold text-slate-600">
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'suppliers' 
                ? 'border-blue-600 text-blue-700 font-extrabold' 
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            {isBn ? 'সংযুক্ত সাপ্লায়ার্স' : 'Connected Suppliers'}
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'settings' 
                ? 'border-blue-600 text-blue-700 font-extrabold' 
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            {isBn ? 'মার্জিন ও অটো-সিঙ্ক সেটিংস' : 'Pricing Margin & Auto-sync'}
          </button>
        </div>

        {/* Body */}
        <div className="p-6 text-xs text-slate-700 space-y-4">
          {syncSuccessMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-2 font-bold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{syncSuccessMsg}</span>
            </div>
          )}

          {activeTab === 'suppliers' ? (
            <div className="space-y-3">
              {suppliers.map((sup) => {
                const isConnected = connectedSuppliers.includes(sup.id);
                return (
                  <div
                    key={sup.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-blue-300 transition-all shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{sup.name}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                          {sup.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        {isBn ? sup.descriptionBn : sup.descriptionEn}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleSupplier(sup.id)}
                      className={`px-3.5 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer shrink-0 ${
                        isConnected
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-300 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-300'
                          : 'bg-slate-900 text-white hover:bg-slate-800'
                      }`}
                    >
                      {isConnected ? (isBn ? 'সংযুক্ত (Connected)' : 'Connected') : (isBn ? 'সংযুক্ত করুন' : 'Connect')}
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <label className="block text-[11px] font-bold text-slate-900">
                  {isBn ? 'রিটেল প্রফিট মার্জিন শতাংশ' : 'Automated Retail Markup %'}
                </label>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-500 text-sm">+</span>
                  <input
                    type="number"
                    min="5"
                    max="300"
                    value={markupPercent}
                    onChange={(e) => setMarkupPercent(Number(e.target.value))}
                    className="w-32 px-3 py-2 bg-white border border-slate-300 rounded-xl font-black text-slate-900 text-sm focus:outline-blue-500"
                  />
                  <span className="font-bold text-slate-600">% profit over wholesale cost</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  {isBn 
                    ? 'উদাহরণ: সাপ্লায়ারের ১০০০৳ পণ্যে ৩৫% মার্জিন যোগ হয়ে অটোমেটিক ১৩৫০৳ সেলিং প্রাইস সেট হবে।' 
                    : 'Example: A ৳1,000 wholesale product will be listed at ৳1,350 retail price automatically.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl border border-slate-200 bg-white flex items-center justify-between">
                <div>
                  <p className="font-bold text-slate-900">
                    {isBn ? 'স্বয়ংক্রিয় স্টক ও মূল্য আপডেট' : 'Real-time Stock & Price Sync'}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    {isBn ? 'সাপ্লায়ার স্টকের হ্রাস-বৃদ্ধি অনুযায়ী প্রতি ঘণ্টায় সিঙ্ক হবে' : 'Automatically sync changes in wholesale quantities every hour'}
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={autoSyncInventory}
                  onChange={(e) => setAutoSyncInventory(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            onClick={handleTriggerSync}
            disabled={isSyncing}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? (isBn ? 'সিঙ্ক হচ্ছে...' : 'Syncing...') : (isBn ? 'এখনই সিঙ্ক চালান' : 'Run Sync Now')}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            {isBn ? 'সম্পন্ন' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
