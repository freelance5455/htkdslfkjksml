import React, { useState, useRef } from 'react';
import { 
  Upload, 
  X, 
  FileSpreadsheet, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  ArrowRight,
  Package
} from 'lucide-react';
import { Product, Store, Language } from '../../../types';

interface ProductImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeStore: Store;
  language: Language;
  onImportProducts: (products: Omit<Product, 'id'>[]) => void;
}

const SAMPLE_DEMO_PRODUCTS: Omit<Product, 'id'>[] = [
  {
    storeId: '',
    name: 'Premium Silk Embroidered Panjabi',
    nameBn: 'প্রিমিয়াম সিল্ক কারুকাজ করা পাঞ্জাবি',
    sku: 'PANJ-SLK-01',
    category: 'Menswear',
    categoryBn: 'পুরুষদের পোশাক',
    price: 3250,
    compareAtPrice: 3950,
    stock: 45,
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 28,
    description: 'Luxurious silk panjabi featuring delicate neckline hand embroidery. Perfect for wedding and festive occasions.',
    descriptionBn: 'উচ্চমানের সিল্ক কাপড়ে তৈরি সুনিপুণ হাতের কারুকাজ করা আরামদায়ক পাঞ্জাবি।',
    isFeatured: true,
    tags: ['Panjabi', 'Eid', 'Festive', 'Menswear'],
    brand: 'Shanju Crafts',
    status: 'active',
    salesChannels: ['online_store', 'pos', 'facebook'],
    variants: [
      { id: 'v-1', name: 'Size: 40', sku: 'PANJ-SLK-01-40', price: 3250, stock: 15 },
      { id: 'v-2', name: 'Size: 42', sku: 'PANJ-SLK-01-42', price: 3250, stock: 20 },
      { id: 'v-3', name: 'Size: 44', sku: 'PANJ-SLK-01-44', price: 3250, stock: 10 },
    ]
  },
  {
    storeId: '',
    name: 'Traditional Tangail Pure Cotton Saree',
    nameBn: 'ঐতিহ্যবাহী টাঙ্গাইল পিওর সুতি শাড়ি',
    sku: 'SAREE-TNG-08',
    category: 'Womenswear',
    categoryBn: 'মহিলাদের পোশাক',
    price: 2400,
    compareAtPrice: 2850,
    stock: 30,
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 34,
    description: 'Authentic 100% pure cotton handloom saree with woven par. Breathable and comfortable for all-day wear.',
    descriptionBn: 'শতভাগ খাঁটি সুতি সুতায় তাঁতে বোনা আরামদায়ক টাঙ্গাইল শাড়ি।',
    isFeatured: true,
    tags: ['Saree', 'Cotton', 'Traditional', 'Womenswear'],
    brand: 'Tangail Weavers',
    status: 'active',
    salesChannels: ['online_store', 'facebook'],
    variants: [
      { id: 'v-4', name: 'Color: Forest Green', sku: 'SAREE-TNG-08-GRN', price: 2400, stock: 18 },
      { id: 'v-5', name: 'Color: Crimson Red', sku: 'SAREE-TNG-08-RED', price: 2400, stock: 12 },
    ]
  },
  {
    storeId: '',
    name: 'Wireless ANC Over-Ear Headphones',
    nameBn: 'ওয়্যারলেস নয়েজ ক্যানসেলিং হেডফোন',
    sku: 'TECH-ANC-500',
    category: 'Electronics',
    categoryBn: 'ইলেকট্রনিক্স',
    price: 4500,
    compareAtPrice: 5800,
    stock: 20,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
    rating: 4.7,
    reviewsCount: 42,
    description: 'Active Noise Canceling Bluetooth 5.3 headphones with 40-hour battery life and high fidelity bass response.',
    descriptionBn: '৪০ ঘণ্টার ব্যাটারি ব্যাকআপ এবং সুপার বেইস সমৃদ্ধ আধুনিক ব্লুটুথ হেডফোন।',
    isFeatured: false,
    tags: ['Headphones', 'Audio', 'Gadgets', 'Bluetooth'],
    brand: 'AcousticPro',
    status: 'active',
    salesChannels: ['online_store', 'pos'],
    variants: [
      { id: 'v-6', name: 'Matte Black', sku: 'TECH-ANC-500-BLK', price: 4500, stock: 12 },
      { id: 'v-7', name: 'Silver White', sku: 'TECH-ANC-500-SLV', price: 4500, stock: 8 },
    ]
  },
  {
    storeId: '',
    name: 'Pure Sundarban Wild Flower Honey 500g',
    nameBn: 'খাঁটি সুন্দরবনের প্রাকৃতিক মধু ৫০০ গ্রাম',
    sku: 'FOOD-HNY-500',
    category: 'Groceries',
    categoryBn: 'গ্রোসারি ও খাদ্য',
    price: 750,
    compareAtPrice: 850,
    stock: 55,
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 78,
    description: '100% natural, unpasteurized wild raw honey harvested directly from the mangroves of Sundarban.',
    descriptionBn: 'সুন্দরবনের গভীর জঙ্গল থেকে সংগৃহীত শতভাগ খাঁটি ও প্রাকৃতিক বুনো ফুলের মধু।',
    isFeatured: true,
    tags: ['Organic', 'Honey', 'Sundarban', 'Pure Food'],
    brand: 'NatureFresh',
    status: 'active',
    salesChannels: ['online_store', 'pos', 'facebook'],
    variants: [
      { id: 'v-8', name: '500g Glass Jar', sku: 'FOOD-HNY-500G', price: 750, stock: 35 },
      { id: 'v-9', name: '1000g Glass Jar', sku: 'FOOD-HNY-1000G', price: 1400, stock: 20 },
    ]
  }
];

export const ProductImportModal: React.FC<ProductImportModalProps> = ({
  isOpen,
  onClose,
  activeStore,
  language,
  onImportProducts
}) => {
  const isBn = language === 'bn';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedCount, setParsedCount] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownloadSampleCSV = () => {
    const csvContent = 
      "Title,Title_BN,SKU,Category,Price,CompareAtPrice,Stock,Image_URL,Description\n" +
      '"Classic Casual Polo","ক্লাসিক ক্যাজুয়াল পোলো","POLO-01","Menswear",850,1100,50,"https://images.unsplash.com/photo-1596755094514-f87e34085b2c","Breathable 100% pima cotton"\n' +
      '"Leather Formal Shoes","প্রিমিয়াম চামড়ার জুতো","SHOE-02","Footwear",2800,3400,25,"https://images.unsplash.com/photo-1549298916-b41d501d3772","Handmade genuine leather formal shoes"';
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'shanju_products_import_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv') && file.type !== 'text/csv') {
      setErrorMsg(isBn ? 'অনুগ্রহ করে একটি বৈধ CSV ফাইল আপলোড করুন।' : 'Please upload a valid .csv file.');
      return;
    }

    setSelectedFile(file);

    // Read and parse basic CSV lines
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter(l => l.trim().length > 0);
        // Header line + at least one product
        if (lines.length <= 1) {
          setErrorMsg(isBn ? 'ফাইলে কোনো পণ্যের ডাটা পাওয়া যায়নি।' : 'CSV contains no product rows.');
          setParsedCount(null);
        } else {
          setParsedCount(lines.length - 1);
        }
      } catch {
        setErrorMsg(isBn ? 'CSV ফাইল পড়তে সমস্যা হয়েছে।' : 'Failed to parse CSV file.');
      }
    };
    reader.readAsText(file);
  };

  const handleProcessImport = () => {
    if (!selectedFile) return;
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter(l => l.trim().length > 0);
        if (lines.length <= 1) {
          setErrorMsg(isBn ? 'ফাইলে পর্যাপ্ত রো নেই।' : 'No rows found to import.');
          setIsProcessing(false);
          return;
        }

        const importedProducts: Omit<Product, 'id'>[] = [];
        // Skip header
        for (let i = 1; i < lines.length; i++) {
          const row = lines[i].split(',').map(c => c.trim().replace(/^"|"$/g, ''));
          if (row.length >= 5) {
            importedProducts.push({
              storeId: activeStore.id,
              name: row[0] || `Imported Product #${i}`,
              nameBn: row[1] || row[0] || `পণ্য #${i}`,
              sku: row[2] || `IMP-${Math.floor(1000 + Math.random() * 9000)}`,
              category: row[3] || 'General',
              categoryBn: 'সাধারণ',
              price: parseFloat(row[4]) || 500,
              compareAtPrice: row[5] ? parseFloat(row[5]) : undefined,
              stock: row[6] ? parseInt(row[6], 10) : 20,
              image: row[7] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
              description: row[8] || '',
              descriptionBn: '',
              rating: 4.8,
              reviewsCount: 1,
              isFeatured: false,
              tags: ['Imported'],
              status: 'active',
              salesChannels: ['online_store']
            });
          }
        }

        if (importedProducts.length > 0) {
          onImportProducts(importedProducts);
          onClose();
        } else {
          setErrorMsg(isBn ? 'কোনো পণ্য সঠিকভাবে প্রক্রিয়াজাত করা যায়নি।' : 'Could not parse products correctly.');
        }
      } catch {
        setErrorMsg(isBn ? 'ইমপোর্ট করার সময় ত্রুটি ঘটেছে।' : 'Error processing import.');
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsText(selectedFile);
  };

  const handleImportDemoCatalog = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const demoWithStore = SAMPLE_DEMO_PRODUCTS.map(p => ({
        ...p,
        storeId: activeStore.id
      }));
      onImportProducts(demoWithStore);
      setIsProcessing(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold border border-emerald-200">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                {isBn ? 'পণ্য ইমপোর্ট করুন (CSV Import)' : 'Import Products by CSV'}
              </h2>
              <p className="text-xs text-slate-500">
                {isBn ? 'স্প্রেডশিট থেকে বাল্ক পণ্য আপলোড করুন' : 'Bulk upload products from a CSV spreadsheet'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 text-xs text-slate-700">
          {/* Download Sample Template */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Download className="w-4 h-4 text-emerald-700 shrink-0" />
              <div>
                <p className="font-bold text-slate-900">
                  {isBn ? 'নমুনা CSV টেমপ্লেট ডাউনলোড করুন' : 'Download Sample CSV Template'}
                </p>
                <p className="text-[11px] text-slate-500">
                  {isBn ? 'সঠিক কলাম ফরম্যাট যাচাই করতে ব্যবহার করুন' : 'Includes columns for title, price, SKU & stock'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleDownloadSampleCSV}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] transition-colors cursor-pointer shrink-0"
            >
              {isBn ? 'ডাউনলোড' : 'Download'}
            </button>
          </div>

          {/* Upload Area */}
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-6 text-center cursor-pointer transition-colors bg-slate-50/50 hover:bg-emerald-50/30"
          >
            <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="font-bold text-slate-800">
              {selectedFile ? selectedFile.name : (isBn ? 'CSV ফাইল টেনে আনুন অথবা ক্লিক করে আপলোড করুন' : 'Drag & drop your CSV file or click to browse')}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              Supports .csv files up to 10MB
            </p>
            <input 
              ref={fileInputRef} 
              type="file" 
              accept=".csv,text/csv" 
              className="hidden" 
              onChange={handleFileChange}
            />
          </div>

          {parsedCount !== null && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{parsedCount} {isBn ? 'টি পণ্য পাওয়া গেছে এবং প্রস্তুত আছে।' : 'products detected and ready to import.'}</span>
            </div>
          )}

          {errorMsg && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 text-rose-700 font-medium border border-rose-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Divider */}
          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink mx-3 text-slate-400 font-bold text-[10px] uppercase">
              {isBn ? 'অথবা ১-ক্লিক ডেমো ক্যাটালগ' : 'OR 1-CLICK DEMO CATALOG'}
            </span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>

          {/* 1-Click Demo Import */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-[11px]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isBn ? 'তাত্ক্ষণিক ডেমো ক্যাটালগ' : 'Instant Demo Catalog'}</span>
              </div>
              <p className="font-extrabold text-sm tracking-tight text-white">
                {isBn ? '৪টি প্রিমিয়াম পণ্য সরাসরি যুক্ত করুন' : 'Load 4 High-Quality Ready Products'}
              </p>
              <p className="text-[10px] text-slate-300">
                {isBn ? 'পাঞ্জাবি, জামদানি শাড়ি, গ্যাজেট ও প্রাকৃতিক মধু' : 'Silk Panjabi, Cotton Saree, Headphones & Honey'}
              </p>
            </div>
            <button
              type="button"
              onClick={handleImportDemoCatalog}
              disabled={isProcessing}
              className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-colors cursor-pointer shrink-0 shadow-sm"
            >
              {isProcessing ? (isBn ? 'যুক্ত হচ্ছে...' : 'Loading...') : (isBn ? '১-ক্লিক ইমপোর্ট' : '1-Click Import')}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs border border-slate-200 transition-colors cursor-pointer"
          >
            {isBn ? 'বাতিল' : 'Cancel'}
          </button>
          <button
            type="button"
            onClick={handleProcessImport}
            disabled={!selectedFile || isProcessing || parsedCount === null}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
          >
            {isProcessing ? (isBn ? 'ইমপোর্ট হচ্ছে...' : 'Importing...') : (isBn ? 'ফাইল থেকে ইমপোর্ট করুন' : 'Import from File')}
          </button>
        </div>
      </div>
    </div>
  );
};
