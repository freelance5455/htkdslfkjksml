import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Upload, 
  Sparkles, 
  Check, 
  Plus, 
  Trash2, 
  Tag, 
  Image as ImageIcon, 
  Video, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  DollarSign, 
  Boxes,
  Globe,
  Sliders,
  Store
} from 'lucide-react';
import { Product, Store as StoreType, Language, ProductVariant } from '../../../types';
import { compressImageFile } from '../../../utils/storage';

interface ProductEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeStore: StoreType;
  language: Language;
  editingProduct: Product | null;
  onSave: (productData: Omit<Product, 'id'> | Product) => void;
}

const PRESET_IMAGES = [
  { label: 'Panjabi / Ethnic', url: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=600&q=80' },
  { label: 'Saree / Traditional', url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80' },
  { label: 'Casual Shirt', url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=600&q=80' },
  { label: 'Headphones / Audio', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80' },
  { label: 'Smartwatch', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80' },
  { label: 'Organic Honey', url: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80' },
  { label: 'Pure Oil', url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80' },
];

export const ProductEditModal: React.FC<ProductEditModalProps> = ({
  isOpen,
  onClose,
  activeStore,
  language,
  editingProduct,
  onSave
}) => {
  const isBn = language === 'bn';
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [description, setDescription] = useState('');
  const [descriptionBn, setDescriptionBn] = useState('');
  const [price, setPrice] = useState<number>(1200);
  const [compareAtPrice, setCompareAtPrice] = useState<number>(1500);
  const [sku, setSku] = useState('');
  const [stock, setStock] = useState<number>(25);
  const [category, setCategory] = useState('Menswear');
  const [brand, setBrand] = useState(activeStore.name);
  const [status, setStatus] = useState<'active' | 'draft' | 'archived'>('active');
  const [salesChannels, setSalesChannels] = useState<string[]>(['online_store', 'pos', 'facebook']);
  
  // Media State
  const [image, setImage] = useState(PRESET_IMAGES[0].url);
  const [videoUrl, setVideoUrl] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [mediaSourceTab, setMediaSourceTab] = useState<'device' | 'presets' | 'url'>('presets');
  const [isReadingFile, setIsReadingFile] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Variants State
  const [variants, setVariants] = useState<ProductVariant[]>([]);
  const [newVariantName, setNewVariantName] = useState('');
  const [newVariantPrice, setNewVariantPrice] = useState<number>(1200);
  const [newVariantStock, setNewVariantStock] = useState<number>(10);

  // Initialize or Reset form on product change
  useEffect(() => {
    if (editingProduct) {
      setName(editingProduct.name || '');
      setNameBn(editingProduct.nameBn || '');
      setDescription(editingProduct.description || '');
      setDescriptionBn(editingProduct.descriptionBn || '');
      setPrice(editingProduct.price || 0);
      setCompareAtPrice(editingProduct.compareAtPrice || 0);
      setSku(editingProduct.sku || '');
      setStock(editingProduct.stock || 0);
      setCategory(editingProduct.category || 'Menswear');
      setBrand(editingProduct.brand || activeStore.name);
      setStatus(editingProduct.status || 'active');
      setSalesChannels(editingProduct.salesChannels || ['online_store', 'pos', 'facebook']);
      setImage(editingProduct.image || PRESET_IMAGES[0].url);
      setVideoUrl(editingProduct.videoUrl || '');
      setMediaType(editingProduct.mediaType || 'image');
      setVariants(editingProduct.variants || []);
    } else {
      setName('');
      setNameBn('');
      setDescription('');
      setDescriptionBn('');
      setPrice(1200);
      setCompareAtPrice(1500);
      setSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
      setStock(25);
      setCategory('Menswear');
      setBrand(activeStore.name);
      setStatus('active');
      setSalesChannels(['online_store', 'pos', 'facebook']);
      setImage(PRESET_IMAGES[0].url);
      setVideoUrl('');
      setMediaType('image');
      setVariants([]);
    }
  }, [editingProduct, activeStore.name]);

  if (!isOpen) return null;

  const handleFileUpload = async (file: File) => {
    setUploadError(null);
    if (!file.type.startsWith('image/')) {
      setUploadError(isBn ? 'অনুগ্রহ করে ছবি ফাইল আপলোড করুন।' : 'Please upload an image file.');
      return;
    }

    setIsReadingFile(true);
    try {
      const { dataUrl } = await compressImageFile(file, 1200, 1200, 0.85);
      setImage(dataUrl);
      setMediaType('image');
    } catch {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target?.result as string);
        setMediaType('image');
      };
      reader.readAsDataURL(file);
    } finally {
      setIsReadingFile(false);
    }
  };

  const handleToggleSalesChannel = (channel: string) => {
    if (salesChannels.includes(channel)) {
      setSalesChannels(salesChannels.filter(c => c !== channel));
    } else {
      setSalesChannels([...salesChannels, channel]);
    }
  };

  const handleAddVariant = () => {
    if (!newVariantName.trim()) return;
    const newVariant: ProductVariant = {
      id: `var-${Date.now()}`,
      name: newVariantName.trim(),
      sku: `${sku}-${newVariantName.trim().toUpperCase()}`,
      price: newVariantPrice || price,
      stock: newVariantStock || 0
    };
    setVariants([...variants, newVariant]);
    setNewVariantName('');
    setNewVariantStock(10);
  };

  const handleRemoveVariant = (id: string) => {
    setVariants(variants.filter(v => v.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    // Total stock is sum of variants if variants exist
    const finalStock = variants.length > 0 
      ? variants.reduce((sum, v) => sum + v.stock, 0)
      : stock;

    const productPayload: Omit<Product, 'id'> = {
      storeId: activeStore.id,
      name: name.trim(),
      nameBn: nameBn.trim() || name.trim(),
      sku: sku.trim() || `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
      category: category.trim(),
      categoryBn: category.trim(),
      price: Number(price) || 0,
      compareAtPrice: compareAtPrice ? Number(compareAtPrice) : undefined,
      stock: finalStock,
      image,
      videoUrl: videoUrl.trim() || undefined,
      mediaType,
      rating: editingProduct?.rating || 4.8,
      reviewsCount: editingProduct?.reviewsCount || 0,
      description: description.trim(),
      descriptionBn: descriptionBn.trim() || description.trim(),
      isFeatured: editingProduct?.isFeatured || false,
      tags: [category, brand].filter(Boolean),
      brand: brand.trim(),
      status,
      salesChannels,
      variants
    };

    if (editingProduct) {
      onSave({
        ...productPayload,
        id: editingProduct.id
      });
    } else {
      onSave(productPayload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 my-6 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold border border-emerald-200">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                {editingProduct 
                  ? (isBn ? 'পণ্য সম্পাদনা করুন (Edit Product)' : 'Edit Product') 
                  : (isBn ? 'নতুন পণ্য যুক্ত করুন (Add New Product)' : 'Add New Product')}
              </h2>
              <p className="text-xs text-slate-500">
                {isBn 
                  ? 'মূল্য, ইনভেন্টরি, ভ্যারিয়েন্ট এবং সেলস চ্যানেল কনফিগার করুন' 
                  : 'Manage pricing, media, inventory variants and sales channels'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <form id="product-form" onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700 flex-1">
          {/* Section 1: Title & Description */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-2">
              {isBn ? '১. পণ্যের নাম ও বিবরণ' : '1. Product Title & Description'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isBn ? 'পণ্যের নাম (English)' : 'Product Title (English)'} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Classic Embroidered Panjabi"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-emerald-500 font-medium text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isBn ? 'পণ্যের নাম (বাংলা)' : 'Product Title (Bengali)'}
                </label>
                <input
                  type="text"
                  placeholder="যেমন: ক্লাসিক কারুকাজ করা পাঞ্জাবি"
                  value={nameBn}
                  onChange={(e) => setNameBn(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-emerald-500 font-medium text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {isBn ? 'বিস্তারিত বর্ণনা (Description)' : 'Product Description'}
              </label>
              <textarea
                rows={3}
                placeholder="Product material, sizing details, washing guidelines..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl focus:outline-emerald-500 font-medium text-slate-900"
              />
            </div>
          </div>

          {/* Section 2: Images & Media */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-2 flex items-center justify-between">
              <span>{isBn ? '২. পণ্যের ছবি ও মিডিয়া' : '2. Product Media'}</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700">
                {isBn ? 'অটো-কম্প্রেশন সক্রিয়' : 'Auto-compress enabled'}
              </span>
            </h3>

            <div className="flex gap-2 border-b border-slate-100 pb-2">
              <button
                type="button"
                onClick={() => setMediaSourceTab('presets')}
                className={`px-3 py-1 rounded-lg font-bold text-xs transition-colors ${
                  mediaSourceTab === 'presets' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {isBn ? 'প্রিসেট ছবি' : 'Presets'}
              </button>
              <button
                type="button"
                onClick={() => setMediaSourceTab('device')}
                className={`px-3 py-1 rounded-lg font-bold text-xs transition-colors ${
                  mediaSourceTab === 'device' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {isBn ? 'ডিভাইস থেকে আপলোড' : 'Upload File'}
              </button>
              <button
                type="button"
                onClick={() => setMediaSourceTab('url')}
                className={`px-3 py-1 rounded-lg font-bold text-xs transition-colors ${
                  mediaSourceTab === 'url' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {isBn ? 'ওয়েব ইমেজ লিংক' : 'Image URL'}
              </button>
            </div>

            {mediaSourceTab === 'presets' && (
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                {PRESET_IMAGES.map((p, idx) => (
                  <button
                    type="button"
                    key={idx}
                    onClick={() => setImage(p.url)}
                    className={`relative rounded-xl overflow-hidden border-2 transition-all p-0.5 ${
                      image === p.url ? 'border-emerald-600 ring-2 ring-emerald-500/20' : 'border-transparent hover:opacity-80'
                    }`}
                  >
                    <img src={p.url} alt={p.label} className="w-full h-14 object-cover rounded-lg" />
                    <p className="text-[9px] font-bold text-slate-700 truncate mt-1 text-center">{p.label}</p>
                  </button>
                ))}
              </div>
            )}

            {mediaSourceTab === 'device' && (
              <div>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-xl p-5 text-center cursor-pointer bg-slate-50 hover:bg-emerald-50/20 transition-colors"
                >
                  <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                  <p className="font-bold text-slate-800 text-xs">
                    {isReadingFile ? (isBn ? 'ছবি প্রস্তুত হচ্ছে...' : 'Compressing image...') : (isBn ? 'ছবি নির্বাচন করতে ক্লিক করুন' : 'Click to select photo')}
                  </p>
                  <p className="text-[10px] text-slate-400">JPG, PNG, WebP up to 15MB</p>
                  <input 
                    ref={fileInputRef} 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleFileUpload(f);
                    }}
                  />
                </div>
                {uploadError && <p className="text-rose-600 text-[11px] mt-1 font-bold">{uploadError}</p>}
              </div>
            )}

            {mediaSourceTab === 'url' && (
              <div>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-medium"
                />
              </div>
            )}

            {/* Current Image Preview */}
            {image && (
              <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <img src={image} alt="Preview" className="w-12 h-12 rounded-lg object-cover border border-slate-200" />
                <div className="text-[11px]">
                  <p className="font-bold text-slate-800">{isBn ? 'সক্রিয় প্রধান ছবি' : 'Active Main Photo'}</p>
                  <p className="text-slate-400 truncate max-w-sm">{image}</p>
                </div>
              </div>
            )}
          </div>

          {/* Section 3: Pricing & Inventory */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-2">
              {isBn ? '৩. মূল্য নির্ধারণ ও স্টক' : '3. Pricing & Inventory'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isBn ? 'বিক্রয় মূল্য (Price ৳)' : 'Selling Price (৳)'} *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-black text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isBn ? 'পূর্বের মূল্য (Compare Price)' : 'Compare-at Price (৳)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={compareAtPrice}
                  onChange={(e) => setCompareAtPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  SKU (Stock Keeping Unit)
                </label>
                <input
                  type="text"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-slate-900 uppercase"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isBn ? 'স্টক পরিমাণ (Stock Quantity)' : 'Inventory Quantity'} *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  disabled={variants.length > 0}
                  value={variants.length > 0 ? variants.reduce((s, v) => s + v.stock, 0) : stock}
                  onChange={(e) => setStock(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-black text-slate-900 disabled:bg-slate-100"
                />
              </div>
            </div>

            {compareAtPrice > price && (
              <p className="text-[11px] text-emerald-700 font-bold">
                🎉 {Math.round(((compareAtPrice - price) / compareAtPrice) * 100)}% {isBn ? 'ডিসকাউন্ট গ্রাহক দেখতে পাবে।' : 'discount displayed on storefront.'}
              </p>
            )}
          </div>

          {/* Section 4: Variants */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-extrabold text-slate-900 text-sm">
                {isBn ? '৪. পণ্য ভ্যারিয়েন্টস (Variants - Size / Color)' : '4. Variants (Size, Color, Options)'}
              </h3>
              <span className="text-[10px] font-bold text-slate-500">
                {variants.length} {isBn ? 'টি ভ্যারিয়েন্ট' : 'variants'}
              </span>
            </div>

            {/* Existing Variants Table */}
            {variants.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="py-2 px-3">Variant Option</th>
                      <th className="py-2 px-3">SKU</th>
                      <th className="py-2 px-3">Price (৳)</th>
                      <th className="py-2 px-3">Stock</th>
                      <th className="py-2 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {variants.map((v) => (
                      <tr key={v.id}>
                        <td className="py-2.5 px-3 font-bold text-slate-900">{v.name}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-500">{v.sku || '-'}</td>
                        <td className="py-2.5 px-3 font-bold">৳ {(v.price || price).toLocaleString()}</td>
                        <td className="py-2.5 px-3 font-black text-slate-900">{v.stock} units</td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => handleRemoveVariant(v.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Add Variant Form */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  {isBn ? 'অপশনের নাম (যেমন: Size M)' : 'Variant Name (e.g. Size XL)'}
                </label>
                <input
                  type="text"
                  placeholder="e.g. Size 42, Blue"
                  value={newVariantName}
                  onChange={(e) => setNewVariantName(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  Price (৳)
                </label>
                <input
                  type="number"
                  min="0"
                  value={newVariantPrice}
                  onChange={(e) => setNewVariantPrice(Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white font-bold"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  Stock Units
                </label>
                <input
                  type="number"
                  min="0"
                  value={newVariantStock}
                  onChange={(e) => setNewVariantStock(Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white font-bold"
                />
              </div>

              <button
                type="button"
                onClick={handleAddVariant}
                disabled={!newVariantName.trim()}
                className="px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isBn ? 'ভ্যারিয়েন্ট যোগ করুন' : 'Add Variant'}</span>
              </button>
            </div>
          </div>

          {/* Section 5: Category, Status & Sales Channels */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-2">
              {isBn ? '৫. স্ট্যাটাস, ক্যাটাগরি ও সেলস চ্যানেল' : '5. Organization & Sales Channels'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isBn ? 'ক্যাটাগরি (Category)' : 'Category'} *
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl bg-white font-bold text-slate-900"
                >
                  <option value="Menswear">Menswear (পোশাক)</option>
                  <option value="Womenswear">Womenswear (মহিলাদের পোশাক)</option>
                  <option value="Electronics">Electronics (ইলেকট্রনিক্স)</option>
                  <option value="Footwear">Footwear (জুতো)</option>
                  <option value="Groceries">Groceries & Foods (খাদ্যদ্রব্য)</option>
                  <option value="Beauty">Beauty & Cosmetics (প্রসাধন)</option>
                  <option value="Handicrafts">Handicrafts (হস্তশিল্প)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isBn ? 'পণ্য স্ট্যাটাস (Product Status)' : 'Product Status'}
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl bg-white font-bold text-slate-900"
                >
                  <option value="active">Active (সক্রিয় - স্টোরে প্রদর্শিত)</option>
                  <option value="draft">Draft (ড্রাফট - লুকানো থাকবে)</option>
                  <option value="archived">Archived (আর্কাইভ - বিক্রয় বন্ধ)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                {isBn ? 'সক্রিয় সেলস চ্যানেল (Sales Channels)' : 'Active Sales Channels'}
              </label>
              <div className="flex flex-wrap gap-2.5">
                {[
                  { id: 'online_store', label: 'Online Store (ওয়েবসাইট)' },
                  { id: 'pos', label: 'Point of Sale (POS)' },
                  { id: 'facebook', label: 'Facebook / Social Catalog' }
                ].map((sc) => {
                  const isChecked = salesChannels.includes(sc.id);
                  return (
                    <button
                      type="button"
                      key={sc.id}
                      onClick={() => handleToggleSalesChannel(sc.id)}
                      className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        isChecked 
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-800' 
                          : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                      }`}
                    >
                      <Check className={`w-3.5 h-3.5 ${isChecked ? 'text-emerald-600' : 'text-transparent'}`} />
                      <span>{sc.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </form>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs border border-slate-200 transition-colors cursor-pointer"
          >
            {isBn ? 'বাতিল' : 'Cancel'}
          </button>
          <button
            type="submit"
            form="product-form"
            className="px-6 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
          >
            {editingProduct 
              ? (isBn ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save Changes') 
              : (isBn ? 'পণ্য প্রকাশ করুন' : 'Publish Product')}
          </button>
        </div>
      </div>
    </div>
  );
};
