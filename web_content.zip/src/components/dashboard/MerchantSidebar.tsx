import React, { useState } from 'react';
import { 
  Home, 
  ShoppingBag, 
  Package, 
  Users, 
  Percent, 
  FileText, 
  Globe, 
  BarChart3, 
  Sliders, 
  Bot, 
  CreditCard, 
  Settings, 
  ExternalLink, 
  Search, 
  Sparkles, 
  LogOut, 
  Store as StoreIcon, 
  Headphones, 
  CheckCircle2, 
  ChevronRight,
  ChevronDown,
  X,
  Bell,
  Truck,
  TrendingUp,
  Boxes,
  Gift,
  ArrowRightLeft,
  ClipboardList,
  GitBranch,
  MessageSquare,
  PanelLeftClose,
  PanelLeft
} from 'lucide-react';
import { Store, Language, DashboardTab } from '../../types';

interface MerchantSidebarProps {
  activeTab: DashboardTab;
  setActiveTab: (tab: DashboardTab) => void;
  activeStore: Store;
  stores?: Store[];
  onSelectStore?: (storeId: string) => void;
  language: Language;
  onOpenStorefront: () => void;
  onOpenSupportChat: () => void;
  onLogout: () => void;
  pendingOrdersCount: number;
  totalProductsCount: number;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
  userEmail?: string;
  userName?: string;
}

export const MerchantSidebar: React.FC<MerchantSidebarProps> = ({
  activeTab,
  setActiveTab,
  activeStore,
  stores = [],
  onSelectStore,
  language,
  onOpenStorefront,
  onOpenSupportChat,
  onLogout,
  pendingOrdersCount,
  totalProductsCount,
  isMobileOpen,
  setIsMobileOpen,
  userEmail,
  userName
}) => {
  const isBn = language === 'bn';
  const [isStoreSwitcherOpen, setIsStoreSwitcherOpen] = useState(false);

  // Orders Submenu Expanded State
  const isOrderTabActive = [
    'orders', 
    'orders_drafts', 
    'orders_abandoned', 
    'orders_returns',
    'shipping'
  ].includes(activeTab);

  const [isOrdersExpanded, setIsOrdersExpanded] = useState(true);

  // Auto-expand Orders submenu if active
  React.useEffect(() => {
    if (isOrderTabActive) {
      setIsOrdersExpanded(true);
    }
  }, [isOrderTabActive]);

  const orderSubmenuItems: { id: DashboardTab; labelEn: string; labelBn: string }[] = [
    { id: 'orders_drafts', labelEn: 'Drafts', labelBn: 'ড্রাফট' },
    { id: 'shipping', labelEn: 'Shipping labels', labelBn: 'শিপিং লেবেল' },
    { id: 'orders_abandoned', labelEn: 'Abandoned checkouts', labelBn: 'পরিত্যক্ত চেকআউট' },
    { id: 'orders_returns', labelEn: 'Returns', labelBn: 'রিটার্নস' },
  ];

  // Products Submenu Expanded State
  const isProductTabActive = [
    'products', 
    'products_collections', 
    'products_inventory', 
    'inventory',
    'products_purchase_orders', 
    'products_transfers', 
    'products_gift_cards'
  ].includes(activeTab);

  const [isProductsExpanded, setIsProductsExpanded] = useState(true);

  // Auto-expand Products submenu if active
  React.useEffect(() => {
    if (isProductTabActive) {
      setIsProductsExpanded(true);
    }
  }, [isProductTabActive]);

  const productSubmenuItems: { id: DashboardTab; labelEn: string; labelBn: string }[] = [
    { id: 'products', labelEn: 'Products', labelBn: 'পণ্যসমূহ' },
    { id: 'products_collections', labelEn: 'Collections', labelBn: 'কালেকশনস' },
    { id: 'products_inventory', labelEn: 'Inventory', labelBn: 'ইনভেন্টরি' },
    { id: 'products_purchase_orders', labelEn: 'Purchase orders', labelBn: 'পারচেজ অর্ডার' },
    { id: 'products_transfers', labelEn: 'Transfers', labelBn: 'ট্রান্সফার' },
    { id: 'products_gift_cards', labelEn: 'Gift cards', labelBn: 'গিফট কার্ডস' },
  ];

  const handleSelectTab = (tab: DashboardTab) => {
    setActiveTab(tab);
    setIsMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div 
          onClick={() => setIsMobileOpen(false)}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside 
        className={`fixed top-0 bottom-0 left-0 z-50 w-60 bg-[#1a1a1a] text-[#e3e3e3] border-r border-[#2a2a2a] flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Top Header with Shopify-style App Icon and Collapse Toggle */}
        <div className="h-14 px-3.5 border-b border-[#282828] flex items-center justify-between bg-[#141414]">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#008060] flex items-center justify-center text-white font-black shadow-sm">
              <StoreIcon className="w-4 h-4 text-white" />
            </div>
            <div className="leading-tight">
              <span className="font-extrabold text-xs text-white tracking-tight">
                Shanju
              </span>
              <span className="text-[9px] uppercase font-bold tracking-wider px-1 py-0.2 ml-1.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Admin
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsMobileOpen(false)}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <button 
              className="hidden lg:flex p-1 rounded text-slate-400 hover:text-white hover:bg-[#282828] transition-colors cursor-pointer"
              title="Toggle sidebar"
            >
              <PanelLeftClose className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Global Quick Search Pill (Exact Shopify: Search Ctrl+K) */}
        <div className="px-3 pt-2.5 pb-1">
          <button
            onClick={() => handleSelectTab('overview')}
            className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-[#242424] hover:bg-[#2c2c2c] text-slate-400 text-xs border border-[#333333] transition-colors group cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-slate-400 group-hover:text-white transition-colors" />
              <span className="text-[11px] text-slate-400 font-medium">{isBn ? 'অনুসন্ধান' : 'Search'}</span>
            </span>
            <kbd className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#1c1c1c] text-slate-400 border border-[#383838]">
              Ctrl K
            </kbd>
          </button>
        </div>

        {/* Navigation Links Scroll Area */}
        <div className="flex-1 overflow-y-auto px-2.5 py-2 space-y-4 text-xs font-normal">
          {/* Main Navigation Group */}
          <div className="space-y-0.5">
            {/* Home */}
            <button
              onClick={() => handleSelectTab('overview')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'overview'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <Home className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'হোম' : 'Home'}</span>
            </button>

            {/* Orders (Shopify-inspired expandable section) */}
            <div>
              <button
                onClick={() => {
                  handleSelectTab('orders');
                  setIsOrdersExpanded(!isOrdersExpanded);
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                  isOrderTabActive
                    ? 'bg-[#303030] text-white font-semibold'
                    : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ShoppingBag className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>{isBn ? 'অর্ডারস' : 'Orders'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {pendingOrdersCount > 0 && !isOrderTabActive && (
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full font-bold bg-amber-500/20 text-amber-300">
                      {pendingOrdersCount}
                    </span>
                  )}
                  <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform duration-200 ${isOrdersExpanded ? 'rotate-180' : ''}`} />
                </div>
              </button>

              {/* Nested Submenu: All Orders, Draft Orders, Abandoned Checkouts, Returns / Refunds */}
              {isOrdersExpanded && (
                <div className="pl-7 pr-1 pt-1 pb-1 space-y-0.5">
                  {orderSubmenuItems.map((sub) => {
                    const isSubActive = activeTab === sub.id;
                    return (
                      <button
                        key={sub.id}
                        onClick={() => handleSelectTab(sub.id)}
                        className={`w-full text-left px-2 py-1 rounded-md text-[11px] transition-colors cursor-pointer flex items-center justify-between ${
                          isSubActive
                            ? 'text-white font-bold bg-[#383838]'
                            : 'text-[#a3a3a3] hover:text-white hover:bg-[#262626]'
                        }`}
                      >
                        <span>{isBn ? sub.labelBn : sub.labelEn}</span>
                        {sub.id === 'orders' && pendingOrdersCount > 0 && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/30 text-amber-300 font-bold">
                            {pendingOrdersCount}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Shipping & Delivery (Separate section per requirement) */}
            <button
              onClick={() => handleSelectTab('shipping')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'shipping'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <Truck className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'শিপিং ও ডেলিভারি' : 'Shipping & Delivery'}</span>
            </button>

            {/* Products (Active / Expanded with Submenu - EXACT Shopify Reference) */}
            <div>
              <button
                onClick={() => {
                  handleSelectTab('products');
                  setIsProductsExpanded(!isProductsExpanded);
                }}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                  isProductTabActive
                    ? 'bg-[#303030] text-white font-semibold'
                    : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Package className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>{isBn ? 'প্রোডাক্টস' : 'Products'}</span>
                </div>
                {totalProductsCount > 0 && !isProductTabActive && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full font-bold bg-[#383838] text-slate-300">
                    {totalProductsCount}
                  </span>
                )}
              </button>

              {/* Nested Submenu: Products, Collections, Inventory, Purchase orders, Transfers, Gift cards */}
              {isProductsExpanded && (
                <div className="pl-7 pr-1 pt-1 pb-1 space-y-0.5">
                  {productSubmenuItems.map((sub) => {
                    const isSubActive = activeTab === sub.id || (sub.id === 'products_inventory' && activeTab === 'inventory');
                    return (
                      <button
                        key={sub.id}
                        onClick={() => handleSelectTab(sub.id)}
                        className={`w-full text-left px-2 py-1 rounded-md text-[11px] transition-colors cursor-pointer ${
                          isSubActive
                            ? 'text-white font-bold bg-[#383838]'
                            : 'text-[#a3a3a3] hover:text-white hover:bg-[#262626]'
                        }`}
                      >
                        {isBn ? sub.labelBn : sub.labelEn}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Customers */}
            <button
              onClick={() => handleSelectTab('customers')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'customers'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <Users className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'কাস্টমারস' : 'Customers'}</span>
            </button>

            {/* Growth */}
            <button
              onClick={() => handleSelectTab('growth')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'growth'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <TrendingUp className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'গ্রোথ' : 'Growth'}</span>
            </button>

            {/* Discounts */}
            <button
              onClick={() => handleSelectTab('discounts')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'discounts'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <Percent className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'ডিসকাউন্টস' : 'Discounts'}</span>
            </button>

            {/* Content */}
            <button
              onClick={() => handleSelectTab('content')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'content'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <FileText className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'কন্টেন্ট' : 'Content'}</span>
            </button>

            {/* Markets */}
            <button
              onClick={() => handleSelectTab('markets')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'markets'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <Globe className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'মার্কেটস' : 'Markets'}</span>
            </button>

            {/* Analytics */}
            <button
              onClick={() => handleSelectTab('analytics')}
              className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                activeTab === 'analytics'
                  ? 'bg-[#303030] text-white font-semibold'
                  : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{isBn ? 'অ্যানালিটিক্স' : 'Analytics'}</span>
            </button>
          </div>

          {/* Sales Channels Section Header */}
          <div>
            <div className="px-2.5 mb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>{isBn ? 'সেলস চ্যানেল' : 'Sales channels'}</span>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </div>
            <div className="space-y-0.5">
              {/* Online Store */}
              <button
                onClick={() => handleSelectTab('customizer')}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                  activeTab === 'customizer'
                    ? 'bg-[#303030] text-white font-semibold'
                    : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Sliders className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>{isBn ? 'অনলাইন স্টোর' : 'Online Store'}</span>
                </div>
                <div 
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenStorefront();
                  }}
                  className="p-1 hover:text-emerald-400 transition-colors"
                  title="View storefront"
                >
                  <ExternalLink className="w-3 h-3" />
                </div>
              </button>

              {/* Point of Sale */}
              <button
                onClick={() => handleSelectTab('pos')}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                  activeTab === 'pos'
                    ? 'bg-[#303030] text-white font-semibold'
                    : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
                }`}
              >
                <CreditCard className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{isBn ? 'পয়েন্ট অফ সেল' : 'Point of Sale'}</span>
              </button>

              {/* Agentic */}
              <button
                onClick={() => handleSelectTab('agentic')}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                  activeTab === 'agentic' || activeTab === 'copilot'
                    ? 'bg-[#303030] text-white font-semibold'
                    : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
                }`}
              >
                <Bot className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{isBn ? 'এজেন্টিক' : 'Agentic'}</span>
              </button>
            </div>
          </div>

          {/* Apps Section Header */}
          <div>
            <div className="px-2.5 mb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>{isBn ? 'অ্যাপস' : 'Apps'}</span>
              <ChevronRight className="w-3 h-3 text-slate-400" />
            </div>
            <div className="space-y-0.5">
              {/* Flow */}
              <button
                onClick={() => handleSelectTab('flow')}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                  activeTab === 'flow'
                    ? 'bg-[#303030] text-white font-semibold'
                    : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
                }`}
              >
                <GitBranch className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{isBn ? 'ফ্লো' : 'Flow'}</span>
              </button>

              {/* Messaging */}
              <button
                onClick={() => {
                  handleSelectTab('messaging');
                  onOpenSupportChat();
                }}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer text-left ${
                  activeTab === 'messaging'
                    ? 'bg-[#303030] text-white font-semibold'
                    : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{isBn ? 'মেসেজিং' : 'Messaging'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Sidebar: Settings & Quickstart Pill (EXACT Screenshot Match) */}
        <div className="p-2 border-t border-[#282828] bg-[#141414] space-y-1">
          {/* Settings Item */}
          <button
            onClick={() => handleSelectTab('settings')}
            className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-[#303030] text-white font-semibold'
                : 'text-[#cccccc] hover:text-white hover:bg-[#242424]'
            }`}
          >
            <Settings className="w-4 h-4 text-slate-400" />
            <span className="font-medium">{isBn ? 'সেটিংস' : 'Settings'}</span>
          </button>

          {/* Quickstart / Dev Store Pill with Bell (Exact Screenshot) */}
          <div className="relative pt-0.5">
            <div 
              onClick={() => setIsStoreSwitcherOpen(!isStoreSwitcherOpen)}
              className="flex items-center justify-between p-2 rounded-lg bg-[#242424] hover:bg-[#2a2a2a] border border-[#333333] transition-colors cursor-pointer select-none"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-4 h-4 rounded bg-[#e11d48] text-white flex items-center justify-center font-bold text-[8px] shrink-0">
                  {activeStore.name.slice(0, 1).toUpperCase()}
                </div>
                <div className="truncate text-left leading-none flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-white truncate max-w-[90px]">
                    {activeStore.name}
                  </span>
                  <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-[#333333] text-slate-300">
                    dev
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-slate-400">
                <Bell className="w-3.5 h-3.5 text-slate-400 hover:text-white" />
              </div>
            </div>

            {/* Store Switcher & Logout Dropdown */}
            {isStoreSwitcherOpen && (
              <div className="absolute bottom-full left-0 right-0 mb-2 bg-[#202020] border border-[#383838] rounded-xl shadow-2xl p-2 text-xs z-50 animate-in fade-in slide-in-from-bottom-2">
                <div className="px-2 py-1.5 border-b border-[#303030] mb-1">
                  <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                    {isBn ? 'মার্চেন্ট অ্যাকাউন্ট' : 'Merchant Account'}
                  </p>
                  <p className="text-xs font-semibold text-white truncate">
                    {userName || userEmail || 'Merchant'}
                  </p>
                  <p className="text-[10px] text-slate-400 truncate">
                    {userEmail}
                  </p>
                </div>

                {stores.length > 1 && (
                  <div className="py-1 border-b border-[#303030] mb-1">
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider px-2 mb-1">
                      {isBn ? 'আপনার স্টোরসমূহ' : 'Your Stores'}
                    </p>
                    {stores.map((s) => (
                      <button
                        key={s.id}
                        onClick={() => {
                          if (onSelectStore) onSelectStore(s.id);
                          setIsStoreSwitcherOpen(false);
                        }}
                        className={`w-full text-left px-2 py-1.5 rounded-lg flex items-center justify-between ${
                          s.id === activeStore.id 
                            ? 'bg-[#303030] text-emerald-400 font-bold' 
                            : 'text-slate-300 hover:bg-[#282828]'
                        }`}
                      >
                        <span className="truncate">{s.name}</span>
                        {s.id === activeStore.id && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                      </button>
                    ))}
                  </div>
                )}

                <button
                  onClick={onLogout}
                  className="w-full flex items-center gap-2 px-2 py-1.5 text-rose-400 hover:bg-rose-500/10 rounded-lg font-bold transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{isBn ? 'লগআউট' : 'Sign Out'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};
