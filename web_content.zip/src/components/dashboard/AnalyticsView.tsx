import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  ShoppingBag, 
  DollarSign, 
  ArrowUpRight, 
  CheckCircle2,
  Calendar,
  Smartphone,
  CreditCard
} from 'lucide-react';
import { Order, Language, Store } from '../../types';

interface AnalyticsViewProps {
  orders: Order[];
  language: Language;
  activeStore: Store;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  orders,
  language,
  activeStore
}) => {
  const isBn = language === 'bn';
  const storeOrders = orders.filter(o => o.storeId === activeStore.id);
  const totalSales = storeOrders.reduce((sum, o) => sum + (o.paymentStatus === 'paid' ? o.totalAmount : 0), 0);
  const totalOrders = storeOrders.length;
  const avgOrderValue = totalOrders > 0 ? Math.round(totalSales / totalOrders) : 0;

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-600" />
            <span>{isBn ? 'স্টোর অ্যানালিটিক্স ও সেলস রিপোর্ট' : 'Analytics & Sales Intelligence'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {isBn 
              ? 'বিক্রয় বৃদ্ধি, রূপান্তর হার (Conversion Rate) ও কাস্টমার ট্রাফিকের বিশদ চিত্র।' 
              : 'Monitor real-time sales trends, checkout conversion rate, and store traffic patterns.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-100 text-slate-700 border border-slate-200">
            {isBn ? '📅 গত ৩০ দিন' : '📅 Last 30 Days'}
          </span>
        </div>
      </div>

      {/* Analytics KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500">{isBn ? 'মোট বিক্রয়' : 'Total Sales'}</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">৳{totalSales.toLocaleString()}</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded flex items-center gap-0.5">
              <ArrowUpRight className="w-3 h-3" /> +24%
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">{isBn ? 'গত মাসের চেয়ে বৃদ্ধি' : 'vs last month'}</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500">{isBn ? 'অনলাইন স্টোর সেশন' : 'Store Sessions'}</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">12,480</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded flex items-center gap-0.5">
              <ArrowUpRight className="w-3 h-3" /> +19%
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">{isBn ? '৮৪% মোবাইল ভিজিটর' : '84% mobile visitors'}</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500">{isBn ? 'কনভার্সন রেট' : 'Online Store Conversion'}</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">3.65%</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded flex items-center gap-0.5">
              <ArrowUpRight className="w-3 h-3" /> +0.8%
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">{isBn ? 'শিল্পের গড়ের চেয়ে ভালো' : 'Above industry benchmark'}</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <span className="text-xs font-semibold text-slate-500">{isBn ? 'গড় অর্ডার সাইজ' : 'Average Order Value'}</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">৳{avgOrderValue.toLocaleString()}</span>
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
              Healthy
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">{isBn ? 'প্রতি কার্টে গড় পণ্যের মূল্য' : 'Average spend per customer'}</span>
        </div>
      </div>

      {/* Traffic & Payment Methods Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <h3 className="font-bold text-slate-900 text-sm mb-4 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'পেমেন্ট মেথড অনুযায়ী বিক্রি' : 'Sales by Payment Method'}</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between font-semibold mb-1 text-slate-700">
                <span>bKash / Nagad Instant</span>
                <span>65% (৳{(totalSales * 0.65).toFixed(0)})</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                <div className="h-full bg-pink-500 rounded-full" style={{ width: '65%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between font-semibold mb-1 text-slate-700">
                <span>Cash on Delivery (COD)</span>
                <span>28% (৳{(totalSales * 0.28).toFixed(0)})</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: '28%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between font-semibold mb-1 text-slate-700">
                <span>Debit / Credit Cards</span>
                <span>7% (৳{(totalSales * 0.07).toFixed(0)})</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: '7%' }}></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <h3 className="font-bold text-slate-900 text-sm mb-4 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'ডিভাইস ও ট্রাফিক সোর্স' : 'Traffic by Device'}</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="font-semibold text-slate-700">📱 Mobile (Android & iOS)</span>
              <span className="font-bold text-slate-900">84.2%</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="font-semibold text-slate-700">💻 Desktop / Laptop</span>
              <span className="font-bold text-slate-900">14.1%</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="font-semibold text-slate-700">📟 Tablet</span>
              <span className="font-bold text-slate-900">1.7%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
