import React, { useState } from 'react';
import { 
  Coins, 
  Flame, 
  ArrowUpRight, 
  Clock, 
  ChevronRight, 
  CheckCircle2, 
  AlertCircle,
  Crown,
  History,
  Sparkles,
  Zap,
  Play,
  Tv,
  Smartphone,
  Share2,
  Gift,
  Download,
  Copy,
  Check,
  MessageSquareHeart,
  MapPin,
  ClipboardList,
  Globe,
  Calculator,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { Task } from '../../types';
import { TaskDetailsModal } from '../tasks/TaskDetailsModal';
import { YouTubeWatchSection } from '../youtube/YouTubeWatchSection';
import { AppTasksSection } from '../apps/AppTasksSection';
import { SocialTasksSection } from '../social/SocialTasksSection';
import { DailyStreakModal } from '../streak/DailyStreakModal';
import { VisitLinkRandomModal } from '../links/VisitLinkRandomModal';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { ApkInstallModal } from '../pwa/ApkInstallModal';
import { AppShareModal } from '../pwa/AppShareModal';
import { AppFeedbackModal } from '../feedback/AppFeedbackModal';
import { DailyCheckinStreakCard } from './DailyCheckinStreakCard';
import { EarningsSparklineCard } from './EarningsSparklineCard';
import { CommunityStatsAndActivityCard } from './CommunityStatsAndActivityCard';
import { WithdrawalDailyHistoryCard } from './WithdrawalDailyHistoryCard';
import { GlobalLeaderboard } from '../leaderboard/GlobalLeaderboard';
import { DashboardSkeleton } from '../common/SkeletonLoader';
import { GoldBullionVisual } from '../common/GoldBullionVisual';
import { SilverBullionVisual } from '../common/SilverBullionVisual';
import { SipCalculator } from '../investment/SipCalculator';
import { GovtLicenseBadge } from '../common/GovtLicenseBadge';

interface DashboardViewProps {
  onOpenTasks: () => void;
  onOpenWallet: () => void;
  onOpenMembership: () => void;
  onOpenGoogleTasks: () => void;
  onOpenVipTasks: () => void;
  onOpenGames: () => void;
  onOpenDownloadApp?: () => void;
  onStartTask: (task: Task) => void;
  onOpenReferrals?: () => void;
  onOpenAuth?: () => void;
  onOpenAiVoice?: (query?: string) => void;
  onOpenInvestments?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenTasks,
  onOpenWallet,
  onOpenMembership,
  onOpenGoogleTasks,
  onOpenVipTasks,
  onOpenGames,
  onOpenDownloadApp,
  onStartTask,
  onOpenReferrals,
  onOpenAuth,
  onOpenAiVoice,
  onOpenInvestments,
}) => {
  const { 
    currentUser, 
    tasks, 
    membershipPlans, 
    getUserDailyTaskCount,
    transactions,
    systemSettings,
    language,
    isDataLoading,
    t 
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isProfessionalMode, setIsProfessionalMode] = useState<boolean>(() => {
    return localStorage.getItem('taskearn_pro_mode') !== 'false';
  });
  const [isStreakModalOpen, setIsStreakModalOpen] = useState(false);
  const [isRandomLinkModalOpen, setIsRandomLinkModalOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const [isSipCalcModalOpen, setIsSipCalcModalOpen] = useState(false);
  const [selectedTaskForDetails, setSelectedTaskForDetails] = useState<Task | null>(null);

  // Real-time Gold & Silver Live Market Prices
  const [livePrices, setLivePrices] = useState({
    gold: 7325.80,
    silver: 89.75,
    goldChange: 1.65,
    silverChange: 2.18,
    lastUpdated: 'Live'
  });

  React.useEffect(() => {
    const fetchLivePrices = async () => {
      try {
        const res = await fetch('/api/metal/prices');
        const json = await res.json();
        if (json.success && json.data) {
          setLivePrices({
            gold: json.data.gold.pricePerGram || 7325.80,
            silver: json.data.silver.pricePerGram || 89.75,
            goldChange: json.data.gold.change24h || 1.65,
            silverChange: json.data.silver.change24h || 2.18,
            lastUpdated: new Date(json.data.gold.lastUpdated).toLocaleTimeString()
          });
        }
      } catch {
        // Fallback gracefully
      }
    };
    fetchLivePrices();
    const interval = setInterval(fetchLivePrices, 30000);
    return () => clearInterval(interval);
  }, []);

  const { isInstalled } = usePWAInstall();

  const handleCopyAppLink = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://taskearn.pro';
    const ref = currentUser?.referralCode || 'EARN100';
    navigator.clipboard.writeText(`${origin}?ref=${ref}`);
    setCopiedLink(true);
    confetti({
      particleCount: 40,
      spread: 45,
      origin: { y: 0.7 }
    });
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const currentCoins = currentUser?.coins ?? 450;
  const lifetimeEarned = currentUser?.lifetimeCoins ?? 820;
  const totalWithdrawn = currentUser?.withdrawnCoins ?? 300;
  const rate = systemSettings?.coinsPerCurrencyUnit ?? 100;
  const inrValue = ((currentCoins ?? 0) / (rate || 100)).toFixed(2);

  const currentPlan = currentUser
    ? membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0]
    : membershipPlans[0];

  const tasksDoneToday = getUserDailyTaskCount();
  const dailyLimit = currentPlan?.dailyTaskLimit ?? 10;

  const categories = [
    'All',
    'Facebook (10 Coins)',
    'Daily (12 Coins)',
    'Watch & Earn',
    'Survey',
    'App Tasks',
    'Social',
    'VIP'
  ];

  // Filter tasks based on chip
  const filteredTasks = tasks.filter(task => {
    if (!task.isActive) return false;
    if (selectedCategory === 'All') return true;
    if (selectedCategory === 'Facebook (10 Coins)') return task.category === 'social_facebook' || task.id.startsWith('task-fb-');
    if (selectedCategory === 'Daily (12 Coins)') return task.category === 'daily_checkin';
    if (selectedCategory === 'VIP') return task.category === 'vip_task';
    if (selectedCategory === 'Survey') return task.category === 'survey';
    if (selectedCategory === 'Watch & Earn') return task.category === 'video_demo' || task.category === 'game' || task.category === 'youtube_watch';
    if (selectedCategory === 'App Tasks') return task.category === 'external_partner' || task.category === 'google_tasks' || task.category === 'app_download';
    if (selectedCategory === 'Social') return task.category === 'review' || task.category === 'quiz' || task.category === 'social_facebook';
    return true;
  });

  if (isDataLoading) {
    return <DashboardSkeleton />;
  }

  return (
    <div className="max-w-xl mx-auto space-y-2.5 sm:space-y-4 px-1 sm:px-0 pb-24 animate-in fade-in duration-200">
      
      {/* Official Government Registration & License Certificate Header */}
      <GovtLicenseBadge />

      {/* Onboarding / Login / Google Sign-up Prominent Card at the top */}
      {!currentUser && (
        <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/40 shadow-2xl text-center space-y-4 relative overflow-hidden animate-in fade-in duration-300">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/10 rounded-full blur-xl pointer-events-none" />
          
          <div className="space-y-1.5 relative z-10">
            <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              🎁 Welcome Friends! 🎁
            </span>
            <h2 className="text-sm sm:text-base font-black text-white tracking-tight">
              Create Your Account & Start Earning!
            </h2>
            <p className="text-[10px] sm:text-[11px] text-slate-300 max-w-sm mx-auto leading-relaxed">
              Sign up in seconds to complete tasks, watch videos, refer friends, and withdraw real money directly to your UPI ID!
            </p>
          </div>

          <div className="flex flex-col gap-2 max-w-xs mx-auto relative z-10">
            {/* Google Quick Sign-Up */}
            <button
              onClick={() => {
                if (onOpenAuth) onOpenAuth();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer active:scale-98"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.18 1-.78 1.85-1.63 2.42v2.81h2.64c1.55-2.42 2.63-5.99 2.63-9.24z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-2.64-2.81c-.73.49-1.66.78-2.64.78-2.73 0-5.04-1.84-5.86-4.31H1.14v2.91C2.95 20.35 7.18 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M6.14 14C5.93 13.33 5.82 12.63 5.82 12s.11-1.33.32-2V7.09H1.14C.41 8.54 0 10.21 0 12s.41 3.46 1.14 4.91L6.14 14z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.18 1 2.95 3.65 1.14 7.09l5 3.91C6.96 8.54 9.27 5.38 12 5.38z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            {/* Email Registration & Sign In */}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  if (onOpenAuth) onOpenAuth();
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Sign In
              </button>
              <button
                onClick={() => {
                  if (onOpenAuth) onOpenAuth();
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition-colors cursor-pointer"
              >
                Register
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clean Balance Card at the Top - Ultra-Mobile Responsive */}
      <div className={`p-2.5 sm:p-4 md:p-5 rounded-2xl sm:rounded-3xl border transition-all duration-300 relative overflow-hidden space-y-2.5 sm:space-y-4 ${
        isProfessionalMode 
          ? 'bg-gradient-to-b from-indigo-950/90 via-slate-900 to-slate-950 border-amber-500/40 shadow-2xl shadow-amber-500/5' 
          : 'bg-gradient-to-b from-slate-900/90 to-slate-950 border-slate-800 shadow-xl'
      }`}>
        {isProfessionalMode && (
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none animate-pulse" />
        )}

        <div className="flex items-start justify-between relative z-10">
          <div className="space-y-0.5 sm:space-y-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[9px] sm:text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                Available Balance
              </span>
              {isProfessionalMode && (
                <span className="px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[8px] font-black uppercase tracking-widest animate-bounce">
                  PRO Mode
                </span>
              )}
            </div>
            <div className="flex items-baseline gap-1 sm:gap-2">
              <h2 className="text-xl sm:text-3xl font-black text-white tracking-tight">
                {(currentCoins ?? 0).toLocaleString()} <span className="text-amber-400 text-sm sm:text-2xl font-bold">Coins</span>
              </h2>
            </div>
            <p className="text-[10px] sm:text-xs font-semibold text-emerald-400">
              ≈ ₹{inrValue} INR
            </p>
          </div>

          <span className={`text-[9px] sm:text-[11px] font-bold px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full shrink-0 border ${
            isProfessionalMode 
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/35' 
              : 'bg-slate-800 text-slate-300 border-slate-700/60'
          }`}>
            {(currentPlan?.name ?? 'VIP 1').split(':')[0]}
          </span>
        </div>

        {/* Secondary Metrics */}
        <div className="grid grid-cols-2 gap-1.5 sm:gap-3 pt-2 sm:pt-3 border-t border-slate-800/80 text-xs relative z-10">
          <div>
            <span className="text-slate-500 text-[9px] sm:text-[11px] block">Lifetime Earned</span>
            <span className="font-bold text-slate-200 text-[11px] sm:text-sm">{(lifetimeEarned ?? 0).toLocaleString()} Coins</span>
          </div>
          <div>
            <span className="text-slate-500 text-[9px] sm:text-[11px] block">Withdrawn</span>
            <span className="font-bold text-slate-200 text-[11px] sm:text-sm">{(totalWithdrawn ?? 0).toLocaleString()} Coins</span>
          </div>
        </div>

        {/* Action Buttons - Min 44px Touch Target */}
        <div className="grid grid-cols-2 gap-1.5 sm:gap-2.5 pt-0.5 relative z-10">
          <button
            type="button"
            onClick={onOpenWallet}
            className={`w-full min-h-[44px] py-2 px-2.5 sm:px-3 rounded-xl font-black text-[11px] sm:text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              isProfessionalMode 
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/10' 
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
            }`}
          >
            <span>Withdraw</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onOpenWallet}
            className="w-full min-h-[44px] py-2 px-2.5 sm:px-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700/80 text-slate-200 font-bold text-[11px] sm:text-xs active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            <History className="w-3.5 h-3.5 text-slate-400" />
            <span>Earning History</span>
          </button>
        </div>

        {/* Professional Mode Toggler bar */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px] sm:text-xs text-slate-400 relative z-10">
          <div className="flex items-center gap-1.5">
            <span className={`w-1.5 h-1.5 rounded-full ${isProfessionalMode ? 'bg-amber-400 animate-pulse' : 'bg-slate-500'}`} />
            <span>Professional Golden Mode Theme</span>
          </div>
          <button
            type="button"
            onClick={() => {
              const nextState = !isProfessionalMode;
              setIsProfessionalMode(nextState);
              localStorage.setItem('taskearn_pro_mode', String(nextState));
              confetti({ particleCount: 30, spread: 45 });
            }}
            className={`px-2.5 py-1 rounded-lg font-black uppercase text-[9px] tracking-wider transition-all cursor-pointer ${
              isProfessionalMode 
                ? 'bg-amber-500 text-slate-950' 
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            {isProfessionalMode ? 'PRO ON ✓' : 'PRO OFF'}
          </button>
        </div>
      </div>

      {/* Live Gold & Silver Bullion Market Rates Ticker */}
      <div 
        onClick={() => { if (onOpenInvestments) onOpenInvestments(); }} 
        className="p-3 sm:p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 via-amber-950/20 to-slate-900 border border-amber-500/30 hover:border-amber-400/60 shadow-lg cursor-pointer transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
      >
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400/50 shrink-0" />
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-black text-white">Live Bullion Rates (লাইভ রেট):</span>
            <span className="text-[10px] text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">MCX / IBJA Live Spot</span>
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4 divide-x divide-slate-800 text-xs">
          {/* Gold Live */}
          <div className="flex items-center gap-2">
            <span className="text-base">🏆</span>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-bold text-slate-300">Gold 24K:</span>
                <span className="font-mono font-black text-amber-300">₹{livePrices.gold.toFixed(2)}/g</span>
                <span className="text-[10px] font-bold text-emerald-400">+{livePrices.goldChange}%</span>
              </div>
            </div>
          </div>

          {/* Silver Live */}
          <div className="flex items-center gap-2 pl-3 sm:pl-4">
            <span className="text-base">🥈</span>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-bold text-slate-300">Silver 999:</span>
                <span className="font-mono font-black text-slate-100">₹{livePrices.silver.toFixed(2)}/g</span>
                <span className="text-[10px] font-bold text-emerald-400">+{livePrices.silverChange}%</span>
              </div>
            </div>
          </div>

          <div className="pl-3 sm:pl-4 hidden sm:flex items-center gap-1 text-[11px] font-bold text-amber-400 group-hover:translate-x-1 transition-transform">
            <span>Trade →</span>
          </div>
        </div>
      </div>

      {/* 3 Main Feature Cards: Gold, Silver & Tasks */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Gold Feature Card */}
        <div 
          onClick={() => { if (onOpenInvestments) onOpenInvestments(); }}
          className="p-4 rounded-3xl bg-gradient-to-br from-amber-950/80 via-slate-900 to-slate-950 border border-amber-500/50 hover:border-amber-400 shadow-xl shadow-amber-500/10 cursor-pointer group transition-all relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center justify-between z-10">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/25 text-amber-300 border border-amber-500/40">
              24K Hallmarked
            </span>
            <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Live +{livePrices.goldChange}%
            </span>
          </div>

          {/* Realistic Gold Bullion Visual Illustration */}
          <div className="py-2 flex items-center justify-center group-hover:scale-105 transition-transform duration-300 z-10">
            <GoldBullionVisual size="sm" showDetails={true} className="w-full max-w-[130px] h-20" />
          </div>

          <div className="z-10 space-y-1">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-black text-white group-hover:text-amber-300 transition-colors flex items-center gap-1">
                <span>Digital Gold</span>
                <span className="text-[10px] text-amber-400 font-normal">999.9</span>
              </h4>
              <span className="text-xs font-black text-amber-300 font-mono">₹{livePrices.gold.toFixed(2)}/g</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-snug">₹5,000 Digital Gold Holding (24K Gold Vault with Live Market Performance)</p>
          </div>

          <div className="pt-2 mt-1 border-t border-amber-500/20 flex items-center justify-between text-xs font-bold text-amber-400 z-10">
            <span className="group-hover:underline">Invest in Gold</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </div>
        </div>

        {/* Silver Feature Card */}
        <div 
          onClick={() => { if (onOpenInvestments) onOpenInvestments(); }}
          className="p-4 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/70 to-slate-950 border border-cyan-500/50 hover:border-cyan-400 shadow-xl shadow-cyan-500/10 cursor-pointer group transition-all relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-cyan-500/15 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center justify-between z-10">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-cyan-500/25 text-cyan-300 border border-cyan-500/40">
              999 Pure Silver
            </span>
            <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Live +{livePrices.silverChange}%
            </span>
          </div>

          {/* Realistic Silver Bullion Visual Illustration */}
          <div className="py-2 flex items-center justify-center group-hover:scale-105 transition-transform duration-300 z-10">
            <SilverBullionVisual size="sm" showDetails={true} className="w-full max-w-[130px] h-20" />
          </div>

          <div className="z-10 space-y-1">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-black text-white group-hover:text-cyan-300 transition-colors flex items-center gap-1">
                <span>Digital Silver</span>
                <span className="text-[10px] text-cyan-300 font-normal">Pure 999</span>
              </h4>
              <span className="text-xs font-black text-cyan-300 font-mono">₹{livePrices.silver.toFixed(2)}/g</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-snug">Pure 999 Silver • Instant UPI Buy/Sell • Secure Storage</p>
          </div>

          <div className="pt-2 mt-1 border-t border-cyan-500/20 flex items-center justify-between text-xs font-bold text-cyan-400 z-10">
            <span className="group-hover:underline">Explore Silver</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </div>
        </div>

        {/* Tasks Feature Card */}
        <div 
          onClick={onOpenTasks}
          className="p-4 rounded-3xl bg-gradient-to-br from-slate-900 via-purple-950/70 to-slate-950 border border-purple-500/50 hover:border-purple-400 shadow-xl shadow-purple-500/10 cursor-pointer group transition-all relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-purple-500/15 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center justify-between z-10">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/25 text-purple-300 border border-purple-500/40">
              100,000+ Tasks Live
            </span>
            <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              Daily Earning
            </span>
          </div>

          {/* Glowing Task Visual Badge */}
          <div className="py-2 flex items-center justify-center group-hover:scale-105 transition-transform duration-300 z-10">
            <div className="w-24 h-20 rounded-2xl bg-gradient-to-tr from-purple-900/60 via-indigo-900/50 to-purple-800/40 border border-purple-400/40 flex flex-col items-center justify-center p-2 shadow-lg shadow-purple-900/40">
              <span className="text-2xl mb-1">📋</span>
              <span className="text-[10px] font-black text-purple-200 uppercase tracking-wider">Earn Coins</span>
              <span className="text-[9px] text-emerald-400 font-bold">₹500 - ₹800/Day</span>
            </div>
          </div>

          <div className="z-10 space-y-1">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-black text-white group-hover:text-purple-300 transition-colors">Task Center</h4>
              <span className="text-xs font-black text-purple-300">{tasks.length} Active</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-snug">Surveys, YouTube 30s, FB Likes/Shares & App Installs</p>
          </div>

          <div className="pt-2 mt-1 border-t border-purple-500/20 flex items-center justify-between text-xs font-bold text-purple-400 z-10">
            <span className="group-hover:underline">Start Tasks</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </div>
        </div>
      </div>

      {/* Task Earn Pro - Main Navigation Cards & Gold/Silver Banner */}
      <div className="space-y-3">
        {/* Exact User Requested Bengali Notice & Action Buttons Card */}
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/80 to-slate-950 border border-amber-500/40 shadow-xl space-y-3 text-xs text-slate-200">
          <div className="space-y-1">
            <h4 className="text-sm font-black text-amber-400 flex items-center gap-1.5">
              <span>🎁</span>
              <span>বন্ধুকে Invite করুন, ₹50 Bonus পান!</span>
            </h4>
            <p className="text-slate-300 leading-relaxed">
              আপনার Referral Link শেয়ার করুন। আপনার বন্ধু সেই লিংক ব্যবহার করে ₹200-এর VIP Plan কিনে সফলভাবে payment করলে আপনি পাবেন ₹50 Referral Bonus।
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-1.5 text-[11px]">
            <div className="font-bold text-amber-300">💳 VIP Payment (VIP Plan: ₹200)</div>
            <p className="text-slate-400">
              Payment করার পর চাইলে Gallery থেকে Payment Screenshot আপলোড করে Payment Proof Submit করতে পারবেন।
            </p>
            <p className="text-rose-400 text-[10px] font-semibold">
              Important: Screenshot upload করলেই payment automatically verified হবে না। Admin/payment gateway verification সফল হওয়ার পরেই VIP activation এবং ₹50 referral bonus credit হবে।
            </p>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                if (onOpenMembership) onOpenMembership();
              }}
              className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              <span>[Buy VIP ₹200]</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onOpenMembership) onOpenMembership();
              }}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-amber-300 font-bold text-[11px] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              <span>[Upload Screenshot]</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onOpenMembership) onOpenMembership();
              }}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-emerald-400 font-bold text-[11px] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              <span>[Submit Proof]</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onOpenReferrals) onOpenReferrals();
              }}
              className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              <span>[My Referral Link]</span>
            </button>
          </div>
        </div>

        {/* Premium Banner */}
        <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-950/90 via-slate-900 to-cyan-950/90 border border-amber-500/50 shadow-xl relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="absolute top-0 right-0 w-40 h-40 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left relative z-10">
            {/* Visuals Preview */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="w-16 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center p-1 shadow-md shadow-amber-500/10">
                <GoldBullionVisual size="sm" showDetails={false} className="w-14 h-12" />
              </div>
              <div className="w-16 h-14 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center p-1 shadow-md shadow-cyan-500/10">
                <SilverBullionVisual size="sm" showDetails={false} className="w-14 h-12" />
              </div>
            </div>

            <div className="space-y-1">
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                🏆 Precious Metals • Gold & Silver
              </span>
              <h3 className="text-base font-black text-white tracking-tight">
                Buy & Accumulate 24K Digital Gold & Pure Silver
              </h3>
              <p className="text-xs text-slate-300">
                Live Market Rates • Min ₹100 • Instant UPI Buy/Sell • Secure Insured Vaults
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 z-10">
            <button
              type="button"
              onClick={() => setIsSipCalcModalOpen(true)}
              className="px-3.5 py-3 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-amber-300 border border-amber-500/50 font-bold text-xs shadow-md cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
            >
              <Calculator className="w-4 h-4 text-amber-400" />
              <span>SIP Calculator</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (onOpenInvestments) onOpenInvestments();
              }}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 cursor-pointer shrink-0 transition-all active:scale-95"
            >
              Start Investing →
            </button>
          </div>
        </div>

        {/* 6 Core Navigation Cards */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
          <button
            onClick={onOpenTasks}
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center space-y-1.5 cursor-pointer group transition-all"
          >
            <div className="w-8 h-8 mx-auto rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center font-bold text-sm group-hover:scale-110 transition-transform">
              📋
            </div>
            <span className="text-[11px] font-bold text-slate-200 block truncate">Tasks</span>
          </button>

          <button
            onClick={() => { if (onOpenInvestments) onOpenInvestments(); }}
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-amber-500/40 text-center space-y-1.5 cursor-pointer group transition-all shadow-md shadow-amber-500/5"
          >
            <div className="w-8 h-8 mx-auto rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center font-bold text-sm group-hover:scale-110 transition-transform">
              🏆
            </div>
            <span className="text-[11px] font-bold text-amber-300 block truncate">Digital Gold</span>
          </button>

          <button
            onClick={() => { if (onOpenInvestments) onOpenInvestments(); }}
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-center space-y-1.5 cursor-pointer group transition-all"
          >
            <div className="w-8 h-8 mx-auto rounded-xl bg-slate-300/20 text-slate-200 border border-slate-600 flex items-center justify-center font-bold text-sm group-hover:scale-110 transition-transform">
              🥈
            </div>
            <span className="text-[11px] font-bold text-slate-200 block truncate">Digital Silver</span>
          </button>

          <button
            onClick={onOpenGames}
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center space-y-1.5 cursor-pointer group transition-all"
          >
            <div className="w-8 h-8 mx-auto rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-sm group-hover:scale-110 transition-transform">
              🎮
            </div>
            <span className="text-[11px] font-bold text-emerald-400 block truncate">1,000+ Games</span>
          </button>

          <button
            onClick={() => setSelectedCategory('Watch & Earn')}
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center space-y-1.5 cursor-pointer group transition-all"
          >
            <div className="w-8 h-8 mx-auto rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center font-bold text-sm group-hover:scale-110 transition-transform">
              ▶️
            </div>
            <span className="text-[11px] font-bold text-slate-200 block truncate">Videos</span>
          </button>

          <button
            onClick={() => setSelectedCategory('App Tasks')}
            className="p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center space-y-1.5 cursor-pointer group transition-all"
          >
            <div className="w-8 h-8 mx-auto rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center font-bold text-sm group-hover:scale-110 transition-transform">
              ⭐
            </div>
            <span className="text-[11px] font-bold text-slate-200 block truncate">Offers</span>
          </button>
        </div>
      </div>

      {/* Interactive Daily Check-in Streak Feature Card */}
      <DailyCheckinStreakCard onOpenStreakModal={() => setIsStreakModalOpen(true)} />

      {/* Mini 7-Day Earnings Progress Sparkline Chart */}
      <EarningsSparklineCard />

      {/* Futuristic AI Intelligent Assistant Card */}
      <div className="p-4 sm:p-5 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-500/30 shadow-xl space-y-3 sm:space-y-4 relative overflow-hidden group">
        {/* Glow Effects */}
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none group-hover:bg-indigo-500/35 transition-all duration-500" />
        <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-purple-500/20 rounded-full blur-3xl pointer-events-none group-hover:bg-purple-500/35 transition-all duration-500" />

        <div className="flex items-start justify-between relative z-10 gap-3">
          <div className="flex items-center gap-3">
            {/* Glowing Orb Ring for AI Bot */}
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 shadow-lg shadow-indigo-500/10 shrink-0 overflow-hidden">
              <span className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-purple-500/20 animate-pulse" />
              <div className="w-6 h-6 text-indigo-400 relative z-10 flex items-center justify-center">
                <svg className="w-5 h-5 sm:w-6 sm:h-6 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-xs sm:text-sm font-black text-white tracking-tight flex items-center gap-1.5">
                  <span>{language === 'bn' ? 'Earnie এআই বুদ্ধিমান সহকারী' : 'Earnie AI Intelligent Assistant'}</span>
                  <span className="animate-ping inline-block w-1.5 h-1.5 rounded-full bg-indigo-400" />
                </h3>
                <span className="px-1.5 sm:px-2 py-0.2 rounded-md bg-indigo-500/25 text-indigo-300 border border-indigo-500/35 text-[8px] sm:text-[9px] font-black uppercase tracking-wider">
                  ACTIVE AI
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 leading-relaxed max-w-sm mt-0.5">
                {language === 'bn' 
                  ? 'ভয়েস বা নীচের কুইক-ক্লিক দিয়ে Earnie-কে নির্দেশ দিন। ব্যালেন্স চেক করতে, কাজ শুরু করতে বা যেকোনো জায়গায় সাথে সাথে যান!' 
                  : 'Command Earnie with your voice or quick-clicks below to check balance, complete tasks, or navigate instantly!'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onOpenAiVoice?.()}
            className="min-h-[40px] px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] sm:text-xs flex items-center gap-1.5 shrink-0 transition-all cursor-pointer active:scale-95 shadow-lg shadow-indigo-600/30"
          >
            <span>{language === 'bn' ? 'চালু করুন' : 'Launch'}</span>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </button>
        </div>

        {/* Quick Action Suggestion Filter/Trigger List */}
        <div className="space-y-1.5 relative z-10 pt-2 border-t border-slate-800/80">
          <span className="text-[9px] sm:text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
            {language === 'bn' ? 'কুইক অ্যাকশন সাজেশন' : 'Quick Actions Suggestions'}
          </span>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {[
              { query: 'Open wallet', label: language === 'bn' ? 'ওয়ালেট খুলুন' : 'Open wallet' },
              { query: 'Start task', label: language === 'bn' ? 'কাজ শুরু করুন' : 'Start task' },
              { query: 'Go to VIP', label: language === 'bn' ? 'ভিআইপি-তে যান' : 'Go to VIP' },
              { query: 'My profile', label: language === 'bn' ? 'আমার প্রোফাইল' : 'My profile' },
            ].map((action, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => onOpenAiVoice?.(action.query)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-950 hover:bg-indigo-950/60 border border-slate-800 hover:border-indigo-500/40 text-[10px] sm:text-xs text-slate-300 hover:text-indigo-300 transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 shrink-0"
              >
                <span className="text-indigo-400">⚡</span>
                <span>{action.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Gold & Silver Investment Card */}
      <div 
        onClick={() => onOpenInvestments?.()}
        className="p-4 sm:p-5 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-amber-950/80 via-slate-900 to-yellow-950/80 border border-amber-500/50 shadow-xl space-y-3 relative overflow-hidden group cursor-pointer hover:border-amber-400 transition-all"
      >
        <div className="absolute top-0 right-0 w-40 h-40 bg-amber-500/15 rounded-full blur-3xl pointer-events-none group-hover:bg-amber-500/25 transition-all" />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 flex items-center justify-center font-bold text-xl shadow-lg shadow-amber-500/20">
              🏆
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-black text-white tracking-tight">
                  Gold & Silver Investment
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Min ₹100 • Aadhaar KYC & Mobile Required
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 leading-relaxed mt-0.5">
                Buy 24K 99.9% Pure Gold & Silver. Instant buy, sell & secure digital portfolio.
              </p>
            </div>
          </div>

          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center group-hover:translate-x-1 transition-transform shrink-0">
            →
          </div>
        </div>
      </div>

      {/* Community Stats & Real-Time VIP / App Users Activity (20,000+ Users, 10,000+ VIP Buyers) */}
      <CommunityStatsAndActivityCard
        onOpenMembership={onOpenMembership}
        onOpenTasks={onOpenTasks}
        onOpenVipTasks={onOpenVipTasks}
      />

      {/* Daily Payouts & Verified Withdrawals Audit History Feed (10,000+ Daily Withdrawals) */}
      <WithdrawalDailyHistoryCard onOpenWallet={onOpenWallet} />

      {/* Facebook Like, Comment & Share Social Earning Hub (Completed Task 10 Coins) */}
      <div className="p-3 sm:p-4 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-blue-950/90 via-slate-900 to-indigo-950/90 border border-blue-600/40 shadow-xl space-y-2.5 sm:space-y-3 relative overflow-hidden">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-blue-600 text-white font-black flex items-center justify-center text-base sm:text-lg shadow-md shadow-blue-600/30 shrink-0">
              f
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-xs sm:text-sm font-black text-white">
                  Facebook Earn Hub
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-black uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  10 Coins / Task
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300">
                Like official post, comment feedback, and share to timeline or groups!
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSelectedCategory('Facebook (10 Coins)')}
            className="text-[10px] sm:text-xs font-bold text-blue-400 hover:text-blue-300 flex items-center gap-0.5 cursor-pointer shrink-0"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 3 Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 sm:gap-2 relative z-10">
          {tasks.filter(t => t.category === 'social_facebook' || t.id.startsWith('task-fb-')).slice(0, 3).map((fbTask) => {
            const fbTitle = language === 'bn' && fbTask.titleBn ? fbTask.titleBn : fbTask.title;
            return (
              <div 
                key={fbTask.id}
                onClick={() => setSelectedTaskForDetails(fbTask)}
                className="p-2 sm:p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-blue-900/60 hover:border-blue-500/80 transition-all flex items-center justify-between gap-2 cursor-pointer group"
                title="Click to view task instructions and reward details"
              >
                <div className="min-w-0 flex-1">
                  <h4 className="text-[10px] sm:text-[11px] font-bold text-white group-hover:text-blue-300 transition-colors truncate">
                    {fbTitle.replace('Facebook: ', '')}
                  </h4>
                  <span className="text-[9px] sm:text-[10px] font-black text-amber-400">
                    +{fbTask.rewardCoins} Coins (₹{(fbTask.rewardCoins / (systemSettings.coinsPerCurrencyUnit || 1)).toFixed(2)})
                  </span>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedTaskForDetails(fbTask);
                  }}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] sm:text-[11px] flex items-center gap-1 shrink-0 transition-all cursor-pointer active:scale-95"
                >
                  <span>Earn</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3-Card Deck: Spin Wheel, Play Games, Refer Friends (Promoted Referrals Program) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
        {/* Card 1: Spin the Lucky Wheel */}
        <div 
          onClick={onOpenGames}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-[#1e1b4b]/80 via-slate-900 to-[#020617]/90 border border-indigo-500/20 shadow-lg hover:border-indigo-500/40 transition-all group cursor-pointer flex flex-col justify-between min-h-[110px]"
        >
          <div className="flex items-center justify-between">
            <span className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-black text-sm">
              🎡
            </span>
            <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
              Spin Wheel
            </span>
          </div>
          <div className="space-y-0.5 mt-2">
            <h4 className="font-black text-xs text-white group-hover:text-indigo-300 transition-colors">
              Spin the Lucky Wheel
            </h4>
            <p className="text-[10px] text-slate-400 leading-tight">
              Win up to 1,000 Coins daily!
            </p>
          </div>
          <button 
            type="button"
            className="w-full mt-2.5 py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] transition-all cursor-pointer"
          >
            Spin Now
          </button>
        </div>

        {/* Card 2: Play Games & Earn */}
        <div 
          onClick={onOpenGames}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-[#451a03]/80 via-slate-900 to-[#020617]/90 border border-amber-500/20 shadow-md hover:border-amber-500/40 transition-all group cursor-pointer flex flex-col justify-between min-h-[110px]"
        >
          <div className="flex items-center justify-between">
            <span className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-sm">
              🎮
            </span>
            <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              1,000+ Games
            </span>
          </div>
          <div className="space-y-0.5 mt-2">
            <h4 className="font-black text-xs text-white group-hover:text-amber-300 transition-colors">
              1,000+ Instant Games
            </h4>
            <p className="text-[10px] text-slate-400 leading-tight">
              Play & earn coins every minute!
            </p>
          </div>
          <button 
            type="button"
            className="w-full mt-2.5 py-1.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] transition-all cursor-pointer"
          >
            Play Now
          </button>
        </div>

        {/* Card 3: Refer Friends */}
        <div 
          onClick={onOpenReferrals}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-[#064e3b]/80 via-slate-900 to-[#020617]/90 border border-emerald-500/20 shadow-md hover:border-emerald-500/40 transition-all group cursor-pointer flex flex-col justify-between min-h-[110px]"
        >
          <div className="flex items-center justify-between">
            <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-sm">
              👥
            </span>
            <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
              Invite
            </span>
          </div>
          <div className="space-y-0.5 mt-2">
            <h4 className="font-black text-xs text-white group-hover:text-emerald-300 transition-colors">
              Refer Friends
            </h4>
            <p className="text-[10px] text-slate-400 leading-tight">
              Earn lifetime coins with friends!
            </p>
          </div>
          <button 
            type="button"
            className="w-full mt-2.5 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] transition-all cursor-pointer"
          >
            Invite Now
          </button>
        </div>
      </div>

      {/* 100,000+ APPS INSTALL/DAILY USES & 100,000+ YOUTUBE 2-HOUR VIDEO PLAY TWIN BANNERS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
        {/* 100,000+ Apps Mega Install & Daily Uses Offer Banner */}
        <div 
          onClick={onOpenTasks}
          className="p-3 sm:p-4 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-purple-950/80 via-slate-900 to-indigo-950/80 border border-purple-800/60 shadow-lg space-y-2 sm:space-y-2.5 relative overflow-hidden group cursor-pointer hover:border-purple-600 transition-all min-h-[52px]"
        >
          <div className="flex items-center justify-between">
            <span className="px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
              ⚡ 100,000+ Apps Pool
            </span>
            <span className="text-[10px] sm:text-xs font-black text-amber-400">Install & Daily Uses ₹</span>
          </div>

          <div>
            <h4 className="font-black text-xs sm:text-sm text-white group-hover:text-purple-300 transition-colors">
              App Install & Daily Uses Earning
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-300 line-clamp-2">
              Install and open apps daily (Binance, ChatGPT, WinZO, Telegram) to earn instant cash & recurring daily coins!
            </p>
          </div>

          <div className="flex items-center justify-between pt-1 text-[10px] sm:text-xs">
            <span className="text-purple-400 font-bold flex items-center gap-1 text-[10px] sm:text-[11px]">
              <span>100,000+ Catalog Apps</span>
            </span>
            <span className="min-h-[40px] px-2.5 py-1.5 rounded-xl bg-purple-600/40 group-hover:bg-purple-600 text-white font-bold text-[10px] sm:text-[11px] transition-colors flex items-center justify-center">
              Install & Use →
            </span>
          </div>
        </div>

        {/* 100,000+ YouTube Videos: 2-Hour Video Play & Direct Stream Banner */}
        <div 
          onClick={onOpenTasks}
          className="p-3 sm:p-4 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-red-950/80 via-slate-900 to-rose-950/80 border border-red-800/60 shadow-lg space-y-2 sm:space-y-2.5 relative overflow-hidden group cursor-pointer hover:border-red-600 transition-all min-h-[52px]"
        >
          <div className="flex items-center justify-between">
            <span className="px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-black uppercase tracking-wider bg-red-500/20 text-red-300 border border-red-500/30 flex items-center gap-1">
              <Play className="w-2.5 h-2.5 fill-current" />
              <span>100,000+ YouTube Videos</span>
            </span>
            <span className="text-[10px] sm:text-xs font-black text-emerald-400">2-Hour: ₹100 Max</span>
          </div>

          <div>
            <h4 className="font-black text-xs sm:text-sm text-white group-hover:text-red-300 transition-colors">
              YouTube 2-Hour Video Play & Direct Stream
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-300 line-clamp-2">
              Play directly or on the YouTube app for up to 2 hours to earn up to 10,000 Coins (₹100) per marathon session!
            </p>
          </div>

          <div className="flex items-center justify-between pt-1 text-[10px] sm:text-xs">
            <span className="text-red-400 font-bold flex items-center gap-1 text-[10px] sm:text-[11px]">
              <Tv className="w-3.5 h-3.5" />
              <span>Direct YouTube Play</span>
            </span>
            <span className="min-h-[40px] px-2.5 py-1.5 rounded-xl bg-red-600/40 group-hover:bg-red-600 text-white font-bold text-[10px] sm:text-[11px] transition-colors flex items-center justify-center">
              Watch & Earn →
            </span>
          </div>
        </div>
      </div>

      {/* 5 MEGA EARNING OPPORTUNITIES: 100k+ Surveys, 100k+ Link 5m Watch, 40m Ads 29 Coins, 200k+ App Install & Used, Google Map Review 30 Coins */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs sm:text-sm font-black text-white flex items-center gap-1.5">
            <span>🔥 {language === 'bn' ? 'মেগা টাস্ক ও ইনস্ট্যান্ট আর্নিং হাব' : 'Mega Tasks & Instant Earning Hub'}</span>
          </h3>
          <span className="text-[10px] text-amber-400 font-bold">
            {language === 'bn' ? '১০০% নিশ্চিত পেআউট' : '100% Verified Payouts'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {/* Card 1: 100,000+ Surveys */}
          <div 
            onClick={onOpenTasks}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-950 border border-indigo-500/30 hover:border-indigo-400 transition-all cursor-pointer group flex flex-col justify-between shadow-md"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-sm">
                📋
              </span>
              <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                100,000+ Pool
              </span>
            </div>
            <div className="space-y-0.5 mt-2">
              <h4 className="font-black text-xs text-white group-hover:text-indigo-300 transition-colors">
                {language === 'bn' ? '১০০,০০০+ সার্ভে ও সমীক্ষা' : '100,000+ Survey Hub'}
              </h4>
              <p className="text-[10px] text-slate-400 leading-tight">
                {language === 'bn' ? 'প্রশ্নাবলীর উত্তর দিয়ে ২০০ - ৫০০ কয়েন অর্জন করুন' : 'Answer quick questions to collect 200 - 500 Coins'}
              </p>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 mt-2">
              <span className="text-[10px] font-black text-amber-400">+250 - +450 Coins</span>
              <span className="text-[10px] font-bold text-indigo-400 group-hover:translate-x-0.5 transition-transform">Start →</span>
            </div>
          </div>

          {/* Card 2: 100,000+ Link & 5-Min Watch */}
          <div 
            onClick={onOpenTasks}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-950 border border-emerald-500/30 hover:border-emerald-400 transition-all cursor-pointer group flex flex-col justify-between shadow-md"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
                🌐
              </span>
              <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                5 Min Watch
              </span>
            </div>
            <div className="space-y-0.5 mt-2">
              <h4 className="font-black text-xs text-white group-hover:text-emerald-300 transition-colors">
                {language === 'bn' ? '১০০,০০০+ লিংক ও ৫ মিনিট ওয়াচ' : '100k+ Link 5-Min Watch'}
              </h4>
              <p className="text-[10px] text-slate-400 leading-tight">
                {language === 'bn' ? 'লিংক ভিজিট করুন ও ৫ মিনিট থাকলে ৮৫ কয়েন নিশ্চিত' : 'Visit sponsored links & stay 5 mins for guaranteed +85 Coins'}
              </p>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 mt-2">
              <span className="text-[10px] font-black text-amber-400">+85 Coins / 5m</span>
              <span className="text-[10px] font-bold text-emerald-400 group-hover:translate-x-0.5 transition-transform">Visit →</span>
            </div>
          </div>

          {/* Card 3: 40-Min Video Ads (29 Coins) */}
          <div 
            onClick={onOpenTasks}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-rose-950/80 via-slate-900 to-slate-950 border border-rose-500/30 hover:border-rose-400 transition-all cursor-pointer group flex flex-col justify-between shadow-md"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-sm">
                🎬
              </span>
              <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30">
                29 Coins
              </span>
            </div>
            <div className="space-y-0.5 mt-2">
              <h4 className="font-black text-xs text-white group-hover:text-rose-300 transition-colors">
                {language === 'bn' ? '৪০ মিনিট বিজ্ঞাপন (২৯ কয়েন)' : '40m Video Ads (29 Coins)'}
              </h4>
              <p className="text-[10px] text-slate-400 leading-tight">
                {language === 'bn' ? '৪০ মিনিট বিজ্ঞাপন স্ট্রিমিং সম্পন্ন করে ২৯ কয়েন সংগ্রহ' : 'Watch 40 mins sponsored video ads & collect 29 Coins'}
              </p>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 mt-2">
              <span className="text-[10px] font-black text-amber-400">Collect 29 Coins</span>
              <span className="text-[10px] font-bold text-rose-400 group-hover:translate-x-0.5 transition-transform">Watch →</span>
            </div>
          </div>

          {/* Card 4: 200,000+ App Install & Used */}
          <div 
            onClick={onOpenTasks}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-teal-950/80 via-slate-900 to-slate-950 border border-teal-500/30 hover:border-teal-400 transition-all cursor-pointer group flex flex-col justify-between shadow-md"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-sm">
                📱
              </span>
              <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-teal-500/20 text-teal-300 border border-teal-500/30">
                200,000+ Apps
              </span>
            </div>
            <div className="space-y-0.5 mt-2">
              <h4 className="font-black text-xs text-white group-hover:text-teal-300 transition-colors">
                {language === 'bn' ? '২০০,০০০+ অ্যাপ ইন্সটল ও ব্যবহার' : '200k+ App Install & Used'}
              </h4>
              <p className="text-[10px] text-slate-400 leading-tight">
                {language === 'bn' ? 'অ্যাপ ইন্সটল করুন, ব্যবহার করুন ও ব্যালেন্সে কয়েন সংগ্রহ করুন' : 'Install, open & use apps to collect instant coins'}
              </p>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 mt-2">
              <span className="text-[10px] font-black text-amber-400">+200 - +3,500 Coins</span>
              <span className="text-[10px] font-bold text-teal-400 group-hover:translate-x-0.5 transition-transform">Install →</span>
            </div>
          </div>

          {/* Card 5: Google Map Review (30 Coins) */}
          <div 
            onClick={onOpenTasks}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-blue-950/80 via-slate-900 to-slate-950 border border-blue-500/30 hover:border-blue-400 transition-all cursor-pointer group flex flex-col justify-between shadow-md sm:col-span-2 lg:col-span-1"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-sm">
                📍
              </span>
              <span className="text-[8px] sm:text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/30">
                30 Coins Each
              </span>
            </div>
            <div className="space-y-0.5 mt-2">
              <h4 className="font-black text-xs text-white group-hover:text-blue-300 transition-colors">
                {language === 'bn' ? 'গুগল ম্যাপ রিভিউ (৩০ কয়েন)' : 'Google Map Review & Earn'}
              </h4>
              <p className="text-[10px] text-slate-400 leading-tight">
                {language === 'bn' ? 'ম্যাপ ওয়েবসাইট ভিজিট করুন, ৫-স্টার রিভিউ দিন ও ৩০ কয়েন নিন' : 'Visit map website, write 5-star review & collect 30 Coins'}
              </p>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 mt-2">
              <span className="text-[10px] font-black text-amber-400">Collect 30 Coins</span>
              <span className="text-[10px] font-bold text-blue-400 group-hover:translate-x-0.5 transition-transform">Review →</span>
            </div>
          </div>
        </div>
      </div>

      {/* Install Android APK Banner */}
      <PWAInstallButton variant="banner" />

      {/* Dedicated APK Download Center Banner */}
      {onOpenDownloadApp && (
        <div 
          onClick={onOpenDownloadApp}
          className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-sky-950/80 via-slate-900 to-indigo-950/80 border border-sky-800/60 shadow-md flex items-center justify-between cursor-pointer hover:border-sky-500/80 transition-all group min-h-[52px]"
        >
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-black shrink-0">
              <Smartphone className="w-4 h-4 sm:w-5 sm:h-5 text-sky-400" />
            </div>
            <div className="min-w-0">
              <h4 className="text-[11px] sm:text-xs font-black text-white group-hover:text-sky-300 transition-colors flex items-center gap-1.5 flex-wrap">
                <span>Task Earn Pro 2 Android APK Center</span>
                <span className="text-[8px] sm:text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  v{systemSettings.apkVersion || '2.5.0'} Official
                </span>
              </h4>
              <p className="text-[10px] sm:text-[11px] text-slate-400 line-clamp-1 sm:line-clamp-none">
                Direct APK download, SHA-256 integrity verification, and Android installation guide
              </p>
            </div>
          </div>

          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" />
        </div>
      )}

      {/* Global Leaderboard - Driving User Engagement & Competition */}
      <GlobalLeaderboard 
        onOpenTasks={onOpenTasks} 
        onOpenWallet={onOpenWallet} 
        onOpenMembership={onOpenMembership} 
      />

      {/* Visit Link & Earn Random Coins Banner */}
      <div 
        onClick={() => setIsRandomLinkModalOpen(true)}
        className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-amber-950/70 via-slate-900 to-slate-950 border border-amber-800/60 shadow-md flex items-center justify-between cursor-pointer hover:border-amber-600/80 transition-all group min-h-[52px]"
      >
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black shrink-0">
            <Gift className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
          </div>
          <div className="min-w-0">
            <h4 className="text-[11px] sm:text-xs font-black text-white group-hover:text-amber-300 transition-colors flex items-center gap-1.5 flex-wrap">
              <span>Visit Link & Earn Random Coins</span>
              <span className="text-[8px] sm:text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                Win +20 to +100 Coins
              </span>
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-400 line-clamp-1 sm:line-clamp-none">
              Browse sponsor & partner websites for 10s to roll random lucky coins
            </p>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" />
      </div>

      {/* VIP Quick Banner */}
      <div 
        onClick={onOpenVipTasks}
        className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-800/60 shadow-md flex items-center justify-between cursor-pointer hover:border-indigo-600/80 transition-all group min-h-[52px]"
      >
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center font-black shrink-0">
            <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
          </div>
          <div className="min-w-0">
            <h4 className="text-[11px] sm:text-xs font-black text-white group-hover:text-amber-300 transition-colors flex items-center gap-1 flex-wrap">
              <span>VIP Tasks & Fast ₹ INR Plans</span>
              <span className="text-[8px] sm:text-[9px] px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                ₹200 - ₹2,000
              </span>
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-400 line-clamp-1 sm:line-clamp-none">
              Complete VIP audit tasks with unlimited instant cashouts
            </p>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" />
      </div>

      {/* YouTube Watch & Earn 10,000+ Banner */}
      <div 
        onClick={() => setSelectedCategory('Watch & Earn')}
        className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-red-950/70 via-slate-900 to-slate-950 border border-red-900/60 shadow-md flex items-center justify-between cursor-pointer hover:border-red-700/80 transition-all group min-h-[52px]"
      >
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-red-600/20 text-red-400 flex items-center justify-center font-black shrink-0">
            <Tv className="w-4 h-4 sm:w-5 sm:h-5 text-red-500" />
          </div>
          <div className="min-w-0">
            <h4 className="text-[11px] sm:text-xs font-black text-white group-hover:text-red-300 transition-colors flex items-center gap-1.5 flex-wrap">
              <span>YouTube Watch & Earn</span>
              <span className="text-[8px] sm:text-[9px] px-1.5 py-0.2 rounded-full bg-red-500/20 text-red-300 border border-red-500/30 font-bold">
                10,000+ Videos
              </span>
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-400 line-clamp-1 sm:line-clamp-none">
              Watch real educational and gaming videos for 15s to earn +15 to +80 coins
            </p>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" />
      </div>

      {/* App Testing & Feature Surveys 10,000+ Banner */}
      <div 
        onClick={() => setSelectedCategory('App Tasks')}
        className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-teal-950/70 via-slate-900 to-slate-950 border border-teal-900/60 shadow-md flex items-center justify-between cursor-pointer hover:border-teal-700/80 transition-all group min-h-[52px]"
      >
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-teal-600/20 text-teal-400 flex items-center justify-center font-black shrink-0">
            <Smartphone className="w-4 h-4 sm:w-5 sm:h-5 text-teal-400" />
          </div>
          <div className="min-w-0">
            <h4 className="text-[11px] sm:text-xs font-black text-white group-hover:text-teal-300 transition-colors flex items-center gap-1.5 flex-wrap">
              <span>App Installs & Feature Surveys</span>
              <span className="text-[8px] sm:text-[9px] px-1.5 py-0.2 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 font-bold">
                10,000+ Apps
              </span>
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-400 line-clamp-1 sm:line-clamp-none">
              Test verified apps & answer short feature feedback surveys for +50 to +250 coins
            </p>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" />
      </div>

      {/* Social Tasks & Follows 10,000+ Banner */}
      <div 
        onClick={() => setSelectedCategory('Social')}
        className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-sky-950/70 via-slate-900 to-slate-950 border border-sky-900/60 shadow-md flex items-center justify-between cursor-pointer hover:border-sky-700/80 transition-all group min-h-[52px]"
      >
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-sky-600/20 text-sky-400 flex items-center justify-center font-black shrink-0">
            <Share2 className="w-4 h-4 sm:w-5 sm:h-5 text-sky-400" />
          </div>
          <div className="min-w-0">
            <h4 className="text-[11px] sm:text-xs font-black text-white group-hover:text-sky-300 transition-colors flex items-center gap-1.5 flex-wrap">
              <span>Social Tasks & Community Follows</span>
              <span className="text-[8px] sm:text-[9px] px-1.5 py-0.2 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 font-bold">
                10,000+ Tasks
              </span>
            </h4>
            <p className="text-[10px] sm:text-[11px] text-slate-400 line-clamp-1 sm:line-clamp-none">
              Join Telegram, follow Instagram & X, and subscribe on YouTube for +30 to +120 coins
            </p>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors shrink-0" />
      </div>

      {/* TASK SECTION */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black text-white uppercase tracking-wider">
            Available Tasks
          </h3>
          <button
            type="button"
            onClick={onOpenTasks}
            className="text-xs font-bold text-emerald-400 hover:underline cursor-pointer"
          >
            View All ({tasks.length})
          </button>
        </div>

        {/* Task categories as horizontal cards/chips */}
        <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-xl whitespace-nowrap font-bold text-[10px] sm:text-xs transition-all cursor-pointer flex items-center justify-center ${
                selectedCategory === cat
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-xs'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* If Watch & Earn selected, render the 10,000+ YouTube section */}
        {selectedCategory === 'Watch & Earn' ? (
          <div className="pt-2 animate-in fade-in duration-200">
            <YouTubeWatchSection />
          </div>
        ) : selectedCategory === 'App Tasks' || selectedCategory === 'Survey' ? (
          <div className="pt-2 animate-in fade-in duration-200">
            <AppTasksSection />
          </div>
        ) : selectedCategory === 'Social' ? (
          <div className="pt-2 animate-in fade-in duration-200">
            <SocialTasksSection />
          </div>
        ) : (
          /* Task Cards List */
          <div className="space-y-2 sm:space-y-2.5">
            {filteredTasks.slice(0, 4).map((task) => {
              const title = language === 'bn' && task.titleBn ? task.titleBn : task.title;

              return (
                <div
                  key={task.id}
                  onClick={() => setSelectedTaskForDetails(task)}
                  className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-slate-900/60 hover:bg-slate-900/80 border border-slate-800/80 hover:border-emerald-500/50 transition-all flex items-center justify-between gap-2 sm:gap-3 shadow-xs cursor-pointer group"
                  title="Click to view full instructions & reward details"
                >
                  <div className="space-y-0.5 sm:space-y-1 min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <span className="text-[8px] sm:text-[9px] uppercase font-bold tracking-wider px-1.5 sm:px-2 py-0.2 sm:py-0.5 rounded-md bg-slate-800 text-slate-300">
                        {task.category.replace('_', ' ')}
                      </span>
                      <span className="text-[10px] sm:text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-slate-500" />
                        <span>{task.estimatedMinutes} min</span>
                      </span>
                    </div>

                    <h4 className="text-[11px] sm:text-xs font-bold text-slate-200 group-hover:text-emerald-300 transition-colors truncate">
                      {title}
                    </h4>
                  </div>

                  <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                    <div className="text-right">
                      <span className="text-[11px] sm:text-xs font-black text-amber-400 block font-mono">
                        +{task.rewardCoins} Coins
                      </span>
                      {task.rewardRupees && (
                        <span className="text-[9px] sm:text-[10px] text-emerald-400 font-semibold block font-mono">
                          ₹{task.rewardRupees}
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedTaskForDetails(task);
                      }}
                      className="min-h-[36px] sm:min-h-[40px] px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 text-[10px] sm:text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
                      title="View Details"
                    >
                      <Info className="w-3 h-3 text-indigo-400" />
                      <span className="hidden xs:inline">Details</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onStartTask(task);
                      }}
                      className="min-h-[36px] sm:min-h-[40px] px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] sm:text-xs shadow-xs active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
                    >
                      <span>Start</span>
                      <Play className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Task Details & Full Instructions Modal */}
      <TaskDetailsModal
        task={selectedTaskForDetails}
        isOpen={!!selectedTaskForDetails}
        onClose={() => setSelectedTaskForDetails(null)}
        onStartTask={(t) => {
          setSelectedTaskForDetails(null);
          onStartTask(t);
        }}
      />

      {/* 7-Day Interactive Daily Streak Modal */}
      <DailyStreakModal
        isOpen={isStreakModalOpen}
        onClose={() => setIsStreakModalOpen(false)}
      />

      {/* Visit Link & Earn Random Coins Modal */}
      <VisitLinkRandomModal
        isOpen={isRandomLinkModalOpen}
        onClose={() => setIsRandomLinkModalOpen(false)}
      />

      {/* Official Android APK & PWA Installation Modal */}
      <ApkInstallModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* App Sharing Modal */}
      <AppShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* App Feedback & Feature Survey Modal */}
      <AppFeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={() => setIsFeedbackModalOpen(false)}
      />

      {/* SIP Calculator Modal */}
      {isSipCalcModalOpen && (
        <SipCalculator
          isModal={true}
          onClose={() => setIsSipCalcModalOpen(false)}
          onStartSip={(metal, amt, freq) => {
            setIsSipCalcModalOpen(false);
            if (onOpenInvestments) onOpenInvestments();
          }}
        />
      )}

    </div>
  );
};
