// Supermarket Live Metrics Dashboard
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { dbStore } from '../../server/services/dbStore';
import {
  DollarSign,
  ShoppingCart,
  TrendingUp,
  Package,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { ActiveTab } from '../layout/Sidebar';

interface DashboardViewProps {
  onNavigate: (tab: ActiveTab) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const { currentBranch } = useAuth();
  const [metrics, setMetrics] = useState(dbStore.getDashboardMetrics(currentBranch.id));
  const settings = dbStore.getSettings();

  useEffect(() => {
    setMetrics(dbStore.getDashboardMetrics(currentBranch.id));
  }, [currentBranch.id]);

  const currency = settings.currency;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner with Branch Info and Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-100">Supermarket Operations Command Center</h1>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
              Live DB
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Displaying live transactional data and stock levels for{' '}
            <span className="text-emerald-400 font-semibold">{currentBranch.name}</span>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('pos')}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm shadow-emerald-900/30 transition-colors"
          >
            <ShoppingCart className="w-4 h-4" />
            Launch POS Cashier
          </button>
          <button
            onClick={() => onNavigate('inventory')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-3.5 py-2.5 rounded-lg border border-slate-700 transition-colors"
          >
            <Package className="w-4 h-4" />
            Manage Stock
          </button>
        </div>
      </div>

      {/* Primary KPI Metric Cards (Real Database Aggregations) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Today's Sales */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Today's Sales</span>
            <div className="p-2 rounded-lg bg-emerald-950/60 text-emerald-400 border border-emerald-900/60">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-100 font-mono">
              {currency} {metrics.todayTotalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
              <span className="text-emerald-400 font-semibold">{metrics.todayTransactionsCount}</span> transactions
              recorded
            </div>
          </div>
        </div>

        {/* Estimated Gross Profit */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Estimated Gross Profit</span>
            <div className="p-2 rounded-lg bg-cyan-950/60 text-cyan-400 border border-cyan-900/60">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-100 font-mono">
              {currency} {metrics.todayGrossProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Calculated as (Revenue - Cost of Goods)</div>
          </div>
        </div>

        {/* Total Inventory Valuation */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Branch Stock Valuation</span>
            <div className="p-2 rounded-lg bg-blue-950/60 text-blue-400 border border-blue-900/60">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-100 font-mono">
              {currency} {metrics.totalInventoryValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Retail value: {currency} {metrics.totalRetailValue.toLocaleString(undefined, { minimumFractionDigits: 0 })}
            </div>
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Stock Alerts</span>
            <div
              className={`p-2 rounded-lg border ${
                metrics.lowStockCount > 0
                  ? 'bg-amber-950/60 text-amber-400 border-amber-900/60'
                  : 'bg-emerald-950/60 text-emerald-400 border-emerald-900/60'
              }`}
            >
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-100 font-mono">{metrics.lowStockCount} items</div>
            <div className="text-[11px] text-amber-400 mt-1 flex items-center gap-1">
              {metrics.lowStockCount > 0 ? 'Below configured reorder threshold' : 'All branch stock levels optimal'}
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Top Selling Products & Low Stock Items */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Products */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h2 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Top Selling Products
            </h2>
            <button
              onClick={() => onNavigate('reports')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5"
            >
              Full report <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-4 divide-y divide-slate-800/80">
            {metrics.topSellingProducts.length > 0 ? (
              metrics.topSellingProducts.map((item, idx) => (
                <div key={item.product.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-400 font-mono flex items-center justify-center text-[10px] font-bold">
                      {idx + 1}
                    </span>
                    <div>
                      <div className="font-semibold text-slate-200">{item.product.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">Barcode: {item.product.barcode}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-emerald-400 font-mono">
                      {currency} {item.revenue.toFixed(2)}
                    </div>
                    <div className="text-[11px] text-slate-400">{item.quantitySold} units sold</div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-xs text-slate-500 py-6 text-center">No sales registered yet today.</div>
            )}
          </div>
        </div>

        {/* Low Stock Watchlist */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h2 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Low Stock Reorder Watchlist
            </h2>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5"
            >
              Adjust stock <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-4 divide-y divide-slate-800/80">
            {metrics.lowStockItems.length > 0 ? (
              metrics.lowStockItems.map((inv) => (
                <div key={inv.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-200">{inv.product.name}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      SKU: {inv.product.sku} | Reorder at: {inv.product.reorderLevel} {inv.product.unit}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="px-2 py-1 rounded bg-amber-950/80 text-amber-300 font-mono font-bold text-xs border border-amber-900/60">
                      {inv.quantity} {inv.product.unit} remaining
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-xs text-emerald-400 py-6 text-center flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                All products in this branch have sufficient inventory.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Sales Ledger */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h2 className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            Recent Point-of-Sale Transactions
          </h2>
          <button
            onClick={() => onNavigate('pos')}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5"
          >
            New Sale <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                <th className="pb-2.5">Receipt #</th>
                <th className="pb-2.5">Cashier</th>
                <th className="pb-2.5">Customer</th>
                <th className="pb-2.5">Items</th>
                <th className="pb-2.5">Method</th>
                <th className="pb-2.5 text-right">Grand Total</th>
                <th className="pb-2.5 text-right">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {metrics.recentSales.map((sale) => (
                <tr key={sale.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 font-mono font-medium text-emerald-400">{sale.receiptNumber}</td>
                  <td className="py-2.5">{sale.cashierName}</td>
                  <td className="py-2.5 text-slate-400">{sale.customerName || 'Walk-in Customer'}</td>
                  <td className="py-2.5 font-mono">{sale.items.length}</td>
                  <td className="py-2.5">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                      {sale.paymentMethod}
                    </span>
                  </td>
                  <td className="py-2.5 text-right font-mono font-semibold text-slate-100">
                    {currency} {sale.grandTotal.toFixed(2)}
                  </td>
                  <td className="py-2.5 text-right text-slate-400 font-mono text-[11px]">
                    {new Date(sale.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
