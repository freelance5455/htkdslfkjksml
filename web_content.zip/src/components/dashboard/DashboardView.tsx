import React from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee, formatIndianDate } from '../../i18n/translations';
import { CategoryIcon } from '../common/CategoryIcon';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  Calendar,
  AlertTriangle,
  AlertCircle,
  PlusCircle,
  MinusCircle,
  Calculator,
  HandCoins,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  BellRing,
  Clock
} from 'lucide-react';

interface DashboardViewProps {
  onNavigateTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigateTab }) => {
  const {
    t,
    language,
    selectedMonth,
    setSelectedMonth,
    monthlyIncome,
    monthlyExpense,
    remainingBalance,
    totalSavings,
    todayExpense,
    pendingToReceive,
    pendingToPay,
    budget,
    budgetProgressPercent,
    currentMonthTransactions,
    categories,
    familyMembers,
    bills,
    markBillPaid,
    setActiveModal,
    setEditingTransaction
  } = useKhata();

  // Parse Year and Month for switcher
  const [yearStr, monthStr] = selectedMonth.split('-');
  const dateObj = new Date(parseInt(yearStr), parseInt(monthStr) - 1, 1);

  const prevMonth = () => {
    const d = new Date(dateObj);
    d.setMonth(d.getMonth() - 1);
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  };

  const nextMonth = () => {
    const d = new Date(dateObj);
    d.setMonth(d.getMonth() + 1);
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  };

  const monthLabel = formatIndianDate(`${selectedMonth}-01`, language).split(' ').slice(1).join(' ');

  // Budget status calculation
  const isBudgetWarning = budgetProgressPercent >= 80 && budgetProgressPercent < 100;
  const isBudgetExceeded = budgetProgressPercent >= 100;
  const budgetRemaining = Math.max(0, (budget.overallBudget || 0) - monthlyExpense);

  // Recent 5 transactions
  const recentTransactions = currentMonthTransactions.slice(0, 5);

  // Upcoming / Pending Bills
  const upcomingBills = bills.filter(b => b.status === 'pending').slice(0, 3);

  return (
    <div className="space-y-5 pb-6">
      {/* Month Navigator Header */}
      <div className="flex items-center justify-between bg-white rounded-2xl p-3 shadow-xs border border-slate-200">
        <button
          onClick={prevMonth}
          className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 active:scale-95 transition"
          aria-label="Previous Month"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-emerald-700" />
          <span className="text-base font-bold text-slate-900 tracking-tight">{monthLabel}</span>
        </div>
        <button
          onClick={nextMonth}
          className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 active:scale-95 transition"
          aria-label="Next Month"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Budget Exceeded / Warning Alert Banners */}
      {isBudgetExceeded && (
        <div className="flex items-center gap-3 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-rose-900 text-xs sm:text-sm">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <div className="flex-1 font-medium">{t.budgetExceeded}</div>
          <button
            onClick={() => onNavigateTab('budget')}
            className="text-xs font-bold text-rose-700 underline shrink-0"
          >
            {t.navBudget}
          </button>
        </div>
      )}

      {isBudgetWarning && (
        <div className="flex items-center gap-3 p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 text-xs sm:text-sm">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
          <div className="flex-1 font-medium">{t.budgetWarning80}</div>
          <button
            onClick={() => onNavigateTab('budget')}
            className="text-xs font-bold text-amber-800 underline shrink-0"
          >
            {t.navBudget}
          </button>
        </div>
      )}

      {/* Primary KPI Balance Card */}
      <div className="bg-gradient-to-br from-emerald-800 via-emerald-700 to-teal-800 rounded-3xl p-5 sm:p-6 text-white shadow-xl shadow-emerald-900/10">
        <div className="flex items-center justify-between text-emerald-100 text-xs font-medium mb-1">
          <span>{t.remainingBalance}</span>
          <span className="flex items-center gap-1 bg-white/15 px-2.5 py-0.5 rounded-full text-[11px] font-semibold text-white">
            <Wallet className="w-3.5 h-3.5" /> {monthLabel}
          </span>
        </div>

        <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums mb-5">
          {formatRupee(remainingBalance)}
        </div>

        {/* 2-Column Split: Income vs Expense */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-emerald-600/40">
          <div className="bg-emerald-900/30 p-3 rounded-2xl">
            <div className="flex items-center gap-1.5 text-emerald-200 text-xs mb-1 font-medium">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-300" />
              <span>{t.monthlyIncome}</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-emerald-100 tabular-nums">
              {formatRupee(monthlyIncome)}
            </div>
          </div>

          <div className="bg-emerald-900/30 p-3 rounded-2xl">
            <div className="flex items-center gap-1.5 text-rose-200 text-xs mb-1 font-medium">
              <TrendingDown className="w-3.5 h-3.5 text-rose-300" />
              <span>{t.monthlyExpense}</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-rose-100 tabular-nums">
              {formatRupee(monthlyExpense)}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-4 gap-2 sm:gap-3">
        <button
          onClick={() => setActiveModal('add-expense')}
          className="min-h-[56px] flex flex-col items-center justify-center p-2.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-2xl text-rose-700 transition active:scale-95"
        >
          <MinusCircle className="w-5 h-5 mb-1" />
          <span className="text-xs font-bold leading-tight">{t.quickAddExpense}</span>
        </button>

        <button
          onClick={() => setActiveModal('add-income')}
          className="min-h-[56px] flex flex-col items-center justify-center p-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-2xl text-emerald-700 transition active:scale-95"
        >
          <PlusCircle className="w-5 h-5 mb-1" />
          <span className="text-xs font-bold leading-tight">{t.quickAddIncome}</span>
        </button>

        <button
          onClick={() => setActiveModal('calculator')}
          className="min-h-[56px] flex flex-col items-center justify-center p-2.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-2xl text-blue-700 transition active:scale-95"
        >
          <Calculator className="w-5 h-5 mb-1" />
          <span className="text-xs font-bold leading-tight">{t.calculator}</span>
        </button>

        <button
          onClick={() => onNavigateTab('loans_bills')}
          className="min-h-[56px] flex flex-col items-center justify-center p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-2xl text-amber-800 transition active:scale-95"
        >
          <HandCoins className="w-5 h-5 mb-1" />
          <span className="text-xs font-bold leading-tight">{language === 'hi' ? 'उधार खाता' : 'Udhaar'}</span>
        </button>
      </div>

      {/* 2-Card Secondary Metrics: Today's Expense & Total Savings */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium mb-1">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>{t.todayExpense}</span>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">
            {formatRupee(todayExpense)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {language === 'hi' ? 'आज का कुल खर्च' : 'Spent today'}
          </div>
        </div>

        <div
          onClick={() => setActiveModal('savings-modal')}
          className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs cursor-pointer hover:border-emerald-300 transition"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium mb-1">
            <div className="flex items-center gap-1.5">
              <PiggyBank className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t.totalSavings}</span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-emerald-700 tabular-nums">
            {formatRupee(totalSavings)}
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">
            {language === 'hi' ? 'बचत लक्ष्य देखें →' : 'View goals →'}
          </div>
        </div>
      </div>

      {/* Monthly Budget Progress Card */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">{t.budgetProgress}</h3>
          </div>
          <button
            onClick={() => onNavigateTab('budget')}
            className="text-xs font-semibold text-emerald-700 hover:underline"
          >
            {t.editBudget}
          </button>
        </div>

        <div>
          <div className="flex justify-between text-xs font-medium text-slate-600 mb-1.5 tabular-nums">
            <span>
              {t.budgetUsed}: <strong>{formatRupee(monthlyExpense)}</strong> ({budgetProgressPercent}%)
            </span>
            <span>
              {t.budgetRemaining}: <strong>{formatRupee(budgetRemaining)}</strong>
            </span>
          </div>
          {/* Progress Bar */}
          <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                isBudgetExceeded
                  ? 'bg-rose-500'
                  : isBudgetWarning
                  ? 'bg-amber-500'
                  : 'bg-emerald-600'
              }`}
              style={{ width: `${Math.min(100, budgetProgressPercent)}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-slate-400 mt-1">
            <span>0</span>
            <span>कुल बजट: {formatRupee(budget.overallBudget)}</span>
          </div>
        </div>
      </div>

      {/* Pending Udhaar / Len-Den Summary Strip */}
      <div
        onClick={() => onNavigateTab('loans_bills')}
        className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs cursor-pointer hover:border-amber-300 transition"
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <HandCoins className="w-4 h-4 text-amber-600" />
            <span className="text-xs font-bold text-slate-900">{t.pendingPayments}</span>
          </div>
          <span className="text-xs font-semibold text-emerald-700">{t.viewAll} →</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-emerald-50/60 border border-emerald-100">
            <span className="text-emerald-700 block text-[11px]">{t.toReceive} (मुझे मिलना है)</span>
            <span className="text-base font-bold text-emerald-800 tabular-nums">
              {formatRupee(pendingToReceive)}
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-rose-50/60 border border-rose-100">
            <span className="text-rose-700 block text-[11px]">{t.toPay} (मुझे देना है)</span>
            <span className="text-base font-bold text-rose-800 tabular-nums">
              {formatRupee(pendingToPay)}
            </span>
          </div>
        </div>
      </div>

      {/* Upcoming / Pending Bills Card */}
      {upcomingBills.length > 0 && (
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BellRing className="w-4 h-4 text-emerald-700" />
              <h3 className="text-xs font-bold text-slate-900">{t.upcomingBills}</h3>
            </div>
            <button
              onClick={() => onNavigateTab('loans_bills')}
              className="text-xs font-semibold text-emerald-700 hover:underline"
            >
              {t.viewAll}
            </button>
          </div>

          <div className="space-y-2">
            {upcomingBills.map(bill => (
              <div
                key={bill.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100"
              >
                <div>
                  <div className="text-xs font-bold text-slate-800">
                    {language === 'hi' ? bill.titleHi : bill.titleEn}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    देय तारीख: {formatIndianDate(bill.dueDate, language)}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900 tabular-nums">
                    {formatRupee(bill.amount)}
                  </span>
                  <button
                    onClick={() => markBillPaid(bill.id, true)}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-lg transition"
                  >
                    {t.payNow}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Transactions List */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">{t.recentTransactions}</h3>
          <button
            onClick={() => onNavigateTab('khata')}
            className="text-xs font-semibold text-emerald-700 hover:underline flex items-center gap-1"
          >
            <span>{t.viewAll}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentTransactions.length === 0 ? (
          <div className="text-center py-6 text-slate-400 text-xs">
            {t.noTransactionsYet}
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {recentTransactions.map(tx => {
              const cat = categories.find(c => c.id === tx.categoryId);
              const member = familyMembers.find(m => m.id === tx.familyMemberId);
              const isIncome = tx.type === 'income';

              return (
                <div
                  key={tx.id}
                  onClick={() => {
                    setEditingTransaction(tx);
                    setActiveModal(isIncome ? 'add-income' : 'add-expense');
                  }}
                  className="py-3 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 rounded-xl px-1.5 transition"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                      style={{
                        backgroundColor: cat ? `${cat.color}15` : '#e2e8f0',
                        color: cat ? cat.color : '#475569'
                      }}
                    >
                      <CategoryIcon name={cat ? cat.icon : 'Receipt'} className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-slate-800 truncate">
                        {tx.description}
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                        <span>{language === 'hi' ? cat?.nameHi : cat?.nameEn}</span>
                        {member && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-slate-600">{member.name.split(' ')[0]}</span>
                          </>
                        )}
                        <span aria-hidden="true">·</span>
                        <span>{formatIndianDate(tx.date, language)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0 ml-2">
                    <div
                      className={`text-sm font-bold tabular-nums ${
                        isIncome ? 'text-emerald-700' : 'text-slate-900'
                      }`}
                    >
                      {isIncome ? '+' : '-'} {formatRupee(tx.amount)}
                    </div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                      {tx.paymentMode}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
