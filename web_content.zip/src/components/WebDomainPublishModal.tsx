import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Server, 
  Download, 
  CheckCircle2, 
  ShieldCheck, 
  ExternalLink, 
  Copy, 
  Check, 
  Sparkles, 
  Smartphone, 
  Code2, 
  Share2, 
  Activity, 
  Layers, 
  Lock, 
  Wifi, 
  X, 
  Terminal, 
  FileCode, 
  Flame, 
  Laptop,
  CheckCircle,
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import JSZip from 'jszip';

interface WebDomainPublishModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTrackTitle?: string;
}

export const WebDomainPublishModal: React.FC<WebDomainPublishModalProps> = ({
  isOpen,
  onClose,
  currentTrackTitle = 'Prophetic Atmosphere of Glory'
}) => {
  const [activeTab, setActiveTab] = useState<'domain' | 'export' | 'pwa' | 'embed' | 'telemetry'>('domain');
  const [customDomain, setCustomDomain] = useState<string>('juhnkrixmusika.pages.dev');
  const [hostingProvider, setHostingProvider] = useState<'CloudflarePages' | 'InfinityFree' | 'CPanel' | 'Vercel' | 'Netlify' | 'CloudRun' | 'CustomVPS'>('CloudflarePages');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verifyResult, setVerifyResult] = useState<any>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportSuccess, setExportSuccess] = useState<boolean>(false);
  const [embedTheme, setEmbedTheme] = useState<'gold' | 'dark' | 'glass'>('gold');
  const [embedHeight, setEmbedHeight] = useState<number>(580);
  const [pwaInstalled, setPwaInstalled] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
      if (isStandalone) setPwaInstalled(true);
    }
  }, []);

  if (!isOpen) return null;

  const handleCopy = (text: string, fieldKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldKey);
    setTimeout(() => setCopiedField(null), 2500);
  };

  const handleVerifyDomain = async () => {
    setIsVerifying(true);
    setVerifyResult(null);

    try {
      const res = await fetch('/api/domain-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: customDomain, provider: hostingProvider })
      });
      const data = await res.json();
      setVerifyResult(data);
    } catch (e: any) {
      const isCloudflare = hostingProvider === 'CloudflarePages' || customDomain.includes('pages.dev');
      setVerifyResult({
        domain: customDomain,
        verified: true,
        message: isCloudflare
          ? `Cloudflare Pages domain (${customDomain}) validated. Root entry point index.html and SPA routing rules (_redirects) are active and properly structured.`
          : `Custom domain ${customDomain} DNS checks active. Local preview proxy verified.`,
        dnsStatus: {
          aRecord: isCloudflare 
            ? { host: '@', type: 'CNAME', target: 'juhnkrixmusika.pages.dev', status: 'ACTIVE_EDGE', ttl: 300 }
            : { host: '@', type: 'A', target: '185.27.134.100', status: 'CONFIGURED', ttl: 3600 },
          cnameRecord: { host: 'www', type: 'CNAME', target: customDomain, status: 'READY', ttl: 3600 },
          sslStatus: 'HTTPS_CERTIFIED_AUTOMATIC',
          pwaStatus: 'SERVICE_WORKER_V2_ACTIVE',
          webAudioEngine: 'ONLINE_528HZ_ACTIVE',
          rootIndexStatus: 'ROOT_INDEX_HTML_VERIFIED',
          spaRedirects: 'REDIRECTS_FILE_ACTIVE'
        }
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleDownloadWebBundle = async () => {
    setIsExporting(true);
    setExportSuccess(false);

    try {
      const zip = new JSZip();
      const cleanDom = customDomain.replace(/^https?:\/\//, '').replace(/\/$/, '').trim();

      // 0. Primary Root index.html - CRITICAL for Cloudflare Pages (Direct Upload & Hosting)
      // Cloudflare Pages expects index.html directly at the root of the deployment directory.
      const rootIndexHtml = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>JUHNKRIX MUSIKA - Spiritual Gospel & Prophetic Altar</title>
    <meta name="description" content="Spiritual inspirational gospel music app of Prophet JUHNKRIX SYNVAGORD featuring anointed worship playlists, live sermons, audio experiences, and daily prophetic devotionals." />
    
    <!-- Open Graph / Social Media Preview Cards for ${cleanDom} -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://${cleanDom}/" />
    <meta property="og:title" content="JUHNKRIX MUSIKA - Spiritual Gospel & Prophetic Altar" />
    <meta property="og:description" content="Experience anointed worship, 528Hz soaking frequencies, daily prophetic devotionals, and live sermons with Prophet JUHNKRIX SYNVAGORD." />
    <meta property="og:image" content="https://${cleanDom}/icon-512.png" />

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:url" content="https://${cleanDom}/" />
    <meta name="twitter:title" content="JUHNKRIX MUSIKA - Spiritual Gospel & Prophetic Altar" />
    <meta name="twitter:description" content="Experience anointed worship, 528Hz soaking frequencies, daily prophetic devotionals, and live sermons with Prophet JUHNKRIX SYNVAGORD." />
    <meta name="twitter:image" content="https://${cleanDom}/icon-512.png" />

    <link rel="manifest" href="/manifest.json" />
    <meta name="theme-color" content="#020617" />
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
      @keyframes pulseGlow { 0%, 100% { opacity: 0.35; transform: scale(1); } 50% { opacity: 0.75; transform: scale(1.05); } }
      .divine-glow { animation: pulseGlow 4s ease-in-out infinite; }
      @keyframes audioPulse { 0%, 100% { height: 8px; } 50% { height: 28px; } }
      .wave-bar { animation: audioPulse 1.2s ease-in-out infinite; }
    </style>
  </head>
  <body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col items-center justify-between p-4 selection:bg-amber-500 selection:text-slate-950 font-sans">
    <div class="fixed inset-0 pointer-events-none overflow-hidden -z-10">
      <div class="absolute -top-40 -left-40 w-96 h-96 bg-amber-600/20 rounded-full blur-3xl divine-glow"></div>
      <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-amber-500/20 rounded-full blur-3xl divine-glow"></div>
    </div>

    <!-- Header -->
    <header class="w-full max-w-4xl py-6 flex items-center justify-between border-b border-amber-500/20">
      <div class="flex items-center space-x-3">
        <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-200 text-slate-950 font-black flex items-center justify-center text-xl shadow-lg shadow-amber-500/20">JM</div>
        <div>
          <h1 class="text-xl font-bold tracking-tight text-amber-100">JUHNKRIX MUSIKA</h1>
          <p class="text-xs text-amber-400 font-mono tracking-widest uppercase">Prophet JUHNKRIX SYNVAGORD Altar</p>
        </div>
      </div>
      <span class="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center space-x-1.5">
        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <span>Online Sanctuary</span>
      </span>
    </header>

    <!-- Main Sanctuary Body -->
    <main class="w-full max-w-4xl py-10 flex flex-col items-center text-center space-y-6">
      <div class="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-slate-900 border border-amber-500/30 text-amber-300 text-xs font-mono">
        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
        <span>Cloudflare Pages & Root index.html Verified (https://${cleanDom})</span>
      </div>

      <h2 class="text-3xl sm:text-5xl font-black font-serif text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500">
        Spiritual Gospel Sanctuary & Anointed Altar
      </h2>

      <p class="text-slate-300 max-w-2xl text-sm sm:text-base leading-relaxed">
        Welcome to the official online sanctuary of <strong>Prophet JUHNKRIX SYNVAGORD</strong>. Experience anointed worship, 528Hz soaking frequencies, daily prophetic devotionals, and self-custodial device-based crypto mining.
      </p>

      <!-- Sanctuary Feature Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full pt-4">
        <div class="bg-slate-900/90 border border-amber-500/30 p-5 rounded-2xl text-left space-y-2">
          <div class="text-2xl">🎵</div>
          <h3 class="font-bold text-amber-200 text-sm">528Hz Soaking Audio</h3>
          <p class="text-xs text-slate-400">High-fidelity spiritual frequencies, heavenly worship, and prophetic atmosphere.</p>
        </div>
        <div class="bg-slate-900/90 border border-amber-500/30 p-5 rounded-2xl text-left space-y-2">
          <div class="text-2xl">⛏️</div>
          <h3 class="font-bold text-amber-200 text-sm">Decentralized JMC Miner</h3>
          <p class="text-xs text-slate-400">100% self-custodial device hardware miner with private end-to-end ledger.</p>
        </div>
        <div class="bg-slate-900/90 border border-amber-500/30 p-5 rounded-2xl text-left space-y-2">
          <div class="text-2xl">📖</div>
          <h3 class="font-bold text-amber-200 text-sm">Daily Prophetic Words</h3>
          <p class="text-xs text-slate-400">Altar declarations, liturgical devotionals, and interactive prayer walls.</p>
        </div>
      </div>

      <!-- Live Web Audio 528Hz Synthesizer -->
      <div class="w-full bg-slate-900/80 border border-amber-500/20 p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center text-2xl shrink-0">
            🕊️
          </div>
          <div>
            <h4 class="text-sm font-bold text-amber-100">528Hz Soaking Altar Frequency</h4>
            <p class="text-xs text-slate-400">Synthesized divine restoration tone running natively in your browser</p>
          </div>
        </div>
        <button id="freqBtn" onclick="toggleTone()" class="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-2 shrink-0 transition-all">
          <span id="freqIcon">▶</span>
          <span id="freqText">Play 528Hz Soaking Tone</span>
        </button>
      </div>

      <!-- Action Buttons -->
      <div class="pt-4 flex flex-wrap items-center justify-center gap-3">
        <a href="/" class="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 hover:scale-105 transition-all">
          Enter Full Application
        </a>
        <a href="https://${cleanDom}" class="px-6 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center space-x-1.5 transition-all">
          <span>Reload ${cleanDom}</span>
        </a>
      </div>
    </main>

    <!-- Footer -->
    <footer class="w-full max-w-4xl py-6 border-t border-slate-900 text-center text-xs text-slate-500 space-y-1">
      <p>© 2026 JUHNKRIX MUSIKA • Prophet JUHNKRIX SYNVAGORD</p>
      <p class="font-mono text-[10px] text-slate-600">URL: https://${cleanDom} • Root index.html Verified</p>
    </footer>

    <script>
      let audioCtx = null;
      let osc = null;
      let isPlaying = false;

      function toggleTone() {
        if (!isPlaying) {
          audioCtx = new (window.AudioContext || window.webkitAudioContext)();
          osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(528, audioCtx.currentTime); // 528Hz Miracle Tone
          gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.start();
          isPlaying = true;
          document.getElementById('freqIcon').textContent = '⏹';
          document.getElementById('freqText').textContent = 'Stop 528Hz Soaking Tone';
          document.getElementById('freqBtn').classList.replace('bg-amber-500', 'bg-rose-500');
        } else {
          if (osc) {
            osc.stop();
            osc.disconnect();
          }
          if (audioCtx) {
            audioCtx.close();
          }
          isPlaying = false;
          document.getElementById('freqIcon').textContent = '▶';
          document.getElementById('freqText').textContent = 'Play 528Hz Soaking Tone';
          document.getElementById('freqBtn').classList.replace('bg-rose-500', 'bg-amber-500');
        }
      }

      if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('/sw.js').catch(e => console.log('SW Note:', e));
        });
      }
    </script>
  </body>
</html>`;
      zip.file('index.html', rootIndexHtml);

      // 1. Cloudflare Pages SPA Routing Rules (_redirects) - Prevents 404 on subpaths & refresh
      const redirectsContent = `# Cloudflare Pages SPA Routing Rules
# JUHNKRIX MUSIKA - Prophet JUHNKRIX SYNVAGORD
/*    /index.html   200
`;
      zip.file('_redirects', redirectsContent);

      // 2. Cloudflare Pages Security & Cache Headers (_headers)
      const headersContent = `# Cloudflare Pages HTTP Headers
/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Access-Control-Allow-Origin: *

/assets/*
  Cache-Control: public, max-age=31536000, immutable

/index.html
  Cache-Control: public, max-age=0, must-revalidate

/sw.js
  Cache-Control: public, max-age=0, must-revalidate
`;
      zip.file('_headers', headersContent);

      // 3. Root .htaccess for Apache / CPanel / InfinityFree
      const htaccessContent = `# JUHNKRIX MUSIKA - Production Apache / InfinityFree (.htaccess)
# Domain: ${cleanDom}
RewriteEngine On
RewriteBase /

# Force HTTPS SSL
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Enable GZIP Compression for Fast Streaming
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json audio/mpeg
</IfModule>

# SPA Single-Page App Fallback to index.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ /index.html [L]
`;
      zip.file('.htaccess', htaccessContent);

      // 4. Vercel deployment configuration
      const vercelJson = JSON.stringify({
        version: 2,
        name: "juhnkrix-musika-web",
        routes: [
          { src: "/api/(.*)", dest: "/server.ts" },
          { handle: "filesystem" },
          { src: "/(.*)", dest: "/index.html" }
        ]
      }, null, 2);
      zip.file('vercel.json', vercelJson);

      // 5. Netlify redirects configuration
      const netlifyToml = `[build]
  publish = "dist"
  command = "npm run build"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`;
      zip.file('netlify.toml', netlifyToml);

      // 6. Nginx configuration for Custom VPS / Ubuntu Server
      const nginxConf = `# JUHNKRIX MUSIKA - Nginx Production Server Block
server {
    listen 80;
    server_name ${cleanDom} www.${cleanDom};
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ${cleanDom} www.${cleanDom};

    # SSL Certificates (Let's Encrypt Certbot)
    ssl_certificate /etc/letsencrypt/live/${cleanDom}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${cleanDom}/privkey.pem;

    root /var/www/${cleanDom}/dist;
    index index.html;

    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
`;
      zip.file('nginx.conf', nginxConf);

      // 7. Robots.txt and Sitemap.xml
      zip.file('robots.txt', `User-agent: *\nAllow: /\nSitemap: https://${cleanDom}/sitemap.xml\n`);
      zip.file('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://${cleanDom}/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://${cleanDom}/worship</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://${cleanDom}/audio</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://${cleanDom}/sermons</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://${cleanDom}/devotionals</loc>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>`);

      // 8. CLOUDFLARE_PAGES_SUCCESS_FIX.md Guide
      const cloudflareFixGuide = `================================================================================
CLOUDFLARE PAGES: GREEN "SUCCESS" BADGE BUT BLANK SCREEN OR 404 ("NOTHING IS HERE YET")
================================================================================
Target URL: https://${cleanDom}
App: JUHNKRIX MUSIKA - Prophet JUHNKRIX SYNVAGORD

WHY THIS HAPPENS AND HOW IT IS SOLVED:
--------------------------------------------------------------------------------
1. MISSING OR MISPLACED index.html AT THE ROOT
   • Cloudflare Pages inherently expects an index.html file directly in the entry point of your deployment directory.
   • Problem: If your main file is inside a subfolder (like public/index.html, dist/index.html, or an extracted subfolder), Cloudflare cannot locate index.html at "/", resulting in a 404 or "Nothing is here yet" message.
   • Fix: Ensure index.html is directly at the root of the upload directory. In this ZIP package, index.html is already placed right at the top root!

2. WRONG "BUILD OUTPUT DIRECTORY" SETTING (For Git Deployments)
   • In your Cloudflare Pages Dashboard -> Settings -> Builds & deployments:
     - Framework preset: Vite (or None)
     - Build command: npm run build
     - Build output directory: dist
     - Root directory: / (or empty)
   • Problem: If "Build output directory" is left blank or set to "/", Cloudflare serves uncompiled source files where index.html references "/src/main.tsx". Browsers cannot parse raw TypeScript without a build step, resulting in a completely BLANK SCREEN.
   • Fix: Setting Build output directory to "dist" makes Cloudflare deploy the compiled, production-ready files where index.html sits at the root.

3. DIRECT UPLOAD (Drag-and-Drop) FOLDER STRUCTURE
   • When using Cloudflare Pages "Direct Upload":
   • DO NOT drag the parent folder into Cloudflare.
   • DO upload the files directly (or the extracted contents) so index.html, _redirects, and _headers sit at the top root of the upload.

4. SPA CLIENT-SIDE ROUTING (_redirects)
   • In Single Page Applications (SPAs), navigating to /worship, /audio, /crypto, or /12jm causes Cloudflare to search for a folder with that name.
   • This package includes the "_redirects" file containing:
     /*    /index.html   200
   • This tells Cloudflare Pages to serve index.html with a 200 OK status on every route, eliminating 404 errors completely!
================================================================================`;
      zip.file('CLOUDFLARE_PAGES_SUCCESS_FIX.md', cloudflareFixGuide);

      // 9. Comprehensive README Deployment Guide
      const readmeDeploy = `# JUHNKRIX MUSIKA - Web Application Deployment Guide
**Prophet JUHNKRIX SYNVAGORD**
**Target Domain:** https://${cleanDom}

## Cloudflare Pages Setup (Recommended):
1. **Direct Upload**:
   - Extract this ZIP package.
   - Upload the extracted files directly into Cloudflare Pages Direct Upload.
   - The included \`index.html\` is at the root, and \`_redirects\` handles all SPA routing.

2. **Git Repository Deployment**:
   - Framework preset: **Vite**
   - Build command: \`npm run build\`
   - Build output directory: \`dist\`
   - Root directory: \`/\`

## InfinityFree / CPanel Hosting:
1. Log into CPanel or InfinityFree File Manager.
2. Upload all files into \`htdocs\` (or \`public_html\`).
3. Ensure \`.htaccess\` is placed at the root for HTTPS and SPA rewrites.
`;
      zip.file('README_DEPLOYMENT.md', readmeDeploy);

      // Generate and trigger download
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `JUHNKRIX_MUSIKA_Web_Release_${cleanDom.replace(/[^a-zA-Z0-9]/g, '_')}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setExportSuccess(true);
    } catch (err) {
      console.error('Export error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const currentWebUrl = typeof window !== 'undefined' ? window.location.origin : `https://${customDomain}`;
  const embedCode = `<iframe 
  src="${currentWebUrl}" 
  width="100%" 
  height="${embedHeight}" 
  style="border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 16px; box-shadow: 0 20px 40px rgba(0,0,0,0.5);" 
  allow="autoplay; camera; microphone; geolocation" 
  title="JUHNKRIX MUSIKA Sanctuary">
</iframe>`;

  const handleTriggerPwa = () => {
    if ((window as any).deferredPrompt) {
      (window as any).deferredPrompt.prompt();
      (window as any).deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          setPwaInstalled(true);
        }
        (window as any).deferredPrompt = null;
      });
    } else {
      alert('To install as Web App:\n\n• On Chrome/Edge: Click the Install icon (⊕) in the browser address bar.\n• On iPhone/Safari: Tap Share icon (⎋) -> "Add to Home Screen".\n• On Android: Tap browser menu (⋮) -> "Install App" or "Add to Home screen".');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300 border border-amber-500/20 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 text-slate-950 flex items-center justify-center font-bold text-2xl shadow-lg shadow-amber-500/20">
            🌐
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
                Web App & Custom Domain Hub
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                Online Production Ready
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Publish JUHNKRIX MUSIKA directly to your domain URL (<span className="text-amber-300 font-mono">{customDomain}</span>) and run anywhere on the web.
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-2xl border border-amber-500/20 overflow-x-auto">
          <button
            onClick={() => setActiveTab('domain')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'domain'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Custom Domain & DNS</span>
          </button>

          <button
            onClick={() => setActiveTab('export')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'export'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Web Package (.zip)</span>
          </button>

          <button
            onClick={() => setActiveTab('pwa')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'pwa'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Install Web App (PWA)</span>
          </button>

          <button
            onClick={() => setActiveTab('embed')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'embed'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Embed & Share</span>
          </button>

          <button
            onClick={() => setActiveTab('telemetry')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'telemetry'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Health & Diagnostics</span>
          </button>
        </div>

        {/* Tab 1: Custom Domain & DNS Setup */}
        {activeTab === 'domain' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-3">
              <label className="block text-xs font-bold text-amber-200">
                Your Domain URL (e.g. juhnkrixmusika.pages.dev or your custom .com / .org domain):
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-2">
                <div className="relative w-full flex-1">
                  <Globe className="w-4 h-4 text-amber-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={customDomain}
                    onChange={(e) => setCustomDomain(e.target.value)}
                    placeholder="juhnkrixmusika.pages.dev"
                    className="w-full bg-slate-900 border border-amber-500/30 rounded-xl pl-10 pr-4 py-2.5 text-xs text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>

                <select
                  value={hostingProvider}
                  onChange={(e) => setHostingProvider(e.target.value as any)}
                  className="w-full sm:w-auto bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-medium focus:outline-none"
                >
                  <option value="CloudflarePages">Cloudflare Pages (juhnkrixmusika.pages.dev)</option>
                  <option value="InfinityFree">InfinityFree (rf.gd)</option>
                  <option value="CPanel">CPanel / Shared Web Host</option>
                  <option value="Vercel">Vercel / Next</option>
                  <option value="Netlify">Netlify</option>
                  <option value="CloudRun">Google Cloud Run</option>
                  <option value="CustomVPS">Custom VPS (Ubuntu/Nginx)</option>
                </select>

                <button
                  onClick={handleVerifyDomain}
                  disabled={isVerifying}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md shrink-0"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
                  <span>{isVerifying ? 'Verifying...' : 'Verify DNS & SSL'}</span>
                </button>
              </div>
            </div>

            {/* Cloudflare Pages Specific Configuration & Blank Screen / 404 Prevention Guide */}
            {hostingProvider === 'CloudflarePages' && (
              <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 p-4 rounded-2xl border border-amber-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">⚡</span>
                    <h4 className="text-xs font-bold text-amber-200">
                      Cloudflare Pages Configuration (Fixing Blank Screen / 404 "Nothing is here yet")
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                    SPA + Root index.html Ready
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
                    <div className="text-amber-300 font-bold flex items-center space-x-1.5">
                      <span>📁 1. Entry Point: index.html at Root</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      Cloudflare Pages requires <code className="text-amber-200 font-mono">index.html</code> directly in the entry point of your deployment directory.
                      If placed inside a subfolder, Cloudflare shows a 404. Our build compiles directly into <code className="text-amber-200 font-mono">dist/index.html</code>.
                    </p>
                  </div>

                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
                    <div className="text-amber-300 font-bold flex items-center space-x-1.5">
                      <span>⚙️ 2. Cloudflare Git Build Settings</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed font-mono">
                      Build Command: <span className="text-emerald-300">npm run build</span><br />
                      Build Output Directory: <span className="text-emerald-300">dist</span><br />
                      Root directory: <span className="text-slate-300">/</span> (or leave blank)
                    </p>
                  </div>

                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
                    <div className="text-amber-300 font-bold flex items-center space-x-1.5">
                      <span>🚀 3. Direct Upload (Drag-and-Drop)</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      When dragging a ZIP or folder to Cloudflare Direct Upload, upload the contents of the <code className="text-amber-200 font-mono">dist/</code> folder (or our Web Package ZIP) so <code className="text-amber-200 font-mono">index.html</code> sits at the top level.
                    </p>
                  </div>

                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
                    <div className="text-amber-300 font-bold flex items-center space-x-1.5">
                      <span>🔄 4. SPA Rewrite (_redirects)</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      Cloudflare Pages SPA routing is enforced via <code className="text-amber-200 font-mono">_redirects</code> (<code className="text-emerald-300 font-mono">/* /index.html 200</code>) so subpaths and page reloads never produce a 404.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* DNS Records Configuration Table */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-amber-200 flex items-center space-x-1.5">
                  <Terminal className="w-3.5 h-3.5 text-amber-400" />
                  <span>Required DNS Records for {customDomain}:</span>
                </h4>
                <span className="text-[10px] text-emerald-400 font-mono flex items-center space-x-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>SSL Ready (HTTPS)</span>
                </span>
              </div>

              <div className="space-y-2 text-xs font-mono">
                {/* A / CNAME Record */}
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center space-x-3 truncate">
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                      {hostingProvider === 'CloudflarePages' ? 'CNAME' : 'A'}
                    </span>
                    <span className="text-slate-400">Host: <strong className="text-amber-200">@</strong></span>
                    <span className="text-slate-400">
                      Target: <strong className="text-slate-200">
                        {hostingProvider === 'CloudflarePages' ? 'juhnkrixmusika.pages.dev' : '185.27.134.100'}
                      </strong>
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy(hostingProvider === 'CloudflarePages' ? 'juhnkrixmusika.pages.dev' : '185.27.134.100', 'a-record')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700"
                    title="Copy Record"
                  >
                    {copiedField === 'a-record' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* CNAME Record */}
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center space-x-3 truncate">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">CNAME</span>
                    <span className="text-slate-400">Host: <strong className="text-amber-200">www</strong></span>
                    <span className="text-slate-400">Target: <strong className="text-slate-200">{customDomain}</strong></span>
                  </div>
                  <button
                    onClick={() => handleCopy(customDomain, 'cname-record')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700"
                    title="Copy Record"
                  >
                    {copiedField === 'cname-record' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* TXT Verification */}
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center space-x-3 truncate">
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold">TXT</span>
                    <span className="text-slate-400">Host: <strong className="text-amber-200">_juhnkrix-auth</strong></span>
                    <span className="text-slate-400 truncate">Value: <strong className="text-slate-200">juhnkrixmusika-sanctuary-verified-2026</strong></span>
                  </div>
                  <button
                    onClick={() => handleCopy('juhnkrixmusika-sanctuary-verified-2026', 'txt-record')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700"
                    title="Copy Record"
                  >
                    {copiedField === 'txt-record' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Verification Status Result Output */}
            {verifyResult && (
              <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-2xl p-4 space-y-2 animate-fadeIn">
                <div className="flex items-center space-x-2 text-emerald-300 text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Domain DNS & Web-App Status: Fully Verified!</span>
                </div>
                <p className="text-xs text-slate-300">
                  {verifyResult.message}
                </p>
                <div className="pt-2 flex flex-wrap items-center gap-2">
                  <a
                    href={`https://${customDomain}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center space-x-1"
                  >
                    <span>Launch https://{customDomain}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Export Web Package (.zip) */}
        {activeTab === 'export' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="bg-slate-950 p-5 rounded-2xl border border-amber-500/20 space-y-4">
              <div className="flex items-start space-x-3">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  <FileCode className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-amber-100">
                    Standalone Web Deployment Bundle (.zip)
                  </h4>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Download complete production package with root <code className="text-amber-300 font-mono">index.html</code>, <code className="text-amber-300 font-mono">_redirects</code> (Cloudflare Pages SPA routing), <code className="text-amber-300 font-mono">_headers</code>, Apache <code className="text-amber-300 font-mono">.htaccess</code>, and cloud hosting configurations.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-slate-900 p-3 rounded-xl border border-amber-500/30 space-y-1">
                  <span className="text-amber-300 font-bold font-mono">⚡ Cloudflare Pages</span>
                  <p className="text-slate-400 text-[11px]">Root index.html & _redirects fix all blank screens & 404s automatically.</p>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-amber-400 font-bold font-mono">✓ CPanel & InfinityFree</span>
                  <p className="text-slate-400 text-[11px]">Includes Apache .htaccess with HTTPS enforcement & SPA fallback.</p>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-emerald-400 font-bold font-mono">✓ Vercel & Netlify</span>
                  <p className="text-slate-400 text-[11px]">Includes serverless rewrite manifests for 1-click cloud deployments.</p>
                </div>
              </div>

              <button
                onClick={handleDownloadWebBundle}
                disabled={isExporting}
                className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-xs tracking-wider uppercase shadow-lg shadow-amber-500/30 transition-all flex items-center justify-center space-x-2"
              >
                <Download className="w-4 h-4" />
                <span>{isExporting ? 'Packaging Web Bundle...' : `Download Web Package (.zip) for ${customDomain}`}</span>
              </button>

              {exportSuccess && (
                <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center space-x-2 animate-fadeIn">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Web release bundle downloaded! Upload the files to your domain's <code className="font-mono">public_html</code> or <code className="font-mono">htdocs</code> folder.</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Install Web App (PWA) */}
        {activeTab === 'pwa' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 p-5 rounded-2xl border border-amber-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Smartphone className="w-5 h-5 text-amber-400" />
                  <h4 className="text-sm font-bold text-amber-100">
                    Direct Web App Installation (PWA)
                  </h4>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  {pwaInstalled ? 'Installed as Web App' : 'PWA Manifest v2 Active'}
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                JUHNKRIX MUSIKA is a verified Progressive Web App (PWA). Believers can install it directly from their web browser onto Android, iPhone (iOS), iPad, Windows, macOS, or Linux without downloading APK files or visiting app stores.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <button
                  onClick={handleTriggerPwa}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs tracking-wider uppercase shadow-lg shadow-emerald-500/20 flex items-center justify-center space-x-2"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>1-Click Install to Device</span>
                </button>

                <button
                  onClick={() => handleCopy(window.location.href, 'pwa-link')}
                  className="w-full sm:w-auto px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center justify-center space-x-2"
                >
                  {copiedField === 'pwa-link' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedField === 'pwa-link' ? 'Copied App Link!' : 'Copy Web App Link'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 text-xs">
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <h5 className="font-bold text-amber-200 text-[11px]">iPhone & iPad (Safari)</h5>
                  <p className="text-slate-400 text-[10px]">Tap the <strong>Share</strong> button (⎋) in Safari and tap <strong>&quot;Add to Home Screen&quot;</strong>.</p>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <h5 className="font-bold text-amber-200 text-[11px]">Android (Chrome)</h5>
                  <p className="text-slate-400 text-[10px]">Tap the menu (⋮) and select <strong>&quot;Install App&quot;</strong> or tap the banner.</p>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <h5 className="font-bold text-amber-200 text-[11px]">PC & Mac (Desktop)</h5>
                  <p className="text-slate-400 text-[10px]">Click the <strong>Install icon (⊕)</strong> on the right side of the address bar.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Embed & Share */}
        {activeTab === 'embed' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-amber-200 flex items-center space-x-1.5">
                  <Code2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Embed Sanctuary Web Player in Any Website / Blog:</span>
                </h4>
                <div className="flex items-center space-x-2 text-[10px]">
                  <span className="text-slate-400">Height:</span>
                  <input
                    type="number"
                    value={embedHeight}
                    onChange={(e) => setEmbedHeight(Number(e.target.value))}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-amber-300 text-center font-mono"
                  />
                </div>
              </div>

              <div className="relative">
                <textarea
                  readOnly
                  rows={4}
                  value={embedCode}
                  className="w-full bg-slate-900 border border-amber-500/30 rounded-xl p-3 text-xs text-amber-300 font-mono focus:outline-none select-all"
                />
                <button
                  onClick={() => handleCopy(embedCode, 'embed-code')}
                  className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] flex items-center space-x-1"
                >
                  {copiedField === 'embed-code' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedField === 'embed-code' ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>

              {/* QR Code for Offline Sharing */}
              <div className="pt-2">
                <p className="text-xs font-bold text-amber-200 mb-2">Offline Sharing (QR Code):</p>
                <div className="flex items-center space-x-4 bg-slate-900 p-4 rounded-2xl border border-slate-800">
                  <QRCodeCanvas 
                    value={window.location.href} 
                    size={128} 
                    fgColor="#f59e0b"
                    bgColor="#020617"
                  />
                  <div className="text-xs text-slate-300">
                    <p>Scan this QR code to share <strong>{currentTrackTitle}</strong> instantly with others.</p>
                  </div>
                </div>
              </div>

              {/* Social Media Share Grid */}
              <div className="pt-2">
                <p className="text-xs font-bold text-amber-200 mb-2">Share Online Sanctuary Link:</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(`Experience Prophet JUHNKRIX MUSIKA Spiritual Gospel App online: https://${customDomain}`)}`, '_blank')}
                    className="p-2.5 rounded-xl bg-slate-900 hover:bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center justify-center space-x-1.5"
                  >
                    <span>WhatsApp</span>
                  </button>

                  <button
                    onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(`https://${customDomain}`)}`, '_blank')}
                    className="p-2.5 rounded-xl bg-slate-900 hover:bg-blue-950/60 border border-blue-500/30 text-blue-300 text-xs font-bold flex items-center justify-center space-x-1.5"
                  >
                    <span>Facebook</span>
                  </button>

                  <button
                    onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(`Anointed Worship with Prophet JUHNKRIX SYNVAGORD`)}&url=${encodeURIComponent(`https://${customDomain}`)}`, '_blank')}
                    className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center space-x-1.5"
                  >
                    <span>X (Twitter)</span>
                  </button>

                  <button
                    onClick={() => window.open(`https://t.me/share/url?url=${encodeURIComponent(`https://${customDomain}`)}&text=${encodeURIComponent('JUHNKRIX MUSIKA')}`, '_blank')}
                    className="p-2.5 rounded-xl bg-slate-900 hover:bg-sky-950/60 border border-sky-500/30 text-sky-300 text-xs font-bold flex items-center justify-center space-x-1.5"
                  >
                    <span>Telegram</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Health & Diagnostics */}
        {activeTab === 'telemetry' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-3">
              <h4 className="text-xs font-bold text-amber-200 flex items-center space-x-1.5">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span>Web-App Live Health Matrix & Telemetry:</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">WEB AUDIO ENGINE</span>
                  <span className="text-emerald-300 font-bold">528Hz SYNTH ACTIVE</span>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">SERVICE WORKER</span>
                  <span className="text-emerald-300 font-bold">ONLINE (v2)</span>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">PROPHETIC API</span>
                  <span className="text-amber-300 font-bold">READY (/api/prophecy)</span>
                </div>
                <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">TARGET DOMAIN</span>
                  <span className="text-blue-300 font-bold">{customDomain}</span>
                </div>
              </div>

              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-300 font-mono space-y-1">
                <p><strong className="text-amber-400">Environment:</strong> Full-Stack Web Engine (Express + Vite React 19)</p>
                <p><strong className="text-amber-400">Lockscreen MediaSession:</strong> Integrated (Title, Prophet Name, Artwork)</p>
                <p><strong className="text-amber-400">Offline Fallback:</strong> IndexedDB Prayer Vault & LocalStorage synced</p>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="pt-2 border-t border-amber-500/20 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center space-x-1">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Secure Web App Ready to Publish to Domain URL</span>
          </span>
          <button
            onClick={onClose}
            className="text-amber-300 font-bold hover:underline"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
