import React, { useState } from 'react';
import {
  ShoppingBag,
  Globe2,
  Sparkles,
  Check,
  Film,
  DollarSign,
  ArrowRight,
  TrendingUp,
  Award,
} from 'lucide-react';
import { PurchasableFormat } from '../types/game';
import { soundFx } from '../utils/audio';

interface FormatsMarketProps {
  formats: PurchasableFormat[];
  cash: number;
  onBuyFormat: (formatId: string) => void;
}

export const FormatsMarket: React.FC<FormatsMarketProps> = ({
  formats,
  cash,
  onBuyFormat,
}) => {
  const [filterGenre, setFilterGenre] = useState<string>('all');

  const filteredFormats = formats.filter((f) => {
    if (filterGenre === 'all') return true;
    return f.genre === filterGenre;
  });

  return (
    <div className="w-full h-full flex flex-col gap-3 select-none overflow-y-auto pr-1">
      {/* Header Banner - Compact */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-amber-400" />
            Mercado de Formatos, Séries & Enlatados
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Compre direitos de transmissão de animes, novelas estrangeiras, reality shows e clássicos de cinema para passar na sua TV com audiência garantida!
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Genre filter buttons */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 text-[11px]">
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterGenre('all');
              }}
              className={`px-2.5 py-1 rounded font-semibold cursor-pointer transition-colors ${
                filterGenre === 'all' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterGenre('reality');
              }}
              className={`px-2.5 py-1 rounded font-semibold cursor-pointer transition-colors ${
                filterGenre === 'reality' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Reality
            </button>
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterGenre('desenho');
              }}
              className={`px-2.5 py-1 rounded font-semibold cursor-pointer transition-colors ${
                filterGenre === 'desenho' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Animação
            </button>
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterGenre('novela');
              }}
              className={`px-2.5 py-1 rounded font-semibold cursor-pointer transition-colors ${
                filterGenre === 'novela' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Novela
            </button>
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterGenre('esporte');
              }}
              className={`px-2.5 py-1 rounded font-semibold cursor-pointer transition-colors ${
                filterGenre === 'esporte' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Esporte
            </button>
          </div>
        </div>
      </div>

      {/* Formats Grid - Compact Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredFormats.map((fmt) => {
          const canAfford = cash >= fmt.licenseCost && !fmt.isPurchased;

          return (
            <div
              key={fmt.id}
              className={`rounded-xl border p-4 flex flex-col justify-between transition-all shadow-md ${
                fmt.isPurchased
                  ? 'bg-slate-900/60 border-emerald-500/40'
                  : 'bg-slate-900/90 border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Globe2 className="w-3.5 h-3.5 text-blue-400" />
                    <span>Origem: {fmt.originCountry}</span>
                  </div>
                  <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-slate-800 text-amber-300">
                    {fmt.genre}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white mt-2 truncate">{fmt.title}</h3>

                <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                  {fmt.description}
                </p>

                {/* Attributes */}
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs bg-slate-950 p-2.5 rounded-lg border border-slate-800/80">
                  <div>
                    <span className="text-[10px] text-slate-400 block">QUALIDADE BASE:</span>
                    <span className="font-mono font-bold text-amber-400">{fmt.initialQuality}%</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">PACOTE EPISÓDIOS:</span>
                    <span className="font-mono font-bold text-slate-200">{fmt.episodesCount} eps</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">EXIBIÇÃO / DIA:</span>
                    <span className="font-mono text-slate-300">R$ {fmt.perSlotCost.toLocaleString('pt-BR')}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">STATUS LICENÇA:</span>
                    <span className={`font-bold ${fmt.isPurchased ? 'text-emerald-400' : 'text-slate-400'}`}>
                      {fmt.isPurchased ? 'No seu Acervo' : 'À Venda'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-3 pt-2.5 border-t border-slate-800">
                {fmt.isPurchased ? (
                  <div className="w-full min-h-[44px] py-2 px-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 text-xs font-bold uppercase text-center flex items-center justify-center gap-1.5">
                    <Check className="w-4 h-4" />
                    <span>Licença Adquirida · No Acervo</span>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      if (canAfford) {
                        soundFx.playCash();
                        onBuyFormat(fmt.id);
                      }
                    }}
                    disabled={!canAfford}
                    className={`w-full min-h-[46px] py-2 px-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-between transition-all cursor-pointer active:scale-95 ${
                      canAfford
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-950/40'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-75'
                    }`}
                  >
                    <span>{canAfford ? 'Comprar Direitos' : 'Caixa Insuficiente'}</span>
                    <span className="font-mono">R$ {fmt.licenseCost.toLocaleString('pt-BR')}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
