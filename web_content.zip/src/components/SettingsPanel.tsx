import type { ReactNode } from 'react';
import type { Settings } from '../engine/settings';

interface Props {
  s: Settings;
  set: (patch: Partial<Settings>) => void;
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-xl bg-zinc-900/60 p-3 ring-1 ring-white/5">
      <h3 className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-emerald-400/90">{title}</h3>
      <div className="space-y-2.5">{children}</div>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  fmt,
  onChange,
  hint,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  fmt?: (v: number) => string;
  onChange: (v: number) => void;
  hint?: string;
}) {
  return (
    <label className="block" title={hint}>
      <div className="flex items-baseline justify-between text-xs">
        <span className="text-zinc-300">{label}</span>
        <span className="font-mono text-emerald-300">{fmt ? fmt(value) : value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-zinc-700 accent-emerald-500"
      />
    </label>
  );
}

function Toggle({
  label,
  value,
  onChange,
  hint,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
  hint?: string;
}) {
  return (
    <button
      type="button"
      title={hint}
      onClick={() => onChange(!value)}
      className="flex w-full items-center justify-between text-left text-xs text-zinc-300"
    >
      <span>{label}</span>
      <span
        className={`relative h-5 w-9 shrink-0 rounded-full transition ${value ? 'bg-emerald-500' : 'bg-zinc-600'}`}
      >
        <span
          className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${
            value ? 'left-[18px]' : 'left-0.5'
          }`}
        />
      </span>
    </button>
  );
}

export default function SettingsPanel({ s, set }: Props) {
  const sec = (ms: number) => (ms >= 1000 ? `${(ms / 1000).toFixed(1)} с` : `${ms} мс`);
  return (
    <div className="space-y-3">
      <Section title="Сила и поведение движка">
        <Slider label="Глубина поиска" value={s.depth} min={1} max={14} onChange={(v) => set({ depth: v })} fmt={(v) => `${v} п/х`} hint="Максимальная глубина в полуходах" />
        <Slider label="Время на ход" value={s.timeMs} min={100} max={15000} step={100} fmt={sec} onChange={(v) => set({ timeMs: v })} hint="Жёсткий лимит времени на один ход" />
        <Slider label="Рассматриваемые ходы" value={s.candidates} min={1} max={8} onChange={(v) => set({ candidates: v })} hint="Из скольких лучших ходов движок может выбирать" />
        <Slider label="Шанс ошибки" value={Math.round(s.mistakeChance * 100)} min={0} max={80} fmt={(v) => `${v}%`} onChange={(v) => set({ mistakeChance: v / 100 })} hint="Вероятность сыграть не лучший ход из кандидатов" />
        <Slider label="Шум оценки" value={s.noise} min={0} max={500} step={5} fmt={(v) => `${v} сп`} onChange={(v) => set({ noise: v })} hint="Случайная погрешность оценки ходов в сотых долях пешки" />
        <Slider label="Вариативность дебюта" value={s.openingVariety} min={0} max={20} fmt={(v) => `${v} п/х`} onChange={(v) => set({ openingVariety: v })} hint="Сколько первых полуходов движок играет случайно среди равных" />
      </Section>

      <Section title="Алгоритм поиска">
        <Toggle label="Поиск взятий (quiescence)" value={s.quiescence} onChange={(v) => set({ quiescence: v })} hint="Доигрывает цепочки взятий в листьях дерева" />
        {s.quiescence && (
          <Slider label="Глубина поиска взятий" value={s.qDepth} min={1} max={14} onChange={(v) => set({ qDepth: v })} />
        )}
        <Toggle label="Таблица транспозиций" value={s.useTT} onChange={(v) => set({ useTT: v })} />
        <Toggle label="Расширение при шахе" value={s.checkExt} onChange={(v) => set({ checkExt: v })} />
        <Toggle label="Нулевой ход (null-move)" value={s.nullMove} onChange={(v) => set({ nullMove: v })} />
        <Toggle label="Сокращение поздних ходов (LMR)" value={s.lmr} onChange={(v) => set({ lmr: v })} />
      </Section>

      <Section title="Оценка позиции">
        <Toggle label="Таблицы позиций фигур" value={s.usePST} onChange={(v) => set({ usePST: v })} />
        <Toggle label="Пара слонов" value={s.bishopPair} onChange={(v) => set({ bishopPair: v })} />
        <Toggle label="Структура пешек" value={s.pawnStructure} onChange={(v) => set({ pawnStructure: v })} />
        <Toggle label="Ладьи на открытых линиях" value={s.rookFiles} onChange={(v) => set({ rookFiles: v })} />
      </Section>

      <Section title="Анализ и подсказки">
        <Slider label="Стрелок-подсказок" value={s.arrows} min={0} max={5} fmt={(v) => (v === 0 ? 'выкл' : String(v))} onChange={(v) => set({ arrows: v })} />
        <Slider label="Глубина анализа" value={s.analysisDepth} min={1} max={16} onChange={(v) => set({ analysisDepth: v })} fmt={(v) => `${v} п/х`} />
        <Slider label="Время анализа" value={s.analysisTimeMs} min={200} max={15000} step={100} fmt={sec} onChange={(v) => set({ analysisTimeMs: v })} />
        <Toggle label="Шкала оценки" value={s.showEval} onChange={(v) => set({ showEval: v })} />
      </Section>

      <Section title="Доска">
        <div>
          <div className="mb-1 text-xs text-zinc-300">Цветовая тема</div>
          <div className="grid grid-cols-4 gap-1.5">
            {(
              [
                ['green', 'Зелёная', '#eeeed2', '#769656'],
                ['classic', 'Классика', '#f0d9b5', '#b58863'],
                ['blue', 'Синяя', '#dee3e6', '#8ca2ad'],
                ['gray', 'Серая', '#e4e4e7', '#8f9199'],
              ] as const
            ).map(([id, name, l, d]) => (
              <button
                key={id}
                onClick={() => set({ theme: id })}
                title={name}
                className={`flex h-9 overflow-hidden rounded-md ring-2 transition ${
                  s.theme === id ? 'ring-emerald-400' : 'ring-transparent hover:ring-zinc-500'
                }`}
              >
                <span className="h-full w-1/2" style={{ background: l }} />
                <span className="h-full w-1/2" style={{ background: d }} />
              </button>
            ))}
          </div>
        </div>
        <Toggle label="Подсветка последнего хода" value={s.showLastMove} onChange={(v) => set({ showLastMove: v })} />
        <Toggle label="Показывать возможные ходы" value={s.showLegal} onChange={(v) => set({ showLegal: v })} />
        <Toggle label="Координаты" value={s.showCoords} onChange={(v) => set({ showCoords: v })} />
        <Toggle label="Авто-разворот при выборе цвета" value={s.autoFlip} onChange={(v) => set({ autoFlip: v })} />
      </Section>
    </div>
  );
}
