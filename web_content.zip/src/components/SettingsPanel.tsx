import type { Quality, Settings } from "../game/Game";

interface Props {
  settings: Settings;
  onChange: (s: Settings) => void;
  onClose: () => void;
  hour: number;
  onSetHour: (h: number) => void;
  onReset: () => void;
  onMenu: () => void;
}

const QUAL: { id: Quality; label: string; desc: string }[] = [
  { id: "baixa", label: "Baixa", desc: "Máximo desempenho" },
  { id: "media", label: "Média", desc: "Equilíbrio (celular)" },
  { id: "alta", label: "Alta", desc: "Sombras + mais distância" },
];

export function SettingsPanel({ settings, onChange, onClose, hour, onSetHour, onReset, onMenu }: Props) {
  const set = (p: Partial<Settings>) => onChange({ ...settings, ...p });
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-3" onClick={onClose}>
      <div className="pixel-panel max-h-full w-full max-w-md overflow-y-auto p-4 text-white" style={{ touchAction: "pan-y" }} onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg uppercase tracking-widest text-fuchsia-300">Configurações</h2>
          <button onClick={onClose} className="pixel-btn bg-rose-600 px-3 py-1 text-sm">✕</button>
        </div>

        <label className="mb-1 block text-sm">Sensibilidade da câmera: <b className="text-amber-300">{settings.sensitivity.toFixed(1)}x</b></label>
        <input
          type="range" min={0.2} max={3} step={0.1} value={settings.sensitivity}
          onChange={(e) => set({ sensitivity: parseFloat(e.target.value) })}
          className="mb-4 w-full accent-fuchsia-500"
        />

        <label className="mb-4 flex items-center gap-2 text-sm">
          <input type="checkbox" checked={settings.invertY} onChange={(e) => set({ invertY: e.target.checked })} className="h-4 w-4 accent-fuchsia-500" />
          Inverter eixo vertical da câmera
        </label>

        <div className="mb-1 text-sm">Qualidade gráfica</div>
        <div className="mb-4 grid grid-cols-3 gap-2">
          {QUAL.map((q) => (
            <button
              key={q.id}
              onClick={() => set({ quality: q.id })}
              className={`pixel-btn px-2 py-2 text-xs ${settings.quality === q.id ? "bg-fuchsia-600" : "bg-black/40"}`}
            >
              <div className="text-sm">{q.label}</div>
              <div className="text-[10px] opacity-70">{q.desc}</div>
            </button>
          ))}
        </div>

        <label className="mb-1 block text-sm">Duração do dia: <b className="text-amber-300">{Math.round(settings.dayLength / 60)} min</b></label>
        <input
          type="range" min={120} max={1800} step={60} value={settings.dayLength}
          onChange={(e) => set({ dayLength: parseInt(e.target.value) })}
          className="mb-4 w-full accent-fuchsia-500"
        />

        <label className="mb-1 block text-sm">Horário atual: <b className="text-amber-300">{String(Math.floor(hour)).padStart(2, "0")}h</b></label>
        <input
          type="range" min={0} max={23.9} step={0.25} value={hour}
          onChange={(e) => onSetHour(parseFloat(e.target.value))}
          className="mb-4 w-full accent-amber-400"
        />

        <label className="mb-4 flex items-center gap-2 text-sm">
          <input type="checkbox" checked={settings.sound !== false} onChange={(e) => set({ sound: e.target.checked })} className="h-4 w-4 accent-fuchsia-500" />
          Efeitos sonoros
        </label>

        <label className="mb-4 flex items-center gap-2 text-sm">
          <input type="checkbox" checked={settings.showFps} onChange={(e) => set({ showFps: e.target.checked })} className="h-4 w-4 accent-fuchsia-500" />
          Mostrar FPS
        </label>

        <div className="mb-4 rounded bg-black/30 p-3 text-[11px] leading-relaxed text-white/75">
          <b className="text-white">Controles:</b><br />
          📱 Arraste no lado esquerdo para mover, no direito para girar a câmera.<br />
          ⌨️ WASD mover · Shift correr · Espaço pular · E interagir · M mapa · arrastar o mouse gira a câmera · roda = zoom.<br />
          ⚔️ F ou clique rápido = atacar · 1–8 barra rápida · Q usar item · I inventário. No celular, toque duas vezes no espaço para usar comida.
        </div>

        <div className="flex gap-2">
          <button onClick={onMenu} className="pixel-btn flex-1 bg-slate-600 px-3 py-2 text-sm">Menu inicial</button>
          <button
            onClick={() => { if (confirm("Apagar todo o progresso (locais, cristais)?")) onReset(); }}
            className="pixel-btn flex-1 bg-rose-700 px-3 py-2 text-sm"
          >
            Reiniciar progresso
          </button>
        </div>
      </div>
    </div>
  );
}
