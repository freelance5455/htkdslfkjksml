import React from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, Legend } from 'recharts';
import { Sparkles, TrendingUp, Users, Radio, Music, MessageSquare } from 'lucide-react';
import { AdminDiskUsageProgress } from './AdminDiskUsageProgress';

const engagementData = [
  { day: 'Mon', prayerHours: 420, musicStreams: 1840, messages: 650 },
  { day: 'Tue', prayerHours: 510, musicStreams: 2120, messages: 820 },
  { day: 'Wed', prayerHours: 680, musicStreams: 2950, messages: 1100 },
  { day: 'Thu', prayerHours: 590, musicStreams: 2600, messages: 940 },
  { day: 'Fri', prayerHours: 850, musicStreams: 3400, messages: 1450 },
  { day: 'Sat', prayerHours: 920, musicStreams: 4100, messages: 1800 },
  { day: 'Sun', prayerHours: 1250, musicStreams: 5800, messages: 2400 },
];

const hourlyStreamData = [
  { hour: '00:00', streams: 120 },
  { hour: '04:00', streams: 80 },
  { hour: '08:00', streams: 450 },
  { hour: '12:00', streams: 890 },
  { hour: '16:00', streams: 1200 },
  { hour: '20:00', streams: 1550 },
  { hour: '23:59', streams: 620 },
];

export const AdminEngagementDashboard: React.FC = () => {
  return (
    <div className="space-y-6 bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-amber-500/20">
        <div>
          <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-widest">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Administrative Monitoring & Analytics</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-serif font-bold text-amber-100 mt-1">
            JUHNKRIX MUSIKA Global Engagement Analytics
          </h3>
          <p className="text-xs text-slate-300 mt-1">
            Real-time telemetry of daily prayer hours, gospel music streams, and message activity across the sanctuary.
          </p>
        </div>
        <div className="flex items-center space-x-3 bg-slate-950 px-4 py-2 rounded-2xl border border-amber-500/30 text-xs text-amber-300">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <span className="font-bold">+34.8% Growth This Week</span>
        </div>
      </div>

      {/* Quick Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/20 flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-amber-500/20 text-amber-400">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Prayer Hours</span>
            <h4 className="text-xl font-bold font-serif text-amber-100 mt-0.5">5,220 hrs</h4>
            <span className="text-[10px] text-emerald-400 font-semibold">+18% vs last week</span>
          </div>
        </div>

        <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/20 flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-blue-500/20 text-blue-400">
            <Music className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Gospel Music Streams</span>
            <h4 className="text-xl font-bold font-serif text-amber-100 mt-0.5">22,810 streams</h4>
            <span className="text-[10px] text-emerald-400 font-semibold">+24.5% active listeners</span>
          </div>
        </div>

        <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/20 flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-purple-500/20 text-purple-400">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Message Activity</span>
            <h4 className="text-xl font-bold font-serif text-amber-100 mt-0.5">8,760 msgs</h4>
            <span className="text-[10px] text-emerald-400 font-semibold">+42% ₦5 billing collected</span>
          </div>
        </div>
      </div>

      {/* Dedicated Disk Usage Progress Bar Component */}
      <AdminDiskUsageProgress />

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-4">
        {/* Weekly Engagement Trends */}
        <div className="bg-slate-950/90 p-6 rounded-2xl border border-amber-500/20 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold font-serif text-amber-200">Weekly Engagement Metrics (Prayer & Streams)</h4>
            <span className="text-[10px] font-mono text-slate-400">Live Telemetry</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={engagementData}>
                <defs>
                  <linearGradient id="colorPrayer" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorStreams" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#f59e0b', borderRadius: '12px', color: '#f8fafc' }} />
                <Legend />
                <Area type="monotone" dataKey="prayerHours" name="Prayer Hours" stroke="#f59e0b" fillOpacity={1} fill="url(#colorPrayer)" />
                <Area type="monotone" dataKey="musicStreams" name="Music Streams" stroke="#3b82f6" fillOpacity={1} fill="url(#colorStreams)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Message Activity & ₦5 Billing Volume */}
        <div className="bg-slate-950/90 p-6 rounded-2xl border border-amber-500/20 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold font-serif text-amber-200">Message Activity & Text Engine Volume</h4>
            <span className="text-[10px] font-mono text-slate-400">₦5 SIM Billing Active</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#f59e0b', borderRadius: '12px', color: '#f8fafc' }} />
                <Legend />
                <Bar dataKey="messages" name="Text Messages Sent" fill="#10b981" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
