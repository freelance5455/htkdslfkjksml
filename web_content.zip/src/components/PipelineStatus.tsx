import React from 'react';
import { Search, FileText, Volume2, Video, CheckCircle2, Loader2, Sparkles } from 'lucide-react';

export type PipelineStep = 'idle' | 'grounding' | 'scripting' | 'voicing' | 'synthesizing' | 'completed' | 'error';

interface PipelineStatusProps {
  currentStep: PipelineStep;
  error?: string | null;
}

export const PipelineStatus: React.FC<PipelineStatusProps> = ({ currentStep, error }) => {
  if (currentStep === 'idle') return null;

  const steps = [
    {
      id: 'grounding',
      title: 'Search & Scrape',
      desc: 'Grounding trending hooks & viral pain points',
      icon: Search,
      color: 'from-blue-500 to-cyan-500',
    },
    {
      id: 'scripting',
      title: '16s UGC Script',
      desc: 'Hook (0-3s), Demo (3-12s) & CTA (12-16s)',
      icon: FileText,
      color: 'from-indigo-500 to-purple-500',
    },
    {
      id: 'voicing',
      title: 'Gemini TTS Studio',
      desc: 'Realistic creator vocal narration & rhythm',
      icon: Volume2,
      color: 'from-pink-500 to-rose-500',
    },
    {
      id: 'synthesizing',
      title: '9:16 Video Synthesis',
      desc: 'Avatar overlay, motion graphics & captions',
      icon: Video,
      color: 'from-emerald-500 to-teal-500',
    },
  ];

  const getStepStatus = (stepId: string) => {
    if (error) return 'error';
    const order = ['grounding', 'scripting', 'voicing', 'synthesizing', 'completed'];
    const currentIndex = order.indexOf(currentStep);
    const stepIndex = order.indexOf(stepId);

    if (currentStep === 'completed' || currentIndex > stepIndex) return 'done';
    if (currentIndex === stepIndex) return 'active';
    return 'pending';
  };

  return (
    <div className="w-full glass-panel rounded-2xl p-4 sm:p-5 border border-white/10 shadow-2xl relative overflow-hidden mb-6">
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-indigo-500 to-pink-500" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            {currentStep === 'completed' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
            )}
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              Fast UGC Generation Pipeline
              {currentStep === 'completed' && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                  16S AD READY
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400">
              Real-time multi-agent processing with Google Search Grounding & Gemini TTS
            </p>
          </div>
        </div>

        {error && (
          <div className="px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-medium">
            {error}
          </div>
        )}
      </div>

      {/* Steps visual indicators */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {steps.map((step, idx) => {
          const status = getStepStatus(step.id);
          const Icon = step.icon;

          return (
            <div
              key={step.id}
              className={`relative rounded-xl p-3 border transition-all duration-300 ${
                status === 'active'
                  ? 'glass-panel bg-white/[0.08] border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.25)]'
                  : status === 'done'
                  ? 'glass-panel-subtle border-emerald-500/30'
                  : 'bg-white/[0.02] border-white/[0.05] opacity-50'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <div
                  className={`p-2 rounded-lg text-white font-bold text-xs flex items-center justify-center ${
                    status === 'active'
                      ? 'bg-gradient-to-br from-cyan-500 to-indigo-600 shadow-md animate-pulse'
                      : status === 'done'
                      ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                      : 'bg-white/5 text-slate-500 border border-white/10'
                  }`}
                >
                  {status === 'done' ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                  ) : status === 'active' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <span>0{idx + 1}</span>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-slate-200 truncate">{step.title}</h4>
                    <span
                      className={`text-[9px] uppercase tracking-wider font-mono font-bold ${
                        status === 'active'
                          ? 'text-cyan-400'
                          : status === 'done'
                          ? 'text-emerald-400'
                          : 'text-slate-500'
                      }`}
                    >
                      {status === 'active' ? 'PROCESSING' : status === 'done' ? 'DONE' : 'WAITING'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{step.desc}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
