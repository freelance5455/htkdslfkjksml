import React from 'react';
import { SectPagodaIcon, MeritScrollIcon } from './icons/DaoIcons';
import { TrendingUp, Landmark, Users } from 'lucide-react';

export type MainTabType = 'sect' | 'overview' | 'buildings' | 'disciples' | 'chronicle';

interface NavigationTabsProps {
  activeTab: MainTabType;
  onTabChange: (tab: MainTabType) => void;
  discipleCount: number;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({
  activeTab,
  onTabChange,
  discipleCount
}) => {
  const tabs = [
    {
      id: 'sect' as MainTabType,
      label: 'Sect',
      icon: <SectPagodaIcon className="w-5 h-5" />
    },
    {
      id: 'overview' as MainTabType,
      label: 'Overview',
      icon: <TrendingUp className="w-5 h-5" />
    },
    {
      id: 'buildings' as MainTabType,
      label: 'Buildings',
      icon: <Landmark className="w-5 h-5" />
    },
    {
      id: 'disciples' as MainTabType,
      label: 'Disciples',
      icon: <Users className="w-5 h-5" />,
      badge: discipleCount
    },
    {
      id: 'chronicle' as MainTabType,
      label: 'Chronicle',
      icon: <MeritScrollIcon className="w-5 h-5" />
    }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#072018] border-t border-[#e2b054]/30 shadow-2xl safe-area-pb">
      <div className="max-w-2xl mx-auto grid grid-cols-5 py-1 px-1">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all relative ${
                isActive
                  ? 'bg-[#184838] text-[#fce18b] font-bold shadow-inner'
                  : 'text-[#8baea0] hover:text-[#e8f1eb] hover:bg-[#0d2e23]'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.badge !== undefined && (
                  <span className="absolute -top-1 -right-2 bg-[#b45309] text-white text-[9px] font-bold px-1 rounded-full border border-[#fce18b]/40">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] sm:text-xs mt-1 tracking-tight">
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute bottom-0.5 w-6 h-0.5 bg-[#fce18b] rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
