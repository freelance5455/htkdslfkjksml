import { useState } from 'react';
import { Globe, MapPin, Calendar, Sun, Compass, Utensils, Hotel, Sparkles, Star, ChevronRight, ChevronLeft, Mic, Search, X } from 'lucide-react';
import { Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { ThreeGlobe } from '../globe/ThreeGlobe';
import { useSpeechRecognition } from '../../hooks/useSpeechRecognition';

interface ExploreScreenProps {
  language: Language;
  currency: Currency;
  onSelectCityAction: (cityName: string) => void;
}

interface DestinationDetail {
  id: string;
  name: string;
  country: string;
  continent: 'europe' | 'asia' | 'africa' | 'middleEast' | 'americas';
  imageUrl: string;
  bestTime: string;
  weather: string;
  attractions: string[];
  restaurants: string[];
  tips: string;
}

const DESTINATIONS: DestinationDetail[] = [
  {
    id: 'ist',
    name: 'إسطنبول (Istanbul)',
    country: 'تركيا',
    continent: 'europe',
    imageUrl: 'https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?auto=format&fit=crop&w=800&q=80',
    bestTime: 'أبريل - مايو & سبتمبر - نوفمبر',
    weather: '18°C مشمس جزئياً',
    attractions: ['آيا صوفيا التاريخية', 'مضيق البوسفور', 'قصر توبكابي', 'البازار الكبير', 'برج غلاطة'],
    restaurants: ['مطعم نصرت Nusret', 'مطعم حمدي Hamdi Restaurant', 'بانوراما 360 إسطنبول'],
    tips: 'استخدم بطاقة Istanbulkart للمواصلات، واحرص على تجربة الشاي التركي في تلة بيير لوتي.',
  },
  {
    id: 'dxb',
    name: 'دبي (Dubai)',
    country: 'الإمارات العربية المتحدة',
    continent: 'middleEast',
    imageUrl: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=800&q=80',
    bestTime: 'نوفمبر - مارس',
    weather: '26°C مشمس دافئ',
    attractions: ['برج خليفة', 'نافورة دبي الراقصة', 'متحف المستقبل', 'نخلة جميرا', 'دبي مول'],
    restaurants: ['أتموسفير في برج خليفة', 'أوسيانو تحت الماء', 'زوما Zuma'],
    tips: 'احجز تذاكر متحف المستقبل وبرج خليفة مسبقاً عبر Tourism By Taki لتفادي طوابير الانتظار.',
  },
  {
    id: 'par',
    name: 'باريس (Paris)',
    country: 'فرنسا',
    continent: 'europe',
    imageUrl: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=80',
    bestTime: 'مايو - أكتوبر',
    weather: '15°C ربيعي معتدل',
    attractions: ['برج إيفل', 'متحف اللوفر', 'قوس النصر والشانزليزيه', 'كاتدرائية نوتردام', 'قصر فرساي'],
    restaurants: ['لو جول فيرن Le Jules Verne', 'كافيه دو فلور', 'لو ترين بلو Le Train Bleu'],
    tips: 'احرص على أخذ جولة بحرية في نهر السين وقت الغروب للاستمتاع بإضاءة المعالم الباريسية.',
  },
  {
    id: 'mkk',
    name: 'مكة المكرمة والمدينة',
    country: 'المملكة العربية السعودية',
    continent: 'middleEast',
    imageUrl: 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=800&q=80',
    bestTime: 'على مدار العام (خصوصاً رجب وشعبان ورمضان)',
    weather: '30°C معتدل ليلاً',
    attractions: ['المسجد الحرام والكعبة المشرفة', 'المسجد النبوي الشريف', 'غار حراء وجبل النور', 'مسجد قباء'],
    restaurants: ['مطاعم مجمع أبراج البيت', 'مطاعم الضيافة الفندقية 5 نجوم'],
    tips: 'خدمات النقل عبر قطار الحرمين السريع درجة رجال الأعمال تختصر المسافة بين مكة والمدينة في ساعتين فقط.',
  },
  {
    id: 'kul',
    name: 'كوالالمبور (Kuala Lumpur)',
    country: 'ماليزيا',
    continent: 'asia',
    imageUrl: 'https://images.unsplash.com/photo-1596422846543-75c6fc197f07?auto=format&fit=crop&w=800&q=80',
    bestTime: 'مايو - سبتمبر',
    weather: '29°C استوائي منعش',
    attractions: ['برجا بتروناس التوأم', 'كهوف باتو Batu Caves', 'حديقة الطيور الاستوائية', 'مرتفعات جينتنج'],
    restaurants: ['مارينيز أون 57 Marini’s', 'مطعم فود كورت بافيليون'],
    tips: 'وجهة مثالية للعائلات الجزائرية دون الحاجة لتأشيرة مسبقة (دخول مجاني 90 يوماً).',
  },
];

export function ExploreScreen({ language, currency, onSelectCityAction }: ExploreScreenProps) {
  const [selectedContinent, setSelectedContinent] = useState<'all' | 'europe' | 'asia' | 'africa' | 'middleEast' | 'americas'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeDestination, setActiveDestination] = useState<DestinationDetail>(DESTINATIONS[0]);

  const [voiceNotice, setVoiceNotice] = useState<string>('');

  const t = translations[language];

  // Speech Recognition Hook for voice commands
  const { isListening, startListening, stopListening } = useSpeechRecognition({
    language,
    onResult: (spokenText) => {
      setSearchQuery(spokenText);
      // Auto-match and select corresponding destination if spoken
      const matched = DESTINATIONS.find(d =>
        d.name.toLowerCase().includes(spokenText.toLowerCase()) ||
        d.country.toLowerCase().includes(spokenText.toLowerCase())
      );
      if (matched) {
        setActiveDestination(matched);
        setVoiceNotice(language === 'ar' ? `تم تحديد وجهة "${matched.name}" صوتياً!` : `Voice selected: ${matched.name}!`);
      } else {
        setVoiceNotice(language === 'ar' ? `تم تسجيل البحث: "${spokenText}"` : `Voice search: "${spokenText}"`);
      }
      setTimeout(() => setVoiceNotice(''), 3500);
    },
  });

  const filteredDestinations = DESTINATIONS.filter(d => {
    const matchesContinent = selectedContinent === 'all' ? true : d.continent === selectedContinent;
    const matchesQuery = !searchQuery.trim() ||
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.tips.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesContinent && matchesQuery;
  });

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div>
        <h1 className="text-xl md:text-2xl font-black text-white">
          {t.exploreTitle}
        </h1>
        <p className="text-xs text-slate-300 mt-1">
          {language === 'ar' ? 'تصفح العالم عبر المجسم ثلاثي الأبعاد أو ابحث بصوتك عن أي وجهة' : 'Interactive 3D World Globe & Voice-Powered Destination Finder'}
        </p>
      </div>

      {/* Voice & Text Destination Search Bar */}
      <div className="glass-panel p-3.5 rounded-2xl border border-cyan-500/25 space-y-2">
        <div className="flex items-center gap-2 bg-[#060c20] p-2 rounded-xl border border-slate-800 focus-within:border-cyan-400 transition-colors">
          <Search className="w-4 h-4 text-cyan-400 mx-1 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={
              isListening
                ? (language === 'ar' ? 'جاري الاستماع لصوتك... (تحدث الآن)' : 'Listening to your voice...')
                : (language === 'ar' ? 'ابحث بالصوت أو النص: إسطنبول، دبي، باريس...' : 'Search by voice or text: Istanbul, Dubai...')
            }
            className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 outline-none"
          />

          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="p-1 text-slate-400 hover:text-white"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Voice Search Button with Animated Pulse */}
          <button
            type="button"
            onClick={() => isListening ? stopListening() : startListening(['إسطنبول', 'باريس', 'دبي', 'مكة المكرمة', 'كوالالمبور'])}
            className={`h-9 px-3 rounded-lg flex items-center gap-1.5 font-bold text-xs transition-all shrink-0 ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse shadow-[0_0_15px_#f43f5e]'
                : 'bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 hover:bg-cyan-500/30'
            }`}
            title="Search with Voice"
            aria-label="Voice Search"
          >
            <Mic className={`w-3.5 h-3.5 ${isListening ? 'animate-bounce' : ''}`} />
            <span>{isListening ? (language === 'ar' ? 'استماع...' : 'Listening...') : (language === 'ar' ? 'تحدث' : 'Voice')}</span>
          </button>
        </div>

        {/* Quick Voice Suggestion Chips */}
        <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px] text-slate-400">
          <span className="text-cyan-400 font-semibold flex items-center gap-1 text-[10px]">
            <Sparkles className="w-3 h-3" />
            {language === 'ar' ? 'جرب أن تقول:' : 'Try saying:'}
          </span>
          {['إسطنبول', 'باريس', 'دبي', 'مكة المكرمة', 'كوالالمبور'].map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => {
                setSearchQuery(city);
                const matched = DESTINATIONS.find(d =>
                  d.name.toLowerCase().includes(city.toLowerCase()) ||
                  d.country.toLowerCase().includes(city.toLowerCase())
                );
                if (matched) {
                  setActiveDestination(matched);
                  setVoiceNotice(language === 'ar' ? `تم تحديد وجهة "${matched.name}"` : `Selected: ${matched.name}`);
                  setTimeout(() => setVoiceNotice(''), 3000);
                }
              }}
              className="px-2 py-0.5 rounded-full bg-slate-900/90 hover:bg-cyan-950 border border-slate-800 hover:border-cyan-400/50 text-slate-300 hover:text-cyan-300 transition-colors text-[10px]"
            >
              "{city}"
            </button>
          ))}
        </div>

        {isListening && (
          <p className="text-[11px] text-cyan-300 font-mono animate-pulse px-2">
            🎙️ {language === 'ar' ? 'قل اسم المدينة (مثال: "إسطنبول" أو "دبي") لتحديدها فوراً...' : 'Say a destination (e.g. "Paris" or "Istanbul")...'}
          </p>
        )}

        {voiceNotice && (
          <div className="text-[11px] text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 px-3 py-1.5 rounded-xl font-mono flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>{voiceNotice}</span>
          </div>
        )}
      </div>

      {/* 3D Interactive Three.js Globe */}
      <div className="glass-panel-elevated rounded-3xl overflow-hidden p-2 border border-cyan-500/25 relative">
        <ThreeGlobe />
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-[10px] text-cyan-400 bg-black/60 px-3 py-1 rounded-full border border-cyan-500/30 font-mono">
          {language === 'ar' ? 'حرّك الكرة الأرضية باللمس للاستكشاف' : 'Drag to rotate 3D Globe'}
        </div>
      </div>

      {/* Continents Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {(['all', 'europe', 'asia', 'middleEast', 'africa', 'americas'] as const).map(cont => (
          <button
            key={cont}
            onClick={() => setSelectedContinent(cont)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
              selectedContinent === cont
                ? 'bg-blue-600/30 border-cyan-400 text-white shadow-[0_0_12px_rgba(0,240,255,0.25)]'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {t.continents[cont]}
          </button>
        ))}
      </div>

      {/* Destinations Horizontal Carousel */}
      <div className="space-y-2">
        <p className="text-xs font-bold text-slate-300">
          {language === 'ar' ? 'المدن والوجهات الأكثر طلباً:' : 'Top Destinations:'}
        </p>
        <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
          {filteredDestinations.map(dest => (
            <button
              key={dest.id}
              onClick={() => setActiveDestination(dest)}
              className={`flex-shrink-0 w-36 rounded-2xl overflow-hidden border text-left rtl:text-right transition-all ${
                activeDestination.id === dest.id
                  ? 'border-cyan-400 shadow-[0_0_20px_rgba(0,240,255,0.3)]'
                  : 'border-slate-800 opacity-75 hover:opacity-100'
              }`}
            >
              <div className="h-20 w-full relative">
                <img
                  src={dest.imageUrl}
                  alt={dest.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#060c22] via-transparent to-transparent" />
              </div>
              <div className="p-2 bg-[#060c22]">
                <p className="text-xs font-bold text-white truncate">{dest.name}</p>
                <p className="text-[10px] text-cyan-400">{dest.country}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Active Destination Full Detail Sheet */}
      <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-500/30 text-white space-y-4">
        {/* Hero banner */}
        <div className="relative h-48 rounded-2xl overflow-hidden">
          <img
            src={activeDestination.imageUrl}
            alt={activeDestination.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#070b1e] via-black/30 to-transparent" />
          <div className="absolute bottom-3 right-3 left-3 flex items-end justify-between">
            <div>
              <span className="text-[10px] text-cyan-400 uppercase tracking-wider font-mono font-bold">
                {activeDestination.country}
              </span>
              <h2 className="text-xl font-black text-white">{activeDestination.name}</h2>
            </div>
            <button
              onClick={() => onSelectCityAction(activeDestination.name)}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs shadow-lg hover:brightness-110 active:scale-95"
            >
              {language === 'ar' ? 'حجز رحلة هنا' : 'Plan Trip'}
            </button>
          </div>
        </div>

        {/* Weather & Best Time */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="p-3 bg-slate-900/80 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-400 flex items-center gap-1 mb-1">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.weather}</span>
            </span>
            <p className="font-bold text-white font-mono">{activeDestination.weather}</p>
          </div>
          <div className="p-3 bg-slate-900/80 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-400 flex items-center gap-1 mb-1">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.bestTimeToVisit}</span>
            </span>
            <p className="font-bold text-white text-[11px] truncate">{activeDestination.bestTime}</p>
          </div>
        </div>

        {/* Attractions */}
        <div className="space-y-1.5">
          <p className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{t.topAttractions}:</span>
          </p>
          <div className="flex flex-wrap gap-1.5">
            {activeDestination.attractions.map((att, i) => (
              <span
                key={i}
                className="text-[11px] bg-slate-900/90 border border-slate-800 text-slate-300 px-2.5 py-1 rounded-xl"
              >
                {att}
              </span>
            ))}
          </div>
        </div>

        {/* Restaurants */}
        <div className="space-y-1.5">
          <p className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Utensils className="w-3.5 h-3.5 text-blue-400" />
            <span>{language === 'ar' ? 'أشهر المطاعم الموصى بها:' : 'Recommended Dining:'}</span>
          </p>
          <div className="flex flex-wrap gap-1.5">
            {activeDestination.restaurants.map((res, i) => (
              <span
                key={i}
                className="text-[11px] bg-slate-900/90 border border-slate-800 text-slate-300 px-2.5 py-1 rounded-xl"
              >
                {res}
              </span>
            ))}
          </div>
        </div>

        {/* Tips from Tourism By Taki */}
        <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/20 text-xs text-slate-300">
          <p className="font-bold text-cyan-400 mb-1 flex items-center gap-1">
            <Compass className="w-3.5 h-3.5" />
            <span>{t.travelTips}</span>
          </p>
          <p className="leading-relaxed text-[11px]">{activeDestination.tips}</p>
        </div>
      </div>
    </div>
  );
}
