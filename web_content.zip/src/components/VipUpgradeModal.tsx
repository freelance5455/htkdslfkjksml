import React from 'react';
import { UserProfile } from '../types';
import { Crown, Sparkles, X, AlertCircle } from 'lucide-react';
import { playAppSound } from '../utils/audio';
import confetti from 'canvas-confetti';

interface VipUpgradeModalProps {
  user: UserProfile;
  onUpgrade: (newVipLevel: number, remainingPoints: number, newRank: string) => void;
  onClose: () => void;
  onToast: (msg: string) => void;
}

export const VipUpgradeModal: React.FC<VipUpgradeModalProps> = ({
  user,
  onUpgrade,
  onClose,
  onToast
}) => {
  const currentVip = user.vipLevel || (user.id === 'ASEF-777777' ? 20 : 0);
  const nextVip = currentVip + 1;
  const isMax = currentVip >= 20;

  // Each level requires nextVip * 100 points
  const requiredPoints = nextVip * 100;
  const canAfford = (user.points || 0) >= requiredPoints;

  const handleUpgrade = () => {
    if (isMax) {
      onToast('أنت بالفعل في أعلى مستوى ملكي VIP 20 👑');
      return;
    }
    if (!canAfford) {
      playAppSound('alert');
      onToast(`نقاطك غير كافية! تحتاج ${requiredPoints} نقطة ورصيدك الحالي ${user.points || 0}`);
      return;
    }

    const remaining = (user.points || 0) - requiredPoints;
    let newRank = user.rank || 'عضو ذهبي 👑';
    if (nextVip >= 20) {
      newRank = '👑 المؤسس الملكي';
    } else if (nextVip >= 10) {
      newRank = '👑 رتبة ماسية ملكية';
    } else if (nextVip >= 5) {
      newRank = '✨ رتبة قوس قزح المشعة';
    } else if (nextVip >= 1) {
      newRank = '⭐ عضو VIP معتمد';
    }

    playAppSound('vip');
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    onUpgrade(nextVip, remaining, newRank);
    onToast(`🎉 مبارك! تمت ترقية حسابك الملكي بنجاح إلى VIP ${nextVip}`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-sm glass-panel-heavy rounded-2xl border border-[#ffd700]/30 p-5 text-center shadow-2xl">
        <div className="flex justify-between items-center mb-3">
          <div className="w-7"></div>
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#ffd700] to-[#ffa500] text-black flex items-center justify-center mx-auto shadow-lg shadow-[#ffd700]/30">
            <Crown className="w-6 h-6" />
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h3 className="text-lg font-black text-[#ffd700] mb-1">
          نظام الترقية الملكي بالنقاط
        </h3>
        <p className="text-xs text-gray-300 mb-4">
          ارتقِ بمستوى حسابك لتكتسب ألواناً متوهجة وهيبة ملكية داخل التطبيق والمجموعات!
        </p>

        {/* Current status card */}
        <div className="bg-black/40 rounded-xl p-3 border border-white/5 mb-4 text-right space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-gray-400">المستوى الحالي:</span>
            <span className="font-extrabold text-[#25d366]">{currentVip > 0 ? `VIP ${currentVip}` : 'عضو قياسي'}</span>
          </div>
          <div className="flex justify-between items-center text-xs">
            <span className="text-gray-400">رصيد نقاطك المتوفر:</span>
            <span className="font-extrabold text-[#ffd700]">⭐ {user.points || 0} نقطة</span>
          </div>
          <div className="flex justify-between items-center text-xs border-t border-white/10 pt-2">
            <span className="text-gray-300 font-semibold">المستوى القادم المستهدف:</span>
            <span className="font-extrabold text-amber-400">VIP {nextVip}</span>
          </div>
          <div className="flex justify-between items-center text-xs">
            <span className="text-gray-300 font-semibold">النقاط المطلوبة للترقية:</span>
            <span className={`font-extrabold ${canAfford ? 'text-[#25d366]' : 'text-red-400'}`}>
              {requiredPoints} نقطة
            </span>
          </div>
        </div>

        {/* Perks description */}
        <div className="text-[11px] text-gray-400 bg-white/5 p-2.5 rounded-xl mb-4 text-right">
          <p className="font-bold text-white mb-1">👑 مميزات مستويات VIP:</p>
          <ul className="space-y-0.5 list-disc list-inside">
            <li>VIP 1-4: ألوان مميزة (برونزي، أزرق، قرمزي، زمردي).</li>
            <li>VIP 5 فما فوق: توهج قوس قزح المشع (Rainbow Glow).</li>
            <li>شارة ملكية ذهبية معتمدة بجانب اسمك في كل رسالة.</li>
          </ul>
        </div>

        {!canAfford && !isMax && (
          <div className="flex items-center gap-1.5 text-xs text-amber-300/90 bg-amber-950/40 border border-amber-500/20 p-2 rounded-xl mb-3 text-right">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
            <span>يمكنك كسب 5 نقاط لكل صديق يسجل عبر رابط دعوتك الخاص!</span>
          </div>
        )}

        <button
          onClick={handleUpgrade}
          disabled={isMax}
          className={`w-full py-3 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition shadow-lg ${
            isMax
              ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
              : canAfford
              ? 'bg-gradient-to-r from-[#ffd700] via-[#ffa500] to-[#ffd700] text-black hover:opacity-95 shadow-[#ffd700]/30 active:scale-95'
              : 'bg-white/10 text-gray-400 hover:bg-white/15'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>{isMax ? 'وصلت للحد الأقصى (VIP 20)' : `ترقية إلى VIP ${nextVip} الآن 👑`}</span>
        </button>
      </div>
    </div>
  );
};
