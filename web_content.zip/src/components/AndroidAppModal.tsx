import React, { useState } from 'react';
import { Smartphone, Download, CheckCircle, ExternalLink, X, Copy, QrCode, Shield, Sparkles, Home } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { soundManager } from '../game/audio/SoundManager';

interface Props {
  onClose: () => void;
}

export const AndroidAppModal: React.FC<Props> = ({ onClose }) => {
  const { isInstallable, isInstalled, isAndroid, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  const sharedUrl = window.location.href;

  const handleInstallClick = async () => {
    soundManager.playButtonClick();
    if (isInstallable) {
      const success = await install();
      if (success) {
        setInstallSuccess(true);
      }
    }
  };

  const handleCopyUrl = () => {
    soundManager.playButtonClick();
    navigator.clipboard.writeText(sharedUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-2xl shadow-[0_0_40px_rgba(245,158,11,0.2)] flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-600 to-amber-400 flex items-center justify-center shadow-lg">
              <Smartphone className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-wider text-white uppercase font-display">
                SPR Android App
              </h2>
              <p className="text-[11px] text-slate-400">Installable Native Package & Options</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="android-modal-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-4 h-4" />
              <span>HOME</span>
            </button>

            <button
              id="android-modal-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center hover:bg-slate-700 transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex flex-col gap-4 text-slate-200 text-sm">
          {/* App Identity Card */}
          <div className="flex items-center gap-4 p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl">
            <img
              src="/pwa-192x192.png"
              alt="SPR App Icon"
              className="w-16 h-16 rounded-xl border border-amber-400 shadow-md object-cover"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-base font-black text-white font-display">SPR – Sahil Powerful Run</span>
                <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold rounded">
                  v1.0.0
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate mt-0.5">Package ID: com.sahil.spr3d</p>
              <div className="flex items-center gap-3 mt-1 text-[11px] text-amber-400">
                <span>⚡ 60 FPS 3D</span>
                <span>•</span>
                <span>🎮 Full Touch Controls</span>
                <span>•</span>
                <span>🛹 Skateboard</span>
              </div>
            </div>
          </div>

          {/* Option 1: Direct Android 1-Click Install (WebAPK) */}
          <div className="p-4 bg-gradient-to-br from-slate-800/80 to-slate-900/90 border border-cyan-500/50 rounded-xl flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-sm uppercase tracking-wider font-display">
                  Method 1: Direct Install on Android Device (WebAPK)
                </h3>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold">
                Recommended
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Android automatically packages the SPR game as a <strong>native WebAPK</strong> directly in your phone's app drawer, with offline play and no browser navigation bars.
            </p>

            {isInstalled || installSuccess ? (
              <div className="flex items-center gap-2 p-2.5 bg-emerald-500/15 border border-emerald-500/40 rounded-lg text-emerald-300 text-xs font-semibold">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>SPR is already installed on this device! Launch it from your Home Screen or App Drawer.</span>
              </div>
            ) : isInstallable ? (
              <button
                id="btn-trigger-android-install"
                onClick={handleInstallClick}
                className="w-full py-3 bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 text-slate-950 font-black text-sm uppercase tracking-wider rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer font-display"
              >
                <Download className="w-4 h-4" />
                Install SPR On This Android Device
              </button>
            ) : (
              <div className="p-3 bg-slate-950/60 border border-slate-700/60 rounded-lg flex flex-col gap-1.5 text-xs text-slate-300">
                <p className="font-medium text-amber-300">
                  📲 To install directly onto your Android phone:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-300">
                  <li>Open this game in <strong>Google Chrome</strong> on your Android device.</li>
                  <li>Tap the <strong>three dots (⋮)</strong> menu in the top right corner.</li>
                  <li>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                  <li>Android will build and install the official SPR 3D app icon into your phone's App Drawer!</li>
                </ol>
              </div>
            )}
          </div>

          {/* Option 2: Build Standalone APK via Android Studio */}
          <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-white text-sm uppercase tracking-wider font-display">
                  Method 2: Standalone .APK Project (.ZIP)
                </h3>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold">
                Offline Ready
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Download the complete, self-contained offline SPR project with pre-configured Android Gradle build, native launcher icons, and bundled game assets:
            </p>
            <a
              id="btn-download-spr-zip"
              href="/SPR_SwapLab_UNDER_50MB_READY.zip"
              download="SPR_SwapLab_UNDER_50MB_READY.zip"
              className="w-full py-2.5 bg-gradient-to-r from-cyan-600 via-sky-500 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer font-display active:scale-95 text-center"
            >
              <Download className="w-4 h-4 text-slate-950" />
              Download SwapLab Project ZIP (Optimized &lt; 25 MB)
            </a>
            <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
              <li>Unzip and open in <strong>Android Studio</strong>.</li>
              <li>Click <strong>Build &rarr; Build Bundle(s) / APK(s) &rarr; Build APK(s)</strong>.</li>
              <li>Install the compiled <code className="text-cyan-300">app-debug.apk</code> or <code className="text-amber-300">app-release.apk</code> directly onto any Android phone!</li>
            </ol>
          </div>

          {/* Share / Open on Phone Link */}
          <div className="flex items-center gap-2 p-2.5 bg-slate-950/90 border border-slate-800 rounded-xl">
            <input
              type="text"
              readOnly
              value={sharedUrl}
              className="flex-1 bg-transparent text-xs text-slate-400 truncate outline-none"
            />
            <button
              onClick={handleCopyUrl}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              {copied ? <CheckCircle className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied Link!' : 'Copy Link'}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-end">
          <button
            onClick={() => {
              soundManager.playButtonClick();
              onClose();
            }}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition cursor-pointer font-display"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
