import { useCallback, useMemo, useState } from "react";
import { getQuizQuestions, type QuizQuestion, type Difficulty } from "../data/quiz";
import type { ClassLevel, Subject } from "../data/types";
import { useQuizState } from "../state/QuizState";
import { useAppState } from "../state/AppState";
import { generateAiQuizQuestion } from "../ai/quizGenerator";

const CLASS_OPTIONS: ClassLevel[] = [8, 9, 10];
const SUBJECT_OPTIONS: Subject[] = ["Mathematics", "Physics", "Chemistry"];
const DIFFICULTY_OPTIONS: (Difficulty | "All")[] = ["All", "Easy", "Medium", "Hard"];
const RECENT_WINDOW = 4; // avoid repeating the last N questions where possible
const ROUND_LENGTH = 5; // number of questions per quiz round, ending in a completion summary

function pickQuestion(pool: QuizQuestion[], recentIds: string[]): QuizQuestion | null {
  if (pool.length === 0) return null;
  const fresh = pool.filter((q) => !recentIds.includes(q.id));
  const choices = fresh.length > 0 ? fresh : pool;
  return choices[Math.floor(Math.random() * choices.length)];
}

export default function Quiz() {
  const { board } = useAppState();
  const { prefs, setPrefs, stats, recordAnswer, resetStats } = useQuizState();
  const [started, setStarted] = useState(false);
  const [current, setCurrent] = useState<QuizQuestion | null>(null);
  const [recentIds, setRecentIds] = useState<string[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [sessionCount, setSessionCount] = useState(0);
  const [sessionCorrect, setSessionCorrect] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const pool = useMemo(() => getQuizQuestions(prefs.classLevel, prefs.subject, prefs.difficulty), [prefs]);

  const loadNext = useCallback(
    (ids: string[]) => {
      const q = pickQuestion(pool, ids);
      setCurrent(q);
      setSelected(null);
      setSubmitted(false);
      if (q) setRecentIds([q.id, ...ids].slice(0, RECENT_WINDOW));
    },
    [pool]
  );

  function startQuiz() {
    setStarted(true);
    setCompleted(false);
    setSessionCount(0);
    setSessionCorrect(0);
    loadNext([]);
  }

  function submitAnswer() {
    if (selected === null || !current) return;
    setSubmitted(true);
    const correct = selected === current.correctIndex;
    recordAnswer(correct);
    setSessionCount((c) => c + 1);
    if (correct) setSessionCorrect((c) => c + 1);
  }

  function nextQuestion() {
    if (sessionCount >= ROUND_LENGTH) {
      setCompleted(true);
      setCurrent(null);
      return;
    }
    loadNext(recentIds);
  }

  function playAgain() {
    setCompleted(false);
    setSessionCount(0);
    setSessionCorrect(0);
    loadNext(recentIds);
  }

  async function requestAiQuestion() {
    setAiLoading(true);
    setAiError(null);
    const result = await generateAiQuizQuestion(board, prefs.classLevel, prefs.subject, prefs.difficulty === "All" ? "Medium" : prefs.difficulty);
    setAiLoading(false);
    if (result.ok && result.question) {
      setCurrent(result.question);
      setSelected(null);
      setSubmitted(false);
    } else {
      setAiError(result.error ?? "Couldn't generate an AI question right now.");
    }
  }

  const accuracy = stats.attempted > 0 ? Math.round((stats.correct / stats.attempted) * 100) : 0;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
      <div className="mb-2 flex items-center gap-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md">
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 11l3 3L22 4" />
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
          </svg>
        </span>
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Quiz</h1>
      </div>
      <p className="text-sm text-slate-500 dark:text-slate-400">
        Test yourself with a verified question bank for Classes 8–10 ({board} selected). The bank covers core concepts common to both
        boards; pick a class, subject and difficulty, then answer as many as you like. You can also ask for a one-off AI-generated
        question, clearly labeled as such.
      </p>

      <div className="mt-5 grid gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:grid-cols-3">
        <Selector label="Class" value={String(prefs.classLevel)} options={CLASS_OPTIONS.map(String)} onChange={(v) => setPrefs({ ...prefs, classLevel: Number(v) as ClassLevel })} />
        <Selector label="Subject" value={prefs.subject} options={SUBJECT_OPTIONS} onChange={(v) => setPrefs({ ...prefs, subject: v as Subject })} />
        <Selector label="Difficulty" value={prefs.difficulty} options={DIFFICULTY_OPTIONS} onChange={(v) => setPrefs({ ...prefs, difficulty: v as Difficulty | "All" })} />
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 dark:text-slate-500">
        <span>{pool.length} question{pool.length === 1 ? "" : "s"} available for this selection</span>
        <span>
          All-time: {stats.correct}/{stats.attempted} correct ({accuracy}%) · Best streak: {stats.bestStreak}
          {stats.attempted > 0 && (
            <button onClick={resetStats} className="ml-2 underline hover:text-slate-600 dark:hover:text-slate-300">
              reset
            </button>
          )}
        </span>
      </div>

      {!started && (
        <div className="mt-6 text-center">
          <button
            onClick={startQuiz}
            disabled={pool.length === 0}
            className="rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-3 text-sm font-semibold text-white shadow-md transition hover:opacity-90 disabled:opacity-40"
          >
            {pool.length === 0 ? "No questions for this selection yet" : "Start Quiz →"}
          </button>
        </div>
      )}

      {started && current && !completed && (
        <div className="mt-6 animate-fade-in rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
            <span className="rounded-md bg-indigo-50 px-2 py-0.5 font-semibold text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
              Class {current.classLevel} · {current.subject} · {current.difficulty}
            </span>
            <span
              className={`rounded-md px-2 py-0.5 text-[10px] font-semibold ${
                current.source === "ai" ? "bg-violet-50 text-violet-600 dark:bg-violet-500/10 dark:text-violet-300" : "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300"
              }`}
            >
              {current.source === "ai" ? "✨ AI-generated" : "✓ Verified Question Bank"}
            </span>
            <span>
              Question {Math.min(sessionCount + 1, ROUND_LENGTH)} of {ROUND_LENGTH} · Score: {sessionCorrect}/{sessionCount}
            </span>
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all" style={{ width: `${(sessionCount / ROUND_LENGTH) * 100}%` }} />
          </div>
          <p className="mt-2 text-[11px] text-slate-400 dark:text-slate-500">{current.topic}</p>

          {!submitted && (
            <div className="mt-2 flex items-center justify-between gap-2">
              <button
                onClick={requestAiQuestion}
                disabled={aiLoading}
                className="text-xs font-medium text-violet-600 underline decoration-dotted transition hover:text-violet-700 disabled:opacity-50 dark:text-violet-400"
              >
                {aiLoading ? "Asking AI for a question…" : "✨ Try an AI-generated question instead"}
              </button>
            </div>
          )}
          {aiError && <p className="mt-1 text-xs text-rose-500">{aiError}</p>}

          <h2 className="mt-3 text-lg font-semibold text-slate-800 dark:text-slate-100">{current.question}</h2>

          <div className="mt-4 space-y-2">
            {current.options.map((opt, i) => {
              const isCorrect = i === current.correctIndex;
              const isSelected = i === selected;
              let cls = "border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-500/50";
              if (submitted) {
                if (isCorrect) cls = "border-emerald-400 bg-emerald-50 dark:border-emerald-500/50 dark:bg-emerald-500/10";
                else if (isSelected) cls = "border-rose-400 bg-rose-50 dark:border-rose-500/50 dark:bg-rose-500/10";
              } else if (isSelected) {
                cls = "border-indigo-400 bg-indigo-50 dark:border-indigo-500/50 dark:bg-indigo-500/10";
              }
              return (
                <button
                  key={i}
                  onClick={() => !submitted && setSelected(i)}
                  disabled={submitted}
                  className={`w-full rounded-xl border px-4 py-2.5 text-left text-sm text-slate-700 transition dark:text-slate-200 ${cls}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>

          {!submitted ? (
            <button
              onClick={submitAnswer}
              disabled={selected === null}
              className="mt-4 w-full rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90 disabled:opacity-40"
            >
              Submit Answer
            </button>
          ) : (
            <>
              <div
                className={`mt-4 rounded-xl p-3 text-sm ${
                  selected === current.correctIndex
                    ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300"
                    : "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300"
                }`}
              >
                <span className="font-semibold">{selected === current.correctIndex ? "✓ Correct! " : "✗ Not quite. "}</span>
                {current.explanation}
              </div>
              <button
                onClick={nextQuestion}
                className="mt-4 w-full rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90"
              >
                {sessionCount >= ROUND_LENGTH ? "Finish Round →" : "Next Question →"}
              </button>
            </>
          )}
        </div>
      )}

      {started && completed && (
        <div className="mt-6 animate-fade-in rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-4xl">{sessionCorrect === ROUND_LENGTH ? "🏆" : sessionCorrect >= ROUND_LENGTH / 2 ? "🎉" : "📘"}</div>
          <h2 className="mt-2 text-lg font-bold text-slate-800 dark:text-slate-100">Round Complete!</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            You scored {sessionCorrect} out of {ROUND_LENGTH} in Class {prefs.classLevel} {prefs.subject}.
          </p>
          <button
            onClick={playAgain}
            className="mt-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90"
          >
            Play Another Round →
          </button>
          <button
            onClick={() => setStarted(false)}
            className="mt-2 block w-full rounded-xl border border-slate-200 px-6 py-2.5 text-sm font-medium text-slate-500 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            Change Class / Subject / Difficulty
          </button>
        </div>
      )}

      {started && !current && !completed && (
        <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
          No questions are available for this Class/Subject/Difficulty combination yet. Try a different selection.
        </div>
      )}
    </div>
  );
}

function Selector({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (v: string) => void }) {
  return (
    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">
      {label}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
      >
        {options.map((opt) => (
          <option key={opt} value={opt}>
            {label === "Class" ? `Class ${opt}` : opt}
          </option>
        ))}
      </select>
    </label>
  );
}
