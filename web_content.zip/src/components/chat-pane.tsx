import { useEffect, useRef, useState } from "react";
import {
  ArrowUp,
  Camera,
  FolderOpen,
  MapPin,
  Paperclip,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { askMira } from "@/lib/assistant/chat";
import { redirectToLoginIfRequired } from "@/lib/app-data";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RichText } from "@/components/rich-text";
import { greeting, pickContacts, readPickedFile } from "@/lib/device";
import type { DeviceFile } from "@/lib/assistant/types";
import { cn } from "@/lib/utils";

const PROMPTS = [
  "Brief me for today",
  "What did I miss in email?",
  "Find the latest file I worked on",
  "What's free this afternoon?",
];

export function ChatPane() {
  const messages = useAppStore((s) => s.messages);
  const addMessage = useAppStore((s) => s.addMessage);
  const addDeviceFiles = useAppStore((s) => s.addDeviceFiles);
  const draft = useAppStore((s) => s.draft);
  const setDraft = useAppStore((s) => s.setDraft);
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<DeviceFile[]>([]);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(
    null,
  );
  const [contacts, setContacts] = useState<
    Array<{ name?: string; email?: string; tel?: string }>
  >([]);
  const scroller = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);
  const empty = messages.length === 0;

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages, busy]);

  async function send(text?: string) {
    const content = (text ?? draft).trim();
    if (!content && pending.length === 0) return;
    if (busy) return;

    const display = content || "Look at what I attached.";
    addMessage({ role: "user", content: display });
    setDraft("");
    const attachments = pending.map((f) => ({
      name: f.name,
      mime: f.mime,
      text: f.text,
      dataUrl: f.dataUrl,
    }));
    setPending([]);
    setBusy(true);

    const history = [
      ...useAppStore.getState().messages.map((m) => ({
        role: m.role,
        content: m.content,
      })),
    ];

    try {
      const result = await askMira({
        data: {
          messages: history,
          attachments: attachments.length ? attachments : undefined,
          location: location ?? undefined,
          contacts: contacts.length ? contacts : undefined,
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          nowISO: new Date().toISOString(),
        },
      });

      if (result.loginRequired) {
        redirectToLoginIfRequired({
          ok: false,
          data: null,
          loginRequired: true,
          loginUrl: result.loginUrl,
        });
      }

      if (!result.ok) {
        addMessage({
          role: "assistant",
          content: result.error ?? "Something went wrong. Try again.",
        });
        return;
      }

      addMessage({
        role: "assistant",
        content: result.text,
        sources: result.sources,
      });
      if (result.pending) {
        toast("Still connecting to your Grok data. Ask again in a moment.");
      }
    } catch (error) {
      addMessage({
        role: "assistant",
        content:
          error instanceof Error
            ? error.message
            : "Could not reach Mira. Try again.",
      });
    } finally {
      setBusy(false);
      setLocation(null);
      setContacts([]);
    }
  }

  async function onFiles(list: FileList | null) {
    if (!list?.length) return;
    try {
      const read = await Promise.all(Array.from(list).slice(0, 4).map(readPickedFile));
      const created = addDeviceFiles(read);
      setPending((prev) => [...prev, ...created].slice(0, 6));
    } catch (error) {
      toast(error instanceof Error ? error.message : "Could not read that file.");
    }
  }

  function shareLocation() {
    if (!navigator.geolocation) {
      toast("Location is not available on this device.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        toast("Location attached to the next message.");
      },
      () => toast("Location permission was denied."),
      { enableHighAccuracy: false, timeout: 8000 },
    );
  }

  async function shareContacts() {
    try {
      const picked = await pickContacts();
      if (picked === null) {
        toast("Contact picking is not supported in this browser.");
        return;
      }
      setContacts(picked);
      toast(`${picked.length} contact${picked.length === 1 ? "" : "s"} attached.`);
    } catch {
      toast("Could not read contacts.");
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        {empty ? (
          <div className="stagger-in mx-auto flex max-w-lg flex-col gap-6 pt-8">
            <div>
              <p className="text-sm font-medium tracking-wide text-muted">
                {greeting()}
              </p>
              <h2 className="font-display mt-2 text-[2.15rem] leading-[1.15] tracking-[-0.03em] text-fg">
                What do you need from your files, mail, or day?
              </h2>
            </div>
            <p className="max-w-prose text-sm leading-relaxed text-muted">
              Mira reads Drive, Gmail, and Calendar when those are connected in
              Grok. Files, photos, contacts, and location from this phone only
              come through if you attach them.
            </p>
            <div className="flex flex-wrap gap-2">
              {PROMPTS.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => void send(prompt)}
                  className="rounded-full bg-raised px-3.5 py-2 text-left text-sm text-fg shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.96]"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="mx-auto flex max-w-lg flex-col gap-5 pt-4">
            {messages.map((message) => (
              <article
                key={message.id}
                className={cn(
                  "flex flex-col gap-2",
                  message.role === "user" ? "items-end" : "items-start",
                )}
              >
                {message.role === "user" ? (
                  <div className="max-w-[88%] rounded-xl rounded-br-md bg-raised px-3.5 py-2.5 text-[0.95rem] leading-relaxed text-fg shadow-[var(--shadow-border)]">
                    {message.content}
                  </div>
                ) : (
                  <RichText text={message.content} />
                )}
                {message.sources && message.sources.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {message.sources.slice(0, 6).map((source, i) => (
                      <Badge key={`${source.title}-${i}`}>
                        {source.kind} · {source.title}
                      </Badge>
                    ))}
                  </div>
                ) : null}
              </article>
            ))}
            {busy ? (
              <p className="shimmer text-sm font-medium">Looking through your sources…</p>
            ) : null}
          </div>
        )}
      </div>

      <div className="px-3 pb-2 pt-1">
        <div className="mx-auto max-w-lg rounded-xl bg-surface p-2 shadow-[var(--shadow-border)]">
          {pending.length > 0 || location || contacts.length > 0 ? (
            <div className="mb-2 flex flex-wrap gap-1.5 px-1">
              {pending.map((file) => (
                <Badge key={file.id} className="gap-1">
                  {file.name}
                  <button
                    type="button"
                    className="ml-0.5"
                    aria-label={`Remove ${file.name}`}
                    onClick={() =>
                      setPending((prev) => prev.filter((f) => f.id !== file.id))
                    }
                  >
                    <X className="size-3" />
                  </button>
                </Badge>
              ))}
              {location ? (
                <Badge>
                  Location
                  <button type="button" className="ml-1" onClick={() => setLocation(null)}>
                    <X className="size-3" />
                  </button>
                </Badge>
              ) : null}
              {contacts.length > 0 ? (
                <Badge>
                  {contacts.length} contacts
                  <button type="button" className="ml-1" onClick={() => setContacts([])}>
                    <X className="size-3" />
                  </button>
                </Badge>
              ) : null}
            </div>
          ) : null}

          <div className="flex items-end gap-1.5">
            <div className="flex gap-0.5">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-10"
                aria-label="Attach files"
                onClick={() => fileRef.current?.click()}
              >
                <Paperclip className="size-4" />
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-10"
                aria-label="Take a photo"
                onClick={() => photoRef.current?.click()}
              >
                <Camera className="size-4" />
              </Button>
            </div>
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
              rows={1}
              placeholder="Ask Mira…"
              className="mb-1 max-h-32 min-h-10 flex-1 resize-none bg-transparent py-2.5 text-[0.95rem] text-fg outline-none placeholder:text-faint"
            />
            <Button
              type="button"
              size="icon"
              className="size-10 rounded-lg"
              aria-label="Send"
              disabled={busy || (!draft.trim() && pending.length === 0)}
              onClick={() => void send()}
            >
              <ArrowUp className="size-4" />
            </Button>
          </div>

          <div className="flex items-center gap-1 px-1 pb-0.5">
            <button
              type="button"
              onClick={shareLocation}
              className="inline-flex h-8 items-center gap-1.5 rounded-md px-2 text-xs text-muted transition-colors duration-150 hover:text-fg"
            >
              <MapPin className="size-3.5" />
              Location
            </button>
            <button
              type="button"
              onClick={() => void shareContacts()}
              className="inline-flex h-8 items-center gap-1.5 rounded-md px-2 text-xs text-muted transition-colors duration-150 hover:text-fg"
            >
              <Users className="size-3.5" />
              Contacts
            </button>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="inline-flex h-8 items-center gap-1.5 rounded-md px-2 text-xs text-muted transition-colors duration-150 hover:text-fg"
            >
              <FolderOpen className="size-3.5" />
              Files
            </button>
          </div>
        </div>
        <input
          ref={fileRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            void onFiles(e.target.files);
            e.target.value = "";
          }}
        />
        <input
          ref={photoRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => {
            void onFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </div>
    </div>
  );
}
