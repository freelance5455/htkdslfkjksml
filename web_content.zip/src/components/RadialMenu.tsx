import React, { useState, useEffect, useRef } from "react";
import { Move, Sparkles, X } from "lucide-react";
import { RadialMenuConfig, RadialMenuItem, RadialActionType } from "../types";
import {
  RADIAL_THEMES,
  CONTEXTUAL_RADIAL_ITEMS,
  clampRadialPosition,
  renderRadialIcon,
  getStoredRadialMenuConfig,
  saveStoredRadialMenuConfig,
} from "../utils/radialMenuConfig";

interface RadialMenuProps {
  isOpen: boolean;
  onToggle: () => void;
  onClose: () => void;
  onSelectAction?: (actionId: RadialActionType | string) => void;
  config?: RadialMenuConfig;
  onUpdateConfig?: (cfg: Partial<RadialMenuConfig>) => void;
  isPreview?: boolean;
}

export const RadialMenu: React.FC<RadialMenuProps> = ({
  isOpen,
  onToggle,
  onClose,
  onSelectAction,
  config: propConfig,
  onUpdateConfig,
  isPreview = false,
}) => {
  const [internalConfig, setInternalConfig] = useState<RadialMenuConfig>(getStoredRadialMenuConfig);
  const activeConfig = propConfig || internalConfig;

  const [isDragging, setIsDragging] = useState(false);
  const [isIdle, setIsIdle] = useState(false);
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);

  const dragStartRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number }>({
    startX: 0,
    startY: 0,
    initialX: 180,
    initialY: 180,
  });

  const activeThemeDef = RADIAL_THEMES[activeConfig.activeTheme] || RADIAL_THEMES.productivity;

  // Sync internal config if updated
  const updateConfig = (patch: Partial<RadialMenuConfig>) => {
    const updated = { ...activeConfig, ...patch };
    setInternalConfig(updated);
    saveStoredRadialMenuConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);
  };

  // Idle Auto-Collapse Handler (3 seconds inactive)
  const resetIdleTimer = () => {
    setIsIdle(false);
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    if (activeConfig.idleAutoCollapse && isOpen) {
      idleTimerRef.current = setTimeout(() => {
        setIsIdle(true);
      }, 3500);
    }
  };

  useEffect(() => {
    resetIdleTimer();
    return () => {
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, [isOpen]);

  // Boundary Collision Detection on Pointer Drag
  const handlePointerDown = (e: React.PointerEvent) => {
    if (isPreview) return;
    e.preventDefault();
    resetIdleTimer();
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: activeConfig.position.x,
      initialY: activeConfig.position.y,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || isPreview) return;
    resetIdleTimer();
    const deltaX = e.clientX - dragStartRef.current.startX;
    const deltaY = e.clientY - dragStartRef.current.startY;

    const rawPos = {
      x: dragStartRef.current.initialX + deltaX,
      y: dragStartRef.current.initialY + deltaY,
    };

    const clampedPos = clampRadialPosition(rawPos, activeConfig.scale, 110);
    updateConfig({ position: clampedPos });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging || isPreview) return;
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {
      // Ignored
    }
  };

  // Filter contextual active items based on visibility settings
  const visibleItems = CONTEXTUAL_RADIAL_ITEMS.filter((item) => {
    if (activeConfig.visibleActions && activeConfig.visibleActions[item.id] === false) {
      return false;
    }
    return true;
  });

  const displayItems = visibleItems.length > 0 ? visibleItems : CONTEXTUAL_RADIAL_ITEMS.slice(0, 6);
  const menuRadius = 95; // Radius in px
  const totalItems = displayItems.length;

  if (activeConfig.useLegacyMenu) {
    return (
      <div
        className={`fixed z-50 transition-all select-none ${isPreview ? "relative" : ""}`}
        style={
          isPreview
            ? {}
            : {
                left: `${activeConfig.position.x}px`,
                top: `${activeConfig.position.y}px`,
                transform: `translate(-50%, -50%) scale(${activeConfig.scale})`,
              }
        }
      >
        <button
          type="button"
          onClick={onToggle}
          className="p-3 rounded-full bg-slate-900 text-white shadow-2xl border border-slate-700 flex items-center gap-2 cursor-pointer"
        >
          <span className="text-xs font-black px-1">Klasik Menü</span>
          <span className="w-6 h-6 rounded-full bg-teal-500 flex items-center justify-center font-bold text-xs">⚡</span>
        </button>
      </div>
    );
  }

  return (
    <div
      onMouseMove={resetIdleTimer}
      onClick={resetIdleTimer}
      className={`select-none transition-all duration-300 z-50 ${
        isPreview ? "relative flex items-center justify-center p-12 min-h-[280px]" : "fixed"
      } ${isIdle ? "opacity-35 hover:opacity-100 scale-95" : "opacity-100"}`}
      style={
        isPreview
          ? { transform: `scale(${activeConfig.scale})` }
          : {
              left: `${activeConfig.position.x}px`,
              top: `${activeConfig.position.y}px`,
              transform: `translate(-50%, -50%) scale(${activeConfig.scale})`,
            }
      }
    >
      {/* Container Disk */}
      <div className="relative flex items-center justify-center">
        
        {/* Radial Action Items Ring (Solid Opaque Mat Backgrounds z-50) */}
        {(isOpen || isPreview) && (
          <div className="absolute inset-0 flex items-center justify-center animate-in zoom-in-75 fade-in duration-200 z-50">
            {displayItems.map((item, index) => {
              const angle = index * ((2 * Math.PI) / totalItems) - Math.PI / 2;
              const x = Math.cos(angle) * menuRadius;
              const y = Math.sin(angle) * menuRadius;

              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    if (onSelectAction) onSelectAction(item.id);
                    resetIdleTimer();
                  }}
                  className="absolute w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-2xl flex flex-col items-center justify-center transition-all duration-200 hover:scale-115 active:scale-95 cursor-pointer group z-50"
                  style={{
                    transform: `translate(${x}px, ${y}px)`,
                  }}
                  title={item.label}
                >
                  <div className={item.color || "text-slate-800 dark:text-slate-100"}>
                    {renderRadialIcon(typeof item.icon === "string" ? item.icon : "Sparkles", "w-5 h-5")}
                  </div>

                  {/* Opaque Mat Label Badge */}
                  <span className="absolute top-full mt-1.5 px-2 py-0.5 rounded-lg bg-slate-900 dark:bg-slate-950 text-white text-[10px] font-bold border border-slate-800 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl z-50">
                    {item.label}
                  </span>

                  {item.badge && (
                    <span className="absolute -top-1 -right-1 text-[8px] font-black px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 shadow-md">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}

        {/* Center Trigger Button with Draggable Handle */}
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onClick={() => {
            if (!isDragging) onToggle();
          }}
          className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full flex flex-col items-center justify-center cursor-grab active:cursor-grabbing border-2 transition-all duration-300 z-50 ${
            activeThemeDef.centerBg
          } ${activeThemeDef.borderColor} ${activeThemeDef.glowShadow} ${
            isOpen ? "rotate-45 scale-105" : "hover:scale-105"
          }`}
        >
          <Move className="w-3.5 h-3.5 opacity-60 absolute top-1.5" />
          <span className="text-[10px] sm:text-xs font-black tracking-tight mt-1">
            {activeThemeDef.centerLabel}
          </span>
          <span className="text-[8px] font-mono opacity-80 uppercase tracking-widest">
            {isOpen ? "Kapat" : "Aç"}
          </span>
        </div>
      </div>
    </div>
  );
};
