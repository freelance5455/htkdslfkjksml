import React from 'react';
import { ArrowLeft, Globe, BarChart3, TrendingUp, Activity, Sparkles } from 'lucide-react';
import { AssetType } from '../types/trading';

interface DirectionSelectViewProps {
  onBack: () => void;
  onSelectDirection: (type: AssetType) => void;
}

export const DirectionSelectView: React.FC<DirectionSelectViewProps> = ({
  onBack,
  onSelectDirection,
}) => {
  return (
    <div className="w-full max-w-lg mx-auto flex flex-col items-center px-3 py-3">
      {/* Quotex Broker Header Banner (Screenshot 6) */}
      <div className="w-full flex items-center justify-between mb-2">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
      </div>

      <div className="flex items-center gap-2 mb-4">
        <div className="w-6 h-6 rounded bg-red-950 border border-red-500/40 flex items-center justify-center">
          <Activity className="w-3.5 h-3.5 text-red-500" />
        </div>
        <div className="text-left leading-tight">
          <span className="text-xs font-black text-slate-100 uppercase">Quotex</span>{' '}
          <span className="text-xs font-black text-red-500 uppercase">Broker</span>
          <div className="text-[9px] font-bold text-zinc-400 tracking-wider">
            SIGNALS OPTIMIZED ONLY
          </div>
        </div>
      </div>

      {/* Main Title & Subtitle (Screenshot 6) */}
      <div className="text-center mb-4">
        <h2 className="text-xl sm:text-2xl font-black text-slate-100 tracking-tight">
          SELECT TRADING DIRECTION
        </h2>
        <p className="text-xs text-zinc-400 mt-1">
          Choose your preferred market for AI-powered signals
        </p>

        {/* Live Proof Metatag Row */}
        <div className="flex items-center justify-center gap-3 text-[11px] font-bold mt-2 font-mono flex-wrap">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            94.7% WIN
          </span>
          <span className="text-zinc-500">·</span>
          <span className="text-zinc-300">50K+ TRADERS</span>
          <span className="text-zinc-500">·</span>
          <span className="text-red-400">REAL-TIME</span>
        </div>
      </div>

      {/* Market Cards */}
      <div className="w-full space-y-3.5">
        {/* Card 1: OTC PAIRS (HOT) */}
        <div
          onClick={() => onSelectDirection('OTC')}
          className="w-full bg-[#180710] hover:bg-[#200a16] border border-[#3b1223] hover:border-emerald-500/60 rounded-2xl p-4 cursor-pointer transition-all duration-200 group shadow-lg active:scale-[0.99]"
        >
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Globe className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-slate-100 group-hover:text-emerald-300 transition-colors">
                    OTC PAIRS
                  </h3>
                  <span className="text-[10px] font-black px-1.5 py-0.2 bg-red-600 text-white rounded font-mono shadow-sm">
                    HOT
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Forex & Currency pairs · Real-time OTC analysis
                </p>
              </div>
            </div>
            <TrendingUp className="w-5 h-5 text-zinc-500 group-hover:text-emerald-400 transition-colors" />
          </div>

          {/* Badges */}
          <div className="flex items-center gap-1.5 flex-wrap mt-3.5 text-[11px] font-medium font-mono text-zinc-300">
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">30 Assets</span>
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">24/7 Trading</span>
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">Forex · Crypto</span>
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">5-30s</span>
          </div>

          <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-[#2d0e1b] text-xs">
            <span className="flex items-center gap-1 text-emerald-400 font-semibold text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Active Markets
            </span>
            <span className="text-red-400 font-bold text-[11px] font-mono">
              High Volume
            </span>
          </div>
        </div>

        {/* Card 2: MARKET PAIRS (PRO) */}
        <div
          onClick={() => onSelectDirection('MARKET')}
          className="w-full bg-[#180710] hover:bg-[#200a16] border border-[#3b1223] hover:border-red-500/60 rounded-2xl p-4 cursor-pointer transition-all duration-200 group shadow-lg active:scale-[0.99]"
        >
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-red-950/60 border border-red-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                <BarChart3 className="w-6 h-6 text-red-500" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-slate-100 group-hover:text-red-400 transition-colors">
                    MARKET PAIRS
                  </h3>
                  <span className="text-[10px] font-black px-1.5 py-0.2 bg-[#2d0e1b] text-zinc-300 border border-zinc-700 rounded font-mono">
                    PRO
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Real exchange assets · Forex, Stocks, Indices
                </p>
              </div>
            </div>
            <TrendingUp className="w-5 h-5 text-zinc-500 group-hover:text-red-400 transition-colors" />
          </div>

          {/* Badges */}
          <div className="flex items-center gap-1.5 flex-wrap mt-3.5 text-[11px] font-medium font-mono text-zinc-300">
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">24 Assets</span>
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">Market Hours</span>
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">Stocks · Indices</span>
            <span className="px-2 py-1 bg-[#10040b] rounded-lg border border-[#2d0e1b]">1-15 min</span>
          </div>

          <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-[#2d0e1b] text-xs">
            <span className="flex items-center gap-1 text-emerald-400 font-semibold text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              Market Hours
            </span>
            <span className="text-zinc-400 font-semibold text-[11px] font-mono">
              Real Exchange
            </span>
          </div>
        </div>
      </div>

      {/* Footer Branding (Screenshot 6) */}
      <div className="text-center text-[11px] text-zinc-500 mt-6 leading-relaxed">
        <span className="text-emerald-400">● Markets Open</span> · Select a direction to begin analysis
        <br />
        Powered by Axiler Quantum Neural Engine
      </div>
    </div>
  );
};
