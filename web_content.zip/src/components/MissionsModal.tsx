/**
 * SPR - Sahil Powerful Run
 * Daily Missions & Tasks Modal
 * With Strict Offline 24-Hour Cooldown & Refresh Cycle
 */

import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, Home, Lock, Sparkles, Award } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';
import { saveManager } from '../game/storage/SaveManager';
import { useRewardCooldown } from '../hooks/useRewardCooldown';

interface MissionItem {
  id: string;
  title: string;
  desc: string;
  rewardType: 'coins' | 'diamonds';
  rewardAmount: number;
  current: number;
  total: number;
  completed: boolean;
  claimed: boolean;
}

interface Props {
  onClose: () => void;
  onClaimReward?: () => void;
}

const DEFAULT_MISSIONS: MissionItem[] = [
  {
    id: 'm1',
    title: 'Track Sprinter',
    desc: 'Run 500 meters down the coastal railway',
    rewardType: 'coins',
    rewardAmount: 500,
    current: 500,
    total: 500,
    completed: true,
    claimed: false,
  },
  {
    id: 'm2',
    title: 'Crown Collector',
    desc: 'Collect 150 golden crown coins on the tracks',
    rewardType: 'coins',
    rewardAmount: 750,
    current: 150,
    total: 150,
    completed: true,
    claimed: false,
  },
  {
    id: 'm3',
    title: 'Skater Boy',
    desc: 'Ride any 3D Skateboard for 25 seconds',
    rewardType: 'diamonds',
    rewardAmount: 3,
    current: 25,
    total: 25,
    completed: true,
    claimed: false,
  },
  {
    id: 'm4',
    title: 'Train Vaulting',
    desc: 'Jump onto 3 commuter train rooftops',
    rewardType: 'coins',
    rewardAmount: 1200,
    current: 2,
    total: 3,
    completed: false,
    claimed: false,
  },
  {
    id: 'm5',
    title: 'Score Emperor',
    desc: 'Achieve a score of 10,000 points or higher',
    rewardType: 'diamonds',
    rewardAmount: 5,
    current: 6450,
    total: 10000,
    completed: false,
    claimed: false,
  },
];

export const MissionsModal: React.FC<Props> = ({ onClose, onClaimReward }) => {
  const { isAvailable, countdown, claim } = useRewardCooldown('missions', 'MISSIONS');
  const [missions, setMissions] = useState<MissionItem[]>(() => {
    return DEFAULT_MISSIONS.map((m) => ({
      ...m,
      claimed: !isAvailable, // If on cooldown, missions for today are already claimed
    }));
  });

  const [claimedNotice, setClaimedNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!isAvailable) {
      setMissions((prev) => prev.map((m) => (m.completed ? { ...m, claimed: true } : m)));
    } else {
      // Unlocked!
      setMissions(DEFAULT_MISSIONS);
    }
  }, [isAvailable]);

  const handleClaim = (missionId: string) => {
    if (!isAvailable) return;
    const mission = missions.find((m) => m.id === missionId);
    if (!mission || !mission.completed || mission.claimed) return;

    soundManager.playPowerupSound();
    if (mission.rewardType === 'coins') {
      saveManager.addCoins(mission.rewardAmount);
      setClaimedNotice(`+₹${mission.rewardAmount.toLocaleString()} Coins Claimed!`);
    } else {
      saveManager.addDiamonds(mission.rewardAmount);
      setClaimedNotice(`+${mission.rewardAmount} Diamonds Claimed!`);
    }

    const updated = missions.map((m) => (m.id === missionId ? { ...m, claimed: true } : m));
    setMissions(updated);

    // If all completed missions are now claimed, trigger 24h refresh cooldown
    const remainingUnclaimed = updated.filter((m) => m.completed && !m.claimed);
    if (remainingUnclaimed.length === 0) {
      claim();
    }

    if (onClaimReward) onClaimReward();
  };

  const handleClaimAll = () => {
    if (!isAvailable) return;
    soundManager.playPowerupSound();

    let totalCoins = 0;
    let totalDiamonds = 0;

    missions.forEach((m) => {
      if (m.completed && !m.claimed) {
        if (m.rewardType === 'coins') totalCoins += m.rewardAmount;
        else totalDiamonds += m.rewardAmount;
      }
    });

    if (totalCoins > 0) saveManager.addCoins(totalCoins);
    if (totalDiamonds > 0) saveManager.addDiamonds(totalDiamonds);

    setMissions((prev) => prev.map((m) => (m.completed ? { ...m, claimed: true } : m)));
    setClaimedNotice(`Claimed All: +₹${totalCoins} 🪙, +${totalDiamonds} 💎!`);

    // Lock 24h cycle
    claim();

    if (onClaimReward) onClaimReward();
  };

  const completedCount = missions.filter((m) => m.completed).length;
  const hasUnclaimed = missions.some((m) => m.completed && !m.claimed);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-xl max-h-[90vh] bg-gradient-to-b from-slate-900 via-slate-950 to-black border-2 border-indigo-500/50 rounded-3xl p-5 sm:p-6 shadow-[0_0_50px_rgba(99,102,241,0.3)] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-indigo-500/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-500 flex items-center justify-center shadow-lg text-white font-black">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-wider text-white uppercase font-display">
                DAILY MISSIONS
              </h2>
              <p className="text-xs text-indigo-300">
                Completed: {completedCount}/{missions.length} Missions
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="missions-btn-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-3.5 h-3.5" />
              <span>HOME</span>
            </button>

            <button
              id="missions-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 24-Hour Countdown Banner */}
        {!isAvailable ? (
          <div className="mt-3 p-3 bg-slate-900/90 border-2 border-indigo-500/40 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-slate-300 font-bold uppercase">Daily Missions Locked</span>
            </div>
            <span className="font-mono font-black text-xs sm:text-sm text-amber-400">
              NEXT MISSIONS IN {countdown}
            </span>
          </div>
        ) : (
          <div className="mt-3 p-2.5 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl flex items-center justify-between">
            <span className="text-xs text-indigo-300 font-semibold">
              ⭐ Finish daily tasks and claim your rewards!
            </span>
            {hasUnclaimed && (
              <button
                onClick={handleClaimAll}
                className="px-3 py-1 bg-gradient-to-r from-amber-400 to-orange-400 hover:from-amber-300 hover:to-orange-300 text-slate-950 font-black text-xs uppercase rounded-lg shadow cursor-pointer font-display"
              >
                CLAIM ALL
              </button>
            )}
          </div>
        )}

        {/* Claim notification alert */}
        {claimedNotice && (
          <div className="mt-2 p-2 bg-emerald-950/80 border border-emerald-400/60 rounded-xl text-center text-xs text-emerald-300 font-bold animate-bounce">
            {claimedNotice}
          </div>
        )}

        {/* Missions List */}
        <div className="flex-1 overflow-y-auto mt-3 space-y-2.5 pr-1">
          {missions.map((m) => {
            const pct = Math.min(100, Math.round((m.current / m.total) * 100));

            return (
              <div
                key={m.id}
                className={`p-3 rounded-2xl border flex items-center justify-between gap-3 transition ${
                  m.claimed
                    ? 'bg-slate-950/40 border-slate-800 opacity-60'
                    : m.completed
                    ? 'bg-indigo-950/30 border-indigo-500/60 shadow-[0_0_15px_rgba(99,102,241,0.2)]'
                    : 'bg-slate-900/60 border-slate-800'
                }`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-white font-display">
                      {m.title}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        m.rewardType === 'coins'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                      }`}
                    >
                      +{m.rewardAmount} {m.rewardType === 'coins' ? '🪙' : '💎'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 truncate">{m.desc}</p>

                  {/* Progress Bar */}
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">
                      {m.current}/{m.total}
                    </span>
                  </div>
                </div>

                {/* Claim Button */}
                <div className="shrink-0">
                  {m.claimed ? (
                    <div className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-400 text-xs font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>CLAIMED</span>
                    </div>
                  ) : m.completed ? (
                    <button
                      onClick={() => handleClaim(m.id)}
                      disabled={!isAvailable}
                      className={`px-3.5 py-1.5 rounded-xl font-black text-xs uppercase transition shadow cursor-pointer font-display ${
                        isAvailable
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 active:scale-95 shadow-[0_0_12px_rgba(16,185,129,0.5)]'
                          : 'bg-slate-800 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      CLAIM
                    </button>
                  ) : (
                    <div className="px-3 py-1.5 rounded-xl bg-slate-800/60 border border-slate-700 text-slate-400 text-[11px] font-bold">
                      IN PROGRESS
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="mt-3 pt-2 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-400 font-medium">
            Missions refresh automatically once every 24 hours.
          </p>
        </div>
      </div>
    </div>
  );
};
