/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Trophy, CheckCircle2 } from 'lucide-react';
import { Mission } from '../types/game';

interface MissionsModalProps {
  missions: Mission[];
  onClaimReward: (missionId: string) => void;
  onClose: () => void;
}

export const MissionsModal: React.FC<MissionsModalProps> = ({
  missions,
  onClaimReward,
  onClose,
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-none flex items-center justify-center p-4 z-50 pointer-events-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-md w-full p-6 text-center shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            <h2 className="text-2xl font-black text-white italic tracking-wide">MISSIONS</h2>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mission Items List */}
        <div className="flex flex-col gap-3 my-4 overflow-y-auto pr-1">
          {missions.map((m) => {
            const percent = Math.min(100, Math.floor((m.progress / m.target) * 100));

            return (
              <div
                key={m.id}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 text-left transition-all ${
                  m.claimed
                    ? 'bg-slate-950/40 border-slate-800/80 opacity-60'
                    : m.completed
                    ? 'bg-slate-800/90 border-emerald-500/50 shadow-md'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-extrabold text-sm text-white">{m.title}</span>
                    <span className="text-[10px] text-amber-400 font-bold bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-500/30">
                      +{m.rewardCoins} $
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mb-2">{m.description}</p>

                  {/* Progress bar */}
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                    <span className="font-mono text-[11px] text-slate-400">
                      {m.progress}/{m.target}
                    </span>
                  </div>
                </div>

                {/* Claim or Status Button */}
                <div>
                  {m.claimed ? (
                    <div className="p-2 text-slate-500 flex items-center gap-1 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      <span>DONE</span>
                    </div>
                  ) : m.completed ? (
                    <button
                      onClick={() => onClaimReward(m.id)}
                      className="px-3.5 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-black text-xs rounded-xl shadow-lg border border-emerald-300/40 cursor-pointer active:scale-95 animate-pulse"
                    >
                      CLAIM
                    </button>
                  ) : (
                    <div className="text-[10px] font-bold uppercase text-slate-500 px-3 py-1 bg-slate-800/60 rounded-lg">
                      IN PROGRESS
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <p className="text-xs text-slate-400">
          Complete objectives to claim bonus coins for your vault!
        </p>
      </div>
    </div>
  );
};
