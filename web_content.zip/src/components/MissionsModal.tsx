import React from 'react';
import { Award, Flag, Play, ShieldAlert, Timer, Truck, X } from 'lucide-react';
import { MISSION_CATALOG } from '../game/missions';
import type { ActiveMissionState, MissionDefinition, MissionType, PlayerProgress } from '../game/types';

interface MissionsModalProps {
  open: boolean;
  progress: PlayerProgress;
  activeMission: ActiveMissionState | null;
  onClose: () => void;
  onStartMission: (def: MissionDefinition) => void;
  onCancelMission: () => void;
}

const TYPE_LABEL: Record<MissionType, string> = {
  entrega: 'Entrega de Pacote',
  tempo: 'Contra o Relógio',
  grau: 'Desafio de Empinar',
  racha: 'Corrida vs NPC',
  policia: 'Perseguição Policial',
};

function renderIcon(type: MissionType) {
  if (type === 'entrega') return <Truck className="w-4 h-4 text-emerald-400" />;
  if (type === 'tempo') return <Timer className="w-4 h-4 text-sky-400" />;
  if (type === 'grau') return <Award className="w-4 h-4 text-amber-400" />;
  if (type === 'racha') return <Flag className="w-4 h-4 text-orange-400" />;
  return <ShieldAlert className="w-4 h-4 text-rose-400" />;
}

export const MissionsModal: React.FC<MissionsModalProps> = ({
  open,
  progress,
  activeMission,
  onClose,
  onStartMission,
  onCancelMission,
}) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3">
      <div className="w-full max-w-3xl max-h-[86vh] flex flex-col bg-neutral-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
          <div>
            <h2 className="font-display text-lg font-bold text-white">Central de Missões · Moto Win</h2>
            <p className="text-xs text-neutral-400">
              Nível {progress.level} · {progress.xp} XP · R$ {progress.money.toLocaleString('pt-BR')}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
            aria-label="Fechar Missões"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {MISSION_CATALOG.map((m) => {
            const isCurrent = activeMission?.def.id === m.id && activeMission.status === 'active';
            const doneBefore = progress.completedMissions.includes(m.id);

            return (
              <div
                key={m.id}
                className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl border ${
                  isCurrent
                    ? 'border-amber-400 bg-amber-400/10'
                    : 'border-white/10 bg-neutral-800/65'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 text-xs text-neutral-400">
                    {renderIcon(m.type)}
                    <span>{TYPE_LABEL[m.type]}</span>
                    {doneBefore && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-emerald-400">Concluída</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-sm font-semibold text-white mt-0.5">{m.title}</h3>
                  <p className="text-xs text-neutral-300 mt-1 leading-relaxed">{m.description}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs font-mono-tabular">
                    <span className="text-emerald-400">+ R$ {m.rewardMoney}</span>
                    <span aria-hidden="true" className="text-neutral-600">·</span>
                    <span className="text-amber-300">+ {m.rewardXp} XP</span>
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  {isCurrent ? (
                    <button
                      type="button"
                      onClick={onCancelMission}
                      className="px-4 py-2 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white transition-colors cursor-pointer"
                    >
                      Cancelar
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        onStartMission(m);
                        onClose();
                      }}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-neutral-950 transition-colors cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      Iniciar
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
