import React, { useState } from 'react';
import { PoketSafeData, SavingsGoal } from '../types/budget';
import { Target, Plus, ArrowUpCircle, ArrowDownCircle, Trash2 } from 'lucide-react';

interface SavingsPageProps {
  data: PoketSafeData;
  onCreateGoal: (title: string, targetAmount: number) => void;
  onAddMoneyToGoal: (goalId: string, amount: number) => void;
  onWithdrawFromGoal: (goalId: string, amount: number) => void;
  onDeleteGoal: (goalId: string) => void;
}

export const SavingsPage: React.FC<SavingsPageProps> = ({
  data,
  onCreateGoal,
  onAddMoneyToGoal,
  onWithdrawFromGoal,
  onDeleteGoal,
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTarget, setGoalTarget] = useState('');

  // Quick adjust amount
  const [activeGoalId, setActiveGoalId] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState('50');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(goalTarget);
    if (!goalTitle.trim() || isNaN(amt) || amt <= 0) return;
    onCreateGoal(goalTitle.trim(), amt);
    setGoalTitle('');
    setGoalTarget('');
    setShowCreateModal(false);
  };

  const totalSavedAllGoals = data.savings.reduce((sum, g) => sum + g.currentAmount, 0);

  return (
    <div className="space-y-5 pb-6">
      {/* Header Banner */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg flex items-center justify-between">
        <div>
          <h2 className="text-sm font-semibold text-white">Savings Goals</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Total Saved: <strong className="font-mono text-emerald-400">RM {totalSavedAllGoals.toFixed(0)}</strong>
          </p>
        </div>
        <button
          onClick={() => setShowCreateModal(!showCreateModal)}
          className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Goal</span>
        </button>
      </div>

      {/* Create Modal Form */}
      {showCreateModal && (
        <form onSubmit={handleCreate} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between font-semibold text-white">
            <span>Create New Savings Target</span>
            <button type="button" onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-slate-400 mb-1">Goal Name</label>
              <input
                type="text"
                placeholder="e.g. Laptop Fund, Emergency Fund"
                value={goalTitle}
                onChange={e => setGoalTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                autoFocus
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Target Amount (RM)</label>
              <input
                type="number"
                step="1"
                placeholder="e.g. 2500"
                value={goalTarget}
                onChange={e => setGoalTarget(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
              />
            </div>
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg transition-colors mt-2"
          >
            Create Goal
          </button>
        </form>
      )}

      {/* Goals List */}
      <div className="space-y-3">
        {data.savings.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900 border border-dashed border-slate-800 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <Target className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="text-sm font-semibold text-white">No Savings Goals Yet</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1 mb-4 leading-relaxed">
              Give your extra money a target. Whether it's an emergency fund, a new laptop, or holiday travels, your saved money is protected from your daily Safe-To-Spend.
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs inline-flex items-center gap-1.5 transition-colors shadow-md"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Create Your First Goal</span>
            </button>
          </div>
        ) : (
          data.savings.map(goal => {
          const progress = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
          const remaining = Math.max(0, goal.targetAmount - goal.currentAmount);
          const isSelected = activeGoalId === goal.id;

          return (
            <div
              key={goal.id}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 shadow-md group hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                    <Target className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">{goal.title}</h3>
                    <p className="text-[11px] text-slate-400 font-mono">
                      RM {goal.currentAmount.toFixed(0)} of RM {goal.targetAmount.toFixed(0)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-emerald-400">{progress}%</span>
                  <button
                    onClick={() => onDeleteGoal(goal.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 transition-opacity"
                    title="Delete Goal"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-400 h-full rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>RM {remaining.toFixed(0)} remaining to reach goal</span>
                <button
                  onClick={() => setActiveGoalId(isSelected ? null : goal.id)}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
                >
                  {isSelected ? 'Close' : '+ Add / Withdraw'}
                </button>
              </div>

              {/* Quick Add / Withdraw Panel */}
              {isSelected && (
                <div className="pt-2 border-t border-slate-800 mt-2 space-y-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">Amount (RM):</span>
                    <input
                      type="number"
                      value={depositAmount}
                      onChange={e => setDepositAmount(e.target.value)}
                      className="w-24 px-2.5 py-1 bg-slate-800 border border-slate-700 rounded-md text-white font-mono"
                    />
                    <button
                      onClick={() => {
                        const amt = parseFloat(depositAmount) || 0;
                        if (amt > 0) onAddMoneyToGoal(goal.id, amt);
                      }}
                      className="px-3 py-1 bg-emerald-500 text-slate-950 font-bold rounded-md flex items-center gap-1"
                    >
                      <ArrowUpCircle className="w-3.5 h-3.5" />
                      <span>Add Money</span>
                    </button>
                    <button
                      onClick={() => {
                        const amt = parseFloat(depositAmount) || 0;
                        if (amt > 0) onWithdrawFromGoal(goal.id, amt);
                      }}
                      className="px-3 py-1 bg-slate-800 text-slate-300 hover:text-white font-medium rounded-md flex items-center gap-1"
                    >
                      <ArrowDownCircle className="w-3.5 h-3.5" />
                      <span>Withdraw</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })
      )}
      </div>
    </div>
  );
};
