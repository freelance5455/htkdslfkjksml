import React, { useId } from 'react';
import {
  AvatarAuraEffect,
  DiscipleExpression,
  DiscipleRank,
  MythicalFormType,
  SpiritRootType
} from '../../types/cultivation';

export const CUSTOM_HAIR_COLORS: { id: string; label: string; main: string; highlight: string; shadow: string }[] = [
  { id: '#16141a', label: 'Obsidian Ink', main: '#1a1822', highlight: '#3f3b52', shadow: '#09080d' },
  { id: '#cbd5e1', label: 'Silver Frost', main: '#d8e2ec', highlight: '#f8fafc', shadow: '#64748b' },
  { id: '#7f1d1d', label: 'Crimson Flame', main: '#881337', highlight: '#e11d48', shadow: '#4c0519' },
  { id: '#b45309', label: 'Imperial Gold', main: '#d97706', highlight: '#fde047', shadow: '#78350f' },
  { id: '#4c1d95', label: 'Void Violet', main: '#5b21b6', highlight: '#a78bfa', shadow: '#2e1065' },
  { id: '#0f766e', label: 'Celestial Jade', main: '#115e59', highlight: '#2dd4bf', shadow: '#042f2e' },
  { id: '#5c3a21', label: 'Chestnut Bronze', main: '#6b4226', highlight: '#a47148', shadow: '#3a2110' },
  { id: '#1e3a8a', label: 'Midnight Indigo', main: '#1d4ed8', highlight: '#60a5fa', shadow: '#0f172a' }
];

export const DISCIPLE_EXPRESSIONS: { id: DiscipleExpression; label: string; desc: string }[] = [
  { id: 'Serene', label: 'Serene', desc: 'Calm Dao poise' },
  { id: 'Smile', label: 'Smile', desc: 'Warm & joyful' },
  { id: 'Stoic', label: 'Stoic', desc: 'Resolute martial gaze' },
  { id: 'Fierce', label: 'Fierce', desc: 'Battle-ready glare' },
  { id: 'Smirk', label: 'Smirk', desc: 'Confident prodigy' }
];

interface CultivatorAvatarProps {
  gender: 'Male' | 'Female';
  rank: DiscipleRank;
  spiritRoot: SpiritRootType;
  realmIndex?: number;
  isBreakthroughReady?: boolean;
  robeColor?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showGenderBadge?: boolean;
  appearanceIndex?: number; // 0 to 11 (10 & 11 are Mythical Forms)
  skinTone?: 'Fair Jade' | 'Warm Honey' | 'Sun Bronze';
  clothingColor?: string;
  hairColor?: string;
  expression?: DiscipleExpression;
  auraEffect?: AvatarAuraEffect;
  mythicalForm?: MythicalFormType;
  soulProtected?: boolean;
  className?: string;
}

export const CultivatorAvatar: React.FC<CultivatorAvatarProps> = ({
  gender,
  rank,
  spiritRoot,
  realmIndex = 0,
  isBreakthroughReady = false,
  robeColor,
  size = 'md',
  showGenderBadge = true,
  appearanceIndex = 0,
  skinTone = 'Warm Honey',
  clothingColor,
  hairColor,
  expression = 'Serene',
  auraEffect = 'None',
  mythicalForm = 'None',
  soulProtected = false,
  className = ''
}) => {
  const rawUid = useId();
  const uid = rawUid.replace(/:/g, '_');

  const dim = size === 'sm' ? 46 : size === 'lg' ? 92 : size === 'xl' ? 116 : 64;

  const effectiveMythical: MythicalFormType =
    mythicalForm && mythicalForm !== 'None'
      ? mythicalForm
      : appearanceIndex === 10
      ? 'Thunder Sovereign'
      : appearanceIndex === 11
      ? 'Immortal Beast'
      : 'None';

  const isThunderSovereign = effectiveMythical === 'Thunder Sovereign';
  const isImmortalBeast = effectiveMythical === 'Immortal Beast';
  const isMythical = isThunderSovereign || isImmortalBeast;

  const isFemale = gender === 'Female';
  const styleIdx = Math.abs(appearanceIndex % 10);

  // Rank & Realm Tier Calculations for visual garment evolution
  const rankTier =
    rank === 'Sect Leader' ? 5
    : rank === 'Grand Elder' ? 4
    : rank === 'Elder' ? 3
    : rank === 'Direct' ? 2
    : rank === 'Inner' ? 1
    : 0;

  const isElderTier = rankTier >= 3;
  const isHighTier = rankTier >= 4 || realmIndex >= 17;

  const getAuraColor = (root: SpiritRootType) => {
    switch (root) {
      case 'Fire': return { stroke: '#ef4444', glow: 'rgba(239, 68, 68, 0.5)', bg: '#310f12', iris: '#b91c1c' };
      case 'Ice': return { stroke: '#38bdf8', glow: 'rgba(56, 189, 248, 0.5)', bg: '#082338', iris: '#0284c7' };
      case 'Thunder': return { stroke: '#eab308', glow: 'rgba(234, 179, 8, 0.55)', bg: '#261e07', iris: '#ca8a04' };
      case 'Wood': return { stroke: '#22c55e', glow: 'rgba(34, 197, 94, 0.5)', bg: '#0a2915', iris: '#15803d' };
      case 'Water': return { stroke: '#06b6d4', glow: 'rgba(6, 182, 212, 0.5)', bg: '#07222b', iris: '#0e7490' };
      case 'Metal': return { stroke: '#cbd5e1', glow: 'rgba(203, 213, 225, 0.5)', bg: '#1b2432', iris: '#475569' };
      case 'Earth': return { stroke: '#d97706', glow: 'rgba(217, 119, 6, 0.5)', bg: '#261506', iris: '#92400e' };
      case 'Wind': return { stroke: '#5eead4', glow: 'rgba(94, 234, 212, 0.5)', bg: '#092b28', iris: '#0f766e' };
      case 'Yin-Yang': return { stroke: '#c084fc', glow: 'rgba(192, 132, 252, 0.58)', bg: '#200f30', iris: '#7e22ce' };
      case 'Chaos': return { stroke: '#f43f5e', glow: 'rgba(244, 63, 94, 0.6)', bg: '#2c0b1b', iris: '#be123c' };
      case 'Heavenly': return { stroke: '#fde047', glow: 'rgba(253, 224, 71, 0.65)', bg: '#2b2207', iris: '#d97706' };
      case 'Immortal': return { stroke: '#34d399', glow: 'rgba(52, 211, 153, 0.7)', bg: '#092e21', iris: '#059669' };
      default: return { stroke: '#10b981', glow: 'rgba(16, 185, 129, 0.5)', bg: '#0a2318', iris: '#047857' };
    }
  };

  const aura = getAuraColor(spiritRoot);

  const getSkinPalette = (tone: 'Fair Jade' | 'Warm Honey' | 'Sun Bronze') => {
    switch (tone) {
      case 'Fair Jade':
        return {
          highlight: '#fff7f0',
          base: '#fde6d6',
          mid: '#f0c3a5',
          shadow: '#cf9578',
          blush: '#f5a89a',
          lipFemale: '#c96b67',
          lipMale: '#b57b65'
        };
      case 'Sun Bronze':
        return {
          highlight: '#e2a36e',
          base: '#c9844c',
          mid: '#a86532',
          shadow: '#7c431b',
          blush: '#b45a3c',
          lipFemale: '#994734',
          lipMale: '#7f482a'
        };
      case 'Warm Honey':
      default:
        return {
          highlight: '#ffe8cf',
          base: '#f6cba2',
          mid: '#daa071',
          shadow: '#b06d42',
          blush: '#e38f79',
          lipFemale: '#bd6056',
          lipMale: '#9e6248'
        };
    }
  };

  const skin = getSkinPalette(skinTone);

  const getClothingPalette = (cName?: string, r?: DiscipleRank) => {
    const key = cName || '';
    switch (key) {
      case 'Celestial Violet':
        return { top: '#7c3aed', mid: '#4c1d95', dark: '#2e1065', trim: '#f5d0fe', inner: '#f8fafc', sash: '#eab308' };
      case 'Astral Jade':
        return { top: '#14b8a6', mid: '#0f766e', dark: '#042f2e', trim: '#fde047', inner: '#ecfdf5', sash: '#34d399' };
      case 'Primordial Obsidian':
        return { top: '#334155', mid: '#0f172a', dark: '#020617', trim: '#fbbf24', inner: '#e2e8f0', sash: '#dc2626' };
      case 'Phoenix Scarlet':
        return { top: '#f43f5e', mid: '#be123c', dark: '#4c0519', trim: '#fde047', inner: '#fff1f2', sash: '#f59e0b' };
      case 'Heavenly White':
        return { top: '#ffffff', mid: '#e2e8f0', dark: '#94a3b8', trim: '#d4af37', inner: '#fefce8', sash: '#38bdf8' };
      case 'Gold':
        return { top: '#facc15', mid: '#ca8a04', dark: '#713f12', trim: '#fef9c3', inner: '#fffbeb', sash: '#991b1b' };
      case 'Crimson':
        return { top: '#ef4444', mid: '#b91c1c', dark: '#7f1d1d', trim: '#fde047', inner: '#fef2f2', sash: '#f59e0b' };
      case 'Pine':
        return { top: '#22c55e', mid: '#15803d', dark: '#14532d', trim: '#fde047', inner: '#f0fdf4', sash: '#e2b054' };
      case 'Ebon':
        return { top: '#3f3f46', mid: '#18181b', dark: '#09090b', trim: '#a1a1aa', inner: '#e4e4e7', sash: '#dc2626' };
      case 'Azure':
        return { top: '#38bdf8', mid: '#0369a1', dark: '#0c4a6e', trim: '#e0f2fe', inner: '#f8fafc', sash: '#eab308' };
      default: {
        if (robeColor && robeColor.startsWith('#')) {
          return { top: robeColor, mid: robeColor, dark: '#0f172a', trim: '#fce18b', inner: '#f8fafc', sash: '#e2b054' };
        }
        switch (r) {
          case 'Inner': return { top: '#3b82f6', mid: '#1d4ed8', dark: '#1e3a8a', trim: '#fde047', inner: '#f8fafc', sash: '#eab308' };
          case 'Direct': return { top: '#eab308', mid: '#a16207', dark: '#422006', trim: '#fef08a', inner: '#fffbeb', sash: '#dc2626' };
          case 'Elder': return { top: '#a855f7', mid: '#6b21a8', dark: '#3b0764', trim: '#fce18b', inner: '#faf5ff', sash: '#eab308' };
          case 'Grand Elder': return { top: '#e11d48', mid: '#9f1239', dark: '#4c0519', trim: '#fde047', inner: '#fff1f2', sash: '#facc15' };
          case 'Sect Leader': return { top: '#fbbf24', mid: '#b45309', dark: '#451a03', trim: '#ffffff', inner: '#fffbeb', sash: '#ef4444' };
          default: return { top: '#64748b', mid: '#334155', dark: '#1e293b', trim: '#e2e8f0', inner: '#f8fafc', sash: '#94a3b8' };
        }
      }
    }
  };

  const robe = getClothingPalette(clothingColor, rank);

  const resolveHairPalette = () => {
    if (hairColor) {
      const matched = CUSTOM_HAIR_COLORS.find(
        c => c.id.toLowerCase() === hairColor.toLowerCase() || c.main.toLowerCase() === hairColor.toLowerCase()
      );
      if (matched) return matched;
      return { id: hairColor, label: 'Custom', main: hairColor, highlight: '#ffffff', shadow: '#09090b' };
    }
    if (isThunderSovereign) return CUSTOM_HAIR_COLORS[4];
    if (isImmortalBeast) return CUSTOM_HAIR_COLORS[1];
    if (styleIdx === 8) return CUSTOM_HAIR_COLORS[1];
    if (styleIdx === 9) return CUSTOM_HAIR_COLORS[7];
    return CUSTOM_HAIR_COLORS[0];
  };

  const hair = resolveHairPalette();

  const getTierDetails = (idx: number) => {
    if (isMythical) {
      return {
        ringColor: isThunderSovereign ? '#c084fc' : '#fde047',
        glowSpread: '16px',
        auraColor: isThunderSovereign ? 'rgba(168, 85, 247, 0.72)' : 'rgba(250, 204, 21, 0.7)'
      };
    }
    if (idx >= 21 || rank === 'Sect Leader') return { ringColor: '#fce18b', glowSpread: '14px', auraColor: aura.glow };
    if (idx >= 17 || rank === 'Grand Elder') return { ringColor: '#c084fc', glowSpread: '10px', auraColor: aura.glow };
    if (idx >= 13 || rank === 'Elder') return { ringColor: '#eab308', glowSpread: '8px', auraColor: aura.glow };
    if (idx >= 9 || rank === 'Direct') return { ringColor: '#38bdf8', glowSpread: '6px', auraColor: aura.glow };
    return { ringColor: aura.stroke, glowSpread: '4px', auraColor: aura.glow };
  };

  const tier = getTierDetails(realmIndex);

  const activeAuraEffect: AvatarAuraEffect =
    auraEffect !== 'None'
      ? auraEffect
      : isThunderSovereign
      ? 'Golden Lightning'
      : isImmortalBeast
      ? 'Celestial Flame'
      : 'None';

  const eyeIris = isThunderSovereign ? '#a855f7' : isImmortalBeast ? '#f59e0b' : aura.iris;

  // Male short back-hair vs Female long flowing hair
  // For males, only style 1 (Long Scholar Mane) & style 8 (Grand Sage) have any hair past neck; others are clean cropped around the ears!
  const renderBackHair = () => {
    if (styleIdx === 7 && !isMythical) return null; // Zen Monk

    if (isFemale) {
      if (styleIdx === 6) {
        // Twin maiden buns + tapered shoulder locks
        return (
          <path
            d="M 38 35 C 35 50, 34 68, 37 82 C 45 78, 75 78, 83 82 C 86 68, 85 50, 82 35 C 78 19, 42 19, 38 35 Z"
            fill={`url(#hairGrad_${uid})`}
          />
        );
      }
      // Flowing long female coiffure
      return (
        <path
          d="M 36 36 C 31 54, 28 78, 31 98 C 43 91, 77 91, 89 98 C 92 78, 89 54, 84 36 C 80 18, 40 18, 36 36 Z"
          fill={`url(#hairGrad_${uid})`}
        />
      );
    }

    // MALE BACK HAIR (Crisp masculine neck-line; NO long behind-the-shoulder skirt of hair!)
    if (styleIdx === 1 || styleIdx === 8 || isMythical) {
      // Martial warrior high tail / sage hair — narrow tapered tail behind shoulders, keeping jawline & neck clearly visible
      return (
        <g>
          <path
            d="M 41 34 C 39 42, 39 50, 42 54 L 78 54 C 81 50, 81 42, 79 34 C 76 19, 44 19, 41 34 Z"
            fill={`url(#hairGrad_${uid})`}
          />
          <path
            d="M 50 54 C 46 68, 43 82, 46 92 L 74 92 C 77 82, 74 68, 70 54 Z"
            fill={`url(#hairGrad_${uid})`}
            opacity="0.92"
          />
        </g>
      );
    }

    // Short cropped male back-of-head dome (stops cleanly at mid-ear y=48, leaving jaw & neck 100% open & masculine)
    return (
      <path
        d="M 40.5 36 C 39.5 41, 40 46, 42.5 48 L 77.5 48 C 80 46, 80.5 41, 79.5 36 C 77 20, 43 20, 40.5 36 Z"
        fill={`url(#hairGrad_${uid})`}
      />
    );
  };

  // Realistic Facial Expressions (Mouth + Eyebrow inflection)
  const renderMouth = () => {
    if (isFemale) {
      switch (expression) {
        case 'Smile':
          return (
            <g>
              <path d="M 55.2 52.6 Q 60 55.6 64.8 52.6 Q 60 53.7 55.2 52.6 Z" fill={skin.lipFemale} />
              <path d="M 55.5 52.7 Q 60 56.2 64.5 52.7" fill="none" stroke={skin.shadow} strokeWidth="0.7" strokeLinecap="round" />
            </g>
          );
        case 'Fierce':
          return (
            <g>
              <path d="M 56.2 53.6 Q 60 52.0 63.8 53.6" fill="none" stroke={skin.lipFemale} strokeWidth="1.4" strokeLinecap="round" />
              <path d="M 57.5 54.4 Q 60 54.8 62.5 54.4" fill="none" stroke={skin.shadow} strokeWidth="0.7" />
            </g>
          );
        case 'Stoic':
          return (
            <g>
              <path d="M 56.2 53.1 L 63.8 53.1" fill="none" stroke={skin.lipFemale} strokeWidth="1.35" strokeLinecap="round" />
              <path d="M 57.8 54.1 Q 60 54.8 62.2 54.1" fill="none" stroke={skin.shadow} strokeWidth="0.65" />
            </g>
          );
        case 'Smirk':
          return (
            <g>
              <path d="M 55.8 53.3 Q 60.5 53.8 64.6 51.9" fill="none" stroke={skin.lipFemale} strokeWidth="1.45" strokeLinecap="round" />
              <path d="M 57.5 54.3 Q 60.8 54.8 63.2 53.5" fill="none" stroke={skin.shadow} strokeWidth="0.6" />
            </g>
          );
        case 'Serene':
        default:
          return (
            <g>
              <path d="M 55.8 52.9 Q 58.2 52.1 60 52.8 Q 61.8 52.1 64.2 52.9 Q 60 54.2 55.8 52.9 Z" fill={skin.lipFemale} opacity="0.9" />
              <path d="M 57 53.8 Q 60 55.1 63 53.8" fill="none" stroke={skin.shadow} strokeWidth="0.75" strokeLinecap="round" />
            </g>
          );
      }
    }

    // MALE MOUTH: Natural sculpted masculine lips (zero lipstick, crisp character lines)
    switch (expression) {
      case 'Smile':
        return (
          <g>
            <path d="M 54.5 52.8 Q 60 56.2 65.5 52.8" fill="none" stroke={skin.lipMale} strokeWidth="1.35" strokeLinecap="round" />
            <path d="M 58 55.0 Q 60 55.8 62 55.0" fill="none" stroke={skin.shadow} strokeWidth="0.65" strokeLinecap="round" />
          </g>
        );
      case 'Fierce':
        return (
          <g>
            <path d="M 55.2 53.8 Q 60 52.1 64.8 53.8" fill="none" stroke="#3a231c" strokeWidth="1.4" strokeLinecap="round" />
            <path d="M 57 54.8 L 63 54.8" fill="none" stroke={skin.shadow} strokeWidth="0.75" strokeLinecap="round" />
          </g>
        );
      case 'Smirk':
        return (
          <g>
            <path d="M 55.2 53.6 Q 60.5 54.2 65.2 51.8" fill="none" stroke={skin.lipMale} strokeWidth="1.4" strokeLinecap="round" />
            <path d="M 58.2 55.0 Q 61 55.2 63 54.3" fill="none" stroke={skin.shadow} strokeWidth="0.6" />
          </g>
        );
      case 'Stoic':
        return (
          <g>
            <path d="M 55.2 53.2 L 64.8 53.2" fill="none" stroke={skin.lipMale} strokeWidth="1.35" strokeLinecap="round" />
            <path d="M 58.2 54.5 L 61.8 54.5" fill="none" stroke={skin.shadow} strokeWidth="0.7" strokeLinecap="round" />
          </g>
        );
      case 'Serene':
      default:
        return (
          <g>
            <path d="M 55.5 53.1 Q 60 54.1 64.5 53.1" fill="none" stroke={skin.lipMale} strokeWidth="1.25" strokeLinecap="round" />
            <path d="M 58.2 54.4 Q 60 55.0 61.8 54.4" fill="none" stroke={skin.shadow} strokeWidth="0.65" strokeLinecap="round" />
          </g>
        );
    }
  };

  // Eyebrow Geometry tuned by Gender & Expression
  const getBrowPaths = () => {
    if (expression === 'Fierce') {
      return {
        left: 'M 45 36.2 L 55.5 38.6',
        right: 'M 75 36.2 L 64.5 38.6'
      };
    }
    if (expression === 'Smirk') {
      return {
        left: isFemale ? 'M 45.8 37.5 Q 50.5 35.6 55.2 37.3' : 'M 45 37.2 L 55.5 37.0',
        right: isFemale ? 'M 74.2 36.5 Q 69.5 34.4 64.8 37.0' : 'M 74.8 35.6 Q 69.5 34.2 64.5 37.0'
      };
    }
    if (expression === 'Smile') {
      return {
        left: isFemale ? 'M 45.8 37.0 Q 50.5 34.6 55.2 36.8' : 'M 45.2 36.6 Q 50.5 35.2 55.6 36.8',
        right: isFemale ? 'M 74.2 37.0 Q 69.5 34.6 64.8 36.8' : 'M 74.8 36.6 Q 69.5 35.2 64.4 36.8'
      };
    }
    if (isFemale) {
      return {
        left: 'M 46 37.4 Q 50.5 35.3 55 37.1',
        right: 'M 74 37.4 Q 69.5 35.3 65 37.1'
      };
    }
    // Sharp, thicker horizontal sword-brows for Male cultivators
    return {
      left: 'M 44.8 36.8 L 55.6 37.4',
      right: 'M 75.2 36.8 L 64.4 37.4'
    };
  };

  const brows = getBrowPaths();

  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-2xl overflow-hidden shadow-lg select-none transition-transform duration-300 ${
        isBreakthroughReady ? 'ring-2 ring-[#fce18b]' : ''
      } ${className}`}
      style={{
        width: dim,
        height: dim,
        background: isThunderSovereign
          ? 'radial-gradient(circle at 50% 35%, #2e1065 0%, #09051a 100%)'
          : isImmortalBeast
          ? 'radial-gradient(circle at 50% 35%, #063d2d 0%, #041712 100%)'
          : `radial-gradient(circle at 50% 35%, ${aura.bg} 0%, #061611 100%)`,
        border: `2px solid ${tier.ringColor}`,
        boxShadow: `0 0 ${tier.glowSpread} ${tier.auraColor}`
      }}
    >
      <svg viewBox="0 0 120 120" width={dim} height={dim} className="w-full h-full">
        <defs>
          <radialGradient id={`bgAura_${uid}`} cx="50%" cy="42%" r="54%">
            <stop offset="0%" stopColor={isThunderSovereign ? '#a855f7' : isImmortalBeast ? '#facc15' : aura.stroke} stopOpacity="0.48" />
            <stop offset="65%" stopColor={aura.stroke} stopOpacity="0.14" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>

          <radialGradient id={`skinFace_${uid}`} cx="44%" cy="38%" r="62%">
            <stop offset="0%" stopColor={skin.highlight} />
            <stop offset="55%" stopColor={skin.base} />
            <stop offset="88%" stopColor={skin.mid} />
            <stop offset="100%" stopColor={skin.shadow} />
          </radialGradient>

          <linearGradient id={`skinNeck_${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={skin.shadow} />
            <stop offset="45%" stopColor={skin.mid} />
            <stop offset="100%" stopColor={skin.base} />
          </linearGradient>

          <linearGradient id={`robeGrad_${uid}`} x1="15%" y1="0%" x2="85%" y2="100%">
            <stop offset="0%" stopColor={robe.top} />
            <stop offset="50%" stopColor={robe.mid} />
            <stop offset="100%" stopColor={robe.dark} />
          </linearGradient>

          <linearGradient id={`hairGrad_${uid}`} x1="20%" y1="0%" x2="80%" y2="100%">
            <stop offset="0%" stopColor={hair.highlight} />
            <stop offset="35%" stopColor={hair.main} />
            <stop offset="100%" stopColor={hair.shadow} />
          </linearGradient>

          <linearGradient id={`goldMetal_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="50%" stopColor="#eab308" />
            <stop offset="100%" stopColor="#92400e" />
          </linearGradient>
        </defs>

        {/* 1. Ambient Aura & Rank/Realm Tier Rings */}
        <circle cx="60" cy="54" r="56" fill={`url(#bgAura_${uid})`} />

        {isThunderSovereign && (
          <g className="animate-spin-slow" style={{ transformOrigin: '60px 46px' }}>
            <circle cx="60" cy="46" r="44" fill="none" stroke="#c084fc" strokeWidth="1.4" strokeDasharray="6 4" opacity="0.85" />
            <circle cx="60" cy="46" r="39" fill="none" stroke="#fde047" strokeWidth="1" strokeDasharray="2 5" opacity="0.8" />
            <path d="M 60 2 L 62.5 8 L 57.5 8 Z" fill="#fde047" />
            <path d="M 60 90 L 62.5 84 L 57.5 84 Z" fill="#fde047" />
            <path d="M 16 46 L 22 48.5 L 22 43.5 Z" fill="#c084fc" />
            <path d="M 104 46 L 98 48.5 L 98 43.5 Z" fill="#c084fc" />
          </g>
        )}

        {isImmortalBeast && (
          <g className="animate-spin-slow" style={{ transformOrigin: '60px 46px' }}>
            <circle cx="60" cy="46" r="43" fill="none" stroke="#34d399" strokeWidth="1.5" strokeDasharray="8 3" opacity="0.8" />
            <circle cx="60" cy="46" r="38" fill="none" stroke="#f59e0b" strokeWidth="1.1" strokeDasharray="3 3" opacity="0.75" />
          </g>
        )}

        {/* High Tier Dharma Halo (Elder / Golden Core+) */}
        {!isMythical && (realmIndex >= 13 || rankTier >= 3) && (
          <circle
            cx="60"
            cy="48"
            r={isHighTier ? 43 : 38}
            fill="none"
            stroke={tier.ringColor}
            strokeWidth={isHighTier ? '1.6' : '1.1'}
            strokeDasharray={isHighTier ? '5 3' : '8 5'}
            opacity="0.72"
          />
        )}

        {soulProtected && (
          <circle
            cx="60"
            cy="52"
            r="48"
            fill="none"
            stroke="#fbbf24"
            strokeWidth="1.2"
            strokeDasharray="3 5"
            opacity="0.7"
          />
        )}

        {/* 2. Mythical Shoulder Ribbons / Plumes */}
        {isThunderSovereign && (
          <g opacity="0.9">
            <path d="M 28 74 C 12 62, 10 42, 22 30 C 16 46, 20 62, 34 72 Z" fill="none" stroke="#c084fc" strokeWidth="2.4" strokeLinecap="round" />
            <path d="M 92 74 C 108 62, 110 42, 98 30 C 104 46, 100 62, 86 72 Z" fill="none" stroke="#fde047" strokeWidth="2.4" strokeLinecap="round" />
          </g>
        )}

        {isImmortalBeast && (
          <g opacity="0.9">
            <path d="M 32 78 Q 14 58 18 32 Q 24 52 38 72 Z" fill="#f59e0b" opacity="0.6" />
            <path d="M 28 84 Q 10 68 12 44 Q 20 62 36 78 Z" fill="#ef4444" opacity="0.45" />
            <path d="M 88 78 Q 106 58 102 32 Q 96 52 82 72 Z" fill="#f59e0b" opacity="0.6" />
            <path d="M 92 84 Q 110 68 108 44 Q 100 62 84 78 Z" fill="#ef4444" opacity="0.45" />
          </g>
        )}

        {/* 3. Back Hair Layer (Gender-Appropriate) */}
        {renderBackHair()}

        {/* 4. Anatomically Tapered Shoulders & Tier-Based Robe Evolution */}
        <g>
          {/* Males get slightly broader athletic shoulders */}
          <path
            d={
              isFemale
                ? 'M 19 122 C 21 91, 33 77, 51 71 L 60 76 L 69 71 C 87 77, 99 91, 101 122 Z'
                : 'M 13 122 C 15 88, 29 73, 49 69 L 60 75 L 71 69 C 91 73, 105 88, 107 122 Z'
            }
            fill={`url(#robeGrad_${uid})`}
            stroke="#061611"
            strokeWidth="1.4"
          />

          {/* Elder+ Tier Shoulder Capelet */}
          {isElderTier && (
            <path
              d="M 22 86 Q 38 71 60 77 Q 82 71 98 86 L 94 94 Q 78 82 60 88 Q 42 82 26 94 Z"
              fill={robe.dark}
              stroke={robe.trim}
              strokeWidth="1.1"
              opacity="0.92"
            />
          )}

          {/* Subtle Shoulder Drapery Folds */}
          <path d="M 32 82 Q 37 100 35 121" fill="none" stroke={robe.dark} strokeWidth="1.6" opacity="0.65" />
          <path d="M 88 82 Q 83 100 85 121" fill="none" stroke={robe.dark} strokeWidth="1.6" opacity="0.65" />

          {/* Crisp Inner Silk Robe V-Neck */}
          <path d="M 49 71 L 60 88 L 71 71 L 66 70 L 60 81 L 54 70 Z" fill={robe.inner} />

          {/* Traditional Left-over-Right Y-Collar Overlapping Lapels */}
          <path
            d="M 46 72 L 64 98 L 69 94 L 51 70 Z"
            fill={robe.mid}
            stroke={rankTier >= 1 ? robe.trim : robe.inner}
            strokeWidth={rankTier >= 2 ? '1.8' : '1.2'}
          />
          <path
            d="M 74 72 L 58 95"
            fill="none"
            stroke={rankTier >= 1 ? robe.trim : robe.inner}
            strokeWidth={rankTier >= 2 ? '2.5' : '1.8'}
            strokeLinecap="round"
          />

          {/* Tier 2+ (Direct+) Chest Medallion Embroidery */}
          {rankTier >= 2 && (
            <circle cx="60" cy="95" r="2.6" fill={`url(#goldMetal_${uid})`} stroke="#061611" strokeWidth="0.7" />
          )}

          {/* Waist Sash & Tier Seal */}
          <path d="M 35 105 Q 60 110 85 105 L 87 113 Q 60 118 33 113 Z" fill={robe.sash} opacity="0.92" />
          <circle cx="60" cy="111" r={rankTier >= 3 ? 4.2 : 3.4} fill={`url(#goldMetal_${uid})`} stroke="#061611" strokeWidth="0.9" />
          <circle cx="60" cy="111" r="1.6" fill={aura.stroke} />

          {/* High-Rank / Mythical Shoulder Pauldrons */}
          {(rankTier >= 4 || isMythical) && (
            <g>
              <path
                d="M 24 84 Q 35 69 48 72 Q 39 80 28 88 Z"
                fill={`url(#goldMetal_${uid})`}
                stroke="#061611"
                strokeWidth="0.85"
              />
              <path
                d="M 96 84 Q 85 69 72 72 Q 81 80 92 88 Z"
                fill={`url(#goldMetal_${uid})`}
                stroke="#061611"
                strokeWidth="0.85"
              />
            </g>
          )}
        </g>

        {/* 5. Shaded Neck & Anatomically Sculpted Collarbone */}
        <path
          d={
            isFemale
              ? 'M 53.5 55 L 52 72 Q 60 76 68 72 L 66.5 55 Z'
              : 'M 50.5 54 L 49 71 Q 60 76 71 71 L 69.5 54 Z'
          }
          fill={`url(#skinNeck_${uid})`}
        />
        <path
          d={isFemale ? 'M 53.5 56 Q 60 63.5 66.5 56 L 66.5 60.5 Q 60 65.5 53.5 60.5 Z' : 'M 50.5 55 Q 60 63.5 69.5 55 L 69.5 60 Q 60 65.5 50.5 60 Z'}
          fill={skin.shadow}
          opacity="0.65"
        />
        {/* Subtle Sternocleidomastoid & Collarbone Hollows */}
        <path d="M 55.5 63 L 58.8 71.5 M 64.5 63 L 61.2 71.5" stroke={skin.shadow} strokeWidth="0.6" opacity="0.38" strokeLinecap="round" />
        <path d="M 50 72 Q 55 74.5 59.2 73.5 M 70 72 Q 65 74.5 60.8 73.5" fill="none" stroke={skin.shadow} strokeWidth="0.7" opacity="0.45" strokeLinecap="round" />

        {/* 6. Detailed Ears with Inner Helix Fold */}
        <g>
          <path d="M 42 40.5 C 38.8 40.5, 38.8 49, 42.5 50.5 Z" fill={skin.mid} stroke={skin.shadow} strokeWidth="0.7" />
          <path d="M 41.3 42.5 Q 40 45 41.6 48" fill="none" stroke={skin.shadow} strokeWidth="0.55" opacity="0.55" />
          <path d="M 78 40.5 C 81.2 40.5, 81.2 49, 77.5 50.5 Z" fill={skin.mid} stroke={skin.shadow} strokeWidth="0.7" />
          <path d="M 78.7 42.5 Q 80 45 78.4 48" fill="none" stroke={skin.shadow} strokeWidth="0.55" opacity="0.55" />
        </g>

        {/* 7. Sculpted Human Face Contour (Distinct Male Square Jaw vs Female Soft Tapered Jaw) */}
        <path
          d={
            isFemale
              ? 'M 43 38 C 43 23, 77 23, 77 38 C 77 46.5, 73.5 53.5, 67 58 Q 60 61.5 53 58 C 46.5 53.5, 43 46.5, 43 38 Z'
              : 'M 41.2 37 C 41.2 22, 78.8 22, 78.8 37 L 78.2 47.5 L 72.5 56.5 L 64.5 60.8 L 55.5 60.8 L 47.5 56.5 L 41.8 47.5 Z'
          }
          fill={`url(#skinFace_${uid})`}
          stroke={skin.shadow}
          strokeWidth="0.75"
        />

        {/* Subtle Cheek Contour & Skin Highlight */}
        <ellipse cx="60" cy="34" rx="8" ry="3.2" fill={skin.highlight} opacity="0.22" />
        {isFemale ? (
          <>
            <ellipse cx="48.5" cy="48.2" rx="3.8" ry="1.8" fill={skin.blush} opacity="0.34" />
            <ellipse cx="71.5" cy="48.2" rx="3.8" ry="1.8" fill={skin.blush} opacity="0.34" />
            <ellipse cx="49" cy="46.2" rx="2.4" ry="0.9" fill={skin.highlight} opacity="0.24" />
            <ellipse cx="71" cy="46.2" rx="2.4" ry="0.9" fill={skin.highlight} opacity="0.24" />
          </>
        ) : (
          <>
            <path d="M 43.8 45.8 L 47.6 52.2" stroke={skin.shadow} strokeWidth="0.85" opacity="0.35" strokeLinecap="round" />
            <path d="M 76.2 45.8 L 72.4 52.2" stroke={skin.shadow} strokeWidth="0.85" opacity="0.35" strokeLinecap="round" />
            <path d="M 45.5 44.5 Q 48 45.5 50 45" stroke={skin.highlight} strokeWidth="0.7" opacity="0.28" strokeLinecap="round" />
            <path d="M 74.5 44.5 Q 72 45.5 70 45" stroke={skin.highlight} strokeWidth="0.7" opacity="0.28" strokeLinecap="round" />
            <path d="M 59 58.6 L 61 58.6" stroke={skin.shadow} strokeWidth="0.75" opacity="0.45" strokeLinecap="round" />
          </>
        )}

        {/* 8. Realistic Eyes, Brows, Nose & Mouth Expression */}
        <g>
          {/* Eyebrows */}
          <path
            d={brows.left}
            fill="none"
            stroke={hair.shadow}
            strokeWidth={isFemale ? '1.3' : '1.9'}
            strokeLinecap="round"
          />
          <path
            d={brows.right}
            fill="none"
            stroke={hair.shadow}
            strokeWidth={isFemale ? '1.3' : '1.9'}
            strokeLinecap="round"
          />

          {/* Left Eye (Eyelid Crease, Limbal Iris Ring, Pupil, Dual Catchlight) */}
          <path
            d={isFemale ? 'M 46.4 39.6 Q 50.8 37.6 54.8 39.8' : 'M 45.8 39.8 Q 50.8 38.4 55.2 40.0'}
            fill="none"
            stroke={skin.shadow}
            strokeWidth="0.6"
            opacity="0.65"
            strokeLinecap="round"
          />
          <path
            d={isFemale ? 'M 46.2 42 Q 50.8 39.0 55 42.2 Q 50.8 44.8 46.2 42 Z' : 'M 45.6 41.8 Q 50.8 39.6 55.4 42.0 Q 50.8 43.9 45.6 41.8 Z'}
            fill="#fcfaf5"
          />
          <circle cx="50.8" cy="41.8" r={isFemale ? '2.25' : '2.0'} fill={eyeIris} stroke="#0f172a" strokeWidth="0.35" />
          <circle cx="50.8" cy="41.8" r="1.05" fill="#0f172a" />
          <circle cx="51.5" cy="41.0" r="0.65" fill="#ffffff" />
          <circle cx="49.9" cy="42.5" r="0.3" fill="#ffffff" opacity="0.7" />
          <path
            d={isFemale ? 'M 45.5 42.1 Q 50.8 38.6 55.5 42.3' : 'M 45.2 41.8 Q 50.8 39.2 55.8 42.0'}
            fill="none"
            stroke="#1e1b18"
            strokeWidth={isFemale ? '1.35' : '1.25'}
            strokeLinecap="round"
          />
          <path d="M 47.4 44.1 Q 50.8 44.7 54.0 43.9" fill="none" stroke={skin.shadow} strokeWidth="0.45" opacity="0.55" />

          {/* Right Eye */}
          <path
            d={isFemale ? 'M 73.6 39.6 Q 69.2 37.6 65.2 39.8' : 'M 74.2 39.8 Q 69.2 38.4 64.8 40.0'}
            fill="none"
            stroke={skin.shadow}
            strokeWidth="0.6"
            opacity="0.65"
            strokeLinecap="round"
          />
          <path
            d={isFemale ? 'M 73.8 42 Q 69.2 39.0 65 42.2 Q 69.2 44.8 73.8 42 Z' : 'M 74.4 41.8 Q 69.2 39.6 64.6 42.0 Q 69.2 43.9 74.4 41.8 Z'}
            fill="#fcfaf5"
          />
          <circle cx="69.2" cy="41.8" r={isFemale ? '2.25' : '2.0'} fill={eyeIris} stroke="#0f172a" strokeWidth="0.35" />
          <circle cx="69.2" cy="41.8" r="1.05" fill="#0f172a" />
          <circle cx="69.9" cy="41.0" r="0.65" fill="#ffffff" />
          <circle cx="68.3" cy="42.5" r="0.3" fill="#ffffff" opacity="0.7" />
          <path
            d={isFemale ? 'M 74.5 42.1 Q 69.2 38.6 64.5 42.3' : 'M 74.8 41.8 Q 69.2 39.2 64.2 42.0'}
            fill="none"
            stroke="#1e1b18"
            strokeWidth={isFemale ? '1.35' : '1.25'}
            strokeLinecap="round"
          />
          <path d="M 72.6 44.1 Q 69.2 44.7 66.0 43.9" fill="none" stroke={skin.shadow} strokeWidth="0.45" opacity="0.55" />

          {/* Sculpted Nose Bridge Highlight, Nostril Base & Philtrum Shadow */}
          <path d="M 60 39.8 L 59.6 47.0" fill="none" stroke={skin.highlight} strokeWidth="0.75" opacity="0.35" strokeLinecap="round" />
          <path d="M 60.2 39.8 L 59.3 47.4 Q 60 48.8 61.5 47.8" fill="none" stroke={skin.shadow} strokeWidth="1.0" strokeLinecap="round" opacity="0.82" />
          <path d="M 58.2 48.2 Q 60 49.5 61.8 48.2" fill="none" stroke={skin.shadow} strokeWidth="0.8" opacity="0.62" strokeLinecap="round" />
          <path d="M 60 49.8 L 60 51.4" stroke={skin.shadow} strokeWidth="0.55" opacity="0.35" strokeLinecap="round" />

          {/* Realistic Expression Mouth */}
          {renderMouth()}

          {/* Dignified Mustache / Goatee for Senior Male Elders or Style #8 */}
          {!isFemale && (isElderTier || styleIdx === 8) && (
            <g opacity="0.88">
              <path d="M 54 51.8 Q 57 50.8 59.5 52.2 M 66 51.8 Q 63 50.8 60.5 52.2" fill="none" stroke={hair.main} strokeWidth="1.25" strokeLinecap="round" />
              <path d="M 58.2 57.5 Q 60 65 61.8 57.5 Z" fill={`url(#hairGrad_${uid})`} />
            </g>
          )}

          {/* Forehead Mark / Mythical Third Eye */}
          {isThunderSovereign ? (
            <g>
              <path d="M 60 28.5 L 62 32.5 L 60 36 L 58 32.5 Z" fill="#c084fc" stroke="#fde047" strokeWidth="0.7" />
              <circle cx="60" cy="32.3" r="1.1" fill="#ffffff" />
            </g>
          ) : isImmortalBeast ? (
            <path d="M 60 29 C 61.5 31.5, 62 34, 60 35.5 C 58 34, 58.5 31.5, 60 29 Z" fill="#f59e0b" stroke="#fde047" strokeWidth="0.5" />
          ) : (
            <path d="M 60 30 L 61.2 32.4 L 60 34.5 L 58.8 32.4 Z" fill={isBreakthroughReady ? '#fde047' : aura.stroke} opacity="0.85" />
          )}
        </g>

        {/* 9. Front Hair & Side Framing Locks (Distinct Male vs Female Cuts) */}
        {styleIdx === 7 && !isMythical ? (
          <g>
            {/* Zen Monk Ordination Marks */}
            <circle cx="60" cy="27" r="0.95" fill="#78350f" />
            <circle cx="56" cy="28.5" r="0.95" fill="#78350f" />
            <circle cx="64" cy="28.5" r="0.95" fill="#78350f" />
            <circle cx="53.5" cy="31" r="0.95" fill="#78350f" />
            <circle cx="66.5" cy="31" r="0.95" fill="#78350f" />
          </g>
        ) : isFemale ? (
          <g>
            <path
              d="M 41.5 39 C 40.5 23, 52 20, 60 20 C 68 20, 79.5 23, 78.5 39 C 77 31, 69 27.5, 60 27 C 51 27.5, 43 31, 41.5 39 Z"
              fill={`url(#hairGrad_${uid})`}
            />
            <path d="M 42 36 C 40 46, 39 58, 42.5 67 C 44.5 58, 44 46, 44.5 36 Z" fill={`url(#hairGrad_${uid})`} />
            <path d="M 78 36 C 80 46, 81 58, 77.5 67 C 75.5 58, 76 46, 75.5 36 Z" fill={`url(#hairGrad_${uid})`} />
            <path d="M 46 29 Q 52 34 55 29 M 65 29 Q 68 34 74 29" fill="none" stroke={hair.main} strokeWidth="2.1" strokeLinecap="round" />
            {/* Realistic silky hairline highlights */}
            <path d="M 48 23.5 Q 54 22.2 59 24.5 M 61 24.5 Q 66 22.2 72 23.5" fill="none" stroke={hair.highlight} strokeWidth="0.9" opacity="0.45" strokeLinecap="round" />
          </g>
        ) : (
          /* MALE FRONT HAIR: Clean swept forehead, sharp sideburns ending at ear, zero long cheek-curtain locks unless style 1 */
          <g>
            <path
              d={
                styleIdx === 2
                  ? 'M 40.5 38 C 39.5 22, 50 18, 60 18 C 70 18, 80.5 22, 79.5 38 L 77 32 L 71 27 L 64 31 L 60 25 L 55 31 L 49 27 L 43 32 Z' // Swept Warrior Spikes
                  : styleIdx === 5
                  ? 'M 40.8 39 C 40 22, 50 19, 60 19 C 70 19, 80 22, 79.2 39 C 77 30, 67 26, 55 27 C 47 28, 42 32, 40.8 39 Z' // Wolf Bangs
                  : 'M 40.8 38 C 40.2 22, 51 19, 60 19 C 69 19, 79.8 22, 79.2 38 C 77.2 29, 69 25.8, 60 25.5 C 51 25.8, 42.8 29, 40.8 38 Z' // Crisp Sleek Back
              }
              fill={`url(#hairGrad_${uid})`}
            />
            {/* Crisp Male Sideburns tapering cleanly at ear level */}
            <path d="M 41 35 L 41 44.5 L 43.2 43 L 43.2 34 Z" fill={`url(#hairGrad_${uid})`} />
            <path d="M 79 35 L 79 44.5 L 76.8 43 L 76.8 34 Z" fill={`url(#hairGrad_${uid})`} />
            <path d="M 48 22.5 Q 60 20.5 72 22.5" fill="none" stroke={hair.highlight} strokeWidth="0.95" opacity="0.4" strokeLinecap="round" />
            {/* Optional loose rogue strand for style 1/5 */}
            {(styleIdx === 1 || styleIdx === 5) && (
              <path d="M 48 26 Q 53 33 56 29" fill="none" stroke={hair.main} strokeWidth="1.9" strokeLinecap="round" />
            )}
          </g>
        )}

        {/* Style-Specific Crowns, Topknots & Hairstyles (0..9 + Mythical) */}
        {!isMythical && styleIdx === 0 && (
          <g>
            {/* Daoist Topknot + Jade Guan Crown */}
            <ellipse cx="60" cy="17.5" rx="6.8" ry="5" fill={`url(#hairGrad_${uid})`} />
            <rect x="53.5" y="17" width="13" height="3.8" rx="1.2" fill={`url(#goldMetal_${uid})`} />
            <line x1="48" y1="18.8" x2="72" y2="18.8" stroke="#fde047" strokeWidth="1.6" strokeLinecap="round" />
            <circle cx="60" cy="19" r="2" fill="#34d399" />
          </g>
        )}

        {!isMythical && styleIdx === 1 && (
          <g>
            {/* Flowing Ribbon Bun / Scholar Chignon */}
            <ellipse cx="60" cy="17" rx="7.2" ry="5.5" fill={`url(#hairGrad_${uid})`} />
            <path d="M 52 19.5 Q 60 13 68 19.5" fill="none" stroke={isFemale ? '#f43f5e' : '#38bdf8'} strokeWidth="2.2" strokeLinecap="round" />
            <circle cx="60" cy="15.8" r="2.2" fill="#fde047" />
          </g>
        )}

        {!isMythical && styleIdx === 2 && (
          <g>
            {/* Golden Martial Circlet */}
            <path d="M 41.5 28.5 Q 60 23.5 78.5 28.5" fill="none" stroke={`url(#goldMetal_${uid})`} strokeWidth="2.5" strokeLinecap="round" />
            <path d="M 54 19 L 60 11 L 66 19 Z" fill={`url(#hairGrad_${uid})`} />
          </g>
        )}

        {!isMythical && styleIdx === 3 && (
          <g>
            {/* Sword Hairpin Bun */}
            <circle cx="60" cy="16.5" r="6" fill={`url(#hairGrad_${uid})`} />
            <circle cx="60" cy="16.5" r="2.2" fill="#38bdf8" />
            <path d="M 52 18.5 L 43 27.5" stroke="#cbd5e1" strokeWidth="1.6" strokeLinecap="round" />
            <path d="M 68 18.5 L 77 27.5" stroke="#cbd5e1" strokeWidth="1.6" strokeLinecap="round" />
          </g>
        )}

        {!isMythical && styleIdx === 4 && (
          <g>
            {/* Imperial Sovereign Crown */}
            <path d="M 51 21 L 54 10 L 60 14.5 L 66 10 L 69 21 Z" fill={`url(#goldMetal_${uid})`} stroke="#78350f" strokeWidth="0.6" />
            <circle cx="60" cy="17.5" r="2" fill="#ef4444" />
          </g>
        )}

        {!isMythical && styleIdx === 5 && (
          <g>
            {/* Crimson Rogue Forehead Ribbon */}
            <path d="M 40.5 28.5 Q 60 24.5 79.5 28.5" fill="none" stroke="#dc2626" strokeWidth="3" />
            <path d="M 78 28.5 Q 85 32.5 87 40" fill="none" stroke="#dc2626" strokeWidth="2.2" strokeLinecap="round" />
          </g>
        )}

        {!isMythical && styleIdx === 6 && (
          isFemale ? (
            <g>
              {/* Maiden Twin Hair Buns */}
              <circle cx="43" cy="21.5" r="5.6" fill={`url(#hairGrad_${uid})`} />
              <circle cx="77" cy="21.5" r="5.6" fill={`url(#hairGrad_${uid})`} />
              <circle cx="43" cy="21.5" r="1.9" fill="#34d399" />
              <circle cx="77" cy="21.5" r="1.9" fill="#34d399" />
            </g>
          ) : (
            <g>
              {/* Male Sleek Top Braid Clasp */}
              <ellipse cx="60" cy="17" rx="6" ry="4.2" fill={`url(#hairGrad_${uid})`} />
              <path d="M 54 18 L 66 18" stroke="#34d399" strokeWidth="2" strokeLinecap="round" />
            </g>
          )
        )}

        {!isMythical && styleIdx === 8 && (
          <g>
            {/* Senior Elder Topknot with Amethyst Gem */}
            <ellipse cx="60" cy="16.5" rx="6.5" ry="4.8" fill={`url(#hairGrad_${uid})`} />
            <circle cx="60" cy="17.5" r="2.4" fill="#a855f7" stroke="#fde047" strokeWidth="0.8" />
          </g>
        )}

        {!isMythical && styleIdx === 9 && (
          <g>
            {/* Dragon-Crest Winged Headpiece */}
            <path d="M 47 23 Q 40 15 44 10 Q 48 15 51 21" fill="none" stroke={`url(#goldMetal_${uid})`} strokeWidth="2.3" strokeLinecap="round" />
            <path d="M 73 23 Q 80 15 76 10 Q 72 15 69 21" fill="none" stroke={`url(#goldMetal_${uid})`} strokeWidth="2.3" strokeLinecap="round" />
            <circle cx="60" cy="23.5" r="2.1" fill="#38bdf8" />
          </g>
        )}

        {/* MYTHICAL FORM I: Nine-Heavens Celestial Thunder Sovereign Crown */}
        {isThunderSovereign && (
          <g>
            <ellipse cx="60" cy="17" rx="8" ry="5" fill={`url(#hairGrad_${uid})`} />
            <path d="M 48 22 L 51 9 L 56 15 L 60 6 L 64 15 L 69 9 L 72 22 Z" fill={`url(#goldMetal_${uid})`} stroke="#4c1d95" strokeWidth="0.8" />
            <circle cx="60" cy="15" r="2.6" fill="#c084fc" stroke="#ffffff" strokeWidth="0.6" />
            <circle cx="51" cy="12" r="1.4" fill="#fde047" />
            <circle cx="69" cy="12" r="1.4" fill="#fde047" />
          </g>
        )}

        {/* MYTHICAL FORM II: Primordial Dragon-Phoenix Immortal Horns */}
        {isImmortalBeast && (
          <g>
            <ellipse cx="60" cy="17" rx="7.5" ry="5" fill={`url(#hairGrad_${uid})`} />
            <path d="M 47 25 C 39 18, 34 10, 42 5 C 40 12, 44 18, 52 23 Z" fill={`url(#goldMetal_${uid})`} stroke="#065f46" strokeWidth="0.7" />
            <path d="M 73 25 C 81 18, 86 10, 78 5 C 80 12, 76 18, 68 23 Z" fill={`url(#goldMetal_${uid})`} stroke="#065f46" strokeWidth="0.7" />
            <path d="M 55 21 L 60 12 L 65 21 Z" fill="#34d399" stroke="#fde047" strokeWidth="0.8" />
            <circle cx="60" cy="18" r="2.2" fill="#fde047" />
          </g>
        )}

        {/* 10. Foreground Animated Lightning & Elemental Effects */}
        {activeAuraEffect === 'Azure Thunder' && (
          <g className="animate-lightning" style={{ transformOrigin: 'center' }}>
            <path d="M 18 28 L 28 38 L 22 44 L 32 58" fill="none" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-lightning-dash" />
            <path d="M 102 26 L 92 38 L 98 44 L 88 58" fill="none" stroke="#7dd3fc" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-lightning-dash" />
            <path d="M 30 92 L 20 100 L 26 106 L 16 114" fill="none" stroke="#bae6fd" strokeWidth="1.6" strokeLinecap="round" />
            <circle cx="24" cy="24" r="1.5" fill="#e0f2fe" />
            <circle cx="96" cy="22" r="1.5" fill="#e0f2fe" />
          </g>
        )}

        {activeAuraEffect === 'Golden Lightning' && (
          <g className="animate-lightning" style={{ transformOrigin: 'center' }}>
            <path d="M 16 20 L 28 32 L 21 38 L 32 52 L 25 60" fill="none" stroke="#fde047" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="animate-lightning-dash" />
            <path d="M 104 20 L 92 32 L 99 38 L 88 52 L 95 60" fill="none" stroke="#facc15" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="animate-lightning-dash" />
            <path d="M 48 8 L 54 16 L 50 18 L 56 26" fill="none" stroke="#fef08a" strokeWidth="1.5" strokeLinecap="round" />
            <circle cx="20" cy="48" r="1.6" fill="#fef08a" />
            <circle cx="100" cy="48" r="1.6" fill="#fef08a" />
          </g>
        )}

        {activeAuraEffect === 'Void Sparks' && (
          <g className="animate-lightning" style={{ transformOrigin: 'center' }}>
            <path d="M 14 34 L 26 42 L 19 49 L 29 62" fill="none" stroke="#c084fc" strokeWidth="2.1" strokeLinecap="round" className="animate-lightning-dash" />
            <path d="M 106 34 L 94 42 L 101 49 L 91 62" fill="none" stroke="#f43f5e" strokeWidth="2.1" strokeLinecap="round" className="animate-lightning-dash" />
            <circle cx="22" cy="76" r="1.7" fill="#d8b4fe" />
            <circle cx="98" cy="76" r="1.7" fill="#fda4af" />
            <circle cx="30" cy="20" r="1.2" fill="#e9d5ff" />
            <circle cx="90" cy="20" r="1.2" fill="#e9d5ff" />
          </g>
        )}

        {activeAuraEffect === 'Celestial Flame' && (
          <g className="animate-lantern-flame">
            <path d="M 18 96 C 14 82, 22 72, 20 62 C 26 70, 28 84, 24 96 Z" fill="#f97316" opacity="0.72" />
            <path d="M 102 96 C 106 82, 98 72, 100 62 C 94 70, 92 84, 96 96 Z" fill="#f59e0b" opacity="0.72" />
            <circle cx="22" cy="52" r="1.5" fill="#fde047" />
            <circle cx="98" cy="50" r="1.5" fill="#fb923c" />
            <circle cx="16" cy="72" r="1.2" fill="#fef08a" />
            <circle cx="104" cy="72" r="1.2" fill="#fef08a" />
          </g>
        )}
      </svg>

      {/* Soul Protection Seal Badge */}
      {soulProtected && (
        <div
          title="Protected by Ancestral Soul Lantern Seal"
          className="absolute top-0.5 left-0.5 w-3.5 h-3.5 rounded-full bg-amber-950/90 border border-amber-400/80 flex items-center justify-center text-[8px] text-amber-300 shadow-xs"
        >
          ✦
        </div>
      )}

      {/* Gender Badge */}
      {showGenderBadge && (
        <div
          title={gender === 'Male' ? 'Male Cultivator (♂)' : 'Female Cultivator (♀)'}
          className={`absolute bottom-0.5 right-0.5 px-1 py-0.2 rounded-md font-bold text-[9px] shadow-sm flex items-center justify-center ${
            gender === 'Male'
              ? 'bg-sky-950/90 text-sky-300 border border-sky-400/50'
              : 'bg-rose-950/90 text-rose-300 border border-rose-400/50'
          }`}
        >
          {gender === 'Male' ? '♂' : '♀'}
        </div>
      )}
    </div>
  );
};
