import React, { useState } from 'react';
import { ChampionTitle } from '../../types/cultivation';
import { Crown, Sparkles, X } from 'lucide-react';
import { soundEngine } from '../../services/audioEngine';

interface ChampionTitleBadgeProps {
  title: ChampionTitle;
  size?: 'sm' | 'md';
}

export const ChampionTitleBadge: React.FC<ChampionTitleBadgeProps> = ({ title, size = 'sm' }) => {
  const [showPopup, setShowPopup] = useState(false);
  const [pressTimer, setPressTimer] = useState<any>(null);

  const handleTouchStart = () => {
    const timer = setTimeout(() => {
      soundEngine.playTalisman();
      setShowPopup(true);
    }, 450); // Long press threshold ~450ms
    setPressTimer(timer);
  };

  const handleTouchEnd = () => {
    if (pressTimer) {
      clearTimeout(pressTimer);
      setPressTimer(null);
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    soundEngine.playClick();
    setShowPopup(!showPopup);
  };

  const getTitleEffects = () => {
    switch (title) {
      case 'Champion I':
        return {
          rank: 'Peak Arena Champion I',
          benefits: [
            'Special Prodigy Status: Suppresses peer jealousy and grudges by 90%.',
            '+20% Cultivation speed in seclusion.',
            '+250 Combat Power permanently.',
            'Direct promotion privileges without internal friction.'
          ]
        };
      case 'Champion II':
        return {
          rank: 'Peak Arena Champion II (Sovereign Aspirant)',
          benefits: [
            'Special Prodigy Status: Suppresses peer jealousy and grudges by 90%.',
            '+35% Cultivation speed and +500 Combat Power.',
            'Supreme Sect Pillar authority eligible for Sect Leader lineage.',
            'Double reputation yield in foreign diplomatic treaties.'
          ]
        };
      case 'Champion S':
        return {
          rank: 'Supreme Universal Champion S (All Sects Pinnacle)',
          benefits: [
            'Peerless Under Heaven: Immune to internal grudges and feuds.',
            '+50% Cultivation speed, +1,200 Combat Power.',
            'Grand Dao Resonance: Deflects 50% Heavenly Tribulation lightning damage.',
            'Renown across Extreme World: Neighbor sects treat your sect with Respect.'
          ]
        };
    }
  };

  const info = getTitleEffects();

  return (
    <div className="relative inline-block">
      <button
        type="button"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        onClick={handleClick}
        title="Long-press or click to view Champion glory perks"
        className={`inline-flex items-center gap-1 font-dao font-black rounded-lg transition-transform active:scale-95 shadow-sm border border-amber-300/80 cursor-pointer ${
          size === 'sm'
            ? 'px-2 py-0.5 text-[10px] bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-stone-950'
            : 'px-2.5 py-1 text-xs bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-600 text-stone-950'
        }`}
      >
        <Crown className="w-3 h-3 text-stone-950 fill-current animate-pulse" />
        <span className="tracking-wide">{title}</span>
      </button>

      {/* Long-press / Click Modal Popup */}
      {showPopup && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-fade-in"
        >
          <div className="bg-[#123d30] border-2 border-amber-400 rounded-3xl w-full max-w-sm p-4 shadow-2xl relative text-xs text-[#d1e6dc] space-y-3">
            <div className="flex justify-between items-start border-b border-[#e2b054]/40 pb-2">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-yellow-300 animate-bounce" />
                <div>
                  <h4 className="font-dao font-bold text-sm text-[#fce18b]">{info.rank}</h4>
                  <p className="text-[10px] text-amber-200">Champion Title Special Prodigy Effects</p>
                </div>
              </div>
              <button
                onClick={() => setShowPopup(false)}
                className="p-1 rounded-lg bg-[#09261d] text-[#a4c5b7] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-white text-[11px] block">Champion Divine Privileges:</span>
              <ul className="space-y-1.5 text-[11px]">
                {info.benefits.map((b, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5" />
                    <span className="leading-tight">{b}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-2 border-t border-[#1b4b3b] text-center">
              <button
                onClick={() => setShowPopup(false)}
                className="w-full py-2 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs shadow-sm hover:brightness-110"
              >
                Acknowledge Glory
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
