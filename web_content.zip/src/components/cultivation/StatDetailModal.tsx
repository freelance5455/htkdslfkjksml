import React from 'react';
import { STAT_DESCRIPTIONS } from '../../data/loreData';
import { Info, X, Sparkles } from 'lucide-react';
import { soundEngine } from '../../services/audioEngine';

interface StatDetailModalProps {
  statKey: string;
  onClose: () => void;
}

export const StatDetailModal: React.FC<StatDetailModalProps> = ({ statKey, onClose }) => {
  const detail = STAT_DESCRIPTIONS[statKey] || {
    title: statKey,
    description: 'A vital cultivation attribute influencing disciple progression and sect balance.',
    impact: 'Affects daily cultivation yields, survivability, and combat ratings.'
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-[#123d30] border-2 border-[#e2b054] rounded-3xl w-full max-w-sm p-4 shadow-2xl relative text-xs text-[#d1e6dc] space-y-3"
      >
        <div className="flex justify-between items-start border-b border-[#e2b054]/40 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-[#184838] border border-[#e2b054]/50 flex items-center justify-center text-[#fce18b]">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-dao font-bold text-sm text-[#fce18b]">{detail.title}</h4>
              <p className="text-[10px] text-[#9fc2b2]">Daoist Stat Specification</p>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="p-1 rounded-lg bg-[#09261d] text-[#a4c5b7] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2">
          <div>
            <span className="font-bold text-white text-[11px] block">Definition:</span>
            <p className="text-[#cbe3d7] text-[11px] leading-relaxed mt-0.5">{detail.description}</p>
          </div>

          <div className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] space-y-1">
            <span className="font-bold text-[#fce18b] text-[10px] flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#e2b054]" />
              <span>In-Game Mechanical Function:</span>
            </span>
            <p className="text-[#a4c5b7] text-[10px] leading-relaxed">{detail.impact}</p>
          </div>
        </div>

        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="w-full py-2 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs shadow-sm hover:brightness-110 active:scale-95"
        >
          Understood
        </button>
      </div>
    </div>
  );
};
