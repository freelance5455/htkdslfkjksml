import React from 'react';
import { motion } from 'motion/react';
import { 
  Home, 
  Heart, 
  Smile, 
  Building2, 
  Trees, 
  Utensils, 
  Sparkles, 
  Compass, 
  Rocket, 
  Crown, 
  Lock, 
  Star, 
  ArrowLeft 
} from 'lucide-react';
import { WORLDS_DATA } from '../game/worldData';
import { WorldInfo } from '../types';

interface WorldSelectModalProps {
  totalStars: number;
  completedLevelsCount: number;
  onSelectWorld: (world: WorldInfo) => void;
  onBack: () => void;
}

export const WorldSelectModal: React.FC<WorldSelectModalProps> = ({
  totalStars,
  onSelectWorld,
  onBack,
}) => {
  const getIcon = (iconName: string) => {
    const p = { className: 'w-6 h-6' };
    switch (iconName) {
      case 'Home': return <Home {...p} />;
      case 'Heart': return <Heart {...p} />;
      case 'Smile': return <Smile {...p} />;
      case 'Building2': return <Building2 {...p} />;
      case 'Trees': return <Trees {...p} />;
      case 'Utensils': return <Utensils {...p} />;
      case 'Sparkles': return <Sparkles {...p} />;
      case 'Compass': return <Compass {...p} />;
      case 'Rocket': return <Rocket {...p} />;
      case 'Crown': return <Crown {...p} />;
      default: return <Home {...p} />;
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-50 dark:bg-slate-900 select-none overflow-hidden">
      {/* Top Header */}
      <div className="px-5 pt-4 pb-3 flex items-center justify-between border-b border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 backdrop-blur-md">
        <button
          id="btn-world-back"
          type="button"
          onClick={onBack}
          className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200 active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center">
          <h2 className="text-lg font-black text-slate-800 dark:text-white tracking-tight">
            SELECT WORLD
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            10 Themed Realms • 200 Puzzles
          </span>
        </div>

        {/* Total Stars Pill */}
        <div className="h-9 px-3 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 flex items-center gap-1.5 shadow-sm">
          <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
          <span className="text-xs font-bold text-amber-900 dark:text-amber-200">
            {totalStars}
          </span>
        </div>
      </div>

      {/* World Cards Scroll View */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 pb-8">
        {WORLDS_DATA.map((world) => {
          const isUnlocked = totalStars >= world.requiredStars;
          return (
            <motion.button
              key={world.id}
              id={`world-card-${world.id}`}
              type="button"
              disabled={!isUnlocked}
              onClick={() => onSelectWorld(world)}
              whileTap={isUnlocked ? { scale: 0.98 } : {}}
              className={`w-full p-4 rounded-3xl border text-left transition-all relative overflow-hidden flex items-center gap-4 ${
                isUnlocked
                  ? 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-md hover:shadow-lg cursor-pointer'
                  : 'bg-slate-100/70 dark:bg-slate-800/40 border-slate-200/50 dark:border-slate-800/50 opacity-70 cursor-not-allowed'
              }`}
            >
              {/* World vector icon box */}
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-inner"
                style={{
                  backgroundColor: isUnlocked ? `${world.accentColor}20` : '#94a3b820',
                  color: isUnlocked ? world.accentColor : '#94a3b8',
                }}
              >
                {getIcon(world.iconName)}
              </div>

              {/* World Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    World {world.id}
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">
                    Levels {world.levelRange[0]}–{world.levelRange[1]}
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-800 dark:text-white truncate">
                  {world.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                  {world.description}
                </p>
              </div>

              {/* Status / Lock Pill */}
              <div className="shrink-0 flex items-center">
                {isUnlocked ? (
                  <div className="w-8 h-8 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                    ➔
                  </div>
                ) : (
                  <div className="px-2.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center gap-1 text-[11px] font-bold">
                    <Lock className="w-3.5 h-3.5" />
                    <span>{world.requiredStars}★</span>
                  </div>
                )}
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};
