import React, { useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Maximize2, Minimize2, Video, Camera } from 'lucide-react';
import { SlideItem, SlideshowSettings } from '../types';

interface SlideshowPlayerProps {
  slides: SlideItem[];
  currentIndex: number;
  isPlaying: boolean;
  settings: SlideshowSettings;
  progress: number; // 0 to 100
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onExportSnapshot: () => void;
  onOpenRecorder: () => void;
}

export const SlideshowPlayer: React.FC<SlideshowPlayerProps> = ({
  slides,
  currentIndex,
  isPlaying,
  settings,
  progress: _progress,
  onTogglePlay,
  onNext,
  onPrev,
  onExportSnapshot,
  onOpenRecorder,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = React.useState(false);

  const currentSlide = slides[currentIndex] || slides[0];

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      // Fallback if browser restrictions occur
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Determine exact edge shift for edge-to-edge straight linear horizontal slide
  const scaleFraction = Math.max(0.4, (settings.foregroundScale || 75) / 100);
  const leftSpacePercent = (1 - scaleFraction) / 2;
  const edgeShift = Math.min(45, Math.max(6, (leftSpacePercent / scaleFraction) * 100));

  // Consistent motion pattern helper for any slide index (never changes keyframe names)
  const getMotionStyles = (index: number) => {
    if (settings.motionPattern === '4-linear') {
      const motionType = index % 4;
      if (motionType === 0) return { main: 'linearZoomIn', bg: 'bgLinearZoomIn', label: '১. Zoom In (জুম ইন)' };
      if (motionType === 1) return { main: 'linearZoomOut', bg: 'bgLinearZoomOut', label: '২. Zoom Out (জুম আউট)' };
      if (motionType === 2) return { main: 'linearRtoL', bg: 'bgLinearRtoL', label: '৩. Right to Left (ডান থেকে বাম)' };
      return { main: 'linearLtoR', bg: 'bgLinearLtoR', label: '৪. Left to Right (বাম থেকে ডান)' };
    }
    const isEven = index % 2 === 0;
    return {
      main: isEven ? 'classicEven' : 'classicOdd',
      bg: isEven ? 'bgClassicEven' : 'bgClassicOdd',
      label: settings.motionPattern,
    };
  };

  const currentMotionInfo = getMotionStyles(currentIndex);
  const currentMotionName = currentMotionInfo.label;

  // Determine aspect ratio class
  const getAspectClass = () => {
    switch (settings.aspectRatio) {
      case '9:16':
        return 'aspect-[9/16] max-h-[580px]';
      case '1:1':
        return 'aspect-square max-h-[500px]';
      case '4:5':
        return 'aspect-[4/5] max-h-[540px]';
      case '16:9':
      default:
        return 'aspect-[16/9] max-h-[460px]';
    }
  };

  // Mask styles - Sharp Square (border-radius: 0px) as requested
  const getMainMaskStyles = (index: number): React.CSSProperties => {
    const motion = getMotionStyles(index).main;
    const playState = isPlaying ? 'running' : 'paused';

    const baseBorder: React.CSSProperties = settings.showBorder
      ? {
          borderStyle: 'solid',
          borderWidth: `${settings.borderWidth}px`,
          borderColor: settings.borderColor,
        }
      : {
          borderStyle: 'none',
          borderWidth: 0,
        };

    const base: React.CSSProperties = {
      ...baseBorder,
      boxSizing: 'border-box',
      boxShadow: settings.showShadow ? '0 8px 25px rgba(0,0,0,0.6)' : 'none',
      animation: `${motion} ${settings.interval}s linear ${playState} forwards`,
      borderRadius: '0px',
      willChange: 'transform',
      transform: 'translateZ(0)',
      backfaceVisibility: 'hidden',
      WebkitBackfaceVisibility: 'hidden',
    };

    if (settings.maskStyle === 'circle') {
      return {
        ...base,
        borderRadius: '50%',
        width: `${settings.foregroundScale * 0.85}%`,
        height: `${settings.foregroundScale * 0.85}%`,
        top: `${(100 - settings.foregroundScale * 0.85) / 2}%`,
        left: `${(100 - settings.foregroundScale * 0.85) / 2}%`,
      };
    }

    if (settings.maskStyle === 'rounded') {
      return {
        ...base,
        borderRadius: '20px',
        width: `${settings.foregroundScale}%`,
        height: `${settings.foregroundScale}%`,
        top: `${(100 - settings.foregroundScale) / 2}%`,
        left: `${(100 - settings.foregroundScale) / 2}%`,
      };
    }

    if (settings.maskStyle === 'polaroid') {
      return {
        ...base,
        borderRadius: '0px',
        width: `${settings.foregroundScale * 0.9}%`,
        height: `${settings.foregroundScale * 0.95}%`,
        top: `${(100 - settings.foregroundScale * 0.95) / 2}%`,
        left: `${(100 - settings.foregroundScale * 0.9) / 2}%`,
        borderStyle: 'solid',
        borderWidth: '8px',
        borderBottomWidth: '32px',
        borderColor: '#ffffff',
      };
    }

    if (settings.maskStyle === 'full') {
      return {
        ...base,
        borderRadius: '0px',
        borderStyle: 'none',
        borderWidth: 0,
        width: '100%',
        height: '100%',
        top: '0%',
        left: '0%',
      };
    }

    // Default 'box': Sharp Square (border-radius: 0px)
    return {
      ...base,
      borderRadius: '0px',
      width: `${settings.foregroundScale}%`,
      height: `${settings.foregroundScale}%`,
      top: `${(100 - settings.foregroundScale) / 2}%`,
      left: `${(100 - settings.foregroundScale) / 2}%`,
    };
  };

  return (
    <div
      ref={containerRef}
      id="inshot-preview-wrapper"
      className="relative w-full flex flex-col items-center justify-center select-none"
    >
      {/* Main Video/Canvas Stage */}
      <div
        id="previewContainer"
        className={`relative w-full overflow-hidden rounded-lg border-2 border-[#333] bg-black shadow-2xl flex items-center justify-center transition-all duration-300 ${getAspectClass()}`}
      >
        {/* Keyframes for Edge-to-Edge Straight Linear Slide & Zoom */}
        <style>{`
          @keyframes progressFill {
            0% { transform: scaleX(0); }
            100% { transform: scaleX(1); }
          }

          @keyframes linearZoomIn {
            0% { transform: translate3d(0, 0, 0) scale(1.0); }
            100% { transform: translate3d(0, 0, 0) scale(1.16); }
          }
          @keyframes linearZoomOut {
            0% { transform: translate3d(0, 0, 0) scale(1.16); }
            100% { transform: translate3d(0, 0, 0) scale(1.0); }
          }
          @keyframes linearRtoL {
            0% { transform: translate3d(${edgeShift}%, 0, 0); }
            100% { transform: translate3d(-${edgeShift}%, 0, 0); }
          }
          @keyframes linearLtoR {
            0% { transform: translate3d(-${edgeShift}%, 0, 0); }
            100% { transform: translate3d(${edgeShift}%, 0, 0); }
          }

          @keyframes bgLinearZoomIn {
            0% { transform: translate3d(0, 0, 0) scale(1.05); }
            100% { transform: translate3d(0, 0, 0) scale(1.18); }
          }
          @keyframes bgLinearZoomOut {
            0% { transform: translate3d(0, 0, 0) scale(1.18); }
            100% { transform: translate3d(0, 0, 0) scale(1.05); }
          }
          @keyframes bgLinearRtoL {
            0% { transform: translate3d(-6%, 0, 0) scale(1.15); }
            100% { transform: translate3d(6%, 0, 0) scale(1.15); }
          }
          @keyframes bgLinearLtoR {
            0% { transform: translate3d(6%, 0, 0) scale(1.15); }
            100% { transform: translate3d(-6%, 0, 0) scale(1.15); }
          }

          @keyframes classicEven {
            0% { transform: translate3d(-4%, -4%, 0) scale(1.0); }
            100% { transform: translate3d(4%, 4%, 0) scale(1.04); }
          }
          @keyframes classicOdd {
            0% { transform: translate3d(4%, 4%, 0) scale(1.04); }
            100% { transform: translate3d(-4%, -4%, 0) scale(1.0); }
          }
          @keyframes bgClassicEven {
            0% { transform: translate3d(4%, 4%, 0) scale(1.14); }
            100% { transform: translate3d(-4%, -4%, 0) scale(1.22); }
          }
          @keyframes bgClassicOdd {
            0% { transform: translate3d(-4%, -4%, 0) scale(1.22); }
            100% { transform: translate3d(4%, 4%, 0) scale(1.14); }
          }
        `}</style>

        {currentSlide ? (
          <>
            {/* PLANE 1: BACKGROUND BLUR LAYER */}
            <div
              key={`curr-bg-${currentSlide.id}-${currentIndex}`}
              id="slideBg"
              className="absolute pointer-events-none z-1"
              style={{
                width: '130%',
                height: '130%',
                top: '-15%',
                left: '-15%',
                backgroundImage: `url('${currentSlide.url}')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                filter: `blur(${settings.blur}px) brightness(${settings.brightness}) saturate(${settings.saturate})`,
                animation: `${getMotionStyles(currentIndex).bg} ${settings.interval}s linear ${isPlaying ? 'running' : 'paused'} forwards`,
                willChange: 'transform',
                transform: 'translateZ(0)',
                backfaceVisibility: 'hidden',
                WebkitBackfaceVisibility: 'hidden',
              }}
            />

            {/* PLANE 2: VIGNETTE OVERLAY */}
            <div
              className="absolute inset-0 pointer-events-none z-5"
              style={{
                background: 'radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.5) 100%)',
              }}
            />

            {/* PLANE 3: FOREGROUND SHARP CARD (Single active slide, no stacking) */}
            {(() => {
              const zoom = currentSlide.zoom ?? 1.0;
              const offX = currentSlide.offsetX ?? 0;
              const offY = currentSlide.offsetY ?? 0;
              const fitMode = currentSlide.fitMode ?? 'cover';

              // Calculate background position: 50% center + offset
              const bgPosX = `calc(50% + ${offX}%)`;
              const bgPosY = `calc(50% + ${offY}%)`;
              const bgSize = fitMode === 'contain' 
                ? (zoom !== 1.0 ? `contain` : 'contain')
                : `${zoom * 100}% auto`;

              return (
                <div
                  key={`curr-main-${currentSlide.id}-${currentIndex}`}
                  id="slideMain"
                  className="absolute pointer-events-none z-10 overflow-hidden"
                  style={{
                    ...getMainMaskStyles(currentIndex),
                  }}
                >
                  <div
                    className="w-full h-full bg-no-repeat"
                    style={{
                      backgroundImage: `url('${currentSlide.url}')`,
                      backgroundPosition: `${bgPosX} ${bgPosY}`,
                      backgroundSize: fitMode === 'contain' ? 'contain' : 'cover',
                      transform: zoom !== 1.0 || offX !== 0 || offY !== 0
                        ? `scale(${zoom}) translate3d(${offX / zoom}%, ${offY / zoom}%, 0)`
                        : 'none',
                      transformOrigin: 'center center',
                    }}
                  />

                  {/* Optional Polaroid Label Chin */}
                  {settings.maskStyle === 'polaroid' && (
                    <div className="absolute -bottom-7 left-0 right-0 text-center text-[10px] font-medium tracking-wider text-neutral-600 uppercase truncate px-2">
                      {currentSlide.name}
                    </div>
                  )}
                </div>
              );
            })()}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center text-neutral-400 gap-3 p-8 text-center">
            <div className="w-12 h-12 rounded-full bg-neutral-800/80 border border-neutral-700 flex items-center justify-center text-neutral-400">
              <Camera className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-semibold text-neutral-200">কোনো ছবি নেই (No slides available)</p>
              <p className="text-xs text-neutral-500 mt-0.5">
                নিচের বাটনে ক্লিক করে নতুন ছবি আপলোড করুন অথবা ডেমো লোড করুন
              </p>
            </div>
          </div>
        )}

        {/* Top Badges (Aspect & Motion indicators) */}
        <div className="absolute top-3 left-3 flex flex-wrap items-center gap-2 z-20">
          <span className="px-2.5 py-1 text-xs font-semibold rounded-md bg-black/70 backdrop-blur-md text-[#00e676] border border-[#00e676]/30 shadow-sm flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00e676] animate-pulse" />
            {settings.aspectRatio} • {settings.maskStyle.toUpperCase()}
          </span>
          <span className="px-2 py-1 text-[11px] font-medium rounded-md bg-black/70 backdrop-blur-md text-sky-300 border border-sky-400/30">
            {currentMotionName}
          </span>
        </div>

        <div className="absolute top-3 right-3 flex items-center gap-1.5 z-20">
          <button
            id="btn-snapshot-quick"
            onClick={onExportSnapshot}
            title="ছবি ফ্রেম ডাউনলোড করুন (Capture Snapshot)"
            className="p-2 rounded-lg bg-black/60 hover:bg-black/80 backdrop-blur-md text-neutral-200 hover:text-white border border-white/10 transition-colors"
          >
            <Camera className="w-4 h-4" />
          </button>
          <button
            id="btn-record-modal"
            onClick={onOpenRecorder}
            title="ভিডিও রেকর্ড করুন (Export Video)"
            className="p-2 rounded-lg bg-black/60 hover:bg-black/80 backdrop-blur-md text-emerald-400 hover:text-emerald-300 border border-emerald-500/30 transition-colors flex items-center gap-1"
          >
            <Video className="w-4 h-4" />
            <span className="text-xs hidden sm:inline font-semibold">ভিডিও</span>
          </button>
          <button
            id="btn-toggle-fullscreen"
            onClick={toggleFullscreen}
            title="ফুলস্ক্রিন মোড (Fullscreen)"
            className="p-2 rounded-lg bg-black/60 hover:bg-black/80 backdrop-blur-md text-neutral-200 hover:text-white border border-white/10 transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>

        {/* Bottom Progress Bar: 100% GPU Compositor Driven */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/40 backdrop-blur-sm z-20 overflow-hidden">
          <div
            key={`prog-bar-${currentIndex}-${isPlaying}`}
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 shadow-[0_0_8px_rgba(0,230,118,0.8)]"
            style={{
              width: '100%',
              transformOrigin: 'left',
              animation: isPlaying ? `progressFill ${settings.interval}s linear forwards` : 'none',
              willChange: 'transform',
            }}
          />
        </div>
      </div>

      {/* Floating Transport Bar under canvas */}
      <div className="w-full mt-3 px-3 py-2.5 rounded-xl bg-neutral-900/90 border border-neutral-800 shadow-lg flex items-center justify-between gap-3 text-white">
        <div className="flex items-center gap-2">
          <button
            id="btn-prev-slide"
            onClick={onPrev}
            disabled={slides.length <= 1}
            title="পূর্ববর্তী ছবি (Previous Slide)"
            className="p-2 rounded-lg hover:bg-neutral-800 text-neutral-300 hover:text-white disabled:opacity-40 transition-colors"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            id="btn-play-pause"
            onClick={onTogglePlay}
            title={isPlaying ? 'স্লাইডশো থামান (Pause)' : 'স্লাইডশো শুরু করুন (Play)'}
            className={`px-4 py-2 rounded-lg font-semibold text-sm flex items-center gap-2 transition-all shadow-md ${
              isPlaying
                ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20'
                : 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-emerald-500/20'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>থামুন (Stop)</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>স্টার্ট শো (Play)</span>
              </>
            )}
          </button>

          <button
            id="btn-next-slide"
            onClick={onNext}
            disabled={slides.length <= 1}
            title="পরবর্তী ছবি (Next Slide)"
            className="p-2 rounded-lg hover:bg-neutral-800 text-neutral-300 hover:text-white disabled:opacity-40 transition-colors"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Counter and Slide info */}
        <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
          <span className="px-2 py-1 rounded bg-neutral-800/80 text-emerald-400 font-bold">
            {slides.length > 0 ? currentIndex + 1 : 0} / {slides.length}
          </span>
          <span className="hidden sm:inline truncate max-w-[140px] text-neutral-300">
            {currentSlide?.name || 'InShot Slide'}
          </span>
        </div>
      </div>
    </div>
  );
};
