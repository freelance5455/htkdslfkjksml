import { useState, type FormEvent } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useVault } from "@/lib/vault-store";

export function AddBookPanel() {
  const setAdding = useVault((s) => s.setAdding);
  const addBook = useVault((s) => s.addBook);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim() || !text.trim()) {
      setError("Нужны название и текст.");
      return;
    }
    addBook({ title, author, text });
  }

  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center">
      <button
        type="button"
        aria-label="Закрыть"
        className="absolute inset-0 bg-ink/70"
        onClick={() => setAdding(false)}
      />
      <div
        role="dialog"
        aria-labelledby="add-book-title"
        className="relative flex max-h-full w-full flex-col overflow-hidden rounded-t-3xl bg-ink-2 p-5 pb-safe shadow-lift"
      >
        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <h2 id="add-book-title" className="font-display text-2xl tracking-tight">Свой текст</h2>
            <p className="mt-1 font-reading text-sm text-muted">
              Останется на этой полке и за тем же паролем.
            </p>
          </div>
          <Button variant="ghost" size="icon-sm" aria-label="Закрыть" onClick={() => setAdding(false)}>
            <X className="size-4" />
          </Button>
        </div>
        <form onSubmit={onSubmit} className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto">
          <div className="space-y-1.5">
            <Label htmlFor="book-title">Название</Label>
            <Input id="book-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Заголовок" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="book-author">Автор</Label>
            <Input
              id="book-author"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="необязательно"
            />
          </div>
          <div className="flex min-h-0 flex-1 flex-col space-y-1.5">
            <Label htmlFor="book-text">Текст</Label>
            <Textarea
              id="book-text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Вставьте рассказ, главу, письмо…"
              className="min-h-40 flex-1"
            />
          </div>
          {error && (
            <p className="text-sm text-danger" role="alert">
              {error}
            </p>
          )}
          <Button type="submit" variant="sage" size="lg" className="mt-1 w-full">
            Поставить на полку
          </Button>
        </form>
      </div>
    </div>
  );
}
