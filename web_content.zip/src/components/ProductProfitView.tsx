import React, { useState, useEffect } from 'react';
import { StorageService } from '../db/storage';
import { BarChart3, ArrowLeft, Search, TrendingUp, Package, Layers } from 'lucide-react';

interface ProductProfitViewProps {
  lang: 'bn' | 'en';
  onBack: () => void;
}

export const ProductProfitView: React.FC<ProductProfitViewProps> = ({
  lang,
  onBack,
}) => {
  const [profitData, setProfitData] = useState(StorageService.getProductProfitSummary());
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    setProfitData(StorageService.getProductProfitSummary());
  }, []);

  const filteredData = profitData.filter((item) => {
    const q = searchQuery.toLowerCase();
    return (
      item.product.name.toLowerCase().includes(q) ||
      item.product.brand.toLowerCase().includes(q) ||
      item.product.modelNumber.toLowerCase().includes(q) ||
      item.product.category.toLowerCase().includes(q)
    );
  });

  const totalSoldAll = profitData.reduce((sum, item) => sum + item.quantitySold, 0);
  const totalSalesValAll = profitData.reduce((sum, item) => sum + item.salesValue, 0);
  const totalNetProfitAll = profitData.reduce((sum, item) => sum + item.netProfit, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-600" />
                <span>{lang === 'bn' ? 'পণ্যভিত্তিক লাভ (Product Profit Analytics)' : 'Product Profit'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? 'প্রতিটি ডিসপ্লে ও পার্টস বিক্রয়ে মোট ক্রয়, বিক্রয় ও নিট লাভ'
                  : 'Itemized revenue, cost of goods, and net profit per product'}
              </p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 border-t border-slate-100">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ব্র্যান্ড, মডেল বা ক্যাটাগরি দিয়ে লাভ খুঁজুন..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Top Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 font-semibold block">মোট বিক্রি হওয়া পণ্য</span>
            <h3 className="text-xl font-extrabold text-slate-900 mt-1">
              {totalSoldAll.toLocaleString()} <span className="text-xs font-normal text-slate-500">পিস</span>
            </h3>
          </div>
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 font-semibold block">সর্বমোট বিক্রয় মূল্য</span>
            <h3 className="text-xl font-extrabold text-blue-600 mt-1">
              ৳{totalSalesValAll.toLocaleString()}
            </h3>
          </div>
          <div className="p-4 rounded-2xl bg-white border border-emerald-200 shadow-xs bg-emerald-50/20">
            <span className="text-xs text-emerald-700 font-bold block">সর্বমোট অর্জিত নিট লাভ</span>
            <h3 className="text-xl font-extrabold text-emerald-600 mt-1">
              ৳{totalNetProfitAll.toLocaleString()}
            </h3>
          </div>
        </div>

        {/* Product Profit Table / Cards */}
        {filteredData.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 text-slate-400 text-xs">
            কোন পণ্যের বিক্রয়ের হিসাব পাওয়া যায়নি
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredData.map((item) => {
              const marginPercent =
                item.salesValue > 0
                  ? Math.round((item.netProfit / item.salesValue) * 100)
                  : 0;

              return (
                <div
                  key={item.product.id}
                  className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 font-bold text-xs">
                        {item.product.brand}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-bold border border-emerald-200">
                        মার্জিন: {marginPercent}%
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-900 text-sm leading-snug">
                      {item.product.modelNumber}
                    </h4>
                    <span className="text-[11px] text-slate-400 block mb-3">
                      {item.product.category}
                    </span>

                    {/* Breakdown Metric Grid */}
                    <div className="grid grid-cols-2 gap-2 text-xs p-3 rounded-xl bg-slate-50 border border-slate-100 mb-3">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">বিক্রয় পরিমাণ</span>
                        <span className="font-bold text-slate-800">{item.quantitySold} পিস</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">রিটার্ন ফেরত</span>
                        <span className="font-bold text-rose-600">{item.returnedQuantity} পিস</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">মোট ক্রয়মূল্য</span>
                        <span className="font-semibold text-slate-700">৳{item.purchaseValue.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">মোট বিক্রয়মূল্য</span>
                        <span className="font-semibold text-blue-700">৳{item.salesValue.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Profit Bottom line */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-600">নিট লাভ (Net Profit):</span>
                    <span className="text-base font-extrabold text-emerald-600">
                      ৳{item.netProfit.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
