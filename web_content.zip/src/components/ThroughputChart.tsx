/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MetricHistoryPoint } from '../types/network';
import { LineChart, Clock } from 'lucide-react';

interface ThroughputChartProps {
  history: MetricHistoryPoint[];
}

export const ThroughputChart: React.FC<ThroughputChartProps> = ({ history }) => {
  const [viewMode, setViewMode] = useState<'speed' | 'ping'>('speed');

  if (!history || history.length < 2) return null;

  const width = 460;
  const height = 150;
  const padding = { top: 15, right: 15, bottom: 25, left: 35 };

  // Determine bounds
  const highestSpeed = Math.max(...history.map(h => Math.max(h.download, h.upload)));
  const maxSpeed = Math.max(100, highestSpeed * 1.15);
  const highestPing = Math.max(...history.map(h => h.ping));
  const maxPing = Math.max(50, highestPing * 1.25);

  const innerW = width - padding.left - padding.right;
  const innerH = height - padding.top - padding.bottom;

  // Generate SVG path points
  const getX = (index: number) => padding.left + (index / (history.length - 1)) * innerW;
  
  const getY = (val: number, max: number) => 
    padding.top + innerH - (Math.min(val, max) / max) * innerH;

  const dlPoints = history.map((h, i) => `${getX(i)},${getY(h.download, maxSpeed)}`).join(' ');
  const ulPoints = history.map((h, i) => `${getX(i)},${getY(h.upload, maxSpeed)}`).join(' ');
  const pingPoints = history.map((h, i) => `${getX(i)},${getY(h.ping, maxPing)}`).join(' ');

  // Area paths for gradient fills
  const dlAreaPath = `M ${getX(0)},${padding.top + innerH} L ${dlPoints.replace(/ /g, ' L ')} L ${getX(history.length - 1)},${padding.top + innerH} Z`;
  const ulAreaPath = `M ${getX(0)},${padding.top + innerH} L ${ulPoints.replace(/ /g, ' L ')} L ${getX(history.length - 1)},${padding.top + innerH} Z`;

  const latest = history[history.length - 1];

  return (
    <div className="rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-slate-800/80 p-4 shadow-lg backdrop-blur-sm">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
          <LineChart className="w-3.5 h-3.5 text-cyan-400" />
          <span>Real-time Network Flow (60s)</span>
        </div>

        <div className="flex items-center p-0.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs">
          <button
            onClick={() => setViewMode('speed')}
            className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
              viewMode === 'speed' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Mbps
          </button>
          <button
            onClick={() => setViewMode('ping')}
            className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
              viewMode === 'ping' ? 'bg-slate-800 text-amber-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Latency
          </button>
        </div>
      </div>

      {/* SVG Chart */}
      <div className="w-full overflow-hidden">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-36">
          <defs>
            <linearGradient id="dlFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="ulFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#a855f7" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#a855f7" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line
            x1={padding.left}
            y1={padding.top}
            x2={width - padding.right}
            y2={padding.top}
            stroke="#1e293b"
            strokeDasharray="3 3"
          />
          <line
            x1={padding.left}
            y1={padding.top + innerH / 2}
            x2={width - padding.right}
            y2={padding.top + innerH / 2}
            stroke="#1e293b"
            strokeDasharray="3 3"
          />
          <line
            x1={padding.left}
            y1={padding.top + innerH}
            x2={width - padding.right}
            y2={padding.top + innerH}
            stroke="#334155"
          />

          {/* Y Axis Labels */}
          {viewMode === 'speed' ? (
            <>
              <text x={padding.left - 6} y={padding.top + 4} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                {Math.round(maxSpeed)}M
              </text>
              <text x={padding.left - 6} y={padding.top + innerH / 2 + 3} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                {Math.round(maxSpeed / 2)}M
              </text>
              <text x={padding.left - 6} y={padding.top + innerH} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                0
              </text>
            </>
          ) : (
            <>
              <text x={padding.left - 6} y={padding.top + 4} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                {Math.round(maxPing)}ms
              </text>
              <text x={padding.left - 6} y={padding.top + innerH / 2 + 3} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                {Math.round(maxPing / 2)}ms
              </text>
              <text x={padding.left - 6} y={padding.top + innerH} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                0ms
              </text>
            </>
          )}

          {/* Paths */}
          {viewMode === 'speed' ? (
            <>
              {/* Areas */}
              <path d={dlAreaPath} fill="url(#dlFill)" />
              <path d={ulAreaPath} fill="url(#ulFill)" />

              {/* Lines */}
              <polyline points={ulPoints} fill="none" stroke="#a855f7" strokeWidth="2" strokeLinecap="round" />
              <polyline points={dlPoints} fill="none" stroke="#06b6d4" strokeWidth="2.5" strokeLinecap="round" />

              {/* Latest dot */}
              <circle
                cx={getX(history.length - 1)}
                cy={getY(latest.download, maxSpeed)}
                r="4"
                fill="#06b6d4"
                stroke="#090d16"
                strokeWidth="2"
              />
            </>
          ) : (
            <>
              <polyline points={pingPoints} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" />
              <circle
                cx={getX(history.length - 1)}
                cy={getY(latest.ping, maxPing)}
                r="4"
                fill="#f59e0b"
                stroke="#090d16"
                strokeWidth="2"
              />
            </>
          )}

          {/* X Axis Timestamps */}
          <text x={padding.left} y={height - 6} fill="#64748b" fontSize="9">
            -60s
          </text>
          <text x={width - padding.right} y={height - 6} textAnchor="end" fill="#64748b" fontSize="9">
            Now
          </text>
        </svg>
      </div>

      {/* Legend & Current Indicators */}
      <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60 mt-1">
        {viewMode === 'speed' ? (
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span className="text-slate-400 text-[11px]">Download:</span>
              <span className="font-mono font-medium text-cyan-300 text-[11px]">{latest.download} Mbps</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-400" />
              <span className="text-slate-400 text-[11px]">Upload:</span>
              <span className="font-mono font-medium text-purple-300 text-[11px]">{latest.upload} Mbps</span>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span className="text-slate-400 text-[11px]">Real Ping Latency:</span>
            <span className="font-mono font-medium text-amber-300 text-[11px]">{latest.ping} ms (Jitter: {latest.jitter}ms)</span>
          </div>
        )}

        <div className="flex items-center gap-1 text-[11px] text-slate-400">
          <Clock className="w-3 h-3 text-slate-400" />
          <span>2s intervals</span>
        </div>
      </div>
    </div>
  );
};
