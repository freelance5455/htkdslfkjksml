/**
 * SPR - Sahil Powerful Run
 * Lucky Fortune Spin Wheel Modal
 * With Strict Offline 24-Hour Cooldown Timer
 */

import React, { useState } from 'react';
import { X, Sparkles, Home, Lock } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';
import { saveManager } from '../game/storage/SaveManager';
import { useRewardCooldown } from '../hooks/useRewardCooldown';

interface Props {
  onClose: () => void;
  onRewardClaimed?: () => void;
}

const SLICES = [
  { text: '500 🪙', type: 'coins', amount: 500, color: '#f59e0b', bg: '#78350f' },
  { text: '2 💎', type: 'diamonds', amount: 2, color: '#38bdf8', bg: '#0369a1' },
  { text: '1,000 🪙', type: 'coins', amount: 1000, color: '#fbbf24', bg: '#92400e' },
  { text: '5 💎', type: 'diamonds', amount: 5, color: '#0ea5e9', bg: '#075985' },
  { text: '2,500 🪙', type: 'coins', amount: 2500, color: '#f97316', bg: '#c2410c' },
  { text: '10 💎', type: 'diamonds', amount: 10, color: '#38bdf8', bg: '#0284c7' },
  { text: '5,000 🪙', type: 'coins', amount: 5000, color: '#eab308', bg: '#a16207' },
  { text: '10,000 👑', type: 'coins', amount: 10000, color: '#ef4444', bg: '#991b1b' },
];

export const SpinModal: React.FC<Props> = ({ onClose, onRewardClaimed }) => {
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [rotation, setRotation] = useState<number>(0);
  const [wonPrize, setWonPrize] = useState<{ text: string; type: string; amount: number } | null>(null);

  const { isAvailable, countdown, claim } = useRewardCooldown('spin', 'SPIN');

  const handleSpin = () => {
    if (isSpinning || !isAvailable) return;

    soundManager.playButtonClick();
    setIsSpinning(true);
    setWonPrize(null);

    // Pick a random slice
    const prizeIndex = Math.floor(Math.random() * SLICES.length);
    const prize = SLICES[prizeIndex];

    // Compute rotation (each slice is 360 / 8 = 45 deg)
    const sliceAngle = 360 / SLICES.length;
    const extraSpins = 5 * 360; // 5 full revolutions
    const targetAngle = extraSpins + (360 - prizeIndex * sliceAngle - sliceAngle / 2);

    setRotation((prev) => prev + targetAngle);

    setTimeout(() => {
      setIsSpinning(false);
      setWonPrize(prize);
      soundManager.playPowerupSound();

      if (prize.type === 'coins') {
        saveManager.addCoins(prize.amount);
      } else {
        saveManager.addDiamonds(prize.amount);
      }

      // Record offline 24-hour cooldown
      claim();

      if (onRewardClaimed) onRewardClaimed();
    }, 3800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-sm bg-gradient-to-b from-slate-900 via-indigo-950 to-black border-2 border-amber-500/50 rounded-3xl p-5 shadow-[0_0_50px_rgba(245,158,11,0.4)] flex flex-col items-center">
        {/* Header */}
        <div className="w-full flex items-center justify-between pb-3 border-b border-amber-500/20">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-400 animate-spin" />
            <div>
              <h2 className="text-xl font-black tracking-wider text-white uppercase font-display">
                LUCKY SPIN
              </h2>
              <p className="text-[11px] text-slate-400">1 Free Spin Every 24 Hours</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="spin-btn-home"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs uppercase font-display shadow-md transition cursor-pointer active:scale-95"
              title="Return to SPR Main Menu"
            >
              <Home className="w-3.5 h-3.5" />
              <span>HOME</span>
            </button>

            <button
              id="spin-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Pointer Arrow */}
        <div className="relative mt-4 flex items-center justify-center">
          <div className="absolute -top-3 z-20 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-amber-400 drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]" />

          {/* Wheel Circle */}
          <div
            className="w-56 h-56 rounded-full border-4 border-amber-400 shadow-[0_0_30px_rgba(245,158,11,0.6)] relative overflow-hidden transition-transform duration-[3800ms] ease-out"
            style={{
              transform: `rotate(${rotation}deg)`,
              background: 'conic-gradient(#78350f 0deg 45deg, #0369a1 45deg 90deg, #92400e 90deg 135deg, #075985 135deg 180deg, #c2410c 180deg 225deg, #0284c7 225deg 270deg, #a16207 270deg 315deg, #991b1b 315deg 360deg)',
            }}
          >
            {SLICES.map((slice, i) => {
              const angle = i * 45 + 22.5;
              return (
                <div
                  key={i}
                  className="absolute inset-0 flex items-start justify-center pt-3 font-bold text-xs text-white drop-shadow"
                  style={{
                    transform: `rotate(${angle}deg)`,
                    transformOrigin: '50% 50%',
                  }}
                >
                  <span className="bg-black/40 px-1.5 py-0.5 rounded font-mono font-bold tracking-tight">
                    {slice.text}
                  </span>
                </div>
              );
            })}

            {/* Center Cap */}
            <div className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-gradient-to-tr from-amber-600 to-yellow-300 border-2 border-white shadow-lg flex items-center justify-center">
              <span className="text-black font-black text-xs font-display">SPR</span>
            </div>
          </div>
        </div>

        {/* Reward Notification */}
        {wonPrize && (
          <div className="mt-4 p-3 bg-amber-500/20 border border-amber-400/60 rounded-xl text-center animate-bounce w-full">
            <span className="text-xs text-amber-200 font-semibold block uppercase tracking-wider">
              🎉 YOU WON!
            </span>
            <span className="text-xl font-black text-amber-400 font-display">
              {wonPrize.text}
            </span>
          </div>
        )}

        {/* 24-Hour Cooldown Action Button */}
        <div className="mt-5 w-full">
          {isSpinning ? (
            <button
              disabled
              className="w-full py-3.5 px-6 rounded-2xl font-black text-base uppercase tracking-wider bg-slate-700 text-slate-300 cursor-not-allowed shadow-inner"
            >
              SPINNING WHEEL...
            </button>
          ) : !isAvailable ? (
            <div className="w-full flex flex-col items-center gap-1.5">
              <button
                disabled
                className="w-full py-3.5 px-6 rounded-2xl font-mono font-black text-sm sm:text-base tracking-wider bg-slate-800/90 border-2 border-slate-700 text-slate-300 cursor-not-allowed flex items-center justify-center gap-2 shadow-inner"
              >
                <Lock className="w-5 h-5 text-amber-400" />
                <span>NEXT SPIN IN {countdown}</span>
              </button>
              <p className="text-[11px] text-slate-400 text-center font-medium">
                ⏳ 24-Hour Cooldown active • Continues counting down offline
              </p>
            </div>
          ) : (
            <button
              id="spin-btn-trigger"
              onClick={handleSpin}
              className="w-full py-3.5 px-6 rounded-2xl font-black text-base uppercase tracking-wider text-slate-950 transition shadow-[0_0_25px_rgba(245,158,11,0.6)] cursor-pointer bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-300 hover:from-amber-300 hover:to-yellow-200 active:scale-95 font-display flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5 fill-current" />
              <span>SPIN NOW (1 FREE SPIN)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
