import React, { useState } from "react";
import { Lightbulb, Sparkles, Wand2, Tag, Copy, Check } from "lucide-react";
import { SAMPLE_PROMPTS, STYLE_PRESETS } from "../data/presets";
import { SamplePrompt } from "../types";

interface PromptInspirationProps {
  onSelectPrompt: (prompt: string, styleId: string, aspectRatio: any) => void;
}

export const PromptInspiration: React.FC<PromptInspirationProps> = ({ onSelectPrompt }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = ["All", "Sci-Fi", "Fantasy", "Anime", "3D Art", "Photorealistic", "Cinematic"];

  const filteredPrompts = SAMPLE_PROMPTS.filter((item) => {
    if (selectedCategory === "All") return true;
    return item.category === selectedCategory;
  });

  const handleCopy = (prompt: string, id: string) => {
    navigator.clipboard.writeText(prompt);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Category Pills */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md flex items-center gap-2 overflow-x-auto">
        <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 shrink-0 pr-2">
          <Tag className="w-3.5 h-3.5 text-indigo-400" />
          <span>Category:</span>
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
              selectedCategory === cat
                ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
                : "bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid of Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPrompts.map((item) => {
          const styleObj = STYLE_PRESETS.find((s) => s.id === item.styleId);
          return (
            <div
              key={item.id}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800/80 hover:border-purple-500/50 transition duration-300 flex flex-col justify-between space-y-4 shadow-lg"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 text-[10px] font-bold uppercase tracking-wider">
                    {item.category}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">{item.aspectRatio}</span>
                </div>

                <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-pink-400" />
                  <span>{item.title}</span>
                </h3>

                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/80 p-3 rounded-xl border border-slate-800/60 font-sans">
                  "{item.prompt}"
                </p>

                <div className="flex flex-wrap gap-1">
                  {item.tags.map((tag) => (
                    <span key={tag} className="px-2 py-0.5 rounded bg-slate-950 text-[10px] text-slate-400">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-800/60">
                <button
                  onClick={() => onSelectPrompt(item.prompt, item.styleId, item.aspectRatio)}
                  className="flex-1 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-purple-500/15 transition"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Use in Studio</span>
                </button>

                <button
                  onClick={() => handleCopy(item.prompt, item.id)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs transition"
                  title="Copy Prompt"
                >
                  {copiedId === item.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
