import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  ArrowDown,
  ArrowUp,
  Camera,
  ChevronDown,
  ChevronLeft,
  ChevronUp,
  Download,
  Eye,
  EyeOff,
  Lock,
  LockOpen,
  Plus,
  Route,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { clsx } from "clsx";
import {
  MINERALS,
  PLACES,
  formatCoords,
  formatDate,
  formatKm,
  inAustria,
  parseCoord,
  placeStopId,
  resolveStop,
  todayIso,
  tourLengthKm,
  validCoord,
  type Find,
} from "@/lib/field";
import { useField, type SaveFindInput } from "@/lib/field-store";

export type TabId = "funde" | "touren" | "orte";

export type EditorState = {
  id: string | null;
  seed?: { name: string; mineral: string; notes: string };
};

type Props = {
  tab: TabId;
  setTab: (tab: TabId) => void;
  sheetOpen: boolean;
  setSheetOpen: (open: boolean) => void;
  query: string;
  setQuery: (value: string) => void;
  showPlaces: boolean;
  setShowPlaces: (value: boolean) => void;
  editor: EditorState | null;
  pin: { lat: number; lng: number } | null;
  setPin: (pin: { lat: number; lng: number }) => void;
  detailKey: string | null;
  activeTourId: string | null;
  recording: boolean;
  setRecording: (value: boolean) => void;
  userLoc: { lat: number; lng: number } | null;
  onOpenDetail: (key: string) => void;
  onCloseDetail: () => void;
  onOpenEditor: (editor: EditorState) => void;
  onCloseEditor: () => void;
  onOpenTour: (id: string) => void;
  onCloseTour: () => void;
  onSaved: (id: string) => void;
  onBanner: (message: string) => void;
};

const fieldCls =
  "w-full rounded-md border border-border bg-bg px-3 text-sm text-fg placeholder:text-muted";
const btnPrimary =
  "inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-medium text-primary-fg hover:opacity-90 disabled:opacity-50";
const btnQuiet =
  "inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-surface-2 px-4 text-sm font-medium text-fg hover:bg-bg disabled:opacity-50";

function matches(query: string, parts: Array<string | undefined>) {
  const needle = query.trim().toLowerCase();
  if (!needle) return true;
  return parts.join(" ").toLowerCase().includes(needle);
}

export function FieldPanel(props: Props) {
  const finds = useField((state) => state.finds);
  const tours = useField((state) => state.tours);
  const ready = useField((state) => state.ready);
  const photoUrls = useField((state) => state.photoUrls);
  const loadError = useField((state) => state.loadError);

  const filteredFinds = finds.filter((find) =>
    matches(props.query, [find.name, find.mineral, find.notes, find.date]),
  );
  const filteredPlaces = PLACES.filter((place) =>
    matches(props.query, [place.name, place.mineral, place.region, place.note]),
  );
  const filteredTours = tours.filter((tour) => matches(props.query, [tour.name, tour.notes]));

  return (
    <aside
      className={clsx(
        "flex w-full min-h-0 shrink-0 flex-col border-t border-border bg-surface xl:h-full xl:w-80 xl:flex-none xl:border-t-0 xl:border-l",
        props.sheetOpen ? "max-xl:flex-1" : "h-14",
      )}
    >
      <div className="flex h-14 shrink-0 items-center gap-1 border-b border-border px-2">
        <TabButton active={props.tab === "funde"} onClick={() => props.setTab("funde")} label="Funde" count={finds.length} />
        <TabButton active={props.tab === "touren"} onClick={() => props.setTab("touren")} label="Touren" count={tours.length} />
        <TabButton active={props.tab === "orte"} onClick={() => props.setTab("orte")} label="Orte" count={PLACES.length} />
        <button
          type="button"
          className="ml-auto grid size-11 place-items-center rounded-md text-muted xl:hidden"
          aria-label={props.sheetOpen ? "Liste einklappen" : "Liste öffnen"}
          onClick={() => props.setSheetOpen(!props.sheetOpen)}
        >
          {props.sheetOpen ? <ChevronDown className="size-5" /> : <ChevronUp className="size-5" />}
        </button>
      </div>

      <div className={clsx("flex min-h-0 flex-1 flex-col", props.sheetOpen ? "" : "hidden xl:flex")}>
        {!props.editor && !props.detailKey && props.activeTourId === null ? (
          <div className="shrink-0 px-3 pt-3">
            <label className="sr-only" htmlFor="ader-search">
              Suchen
            </label>
            <input
              id="ader-search"
              value={props.query}
              onChange={(event) => props.setQuery(event.target.value)}
              placeholder={props.tab === "touren" ? "Tour suchen" : "Name oder Mineral"}
              autoComplete="off"
              suppressHydrationWarning
              className={clsx(fieldCls, "h-11")}
            />
          </div>
        ) : null}

        <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3">
          {loadError ? <p className="mb-3 text-sm text-muted">{loadError}</p> : null}
          {!ready ? <p className="text-sm text-muted">Lade deine Funde…</p> : null}

          {ready && props.editor ? (
            <FindForm
              key={`${props.editor.id ?? "neu"}-${props.editor.seed?.name ?? ""}`}
              editor={props.editor}
              pin={props.pin}
              setPin={props.setPin}
              userLoc={props.userLoc}
              finds={finds}
              photoUrls={photoUrls}
              onCancel={props.onCloseEditor}
              onSaved={props.onSaved}
              onBanner={props.onBanner}
            />
          ) : null}

          {ready && !props.editor && props.detailKey ? (
            <Detail
              detailKey={props.detailKey}
              finds={finds}
              photoUrls={photoUrls}
              onBack={props.onCloseDetail}
              onEdit={(id) => props.onOpenEditor({ id })}
              onAdopt={(placeId) => {
                const place = PLACES.find((item) => item.id === placeId);
                if (!place) return;
                props.setPin({ lat: place.lat, lng: place.lng });
                props.onOpenEditor({
                  id: null,
                  seed: { name: place.name, mineral: place.mineral, notes: place.note },
                });
              }}
              onBanner={props.onBanner}
            />
          ) : null}

          {ready && !props.editor && !props.detailKey && props.tab === "funde" ? (
            <FindList
              finds={filteredFinds}
              total={finds.length}
              photoUrls={photoUrls}
              onOpen={props.onOpenDetail}
              onCreate={() => props.onOpenEditor({ id: null })}
              onBanner={props.onBanner}
            />
          ) : null}

          {ready && !props.editor && !props.detailKey && props.tab === "touren" && props.activeTourId === null ? (
            <TourList
              tours={filteredTours}
              finds={finds}
              onOpen={props.onOpenTour}
              onCreate={async () => {
                const id = await useField.getState().createTour();
                props.onOpenTour(id);
                props.setRecording(true);
              }}
            />
          ) : null}

          {ready && !props.editor && !props.detailKey && props.activeTourId ? (
            <TourEditor
              tourId={props.activeTourId}
              finds={finds}
              recording={props.recording}
              setRecording={props.setRecording}
              onBack={props.onCloseTour}
              onBanner={props.onBanner}
            />
          ) : null}

          {ready && !props.editor && !props.detailKey && props.tab === "orte" ? (
            <PlaceList
              places={filteredPlaces}
              showPlaces={props.showPlaces}
              setShowPlaces={props.setShowPlaces}
              onOpen={(id) => props.onOpenDetail(placeStopId(id))}
            />
          ) : null}
        </div>
      </div>
    </aside>
  );
}

function TabButton({
  active,
  label,
  count,
  onClick,
}: {
  active: boolean;
  label: string;
  count: number;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={clsx(
        "relative h-11 rounded-md px-2.5 text-sm font-medium",
        active ? "text-fg" : "text-muted",
      )}
    >
      {label}
      <span className="ml-1 text-xs text-muted">{count}</span>
      {active ? <span className="absolute inset-x-2 bottom-1 h-0.5 rounded-full bg-primary" /> : null}
    </button>
  );
}

function FindList({
  finds,
  total,
  photoUrls,
  onOpen,
  onCreate,
  onBanner,
}: {
  finds: Find[];
  total: number;
  photoUrls: Record<string, string>;
  onOpen: (id: string) => void;
  onCreate: () => void;
  onBanner: (message: string) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const exportBackup = useField((state) => state.exportBackup);
  const importBackup = useField((state) => state.importBackup);

  return (
    <div className="flex flex-col gap-3">
      <button type="button" className={btnPrimary} onClick={onCreate}>
        <Plus className="size-4" />
        Fund eintragen
      </button>
      <p className="text-sm leading-relaxed text-muted">
        Tipp auf die Karte setzt den Punkt. Fotos und Notizen bleiben auf diesem Gerät.
      </p>
      {total === 0 ? (
        <p className="font-display text-xl leading-snug text-fg">Noch keine eigenen Funde.</p>
      ) : finds.length === 0 ? (
        <p className="text-sm text-muted">Nichts passt zur Suche.</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {finds.map((find) => {
            const photo = find.photoIds.map((id) => photoUrls[id]).find(Boolean);
            return (
              <li key={find.id}>
                <button
                  type="button"
                  onClick={() => onOpen(find.id)}
                  className="flex w-full items-center gap-3 rounded-md border border-border bg-bg p-2 text-left hover:border-primary"
                >
                  {photo ? (
                    <img src={photo} alt="" className="size-14 rounded-md object-cover" />
                  ) : (
                    <span className="grid size-14 place-items-center rounded-md bg-surface-2 text-primary">
                      <span className="size-3 rotate-45 bg-primary" />
                    </span>
                  )}
                  <span className="min-w-0">
                    <span className="block truncate font-medium text-fg">{find.name}</span>
                    <span className="block truncate text-sm text-muted">
                      {find.mineral} · {formatDate(find.date)}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
      <div className="mt-2 flex flex-wrap gap-2">
        <button
          type="button"
          className={btnQuiet}
          onClick={() => {
            void exportBackup().catch(() => onBanner("Sicherung konnte nicht gespeichert werden."));
          }}
        >
          <Download className="size-4" />
          Sichern
        </button>
        <button type="button" className={btnQuiet} onClick={() => fileRef.current?.click()}>
          <Upload className="size-4" />
          Laden
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          className="sr-only"
          onChange={(event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            void importBackup(file)
              .then((count) => onBanner(count ? `${count} Funde übernommen.` : "Nichts Neues in der Sicherung."))
              .catch(() => onBanner("Diese Datei ist keine Ader-Sicherung."));
          }}
        />
      </div>
    </div>
  );
}

function PlaceList({
  places,
  showPlaces,
  setShowPlaces,
  onOpen,
}: {
  places: typeof PLACES;
  showPlaces: boolean;
  setShowPlaces: (value: boolean) => void;
  onOpen: (id: string) => void;
}) {
  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm leading-relaxed text-muted">
        Bekannte Reviere zur Orientierung. Nationalpark, Privatgrund und Bergbau sind oft gesperrt — das ist kein Sammelrecht.
      </p>
      <button
        type="button"
        className={btnQuiet}
        aria-pressed={showPlaces}
        onClick={() => setShowPlaces(!showPlaces)}
      >
        {showPlaces ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
        {showPlaces ? "Orte auf der Karte" : "Orte ausgeblendet"}
      </button>
      <ul className="flex flex-col gap-2">
        {places.map((place) => (
          <li key={place.id}>
            <button
              type="button"
              onClick={() => onOpen(place.id)}
              className="w-full rounded-md border border-border bg-bg px-3 py-3 text-left hover:border-primary"
            >
              <span className="block font-medium text-fg">{place.name}</span>
              <span className="block text-sm text-muted">
                {place.mineral} · {place.region}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function TourList({
  tours,
  finds,
  onOpen,
  onCreate,
}: {
  tours: ReturnType<typeof useField.getState>["tours"];
  finds: Find[];
  onOpen: (id: string) => void;
  onCreate: () => Promise<void>;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <div className="flex flex-col gap-3">
      <button
        type="button"
        className={btnPrimary}
        disabled={busy}
        onClick={() => {
          setBusy(true);
          void onCreate().finally(() => setBusy(false));
        }}
      >
        <Route className="size-4" />
        Neue Tour
      </button>
      <p className="text-sm leading-relaxed text-muted">
        Hänge Punkte in der Reihenfolge an und fixiere die Tour, wenn die Runde steht.
      </p>
      {tours.length === 0 ? (
        <p className="font-display text-xl leading-snug text-fg">Noch keine Tour.</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {tours.map((tour) => (
            <li key={tour.id}>
              <button
                type="button"
                onClick={() => onOpen(tour.id)}
                className="w-full rounded-md border border-border bg-bg px-3 py-3 text-left hover:border-primary"
              >
                <span className="flex items-center gap-2 font-medium text-fg">
                  {tour.fixed ? <Lock className="size-4 text-primary" /> : <Route className="size-4 text-muted" />}
                  <span className="truncate">{tour.name.trim() || "Ohne Namen"}</span>
                </span>
                <span className="mt-1 block text-sm text-muted">
                  {tour.stopIds.length} Punkte · {formatKm(tourLengthKm(tour, finds))} Luftlinie
                  {tour.fixed ? " · fixiert" : ""}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function FindForm({
  editor,
  pin,
  setPin,
  userLoc,
  finds,
  photoUrls,
  onCancel,
  onSaved,
  onBanner,
}: {
  editor: EditorState;
  pin: { lat: number; lng: number } | null;
  setPin: (pin: { lat: number; lng: number }) => void;
  userLoc: { lat: number; lng: number } | null;
  finds: Find[];
  photoUrls: Record<string, string>;
  onCancel: () => void;
  onSaved: (id: string) => void;
  onBanner: (message: string) => void;
}) {
  const existing = finds.find((find) => find.id === editor.id);
  const [name, setName] = useState(existing?.name ?? editor.seed?.name ?? "");
  const initialMineral = existing?.mineral ?? editor.seed?.mineral ?? "Bergkristall";
  const known = (MINERALS as readonly string[]).includes(initialMineral);
  const [mineralPick, setMineralPick] = useState(known ? initialMineral : "Anderes");
  const [customMineral, setCustomMineral] = useState(known ? "" : initialMineral);
  const [notes, setNotes] = useState(existing?.notes ?? editor.seed?.notes ?? "");
  const [date, setDate] = useState(existing?.date || todayIso());
  const [latText, setLatText] = useState(pin ? String(pin.lat) : "");
  const [lngText, setLngText] = useState(pin ? String(pin.lng) : "");
  const [keepPhotoIds, setKeepPhotoIds] = useState<string[]>(existing?.photoIds ?? []);
  const [files, setFiles] = useState<Array<{ file: File; url: string }>>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!pin) return;
    setLatText(pin.lat.toFixed(5));
    setLngText(pin.lng.toFixed(5));
  }, [pin?.lat, pin?.lng]);

  const filesRef = useRef(files);
  filesRef.current = files;
  useEffect(() => {
    return () => {
      for (const item of filesRef.current) URL.revokeObjectURL(item.url);
    };
  }, []);

  const mineral = mineralPick === "Anderes" ? customMineral.trim() : mineralPick;
  const lat = parseCoord(latText);
  const lng = parseCoord(lngText);
  const outside = lat !== null && lng !== null && validCoord(lat, lng) && !inAustria(lat, lng);

  function pushCoords(nextLat: string, nextLng: string) {
    const parsedLat = parseCoord(nextLat);
    const parsedLng = parseCoord(nextLng);
    if (parsedLat === null || parsedLng === null || !validCoord(parsedLat, parsedLng)) return;
    setPin({ lat: parsedLat, lng: parsedLng });
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (lat === null || lng === null || !validCoord(lat, lng)) {
      setError("Koordinaten fehlen oder sind ungültig.");
      return;
    }
    setSaving(true);
    setError(null);
    const input: SaveFindInput = {
      id: editor.id,
      name,
      mineral,
      notes,
      date,
      lat,
      lng,
      keepPhotoIds,
      files: files.map((item) => item.file),
    };
    try {
      const id = await useField.getState().saveFind(input);
      onSaved(id);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Speichern fehlgeschlagen.");
      setSaving(false);
    }
  }

  return (
    <form className="flex flex-col gap-3" onSubmit={(event) => void onSubmit(event)}>
      <button type="button" className="inline-flex h-11 items-center gap-1 text-sm text-muted" onClick={onCancel}>
        <ChevronLeft className="size-4" />
        Zurück
      </button>
      <h2 className="font-display text-2xl text-fg">{editor.id ? "Fund bearbeiten" : "Neuer Fund"}</h2>
      <p className="text-sm text-muted">Ein Tipp auf die Karte verschiebt den Punkt.</p>
      <label className="flex flex-col gap-1 text-xs font-medium text-muted">
        Name
        <input className={clsx(fieldCls, "h-11")} value={name} maxLength={80} onChange={(event) => setName(event.target.value)} required />
      </label>
      <label className="flex flex-col gap-1 text-xs font-medium text-muted">
        Mineral
        <select
          className={clsx(fieldCls, "h-11")}
          value={mineralPick}
          onChange={(event) => setMineralPick(event.target.value)}
        >
          {MINERALS.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
      </label>
      {mineralPick === "Anderes" ? (
        <input
          className={clsx(fieldCls, "h-11")}
          value={customMineral}
          maxLength={40}
          placeholder="Mineral nennen"
          onChange={(event) => setCustomMineral(event.target.value)}
        />
      ) : null}
      <label className="flex flex-col gap-1 text-xs font-medium text-muted">
        Datum
        <input className={clsx(fieldCls, "h-11")} type="date" value={date} onChange={(event) => setDate(event.target.value)} />
      </label>
      <div className="grid grid-cols-2 gap-2">
        <label className="flex flex-col gap-1 text-xs font-medium text-muted">
          Breite
          <input
            className={clsx(fieldCls, "h-11")}
            inputMode="decimal"
            value={latText}
            onChange={(event) => {
              setLatText(event.target.value);
              pushCoords(event.target.value, lngText);
            }}
          />
        </label>
        <label className="flex flex-col gap-1 text-xs font-medium text-muted">
          Länge
          <input
            className={clsx(fieldCls, "h-11")}
            inputMode="decimal"
            value={lngText}
            onChange={(event) => {
              setLngText(event.target.value);
              pushCoords(latText, event.target.value);
            }}
          />
        </label>
      </div>
      {userLoc ? (
        <button
          type="button"
          className={btnQuiet}
          onClick={() => setPin(userLoc)}
        >
          Meinen Standort übernehmen
        </button>
      ) : null}
      {outside ? (
        <p className="text-sm text-muted">Liegt außerhalb von Österreich. Du kannst ihn trotzdem speichern.</p>
      ) : null}
      <label className="flex flex-col gap-1 text-xs font-medium text-muted">
        Notiz
        <textarea
          className={clsx(fieldCls, "min-h-24 py-2")}
          value={notes}
          maxLength={2000}
          onChange={(event) => setNotes(event.target.value)}
        />
      </label>
      <div className="flex flex-col gap-2">
        <span className="text-xs font-medium text-muted">Fotos</span>
        <div className="flex gap-2 overflow-x-auto">
          {keepPhotoIds.map((id) =>
            photoUrls[id] ? (
              <span key={id} className="relative shrink-0">
                <img src={photoUrls[id]} alt="" className="size-16 rounded-md object-cover" />
                <button
                  type="button"
                  className="absolute right-1 top-1 grid size-6 place-items-center rounded-full bg-bg text-fg"
                  aria-label="Foto entfernen"
                  onClick={() => setKeepPhotoIds((ids) => ids.filter((item) => item !== id))}
                >
                  <X className="size-3" />
                </button>
              </span>
            ) : null,
          )}
          {files.map((item) => (
            <span key={item.url} className="relative shrink-0">
              <img src={item.url} alt="" className="size-16 rounded-md object-cover" />
              <button
                type="button"
                className="absolute right-1 top-1 grid size-6 place-items-center rounded-full bg-bg text-fg"
                aria-label="Foto entfernen"
                onClick={() => {
                  URL.revokeObjectURL(item.url);
                  setFiles((current) => current.filter((entry) => entry.url !== item.url));
                }}
              >
                <X className="size-3" />
              </button>
            </span>
          ))}
        </div>
        <label className={clsx(btnQuiet, "cursor-pointer")}>
          <Camera className="size-4" />
          Foto hinzufügen
          <input
            type="file"
            accept="image/*"
            multiple
            className="sr-only"
            onChange={(event) => {
              const list = Array.from(event.target.files ?? []);
              event.target.value = "";
              const room = 6 - keepPhotoIds.length - files.length;
              if (room <= 0) {
                onBanner("Höchstens 6 Fotos pro Fund.");
                return;
              }
              const next = list.slice(0, room).map((file) => ({ file, url: URL.createObjectURL(file) }));
              setFiles((current) => [...current, ...next]);
            }}
          />
        </label>
      </div>
      {error ? <p className="text-sm text-fg">{error}</p> : null}
      <button type="submit" className={btnPrimary} disabled={saving || !name.trim()}>
        {saving ? "Speichert…" : "Fund speichern"}
      </button>
    </form>
  );
}

function Detail({
  detailKey,
  finds,
  photoUrls,
  onBack,
  onEdit,
  onAdopt,
  onBanner,
}: {
  detailKey: string;
  finds: Find[];
  photoUrls: Record<string, string>;
  onBack: () => void;
  onEdit: (id: string) => void;
  onAdopt: (placeId: string) => void;
  onBanner: (message: string) => void;
}) {
  const place = detailKey.startsWith("place:")
    ? PLACES.find((item) => item.id === detailKey.slice(6))
    : undefined;
  const find = place ? undefined : finds.find((item) => item.id === detailKey);
  const [photoIndex, setPhotoIndex] = useState(0);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const point = place
    ? { name: place.name, mineral: place.mineral, lat: place.lat, lng: place.lng, notes: place.note }
    : find
      ? { name: find.name, mineral: find.mineral, lat: find.lat, lng: find.lng, notes: find.notes }
      : null;

  const photos = useMemo(
    () => (find ? find.photoIds.map((id) => photoUrls[id]).filter(Boolean) : []),
    [find, photoUrls],
  );

  if (!point) {
    return (
      <button type="button" className="text-sm text-muted" onClick={onBack}>
        Zurück
      </button>
    );
  }

  const current = photos[photoIndex] ?? photos[0];

  return (
    <div className="flex flex-col gap-3">
      <button type="button" className="inline-flex h-11 items-center gap-1 text-sm text-muted" onClick={onBack}>
        <ChevronLeft className="size-4" />
        Zurück
      </button>
      {current ? (
        <img src={current} alt={point.name} className="aspect-square w-full rounded-md object-cover" />
      ) : null}
      {photos.length > 1 ? (
        <div className="flex gap-2">
          {photos.map((src, index) => (
            <button key={src} type="button" onClick={() => setPhotoIndex(index)} aria-label={`Foto ${index + 1}`}>
              <img
                src={src}
                alt=""
                className={clsx("size-12 rounded-md object-cover", index === photoIndex ? "ring-2 ring-primary" : "")}
              />
            </button>
          ))}
        </div>
      ) : null}
      <h2 className="font-display text-2xl leading-tight text-fg">{point.name}</h2>
      <p className="text-sm text-primary">{point.mineral}</p>
      {place ? <p className="text-sm text-muted">{place.region}</p> : null}
      {find ? <p className="text-sm text-muted">{formatDate(find.date)}</p> : null}
      <p className="text-sm text-fg">{formatCoords(point.lat, point.lng)}</p>
      {point.notes ? <p className="text-sm leading-relaxed text-fg">{point.notes}</p> : null}
      <button
        type="button"
        className={btnQuiet}
        onClick={() => {
          void navigator.clipboard?.writeText(`${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`).then(
            () => onBanner("Koordinaten kopiert."),
            () => onBanner("Kopieren nicht möglich."),
          );
        }}
      >
        Koordinaten kopieren
      </button>
      {find ? (
        <>
          <button type="button" className={btnPrimary} onClick={() => onEdit(find.id)}>
            Bearbeiten
          </button>
          {confirmDelete ? (
            <div className="flex flex-col gap-2 rounded-md border border-border p-3">
              <p className="text-sm text-fg">Fund und Fotos löschen? Er verschwindet auch aus Touren.</p>
              <button
                type="button"
                className={btnQuiet}
                onClick={() => {
                  void useField.getState().deleteFind(find.id).then(onBack);
                }}
              >
                <Trash2 className="size-4" />
                Endgültig löschen
              </button>
              <button type="button" className="h-11 text-sm text-muted" onClick={() => setConfirmDelete(false)}>
                Abbrechen
              </button>
            </div>
          ) : (
            <button type="button" className="h-11 text-sm text-muted" onClick={() => setConfirmDelete(true)}>
              Löschen
            </button>
          )}
        </>
      ) : place ? (
        <button type="button" className={btnPrimary} onClick={() => onAdopt(place.id)}>
          <Plus className="size-4" />
          Als eigenen Fund
        </button>
      ) : null}
    </div>
  );
}

function TourEditor({
  tourId,
  finds,
  recording,
  setRecording,
  onBack,
  onBanner,
}: {
  tourId: string;
  finds: Find[];
  recording: boolean;
  setRecording: (value: boolean) => void;
  onBack: () => void;
  onBanner: (message: string) => void;
}) {
  const tour = useField((state) => state.tours.find((item) => item.id === tourId));
  const patchTour = useField((state) => state.patchTour);
  const deleteTour = useField((state) => state.deleteTour);
  const removeStop = useField((state) => state.removeStop);
  const moveStop = useField((state) => state.moveStop);
  const addStop = useField((state) => state.addStop);
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (!tour) {
    return (
      <button type="button" className="text-sm text-muted" onClick={onBack}>
        Zurück
      </button>
    );
  }

  const km = tourLengthKm(tour, finds);

  return (
    <div className="flex flex-col gap-3">
      <button type="button" className="inline-flex h-11 items-center gap-1 text-sm text-muted" onClick={onBack}>
        <ChevronLeft className="size-4" />
        Alle Touren
      </button>
      <label className="flex flex-col gap-1 text-xs font-medium text-muted">
        Name
        <input
          className={clsx(fieldCls, "h-11 font-display text-lg")}
          value={tour.name}
          maxLength={80}
          onChange={(event) => void patchTour(tour.id, { name: event.target.value })}
        />
      </label>
      <label className="flex flex-col gap-1 text-xs font-medium text-muted">
        Datum
        <input
          className={clsx(fieldCls, "h-11")}
          type="date"
          value={tour.date}
          onChange={(event) => void patchTour(tour.id, { date: event.target.value })}
        />
      </label>
      {tour.fixed ? (
        <p className="rounded-md border border-border bg-bg px-3 py-3 text-sm leading-relaxed text-fg">
          <Lock className="mr-1 inline size-4 text-primary" />
          Fixiert. Reihenfolge und Punkte bleiben, bis du die Fixierung löst.
        </p>
      ) : (
        <p className="text-sm leading-relaxed text-muted">
          {recording
            ? "Tippe Funde oder Orte auf der Karte an. Sie hängen sich in dieser Reihenfolge an."
            : "Starte das Aufnehmen und tippe die Punkte auf der Karte an."}
        </p>
      )}
      <p className="text-sm text-fg">
        {tour.stopIds.length} Punkte · {formatKm(km)} Luftlinie
      </p>
      {!tour.fixed ? (
        <label className="flex flex-col gap-1 text-xs font-medium text-muted">
          Punkt anhängen
          <select
            className={clsx(fieldCls, "h-11")}
            value=""
            onChange={(event) => {
              const stopId = event.target.value;
              if (!stopId) return;
              void addStop(tour.id, stopId).then((added) => {
                if (!added) onBanner("Der Punkt ist schon in der Tour.");
              });
            }}
          >
            <option value="">Wählen…</option>
            {finds.length > 0 ? (
              <optgroup label="Eigene Funde">
                {finds.map((find) => (
                  <option key={find.id} value={find.id}>
                    {find.name}
                  </option>
                ))}
              </optgroup>
            ) : null}
            <optgroup label="Orientierung">
              {PLACES.map((place) => (
                <option key={place.id} value={placeStopId(place.id)}>
                  {place.name}
                </option>
              ))}
            </optgroup>
          </select>
        </label>
      ) : null}
      <ol className="flex flex-col gap-2">
        {tour.stopIds.map((stopId, index) => {
          const point = resolveStop(stopId, finds);
          if (!point) return null;
          return (
            <li key={`${stopId}-${index}`} className="flex items-center gap-2 rounded-md border border-border bg-bg px-2 py-2">
              <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-fg">
                {index + 1}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium text-fg">{point.name}</span>
                <span className="block truncate text-xs text-muted">
                  {point.mineral}
                  {point.kind === "place" ? " · Orientierung" : ""}
                </span>
              </span>
              {!tour.fixed ? (
                <span className="flex shrink-0">
                  <button type="button" className="grid size-9 place-items-center text-muted" aria-label="Nach oben" onClick={() => void moveStop(tour.id, index, -1)}>
                    <ArrowUp className="size-4" />
                  </button>
                  <button type="button" className="grid size-9 place-items-center text-muted" aria-label="Nach unten" onClick={() => void moveStop(tour.id, index, 1)}>
                    <ArrowDown className="size-4" />
                  </button>
                  <button type="button" className="grid size-9 place-items-center text-muted" aria-label="Punkt entfernen" onClick={() => void removeStop(tour.id, index)}>
                    <X className="size-4" />
                  </button>
                </span>
              ) : null}
            </li>
          );
        })}
      </ol>
      {!tour.fixed ? (
        <button type="button" className={recording ? btnPrimary : btnQuiet} onClick={() => setRecording(!recording)}>
          {recording ? "Aufnahme beenden" : "Punkte aufnehmen"}
        </button>
      ) : null}
      {tour.fixed ? (
        <button type="button" className={btnQuiet} onClick={() => void patchTour(tour.id, { fixed: false })}>
          <LockOpen className="size-4" />
          Fixierung lösen
        </button>
      ) : (
        <button
          type="button"
          className={btnPrimary}
          disabled={tour.stopIds.length < 2}
          onClick={() => {
            void patchTour(tour.id, { fixed: true, visible: true });
            setRecording(false);
            onBanner("Tour ist fixiert.");
          }}
        >
          <Lock className="size-4" />
          Tour fixieren
        </button>
      )}
      <button
        type="button"
        className={btnQuiet}
        onClick={() => void patchTour(tour.id, { visible: !tour.visible })}
      >
        {tour.visible ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
        {tour.visible ? "Auf der Karte" : "Auf der Karte aus"}
      </button>
      <label className="flex flex-col gap-1 text-xs font-medium text-muted">
        Notiz
        <textarea
          className={clsx(fieldCls, "min-h-24 py-2")}
          value={tour.notes}
          maxLength={2000}
          onChange={(event) => void patchTour(tour.id, { notes: event.target.value })}
        />
      </label>
      {tour.stopIds.length < 2 && !tour.fixed ? (
        <p className="text-sm text-muted">Zum Fixieren brauchst du mindestens zwei Punkte.</p>
      ) : null}
      {confirmDelete ? (
        <button
          type="button"
          className={btnQuiet}
          onClick={() => {
            void deleteTour(tour.id).then(onBack);
          }}
        >
          <Trash2 className="size-4" />
          Tour löschen
        </button>
      ) : (
        <button type="button" className="h-11 text-sm text-muted" onClick={() => setConfirmDelete(true)}>
          Tour löschen
        </button>
      )}
    </div>
  );
}
