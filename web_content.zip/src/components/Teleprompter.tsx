import React, { useState, useEffect, useRef } from 'react';
import { ScriptScene } from '../data/scriptData';
import {
  Play,
  Pause,
  RotateCcw,
  FlipHorizontal,
  Maximize2,
  Minimize2,
  Type,
  FastForward,
  Eye,
  Sliders,
} from 'lucide-react';

interface TeleprompterProps {
  scenes: ScriptScene[];
  selectedSceneIndex: number;
  setSelectedSceneIndex: (index: number) => void;
}

export const Teleprompter: React.FC<TeleprompterProps> = ({
  scenes,
  selectedSceneIndex,
  setSelectedSceneIndex,
}) => {
  const [isScrolling, setIsScrolling] = useState<boolean>(false);
  const [scrollSpeed, setScrollSpeed] = useState<number>(35); // pixels per sec
  const [fontSize, setFontSize] = useState<number>(32); // in px
  const [isMirrored, setIsMirrored] = useState<boolean>(false);
  const [showEyeLine, setShowEyeLine] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const lastTimestampRef = useRef<number | null>(null);

  // Smooth scroll loop using requestAnimationFrame
  useEffect(() => {
    if (!isScrolling) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      lastTimestampRef.current = null;
      return;
    }

    const scrollStep = (timestamp: number) => {
      if (!lastTimestampRef.current) lastTimestampRef.current = timestamp;
      const elapsed = timestamp - lastTimestampRef.current;
      lastTimestampRef.current = timestamp;

      if (containerRef.current) {
        const delta = (scrollSpeed * elapsed) / 1000;
        containerRef.current.scrollTop += delta;

        // Check if reached bottom
        if (
          containerRef.current.scrollTop + containerRef.current.clientHeight >=
          containerRef.current.scrollHeight - 10
        ) {
          setIsScrolling(false);
          return;
        }
      }

      animationFrameRef.current = requestAnimationFrame(scrollStep);
    };

    animationFrameRef.current = requestAnimationFrame(scrollStep);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isScrolling, scrollSpeed]);

  const handleReset = () => {
    setIsScrolling(false);
    if (containerRef.current) {
      containerRef.current.scrollTop = 0;
    }
  };

  const toggleFullscreen = () => {
    const elem = document.getElementById('teleprompter-box');
    if (!elem) return;

    if (!document.fullscreenElement) {
      elem.requestFullscreen().then(() => setIsFullscreen(true)).catch(console.error);
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(console.error);
    }
  };

  return (
    <div className="space-y-4 pb-28">
      {/* Controls Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsScrolling(!isScrolling)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition cursor-pointer shadow-lg ${
              isScrolling
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
            }`}
          >
            {isScrolling ? <Pause className="w-4 h-4 fill-slate-950" /> : <Play className="w-4 h-4 fill-slate-950" />}
            <span className="font-bengali">{isScrolling ? 'স্ক্রল থামান' : 'স্ক্রল শুরু করুন'}</span>
          </button>

          <button
            onClick={handleReset}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title="Reset to Top"
            aria-label="Reset scroll to top"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Speed & Font adjustments */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-bengali">
          {/* Scroll Speed */}
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
            <FastForward className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-400">গতি:</span>
            <input
              type="range"
              min="15"
              max="90"
              value={scrollSpeed}
              onChange={(e) => setScrollSpeed(parseInt(e.target.value, 10))}
              className="w-24 accent-emerald-500 cursor-pointer"
            />
            <span className="font-mono text-slate-200 w-8">{scrollSpeed}px</span>
          </div>

          {/* Font Size */}
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
            <Type className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-400">ফন্ট:</span>
            <input
              type="range"
              min="20"
              max="52"
              value={fontSize}
              onChange={(e) => setFontSize(parseInt(e.target.value, 10))}
              className="w-24 accent-cyan-500 cursor-pointer"
            />
            <span className="font-mono text-slate-200 w-8">{fontSize}px</span>
          </div>

          {/* Mirror & Eyeline Toggles */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsMirrored(!isMirrored)}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                isMirrored
                  ? 'bg-emerald-600 border-emerald-500 text-white'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Mirror Mode (for glass teleprompters)"
              aria-label="Toggle Mirror Mode"
            >
              <FlipHorizontal className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowEyeLine(!showEyeLine)}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                showEyeLine
                  ? 'bg-cyan-600 border-cyan-500 text-white'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Toggle Eye-Line Guide"
              aria-label="Toggle Eye-Line Guide"
            >
              <Eye className="w-4 h-4" />
            </button>

            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              title="Toggle Fullscreen"
              aria-label="Toggle Fullscreen"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Teleprompter Display Box */}
      <div
        id="teleprompter-box"
        className="relative rounded-2xl bg-black border border-slate-800 shadow-2xl overflow-hidden h-[65vh] flex flex-col"
      >
        {/* Eye line indicator overlay */}
        {showEyeLine && (
          <div className="absolute top-1/3 inset-x-0 h-16 border-y border-emerald-500/30 bg-emerald-500/5 pointer-events-none z-20 flex items-center justify-between px-4">
            <span className="text-[10px] font-mono text-emerald-400/60 uppercase tracking-widest">
              Camera Lens Eyeline
            </span>
            <span className="text-[10px] font-mono text-emerald-400/60 uppercase tracking-widest">
              দৃষ্টি স্থির রাখুন
            </span>
          </div>
        )}

        {/* Scrollable Script Area */}
        <div
          ref={containerRef}
          className={`flex-1 overflow-y-auto px-6 sm:px-16 py-32 scrollbar-none transition-transform duration-200 select-none ${
            isMirrored ? 'scale-x-[-1]' : ''
          }`}
          style={{ scrollBehavior: 'auto' }}
        >
          <div className="max-w-4xl mx-auto space-y-16">
            {scenes.map((scene, idx) => (
              <div key={scene.id} className="space-y-4">
                <div className="inline-block px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-emerald-400 font-mono text-sm">
                  Scene #{scene.order}: {scene.titleBn}
                </div>
                <p
                  className="font-bengali text-slate-100 font-semibold leading-relaxed tracking-wide"
                  style={{ fontSize: `${fontSize}px`, lineHeight: 1.6 }}
                >
                  {scene.textBn}
                </p>
              </div>
            ))}
            {/* Generous bottom padding for complete read */}
            <div className="h-48 flex items-center justify-center text-slate-600 font-mono text-sm">
              — স্ক্রিপ্ট সমাপ্ত (End of Script) —
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
