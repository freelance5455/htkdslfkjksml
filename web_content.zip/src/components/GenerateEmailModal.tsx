import React, { useState } from 'react';
import { X, Sparkles, Clock, Globe, ArrowRight } from 'lucide-react';
import { LIVE_DOMAINS } from '../services/realTempMail.ts';

interface GenerateEmailModalProps {
  onClose: () => void;
  onGenerate: (username?: string, domain?: string, duration?: '10m' | '1h' | '24h' | '7d') => void;
}

export const GenerateEmailModal: React.FC<GenerateEmailModalProps> = ({ onClose, onGenerate }) => {
  const [mode, setMode] = useState<'random' | 'custom'>('random');
  const [customUser, setCustomUser] = useState('');
  const [selectedDomain, setSelectedDomain] = useState(LIVE_DOMAINS[0].domain);
  const [selectedDuration, setSelectedDuration] = useState<'10m' | '1h' | '24h' | '7d'>('24h');
  const [randomSeed, setRandomSeed] = useState(() => 'user' + Math.random().toString(36).substring(2, 8));

  const handleRandomize = () => {
    setRandomSeed(Math.random().toString(36).substring(2, 8));
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'custom') {
      const clean = customUser.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '');
      if (!clean) return;
      onGenerate(clean, selectedDomain, selectedDuration);
    } else {
      onGenerate(randomSeed, selectedDomain, selectedDuration);
    }
  };

  const previewAddress = `${mode === 'custom' ? (customUser.trim() || 'username') : randomSeed}@${selectedDomain}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 shadow-2xl relative text-slate-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mb-4">
          <Sparkles className="w-6 h-6" />
        </div>

        <h3 className="text-xl font-bold text-slate-900 mb-1">New Disposable Address</h3>
        <p className="text-xs text-slate-500 mb-5">
          Generate an untraceable email address to receive activation links and verification codes securely.
        </p>

        {/* Tab Selection */}
        <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl border border-slate-200 mb-5">
          <button
            type="button"
            onClick={() => setMode('random')}
            className={`py-2 text-xs font-bold rounded-lg transition-colors ${
              mode === 'random' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Address
          </button>
          <button
            type="button"
            onClick={() => setMode('custom')}
            className={`py-2 text-xs font-bold rounded-lg transition-colors ${
              mode === 'custom' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Custom Username
          </button>
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          {mode === 'custom' ? (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Choose Username</label>
              <div className="relative">
                <input
                  type="text"
                  value={customUser}
                  onChange={(e) => setCustomUser(e.target.value.toLowerCase())}
                  placeholder="e.g. dev-signup-42"
                  className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 font-mono"
                  required
                />
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-700">Generated Alias</label>
                <button
                  type="button"
                  onClick={handleRandomize}
                  className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-bold"
                >
                  <Sparkles className="w-3 h-3" />
                  Reroll
                </button>
              </div>
              <div className="bg-blue-50/70 border border-blue-200 rounded-xl px-3.5 py-2.5 font-mono text-sm text-blue-700 font-bold">
                {randomSeed}
              </div>
            </div>
          )}

          {/* Domain Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              <span>Select Domain</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {LIVE_DOMAINS.map((item) => (
                <button
                  type="button"
                  key={item.domain}
                  onClick={() => setSelectedDomain(item.domain)}
                  className={`px-3 py-2 rounded-xl text-xs font-mono text-left border transition-all ${
                    selectedDomain === item.domain
                      ? 'bg-blue-50 border-blue-500 text-blue-700 font-bold shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-blue-200'
                  }`}
                >
                  @{item.domain}
                </button>
              ))}
            </div>
          </div>

          {/* Lifetime Options */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              <span>Lifetime Duration</span>
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(
                [
                  { id: '10m', label: '10 Min' },
                  { id: '1h', label: '1 Hour' },
                  { id: '24h', label: '24 Hours' },
                  { id: '7d', label: '7 Days 👑' },
                ] as const
              ).map((tier) => (
                <button
                  type="button"
                  key={tier.id}
                  onClick={() => setSelectedDuration(tier.id)}
                  className={`py-2 rounded-xl text-xs font-semibold border text-center transition-all ${
                    selectedDuration === tier.id
                      ? 'bg-blue-600 border-blue-600 text-white shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-blue-200'
                  }`}
                >
                  {tier.label}
                </button>
              ))}
            </div>
          </div>

          {/* Preview Box */}
          <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3 flex items-center justify-between">
            <span className="text-[11px] text-blue-800 uppercase tracking-wider font-bold">Ready Address:</span>
            <span className="text-xs font-mono text-blue-700 font-bold truncate max-w-[240px]">
              {previewAddress}
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors shadow-sm shadow-blue-600/25 active:scale-98 cursor-pointer"
          >
            <span>Create Inbox</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
