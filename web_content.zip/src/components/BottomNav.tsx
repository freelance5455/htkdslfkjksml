import React from 'react';
import { Zap, Sun, Radio, Settings2, Moon } from 'lucide-react';
import { soundService } from '../utils/sound';

interface BottomNavProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  isOled: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  isOled,
}) => {
  const tabs = [
    { id: 'main', label: 'Svítilna', icon: Zap },
    { id: 'screen', label: 'Displej', icon: Sun },
    { id: 'strobe', label: 'Stroboskop', icon: Radio },
    { id: 'settings', label: 'OLED & Shake', icon: Moon },
  ];

  return (
    <nav
      className={`fixed bottom-0 left-0 right-0 z-40 border-t transition-colors ${
        isOled
          ? 'bg-black/95 border-neutral-900 backdrop-blur-md'
          : 'bg-[#070b14]/95 border-slate-800/80 backdrop-blur-md'
      }`}
    >
      <div className="grid grid-cols-4 max-w-md mx-auto items-center h-16 px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                soundService.playTick();
                onSelectTab(tab.id);
              }}
              className={`flex flex-col items-center justify-center min-h-[48px] min-w-[48px] py-1 cursor-pointer transition-colors ${
                isActive ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon
                className={`w-5 h-5 transition-transform ${
                  isActive ? 'scale-110 drop-shadow-[0_0_8px_#00F0FF]' : ''
                }`}
              />
              <span
                className={`text-[10px] font-medium tracking-tight mt-1 truncate ${
                  isActive ? 'font-bold text-cyan-400' : ''
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
