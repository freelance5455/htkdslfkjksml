import React from 'react';
import { Home, History, User } from 'lucide-react';
import { ScreenType, BottomTabType } from '../types';

interface BottomNavProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  unreadNotificationsCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentScreen,
  onNavigate,
}) => {
  const getTabKey = (screen: ScreenType): BottomTabType | null => {
    if (screen === 'home') return 'home';
    if (screen === 'history') return 'history';
    if (screen === 'profile') return 'profile';
    return null;
  };

  const activeTab = getTabKey(currentScreen);

  // If we are on splash or welcome, don't show bottom nav
  if (currentScreen === 'splash' || currentScreen === 'welcome') {
    return null;
  }

  const navItems = [
    {
      id: 'home' as ScreenType,
      tab: 'home' as BottomTabType,
      label: 'Home',
      icon: Home,
    },
    {
      id: 'history' as ScreenType,
      tab: 'history' as BottomTabType,
      label: 'History',
      icon: History,
    },
    {
      id: 'profile' as ScreenType,
      tab: 'profile' as BottomTabType,
      label: 'Profile',
      icon: User,
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/95 backdrop-blur-md border-t border-slate-200/80 px-3 py-2 z-40 android-shadow">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.tab;

          return (
            <button
              key={item.tab}
              onClick={() => onNavigate(item.id)}
              className="group relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 focus:outline-none"
            >
              <div
                className={`relative px-5 py-1.5 rounded-full transition-all duration-300 flex items-center justify-center ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/25 scale-105'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              </div>
              <span
                className={`text-[11px] mt-1 font-medium tracking-tight transition-colors ${
                  isActive ? 'text-blue-700 font-bold' : 'text-slate-500'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
