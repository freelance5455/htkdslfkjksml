import React from 'react';
import { Clock, History, Info } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  historyCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  historyCount = 0,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200/80 pb-safe shadow-lg">
      <div className="max-w-md mx-auto flex items-center justify-around py-2 px-3">
        {/* Converter Tab */}
        <button
          type="button"
          onClick={() => onTabChange('converter')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-2 rounded-xl transition-colors ${
            activeTab === 'converter'
              ? 'text-blue-600 font-semibold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            <div
              className={`p-1 rounded-full transition-transform ${
                activeTab === 'converter' ? 'bg-blue-50 text-blue-600 scale-105' : ''
              }`}
            >
              <Clock className="w-5 h-5 stroke-[2]" />
            </div>
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">Converter</span>
        </button>

        {/* History Tab */}
        <button
          type="button"
          onClick={() => onTabChange('history')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-2 rounded-xl transition-colors ${
            activeTab === 'history'
              ? 'text-blue-600 font-semibold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            <div
              className={`p-1 rounded-full transition-transform ${
                activeTab === 'history' ? 'bg-blue-50 text-blue-600 scale-105' : ''
              }`}
            >
              <History className="w-5 h-5 stroke-[2]" />
            </div>
            {historyCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-blue-600 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full min-w-[16px] text-center">
                {historyCount > 99 ? '99+' : historyCount}
              </span>
            )}
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">History</span>
        </button>

        {/* About Tab */}
        <button
          type="button"
          onClick={() => onTabChange('about')}
          className={`flex flex-col items-center justify-center flex-1 py-1 px-2 rounded-xl transition-colors ${
            activeTab === 'about'
              ? 'text-blue-600 font-semibold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            <div
              className={`p-1 rounded-full transition-transform ${
                activeTab === 'about' ? 'bg-blue-50 text-blue-600 scale-105' : ''
              }`}
            >
              <Info className="w-5 h-5 stroke-[2]" />
            </div>
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight">About</span>
        </button>
      </div>

      {/* Android bottom home bar pill simulation */}
      <div className="w-32 h-1 bg-slate-900/40 rounded-full mx-auto mb-1.5 hidden sm:block"></div>
    </nav>
  );
};
