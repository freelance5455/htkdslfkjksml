import React from 'react';
import { 
  BarChart3, 
  LineChart, 
  Sparkles, 
  Mic, 
  Star, 
  Briefcase
} from 'lucide-react';
import { AppTab, ThemeMode, AppLanguage } from '../types/market';
import { getTranslation } from '../i18n/translations';

interface BottomNavProps {
  currentTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  activeAlertsCount: number;
  watchlistCount: number;
  theme: ThemeMode;
  language?: AppLanguage;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  activeAlertsCount,
  watchlistCount,
  theme,
  language = 'fr',
}) => {
  const isLight = theme === 'light';

  const navItems: Array<{
    id: AppTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    highlight?: boolean;
  }> = [
    { id: 'marche', label: getTranslation(language, 'tab_marche', 'Marché'), icon: BarChart3 },
    { id: 'graph', label: getTranslation(language, 'tab_graph', 'Graph'), icon: LineChart },
    { id: 'iasignals', label: getTranslation(language, 'tab_iasignals', 'IA Signals'), icon: Sparkles, highlight: true },
    { id: 'alerte', label: getTranslation(language, 'tab_alerte', 'Studio'), icon: Mic, badge: activeAlertsCount },
    { id: 'watchlist', label: getTranslation(language, 'tab_watchlist', 'Watchlist'), icon: Star, badge: watchlistCount },
    { id: 'portfolio', label: getTranslation(language, 'tab_portfolio', 'Portfolio'), icon: Briefcase },
  ];

  return (
    <div className={`fixed bottom-0 left-0 right-0 z-40 border-t backdrop-blur-xl transition-colors duration-200 pb-[env(safe-area-inset-bottom)] ${
      isLight 
        ? 'bg-white/90 border-slate-200/90 shadow-lg shadow-slate-200/50' 
        : 'bg-slate-950/90 border-slate-800/90 shadow-2xl shadow-black/80'
    }`}>
      <div className="max-w-3xl mx-auto px-2 sm:px-4">
        <div className="flex items-center justify-around h-16 sm:h-18">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
                    try { navigator.vibrate(12); } catch { /* ignore */ }
                  }
                  onSelectTab(item.id);
                }}
                className={`relative flex flex-col items-center justify-center flex-1 h-full py-1 px-1 transition-all cursor-pointer group ${
                  isActive
                    ? isLight
                      ? 'text-amber-600 font-bold'
                      : 'text-amber-400 font-bold'
                    : isLight
                    ? 'text-slate-500 hover:text-slate-800'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {/* Active Indicator Top Pill */}
                {isActive && (
                  <span className={`absolute top-0 w-8 h-1 rounded-full ${
                    item.highlight 
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 shadow-sm shadow-purple-500/50' 
                      : 'bg-amber-500 shadow-sm shadow-amber-500/50'
                  }`} />
                )}

                <div className="relative flex items-center justify-center">
                  <div className={`p-1.5 rounded-xl transition-transform ${
                    isActive 
                      ? isLight ? 'bg-amber-100 scale-105' : 'bg-amber-500/15 scale-105' 
                      : 'group-hover:scale-105'
                  }`}>
                    <Icon className={`w-5 h-5 ${
                      item.highlight && !isActive
                        ? isLight ? 'text-purple-600' : 'text-purple-400'
                        : ''
                    }`} />
                  </div>

                  {/* Badge */}
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="absolute -top-1 -right-1 px-1.5 py-0.2 min-w-4 text-[10px] font-mono font-bold rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-sm">
                      {item.badge}
                    </span>
                  )}
                </div>

                <span className="text-[11px] font-medium tracking-tight mt-0.5 truncate max-w-[64px]">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
