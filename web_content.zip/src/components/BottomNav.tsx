import React from 'react';
import { CheckSquare, LayoutGrid, Sparkles, CalendarDays, BarChart3 } from 'lucide-react';

export type TabType = 'routine' | 'categories' | 'transform' | 'calendar' | 'analytics';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  pendingCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  pendingCount,
}) => {
  const tabs = [
    {
      id: 'routine' as TabType,
      label: 'Routine',
      icon: CheckSquare,
      badge: pendingCount > 0 ? pendingCount : null,
    },
    {
      id: 'categories' as TabType,
      label: 'Habits',
      icon: LayoutGrid,
    },
    {
      id: 'transform' as TabType,
      label: '90-Day',
      icon: Sparkles,
    },
    {
      id: 'calendar' as TabType,
      label: 'History',
      icon: CalendarDays,
    },
    {
      id: 'analytics' as TabType,
      label: 'Insights',
      icon: BarChart3,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-[#0B0C10]/90 backdrop-blur-lg border-t border-slate-200/80 dark:border-slate-800/80 safe-area-pb">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onChangeTab(tab.id)}
              className={`relative flex flex-col items-center justify-center min-h-[44px] py-1 transition-all group ${
                isActive
                  ? 'text-purple-600 dark:text-purple-400 font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
              aria-label={tab.label}
              aria-current={isActive ? 'page' : undefined}
            >
              {/* Active top pill indicator */}
              {isActive && (
                <span className="absolute top-0.5 w-6 h-0.5 rounded-full bg-purple-600 dark:bg-purple-400" />
              )}

              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'scale-110 stroke-[2.2]' : 'group-hover:scale-105'
                  }`}
                />
                {tab.badge !== null && tab.badge !== undefined && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 px-1 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center tabular-nums shadow-sm">
                    {tab.badge}
                  </span>
                )}
              </div>

              <span className="text-[11px] tracking-tight mt-1 truncate">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
