export type Tab = "home" | "games" | "perf" | "settings";
const items: { id: Tab; icon: string; label: string }[] = [
  { id: "home", icon: "🏠", label: "Home" },
  { id: "games", icon: "🎮", label: "Games" },
  { id: "perf", icon: "📊", label: "Perf" },
  { id: "settings", icon: "⚙️", label: "Settings" },
];
export default function BottomNav({ active, onChange }: { active: Tab; onChange: (t: Tab) => void }) {
  return (
    <nav className="nav">
      {items.map((i) => (
        <button key={i.id} className={active === i.id ? "on" : ""} onClick={() => onChange(i.id)}>
          <b>{i.icon}</b>{i.label}
        </button>
      ))}
    </nav>
  );
}
