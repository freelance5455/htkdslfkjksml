import React from 'react';
import { Pickaxe, Zap, Gift, Wallet, Users } from 'lucide-react';
import { useAudioFeedback } from '../hooks/useAudioFeedback';

export type TabId = 'tap' | 'boost' | 'earn' | 'withdraw' | 'friends';

interface BottomNavProps {
  activeTab: TabId;
  onChangeTab: (tab: TabId) => void;
  canClaimDaily: boolean;
  canWithdraw: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  canClaimDaily,
  canWithdraw,
}) => {
  const { playButtonClick } = useAudioFeedback();

  const tabs = [
    { id: 'tap' as TabId, label: 'Tap', icon: Pickaxe, badge: false },
    { id: 'boost' as TabId, label: 'Boost', icon: Zap, badge: false },
    { id: 'earn' as TabId, label: 'Earn', icon: Gift, badge: canClaimDaily },
    { id: 'withdraw' as TabId, label: 'Withdraw', icon: Wallet, badge: canWithdraw },
    { id: 'friends' as TabId, label: 'Friends', icon: Users, badge: false },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800/80 px-2 pb-safe">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => {
                playButtonClick();
                onChangeTab(tab.id);
              }}
              className={`relative min-h-[48px] flex flex-col items-center justify-center py-1 transition-all group ${
                isActive ? 'text-amber-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 stroke-[2.4]' : 'scale-100 stroke-[1.8]'
                  }`}
                />
                {tab.badge && (
                  <span className="absolute -top-1 -right-1.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
                )}
              </div>
              <span
                className={`text-[11px] font-medium tracking-tight mt-1 whitespace-nowrap truncate ${
                  isActive ? 'text-amber-400 font-bold' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute top-0 w-8 h-0.5 bg-gradient-to-r from-amber-400 to-yellow-300 rounded-full shadow-sm shadow-amber-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
