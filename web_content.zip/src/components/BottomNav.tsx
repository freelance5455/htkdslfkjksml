import React from 'react';
import { Home, MessageSquare, PlusCircle, History, Settings } from 'lucide-react';
import { NavTab } from '../types';

interface BottomNavProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  unreadCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const tabs: { id: NavTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'chat', label: 'Chat', icon: MessageSquare },
    { id: 'create', label: 'Create', icon: PlusCircle },
    { id: 'history', label: 'History', icon: History },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/95 border-t border-amber-500/20 backdrop-blur-lg px-2 py-2 shadow-2xl">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative flex flex-col items-center justify-center min-w-[56px] min-h-[44px] py-1 px-2 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-amber-300 font-semibold scale-105'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              {/* Gold glow backdrop when active */}
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-t from-amber-500/20 to-amber-500/5 rounded-xl border border-amber-500/30 -z-10 shadow-xs"></div>
              )}

              <Icon
                className={`w-5 h-5 transition-transform duration-200 ${
                  isActive ? 'text-amber-400 drop-shadow-[0_0_8px_rgba(245,208,97,0.5)]' : ''
                }`}
              />
              <span className="text-[10px] mt-1 tracking-tight">{tab.label}</span>

              {/* Indicator dot */}
              {isActive && (
                <span className="absolute -top-1 w-1.5 h-1.5 bg-amber-400 rounded-full shadow-[0_0_6px_#f5d061]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
