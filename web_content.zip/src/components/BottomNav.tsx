import React from 'react';
import { LayoutDashboard, CalendarCheck, Target, MoonStar, User, Plus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ActiveTab } from '../types';

interface BottomNavProps {
  onOpenQuickAdd: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ onOpenQuickAdd }) => {
  const { activeTab, setActiveTab, t } = useApp();

  const navItems: Array<{ id: ActiveTab; label: string; icon: React.ReactNode }> = [
    {
      id: 'dashboard',
      label: t.navDashboard,
      icon: <LayoutDashboard size={20} />,
    },
    {
      id: 'planner',
      label: t.navPlanner,
      icon: <CalendarCheck size={20} />,
    },
    {
      id: 'habits',
      label: t.navHabits,
      icon: <Target size={20} />,
    },
    {
      id: 'prayer',
      label: t.navPrayer,
      icon: <MoonStar size={20} />,
    },
    {
      id: 'profile',
      label: t.navProfile,
      icon: <User size={20} />,
    },
  ];

  return (
    <>
      {/* Spacer so content doesn't hide behind fixed bottom bar */}
      <div className="h-20 sm:h-22" />

      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/85 dark:bg-slate-900/85 backdrop-blur-xl border-t border-slate-200/60 dark:border-slate-800/60 shadow-[0_-8px_30px_rgba(0,0,0,0.04)] dark:shadow-[0_-8px_30px_rgba(0,0,0,0.35)] transition-colors">
        <div className="max-w-md mx-auto px-2 py-2 flex items-center justify-between relative">
          {/* Left two items */}
          <div className="flex items-center justify-around flex-1">
            {navItems.slice(0, 2).map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-2xl transition-all relative ${
                    isActive
                      ? 'text-violet-600 dark:text-violet-400 font-bold scale-[1.02]'
                      : 'text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-medium'
                  }`}
                >
                  <div className={`p-1.5 rounded-xl transition-all ${
                    isActive 
                      ? 'bg-violet-100 dark:bg-violet-950/70 shadow-xs' 
                      : 'hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
                  }`}>
                    {item.icon}
                  </div>
                  <span className="text-[11px] tracking-tight mt-1 leading-none">{item.label}</span>
                  {isActive && (
                    <span className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-violet-600 dark:bg-violet-400" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Center Floating Quick-Add Action Button */}
          <div className="relative -top-4 flex items-center justify-center px-1">
            <button
              onClick={onOpenQuickAdd}
              className="w-13 h-13 rounded-2xl bg-linear-to-tr from-violet-600 via-indigo-600 to-sky-500 hover:from-violet-500 hover:to-indigo-500 text-white shadow-xl shadow-violet-500/35 hover:shadow-violet-500/50 flex items-center justify-center active:scale-90 transition-all group ring-4 ring-white dark:ring-slate-900"
              aria-label={t.quickAdd}
            >
              <Plus size={24} className="group-hover:rotate-90 transition-transform duration-300 stroke-[2.5]" />
            </button>
          </div>

          {/* Right three items */}
          <div className="flex items-center justify-around flex-1">
            {navItems.slice(2).map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex flex-col items-center justify-center py-1 px-2 rounded-2xl transition-all relative ${
                    isActive
                      ? 'text-violet-600 dark:text-violet-400 font-bold scale-[1.02]'
                      : 'text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-medium'
                  }`}
                >
                  <div className={`p-1.5 rounded-xl transition-all ${
                    isActive 
                      ? 'bg-violet-100 dark:bg-violet-950/70 shadow-xs' 
                      : 'hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
                  }`}>
                    {item.icon}
                  </div>
                  <span className="text-[11px] tracking-tight mt-1 leading-none text-center">{item.label}</span>
                  {isActive && (
                    <span className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-violet-600 dark:bg-violet-400" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    </>
  );
};
