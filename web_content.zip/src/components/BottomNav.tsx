import React from 'react';
import { Home, Layers, Clock, Compass, Heart, Settings } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TabType } from '../types';
import { triggerVibration } from '../utils/audioFeedback';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, favorites } = useApp();

  const tabs: {
    id: TabType;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
  }[] = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'list', label: 'الأذكار', icon: Layers },
    { id: 'prayer_times', label: 'المواقيت', icon: Clock },
    { id: 'qibla', label: 'القبلة', icon: Compass },
    { id: 'favorites', label: 'المفضلة', icon: Heart, badge: favorites.length },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  return (
    <nav 
      aria-label="شريط التنقل السفلي"
      style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 4px)' }}
      className="fixed bottom-0 left-0 right-0 z-30 bg-[#ffffff]/98 dark:bg-[#021811]/98 backdrop-blur-md border-t border-emerald-600/20 dark:border-emerald-800/80 shadow-xl select-none"
    >
      <div className="max-w-md mx-auto grid grid-cols-6 items-center h-16 px-0.5">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id || (tab.id === 'list' && activeTab === 'morning_evening');

          return (
            <button
              key={tab.id}
              onClick={() => {
                triggerVibration(true, 'light');
                setActiveTab(tab.id);
              }}
              className={`flex flex-col items-center justify-center h-full min-h-[48px] px-0.5 transition-all relative cursor-pointer ${
                isActive 
                  ? 'text-emerald-700 dark:text-emerald-300 font-bold' 
                  : 'text-[#4d7d67] dark:text-[#7ba993] hover:text-emerald-700 dark:hover:text-emerald-300'
              }`}
            >
              <div className="relative">
                <Icon className={`w-4.5 h-4.5 transition-transform ${isActive ? 'scale-110 text-emerald-700 dark:text-emerald-300 stroke-[2.2]' : 'stroke-[1.8]'}`} />
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1 -right-2 min-w-3.5 h-3.5 px-0.5 rounded-full bg-emerald-600 text-white text-[8px] flex items-center justify-center font-bold shadow-2xs">
                    {tab.badge}
                  </span>
                )}
              </div>

              <span className={`text-[10px] font-tajawal mt-1 tracking-tight truncate max-w-full ${isActive ? 'font-bold text-emerald-700 dark:text-emerald-300' : 'font-medium'}`}>
                {tab.label}
              </span>

              {isActive && (
                <span className="w-1.5 h-1 rounded-full bg-emerald-500 absolute bottom-1 shadow-xs" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
