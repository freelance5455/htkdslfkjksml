import React from 'react';
import { Flame, Trophy, Swords, Wallet, User as UserIcon } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab, language } = useApp();

  const tabs = [
    { id: 'home', label: language === 'bn' ? 'হোম' : 'Home', icon: Flame },
    { id: 'tournaments', label: language === 'bn' ? 'টুর্নামেন্ট' : 'Matches', icon: Swords },
    { id: 'my-matches', label: language === 'bn' ? 'আমার ম্যাচ' : 'My Matches', icon: Trophy },
    { id: 'wallet', label: language === 'bn' ? 'ওয়ালেট' : 'Wallet', icon: Wallet },
    { id: 'profile', label: language === 'bn' ? 'প্রোফাইল' : 'Profile', icon: UserIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#090c12]/95 backdrop-blur-lg border-t border-red-950/40 md:hidden">
      <div className="grid grid-cols-5 h-16 max-w-md mx-auto items-center">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id)}
              className="flex flex-col items-center justify-center h-full min-h-[44px] py-1 transition-all active:scale-95"
            >
              <div className={`relative p-1 rounded-xl transition-all ${
                isActive ? 'text-red-500 scale-110' : 'text-slate-400 hover:text-slate-200'
              }`}>
                <Icon className="w-5 h-5" />
                {isActive && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-red-500 rounded-full" />
                )}
              </div>
              <span className={`text-[10px] font-medium tracking-tight mt-0.5 ${
                isActive ? 'text-white font-semibold' : 'text-slate-400'
              }`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
