import React from 'react';
import { Home, Users, Settings } from 'lucide-react';

interface BottomNavProps {
  activeTab: 'home' | 'customers' | 'settings';
  lang: 'bn' | 'en';
  onTabChange: (tab: 'home' | 'customers' | 'settings') => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  lang,
  onTabChange,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 shadow-lg px-6 py-2 print:hidden">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {/* Left: Customer Contact */}
        <button
          onClick={() => onTabChange('customers')}
          className={`flex flex-col items-center gap-1 py-1 px-4 rounded-2xl transition-all cursor-pointer ${
            activeTab === 'customers'
              ? 'text-indigo-600 font-bold scale-105'
              : 'text-slate-500 hover:text-slate-900 font-medium'
          }`}
        >
          <div
            className={`p-1.5 rounded-xl ${
              activeTab === 'customers' ? 'bg-indigo-50' : 'bg-transparent'
            }`}
          >
            <Users className="w-5 h-5" />
          </div>
          <span className="text-[11px] leading-none">
            {lang === 'bn' ? 'কন্টাক্ট' : 'Contacts'}
          </span>
        </button>

        {/* Center: Home / Dashboard */}
        <button
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center gap-1 py-1 px-4 rounded-2xl transition-all cursor-pointer ${
            activeTab === 'home'
              ? 'text-blue-600 font-bold scale-105'
              : 'text-slate-500 hover:text-slate-900 font-medium'
          }`}
        >
          <div
            className={`p-1.5 rounded-xl ${
              activeTab === 'home' ? 'bg-blue-50' : 'bg-transparent'
            }`}
          >
            <Home className="w-5 h-5" />
          </div>
          <span className="text-[11px] leading-none">
            {lang === 'bn' ? 'হোম' : 'Home'}
          </span>
        </button>

        {/* Right: Settings */}
        <button
          onClick={() => onTabChange('settings')}
          className={`flex flex-col items-center gap-1 py-1 px-4 rounded-2xl transition-all cursor-pointer ${
            activeTab === 'settings'
              ? 'text-slate-900 font-bold scale-105'
              : 'text-slate-500 hover:text-slate-900 font-medium'
          }`}
        >
          <div
            className={`p-1.5 rounded-xl ${
              activeTab === 'settings' ? 'bg-slate-100' : 'bg-transparent'
            }`}
          >
            <Settings className="w-5 h-5" />
          </div>
          <span className="text-[11px] leading-none">
            {lang === 'bn' ? 'সেটিংস' : 'Settings'}
          </span>
        </button>
      </div>
    </div>
  );
};
