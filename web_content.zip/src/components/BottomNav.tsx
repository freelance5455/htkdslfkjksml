import React from 'react';
import { Activity, Star, User } from 'lucide-react';
import { soundManager } from '../utils/soundEffects';

export type TabType = 'trade' | 'reviews' | 'profile';

interface BottomNavProps {
  currentTab: TabType;
  onChangeTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onChangeTab }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0e0408]/95 backdrop-blur-md border-t border-[#31101e] px-4 py-2">
      <div className="max-w-md mx-auto grid grid-cols-3 gap-2">
        {/* Trade Tab */}
        <button
          onClick={() => {
            soundManager.playPip();
            onChangeTab('trade');
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentTab === 'trade'
              ? 'text-red-500 font-extrabold scale-105'
              : 'text-zinc-500 hover:text-zinc-300 font-medium'
          }`}
        >
          <Activity className={`w-5 h-5 mb-0.5 ${currentTab === 'trade' ? 'text-red-500 drop-shadow-[0_0_6px_rgba(239,68,68,0.7)]' : ''}`} />
          <span className="text-[10px] tracking-wider uppercase font-mono">TRADE</span>
        </button>

        {/* Reviews Tab */}
        <button
          onClick={() => {
            soundManager.playPip();
            onChangeTab('reviews');
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentTab === 'reviews'
              ? 'text-red-500 font-extrabold scale-105'
              : 'text-zinc-500 hover:text-zinc-300 font-medium'
          }`}
        >
          <Star className={`w-5 h-5 mb-0.5 ${currentTab === 'reviews' ? 'text-red-500 fill-red-500 drop-shadow-[0_0_6px_rgba(239,68,68,0.7)]' : ''}`} />
          <span className="text-[10px] tracking-wider uppercase font-mono">REVIEWS</span>
        </button>

        {/* Profile Tab */}
        <button
          onClick={() => {
            soundManager.playPip();
            onChangeTab('profile');
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentTab === 'profile'
              ? 'text-red-500 font-extrabold scale-105'
              : 'text-zinc-500 hover:text-zinc-300 font-medium'
          }`}
        >
          <User className={`w-5 h-5 mb-0.5 ${currentTab === 'profile' ? 'text-red-500 drop-shadow-[0_0_6px_rgba(239,68,68,0.7)]' : ''}`} />
          <span className="text-[10px] tracking-wider uppercase font-mono">PROFILE</span>
        </button>
      </div>
    </nav>
  );
};
