import React from "react";
import { Sparkles, Clock, Heart, Settings, BookOpen } from "lucide-react";

export type NavTab = "create" | "history" | "favorites" | "settings";

interface BottomNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  favoritesCount: number;
  historyCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  favoritesCount,
  historyCount
}) => {
  const tabs = [
    {
      id: "create" as NavTab,
      labelUrdu: "تخلیق",
      labelEn: "Create",
      icon: Sparkles
    },
    {
      id: "history" as NavTab,
      labelUrdu: "تاریخچہ",
      labelEn: "History",
      icon: Clock,
      count: historyCount
    },
    {
      id: "favorites" as NavTab,
      labelUrdu: "پسندیدہ",
      labelEn: "Favorites",
      icon: Heart,
      count: favoritesCount
    },
    {
      id: "settings" as NavTab,
      labelUrdu: "ترتیبات",
      labelEn: "Settings",
      icon: Settings
    }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-stone-900/95 backdrop-blur-lg border-t border-emerald-900/40 shadow-2xl pb-safe">
      <div className="max-w-md mx-auto grid grid-cols-4 px-2 py-1.5">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              id={`nav-tab-${tab.id}`}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition-all relative ${
                isActive
                  ? "text-amber-300 font-bold"
                  : "text-stone-400 hover:text-stone-200"
              }`}
            >
              {/* Active Pill Accent Background */}
              {isActive && (
                <div className="absolute inset-0 bg-emerald-950/60 rounded-xl border border-amber-500/20 shadow-inner -z-10" />
              )}

              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? "scale-110 text-amber-400" : ""
                  }`}
                />
                {tab.count !== undefined && tab.count > 0 && (
                  <span className="absolute -top-1 -left-2 min-w-4 h-4 px-1 rounded-full bg-amber-500 text-stone-950 text-[10px] font-bold flex items-center justify-center">
                    {tab.count > 99 ? "99+" : tab.count}
                  </span>
                )}
              </div>

              <span className="text-[11px] font-urdu-sans mt-0.5 leading-tight">
                {tab.labelUrdu}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
