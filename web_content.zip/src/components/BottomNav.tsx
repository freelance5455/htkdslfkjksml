import { Code2, FolderTree, Play, Settings } from "lucide-react";
import type { Tab } from "@/App";
import { cn } from "@/lib/utils";

interface Props {
  tab: Tab;
  onTab: (t: Tab) => void;
}

const ITEMS: { id: Tab; label: string; icon: typeof Code2 }[] = [
  { id: "editor", label: "المحرر", icon: Code2 },
  { id: "files", label: "الملفات", icon: FolderTree },
  { id: "preview", label: "المعاينة", icon: Play },
  { id: "settings", label: "الإعدادات", icon: Settings },
];

export function BottomNav({ tab, onTab }: Props) {
  return (
    <nav className="flex border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
      {ITEMS.map((item) => {
        const Icon = item.icon;
        const active = tab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onTab(item.id)}
            className={cn(
              "flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] transition-colors",
              active
                ? "text-sky-600 dark:text-sky-400"
                : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
            )}
          >
            <Icon className={cn("h-5 w-5", active && "scale-110")} />
            <span className={cn(active && "font-semibold")}>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}