import React from 'react';
import { BookOpen, HelpCircle, Layers, Sparkles, Bookmark } from 'lucide-react';

interface BottomNavProps {
  currentTab: 'notes' | 'quiz' | 'flashcards' | 'ai' | 'saved';
  onSelectTab: (tab: 'notes' | 'quiz' | 'flashcards' | 'ai' | 'saved') => void;
  language: 'om' | 'en';
  onOpenAiGenerator: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  language,
  onOpenAiGenerator,
}) => {
  return (
    <nav
      aria-label="Mobile Bottom Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 h-16 pb-safe"
    >
      <div className="grid grid-cols-5 items-center h-full max-w-md mx-auto">
        {/* Tab 1: Notes */}
        <button
          onClick={() => onSelectTab('notes')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            currentTab === 'notes' ? 'text-amber-600 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">
            {language === 'om' ? 'Qabxii' : 'Notes'}
          </span>
        </button>

        {/* Tab 2: Quizzes */}
        <button
          onClick={() => onSelectTab('quiz')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            currentTab === 'quiz' ? 'text-amber-600 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <HelpCircle className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">
            {language === 'om' ? 'Qormaata' : 'Quizzes'}
          </span>
        </button>

        {/* Tab 3: AI Generator Action */}
        <button
          onClick={onOpenAiGenerator}
          className="min-h-[44px] flex flex-col items-center justify-center cursor-pointer transition-colors text-amber-700 hover:text-amber-900"
        >
          <div className="w-7 h-7 rounded-full bg-amber-400 flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4 text-slate-950" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5 font-bold text-slate-900">
            {language === 'om' ? 'AI' : 'AI'}
          </span>
        </button>

        {/* Tab 4: Flashcards */}
        <button
          onClick={() => onSelectTab('flashcards')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            currentTab === 'flashcards' ? 'text-amber-600 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">
            {language === 'om' ? 'Kaardii' : 'Cards'}
          </span>
        </button>

        {/* Tab 5: Saved / Bookmarks */}
        <button
          onClick={() => onSelectTab('saved')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer transition-colors ${
            currentTab === 'saved' ? 'text-amber-600 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Bookmark className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">
            {language === 'om' ? 'Olkaa\'e' : 'Saved'}
          </span>
        </button>
      </div>
    </nav>
  );
};
