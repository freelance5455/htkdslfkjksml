import React from 'react';
import { Home, Scissors, LayoutTemplate, Sliders, Sparkles, FolderGit2 } from 'lucide-react';

export type TabType = 'home' | 'editor' | 'splitter' | 'templates' | 'ai_tools' | 'projects';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  lang: 'ar' | 'en';
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  lang
}) => {
  const items: { id: TabType; labelAr: string; labelEn: string; icon: React.ReactNode }[] = [
    { id: 'home', labelAr: 'الرئيسية', labelEn: 'Home', icon: <Home className="w-5 h-5" /> },
    { id: 'editor', labelAr: 'المحرر', labelEn: 'Editor', icon: <Sliders className="w-5 h-5" /> },
    { id: 'splitter', labelAr: 'التقسيم', labelEn: 'Splitter', icon: <Scissors className="w-5 h-5" /> },
    { id: 'templates', labelAr: 'القوالب', labelEn: 'Templates', icon: <LayoutTemplate className="w-5 h-5" /> },
    { id: 'ai_tools', labelAr: 'أدوات AI', labelEn: 'AI Tools', icon: <Sparkles className="w-5 h-5" /> },
    { id: 'projects', labelAr: 'المشاريع', labelEn: 'Projects', icon: <FolderGit2 className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0c0d1a]/95 backdrop-blur-xl border-t border-purple-900/30 px-2 py-1.5 sm:px-6 shadow-2xl">
      <div className="max-w-2xl mx-auto flex items-center justify-around">
        {items.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all relative cursor-pointer ${
                isActive
                  ? 'text-purple-300 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200 font-medium'
              }`}
            >
              {isActive && (
                <span className="absolute -top-1 w-6 h-1 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 shadow-sm shadow-purple-500/50" />
              )}
              <div
                className={`p-1 rounded-lg transition ${
                  isActive ? 'bg-purple-900/40 text-purple-300' : ''
                }`}
              >
                {item.icon}
              </div>
              <span className="text-[11px] mt-0.5 tracking-tight">
                {lang === 'ar' ? item.labelAr : item.labelEn}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
