import React from 'react';
import { LayoutDashboard, Users, ShoppingCart, Boxes, MoreHorizontal } from 'lucide-react';

export type ActiveTab = 'dashboard' | 'visits' | 'invoice' | 'inventory' | 'more' | 'treasury' | 'returns' | 'day-close' | 'reports' | 'debt' | 'profit' | 'products' | 'settings';

interface BottomNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  cartCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  cartCount,
}) => {
  // Determine if activeTab is under the 'more' group
  const isMoreActive = ['more', 'treasury', 'returns', 'day-close', 'reports', 'debt', 'profit', 'products', 'settings'].includes(activeTab);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 pb-[max(0.5rem,var(--sab))] select-none shadow-[0_-4px_20px_rgba(0,0,0,0.4)]">
      <div className="max-w-md mx-auto grid grid-cols-5 px-1 py-1">
        {/* Dashboard */}
        <button
          onClick={() => onTabChange('dashboard')}
          className={`flex flex-col items-center justify-center py-1.5 transition active:scale-95 ${
            activeTab === 'dashboard' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className={`p-1 rounded-xl transition ${activeTab === 'dashboard' ? 'bg-amber-400/15' : ''}`}>
            <LayoutDashboard className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">الرئيسية</span>
        </button>

        {/* Visits & Customers */}
        <button
          onClick={() => onTabChange('visits')}
          className={`flex flex-col items-center justify-center py-1.5 transition active:scale-95 ${
            activeTab === 'visits' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className={`p-1 rounded-xl transition ${activeTab === 'visits' ? 'bg-amber-400/15' : ''}`}>
            <Users className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">الزيارات</span>
        </button>

        {/* Quick Sell / POS with Cart Badge */}
        <button
          onClick={() => onTabChange('invoice')}
          className="relative flex flex-col items-center justify-center -top-2 transition active:scale-95"
        >
          <div
            className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition ${
              activeTab === 'invoice'
                ? 'bg-amber-500 text-slate-950 shadow-amber-500/30'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
            }`}
          >
            <ShoppingCart className="w-6 h-6" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-600 text-white rounded-full text-[11px] font-black border-2 border-slate-900 flex items-center justify-center animate-bounce">
                {cartCount}
              </span>
            )}
          </div>
          <span className={`text-[11px] mt-0.5 font-bold ${activeTab === 'invoice' ? 'text-amber-400' : 'text-slate-300'}`}>
            فاتورة
          </span>
        </button>

        {/* Inventory / Stock */}
        <button
          onClick={() => onTabChange('inventory')}
          className={`flex flex-col items-center justify-center py-1.5 transition active:scale-95 ${
            activeTab === 'inventory' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className={`p-1 rounded-xl transition ${activeTab === 'inventory' ? 'bg-amber-400/15' : ''}`}>
            <Boxes className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">المخزون</span>
        </button>

        {/* More */}
        <button
          onClick={() => onTabChange('more')}
          className={`flex flex-col items-center justify-center py-1.5 transition active:scale-95 ${
            isMoreActive ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className={`p-1 rounded-xl transition ${isMoreActive ? 'bg-amber-400/15' : ''}`}>
            <MoreHorizontal className="w-5 h-5" />
          </div>
          <span className="text-[11px] mt-0.5">المزيد</span>
        </button>
      </div>
    </nav>
  );
};
