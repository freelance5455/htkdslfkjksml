import React from 'react';
import { Home, Grid, MessageSquare, ShoppingCart, User } from 'lucide-react';
import { ScreenType } from '../types/ecommerce';

interface BottomNavProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  cartCount: number;
  unreadMessagesCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentScreen,
  onNavigate,
  cartCount,
  unreadMessagesCount = 2
}) => {
  const tabs = [
    { id: 'home' as ScreenType, label: 'Home', icon: Home },
    { id: 'categories' as ScreenType, label: 'Categories', icon: Grid },
    { id: 'account' as ScreenType, label: 'Messages', icon: MessageSquare, badge: unreadMessagesCount },
    { id: 'cart' as ScreenType, label: 'Cart', icon: ShoppingCart, badge: cartCount },
    { id: 'account' as ScreenType, label: 'Account', icon: User }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg safe-bottom max-w-md mx-auto md:max-w-none">
      <div className="grid grid-cols-5 h-14 max-w-md mx-auto items-center px-1">
        {tabs.map((tab, idx) => {
          const Icon = tab.icon;
          const isActive = 
            (tab.id === 'home' && currentScreen === 'home') ||
            (tab.id === 'categories' && currentScreen === 'categories') ||
            (tab.label === 'Cart' && currentScreen === 'cart') ||
            (tab.label === 'Account' && currentScreen === 'account');

          return (
            <button
              key={`${tab.label}-${idx}`}
              onClick={() => onNavigate(tab.id)}
              className={`flex flex-col items-center justify-center h-full relative transition-colors ${
                isActive ? 'text-[#FF6600]' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 stroke-[2.2]' : 'stroke-[1.8]'}`} />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-2.5 bg-[#FF6600] text-white text-[9px] font-bold px-1 min-w-[15px] h-[15px] rounded-full flex items-center justify-center border-2 border-white">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span className={`text-[10px] mt-0.5 tracking-tight ${isActive ? 'font-bold text-[#FF6600]' : 'font-medium'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
