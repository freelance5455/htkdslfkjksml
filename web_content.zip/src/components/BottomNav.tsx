import React from 'react';
import { Clock, FolderOpen, Settings, Code, Plus } from 'lucide-react';

interface BottomNavProps {
  activeTab: 'alarms' | 'media' | 'settings' | 'code';
  onChangeTab: (tab: 'alarms' | 'media' | 'settings' | 'code') => void;
  onOpenCreateModal: () => void;
  alarmCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  onOpenCreateModal,
  alarmCount,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 shadow-lg pb-safe">
      <div className="max-w-md mx-auto px-6 h-16 flex items-center justify-between relative">
        {/* Alarms Tab */}
        <button
          onClick={() => onChangeTab('alarms')}
          className={`flex flex-col items-center justify-center gap-1 min-w-[56px] cursor-pointer transition-colors ${
            activeTab === 'alarms'
              ? 'text-slate-900 dark:text-white font-bold'
              : 'text-slate-400 dark:text-slate-500 hover:text-slate-600'
          }`}
        >
          <div className="relative">
            <Clock className="w-5 h-5 stroke-[2.2]" />
            {alarmCount > 0 && (
              <span className="absolute -top-1 -right-2 w-4 h-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[10px] font-extrabold rounded-full flex items-center justify-center">
                {alarmCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-semibold tracking-tight">Alarms</span>
        </button>

        {/* Media Library Tab */}
        <button
          onClick={() => onChangeTab('media')}
          className={`flex flex-col items-center justify-center gap-1 min-w-[56px] cursor-pointer transition-colors ${
            activeTab === 'media'
              ? 'text-slate-900 dark:text-white font-bold'
              : 'text-slate-400 dark:text-slate-500 hover:text-slate-600'
          }`}
        >
          <FolderOpen className="w-5 h-5 stroke-[2.2]" />
          <span className="text-[10px] font-semibold tracking-tight">Media</span>
        </button>

        {/* Floating Action Button for Create Alarm in Center */}
        <div className="-mt-8">
          <button
            onClick={onOpenCreateModal}
            className="w-14 h-14 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 flex items-center justify-center shadow-xl hover:scale-105 active:scale-95 transition-transform cursor-pointer border-4 border-slate-50 dark:border-slate-950"
            title="Create New Alarm"
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </button>
        </div>

        {/* Android Code Tab */}
        <button
          onClick={() => onChangeTab('code')}
          className={`flex flex-col items-center justify-center gap-1 min-w-[56px] cursor-pointer transition-colors ${
            activeTab === 'code'
              ? 'text-slate-900 dark:text-white font-bold'
              : 'text-slate-400 dark:text-slate-500 hover:text-slate-600'
          }`}
        >
          <Code className="w-5 h-5 stroke-[2.2]" />
          <span className="text-[10px] font-semibold tracking-tight">Android</span>
        </button>

        {/* Settings Tab */}
        <button
          onClick={() => onChangeTab('settings')}
          className={`flex flex-col items-center justify-center gap-1 min-w-[56px] cursor-pointer transition-colors ${
            activeTab === 'settings'
              ? 'text-slate-900 dark:text-white font-bold'
              : 'text-slate-400 dark:text-slate-500 hover:text-slate-600'
          }`}
        >
          <Settings className="w-5 h-5 stroke-[2.2]" />
          <span className="text-[10px] font-semibold tracking-tight">Settings</span>
        </button>
      </div>
    </div>
  );
};
