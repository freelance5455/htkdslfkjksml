import { useEffect, useMemo, useRef, useState } from "react";
import { Menu, PenLine, Square, Trash2, X } from "lucide-react";
import {
  CHAMBERS,
  MAX_CHARS,
  MODEL,
  chamberById,
  titleFrom,
  type ChamberId,
  type StoredMessage,
  type Thread,
} from "@/lib/ardania";
import { previewPathPrefix } from "@/lib/preview-path-prefix";

const STORAGE_KEY = "ardania.threads.v1";

function apiPath(path: string): string {
  if (typeof window === "undefined") return path;
  const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
  return prefix ? `${prefix}${path}` : path;
}

function loadThreads(): Thread[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Thread[];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => item && typeof item.id === "string" && Array.isArray(item.messages));
  } catch {
    return [];
  }
}

function RichText({ text }: { text: string }) {
  const parts = text.split("```");
  return (
    <div className="space-y-3">
      {parts.map((part, index) => {
        if (index % 2 === 1) {
          const breakAt = part.indexOf("\n");
          const code = (breakAt === -1 ? part : part.slice(breakAt + 1)).replace(/\n$/, "");
          return (
            <pre
              key={index}
              className="overflow-x-auto rounded-md bg-bg px-3 py-3 font-mono text-sm leading-relaxed text-fg"
            >
              <code>{code}</code>
            </pre>
          );
        }
        return <Prose key={index} text={part} />;
      })}
    </div>
  );
}

function inlineBits(text: string) {
  const bits = text.split(/(\*\*[^*]+\*\*)/g);
  return bits.map((bit, index) => {
    if (bit.startsWith("**") && bit.endsWith("**")) {
      return (
        <strong key={index} className="font-medium text-fg">
          {bit.slice(2, -2)}
        </strong>
      );
    }
    return <span key={index}>{bit}</span>;
  });
}

function Prose({ text }: { text: string }) {
  const blocks = text
    .trim()
    .split(/\n{2,}/)
    .filter(Boolean);
  if (blocks.length === 0) return null;
  return (
    <div className="space-y-3">
      {blocks.map((block, index) => {
        const lines = block.split("\n");
        const list = lines.every((line) => /^[-*]\s+/.test(line.trim()));
        if (list) {
          return (
            <ul key={index} className="space-y-1.5 pl-4">
              {lines.map((line, lineIndex) => (
                <li key={lineIndex} className="list-disc text-pretty leading-relaxed">
                  {inlineBits(line.trim().replace(/^[-*]\s+/, ""))}
                </li>
              ))}
            </ul>
          );
        }
        return (
          <p key={index} className="text-pretty leading-relaxed">
            {inlineBits(block)}
          </p>
        );
      })}
    </div>
  );
}

export function ArdaniaStudio() {
  const [hydrated, setHydrated] = useState(false);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [chamber, setChamber] = useState<ChamberId>("rada");
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState<boolean | null>(null);
  const [navOpen, setNavOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const fieldRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    const stored = loadThreads();
    setThreads(stored);
    setHydrated(true);
    const controller = new AbortController();
    fetch(apiPath("/api/ardania"), { signal: controller.signal })
      .then((res) => res.json())
      .then((body: { ready?: boolean }) => setReady(Boolean(body.ready)))
      .catch(() => setReady(null));
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(threads));
  }, [threads, hydrated]);

  const active = threads.find((item) => item.id === activeId) ?? null;
  const shownChamber = active ? active.chamber : chamber;
  const meta = chamberById(shownChamber);

  useEffect(() => {
    const node = scrollerRef.current;
    if (!node) return;
    node.scrollTop = node.scrollHeight;
  }, [active?.messages, busy]);

  const ordered = useMemo(
    () => [...threads].sort((a, b) => b.updatedAt - a.updatedAt),
    [threads],
  );

  function openThread(id: string) {
    const next = threads.find((item) => item.id === id);
    if (!next || busy) return;
    setActiveId(id);
    setChamber(next.chamber);
    setError(null);
    setNavOpen(false);
  }

  function startFresh(nextChamber: ChamberId = chamber) {
    if (busy) return;
    setActiveId(null);
    setChamber(nextChamber);
    setDraft("");
    setError(null);
    setNavOpen(false);
    fieldRef.current?.focus();
  }

  function pickChamber(next: ChamberId) {
    if (busy) return;
    if (active && active.messages.length > 0 && active.chamber !== next) {
      startFresh(next);
      return;
    }
    setChamber(next);
    setError(null);
  }

  function removeThread(id: string) {
    if (busy) return;
    setThreads((current) => current.filter((item) => item.id !== id));
    if (activeId === id) setActiveId(null);
  }

  function stop() {
    abortRef.current?.abort();
  }

  async function send(text: string) {
    const content = text.trim();
    if (!content || busy || content.length > MAX_CHARS) return;

    const threadId = activeId ?? crypto.randomUUID();
    const now = Date.now();
    const userMessage: StoredMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content,
      createdAt: now,
    };
    const assistantId = crypto.randomUUID();
    const useChamber = active?.chamber ?? chamber;

    setThreads((current) => {
      const existing = current.find((item) => item.id === threadId);
      if (!existing) {
        const created: Thread = {
          id: threadId,
          title: titleFrom(content),
          chamber: useChamber,
          updatedAt: now,
          messages: [
            userMessage,
            { id: assistantId, role: "assistant", content: "", createdAt: now },
          ],
        };
        return [created, ...current];
      }
      return current.map((item) =>
        item.id === threadId
          ? {
              ...item,
              updatedAt: now,
              messages: [
                ...item.messages,
                userMessage,
                { id: assistantId, role: "assistant", content: "", createdAt: now },
              ],
            }
          : item,
      );
    });
    setActiveId(threadId);
    setDraft("");
    setBusy(true);
    setError(null);

    const history = [
      ...(active?.messages ?? []).map((item) => ({ role: item.role, content: item.content })),
      { role: "user" as const, content },
    ].filter((item) => item.content.trim());

    const controller = new AbortController();
    abortRef.current = controller;

    const writeAssistant = (value: string) => {
      setThreads((current) =>
        current.map((item) =>
          item.id !== threadId
            ? item
            : {
                ...item,
                updatedAt: Date.now(),
                messages: item.messages.map((message) =>
                  message.id === assistantId ? { ...message, content: value } : message,
                ),
              },
        ),
      );
    };

    try {
      const response = await fetch(apiPath("/api/ardania"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({ chamber: useChamber, messages: history.slice(-12) }),
      });

      const body = (await response.json().catch(() => null)) as { text?: string; error?: string } | null;
      if (!response.ok || !body?.text) {
        throw new Error(body?.error || "Сервіс не відповів.");
      }
      writeAssistant(body.text);
    } catch (reason) {
      if (controller.signal.aborted) {
        setThreads((current) =>
          current.map((item) =>
            item.id !== threadId
              ? item
              : {
                  ...item,
                  messages: item.messages.flatMap((message) => {
                    if (message.id !== assistantId) return [message];
                    if (!message.content.trim()) return [];
                    return [message];
                  }),
                },
          ),
        );
      } else {
        const message = reason instanceof Error ? reason.message : "Щось пішло не так.";
        setError(message);
        setThreads((current) =>
          current.map((item) =>
            item.id !== threadId
              ? item
              : { ...item, messages: item.messages.filter((entry) => entry.id !== assistantId) },
          ),
        );
      }
    } finally {
      setBusy(false);
      abortRef.current = null;
    }
  }

  return (
    <div className="flex h-dvh min-h-0 bg-bg text-fg">
      {navOpen ? (
        <button
          type="button"
          aria-label="Закрити список"
          className="fixed inset-0 z-20 bg-ink/70 lg:hidden"
          onClick={() => setNavOpen(false)}
        />
      ) : null}

      <aside
        className={
          "drawer fixed inset-y-0 left-0 z-30 flex w-80 flex-col border-r border-line bg-surface lg:static lg:translate-x-0 " +
          (navOpen ? "translate-x-0" : "-translate-x-full")
        }
      >
        <div className="flex items-start justify-between gap-3 px-5 pt-6 pb-4">
          <div>
            <p className="font-display text-3xl leading-none tracking-tight text-fg">Ardania</p>
            <p className="mt-2 text-sm text-muted">Власний сервіс мислення</p>
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md text-muted lg:hidden"
            aria-label="Закрити"
            onClick={() => setNavOpen(false)}
          >
            <X className="size-5" />
          </button>
        </div>

        <div className="px-3">
          <button
            type="button"
            onClick={() => startFresh(chamber)}
            className="flex h-11 w-full items-center justify-center gap-2 rounded-md bg-paper text-sm font-medium text-ink"
          >
            <PenLine className="size-4" />
            Нова розмова
          </button>
        </div>

        <div className="mt-6 px-5">
          <p className="text-xs font-medium tracking-wide text-faint uppercase">Палати</p>
          <ul className="mt-3 space-y-1">
            {CHAMBERS.map((item) => {
              const selected = shownChamber === item.id && !active;
              const current = active?.chamber === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => pickChamber(item.id)}
                    className={
                      "w-full rounded-md px-3 py-2.5 text-left " +
                      (selected || current ? "bg-raised text-fg" : "text-muted hover:bg-raised/70")
                    }
                  >
                    <span className="block text-sm font-medium">{item.name}</span>
                    <span className="mt-0.5 block text-xs leading-snug text-faint">{item.line}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="mt-6 min-h-0 flex-1 overflow-y-auto px-3 pb-4">
          <p className="px-2 text-xs font-medium tracking-wide text-faint uppercase">Розмови</p>
          {ordered.length === 0 ? (
            <p className="px-2 pt-3 text-sm text-faint">Поки порожньо. Пам'ять лишається в цьому браузері.</p>
          ) : (
            <ul className="mt-2 space-y-1">
              {ordered.map((item) => (
                <li key={item.id} className="group flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => openThread(item.id)}
                    className={
                      "min-w-0 flex-1 rounded-md px-2 py-2 text-left " +
                      (item.id === activeId ? "bg-raised" : "hover:bg-raised/70")
                    }
                  >
                    <span className="block truncate text-sm text-fg">{item.title}</span>
                    <span className="mt-0.5 block text-xs text-faint">
                      {chamberById(item.chamber).name}
                    </span>
                  </button>
                  <button
                    type="button"
                    aria-label="Видалити розмову"
                    onClick={() => removeThread(item.id)}
                    className="grid size-11 shrink-0 place-items-center rounded-md text-faint opacity-100 lg:opacity-0 lg:group-hover:opacity-100"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="border-t border-line px-5 py-4 text-xs leading-relaxed text-faint">
          <p className="font-medium text-muted">Сервіс Ardania</p>
          <p className="mt-1">
            Модель {MODEL}. Відповідь до 700 токенів. Виклик лише після вашого запиту.
          </p>
        </div>
      </aside>

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-line px-4 py-3 lg:px-8">
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md border border-line lg:hidden"
            aria-label="Відкрити палати"
            onClick={() => setNavOpen(true)}
          >
            <Menu className="size-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-xl leading-none tracking-tight">{meta.name}</p>
            <p className="mt-1 truncate text-xs text-faint">{meta.line}</p>
          </div>
          <p className="hidden text-xs text-faint sm:block">
            {ready === false ? "Сервіс недоступний" : `${MODEL} · сервер Ardania`}
          </p>
        </header>

        <div ref={scrollerRef} className="min-h-0 flex-1 overflow-y-auto">
          <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-8 lg:px-8">
            {!active || active.messages.length === 0 ? (
              <section className="animate-rise pt-6 sm:pt-16">
                <p className="text-xs font-medium tracking-widest text-mist uppercase">Ardania</p>
                <h1 className="mt-3 max-w-xl font-display text-4xl leading-tight tracking-tight text-balance sm:text-5xl">
                  Окремий голос, не чужий чат.
                </h1>
                <p className="mt-4 max-w-xl text-base leading-relaxed text-pretty text-muted">
                  Три палати одного сервісу. Рада вирішує, Майстерня робить, Архів стискає.
                  Розмова лишається лише на цьому пристрої.
                </p>
                <div className="mt-8 grid gap-3 sm:grid-cols-3">
                  {CHAMBERS.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => pickChamber(item.id)}
                      className={
                        "rounded-lg border px-4 py-4 text-left " +
                        (shownChamber === item.id
                          ? "border-mist bg-raised"
                          : "border-line bg-surface hover:border-mist")
                      }
                    >
                      <span className="block font-display text-2xl tracking-tight">{item.name}</span>
                      <span className="mt-2 block text-sm leading-snug text-muted">{item.line}</span>
                    </button>
                  ))}
                </div>
                <div className="mt-8 space-y-2">
                  {meta.prompts.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => send(prompt)}
                      className="block w-full rounded-lg border border-line bg-surface px-4 py-3 text-left text-sm leading-relaxed text-fg hover:border-mist"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </section>
            ) : (
              active.messages.map((message) => (
                <article
                  key={message.id}
                  className={"animate-rise " + (message.role === "user" ? "ml-auto max-w-xl" : "max-w-3xl")}
                >
                  <p className="mb-2 text-xs font-medium tracking-wide text-faint uppercase">
                    {message.role === "user" ? "Ви" : "Ardania"}
                  </p>
                  <div
                    className={
                      message.role === "user"
                        ? "rounded-lg rounded-br-sm bg-raised px-4 py-3 text-sm sm:text-base"
                        : "text-sm sm:text-base"
                    }
                  >
                    {message.role === "assistant" && !message.content ? (
                      <p className="thinking">Ardania думає</p>
                    ) : (
                      <RichText text={message.content} />
                    )}
                  </div>
                </article>
              ))
            )}
            {error ? (
              <p className="rounded-md border border-line bg-surface px-4 py-3 text-sm text-fg" role="alert">
                {error}
              </p>
            ) : null}
          </div>
        </div>

        <form
          className="border-t border-line px-4 py-4 lg:px-8"
          onSubmit={(event) => {
            event.preventDefault();
            void send(draft);
          }}
        >
          <div className="mx-auto flex w-full max-w-3xl items-end gap-2 rounded-xl border border-line bg-surface p-2">
            <label className="sr-only" htmlFor="ardania-draft">
              Повідомлення для Ardania
            </label>
            <textarea
              id="ardania-draft"
              ref={fieldRef}
              value={draft}
              rows={1}
              maxLength={MAX_CHARS}
              placeholder={`Запит у палату «${meta.name}»`}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  void send(draft);
                }
              }}
              className="max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2.5 text-base text-fg outline-none placeholder:text-faint"
            />
            {busy ? (
              <button
                type="button"
                onClick={stop}
                className="grid size-11 shrink-0 place-items-center rounded-md bg-paper text-ink"
                aria-label="Зупинити"
              >
                <Square className="size-4" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={!draft.trim()}
                className="h-11 shrink-0 rounded-md bg-paper px-4 text-sm font-medium text-ink disabled:opacity-40"
              >
                Надіслати
              </button>
            )}
          </div>
          <p className="mx-auto mt-2 w-full max-w-3xl text-xs text-faint">
            Enter надсилає. Shift+Enter — новий рядок.
            {draft.length > 3200 ? ` ${draft.length}/${MAX_CHARS}` : ""}
          </p>
        </form>
      </main>
    </div>
  );
}
