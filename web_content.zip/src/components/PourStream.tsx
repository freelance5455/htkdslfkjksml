import { LIQUID_COLORS } from "../game";

interface Point { x: number; y: number }

interface PourStreamProps {
  color: number;
  amount: number;
  progress: number;
  /** 0..1 live flow — drives width, opacity and splash energy. Matches audio. */
  flow: number;
  start: Point;
  control: Point;
  end: Point;
  opacity: number;
  impactRadius: number;
  /** 0..1 how far the falling head has travelled (stream growing from the lip). */
  headT?: number;
  /** 0..1 how far the detached tail has fallen (stream ending). */
  tailT?: number;
}

function pointOnCurve(start: Point, control: Point, end: Point, t: number): Point {
  const inverse = 1 - t;
  return {
    x: inverse * inverse * start.x + 2 * inverse * t * control.x + t * t * end.x,
    y: inverse * inverse * start.y + 2 * inverse * t * control.y + t * t * end.y,
  };
}

function tangentOnCurve(start: Point, control: Point, end: Point, t: number): Point {
  const dx = 2 * (1 - t) * (control.x - start.x) + 2 * t * (end.x - control.x);
  const dy = 2 * (1 - t) * (control.y - start.y) + 2 * t * (end.y - control.y);
  const len = Math.max(0.001, Math.hypot(dx, dy));
  return { x: dx / len, y: dy / len };
}

interface Ribbon {
  path: string;
  left: Point[];
  right: Point[];
  center: Point[];
}

/** Variable-width ribbon: necking at the lip, gravity thinning downward. */
function liquidRibbon(
  start: Point,
  control: Point,
  end: Point,
  width: number,
  progress: number,
  wobbleAmp: number,
): Ribbon {
  const left: Point[] = [];
  const right: Point[] = [];
  const center: Point[] = [];
  const segments = 18;
  for (let index = 0; index <= segments; index += 1) {
    const t = index / segments;
    const point = pointOnCurve(start, control, end, t);
    const tangent = tangentOnCurve(start, control, end, t);
    const normal = { x: -tangent.y, y: tangent.x };
    // Necking near the lip, then steady thinning as the fall accelerates.
    const neck = t < 0.18 ? 0.72 + (t / 0.18) * 0.28 : 1 - (t - 0.18) * 0.42;
    const ripple =
      1 +
      Math.sin(progress * 46 + t * 22) * 0.045 +
      Math.sin(progress * 23 - t * 9) * 0.03;
    // Lateral wobble grows toward the bottom where the stream is freest.
    const sway = Math.sin(progress * 31 + t * 7) * wobbleAmp * t;
    const cx = point.x + normal.x * sway;
    const cy = point.y + normal.y * sway;
    center.push({ x: cx, y: cy });
    const halfWidth = Math.max(0.5, width * neck * ripple * 0.5);
    left.push({ x: cx + normal.x * halfWidth, y: cy + normal.y * halfWidth });
    right.push({ x: cx - normal.x * halfWidth, y: cy - normal.y * halfWidth });
  }
  return {
    path: [
      `M ${left[0].x} ${left[0].y}`,
      ...left.slice(1).map((p) => `L ${p.x} ${p.y}`),
      ...right.reverse().map((p) => `L ${p.x} ${p.y}`),
      "Z",
    ].join(" "),
    left,
    right,
    center,
  };
}

function polyline(points: Point[]): string {
  return points.map((p, i) => `${i ? "L" : "M"} ${p.x} ${p.y}`).join(" ");
}

export default function PourStream({
  color,
  amount,
  progress,
  flow,
  start: fullStart,
  control: fullControl,
  end: fullEnd,
  opacity,
  impactRadius,
  headT = 1,
  tailT = 0,
}: PourStreamProps) {
  // Gravity: head and tail move with accelerating (t²-like) timing.
  const t1 = Math.max(0.03, Math.min(1, headT * headT * 0.6 + headT * 0.4));
  const t0 = Math.min(t1 - 0.02, tailT * tailT);
  const start = pointOnCurve(fullStart, fullControl, fullEnd, t0);
  const end = pointOnCurve(fullStart, fullControl, fullEnd, t1);
  const k = (1 - t0) ;
  const control = {
    x: start.x + (t1 - t0) * (k * (fullControl.x - fullStart.x) + t0 * (fullEnd.x - fullControl.x)),
    y: start.y + (t1 - t0) * (k * (fullControl.y - fullStart.y) + t0 * (fullEnd.y - fullControl.y)),
  };
  const landed = headT >= 0.98;
  if (tailT >= 0.995) return null;
  const palette = LIQUID_COLORS[color];
  const f = Math.max(0.001, Math.min(1, flow));
  // Width breathes with flow: thin trickle in/out, full body mid-pour.
  const width = (3.4 + amount * 0.85) * (0.3 + 0.7 * Math.pow(f, 0.65));
  const ribbon = liquidRibbon(start, control, end, width, progress, 0.9);
  const core = liquidRibbon(
    { x: start.x - 0.7, y: start.y },
    { x: control.x - 0.7, y: control.y },
    { x: end.x - 0.7, y: end.y },
    width * 0.42,
    progress * 1.2,
    0.9,
  );
  const energy = f; // splash scale

  return (
    <g className="realistic-stream" style={{ opacity }}>
      {/* Soft airborne mist around a fast stream. */}
      <path d={ribbon.path} fill={palette.base} opacity={0.14 * f} transform="translate(0 0.6) scale(1)" />
      {/* Main body: saturated translucent column. */}
      <path d={ribbon.path} fill={palette.base} opacity={0.55 + 0.4 * f} />
      <path d={ribbon.path} fill={palette.dark} opacity={0.18} />
      {/* Dark limbs where light travels furthest through the stream. */}
      <path d={polyline(ribbon.left)} fill="none" stroke={palette.dark} strokeWidth={0.9} opacity={0.5} strokeLinecap="round" />
      <path d={polyline(ribbon.right)} fill="none" stroke={palette.dark} strokeWidth={0.9} opacity={0.4} strokeLinecap="round" />
      {/* Bright refracted core, offset to the key-light side. */}
      <path d={core.path} fill={palette.light} opacity={0.35 + 0.45 * f} />
      <path
        className="stream-glint"
        d={polyline(core.center)}
        fill="none"
        stroke="#ffffff"
        strokeWidth={0.9}
        strokeLinecap="round"
        strokeDasharray="7 13"
        opacity={0.55 * f + 0.2}
      />

      {/* Stretched glints racing down the column. */}
      {Array.from({ length: 3 }, (_, index) => {
        const t = (progress * 2.6 + index / 3) % 1;
        const p = pointOnCurve(start, control, end, 0.08 + t * 0.8);
        const tan = tangentOnCurve(start, control, end, 0.08 + t * 0.8);
        const len = 4 + index * 1.5;
        return (
          <line
            key={`glint-${index}`}
            x1={p.x - tan.x * len - tan.y * 0.8}
            y1={p.y - tan.y * len + tan.x * 0.8}
            x2={p.x + tan.x * len - tan.y * 0.8}
            y2={p.y + tan.y * len + tan.x * 0.8}
            stroke="#ffffff"
            strokeWidth={0.8}
            strokeLinecap="round"
            opacity={Math.sin(t * Math.PI) * 0.6 * f}
          />
        );
      })}

      {/* Satellite droplets pinching off the wobbling stream. */}
      {Array.from({ length: 5 }, (_, index) => {
        const t = 0.3 + ((progress * 3.4 + index * 0.19) % 0.62);
        const p = pointOnCurve(start, control, end, t);
        const tan = tangentOnCurve(start, control, end, t);
        const side = index % 2 ? 1 : -1;
        const off = side * (2 + index * 0.7) * Math.sin(t * Math.PI);
        const cx = p.x - tan.y * off;
        const cy = p.y + tan.x * off;
        const r = (0.7 + (index % 3) * 0.3) * (0.5 + 0.5 * f);
        const stretch = 1 + t * 1.1;
        return (
          <g key={`sat-${index}`} opacity={Math.sin(t * Math.PI) * 0.75 * f}>
            <ellipse
              cx={cx}
              cy={cy}
              rx={r * 0.72}
              ry={r * stretch}
              fill={palette.base}
              transform={`rotate(${(Math.atan2(tan.y, tan.x) * 180) / Math.PI - 90} ${cx} ${cy})`}
            />
            <circle cx={cx - r * 0.25} cy={cy - r * 0.4} r={r * 0.28} fill="#ffffff" opacity=".9" />
          </g>
        );
      })}

      {landed && (<g>
      {/* Impact crater: the stream dents the surface. */}
      <ellipse cx={end.x} cy={end.y + 0.6} rx={impactRadius * (0.34 + 0.3 * energy)} ry={1.7} fill={palette.dark} opacity={0.5 * f} />
      {/* Foam collar hugging the entry point. */}
      <ellipse
        cx={end.x}
        cy={end.y + 0.4}
        rx={impactRadius * (0.42 + 0.34 * energy)}
        ry={2}
        fill="none"
        stroke={palette.light}
        strokeWidth={1.3}
        opacity={0.55 * f}
      />
      <ellipse cx={end.x} cy={end.y + 0.3} rx={impactRadius * 0.4} ry={1.3} fill="#ffffff" opacity={0.3 * f} />

      {/* Crown spikes thrown upward by the impact. */}
      {Array.from({ length: 6 }, (_, index) => {
        const phase = (progress * 9 + index * 0.37) % 1;
        const dir = index - 2.5;
        const h = (3 + (index % 3) * 2.4) * energy * Math.sin(phase * Math.PI);
        const bx = end.x + dir * impactRadius * 0.22;
        return (
          <path
            key={`crown-${index}`}
            d={`M ${bx - 1.4} ${end.y + 0.5} Q ${bx + dir * 0.4} ${end.y - h} ${bx + 1.4} ${end.y + 0.5} Z`}
            fill={index % 2 ? palette.light : palette.base}
            opacity={(1 - phase * 0.5) * 0.7 * f}
          />
        );
      })}

      {/* Ballistic splash droplets arcing off the crown. */}
      {Array.from({ length: 8 }, (_, index) => {
        const age = (progress * 11 + index / 8) % 1;
        const dir = index - 3.5;
        const height = (6 + (index % 4) * 3.4) * (0.4 + 0.6 * energy);
        const cx = end.x + dir * age * (4.5 + energy * 2);
        const cy = end.y - Math.sin(age * Math.PI) * height + age * age * 3;
        const r = (0.8 + (index % 2) * 0.55) * (0.6 + 0.4 * f);
        return (
          <g key={`splash-${index}`} opacity={(1 - age) * 0.85 * f}>
            <circle cx={cx} cy={cy} r={r} fill={index % 3 === 0 ? palette.light : palette.base} />
            <circle cx={cx - r * 0.3} cy={cy - r * 0.35} r={r * 0.3} fill="#ffffff" opacity=".85" />
          </g>
        );
      })}

      {/* Expanding ripple rings constrained to the glass width. */}
      {[0, 1, 2].map((ring) => {
        const age = (progress * 7 + ring / 3) % 1;
        return (
          <ellipse
            key={`ripple-${ring}`}
            cx={end.x}
            cy={end.y + 1}
            rx={2 + age * impactRadius * 1.15}
            ry={0.8 + age * 2.6}
            fill="none"
            stroke={palette.light}
            strokeWidth={1.1 - age * 0.5}
            opacity={(1 - age) * 0.6 * f}
          />
        );
      })}
      </g>)}
      {/* Rounded head drop while the stream is still falling. */}
      {!landed && (
        <ellipse cx={end.x} cy={end.y} rx={width * 0.42} ry={width * 0.62} fill={palette.base} />
      )}
    </g>
  );
}
