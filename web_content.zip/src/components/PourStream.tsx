import React, { useEffect, useState } from 'react';
import { ColorId } from '../types/game';
import { LIQUID_COLORS } from '../utils/colors';

interface PourStreamProps {
  sourceIndex: number;
  destinationIndex: number;
  color: ColorId;
  containerRef: React.RefObject<HTMLDivElement | null>;
}

export const PourStream: React.FC<PourStreamProps> = ({
  sourceIndex,
  destinationIndex,
  color,
  containerRef,
}) => {
  const [coords, setCoords] = useState<{
    x1: number;
    y1: number;
    x2: number;
    y2: number;
  } | null>(null);

  useEffect(() => {
    let animId: number;

    const updatePosition = () => {
      if (!containerRef.current) return;
      const containerRect = containerRef.current.getBoundingClientRect();

      const sourceEl = document.getElementById(`tube-${sourceIndex}`);
      const destEl = document.getElementById(`tube-${destinationIndex}`);
      const rightSpout = document.getElementById(`tube-spout-right-${sourceIndex}`);
      const leftSpout = document.getElementById(`tube-spout-left-${sourceIndex}`);
      const destMouth = document.getElementById(`tube-mouth-${destinationIndex}`);

      if (!sourceEl || !destEl) return;

      const sourceRect = sourceEl.getBoundingClientRect();
      const destRect = destEl.getBoundingClientRect();
      const isSourceLeft = sourceRect.left < destRect.left;

      let x1 = 0;
      let y1 = 0;
      let x2 = 0;
      let y2 = 0;

      // Use dedicated high-precision spout marker if available
      const activeSpout = isSourceLeft ? (rightSpout || leftSpout) : (leftSpout || rightSpout);

      if (activeSpout) {
        const spoutRect = activeSpout.getBoundingClientRect();
        x1 = spoutRect.left + spoutRect.width / 2 - containerRect.left;
        y1 = spoutRect.top + spoutRect.height / 2 - containerRect.top;
      } else {
        x1 = isSourceLeft
          ? sourceRect.right - containerRect.left - 4
          : sourceRect.left - containerRect.left + 4;
        y1 = sourceRect.top - containerRect.top + 6;
      }

      // Use dedicated destination mouth marker if available
      if (destMouth) {
        const mouthRect = destMouth.getBoundingClientRect();
        x2 = mouthRect.left + mouthRect.width / 2 - containerRect.left;
        y2 = mouthRect.top + mouthRect.height / 2 - containerRect.top + 2;
      } else {
        x2 = destRect.left - containerRect.left + destRect.width / 2;
        y2 = destRect.top - containerRect.top + 12;
      }

      setCoords({ x1, y1, x2, y2 });

      // Run continuous RAF loop to smoothly track rotating/lifting source tube
      animId = requestAnimationFrame(updatePosition);
    };

    animId = requestAnimationFrame(updatePosition);
    return () => cancelAnimationFrame(animId);
  }, [sourceIndex, destinationIndex, containerRef]);

  if (!coords) return null;

  const colorInfo = LIQUID_COLORS[color] || LIQUID_COLORS.blue;
  const { x1, y1, x2, y2 } = coords;

  // Fluid dynamics vectors for natural parabolic water arc
  const dx = x2 - x1;
  const dy = y2 - y1;

  // Spout exit vector: pushes out horizontally towards destination with a slight upward arch
  const exitDx = dx * 0.45;
  const exitDy = Math.min(-14, dy * 0.1);
  const cp1x = x1 + exitDx;
  const cp1y = y1 + exitDy;

  // Destination entry vector: drops smoothly into destination tube mouth almost vertically
  const cp2x = x2 - dx * 0.06;
  const cp2y = y2 - Math.max(30, Math.abs(dy) * 0.35);

  // Cubic bezier stream path
  const pathD = `M ${x1} ${y1} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${x2} ${y2}`;

  // Slightly offset highlights for 3D liquid refraction
  const pathDLight = `M ${x1 + (dx > 0 ? -1 : 1)} ${y1 - 1.5} C ${cp1x} ${cp1y - 2}, ${cp2x} ${cp2y - 2}, ${x2} ${y2 - 1}`;
  const pathDShadow = `M ${x1 + (dx > 0 ? 1 : -1)} ${y1 + 2} C ${cp1x} ${cp1y + 2}, ${cp2x} ${cp2y + 2}, ${x2} ${y2 + 2}`;

  // Midpoint approximation for floating stars
  const midX = (x1 + x2) / 2;
  const midY = (cp1y + cp2y) / 2;

  return (
    <svg
      className="absolute inset-0 w-full h-full pointer-events-none z-40 overflow-visible transform-gpu"
      style={{ filter: `drop-shadow(0 4px 14px ${colorInfo.glowHex || '#06b6d4'})` }}
    >
      <defs>
        {/* Main Stream Fluid Multi-Stop Gradient */}
        <linearGradient id={`streamGrad-${color}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={colorInfo.topHighlight} stopOpacity="0.95" />
          <stop offset="30%" stopColor={colorInfo.baseHex} stopOpacity="0.9" />
          <stop offset="75%" stopColor={colorInfo.baseHex} stopOpacity="0.95" />
          <stop offset="100%" stopColor={colorInfo.bottomShadow} stopOpacity="1" />
        </linearGradient>

        {/* Specular Core Water Sheen */}
        <linearGradient id={`streamSpecular-${color}`} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="40%" stopColor="rgba(255,255,255,0.6)" />
          <stop offset="85%" stopColor="rgba(255,255,255,0.1)" />
          <stop offset="100%" stopColor="transparent" />
        </linearGradient>

        {/* Fluid Splash Foam Gradient */}
        <radialGradient id={`splashGrad-${color}`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="45%" stopColor={colorInfo.topHighlight} stopOpacity="0.85" />
          <stop offset="100%" stopColor={colorInfo.baseHex} stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* 1. Atmospheric Outer Fluid Aura */}
      <path
        d={pathD}
        fill="none"
        stroke={colorInfo.topHighlight}
        strokeWidth="18"
        strokeLinecap="round"
        className="opacity-35 blur-[4px]"
      />

      {/* 2. Deep Underbelly Shadow Layer */}
      <path
        d={pathDShadow}
        fill="none"
        stroke={colorInfo.bottomShadow}
        strokeWidth="12"
        strokeLinecap="round"
        className="opacity-70"
      />

      {/* 3. Main Glossy Fluid Column */}
      <path
        d={pathD}
        fill="none"
        stroke={`url(#streamGrad-${color})`}
        strokeWidth="9.5"
        strokeLinecap="round"
        className="opacity-95"
      />

      {/* 4. Top Glassy Refraction Line */}
      <path
        d={pathDLight}
        fill="none"
        stroke={colorInfo.topHighlight}
        strokeWidth="5"
        strokeLinecap="round"
        className="opacity-85"
      />

      {/* 5. Pure White Specular Water Core */}
      <path
        d={pathD}
        fill="none"
        stroke={`url(#streamSpecular-${color})`}
        strokeWidth="2.8"
        strokeLinecap="round"
        className="opacity-95"
      />

      {/* 6. Dynamic Water Wave Ripple Currents */}
      <path
        d={pathD}
        fill="none"
        stroke="#ffffff"
        strokeWidth="2"
        strokeDasharray="8 16"
        strokeLinecap="round"
        className="opacity-85"
      >
        <animate
          attributeName="stroke-dashoffset"
          from="0"
          to="48"
          dur="0.18s"
          repeatCount="indefinite"
        />
      </path>

      {/* 7. Secondary Rapid Liquid Beads */}
      <path
        d={pathD}
        fill="none"
        stroke={colorInfo.topHighlight}
        strokeWidth="3.2"
        strokeDasharray="4 26"
        strokeLinecap="round"
        className="opacity-90"
      >
        <animate
          attributeName="stroke-dashoffset"
          from="0"
          to="90"
          dur="0.25s"
          repeatCount="indefinite"
        />
      </path>

      {/* 8. Liquid Droplets Traveling Down the Parabolic Path */}
      <circle r="2.5" fill="#ffffff" opacity="0.9">
        <animateMotion path={pathD} dur="0.28s" repeatCount="indefinite" />
      </circle>
      <circle r="3" fill={colorInfo.topHighlight} opacity="0.85">
        <animateMotion path={pathD} dur="0.32s" begin="0.1s" repeatCount="indefinite" />
      </circle>
      <circle r="2" fill="#ffffff" opacity="0.95">
        <animateMotion path={pathD} dur="0.26s" begin="0.18s" repeatCount="indefinite" />
      </circle>

      {/* ==========================================
          MAGICAL WATER SPARKLES
          ========================================== */}
      {/* Sparkle 1: Near Spout Lip */}
      <g transform={`translate(${x1 + (midX - x1) * 0.3}, ${y1 + (midY - y1) * 0.3 - 4})`}>
        <polygon
          points="0,-6 1.8,-1.8 6,0 1.8,1.8 0,6 -1.8,1.8 -6,0 -1.8,-1.8"
          fill="#ffffff"
        >
          <animateTransform
            attributeName="transform"
            type="rotate"
            from="0"
            to="360"
            dur="0.7s"
            repeatCount="indefinite"
          />
          <animate
            attributeName="opacity"
            values="0.4;1;0.4"
            dur="0.35s"
            repeatCount="indefinite"
          />
        </polygon>
      </g>

      {/* Sparkle 2: Mid-Arc Apex */}
      <g transform={`translate(${midX}, ${midY - 5})`}>
        <polygon
          points="0,-7 2.2,-2.2 7,0 2.2,2.2 0,7 -2.2,2.2 -7,0 -2.2,-2.2"
          fill="#cffafe"
        >
          <animateTransform
            attributeName="transform"
            type="rotate"
            from="360"
            to="0"
            dur="0.85s"
            repeatCount="indefinite"
          />
          <animate
            attributeName="opacity"
            values="0.7;1;0.3;0.7"
            dur="0.45s"
            repeatCount="indefinite"
          />
        </polygon>
      </g>

      {/* ==========================================
          DESTINATION WATER IMPACT & SPLASH RIPPLES
          ========================================== */}
      {/* Outer Expanding Water Wave Ring 1 */}
      <ellipse
        cx={x2}
        cy={y2 + 2}
        rx="10"
        ry="3.5"
        fill="none"
        stroke={colorInfo.topHighlight}
        strokeWidth="2.5"
      >
        <animate
          attributeName="rx"
          values="4;15;4"
          dur="0.26s"
          repeatCount="indefinite"
        />
        <animate
          attributeName="ry"
          values="1.5;5.5;1.5"
          dur="0.26s"
          repeatCount="indefinite"
        />
        <animate
          attributeName="opacity"
          values="0.95;0.15;0.95"
          dur="0.26s"
          repeatCount="indefinite"
        />
      </ellipse>

      {/* Inner Splash Core Glow */}
      <ellipse
        cx={x2}
        cy={y2 + 1}
        rx="6"
        ry="2.5"
        fill={`url(#splashGrad-${color})`}
      >
        <animate
          attributeName="rx"
          values="3;9;3"
          dur="0.22s"
          repeatCount="indefinite"
        />
        <animate
          attributeName="opacity"
          values="0.7;1;0.7"
          dur="0.22s"
          repeatCount="indefinite"
        />
      </ellipse>

      {/* Dynamic Water Splash Droplets leaping up from impact */}
      <circle cx={x2 - 8} cy={y2 - 2} r="2.2" fill={colorInfo.topHighlight}>
        <animate attributeName="cy" values={`${y2};${y2 - 14};${y2 + 2}`} dur="0.26s" repeatCount="indefinite" />
        <animate attributeName="cx" values={`${x2 - 2};${x2 - 9};${x2 - 13}`} dur="0.26s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.2;1;0" dur="0.26s" repeatCount="indefinite" />
      </circle>
      <circle cx={x2 + 8} cy={y2 - 2} r="2" fill="#ffffff">
        <animate attributeName="cy" values={`${y2};${y2 - 12};${y2 + 2}`} dur="0.3s" repeatCount="indefinite" />
        <animate attributeName="cx" values={`${x2 + 2};${x2 + 9};${x2 + 12}`} dur="0.3s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.3;1;0" dur="0.3s" repeatCount="indefinite" />
      </circle>
      <circle cx={x2} cy={y2 - 3} r="1.8" fill={colorInfo.topHighlight}>
        <animate attributeName="cy" values={`${y2};${y2 - 16};${y2}`} dur="0.24s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0;1;0" dur="0.24s" repeatCount="indefinite" />
      </circle>
    </svg>
  );
};
