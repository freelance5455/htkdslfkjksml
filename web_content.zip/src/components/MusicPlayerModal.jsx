import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Disc3, FolderSearch, ListMusic, Music2, Pause, Play, Plus, Repeat, Repeat1, Search, Shuffle, SkipBack, SkipForward, Trash2, Upload, Volume2, VolumeX, X, } from 'lucide-react';
import { cleanTrackTitle, collectAudioFilesFromDirectory, formatFileSize, formatTime, isSupportedAudioFile, } from '../utils/musicLibrary';
import { sound } from '../utils/sound';
const LOOP_ORDER = ['all', 'one', 'shuffle'];
export const MusicPlayerModal = ({ open, language, tracks, prefs, musicEnabled, onToggleMusicEnabled, onSelectTrack, onAddFiles, onRemoveTrack, onUpdatePrefs, onClose, }) => {
    const fileInputRef = useRef(null);
    const folderInputRef = useRef(null);
    const [snap, setSnap] = useState(() => sound.getSnapshot());
    const [viewMode, setViewMode] = useState('player');
    const [isScanning, setIsScanning] = useState(false);
    const [isImporting, setIsImporting] = useState(false);
    const [errorMsg, setErrorMsg] = useState(null);
    const [infoMsg, setInfoMsg] = useState(null);
    const [playlistQuery, setPlaylistQuery] = useState('');
    const [scannedFiles, setScannedFiles] = useState([]);
    const [selectedKeys, setSelectedKeys] = useState(new Set());
    const [scanQuery, setScanQuery] = useState('');
    const canUseDirectoryPicker = useMemo(() => {
        if (typeof window === 'undefined')
            return false;
        const win = window;
        const isTopWindow = (() => {
            try {
                return window.self === window.top;
            }
            catch {
                return false;
            }
        })();
        return isTopWindow && typeof win.showDirectoryPicker === 'function';
    }, []);
    useEffect(() => {
        if (!open)
            return;
        return sound.subscribe(setSnap);
    }, [open]);
    const isAr = language === 'ar';
    const filteredTracks = useMemo(() => {
        const q = playlistQuery.trim().toLowerCase();
        if (!q)
            return tracks;
        return tracks.filter((t) => t.title.toLowerCase().includes(q));
    }, [tracks, playlistQuery]);
    const filteredScanned = useMemo(() => {
        const q = scanQuery.trim().toLowerCase();
        if (!q)
            return scannedFiles;
        return scannedFiles.filter((item) => item.title.toLowerCase().includes(q));
    }, [scannedFiles, scanQuery]);
    if (!open)
        return null;
    const activeTrack = tracks.find((t) => t.id === prefs.selectedTrackId) ?? tracks[0];
    const duration = snap.duration > 0 ? snap.duration : activeTrack?.duration || 0;
    const currentTime = Math.min(snap.currentTime, duration || snap.currentTime);
    const progressPct = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;
    const loadScannedList = (files) => {
        const audioOnly = files.filter(isSupportedAudioFile);
        if (audioOnly.length === 0) {
            setErrorMsg(isAr
                ? 'لم يتم العثور على ملفات صوتية داخل الاختيار'
                : 'No audio files were found in your selection');
            return;
        }
        const items = audioOnly.map((file, idx) => ({
            key: `${file.name}-${file.size}-${idx}`,
            file,
            title: cleanTrackTitle(file.name),
            sizeLabel: formatFileSize(file.size),
        }));
        setErrorMsg(null);
        setInfoMsg(null);
        setScannedFiles(items);
        setSelectedKeys(new Set(items.map((it) => it.key)));
        setScanQuery('');
        setViewMode('picker');
    };
    const handleDirectAudioChange = async (e) => {
        const files = e.target.files ? Array.from(e.target.files) : [];
        e.target.value = '';
        if (files.length === 0)
            return;
        const valid = files.filter(isSupportedAudioFile);
        if (valid.length === 0) {
            setErrorMsg(isAr
                ? 'الرجاء اختيار ملفات صوتية صالحة (MP3, M4A, WAV...)'
                : 'Please select valid audio files (MP3, M4A, WAV...)');
            return;
        }
        // If user picked 1 song directly, import & play right away; if multiple, show organized checklist
        if (valid.length === 1) {
            setErrorMsg(null);
            setIsImporting(true);
            try {
                const res = await onAddFiles(valid);
                if (res.added > 0) {
                    sound.playClick();
                    setViewMode('player');
                }
            }
            finally {
                setIsImporting(false);
            }
            return;
        }
        loadScannedList(valid);
    };
    const handleFolderInputChange = (e) => {
        const files = e.target.files ? Array.from(e.target.files) : [];
        e.target.value = '';
        if (files.length === 0)
            return;
        loadScannedList(files);
    };
    const handleScanPhoneFolder = async () => {
        sound.playClick();
        setErrorMsg(null);
        setInfoMsg(null);
        const win = window;
        if (canUseDirectoryPicker && typeof win.showDirectoryPicker === 'function') {
            try {
                setIsScanning(true);
                const dirHandle = await win.showDirectoryPicker({
                    id: 'flapora-phone-music',
                    mode: 'read',
                });
                const found = await collectAudioFilesFromDirectory(dirHandle);
                setIsScanning(false);
                loadScannedList(found);
                return;
            }
            catch (err) {
                setIsScanning(false);
                if (err instanceof DOMException && err.name === 'AbortError') {
                    return;
                }
            }
        }
        fileInputRef.current?.click();
    };
    const handleConfirmScannedImport = async () => {
        const chosen = scannedFiles
            .filter((item) => selectedKeys.has(item.key))
            .map((item) => item.file);
        if (chosen.length === 0)
            return;
        setIsImporting(true);
        setErrorMsg(null);
        try {
            const result = await onAddFiles(chosen);
            if (result.added > 0) {
                sound.playClick();
                setScannedFiles([]);
                setSelectedKeys(new Set());
                setViewMode('player');
            }
            else {
                setErrorMsg(isAr
                    ? 'تعذر حفظ الملفات الصوتية، جرّب ملفات أصغر'
                    : 'Could not save audio files, try smaller files');
            }
        }
        finally {
            setIsImporting(false);
        }
    };
    const cycleLoopMode = () => {
        sound.playClick();
        const idx = LOOP_ORDER.indexOf(prefs.loopMode);
        const next = LOOP_ORDER[(idx + 1) % LOOP_ORDER.length];
        onUpdatePrefs({ loopMode: next });
    };
    const loopLabel = prefs.loopMode === 'one'
        ? isAr
            ? 'تكرار'
            : 'Repeat 1'
        : prefs.loopMode === 'shuffle'
            ? isAr
                ? 'عشوائي'
                : 'Shuffle'
            : isAr
                ? 'تلقائي'
                : 'Loop All';
    const handleClose = () => {
        sound.playClick();
        setViewMode('player');
        setErrorMsg(null);
        setInfoMsg(null);
        onClose();
    };
    const allScannedSelected = scannedFiles.length > 0 && selectedKeys.size === scannedFiles.length;
    return (<div className="absolute inset-0 z-30 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3.5" onClick={(e) => {
            if (e.target === e.currentTarget) {
                handleClose();
            }
        }}>
      <div dir={isAr ? 'rtl' : 'ltr'} role="dialog" aria-modal="true" aria-label={isAr ? 'مشغل الموسيقى' : 'Music Player'} className={`relative w-full max-w-[350px] pt-5 ${isAr ? 'font-arabic' : ''}`}>
        {/* Overlapping Top Ribbon Banner */}
        <div className="absolute top-0 inset-x-0 flex justify-center z-10 pointer-events-none">
          <div className="px-7 py-2 rounded-2xl bg-gradient-to-b from-fuchsia-400 via-purple-500 to-purple-700 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-display font-bold text-xl tracking-wide drop-shadow-[0_2px_0_rgba(59,7,100,0.9)]">
            {viewMode === 'picker'
            ? isAr
                ? 'أغاني الهاتف'
                : 'Phone Songs'
            : isAr
                ? 'الموسيقى'
                : 'Music Player'}
          </div>
        </div>

        {/* Close Button */}
        <button type="button" onClick={handleClose} aria-label={isAr ? 'إغلاق' : 'Close'} className={`absolute top-2 ${isAr ? 'left-1' : 'right-1'} z-20 w-11 h-11 rounded-full bg-gradient-to-b from-rose-400 to-rose-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_3px_0_#451A03] text-white flex items-center justify-center cursor-pointer transition-transform duration-150 hover:scale-105 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-300`}>
          <X className="w-5 h-5 stroke-[3]"/>
        </button>

        {/* Hidden Audio & Folder Inputs */}
        <input ref={fileInputRef} type="file" accept="audio/*" multiple onChange={handleDirectAudioChange} className="hidden"/>
        <input ref={folderInputRef} type="file" multiple 
    // @ts-expect-error webkitdirectory is a standard non-typed browser attribute
    webkitdirectory="" onChange={handleFolderInputChange} className="hidden"/>

        {/* Cartoon Wood & Cream Parchment Frame */}
        <div className="rounded-[28px] bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 border-[3px] border-amber-950 p-2 shadow-[0_10px_0_#451A03,0_24px_50px_rgba(0,0,0,0.55)]">
          <div className="rounded-[20px] bg-gradient-to-b from-amber-50 to-amber-100 border-2 border-amber-800/30 px-3 pt-7 pb-3.5 text-amber-950 flex flex-col gap-2.5 max-h-[84dvh]">
            {viewMode === 'picker' ? (
        /* ================= PHONE SONGS PICKER VIEW ================= */
        <>
                <div className="flex items-center justify-between gap-2">
                  <button type="button" onClick={() => {
                sound.playClick();
                setViewMode('player');
                setErrorMsg(null);
                setInfoMsg(null);
            }} className="min-h-[38px] px-3 rounded-xl bg-white/90 hover:bg-white border-2 border-amber-900/20 text-xs font-extrabold text-amber-950 flex items-center gap-1.5 cursor-pointer">
                    {isAr ? (<ArrowRight className="w-4 h-4"/>) : (<ArrowLeft className="w-4 h-4"/>)}
                    <span>{isAr ? 'رجوع للمشغل' : 'Back'}</span>
                  </button>

                  <span className="text-[11px] font-extrabold text-amber-900/80 tabular-nums">
                    {scannedFiles.length > 0
                ? isAr
                    ? `تم العثور على ${scannedFiles.length} أغنية`
                    : `${scannedFiles.length} songs found`
                : isAr
                    ? 'اختر مصدر الأغاني'
                    : 'Choose source'}
                  </span>
                </div>

                {/* Source Buttons */}
                {canUseDirectoryPicker ? (<div className="grid grid-cols-2 gap-2">
                    <button type="button" disabled={isScanning || isImporting} onClick={handleScanPhoneFolder} className="min-h-[48px] rounded-2xl bg-gradient-to-b from-sky-400 to-blue-600 hover:brightness-105 disabled:opacity-70 border-[2.5px] border-amber-950 shadow-[0_3px_0_#451A03] px-2.5 py-2 text-white font-extrabold text-xs flex flex-col items-center justify-center gap-1 cursor-pointer active:translate-y-0.5">
                      <FolderSearch className="w-4 h-4"/>
                      <span className="leading-tight text-center">
                        {isScanning
                    ? isAr
                        ? 'جاري الفحص...'
                        : 'Scanning...'
                    : isAr
                        ? 'فحص مجلد الموسيقى'
                        : 'Scan Music Folder'}
                      </span>
                    </button>

                    <button type="button" disabled={isScanning || isImporting} onClick={() => {
                    sound.playClick();
                    setErrorMsg(null);
                    fileInputRef.current?.click();
                }} className="min-h-[48px] rounded-2xl bg-gradient-to-b from-amber-300 via-orange-400 to-orange-500 hover:brightness-105 disabled:opacity-70 border-[2.5px] border-amber-950 shadow-[0_3px_0_#451A03] px-2.5 py-2 text-white font-extrabold text-xs flex flex-col items-center justify-center gap-1 cursor-pointer active:translate-y-0.5">
                      <ListMusic className="w-4 h-4"/>
                      <span className="leading-tight text-center drop-shadow-[0_1px_0_rgba(69,26,3,0.6)]">
                        {isAr ? 'اختيار ملفات صوتية' : 'Pick Audio Files'}
                      </span>
                    </button>
                  </div>) : (<button type="button" disabled={isImporting} onClick={() => {
                    sound.playClick();
                    setErrorMsg(null);
                    fileInputRef.current?.click();
                }} className="w-full min-h-[48px] rounded-2xl bg-gradient-to-b from-amber-300 via-orange-400 to-orange-500 hover:brightness-105 disabled:opacity-70 border-[2.5px] border-amber-950 shadow-[0_3px_0_#451A03] px-3 py-2 text-white font-extrabold text-sm flex items-center justify-center gap-2 cursor-pointer active:translate-y-0.5">
                    <ListMusic className="w-4 h-4 shrink-0"/>
                    <span className="drop-shadow-[0_1px_0_rgba(69,26,3,0.6)]">
                      {isAr ? 'فتح صوتيات الهاتف وتحديد الأغاني' : 'Open Phone Audio & Select Songs'}
                    </span>
                  </button>)}

                {infoMsg && (<div className="rounded-xl bg-sky-100 border border-sky-400 px-3 py-2 text-[11px] font-bold text-sky-900 text-center leading-relaxed">
                    {infoMsg}
                  </div>)}

                {errorMsg && (<div className="rounded-xl bg-rose-100 border border-rose-400 px-3 py-1.5 text-xs font-bold text-rose-800 text-center">
                    {errorMsg}
                  </div>)}

                {scannedFiles.length > 0 ? (<>
                    {/* Search + Select All Controls */}
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <Search className={`w-3.5 h-3.5 text-amber-800/60 absolute top-1/2 -translate-y-1/2 ${isAr ? 'right-2.5' : 'left-2.5'}`}/>
                        <input type="text" value={scanQuery} onChange={(e) => setScanQuery(e.target.value)} placeholder={isAr ? 'ابحث في الأغاني...' : 'Search songs...'} className={`w-full h-9 rounded-xl bg-white/90 border border-amber-900/20 text-xs font-bold text-amber-950 placeholder:text-amber-800/50 focus:outline-2 focus:outline-purple-500 ${isAr ? 'pr-8 pl-2.5' : 'pl-8 pr-2.5'}`}/>
                      </div>

                      <button type="button" onClick={() => {
                    sound.playClick();
                    if (allScannedSelected) {
                        setSelectedKeys(new Set());
                    }
                    else {
                        setSelectedKeys(new Set(scannedFiles.map((s) => s.key)));
                    }
                }} className="h-9 px-2.5 rounded-xl bg-purple-100 hover:bg-purple-200 border border-purple-400 text-[11px] font-extrabold text-purple-900 shrink-0 cursor-pointer">
                        {allScannedSelected
                    ? isAr
                        ? 'إلغاء الكل'
                        : 'Clear'
                    : isAr
                        ? 'تحديد الكل'
                        : 'Select All'}
                      </button>
                    </div>

                    {/* Discovered Songs Checklist */}
                    <div className="max-h-[34dvh] overflow-y-auto space-y-1.5 pr-0.5">
                      {filteredScanned.map((item) => {
                    const checked = selectedKeys.has(item.key);
                    return (<button key={item.key} type="button" onClick={() => {
                            sound.playClick();
                            setSelectedKeys((prev) => {
                                const next = new Set(prev);
                                if (next.has(item.key))
                                    next.delete(item.key);
                                else
                                    next.add(item.key);
                                return next;
                            });
                        }} className={`w-full text-start flex items-center gap-2.5 rounded-xl px-2.5 py-2 border-2 cursor-pointer transition-all ${checked
                            ? 'bg-emerald-50 border-emerald-500'
                            : 'bg-white/80 border-amber-900/15'}`}>
                            <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center shrink-0 ${checked
                            ? 'bg-emerald-500 border-emerald-800 text-white'
                            : 'bg-white border-amber-900/30'}`}>
                              {checked && <Check className="w-3.5 h-3.5 stroke-[3]"/>}
                            </div>

                            <div className="min-w-0 flex-1">
                              <div className="text-xs font-extrabold text-amber-950 truncate">
                                {item.title}
                              </div>
                              {item.sizeLabel && (<div className="text-[10px] font-bold text-amber-800/70 tabular-nums">
                                  {item.sizeLabel}
                                </div>)}
                            </div>
                          </button>);
                })}
                    </div>

                    {/* Import Selected Songs */}
                    <button type="button" disabled={selectedKeys.size === 0 || isImporting} onClick={handleConfirmScannedImport} className="w-full min-h-[46px] rounded-2xl bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-600 hover:brightness-105 disabled:opacity-60 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-extrabold text-sm flex items-center justify-center gap-2 cursor-pointer">
                      {isImporting ? (<Upload className="w-4 h-4 animate-bounce"/>) : (<Plus className="w-4 h-4 stroke-[3]"/>)}
                      <span>
                        {isImporting
                    ? isAr
                        ? 'جاري إضافة الأغاني...'
                        : 'Adding songs...'
                    : isAr
                        ? `إضافة المحدد (${selectedKeys.size})`
                        : `Add Selected (${selectedKeys.size})`}
                      </span>
                    </button>
                  </>) : (<div className="rounded-2xl bg-white/80 border-2 border-amber-800/25 p-3.5 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-extrabold text-amber-950">
                      <Music2 className="w-5 h-5 text-purple-600 shrink-0"/>
                      <span>
                        {canUseDirectoryPicker
                    ? isAr
                        ? 'اسمح بالوصول لمجلد الموسيقى أو اختر أغاني'
                        : 'Grant folder access or pick audio files'
                    : isAr
                        ? 'لجلب كل أغانيك من شاشة «صوتيات» بالهاتف:'
                        : 'How to import multiple songs on mobile:'}
                      </span>
                    </div>
                    {canUseDirectoryPicker ? (<p className="text-[11px] font-semibold text-amber-800/85 leading-relaxed">
                        {isAr
                        ? 'عند منح الإذن لمجلد الموسيقى ستظهر كل أغانيك هنا لتختار منها أو تضيفها كلها بضغطة واحدة.'
                        : 'Once you grant access to your Music folder, all songs appear here to add in one tap.'}
                      </p>) : (<ol className="text-[11px] font-semibold text-amber-900/85 space-y-1 list-decimal list-inside leading-relaxed">
                        <li>
                          {isAr
                        ? 'اضغط الزر بالأعلى لفتح صوتيات الهاتف، وادخل أي مجلد أو اضغط أيقونة البحث للوصول لكل الأغاني.'
                        : 'Tap the button above, open a folder or tap Search to view songs.'}
                        </li>
                        <li>
                          {isAr
                        ? 'اضغط مطولاً على أول أغنية ثم اختر «تحديد الكل» أو حدد الأغاني التي تريدها واضغط «تحديد».'
                        : 'Long-press a song, tap Select All (or pick songs), then tap Select.'}
                        </li>
                        <li>
                          {isAr
                        ? 'ستُحفظ كل أغانيك داخل اللعبة للأبد ولن تحتاج لإعادة اختيارها.'
                        : 'All selected songs are saved permanently inside the game.'}
                        </li>
                      </ol>)}
                  </div>)}
              </>) : (
        /* ================= MAIN MUSIC PLAYER VIEW ================= */
        <>
                {/* 1. Now Playing Deck */}
                <div className="rounded-2xl bg-gradient-to-b from-purple-950 via-indigo-950 to-slate-900 border-2 border-amber-950 p-3 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.15),0_4px_12px_rgba(15,23,42,0.25)] space-y-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-gradient-to-br from-fuchsia-400 via-purple-500 to-indigo-600 border-2 border-white/25 shadow-md flex items-center justify-center shrink-0">
                      {activeTrack?.coverUrl ? (<img src={activeTrack.coverUrl} alt={activeTrack.title} referrerPolicy="no-referrer" className="w-full h-full object-cover"/>) : (<Disc3 className={`w-6 h-6 text-white ${snap.isPlaying
                    ? 'motion-safe:animate-[spin_5s_linear_infinite]'
                    : ''}`}/>)}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-extrabold text-white truncate">
                        {activeTrack?.title ?? 'Sky Kingdom Theme'}
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] font-semibold text-purple-200/85 truncate">
                        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${snap.isPlaying ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`}/>
                        <span className="truncate">
                          {activeTrack
                ? isAr
                    ? activeTrack.subtitleAr
                    : activeTrack.subtitleEn
                : ''}
                        </span>
                      </div>
                    </div>

                    {/* Mute / Unmute Game Music */}
                    <button type="button" onClick={() => {
                const next = !musicEnabled;
                sound.playClick();
                onToggleMusicEnabled(next);
            }} aria-label={musicEnabled
                ? isAr
                    ? 'كتم الموسيقى'
                    : 'Mute music'
                : isAr
                    ? 'تفعيل الموسيقى'
                    : 'Unmute music'} className={`w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-colors shrink-0 ${musicEnabled
                ? 'bg-white/10 hover:bg-white/20 border-white/20 text-emerald-300'
                : 'bg-rose-500/20 hover:bg-rose-500/30 border-rose-400/40 text-rose-300'}`}>
                      {musicEnabled ? (<Volume2 className="w-4 h-4"/>) : (<VolumeX className="w-4 h-4"/>)}
                    </button>
                  </div>

                  {/* Seek Bar */}
                  <div dir="ltr" className="space-y-1">
                    <input type="range" min={0} max={Math.max(duration, 1)} step={0.1} value={currentTime} onChange={(e) => sound.seekTo(Number(e.target.value))} aria-label={isAr ? 'شريط التقدم' : 'Seek bar'} style={{
                background: `linear-gradient(to right, #e879f9 ${progressPct}%, rgba(255,255,255,0.2) ${progressPct}%)`,
            }} className="w-full h-1.5 rounded-full appearance-none cursor-pointer accent-fuchsia-300"/>
                    <div className="flex items-center justify-between text-[10px] font-bold text-purple-200/80 tabular-nums">
                      <span>{formatTime(currentTime)}</span>
                      <span>{formatTime(duration)}</span>
                    </div>
                  </div>

                  {/* Transport Controls */}
                  <div dir="ltr" className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
                    <div className="flex justify-start">
                      <button type="button" onClick={cycleLoopMode} aria-label={loopLabel} title={loopLabel} className="min-w-[58px] h-9 px-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-[10px] font-bold text-purple-100 flex items-center justify-center gap-1 cursor-pointer transition-transform active:scale-95">
                        {prefs.loopMode === 'one' ? (<Repeat1 className="w-3.5 h-3.5 text-amber-300 shrink-0"/>) : prefs.loopMode === 'shuffle' ? (<Shuffle className="w-3.5 h-3.5 text-fuchsia-300 shrink-0"/>) : (<Repeat className="w-3.5 h-3.5 text-emerald-300 shrink-0"/>)}
                        <span>{loopLabel}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => {
                sound.playClick();
                sound.stepTrack(-1, true);
                if (!musicEnabled)
                    onToggleMusicEnabled(true);
            }} aria-label={isAr ? 'الأغنية السابقة' : 'Previous track'} className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-white flex items-center justify-center cursor-pointer transition-transform active:scale-90">
                        <SkipBack className="w-4 h-4 fill-current"/>
                      </button>

                      <button type="button" onClick={() => {
                if (!snap.isPlaying && !musicEnabled) {
                    onToggleMusicEnabled(true);
                }
                sound.togglePlayPause();
            }} aria-label={snap.isPlaying
                ? isAr
                    ? 'إيقاف مؤقت'
                    : 'Pause'
                : isAr
                    ? 'تشغيل'
                    : 'Play'} className="w-12 h-12 rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 hover:brightness-105 border-2 border-amber-950 shadow-[0_3px_0_#022C22] text-white flex items-center justify-center cursor-pointer transition-transform hover:scale-105 active:scale-95">
                        {snap.isPlaying ? (<Pause className="w-5 h-5 fill-current"/>) : (<Play className="w-5 h-5 fill-current ml-0.5"/>)}
                      </button>

                      <button type="button" onClick={() => {
                sound.playClick();
                sound.stepTrack(1, true);
                if (!musicEnabled)
                    onToggleMusicEnabled(true);
            }} aria-label={isAr ? 'الأغنية التالية' : 'Next track'} className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-white flex items-center justify-center cursor-pointer transition-transform active:scale-90">
                        <SkipForward className="w-4 h-4 fill-current"/>
                      </button>
                    </div>

                    <div aria-hidden="true"/>
                  </div>

                  {/* Volume Control Row */}
                  <div dir="ltr" className="flex items-center gap-2 pt-0.5">
                    <VolumeX className="w-3.5 h-3.5 text-purple-200/70 shrink-0"/>
                    <input type="range" min={0} max={1} step={0.02} value={prefs.volume} onChange={(e) => {
                onUpdatePrefs({ volume: Number(e.target.value) });
            }} aria-label={isAr ? 'مستوى الصوت' : 'Music Volume'} style={{
                background: `linear-gradient(to right, #38bdf8 ${prefs.volume * 100}%, rgba(255,255,255,0.2) ${prefs.volume * 100}%)`,
            }} className="w-full h-1.5 rounded-full appearance-none cursor-pointer accent-sky-300"/>
                    <Volume2 className="w-3.5 h-3.5 text-sky-300 shrink-0"/>
                  </div>
                </div>

                {/* 2. Add Music from Phone Library Button */}
                <button type="button" disabled={isImporting} onClick={() => {
                sound.playClick();
                setErrorMsg(null);
                setInfoMsg(null);
                setViewMode('picker');
            }} className="w-full min-h-[44px] rounded-2xl bg-gradient-to-b from-amber-300 via-orange-400 to-orange-500 hover:brightness-105 disabled:opacity-70 border-[2.5px] border-amber-950 shadow-[0_3px_0_#451A03] px-3.5 py-2 text-white font-extrabold text-sm flex items-center justify-center gap-2 cursor-pointer transition-transform duration-150 active:translate-y-0.5 active:shadow-[0_1px_0_#451A03]">
                  <Plus className="w-4 h-4 stroke-[3] shrink-0"/>
                  <span className="drop-shadow-[0_1.5px_0_rgba(69,26,3,0.75)]">
                    {isAr ? 'إضافة أغاني من الهاتف' : 'Add Songs from Phone'}
                  </span>
                </button>

                {errorMsg && (<div className="rounded-xl bg-rose-100 border border-rose-400 px-3 py-1.5 text-xs font-bold text-rose-800 text-center">
                    {errorMsg}
                  </div>)}

                {/* 3. Playlist Header & Optional Search */}
                <div className="flex items-center justify-between px-1 pt-0.5">
                  <span className="text-xs font-extrabold text-amber-900 flex items-center gap-1.5">
                    <ListMusic className="w-4 h-4 text-purple-600"/>
                    {isAr ? `قائمة الأغاني (${tracks.length})` : `Playlist (${tracks.length})`}
                  </span>
                  <span className="text-[10px] font-bold text-amber-800/80">
                    {isAr ? 'تعمل طول فتح اللعبة' : 'Plays continuously'}
                  </span>
                </div>

                {tracks.length > 3 && (<div className="relative">
                    <Search className={`w-3.5 h-3.5 text-amber-800/60 absolute top-1/2 -translate-y-1/2 ${isAr ? 'right-2.5' : 'left-2.5'}`}/>
                    <input type="text" value={playlistQuery} onChange={(e) => setPlaylistQuery(e.target.value)} placeholder={isAr ? 'ابحث في قائمتك...' : 'Search playlist...'} className={`w-full h-8 rounded-xl bg-white/90 border border-amber-900/20 text-xs font-bold text-amber-950 placeholder:text-amber-800/50 focus:outline-2 focus:outline-purple-500 ${isAr ? 'pr-8 pl-2.5' : 'pl-8 pr-2.5'}`}/>
                  </div>)}

                <div className="max-h-[20dvh] overflow-y-auto space-y-1.5 pr-0.5">
                  {filteredTracks.map((track) => {
                const isSelected = track.id === prefs.selectedTrackId;
                const isThisPlaying = isSelected && snap.isPlaying;
                return (<div key={track.id} role="button" tabIndex={0} aria-pressed={isSelected} onClick={() => {
                        sound.playClick();
                        if (!musicEnabled)
                            onToggleMusicEnabled(true);
                        onSelectTrack(track.id, true);
                    }} onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            sound.playClick();
                            if (!musicEnabled)
                                onToggleMusicEnabled(true);
                            onSelectTrack(track.id, true);
                        }
                    }} className={`flex items-center gap-2.5 rounded-xl px-2.5 py-2 border-2 cursor-pointer transition-all ${isSelected
                        ? 'bg-purple-100/95 border-purple-500 shadow-xs'
                        : 'bg-white/85 border-amber-900/15 hover:bg-white'}`}>
                        <div className={`relative w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center shrink-0 border ${isSelected
                        ? 'bg-gradient-to-b from-purple-500 to-indigo-600 border-purple-900 text-white'
                        : 'bg-amber-100 border-amber-800/20 text-amber-900'}`}>
                          {track.coverUrl ? (<>
                              <img src={track.coverUrl} alt={track.title} referrerPolicy="no-referrer" className="w-full h-full object-cover"/>
                              {isSelected && (<div className="absolute inset-0 bg-purple-950/45 flex items-center justify-center text-white">
                                  {isThisPlaying ? (<Pause className="w-4 h-4 fill-current"/>) : (<Check className="w-4 h-4 stroke-[3]"/>)}
                                </div>)}
                            </>) : isThisPlaying ? (<Pause className="w-4 h-4 fill-current"/>) : isSelected ? (<Check className="w-4 h-4 stroke-[3]"/>) : (<Music2 className="w-4 h-4"/>)}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-extrabold text-amber-950 truncate">
                            {track.title}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] font-bold text-amber-800/75 tabular-nums">
                            <span>{formatTime(track.duration)}</span>
                            <span>•</span>
                            <span className="truncate">
                              {isAr ? track.subtitleAr : track.subtitleEn}
                            </span>
                          </div>
                        </div>

                        {track.isCustom && (<button type="button" aria-label={isAr ? 'حذف الأغنية' : 'Delete track'} onClick={(e) => {
                            e.stopPropagation();
                            sound.playClick();
                            onRemoveTrack(track.id);
                        }} className="w-8 h-8 rounded-lg bg-rose-100 hover:bg-rose-200 border border-rose-300 text-rose-600 flex items-center justify-center shrink-0 cursor-pointer transition-colors">
                            <Trash2 className="w-3.5 h-3.5"/>
                          </button>)}
                      </div>);
            })}
                </div>

                {/* Done Button */}
                <button type="button" onClick={handleClose} className="w-full min-h-[44px] rounded-2xl bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-extrabold text-base tracking-wide cursor-pointer transition-transform duration-150 active:translate-y-0.5 active:shadow-[0_2px_0_#451A03]">
                  {isAr ? 'تم' : 'Done'}
                </button>
              </>)}
          </div>
        </div>
      </div>
    </div>);
};
