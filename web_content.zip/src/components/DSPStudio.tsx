import React, { useState, useEffect } from 'react';
import { audioEngine, EQ_FREQUENCIES, EQ_PRESETS } from '../services/audioEngine';
import { DSPSettings, DynamicFxMode, ReverbRoomSize } from '../types/audio';
import {
  Sliders,
  Sparkles,
  Waves,
  Zap,
  Volume2,
  RotateCcw,
  Check,
  Disc,
  Activity,
  Headphones,
  Maximize2
} from 'lucide-react';

interface Props {
  bpm: number;
  isBeat: boolean;
  beatStrength: number;
}

export const DSPStudio: React.FC<Props> = ({ bpm, isBeat, beatStrength }) => {
  const [settings, setSettings] = useState<DSPSettings>(() => audioEngine.getDSPSettings());
  const [activeSubTab, setActiveSubTab] = useState<'eq' | 'dynamic' | 'tone' | 'bass_reverb'>('dynamic');
  const [savedPresets, setSavedPresets] = useState<Record<string, number[]>>({});
  const [newPresetName, setNewPresetName] = useState('');
  const [showSavePreset, setShowSavePreset] = useState(false);

  useEffect(() => {
    // Load custom presets from localStorage if available
    try {
      const stored = localStorage.getItem('aurasound_custom_presets');
      if (stored) {
        setSavedPresets(JSON.parse(stored));
      }
    } catch {
      // ignore
    }
  }, []);

  const handleUpdate = (partial: Partial<DSPSettings>) => {
    const updated = { ...settings, ...partial };
    setSettings(updated);
    audioEngine.updateDSPSettings(partial);
  };

  const handleBandChange = (index: number, val: number) => {
    const newBands = [...settings.eqBands];
    newBands[index] = val;
    handleUpdate({ eqBands: newBands, eqPreset: 'Personalizado' });
  };

  const handleApplyPreset = (presetName: string) => {
    const preset = EQ_PRESETS[presetName] || savedPresets[presetName];
    if (preset) {
      handleUpdate({ eqBands: [...preset], eqPreset: presetName });
    }
  };

  const handleResetEQ = () => {
    handleUpdate({
      eqBands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      preAmp: 0,
      eqPreset: 'Flat',
    });
  };

  const handleSavePreset = () => {
    if (!newPresetName.trim()) return;
    const updated = { ...savedPresets, [newPresetName.trim()]: [...settings.eqBands] };
    setSavedPresets(updated);
    localStorage.setItem('aurasound_custom_presets', JSON.stringify(updated));
    handleUpdate({ eqPreset: newPresetName.trim() });
    setNewPresetName('');
    setShowSavePreset(false);
  };

  // Format Hz nicely
  const formatHz = (freq: number) => {
    if (freq >= 1000) return `${freq / 1000}k`;
    return `${freq}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Header / Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-400" />
            <span>Estudio DSP & Ecualizador</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Procesamiento de audio de punto flotante de 32 bits a 48/96 kHz
          </p>
        </div>

        {/* Live Rhythm Status Indicator */}
        <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 self-start sm:self-auto">
          <div
            className={`w-2.5 h-2.5 rounded-full transition-all duration-75 ${
              isBeat
                ? 'bg-emerald-400 scale-125 shadow-lg shadow-emerald-400/50'
                : 'bg-slate-600 scale-100'
            }`}
          />
          <span className="text-xs font-mono tabular-nums text-slate-200">
            {bpm > 0 ? `${bpm} BPM` : 'Detectando...'}
          </span>
          <span className="text-[10px] text-slate-400 border-l border-slate-700 pl-2">
            Auto-Sync
          </span>
        </div>
      </div>

      {/* Sub navigation bar */}
      <div className="flex items-center gap-2 p-1 bg-slate-900/80 border border-slate-800 rounded-xl overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('dynamic')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition ${
            activeSubTab === 'dynamic'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-300" />
          <span>Efectos Dinámicos al Ritmo</span>
        </button>

        <button
          onClick={() => setActiveSubTab('eq')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition ${
            activeSubTab === 'eq'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Ecualizador 10 Bandas</span>
        </button>

        <button
          onClick={() => setActiveSubTab('tone')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition ${
            activeSubTab === 'tone'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Tono: Grave a Agudo</span>
        </button>

        <button
          onClick={() => setActiveSubTab('bass_reverb')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition ${
            activeSubTab === 'bass_reverb'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Waves className="w-3.5 h-3.5" />
          <span>Bajos & Reverb Envolvente</span>
        </button>
      </div>

      {/* SUBTAB 1: EFECTOS DINAMICOS AL RITMO */}
      {activeSubTab === 'dynamic' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Main Toggle Card */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950/40 border border-indigo-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-white">
                  Modificaciones de Audio Dinámicas en Tiempo Real
                </span>
                <span className="px-2 py-0.5 text-[10px] font-medium text-amber-300 bg-amber-500/10 border border-amber-500/20 rounded-md">
                  En Vivo
                </span>
              </div>
              <p className="text-xs text-slate-400 max-w-xl leading-relaxed">
                El motor analiza la frecuencia de transitorios del archivo reproducido (MP3, OGG o WAV)
                y modula los nodos DSP exactamente al compás de la pista.
              </p>
            </div>

            <button
              onClick={() => handleUpdate({ dynamicRhythmFx: !settings.dynamicRhythmFx })}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition flex items-center gap-2 shrink-0 ${
                settings.dynamicRhythmFx
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>{settings.dynamicRhythmFx ? 'Activado' : 'Desactivado'}</span>
            </button>
          </div>

          {/* Mode Selector */}
          <div className="space-y-3">
            <label className="text-xs font-medium text-slate-300 uppercase tracking-wider">
              Tipo de Modificación Rítmica
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                {
                  id: 'pump' as DynamicFxMode,
                  title: 'Pump / Sidechain Dinámico',
                  desc: 'Atenúa y bombea la ganancia rítmicamente en cada golpe de bajo como en música de club.',
                  icon: Activity,
                },
                {
                  id: 'autofilter' as DynamicFxMode,
                  title: 'Auto-Filtro Sincronizado',
                  desc: 'Barrer la frecuencia del filtro paso-bajo en perfecta sincronización con el tempo detectado.',
                  icon: Sliders,
                },
                {
                  id: 'gater' as DynamicFxMode,
                  title: 'Gater Rítmico (Stutter)',
                  desc: 'Pulsos de volumen estroboscópicos a subdivisiones de compás exactas.',
                  icon: Zap,
                },
                {
                  id: 'autopan' as DynamicFxMode,
                  title: 'Auto-Pan Estéreo 3D',
                  desc: 'Oscila el campo sonoro espacial entre auricular izquierdo y derecho al compás.',
                  icon: Headphones,
                },
                {
                  id: 'subpunch' as DynamicFxMode,
                  title: 'Sub-Punch Transient Exciter',
                  desc: 'Inyección de armónicos subgraves ultra profundos cada vez que golpea el bombo.',
                  icon: Volume2,
                },
                {
                  id: 'reverbbreath' as DynamicFxMode,
                  title: 'Reverb Breath (Expansión Espacial)',
                  desc: 'La reverberación envolvente respira y se amplía con la intensidad del ritmo musical.',
                  icon: Waves,
                },
              ].map((fx) => {
                const Icon = fx.icon;
                const isSelected = settings.dynamicFxMode === fx.id;
                return (
                  <button
                    key={fx.id}
                    onClick={() => handleUpdate({ dynamicFxMode: fx.id, dynamicRhythmFx: true })}
                    className={`p-4 rounded-xl text-left border transition flex flex-col justify-between ${
                      isSelected
                        ? 'bg-indigo-600/15 border-indigo-500/80 text-white shadow-md shadow-indigo-500/10'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className={`text-xs font-semibold ${isSelected ? 'text-indigo-300' : 'text-slate-200'}`}>
                          {fx.title}
                        </span>
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">{fx.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Controls: Intensity, Division, Sensitivity */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-5 bg-slate-900/70 border border-slate-800 rounded-2xl">
            {/* Intensity */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Intensidad del Efecto</span>
                <span className="font-mono tabular-nums text-indigo-400 font-semibold">
                  {settings.dynamicFxIntensity}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.dynamicFxIntensity}
                onChange={(e) => handleUpdate({ dynamicFxIntensity: Number(e.target.value) })}
                className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Division */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">División Rítmica</span>
                <span className="font-mono text-slate-200 font-semibold">{settings.dynamicFxDivision}</span>
              </div>
              <div className="grid grid-cols-4 gap-1">
                {(['1/1', '1/2', '1/4', '1/8'] as const).map((div) => (
                  <button
                    key={div}
                    onClick={() => handleUpdate({ dynamicFxDivision: div })}
                    className={`py-1.5 text-xs font-mono font-medium rounded-lg border transition ${
                      settings.dynamicFxDivision === div
                        ? 'bg-indigo-600 border-indigo-500 text-white'
                        : 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {div}
                  </button>
                ))}
              </div>
            </div>

            {/* Sensitivity */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Sensibilidad a Transitorios</span>
                <span className="font-mono tabular-nums text-slate-200 font-semibold">
                  {Math.round(settings.dynamicFxSensitivity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={settings.dynamicFxSensitivity}
                onChange={(e) => handleUpdate({ dynamicFxSensitivity: Number(e.target.value) })}
                className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: EQUALIZER 10 BANDAS */}
      {activeSubTab === 'eq' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Preset Selector & Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Preset:</span>
              <select
                value={settings.eqPreset}
                onChange={(e) => handleApplyPreset(e.target.value)}
                className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 border border-slate-800 rounded-xl focus:outline-none focus:border-indigo-500"
              >
                <optgroup label="Presets de Estudio">
                  {Object.keys(EQ_PRESETS).map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </optgroup>
                {Object.keys(savedPresets).length > 0 && (
                  <optgroup label="Mis Presets Guardados">
                    {Object.keys(savedPresets).map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </optgroup>
                )}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSavePreset(!showSavePreset)}
                className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-xl transition"
              >
                Guardar Preset
              </button>
              <button
                onClick={handleResetEQ}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-xl transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restablecer</span>
              </button>
            </div>
          </div>

          {showSavePreset && (
            <div className="flex items-center gap-2 p-3 bg-slate-900 border border-slate-800 rounded-xl">
              <input
                type="text"
                placeholder="Nombre del preset (ej: Mis Bajos Favoritos)"
                value={newPresetName}
                onChange={(e) => setNewPresetName(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none"
              />
              <button
                onClick={handleSavePreset}
                className="px-3 py-1.5 text-xs font-semibold bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Guardar
              </button>
            </div>
          )}

          {/* PreAmp Gain Slider */}
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-slate-400" />
              <span className="text-xs font-medium text-slate-300">Pre-Amp Master</span>
            </div>
            <div className="flex items-center gap-3 flex-1 max-w-xs">
              <input
                type="range"
                min="-12"
                max="12"
                step="0.5"
                value={settings.preAmp}
                onChange={(e) => handleUpdate({ preAmp: Number(e.target.value) })}
                className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono tabular-nums text-slate-300 w-12 text-right">
                {settings.preAmp > 0 ? `+${settings.preAmp}` : settings.preAmp} dB
              </span>
            </div>
          </div>

          {/* 10 Vertical Sliders */}
          <div className="p-6 bg-slate-900/80 border border-slate-800 rounded-2xl">
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-3 sm:gap-4 items-end justify-items-center h-64">
              {EQ_FREQUENCIES.map((freq, idx) => {
                const gain = settings.eqBands[idx] || 0;
                return (
                  <div key={freq} className="flex flex-col items-center justify-between h-full w-full">
                    <span className="text-[11px] font-mono tabular-nums text-indigo-400 font-semibold mb-2">
                      {gain > 0 ? `+${gain}` : gain}
                    </span>

                    {/* Vertical Slider */}
                    <div className="relative flex-1 flex items-center justify-center">
                      <input
                        type="range"
                        min="-12"
                        max="12"
                        step="0.5"
                        value={gain}
                        onChange={(e) => handleBandChange(idx, Number(e.target.value))}
                        className="h-44 -rotate-90 w-44 accent-indigo-500 bg-slate-800 cursor-pointer rounded-lg"
                        style={{ appearance: 'auto' }}
                      />
                    </div>

                    <div className="text-center mt-2">
                      <span className="text-[11px] font-mono font-medium text-slate-300 block">
                        {formatHz(freq)}
                      </span>
                      <span className="text-[9px] text-slate-500">Hz</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: TONO (GRAVE A AGUDO) */}
      {activeSubTab === 'tone' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Tone Balance: Grave a Agudo */}
          <div className="p-6 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Balance Espectral de Tono (Grave ↔ Agudo)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Desplaza el peso tonal de la canción: desde graves oscuros y cálidos hasta agudos brillantes y cristalinos.
                </p>
              </div>
              <span className="text-xs font-mono tabular-nums px-2.5 py-1 rounded-md bg-slate-800 text-indigo-300 font-medium">
                {settings.toneTilt === 0
                  ? 'Neutro (0)'
                  : settings.toneTilt < 0
                  ? `Grave (${settings.toneTilt})`
                  : `Agudo (+${settings.toneTilt})`}
              </span>
            </div>

            <div className="relative pt-3 pb-1">
              <input
                type="range"
                min="-100"
                max="100"
                value={settings.toneTilt}
                onChange={(e) => handleUpdate({ toneTilt: Number(e.target.value) })}
                className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-2">
                <span className="text-cyan-400 font-medium">◄ Ultra Grave (Cálido)</span>
                <button
                  onClick={() => handleUpdate({ toneTilt: 0 })}
                  className="text-slate-500 hover:text-white"
                >
                  Neutro
                </button>
                <span className="text-pink-400 font-medium">Ultra Agudo (Brillante) ►</span>
              </div>
            </div>

            {/* Quick Presets for Tone */}
            <div className="grid grid-cols-5 gap-2 pt-2">
              {[
                { label: 'Sub-Grave', val: -80 },
                { label: 'Cálido', val: -35 },
                { label: 'Plano', val: 0 },
                { label: 'Claridad', val: 35 },
                { label: 'Cristalino', val: 80 },
              ].map((p) => (
                <button
                  key={p.label}
                  onClick={() => handleUpdate({ toneTilt: p.val })}
                  className={`py-1.5 text-xs rounded-lg border transition ${
                    settings.toneTilt === p.val
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Musical Pitch Transposition (Semitonos) */}
          <div className="p-6 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Afinación / Tono Musical (Pitch Shift)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Cambia la afinación fundamental de las voces e instrumentos desde grave hasta agudo en semitonos.
                </p>
              </div>
              <span className="text-xs font-mono tabular-nums px-2.5 py-1 rounded-md bg-slate-800 text-indigo-300 font-medium">
                {settings.pitchShift > 0
                  ? `+${settings.pitchShift} Semitonos (Agudo)`
                  : settings.pitchShift < 0
                  ? `${settings.pitchShift} Semitonos (Grave)`
                  : 'Tono Original (0)'}
              </span>
            </div>

            <div className="space-y-2">
              <input
                type="range"
                min="-12"
                max="12"
                step="1"
                value={settings.pitchShift}
                onChange={(e) => handleUpdate({ pitchShift: Number(e.target.value) })}
                className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-slate-400">
                <span className="text-indigo-400">-12 (Octava Grave / Slowed)</span>
                <span className="text-slate-500">0 (Original)</span>
                <span className="text-pink-400">+12 (Octava Aguda / Nightcore)</span>
              </div>
            </div>

            {/* Quick buttons */}
            <div className="flex flex-wrap items-center gap-2">
              {[
                { label: '-12st (Grave)', val: -12 },
                { label: '-6st', val: -6 },
                { label: '-2st', val: -2 },
                { label: 'Original', val: 0 },
                { label: '+2st', val: 2 },
                { label: '+6st', val: 6 },
                { label: '+12st (Agudo)', val: 12 },
              ].map((btn) => (
                <button
                  key={btn.label}
                  onClick={() => handleUpdate({ pitchShift: btn.val })}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition ${
                    settings.pitchShift === btn.val
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-slate-800 border-slate-700/60 text-slate-300 hover:text-white'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>

            {/* Pitch preservation toggle */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-400">Modo Vinilo / Efecto de cinta analógica:</span>
              <button
                onClick={() => handleUpdate({ preservePitchWithSpeed: !settings.preservePitchWithSpeed })}
                className={`px-3 py-1 text-xs font-medium rounded-lg border transition ${
                  !settings.preservePitchWithSpeed
                    ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-300'
                    : 'bg-slate-800 border-slate-700 text-slate-400'
                }`}
              >
                {!settings.preservePitchWithSpeed ? 'Vinilo Analógico (Tono + Tiempo)' : 'Pitch Digital'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 4: BAJOS & REVERB ENVOLVENTE */}
      {activeSubTab === 'bass_reverb' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-200">
          {/* Bass Boost Card */}
          <div className="p-6 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>Mejora de Bajos Configurable</span>
              </h3>
              <span className="text-xs font-mono tabular-nums text-cyan-400 font-semibold">
                +{Math.round((settings.bassBoost / 100) * 15)} dB
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Intensidad de Refuerzo</span>
                <span className="font-mono text-slate-200">{settings.bassBoost}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.bassBoost}
                onChange={(e) => handleUpdate({ bassBoost: Number(e.target.value) })}
                className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Frecuencia de Corte de Subgraves</span>
                <span className="font-mono text-slate-200">{settings.bassFreq} Hz</span>
              </div>
              <input
                type="range"
                min="50"
                max="120"
                value={settings.bassFreq}
                onChange={(e) => handleUpdate({ bassFreq: Number(e.target.value) })}
                className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Saturación Armónica de Bajos (Drive)</span>
                <span className="font-mono text-slate-200">{settings.bassDrive}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.bassDrive}
                onChange={(e) => handleUpdate({ bassDrive: Number(e.target.value) })}
                className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>

          {/* Surround & Reverb Card */}
          <div className="p-6 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Waves className="w-4 h-4 text-purple-400" />
                <span>Reverberación Envolvente 3D</span>
              </h3>
              <span className="text-xs font-mono tabular-nums text-purple-400 font-semibold">
                {settings.surroundReverb}% Wet
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Mezcla Envolvente</span>
                <span className="font-mono text-slate-200">{settings.surroundReverb}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.surroundReverb}
                onChange={(e) => handleUpdate({ surroundReverb: Number(e.target.value) })}
                className="w-full accent-purple-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs text-slate-400 block">Tamaño Acústico de Sala</label>
              <div className="grid grid-cols-4 gap-1.5">
                {(['small', 'studio', 'hall', 'cathedral'] as ReverbRoomSize[]).map((room) => {
                  const names: Record<ReverbRoomSize, string> = {
                    small: 'Sala',
                    studio: 'Estudio',
                    hall: 'Concierto',
                    cathedral: 'Catedral',
                  };
                  return (
                    <button
                      key={room}
                      onClick={() => handleUpdate({ reverbRoom: room })}
                      className={`py-1.5 text-xs rounded-lg border transition ${
                        settings.reverbRoom === room
                          ? 'bg-purple-600 border-purple-500 text-white'
                          : 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {names[room]}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Amplitud Estéreo Espacial</span>
                <span className="font-mono text-slate-200">{settings.stereoWidth}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="200"
                value={settings.stereoWidth}
                onChange={(e) => handleUpdate({ stereoWidth: Number(e.target.value) })}
                className="w-full accent-purple-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
