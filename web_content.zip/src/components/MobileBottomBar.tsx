import React from "react";
import { UtensilsCrossed, Phone, MapPin, MessageSquare, ShoppingBag } from "lucide-react";
import { RESTAURANT_INFO } from "../data/restaurantInfo";

interface MobileBottomBarProps {
  onOpenMenu: () => void;
  onOpenConcierge: () => void;
  onOrderOnline: () => void;
  dishCount?: number;
}

export const MobileBottomBar: React.FC<MobileBottomBarProps> = ({
  onOpenMenu,
  onOpenConcierge,
  onOrderOnline,
  dishCount = 0,
}) => {
  const scrollToMap = () => {
    const elem = document.getElementById("visit");
    if (elem) {
      elem.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      aria-label="Mobile Quick Actions"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#FDFBF7]/95 backdrop-blur-md border-t border-[#D8D0C2] px-2 py-2 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] pb-[max(0.5rem,env(safe-area-inset-bottom))]"
    >
      <div className="max-w-md mx-auto grid grid-cols-5 gap-1 items-center text-center">
        {/* 1. Full Digital Menu */}
        <button
          type="button"
          onClick={onOpenMenu}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xs text-[#17201C] hover:bg-[#EAE4D7]/60 active:scale-95 transition-all cursor-pointer group"
        >
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-[#17201C] text-[#F4F0E7] flex items-center justify-center group-hover:bg-[#9BAF82] group-hover:text-[#17201C] transition-colors shadow-xs">
              <UtensilsCrossed className="w-4 h-4" />
            </div>
            {dishCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#9BAF82] text-[#17201C] text-[9px] font-bold font-mono px-1 rounded-full border border-white">
                {dishCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium tracking-tight mt-1 text-[#17201C]">
            Menu
          </span>
        </button>

        {/* 2. Direct Call (Instant Dialer) */}
        <a
          href={`tel:${RESTAURANT_INFO.phone}`}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xs text-[#17201C] hover:bg-[#EAE4D7]/60 active:scale-95 transition-all cursor-pointer group"
          title={`Call ${RESTAURANT_INFO.phoneDisplay}`}
        >
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-[#9BAF82]/25 text-[#17201C] border border-[#9BAF82]/50 flex items-center justify-center group-hover:bg-[#9BAF82] transition-colors">
              <Phone className="w-4 h-4 text-emerald-800" />
            </div>
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-600 animate-pulse border border-white" />
          </div>
          <span className="text-[10px] font-medium tracking-tight mt-1 text-emerald-900 font-semibold">
            Direct Call
          </span>
        </a>

        {/* 3. Real-Time Map & Directions */}
        <button
          type="button"
          onClick={scrollToMap}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xs text-[#17201C]/80 hover:text-[#17201C] hover:bg-[#EAE4D7]/60 active:scale-95 transition-all cursor-pointer"
        >
          <div className="w-8 h-8 rounded-full bg-[#F4F0E7] border border-[#D8D0C2] flex items-center justify-center text-[#17201C]">
            <MapPin className="w-4 h-4 text-[#9BAF82]" />
          </div>
          <span className="text-[10px] font-medium tracking-tight mt-1">
            Map & Visit
          </span>
        </button>

        {/* 4. AI Nutrition Concierge */}
        <button
          type="button"
          onClick={onOpenConcierge}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xs text-[#17201C]/80 hover:text-[#17201C] hover:bg-[#EAE4D7]/60 active:scale-95 transition-all cursor-pointer"
        >
          <div className="w-8 h-8 rounded-full bg-[#F4F0E7] border border-[#D8D0C2] flex items-center justify-center text-[#17201C]">
            <MessageSquare className="w-4 h-4 text-[#9BAF82]" />
          </div>
          <span className="text-[10px] font-medium tracking-tight mt-1">
            Concierge
          </span>
        </button>

        {/* 5. Order / Reserve */}
        <button
          type="button"
          onClick={onOrderOnline}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xs text-[#17201C] hover:bg-[#EAE4D7]/60 active:scale-95 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-full bg-[#17201C] text-[#F4F0E7] flex items-center justify-center group-hover:bg-[#B96D52] transition-colors shadow-xs">
            <ShoppingBag className="w-4 h-4 text-[#9BAF82]" />
          </div>
          <span className="text-[10px] font-medium tracking-tight mt-1 text-[#17201C]">
            Order
          </span>
        </button>
      </div>
    </nav>
  );
};
