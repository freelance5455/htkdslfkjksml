import React, { useState, useEffect } from 'react';
import { 
  Bluetooth, RefreshCw, Smartphone, Headphones, Tv, Car, 
  Wifi, X, AlertCircle, CheckCircle, Power, Trash2, Plus, 
  Radio, Cast, Activity, SignalHigh, SignalMedium 
} from 'lucide-react';
import { deviceService, SavedDevice } from '../services/deviceService';

interface DeviceDiscoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeviceConnected?: (name: string) => void;
}

export const DeviceDiscoveryModal: React.FC<DeviceDiscoveryModalProps> = ({ 
  isOpen, 
  onClose,
  onDeviceConnected,
}) => {
  const [devices, setDevices] = useState<SavedDevice[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [scanning, setScanning] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isAddingCustom, setIsAddingCustom] = useState(false);

  // New device form state
  const [newDeviceName, setNewDeviceName] = useState('');
  const [newDeviceLabel, setNewDeviceLabel] = useState('');
  const [newDeviceCat, setNewDeviceCat] = useState<SavedDevice['category']>('car');

  const refreshDeviceList = () => {
    const list = deviceService.getDevices();
    setDevices(list);
  };

  useEffect(() => {
    if (isOpen) {
      refreshDeviceList();
      setStatusMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleScanBluetooth = async () => {
    setStatusMessage(null);
    setScanning(true);
    const result = await deviceService.scanBluetooth();
    setScanning(false);
    refreshDeviceList();
    setStatusMessage(result.message);
    if (result.success && result.device && onDeviceConnected) {
      onDeviceConnected(result.device.name);
    }
  };

  const handleToggleConnect = async (dev: SavedDevice) => {
    if (dev.isConnected) {
      const res = await deviceService.disconnectDevice(dev.id);
      setStatusMessage(res.message);
    } else {
      const res = await deviceService.connectDevice(dev.id);
      setStatusMessage(res.message);
      if (res.success && onDeviceConnected) {
        onDeviceConnected(dev.name);
      }
    }
    refreshDeviceList();
  };

  const handleForgetDevice = (dev: SavedDevice) => {
    deviceService.forgetDevice(dev.id);
    refreshDeviceList();
    setStatusMessage(`Device "${dev.name}" removed from memory, Harman Sir.`);
  };

  const handleCreateCustomDevice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeviceName.trim()) return;

    const newDev: SavedDevice = {
      id: `dev-${newDeviceCat}-${Date.now()}`,
      name: newDeviceName.trim(),
      customLabel: newDeviceLabel.trim() || newDeviceName.trim(),
      category: newDeviceCat,
      connectionType: newDeviceCat === 'tv' ? 'cast' : 'bluetooth',
      isPaired: true,
      isConnected: false,
      lastConnectedTime: Date.now(),
      signalStrength: -50,
    };

    deviceService.saveDevice(newDev);
    refreshDeviceList();
    setIsAddingCustom(false);
    setNewDeviceName('');
    setNewDeviceLabel('');
    setStatusMessage(`Registered "${newDev.name}" into device memory, Harman Sir.`);
  };

  const filteredDevices = selectedCategory === 'all' 
    ? devices 
    : devices.filter(d => d.category === selectedCategory);

  const getCategoryIcon = (cat: SavedDevice['category']) => {
    switch (cat) {
      case 'car': return <Car className="w-4 h-4 text-amber-400" />;
      case 'tv': return <Tv className="w-4 h-4 text-cyan-400" />;
      case 'audio': return <Headphones className="w-4 h-4 text-indigo-400" />;
      default: return <Smartphone className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100 flex items-center gap-2">
              UNIVERSAL DEVICE REGISTRY & MEMORY
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono-tech">
                CAR • TV • AUDIO • BLUETOOTH
              </span>
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action & Filter Bar */}
        <div className="px-5 pt-4 pb-2 border-b border-cyan-500/20 space-y-3 bg-gray-950/40">
          <div className="flex items-center justify-between gap-2">
            <button
              onClick={handleScanBluetooth}
              disabled={scanning}
              className="px-3.5 py-1.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-gray-950 font-bold text-xs uppercase rounded-xl transition-all flex items-center gap-1.5 cursor-pointer glow-cyan-sm font-tech"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${scanning ? 'animate-spin' : ''}`} />
              {scanning ? 'Scanning...' : 'Scan Bluetooth'}
            </button>

            <button
              onClick={() => setIsAddingCustom(!isAddingCustom)}
              className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-cyan-200 text-xs uppercase rounded-xl transition-all flex items-center gap-1 font-tech border border-cyan-500/30 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-cyan-400" />
              {isAddingCustom ? 'Cancel' : 'Remember Device'}
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-mono-tech">
            {['all', 'car', 'tv', 'audio', 'smart_home'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg uppercase tracking-wider text-[11px] transition-all cursor-pointer ${
                  selectedCategory === cat 
                    ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400 font-bold glow-cyan-sm' 
                    : 'bg-gray-900 text-cyan-400/60 border border-cyan-500/10 hover:text-cyan-300'
                }`}
              >
                {cat === 'all' ? 'All Devices' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4">
          
          {/* Status Message */}
          {statusMessage && (
            <div className="p-3 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-200 text-xs flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* Add Custom Device Form */}
          {isAddingCustom && (
            <form onSubmit={handleCreateCustomDevice} className="p-4 rounded-xl bg-gray-950 border border-cyan-500/40 space-y-3">
              <div className="text-xs font-tech uppercase text-cyan-200 font-bold">
                Remember New Device in JARVIS Memory
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Device Name (e.g. Creta Infotainment / LG OLED TV)"
                  value={newDeviceName}
                  onChange={(e) => setNewDeviceName(e.target.value)}
                  required
                  className="px-3 py-1.5 rounded-lg bg-gray-900 border border-cyan-500/30 text-xs text-cyan-100 placeholder:text-gray-500 font-mono-tech"
                />
                <input
                  type="text"
                  placeholder="Custom Nickname (e.g. My Car, Living Room)"
                  value={newDeviceLabel}
                  onChange={(e) => setNewDeviceLabel(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-gray-900 border border-cyan-500/30 text-xs text-cyan-100 placeholder:text-gray-500 font-mono-tech"
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <select
                  value={newDeviceCat}
                  onChange={(e) => setNewDeviceCat(e.target.value as any)}
                  className="px-3 py-1.5 rounded-lg bg-gray-900 border border-cyan-500/30 text-xs text-cyan-200 font-mono-tech uppercase"
                >
                  <option value="car">Car Infotainment</option>
                  <option value="tv">Smart TV / Screen</option>
                  <option value="audio">Headphones / Audio</option>
                  <option value="smart_home">Smart Home / IoT</option>
                  <option value="other">Other Peripheral</option>
                </select>

                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-gray-950 font-bold text-xs uppercase font-tech cursor-pointer"
                >
                  Save to Registry
                </button>
              </div>
            </form>
          )}

          {/* Device List */}
          <div className="space-y-2.5">
            {filteredDevices.length === 0 ? (
              <div className="text-center py-8 text-cyan-400/50 text-xs font-mono-tech">
                No devices found in this category. Click "Scan Bluetooth" or "Remember Device".
              </div>
            ) : (
              filteredDevices.map((dev) => (
                <div
                  key={dev.id}
                  className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                    dev.isConnected
                      ? 'bg-cyan-950/50 border-cyan-400 glow-cyan-sm'
                      : 'bg-gray-950/70 border-cyan-500/20 hover:border-cyan-500/40'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`p-2.5 rounded-xl border ${dev.isConnected ? 'bg-cyan-500/20 border-cyan-400' : 'bg-gray-900 border-gray-800'}`}>
                      {getCategoryIcon(dev.category)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-cyan-100 font-tech truncate">
                          {dev.name}
                        </span>
                        {dev.isConnected && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono-tech font-bold uppercase">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-cyan-400/70 font-mono-tech">
                        <span>Label: {dev.customLabel}</span>
                        <span>•</span>
                        <span className="uppercase">{dev.connectionType}</span>
                        {dev.signalStrength && (
                          <>
                            <span>•</span>
                            <span>{dev.signalStrength} dBm</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleToggleConnect(dev)}
                      className={`px-3 py-1.5 rounded-xl font-tech text-xs uppercase flex items-center gap-1.5 transition-all cursor-pointer ${
                        dev.isConnected
                          ? 'bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40'
                          : 'bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400'
                      }`}
                    >
                      <Power className="w-3.5 h-3.5" />
                      {dev.isConnected ? 'Disconnect' : 'Connect'}
                    </button>

                    <button
                      onClick={() => handleForgetDevice(dev)}
                      title="Forget this device"
                      className="p-1.5 rounded-lg bg-gray-900 hover:bg-red-500/20 text-gray-400 hover:text-red-300 border border-gray-800 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Voice Prompt Help */}
          <div className="p-3 rounded-xl bg-gray-950/80 border border-cyan-500/20 text-xs space-y-1">
            <div className="font-tech uppercase text-cyan-300 font-bold">
              Supported Voice Commands (Hindi / English / Punjabi):
            </div>
            <div className="text-[11px] text-cyan-400/70 space-y-0.5 font-mono-tech">
              <div>• "Meri car se connect ho jao" / "Connect to my car"</div>
              <div>• "Mere TV se connect ho jao" / "Connect to my TV"</div>
              <div>• "Mere Bluetooth headphones connect kar do" / "Connect to my saved headphones"</div>
              <div>• "Remember this device as my car [Name]" / "Car ko register karo"</div>
              <div>• "Forget my old TV" / "TV ko disconnect ya bhool jao"</div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
