import React from 'react';
import { Logo } from './Logo';
import { Project, UserSession } from '../types';
import { Terminal as TerminalIcon, Sun, Moon, LogOut } from 'lucide-react';

interface MobileHeaderProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  session: UserSession | null;
  activeProject: Project;
  siteTheme: string;
  onToggleTheme: () => void;
  onToggleTerminal: () => void;
  isTerminalOpen: boolean;
  onSignOut: () => void;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  activeTab,
  onSelectTab,
  session,
  activeProject,
  siteTheme,
  onToggleTheme,
  onToggleTerminal,
  isTerminalOpen,
  onSignOut,
}) => {
  const isLight = siteTheme === 'vscode-light' || siteTheme === 'github-light';

  return (
    <header className="h-12 theme-bg-header border-b theme-border px-3 flex items-center justify-between shrink-0 select-none z-30 transition-colors">
      <div className="flex items-center space-x-2 truncate">
        <div
          onClick={() => onSelectTab(activeTab === 'home' ? 'editor' : 'home')}
          className="cursor-pointer"
        >
          <Logo size="sm" showName={false} />
        </div>
        <span className="text-xs font-bold theme-text-main truncate max-w-[120px]">
          {activeProject?.name || 'My Project'}
        </span>
      </div>

      <div className="flex items-center space-x-2">
        {/* Terminal button */}
        <button
          onClick={onToggleTerminal}
          className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
            isTerminalOpen
              ? 'bg-cyan-500 text-white border-cyan-400'
              : 'theme-bg-surface text-cyan-400 border-transparent hover:theme-text-main'
          }`}
          title="Terminal Console"
        >
          <TerminalIcon className="w-4 h-4" />
        </button>

        {/* Theme toggle */}
        <button
          onClick={onToggleTheme}
          className="p-1.5 theme-text-muted hover:theme-text-main rounded-lg transition-colors cursor-pointer"
          title="Toggle Light / Dark"
        >
          {isLight ? (
            <Moon className="w-4 h-4 text-indigo-400" />
          ) : (
            <Sun className="w-4 h-4 text-amber-400" />
          )}
        </button>

        {/* User avatar or sign out */}
        {session && (
          <button
            onClick={onSignOut}
            className="p-1.5 theme-text-muted hover:text-red-400 rounded-lg transition-colors cursor-pointer"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        )}
      </div>
    </header>
  );
};
