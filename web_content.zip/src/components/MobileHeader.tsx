import React from 'react';
import { Menu, RefreshCw, Wifi, WifiOff, Truck } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface MobileHeaderProps {
  onOpenDrawer: () => void;
  isOnline: boolean;
  pendingCount: number;
  onSync: () => void;
  isSyncing: boolean;
  selectedDay: string;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  onOpenDrawer,
  isOnline,
  pendingCount,
  onSync,
  isSyncing,
  selectedDay,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-lg pt-[var(--sat)] select-none">
      <div className="max-w-4xl mx-auto px-3.5 py-2.5 flex items-center justify-between gap-2">
        {/* Left: Menu & Brand */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenDrawer}
            aria-label="القائمة الجانبية"
            className="w-10 h-10 rounded-xl bg-slate-800/80 border border-slate-700/60 text-slate-200 flex items-center justify-center active:scale-95 transition"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-base font-black tracking-tight text-amber-400">مندوب برو</span>
              <span className="text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded-full">
                {selectedDay}
              </span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-slate-400">
              <Truck className="w-3 h-3 text-emerald-400" />
              <span>VAN-9902</span>
            </div>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* PWA install prompt button */}
          <PWAInstallButton />

          {/* Sync Button */}
          <button
            onClick={onSync}
            disabled={isSyncing}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition active:scale-95 ${
              pendingCount > 0
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                : 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:text-white'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-400' : ''}`} />
            <span>{isSyncing ? 'جاري…' : 'مزامنة'}</span>
            {pendingCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center">
                {pendingCount}
              </span>
            )}
          </button>

          {/* Online status indicator */}
          <div
            className={`w-3 h-3 rounded-full flex items-center justify-center transition ${
              isOnline ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'
            }`}
            title={isOnline ? 'متصل بالإنترنت' : 'يعمل دون إنترنت (Offline)'}
          >
            {isOnline ? (
              <span className="sr-only">متصل</span>
            ) : (
              <span className="sr-only">غير متصل</span>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
