import React from 'react';
import { Flame, Bell, Wallet, Smartphone, Monitor, ShieldAlert, Globe } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { APP_CONFIG } from '../config/appConfig';

export const TopBar: React.FC = () => {
  const { 
    user, 
    currentTab, 
    setCurrentTab, 
    notifications, 
    language, 
    setLanguage, 
    deviceMode, 
    setDeviceMode,
    setIsAdminModalOpen
  } = useApp();

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0b0e14]/95 backdrop-blur-md border-b border-red-950/40">
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <button 
          onClick={() => setCurrentTab('home')}
          className="flex items-center gap-2 group text-left cursor-pointer shrink-0"
        >
          <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-600/40 flex items-center justify-center text-red-500 shadow-sm shadow-red-900/30 group-hover:bg-red-600 group-hover:text-white transition-all">
            <Flame className="w-4 h-4 fill-current" />
          </div>
          <span className="font-display font-extrabold text-base tracking-wider text-white whitespace-nowrap">
            {APP_CONFIG.appName}
          </span>
        </button>

        {/* Zone 2: 4-5 concise single-line nav links (desktop) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button 
            onClick={() => setCurrentTab('home')}
            className={`whitespace-nowrap transition-colors hover:text-white ${currentTab === 'home' ? 'text-red-500 font-semibold' : ''}`}
          >
            {language === 'bn' ? 'হোম' : 'Home'}
          </button>
          <button 
            onClick={() => setCurrentTab('tournaments')}
            className={`whitespace-nowrap transition-colors hover:text-white ${currentTab === 'tournaments' ? 'text-red-500 font-semibold' : ''}`}
          >
            {language === 'bn' ? 'টুর্নামেন্ট' : 'Tournaments'}
          </button>
          <button 
            onClick={() => setCurrentTab('my-matches')}
            className={`whitespace-nowrap transition-colors hover:text-white ${currentTab === 'my-matches' ? 'text-red-500 font-semibold' : ''}`}
          >
            {language === 'bn' ? 'আমার ম্যাচ' : 'My Matches'}
          </button>
          <button 
            onClick={() => setCurrentTab('results')}
            className={`whitespace-nowrap transition-colors hover:text-white ${currentTab === 'results' ? 'text-red-500 font-semibold' : ''}`}
          >
            {language === 'bn' ? 'ফলাফল' : 'Results'}
          </button>
          <button 
            onClick={() => setCurrentTab('leaderboard')}
            className={`whitespace-nowrap transition-colors hover:text-white ${currentTab === 'leaderboard' ? 'text-red-500 font-semibold' : ''}`}
          >
            {language === 'bn' ? 'লিডারবোর্ড' : 'Leaderboard'}
          </button>
          <button 
            onClick={() => setCurrentTab('support')}
            className={`whitespace-nowrap transition-colors hover:text-white ${currentTab === 'support' ? 'text-red-500 font-semibold' : ''}`}
          >
            {language === 'bn' ? 'সাপোর্ট' : 'Support'}
          </button>
        </nav>

        {/* Zone 3: Primary action zone */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Android Frame / Desktop View Toggle */}
          <button
            onClick={() => setDeviceMode(deviceMode === 'android' ? 'expanded' : 'android')}
            title={deviceMode === 'android' ? 'Switch to Full-Width Responsive View' : 'Switch to Android Native Phone Simulator'}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-medium transition-colors"
          >
            {deviceMode === 'android' ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-blue-400" />
                <span className="hidden sm:inline">Desktop</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-red-400" />
                <span className="hidden sm:inline">Android APK</span>
              </>
            )}
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
            title="Toggle Language (English / বাংলা)"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'en' ? 'বাংলা' : 'EN'}</span>
          </button>

          {/* Notifications Bell */}
          <button
            onClick={() => setCurrentTab('notifications')}
            className="relative p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center font-mono animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Quick Wallet Button */}
          <button
            onClick={() => setCurrentTab('wallet')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white rounded-lg font-semibold text-xs transition-transform active:scale-95 shadow-sm shadow-red-950"
          >
            <Wallet className="w-3.5 h-3.5" />
            <span className="font-mono tabular-nums">৳{user.walletBalance}</span>
          </button>

          {/* Admin Control Trigger */}
          <button
            onClick={() => setIsAdminModalOpen(true)}
            className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 transition-colors"
            title="Admin Suite & 100K Load Tester"
          >
            <ShieldAlert className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
