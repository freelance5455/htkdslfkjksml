import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  ChevronDown,
  Download,
  FolderOpen,
  KeyRound,
  Monitor,
  MoreVertical,
  PlusCircle,
  Search,
} from 'lucide-react';
import { PROVIDER_META } from '../constants/models';
import type { ApiKeysMap, ModelOption, ProviderId } from '../types/mycode';

interface TopBarProps {
  models: ModelOption[];
  activeModel: ModelOption;
  onSelectModel: (modelId: string) => void;
  apiKeys: ApiKeysMap;
  hasServerGeminiKey: boolean;
  desktopView: boolean;
  onToggleDesktopView: () => void;
  onOpenApiKeys: () => void;
  onOpenWorkspace: () => void;
  onNewSession: () => void;
  onExportZip: () => void;
  workspaceFileCount: number;
}

export function TopBar({
  models,
  activeModel,
  onSelectModel,
  apiKeys,
  hasServerGeminiKey,
  desktopView,
  onToggleDesktopView,
  onOpenApiKeys,
  onOpenWorkspace,
  onNewSession,
  onExportZip,
  workspaceFileCount,
}: TopBarProps) {
  const [modelMenuOpen, setModelMenuOpen] = useState(false);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [tierFilter, setTierFilter] = useState<'All' | 'Free' | 'Paid'>('All');
  const [modelQuery, setModelQuery] = useState('');

  const modelMenuRef = useRef<HTMLDivElement>(null);
  const moreMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleOutsideClick(event: MouseEvent) {
      const target = event.target as Node;
      if (modelMenuRef.current && !modelMenuRef.current.contains(target)) {
        setModelMenuOpen(false);
      }
      if (moreMenuRef.current && !moreMenuRef.current.contains(target)) {
        setMoreMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const isProviderConfigured = (provider: ProviderId): boolean => {
    if (provider === 'google') {
      return Boolean(apiKeys.google?.trim() || hasServerGeminiKey);
    }
    return Boolean(apiKeys[provider]?.trim());
  };

  const { freeModels, paidModels, totalFree, totalPaid } = useMemo(() => {
    const q = modelQuery.trim().toLowerCase();
    const matchesQuery = (m: ModelOption) =>
      !q ||
      m.label.toLowerCase().includes(q) ||
      m.id.toLowerCase().includes(q) ||
      PROVIDER_META[m.provider].name.toLowerCase().includes(q);

    const allFree = models.filter((m) => m.tier === 'Free');
    const allPaid = models.filter((m) => m.tier === 'Paid');

    return {
      freeModels: tierFilter === 'Paid' ? [] : allFree.filter(matchesQuery),
      paidModels: tierFilter === 'Free' ? [] : allPaid.filter(matchesQuery),
      totalFree: allFree.length,
      totalPaid: allPaid.length,
    };
  }, [models, tierFilter, modelQuery]);

  const renderModelRow = (model: ModelOption) => {
    const selected = model.id === activeModel.id;
    const ready = isProviderConfigured(model.provider);
    return (
      <button
        key={model.id}
        type="button"
        role="menuitem"
        onClick={() => {
          onSelectModel(model.id);
          setModelMenuOpen(false);
        }}
        className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 text-left transition-colors ${
          selected ? 'bg-[#F3F4F6]' : 'hover:bg-[#F9FAFB]'
        }`}
      >
        <div className="min-w-0 flex-1">
          <div className="truncate text-[13px] font-medium text-[#111827]">{model.label}</div>
          <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-[#6B7280]">
            <span>{PROVIDER_META[model.provider].name}</span>
            <span aria-hidden="true">·</span>
            <span>{model.tier}</span>
            <span aria-hidden="true">·</span>
            <span>{ready ? 'Ready' : 'Key required'}</span>
          </div>
        </div>
        {selected && <Check className="h-4 w-4 shrink-0 text-[#111827]" />}
      </button>
    );
  };

  return (
    <header
      className={`sticky top-0 z-30 w-full bg-white/95 backdrop-blur-sm border-b border-[#E5E7EB] transition-colors ${
        desktopView ? 'h-12 px-4' : 'h-14 px-3 sm:px-5'
      }`}
    >
      <div className="mx-auto flex h-full max-w-[1600px] items-center justify-between gap-3">
        {/* Left: Brand Title */}
        <div className="flex items-center shrink-0">
          <span
            className={`font-display font-bold tracking-tight text-[#111827] whitespace-nowrap ${
              desktopView ? 'text-base' : 'text-lg'
            }`}
          >
            MyCode
          </span>
        </div>

        {/* Center: Model Selector Dropdown Pill */}
        <div className="relative min-w-0 flex-1 flex justify-center" ref={modelMenuRef}>
          <button
            type="button"
            onClick={() => {
              setModelMenuOpen((prev) => !prev);
              setMoreMenuOpen(false);
            }}
            aria-expanded={modelMenuOpen}
            aria-label="Select AI Model"
            className={`inline-flex items-center gap-1.5 rounded-full border border-[#E5E7EB] bg-[#F9FAFB] hover:bg-[#F3F4F6] text-[#111827] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#111827] max-w-[230px] sm:max-w-[340px] ${
              desktopView ? 'h-8 px-3 text-xs' : 'min-h-[40px] px-3.5 text-[13px]'
            } font-medium`}
          >
            <span className="truncate">{activeModel.label}</span>
            <ChevronDown
              className={`h-3.5 w-3.5 shrink-0 text-[#6B7280] transition-transform duration-150 ${
                modelMenuOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {modelMenuOpen && (
            <div
              role="menu"
              className="absolute top-full mt-2 w-[316px] sm:w-[372px] rounded-xl border border-[#E5E7EB] bg-white shadow-[0_12px_32px_rgba(17,24,39,0.1)] py-2 z-50"
            >
              {/* Segmented Filter Bar: All / Free / Paid */}
              <div className="px-2.5 pb-2 space-y-2 border-b border-[#F3F4F6]">
                <div className="grid grid-cols-3 gap-1 rounded-lg bg-[#F3F4F6] p-1">
                  {(['All', 'Free', 'Paid'] as const).map((tab) => {
                    const count =
                      tab === 'All' ? models.length : tab === 'Free' ? totalFree : totalPaid;
                    const active = tierFilter === tab;
                    return (
                      <button
                        key={tab}
                        type="button"
                        onClick={() => setTierFilter(tab)}
                        className={`rounded-md py-1.5 text-[12px] font-medium transition-colors whitespace-nowrap ${
                          active
                            ? 'bg-white text-[#111827] shadow-xs'
                            : 'text-[#6B7280] hover:text-[#111827]'
                        }`}
                      >
                        {tab} ({count})
                      </button>
                    );
                  })}
                </div>

                <div className="relative flex items-center">
                  <Search className="pointer-events-none absolute left-2.5 h-3.5 w-3.5 text-[#9CA3AF]" />
                  <input
                    type="text"
                    value={modelQuery}
                    onChange={(e) => setModelQuery(e.target.value)}
                    placeholder="Filter Gemini, GLM, DeepSeek, Claude..."
                    className="w-full rounded-lg border border-[#E5E7EB] bg-[#FAFAFA] py-1.5 pl-8 pr-2.5 text-[12px] text-[#111827] placeholder:text-[#9CA3AF] focus:border-[#111827] focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="max-h-[340px] overflow-y-auto py-1">
                {freeModels.length > 0 && (
                  <div>
                    <div className="px-3 pt-2 pb-1 text-[11px] font-semibold text-[#6B7280]">
                      Free Models
                    </div>
                    {freeModels.map(renderModelRow)}
                  </div>
                )}

                {paidModels.length > 0 && (
                  <div className={freeModels.length > 0 ? 'mt-1 border-t border-[#F3F4F6] pt-1' : ''}>
                    <div className="px-3 pt-2 pb-1 text-[11px] font-semibold text-[#6B7280]">
                      Paid Models
                    </div>
                    {paidModels.map(renderModelRow)}
                  </div>
                )}

                {freeModels.length === 0 && paidModels.length === 0 && (
                  <div className="px-4 py-6 text-center text-[12px] text-[#6B7280]">
                    No models match &ldquo;{modelQuery}&rdquo;.
                  </div>
                )}
              </div>

              <div className="border-t border-[#F3F4F6] pt-1.5 px-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setModelMenuOpen(false);
                    onOpenApiKeys();
                  }}
                  className="w-full flex items-center gap-2 rounded-lg px-2.5 py-2 text-[12px] font-medium text-[#111827] hover:bg-[#F9FAFB] transition-colors"
                >
                  <KeyRound className="h-3.5 w-3.5 text-[#6B7280]" />
                  <span>Manage API Keys & Custom Models</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: Three-Dots Menu */}
        <div className="relative shrink-0" ref={moreMenuRef}>
          <button
            type="button"
            onClick={() => {
              setMoreMenuOpen((prev) => !prev);
              setModelMenuOpen(false);
            }}
            aria-expanded={moreMenuOpen}
            aria-label="Open menu"
            className={`inline-flex items-center justify-center rounded-lg text-[#111827] hover:bg-[#F3F4F6] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#111827] ${
              desktopView ? 'h-8 w-8' : 'min-h-[44px] min-w-[44px]'
            }`}
          >
            <MoreVertical className="h-5 w-5" />
          </button>

          {moreMenuOpen && (
            <div
              role="menu"
              className="absolute right-0 top-full mt-2 w-64 rounded-xl border border-[#E5E7EB] bg-white shadow-[0_12px_32px_rgba(17,24,39,0.08)] py-1.5 z-50"
            >
              {/* a) Desktop View toggle switch */}
              <button
                type="button"
                role="menuitemcheckbox"
                aria-checked={desktopView}
                onClick={onToggleDesktopView}
                className="w-full flex items-center justify-between gap-3 px-3.5 py-2.5 text-left hover:bg-[#F9FAFB] transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <Monitor className="h-4 w-4 text-[#4B5563]" />
                  <span className="text-[13px] font-medium text-[#111827]">Desktop View</span>
                </div>
                <span
                  aria-hidden="true"
                  className={`relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors ${
                    desktopView ? 'bg-[#111827]' : 'bg-[#D1D5DB]'
                  }`}
                >
                  <span
                    className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                      desktopView ? 'translate-x-4.5' : 'translate-x-1'
                    }`}
                  />
                </span>
              </button>

              <div className="my-1 border-t border-[#F3F4F6]" />

              {/* b) API Keys & Models */}
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setMoreMenuOpen(false);
                  onOpenApiKeys();
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-left text-[13px] font-medium text-[#111827] hover:bg-[#F9FAFB] transition-colors"
              >
                <KeyRound className="h-4 w-4 text-[#4B5563]" />
                <span>API Keys & Models</span>
              </button>

              {/* Workspace Files shortcut */}
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setMoreMenuOpen(false);
                  onOpenWorkspace();
                }}
                className="w-full flex items-center justify-between gap-2.5 px-3.5 py-2.5 text-left text-[13px] font-medium text-[#111827] hover:bg-[#F9FAFB] transition-colors"
              >
                <span className="flex items-center gap-2.5">
                  <FolderOpen className="h-4 w-4 text-[#4B5563]" />
                  <span>Workspace Files</span>
                </span>
                <span className="text-[11px] text-[#6B7280] tabular-nums">
                  {workspaceFileCount}
                </span>
              </button>

              <div className="my-1 border-t border-[#F3F4F6]" />

              {/* c) New Session & Export Project as ZIP */}
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setMoreMenuOpen(false);
                  onNewSession();
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-left text-[13px] font-medium text-[#111827] hover:bg-[#F9FAFB] transition-colors"
              >
                <PlusCircle className="h-4 w-4 text-[#4B5563]" />
                <span>New Session</span>
              </button>

              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setMoreMenuOpen(false);
                  onExportZip();
                }}
                className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-left text-[13px] font-medium text-[#111827] hover:bg-[#F9FAFB] transition-colors"
              >
                <Download className="h-4 w-4 text-[#4B5563]" />
                <span>Export Project as ZIP</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
