import React from 'react';
import { LogIn, LogOut } from 'lucide-react';
import type { User } from 'firebase/auth';

interface TopBarProps {
  user: User | null;
  authReady: boolean;
  isSigningIn: boolean;
  onSignIn: () => void;
  onSignOut: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  user,
  authReady,
  isSigningIn,
  onSignIn,
  onSignOut,
}) => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        <a
          href="#top"
          dir="ltr"
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
        >
          Eladawy Working Days
        </a>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <a
            href="#summary"
            className="hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            الملخص
          </a>
          <a
            href="#setup"
            className="hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            تسجيل العودة
          </a>
          <a
            href="#calendar"
            className="hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            التقويم
          </a>
          <a
            href="#records"
            className="hover:text-slate-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            سجل الأيام
          </a>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          {!authReady ? (
            <span className="text-xs text-slate-400 whitespace-nowrap">جاري التحقق...</span>
          ) : user ? (
            <div className="flex items-center gap-3">
              <span className="hidden sm:inline text-xs text-slate-600 max-w-[160px] truncate">
                {user.displayName || user.email}
              </span>
              <button
                type="button"
                onClick={onSignOut}
                className="inline-flex items-center gap-2 px-3.5 py-2 min-h-[40px] text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
              >
                <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
                <span>تسجيل الخروج</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onSignIn}
              disabled={isSigningIn}
              className="inline-flex items-center gap-2 px-4 py-2 min-h-[40px] text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
            >
              <LogIn className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{isSigningIn ? 'جاري الدخول...' : 'حفظ بحساب Google'}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
