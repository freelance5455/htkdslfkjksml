import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronDown,
  Download,
  FileImage,
  FileText,
  FileType,
  FolderOpen,
  Images,
  Languages,
  Settings,
  Type,
} from 'lucide-react';
import { UILanguage } from '../types/pdf';
import { UI_COPY } from '../utils/i18n';
import { PWAInstallButton } from './PWAInstallButton';

interface TopBarProps {
  lang: UILanguage;
  onToggleLang: () => void;
  onUploadPdfs: (files: File[]) => void;
  onOpenFonts: () => void;
  onOpenSettings: () => void;
  onExportPdf: () => void;
  onExportImage: (format: 'png' | 'jpeg', scope: 'current' | 'all') => void;
  onExportDocx: () => void;
  isExporting: boolean;
  hasPages: boolean;
  pageCount: number;
  activePageNumber: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  lang,
  onToggleLang,
  onUploadPdfs,
  onOpenFonts,
  onOpenSettings,
  onExportPdf,
  onExportImage,
  onExportDocx,
  isExporting,
  hasPages,
  pageCount,
  activePageNumber,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const t = UI_COPY[lang];

  useEffect(() => {
    if (!menuOpen) return;
    const handleOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('mousedown', handleOutside);
    return () => window.removeEventListener('mousedown', handleOutside);
  }, [menuOpen]);

  const boxedNavItems = (
    <>
      <button
        type="button"
        onClick={() => fileInputRef.current?.click()}
        data-tooltip={t.openPdf}
        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <FolderOpen className="w-3.5 h-3.5 text-blue-700 shrink-0" />
        <span>{t.openPdf}</span>
      </button>
      <button
        type="button"
        onClick={onOpenFonts}
        data-tooltip={t.fonts}
        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Type className="w-3.5 h-3.5 text-blue-700 shrink-0" />
        <span>{t.fonts}</span>
      </button>
      <button
        type="button"
        onClick={onOpenSettings}
        data-tooltip={t.settings}
        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Settings className="w-3.5 h-3.5 text-slate-600 shrink-0" />
        <span>{t.settings}</span>
      </button>
      <button
        type="button"
        onClick={onToggleLang}
        data-tooltip={t.uiLanguageLabel}
        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Languages className="w-3.5 h-3.5 text-slate-500 shrink-0" />
        <span>{t.langToggle}</span>
      </button>
      <PWAInstallButton lang={lang} />
    </>
  );

  return (
    <header className="bg-white border-b border-slate-200 shrink-0 z-30">
      {/* Main Row: Brand + Boxed Desktop Options + Save CTA */}
      <div className="h-12 md:h-13 px-3 sm:px-6 flex items-center justify-between gap-4">
        <span className="text-base md:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
          {t.brand}
        </span>

        {/* Desktop Boxed Nav (md+) */}
        <nav className="hidden md:flex items-center gap-2">
          {boxedNavItems}
        </nav>

        {/* Save Menu Trigger */}
        <div className="relative flex items-center shrink-0" ref={menuRef}>
          <button
            type="button"
            disabled={!hasPages || isExporting}
            onClick={() => setMenuOpen((o) => !o)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? t.exporting : t.exportMenuBtn}</span>
            <ChevronDown className="w-3.5 h-3.5 opacity-85" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-xl shadow-lg py-2 z-50">
              <div className="px-3 py-1 text-[11px] font-semibold text-slate-400">
                {t.exportSectionPdf}
              </div>
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onExportPdf();
                }}
                className="w-full px-3 py-2 text-left hover:bg-slate-50 flex items-start gap-2.5 cursor-pointer"
              >
                <FileText className="w-4 h-4 text-blue-700 mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900">
                    {t.exportPdfTitle}
                  </div>
                  <div className="text-[11px] text-slate-500 leading-snug">
                    {t.exportPdfDesc}
                  </div>
                </div>
              </button>

              <div className="my-1.5 border-t border-slate-100" />

              <div className="px-3 py-1 flex items-center justify-between text-[11px]">
                <span className="font-semibold text-slate-400">
                  {t.exportSectionImage}
                </span>
                <span className="font-mono tabular-nums text-slate-400">
                  {activePageNumber}/{pageCount}
                </span>
              </div>

              <div className="px-3 pb-1 text-[11px] text-slate-500">
                {t.exportImageDesc}
              </div>

              <div className="px-3 py-1 grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onExportImage('png', 'current');
                  }}
                  className="px-2.5 py-2 text-left bg-slate-50 hover:bg-blue-50 hover:text-blue-900 border border-slate-200 rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <FileImage className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                  <span className="text-[11px] font-semibold truncate">
                    {t.exportPngPage}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onExportImage('jpeg', 'current');
                  }}
                  className="px-2.5 py-2 text-left bg-slate-50 hover:bg-blue-50 hover:text-blue-900 border border-slate-200 rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <FileImage className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                  <span className="text-[11px] font-semibold truncate">
                    {t.exportJpgPage}
                  </span>
                </button>
              </div>

              {pageCount > 1 && (
                <div className="px-3 py-1 grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onExportImage('png', 'all');
                    }}
                    className="px-2.5 py-1.5 text-left bg-white hover:bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-1.5 cursor-pointer"
                  >
                    <Images className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                    <span className="text-[11px] font-medium text-slate-700 truncate">
                      {t.exportPngAll}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onExportImage('jpeg', 'all');
                    }}
                    className="px-2.5 py-1.5 text-left bg-white hover:bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-1.5 cursor-pointer"
                  >
                    <Images className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                    <span className="text-[11px] font-medium text-slate-700 truncate">
                      {t.exportJpgAll}
                    </span>
                  </button>
                </div>
              )}

              <div className="my-1.5 border-t border-slate-100" />

              <div className="px-3 py-1 text-[11px] font-semibold text-slate-400">
                {t.exportSectionDocx}
              </div>
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onExportDocx();
                }}
                className="w-full px-3 py-2 text-left hover:bg-slate-50 flex items-start gap-2.5 cursor-pointer"
              >
                <FileType className="w-4 h-4 text-blue-700 mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900">
                    {t.exportDocxTitle}
                  </div>
                  <div className="text-[11px] text-slate-500 leading-snug">
                    {t.exportDocxDesc}
                  </div>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Boxed Nav Row */}
      <nav className="md:hidden px-3 py-2 border-t border-slate-100 flex items-center justify-between gap-1.5 overflow-x-auto">
        {boxedNavItems}
      </nav>

      <input
        ref={fileInputRef}
        type="file"
        accept="application/pdf,.pdf"
        multiple
        className="hidden"
        onChange={(e) => {
          const files = e.target.files ? Array.from(e.target.files) : [];
          if (files.length > 0) onUploadPdfs(files);
          e.target.value = '';
        }}
      />
    </header>
  );
};
