import { Button } from "@/components/ui/button";
import { Save, Undo2, Redo2, Play, FolderOpen, Plus, FileCode2 } from "lucide-react";
import type { StudioApi } from "@/hooks/useStudio";
import type { Tab } from "@/App";

interface Props {
  studio: StudioApi;
  tab: Tab;
  onTab: (t: Tab) => void;
  onOpenFiles: () => void;
  onNewProject: () => void;
}

export function TopBar({ studio, onTab, onOpenFiles, onNewProject }: Props) {
  const { saveAll, files } = studio;
  const dirtyCount = files.filter((f) => f.dirty).length;

  return (
    <header className="flex items-center gap-2 border-b border-slate-200 bg-gradient-to-r from-sky-600 to-cyan-600 px-3 py-2 text-white shadow-sm dark:border-slate-800">
      <div className="flex items-center gap-2">
        <div className="rounded-lg bg-white/20 p-1.5">
          <FileCode2 className="h-5 w-5" />
        </div>
        <div className="leading-tight">
          <h1 className="text-sm font-bold">Mobile Code Studio</h1>
          <p className="text-[10px] text-white/70">
            {files.length} ملف{dirtyCount > 0 ? ` · ${dirtyCount} غير محفوظ` : ""}
          </p>
        </div>
      </div>

      <div className="ms-auto flex items-center gap-1">
        <Button
          size="sm"
          variant="ghost"
          onClick={onNewProject}
          className="h-8 w-8 p-0 text-white hover:bg-white/20"
          title="مشروع جديد"
        >
          <Plus className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={onOpenFiles}
          className="h-8 w-8 p-0 text-white hover:bg-white/20"
          title="الملفات"
        >
          <FolderOpen className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => saveAll()}
          className="h-8 w-8 p-0 text-white hover:bg-white/20"
          title="حفظ الكل"
        >
          <Save className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          onClick={() => onTab("preview")}
          className="h-8 gap-1 bg-white/20 px-2 text-white hover:bg-white/30"
          title="معاينة"
        >
          <Play className="h-4 w-4" />
          <span className="text-xs">تشغيل</span>
        </Button>
      </div>
    </header>
  );
}