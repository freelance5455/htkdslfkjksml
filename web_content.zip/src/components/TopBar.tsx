import React from 'react';
import { Plus, Moon, Sun, Brain, Database, Download } from 'lucide-react';

export type NavView = 'topics' | 'flashcards' | 'curve' | 'reminders';

interface TopBarProps {
  currentView: NavView;
  onSelectView: (view: NavView) => void;
  onOpenAddTopic: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  dueTopicsCount: number;
  onOpenStorageModal?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentView,
  onSelectView,
  onOpenAddTopic,
  isDark,
  onToggleTheme,
  dueTopicsCount,
  onOpenStorageModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand title, one line wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
            <Brain className="w-4 h-4" />
          </div>
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onSelectView('topics');
            }}
            className="text-base sm:text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity"
          >
            RecallCurve
          </a>
        </div>

        {/* Zone 2: 4 nav links, 1-2 word labels, single-line */}
        <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-400">
          <button
            type="button"
            onClick={() => onSelectView('topics')}
            className={`transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 py-1 ${
              currentView === 'topics'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-600 dark:border-indigo-400'
                : 'hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <span>Topics & Retention</span>
            {dueTopicsCount > 0 && (
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold">
                {dueTopicsCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => onSelectView('flashcards')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              currentView === 'flashcards'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-600 dark:border-indigo-400'
                : 'hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Flashcard Decks
          </button>

          <button
            type="button"
            onClick={() => onSelectView('curve')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              currentView === 'curve'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-600 dark:border-indigo-400'
                : 'hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Forgetting Curve
          </button>

          <button
            type="button"
            onClick={() => onSelectView('reminders')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              currentView === 'reminders'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-600 dark:border-indigo-400'
                : 'hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Study Reminders
          </button>
        </nav>

        {/* Zone 3: 1 primary action button + Theme toggle + Device Storage button + APK Zip Download */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          <a
            href="/recallcurve-source.zip"
            download="recallcurve-source.zip"
            className="px-2.5 py-1.5 text-xs font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 border border-indigo-200 dark:border-indigo-800/60 rounded-lg transition-colors flex items-center gap-1.5"
            title="Download full project code as ZIP (Ready for APK conversion)"
            aria-label="Download project ZIP for APK"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download ZIP</span>
          </a>

          {onOpenStorageModal && (
            <button
              type="button"
              onClick={onOpenStorageModal}
              className="p-2 text-slate-500 hover:text-emerald-600 dark:text-slate-400 dark:hover:text-emerald-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="On-Device Database (Room DB & SharedPreferences)"
              aria-label="Open on-device database and settings"
            >
              <Database className="w-4 h-4" />
            </button>
          )}

          <button
            type="button"
            onClick={onToggleTheme}
            className="p-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={onOpenAddTopic}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-500 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Topic</span>
          </button>
        </div>
      </div>

      {/* Mobile navigation tab strip */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-100 dark:border-slate-800 px-2 py-1.5 text-xs text-slate-600 dark:text-slate-400">
        <button
          onClick={() => onSelectView('topics')}
          className={`py-1 px-2 rounded-md ${currentView === 'topics' ? 'font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30' : ''}`}
        >
          Topics {dueTopicsCount > 0 ? `(${dueTopicsCount})` : ''}
        </button>
        <button
          onClick={() => onSelectView('flashcards')}
          className={`py-1 px-2 rounded-md ${currentView === 'flashcards' ? 'font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30' : ''}`}
        >
          Flashcards
        </button>
        <button
          onClick={() => onSelectView('curve')}
          className={`py-1 px-2 rounded-md ${currentView === 'curve' ? 'font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30' : ''}`}
        >
          Curve
        </button>
        <button
          onClick={() => onSelectView('reminders')}
          className={`py-1 px-2 rounded-md ${currentView === 'reminders' ? 'font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30' : ''}`}
        >
          Reminders
        </button>
      </div>
    </header>
  );
};
