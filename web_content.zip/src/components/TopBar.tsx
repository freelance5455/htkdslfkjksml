import { Share2 } from 'lucide-react';

interface TopBarProps {
  onShare: () => void;
}

export function TopBar({ onShare }: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.08] bg-[#080B12]/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6">
        <a
          href="#overview"
          className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded-md"
        >
          ChronoAge Pro
        </a>

        <nav aria-label="Section navigation" className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <a
            href="#overview"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Overview
          </a>
          <a
            href="#countdown"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Countdown
          </a>
          <a
            href="#milestones"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Milestones
          </a>
          <a
            href="#planets"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Planets
          </a>
          <a
            href="#astrology"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Birth Details
          </a>
        </nav>

        <button
          type="button"
          onClick={onShare}
          className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-indigo-500 active:scale-[0.98] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
        >
          <Share2 className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Share Summary</span>
        </button>
      </div>
    </header>
  );
}
