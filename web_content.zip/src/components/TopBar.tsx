import { Calculator, History, Moon, Sun } from 'lucide-react';
import type { CalculatorMode } from '../types/calculator';

interface TopBarProps {
  mode: CalculatorMode;
  onModeChange: (mode: CalculatorMode) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  onOpenHistory: () => void;
  historyCount: number;
}

export function TopBar({
  mode,
  onModeChange,
  isDark,
  onToggleTheme,
  onOpenHistory,
  historyCount,
}: TopBarProps) {
  return (
    <header className="w-full h-14 px-4 sm:px-6 border-b border-zinc-200/80 dark:border-zinc-800/80 bg-white/85 dark:bg-[#13171F]/85 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-6xl mx-auto h-full flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm shadow-blue-600/20">
            <Calculator className="w-4 h-4" aria-hidden="true" />
          </div>
          <span className="text-base font-bold tracking-tight text-zinc-900 dark:text-zinc-100 whitespace-nowrap hidden sm:inline">
            Calc Studio
          </span>
        </div>

        {/* Mode Switcher: REGULAR | SCIENTIFIC */}
        <div
          role="tablist"
          aria-label="Calculator Mode"
          className="flex items-center p-1 rounded-xl bg-zinc-100 dark:bg-zinc-800/90 border border-zinc-200/70 dark:border-zinc-700/60"
        >
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'regular'}
            onClick={() => onModeChange('regular')}
            className={`px-3.5 sm:px-4 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all whitespace-nowrap shrink-0 min-h-[34px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
              mode === 'regular'
                ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-sm'
                : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
          >
            REGULAR
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'scientific'}
            onClick={() => onModeChange('scientific')}
            className={`px-3.5 sm:px-4 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all whitespace-nowrap shrink-0 min-h-[34px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
              mode === 'scientific'
                ? 'bg-white dark:bg-zinc-900 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
          >
            SCIENTIFIC
          </button>
        </div>

        {/* Right Controls: Mobile History Drawer + Light/Dark Theme */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={onOpenHistory}
            aria-label={`Open calculation history (${historyCount} items)`}
            className="lg:hidden relative p-2 rounded-xl text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            title="Calculation History"
          >
            <History className="w-5 h-5" />
            {historyCount > 0 && (
              <span className="absolute top-1.5 right-1.5 text-[10px] font-mono font-bold leading-none text-blue-600 dark:text-blue-400">
                {historyCount > 99 ? '99+' : historyCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className="p-2 rounded-xl text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            title={isDark ? 'Light Mode' : 'Dark Mode'}
          >
            {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </header>
  );
}
