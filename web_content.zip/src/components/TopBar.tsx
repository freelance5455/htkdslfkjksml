import React from "react";
import { Menu, Moon, Plus, Sun } from "lucide-react";
import type { AppPage, ThemePreference } from "../types/chat";
import { BrandLogo } from "./BrandLogo";

interface TopBarProps {
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
  currentPage: AppPage;
  activeChatTitle: string | null;
  onNewChat: () => void;
  theme: ThemePreference;
  resolvedDark: boolean;
  onToggleTheme: () => void;
  onNavigateChat: () => void;
}

const PAGE_TITLES: Record<AppPage, string> = {
  welcome: "Welcome to MIH.AI",
  chat: "MIH.AI",
  history: "Chat History",
  settings: "Settings",
  about: "Privacy & About",
};

export const TopBar: React.FC<TopBarProps> = ({
  sidebarOpen,
  onToggleSidebar,
  currentPage,
  activeChatTitle,
  onNewChat,
  resolvedDark,
  onToggleTheme,
  onNavigateChat,
}) => {
  const displayTitle =
    currentPage === "chat" && activeChatTitle
      ? activeChatTitle
      : PAGE_TITLES[currentPage];

  return (
    <header className="sticky top-0 z-30 h-14 shrink-0 px-3 sm:px-5 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between gap-4">
      {/* Left: Menu trigger + Brand / Page Title */}
      <div className="flex items-center gap-2 min-w-0">
        <button
          type="button"
          onClick={onToggleSidebar}
          className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          aria-label={sidebarOpen ? "Toggle sidebar" : "Open menu"}
        >
          <Menu className="w-5 h-5" />
        </button>

        {!sidebarOpen ? (
          <button
            type="button"
            onClick={onNavigateChat}
            className="text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded-lg"
          >
            <BrandLogo size="sm" />
          </button>
        ) : (
          <h1 className="font-display text-sm sm:text-base font-semibold text-slate-900 dark:text-slate-100 truncate">
            {displayTitle}
          </h1>
        )}
      </div>

      {/* Center title on mobile/when sidebar closed and inside a chat */}
      {!sidebarOpen && (
        <div className="hidden sm:block text-sm font-medium text-slate-600 dark:text-slate-400 truncate max-w-md">
          {displayTitle}
        </div>
      )}

      {/* Right: New Chat + Theme Toggle */}
      <div className="flex items-center gap-1.5 shrink-0">
        <button
          type="button"
          onClick={onNewChat}
          className="min-h-[40px] px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-800 inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">New Chat</span>
        </button>

        <button
          type="button"
          onClick={onToggleTheme}
          className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          aria-label={resolvedDark ? "Switch to light mode" : "Switch to dark mode"}
          title={resolvedDark ? "Switch to light mode" : "Switch to dark mode"}
        >
          {resolvedDark ? (
            <Sun className="w-4 h-4" />
          ) : (
            <Moon className="w-4 h-4" />
          )}
        </button>
      </div>
    </header>
  );
};
