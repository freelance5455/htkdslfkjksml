import React, { useState, useEffect } from 'react';
import { Clock, Calendar, Radio } from 'lucide-react';
import { Language } from '../types';

interface TopBarProps {
  language: Language;
}

export const TopBar: React.FC<TopBarProps> = () => {
  const [timeStr, setTimeStr] = useState<string>('00:00:00');
  const [dateStr, setDateStr] = useState<string>('01 NOV 2026');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('en-US', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
      setDateStr(
        now
          .toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
          })
          .toUpperCase()
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center justify-between px-4 sm:px-6 py-3 text-sm bg-[#101d32] text-[#4ceaff] border-b border-[#1f4066] font-mono tracking-wider tabular-nums shadow-inner select-none">
      <div className="flex items-center gap-2">
        <Clock className="w-4 h-4 text-cyan-400 animate-pulse" />
        <span className="font-bold text-cyan-300 text-base">{timeStr}</span>
        <span className="text-xs text-cyan-500/70 hidden sm:inline">PKT</span>
      </div>

      <div className="flex items-center gap-2">
        <Radio className="w-3.5 h-3.5 text-emerald-400" />
        <span className="text-xs text-emerald-300/80 font-sans hidden md:inline">SYSTEM ONLINE</span>
        <span className="text-slate-500">|</span>
        <Calendar className="w-4 h-4 text-cyan-400" />
        <span className="font-medium text-cyan-200">{dateStr}</span>
      </div>
    </div>
  );
};
