import React from 'react';
import { GameResources, WeaponConfig } from '../types';
import {
  Shield,
  Heart,
  Coins,
  Package,
  Wrench,
  Zap,
  Sliders,
  Move,
  ShoppingBag,
  Pause,
  Play,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface TopBarProps {
  wave: number;
  score: number;
  zombiesRemaining: number;
  zombiesTotal: number;
  playerHp: number;
  playerMaxHp: number;
  baseHp: number;
  baseMaxHp: number;
  resources: GameResources;
  currentWeapon: WeaponConfig;
  currentAmmo: number;
  isPaused: boolean;
  onTogglePause: () => void;
  onOpenGraphics: () => void;
  onOpenControlsCustomizer: () => void;
  onOpenUpgradeShop: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  wave,
  score,
  zombiesRemaining,
  zombiesTotal,
  playerHp,
  playerMaxHp,
  baseHp,
  baseMaxHp,
  resources,
  currentWeapon,
  currentAmmo,
  isPaused,
  onTogglePause,
  onOpenGraphics,
  onOpenControlsCustomizer,
  onOpenUpgradeShop,
  isMuted,
  onToggleMute,
}) => {
  const baseHpPct = Math.max(0, Math.min(100, (baseHp / baseMaxHp) * 100));
  const playerHpPct = Math.max(0, Math.min(100, (playerHp / playerMaxHp) * 100));

  return (
    <div
      id="top-hud-bar"
      className="absolute top-0 left-0 right-0 z-40 px-4 py-2.5 flex items-center justify-between pointer-events-none select-none bg-gradient-to-b from-black/80 via-black/40 to-transparent"
    >
      {/* Left: Player HP & Base HP */}
      <div className="flex items-center gap-3 pointer-events-auto">
        {/* Player HP */}
        <div className="flex items-center gap-2 bg-zinc-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-zinc-800 shadow-md">
          <Heart className="w-4 h-4 text-red-500 fill-red-500 animate-pulse" />
          <div className="flex flex-col">
            <div className="flex justify-between items-center text-[10px] font-bold text-zinc-300 w-24">
              <span>QAHRAMON</span>
              <span className="text-red-400">{Math.round(playerHp)}</span>
            </div>
            <div className="w-24 h-2 bg-zinc-800 rounded-full overflow-hidden mt-0.5">
              <div
                style={{ width: `${playerHpPct}%` }}
                className={`h-full transition-all duration-200 ${
                  playerHpPct > 50 ? 'bg-red-500' : playerHpPct > 20 ? 'bg-amber-500' : 'bg-red-700 animate-pulse'
                }`}
              />
            </div>
          </div>
        </div>

        {/* Base HP */}
        <div className="flex items-center gap-2 bg-zinc-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-zinc-800 shadow-md">
          <Shield
            className={`w-4 h-4 ${
              baseHpPct < 30 ? 'text-red-500 fill-red-500 animate-bounce' : 'text-sky-400 fill-sky-400/30'
            }`}
          />
          <div className="flex flex-col">
            <div className="flex justify-between items-center text-[10px] font-bold text-zinc-300 w-28">
              <span>BAZA MARKAZI</span>
              <span className={baseHpPct < 30 ? 'text-red-400' : 'text-sky-300'}>
                {Math.round(baseHp)}
              </span>
            </div>
            <div className="w-28 h-2 bg-zinc-800 rounded-full overflow-hidden mt-0.5">
              <div
                style={{ width: `${baseHpPct}%` }}
                className={`h-full transition-all duration-200 ${
                  baseHpPct > 50 ? 'bg-sky-500' : baseHpPct > 25 ? 'bg-amber-500' : 'bg-red-600 animate-pulse'
                }`}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Center: Wave & Zombie Progress */}
      <div className="flex flex-col items-center pointer-events-auto bg-zinc-950/85 backdrop-blur-md px-5 py-1.5 rounded-xl border border-zinc-800/90 shadow-lg">
        <div className="flex items-center gap-2">
          <span className="text-red-500 font-display text-xl font-bold uppercase tracking-wider">
            {wave}-TOʻLQIN
          </span>
          <span className="text-xs text-zinc-400 font-mono">
            ({zombiesRemaining} qoldi)
          </span>
        </div>
        <div className="text-[11px] text-yellow-400 font-mono font-bold tracking-wide">
          BALL: {score}
        </div>
      </div>

      {/* Right: Resources & Action Panels */}
      <div className="flex items-center gap-2 pointer-events-auto">
        {/* Resource Badges */}
        <div className="flex items-center gap-2 bg-zinc-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-zinc-800 text-xs font-bold font-mono">
          <div className="flex items-center gap-1 text-yellow-400" title="Tangalar">
            <Coins className="w-3.5 h-3.5" />
            <span>{resources.coins}</span>
          </div>
          <div className="w-px h-3.5 bg-zinc-800" />
          <div className="flex items-center gap-1 text-slate-300" title="Metall">
            <Package className="w-3.5 h-3.5 text-slate-400" />
            <span>{resources.metal}</span>
          </div>
          <div className="w-px h-3.5 bg-zinc-800" />
          <div className="flex items-center gap-1 text-amber-500" title="Yogʻoch">
            <Wrench className="w-3.5 h-3.5" />
            <span>{resources.wood}</span>
          </div>
        </div>

        {/* Upgrade Shop Button */}
        <button
          id="top-upgrade-btn"
          onClick={onOpenUpgradeShop}
          title="Arsenal va Yaxshilash"
          className="p-2 rounded-xl bg-amber-600/90 hover:bg-amber-500 text-white border border-amber-400/50 shadow-md transition active:scale-95"
        >
          <ShoppingBag className="w-4 h-4" />
        </button>

        {/* Controls Customizer Button */}
        <button
          id="top-controls-btn"
          onClick={onOpenControlsCustomizer}
          title="Tugmalarni moslashtirish"
          className="p-2 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-sky-400 border border-zinc-700 shadow-md transition active:scale-95"
        >
          <Move className="w-4 h-4" />
        </button>

        {/* Graphics Settings Button */}
        <button
          id="top-graphics-btn"
          onClick={onOpenGraphics}
          title="Grafika sozlamalari"
          className="p-2 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 shadow-md transition active:scale-95"
        >
          <Sliders className="w-4 h-4" />
        </button>

        {/* Mute Toggle */}
        <button
          id="top-sound-btn"
          onClick={onToggleMute}
          title="Ovozni yoqish/oʻchirish"
          className="p-2 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 shadow-md transition active:scale-95"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
        </button>

        {/* Pause Toggle */}
        <button
          id="top-pause-btn"
          onClick={onTogglePause}
          title="Pauza"
          className="p-2 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 shadow-md transition active:scale-95"
        >
          {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
