import React from 'react';
import {
  Award,
  BarChart3,
  Bell,
  Building2,
  Castle,
  Clock,
  Gift,
  Hammer,
  History,
  Layers,
  LayoutDashboard,
  RefreshCw,
  Search,
  Settings,
  Swords,
  Users,
} from 'lucide-react';

export type AppTab =
  | 'overview'
  | 'active_upgrades'
  | 'villages'
  | 'upgrade_history'
  | 'rankings'
  | 'history'
  | 'wars'
  | 'cwl'
  | 'donations'
  | 'capital'
  | 'events'
  | 'player'
  | 'groups'
  | 'clan_stats'
  | 'settings';

export const NAV_ITEMS: Array<{ id: AppTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'overview', label: 'Обзор', icon: LayoutDashboard },
  { id: 'active_upgrades', label: 'Сейчас улучшается', icon: Hammer },
  { id: 'villages', label: 'Три деревни', icon: Building2 },
  { id: 'upgrade_history', label: 'История улучшений', icon: History },
  { id: 'rankings', label: 'Рейтинги', icon: Award },
  { id: 'history', label: 'Активность и снимки', icon: Clock },
  { id: 'wars', label: 'Войны и CWL', icon: Swords },
  { id: 'donations', label: 'Пожертвования', icon: Gift },
  { id: 'capital', label: 'Столица клана', icon: Castle },
  { id: 'events', label: 'События клана', icon: Bell },
  { id: 'player', label: 'Игроки и база', icon: Users },
  { id: 'groups', label: 'Группы TH', icon: Layers },
  { id: 'clan_stats', label: 'Статистика', icon: BarChart3 },
  { id: 'settings', label: 'Настройки', icon: Settings },
];

interface TopBarProps {
  activeTab: AppTab;
  clanName?: string;
  clanTag?: string;
  hasClan: boolean;
  unreadEventsCount?: number;
  activeUpgradesCount?: number;
  onSelectTab: (tab: AppTab) => void;
  onSyncTick: () => void;
  onOpenSearch: () => void;
  isSyncing: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  clanName,
  clanTag,
  hasClan,
  unreadEventsCount = 0,
  activeUpgradesCount = 0,
  onSelectTab,
  onSyncTick,
  onOpenSearch,
  isSyncing,
}) => {
  const effectiveActiveTab: AppTab = activeTab === 'cwl' ? 'wars' : activeTab;
  const activeLabel = NAV_ITEMS.find((i) => i.id === effectiveActiveTab)?.label ?? 'Обзор';

  return (
    <header className="sticky top-0 z-30 border-b border-slate-800/90 bg-[#0B0F17]/95 backdrop-blur-md">
      <div className="flex items-center justify-between gap-4 px-4 py-3 sm:px-6">
        {/* Left: Brand + Contextual Breadcrumb */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => onSelectTab('overview')}
            className="font-display text-lg font-extrabold tracking-tight text-slate-100 whitespace-nowrap shrink-0 hover:text-amber-400 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded"
          >
            Clash Analytics
          </button>
          <span className="hidden sm:inline text-slate-600" aria-hidden="true">/</span>
          <span className="hidden sm:inline text-sm text-slate-300 font-medium truncate">
            {activeLabel}
          </span>
          {clanName && (
            <>
              <span className="hidden md:inline text-slate-600" aria-hidden="true">·</span>
              <span className="hidden md:inline text-xs text-slate-400 truncate">
                {clanName} <span className="font-mono text-slate-500">{clanTag}</span>
              </span>
            </>
          )}
        </div>

        {/* Right: Global Search + Refresh CTA */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onOpenSearch}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-700/90 bg-[#121824] px-3 py-2 text-xs font-medium text-slate-200 hover:border-amber-500/60 hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
          >
            <Search className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Поиск клана / игрока</span>
            <span className="sm:hidden">Поиск</span>
          </button>

          <button
            type="button"
            onClick={onSyncTick}
            disabled={isSyncing || !hasClan}
            className="inline-flex items-center gap-2 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-semibold text-slate-950 transition-colors hover:bg-amber-400 disabled:opacity-50 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Синхронизация...' : 'Синхронизировать'}</span>
          </button>
        </div>
      </div>

      {/* Mobile horizontal nav strip (compact to keep mobile sticky height <= 15%) */}
      <nav className="flex lg:hidden items-center gap-1 overflow-x-auto border-t border-slate-800/70 px-3 py-1.5">
        {NAV_ITEMS.map((item) => {
          const isActive = effectiveActiveTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{item.label}</span>
              {item.id === 'active_upgrades' && activeUpgradesCount > 0 && (
                <span className="font-mono text-[11px] tabular-nums text-amber-400">
                  ({activeUpgradesCount})
                </span>
              )}
              {item.id === 'events' && unreadEventsCount > 0 && (
                <span className="font-mono text-[11px] tabular-nums text-amber-400">
                  ({unreadEventsCount})
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
};

interface SidebarNavProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  clanName?: string;
  clanTag?: string;
  membersCount?: number;
  unreadEventsCount?: number;
  activeUpgradesCount?: number;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  onSelectTab,
  clanName,
  clanTag,
  membersCount,
  unreadEventsCount = 0,
  activeUpgradesCount = 0,
}) => {
  const effectiveActiveTab: AppTab = activeTab === 'cwl' ? 'wars' : activeTab;

  return (
    <aside className="hidden lg:flex lg:w-[240px] lg:shrink-0 lg:flex-col lg:border-r lg:border-slate-800/90 lg:bg-[#0E131D]">
      <div className="sticky top-[57px] flex flex-col gap-1 p-3">
        {clanName && (
          <div className="mb-2 border-b border-slate-800/80 px-3 pb-3 pt-1">
            <div className="truncate text-sm font-semibold text-slate-100">{clanName}</div>
            <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-400">
              <span className="font-mono text-amber-400">{clanTag}</span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums">{membersCount ?? 0} уч.</span>
            </div>
          </div>
        )}

        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = effectiveActiveTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`flex items-center justify-between gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors whitespace-nowrap text-left ${
                isActive
                  ? 'bg-amber-500/12 text-amber-400'
                  : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-100'
              }`}
            >
              <span className="flex items-center gap-3 min-w-0">
                <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                <span className="truncate">{item.label}</span>
              </span>
              {item.id === 'active_upgrades' && activeUpgradesCount > 0 && (
                <span className="font-mono text-[11px] font-semibold tabular-nums text-amber-400 shrink-0">
                  {activeUpgradesCount}
                </span>
              )}
              {item.id === 'events' && unreadEventsCount > 0 && (
                <span className="font-mono text-[11px] font-semibold tabular-nums text-amber-400 shrink-0">
                  {unreadEventsCount}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </aside>
  );
};
