import React from 'react';
import { Download, Smartphone } from 'lucide-react';

interface TopBarProps {
  activeTab: 'player' | 'pipeline' | 'editor' | 'android' | 'guide';
  setActiveTab: (tab: 'player' | 'pipeline' | 'editor' | 'android' | 'guide') => void;
  onExportZip: () => void;
  isExportingZip: boolean;
  phoneFrameMode: boolean;
  setPhoneFrameMode: (val: boolean) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onExportZip,
  isExportingZip,
  phoneFrameMode,
  setPhoneFrameMode,
}) => {
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-8 px-6 py-3.5 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <a
          href="#player"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('player');
          }}
          className="text-lg font-bold tracking-tight text-white hover:text-orange-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-orange-500/10 border border-orange-500/30 text-orange-400 font-bold text-sm">
            हि
          </span>
          <span>Hindi Video Translator</span>
        </a>
      </div>

      {/* Zone 2: Navigation Links (single line, clean unboxed typography) */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('player')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
            activeTab === 'player' ? 'border-orange-500 text-white font-semibold' : 'border-transparent'
          }`}
        >
          वीडियो प्लेयर (Player)
        </button>
        <button
          onClick={() => setActiveTab('pipeline')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
            activeTab === 'pipeline' ? 'border-orange-500 text-white font-semibold' : 'border-transparent'
          }`}
        >
          अनुवाद पाइपलाइन (Pipeline)
        </button>
        <button
          onClick={() => setActiveTab('editor')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
            activeTab === 'editor' ? 'border-orange-500 text-white font-semibold' : 'border-transparent'
          }`}
        >
          उपशीर्षक संपादक (Editor)
        </button>
        <button
          onClick={() => setActiveTab('android')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
            activeTab === 'android' ? 'border-orange-500 text-white font-semibold' : 'border-transparent'
          }`}
        >
          एंड्रॉइड कोड (Android Code)
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
            activeTab === 'guide' ? 'border-orange-500 text-white font-semibold' : 'border-transparent'
          }`}
        >
          शुरुआती गाइड (Guide)
        </button>
      </nav>

      {/* Zone 3: Primary Action & Phone Toggle */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={() => setPhoneFrameMode(!phoneFrameMode)}
          title="Toggle Android Phone Preview Frame"
          className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
            phoneFrameMode
              ? 'bg-slate-800 text-orange-400 border-orange-500/40'
              : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>{phoneFrameMode ? 'मोबाइल दृश्य' : 'डेस्कटॉप दृश्य'}</span>
        </button>

        <button
          onClick={onExportZip}
          disabled={isExportingZip}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-500 active:bg-orange-700 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm shadow-orange-950/40"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{isExportingZip ? 'तैयार हो रहा है...' : 'एंड्रॉइड प्रोजेक्ट (.ZIP)'}</span>
        </button>
      </div>
    </header>
  );
};
