import React from 'react';
import { Pause, Play } from 'lucide-react';
import { formatLocationLabel, formatSimClock } from '../data/kennelConstants';
import { LocationId } from '../types/kennel';
import { PWAInstallButton } from './PWAInstallButton';

export type NavTab = 'facility' | 'location' | 'market' | 'journal' | 'save';

interface TopBarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  simClockSec: number;
  dayCount: number;
  isPaused: boolean;
  onTogglePause: () => void;
  playerLocation: LocationId;
}

const NAV_ITEMS: { id: NavTab; label: string }[] = [
  { id: 'facility', label: 'Facility' },
  { id: 'location', label: 'Location' },
  { id: 'market', label: 'Market' },
  { id: 'journal', label: 'Journal' },
  { id: 'save', label: 'Save' },
];

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onSelectTab,
  simClockSec,
  dayCount,
  isPaused,
  onTogglePause,
  playerLocation,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#F7F5F0]/95 backdrop-blur-md border-b border-[#DFDBD0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Single-element wordmark */}
        <button
          type="button"
          onClick={() => onSelectTab('location')}
          className="font-display text-lg sm:text-xl font-bold tracking-tight text-[#1C1B18] whitespace-nowrap shrink-0 text-left cursor-pointer"
        >
          Dingo Ledger
        </button>

        {/* Zone 2: Clean single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6" aria-label="Primary navigation">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`py-1.5 text-sm font-medium whitespace-nowrap shrink-0 border-b-2 transition-colors cursor-pointer ${
                  isActive
                    ? 'border-[#1F4E3D] text-[#1C1B18]'
                    : 'border-transparent text-[#5C584F] hover:text-[#1C1B18]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Clock & single simulation toggle */}
        <div className="flex items-center gap-2.5 shrink-0">
          <span className="hidden sm:inline text-xs text-[#5C584F] whitespace-nowrap">
            Day {dayCount} · {formatLocationLabel(playerLocation)}
          </span>
          <span className="font-mono-tabular text-xs sm:text-sm font-medium text-[#1C1B18] whitespace-nowrap">
            {formatSimClock(simClockSec)}
          </span>
          <button
            type="button"
            onClick={onTogglePause}
            aria-label={isPaused ? 'Resume simulation' : 'Pause simulation'}
            className={`inline-flex items-center justify-center gap-1.5 min-h-[38px] px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              isPaused
                ? 'bg-[#9A5B13] text-white hover:bg-[#7D490E]'
                : 'bg-[#1F4E3D] text-white hover:bg-[#173B2E]'
            }`}
          >
            {isPaused ? (
              <>
                <Play className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Resume</span>
              </>
            ) : (
              <>
                <Pause className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Pause</span>
              </>
            )}
          </button>
          <div className="hidden lg:block">
            <PWAInstallButton compact />
          </div>
        </div>
      </div>
    </header>
  );
};
