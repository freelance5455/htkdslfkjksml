import React, { useState, useEffect, useCallback } from 'react';
import {
  Cloud,
  CloudUpload,
  CloudDownload,
  ShieldCheck,
  KeyRound,
  RefreshCw,
  LogOut,
  CheckCircle2,
  AlertTriangle,
  FileLock2,
  Clock,
  Eye,
  EyeOff,
  Play,
  BookOpen,
} from 'lucide-react';
import {
  BACKUP_FORMAT_VERSION,
  FullBackupPayload,
  decryptAndValidateBackup,
  encryptBackupPayload,
} from '../utils/cryptoBackup';
import {
  DriveBackupFileMetadata,
  disconnectGoogleAccount,
  downloadEncryptedBackupFromDrive,
  getAccessToken,
  googleSignInForDrive,
  initDriveAuth,
  listAppDataBackups,
  uploadEncryptedBackupToDrive,
} from '../utils/googleDriveBackup';
import { ConfirmDialog } from './ConfirmDialog';
import { toBengaliDigits } from '../utils/money';

interface GoogleDriveBackupSectionProps {
  buildCurrentPayload: () => FullBackupPayload;
  onApplyRestoredPayload: (payload: FullBackupPayload) => void;
  useBengaliDigits: boolean;
}

const DRIVE_META_STORAGE_KEY = 'hisab_khata_drive_sync_meta_v1';

interface StoredDriveSyncMeta {
  connectedEmail: string | null;
  autoBackupEnabled: boolean;
  lastSuccessfulBackupAt: string | null;
  lastBackupVersion: string | null;
  lastBackupSizeBytes: number | null;
  pendingRetryOnReconnect: boolean;
}

function loadSyncMeta(): StoredDriveSyncMeta {
  try {
    const raw = localStorage.getItem(DRIVE_META_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        connectedEmail: parsed.connectedEmail ?? null,
        autoBackupEnabled: Boolean(parsed.autoBackupEnabled),
        lastSuccessfulBackupAt: parsed.lastSuccessfulBackupAt ?? null,
        lastBackupVersion: parsed.lastBackupVersion ?? null,
        lastBackupSizeBytes:
          typeof parsed.lastBackupSizeBytes === 'number'
            ? parsed.lastBackupSizeBytes
            : null,
        pendingRetryOnReconnect: Boolean(parsed.pendingRetryOnReconnect),
      };
    }
  } catch {
    // Ignore storage read error
  }
  return {
    connectedEmail: null,
    autoBackupEnabled: false,
    lastSuccessfulBackupAt: null,
    lastBackupVersion: null,
    lastBackupSizeBytes: null,
    pendingRetryOnReconnect: false,
  };
}

function formatByteSizeBn(bytes: number, useBengaliDigits: boolean): string {
  if (!bytes || bytes <= 0) return useBengaliDigits ? '০ বাইট' : '0 B';
  if (bytes < 1024) {
    const num = useBengaliDigits ? toBengaliDigits(String(bytes)) : String(bytes);
    return `${num} বাইট`;
  }
  const kb = (bytes / 1024).toFixed(1);
  const num = useBengaliDigits ? toBengaliDigits(kb) : kb;
  return `${num} কিলোবাইট`;
}

function formatDateTimeBn(iso: string | null, useBengaliDigits: boolean): string {
  if (!iso) return 'এখনো ব্যাকআপ নেওয়া হয়নি';
  try {
    const d = new Date(iso);
    const formatted = d.toLocaleString('bn-BD', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    return useBengaliDigits ? toBengaliDigits(formatted) : formatted;
  } catch {
    return iso;
  }
}

export const GoogleDriveBackupSection: React.FC<GoogleDriveBackupSectionProps> = ({
  buildCurrentPayload,
  onApplyRestoredPayload,
  useBengaliDigits,
}) => {
  const [syncMeta, setSyncMeta] = useState<StoredDriveSyncMeta>(loadSyncMeta);
  const [hasValidToken, setHasValidToken] = useState<boolean>(false);
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);

  const [passphrase, setPassphrase] = useState<string>('');
  const [showPassphrase, setShowPassphrase] = useState<boolean>(false);

  const [remoteBackupFile, setRemoteBackupFile] =
    useState<DriveBackupFileMetadata | null>(null);
  const [isLoadingRemote, setIsLoadingRemote] = useState<boolean>(false);
  const [backupStatus, setBackupStatus] = useState<
    'IDLE' | 'UPLOADING' | 'RESTORING' | 'SUCCESS' | 'RETRY_QUEUED' | 'ERROR'
  >('IDLE');
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    titleBn: string;
    messageBn: string;
    confirmLabelBn: string;
    danger?: boolean;
    onConfirm: () => void;
  }>({
    open: false,
    titleBn: '',
    messageBn: '',
    confirmLabelBn: 'নিশ্চিত করুন',
    danger: false,
    onConfirm: () => {},
  });

  const [testResults, setTestResults] = useState<
    { nameBn: string; passed: boolean; detailBn: string }[]
  >([]);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);
  const [showCloudGuide, setShowCloudGuide] = useState<boolean>(false);

  useEffect(() => {
    try {
      localStorage.setItem(DRIVE_META_STORAGE_KEY, JSON.stringify(syncMeta));
    } catch {
      // Ignore storage error
    }
  }, [syncMeta]);

  const refreshRemoteDriveMetadata = useCallback(async (token: string) => {
    setIsLoadingRemote(true);
    try {
      const files = await listAppDataBackups(token);
      if (files.length > 0) {
        const latest = files[0];
        setRemoteBackupFile(latest);
        setSyncMeta((prev) => ({
          ...prev,
          lastBackupVersion: latest.backupVersion,
          lastBackupSizeBytes: latest.sizeBytes,
        }));
      } else {
        setRemoteBackupFile(null);
      }
    } catch (err: any) {
      if (err?.message === 'AUTH_EXPIRED') {
        setHasValidToken(false);
      }
    } finally {
      setIsLoadingRemote(false);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = initDriveAuth(
      (user, token) => {
        setHasValidToken(true);
        setSyncMeta((prev) => ({
          ...prev,
          connectedEmail: user.email || prev.connectedEmail,
        }));
        refreshRemoteDriveMetadata(token);
      },
      (user) => {
        setHasValidToken(false);
        if (user?.email) {
          setSyncMeta((prev) => ({
            ...prev,
            connectedEmail: user.email,
          }));
        }
      }
    );
    return () => unsubscribe();
  }, [refreshRemoteDriveMetadata]);

  const executeEncryptedDriveUpload = useCallback(
    async (isAutomatic = false) => {
      if (!passphrase || passphrase.trim().length < 6) {
        if (!isAutomatic) {
          setStatusMessage({
            type: 'error',
            text: 'ব্যাকআপ এনক্রিপ্ট করার জন্য কমপক্ষে ৬ অক্ষরের রিকভারি পাসফ্রেজ দিন।',
          });
        }
        return;
      }

      const token = await getAccessToken();
      if (!token) {
        if (!isAutomatic) {
          setStatusMessage({
            type: 'error',
            text: 'গুগল ড্রাইভে ব্যাকআপ নিতে প্রথমে আপনার গুগল অ্যাকাউন্ট সংযুক্ত করুন।',
          });
        }
        return;
      }

      setBackupStatus('UPLOADING');
      if (!isAutomatic) {
        setStatusMessage({
          type: 'info',
          text: 'তথ্য AES-256-GCM দ্বারা এনক্রিপ্ট করে গুগল ড্রাইভে আপলোড করা হচ্ছে...',
        });
      }

      try {
        const payload = buildCurrentPayload();
        const { envelope, serializedJson } = await encryptBackupPayload(
          payload,
          passphrase
        );

        const uploadedMeta = await uploadEncryptedBackupToDrive({
          accessToken: token,
          serializedEncryptedJson: serializedJson,
          sha256Hex: envelope.plaintextSha256Hex,
          existingFileId: remoteBackupFile?.id,
        });

        setRemoteBackupFile(uploadedMeta);
        setBackupStatus('SUCCESS');
        setSyncMeta((prev) => ({
          ...prev,
          lastSuccessfulBackupAt: uploadedMeta.modifiedTime,
          lastBackupVersion: uploadedMeta.backupVersion,
          lastBackupSizeBytes: uploadedMeta.sizeBytes,
          pendingRetryOnReconnect: false,
        }));

        if (!isAutomatic) {
          setStatusMessage({
            type: 'success',
            text: 'গুগল ড্রাইভের গোপন ফোল্ডারে (appDataFolder) এনক্রিপ্টেড ব্যাকআপ সফলভাবে সংরক্ষিত হয়েছে।',
          });
        }
      } catch (err: any) {
        const isOfflineOrNetwork =
          !navigator.onLine ||
          String(err?.message || '').includes('Failed to fetch') ||
          String(err?.message || '').includes('NetworkError');

        if (isOfflineOrNetwork) {
          setBackupStatus('RETRY_QUEUED');
          setSyncMeta((prev) => ({
            ...prev,
            pendingRetryOnReconnect: true,
          }));
          setStatusMessage({
            type: 'info',
            text: 'ইন্টারনেট সংযোগ নেই। সংযোগ ফিরে এলে স্বয়ংক্রিয়ভাবে ব্যাকআপ সম্পন্ন হবে।',
          });
        } else {
          setBackupStatus('ERROR');
          setStatusMessage({
            type: 'error',
            text: err?.message || 'গুগল ড্রাইভে ব্যাকআপ আপলোড ব্যর্থ হয়েছে।',
          });
        }
      }
    },
    [buildCurrentPayload, passphrase, remoteBackupFile?.id]
  );

  // Automatic retry when internet connection returns (WorkManager network constraint equivalent)
  useEffect(() => {
    const handleOnline = () => {
      if (
        syncMeta.pendingRetryOnReconnect &&
        hasValidToken &&
        passphrase.trim().length >= 6
      ) {
        executeEncryptedDriveUpload(true);
      }
    };
    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [
    syncMeta.pendingRetryOnReconnect,
    hasValidToken,
    passphrase,
    executeEncryptedDriveUpload,
  ]);

  // Automatic Daily Check (runs silently in background if enabled and >24h since last backup)
  useEffect(() => {
    if (
      !syncMeta.autoBackupEnabled ||
      !hasValidToken ||
      passphrase.trim().length < 6
    ) {
      return;
    }

    const lastTime = syncMeta.lastSuccessfulBackupAt
      ? new Date(syncMeta.lastSuccessfulBackupAt).getTime()
      : 0;
    const twentyFourHoursMs = 24 * 60 * 60 * 1000;

    if (Date.now() - lastTime >= twentyFourHoursMs) {
      executeEncryptedDriveUpload(true);
    }
  }, [
    syncMeta.autoBackupEnabled,
    syncMeta.lastSuccessfulBackupAt,
    hasValidToken,
    passphrase,
    executeEncryptedDriveUpload,
  ]);

  const handleGoogleSignIn = async () => {
    setIsSigningIn(true);
    setStatusMessage(null);
    try {
      const { user, accessToken } = await googleSignInForDrive();
      setHasValidToken(true);
      setSyncMeta((prev) => ({
        ...prev,
        connectedEmail: user.email || 'সংযুক্ত অ্যাকাউন্ট',
      }));
      await refreshRemoteDriveMetadata(accessToken);
      setStatusMessage({
        type: 'success',
        text: `গুগল অ্যাকাউন্ট (${user.email}) সফলভাবে সংযুক্ত হয়েছে।`,
      });
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text:
          err?.message ||
          'গুগল সাইন-ইন সম্পন্ন করা যায়নি। পপ-আপ ব্লক করা থাকলে অনুমতি দিন।',
      });
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleDisconnectGoogle = () => {
    setConfirmDialog({
      open: true,
      titleBn: 'গুগল অ্যাকাউন্ট সংযোগ বিচ্ছিন্ন করবেন?',
      messageBn:
        'সংযোগ বিচ্ছিন্ন করলে স্বয়ংক্রিয় ক্লাউড ব্যাকআপ বন্ধ হয়ে যাবে। তবে আপনার ফোনের স্থানীয় হিসাব সম্পূর্ণ অক্ষত থাকবে।',
      confirmLabelBn: 'সংযোগ বিচ্ছিন্ন করুন',
      danger: true,
      onConfirm: async () => {
        setConfirmDialog((c) => ({ ...c, open: false }));
        await disconnectGoogleAccount();
        setHasValidToken(false);
        setRemoteBackupFile(null);
        setSyncMeta((prev) => ({
          ...prev,
          connectedEmail: null,
          autoBackupEnabled: false,
        }));
        setStatusMessage({
          type: 'info',
          text: 'গুগল অ্যাকাউন্ট সংযোগ বিচ্ছিন্ন করা হয়েছে।',
        });
      },
    });
  };

  const handleManualBackupClick = () => {
    if (!passphrase || passphrase.trim().length < 6) {
      setStatusMessage({
        type: 'error',
        text: 'অনুগ্রহ করে প্রথমে কমপক্ষে ৬ অক্ষরের রিকভারি পাসফ্রেজ লিখুন।',
      });
      return;
    }

    if (remoteBackupFile) {
      // Mandatory user confirmation before updating/overwriting existing file on Google Drive
      setConfirmDialog({
        open: true,
        titleBn: 'গুগল ড্রাইভে নতুন ব্যাকআপ আপডেট করবেন?',
        messageBn: `গুগল ড্রাইভে পূর্বের ব্যাকআপটি (${formatDateTimeBn(
          remoteBackupFile.modifiedTime,
          useBengaliDigits
        )}) নতুন এনক্রিপ্টেড ব্যাকআপ দিয়ে হালনাগাদ করা হবে।`,
        confirmLabelBn: 'ব্যাকআপ আপডেট করুন',
        danger: false,
        onConfirm: () => {
          setConfirmDialog((c) => ({ ...c, open: false }));
          executeEncryptedDriveUpload(false);
        },
      });
    } else {
      executeEncryptedDriveUpload(false);
    }
  };

  const handleManualRestoreClick = async () => {
    if (!passphrase || passphrase.trim().length < 6) {
      setStatusMessage({
        type: 'error',
        text: 'ব্যাকআপ ডিক্রিপ্ট করার জন্য আপনার গোপন রিকভারি পাসফ্রেজটি লিখুন।',
      });
      return;
    }

    const token = await getAccessToken();
    if (!token) {
      setStatusMessage({
        type: 'error',
        text: 'ব্যাকআপ রিস্টোর করতে প্রথমে গুগল অ্যাকাউন্টে সাইন ইন করুন।',
      });
      return;
    }

    if (!remoteBackupFile) {
      setStatusMessage({
        type: 'error',
        text: 'গুগল ড্রাইভের appDataFolder-এ কোনো ব্যাকআপ ফাইল পাওয়া যায়নি।',
      });
      return;
    }

    setBackupStatus('RESTORING');
    setStatusMessage({
      type: 'info',
      text: 'গুগল ড্রাইভ থেকে ব্যাকআপ ডাউনলোড ও অখণ্ডতা (Integrity) যাচাই করা হচ্ছে...',
    });

    try {
      const encryptedContent = await downloadEncryptedBackupFromDrive(
        token,
        remoteBackupFile.id
      );
      const verifiedPayload = await decryptAndValidateBackup(
        encryptedContent,
        passphrase
      );

      setBackupStatus('IDLE');
      // Ask for mandatory explicit confirmation BEFORE replacing local data
      setConfirmDialog({
        open: true,
        titleBn: 'ব্যাকআপ রিস্টোর নিশ্চিত করুন',
        messageBn: `ব্যাকআপ ফাইলটির অখণ্ডতা যাচাই সফল হয়েছে (${verifiedPayload.transactions.length}টি লেনদেন, ${verifiedPayload.debts.length}টি দেনা-পাওনা, ${verifiedPayload.subscriptions.length}টি নিয়মিত বিল)। রিস্টোর করলে বর্তমান তথ্যের স্থলে এই ব্যাকআপটি প্রতিস্থাপিত হবে।`,
        confirmLabelBn: 'হ্যাঁ, রিস্টোর করুন',
        danger: true,
        onConfirm: () => {
          setConfirmDialog((c) => ({ ...c, open: false }));
          onApplyRestoredPayload(verifiedPayload);
          setBackupStatus('SUCCESS');
          setStatusMessage({
            type: 'success',
            text: 'গুগল ড্রাইভ থেকে এনক্রিপ্টেড ব্যাকআপ সফলভাবে রিস্টোর করা হয়েছে!',
          });
        },
      });
    } catch (err: any) {
      setBackupStatus('ERROR');
      setStatusMessage({
        type: 'error',
        text:
          err?.message ||
          'ব্যাকআপ ডিক্রিপ্ট বা যাচাই করা সম্ভব হয়নি। পাসফ্রেজ সঠিক কি না দেখুন।',
      });
    }
  };

  const handleExportEncryptedFile = async () => {
    if (!passphrase || passphrase.trim().length < 6) {
      setStatusMessage({
        type: 'error',
        text: 'এনক্রিপ্টেড ফাইল ডাউনলোড করতে কমপক্ষে ৬ অক্ষরের রিকভারি পাসফ্রেজ দিন।',
      });
      return;
    }

    try {
      const payload = buildCurrentPayload();
      const { serializedJson } = await encryptBackupPayload(payload, passphrase);
      const blob = new Blob([serializedJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `hisab-khata-encrypted-v${BACKUP_FORMAT_VERSION}.enc.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setStatusMessage({
        type: 'success',
        text: 'AES-256-GCM এনক্রিপ্টেড ব্যাকআপ ফাইল ডাউনলোড সম্পন্ন হয়েছে।',
      });
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err?.message || 'এনক্রিপ্টেড ফাইল তৈরি করা যায়নি।',
      });
    }
  };

  const handleImportEncryptedFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!passphrase || passphrase.trim().length < 6) {
      setStatusMessage({
        type: 'error',
        text: 'এনক্রিপ্টেড ফাইল রিস্টোর করার আগে রিকভারি পাসফ্রেজ বক্সে পাসফ্রেজ লিখুন।',
      });
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const rawText = String(reader.result ?? '');
        const verifiedPayload = await decryptAndValidateBackup(
          rawText,
          passphrase
        );

        setConfirmDialog({
          open: true,
          titleBn: 'এনক্রিপ্টেড ফাইল থেকে রিস্টোর করবেন?',
          messageBn: `ফাইলের অখণ্ডতা ও পাসফ্রেজ যাচাই সফল হয়েছে (${verifiedPayload.transactions.length}টি লেনদেন ও ${verifiedPayload.debts.length}টি দেনা-পাওনা)। রিস্টোর করলে বর্তমান ডাটা প্রতিস্থাপিত হবে।`,
          confirmLabelBn: 'নিশ্চিত ও রিস্টোর করুন',
          danger: true,
          onConfirm: () => {
            setConfirmDialog((c) => ({ ...c, open: false }));
            onApplyRestoredPayload(verifiedPayload);
            setStatusMessage({
              type: 'success',
              text: 'এনক্রিপ্টেড ব্যাকআপ ফাইল থেকে সফলভাবে রিস্টোর সম্পন্ন হয়েছে।',
            });
          },
        });
      } catch (err: any) {
        setStatusMessage({
          type: 'error',
          text:
            err?.message ||
            'এনক্রিপ্টেড ফাইলটি ডিক্রিপ্ট করা যায়নি। পাসফ্রেজ বা ফাইল যাচাই করুন।',
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleRunSecurityAndRestoreTests = async () => {
    setIsRunningTests(true);
    const results: { nameBn: string; passed: boolean; detailBn: string }[] = [];
    const testPass =
      passphrase.trim().length >= 6 ? passphrase : 'HisabKhata#Test2026';

    try {
      // Test 1: First backup encryption & SHA-256 verification
      const samplePayload = buildCurrentPayload();
      const firstBackup = await encryptBackupPayload(samplePayload, testPass);
      const decryptedFirst = await decryptAndValidateBackup(
        firstBackup.serializedJson,
        testPass
      );
      results.push({
        nameBn: '১. প্রথম ব্যাকআপ ও AES-256-GCM এনক্রিপশন পরীক্ষা',
        passed:
          decryptedFirst.transactions.length ===
            samplePayload.transactions.length &&
          firstBackup.envelope.algorithm === 'AES-256-GCM',
        detailBn: `সংস্করণ v${firstBackup.envelope.backupFormatVersion}, আকার ${formatByteSizeBn(
          firstBackup.sizeBytes,
          useBengaliDigits
        )}, প্লেইনটেক্সট গোপন রাখা হয়েছে।`,
      });

      // Test 2: Repeated backup with distinct random IV & salt
      const secondBackup = await encryptBackupPayload(samplePayload, testPass);
      results.push({
        nameBn: '২. পুনরায় ব্যাকআপ ও নতুন র‍্যান্ডম IV যাচাই',
        passed:
          secondBackup.envelope.ivBase64 !== firstBackup.envelope.ivBase64 &&
          secondBackup.envelope.saltBase64 !== firstBackup.envelope.saltBase64,
        detailBn:
          'প্রতিটি ব্যাকআপে স্বতন্ত্র ১৬-বাইট Salt ও ১২-বাইট IV ব্যবহৃত হয়েছে।',
      });

      // Test 3: Second device restore & duplicate record prevention
      const duplicatedPayload: FullBackupPayload = {
        ...samplePayload,
        transactions: [
          ...samplePayload.transactions,
          ...samplePayload.transactions,
        ],
      };
      const dupEncrypted = await encryptBackupPayload(
        duplicatedPayload,
        testPass
      );
      const restoredClean = await decryptAndValidateBackup(
        dupEncrypted.serializedJson,
        testPass
      );
      results.push({
        nameBn: '৩. দ্বিতীয় ডিভাইসে রিস্টোর ও ডুপ্লিকেট এন্ট্রি প্রতিরোধ',
        passed:
          restoredClean.transactions.length ===
          samplePayload.transactions.length,
        detailBn: `ডুপ্লিকেট লেনদেন স্বয়ংক্রিয়ভাবে বাদ দিয়ে ${restoredClean.transactions.length}টি অনন্য রেকর্ড অক্ষত রাখা হয়েছে।`,
      });

      // Test 4: Corrupted backup & wrong passphrase rejection
      let corruptedRejected = false;
      try {
        const tampered = JSON.parse(firstBackup.serializedJson);
        tampered.ciphertextBase64 =
          tampered.ciphertextBase64.slice(0, -4) + 'AAAA';
        await decryptAndValidateBackup(JSON.stringify(tampered), testPass);
      } catch {
        corruptedRejected = true;
      }

      let wrongPassRejected = false;
      try {
        await decryptAndValidateBackup(
          firstBackup.serializedJson,
          'WrongPassphrase#999'
        );
      } catch {
        wrongPassRejected = true;
      }

      results.push({
        nameBn: '৪. ক্ষতিগ্রস্ত ফাইল ও ভুল পাসফ্রেজ প্রতিরোধ পরীক্ষা',
        passed: corruptedRejected && wrongPassRejected,
        detailBn:
          'ক্ষতিগ্রস্ত সাইফারটেক্সট ও ভুল পাসফ্রেজ সফলভাবে শনাক্ত ও ব্লক করা হয়েছে।',
      });

      // Test 5: Live Google Drive appDataFolder connection check
      const token = await getAccessToken();
      if (token) {
        const files = await listAppDataBackups(token);
        results.push({
          nameBn: '৫. বাস্তব গুগল ড্রাইভ (appDataFolder) সংযোগ পরীক্ষা',
          passed: true,
          detailBn: `গুগল অ্যাকাউন্ট (${syncMeta.connectedEmail}) সংযুক্ত আছে এবং appDataFolder-এ ${files.length}টি ব্যাকআপ পাওয়া গেছে।`,
        });
      } else {
        results.push({
          nameBn: '৫. বাস্তব গুগল ড্রাইভ (appDataFolder) সংযোগ পরীক্ষা',
          passed: false,
          detailBn:
            'গুগল ড্রাইভ লাইভ আপলোড ও রিস্টোর পরীক্ষা করতে উপরে "গুগল দিয়ে সাইন ইন করুন" বাটনে ক্লিক করে বাস্তব অ্যাকাউন্ট যুক্ত করুন।',
        });
      }
    } catch (err: any) {
      results.push({
        nameBn: 'পরীক্ষা চলাকালীন ত্রুটি',
        passed: false,
        detailBn: err?.message || 'অপ্রত্যাশিত ত্রুটি',
      });
    } finally {
      setTestResults(results);
      setIsRunningTests(false);
    }
  };

  const statusBadgeText =
    backupStatus === 'UPLOADING'
      ? 'ব্যাকআপ আপলোড হচ্ছে...'
      : backupStatus === 'RESTORING'
      ? 'ব্যাকআপ যাচাই ও রিস্টোর হচ্ছে...'
      : backupStatus === 'RETRY_QUEUED' || syncMeta.pendingRetryOnReconnect
      ? 'অপেক্ষমাণ (ইন্টারনেট পেলে পুনরায় চেষ্টা হবে)'
      : backupStatus === 'SUCCESS'
      ? 'সুরক্ষিত ও সিঙ্ককৃত'
      : syncMeta.autoBackupEnabled
      ? 'স্বয়ংক্রিয় ব্যাকআপ সক্রিয়'
      : 'প্রস্তুত';

  return (
    <div className="space-y-6">
      {/* Main Google Account & Drive Encrypted Backup Card */}
      <section className="rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-emerald-900/15 dark:border-slate-800 p-6 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600/10 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Cloud className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  গুগল ড্রাইভ এনক্রিপ্টেড ক্লাউড ব্যাকআপ
                </h2>
                <span className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800/70">
                  AES-256-GCM · appDataFolder
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                আপনার আর্থিক তথ্য ডিভাইসে এনক্রিপ্ট হয়ে শুধুমাত্র গুগল ড্রাইভের গোপন অ্যাপ ফোল্ডারে সংরক্ষিত থাকে
              </p>
            </div>
          </div>

          {/* Official Sign in with Google / Connected Account Controls */}
          <div className="flex items-center gap-3 shrink-0">
            {hasValidToken && syncMeta.connectedEmail ? (
              <div className="flex items-center gap-2.5 bg-slate-100/90 dark:bg-slate-800/90 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="text-right">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    সংযুক্ত গুগল অ্যাকাউন্ট
                  </p>
                  <p className="text-xs font-semibold text-slate-900 dark:text-white truncate max-w-[200px]">
                    {syncMeta.connectedEmail}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleDisconnectGoogle}
                  className="min-h-[36px] px-2.5 py-1.5 rounded-lg text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 flex items-center gap-1"
                  title="সংযোগ বিচ্ছিন্ন করুন"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>বিচ্ছিন্ন</span>
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isSigningIn}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-white border border-slate-300 dark:border-slate-600 text-xs font-semibold flex items-center gap-2.5 shadow-2xs transition-colors cursor-pointer disabled:opacity-60"
              >
                <svg
                  className="w-4 h-4 shrink-0"
                  viewBox="0 0 48 48"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                </svg>
                <span>
                  {isSigningIn
                    ? 'গুগল সংযোগ হচ্ছে...'
                    : syncMeta.connectedEmail
                    ? `পুনরায় সংযুক্ত করুন (${syncMeta.connectedEmail})`
                    : 'গুগল দিয়ে সাইন ইন করুন'}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Status Banner */}
        {statusMessage && (
          <div
            className={`p-3.5 rounded-xl text-xs border flex items-start gap-2.5 ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                : statusMessage.type === 'error'
                ? 'bg-red-50 dark:bg-red-950/50 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
                : 'bg-sky-50 dark:bg-sky-950/50 border-sky-200 dark:border-sky-800 text-sky-900 dark:text-sky-200'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Grid: Recovery Passphrase + Backup Status & Metadata */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Left Box: Recovery Passphrase */}
          <div className="p-4 rounded-xl bg-slate-50/90 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  গোপন রিকভারি পাসফ্রেজ (AES-256-GCM কী)
                </h3>
              </div>
              <span className="text-[11px] text-slate-500">কমপক্ষে ৬ অক্ষর</span>
            </div>

            <div className="relative">
              <input
                type={showPassphrase ? 'text' : 'password'}
                value={passphrase}
                onChange={(e) => setPassphrase(e.target.value)}
                placeholder="আপনার গোপন রিকভারি পাসফ্রেজ লিখুন..."
                className="w-full min-h-[42px] pl-3.5 pr-10 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
              <button
                type="button"
                onClick={() => setShowPassphrase((s) => !s)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                aria-label="পাসফ্রেজ দেখুন"
              >
                {showPassphrase ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              এই পাসফ্রেজ দিয়েই আপনার ব্যাকআপ এনক্রিপ্ট ও ডিক্রিপ্ট করা হয়। পাসফ্রেজটি কোথাও লিখে রাখুন—অন্য ফোনে রিস্টোর করার সময় এটি প্রয়োজন হবে।
            </p>
          </div>

          {/* Right Box: Backup Metadata & Automatic Daily Backup Toggle */}
          <div className="p-4 rounded-xl bg-slate-50/90 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  ব্যাকআপের অবস্থা ও বিবরণ
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                {statusBadgeText}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-1">
              <div>
                <span className="text-slate-500 block text-[11px]">
                  সর্বশেষ সফল ব্যাকআপ:
                </span>
                <span className="font-semibold text-slate-900 dark:text-slate-100">
                  {formatDateTimeBn(
                    remoteBackupFile?.modifiedTime ||
                      syncMeta.lastSuccessfulBackupAt,
                    useBengaliDigits
                  )}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">
                  ব্যাকআপ সংস্করণ ও আকার:
                </span>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {remoteBackupFile?.backupVersion ||
                    syncMeta.lastBackupVersion ||
                    `v${BACKUP_FORMAT_VERSION}`}{' '}
                  ·{' '}
                  {formatByteSizeBn(
                    remoteBackupFile?.sizeBytes ||
                      syncMeta.lastBackupSizeBytes ||
                      0,
                    useBengaliDigits
                  )}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  দৈনিক স্বয়ংক্রিয় ব্যাকআপ (WorkManager)
                </p>
                <p className="text-[11px] text-slate-500">
                  হিসাব লেখার সময় কোনো বিঘ্ন না ঘটিয়ে ব্যাকগ্রাউন্ডে ব্যাকআপ নেয়
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={syncMeta.autoBackupEnabled}
                onClick={() =>
                  setSyncMeta((prev) => ({
                    ...prev,
                    autoBackupEnabled: !prev.autoBackupEnabled,
                  }))
                }
                className={`w-11 h-6 rounded-full transition-colors p-0.5 shrink-0 ${
                  syncMeta.autoBackupEnabled
                    ? 'bg-emerald-600'
                    : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                    syncMeta.autoBackupEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Manual Backup, Restore, and Encrypted File Export Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleManualBackupClick}
              disabled={backupStatus === 'UPLOADING'}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-2 shadow-xs disabled:opacity-60 cursor-pointer"
            >
              <CloudUpload className="w-4 h-4" />
              <span>
                {backupStatus === 'UPLOADING'
                  ? 'আপলোড হচ্ছে...'
                  : 'এখনই ব্যাকআপ নিন'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleManualRestoreClick}
              disabled={backupStatus === 'RESTORING' || !remoteBackupFile}
              className="min-h-[44px] px-4 py-2.5 rounded-xl border border-emerald-700/30 dark:border-emerald-500/40 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100/70 dark:hover:bg-emerald-950/70 text-emerald-900 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <CloudDownload className="w-4 h-4" />
              <span>ব্যাকআপ রিস্টোর করুন</span>
            </button>

            {hasValidToken && (
              <button
                type="button"
                onClick={async () => {
                  const t = await getAccessToken();
                  if (t) refreshRemoteDriveMetadata(t);
                }}
                disabled={isLoadingRemote}
                className="min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5"
                title="ড্রাইভের তথ্য রিফ্রেশ করুন"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${
                    isLoadingRemote ? 'animate-spin' : ''
                  }`}
                />
                <span>তথ্য যাচাই</span>
              </button>
            )}
          </div>

          {/* Separate Encrypted File Export & Import */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleExportEncryptedFile}
              className="min-h-[42px] px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1.5"
            >
              <FileLock2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              <span>এনক্রিপ্টেড ফাইল এক্সপোর্ট (.enc)</span>
            </button>

            <label className="min-h-[42px] px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer">
              <ShieldCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              <span>এনক্রিপ্টেড ফাইল রিস্টোর</span>
              <input
                type="file"
                accept=".json,.enc.json,application/json"
                onChange={handleImportEncryptedFile}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </section>

      {/* Diagnostic & Verification Suite + Google Cloud Console Setup Guide */}
      <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>নিরাপত্তা ও ব্যাকআপ অখণ্ডতা পরীক্ষা এবং Google Cloud কনফিগারেশন</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              প্রথম ব্যাকআপ, পুনরায় ব্যাকআপ, ডুপ্লিকেট রোধ, ক্ষতিগ্রস্ত ফাইল প্রতিরোধ এবং বাস্তব গুগল ড্রাইভ সংযোগ যাচাই করুন
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleRunSecurityAndRestoreTests}
              disabled={isRunningTests}
              className="min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-emerald-600 text-white text-xs font-semibold flex items-center gap-1.5 hover:opacity-90 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>
                {isRunningTests ? 'পরীক্ষা চলছে...' : 'সকল নিরাপত্তা পরীক্ষা চালান'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setShowCloudGuide((g) => !g)}
              className="min-h-[40px] px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Google Cloud সেটআপ গাইড</span>
            </button>
          </div>
        </div>

        {testResults.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            {testResults.map((res) => (
              <div
                key={res.nameBn}
                className={`p-3.5 rounded-xl border text-xs space-y-1 ${
                  res.passed
                    ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/80'
                    : 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800/80'
                }`}
              >
                <div className="flex items-center justify-between gap-2 font-semibold text-slate-900 dark:text-white">
                  <span>{res.nameBn}</span>
                  <span
                    className={
                      res.passed
                        ? 'text-emerald-700 dark:text-emerald-400'
                        : 'text-amber-700 dark:text-amber-400'
                    }
                  >
                    {res.passed ? 'উত্তীর্ণ' : 'মনোযোগ প্রয়োজন'}
                  </span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {res.detailBn}
                </p>
              </div>
            ))}
          </div>
        )}

        {showCloudGuide && (
          <div className="mt-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-3 leading-relaxed text-slate-700 dark:text-slate-300">
            <h4 className="font-bold text-slate-900 dark:text-white text-sm">
              নেটিভ অ্যান্ড্রয়েড অ্যাপের জন্য Google Cloud Console কনফিগারেশন:
            </h4>
            <ol className="list-decimal list-inside space-y-2">
              <li>
                <strong>Google Drive API সক্রিয়করণ:</strong> Google Cloud Console
                এ গিয়ে <code>APIs &amp; Services &rarr; Library</code> থেকে{' '}
                <strong>Google Drive API</strong> খুঁজে <strong>Enable</strong>{' '}
                করুন।
              </li>
              <li>
                <strong>OAuth Consent Screen ও ন্যূনতম স্কোপ:</strong> User Type{' '}
                <code>External</code> নির্বাচন করুন এবং Scopes তালিকায় শুধুমাত্র{' '}
                <code>https://www.googleapis.com/auth/drive.appdata</code> স্কোপটি
                যুক্ত করুন (পূর্ণ ড্রাইভের অ্যাক্সেস নেওয়া যাবে না)।
              </li>
              <li>
                <strong>Android ও Web OAuth 2.0 Client ID তৈরি:</strong>
                <ul className="list-disc list-inside pl-4 mt-1 space-y-1">
                  <li>
                    টার্মিনালে <code>./gradlew signingReport</code> চালিয়ে আপনার
                    অ্যাপের <code>SHA-1</code> ফিঙ্গারপ্রিন্ট নিন।
                  </li>
                  <li>
                    <code>Credentials &rarr; Create Credentials &rarr; OAuth client ID</code>{' '}
                    থেকে একটি <strong>Android Client ID</strong> (প্যাকেজ:{' '}
                    <code>com.hisabkhata.app</code> ও SHA-1 সহ) এবং একটি{' '}
                    <strong>Web Application Client ID</strong> তৈরি করুন।
                  </li>
                  <li>
                    Credential Manager এর{' '}
                    <code>GetGoogleIdOption.Builder().setServerClientId(WEB_CLIENT_ID)</code>{' '}
                    এ Web Client ID ব্যবহার করুন। অ্যাপে কখনোই কোনো Client Secret
                    সংরক্ষণ করবেন না।
                  </li>
                </ul>
              </li>
            </ol>
          </div>
        )}
      </section>

      <ConfirmDialog
        open={confirmDialog.open}
        titleBn={confirmDialog.titleBn}
        messageBn={confirmDialog.messageBn}
        confirmLabelBn={confirmDialog.confirmLabelBn}
        danger={confirmDialog.danger}
        onConfirm={confirmDialog.onConfirm}
        onCancel={() => setConfirmDialog((c) => ({ ...c, open: false }))}
      />
    </div>
  );
};
