import React, { useRef } from 'react';

interface CircularProgressRingProps {
  progress: number; // current seconds
  duration: number; // total duration
  isPlaying: boolean;
  size?: number; // size in px
  strokeWidth?: number;
  onSeek?: (newTime: number) => void;
  children?: React.ReactNode;
  showTimeText?: boolean;
}

export const CircularProgressRing: React.FC<CircularProgressRingProps> = ({
  progress,
  duration,
  isPlaying,
  size = 120,
  strokeWidth = 6,
  onSeek,
  children,
  showTimeText = false,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = duration > 0 ? Math.min(1, Math.max(0, progress / duration)) : 0;
  const strokeDashoffset = circumference - pct * circumference;

  const handleClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!onSeek || duration <= 0 || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const x = e.clientX - centerX;
    const y = e.clientY - centerY;

    // Calculate angle in radians from top (-PI/2)
    let angle = Math.atan2(y, x) + Math.PI / 2;
    if (angle < 0) angle += 2 * Math.PI;

    const clickedPct = angle / (2 * Math.PI);
    onSeek(Math.floor(clickedPct * duration));
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div
      className="relative flex items-center justify-center inline-block group cursor-pointer"
      style={{ width: size, height: size }}
    >
      {/* Outer Pulse Glow Ring when Playing */}
      {isPlaying && (
        <div
          className="absolute inset-0 rounded-full border border-amber-400/40 animate-ping opacity-30 pointer-events-none"
          style={{ width: size, height: size }}
        />
      )}

      {/* Background Subtle Radial Backlight */}
      <div
        className={`absolute inset-2 rounded-full transition-all duration-700 ${
          isPlaying
            ? 'bg-amber-500/10 shadow-[0_0_30px_rgba(251,191,36,0.3)] scale-105'
            : 'bg-slate-900/60'
        }`}
      />

      {/* SVG Circular Ring */}
      <svg
        ref={svgRef}
        width={size}
        height={size}
        onClick={handleClick}
        className="transform -rotate-90 relative z-10 transition-transform duration-300 group-hover:scale-105"
      >
        {/* Background Track Circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-slate-800/80 fill-none"
        />

        {/* Animated Progress Circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="url(#progressGradient)"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="fill-none transition-all duration-300 ease-out"
        />

        {/* Gradient Def */}
        <defs>
          <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#f59e0b" />
            <stop offset="50%" stopColor="#fbbf24" />
            <stop offset="100%" stopColor="#fef08a" />
          </linearGradient>
        </defs>
      </svg>

      {/* Central Content (Button / Artwork / Time) */}
      <div className="absolute inset-0 z-20 flex flex-col items-center justify-center pointer-events-auto">
        {children}
        {showTimeText && (
          <span className="text-[10px] font-mono font-bold text-amber-300 tracking-wider mt-0.5">
            {formatTime(progress)}
          </span>
        )}
      </div>
    </div>
  );
};
