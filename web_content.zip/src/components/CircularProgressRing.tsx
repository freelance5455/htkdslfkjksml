import React from 'react';
import { Check } from 'lucide-react';

interface CircularProgressRingProps {
  score: number;
  total: number;
  size?: number;
  strokeWidth?: number;
  showText?: boolean;
}

export const CircularProgressRing: React.FC<CircularProgressRingProps> = ({
  score,
  total,
  size = 46,
  strokeWidth = 4,
  showText = true,
}) => {
  const safeTotal = total > 0 ? total : 5;
  const safeScore = Math.max(0, Math.min(score, safeTotal));
  const percentage = Math.round((safeScore / safeTotal) * 100);

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  const isMastered = safeScore === safeTotal && safeTotal > 0;
  const isStarted = safeScore > 0;

  // Determine stroke color
  let strokeColor = '#cbd5e1'; // slate-300
  let trackColor = '#f1f5f9'; // slate-100

  if (isMastered) {
    strokeColor = '#10b981'; // emerald-500
    trackColor = '#ecfdf5'; // emerald-50
  } else if (percentage >= 60) {
    strokeColor = '#f59e0b'; // amber-500
    trackColor = '#fffbeb'; // amber-50
  } else if (isStarted) {
    strokeColor = '#eab308'; // yellow-500
    trackColor = '#fefce8';
  }

  return (
    <div
      className="relative inline-flex items-center justify-center shrink-0"
      style={{ width: size, height: size }}
      role="progressbar"
      aria-valuenow={safeScore}
      aria-valuemin={0}
      aria-valuemax={safeTotal}
      aria-label={`Progress: ${safeScore} of ${safeTotal} questions answered correctly`}
    >
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="transform -rotate-90"
      >
        {/* Background track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={trackColor}
          strokeWidth={strokeWidth}
        />
        {/* Animated Progress bar */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={strokeColor}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="transition-all duration-500 ease-out"
        />
      </svg>

      {/* Center Label */}
      {showText && (
        <div className="absolute inset-0 flex items-center justify-center text-center">
          {isMastered ? (
            <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
          ) : (
            <span
              className={`font-mono text-[11px] font-bold tabular-nums leading-none ${
                isStarted ? 'text-slate-800' : 'text-slate-400'
              }`}
            >
              {safeScore}/{safeTotal}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
