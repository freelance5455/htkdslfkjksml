import React, { useState } from 'react';
import { ShieldCheck, ShieldOff, Lock, EyeOff, Cookie, Cpu, AlertTriangle, ChevronDown, ChevronUp, CheckCircle2, X } from 'lucide-react';
import { Tab, BlockedItem } from '../types/browser';
import { TRACKER_DATABASE } from '../data/mockWeb';

interface ShieldSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currentTab: Tab;
  onToggleShields: (tabId: string, enabled: boolean) => void;
  onToggleScripts: (tabId: string, enabled: boolean) => void;
}

export const ShieldSheet: React.FC<ShieldSheetProps> = ({
  isOpen,
  onClose,
  currentTab,
  onToggleShields,
  onToggleScripts,
}) => {
  const [showDetails, setShowDetails] = useState(false);

  if (!isOpen) return null;

  // Extract domain for tracker lookup
  let hostname = 'default';
  try {
    if (currentTab.url && currentTab.url.startsWith('http')) {
      hostname = new URL(currentTab.url).hostname.replace(/^www\./, '');
    }
  } catch {
    hostname = 'default';
  }

  const blockedList: BlockedItem[] = TRACKER_DATABASE[hostname] || TRACKER_DATABASE['default'];
  const totalBlocked = currentTab.trackersBlocked + currentTab.fingerprintsBlocked + currentTab.cookiesBlocked;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-fade-in">
      {/* Backdrop tap to close */}
      <div className="flex-1" onClick={onClose} />

      {/* Android Bottom Sheet Card */}
      <div className="w-full max-w-lg mx-auto bg-slate-900 border-t border-slate-700/80 rounded-t-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-slide-up">
        {/* Handle Bar */}
        <div className="pt-3 pb-1 flex justify-center cursor-grab" onClick={onClose}>
          <div className="w-12 h-1.5 rounded-full bg-slate-700" />
        </div>

        {/* Sheet Header */}
        <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl ${currentTab.shieldsEnabled ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60' : 'bg-slate-800 text-slate-400'}`}>
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-base font-bold text-slate-100">Aegis Shield</h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/60">
                  Grade A+
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-[240px]">
                {hostname === 'default' ? 'Global Protection Engine' : hostname}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-4 no-scrollbar">
          {/* Master Site Toggle */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-850 bg-slate-950/60 border border-slate-800">
            <div>
              <p className="text-sm font-semibold text-slate-200">Shields for this site</p>
              <p className="text-xs text-slate-400">
                {currentTab.shieldsEnabled
                  ? 'All trackers, fingerprint scripts, and beacons blocked'
                  : 'Protection disabled for compatibility'}
              </p>
            </div>
            <button
              onClick={() => onToggleShields(currentTab.id, !currentTab.shieldsEnabled)}
              className={`w-12 h-7 rounded-full transition-colors relative p-0.5 ${
                currentTab.shieldsEnabled ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform ${
                  currentTab.shieldsEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-750 flex flex-col items-center text-center">
              <EyeOff className="w-4 h-4 text-emerald-400 mb-1" />
              <span className="text-lg font-bold font-mono text-slate-100">
                {currentTab.shieldsEnabled ? currentTab.trackersBlocked : 0}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">Trackers</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-750 flex flex-col items-center text-center">
              <Cpu className="w-4 h-4 text-cyan-400 mb-1" />
              <span className="text-lg font-bold font-mono text-slate-100">
                {currentTab.shieldsEnabled ? currentTab.fingerprintsBlocked : 0}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">Canvas / JS</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-750 flex flex-col items-center text-center">
              <Cookie className="w-4 h-4 text-amber-400 mb-1" />
              <span className="text-lg font-bold font-mono text-slate-100">
                {currentTab.shieldsEnabled ? currentTab.cookiesBlocked : 0}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">3rd Cookies</span>
            </div>
          </div>

          {/* Security Protocols Bar */}
          <div className="space-y-2 bg-slate-950/40 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Connection</span>
              </div>
              <span className="text-emerald-400 font-medium">Encrypted TLS 1.3 Strict</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Encrypted DNS</span>
              </div>
              <span className="text-slate-400 font-medium">Cloudflare (DoH)</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Global Privacy Control (GPC)</span>
              </div>
              <span className="text-emerald-400 font-medium">Active (DNT=1)</span>
            </div>
          </div>

          {/* Site Controls */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Advanced Site Controls
            </h4>

            {/* Block Scripts Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/40 border border-slate-800">
              <div>
                <p className="text-xs font-semibold text-slate-200">JavaScript Scripts</p>
                <p className="text-[11px] text-slate-400">Turn off to prevent invasive client code</p>
              </div>
              <button
                onClick={() => onToggleScripts(currentTab.id, !currentTab.scriptsEnabled)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                  currentTab.scriptsEnabled
                    ? 'bg-slate-700 text-slate-300'
                    : 'bg-red-950/80 text-red-400 border border-red-800/60'
                }`}
              >
                {currentTab.scriptsEnabled ? 'Allowed' : 'Blocked'}
              </button>
            </div>
          </div>

          {/* Collapsible Blocked Tracker Telemetry List */}
          <div className="border border-slate-800 rounded-xl overflow-hidden">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="w-full px-4 py-3 bg-slate-850 bg-slate-900 flex items-center justify-between text-xs font-medium text-slate-300 hover:text-white"
            >
              <span>Detailed Blocked Log ({blockedList.length} items)</span>
              {showDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showDetails && (
              <div className="p-3 bg-slate-950/90 space-y-2 border-t border-slate-800 text-xs">
                {blockedList.length === 0 ? (
                  <p className="text-slate-400 text-center py-2">No active trackers detected on this site.</p>
                ) : (
                  blockedList.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between"
                    >
                      <div>
                        <p className="font-semibold text-slate-200">{item.name}</p>
                        <p className="text-[10px] text-slate-500 font-mono">{item.domain}</p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-400 border border-slate-700">
                          {item.category}
                        </span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          item.risk === 'High' ? 'bg-red-950 text-red-400' : 'bg-amber-950 text-amber-400'
                        }`}>
                          {item.risk}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-4 bg-slate-950/90 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-500">
            Aegis isolates site storage in disposable sandboxes. No tracking telemetry ever leaves this Android device.
          </p>
        </div>
      </div>
    </div>
  );
};
