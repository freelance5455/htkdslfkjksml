import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Play, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Award, 
  ExternalLink, 
  Volume2, 
  Zap, 
  Check, 
  Ticket,
  ChevronRight,
  Tv,
  Gift
} from 'lucide-react';
import { WeeklyQuiz } from '../types';

interface QuizAdGateModalProps {
  quiz: WeeklyQuiz;
  language: string;
  requiredAdsCount?: number;
  onPassGranted?: () => void;
  onCompleted?: () => void;
  onClose: () => void;
}

interface SponsorAdItem {
  id: string;
  sponsorName: string;
  sponsorBadge: string;
  title: string;
  subtitle: string;
  description: string;
  ctaText: string;
  bgGradient: string;
  iconColor: string;
  features: string[];
}

const SPONSOR_ADS: SponsorAdItem[] = [
  {
    id: 'ad-1',
    sponsorName: 'StudySkill Premier Academy & Study Circle',
    sponsorBadge: 'স্পনসরড পার্টনার ১/২',
    title: 'WBCS & SSC স্পেশাল কমপ্লিট মক টেস্ট ও ডেইলি স্টাডি মেটেরিয়াল',
    subtitle: 'অভিজ্ঞ মেন্টরদের লাইভ গাইডেন্স ও ২০,০০০+ সলভড প্রশ্নভাণ্ডার',
    description: 'পরীক্ষার প্রস্তুতিতে সেরা হতে আজই যুক্ত হোন স্টাডিস্কিল স্পেশাল ব্যাচে। অধ্যায়ভিত্তিক প্র্যাকটিস ও রিয়েল এক্সাম সিমুলেশন।',
    ctaText: 'ফ্রি স্টাডি কিট জানুন',
    bgGradient: 'from-indigo-900/90 via-purple-950/80 to-slate-950',
    iconColor: 'text-indigo-400',
    features: ['অধ্যায়ভিত্তিক প্র্যাকটিস সেট', 'ভিডিও সলিউশন ও নোটস', 'অল বেঙ্গল মক র‍্যাংকিং']
  },
  {
    id: 'ad-2',
    sponsorName: 'Scholar Books & Career Publications',
    sponsorBadge: 'স্পনসরড পার্টনার ২/২',
    title: 'চাকরি ও বোর্ড পরীক্ষার সেরা হ্যান্ডবুক এবং এক্সক্লুসিভ বুকলেট',
    subtitle: 'ছাত্রছাত্রীদের জন্য বিশেষ স্কলারশিপ ও ফ্ল্যাট ৩০% ডিসকাউন্ট',
    description: 'টপারদের তৈরি হ্যান্ডরিটেন নোটস ও সলভড পেপারস সরাসরি আপনার ঠিকানায় ফ্রি হোম ডেলিভারি।',
    ctaText: 'ডিসকাউন্ট কুপন আনলক করুন',
    bgGradient: 'from-amber-950/80 via-slate-900/95 to-slate-950',
    iconColor: 'text-amber-400',
    features: ['লেটেস্ট সিলেবাস ২০২৬', 'ফ্রি ডেলিভারি সুবিধা', 'টপারদের ট্রিকস গাইড']
  }
];

export default function QuizAdGateModal({
  quiz,
  language,
  requiredAdsCount = 2,
  onPassGranted,
  onCompleted,
  onClose
}: QuizAdGateModalProps) {
  const [currentAdIndex, setCurrentAdIndex] = useState<number>(0); // 0 or 1
  const [secondsRemaining, setSecondsRemaining] = useState<number>(5);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [isUnlockingPass, setIsUnlockingPass] = useState<boolean>(false);

  const ad = SPONSOR_ADS[currentAdIndex] || SPONSOR_ADS[0];
  const requiredSeconds = quiz.adWatchSeconds || 5;

  // Countdown timer for active ad
  useEffect(() => {
    setSecondsRemaining(requiredSeconds);
    const interval = setInterval(() => {
      setSecondsRemaining(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentAdIndex, requiredSeconds]);

  const handleNextAdOrComplete = () => {
    if (secondsRemaining > 0) return;

    if (currentAdIndex === 0) {
      // Move to 2nd ad
      setCurrentAdIndex(1);
    } else {
      // Completed both ads
      setIsUnlockingPass(true);
      setTimeout(() => {
        setIsCompleted(true);
        setTimeout(() => {
          if (onCompleted) {
            onCompleted();
          } else if (onPassGranted) {
            onPassGranted();
          }
        }, 1200);
      }, 1000);
    }
  };

  const progressPercent = Math.min(100, Math.round(((requiredSeconds - secondsRemaining) / requiredSeconds) * 100));

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className={`relative w-full max-w-xl bg-gradient-to-b ${ad.bgGradient} border-2 border-indigo-500/40 rounded-3xl p-5 sm:p-7 shadow-2xl overflow-hidden transition-all duration-300`}>
        
        {/* Glowing Background FX */}
        <div className="absolute -top-24 -right-24 w-60 h-60 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-24 -left-24 w-60 h-60 bg-purple-500/20 rounded-full blur-3xl pointer-events-none"></div>

        {/* Top Header Badge & Progress */}
        <div className="relative z-10 flex items-center justify-between gap-3 border-b border-slate-800/80 pb-4 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
              <Tv className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-amber-400 uppercase tracking-wider">
                  {ad.sponsorBadge}
                </span>
                <span className="text-[10px] bg-slate-800 text-slate-300 font-bold px-2 py-0.5 rounded-full border border-slate-700">
                  {currentAdIndex === 0 ? '১ম এড' : '২য় এড (শেষ)'}
                </span>
              </div>
              <h3 className="text-sm font-extrabold text-white">
                {language === 'bn' ? 'কুইজ এন্ট্রি পাস ভেরিফিকেশন' : 'Quiz Entry Pass Verification'}
              </h3>
            </div>
          </div>

          {/* Close button (allowed with warning) */}
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-xs px-2.5 py-1 rounded-lg bg-slate-900/60 hover:bg-slate-800 border border-slate-800 cursor-pointer transition-all"
          >
            {language === 'bn' ? 'বাতিল' : 'Cancel'}
          </button>
        </div>

        {/* Step Indicator: Ad 1 & Ad 2 */}
        <div className="grid grid-cols-2 gap-2 mb-5">
          <div className={`p-2.5 rounded-xl border transition-all flex items-center gap-2 ${
            currentAdIndex === 0 
              ? 'bg-indigo-600/30 border-indigo-400 text-white shadow-md' 
              : 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
          }`}>
            {currentAdIndex > 0 ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <span className="w-4 h-4 rounded-full bg-indigo-500 text-[10px] font-black text-white flex items-center justify-center shrink-0">1</span>
            )}
            <span className="text-xs font-bold truncate">বিজ্ঞাপন ১: স্টাডি পার্টনার</span>
          </div>

          <div className={`p-2.5 rounded-xl border transition-all flex items-center gap-2 ${
            currentAdIndex === 1 
              ? 'bg-indigo-600/30 border-indigo-400 text-white shadow-md' 
              : 'bg-slate-900/60 border-slate-800 text-slate-400'
          }`}>
            {isCompleted ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <span className="w-4 h-4 rounded-full bg-slate-800 text-[10px] font-black text-slate-300 flex items-center justify-center shrink-0">2</span>
            )}
            <span className="text-xs font-bold truncate">বিজ্ঞাপন ২: বুকলেট অফার</span>
          </div>
        </div>

        {/* Ad Content Container */}
        {!isUnlockingPass ? (
          <div className="space-y-4">
            <div className="bg-slate-900/90 border border-slate-800/90 rounded-2xl p-4 sm:p-5 relative overflow-hidden space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400">
                  {ad.sponsorName}
                </span>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-md font-mono">
                  Verified Sponsor
                </span>
              </div>

              <h4 className="text-base sm:text-lg font-black text-white leading-snug">
                {ad.title}
              </h4>
              <p className="text-xs text-indigo-200/90 font-medium">
                {ad.subtitle}
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">
                {ad.description}
              </p>

              {/* Sponsor Bullet Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-800/80">
                {ad.features.map((f, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 text-[11px] text-slate-300">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">{f}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Watch Progress & Next Action Bar */}
            <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  {secondsRemaining > 0 
                    ? (language === 'bn' ? `বিজ্ঞাপন চলছে: ${secondsRemaining} সেকেন্ড বাকি` : `Watching: ${secondsRemaining}s remaining`)
                    : (language === 'bn' ? '✓ বিজ্ঞাপন দেখা সম্পন্ন হয়েছে' : '✓ Ad Completed')}
                </span>
                <span className="font-mono text-indigo-400 font-black">
                  {progressPercent}%
                </span>
              </div>

              {/* Animated Progress Bar */}
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 h-full transition-all duration-300 ease-out rounded-full"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>

              {/* CTA Button */}
              <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
                <button
                  onClick={handleNextAdOrComplete}
                  disabled={secondsRemaining > 0}
                  className={`w-full py-3 px-5 rounded-xl font-black text-sm flex items-center justify-center gap-2 cursor-pointer transition-all duration-200 ${
                    secondsRemaining === 0
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 shadow-lg shadow-emerald-500/25 scale-[1.01]'
                      : 'bg-slate-800/80 text-slate-500 border border-slate-700/50 cursor-not-allowed'
                  }`}
                >
                  {secondsRemaining > 0 ? (
                    <>
                      <Clock className="w-4 h-4 animate-spin text-amber-400" />
                      <span>{language === 'bn' ? `দয়া করে ${secondsRemaining} সেকেন্ড অপেক্ষা করুন` : `Please wait ${secondsRemaining}s...`}</span>
                    </>
                  ) : currentAdIndex === 0 ? (
                    <>
                      <span>{language === 'bn' ? 'পরবর্তী এড দেখুন (২/২)' : 'Watch Next Ad (2/2)'}</span>
                      <ChevronRight className="w-4 h-4" />
                    </>
                  ) : (
                    <>
                      <Ticket className="w-4 h-4 text-slate-950 animate-bounce" />
                      <span>{language === 'bn' ? 'কুইজ এন্ট্রি পাস আনলক করুন ও শুরু করুন' : 'Claim Entry Pass & Start Quiz'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <p className="text-[11px] text-center text-slate-500">
              {language === 'bn' 
                ? 'স্পনসরড বিজ্ঞাপন ফ্রিতে বড় অংকের পুরস্কার তহবিল গঠন করতে সাহায্য করে।' 
                : 'Sponsored ads support free physical prize funding for top learners.'}
            </p>
          </div>
        ) : (
          /* Pass Verified Success Transition */
          <div className="py-12 flex flex-col items-center justify-center text-center space-y-4 animate-in zoom-in-95 duration-300">
            <div className="w-20 h-20 bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 rounded-3xl flex items-center justify-center shadow-xl shadow-emerald-500/30 animate-bounce">
              <Ticket className="w-10 h-10" />
            </div>

            <div className="space-y-1.5">
              <span className="text-xs font-black text-emerald-400 uppercase tracking-wider">
                ENTRY PASS VERIFIED
              </span>
              <h3 className="text-xl font-black text-white">
                {language === 'bn' ? 'কুইজে অংশগ্রহণের অনুমতি নিশ্চিত হয়েছে!' : 'Quiz Entry Pass Unlocked!'}
              </h3>
              <p className="text-xs text-slate-300 max-w-sm mx-auto">
                {language === 'bn' ? 'আপনার লাইভ পরীক্ষাটি এখন লোড হচ্ছে... শুভকামনা!' : 'Loading your live test... Best of luck!'}
              </p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
