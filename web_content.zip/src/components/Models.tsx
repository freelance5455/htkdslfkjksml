import { useMemo, useRef, useState } from "react";
import { KINDS, MODELS, type ModelKind, type YunoModel } from "../lib/models";
import { usePersistentState, useReveal } from "../lib/hooks";
import { IconCheck, IconDownload, IconGithub, IconHf, IconSearch, IconCpu } from "./Icons";

interface Props {
  selectedId: string;
  onSelect: (m: YunoModel) => void;
  toast: (msg: string, kind?: "ok" | "warn") => void;
}

const KIND_COLOR: Record<ModelKind, string> = {
  Code: "text-ember border-ember/50 bg-ember/8",
  Chat: "text-teal border-teal/50 bg-teal/8",
  Vision: "text-[#7dd8ff] border-[#7dd8ff]/50 bg-[#7dd8ff]/8",
  Voice: "text-coral border-coral/50 bg-coral/8",
};

export default function Models({ selectedId, onSelect, toast }: Props) {
  const [kind, setKind] = useState<(typeof KINDS)[number]>("All");
  const [q, setQ] = useState("");
  const [cached, setCached] = usePersistentState<string[]>("yuno.models.cached", ["qwen-coder", "whisper"]);
  const [downloading, setDownloading] = useState<Record<string, number>>({});
  const timers = useRef<Record<string, ReturnType<typeof setInterval>>>({});
  const headRef = useReveal<HTMLDivElement>();
  const gridRef = useReveal<HTMLDivElement>();

  const list = useMemo(
    () =>
      MODELS.filter((m) => (kind === "All" ? true : m.kind === kind)).filter((m) =>
        (m.name + " " + m.org + " " + m.tags.join(" ")).toLowerCase().includes(q.toLowerCase())
      ),
    [kind, q]
  );

  const startDownload = (m: YunoModel) => {
    if (cached.includes(m.id) || downloading[m.id] !== undefined) return;
    let p = 0;
    setDownloading((d) => ({ ...d, [m.id]: 0 }));
    timers.current[m.id] = setInterval(() => {
      p += 3 + Math.random() * 9;
      if (p >= 100) {
        clearInterval(timers.current[m.id]);
        delete timers.current[m.id];
        setDownloading((d) => {
          const n = { ...d };
          delete n[m.id];
          return n;
        });
        setCached((c) => [...c, m.id]);
        toast(`${m.name} cached to disk — ready for offline forging`, "ok");
      } else {
        setDownloading((d) => ({ ...d, [m.id]: Math.floor(p) }));
      }
    }, 110);
  };

  return (
    <section id="models" className="relative py-24">
      <div className="mx-auto max-w-7xl px-5">
        <div ref={headRef} className="reveal flex flex-wrap items-end justify-between gap-6 mb-10">
          <div>
            <p className="font-mono text-[11px] tracking-[0.3em] text-teal mb-3">// 01 — MODEL DECK</p>
            <h2 className="font-display font-bold text-[clamp(1.6rem,3.4vw,2.5rem)] text-snow leading-tight">
              Pick your engine.<br />
              <span className="text-fog text-[0.62em] font-medium">Every weight runs on your hardware.</span>
            </h2>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <label className="flex items-center gap-2.5 border border-line bg-panel px-3.5 h-11 clip-hud-sm focus-within:border-ember/60 transition-colors w-full sm:w-64">
              <IconSearch size={15} className="text-fog" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search models, tags, orgs…"
                className="bg-transparent outline-none text-[13px] text-snow placeholder:text-fog/60 w-full font-mono"
              />
            </label>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-8">
          {KINDS.map((k) => (
            <button
              key={k}
              onClick={() => setKind(k)}
              className={`clip-tag px-4 py-2 font-mono text-[11px] tracking-[0.16em] border transition-all duration-200 ${
                kind === k
                  ? "bg-ember text-ink border-ember shadow-[0_0_22px_rgba(255,180,84,0.3)]"
                  : "border-line2 text-fog hover:text-snow hover:border-ember/50"
              }`}
            >
              {k.toUpperCase()}
              <span className="ml-2 opacity-60">
                {k === "All" ? MODELS.length : MODELS.filter((m) => m.kind === k).length}
              </span>
            </button>
          ))}
        </div>

        <div ref={gridRef} className="reveal grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {list.map((m) => {
            const isSelected = m.id === selectedId;
            const isCached = cached.includes(m.id);
            const prog = downloading[m.id];
            return (
              <article
                key={m.id}
                className={`card-hover relative border bg-panel clip-hud p-5 flex flex-col ${
                  isSelected ? "border-ember shadow-[0_0_0_1px_rgba(255,180,84,0.35),0_0_36px_rgba(255,122,47,0.12)]" : "border-line"
                }`}
              >
                {isSelected && (
                  <span className="absolute top-0 right-0 bg-ember text-ink font-mono text-[9px] font-bold tracking-[0.2em] px-2.5 py-1">
                    ACTIVE
                  </span>
                )}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-fog">{m.source === "github" ? <IconGithub size={17} /> : <IconHf size={17} />}</span>
                    <div>
                      <h3 className="font-display text-[15px] font-bold text-snow leading-none">{m.name}</h3>
                      <p className="font-mono text-[10px] text-fog mt-1.5 tracking-[0.12em]">
                        {m.org.toUpperCase()} · {m.params}
                      </p>
                    </div>
                  </div>
                  <span className={`clip-tag border px-2 py-1 font-mono text-[9px] tracking-[0.18em] ${KIND_COLOR[m.kind]}`}>
                    {m.kind.toUpperCase()}
                  </span>
                </div>

                <p className="mt-3.5 text-[12.5px] leading-relaxed text-fog min-h-[56px]">{m.desc}</p>

                <div className="mt-3 grid grid-cols-3 gap-px bg-line border border-line clip-tag overflow-hidden">
                  {[
                    ["QUANT", m.quant],
                    ["SIZE", m.sizeGb.toFixed(1) + " GB"],
                    ["RAM", m.ramGb.toFixed(1) + " GB"],
                  ].map(([k, v]) => (
                    <div key={k} className="bg-ink2 px-2.5 py-2">
                      <p className="font-mono text-[8.5px] tracking-[0.2em] text-fog/70">{k}</p>
                      <p className="font-mono text-[11.5px] text-mist mt-0.5">{v}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-3">
                  <div className="flex justify-between font-mono text-[9.5px] tracking-[0.16em] text-fog mb-1.5">
                    <span className="flex items-center gap-1.5"><IconCpu size={11} /> INFER SPEED</span>
                    <span className="text-teal">{m.tokPerSec} tok/s</span>
                  </div>
                  <div className="h-1 bg-ink2 relative overflow-hidden">
                    <div
                      className="absolute inset-y-0 left-0 bg-gradient-to-r from-tealdim to-teal transition-all duration-700"
                      style={{ width: `${Math.min(100, (m.tokPerSec / 140) * 100)}%` }}
                    />
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {m.tags.map((t) => (
                    <span key={t} className="font-mono text-[9px] tracking-[0.14em] text-fog border border-line2 px-1.5 py-0.5">
                      {t}
                    </span>
                  ))}
                </div>

                <div className="mt-4 pt-4 border-t border-line flex items-center gap-2.5">
                  <button
                    onClick={() => (isCached ? undefined : startDownload(m))}
                    disabled={isCached || prog !== undefined}
                    className={`clip-tag h-9 px-3 font-mono text-[10px] tracking-[0.14em] border transition-all ${
                      isCached
                        ? "border-teal/50 text-teal bg-teal/8 cursor-default"
                        : prog !== undefined
                          ? "border-line2 text-mist w-36"
                          : "border-line2 text-fog hover:border-ember hover:text-ember"
                    }`}
                  >
                    {isCached ? (
                      <span className="flex items-center gap-1.5"><IconCheck size={12} /> CACHED</span>
                    ) : prog !== undefined ? (
                      <span className="relative block h-full w-full">
                        <span className="absolute inset-0 bg-ember/20 stripes" style={{ width: `${prog}%` }} />
                        <span className="relative z-10 leading-[34px]">{prog}% OF {m.sizeGb.toFixed(1)}GB</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5"><IconDownload size={12} /> CACHE LOCALLY</span>
                    )}
                  </button>
                  <button
                    onClick={() => {
                      onSelect(m);
                      toast(`Forge engine set to ${m.name} ${m.params}`, "ok");
                    }}
                    className={`clip-tag h-9 flex-1 font-mono text-[10px] font-bold tracking-[0.14em] transition-all ${
                      isSelected
                        ? "bg-ember text-ink"
                        : "btn-ghost hover:bg-panel2"
                    }`}
                  >
                    {isSelected ? "FORGING WITH THIS" : "FORGE WITH THIS"}
                  </button>
                </div>
              </article>
            );
          })}
        </div>

        {list.length === 0 && (
          <p className="text-center font-mono text-fog text-sm py-16">
            No models match "{q}" — try another tag.
          </p>
        )}

        <p className="mt-8 font-mono text-[10.5px] tracking-[0.14em] text-fog/70 flex items-center gap-2">
          <IconDownload size={13} className="text-teal" />
          "CACHE LOCALLY" STREAMS WEIGHTS FROM HUGGING FACE / GITHUB ONCE — AFTER THAT THE MODEL RUNS FOREVER OFFLINE.
        </p>
      </div>
    </section>
  );
}
