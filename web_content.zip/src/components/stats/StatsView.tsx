import React, { useState, useMemo } from 'react';
import { Book, ReadingSession } from '../../types';
import { calculateReadingStats } from '../../services/statsCalculator';
import {
  BarChart3,
  BookCheck,
  Clock,
  Flame,
  Zap,
  Award,
  Layers,
  Calendar,
  Sparkles,
  TrendingUp,
} from 'lucide-react';

interface StatsViewProps {
  books: Book[];
  sessions: ReadingSession[];
  onOpenBookDetail: (book: Book) => void;
}

export const StatsView: React.FC<StatsViewProps> = ({ books, sessions, onOpenBookDetail }) => {
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState<number>(currentYear);
  const [viewScope, setViewScope] = useState<'AÑO' | 'TODO'>('AÑO');

  // Compute calculated stats with real data
  const stats = useMemo(() => {
    return calculateReadingStats(books, sessions, viewScope === 'AÑO' ? selectedYear : undefined);
  }, [books, sessions, viewScope, selectedYear]);

  // Max pages in monthly breakdown for chart scale
  const maxMonthlyPages = useMemo(() => {
    const pages = stats.monthlyBreakdown.map((m) => m.pages);
    return Math.max(...pages, 50);
  }, [stats.monthlyBreakdown]);

  // Find longest book, shortest book, highest rated book
  const longestBook = useMemo(() => {
    return [...books].sort((a, b) => (b.totalPages || 0) - (a.totalPages || 0))[0];
  }, [books]);

  const mostReadBook = useMemo(() => {
    return [...books].sort((a, b) => (b.totalReadingMinutes || 0) - (a.totalReadingMinutes || 0))[0];
  }, [books]);

  return (
    <div className="space-y-6 pb-16 animate-fadeIn">
      {/* Header and Scope Selector */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne']">
            Estadísticas de Lectura
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Métricas precisas y progreso calculados a partir de tus sesiones reales
          </p>
        </div>

        {/* Scope and Year selector */}
        <div className="flex items-center gap-2 self-end sm:self-auto">
          <div className="flex items-center p-1 bg-white/[0.04] border border-white/10 rounded-xl text-xs">
            <button
              onClick={() => setViewScope('AÑO')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                viewScope === 'AÑO'
                  ? 'bg-white/15 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Año {selectedYear}
            </button>
            <button
              onClick={() => setViewScope('TODO')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                viewScope === 'TODO'
                  ? 'bg-white/15 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Histórico
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid (60-30-10, Tabular figures) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {/* Books Completed */}
        <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">
              Libros Leídos
            </span>
            <div className="w-7 h-7 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center text-white">
              <BookCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight tabular-nums">
              {stats.completedBooks}
            </span>
            <span className="text-xs text-zinc-400 block mt-0.5">
              de {stats.totalBooks} en biblioteca
            </span>
          </div>
        </div>

        {/* Total Pages Read */}
        <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">
              Páginas Leídas
            </span>
            <div className="w-7 h-7 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center text-white">
              <Layers className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight tabular-nums">
              {stats.totalPagesRead}
            </span>
            <span className="text-xs text-zinc-400 block mt-0.5">
              ~{stats.avgPagesPerSession} págs / sesión
            </span>
          </div>
        </div>

        {/* Total Reading Time */}
        <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">
              Tiempo Total
            </span>
            <div className="w-7 h-7 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center text-white">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight tabular-nums">
              {stats.totalReadingHoursFormatted}
            </span>
            <span className="text-xs text-zinc-400 block mt-0.5">
              ~{stats.avgMinutesPerSession} min / sesión
            </span>
          </div>
        </div>

        {/* Velocity / Streak */}
        <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">
              Velocidad
            </span>
            <div className="w-7 h-7 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center text-white">
              <Zap className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight tabular-nums">
              {stats.readingVelocityPagesPerHour}
            </span>
            <span className="text-xs text-zinc-400 block mt-0.5">
              páginas por hora
            </span>
          </div>
        </div>
      </div>

      {/* Monthly Bar Chart */}
      <div className="glass-panel rounded-2xl p-5 sm:p-6 border border-white/10 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight uppercase tracking-wider">
              Ritmo de Lectura Mensual ({selectedYear})
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">Páginas leídas mes a mes</p>
          </div>
          <span className="text-xs font-mono text-white font-semibold tabular-nums">
            Total {stats.monthlyBreakdown.reduce((sum, m) => sum + m.pages, 0)} págs
          </span>
        </div>

        {/* SVG/CSS Bar Chart with Glass Ledges */}
        <div className="pt-6 pb-2">
          <div className="h-44 flex items-end justify-between gap-1 sm:gap-2">
            {stats.monthlyBreakdown.map((m) => {
              const heightPercent = maxMonthlyPages > 0 ? Math.round((m.pages / maxMonthlyPages) * 100) : 0;
              const hasPages = m.pages > 0;

              return (
                <div key={m.monthIndex} className="flex-1 flex flex-col items-center h-full justify-end group">
                  {/* Bar Value Tooltip */}
                  {hasPages && (
                    <span className="text-[10px] font-mono text-zinc-300 opacity-0 group-hover:opacity-100 transition-opacity mb-1 tabular-nums">
                      {m.pages}
                    </span>
                  )}
                  {/* Bar Column */}
                  <div
                    className={`w-full max-w-[28px] rounded-t-lg transition-all duration-500 relative ${
                      hasPages
                        ? 'bg-gradient-to-t from-zinc-500 to-white shadow-[0_0_12px_rgba(255,255,255,0.25)]'
                        : 'bg-white/[0.04]'
                    }`}
                    style={{ height: `${Math.max(hasPages ? 8 : 2, heightPercent)}%` }}
                  />
                  {/* Month Label */}
                  <span className="text-[10px] text-zinc-400 font-medium mt-2">{m.monthLabel}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Breakdown: Géneros & Autores */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Top Genres */}
        <div className="glass-panel rounded-2xl p-5 border border-white/10 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
            Géneros más leídos
          </h3>
          {stats.topGenres.length === 0 ? (
            <p className="text-xs text-zinc-500 py-4 text-center">Sin datos de géneros aún</p>
          ) : (
            <div className="space-y-2.5">
              {stats.topGenres.map((g) => {
                const percent = Math.round((g.count / (stats.totalBooks || 1)) * 100);
                return (
                  <div key={g.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-medium">
                      <span className="text-white/90">{g.name}</span>
                      <span className="text-zinc-400 font-mono tabular-nums">
                        {g.count} {g.count === 1 ? 'libro' : 'libros'}
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                      <div
                        className="h-full bg-white/80 rounded-full"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Top Authors */}
        <div className="glass-panel rounded-2xl p-5 border border-white/10 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
            Autores destacados
          </h3>
          {stats.topAuthors.length === 0 ? (
            <p className="text-xs text-zinc-500 py-4 text-center">Sin datos de autores aún</p>
          ) : (
            <div className="space-y-2.5">
              {stats.topAuthors.map((a, idx) => (
                <div
                  key={a.name}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.06]"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-xs font-bold font-mono text-white/90 w-4">{idx + 1}</span>
                    <span className="text-xs font-semibold text-white/95 truncate">{a.name}</span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs font-mono font-bold text-white block tabular-nums">
                      {a.pages} págs
                    </span>
                    <span className="text-[10px] text-zinc-400 tabular-nums">
                      {a.count} {a.count === 1 ? 'libro' : 'libros'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* MI AÑO DE LECTURA (Section 47) */}
      <div className="glass-panel rounded-2xl p-6 border border-white/15 relative overflow-hidden shadow-2xl">
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-zinc-300" />
              <h2 className="text-lg font-bold text-white tracking-tight font-['Syne']">
                Mi Año de Lectura {selectedYear}
              </h2>
            </div>
            <p className="text-xs text-zinc-400 mt-1">
              Tu trayectoria literaria resumida en un vistazo
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-white/10 text-xs font-semibold text-white border border-white/15">
              {stats.activeReadingDaysCount} días activos
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 relative z-10">
          <div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 block">Libro más extenso</span>
            <p className="text-xs font-semibold text-white mt-1 truncate">
              {longestBook ? `${longestBook.title} (${longestBook.totalPages} págs)` : '—'}
            </p>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 block">Racha récord</span>
            <p className="text-xs font-semibold text-zinc-200 mt-1">
              {stats.longestStreakDays} {stats.longestStreakDays === 1 ? 'día' : 'días'}
            </p>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 block">Sesiones registradas</span>
            <p className="text-xs font-semibold text-white mt-1 tabular-nums">{stats.totalSessions}</p>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 block">En curso</span>
            <p className="text-xs font-semibold text-zinc-300 mt-1 tabular-nums">
              {stats.readingBooks} {stats.readingBooks === 1 ? 'libro' : 'libros'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
