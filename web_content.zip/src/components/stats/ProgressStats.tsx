import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BarChart3,
  TrendingUp,
  CheckCircle2,
  Clock,
  BookOpen,
  Compass,
  Pill,
  Award,
  Calendar,
  Layers,
} from 'lucide-react';
import { timeToMinutes } from '../../utils/smartScheduler';

const DAYS_NAMES_AR = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export const ProgressStats: React.FC = () => {
  const {
    subjects,
    scheduleItems,
    completedPrayersRecord,
    medications,
    medicationLogs,
    currentTime,
  } = useApp();

  // 1. Study Hours per day of week (Planned vs Completed)
  const studyHoursByDay = useMemo(() => {
    return DAYS_NAMES_AR.map((name, dayIndex) => {
      const items = scheduleItems.filter((i) => i.dayOfWeek === dayIndex && i.type === 'study');
      const plannedMinutes = items.reduce((acc, i) => acc + i.durationMinutes, 0);
      const completedMinutes = items
        .filter((i) => i.isCompleted)
        .reduce((acc, i) => acc + i.durationMinutes, 0);

      return {
        name,
        dayIndex,
        plannedHours: Number((plannedMinutes / 60).toFixed(1)),
        completedHours: Number((completedMinutes / 60).toFixed(1)),
      };
    });
  }, [scheduleItems]);

  const maxHours = Math.max(6, ...studyHoursByDay.map((d) => d.plannedHours));

  // 2. Total lectures and sections breakdown
  const lectureSectionStats = useMemo(() => {
    let totalLectures = 0;
    let completedLectures = 0;
    let totalSections = 0;
    let completedSections = 0;

    subjects.forEach((sub) => {
      const lecs = sub.items.filter((i) => i.type === 'lecture');
      const secs = sub.items.filter((i) => i.type === 'section');

      totalLectures += lecs.length;
      completedLectures += lecs.filter((l) => l.isCompleted).length;

      totalSections += secs.length;
      completedSections += secs.filter((s) => s.isCompleted).length;
    });

    return {
      totalLectures,
      completedLectures,
      remainingLectures: totalLectures - completedLectures,
      totalSections,
      completedSections,
      remainingSections: totalSections - completedSections,
    };
  }, [subjects]);

  // 3. Schedule Adherence Rate
  const scheduleAdherence = useMemo(() => {
    const total = scheduleItems.length;
    const completed = scheduleItems.filter((i) => i.isCompleted).length;
    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
    return { total, completed, rate };
  }, [scheduleItems]);

  // 4. Prayer Regularity (past 7 days)
  const prayerStats = useMemo(() => {
    const totalTarget = 7 * 5;
    let completed = 0;
    for (let i = 0; i < 7; i++) {
      const d = new Date(currentTime);
      d.setDate(d.getDate() - i);
      const str = d.toISOString().split('T')[0];
      const list = completedPrayersRecord[str] || [];
      completed += list.filter((p) => p !== 'sunrise').length;
    }
    const rate = Math.round((completed / totalTarget) * 100);
    return { completed, totalTarget, rate };
  }, [completedPrayersRecord, currentTime]);

  // 5. Medication Adherence
  const medStats = useMemo(() => {
    const active = medications.filter((m) => m.active);
    const dailyTarget = active.reduce((acc, m) => acc + m.times.length, 0);
    const weeklyTarget = dailyTarget * 7;
    const takenCount = medicationLogs.filter((l) => l.status === 'taken').length;
    const rate = weeklyTarget > 0 ? Math.min(100, Math.round((takenCount / weeklyTarget) * 100)) : 100;
    return { takenCount, weeklyTarget, rate };
  }, [medications, medicationLogs]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Title Banner */}
      <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-rose-600 dark:text-rose-400" />
          <h2 className="text-xl font-bold text-slate-900 dark:text-rose-50">
            متابعة الإنجاز والإحصائيات التفاعلية
          </h2>
        </div>
        <p className="text-xs text-slate-500 dark:text-rose-200/70 mt-1">
          رؤية تحليلية شاملة لساعات المذاكرة، نسبة تغطية المواد، الالتزام بالجدول، ومتابعة الأدوية والصلاة
        </p>
      </div>

      {/* 4 Core Metric Gauges */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Schedule Adherence */}
        <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-200/70">الالتزام بالجدول</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100 mb-2">
            {scheduleAdherence.rate}%
          </div>
          <p className="text-xs text-slate-500 dark:text-rose-200/70">
            {scheduleAdherence.completed} من {scheduleAdherence.total} نشاط مكتمل
          </p>
          <div className="w-full bg-rose-100/60 dark:bg-rose-950/60 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-rose-500 h-full rounded-full transition-all"
              style={{ width: `${scheduleAdherence.rate}%` }}
            />
          </div>
        </div>

        {/* Study Hours */}
        <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-200/70">ساعات المذاكرة الأسبوعية</span>
            <div className="w-8 h-8 rounded-lg bg-pink-50 dark:bg-pink-950/60 text-pink-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100 mb-2">
            {studyHoursByDay.reduce((a, b) => a + b.completedHours, 0).toFixed(1)}{' '}
            <span className="text-xs font-normal text-rose-400">
              / {studyHoursByDay.reduce((a, b) => a + b.plannedHours, 0).toFixed(1)} س
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-rose-200/70">ساعات المذاكرة المنجزة هذا الأسبوع</p>
          <div className="w-full bg-rose-100/60 dark:bg-rose-950/60 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-rose-500 to-pink-500 h-full rounded-full transition-all"
              style={{
                width: `${Math.min(
                  100,
                  Math.round(
                    (studyHoursByDay.reduce((a, b) => a + b.completedHours, 0) /
                      Math.max(1, studyHoursByDay.reduce((a, b) => a + b.plannedHours, 0))) *
                      100
                  )
                )}%`,
              }}
            />
          </div>
        </div>

        {/* Prayer Regularity */}
        <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-200/70">الانتظام في الصلاة</span>
            <div className="w-8 h-8 rounded-lg bg-fuchsia-50 dark:bg-fuchsia-950/60 text-fuchsia-600 flex items-center justify-center">
              <Compass className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100 mb-2">
            {prayerStats.rate}%
          </div>
          <p className="text-xs text-slate-500 dark:text-rose-200/70">
            {prayerStats.completed} فريضة مسجلة من 35 فريضة
          </p>
          <div className="w-full bg-rose-100/60 dark:bg-rose-950/60 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-fuchsia-500 h-full rounded-full transition-all"
              style={{ width: `${prayerStats.rate}%` }}
            />
          </div>
        </div>

        {/* Medication Compliance */}
        <div className="bg-white dark:bg-[#180d15] p-5 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-rose-200/70">الالتزام بالدواء</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center">
              <Pill className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100 mb-2">
            {medStats.rate}%
          </div>
          <p className="text-xs text-slate-500 dark:text-rose-200/70">
            {medStats.takenCount} جرعة مأخوذة في موعدها
          </p>
          <div className="w-full bg-rose-100/60 dark:bg-rose-950/60 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-rose-600 h-full rounded-full transition-all"
              style={{ width: `${medStats.rate}%` }}
            />
          </div>
        </div>
      </div>

      {/* Interactive Daily Study Hours Bar Chart */}
      <div className="bg-white dark:bg-[#180d15] p-6 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-rose-50 dark:border-rose-950/50 mb-6">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-rose-50">
              مقارنة ساعات المذاكرة اليومية (المخطط vs المنجز)
            </h3>
            <p className="text-xs text-slate-500 dark:text-rose-200/70">
              توزيع ساعات الاستذكار على أيام الأسبوع
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-rose-500" />
              <span className="text-slate-600 dark:text-rose-200">المنجز فعلياً</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-rose-200 dark:bg-rose-950" />
              <span className="text-slate-600 dark:text-rose-200">المخطط في الجدول</span>
            </div>
          </div>
        </div>

        {/* Chart Columns */}
        <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end h-64 pt-6 pb-2 border-b border-rose-100 dark:border-rose-950/60">
          {studyHoursByDay.map((day) => {
            const plannedHeight = (day.plannedHours / maxHours) * 100;
            const completedHeight = (day.completedHours / maxHours) * 100;

            return (
              <div key={day.dayIndex} className="flex flex-col items-center h-full justify-end group">
                <div className="text-[11px] font-mono font-semibold text-rose-700 dark:text-rose-300 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {day.completedHours}س
                </div>

                <div className="w-full max-w-[42px] flex items-end justify-center gap-1 h-full">
                  {/* Planned Bar */}
                  <div
                    className="w-1/2 bg-rose-100 dark:bg-rose-950/60 rounded-t-md transition-all duration-500"
                    style={{ height: `${Math.max(8, plannedHeight)}%` }}
                    title={`المخطط: ${day.plannedHours} ساعة`}
                  />
                  {/* Completed Bar */}
                  <div
                    className="w-1/2 bg-gradient-to-t from-rose-600 to-pink-500 rounded-t-md transition-all duration-500 shadow-xs"
                    style={{ height: `${Math.max(4, completedHeight)}%` }}
                    title={`المنجز: ${day.completedHours} ساعة`}
                  />
                </div>

                <div className="text-xs font-semibold text-slate-700 dark:text-rose-200 mt-2">
                  {day.name}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lectures and Sections Breakdown & Subject Coverage */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Lectures & Sections Counter Card */}
        <div className="bg-white dark:bg-[#180d15] p-6 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors space-y-4 shadow-xs">
          <h3 className="font-bold text-base text-slate-900 dark:text-rose-50 pb-3 border-b border-rose-50 dark:border-rose-950/50">
            موقف المحاضرات والسكاشن
          </h3>

          <div className="grid grid-cols-2 gap-4">
            {/* Lectures Block */}
            <div className="p-4 rounded-xl bg-rose-50/60 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 space-y-2">
              <div className="text-xs font-bold text-rose-700 dark:text-rose-300">
                المحاضرات الجامعية
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100">
                  {lectureSectionStats.completedLectures}
                </span>
                <span className="text-xs text-rose-400">
                  من إجمالي {lectureSectionStats.totalLectures}
                </span>
              </div>
              <div className="text-[11px] text-rose-600 dark:text-rose-300 font-medium">
                متبقي {lectureSectionStats.remainingLectures} محاضرات
              </div>
            </div>

            {/* Sections Block */}
            <div className="p-4 rounded-xl bg-pink-50/60 dark:bg-pink-950/40 border border-pink-200 dark:border-pink-900/60 space-y-2">
              <div className="text-xs font-bold text-pink-700 dark:text-pink-300">
                السكاشن والتمارين
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-bold font-mono text-slate-900 dark:text-rose-100">
                  {lectureSectionStats.completedSections}
                </span>
                <span className="text-xs text-pink-400">
                  من إجمالي {lectureSectionStats.totalSections}
                </span>
              </div>
              <div className="text-[11px] text-pink-600 dark:text-pink-300 font-medium">
                متبقي {lectureSectionStats.remainingSections} سكاشن
              </div>
            </div>
          </div>
        </div>

        {/* Subjects Progress Meters */}
        <div className="bg-white dark:bg-[#180d15] p-6 rounded-2xl border border-rose-100 dark:border-rose-950/60 transition-colors space-y-4 shadow-xs">
          <h3 className="font-bold text-base text-slate-900 dark:text-rose-50 pb-3 border-b border-rose-50 dark:border-rose-950/50">
            نسبة تغطية المواد الدراسية
          </h3>

          <div className="space-y-3.5">
            {subjects.map((sub) => {
              const total = sub.items.length;
              const completed = sub.items.filter((i) => i.isCompleted).length;
              const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

              return (
                <div key={sub.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-800 dark:text-rose-100">
                      {sub.name} ({sub.code})
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-rose-700 dark:text-rose-300">
                      {completed} / {total} ({pct}%)
                    </span>
                  </div>

                  <div className="w-full bg-rose-100/60 dark:bg-rose-950/60 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%`, backgroundColor: sub.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
