/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Book, ReadingSession } from '../../types';
import {
  X,
  Sparkles,
  Calendar,
  BookOpen,
  Clock,
  Flame,
  TrendingUp,
  Tag as TagIcon,
  Award,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

interface ReadingSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  books: Book[];
  sessions: ReadingSession[];
}

const MONTH_NAMES = [
  'Enero',
  'Febrero',
  'Marzo',
  'Abril',
  'Mayo',
  'Junio',
  'Julio',
  'Agosto',
  'Septiembre',
  'Octubre',
  'Noviembre',
  'Diciembre',
];

export const ReadingSummaryModal: React.FC<ReadingSummaryModalProps> = ({
  isOpen,
  onClose,
  books,
  sessions,
}) => {
  if (!isOpen) return null;

  const currentDate = new Date();
  const [periodType, setPeriodType] = useState<'month' | 'year'>('month');
  const [selectedYear, setSelectedYear] = useState<number>(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(currentDate.getMonth()); // 0-indexed

  // Filter sessions that fall precisely in the chosen period
  const filteredSessions = useMemo(() => {
    return sessions.filter((s) => {
      if (!s.date) return false;
      const [yearStr, monthStr] = s.date.split('-');
      const y = parseInt(yearStr, 10);
      const m = parseInt(monthStr, 10) - 1;

      if (periodType === 'year') {
        return y === selectedYear;
      } else {
        return y === selectedYear && m === selectedMonth;
      }
    });
  }, [sessions, periodType, selectedYear, selectedMonth]);

  // Real books completed in this period
  const completedBooksInPeriod = useMemo(() => {
    return books.filter((b) => {
      if (b.status !== 'TERMINADO') return false;
      const lastSessionDate = sessions.filter((s) => s.bookId === b.id).sort((x, y) => x.date.localeCompare(y.date)).pop()?.date;
      const finishDate = b.dateFinished || lastSessionDate;
      if (!finishDate) return false;

      const dateObj = new Date(finishDate);
      if (isNaN(dateObj.getTime())) return false;

      if (periodType === 'year') {
        return dateObj.getFullYear() === selectedYear;
      } else {
        return dateObj.getFullYear() === selectedYear && dateObj.getMonth() === selectedMonth;
      }
    });
  }, [books, periodType, selectedYear, selectedMonth]);

  // Aggregate stats from real data
  const totalPagesRead = useMemo(() => {
    return filteredSessions.reduce((acc, s) => acc + (s.pagesRead || 0), 0);
  }, [filteredSessions]);

  const totalReadingMinutes = useMemo(() => {
    return filteredSessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0);
  }, [filteredSessions]);

  const formattedTime = useMemo(() => {
    const hours = Math.floor(totalReadingMinutes / 60);
    const mins = totalReadingMinutes % 60;
    if (hours > 0) return `${hours} h ${mins} min`;
    return `${mins} min`;
  }, [totalReadingMinutes]);

  const activeReadingDays = useMemo(() => {
    const daysSet = new Set(filteredSessions.map((s) => s.date));
    return daysSet.size;
  }, [filteredSessions]);

  const dailyAveragePages = useMemo(() => {
    if (activeReadingDays === 0) return 0;
    return Math.round(totalPagesRead / activeReadingDays);
  }, [totalPagesRead, activeReadingDays]);

  // Calculate streak in period
  const periodStreak = useMemo(() => {
    const days = Array.from(new Set(filteredSessions.map((s) => s.date))).sort();
    if (days.length === 0) return 0;

    let maxStreak = 1;
    let currentStreak = 1;

    for (let i = 1; i < days.length; i++) {
      const prev = new Date(days[i - 1]);
      const curr = new Date(days[i]);
      const diffDays = Math.round((curr.getTime() - prev.getTime()) / (1000 * 3600 * 24));

      if (diffDays === 1) {
        currentStreak++;
        if (currentStreak > maxStreak) maxStreak = currentStreak;
      } else if (diffDays > 1) {
        currentStreak = 1;
      }
    }

    return maxStreak;
  }, [filteredSessions]);

  // Most read book in this period (by pages read in sessions)
  const mostReadBook = useMemo(() => {
    const bookPageMap: Record<string, number> = {};
    filteredSessions.forEach((s) => {
      bookPageMap[s.bookId] = (bookPageMap[s.bookId] || 0) + (s.pagesRead || 0);
    });

    let topBookId: string | null = null;
    let topPages = -1;

    Object.entries(bookPageMap).forEach(([bookId, p]) => {
      if (p > topPages) {
        topPages = p;
        topBookId = bookId;
      }
    });

    if (topBookId) {
      const found = books.find((b) => b.id === topBookId);
      if (found) return { book: found, pages: topPages };
    }

    if (completedBooksInPeriod.length > 0) {
      return { book: completedBooksInPeriod[0], pages: completedBooksInPeriod[0].totalPages };
    }

    return null;
  }, [filteredSessions, books, completedBooksInPeriod]);

  // Most read author
  const mostReadAuthor = useMemo(() => {
    const authorMap: Record<string, number> = {};
    filteredSessions.forEach((s) => {
      const b = books.find((x) => x.id === s.bookId);
      if (b && b.author) {
        authorMap[b.author] = (authorMap[b.author] || 0) + (s.pagesRead || 0);
      }
    });

    let topAuthor = '';
    let topPages = -1;
    Object.entries(authorMap).forEach(([author, p]) => {
      if (p > topPages) {
        topPages = p;
        topAuthor = author;
      }
    });

    return topAuthor || (books[0]?.author ?? 'Sin registros');
  }, [filteredSessions, books]);

  // Most read genre
  const mostReadGenre = useMemo(() => {
    const genreMap: Record<string, number> = {};
    filteredSessions.forEach((s) => {
      const b = books.find((x) => x.id === s.bookId);
      if (b && b.genres) {
        b.genres.forEach((g) => {
          genreMap[g] = (genreMap[g] || 0) + 1;
        });
      }
    });

    let topGenre = '';
    let count = 0;
    Object.entries(genreMap).forEach(([g, c]) => {
      if (c > count) {
        count = c;
        topGenre = g;
      }
    });

    return topGenre || (books[0]?.genres?.[0] ?? 'Lectura general');
  }, [filteredSessions, books]);

  // Most used tags in period
  const mostUsedTags = useMemo(() => {
    const tagMap: Record<string, number> = {};
    filteredSessions.forEach((s) => {
      const b = books.find((x) => x.id === s.bookId);
      if (b && b.tags) {
        b.tags.forEach((t) => {
          const clean = t.trim().toLowerCase();
          if (clean) tagMap[clean] = (tagMap[clean] || 0) + 1;
        });
      }
    });

    return Object.entries(tagMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([tag, count]) => ({ tag, count }));
  }, [filteredSessions, books]);

  // Period navigation
  const handlePrevPeriod = () => {
    if (periodType === 'month') {
      if (selectedMonth === 0) {
        setSelectedMonth(11);
        setSelectedYear((y) => y - 1);
      } else {
        setSelectedMonth((m) => m - 1);
      }
    } else {
      setSelectedYear((y) => y - 1);
    }
  };

  const handleNextPeriod = () => {
    if (periodType === 'month') {
      if (selectedMonth === 11) {
        setSelectedMonth(0);
        setSelectedYear((y) => y + 1);
      } else {
        setSelectedMonth((m) => m + 1);
      }
    } else {
      setSelectedYear((y) => y + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-2xl animate-fadeIn">
      <div className="w-full max-w-xl glass-panel rounded-3xl p-5 sm:p-7 border border-white/15 shadow-2xl flex flex-col justify-between max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-white" />
            <h2 className="text-base sm:text-lg font-bold text-white font-['Syne']">
              Resumen de Lectura
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Period Selector Tabs: Mes / Año */}
        <div className="py-4 space-y-4 text-xs">
          <div className="flex items-center justify-between bg-white/[0.04] p-1 rounded-2xl border border-white/10">
            <button
              onClick={() => setPeriodType('month')}
              className={`flex-1 py-1.5 rounded-xl font-bold transition-all text-xs ${
                periodType === 'month'
                  ? 'bg-white/20 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Resumen del Mes
            </button>
            <button
              onClick={() => setPeriodType('year')}
              className={`flex-1 py-1.5 rounded-xl font-bold transition-all text-xs ${
                periodType === 'year'
                  ? 'bg-white/20 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Resumen del Año
            </button>
          </div>

          {/* Navigator for Month / Year */}
          <div className="flex items-center justify-between px-2">
            <button
              onClick={handlePrevPeriod}
              className="p-1.5 rounded-xl bg-white/[0.05] hover:bg-white/15 text-zinc-300 hover:text-white transition-all"
              title="Período anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="text-center">
              <span className="text-sm font-bold text-white font-['Syne'] block">
                {periodType === 'month'
                  ? `${MONTH_NAMES[selectedMonth]} ${selectedYear}`
                  : `Año ${selectedYear}`}
              </span>
              <span className="text-[10px] text-zinc-400">
                {filteredSessions.length} {filteredSessions.length === 1 ? 'sesión' : 'sesiones'} registradas
              </span>
            </div>

            <button
              onClick={handleNextPeriod}
              className="p-1.5 rounded-xl bg-white/[0.05] hover:bg-white/15 text-zinc-300 hover:text-white transition-all"
              title="Período siguiente"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Staggered progressive cards display */}
          <div className="space-y-3 pt-1">
            {/* Primary KPI Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {/* Libros terminados */}
              <div
                className="glass-panel-subtle rounded-2xl p-3 border border-white/[0.08] space-y-1 animate-fadeIn"
                style={{ animationDelay: '50ms' }}
              >
                <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
                  Terminados
                </span>
                <span className="text-lg font-bold text-white font-mono tabular-nums block">
                  {completedBooksInPeriod.length}
                </span>
                <span className="text-[10px] text-zinc-500">libros en el período</span>
              </div>

              {/* Páginas leídas */}
              <div
                className="glass-panel-subtle rounded-2xl p-3 border border-white/[0.08] space-y-1 animate-fadeIn"
                style={{ animationDelay: '100ms' }}
              >
                <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
                  Páginas
                </span>
                <span className="text-lg font-bold text-white font-mono tabular-nums block">
                  {totalPagesRead.toLocaleString()}
                </span>
                <span className="text-[10px] text-zinc-500">leídas en total</span>
              </div>

              {/* Tiempo de lectura */}
              <div
                className="glass-panel-subtle rounded-2xl p-3 border border-white/[0.08] space-y-1 animate-fadeIn"
                style={{ animationDelay: '150ms' }}
              >
                <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
                  Tiempo
                </span>
                <span className="text-lg font-bold text-white font-mono tabular-nums truncate block">
                  {formattedTime}
                </span>
                <span className="text-[10px] text-zinc-500">dedicado a leer</span>
              </div>

              {/* Días de lectura */}
              <div
                className="glass-panel-subtle rounded-2xl p-3 border border-white/[0.08] space-y-1 animate-fadeIn"
                style={{ animationDelay: '200ms' }}
              >
                <span className="text-[10px] text-zinc-400 uppercase font-semibold block truncate">
                  Días activos
                </span>
                <span className="text-lg font-bold text-white font-mono tabular-nums block">
                  {activeReadingDays}
                </span>
                <span className="text-[10px] text-zinc-500">días con lectura</span>
              </div>
            </div>

            {/* Secondary KPIs: Racha y Promedio */}
            <div className="grid grid-cols-2 gap-2.5">
              <div
                className="glass-panel-subtle rounded-2xl p-3 border border-white/[0.08] flex items-center gap-3 animate-fadeIn"
                style={{ animationDelay: '250ms' }}
              >
                <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-white shrink-0">
                  <Flame className="w-4 h-4 fill-white text-white" />
                </div>
                <div>
                  <span className="text-[10px] text-zinc-400 uppercase font-semibold block">
                    Racha en el período
                  </span>
                  <span className="text-sm font-bold text-white font-mono">
                    {periodStreak} {periodStreak === 1 ? 'día' : 'días continuos'}
                  </span>
                </div>
              </div>

              <div
                className="glass-panel-subtle rounded-2xl p-3 border border-white/[0.08] flex items-center gap-3 animate-fadeIn"
                style={{ animationDelay: '300ms' }}
              >
                <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-white shrink-0">
                  <TrendingUp className="w-4 h-4 text-white" />
                </div>
                <div>
                  <span className="text-[10px] text-zinc-400 uppercase font-semibold block">
                    Promedio de lectura
                  </span>
                  <span className="text-sm font-bold text-white font-mono">
                    {dailyAveragePages} págs/día activo
                  </span>
                </div>
              </div>
            </div>

            {/* Creative Highlights: Libro más leído & Autor más leído */}
            <div
              className="glass-panel rounded-2xl p-4 border border-white/[0.08] space-y-3 animate-fadeIn"
              style={{ animationDelay: '350ms' }}
            >
              <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider block">
                Destacados del período
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* Libro más leído */}
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] space-y-1">
                  <div className="flex items-center gap-1.5 text-zinc-400">
                    <BookOpen className="w-3.5 h-3.5 text-zinc-300" />
                    <span className="text-[11px] font-medium">Libro más leído</span>
                  </div>
                  <p className="font-bold text-white truncate text-sm">
                    {mostReadBook ? mostReadBook.book.title : 'Sin lecturas registradas'}
                  </p>
                  {mostReadBook && (
                    <p className="text-[10px] text-zinc-400 truncate">
                      {mostReadBook.book.author} {mostReadBook.pages > 0 && `(aprox. ${mostReadBook.pages} págs)`}
                    </p>
                  )}
                </div>

                {/* Autor más leído */}
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] space-y-1">
                  <div className="flex items-center gap-1.5 text-zinc-400">
                    <Award className="w-3.5 h-3.5 text-zinc-300" />
                    <span className="text-[11px] font-medium">Autor más leído</span>
                  </div>
                  <p className="font-bold text-white truncate text-sm">{mostReadAuthor}</p>
                  <p className="text-[10px] text-zinc-400">Tu autor de preferencia en estas fechas</p>
                </div>

                {/* Género más leído */}
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] space-y-1">
                  <span className="text-[11px] text-zinc-400 block font-medium">Género principal</span>
                  <p className="font-bold text-white truncate text-sm">{mostReadGenre}</p>
                </div>

                {/* Etiquetas más utilizadas en el período */}
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] space-y-1.5">
                  <span className="text-[11px] text-zinc-400 flex items-center gap-1 font-medium">
                    <TagIcon className="w-3 h-3 text-zinc-300" />
                    <span>Etiquetas más utilizadas</span>
                  </span>
                  {mostUsedTags.length === 0 ? (
                    <span className="text-[10px] text-zinc-500 italic block">Sin etiquetas registradas</span>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {mostUsedTags.map((item) => (
                        <span
                          key={item.tag}
                          className="px-2 py-0.5 rounded-lg bg-white/10 text-white text-[10px] font-semibold border border-white/10"
                        >
                          #{item.tag} ({item.count})
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs shadow-lg transition-all"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
