import React, { useState } from 'react';
import {
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  History,
  TrendingUp,
  Edit3,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react';
import type { Player, Category, DailyRecord, Attempt } from '../types/index.ts';

interface AttemptRecorderProps {
  activePlayer: Player;
  categories: Category[];
  selectedCategoryId: string;
  onSelectCategory: (id: string) => void;
  dailyRecords: DailyRecord[];
  todayDateStr: string;
  onSaveAttempt: (count: number) => Promise<boolean>;
  onOpenCorrection: (record: DailyRecord | null) => void;
}

export const AttemptRecorder: React.FC<AttemptRecorderProps> = ({
  activePlayer,
  categories,
  selectedCategoryId,
  onSelectCategory,
  dailyRecords,
  todayDateStr,
  onSaveAttempt,
  onOpenCorrection,
}) => {
  const [currentCount, setCurrentCount] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [lastAttemptSaved, setLastAttemptSaved] = useState<number | null>(null);
  const [recentAttempts, setRecentAttempts] = useState<number[]>([]);

  const selectedCategory = categories.find((c) => c.id === selectedCategoryId) || categories[0];
  const isCategoryDisabled = selectedCategory ? selectedCategory.status !== 'active' : true;

  // Find today's official record for this player & category
  const recordId = `${activePlayer.id}_${selectedCategoryId}_${todayDateStr}`;
  const todayRecord = dailyRecords.find((r) => r.id === recordId);
  const currentBest = todayRecord ? todayRecord.bestStreak : 0;
  const hasTrainedToday = todayRecord ? todayRecord.trained : false;

  const handleIncrement = () => {
    if (isCategoryDisabled) return;
    try {
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(20);
      }
    } catch {
      // ignore
    }
    setCurrentCount((prev) => prev + 1);
  };

  const handleFinishAttempt = async () => {
    if (isCategoryDisabled) return;
    setIsSubmitting(true);
    const count = currentCount;
    setRecentAttempts((prev) => [count, ...prev.slice(0, 4)]);
    setLastAttemptSaved(count);
    
    await onSaveAttempt(count);
    setCurrentCount(0);
    setIsSubmitting(false);
  };

  const handleLogZeroTraining = async () => {
    if (isCategoryDisabled) return;
    if (window.confirm('Confirmar treino de hoje com 0 acertos válidos? Isso contará na sua média semanal como zero.')) {
      setIsSubmitting(true);
      await onSaveAttempt(0);
      setRecentAttempts((prev) => [0, ...prev.slice(0, 4)]);
      setLastAttemptSaved(0);
      setCurrentCount(0);
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Category selector */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4">
        <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider block mb-2">
          Categoria de Peso da Garrafa
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {categories.map((cat) => {
            const isSelected = cat.id === selectedCategoryId;
            const isArchived = cat.status !== 'active';
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex flex-col p-3 rounded-xl border text-left transition-all relative ${
                  isSelected
                    ? isArchived
                      ? 'bg-amber-950/40 border-amber-500/80 text-amber-200'
                      : 'bg-emerald-950/40 border-emerald-500 text-white shadow-md shadow-emerald-950/50'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700 text-neutral-400'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-sm">{cat.name.split(' ')[0]} {cat.name.split(' ')[1]}</span>
                  {isArchived ? (
                    <span className="text-[10px] font-bold text-amber-400 bg-amber-950/80 px-1.5 py-0.5 rounded border border-amber-800">
                      Arquivada
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800">
                      Ativa
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-neutral-400">
                  {cat.weightGrams} gramas
                </span>
              </button>
            );
          })}
        </div>

        {/* Safety Warning if category is archived/disabled */}
        {isCategoryDisabled && (
          <div className="mt-4 p-3.5 rounded-xl bg-amber-950/30 border border-amber-800/60 flex items-start gap-3 text-amber-300">
            <ShieldAlert className="w-5 h-5 shrink-0 text-amber-400 mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-bold">Categoria Desativada por Proteção de Segurança</p>
              <p className="text-amber-300/80 leading-relaxed">
                {selectedCategory?.safetyNotice ||
                  'Esta categoria está arquivada para evitar arremessos de recipientes pesados que aumentem o risco de lesões físicas ou danos materiais.'}
              </p>
              <p className="text-neutral-400 text-[11px]">
                O botão de iniciar desafio e registro de tentativas está desativado para esta categoria.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Main Counter Card */}
      {!isCategoryDisabled ? (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
          {/* Background sports grid pattern */}
          <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px]" />

          <div className="flex items-center justify-between text-xs text-neutral-400 mb-4 border-b border-neutral-800 pb-3">
            <div>
              <span className="text-neutral-500">Jogador: </span>
              <span className="font-bold text-white">{activePlayer.name}</span>
            </div>
            <div>
              <span className="text-neutral-500">Data local (SP): </span>
              <span className="font-bold text-emerald-400 font-mono-numbers">{todayDateStr}</span>
            </div>
          </div>

          {/* Current Attempt Counter display */}
          <div className="text-center py-6">
            <div className="text-xs uppercase font-extrabold tracking-widest text-emerald-400 mb-1">
              Tentativa Atual em Andamento
            </div>
            <div className="text-8xl sm:text-9xl font-extrabold text-white font-mono-numbers tracking-tighter transition-all transform scale-100 select-none">
              {currentCount}
            </div>
            <div className="text-xs text-neutral-400 mt-2">
              {currentCount === 0
                ? 'Toque no botão grande para cada acerto consecutivo'
                : `${currentCount} ${currentCount === 1 ? 'acerto consecutivo' : 'acertos consecutivos'} nesta tentativa`}
            </div>
          </div>

          {/* Massive Action Buttons for Single-Handed Mobile Operation */}
          <div className="space-y-3 pt-2">
            {/* The BIG +1 Acerto button */}
            <button
              onClick={handleIncrement}
              disabled={isSubmitting}
              className="w-full py-6 sm:py-7 rounded-2xl bg-gradient-to-b from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 active:scale-[0.98] text-neutral-950 font-black text-2xl tracking-wide uppercase shadow-lg shadow-emerald-950/60 transition-all cursor-pointer flex items-center justify-center gap-3 border border-emerald-400/50"
              aria-label="Registrar mais 1 acerto consecutivo"
            >
              <span>+1 ACERTO</span>
            </button>

            {/* End Attempt Button */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={handleFinishAttempt}
                disabled={isSubmitting || currentCount === 0}
                className={`py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                  currentCount > 0
                    ? 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700 active:scale-95'
                    : 'bg-neutral-900 text-neutral-600 border border-neutral-800/80 cursor-not-allowed'
                }`}
                aria-label="Encerrar tentativa atual e salvar"
              >
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>Encerrar Tentativa ({currentCount})</span>
              </button>

              <button
                onClick={() => setCurrentCount(0)}
                disabled={currentCount === 0}
                className={`py-3.5 px-4 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-all ${
                  currentCount > 0
                    ? 'bg-neutral-950 hover:bg-neutral-800 text-neutral-400 border border-neutral-800'
                    : 'opacity-40 cursor-not-allowed text-neutral-600 border border-neutral-800'
                }`}
                aria-label="Zerar tentativa atual"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Resetar Tentativa</span>
              </button>
            </div>
          </div>

          {/* Today's Official Record Card */}
          <div className="mt-6 pt-5 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4 bg-neutral-950/60 p-4 rounded-2xl border border-neutral-800/60">
            <div className="text-center sm:text-left">
              <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                Recorde Oficial do Dia ({todayDateStr})
              </span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-3xl font-extrabold text-white font-mono-numbers">
                  {hasTrainedToday ? currentBest : 'Nenhum'}
                </span>
                <span className="text-xs text-neutral-400">
                  {hasTrainedToday ? 'acertos consecutivos' : 'treino registrado hoje'}
                </span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">
                Apenas a maior sequência do dia entra no cálculo da média (não soma tentativas).
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenCorrection(todayRecord || null)}
                className="px-3 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors border border-neutral-700"
                title="Corrigir registro com auditoria"
                aria-label="Corrigir registro com auditoria"
              >
                <Edit3 className="w-3.5 h-3.5 text-neutral-400" />
                <span>Corrigir</span>
              </button>

              {!hasTrainedToday && (
                <button
                  onClick={handleLogZeroTraining}
                  className="px-3 py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-amber-300 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-neutral-800"
                  title="Registrar treino oficial com 0 acertos"
                  aria-label="Registrar treino oficial com 0 acertos"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                  <span>Treino com 0</span>
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 text-center">
          <ShieldAlert className="w-12 h-12 text-amber-500 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-2">Desafios Bloqueados Nesta Categoria</h3>
          <p className="text-sm text-neutral-400 max-w-md mx-auto">
            Por determinação de segurança do grupo Garrafões, garrafas acima de 500 g não possuem disputas ativas.
            Escolha uma categoria aprovada como 200 g ou 500 g para lançar tentativas.
          </p>
        </div>
      )}

      {/* Transparent Rules Banner */}
      <div className="bg-neutral-900/50 border border-neutral-800/80 rounded-2xl p-4 text-xs text-neutral-400 space-y-2">
        <div className="flex items-center gap-2 font-bold text-neutral-200">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Regras Transparentes de Cálculo:</span>
        </div>
        <ul className="space-y-1.5 pl-5 list-disc text-neutral-400">
          <li>
            <strong className="text-neutral-200">Múltiplas tentativas:</strong> Se você fizer 4, 8 e 6 acertos hoje, seu recorde diário salvo será <strong>8</strong> (não 18).
          </li>
          <li>
            <strong className="text-neutral-200">Dias sem treino:</strong> Se você não treinar ou não registrar, esse dia não entra na média nem como zero.
          </li>
          <li>
            <strong className="text-neutral-200">Treino com 0:</strong> Se você treinar e não acertar nenhuma vez, registrar o treino com 0 acertos conta oficialmente como 0 e reduz a média semanal.
          </li>
          <li>
            <strong className="text-neutral-200">Fuso oficial:</strong> Os dias encerram às 23:59 no horário de São Paulo.
          </li>
        </ul>
      </div>
    </div>
  );
};
