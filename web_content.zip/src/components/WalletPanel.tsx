import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile, WalletTransaction, WithdrawalRequest } from '../types';
import {
  subscribeTransactions,
  requestWithdrawalFn,
  cancelWithdrawalFn,
  walletErrorMessage
} from '../wallet';
import { WITHDRAWAL_RULES } from '../economy';

const TYPE_LABEL: Record<string, string> = {
  topup: 'شحن رصيد',
  daily_bonus: 'مكافأة يومية',
  gift_sent: 'هدية مرسلة',
  gift_purchase: 'شراء هدية',
  gift_received: 'هدية مستلمة (أرباح)',
  withdrawal_hold: 'حجز مبلغ للسحب',
  withdrawal_refund: 'استرجاع مبلغ السحب',
  withdrawal_paid: 'تم تحويل السحب'
};
const CURRENCY_LABEL: Record<string, string> = { coins: 'عملة', flowers: 'زهرة', earnings: 'من الأرباح' };
const STATUS: Record<string, { label: string; cls: string }> = {
  pending: { label: '⏳ قيد المراجعة', cls: 'bg-amber-100 text-amber-700 border-amber-200' },
  approved: { label: '✓ تمت الموافقة، بانتظار التحويل', cls: 'bg-sky-100 text-sky-700 border-sky-200' },
  paid: { label: '✓ تم التحويل', cls: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  rejected: { label: '✕ مرفوض', cls: 'bg-red-100 text-red-700 border-red-200' },
  cancelled: { label: 'ملغي', cls: 'bg-slate-100 text-slate-600 border-slate-200' }
};

const fmtDate = (iso: string) => {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? '' : d.toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });
};

interface Props {
  currentUser: UserProfile;
  showToast: (m: string) => void;
}

export const WalletPanel: React.FC<Props> = ({ currentUser, showToast }) => {
  const [txs, setTxs] = useState<WalletTransaction[]>([]);
  const [txError, setTxError] = useState(false);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [amount, setAmount] = useState('');
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const unsub = subscribeTransactions(currentUser.uid, (l) => { setTxs(l); setTxError(false); }, () => setTxError(true));
    return () => unsub();
  }, [currentUser.uid]);

  useEffect(() => {
    const q = query(collection(db, 'withdrawals'), where('userId', '==', currentUser.uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
        list.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        setWithdrawals(list);
      },
      (e) => console.error('Withdrawals listener error:', e)
    );
    return () => unsub();
  }, [currentUser.uid]);

  const earnings = currentUser.earnings || 0;
  const amountNum = parseInt(amount, 10) || 0;
  const ageDays = (Date.now() - Date.parse(currentUser.createdAt || '')) / 86400000;
  const open = withdrawals.some((w) => w.status === 'pending' || w.status === 'approved');
  const checks = [
    { ok: earnings >= WITHDRAWAL_RULES.MIN_EARNINGS, text: `رصيد الأرباح ${WITHDRAWAL_RULES.MIN_EARNINGS.toLocaleString('en-US')} على الأقل` },
    { ok: isFinite(ageDays) && ageDays >= WITHDRAWAL_RULES.MIN_ACCOUNT_AGE_DAYS, text: `مرور ${WITHDRAWAL_RULES.MIN_ACCOUNT_AGE_DAYS} أيام على إنشاء الحساب` },
    { ok: !open, text: 'لا يوجد طلب سحب قيد المعالجة' }
  ];

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const res = await requestWithdrawalFn(amountNum, phone.trim());
      showToast(`تم إرسال طلب سحب ${res.amountEGP} ج.م وهو الآن قيد المراجعة`);
      setAmount('');
    } catch (err) {
      showToast(walletErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const cancel = async (id: string) => {
    try {
      await cancelWithdrawalFn(id);
      showToast('تم إلغاء الطلب وإرجاع المبلغ لرصيد أرباحك');
    } catch (err) {
      showToast(walletErrorMessage(err));
    }
  };

  return (
    <div dir="rtl" className="mt-4 pt-4 border-t border-slate-100 space-y-4">
      {/* Earnings + withdrawal */}
      <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-200">
        <div className="flex items-baseline justify-between mb-2">
          <span className="text-xs font-bold text-slate-800">أرباحك من الهدايا</span>
          <span className="text-lg font-black text-emerald-700">
            {earnings.toLocaleString('en-US')}
            <span className="text-[10px] font-bold text-slate-500 mr-1">
              ≈ {(earnings * WITHDRAWAL_RULES.EGP_PER_EARNING).toFixed(2)} ج.م
            </span>
          </span>
        </div>
        <ul className="space-y-1 mb-3">
          {checks.map((c) => (
            <li key={c.text} className={`text-[11px] flex items-center gap-1.5 ${c.ok ? 'text-emerald-700' : 'text-slate-500'}`}>
              <span>{c.ok ? '✓' : '○'}</span>
              <span>{c.text}</span>
            </li>
          ))}
        </ul>
        <form onSubmit={submit} className="space-y-2">
          <input
            type="number"
            inputMode="numeric"
            min={WITHDRAWAL_RULES.MIN_EARNINGS}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="مبلغ السحب من الأرباح"
            className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800"
            required
          />
          {amountNum > 0 && (
            <p className="text-[11px] text-slate-500">
              ستستلم تقريباً {(amountNum * WITHDRAWAL_RULES.EGP_PER_EARNING).toFixed(2)} ج.م على فودافون كاش
            </p>
          )}
          <input
            type="tel"
            inputMode="numeric"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="رقم فودافون كاش (01xxxxxxxxx)"
            className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800"
            required
          />
          <button
            type="submit"
            disabled={busy}
            className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold cursor-pointer"
          >
            {busy ? 'جاري الإرسال...' : 'طلب سحب'}
          </button>
          <p className="text-[10px] text-slate-500 text-center">
            يُحجز المبلغ من أرباحك فور الطلب، ويراجعه المالك قبل التحويل. السيرفر هو من يتحقق من الشروط.
          </p>
        </form>
      </div>

      {/* My withdrawals */}
      {withdrawals.length > 0 && (
        <div>
          <span className="block text-[11px] font-bold text-slate-700 mb-2">طلبات السحب الخاصة بك</span>
          <div className="space-y-1.5">
            {withdrawals.map((w) => {
              const st = STATUS[w.status] || STATUS.pending;
              return (
                <div key={w.id} className="p-2.5 rounded-xl bg-white border border-slate-200 text-[11px]">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-slate-800">
                      {w.amountEarnings.toLocaleString('en-US')} ← {w.amountEGP} ج.م
                    </span>
                    <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold ${st.cls}`}>{st.label}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">{fmtDate(w.createdAt)} · {w.phone}</div>
                  {w.status === 'rejected' && w.adminNote && (
                    <div className="text-[10px] text-red-600 mt-1">سبب الرفض: {w.adminNote}</div>
                  )}
                  {w.status === 'pending' && (
                    <button onClick={() => cancel(w.id)} className="mt-1.5 text-[10px] font-bold text-slate-600 underline cursor-pointer">
                      إلغاء الطلب
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Transaction history */}
      <div>
        <span className="block text-[11px] font-bold text-slate-700 mb-2">سجل المعاملات</span>
        {txError ? (
          <p className="text-[11px] text-red-600">تعذر تحميل السجل.</p>
        ) : txs.length === 0 ? (
          <p className="text-[11px] text-slate-500">لا توجد معاملات بعد.</p>
        ) : (
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {txs.map((t) => (
              <div key={t.id} className="p-2 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-[11px]">
                <div>
                  <span className="font-bold text-slate-800 block">{TYPE_LABEL[t.type] || t.type}</span>
                  <span className="text-[10px] text-slate-500">{t.note ? `${t.note} · ` : ''}{fmtDate(t.createdAt)}</span>
                </div>
                <div className="text-left shrink-0">
                  <span className={`font-black block ${t.amount > 0 ? 'text-emerald-600' : t.amount < 0 ? 'text-rose-600' : 'text-slate-500'}`} dir="ltr">
                    {t.amount > 0 ? '+' : ''}{t.amount.toLocaleString('en-US')} {CURRENCY_LABEL[t.currency] || ''}
                  </span>
                  {t.balanceAfter !== null && t.balanceAfter !== undefined && (
                    <span className="text-[10px] text-slate-500">الرصيد بعدها: {t.balanceAfter.toLocaleString('en-US')}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
