import React, { useState } from 'react';
import { 
  CheckSquare, 
  Clock, 
  Search, 
  CheckCircle2, 
  ListTodo, 
  Play, 
  Check, 
  ExternalLink,
  Crown,
  Tv,
  Smartphone,
  Share2,
  Gift,
  Flame,
  MessageSquareHeart,
  Coins,
  Download,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Task } from '../../types';
import { YouTubeWatchSection } from '../youtube/YouTubeWatchSection';
import { AppTasksSection } from '../apps/AppTasksSection';
import { SocialTasksSection } from '../social/SocialTasksSection';
import { DailyStreakModal } from '../streak/DailyStreakModal';
import { VisitLinkRandomModal } from '../links/VisitLinkRandomModal';
import { MegaAppInstallOfferwall } from '../apps/MegaAppInstallOfferwall';
import { AppFeedbackModal } from '../feedback/AppFeedbackModal';
import { AppDownloadSection } from './AppDownloadSection';
import { YouTubeWatchTasksView } from './YouTubeWatchTasksView';
import { GameTasksSection } from './GameTasksSection';
import { TasksSkeleton } from '../common/SkeletonLoader';
import { MegaSurveyHubView } from '../surveys/MegaSurveyHubView';
import { MegaLinkVisitWatchView } from '../links/MegaLinkVisitWatchView';
import { VideoAdsEarningView } from '../ads/VideoAdsEarningView';
import { Mega200kAppInstallUsedView } from '../apps/Mega200kAppInstallUsedView';
import { GoogleMapReviewTasksView } from './GoogleMapReviewTasksView';
import { TaskDetailsModal } from './TaskDetailsModal';
import { MapPin, Globe, ClipboardList, Info } from 'lucide-react';

interface TasksViewProps {
  onStartTask: (task: Task) => void;
  onOpenGoogleTasks: () => void;
}

export const TasksView: React.FC<TasksViewProps> = ({ onStartTask, onOpenGoogleTasks }) => {
  const { 
    tasks, 
    currentUser, 
    membershipPlans, 
    taskSubmissions, 
    getUserDailyTaskCount,
    language, 
    isDataLoading,
    t 
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('📋 100,000+ Survey');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTaskForDetails, setSelectedTaskForDetails] = useState<Task | null>(null);
  const [isStreakModalOpen, setIsStreakModalOpen] = useState(false);
  const [isRandomLinkModalOpen, setIsRandomLinkModalOpen] = useState(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);

  const currentPlan = currentUser
    ? membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0]
    : membershipPlans[0];

  const tasksDoneToday = getUserDailyTaskCount();
  const dailyLimit = currentPlan.dailyTaskLimit;

  const categories = [
    'All Tasks',
    '📋 100,000+ Survey',
    '🔗 Link (5-Min Watch)',
    '🎬 40-Min Ads (29 Coins)',
    '📱 200,000+ Install & Used',
    '📍 Google Map (30 Coins)',
    '📘 Facebook (10 Coins)',
    'Social Media',
    'Data Entry',
    'Mobile Games',
    '📱 App Download',
    '▶️ YouTube Watch',
    'VIP Tasks'
  ];

  const getTaskStatus = (taskId: string, taskDailyLimit: number) => {
    if (!currentUser) return { isCompleted: false, count: 0 };
    const today = new Date().toISOString().split('T')[0];
    const userSubs = taskSubmissions.filter(
      s => s.userId === currentUser.id && s.taskId === taskId && s.completedAt.startsWith(today)
    );
    return {
      isCompleted: userSubs.length >= taskDailyLimit,
      count: userSubs.length,
    };
  };

  const filteredTasks = tasks.filter((task) => {
    if (!task.isActive) return false;
    
    // Category mapping
    let matchesCategory = true;
    const catLower = task.category.toLowerCase();
    const titleLower = task.title.toLowerCase();
    const descLower = task.description.toLowerCase();

    if (selectedCategory === '📘 Facebook (10 Coins)') {
      matchesCategory = catLower.includes('facebook') || titleLower.includes('facebook');
    } else if (selectedCategory === 'Social Media') {
      matchesCategory = catLower.includes('review') || catLower.includes('quiz') || catLower.includes('social') || titleLower.includes('social') || titleLower.includes('telegram') || titleLower.includes('youtube') || titleLower.includes('whatsapp') || titleLower.includes('facebook') || descLower.includes('social');
    } else if (selectedCategory === 'Data Entry') {
      matchesCategory = catLower.includes('data') || catLower.includes('typing') || titleLower.includes('data') || titleLower.includes('entry') || titleLower.includes('form') || descLower.includes('data entry');
    } else if (selectedCategory === 'Survey') {
      matchesCategory = catLower.includes('survey') || titleLower.includes('survey') || descLower.includes('survey') || titleLower.includes('feedback');
    } else if (selectedCategory === 'Mobile Games') {
      matchesCategory = catLower.includes('game') || catLower.includes('video_demo') || titleLower.includes('game') || titleLower.includes('play') || descLower.includes('game');
    } else if (selectedCategory === 'VIP Tasks') {
      matchesCategory = catLower.includes('vip');
    } else if (selectedCategory === '📱 App Download') {
      matchesCategory = catLower.includes('external_partner') || catLower.includes('google_tasks') || titleLower.includes('app') || titleLower.includes('install');
    } else if (selectedCategory === '▶️ YouTube Watch') {
      matchesCategory = catLower.includes('video_demo') || titleLower.includes('youtube') || titleLower.includes('watch');
    } else if (selectedCategory === 'All Tasks') {
      matchesCategory = true;
    }

    const title = language === 'bn' && task.titleBn ? task.titleBn : task.title;
    const desc = language === 'bn' && task.descriptionBn ? task.descriptionBn : task.description;
    const matchesSearch = title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          desc.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  if (isDataLoading) {
    return <TasksSkeleton />;
  }

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-24 animate-in fade-in duration-200">
      
      {/* Top Header Card */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-black text-white flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-emerald-400" />
            <span>Tasks & Rewards</span>
          </h1>
          <p className="text-xs text-slate-400">
            Complete short daily assignments to earn instant coins
          </p>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => setSelectedCategory('📋 100,000+ Survey')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedCategory === '📋 100,000+ Survey'
                ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-indigo-400 shadow-md'
                : 'bg-indigo-500/20 hover:bg-indigo-500/30 border-indigo-500/40 text-indigo-300'
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>100k+ Survey</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedCategory('🔗 Link (5-Min Watch)')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedCategory === '🔗 Link (5-Min Watch)'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 border-emerald-400 shadow-md'
                : 'bg-emerald-500/20 hover:bg-emerald-500/30 border-emerald-500/40 text-emerald-300'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>5-Min Link Watch</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedCategory('🎬 40-Min Ads (29 Coins)')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedCategory === '🎬 40-Min Ads (29 Coins)'
                ? 'bg-gradient-to-r from-rose-500 to-red-500 text-white border-rose-400 shadow-md'
                : 'bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/40 text-rose-300'
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            <span>40m Ads (29 Coins)</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedCategory('📱 200,000+ Install & Used')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedCategory === '📱 200,000+ Install & Used'
                ? 'bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-950 border-teal-400 shadow-md'
                : 'bg-teal-500/20 hover:bg-teal-500/30 border-teal-500/40 text-teal-300'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>200,000+ Install & Used</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedCategory('📍 Google Map (30 Coins)')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedCategory === '📍 Google Map (30 Coins)'
                ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white border-blue-400 shadow-md'
                : 'bg-blue-500/20 hover:bg-blue-500/30 border-blue-500/40 text-blue-300'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Map Review (30 Coins)</span>
          </button>

          <button
            type="button"
            onClick={() => setIsStreakModalOpen(true)}
            className="px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer bg-amber-500/20 hover:bg-amber-500/30 border-amber-500/40 text-amber-300"
          >
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-current" />
            <span>7-Day Streak</span>
          </button>

          <button
            type="button"
            onClick={() => setIsRandomLinkModalOpen(true)}
            className="px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer bg-orange-500/20 hover:bg-orange-500/30 border-orange-500/40 text-orange-300"
          >
            <Gift className="w-3.5 h-3.5 text-orange-400" />
            <span>Random Link (+Coins)</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedCategory('Social Media')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedCategory === 'Social Media'
                ? 'bg-sky-600 text-white border-sky-500 shadow-md shadow-sky-600/20'
                : 'bg-sky-600/20 hover:bg-sky-600/30 border-sky-500/40 text-sky-300'
            }`}
          >
            <Share2 className="w-3.5 h-3.5 text-sky-400" />
            <span>Social</span>
          </button>

          <button
            type="button"
            onClick={onOpenGoogleTasks}
            className="px-3 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <ListTodo className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Google Tasks</span>
          </button>
        </div>
      </div>

      {/* Daily Progress Mini Banner */}
      <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-800/80 flex items-center justify-between text-xs">
        <span className="text-slate-400 font-medium">Daily Limit Progress</span>
        <div className="flex items-center gap-2">
          <div className="w-24 h-1.5 rounded-full bg-slate-800 overflow-hidden">
            <div 
              className="h-full bg-emerald-500 rounded-full"
              style={{ width: `${Math.min(100, (tasksDoneToday / dailyLimit) * 100)}%` }}
            />
          </div>
          <span className="font-bold text-slate-200">{tasksDoneToday}/{dailyLimit} Done</span>
        </div>
      </div>

      {/* Horizontal Category Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap font-bold transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-xs'
                : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Categorized Earning Views */}
      {selectedCategory === '📋 100,000+ Survey' ? (
        <div className="pt-1 animate-in fade-in duration-200">
          <MegaSurveyHubView />
        </div>
      ) : selectedCategory === '🔗 Link (5-Min Watch)' ? (
        <div className="pt-1 animate-in fade-in duration-200">
          <MegaLinkVisitWatchView />
        </div>
      ) : selectedCategory === '🎬 40-Min Ads (29 Coins)' ? (
        <div className="pt-1 animate-in fade-in duration-200">
          <VideoAdsEarningView />
        </div>
      ) : selectedCategory === '📱 200,000+ Install & Used' ? (
        <div className="pt-1 animate-in fade-in duration-200">
          <Mega200kAppInstallUsedView />
        </div>
      ) : selectedCategory === '📍 Google Map (30 Coins)' ? (
        <div className="pt-1 animate-in fade-in duration-200">
          <GoogleMapReviewTasksView />
        </div>
      ) : selectedCategory === '📱 App Download' ? (
        <div className="pt-1 animate-in fade-in duration-200">
          <AppDownloadSection />
        </div>
      ) : selectedCategory === '▶️ YouTube Watch' ? (
        <div className="pt-1 animate-in fade-in duration-200">
          <YouTubeWatchTasksView />
        </div>
      ) : (
        <>
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search available tasks..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900/70 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Tasks List */}
          <div className="space-y-2.5">
            {filteredTasks.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs rounded-2xl bg-slate-900/40 border border-slate-800">
                No tasks found matching your filter.
              </div>
            ) : (
              filteredTasks.map((task) => {
                const status = getTaskStatus(task.id, task.dailyLimit);
                const title = language === 'bn' && task.titleBn ? task.titleBn : task.title;

                return (
                  <div
                    key={task.id}
                    onClick={() => setSelectedTaskForDetails(task)}
                    className="p-4 rounded-2xl bg-slate-900/70 hover:bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 transition-all flex items-center justify-between gap-3 shadow-xs cursor-pointer group"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                          {task.category.replace('_', ' ')}
                        </span>
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-500" />
                          <span>{task.estimatedMinutes} min</span>
                        </span>
                        {status.isCompleted ? (
                          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                            Completed
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md">
                            Available
                          </span>
                        )}
                      </div>

                      <h3 className="text-sm font-bold text-slate-100 group-hover:text-emerald-300 transition-colors truncate">
                        {title}
                      </h3>
                      <p className="text-[11px] text-slate-400 truncate line-clamp-1">
                        {language === 'bn' && task.descriptionBn ? task.descriptionBn : task.description}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                      <div className="text-right">
                        <span className="text-xs font-black text-amber-400 block font-mono">
                          +{task.rewardCoins} Coins
                        </span>
                        {task.rewardRupees && (
                          <span className="text-[10px] text-emerald-400 font-semibold block font-mono">
                            ₹{task.rewardRupees}
                          </span>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedTaskForDetails(task);
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
                        title="View Full Instructions & Reward Details"
                      >
                        <Info className="w-3.5 h-3.5 text-indigo-400" />
                        <span className="hidden sm:inline">Details</span>
                      </button>

                      {status.isCompleted ? (
                        <button
                          disabled
                          className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-500 text-xs font-bold flex items-center gap-1 cursor-default"
                        >
                          <Check className="w-3 h-3" />
                          <span>Done</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onStartTask(task);
                          }}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-xs active:scale-95 transition-all cursor-pointer flex items-center gap-1"
                        >
                          <span>Start</span>
                          <Play className="w-3 h-3 fill-current" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      )}

      {/* Task Details & Full Instructions Modal */}
      <TaskDetailsModal
        task={selectedTaskForDetails}
        isOpen={!!selectedTaskForDetails}
        onClose={() => setSelectedTaskForDetails(null)}
        onStartTask={(t) => {
          setSelectedTaskForDetails(null);
          onStartTask(t);
        }}
      />

      {/* 7-Day Daily Streak Modal */}
      <DailyStreakModal
        isOpen={isStreakModalOpen}
        onClose={() => setIsStreakModalOpen(false)}
      />

      {/* Visit Link & Earn Random Coins Modal */}
      <VisitLinkRandomModal
        isOpen={isRandomLinkModalOpen}
        onClose={() => setIsRandomLinkModalOpen(false)}
      />

      {/* App Feedback & Feature Survey Modal */}
      <AppFeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={() => setIsFeedbackModalOpen(false)}
      />

    </div>
  );
};
