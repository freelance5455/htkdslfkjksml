import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Download, 
  CheckCircle2, 
  Coins, 
  Sparkles, 
  AlertCircle, 
  ExternalLink,
  Smartphone,
  RefreshCw,
  FileCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { AppOffer } from '../../services/appOffersLibrary';

interface AppDownloadVerificationModalProps {
  offer: AppOffer | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (offerId: string) => void;
}

export const AppDownloadVerificationModal: React.FC<AppDownloadVerificationModalProps> = ({
  offer,
  isOpen,
  onClose,
  onSuccess
}) => {
  const { currentUser, submitTaskCompletion, adjustUserCoins, language } = useApp();

  const [verificationMethod, setVerificationMethod] = useState<'attribution' | 'screenshot'>('attribution');
  const [proofText, setProofText] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<'idle' | 'success' | 'failed'>('idle');
  const [statusMessage, setStatusMessage] = useState('');

  if (!isOpen || !offer) return null;

  const handleVerifyAttribution = async () => {
    if (!currentUser) return;
    setIsVerifying(true);
    setStatusMessage('Querying attribution postback service & validating device identifier...');

    // Simulate legitimate attribution check (1.8s)
    setTimeout(() => {
      setIsVerifying(false);
      
      // Submit completion securely
      const res = submitTaskCompletion(
        offer.id, 
        `App Install Verification: ${offer.name} (${offer.packageName}) | Attribution Token: ${offer.attributionToken}`
      );

      if (res.success) {
        setVerificationResult('success');
        setStatusMessage(
          language === 'bn'
            ? `সফলভাবে যাচাই সম্পন্ন! ২০০ কয়েন আপনার অ্যাকাউন্টে যোগ হয়েছে।`
            : `Attribution verified successfully! 200 Coins have been credited to your wallet.`
        );
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.65 }
        });
        onSuccess(offer.id);
      } else {
        // If daily limit or already submitted, show error
        setVerificationResult('failed');
        setStatusMessage(res.message);
      }
    }, 1800);
  };

  const handleManualProofSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !proofText.trim()) return;

    setIsVerifying(true);
    setStatusMessage('Validating install proof submission...');

    setTimeout(() => {
      setIsVerifying(false);
      const res = submitTaskCompletion(
        offer.id,
        `Manual Install Proof: ${offer.name} | Details: ${proofText.trim()} | Token: ${offer.attributionToken}`
      );

      if (res.success) {
        setVerificationResult('success');
        setStatusMessage(`Verification accepted! 200 Coins have been awarded.`);
        confetti({
          particleCount: 90,
          spread: 65,
          origin: { y: 0.6 }
        });
        onSuccess(offer.id);
      } else {
        setVerificationResult('failed');
        setStatusMessage(res.message);
      }
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3.5 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4 text-slate-100"
        role="dialog"
      >
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img 
              src={offer.iconUrl} 
              alt={offer.name} 
              className="w-12 h-12 rounded-2xl object-cover border border-emerald-500/30 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  📱 App Verification
                </span>
                <span className="text-[11px] font-black text-amber-400 flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5" /> +200 Coins
                </span>
              </div>
              <h2 className="text-base font-black text-white truncate max-w-[220px]">
                {offer.name}
              </h2>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Verification Status Banner */}
        {verificationResult === 'success' ? (
          <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 space-y-2 text-center animate-in zoom-in-95 duration-200">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <div className="text-sm font-black text-white">Installation Verified!</div>
            <p className="text-xs leading-relaxed">{statusMessage}</p>
            <button
              onClick={onClose}
              className="w-full mt-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs transition-all cursor-pointer"
            >
              Done & Return to Tasks
            </button>
          </div>
        ) : (
          <>
            {/* Offer details & Anti-fraud badge */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span>Developer:</span>
                <span className="text-slate-200 font-semibold">{offer.developer}</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Package ID:</span>
                <span className="font-mono text-[11px] text-sky-400">{offer.packageName}</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Attribution Token:</span>
                <span className="font-mono text-[10px] text-emerald-400">{offer.attributionToken}</span>
              </div>
              <div className="pt-2 border-t border-slate-800/60 flex items-center gap-1.5 text-[11px] text-emerald-400">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>Legitimate install tracking enabled (no duplicate rewards).</span>
              </div>
            </div>

            {/* Verification Method Tabs */}
            <div className="flex gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800">
              <button
                type="button"
                onClick={() => setVerificationMethod('attribution')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  verificationMethod === 'attribution'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Auto Postback Check
              </button>
              <button
                type="button"
                onClick={() => setVerificationMethod('screenshot')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  verificationMethod === 'screenshot'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Submit Account / ID Proof
              </button>
            </div>

            {verificationMethod === 'attribution' ? (
              <div className="space-y-3">
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 space-y-1.5">
                  <div className="font-bold text-slate-100 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>How Automatic Verification Works:</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px]">
                    <li>You opened the official Play Store link and installed the app.</li>
                    <li>You launched the app for at least 1 minute on this device.</li>
                    <li>Click below to query the attribution server for confirmation.</li>
                  </ol>
                </div>

                {statusMessage && verificationResult === 'failed' && (
                  <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{statusMessage}</span>
                  </div>
                )}

                <button
                  type="button"
                  disabled={isVerifying}
                  onClick={handleVerifyAttribution}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 active:scale-95 transition-all cursor-pointer"
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying Postback Token...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Verify & Claim 200 Coins</span>
                    </>
                  )}
                </button>
              </div>
            ) : (
              <form onSubmit={handleManualProofSubmit} className="space-y-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">
                    Google Play Order ID, Account Nickname or Install Notes:
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={proofText}
                    onChange={(e) => setProofText(e.target.value)}
                    placeholder="e.g., Installed on Samsung Galaxy, registered with my email..."
                    className="w-full p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 resize-none"
                  />
                </div>

                {statusMessage && verificationResult === 'failed' && (
                  <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{statusMessage}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isVerifying || !proofText.trim()}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 active:scale-95 transition-all cursor-pointer"
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Submitting Proof...</span>
                    </>
                  ) : (
                    <>
                      <FileCheck className="w-4 h-4" />
                      <span>Submit Proof for 200 Coins</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
};
