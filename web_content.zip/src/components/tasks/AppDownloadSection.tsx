import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Download, 
  Coins, 
  Star, 
  CheckCircle2, 
  Sparkles, 
  Search, 
  Filter, 
  RefreshCw, 
  ExternalLink,
  ShieldCheck,
  Check,
  Clock,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { 
  getAppOffers, 
  AppOffer, 
  APP_OFFER_CATEGORIES, 
  TOTAL_APP_OFFERS_COUNT 
} from '../../services/appOffersLibrary';
import { AppDownloadVerificationModal } from './AppDownloadVerificationModal';

export const AppDownloadSection: React.FC = () => {
  const { currentUser, taskSubmissions } = useApp();

  const [category, setCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [offersList, setOffersList] = useState<AppOffer[]>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [totalCount, setTotalCount] = useState<number>(TOTAL_APP_OFFERS_COUNT);

  // Track installed state (clicked install, pending verification)
  const [installedOfferIds, setInstalledOfferIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_installed_apps_pending');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Track completed offers
  const [completedOfferIds, setCompletedOfferIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_completed_apps');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Verification Modal State
  const [selectedOfferToVerify, setSelectedOfferToVerify] = useState<AppOffer | null>(null);

  // Sync completed offers from user taskSubmissions if available
  useEffect(() => {
    if (currentUser && taskSubmissions.length > 0) {
      const userCompletedTaskIds = taskSubmissions
        .filter(s => s.userId === currentUser.id && s.status === 'completed')
        .map(s => s.taskId);
      
      setCompletedOfferIds(prev => Array.from(new Set([...prev, ...userCompletedTaskIds])));
    }
  }, [currentUser, taskSubmissions]);

  // Load offers on filter change
  useEffect(() => {
    const { offers, total, hasMore: more } = getAppOffers(1, 12, category, searchQuery);
    setOffersList(offers);
    setPage(1);
    setHasMore(more);
    setTotalCount(total);
  }, [category, searchQuery]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    const { offers: newBatch, hasMore: more } = getAppOffers(nextPage, 12, category, searchQuery);
    setOffersList(prev => [...prev, ...newBatch]);
    setPage(nextPage);
    setHasMore(more);
  };

  const handleInstallClick = (offer: AppOffer) => {
    if (completedOfferIds.includes(offer.id)) return;

    // Open official store URL with attribution tracking
    window.open(offer.appStoreUrl, '_blank', 'noopener,noreferrer');

    // Mark as installed/pending verification
    setInstalledOfferIds(prev => {
      const updated = Array.from(new Set([...prev, offer.id]));
      localStorage.setItem('taskearn_installed_apps_pending', JSON.stringify(updated));
      return updated;
    });
  };

  const handleVerifyClick = (offer: AppOffer) => {
    if (completedOfferIds.includes(offer.id)) return;
    setSelectedOfferToVerify(offer);
  };

  const handleVerificationSuccess = (offerId: string) => {
    setCompletedOfferIds(prev => {
      const updated = Array.from(new Set([...prev, offerId]));
      localStorage.setItem('taskearn_completed_apps', JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <div className="space-y-4">
      {/* 10,000+ Header Card */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-900/60 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/30">
                <Smartphone className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-white">
                App Download & Install Tasks
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                10,000+ Offers
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Download verified applications, complete legitimate installation verification, and earn <strong>200 Coins (₹200)</strong> per app!
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/70 border border-emerald-500/30 px-3 py-2 rounded-2xl shrink-0">
            <Coins className="w-4 h-4 text-amber-400" />
            <div className="text-xs">
              <span className="text-slate-400">Fixed Reward: </span>
              <span className="font-black text-emerald-400">200 Coins</span>
            </div>
          </div>
        </div>

        {/* Verification Guarantee */}
        <div className="p-2.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/20 flex items-center gap-2 text-xs text-emerald-300">
          <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>Official Play Store attribution tracking enabled. No reward simply for clicking install; verified installation required.</span>
        </div>
      </div>

      {/* Search & Categories Bar */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search across 10,000+ app offers by name or developer..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {APP_OFFER_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                category === cat
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* App Offers Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {offersList.map((offer) => {
          const isCompleted = completedOfferIds.includes(offer.id);
          const isInstalledPending = installedOfferIds.includes(offer.id) && !isCompleted;

          return (
            <div 
              key={offer.id}
              className={`p-4 rounded-3xl bg-slate-900 border transition-all duration-200 flex flex-col justify-between space-y-3 ${
                isCompleted 
                  ? 'border-emerald-500/40 bg-slate-900/60 opacity-90' 
                  : isInstalledPending
                  ? 'border-amber-500/40 shadow-md shadow-amber-500/10'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-2.5">
                {/* Header: Icon, Name & Status */}
                <div className="flex items-start gap-3">
                  <img
                    src={offer.iconUrl}
                    alt={offer.name}
                    className="w-12 h-12 rounded-2xl object-cover border border-slate-800 shadow-md shrink-0"
                    loading="lazy"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 truncate">
                        {offer.category}
                      </span>
                      {isCompleted ? (
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                          <Check className="w-3 h-3" /> Completed
                        </span>
                      ) : isInstalledPending ? (
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> Ready to Verify
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-800 text-slate-400">
                          {offer.downloadsCount}
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm font-bold text-white truncate" title={offer.name}>
                      {offer.name}
                    </h3>
                    <p className="text-[11px] text-slate-400 truncate">
                      {offer.developer}
                    </p>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {offer.description}
                </p>

                {/* Rating & Size & Reward Tag */}
                <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60">
                  <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                    <span className="flex items-center gap-0.5 text-amber-400 font-bold">
                      <Star className="w-3 h-3 fill-amber-400" /> {offer.rating}
                    </span>
                    <span>•</span>
                    <span>{offer.sizeMb} MB</span>
                  </div>

                  <div className="flex items-center gap-1 font-black text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
                    <Coins className="w-3.5 h-3.5" />
                    <span>+200 Coins</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons: Install & Verify */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                {/* 1. Install Button */}
                <button
                  type="button"
                  disabled={isCompleted}
                  onClick={() => handleInstallClick(offer)}
                  className={`py-2 px-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isCompleted
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : isInstalledPending
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 active:scale-95'
                  }`}
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isInstalledPending ? 'Re-open Store' : 'Install App'}</span>
                </button>

                {/* 2. Verify Button */}
                <button
                  type="button"
                  disabled={isCompleted}
                  onClick={() => handleVerifyClick(offer)}
                  className={`py-2 px-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isCompleted
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 cursor-not-allowed'
                      : isInstalledPending
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-95 text-white shadow-md shadow-amber-500/25 active:scale-95 animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isCompleted ? 'Claimed' : 'Verify'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pagination / Load More Button */}
      {hasMore && (
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={handleLoadMore}
            className="py-3 px-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 text-slate-200 text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer inline-flex items-center gap-2"
          >
            <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
            <span>Load More App Offers ({offersList.length} of {totalCount.toLocaleString()})</span>
          </button>
        </div>
      )}

      {/* Verification Modal */}
      {selectedOfferToVerify && (
        <AppDownloadVerificationModal
          offer={selectedOfferToVerify}
          isOpen={Boolean(selectedOfferToVerify)}
          onClose={() => setSelectedOfferToVerify(null)}
          onSuccess={handleVerificationSuccess}
        />
      )}
    </div>
  );
};
