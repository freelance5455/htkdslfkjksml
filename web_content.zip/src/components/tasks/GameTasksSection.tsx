import React, { useState } from 'react';
import { 
  Gamepad2, 
  Coins, 
  Trophy, 
  Sparkles, 
  CheckCircle2, 
  Play, 
  ShieldCheck, 
  Flame,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CoinCollectorGameModal } from './CoinCollectorGameModal';

export const GameTasksSection: React.FC = () => {
  const { currentUser, taskSubmissions } = useApp();
  const [isCoinCollectorOpen, setIsCoinCollectorOpen] = useState(false);

  // Check if coin collector is completed today
  const today = new Date().toISOString().split('T')[0];
  const isCoinCollectorCompleted = Boolean(
    currentUser && taskSubmissions.some(
      s => s.userId === currentUser.id && 
           s.taskId === 'game-coin-collector' && 
           s.completedAt.startsWith(today) &&
           s.status === 'completed'
    )
  );

  return (
    <div className="space-y-4">
      {/* 18 Coins Game Category Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-900/60 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/30">
                <Gamepad2 className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-white">
                Play Game & Earn Tasks
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                18 Coins / Game
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Play arcade mini-games, reach the required target score legitimately, and submit for verification to earn <strong>18 Coins (₹18)</strong>!
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/70 border border-indigo-500/30 px-3 py-2 rounded-2xl shrink-0">
            <Coins className="w-4 h-4 text-amber-400" />
            <div className="text-xs">
              <span className="text-slate-400">Fixed Reward: </span>
              <span className="font-black text-indigo-400">18 Coins</span>
            </div>
          </div>
        </div>

        <div className="p-2.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/20 flex items-center gap-2 text-xs text-indigo-300">
          <ShieldCheck className="w-4 h-4 shrink-0 text-indigo-400" />
          <span>Anti-cheat verified session active. Coins are rewarded upon achieving the target score legitimately.</span>
        </div>
      </div>

      {/* Game Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {/* 1. Official Coin Collector Game Task */}
        <div className={`p-4 rounded-3xl bg-slate-900 border transition-all flex flex-col justify-between space-y-3 ${
          isCoinCollectorCompleted ? 'border-emerald-500/40 opacity-85' : 'border-slate-800 hover:border-slate-700'
        }`}>
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 flex items-center justify-center font-black text-xl shadow-lg shadow-amber-500/20">
                  🪙
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                      Mini Arcade
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Popular
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white">Coin Collector</h3>
                  <p className="text-[11px] text-slate-400">Target: Collect 30 coins</p>
                </div>
              </div>

              <div className="flex items-center gap-1 font-black text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
                <Coins className="w-3.5 h-3.5" />
                <span>+18 Coins</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Catch falling coins & gems with your basket while avoiding dangerous bombs. Reach 30 coins to submit for verification.
            </p>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Duration: ~45 seconds</span>
              <span className="text-amber-400 font-bold">1 Reward / Day</span>
            </div>
          </div>

          <button
            type="button"
            disabled={isCoinCollectorCompleted}
            onClick={() => setIsCoinCollectorOpen(true)}
            className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              isCoinCollectorCompleted
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 active:scale-95'
            }`}
          >
            {isCoinCollectorCompleted ? (
              <>
                <Check className="w-4 h-4" />
                <span>Completed Today</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Play Coin Collector (18 Coins)</span>
              </>
            )}
          </button>
        </div>

        {/* 2. Speed Quiz Game Task */}
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 transition-all flex flex-col justify-between space-y-3">
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 text-white flex items-center justify-center font-black text-xl shadow-lg shadow-purple-500/20">
                  🎯
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400">
                      Brain Challenge
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white">Daily Rapid Trivia</h3>
                  <p className="text-[11px] text-slate-400">Target: Answer 3 questions correctly</p>
                </div>
              </div>

              <div className="flex items-center gap-1 font-black text-xs text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded-lg border border-purple-500/20">
                <Coins className="w-3.5 h-3.5" />
                <span>+18 Coins</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Test your general knowledge and earn 18 coins by answering 3 rapid trivia questions with zero mistakes.
            </p>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Duration: ~1 minute</span>
              <span className="text-purple-400 font-bold">1 Reward / Day</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsCoinCollectorOpen(true)}
            className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/20 active:scale-95 transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Play Game (18 Coins)</span>
          </button>
        </div>
      </div>

      {/* Modal */}
      {isCoinCollectorOpen && (
        <CoinCollectorGameModal
          isOpen={isCoinCollectorOpen}
          onClose={() => setIsCoinCollectorOpen(false)}
          onSuccess={() => setIsCoinCollectorOpen(false)}
          targetScore={30}
          rewardCoins={18}
        />
      )}
    </div>
  );
};
