import React, { useState } from 'react';
import { 
  MapPin, 
  Star, 
  ExternalLink, 
  Coins, 
  Sparkles, 
  CheckCircle2, 
  Check, 
  Globe, 
  Building2, 
  MessageSquare, 
  X,
  UploadCloud,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { 
  GOOGLE_MAP_PLACES, 
  MAP_REVIEW_SUGGESTIONS, 
  GoogleMapPlace 
} from '../../services/googleMapReviewLibrary';

export const GoogleMapReviewTasksView: React.FC = () => {
  const { currentUser, adjustUserCoins, language } = useApp();

  const [visitedMapPlaces, setVisitedMapPlaces] = useState<Record<string, boolean>>({});
  const [submittedReviewPlaces, setSubmittedReviewPlaces] = useState<Record<string, boolean>>({});
  const [collectedPlaces, setCollectedPlaces] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_google_map_collected_places');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Active review submission modal
  const [activeReviewPlace, setActiveReviewPlace] = useState<GoogleMapPlace | null>(null);
  const [selectedRating, setSelectedRating] = useState<number>(5);
  const [reviewText, setReviewText] = useState<string>(MAP_REVIEW_SUGGESTIONS[0]);
  const [isSubmittingReview, setIsSubmittingReview] = useState<boolean>(false);

  const handleVisitMapWebsite = (place: GoogleMapPlace) => {
    window.open(place.mapWebsiteUrl, '_blank', 'noopener,noreferrer');
    setVisitedMapPlaces(prev => ({ ...prev, [place.id]: true }));
  };

  const handleOpenReviewModal = (place: GoogleMapPlace) => {
    setActiveReviewPlace(place);
    setSelectedRating(5);
    setReviewText(language === 'bn' ? MAP_REVIEW_SUGGESTIONS[3] : MAP_REVIEW_SUGGESTIONS[0]);
  };

  const handleSubmitReview = () => {
    if (!activeReviewPlace) return;
    setIsSubmittingReview(true);
    setTimeout(() => {
      setSubmittedReviewPlaces(prev => ({ ...prev, [activeReviewPlace.id]: true }));
      setIsSubmittingReview(false);
      setActiveReviewPlace(null);
    }, 600);
  };

  const handleCollect30Coins = (place: GoogleMapPlace) => {
    if (!currentUser) return;
    adjustUserCoins(
      currentUser.id,
      30, 
      `Google Map Review Verified (+30 Coins): ${place.name}`
    );
    const updated = [...collectedPlaces, place.id];
    setCollectedPlaces(updated);
    try {
      localStorage.setItem('taskearn_google_map_collected_places', JSON.stringify(updated));
    } catch {
      // ignore
    }

    confetti({
      particleCount: 75,
      spread: 65,
      origin: { y: 0.6 }
    });
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 border border-blue-500/30 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                <MapPin className="w-3 h-3 text-blue-400" />
                Google Maps Verified Places
              </span>
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black flex items-center gap-1">
                <Coins className="w-3 h-3 text-amber-400" />
                30 Coins per Review
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
              <span>{language === 'bn' ? 'গুগল ম্যাপ রিভিউ — প্রতি রিভিউতে ৩০ কয়েন সংগ্রহ' : 'Google Map Review & 30 Coins Collection'}</span>
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'bn'
                ? 'ম্যাপ ওয়েবসাইট ভিজিট করুন, ৫-স্টার রিভিউ দিন এবং তাৎক্ষণিক ৩০ কয়েন সংগ্রহ করুন!'
                : 'Visit map website, write a positive 5-star review, and collect 30 Coins instantly!'}
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 p-2.5 rounded-xl border border-blue-500/20 self-start sm:self-auto">
            <Coins className="w-5 h-5 text-amber-400 animate-bounce" />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-bold">Reward per Place</span>
              <span className="text-sm font-black text-amber-300">30 Coins Collected</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Steps Guide Pill */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
          <span className="w-5 h-5 mx-auto rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-black flex items-center justify-center">1</span>
          <span className="font-bold text-slate-200 block truncate">{language === 'bn' ? 'ম্যাপ ওয়েবসাইট ভিজিট' : 'Visit Map Website'}</span>
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
          <span className="w-5 h-5 mx-auto rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black flex items-center justify-center">2</span>
          <span className="font-bold text-slate-200 block truncate">{language === 'bn' ? '৫-স্টার রিভিউ' : '5-Star Review'}</span>
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-0.5">
          <span className="w-5 h-5 mx-auto rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black flex items-center justify-center">3</span>
          <span className="font-bold text-slate-200 block truncate">{language === 'bn' ? '৩০ কয়েন সংগ্রহ' : 'Collect 30 Coins'}</span>
        </div>
      </div>

      {/* Places Grid */}
      <div className="space-y-3">
        {GOOGLE_MAP_PLACES.map((place) => {
          const isVisited = !!visitedMapPlaces[place.id];
          const isReviewed = !!submittedReviewPlaces[place.id];
          const isCollected = collectedPlaces.includes(place.id);
          const title = language === 'bn' ? place.nameBn : place.name;
          const address = language === 'bn' ? place.addressBn : place.address;

          return (
            <div
              key={place.id}
              className={`p-4 rounded-2xl border transition-all space-y-3 ${
                isCollected
                  ? 'bg-slate-900/40 border-slate-800 opacity-80'
                  : 'bg-slate-900/80 hover:bg-slate-850 border-slate-800 hover:border-blue-500/40 shadow-md'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0">
                  <img
                    src={place.imageUrl}
                    alt={place.name}
                    className="w-14 h-14 rounded-2xl object-cover border border-slate-700 shrink-0 shadow-md"
                  />
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] uppercase font-black px-1.5 py-0.5 rounded-md bg-blue-500/10 text-blue-300 border border-blue-500/20">
                        {place.category}
                      </span>
                      <div className="flex items-center gap-1 text-[11px] text-amber-400 font-bold">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{place.rating} ({place.totalReviews.toLocaleString()}+ reviews)</span>
                      </div>
                    </div>

                    <h3 className="text-sm font-bold text-white truncate">
                      {title}
                    </h3>

                    <p className="text-[11px] text-slate-400 flex items-center gap-1 truncate">
                      <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                      <span className="truncate">{address}</span>
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-sm font-black text-amber-400 block">
                    +30 Coins
                  </span>
                  <span className="text-[10px] text-emerald-400 font-bold block">
                    ₹0.30 INR
                  </span>
                </div>
              </div>

              {/* Action Buttons Row */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2 flex-wrap">
                {/* Step status tags */}
                <div className="flex items-center gap-1.5 text-[11px]">
                  <span className={`px-2 py-0.5 rounded-md border flex items-center gap-1 ${
                    isVisited 
                      ? 'bg-blue-500/20 text-blue-300 border-blue-500/30 font-bold' 
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    {isVisited ? <Check className="w-3 h-3 text-blue-400" /> : <Globe className="w-3 h-3" />}
                    <span>{language === 'bn' ? 'ম্যাপ ভিজিট' : 'Map Visited'}</span>
                  </span>

                  <span className={`px-2 py-0.5 rounded-md border flex items-center gap-1 ${
                    isReviewed 
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30 font-bold' 
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    {isReviewed ? <Check className="w-3 h-3 text-amber-400" /> : <MessageSquare className="w-3 h-3" />}
                    <span>{language === 'bn' ? 'রিভিউ জমা' : 'Reviewed'}</span>
                  </span>
                </div>

                {/* Main Action Buttons */}
                <div className="flex items-center gap-1.5">
                  {/* Step 1: Visit Map Website */}
                  <button
                    onClick={() => handleVisitMapWebsite(place)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer active:scale-95 transition-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-blue-400" />
                    <span>{language === 'bn' ? 'ম্যাপ ওয়েবসাইট' : 'Visit Map'}</span>
                  </button>

                  {/* Step 2: Write Review */}
                  {!isReviewed && (
                    <button
                      onClick={() => handleOpenReviewModal(place)}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-blue-600/20 active:scale-95 transition-all"
                    >
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{language === 'bn' ? 'রিভিউ দিন' : 'Review'}</span>
                    </button>
                  )}

                  {/* Step 3: Collect 30 Coins */}
                  {!isCollected ? (
                    <button
                      disabled={!isVisited || !isReviewed}
                      onClick={() => handleCollect30Coins(place)}
                      className={`px-3.5 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                        isVisited && isReviewed
                          ? 'bg-gradient-to-r from-amber-500 to-emerald-400 text-slate-950 shadow-md shadow-amber-500/20 animate-pulse hover:scale-105'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? '৩০ কয়েন সংগ্রহ' : 'Collect 30 Coins'}</span>
                    </button>
                  ) : (
                    <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-black flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? '৩০ কয়েন সংগৃহীত' : '30 Coins Collected'}</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Review Submission Modal */}
      {activeReviewPlace && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-slate-900 border border-blue-500/40 rounded-3xl max-w-md w-full p-5 space-y-4 shadow-2xl relative animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-black uppercase text-blue-400 px-2 py-0.5 rounded-md bg-blue-500/10 border border-blue-500/20">
                  Google Maps Review • +30 Coins
                </span>
                <h3 className="text-base font-black text-white mt-1">
                  {language === 'bn' ? activeReviewPlace.nameBn : activeReviewPlace.name}
                </h3>
              </div>
              <button
                onClick={() => setActiveReviewPlace(null)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Rating Stars */}
            <div className="space-y-1.5 text-center">
              <span className="text-xs font-bold text-slate-400 block">
                {language === 'bn' ? 'আপনার রেটিং নির্বাচন করুন (৫-স্টার বাঞ্ছনীয়)' : 'Select Your Rating (5-Stars Recommended)'}
              </span>
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setSelectedRating(star)}
                    className="p-1 transition-transform hover:scale-125 cursor-pointer"
                  >
                    <Star className={`w-7 h-7 ${star <= selectedRating ? 'text-amber-400 fill-current' : 'text-slate-600'}`} />
                  </button>
                ))}
              </div>
            </div>

            {/* Review feedback text */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                {language === 'bn' ? 'রিভিউ মতামত (Review Feedback):' : 'Review Feedback:'}
              </label>
              <textarea
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                rows={3}
                className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
              />
            </div>

            {/* Quick Suggestions */}
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold block">
                {language === 'bn' ? 'কুইক টেমপ্লেট নির্বাচন করুন:' : 'Quick Review Templates:'}
              </span>
              <div className="space-y-1">
                {MAP_REVIEW_SUGGESTIONS.slice(0, 3).map((template, idx) => (
                  <button
                    key={idx}
                    onClick={() => setReviewText(template)}
                    className="w-full text-left p-1.5 rounded-lg bg-slate-950/60 hover:bg-slate-800 border border-slate-800/80 text-[10px] text-slate-300 hover:text-white truncate cursor-pointer transition-colors"
                  >
                    • {template}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Review Button */}
            <div className="pt-2">
              <button
                disabled={isSubmittingReview}
                onClick={handleSubmitReview}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-600/30 active:scale-95 transition-all"
              >
                <Check className="w-4 h-4" />
                <span>{language === 'bn' ? 'রিভিউ জমা দিন ও ৩০ কয়েন আনলক করুন' : 'Submit Review & Unlock 30 Coins'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
