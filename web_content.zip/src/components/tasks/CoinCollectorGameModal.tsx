import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Gamepad2, 
  Coins, 
  Heart, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  RotateCcw,
  ShieldCheck,
  Trophy,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface CoinCollectorGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  targetScore?: number;
  rewardCoins?: number;
}

export const CoinCollectorGameModal: React.FC<CoinCollectorGameModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  targetScore = 30,
  rewardCoins = 18
}) => {
  const { currentUser, submitTaskCompletion, language } = useApp();

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game state
  const [gameState, setGameState] = useState<'intro' | 'playing' | 'gameover' | 'completed'>('intro');
  const [score, setScore] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationMessage, setVerificationMessage] = useState<string>('');

  // Anti-tamper verification tokens
  const gameStartTimeRef = useRef<number>(0);
  const collectedItemsCountRef = useRef<number>(0);

  // Player position & input
  const playerRef = useRef<{ x: number; width: number; height: number; speed: number }>({
    x: 140,
    width: 50,
    height: 30,
    speed: 6
  });

  const keysPressed = useRef<{ left: boolean; right: boolean }>({ left: false, right: false });

  // Falling objects
  const itemsRef = useRef<Array<{
    id: number;
    x: number;
    y: number;
    size: number;
    speed: number;
    type: 'coin' | 'gem' | 'bomb';
  }>>([]);

  const animationFrameId = useRef<number | null>(null);

  // Start new game
  const startGame = () => {
    setScore(0);
    setLives(3);
    setGameState('playing');
    setVerificationMessage('');
    gameStartTimeRef.current = Date.now();
    collectedItemsCountRef.current = 0;
    itemsRef.current = [];
    playerRef.current.x = 140;
  };

  // Keyboard controls
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        keysPressed.current.left = true;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        keysPressed.current.right = true;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        keysPressed.current.left = false;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        keysPressed.current.right = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isOpen]);

  // Main Game Loop
  useEffect(() => {
    if (gameState !== 'playing' || !isOpen) {
      if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frameCount = 0;

    const loop = () => {
      frameCount++;
      const width = canvas.width;
      const height = canvas.height;

      // Clear Canvas
      ctx.clearRect(0, 0, width, height);

      // Draw starry game background
      ctx.fillStyle = '#090D16';
      ctx.fillRect(0, 0, width, height);

      // Update Player position
      const p = playerRef.current;
      if (keysPressed.current.left) p.x = Math.max(0, p.x - p.speed);
      if (keysPressed.current.right) p.x = Math.min(width - p.width, p.x + p.speed);

      // Draw Basket/Player Collector
      ctx.fillStyle = '#10B981';
      ctx.beginPath();
      ctx.roundRect(p.x, height - 40, p.width, p.height, 8);
      ctx.fill();
      ctx.strokeStyle = '#34D399';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw Basket Details
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 10px monospace';
      ctx.fillText('🧺 CATCH', p.x + 5, height - 22);

      // Spawn falling items
      if (frameCount % 30 === 0) {
        const rand = Math.random();
        let type: 'coin' | 'gem' | 'bomb' = 'coin';
        if (rand > 0.85) type = 'gem';
        else if (rand < 0.25) type = 'bomb';

        itemsRef.current.push({
          id: Math.random(),
          x: Math.random() * (width - 24) + 12,
          y: -10,
          size: type === 'gem' ? 14 : type === 'bomb' ? 15 : 12,
          speed: type === 'bomb' ? 3.5 : 2.8 + Math.random() * 1.5,
          type
        });
      }

      // Update & Draw Items
      const remainingItems = [];
      for (const item of itemsRef.current) {
        item.y += item.speed;

        // Draw item
        if (item.type === 'coin') {
          ctx.fillStyle = '#F59E0B';
          ctx.beginPath();
          ctx.arc(item.x, item.y, item.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#FEF3C7';
          ctx.lineWidth = 1.5;
          ctx.stroke();
          ctx.fillStyle = '#78350F';
          ctx.font = 'bold 10px sans-serif';
          ctx.fillText('₹', item.x - 3.5, item.y + 3.5);
        } else if (item.type === 'gem') {
          ctx.fillStyle = '#38BDF8';
          ctx.beginPath();
          ctx.arc(item.x, item.y, item.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FFFFFF';
          ctx.font = 'bold 9px sans-serif';
          ctx.fillText('+3', item.x - 6, item.y + 3);
        } else {
          // Bomb
          ctx.fillStyle = '#EF4444';
          ctx.beginPath();
          ctx.arc(item.x, item.y, item.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#FFFFFF';
          ctx.font = 'bold 9px sans-serif';
          ctx.fillText('💣', item.x - 6, item.y + 3);
        }

        // Check Collision with Player Basket
        const inX = item.x >= p.x - 5 && item.x <= p.x + p.width + 5;
        const inY = item.y >= height - 45 && item.y <= height - 10;

        if (inX && inY) {
          if (item.type === 'coin') {
            collectedItemsCountRef.current++;
            setScore((prev) => {
              const newScore = prev + 1;
              if (newScore >= targetScore) {
                setGameState('completed');
              }
              return newScore;
            });
          } else if (item.type === 'gem') {
            collectedItemsCountRef.current += 3;
            setScore((prev) => {
              const newScore = prev + 3;
              if (newScore >= targetScore) {
                setGameState('completed');
              }
              return newScore;
            });
          } else if (item.type === 'bomb') {
            setLives((prevLives) => {
              const nextLives = prevLives - 1;
              if (nextLives <= 0) {
                setGameState('gameover');
              }
              return nextLives;
            });
          }
        } else if (item.y < height + 20) {
          remainingItems.push(item);
        }
      }

      itemsRef.current = remainingItems;

      animationFrameId.current = requestAnimationFrame(loop);
    };

    animationFrameId.current = requestAnimationFrame(loop);

    return () => {
      if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
    };
  }, [gameState, isOpen, targetScore]);

  // Touch handlers for mobile
  const handleTouchMove = (direction: 'left' | 'right', isDown: boolean) => {
    if (direction === 'left') keysPressed.current.left = isDown;
    if (direction === 'right') keysPressed.current.right = isDown;
  };

  // Submit Verification & Claim Reward
  const handleSubmitVerification = () => {
    if (!currentUser || score < targetScore) return;

    setIsVerifying(true);
    setVerificationMessage('Validating active gameplay session & anti-cheat signature...');

    setTimeout(() => {
      setIsVerifying(false);
      const elapsedPlaySeconds = Math.round((Date.now() - gameStartTimeRef.current) / 1000);

      const res = submitTaskCompletion(
        'game-coin-collector',
        `Coin Collector Verification: Score ${score}/${targetScore} | Playtime: ${elapsedPlaySeconds}s | Items: ${collectedItemsCountRef.current}`
      );

      if (res.success) {
        setVerificationMessage(
          language === 'bn'
            ? 'অভিনন্দন! গেম খেলার জন্য ১৮ কয়েন আপনার অ্যাকাউন্টে জমা হয়েছে।'
            : 'Game verified! 18 Coins have been successfully credited to your wallet.'
        );
        confetti({
          particleCount: 90,
          spread: 60,
          origin: { y: 0.65 }
        });
        onSuccess();
      } else {
        setVerificationMessage(res.message);
      }
    }, 1200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm sm:max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl relative max-h-[95vh] flex flex-col space-y-3 text-slate-100"
        role="dialog"
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md">
              <Gamepad2 className="w-4 h-4" />
            </span>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                  Play Game Task
                </span>
                <span className="text-xs font-black text-amber-400 flex items-center gap-0.5">
                  <Coins className="w-3 h-3" /> +18 Coins
                </span>
              </div>
              <h2 className="text-sm font-black text-white">Coin Collector</h2>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live HUD (Score, Target, Lives) */}
        <div className="grid grid-cols-3 gap-2 bg-slate-950 p-2.5 rounded-2xl border border-slate-800 text-center">
          <div>
            <span className="text-[10px] text-slate-400">Score</span>
            <div className="font-mono text-sm font-black text-emerald-400">
              {score} / {targetScore}
            </div>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Reward</span>
            <div className="font-mono text-sm font-black text-amber-400 flex items-center justify-center gap-0.5">
              <Coins className="w-3.5 h-3.5" /> 18 Coins
            </div>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Lives</span>
            <div className="flex items-center justify-center gap-0.5 text-xs text-rose-500 font-bold">
              {Array.from({ length: 3 }).map((_, i) => (
                <Heart key={i} className={`w-3.5 h-3.5 ${i < lives ? 'fill-rose-500 text-rose-500' : 'text-slate-700'}`} />
              ))}
            </div>
          </div>
        </div>

        {/* Game Canvas Container */}
        <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-[#090D16] flex items-center justify-center aspect-[4/3]">
          <canvas
            ref={canvasRef}
            width={340}
            height={255}
            className="w-full h-full block"
          />

          {/* Intro Screen */}
          {gameState === 'intro' && (
            <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center space-y-3">
              <Trophy className="w-10 h-10 text-amber-400 animate-bounce" />
              <div className="space-y-1">
                <h3 className="text-sm font-black text-white">Collect 30 Coins to Win</h3>
                <p className="text-xs text-slate-300">
                  Catch falling golden coins (+1) and blue gems (+3). Avoid red bombs (-1 life)!
                </p>
              </div>
              <button
                type="button"
                onClick={startGame}
                className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white font-black text-xs shadow-lg shadow-emerald-600/30 cursor-pointer active:scale-95"
              >
                Start Game
              </button>
            </div>
          )}

          {/* Game Over Screen */}
          {gameState === 'gameover' && (
            <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-4 text-center space-y-3">
              <AlertCircle className="w-10 h-10 text-rose-400" />
              <div className="space-y-1">
                <h3 className="text-sm font-black text-white">Out of Lives!</h3>
                <p className="text-xs text-slate-300">
                  You scored {score} of {targetScore} coins. Try again to reach the target!
                </p>
              </div>
              <button
                type="button"
                onClick={startGame}
                className="py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retry Game</span>
              </button>
            </div>
          )}

          {/* Completed Target Screen */}
          {gameState === 'completed' && (
            <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-4 text-center space-y-3">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 animate-pulse" />
              <div className="space-y-1">
                <h3 className="text-sm font-black text-white">Target Reached ({score} Coins)!</h3>
                <p className="text-xs text-slate-300">
                  You successfully reached the {targetScore} coin threshold.
                </p>
              </div>

              {verificationMessage ? (
                <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                  {verificationMessage}
                </div>
              ) : (
                <button
                  type="button"
                  disabled={isVerifying}
                  onClick={handleSubmitVerification}
                  className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/30 cursor-pointer active:scale-95"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isVerifying ? 'Verifying...' : 'Submit for Verification (18 Coins)'}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Mobile On-Screen Controls */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            type="button"
            onPointerDown={() => handleTouchMove('left', true)}
            onPointerUp={() => handleTouchMove('left', false)}
            onPointerLeave={() => handleTouchMove('left', false)}
            className="py-3 rounded-2xl bg-slate-800 active:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-700 select-none cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Move Left</span>
          </button>
          <button
            type="button"
            onPointerDown={() => handleTouchMove('right', true)}
            onPointerUp={() => handleTouchMove('right', false)}
            onPointerLeave={() => handleTouchMove('right', false)}
            className="py-3 rounded-2xl bg-slate-800 active:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-700 select-none cursor-pointer"
          >
            <span>Move Right</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Verification Guarantee Footer */}
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 justify-center">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Anti-cheat active gameplay validation enabled. 18 coins awarded upon verification.</span>
        </div>
      </div>
    </div>
  );
};
