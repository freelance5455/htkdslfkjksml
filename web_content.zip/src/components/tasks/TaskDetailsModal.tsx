import React from 'react';
import { 
  X, 
  Clock, 
  Coins, 
  Award, 
  CheckCircle2, 
  AlertCircle, 
  ExternalLink, 
  ShieldCheck, 
  FileText, 
  ListChecks, 
  Play, 
  Sparkles, 
  Crown, 
  Camera, 
  Tv, 
  Smartphone, 
  Download, 
  HelpCircle, 
  MapPin, 
  Share2, 
  ChevronRight, 
  Info,
  Check,
  Zap,
  Lock
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Task } from '../../types';

interface TaskDetailsModalProps {
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
  onStartTask: (task: Task) => void;
}

export const TaskDetailsModal: React.FC<TaskDetailsModalProps> = ({
  task,
  isOpen,
  onClose,
  onStartTask
}) => {
  const { 
    currentUser, 
    membershipPlans, 
    taskSubmissions, 
    systemSettings, 
    language 
  } = useApp();

  if (!isOpen || !task) return null;

  const currentPlan = currentUser
    ? membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0]
    : membershipPlans[0];

  // Daily submission status
  const today = new Date().toISOString().split('T')[0];
  const userSubsToday = currentUser
    ? taskSubmissions.filter(s => s.userId === currentUser.id && s.taskId === task.id && s.completedAt.startsWith(today))
    : [];
  const completedCount = userSubsToday.length;
  const isLimitReached = completedCount >= task.dailyLimit;

  // Title and description according to selected language
  const title = language === 'bn' && task.titleBn ? task.titleBn : task.title;
  const description = language === 'bn' && task.descriptionBn ? task.descriptionBn : task.description;

  // Reward calculations
  const multiplier = currentPlan?.rewardMultiplier || 1;
  const finalRewardCoins = Math.round(task.rewardCoins * multiplier);
  const bonusCoins = finalRewardCoins - task.rewardCoins;
  const coinsPerRupee = systemSettings?.coinsPerCurrencyUnit || 1000;
  const baseRupees = task.rewardRupees || Number((task.rewardCoins / coinsPerRupee).toFixed(2));
  const finalRupees = Number((finalRewardCoins / coinsPerRupee).toFixed(2));

  // Category Icon & Color Helper
  const getCategoryMeta = () => {
    switch (task.category) {
      case 'survey':
        return {
          icon: <ListChecks className="w-4 h-4 text-emerald-400" />,
          label: 'Survey & Market Research',
          badgeBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
        };
      case 'youtube_watch':
        return {
          icon: <Tv className="w-4 h-4 text-red-400" />,
          label: 'YouTube Video Watch',
          badgeBg: 'bg-red-500/10 text-red-400 border-red-500/30'
        };
      case 'app_download':
        return {
          icon: <Download className="w-4 h-4 text-cyan-400" />,
          label: 'App Install & Review',
          badgeBg: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
        };
      case 'social_facebook':
        return {
          icon: <Share2 className="w-4 h-4 text-blue-400" />,
          label: 'Facebook Social Task',
          badgeBg: 'bg-blue-500/10 text-blue-400 border-blue-500/30'
        };
      case 'review':
        return {
          icon: <MapPin className="w-4 h-4 text-amber-400" />,
          label: 'Review & Ratings',
          badgeBg: 'bg-amber-500/10 text-amber-400 border-amber-500/30'
        };
      case 'quiz':
        return {
          icon: <HelpCircle className="w-4 h-4 text-purple-400" />,
          label: 'Knowledge Quiz',
          badgeBg: 'bg-purple-500/10 text-purple-400 border-purple-500/30'
        };
      case 'vip_task':
        return {
          icon: <Crown className="w-4 h-4 text-yellow-400" />,
          label: 'VIP Exclusive Mission',
          badgeBg: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30'
        };
      default:
        return {
          icon: <FileText className="w-4 h-4 text-teal-400" />,
          label: task.category.replace('_', ' ').toUpperCase(),
          badgeBg: 'bg-slate-800 text-slate-300 border-slate-700'
        };
    }
  };

  const catMeta = getCategoryMeta();

  // Dynamic step-by-step instructions
  const getStepInstructions = () => {
    switch (task.category) {
      case 'survey':
        return [
          {
            step: 1,
            title: language === 'bn' ? 'সার্ভে ওপেন করুন' : 'Launch Survey Questionnaire',
            desc: language === 'bn' 
              ? 'নির্ধারিত সার্ভে পেজে গিয়ে সকল প্রশ্ন মনোযোগ দিয়ে পড়ুন।'
              : 'Read all consumer feedback or opinion survey questions carefully.'
          },
          {
            step: 2,
            title: language === 'bn' ? 'সঠিক মতামত প্রদান করুন' : 'Provide Genuine Answers',
            desc: language === 'bn'
              ? 'বাস্তব ও নির্ভুল উত্তর দিন। তাড়াহুড়ো করে ভুল উত্তর দিলে সিস্টেম রিজেক্ট করতে পারে।'
              : 'Answer honestly based on your experience. Rushed or contradictory answers may be rejected.'
          },
          {
            step: 3,
            title: language === 'bn' ? 'সাবমিট ও প্রমাণ প্রদান' : 'Submit & Provide Proof',
            desc: task.requiresProof
              ? (task.proofInstructions || (language === 'bn' ? 'সম্পন্ন হওয়ার পর ফাইনাল স্ক্রিনশট বা কোড আপলোড করুন।' : 'Submit final confirmation screenshot or verification code.'))
              : (language === 'bn' ? 'সার্ভে সমাপ্তির পর কয়েন সরাসরি আপনার ব্যালেন্সে যোগ হবে।' : 'Once completed, your reward coins will be credited instantly.')
          }
        ];
      case 'youtube_watch':
        return [
          {
            step: 1,
            title: language === 'bn' ? 'ভিডিও দেখা শুরু করুন' : 'Begin Video Playback',
            desc: language === 'bn'
              ? `সম্পূর্ণ ভিডিওটি মনোযোগ দিয়ে দেখুন। ন্যূনতম ${task.requiredWatchSeconds || 60} সেকেন্ড দেখতে হবে।`
              : `Watch the full video without skipping. Minimum required duration: ${task.requiredWatchSeconds || 60} seconds.`
          },
          {
            step: 2,
            title: language === 'bn' ? 'ভিডিওতে লাইক ও সাবস্ক্রাইব' : 'Engage with Content',
            desc: language === 'bn'
              ? 'চ্যানেলটি সাবস্ক্রাইব করুন এবং ভিডিওতে একটি লাইক দিন।'
              : 'Like the video and consider subscribing to verify authentic user engagement.'
          },
          {
            step: 3,
            title: language === 'bn' ? 'টাইমার ও স্ক্রিনশট' : 'Complete Timer & Upload Proof',
            desc: task.requiresProof
              ? (task.proofInstructions || (language === 'bn' ? 'ভিডিও ওয়াচ টাইমার শেষ হলে স্ক্রিনশট সাবমিট করুন।' : 'Upload a screenshot showing playback completion for verification.'))
              : (language === 'bn' ? 'টাইমার শেষ হওয়া মাত্রই কয়েন ওয়ালেটে যোগ হবে।' : 'Coins will automatically credit as soon as the watch timer elapses.')
          }
        ];
      case 'app_download':
        return [
          {
            step: 1,
            title: language === 'bn' ? 'অ্যাপ ডাউনলোড ও ইনস্টল' : 'Download and Install App',
            desc: language === 'bn'
              ? `অফিসিয়াল স্টোর থেকে অ্যাপটি ডাউনলোড করে সম্পূর্ণ ইনস্টল করুন (${task.appSizeMb ? `${task.appSizeMb} MB` : 'Play Store'})।`
              : `Download the application from the official store and install it on your device (${task.appSizeMb ? `${task.appSizeMb} MB` : 'Play Store'}).`
          },
          {
            step: 2,
            title: language === 'bn' ? 'অ্যাপটি ওপেন করে ব্যবহার করুন' : 'Open and Explore App',
            desc: language === 'bn'
              ? 'অ্যাপটি ওপেন করে অন্তত ১-২ মিনিট ব্যবহার করুন বা সাইন-আপ সম্পন্ন করুন।'
              : 'Open the application and browse its features for at least 1-2 minutes or complete signup.'
          },
          {
            step: 3,
            title: language === 'bn' ? 'ভেরিফিকেশন ও কয়েন ক্রেডিট' : 'Verification & Coin Reward',
            desc: task.proofInstructions || (language === 'bn' ? 'অ্যাপের হোম পেজের স্ক্রিনশট আপলোড করে টাস্ক সম্পূর্ণ করুন।' : 'Upload a screenshot of the opened application home screen to claim reward.')
          }
        ];
      case 'social_facebook':
        return [
          {
            step: 1,
            title: language === 'bn' ? 'ফেসবুক পেজ / পোস্টে যান' : 'Navigate to Facebook Page/Post',
            desc: language === 'bn'
              ? 'নির্ধারিত লিংকে ক্লিক করে অফিসিয়াল ফেসবুক পেজ অথবা পোস্টে যান।'
              : 'Click the provided link to open the official target Facebook page or promotional post.'
          },
          {
            step: 2,
            title: language === 'bn' ? 'লাইক ও ফলো করুন' : 'Like, Follow & Engage',
            desc: language === 'bn'
              ? 'পেজটি লাইক ও ফলো করুন এবং নির্দিষ্ট পোস্টে একটি প্রাসঙ্গিক কমেন্ট করুন।'
              : 'Follow/Like the official page and interact with the designated post.'
          },
          {
            step: 3,
            title: language === 'bn' ? 'স্ক্রিনশট প্রুফ জমা দিন' : 'Submit Screenshot Proof',
            desc: task.proofInstructions || (language === 'bn' ? 'আপনার ফেসবুক আইডি ও লাইক করা অবস্থার স্পষ্ট স্ক্রিনশট আপলোড করুন।' : 'Upload a screenshot clearly showing you have liked/followed the page.')
          }
        ];
      default:
        return [
          {
            step: 1,
            title: language === 'bn' ? 'টাস্ক নির্দেশিকা পড়ুন' : 'Review Task Instructions',
            desc: description
          },
          {
            step: 2,
            title: language === 'bn' ? 'টাস্ক সম্পন্ন করুন' : 'Execute Activity',
            desc: language === 'bn'
              ? `প্রয়োজনীয় সকল ধাপ মনোযোগের সাথে সম্পন্ন করুন। আনুমানিক সময়: ${task.estimatedMinutes} মিনিট।`
              : `Follow all required actions accurately. Estimated duration: ${task.estimatedMinutes} minutes.`
          },
          {
            step: 3,
            title: language === 'bn' ? 'ভেরিফিকেশন ও কয়েন রিওয়ার্ড' : 'Verify & Claim Reward',
            desc: task.requiresProof
              ? (task.proofInstructions || (language === 'bn' ? 'স্ক্রিনশট বা প্রয়োজনীয় প্রুফ জমা দিয়ে কয়েন নিশ্চিত করুন।' : 'Submit requested screenshot or confirmation proof.'))
              : (language === 'bn' ? 'সম্পন্ন হওয়া মাত্র কয়েন ব্যালেন্সে রিফ্লেক্ট করবে।' : 'Coins are added directly to your available balance upon completion.')
          }
        ];
    }
  };

  const steps = getStepInstructions();

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-lg bg-[#0B1120] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl relative space-y-5 text-slate-100 my-auto max-h-[92vh] overflow-y-auto no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-start justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="space-y-1.5 flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`px-2.5 py-1 rounded-xl border text-[10px] font-black tracking-wide uppercase flex items-center gap-1.5 ${catMeta.badgeBg}`}>
                {catMeta.icon}
                <span>{catMeta.label}</span>
              </span>

              {isLimitReached ? (
                <span className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-bold flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span>{language === 'bn' ? 'দৈনিক লিমিট পূর্ণ' : 'Daily Limit Reached'}</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                  <Zap className="w-3 h-3 text-emerald-400" />
                  <span>{language === 'bn' ? 'উপলব্ধ (Active)' : 'Available Now'}</span>
                </span>
              )}

              {task.vipTierRequired && (
                <span className="px-2 py-0.5 rounded-lg bg-yellow-500/10 text-yellow-400 border border-yellow-500/30 text-[10px] font-black uppercase">
                  VIP: {task.vipTierRequired}
                </span>
              )}
            </div>

            <h2 className="text-base sm:text-lg font-black text-white leading-snug tracking-tight">
              {title}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer shrink-0"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Reward Highlights Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-emerald-950/30 border border-amber-500/30 shadow-lg relative overflow-hidden space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="text-[11px] font-black text-amber-400/90 uppercase tracking-wider flex items-center gap-1.5">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>{language === 'bn' ? 'টাস্ক রিওয়ার্ড তথ্য' : 'Reward Breakdown'}</span>
            </span>

            <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
              <Clock className="w-3 h-3 text-slate-400" />
              <span>{task.estimatedMinutes} {language === 'bn' ? 'মিনিট আনুমানিক' : 'mins est.'}</span>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            {/* Total Reward Coins */}
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-0.5">
              <span className="text-[10px] text-slate-400 block font-semibold">
                {language === 'bn' ? 'মোট কয়েন রিওয়ার্ড' : 'Total Reward Coins'}
              </span>
              <div className="flex items-baseline gap-1">
                <span className="text-lg font-black text-amber-400 font-mono">
                  +{finalRewardCoins.toLocaleString()}
                </span>
                <span className="text-[10px] text-amber-500 font-bold">🪙</span>
              </div>
            </div>

            {/* Estimated Cash Value */}
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-0.5">
              <span className="text-[10px] text-slate-400 block font-semibold">
                {language === 'bn' ? 'সমপরিমাণ রুপি (INR)' : 'Cash Equivalent (INR)'}
              </span>
              <div className="flex items-baseline gap-1">
                <span className="text-lg font-black text-emerald-400 font-mono">
                  ₹{finalRupees}
                </span>
                <span className="text-[10px] text-emerald-500 font-bold">INR</span>
              </div>
            </div>

            {/* Daily Limit Status */}
            <div className="col-span-2 sm:col-span-1 p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-0.5">
              <span className="text-[10px] text-slate-400 block font-semibold">
                {language === 'bn' ? 'দৈনিক সম্পন্ন সংখ্যা' : 'Daily Completion'}
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-lg font-black text-slate-200 font-mono">
                  {completedCount}/{task.dailyLimit}
                </span>
                <span className="text-[10px] text-slate-400">
                  {language === 'bn' ? 'আজকে' : 'today'}
                </span>
              </div>
            </div>
          </div>

          {/* Membership Tier Multiplier Note */}
          <div className="px-3 py-2 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-[11px]">
            <div className="flex items-center gap-1.5 text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>
                {currentPlan.name}: <strong className="text-amber-300">{multiplier}x Multiplier</strong>
              </span>
            </div>
            {bonusCoins > 0 ? (
              <span className="text-emerald-400 font-black">
                +{bonusCoins} {language === 'bn' ? 'বোনাস কয়েন অন্তর্ভুক্ত' : 'bonus coins included'}
              </span>
            ) : (
              <span className="text-slate-400 text-[10px]">
                {language === 'bn' ? 'ভিআইপি মেম্বারশিপে আরও বেশি কয়েন' : 'Upgrade VIP for up to 3x coins'}
              </span>
            )}
          </div>
        </div>

        {/* Task Full Description */}
        <div className="space-y-2">
          <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-indigo-400" />
            <span>{language === 'bn' ? 'টাস্ক ওভারভিউ ও বিবরণ' : 'Task Overview & Description'}</span>
          </h3>
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/90 text-xs text-slate-300 leading-relaxed font-medium">
            {description}
          </div>
        </div>

        {/* Step-by-Step Instructions */}
        <div className="space-y-2.5">
          <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
            <ListChecks className="w-3.5 h-3.5 text-emerald-400" />
            <span>{language === 'bn' ? 'ধাপে ধাপে নির্দেশাবলী' : 'Step-by-Step Instructions'}</span>
          </h3>

          <div className="space-y-2">
            {steps.map((s) => (
              <div 
                key={s.step}
                className="p-3 rounded-2xl bg-slate-900/50 border border-slate-800/80 flex items-start gap-3 text-xs"
              >
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-black text-xs shrink-0 mt-0.5">
                  {s.step}
                </div>
                <div className="space-y-0.5 flex-1 min-w-0">
                  <h4 className="font-bold text-white text-xs">
                    {s.title}
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {s.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Verification & Proof Details */}
        <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-300 flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'bn' ? 'প্রুফ ভেরিফিকেশন রিকোয়ারমেন্ট' : 'Verification Requirement'}</span>
            </span>
            {task.requiresProof ? (
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                {task.proofType?.toUpperCase() || 'SCREENSHOT'} PROOF REQUIRED
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                INSTANT AUTO CREDIT
              </span>
            )}
          </div>

          {task.requiresProof ? (
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {task.proofInstructions || (language === 'bn'
                ? 'টাস্ক সম্পন্ন করার পর স্ক্রিনশট বা প্রুফ আপলোড করুন। অ্যাডমিন টিম দ্রুত ভেরিফাই করে কয়েন যুক্ত করবেন।'
                : 'Upload a clear screenshot proof of the completed action. Our admin team verifies all proofs to maintain fair earnings.')}
            </p>
          ) : (
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {language === 'bn'
                ? 'এই টাস্কে কোনো স্ক্রিনশট প্রয়োজন নেই। টাইমার সমাপ্তির সাথে সাথে কয়েন সরাসরি জমা হবে।'
                : 'No manual screenshot required for this task. Reward coins credit automatically upon verified completion.'}
            </p>
          )}

          {task.isExternal && task.externalPlatform && (
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
              <span>Platform: <strong className="text-slate-200">{task.externalPlatform}</strong></span>
              <span className="flex items-center gap-1 text-indigo-400">
                <span>External Portal</span>
                <ExternalLink className="w-3 h-3" />
              </span>
            </div>
          )}
        </div>

        {/* Security & Anti-Fraud Guarantee Note */}
        <div className="px-3.5 py-2.5 rounded-xl bg-indigo-950/30 border border-indigo-800/40 flex items-center gap-2.5 text-[11px] text-indigo-300">
          <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>
            {language === 'bn'
              ? 'নিরাপদ ডিজিটাল ট্র্যাকিং ও ইনস্ট্যান্ট পেআউট গ্যারান্টি। কোনো ভিপিএন ব্যবহার গ্রহণযোগ্য নয়।'
              : 'Safe digital tracking with guaranteed payouts. One account per user, VPN usage strictly prohibited.'}
          </span>
        </div>

        {/* Footer Actions */}
        <div className="pt-2 flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white font-bold text-xs transition-all cursor-pointer"
          >
            {language === 'bn' ? 'পরে করব' : 'Close'}
          </button>

          {isLimitReached ? (
            <button
              disabled
              className="flex-2 py-3 rounded-2xl bg-slate-800 text-slate-500 font-black text-xs flex items-center justify-center gap-2 cursor-not-allowed border border-slate-700/60"
            >
              <Check className="w-4 h-4" />
              <span>{language === 'bn' ? 'আজকের লিমিট শেষ' : 'Daily Limit Reached'}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                onClose();
                onStartTask(task);
              }}
              className="flex-2 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>{language === 'bn' ? 'এখনই টাস্ক শুরু করুন' : 'Start Task Now'}</span>
              <Play className="w-3.5 h-3.5 fill-current" />
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
