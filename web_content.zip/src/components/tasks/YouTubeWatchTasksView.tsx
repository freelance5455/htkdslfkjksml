import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Tv, 
  Coins, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  RefreshCw, 
  Search, 
  Check, 
  AlertCircle,
  ExternalLink,
  X,
  Pause
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { YouTubeVideo } from '../../types';
import { getYoutubeVideos, TOTAL_YOUTUBE_CATALOG_COUNT, YOUTUBE_CATEGORIES } from '../../services/youtubeLibrary';

export const YouTubeWatchTasksView: React.FC = () => {
  const { currentUser, submitTaskCompletion, adjustUserCoins, recordPlaySeen, language } = useApp();

  const [category, setCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const [videosList, setVideosList] = useState<YouTubeVideo[]>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);

  // Active playing video modal
  const [activeVideo, setActiveVideo] = useState<YouTubeVideo | null>(null);

  // Real Playback tracking states
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [requiredSeconds, setRequiredSeconds] = useState<number>(60); // 60s standard test or configurable
  const [isRequirementMet, setIsRequirementMet] = useState<boolean>(false);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationSuccess, setVerificationSuccess] = useState<boolean>(false);
  const [verificationMessage, setVerificationMessage] = useState<string>('');

  // Persisted completed video task IDs
  const [completedVideoIds, setCompletedVideoIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_completed_yt_tasks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Load videos
  useEffect(() => {
    const { videos, hasMore: more } = getYoutubeVideos(1, 12, category, searchQuery);
    // Standardize reward to 25 coins for the YouTube Watch task category
    const standardized = videos.map(v => ({ ...v, rewardCoins: 25 }));
    setVideosList(standardized);
    setPage(1);
    setHasMore(more);
  }, [category, searchQuery]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    const { videos: newBatch, hasMore: more } = getYoutubeVideos(nextPage, 12, category, searchQuery);
    const standardized = newBatch.map(v => ({ ...v, rewardCoins: 25 }));
    setVideosList(prev => [...prev, ...standardized]);
    setPage(nextPage);
    setHasMore(more);
  };

  const handleOpenVideo = (video: YouTubeVideo) => {
    if (completedVideoIds.includes(video.id)) return;
    setActiveVideo(video);
    // Use video duration or minimum 60 seconds (1 minute / configurable)
    const targetTime = Math.min(Math.max(video.durationSeconds, 60), 300); // 60-300 seconds
    setRequiredSeconds(targetTime);
    setElapsedSeconds(0);
    setIsRequirementMet(false);
    setIsPlaying(true);
    setVerificationSuccess(false);
    setVerificationMessage('');
  };

  const handleCloseModal = () => {
    setActiveVideo(null);
    setIsPlaying(false);
    setElapsedSeconds(0);
    setIsRequirementMet(false);
  };

  // Real Timer: advances only when active, pauses if tab hidden
  useEffect(() => {
    if (!activeVideo || isRequirementMet || !isPlaying) return;

    const timer = setInterval(() => {
      // Pause if tab is hidden
      if (document.hidden) {
        setIsPlaying(false);
        return;
      }

      setElapsedSeconds((prev) => {
        const next = prev + 1;
        if (next >= requiredSeconds) {
          setIsRequirementMet(true);
          return requiredSeconds;
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeVideo, isPlaying, isRequirementMet, requiredSeconds]);

  // Listen to visibilitychange to prevent background fake watch time
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden) {
        setIsPlaying(false);
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, []);

  const handleSubmitVerification = () => {
    if (!currentUser || !activeVideo || !isRequirementMet) return;

    setIsVerifying(true);
    setVerificationMessage('Verifying watch telemetry & session integrity...');

    setTimeout(() => {
      setIsVerifying(false);
      
      const res = submitTaskCompletion(
        activeVideo.id,
        `YouTube Watch Verification: ${activeVideo.title} | Duration: ${elapsedSeconds}s | VideoID: ${activeVideo.youtubeId}`
      );

      if (res.success) {
        // Record Play Seen for Admin Ad Revenue & Monetization
        recordPlaySeen(elapsedSeconds);

        setVerificationSuccess(true);
        setVerificationMessage(
          language === 'bn'
            ? 'অভিনন্দন! ইউটিউব ভিডিও দেখার জন্য ২৫ কয়েন আপনার অ্যাকাউন্টে জমা হয়েছে।'
            : 'Watch verified successfully! 25 Coins have been credited to your wallet.'
        );
        setCompletedVideoIds(prev => {
          const updated = Array.from(new Set([...prev, activeVideo.id]));
          localStorage.setItem('taskearn_completed_yt_tasks', JSON.stringify(updated));
          return updated;
        });
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.65 }
        });
      } else {
        setVerificationMessage(res.message);
      }
    }, 1200);
  };

  const progressPercent = Math.min(100, Math.round((elapsedSeconds / requiredSeconds) * 100));

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4">
      {/* 25 Coins YouTube Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-red-950/80 via-slate-900 to-indigo-950/80 border border-red-900/60 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-md shadow-red-600/30">
                <Tv className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-black text-white">
                YouTube Watch & Earn Tasks
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-500/20 text-red-300 border border-red-500/30">
                25 Coins / Task
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Watch real educational and gaming videos in the official YouTube player, reach the required watch duration, and submit for verification to earn <strong>25 Coins (₹25)</strong>!
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/70 border border-red-500/30 px-3 py-2 rounded-2xl shrink-0">
            <Coins className="w-4 h-4 text-amber-400" />
            <div className="text-xs">
              <span className="text-slate-400">Fixed Reward: </span>
              <span className="font-black text-red-400">25 Coins</span>
            </div>
          </div>
        </div>

        {/* Anti-Fraud / Real Watch Policy Banner */}
        <div className="p-2.5 rounded-2xl bg-red-950/40 border border-red-500/20 flex items-center gap-2 text-xs text-red-300">
          <ShieldCheck className="w-4 h-4 shrink-0 text-red-400" />
          <span>Real watch tracking enabled. Coins are never credited simply for opening the video; completion condition must be fulfilled.</span>
        </div>
      </div>

      {/* Search & Category Filter */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search YouTube tasks by title, channel, or topic..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-red-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {['All', ...YOUTUBE_CATEGORIES].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                category === cat
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Videos List Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {videosList.map((video) => {
          const isCompleted = completedVideoIds.includes(video.id);

          return (
            <div
              key={video.id}
              className={`rounded-3xl bg-slate-900 border overflow-hidden transition-all duration-200 flex flex-col justify-between ${
                isCompleted 
                  ? 'border-emerald-500/40 opacity-80' 
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Thumbnail with duration badge */}
              <div className="relative aspect-video bg-black/60 overflow-hidden">
                <img
                  src={video.thumbnailUrl}
                  alt={video.title}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

                {/* Duration Tag */}
                <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-black/80 text-[10px] font-mono font-bold text-white flex items-center gap-1">
                  <Clock className="w-3 h-3 text-red-400" />
                  <span>{formatTime(video.durationSeconds)}</span>
                </div>

                {/* Reward Badge */}
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-red-600 text-[10px] font-black text-white flex items-center gap-1 shadow-md">
                  <Coins className="w-3 h-3 text-amber-300" />
                  <span>+25 Coins</span>
                </div>

                {isCompleted && (
                  <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md bg-emerald-500/90 text-[10px] font-black text-white flex items-center gap-1 shadow-md">
                    <Check className="w-3 h-3" />
                    <span>Completed</span>
                  </div>
                )}
              </div>

              {/* Video Info */}
              <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-red-400 uppercase tracking-wider">
                    {video.category} • {video.channelTitle}
                  </span>
                  <h3 className="text-xs font-bold text-white line-clamp-2 leading-relaxed" title={video.title}>
                    {video.title}
                  </h3>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Required: {formatTime(video.durationSeconds)}
                  </span>

                  <button
                    type="button"
                    disabled={isCompleted}
                    onClick={() => handleOpenVideo(video)}
                    className={`py-1.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                      isCompleted
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : 'bg-red-600 hover:bg-red-500 text-white shadow-md shadow-red-600/20 active:scale-95'
                    }`}
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{isCompleted ? 'Watched' : 'Watch & Earn'}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pagination Load More */}
      {hasMore && (
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={handleLoadMore}
            className="py-3 px-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-red-500/50 text-slate-200 text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer inline-flex items-center gap-2"
          >
            <RefreshCw className="w-3.5 h-3.5 text-red-400" />
            <span>Load More YouTube Tasks ({videosList.length} of {TOTAL_YOUTUBE_CATALOG_COUNT.toLocaleString()})</span>
          </button>
        </div>
      )}

      {/* Official YouTube Watch Player & Verification Modal */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div 
            className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl relative max-h-[94vh] flex flex-col space-y-4 text-slate-100 overflow-y-auto"
            role="dialog"
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30">
                    ▶️ YouTube Watch
                  </span>
                  <span className="text-xs font-black text-amber-400 flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" /> +25 Coins Reward
                  </span>
                </div>
                <h2 className="text-sm sm:text-base font-black text-white mt-1 line-clamp-1">
                  {activeVideo.title}
                </h2>
              </div>

              <button
                onClick={handleCloseModal}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Official Embedded YouTube Player */}
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-xl">
              <iframe
                title={activeVideo.title}
                src={`https://www.youtube.com/embed/${activeVideo.youtubeId}?autoplay=1&enablejsapi=1&origin=${typeof window !== 'undefined' ? window.location.origin : ''}`}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>

            {/* Live Real-time Watch Progress Bar */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-red-400" />
                  <span>Real Watch Telemetry:</span>
                </span>
                <span className="font-mono font-bold text-white">
                  {formatTime(elapsedSeconds)} / {formatTime(requiredSeconds)} ({progressPercent}%)
                </span>
              </div>

              <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-red-600 to-amber-500 transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                <span>Status: {isPlaying ? '🟢 Playing & Tracking' : '⏸️ Paused (Timer paused)'}</span>
                <span>Requirement: Complete required watch duration</span>
              </div>
            </div>

            {/* Verification & Claim Section */}
            {verificationSuccess ? (
              <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <div className="text-sm font-black text-white">Reward Claimed!</div>
                <p className="text-xs">{verificationMessage}</p>
                <button
                  onClick={handleCloseModal}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs transition-all cursor-pointer"
                >
                  Close & Continue
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {verificationMessage && (
                  <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{verificationMessage}</span>
                  </div>
                )}

                <button
                  type="button"
                  disabled={!isRequirementMet || isVerifying}
                  onClick={handleSubmitVerification}
                  className={`w-full py-3.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                    isRequirementMet
                      ? 'bg-gradient-to-r from-red-600 to-amber-600 hover:opacity-95 text-white shadow-red-600/30 active:scale-95 animate-pulse'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  }`}
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying Watch Integrity...</span>
                    </>
                  ) : isRequirementMet ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Submit for Verification (Claim 25 Coins)</span>
                    </>
                  ) : (
                    <>
                      <Clock className="w-4 h-4" />
                      <span>Watch in progress ({formatTime(requiredSeconds - elapsedSeconds)} remaining)</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
