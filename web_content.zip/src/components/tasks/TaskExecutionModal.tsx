import React, { useState, useEffect } from 'react';
import { 
  X, 
  Clock, 
  ExternalLink, 
  AlertCircle, 
  Sparkles, 
  CheckCircle2, 
  Send,
  Activity,
  Check,
  ListChecks,
  Hourglass,
  Camera,
  Upload
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { Task } from '../../types';

interface TaskExecutionModalProps {
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
}

const TOTAL_TIMER_SECONDS = 6; // Focus review timer in seconds

export const TaskExecutionModal: React.FC<TaskExecutionModalProps> = ({ task, isOpen, onClose }) => {
  const { 
    currentUser, 
    membershipPlans, 
    submitTaskCompletion, 
    taskSubmissions,
    language, 
    t 
  } = useApp();

  const [timerSeconds, setTimerSeconds] = useState(TOTAL_TIMER_SECONDS);
  const [timerFinished, setTimerFinished] = useState(false);
  const [visitedExternalLink, setVisitedExternalLink] = useState(false);
  const [proofText, setProofText] = useState('');
  const [proofScreenshot, setProofScreenshot] = useState<string | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && task) {
      setTimerSeconds(TOTAL_TIMER_SECONDS);
      setTimerFinished(false);
      setVisitedExternalLink(false);
      setProofText('');
      setProofScreenshot(null);
      setQuizAnswers(task.quizQuestions ? new Array(task.quizQuestions.length).fill(-1) : []);
      setErrorMessage('');
    }
  }, [isOpen, task]);

  const handleProofFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvt) => {
        setProofScreenshot(uploadEvt.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Countdown timer
  useEffect(() => {
    if (!isOpen || timerFinished) return;
    if (timerSeconds <= 0) {
      setTimerFinished(true);
      return;
    }
    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          setTimerFinished(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, timerSeconds, timerFinished]);

  if (!isOpen || !task) return null;

  const currentPlan = currentUser
    ? membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0]
    : membershipPlans[0];

  const title = language === 'bn' && task.titleBn ? task.titleBn : task.title;
  const description = language === 'bn' && task.descriptionBn ? task.descriptionBn : task.description;
  const finalReward = Math.round(task.rewardCoins * currentPlan.rewardMultiplier);

  // Time spent & step metrics
  const timeElapsed = TOTAL_TIMER_SECONDS - timerSeconds;
  const isTimeComplete = timerFinished || timerSeconds <= 0;
  const timeProgress = isTimeComplete 
    ? 100 
    : Math.min(100, Math.max(0, Math.round((timeElapsed / TOTAL_TIMER_SECONDS) * 100)));

  // External task metrics
  const isExternalTask = Boolean(task.isExternal && task.externalUrl);
  const isExternalComplete = !isExternalTask || visitedExternalLink;
  const externalProgress = isExternalTask ? (visitedExternalLink ? 100 : 0) : 100;

  // Quiz questions metrics
  const hasQuiz = Boolean(task.quizQuestions && task.quizQuestions.length > 0);
  const totalQuestions = task.quizQuestions ? task.quizQuestions.length : 0;
  const answeredQuestions = quizAnswers.filter(a => a !== -1).length;
  const isQuizComplete = !hasQuiz || (answeredQuestions === totalQuestions);
  const quizProgress = hasQuiz && totalQuestions > 0 
    ? Math.round((answeredQuestions / totalQuestions) * 100) 
    : 100;

  // Proof requirement metrics
  const hasProof = Boolean(task.requiresProof && !task.quizQuestions);
  const isProofComplete = !hasProof || (proofScreenshot !== null);
  const proofProgress = hasProof ? (isProofComplete ? 100 : 0) : 100;

  // Multi-step array for step-by-step progress tracking
  interface TaskStepItem {
    id: string;
    title: string;
    detail: string;
    isComplete: boolean;
    percentage: number;
    icon: React.ReactNode;
  }

  const steps: TaskStepItem[] = [
    {
      id: 'timer',
      title: t('stepTime'),
      detail: isTimeComplete ? 'Done (6s)' : `${timeElapsed}s / ${TOTAL_TIMER_SECONDS}s`,
      isComplete: isTimeComplete,
      percentage: timeProgress,
      icon: <Clock className="w-3.5 h-3.5" />,
    }
  ];

  if (isExternalTask) {
    steps.push({
      id: 'external',
      title: t('stepVisit'),
      detail: visitedExternalLink ? 'Visited ✓' : 'Click link',
      isComplete: visitedExternalLink,
      percentage: externalProgress,
      icon: <ExternalLink className="w-3.5 h-3.5" />,
    });
  }

  if (hasQuiz) {
    steps.push({
      id: 'quiz',
      title: t('stepQuiz'),
      detail: `${answeredQuestions}/${totalQuestions} answered`,
      isComplete: isQuizComplete,
      percentage: quizProgress,
      icon: <ListChecks className="w-3.5 h-3.5" />,
    });
  }

  if (hasProof) {
    steps.push({
      id: 'proof',
      title: 'Upload Proof',
      detail: isProofComplete ? 'Screenshot Uploaded ✓' : 'Screenshot Required',
      isComplete: isProofComplete,
      percentage: proofProgress,
      icon: <Camera className="w-3.5 h-3.5" />,
    });
  }

  // Calculate weighted overall completion status
  const sumPercentages = steps.reduce((sum, s) => sum + s.percentage, 0);
  const overallProgress = Math.min(100, Math.round(sumPercentages / steps.length));
  const completedStepsCount = steps.filter(s => s.isComplete).length;
  const allStepsComplete = completedStepsCount === steps.length;

  const handleQuizAnswer = (qIndex: number, optIndex: number) => {
    const updated = [...quizAnswers];
    updated[qIndex] = optIndex;
    setQuizAnswers(updated);
  };

  const handleSubmit = () => {
    setErrorMessage('');

    // Check timer requirement
    if (!isTimeComplete) {
      setErrorMessage(
        language === 'bn' 
          ? `অনুগ্রহ করে টাস্কে অন্তত আরও ${timerSeconds} সেকেন্ড সময় ব্যয় করুন।`
          : `Please review the task for at least ${timerSeconds} more seconds.`
      );
      return;
    }

    // Check external link visit requirement
    if (isExternalTask && !visitedExternalLink) {
      setErrorMessage(
        language === 'bn'
          ? 'অনুগ্রহ করে প্রথমে অফিশিয়াল পোর্টাল লিংকে ভিজিট করুন।'
          : 'Please visit the official partner portal link before submitting.'
      );
      return;
    }

    // Check quiz answers
    if (task.quizQuestions && task.quizQuestions.length > 0) {
      const anyUnanswered = quizAnswers.some(a => a === -1);
      if (anyUnanswered) {
        setErrorMessage(language === 'bn' ? 'অনুগ্রহ করে সকল কুইজ প্রশ্নের উত্তর দিন।' : 'Please answer all quiz questions.');
        return;
      }
      // Check correctness
      const incorrect = task.quizQuestions.some((q, i) => q.correctIndex !== quizAnswers[i]);
      if (incorrect) {
        setErrorMessage(
          language === 'bn' 
            ? 'কিছু উত্তর ভুল হয়েছে! অনুগ্রহ করে সঠিক উত্তরটি পুনরায় নির্বাচন করুন।' 
            : 'One or more quiz answers are incorrect. Review and select the right answers!'
        );
        return;
      }
    }

    // Check proof requirement
    if (task.requiresProof && !task.quizQuestions && !proofScreenshot) {
      setErrorMessage(language === 'bn' ? 'অনুগ্রহ করে টাস্ক সম্পন্ন করার একটি স্ক্রিনশট প্রমাণ হিসেবে আপলোড করুন।' : 'Please upload a screenshot proof of your completed task to receive coins.');
      return;
    }

    setIsSubmitting(true);
    const fullProof = proofScreenshot ? `${proofText ? proofText + ' | ' : ''}[Screenshot: Provided]` : proofText;
    const result = submitTaskCompletion(task.id, fullProof, undefined, proofScreenshot || undefined);
    setIsSubmitting(false);

    if (result.success) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
      onClose();
    } else {
      setErrorMessage(result.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl relative max-h-[90vh] flex flex-col"
        role="dialog"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Task Header */}
        <div className="space-y-1.5 mb-3 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400">
              {task.category.replace('_', ' ')}
            </span>
            {task.isExternal && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300">
                {t('externalTask')}
              </span>
            )}
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 ml-auto flex items-center gap-1">
              <span>🪙</span> +{finalReward} ({currentPlan.rewardMultiplier}x Tier)
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
            {title}
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {description}
          </p>
        </div>

        {/* Visual Progress Bar Section */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/90 dark:border-slate-700/80 mb-3.5 shrink-0 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className={`p-1.5 rounded-lg transition-colors ${
                allStepsComplete 
                  ? 'bg-emerald-500 text-white shadow-xs' 
                  : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
              }`}>
                {allStepsComplete ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <Activity className="w-4 h-4 animate-pulse" />
                )}
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  {t('taskProgress')}
                </h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  {allStepsComplete 
                    ? (language === 'bn' ? 'সকল ধাপ সম্পন্ন হয়েছে! জমা দিন।' : 'All requirements met! Ready to submit.')
                    : (language === 'bn' 
                        ? `${completedStepsCount}/${steps.length} টি ধাপ সম্পন্ন (${overallProgress}%)` 
                        : `${completedStepsCount} of ${steps.length} steps completed (${overallProgress}%)`)}
                </p>
              </div>
            </div>

            {/* Dynamic Status / Percentage Badge */}
            <div className={`px-2.5 py-1 rounded-full text-xs font-black tracking-tight flex items-center gap-1.5 transition-all shadow-xs ${
              allStepsComplete 
                ? 'bg-emerald-500 text-white shadow-emerald-500/30 ring-2 ring-emerald-400/40' 
                : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
            }`}>
              {allStepsComplete ? (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" style={{ animationDuration: '6s' }} />
                  <span>100% {t('readyToSubmit')}</span>
                </>
              ) : (
                <>
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  <span>{overallProgress}%</span>
                </>
              )}
            </div>
          </div>

          {/* Progress Bar Track */}
          <div className="relative h-3 w-full bg-slate-200/90 dark:bg-slate-700/80 rounded-full overflow-hidden p-0.5 shadow-inner">
            <div 
              className={`h-full rounded-full transition-all duration-300 ease-out relative ${
                allStepsComplete
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400'
                  : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-500'
              }`}
              style={{ width: `${overallProgress}%` }}
            >
              {/* Glossy shimmer effect */}
              <div className="absolute inset-0 bg-white/20 animate-pulse" />
            </div>
          </div>

          {/* Micro-steps Pills Breakdown */}
          <div className="flex flex-wrap items-center gap-1.5 mt-2.5 pt-2 border-t border-slate-200/70 dark:border-slate-700/60 text-[10px]">
            {steps.map(step => (
              <div 
                key={step.id}
                className={`flex items-center gap-1.5 px-2 py-0.5 rounded-lg border transition-all ${
                  step.isComplete
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-semibold'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400'
                }`}
              >
                {step.isComplete ? (
                  <Check className="w-3 h-3 text-emerald-500 stroke-[3]" />
                ) : (
                  step.icon
                )}
                <span>{step.title}:</span>
                <span className={step.isComplete ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-300 font-medium'}>
                  {step.detail}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4 text-xs">
          
          {/* External Task Banner & Link */}
          {task.isExternal && task.externalUrl && (
            <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
                  <ExternalLink className="w-4 h-4 text-blue-600" />
                  {task.externalPlatform || 'Official Partner Portal'}
                </span>
                <span className="text-[10px] uppercase font-bold text-blue-600 dark:text-blue-400">
                  {t('externalTask')}
                </span>
              </div>
              <p className="text-blue-700 dark:text-blue-300 text-[11px] leading-relaxed">
                Click below to visit the official portal. Review the content, then return to claim your reward.
              </p>
              <div className="flex items-center gap-3">
                <a
                  href={task.externalUrl}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => setVisitedExternalLink(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                >
                  <span>Visit {task.externalPlatform || 'Portal'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                {visitedExternalLink ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2.5 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Portal Visited
                  </span>
                ) : (
                  <span className="text-[10px] text-blue-600/80 dark:text-blue-400 italic">
                    (Click to fulfill portal step)
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Quiz Component if applicable */}
          {task.quizQuestions && task.quizQuestions.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                  {language === 'bn' ? 'কুইজ প্রশ্নের উত্তর দিন:' : 'Answer the Questions:'}
                </h3>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  {answeredQuestions}/{totalQuestions} Answered
                </span>
              </div>
              {task.quizQuestions.map((q, qIndex) => {
                const qText = language === 'bn' && q.questionBn ? q.questionBn : q.question;
                return (
                  <div key={qIndex} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2">
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {qIndex + 1}. {qText}
                    </p>
                    <div className="space-y-1.5 pt-1">
                      {q.options.map((opt, optIndex) => (
                        <label
                          key={optIndex}
                          className={`flex items-center gap-2.5 p-2 rounded-lg border transition-all cursor-pointer ${
                            quizAnswers[qIndex] === optIndex
                              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 text-emerald-900 dark:text-emerald-200 font-semibold'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`quiz-${qIndex}`}
                            checked={quizAnswers[qIndex] === optIndex}
                            onChange={() => handleQuizAnswer(qIndex, optIndex)}
                            className="text-emerald-600 focus:ring-emerald-500"
                          />
                          <span>{opt}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Submission Review Workflow: Upload Proof Component & History */}
          {task.requiresProof && !task.quizQuestions && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 dark:bg-emerald-950/30 border border-emerald-500/30 space-y-3.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5 text-xs">
                  <Camera className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  Task Completion Screenshot Proof
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-700 dark:text-emerald-300">
                  Required for Coins
                </span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                {task.proofInstructions || 'Upload a clear screenshot showing your completed task (e.g. video watch screen, like/comment proof, survey success) to receive your reward coins.'}
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <label className="w-full flex-1 flex flex-col items-center justify-center p-4 border-2 border-dashed border-emerald-500/40 rounded-2xl bg-white dark:bg-slate-900/60 hover:bg-emerald-50/50 dark:hover:bg-slate-900 cursor-pointer transition-all group shadow-xs">
                  <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300 group-hover:text-emerald-800 dark:group-hover:text-emerald-200">
                    <Upload className="w-5 h-5 animate-pulse" />
                    <span className="text-xs font-bold">
                      {proofScreenshot ? 'Change Proof Screenshot' : 'Upload Completed Task Screenshot'}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">PNG, JPG, WEBP up to 10MB</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleProofFileChange}
                    className="hidden"
                  />
                </label>

                {proofScreenshot && (
                  <div className="relative w-20 h-20 rounded-xl overflow-hidden border-2 border-emerald-500 shadow-md shrink-0 bg-slate-950">
                    <img src={proofScreenshot} alt="Proof" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setProofScreenshot(null)}
                      className="absolute top-1 right-1 p-1 bg-red-600 text-white rounded-full text-[9px] hover:bg-red-700 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                )}
              </div>

              {/* Optional verification text / username */}
              <input
                type="text"
                value={proofText}
                onChange={(e) => setProofText(e.target.value)}
                placeholder="Optional username, email or verification comment..."
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs focus:outline-emerald-500 shadow-inner"
              />

              {/* Submission History & Status List */}
              {currentUser && taskSubmissions.filter(s => s.userId === currentUser.id && s.taskId === task.id).length > 0 && (
                <div className="mt-4 pt-3 border-t border-emerald-500/20 space-y-2.5">
                  <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <ListChecks className="w-3.5 h-3.5 text-emerald-600" />
                    Your Proof Submissions History ({taskSubmissions.filter(s => s.userId === currentUser.id && s.taskId === task.id).length})
                  </h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {taskSubmissions
                      .filter(s => s.userId === currentUser.id && s.taskId === task.id)
                      .map(sub => {
                        const isPending = sub.status === 'pending_verification';
                        const isVerified = sub.status === 'completed';
                        const isRejected = sub.status === 'rejected';

                        return (
                          <div 
                            key={sub.id} 
                            className={`p-2.5 rounded-xl border text-[11px] flex items-center justify-between gap-3 ${
                              isVerified 
                                ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800'
                                : isRejected
                                  ? 'bg-rose-50/80 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800'
                                  : 'bg-amber-50/80 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              {sub.proofUrl ? (
                                <img src={sub.proofUrl} alt="Proof" className="w-10 h-10 rounded-lg object-cover border border-slate-300 dark:border-slate-700 shrink-0" />
                              ) : (
                                <div className="w-10 h-10 rounded-lg bg-slate-200 dark:bg-slate-800 flex items-center justify-center shrink-0 text-slate-500">
                                  <Camera className="w-4 h-4" />
                                </div>
                              )}
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 font-semibold">
                                  <span>{new Date(sub.completedAt).toLocaleDateString()} {new Date(sub.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                  <span className="text-emerald-700 dark:text-emerald-300 font-bold">+{sub.rewardCoins}🪙</span>
                                </div>
                                <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                                  {sub.proofText || 'Screenshot proof submitted'}
                                </p>
                                {sub.adminRemark && (
                                  <p className="text-[10px] text-rose-600 dark:text-rose-400 font-medium italic mt-0.5">
                                    Admin: {sub.adminRemark}
                                  </p>
                                )}
                              </div>
                            </div>

                            {/* Visual Status Indicator Badge */}
                            <div className="shrink-0">
                              {isVerified && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 font-bold text-[10px] border border-emerald-300 dark:border-emerald-700">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                                  Verified
                                </span>
                              )}
                              {isPending && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 font-bold text-[10px] border border-amber-300 dark:border-amber-700">
                                  <Hourglass className="w-3 h-3 text-amber-600 dark:text-amber-400 animate-spin" />
                                  Pending Approval
                                </span>
                              )}
                              {isRejected && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 font-bold text-[10px] border border-rose-300 dark:border-rose-700">
                                  <AlertCircle className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                                  Rejected
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Focus Timer Status Box with Live Bar */}
          <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800/90 border border-slate-200/80 dark:border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-700 dark:text-slate-200 font-medium">
                <Clock className={`w-4 h-4 ${isTimeComplete ? 'text-emerald-500' : 'text-amber-500'}`} />
                {t('timerRemaining')}
              </span>
              <span className={`font-mono font-bold px-2 py-0.5 rounded-md text-xs ${
                isTimeComplete 
                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-slate-100'
              }`}>
                {isTimeComplete ? '00:00 (Completed ✓)' : `00:0${timerSeconds}s`}
              </span>
            </div>
            {/* Live timer progress bar */}
            <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500 rounded-full transition-all duration-300 ease-linear"
                style={{ width: `${timeProgress}%` }}
              />
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-medium">
              {errorMessage}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            {t('cancel')}
          </button>

          <button
            type="button"
            onClick={handleSubmit}
            disabled={!allStepsComplete || isSubmitting}
            className={`px-6 py-2.5 rounded-xl text-white font-bold text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer ${
              allStepsComplete 
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-emerald-600/25 active:scale-95' 
                : 'bg-slate-400 dark:bg-slate-700 opacity-60 cursor-not-allowed shadow-none'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>
              {isSubmitting 
                ? t('loading') 
                : allStepsComplete 
                  ? t('submitTask') 
                  : `${language === 'bn' ? 'ধাপ সম্পন্ন করুন' : 'Complete Steps'} (${overallProgress}%)`}
            </span>
          </button>
        </div>

      </div>
    </div>
  );
};
