import { useEffect, useState } from "react";
import { useCaliber } from "@/lib/store";

const STEPS_EN = ["CPU / SoC", "GPU renderer", "Memory map", "Display modes", "Battery + thermal", "Scoring engine"];
const STEPS_AR = ["المعالج", "المعالج الرسومي", "خريطة الذاكرة", "أوضاع الشاشة", "البطارية والحرارة", "محرك التقييم"];

export function ScanOverlay() {
  const { dict, lang } = useCaliber();
  const steps = lang === "ar" ? STEPS_AR : STEPS_EN;
  const [i, setI] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => setI((n) => Math.min(n + 1, steps.length - 1)), 380);
    return () => window.clearInterval(id);
  }, [steps.length]);

  return (
    <div className="relative flex min-h-dvh flex-col items-center justify-center px-6">
      <div className="relative h-64 w-40 overflow-hidden rounded-[28px] bg-surface shadow-[var(--shadow-border)]">
        <div className="absolute inset-x-8 top-3 h-4 rounded-full bg-bg" />
        <div className="scan-line absolute inset-x-0 h-24" />
        <div className="absolute inset-6 top-10 space-y-2">
          {steps.map((step, idx) => (
            <div
              key={step}
              className="flex items-center gap-2 text-[11px] uppercase tracking-[0.14em]"
              style={{ opacity: idx <= i ? 1 : 0.28 }}
            >
              <span className={`size-1.5 rounded-full ${idx <= i ? "bg-primary" : "bg-subtle"}`} />
              <span className={idx <= i ? "text-fg" : "text-subtle"}>{step}</span>
            </div>
          ))}
        </div>
      </div>
      <p className="mt-6 font-display text-2xl font-semibold tracking-wide text-primary">{dict.scanning}</p>
      <p className="mt-1 text-xs text-muted">{steps[i]}</p>
    </div>
  );
}
