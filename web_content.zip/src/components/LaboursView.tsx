import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Labour, LabourRoleType } from '../types';
import { formatCurrency, formatNumber, formatDateBengali, getRoleTypeBadge } from '../utils/formatters';
import { 
  Users, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Phone, 
  Briefcase, 
  Home, 
  Calendar,
  X,
  UserCheck
} from 'lucide-react';

export const LaboursView: React.FC = () => {
  const { 
    labours, 
    sites, 
    addLabour, 
    updateLabour, 
    deleteLabour 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingLabour, setEditingLabour] = useState<Labour | null>(null);

  const [form, setForm] = useState({
    name: '',
    phone: '',
    trade: 'হেড রাজমিস্ত্রি',
    roleType: 'mess_and_site' as LabourRoleType,
    assignedSiteId: sites[0]?.id || '',
    dailyWageRate: 650,
    messStayStartDate: new Date().toISOString().slice(0, 10),
    messStayEndDate: '',
    isActive: true,
    notes: ''
  });

  // Role Counts
  const totalLabours = labours.length;
  const messAndSiteCount = labours.filter(l => l.roleType === 'mess_and_site').length;
  const messOnlyCount = labours.filter(l => l.roleType === 'mess_only').length;
  const siteOnlyCount = labours.filter(l => l.roleType === 'site_only').length;
  const totalMessMembers = messAndSiteCount + messOnlyCount;

  // Filtered Labours
  const filteredLabours = labours.filter(l => {
    if (roleFilter !== 'all' && l.roleType !== roleFilter) return false;
    if (searchQuery) {
      return (
        l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        l.trade.toLowerCase().includes(searchQuery.toLowerCase()) ||
        l.phone.includes(searchQuery)
      );
    }
    return true;
  });

  const openAddModal = () => {
    setEditingLabour(null);
    setForm({
      name: '',
      phone: '',
      trade: 'হেড রাজমিস্ত্রি',
      roleType: 'mess_and_site',
      assignedSiteId: sites[0]?.id || '',
      dailyWageRate: 650,
      messStayStartDate: new Date().toISOString().slice(0, 10),
      messStayEndDate: '',
      isActive: true,
      notes: ''
    });
    setShowAddModal(true);
  };

  const openEditModal = (labour: Labour) => {
    setEditingLabour(labour);
    setForm({
      name: labour.name,
      phone: labour.phone,
      trade: labour.trade,
      roleType: labour.roleType,
      assignedSiteId: labour.assignedSiteId || '',
      dailyWageRate: labour.dailyWageRate,
      messStayStartDate: labour.messStayStartDate || new Date().toISOString().slice(0, 10),
      messStayEndDate: labour.messStayEndDate || '',
      isActive: labour.isActive,
      notes: labour.notes || ''
    });
    setShowAddModal(true);
  };

  return (
    <div className="space-y-6">
      
      {/* হেডার ও মেট্রিক্স কার্ডস */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-slate-500">মোট নথিভুক্ত লেবার</span>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {formatNumber(totalLabours)} জন
          </div>
          <span className="block text-[10px] text-slate-400 mt-0.5">মাস্টার ডিরেক্টরি</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-emerald-800">মেসে থাকে ও সাইটে কাজ করে</span>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-emerald-700">
            {formatNumber(messAndSiteCount)} জন
          </div>
          <span className="block text-[10px] text-emerald-600 mt-0.5">সাইট মজুরি ও মেস শেয়ার</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-amber-800">মেসে থাকে কিন্তু বাইরে কাজ করে</span>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-amber-700">
            {formatNumber(messOnlyCount)} জন
          </div>
          <span className="block text-[10px] text-amber-600 mt-0.5">শুধুমাত্র মেস ও রুম ভাড়া দেয়</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="block text-xs font-medium text-blue-800">সাইটে কাজ করে (মেসে থাকে না)</span>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-blue-700">
            {formatNumber(siteOnlyCount)} জন
          </div>
          <span className="block text-[10px] text-blue-600 mt-0.5">স্থানীয় বাড়ি থেকে যাতায়াত</span>
        </div>

      </div>

      {/* সার্চ ও ফিল্টার বার */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-slate-500 font-medium mr-1">স্ট্যাটাস:</span>
          <button
            onClick={() => setRoleFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              roleFilter === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            সব লেবার ({totalLabours})
          </button>
          <button
            onClick={() => setRoleFilter('mess_and_site')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              roleFilter === 'mess_and_site'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            মেসে ও সাইটে ({messAndSiteCount})
          </button>
          <button
            onClick={() => setRoleFilter('mess_only')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              roleFilter === 'mess_only'
                ? 'bg-amber-700 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            মেসে থাকে কিন্তু বাইরে কাজ ({messOnlyCount})
          </button>
          <button
            onClick={() => setRoleFilter('site_only')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              roleFilter === 'site_only'
                ? 'bg-blue-700 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            সাইটে স্থানীয় লেবার ({siteOnlyCount})
          </button>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="নাম, ফোন বা পদবি খুঁজুন..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 w-48 sm:w-56"
            />
          </div>

          <button
            onClick={openAddModal}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-medium rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন লেবার যোগ</span>
          </button>
        </div>
      </div>

      {/* লেবার ডিরেক্টরি টেবিল */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-semibold">
              <tr>
                <th className="py-3 px-4">লেবারের নাম ও ফোন</th>
                <th className="py-3 px-3">ট্রেড / পদবি</th>
                <th className="py-3 px-4">কাজের ধরন ও থাকার স্ট্যাটাস</th>
                <th className="py-3 px-3 text-right">দৈনিক মজুরি রেট (₹)</th>
                <th className="py-3 px-3">মেসে থাকার সময়কাল</th>
                <th className="py-3 px-3">যুক্ত সাইট</th>
                <th className="py-3 px-4 text-center">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLabours.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    কোনো লেবার রেকর্ড পাওয়া যায়নি।
                  </td>
                </tr>
              ) : (
                filteredLabours.map(labour => {
                  const roleBadge = getRoleTypeBadge(labour.roleType);
                  const assignedSite = sites.find(s => s.id === labour.assignedSiteId);

                  return (
                    <tr key={labour.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{labour.name}</div>
                        <a 
                          href={`tel:${labour.phone}`}
                          className="text-[11px] font-mono text-slate-500 hover:text-amber-700 flex items-center gap-1 mt-0.5"
                        >
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{labour.phone}</span>
                        </a>
                      </td>

                      <td className="py-3 px-3 font-medium text-slate-800">
                        {labour.trade}
                      </td>

                      <td className="py-3 px-4">
                        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium border ${roleBadge.badgeClass}`}>
                          {roleBadge.label}
                        </span>
                        {labour.notes && (
                          <div className="text-[10px] text-slate-400 mt-0.5 max-w-xs truncate">{labour.notes}</div>
                        )}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                        {formatCurrency(labour.dailyWageRate)}
                      </td>

                      <td className="py-3 px-3 text-xs text-slate-600 font-mono whitespace-nowrap">
                        {labour.roleType === 'site_only' ? (
                          <span className="text-slate-400">মেসে থাকে না</span>
                        ) : (
                          <div>
                            <div>শুরু: {formatDateBengali(labour.messStayStartDate)}</div>
                            {labour.messStayEndDate ? (
                              <div className="text-rose-600">শেষ: {formatDateBengali(labour.messStayEndDate)}</div>
                            ) : (
                              <div className="text-emerald-700 text-[10px]">চলতি রয়েছে</div>
                            )}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-3 text-xs text-slate-700">
                        {assignedSite ? assignedSite.name : <span className="text-slate-400">কোনো নির্দিষ্ট সাইট নেই</span>}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => openEditModal(labour)}
                            className="p-1.5 text-slate-500 hover:text-amber-700 rounded transition-colors"
                            title="এডিট করুন"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteLabour(labour.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded transition-colors"
                            title="মুছুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* নতুন লেবার যোগ ও এডিট মডাল */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                {editingLabour ? 'লেবার প্রোফাইল এডিট করুন' : 'নতুন লেবার নথিভুক্তকরণ'}
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                if (!form.name.trim()) return;

                if (editingLabour) {
                  updateLabour(editingLabour.id, {
                    name: form.name,
                    phone: form.phone,
                    trade: form.trade,
                    roleType: form.roleType,
                    assignedSiteId: form.assignedSiteId || undefined,
                    dailyWageRate: Number(form.dailyWageRate),
                    messStayStartDate: form.messStayStartDate,
                    messStayEndDate: form.messStayEndDate || null,
                    isActive: form.isActive,
                    notes: form.notes
                  });
                } else {
                  addLabour({
                    name: form.name,
                    phone: form.phone,
                    trade: form.trade,
                    roleType: form.roleType,
                    assignedSiteId: form.assignedSiteId || undefined,
                    dailyWageRate: Number(form.dailyWageRate),
                    messStayStartDate: form.messStayStartDate,
                    messStayEndDate: form.messStayEndDate || null,
                    isActive: form.isActive,
                    notes: form.notes
                  });
                }
                setShowAddModal(false);
              }}
              className="space-y-4 mt-4 text-xs sm:text-sm"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">লেবারের নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: স্বপন মণ্ডল"
                    value={form.name}
                    onChange={e => setForm({ ...form, name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">ফোন নম্বর *</label>
                  <input
                    type="text"
                    required
                    placeholder="৯৭৪৮০১১২২৩"
                    value={form.phone}
                    onChange={e => setForm({ ...form, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">ট্রেড / পদবি *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: হেড রাজমিস্ত্রি, জোগাড়ে, ইত্যাদি"
                    value={form.trade}
                    onChange={e => setForm({ ...form, trade: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">দৈনিক মজুরি রেট (₹/দিন) *</label>
                  <input
                    type="number"
                    required
                    min="100"
                    step="10"
                    value={form.dailyWageRate}
                    onChange={e => setForm({ ...form, dailyWageRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold"
                  />
                </div>
              </div>

              {/* কাজের ধরন ও মেস স্ট্যাটাস */}
              <div className="bg-amber-50/70 p-3.5 rounded-lg border border-amber-200">
                <label className="block font-bold text-amber-950 mb-1">
                  কাজের ধরন ও মেস স্ট্যাটাস (Role & Status) *
                </label>
                <select
                  value={form.roleType}
                  onChange={e => setForm({ ...form, roleType: e.target.value as any })}
                  className="w-full px-3 py-2 border border-amber-300 rounded-lg bg-white font-medium"
                >
                  <option value="mess_and_site">১. মেসে থাকে ও সাইটে কাজ করে</option>
                  <option value="mess_only">২. মেসে থাকে কিন্তু বাইরে নিজের কাজ খুঁজে খায়</option>
                  <option value="site_only">৩. সাইটে কাজ করে কিন্তু মেসে থাকে না (স্থানীয় লেবার)</option>
                </select>
                <p className="text-[11px] text-amber-800 mt-1">
                  {form.roleType === 'mess_and_site' && 'সাইটের মজুরি পাবে এবং মেসের খাওয়া ও রুম ভাড়ার আওতাভুক্ত।'}
                  {form.roleType === 'mess_only' && 'বাইরে কাজ করবে কিন্তু মেসের সদস্য; বাড়িওয়ালার ভাড়ায় এবং খাবার খরচে গণনা হবে।'}
                  {form.roleType === 'site_only' && 'স্থানীয় লেবার, শুধুমাত্র সাইটের কাজে আসবে; মেসের ভাড়ায় গণনা হবে না।'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">মেসে ওঠার তারিখ (Start)</label>
                  <input
                    type="date"
                    disabled={form.roleType === 'site_only'}
                    value={form.messStayStartDate}
                    onChange={e => setForm({ ...form, messStayStartDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg disabled:bg-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">মেস ছাড়ার তারিখ (Exit - ঐচ্ছিক)</label>
                  <input
                    type="date"
                    disabled={form.roleType === 'site_only'}
                    value={form.messStayEndDate}
                    onChange={e => setForm({ ...form, messStayEndDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg disabled:bg-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">প্রধান সাইট নির্ধারণ</label>
                <select
                  value={form.assignedSiteId}
                  onChange={e => setForm({ ...form, assignedSiteId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                >
                  <option value="">-- কোনো নির্দিষ্ট সাইট নেই --</option>
                  {sites.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">নোট / মন্তব্য</label>
                <input
                  type="text"
                  placeholder="যেমন: অভিজ্ঞ মিস্ত্রি, বিশেষ দক্ষতা"
                  value={form.notes}
                  onChange={e => setForm({ ...form, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
                >
                  {editingLabour ? 'আপডেট সংরক্ষণ' : 'লেবার সংরক্ষণ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
