import React, { useState, useEffect } from 'react';
import { Clock, RefreshCw } from 'lucide-react';

interface CountdownBadgeProps {
  expiresAt: string;
  onExtend?: () => void;
  showExtendButton?: boolean;
}

export const CountdownBadge: React.FC<CountdownBadgeProps> = ({
  expiresAt,
  onExtend,
  showExtendButton = true,
}) => {
  const [timeLeft, setTimeLeft] = useState<{ hours: number; minutes: number; seconds: number; isExpired: boolean }>({
    hours: 0,
    minutes: 0,
    seconds: 0,
    isExpired: false,
  });

  useEffect(() => {
    function calculate() {
      const diff = new Date(expiresAt).getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0, isExpired: true });
        return;
      }
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setTimeLeft({ hours, minutes, seconds, isExpired: false });
    }

    calculate();
    const interval = setInterval(calculate, 1000);
    return () => clearInterval(interval);
  }, [expiresAt]);

  const pad = (n: number) => n.toString().padStart(2, '0');

  const isUrgent = !timeLeft.isExpired && timeLeft.hours === 0 && timeLeft.minutes < 15;

  return (
    <div className="inline-flex items-center gap-1.5">
      <div
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-semibold border transition-colors ${
          timeLeft.isExpired
            ? 'bg-rose-50 border-rose-200 text-rose-600'
            : isUrgent
            ? 'bg-amber-50 border-amber-300 text-amber-700 animate-pulse'
            : 'bg-blue-50/80 border-blue-200 text-blue-700'
        }`}
      >
        <Clock className="w-3.5 h-3.5" />
        <span>
          {timeLeft.isExpired
            ? 'Expired'
            : `${pad(timeLeft.hours)}h ${pad(timeLeft.minutes)}m ${pad(timeLeft.seconds)}s`}
        </span>
      </div>

      {showExtendButton && onExtend && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onExtend();
          }}
          className="p-1 rounded-full bg-white hover:bg-blue-50 text-slate-500 hover:text-blue-600 border border-slate-200 hover:border-blue-300 transition-all text-xs cursor-pointer shadow-2xs"
          title="Extend by 24 hours"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
};
