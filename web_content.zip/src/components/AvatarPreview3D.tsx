import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { AvatarConfig, EmoteId } from '../types/game';
import { createAvatarRig, AvatarRig } from '../engine/avatar';

interface AvatarPreview3DProps {
  avatar: AvatarConfig;
  animMode?: 'idle' | 'walk' | 'jump' | 'emote';
  previewEmote?: EmoteId | null;
  nameTag?: string;
  isPlus?: boolean;
  className?: string;
}

export const AvatarPreview3D: React.FC<AvatarPreview3DProps> = ({
  avatar,
  animMode = 'idle',
  previewEmote = null,
  nameTag,
  isPlus = false,
  className = '',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rigRef = useRef<AvatarRig | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const requestRenderRef = useRef<(() => void) | null>(null);
  const startLoopRef = useRef<(() => void) | null>(null);
  const avatarRef = useRef(avatar);
  avatarRef.current = avatar;
  const animModeRef = useRef(animMode);
  animModeRef.current = animMode;
  const previewEmoteRef = useRef(previewEmote);
  previewEmoteRef.current = previewEmote;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas');
        const gl = probe.getContext('webgl2') || probe.getContext('webgl');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const gpu = String(gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth || 400, container.clientHeight || 280);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmrem.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(
      38,
      (container.clientWidth || 400) / (container.clientHeight || 280),
      0.1,
      100
    );
    camera.position.set(0, 2.05, 6.6);
    camera.lookAt(0, 1.55, 0);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x94a3b8, 1.1));
    const key = new THREE.DirectionalLight(0xfffbeb, 1.35);
    key.position.set(4, 7, 5);
    scene.add(key);

    const pillarMat = new THREE.MeshStandardMaterial({ color: 0xe4e4e7, roughness: 0.8 });
    const pillarGeo = new THREE.BoxGeometry(1.1, 8, 1.1);
    [
      [-2.8, 2, -3.5],
      [2.8, 2, -3.5],
      [0, 2, -4.5],
    ].forEach(([px, py, pz]) => {
      const m = new THREE.Mesh(pillarGeo, pillarMat);
      m.position.set(px, py, pz);
      scene.add(m);
    });

    const discGeo = new THREE.CircleGeometry(1.45, 32);
    const discMat = new THREE.MeshBasicMaterial({ color: 0x71717a, transparent: true, opacity: 0.4 });
    const disc = new THREE.Mesh(discGeo, discMat);
    disc.rotation.x = -Math.PI / 2;
    disc.position.y = 0.01;
    scene.add(disc);

    const rig = createAvatarRig(avatarRef.current, nameTag);
    if (nameTag) rig.setNameTag(nameTag, isPlus);
    rig.root.rotation.y = 0.35;
    scene.add(rig.root);
    rigRef.current = rig;

    const applyBg = (bgStyle: AvatarConfig['bgStyle']) => {
      if (bgStyle === 'dark') scene.background = new THREE.Color('#09090b');
      else if (bgStyle === 'sunset') scene.background = new THREE.Color('#fdba74');
      else if (bgStyle === 'ocean') scene.background = new THREE.Color('#7dd3fc');
      else scene.background = new THREE.Color('#f4f4f5');
    };
    applyBg(avatarRef.current.bgStyle);

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let loopRunning = false;
    let disposed = false;
    let lastTime = performance.now();
    let jumpTimer = 0;
    let emoteTimer = 0;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const st = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (st === gl.UNSIGNALED) frameId = window.setTimeout(poll, 5);
        else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const needsContinuousLoop = () => true;

    const requestRender = () => {
      if (disposed || loopRunning) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;
        renderer.render(scene, camera);
        const done = () => {
          renderBusy = false;
          if (renderDirty) requestRender();
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    };
    requestRenderRef.current = requestRender;

    const tick = () => {
      if (disposed) return;
      if (!needsContinuousLoop()) {
        loopRunning = false;
        rig.root.position.y = 0;
        rig.updateAnimation(
          0.016,
          0,
          true,
          0,
          avatarRef.current.walkAnim,
          avatarRef.current.jumpAnim,
          null,
          0,
          avatarRef.current.idleAnim
        );
        renderer.render(scene, camera);
        return;
      }
      const now = performance.now();
      const dt = Math.min(0.05, Math.max(0.008, (now - lastTime) / 1000));
      lastTime = now;

      if (animModeRef.current === 'emote' && previewEmoteRef.current) {
        emoteTimer += dt;
        rig.root.position.y = 0;
        rig.updateAnimation(
          dt,
          0,
          true,
          0,
          avatarRef.current.walkAnim,
          avatarRef.current.jumpAnim,
          previewEmoteRef.current,
          emoteTimer,
          avatarRef.current.idleAnim
        );
      } else if (animModeRef.current === 'walk') {
        rig.root.position.y = 0;
        rig.updateAnimation(
          dt,
          1.0,
          true,
          0,
          avatarRef.current.walkAnim,
          avatarRef.current.jumpAnim,
          null,
          0,
          avatarRef.current.idleAnim
        );
      } else if (animModeRef.current === 'jump') {
        jumpTimer = (jumpTimer + dt) % 1.35;
        const phase = jumpTimer / 1.35;
        const inAir = phase < 0.78;
        const tAir = phase / 0.78;
        const height = inAir ? Math.sin(tAir * Math.PI) * 1.45 : 0;
        const velY = inAir ? Math.cos(tAir * Math.PI) * 12 : 0;
        rig.root.position.y = height;
        rig.updateAnimation(
          dt,
          0.3,
          !inAir,
          velY,
          avatarRef.current.walkAnim,
          avatarRef.current.jumpAnim,
          null,
          0,
          avatarRef.current.idleAnim
        );
      } else {
        rig.root.position.y = 0;
        rig.updateAnimation(
          dt,
          0,
          true,
          0,
          avatarRef.current.walkAnim,
          avatarRef.current.jumpAnim,
          null,
          0,
          avatarRef.current.idleAnim
        );
      }

      renderer.render(scene, camera);
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    };

    const startLoop = () => {
      if (disposed) return;
      if (!needsContinuousLoop()) {
        loopRunning = false;
        rig.root.position.y = 0;
        rig.updateAnimation(
          0.016,
          0,
          true,
          0,
          avatarRef.current.walkAnim,
          avatarRef.current.jumpAnim,
          null,
          0,
          avatarRef.current.idleAnim
        );
        requestRender();
        return;
      }
      if (!loopRunning) {
        loopRunning = true;
        lastTime = performance.now();
        jumpTimer = 0;
        emoteTimer = 0;
        tick();
      }
    };
    startLoopRef.current = startLoop;
    startLoop();

    let dragging = false;
    let lastX = 0;
    const onDown = (e: PointerEvent) => {
      dragging = true;
      lastX = e.clientX;
    };
    const onMove = (e: PointerEvent) => {
      if (!dragging) return;
      rig.root.rotation.y += (e.clientX - lastX) * 0.014;
      lastX = e.clientX;
      requestRender();
    };
    const onUp = () => {
      dragging = false;
    };
    renderer.domElement.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);

    const onResize = () => {
      const w = container.clientWidth || 400;
      const h = container.clientHeight || 280;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    window.addEventListener('resize', onResize);

    return () => {
      disposed = true;
      loopRunning = false;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      renderer.domElement.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('resize', onResize);
      rig.dispose();
      pillarGeo.dispose();
      pillarMat.dispose();
      discGeo.dispose();
      discMat.dispose();
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  useEffect(() => {
    if (rigRef.current) {
      rigRef.current.updateAppearance(avatar);
    }
    if (sceneRef.current) {
      if (avatar.bgStyle === 'dark') sceneRef.current.background = new THREE.Color('#09090b');
      else if (avatar.bgStyle === 'sunset') sceneRef.current.background = new THREE.Color('#fdba74');
      else if (avatar.bgStyle === 'ocean') sceneRef.current.background = new THREE.Color('#7dd3fc');
      else sceneRef.current.background = new THREE.Color('#f4f4f5');
    }
    startLoopRef.current?.();
    requestRenderRef.current?.();
  }, [avatar]);

  useEffect(() => {
    if (rigRef.current) {
      rigRef.current.setNameTag(nameTag || null, isPlus);
      requestRenderRef.current?.();
    }
  }, [nameTag, isPlus]);

  useEffect(() => {
    startLoopRef.current?.();
  }, [animMode, previewEmote]);

  return <div ref={mountRef} className={`w-full h-full cursor-grab active:cursor-grabbing ${className}`} />;
};
