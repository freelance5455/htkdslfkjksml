import React, { useState } from 'react';
import { X, Sliders, Zap, Check, Send, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';
import { IndicatorConfig, BotSettings } from '../types/trading';
import { soundManager } from '../utils/soundEffects';

interface BotStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  indicators: IndicatorConfig;
  onUpdateIndicators: (config: IndicatorConfig) => void;
  botSettings: BotSettings;
  onUpdateBotSettings: (settings: BotSettings) => void;
}

export const BotStudioModal: React.FC<BotStudioModalProps> = ({
  isOpen,
  onClose,
  indicators,
  onUpdateIndicators,
  botSettings,
  onUpdateBotSettings,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'indicators' | 'bot' | 'webhook'>('indicators');
  const [webhookTestStatus, setWebhookTestStatus] = useState<string | null>(null);

  const handleTestWebhook = async () => {
    setWebhookTestStatus('Transmitting test signal payload...');
    soundManager.playPip();
    try {
      const res = await fetch('/api/quotex-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pair: 'EUR/USD OTC',
          direction: 'CALL',
          amount: botSettings.stakeAmount,
          expirySeconds: 60,
          signalId: 'TEST-SIG-01',
          timestamp: new Date().toISOString(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setWebhookTestStatus(`Transmitted successfully! ID: ${data.executionId}`);
        soundManager.playTradeWon();
      } else {
        setWebhookTestStatus('Failed to deliver webhook');
      }
    } catch {
      setWebhookTestStatus('Webhook error or network timeout');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-xl bg-[#14050d] border border-[#3b1223] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-4 py-3.5 border-b border-[#300f1e] flex items-center justify-between bg-[#190711]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-950 border border-red-500/40 flex items-center justify-center text-red-500">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-100 tracking-wide">
                QUANTUM BOT & INDICATOR STUDIO
              </h2>
              <p className="text-[11px] text-zinc-400">
                Custom technical analysis indicators & 99% sniper bot engine
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-[#2d0e1c] bg-[#10040a] px-3 pt-2 gap-2 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('indicators')}
            className={`py-2 px-3 border-b-2 transition-all ${
              activeTab === 'indicators'
                ? 'border-red-500 text-white font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Custom Indicators
          </button>
          <button
            onClick={() => setActiveTab('bot')}
            className={`py-2 px-3 border-b-2 transition-all flex items-center gap-1 ${
              activeTab === 'bot'
                ? 'border-red-500 text-white font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Zap className="w-3 h-3 text-amber-400" />
            <span>99% Sniper & Execution</span>
          </button>
          <button
            onClick={() => setActiveTab('webhook')}
            className={`py-2 px-3 border-b-2 transition-all ${
              activeTab === 'webhook'
                ? 'border-red-500 text-white font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Quotex Webhook / API
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 overflow-y-auto space-y-4 custom-scrollbar text-xs">
          {activeTab === 'indicators' && (
            <div className="space-y-3.5">
              {/* RSI */}
              <div className="bg-[#1a0711] border border-[#3b1223] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={indicators.rsi.enabled}
                      onChange={(e) =>
                        onUpdateIndicators({
                          ...indicators,
                          rsi: { ...indicators.rsi, enabled: e.target.checked },
                        })
                      }
                      className="accent-red-500 rounded cursor-pointer"
                    />
                    <span className="font-bold text-slate-100">Relative Strength Index (RSI)</span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400">Weight: 20 pts</span>
                </div>
                {indicators.rsi.enabled && (
                  <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-[#2e0e1c]">
                    <div>
                      <label className="text-[10px] text-zinc-400">Period</label>
                      <input
                        type="number"
                        value={indicators.rsi.period}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            rsi: { ...indicators.rsi, period: Number(e.target.value) || 14 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400">Overbought</label>
                      <input
                        type="number"
                        value={indicators.rsi.overbought}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            rsi: { ...indicators.rsi, overbought: Number(e.target.value) || 70 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400">Oversold</label>
                      <input
                        type="number"
                        value={indicators.rsi.oversold}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            rsi: { ...indicators.rsi, oversold: Number(e.target.value) || 30 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Bollinger Bands */}
              <div className="bg-[#1a0711] border border-[#3b1223] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={indicators.bollingerBands.enabled}
                      onChange={(e) =>
                        onUpdateIndicators({
                          ...indicators,
                          bollingerBands: { ...indicators.bollingerBands, enabled: e.target.checked },
                        })
                      }
                      className="accent-red-500 rounded cursor-pointer"
                    />
                    <span className="font-bold text-slate-100">Bollinger Bands Envelope</span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400">Weight: 25 pts</span>
                </div>
                {indicators.bollingerBands.enabled && (
                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-[#2e0e1c]">
                    <div>
                      <label className="text-[10px] text-zinc-400">Period (SMA)</label>
                      <input
                        type="number"
                        value={indicators.bollingerBands.period}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            bollingerBands: { ...indicators.bollingerBands, period: Number(e.target.value) || 20 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400">Standard Deviation</label>
                      <input
                        type="number"
                        step="0.1"
                        value={indicators.bollingerBands.stdDev}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            bollingerBands: { ...indicators.bollingerBands, stdDev: Number(e.target.value) || 2.0 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* MACD */}
              <div className="bg-[#1a0711] border border-[#3b1223] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={indicators.macd.enabled}
                      onChange={(e) =>
                        onUpdateIndicators({
                          ...indicators,
                          macd: { ...indicators.macd, enabled: e.target.checked },
                        })
                      }
                      className="accent-red-500 rounded cursor-pointer"
                    />
                    <span className="font-bold text-slate-100">MACD Histogram & Signal</span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400">Weight: 15 pts</span>
                </div>
                {indicators.macd.enabled && (
                  <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-[#2e0e1c]">
                    <div>
                      <label className="text-[10px] text-zinc-400">Fast EMA</label>
                      <input
                        type="number"
                        value={indicators.macd.fastPeriod}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            macd: { ...indicators.macd, fastPeriod: Number(e.target.value) || 12 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400">Slow EMA</label>
                      <input
                        type="number"
                        value={indicators.macd.slowPeriod}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            macd: { ...indicators.macd, slowPeriod: Number(e.target.value) || 26 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400">Signal EMA</label>
                      <input
                        type="number"
                        value={indicators.macd.signalPeriod}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            macd: { ...indicators.macd, signalPeriod: Number(e.target.value) || 9 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* EMA Cross */}
              <div className="bg-[#1a0711] border border-[#3b1223] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={indicators.emaCross.enabled}
                      onChange={(e) =>
                        onUpdateIndicators({
                          ...indicators,
                          emaCross: { ...indicators.emaCross, enabled: e.target.checked },
                        })
                      }
                      className="accent-red-500 rounded cursor-pointer"
                    />
                    <span className="font-bold text-slate-100">Dual EMA Dynamic Crossover</span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400">Weight: 20 pts</span>
                </div>
                {indicators.emaCross.enabled && (
                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-[#2e0e1c]">
                    <div>
                      <label className="text-[10px] text-zinc-400">Fast EMA</label>
                      <input
                        type="number"
                        value={indicators.emaCross.fastPeriod}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            emaCross: { ...indicators.emaCross, fastPeriod: Number(e.target.value) || 7 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-zinc-400">Slow EMA</label>
                      <input
                        type="number"
                        value={indicators.emaCross.slowPeriod}
                        onChange={(e) =>
                          onUpdateIndicators({
                            ...indicators,
                            emaCross: { ...indicators.emaCross, slowPeriod: Number(e.target.value) || 14 },
                          })
                        }
                        className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1 text-white font-mono mt-0.5"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Candlestick Patterns */}
              <div className="bg-[#1a0711] border border-[#3b1223] rounded-xl p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={indicators.candlestickPatterns.enabled}
                      onChange={(e) =>
                        onUpdateIndicators({
                          ...indicators,
                          candlestickPatterns: { ...indicators.candlestickPatterns, enabled: e.target.checked },
                        })
                      }
                      className="accent-red-500 rounded cursor-pointer"
                    />
                    <span className="font-bold text-slate-100">Candlestick Rejection Patterns</span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400">Weight: 20 pts</span>
                </div>
                <p className="text-[11px] text-zinc-400 mt-1">
                  Detects Pin Bar / Hammer wicks and Bullish/Bearish Engulfing reversal candles.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'bot' && (
            <div className="space-y-4">
              {/* STRONG SINGLE BOT 99% BANNER */}
              <div className="bg-gradient-to-br from-amber-950/70 via-[#270e17] to-[#16050e] border border-amber-600/60 rounded-xl p-3.5 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                      <Zap className="w-4 h-4 fill-amber-400" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-amber-300">
                        STRONG SINGLE BOT 99% MODE
                      </h3>
                      <p className="text-[11px] text-zinc-300">
                        High-confluence filter for single sniper entries
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      onUpdateBotSettings({
                        ...botSettings,
                        strongSniperMode99: !botSettings.strongSniperMode99,
                      });
                      soundManager.playPip();
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                      botSettings.strongSniperMode99
                        ? 'bg-amber-500 text-black border-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.5)]'
                        : 'bg-[#180710] text-zinc-400 border-[#381121]'
                    }`}
                  >
                    {botSettings.strongSniperMode99 ? 'ACTIVATED' : 'DISABLED'}
                  </button>
                </div>
                <div className="text-[11px] text-zinc-300 mt-2.5 leading-relaxed bg-[#10040a]/70 p-2 rounded-lg border border-amber-500/20">
                  <strong className="text-amber-300">How it works:</strong> In 99% mode, signals are only
                  fired when RSI exhaustion, Bollinger envelope rejection, EMA trend, and candlestick
                  pin bar rejection align simultaneously. Signals reach <strong>98.5%–99.4%</strong> confluence probability.
                </div>
              </div>

              {/* Money Management */}
              <div className="bg-[#1a0711] border border-[#3b1223] rounded-xl p-3 space-y-3">
                <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px]">
                  Execution & Money Management
                </h4>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-zinc-400">Trade Stake ($)</label>
                    <input
                      type="number"
                      value={botSettings.stakeAmount}
                      onChange={(e) =>
                        onUpdateBotSettings({
                          ...botSettings,
                          stakeAmount: Number(e.target.value) || 10,
                        })
                      }
                      className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2.5 py-1.5 text-white font-mono font-bold mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-zinc-400">Martingale Strategy</label>
                    <select
                      value={botSettings.martingaleMode}
                      onChange={(e) =>
                        onUpdateBotSettings({
                          ...botSettings,
                          martingaleMode: e.target.value as any,
                        })
                      }
                      className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2 py-1.5 text-white font-mono mt-1"
                    >
                      <option value="none">Flat Stake (No Martingale)</option>
                      <option value="1_step">1-Step Martingale (x2.2)</option>
                      <option value="2_step">2-Step Martingale (x2.2)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-zinc-400">Stop Loss Limit ($)</label>
                    <input
                      type="number"
                      value={botSettings.stopLossAmount}
                      onChange={(e) =>
                        onUpdateBotSettings({
                          ...botSettings,
                          stopLossAmount: Number(e.target.value) || 200,
                        })
                      }
                      className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2.5 py-1.5 text-white font-mono mt-1"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-zinc-400">Take Profit Target ($)</label>
                    <input
                      type="number"
                      value={botSettings.takeProfitAmount}
                      onChange={(e) =>
                        onUpdateBotSettings({
                          ...botSettings,
                          takeProfitAmount: Number(e.target.value) || 500,
                        })
                      }
                      className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2.5 py-1.5 text-white font-mono mt-1"
                    />
                  </div>
                </div>

                {/* Fast Speed Setting */}
                <div className="pt-2 border-t border-[#2e0e1c] flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-100 flex items-center gap-1.5 text-xs">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>Ultra-Fast Analysis (Under 0.5s)</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 mt-0.5">
                      Instantly calculate signals without waiting for neural animation
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={botSettings.fastAnalysis}
                    onChange={(e) =>
                      onUpdateBotSettings({
                        ...botSettings,
                        fastAnalysis: e.target.checked,
                      })
                    }
                    className="accent-red-500 w-4 h-4 rounded cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'webhook' && (
            <div className="space-y-3.5">
              <div className="bg-[#1a0711] border border-[#3b1223] rounded-xl p-3">
                <h4 className="font-bold text-slate-100 uppercase tracking-wider text-[11px] mb-2">
                  Quotex Automation Bridge & Webhooks
                </h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed mb-3">
                  Connect your automated trading bot (Quotex Chrome extension, Python script, or
                  Telegram broker channel) to receive instant trade trigger payloads when 99% signals occur.
                </p>

                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] text-zinc-400">Webhook Receiver URL</label>
                    <input
                      type="text"
                      value={botSettings.quotexWebhookUrl}
                      onChange={(e) =>
                        onUpdateBotSettings({
                          ...botSettings,
                          quotexWebhookUrl: e.target.value,
                        })
                      }
                      placeholder="https://your-bot-listener.com/quotex-trade"
                      className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2.5 py-1.5 text-white font-mono mt-0.5"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-zinc-400">Quotex Account ID (Optional)</label>
                    <input
                      type="text"
                      value={botSettings.quotexAccountId}
                      onChange={(e) =>
                        onUpdateBotSettings({
                          ...botSettings,
                          quotexAccountId: e.target.value,
                        })
                      }
                      placeholder="e.g. QX-8491823"
                      className="w-full bg-[#10040a] border border-[#300e1b] rounded px-2.5 py-1.5 text-white font-mono mt-0.5"
                    />
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-[#2e0e1c] flex items-center justify-between">
                  <button
                    onClick={handleTestWebhook}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg font-bold text-xs transition-colors shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Test Webhook</span>
                  </button>

                  {webhookTestStatus && (
                    <span className="text-[11px] font-mono text-emerald-400">
                      {webhookTestStatus}
                    </span>
                  )}
                </div>
              </div>

              {/* Sample Webhook Payload */}
              <div className="bg-[#10040a] border border-[#2a0c18] rounded-xl p-3 font-mono text-[11px]">
                <div className="text-zinc-500 mb-1">Standard Quotex Webhook Payload Format:</div>
                <pre className="text-emerald-400 overflow-x-auto p-1 leading-relaxed">
{`{
  "broker": "QUOTEX",
  "pair": "EUR/USD OTC",
  "direction": "CALL", // or "PUT"
  "amount": ${botSettings.stakeAmount},
  "durationSeconds": 60,
  "confidence": 99.2,
  "isSniper99": true,
  "candleOpenTime": "21:55:00"
}`}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#300f1e] bg-[#190711] flex items-center justify-between">
          <div className="flex items-center gap-1 text-[11px] text-zinc-400 font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Settings synced locally</span>
          </div>

          <button
            onClick={() => {
              soundManager.playPip();
              onClose();
            }}
            className="px-4 py-2 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white rounded-xl font-bold text-xs transition-all shadow-md active:scale-95"
          >
            Apply & Save
          </button>
        </div>
      </div>
    </div>
  );
};
