import React from 'react';
import { Video, Music, Trash2, Edit3, Play, Bell, Repeat } from 'lucide-react';
import { Alarm } from '../types/alarm';
import { formatAlarmTime, formatRepeatDays, WEEKDAY_LABELS } from '../utils/alarmEngine';

interface AlarmCardProps {
  alarm: Alarm;
  is24h: boolean;
  onToggle: (id: string, isEnabled: boolean) => void;
  onEdit: (alarm: Alarm) => void;
  onDelete: (id: string) => void;
  onTestTrigger: (alarm: Alarm) => void;
}

export const AlarmCard: React.FC<AlarmCardProps> = ({
  alarm,
  is24h,
  onToggle,
  onEdit,
  onDelete,
  onTestTrigger,
}) => {
  const { timeStr, period } = formatAlarmTime(alarm.hour, alarm.minute, is24h);
  const isVideo = alarm.mediaType === 'video';

  return (
    <div
      className={`group relative rounded-2xl p-4 sm:p-5 border transition-all duration-200 shadow-xs ${
        alarm.isEnabled
          ? 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 shadow-sm hover:border-slate-300 dark:hover:border-slate-700'
          : 'bg-slate-100/70 dark:bg-slate-900/40 border-slate-200/50 dark:border-slate-800/50 opacity-75'
      }`}
    >
      <div className="flex items-start justify-between gap-4">
        {/* Left Info Column */}
        <div className="flex-1 min-w-0">
          {/* Label & Media Type Badge */}
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="text-sm font-semibold text-slate-900 dark:text-white truncate max-w-[200px]">
              {alarm.alarmLabel || 'Alarm'}
            </span>

            {/* Media Badge */}
            <div
              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                isVideo
                  ? 'bg-purple-50 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800/50'
                  : 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50'
              }`}
            >
              {isVideo ? <Video className="w-3 h-3" /> : <Music className="w-3 h-3" />}
              <span className="truncate max-w-[130px]">{alarm.mediaName || (isVideo ? 'Video' : 'Music')}</span>
            </div>
          </div>

          {/* Large Time Display */}
          <div className="flex items-baseline gap-1.5 my-1">
            <span
              className={`text-3xl sm:text-4xl font-extrabold font-mono tracking-tight ${
                alarm.isEnabled ? 'text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-500'
              }`}
            >
              {timeStr}
            </span>
            {period && (
              <span className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {period}
              </span>
            )}
          </div>

          {/* Repeat Days Indicators */}
          <div className="mt-2.5 flex items-center gap-1.5 flex-wrap">
            {WEEKDAY_LABELS.map((day) => {
              const isSelected = alarm.repeatDays.includes(day.value);
              return (
                <span
                  key={day.value}
                  className={`w-6 h-6 rounded-lg text-[11px] font-bold flex items-center justify-center transition-colors ${
                    isSelected
                      ? alarm.isEnabled
                        ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                        : 'bg-slate-400 dark:bg-slate-700 text-white dark:text-slate-300'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-600'
                  }`}
                  title={day.full}
                >
                  {day.short}
                </span>
              );
            })}

            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium ml-2 hidden sm:inline">
              {formatRepeatDays(alarm.repeatDays)}
            </span>
          </div>
        </div>

        {/* Right Toggle & Actions */}
        <div className="flex flex-col items-end justify-between gap-3 shrink-0">
          {/* Main Enable/Disable iOS/Android style Switch */}
          <button
            onClick={() => onToggle(alarm.id, !alarm.isEnabled)}
            className={`w-12 h-7 rounded-full p-1 transition-colors duration-200 ease-in-out cursor-pointer relative ${
              alarm.isEnabled ? 'bg-slate-900 dark:bg-white' : 'bg-slate-300 dark:bg-slate-700'
            }`}
            aria-label={alarm.isEnabled ? 'Disable alarm' : 'Enable alarm'}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white dark:bg-slate-900 shadow-md transform transition-transform duration-200 ${
                alarm.isEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>

          {/* Action Row */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onTestTrigger(alarm)}
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="Test Ring Alarm Now"
            >
              <Play className="w-4 h-4 text-emerald-600 dark:text-emerald-400 fill-emerald-600/20" />
            </button>

            <button
              onClick={() => onEdit(alarm)}
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title="Edit Alarm"
            >
              <Edit3 className="w-4 h-4" />
            </button>

            <button
              onClick={() => onDelete(alarm.id)}
              className="p-2 rounded-xl text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors cursor-pointer"
              title="Delete Alarm"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
