import React, { useCallback, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Calendar,
  Check,
  CheckSquare,
  ExternalLink,
  Plus,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import { ConfirmDialogState } from '../types/ops';
import {
  CalendarEvent,
  createCalendarEvent,
  createTask,
  deleteCalendarEvent,
  deleteTask,
  GoogleTask,
  GoogleTaskList,
  listCalendarEvents,
  listTaskLists,
  listTasks,
  toggleTaskCompletion,
} from '../lib/workspaceApi';
import { WorkspaceTokenGate } from './WorkspaceTokenGate';

interface CalendarTasksViewProps {
  accessToken: string | null;
  isLoggingIn: boolean;
  onReconnectWorkspace: () => void;
  onRequestConfirm: (dialog: ConfirmDialogState) => void;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

export const CalendarTasksView: React.FC<CalendarTasksViewProps> = ({
  accessToken,
  isLoggingIn,
  onReconnectWorkspace,
  onRequestConfirm,
  onNotify,
}) => {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loadingEvents, setLoadingEvents] = useState(false);

  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>('');
  const [tasks, setTasks] = useState<GoogleTask[]>([]);
  const [loadingTasks, setLoadingTasks] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Calendar Form
  const [eventSummary, setEventSummary] = useState('');
  const [eventStart, setEventStart] = useState(() => {
    const d = new Date(Date.now() + 60 * 60 * 1000);
    return d.toISOString().slice(0, 16);
  });
  const [eventLocation, setEventLocation] = useState('Gudang Tiga Rekan ID');

  // Task Form
  const [taskTitle, setTaskTitle] = useState('');
  const [taskNotes, setTaskNotes] = useState('');

  const loadCalendarAndLists = useCallback(async () => {
    if (!accessToken) return;
    setErrorMsg(null);
    setLoadingEvents(true);
    setLoadingTasks(true);
    try {
      const [ev, lists] = await Promise.all([
        listCalendarEvents(accessToken, 15),
        listTaskLists(accessToken),
      ]);
      setEvents(ev);
      setTaskLists(lists);
      const firstId = lists[0]?.id || '@default';
      setSelectedListId(firstId);
      const listItems = await listTasks(accessToken, firstId);
      setTasks(listItems);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Gagal memuat Calendar & Tasks.');
    } finally {
      setLoadingEvents(false);
      setLoadingTasks(false);
    }
  }, [accessToken]);

  useEffect(() => {
    loadCalendarAndLists();
  }, [loadCalendarAndLists]);

  const handleSelectTaskList = async (listId: string) => {
    if (!accessToken) return;
    setSelectedListId(listId);
    setLoadingTasks(true);
    try {
      const items = await listTasks(accessToken, listId);
      setTasks(items);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Gagal memuat daftar tugas.', 'error');
    } finally {
      setLoadingTasks(false);
    }
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !eventSummary.trim()) return;
    const startDate = new Date(eventStart);
    const endDate = new Date(startDate.getTime() + 60 * 60 * 1000);
    onRequestConfirm({
      open: true,
      title: 'Buat Jadwal di Google Calendar?',
      description: `Aplikasi akan menambahkan acara baru "${eventSummary}" ke kalender utama Google Anda.`,
      confirmLabel: 'Buat Jadwal',
      details: [
        `Acara: ${eventSummary}`,
        `Waktu: ${startDate.toLocaleString('id-ID')} - ${endDate.toLocaleTimeString('id-ID')}`,
        `Lokasi: ${eventLocation || '-'}`,
      ],
      onConfirm: async () => {
        await createCalendarEvent(accessToken, {
          summary: eventSummary.trim(),
          location: eventLocation.trim(),
          startIso: startDate.toISOString(),
          endIso: endDate.toISOString(),
        });
        setEventSummary('');
        onNotify('Jadwal baru berhasil ditambahkan ke Google Calendar.', 'success');
        const ev = await listCalendarEvents(accessToken, 15);
        setEvents(ev);
      },
    });
  };

  const handleDeleteEvent = (ev: CalendarEvent) => {
    if (!accessToken) return;
    onRequestConfirm({
      open: true,
      title: 'Hapus Acara dari Google Calendar?',
      description: `Acara "${ev.summary || 'Tanpa Judul'}" akan dihapus permanen dari kalender Google Anda.`,
      confirmLabel: 'Hapus Acara',
      variant: 'danger',
      onConfirm: async () => {
        await deleteCalendarEvent(accessToken, ev.id);
        setEvents((prev) => prev.filter((item) => item.id !== ev.id));
        onNotify('Acara kalender telah dihapus.', 'success');
      },
    });
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !taskTitle.trim()) return;
    const targetList = selectedListId || '@default';
    onRequestConfirm({
      open: true,
      title: 'Tambah Tugas di Google Tasks?',
      description: `Menambahkan tugas operasional "${taskTitle}" ke Google Tasks Anda.`,
      confirmLabel: 'Simpan Tugas',
      details: [
        `Daftar: ${taskLists.find((l) => l.id === targetList)?.title || 'Default'}`,
        `Tugas: ${taskTitle}`,
      ],
      onConfirm: async () => {
        await createTask(accessToken, targetList, {
          title: taskTitle.trim(),
          notes: taskNotes.trim(),
        });
        setTaskTitle('');
        setTaskNotes('');
        const items = await listTasks(accessToken, targetList);
        setTasks(items);
        onNotify('Tugas baru berhasil disimpan di Google Tasks.', 'success');
      },
    });
  };

  const handleToggleTask = (task: GoogleTask) => {
    if (!accessToken) return;
    const targetList = selectedListId || '@default';
    const nextAction = task.status === 'completed' ? 'Tandai Belum Selesai' : 'Tandai Selesai';
    onRequestConfirm({
      open: true,
      title: `${nextAction} di Google Tasks?`,
      description: `Status tugas "${task.title}" di Google Tasks akan diperbarui.`,
      confirmLabel: nextAction,
      onConfirm: async () => {
        await toggleTaskCompletion(accessToken, targetList, task);
        const items = await listTasks(accessToken, targetList);
        setTasks(items);
        onNotify('Status tugas Google Tasks diperbarui.', 'success');
      },
    });
  };

  const handleDeleteTask = (task: GoogleTask) => {
    if (!accessToken) return;
    const targetList = selectedListId || '@default';
    onRequestConfirm({
      open: true,
      title: 'Hapus Tugas dari Google Tasks?',
      description: `Tugas "${task.title}" akan dihapus permanen dari akun Google Tasks Anda.`,
      confirmLabel: 'Hapus Tugas',
      variant: 'danger',
      onConfirm: async () => {
        await deleteTask(accessToken, targetList, task.id);
        setTasks((prev) => prev.filter((t) => t.id !== task.id));
        onNotify('Tugas dihapus dari Google Tasks.', 'success');
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-stone-200">
        <div>
          <h1 className="text-2xl font-bold text-stone-900 tracking-tight">
            Google Calendar & Google Tasks
          </h1>
          <p className="text-sm text-stone-600 mt-1">
            Atur jadwal sesi Live, kedatangan stok supplier, shift gudang, dan daftar tugas harian tim Tiga Rekan ID.
          </p>
        </div>
        {accessToken && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            type="button"
            onClick={loadCalendarAndLists}
            disabled={loadingEvents || loadingTasks}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${loadingEvents ? 'animate-spin' : ''}`} />
            Segarkan Data
          </motion.button>
        )}
      </div>

      {!accessToken ? (
        <WorkspaceTokenGate
          serviceName="Google Calendar & Tasks"
          onReconnect={onReconnectWorkspace}
          isLoggingIn={isLoggingIn}
        />
      ) : (
        <>
          {errorMsg && (
            <div className="p-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl">
              {errorMsg}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Google Calendar Column */}
            <section className="lg:col-span-6 bg-white border border-stone-200 rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-stone-200 flex items-center gap-2.5">
                <Calendar className="w-4 h-4 text-orange-600" />
                <h2 className="text-base font-semibold text-stone-900">
                  Agenda Operasional (Google Calendar)
                </h2>
              </div>

              <form onSubmit={handleCreateEvent} className="p-5 bg-stone-50 border-b border-stone-200 space-y-3">
                <input
                  type="text"
                  required
                  value={eventSummary}
                  onChange={(e) => setEventSummary(e.target.value)}
                  placeholder="Agenda baru (misal: Live Flash Sale / Pickup Kurir)"
                  className="w-full px-3 py-2 text-sm bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="datetime-local"
                    required
                    value={eventStart}
                    onChange={(e) => setEventStart(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                  <input
                    type="text"
                    value={eventLocation}
                    onChange={(e) => setEventLocation(e.target.value)}
                    placeholder="Lokasi / Toko"
                    className="w-full px-3 py-2 text-sm bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  type="submit"
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Tambah ke Google Calendar
                </motion.button>
              </form>

              {loadingEvents ? (
                <div className="p-6 space-y-3">
                  <div className="h-12 bg-stone-100 rounded-lg" />
                  <div className="h-12 bg-stone-100 rounded-lg" />
                  <div className="h-12 bg-stone-100 rounded-lg" />
                </div>
              ) : events.length === 0 ? (
                <div className="p-8 text-center text-sm text-stone-600">
                  Tidak ada jadwal mendatang di Google Calendar utama Anda.
                </div>
              ) : (
                <div className="divide-y divide-stone-100">
                  {events.map((ev) => {
                    const startStr = ev.start?.dateTime || ev.start?.date || '';
                    const formatted = startStr
                      ? new Date(startStr).toLocaleString('id-ID', {
                          day: '2-digit',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : '-';
                    return (
                      <div
                        key={ev.id}
                        className="px-5 py-3.5 flex items-start justify-between gap-3 hover:bg-orange-50/30 transition-colors"
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-stone-900 truncate">
                            {ev.summary || '(Tanpa judul)'}
                          </p>
                          <p className="text-xs text-stone-500 font-mono mt-0.5">
                            {formatted}
                            {ev.location ? ` · ${ev.location}` : ''}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {ev.htmlLink && (
                            <a
                              href={ev.htmlLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 text-stone-400 hover:text-orange-600 rounded-md"
                              title="Buka di Google Calendar"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={() => handleDeleteEvent(ev)}
                            className="p-1.5 text-stone-400 hover:text-red-700 rounded-md"
                            title="Hapus acara"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>

            {/* Google Tasks Column */}
            <section className="lg:col-span-6 bg-white border border-stone-200 rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <CheckSquare className="w-4 h-4 text-orange-600" />
                  <h2 className="text-base font-semibold text-stone-900">
                    Daftar Tugas (Google Tasks)
                  </h2>
                </div>
                {taskLists.length > 0 && (
                  <select
                    value={selectedListId}
                    onChange={(e) => handleSelectTaskList(e.target.value)}
                    aria-label="Pilih daftar tugas Google Tasks"
                    className="px-2.5 py-1.5 text-xs bg-white border border-stone-300 rounded-md text-stone-700"
                  >
                    {taskLists.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.title}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <form onSubmit={handleCreateTask} className="p-5 bg-stone-50 border-b border-stone-200 space-y-3">
                <input
                  type="text"
                  required
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  placeholder="Tugas baru (misal: Follow up komplain / Restock SKU Veelo)"
                  className="w-full px-3 py-2 text-sm bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                />
                <input
                  type="text"
                  value={taskNotes}
                  onChange={(e) => setTaskNotes(e.target.value)}
                  placeholder="Catatan tambahan (opsional)"
                  className="w-full px-3 py-2 text-sm bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  type="submit"
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Tambah ke Google Tasks
                </motion.button>
              </form>

              {loadingTasks ? (
                <div className="p-6 space-y-3">
                  <div className="h-11 bg-stone-100 rounded-lg" />
                  <div className="h-11 bg-stone-100 rounded-lg" />
                  <div className="h-11 bg-stone-100 rounded-lg" />
                </div>
              ) : tasks.length === 0 ? (
                <div className="p-8 text-center text-sm text-stone-600">
                  Belum ada tugas di daftar Google Tasks ini.
                </div>
              ) : (
                <div className="divide-y divide-stone-100">
                  {tasks.map((task) => {
                    const done = task.status === 'completed';
                    return (
                      <div
                        key={task.id}
                        className="px-5 py-3 flex items-start justify-between gap-3 hover:bg-orange-50/30 transition-colors"
                      >
                        <div className="flex items-start gap-3 min-w-0">
                          <motion.button
                            whileTap={{ scale: 0.9 }}
                            type="button"
                            onClick={() => handleToggleTask(task)}
                            className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center shrink-0 transition-colors ${
                              done
                                ? 'bg-emerald-600 border-emerald-600 text-white'
                                : 'bg-white border-stone-300 hover:border-orange-600'
                            }`}
                            aria-label={`Ubah status ${task.title}`}
                          >
                            {done && <Check className="w-3.5 h-3.5" />}
                          </motion.button>
                          <div className="min-w-0">
                            <p
                              className={`text-sm font-medium ${
                                done ? 'line-through text-stone-400' : 'text-stone-900'
                              }`}
                            >
                              {task.title}
                            </p>
                            {task.notes && (
                              <p className="text-xs text-stone-500 mt-0.5 break-words">
                                {task.notes}
                              </p>
                            )}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleDeleteTask(task)}
                          className="p-1.5 text-stone-400 hover:text-red-700 rounded-md shrink-0"
                          title="Hapus tugas"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          </div>
        </>
      )}
    </div>
  );
};
