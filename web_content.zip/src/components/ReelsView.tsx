import React, { useState, useRef, useEffect } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Volume2, 
  VolumeX, 
  Music, 
  Plus, 
  ChevronUp, 
  ChevronDown, 
  Send, 
  X,
  Play,
  Pause,
  Trash2
} from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { useAuth } from '../context/AuthContext';
import { Reel } from '../types';
import { SafeVideo } from './SafeVideo';

interface ReelsViewProps {
  onOpenCreateReel: () => void;
  onOpenProfile?: (userId: string) => void;
}

export const ReelsView: React.FC<ReelsViewProps> = ({ onOpenCreateReel, onOpenProfile }) => {
  const { reels, toggleLikeReel, deleteReel } = useSocial();
  const { user, isAdmin } = useAuth();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [localComments, setLocalComments] = useState<Record<string, { author: string; text: string; time: string }[]>>({});
  const [heartBurst, setHeartBurst] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const lastTapRef = useRef<number>(0);

  const currentReel: Reel | undefined = reels[currentIndex];

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    }
  }, [currentIndex]);

  const handleVideoTap = () => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;

    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      // Double tap -> Like!
      if (currentReel && !currentReel.userLiked) {
        toggleLikeReel(currentReel.id);
      }
      setHeartBurst(true);
      setTimeout(() => setHeartBurst(false), 900);
    } else {
      // Single tap -> Play / Pause
      if (videoRef.current) {
        if (isPlaying) {
          videoRef.current.pause();
          setIsPlaying(false);
        } else {
          videoRef.current.play();
          setIsPlaying(true);
        }
      }
    }
    lastTapRef.current = now;
  };

  const handleNext = () => {
    if (currentIndex < reels.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleShare = async () => {
    if (!currentReel) return;
    const shareUrl = window.location.origin + '/#reel-' + currentReel.id;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `FaceLook Reel by ${currentReel.authorName}`,
          text: currentReel.caption,
          url: shareUrl,
        });
        return;
      } catch {}
    }
    navigator.clipboard.writeText(shareUrl);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !currentReel) return;
    
    setLocalComments(prev => ({
      ...prev,
      [currentReel.id]: [
        ...(prev[currentReel.id] || []),
        {
          author: user?.displayName || 'Me',
          text: commentText.trim(),
          time: 'Just now',
        }
      ]
    }));
    setCommentText('');
  };

  if (!currentReel) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-6 text-center">
        <p className="text-slate-600 font-semibold mb-4">No reels found yet. Be the first to publish one!</p>
        <button
          onClick={onOpenCreateReel}
          className="bg-linear-to-r from-rose-500 to-pink-600 text-white font-bold px-6 py-2.5 rounded-full shadow-md"
        >
          Upload Reel from Phone
        </button>
      </div>
    );
  }

  const activeComments = localComments[currentReel.id] || [
    { author: 'Sophia Chen', text: 'This looks stunning on mobile! 🔥', time: '10m' },
    { author: 'Marcus Vance', text: 'Great edit and music sync 👏', time: '1h' },
  ];

  return (
    <div className="relative w-full max-w-sm sm:max-w-md mx-auto h-[calc(100vh-8.5rem)] sm:h-[82vh] bg-black rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between select-none">
      
      {/* Top Overlay Header */}
      <div className="absolute top-0 inset-x-0 z-30 p-4 flex items-center justify-between bg-linear-to-b from-black/80 via-black/20 to-transparent">
        <div className="flex items-center gap-2">
          <span className="font-black text-lg text-white tracking-wide">Reels</span>
          <span className="text-[10px] bg-rose-500 text-white font-bold px-2 py-0.5 rounded-full">
            {currentIndex + 1}/{reels.length}
          </span>
        </div>

        <button
          onClick={onOpenCreateReel}
          className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white font-bold text-xs px-3 py-1.5 rounded-full transition-colors cursor-pointer border border-white/30"
        >
          <Plus className="w-4 h-4" />
          <span>Upload Reel</span>
        </button>
      </div>

      {/* Main Reel Video Player */}
      <div 
        onClick={handleVideoTap}
        className="relative w-full h-full flex items-center justify-center bg-black cursor-pointer overflow-hidden"
      >
        <SafeVideo
          ref={videoRef}
          src={currentReel.videoUrl}
          className="w-full h-full object-cover"
          autoPlay
          loop
          muted={isMuted}
          playsInline
        />

        {/* Play / Pause indicator icon */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 pointer-events-none">
            <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-md text-white flex items-center justify-center">
              <Play className="w-8 h-8 translate-x-0.5" />
            </div>
          </div>
        )}

        {/* Double-tap Heart Burst Animation */}
        {heartBurst && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none animate-in zoom-in-50 fade-in duration-300">
            <Heart className="w-24 h-24 text-rose-500 fill-rose-500 drop-shadow-2xl animate-bounce" />
          </div>
        )}

        {/* Audio Mute/Unmute floating button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            if (videoRef.current) videoRef.current.muted = !isMuted;
            setIsMuted(!isMuted);
          }}
          className="absolute top-16 right-4 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md text-white flex items-center justify-center transition-colors cursor-pointer z-20"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Desktop Vertical Nav Arrows */}
        <div className="hidden sm:flex flex-col gap-2 absolute right-4 top-1/2 -translate-y-1/2 z-20">
          <button
            onClick={(e) => { e.stopPropagation(); handlePrev(); }}
            disabled={currentIndex === 0}
            className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 disabled:opacity-30 text-white flex items-center justify-center cursor-pointer"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); handleNext(); }}
            disabled={currentIndex === reels.length - 1}
            className="w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 disabled:opacity-30 text-white flex items-center justify-center cursor-pointer"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Right Side Social Actions (Like, Comment, Share) */}
      <div className="absolute right-3 bottom-18 z-30 flex flex-col items-center gap-4">
        
        {/* Author Avatar with follow badge */}
        <div 
          onClick={() => onOpenProfile && onOpenProfile(currentReel.authorId)}
          className="relative cursor-pointer group"
        >
          <img
            src={currentReel.authorPhotoURL}
            alt={currentReel.authorName}
            className="w-11 h-11 rounded-full object-cover ring-2 ring-white shadow-lg"
          />
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-rose-500 text-white flex items-center justify-center text-[10px] font-bold ring-2 ring-black">
            +
          </div>
        </div>

        {/* Like */}
        <button
          onClick={() => toggleLikeReel(currentReel.id)}
          className="flex flex-col items-center gap-1 cursor-pointer transition-transform active:scale-125"
        >
          <div className={`w-11 h-11 rounded-full backdrop-blur-md flex items-center justify-center shadow-lg ${
            currentReel.userLiked ? 'bg-rose-500 text-white' : 'bg-black/40 text-white'
          }`}>
            <Heart className={`w-6 h-6 ${currentReel.userLiked ? 'fill-white' : ''}`} />
          </div>
          <span className="text-white text-xs font-bold drop-shadow-md">
            {currentReel.likesCount}
          </span>
        </button>

        {/* Comments */}
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex flex-col items-center gap-1 cursor-pointer transition-transform active:scale-110"
        >
          <div className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-md text-white flex items-center justify-center shadow-lg">
            <MessageCircle className="w-6 h-6" />
          </div>
          <span className="text-white text-xs font-bold drop-shadow-md">
            {currentReel.commentsCount + activeComments.length - 2}
          </span>
        </button>

        {/* Share */}
        <button
          onClick={handleShare}
          className="flex flex-col items-center gap-1 cursor-pointer transition-transform active:scale-110"
        >
          <div className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-md text-white flex items-center justify-center shadow-lg">
            <Share2 className="w-6 h-6" />
          </div>
          <span className="text-white text-xs font-bold drop-shadow-md">
            Share
          </span>
        </button>

        {/* Delete Reel if owner or admin */}
        {(isAdmin || user?.id === currentReel.authorId) && (
          <button
            onClick={() => deleteReel(currentReel.id)}
            className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-md text-rose-400 hover:text-rose-500 flex items-center justify-center cursor-pointer"
            title="Delete Reel"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}

        {/* Spinning Vinyl Record Icon */}
        <div className="w-10 h-10 rounded-full bg-zinc-900 border-2 border-zinc-700 flex items-center justify-center animate-spin duration-3000">
          <div className="w-3 h-3 rounded-full bg-rose-500"></div>
        </div>

      </div>

      {/* Bottom Information Overlay (Creator info, caption, music ticker) */}
      <div className="absolute bottom-0 inset-x-0 z-20 p-4 pb-5 pr-16 bg-linear-to-t from-black/90 via-black/40 to-transparent">
        
        {/* Creator Name */}
        <div 
          onClick={() => onOpenProfile && onOpenProfile(currentReel.authorId)}
          className="flex items-center gap-2 mb-1.5 cursor-pointer"
        >
          <span className="font-bold text-white text-sm hover:underline">
            @{currentReel.authorUsername}
          </span>
          <span className="text-[11px] font-semibold text-white/80 bg-white/20 px-2 py-0.5 rounded-full">
            Follow
          </span>
        </div>

        {/* Caption */}
        <p className="text-white text-xs sm:text-sm font-normal line-clamp-2 leading-relaxed mb-2 drop-shadow-md">
          {currentReel.caption}
        </p>

        {/* Music Sound Ticker */}
        <div className="flex items-center gap-2 text-white/90 text-xs font-medium overflow-hidden">
          <Music className="w-3.5 h-3.5 shrink-0 animate-pulse text-rose-400" />
          <span className="truncate">{currentReel.soundTitle}</span>
        </div>

      </div>

      {/* Sliding Comments Bottom Sheet */}
      {showComments && (
        <div className="absolute inset-x-0 bottom-0 top-1/3 bg-zinc-900/95 backdrop-blur-md rounded-t-3xl z-40 p-4 flex flex-col justify-between animate-in slide-in-from-bottom duration-200">
          
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2 mb-2">
            <span className="font-bold text-white text-sm">Comments</span>
            <button
              onClick={() => setShowComments(false)}
              className="text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Comments List */}
          <div className="flex-1 overflow-y-auto space-y-3 py-1 pr-1">
            {activeComments.map((c, i) => (
              <div key={i} className="flex items-start gap-2 text-xs">
                <div className="w-7 h-7 rounded-full bg-zinc-700 text-white font-bold flex items-center justify-center shrink-0">
                  {c.author.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-zinc-200">{c.author}</span>
                    <span className="text-[10px] text-zinc-500">{c.time}</span>
                  </div>
                  <p className="text-zinc-300 mt-0.5">{c.text}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Comment Form */}
          <form onSubmit={handleAddComment} className="flex items-center gap-2 pt-2 border-t border-zinc-800">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 bg-zinc-800 rounded-full px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-hidden"
            />
            <button
              type="submit"
              disabled={!commentText.trim()}
              className="w-8 h-8 rounded-full bg-rose-500 text-white flex items-center justify-center disabled:opacity-40 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>
      )}

    </div>
  );
};
