import React from 'react';
import { Check } from 'lucide-react';

interface BlueTickProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showTooltip?: boolean;
}

export const BlueTick: React.FC<BlueTickProps> = ({ size = 'sm', className = '', showTooltip = true }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  };

  const iconSizes = {
    sm: 10,
    md: 12,
    lg: 14,
  };

  return (
    <span
      className={`inline-flex items-center justify-center rounded-full bg-gradient-to-tr from-cyan-600 via-sky-500 to-blue-400 text-slate-950 shadow-[0_0_8px_rgba(0,210,255,0.6)] ${sizeClasses[size]} ${className} shrink-0 cursor-help group relative`}
      title={showTooltip ? 'Unknown Gamer Verified Esports Badge' : undefined}
      aria-label="Unknown Gamer Verified"
    >
      <Check strokeWidth={3.5} size={iconSizes[size]} className="text-slate-950 drop-shadow-xs" />
      {showTooltip && (
        <span className="pointer-events-none absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-slate-950 px-2 py-0.5 text-[10px] font-semibold text-cyan-400 opacity-0 shadow-lg ring-1 ring-cyan-500/30 transition-opacity group-hover:opacity-100 z-50">
          UG Verified Badge
        </span>
      )}
    </span>
  );
};
