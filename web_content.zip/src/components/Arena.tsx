import { useEffect, useRef, useState } from "react";
import { useApp } from "@/lib/store";
import { BUTTONS, DEFAULT_SETTINGS, WEAPONS } from "@/lib/defaults";
import { applyTouchCurve, buildAimModel, joystickVector, smoothingFactor } from "@/lib/sensitivity";
import type { ButtonId, TouchSettings, Weapon } from "@/lib/types";
import { Btn, Card, Slider, Stat, Toggle } from "./UI";
import { cn } from "@/utils/cn";

type Target = { id: number; x: number; y: number; z: number; r: number; alive: boolean; respawn: number };
type Grenade = { x: number; y: number; z: number; vx: number; vy: number; vz: number; t: number };
type Trail = { x: number; y: number; life: number };
type Basis = { fwd: Vec3; right: Vec3; up: Vec3 };
type Vec3 = { x: number; y: number; z: number };

type St = {
  yaw: number;
  pitch: number;
  targetYaw: number;
  targetPitch: number;
  px: number;
  pz: number;
  py: number;
  vy: number;
  recoilPitch: number;
  recoilYaw: number;
  moving: { x: number; z: number };
  firing: boolean;
  scope: boolean;
  ammo: number;
  hp: number;
  score: number;
  shots: number;
  hits: number;
  lastShot: number;
  targets: Target[];
  grenades: Grenade[];
  trail: Trail[];
  idSeq: number;
  fpsAcc: number;
  fpsFrames: number;
  fps: number;
};

const GROUND = 34;

/** Estado global do simulador — compartilhado entre o loop de render e a UI. */
const G = {
  settings: DEFAULT_SETTINGS as TouchSettings,
  weapon: "ak",
  joy: { nx: 0, ny: 0 },
  state: {
    yaw: 0,
    pitch: 0,
    targetYaw: 0,
    targetPitch: 0,
    px: 0,
    pz: 8,
    py: 0,
    vy: 0,
    recoilPitch: 0,
    recoilYaw: 0,
    moving: { x: 0, z: 0 },
    firing: false,
    scope: false,
    ammo: 30,
    hp: 100,
    score: 0,
    shots: 0,
    hits: 0,
    lastShot: 0,
    targets: [] as Target[],
    grenades: [] as Grenade[],
    trail: [] as Trail[],
    idSeq: 1,
    fpsAcc: 0,
    fpsFrames: 0,
    fps: 60,
  } as St,
};

function currentWeapon(): Weapon {
  return WEAPONS[G.weapon] ?? WEAPONS.ak;
}

export default function Arena() {
  const { settings, layout, enabledButtons, setWeapon, weapon, set } = useApp();

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const joyZoneRef = useRef<HTMLDivElement>(null);

  G.settings = settings;
  G.weapon = weapon;

  const [hud, setHud] = useState({
    ammo: 30,
    hp: 100,
    score: 0,
    hits: 0,
    shots: 0,
    fps: 60,
    zoom: false,
  });

  const look = useRef({ active: false, x: 0, y: 0 });
  const joy = useRef({ active: false, id: -1, nx: 0, ny: 0 });
  const layoutRef = useRef(layout);
  layoutRef.current = layout;

  /* ---------------- loop principal ---------------- */
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;
    let last = performance.now();
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = wrapRef.current!.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrapRef.current!);

    for (let i = 0; i < 5; i++) spawnTarget();

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      update(dt, now);
      render(ctx, canvas.width, canvas.height, dpr);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  /* ---------------- HUD ---------------- */
  useEffect(() => {
    const id = window.setInterval(() => {
      const s = G.state;
      setHud({
        ammo: s.ammo,
        hp: Math.round(s.hp),
        score: s.score,
        hits: s.hits,
        shots: s.shots,
        fps: Math.round(s.fps),
        zoom: s.scope,
      });
    }, 200);
    return () => window.clearInterval(id);
  }, []);

  /* ---------------- input: olhar ---------------- */
  const onPointerDown = (e: React.PointerEvent) => {
    if (G.settings.lockTouchToMove) return;
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
    look.current = { active: true, x: e.clientX, y: e.clientY };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!look.current.active) return;
    const dx = e.clientX - look.current.x;
    const dy = e.clientY - look.current.y;
    look.current.x = e.clientX;
    look.current.y = e.clientY;
    const cfg = G.settings;
    if (cfg.showTouchTrail) {
      const rect = wrapRef.current!.getBoundingClientRect();
      G.state.trail.push({
        x: ((e.clientX - rect.left) / rect.width) * 100,
        y: ((e.clientY - rect.top) / rect.height) * 100,
        life: 1,
      });
      if (G.state.trail.length > 24) G.state.trail.shift();
    }
    const eff = applyTouchCurve(dx, dy, cfg);
    const model = buildAimModel(cfg);
    G.state.targetYaw += eff.x * model.degPerPxX;
    const sign = cfg.invertY ? -1 : 1;
    G.state.targetPitch += -eff.y * model.degPerPxY * sign;
  };
  const onPointerUp = () => {
    look.current.active = false;
  };

  /* ---------------- input: joystick ---------------- */
  const joyDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    joy.current = { active: true, id: e.pointerId, nx: 0, ny: 0 };
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
    if (G.settings.floatingJoystick) {
      // o joystick nasce onde o dedo encostou (dentro da metade inferior esquerda)
      const wrapRect = wrapRef.current!.getBoundingClientRect();
      const x = Math.min(70, Math.max(12, ((e.clientX - wrapRect.left) / wrapRect.width) * 100));
      const y = Math.min(90, Math.max(45, ((e.clientY - wrapRect.top) / wrapRect.height) * 100));
      const zone = joyZoneRef.current!;
      zone.style.left = `${x}%`;
      zone.style.top = `${y}%`;
    }
    joyMove(e);
  };
  const joyMove = (e: React.PointerEvent) => {
    if (!joy.current.active) return;
    const zone = joyZoneRef.current!.getBoundingClientRect();
    const cx = zone.left + zone.width / 2;
    const cy = zone.top + zone.height / 2;
    const max = zone.width / 2;
    let dx = e.clientX - cx;
    let dy = e.clientY - cy;
    const len = Math.hypot(dx, dy) || 1;
    if (len > max) {
      dx = (dx / len) * max;
      dy = (dy / len) * max;
    }
    const nx = dx / max;
    const ny = dy / max;
    joy.current.nx = nx;
    joy.current.ny = ny;
    G.joy.nx = nx;
    G.joy.ny = ny;
    if (knobRef.current) knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
  };
  const joyUp = () => {
    joy.current.active = false;
    joy.current.nx = 0;
    joy.current.ny = 0;
    G.joy.nx = 0;
    G.joy.ny = 0;
    if (knobRef.current) knobRef.current.style.transform = "translate(0px, 0px)";
    if (G.settings.floatingJoystick && joyZoneRef.current) {
      joyZoneRef.current.style.left = `${layoutRef.current.joystick.x}%`;
      joyZoneRef.current.style.top = `${layoutRef.current.joystick.y}%`;
    }
  };

  /* ---------------- botões ---------------- */
  const press = (id: ButtonId) => {
    const s = G.state;
    const cfg = G.settings;
    const w = currentWeapon();
    switch (id) {
      case "fire":
        if (w.auto) s.firing = true;
        else shoot(performance.now());
        break;
      case "reload":
        s.ammo = w.id === "awp" ? 5 : 30;
        s.firing = false;
        break;
      case "scope":
        s.scope = !s.scope;
        break;
      case "jump":
        s.vy = 5.4;
        break;
      case "medkit":
        s.hp = Math.min(100, s.hp + 45);
        break;
      case "grenade": {
        const yaw = s.yaw + s.recoilYaw;
        const pitch = s.pitch + s.recoilPitch;
        s.grenades.push({
          x: s.px,
          y: 1.6 + s.py,
          z: s.pz,
          vx: Math.sin(yaw) * Math.cos(pitch) * 16,
          vy: Math.sin(pitch) * 16 + 4,
          vz: -Math.cos(yaw) * Math.cos(pitch) * 16,
          t: 0,
        });
        break;
      }
      default:
        break;
    }
    if (cfg.haptics && typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate?.(id === "fire" ? 8 : 14);
    }
  };

  const release = (id: ButtonId) => {
    if (id === "fire") G.state.firing = false;
  };

  const holdBtn = (id: ButtonId) => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.stopPropagation();
      (e.currentTarget as Element).setPointerCapture(e.pointerId);
      press(id);
    },
    onPointerUp: (e: React.PointerEvent) => {
      e.stopPropagation();
      release(id);
    },
    onPointerCancel: () => release(id),
  });

  const acc = hud.shots ? Math.round((hud.hits / hud.shots) * 100) : 0;

  return (
    <div className="space-y-4">
      <Card
        title="Treino (Simulador)"
        icon="🎮"
        desc="Treine o touch com a sua sensibilidade. Arraste na tela para mirar e use o joystick para andar."
        action={
          <div className="flex flex-wrap gap-1.5">
            {Object.values(WEAPONS).map((w) => (
              <button
                key={w.id}
                onClick={() => setWeapon(w.id)}
                className={cn(
                  "rounded-lg px-2 py-1 text-[11px] font-bold transition",
                  weapon === w.id ? "bg-lime-400 text-slate-950" : "bg-white/5 text-slate-300",
                )}
              >
                {w.name}
              </button>
            ))}
          </div>
        }
      >
        <div
          ref={wrapRef}
          className="relative mx-auto w-full max-w-[440px] touch-none overflow-hidden rounded-3xl border border-white/10 bg-black shadow-2xl shadow-black/60"
          style={{ aspectRatio: "9 / 16", maxHeight: "72vh" }}
        >
          <canvas
            ref={canvasRef}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            className="absolute inset-0 h-full w-full"
          />

          <div
            ref={joyZoneRef}
            onPointerDown={joyDown}
            onPointerMove={joyMove}
            onPointerUp={joyUp}
            onPointerCancel={joyUp}
            className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-lime-300/50 bg-lime-400/10"
            style={{
              left: `${layout.joystick.x}%`,
              top: `${layout.joystick.y}%`,
              width: 96 * (settings.joystickSize / 100),
              height: 96 * (settings.joystickSize / 100),
              opacity: settings.opacity / 100,
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div ref={knobRef} className="h-10 w-10 rounded-full border border-white/40 bg-white/25 shadow-lg" />
            </div>
          </div>

          {BUTTONS.filter((b) => enabledButtons.includes(b.id)).map((b) => (
            <button
              key={b.id}
              {...holdBtn(b.id)}
              className={cn(
                "absolute flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-gradient-to-br text-xl shadow-lg shadow-black/50 ring-1 ring-white/25 active:scale-95",
                b.accent,
              )}
              style={{
                left: `${layout[b.id].x}%`,
                top: `${layout[b.id].y}%`,
                width: 54 * (settings.buttonSize / 100),
                height: 54 * (settings.buttonSize / 100),
                opacity: settings.opacity / 100,
              }}
            >
              {b.icon}
            </button>
          ))}

          {settings.showTelemetry && (
            <div className="pointer-events-none absolute left-3 top-3 space-y-1 font-mono text-[10px] text-lime-300/90">
              <div>
                MIRA H {settings.sensHorizontal}% · V {settings.sensVertical}%
              </div>
              <div>RECUO -{Math.round(settings.recoilControl)}%</div>
              <div>FPS {hud.fps}</div>
            </div>
          )}
          <div className="pointer-events-none absolute right-3 top-3 font-mono text-[10px] text-white/70">
            {hud.zoom ? "ADS" : "HIP"}
          </div>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
          <Stat label="Munição" value={`${hud.ammo}`} tone="amber" />
          <Stat label="Vida" value={`${hud.hp}`} tone={hud.hp > 50 ? "lime" : "rose"} />
          <Stat label="Pontos" value={`${hud.score}`} tone="cyan" />
          <Stat label="Acertos" value={`${hud.hits}`} />
          <Stat label="Precisão" value={`${acc}%`} tone="lime" />
          <Stat label="Tiros" value={`${hud.shots}`} />
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
          Dica: segure 🔥 para disparo contínuo. O recuo é simulado conforme a arma — compare os
          perfis com o controle de recuo e a mira assistida ligados.
        </p>
      </Card>

      <Card title="Ajustes do treino" icon="🧪" desc="Recursos de apoio simulados no trainer.">
        <div className="space-y-4">
          <Slider
            label="Controle de recuo"
            value={settings.recoilControl}
            min={0}
            max={100}
            onChange={(v) => set("recoilControl", v)}
            accent="lime"
            hint="Puxa a mira para baixo durante o tiro contínuo."
          />
          <Slider
            label="Mira assistida"
            value={settings.aimAssist}
            min={0}
            max={100}
            onChange={(v) => set("aimAssist", v)}
            accent="cyan"
            hint="Puxa levemente a mira para o alvo mais próximo dentro do cone."
          />
          <Slider
            label="Cadência de tiro"
            value={settings.fireRate}
            min={0}
            max={100}
            onChange={(v) => set("fireRate", v)}
            accent="amber"
            hint="Aumenta o RPM da arma no simulador."
          />
          <div className="grid gap-2 sm:grid-cols-2">
            <Toggle
              icon="🔁"
              label="Tiro automático"
              desc="Atira continuamente enquanto segurar."
              checked={settings.autoFire}
              onChange={(v) => set("autoFire", v)}
            />
            <Toggle
              icon="♻️"
              label="Recarga automática"
              desc="Recarrega sozinho quando a munição acaba."
              checked={settings.autoReload}
              onChange={(v) => set("autoReload", v)}
            />
            <Toggle
              icon="📱"
              label="Travar toque para andar"
              desc="Com ligado, arrastar na tela não move a câmera."
              checked={settings.lockTouchToMove}
              onChange={(v) => set("lockTouchToMove", v)}
            />
            <Toggle
              icon="🫧"
              label="Joystick flutuante"
              desc="O joystick nasce onde o seu dedo encostar na parte de baixo da tela."
              checked={settings.floatingJoystick}
              onChange={(v) => set("floatingJoystick", v)}
            />
            <Toggle
              icon="〰️"
              label="Mostrar rastro do toque"
              desc="Exibe os pontos de toque na tela."
              checked={settings.showTouchTrail}
              onChange={(v) => set("showTouchTrail", v)}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Btn
              variant="danger"
              onClick={() => {
                const s = G.state;
                s.score = 0;
                s.hits = 0;
                s.shots = 0;
                s.hp = 100;
              }}
            >
              Zerar estatísticas
            </Btn>
          </div>
        </div>
      </Card>
    </div>
  );
}

/* ---------------- motor do simulador ---------------- */

function spawnTarget() {
  const s = G.state;
  const ang = Math.random() * Math.PI * 2;
  const dist = 9 + Math.random() * 14;
  s.targets.push({
    id: s.idSeq++,
    x: s.px + Math.sin(ang) * dist,
    y: 0.6 + Math.random() * 2.2,
    z: s.pz + Math.cos(ang) * dist,
    r: 0.45,
    alive: true,
    respawn: 0,
  });
}

function cameraBasis(yaw: number, pitch: number): Basis {
  const cp = Math.cos(pitch);
  const fwd = { x: Math.sin(yaw) * cp, y: Math.sin(pitch), z: -Math.cos(yaw) * cp };
  const right = { x: Math.cos(yaw), y: 0, z: Math.sin(yaw) };
  const up = {
    x: -Math.sin(yaw) * Math.sin(pitch),
    y: Math.cos(pitch),
    z: Math.cos(yaw) * Math.sin(pitch),
  };
  return { fwd, right, up };
}

function update(dt: number, now: number) {
  const s = G.state;
  const cfg = G.settings;
  const w = currentWeapon();

  s.fpsAcc += dt;
  s.fpsFrames += 1;
  if (s.fpsAcc > 0.5) {
    s.fps = s.fpsAcc / Math.max(1, s.fpsFrames);
    s.fpsAcc = 0;
    s.fpsFrames = 0;
  }

  /* suavização da mira */
  const follow = 1 - Math.pow(1 - smoothingFactor(cfg), dt * 60);
  s.yaw += (s.targetYaw - s.yaw) * follow;
  s.pitch += (s.targetPitch - s.pitch) * follow;
  s.pitch = Math.max(-85, Math.min(85, s.pitch));

  /* mira assistida */
  if (cfg.aimAssist > 0) {
    const basis = cameraBasis(s.yaw + s.recoilYaw, s.pitch + s.recoilPitch);
    const origin = { x: s.px, y: 1.6 + s.py, z: s.pz };
    let best: Target | null = null;
    let bestAng = Infinity;
    for (const t of s.targets) {
      if (!t.alive) continue;
      const v = { x: t.x - origin.x, y: t.y - origin.y, z: t.z - origin.z };
      const len = Math.hypot(v.x, v.y, v.z) || 1;
      const dot = (v.x * basis.fwd.x + v.y * basis.fwd.y + v.z * basis.fwd.z) / len;
      const ang = Math.acos(Math.max(-1, Math.min(1, dot)));
      if (ang < bestAng) {
        bestAng = ang;
        best = t;
      }
    }
    if (best && bestAng < 0.25) {
      const strength = (cfg.aimAssist / 100) * 0.1;
      const to = {
        x: best.x - origin.x,
        y: best.y - origin.y,
        z: best.z - origin.z,
      };
      const lateral = to.x * basis.right.x + to.y * basis.right.y + to.z * basis.right.z;
      const vertical = to.x * basis.up.x + to.y * basis.up.y + to.z * basis.up.z;
      s.targetYaw += Math.atan2(lateral, 14) * strength;
      s.targetPitch += Math.atan2(vertical, 14) * strength;
    }
  }

  /* movimento */
  const jv = joystickVector(G.joy.nx, G.joy.ny, cfg);
  s.moving.x = jv.x;
  s.moving.z = jv.z;
  const yaw = s.yaw + s.recoilYaw;
  const fwdX = Math.sin(yaw);
  const fwdZ = -Math.cos(yaw);
  const rgtX = Math.cos(yaw);
  const rgtZ = Math.sin(yaw);
  const speed = 5.6;
  s.px += (rgtX * s.moving.x + fwdX * s.moving.z) * speed * dt;
  s.pz += (rgtZ * s.moving.x + fwdZ * s.moving.z) * speed * dt;
  s.px = Math.max(-GROUND, Math.min(GROUND, s.px));
  s.pz = Math.max(-GROUND, Math.min(GROUND, s.pz));

  /* pulo */
  s.vy -= 16 * dt;
  s.py += s.vy * dt;
  if (s.py <= 0) {
    s.py = 0;
    s.vy = 0;
  }

  /* tiro automático */
  const rateMul = 0.6 + cfg.fireRate / 100;
  const interval = 60000 / (w.rpm * rateMul);
  if (s.firing && cfg.autoFire && w.auto && now - s.lastShot >= interval) {
    shoot(now);
  }

  /* recarga automática */
  if (cfg.autoReload && s.ammo <= 0 && now - s.lastShot > 320) {
    s.ammo = w.id === "awp" ? 5 : 30;
  }

  /* recuperação do recuo */
  s.recoilPitch *= Math.pow(0.86, dt * 60);
  s.recoilYaw *= Math.pow(0.88, dt * 60);

  /* granadas */
  for (const g of s.grenades) {
    g.t += dt;
    g.vy -= 16 * dt;
    g.x += g.vx * dt;
    g.y += g.vy * dt;
    g.z += g.vz * dt;
    if (g.t > 1.7 || g.y < 0.1) {
      for (const t of s.targets) {
        if (!t.alive) continue;
        const d = Math.hypot(t.x - g.x, t.y - g.y, t.z - g.z);
        if (d < 5) {
          t.alive = false;
          t.respawn = 0.5;
          s.hits += 1;
          s.score += 150;
        }
      }
      s.grenades = s.grenades.filter((x) => x !== g);
    }
  }

  /* respawn de alvos */
  for (const t of s.targets) {
    if (!t.alive) {
      t.respawn -= dt;
      if (t.respawn <= 0) {
        const ang = Math.random() * Math.PI * 2;
        const dist = 9 + Math.random() * 14;
        t.x = s.px + Math.sin(ang) * dist;
        t.z = s.pz + Math.cos(ang) * dist;
        t.y = 0.6 + Math.random() * 2.2;
        t.alive = true;
      }
    }
  }
  if (s.targets.filter((t) => t.alive).length < 4 && Math.random() < dt * 0.8) {
    spawnTarget();
  }

  /* rastro do toque */
  for (const p of s.trail) p.life -= dt * 1.6;
  s.trail = s.trail.filter((p) => p.life > 0);
}

function shoot(now: number) {
  const s = G.state;
  const cfg = G.settings;
  const w = currentWeapon();
  if (s.ammo <= 0) s.ammo = w.id === "awp" ? 5 : 30;
  s.ammo -= 1;
  s.shots += 1;
  s.lastShot = now;

  const control = cfg.recoilControl / 100;
  const kick = w.recoilVertical * (1 - control);
  s.recoilPitch += kick * (0.55 + Math.random() * 0.45);
  s.recoilYaw += (Math.random() - 0.5) * 2 * w.recoilHorizontal * (1 - control);
  s.targetPitch -= kick * control * 0.55;

  const basis = cameraBasis(s.yaw + s.recoilYaw, s.pitch + s.recoilPitch);
  const origin = { x: s.px, y: 1.6 + s.py, z: s.pz };
  let hit: Target | null = null;
  let hitDist = Infinity;
  for (const t of s.targets) {
    if (!t.alive) continue;
    const v = { x: t.x - origin.x, y: t.y - origin.y, z: t.z - origin.z };
    const along = v.x * basis.fwd.x + v.y * basis.fwd.y + v.z * basis.fwd.z;
    if (along <= 0.2) continue;
    const perpX = v.x - basis.fwd.x * along;
    const perpY = v.y - basis.fwd.y * along;
    const perpZ = v.z - basis.fwd.z * along;
    const perp = Math.hypot(perpX, perpY, perpZ);
    if (perp < t.r && along < hitDist) {
      hitDist = along;
      hit = t;
    }
  }
  if (hit) {
    hit.alive = false;
    hit.respawn = 0.55;
    s.hits += 1;
    s.score += 100;
  }
}

function project(
  p: { x: number; y: number; z: number },
  origin: { x: number; y: number; z: number },
  basis: Basis,
  focal: number,
  cx: number,
  cy: number,
) {
  const vx = p.x - origin.x;
  const vy = p.y - origin.y;
  const vz = p.z - origin.z;
  const zc = vx * basis.fwd.x + vy * basis.fwd.y + vz * basis.fwd.z;
  if (zc <= 0.15) return null;
  const xc = vx * basis.right.x + vy * basis.right.y + vz * basis.right.z;
  const yc = vx * basis.up.x + vy * basis.up.y + vz * basis.up.z;
  return { x: cx + (focal * xc) / zc, y: cy - (focal * yc) / zc, z: zc };
}

function render(ctx: CanvasRenderingContext2D, w: number, h: number, dpr: number) {
  const s = G.state;
  const cfg = G.settings;
  const weapon = currentWeapon();
  const fov = ((s.scope ? weapon.adsFov : weapon.fov) * Math.PI) / 180;
  const focal = h / 2 / Math.tan(fov / 2);
  const cx = w / 2;
  const cy = h / 2;

  const basis = cameraBasis(s.yaw + s.recoilYaw, s.pitch + s.recoilPitch);
  const origin = { x: s.px, y: 1.6 + s.py, z: s.pz };

  const sky = ctx.createLinearGradient(0, 0, 0, h);
  sky.addColorStop(0, "#0b1a2b");
  sky.addColorStop(0.55, "#123047");
  sky.addColorStop(1, "#0a1420");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, h);

  const cosPitch = Math.cos(s.pitch + s.recoilPitch);
  const groundY = cy + (focal * (1.6 + s.py)) / Math.max(0.25, cosPitch);
  ctx.fillStyle = "#0d1b16";
  ctx.fillRect(0, Math.min(h, groundY), w, h);

  ctx.strokeStyle = "rgba(120,255,170,0.13)";
  ctx.lineWidth = 1 * dpr;
  for (let i = -16; i <= 16; i++) {
    const a = project({ x: s.px + i * 2, y: 0, z: s.pz - 24 }, origin, basis, focal, cx, cy);
    const b = project({ x: s.px + i * 2, y: 0, z: s.pz + 24 }, origin, basis, focal, cx, cy);
    if (!a || !b) continue;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }
  for (let i = -12; i <= 12; i++) {
    const a = project({ x: s.px - 24, y: 0, z: s.pz + i * 2 }, origin, basis, focal, cx, cy);
    const b = project({ x: s.px + 24, y: 0, z: s.pz + i * 2 }, origin, basis, focal, cx, cy);
    if (!a || !b) continue;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  for (const t of s.targets) {
    const pr = project(t, origin, basis, focal, cx, cy);
    if (!pr) continue;
    const r = Math.max(3, (t.r * focal) / pr.z);
    ctx.globalAlpha = t.alive ? 1 : 0.3;
    ctx.fillStyle = t.alive ? "#f97316" : "#334155";
    ctx.beginPath();
    ctx.arc(pr.x, pr.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.8)";
    ctx.lineWidth = 2 * dpr;
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  for (const g of s.grenades) {
    const pr = project(g, origin, basis, focal, cx, cy);
    if (!pr) continue;
    const r = Math.max(2, (0.18 * focal) / pr.z);
    ctx.fillStyle = "#facc15";
    ctx.beginPath();
    ctx.arc(pr.x, pr.y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const spread = 6 * dpr + (Math.abs(s.recoilPitch) / 4) * 26 * dpr;
  ctx.strokeStyle = "#a3e635";
  ctx.lineWidth = 2 * dpr;
  ctx.beginPath();
  ctx.moveTo(cx - spread - 10 * dpr, cy);
  ctx.lineTo(cx - spread, cy);
  ctx.moveTo(cx + spread, cy);
  ctx.lineTo(cx + spread + 10 * dpr, cy);
  ctx.moveTo(cx, cy - spread - 10 * dpr);
  ctx.lineTo(cx, cy - spread);
  ctx.moveTo(cx, cy + spread);
  ctx.lineTo(cx, cy + spread + 10 * dpr);
  ctx.stroke();
  ctx.fillStyle = "#a3e635";
  ctx.beginPath();
  ctx.arc(cx, cy, 2 * dpr, 0, Math.PI * 2);
  ctx.fill();

  if (cfg.showTouchTrail) {
    for (const p of s.trail) {
      ctx.fillStyle = `rgba(56,189,248,${Math.max(0, p.life) * 0.5})`;
      ctx.beginPath();
      ctx.arc((p.x / 100) * w, (p.y / 100) * h, 4 * dpr, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.fillStyle = "rgba(0,0,0,0.45)";
  ctx.fillRect(10 * dpr, h - 26 * dpr, 120 * dpr, 8 * dpr);
  const rec = Math.min(1, Math.abs(s.recoilPitch) / 8);
  ctx.fillStyle = rec > 0.6 ? "#fb7185" : "#facc15";
  ctx.fillRect(10 * dpr, h - 26 * dpr, 120 * dpr * rec, 8 * dpr);

  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.font = `${13 * dpr}px ui-monospace, monospace`;
  ctx.textAlign = "right";
  ctx.fillText(`${s.ammo}`, w - 14 * dpr, h - 20 * dpr);
  ctx.textAlign = "left";
}
