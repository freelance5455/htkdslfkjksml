import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Edit3,
  Trash2,
  ArrowUpDown,
  FileSpreadsheet,
} from 'lucide-react';
import {
  Account,
  DebtRecord,
  SubscriptionRecord,
  TransactionRecord,
  TransactionType,
} from '../types/finance';
import {
  formatBDT,
  formatDateBnEn,
  getCurrentYearMonth,
  getTodayISO,
} from '../utils/money';
import {
  buildUnifiedLedger,
  LedgerSourceGroup,
  UnifiedLedgerItem,
} from '../utils/unifiedLedger';

interface TransactionsModuleProps {
  transactions: TransactionRecord[];
  debts: DebtRecord[];
  subscriptions: SubscriptionRecord[];
  accounts: Account[];
  useBengaliDigits: boolean;
  onAddTransaction: (type?: TransactionType) => void;
  onEditTransaction: (tx: TransactionRecord) => void;
  onDeleteLedgerItem: (item: UnifiedLedgerItem) => void;
  onExportUnifiedCSV: (items: UnifiedLedgerItem[]) => void;
}

type DateFilterMode = 'ALL' | 'TODAY' | 'THIS_MONTH' | 'CUSTOM';

export const TransactionsModule: React.FC<TransactionsModuleProps> = ({
  transactions,
  debts,
  subscriptions,
  accounts,
  useBengaliDigits,
  onAddTransaction,
  onEditTransaction,
  onDeleteLedgerItem,
  onExportUnifiedCSV,
}) => {
  const todayISO = getTodayISO();
  const currentYM = getCurrentYearMonth();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<'ALL' | LedgerSourceGroup>('ALL');
  const [selectedAccountId, setSelectedAccountId] = useState<string>('ALL');
  const [dateFilterMode, setDateFilterMode] = useState<DateFilterMode>('ALL');
  const [customStartDate, setCustomStartDate] = useState(`${currentYM}-01`);
  const [customEndDate, setCustomEndDate] = useState(todayISO);

  const allLedgerItems = useMemo(
    () =>
      buildUnifiedLedger({
        transactions,
        debts,
        subscriptions,
        accounts,
      }),
    [transactions, debts, subscriptions, accounts]
  );

  const filteredItems = useMemo(() => {
    return allLedgerItems.filter((item) => {
      if (selectedGroup !== 'ALL' && item.sourceGroup !== selectedGroup) {
        return false;
      }
      if (
        selectedAccountId !== 'ALL' &&
        item.accountId !== selectedAccountId
      ) {
        return false;
      }

      if (dateFilterMode === 'TODAY' && item.date !== todayISO) return false;
      if (dateFilterMode === 'THIS_MONTH' && !item.date.startsWith(currentYM))
        return false;
      if (dateFilterMode === 'CUSTOM') {
        if (customStartDate && item.date < customStartDate) return false;
        if (customEndDate && item.date > customEndDate) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = item.titleBn.toLowerCase().includes(q);
        const matchCat = item.categoryBn.toLowerCase().includes(q);
        const matchType = item.typeLabelBn.toLowerCase().includes(q);
        const matchAcc = item.accountNameBn.toLowerCase().includes(q);
        if (!matchTitle && !matchCat && !matchType && !matchAcc) return false;
      }

      return true;
    });
  }, [
    allLedgerItems,
    selectedGroup,
    selectedAccountId,
    dateFilterMode,
    customStartDate,
    customEndDate,
    searchQuery,
    todayISO,
    currentYM,
  ]);

  const reportTotals = useMemo(() => {
    let totalIncome = 0;
    let totalExpense = 0;
    let totalDebtActivity = 0;
    let totalBillActivity = 0;

    for (const item of filteredItems) {
      if (item.sourceGroup === 'INCOME') {
        totalIncome += item.amountPaisa;
      } else if (item.sourceGroup === 'EXPENSE') {
        totalExpense += item.amountPaisa;
      } else if (item.sourceGroup === 'DEBT') {
        totalDebtActivity += item.amountPaisa;
      } else if (item.sourceGroup === 'BILL') {
        totalBillActivity += item.amountPaisa;
        if (item.sourceKind === 'TRANSACTION' || item.sourceKind === 'SUBSCRIPTION_PAYMENT') {
          totalExpense += item.amountPaisa;
        }
      }
    }

    return {
      totalIncome,
      totalExpense,
      totalDebtActivity,
      totalBillActivity,
    };
  }, [filteredItems]);

  return (
    <div className="space-y-6">
      {/* Header & Primary Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            সকল লেনদেনের খতিয়ান
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
            আয়, ব্যয়, দেনা-পাওনা, কিস্তি এবং নিয়মিত বিলের সম্মিলিত তালিকা
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => onExportUnifiedCSV(filteredItems)}
            className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white/90 dark:bg-slate-900/90 hover:bg-white dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>সিএসভি ডাউনলোড</span>
          </button>
          <button
            type="button"
            onClick={() => onAddTransaction('EXPENSE')}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন হিসাব যোগ করুন</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-5 space-y-4 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="বিবরণ, নাম, খাত বা হিসাব দিয়ে খুঁজুন..."
              className="w-full min-h-[44px] pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/80 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div className="md:col-span-3">
            <select
              value={selectedAccountId}
              onChange={(e) => setSelectedAccountId(e.target.value)}
              aria-label="হিসাব ফিল্টার"
              className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/80 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="ALL">সকল হিসাব</option>
              {accounts.map((acc) => (
                <option key={acc.id} value={acc.id}>
                  {acc.nameBn}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-4 flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            {(
              [
                { mode: 'ALL', label: 'সব' },
                { mode: 'TODAY', label: 'আজ' },
                { mode: 'THIS_MONTH', label: 'এই মাস' },
                { mode: 'CUSTOM', label: 'নির্দিষ্ট তারিখ' },
              ] as { mode: DateFilterMode; label: string }[]
            ).map((item) => (
              <button
                key={item.mode}
                type="button"
                onClick={() => setDateFilterMode(item.mode)}
                className={`flex-1 min-h-[36px] px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  dateFilterMode === item.mode
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {dateFilterMode === 'CUSTOM' && (
          <div className="pt-2 flex flex-wrap items-center gap-4 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-500">শুরু:</label>
              <input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-500">শেষ:</label>
              <input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>
        )}

        {/* Unified Source Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(
            [
              { group: 'ALL', label: `সকল লেনদেন (${allLedgerItems.length})` },
              { group: 'INCOME', label: 'আয়' },
              { group: 'EXPENSE', label: 'ব্যয়' },
              { group: 'DEBT', label: 'দেনা-পাওনা ও কিস্তি' },
              { group: 'BILL', label: 'নিয়মিত বিল' },
            ] as { group: 'ALL' | LedgerSourceGroup; label: string }[]
          ).map((tab) => (
            <button
              key={tab.group}
              type="button"
              onClick={() => setSelectedGroup(tab.group)}
              className={`min-h-[38px] px-4 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                selectedGroup === tab.group
                  ? 'bg-emerald-700 text-white dark:bg-emerald-600 dark:text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </section>

      {/* Filtered Summary Strip */}
      <section className="rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 p-5 grid grid-cols-2 sm:grid-cols-4 gap-4 shadow-xs">
        <div>
          <p className="text-xs text-slate-500 dark:text-slate-400">মোট আয়</p>
          <p className="mt-1 text-lg font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
            +{formatBDT(reportTotals.totalIncome, { useBengaliDigits })}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500 dark:text-slate-400">মোট ব্যয় ও বিল</p>
          <p className="mt-1 text-lg font-bold font-mono tabular-nums text-red-600 dark:text-red-400">
            -{formatBDT(reportTotals.totalExpense, { useBengaliDigits })}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500 dark:text-slate-400">দেনা-পাওনা ও কিস্তি</p>
          <p className="mt-1 text-lg font-bold font-mono tabular-nums text-amber-700 dark:text-amber-400">
            {formatBDT(reportTotals.totalDebtActivity, { useBengaliDigits })}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500 dark:text-slate-400">নিয়মিত বিল</p>
          <p className="mt-1 text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {formatBDT(reportTotals.totalBillActivity, { useBengaliDigits })}
          </p>
        </div>
      </section>

      {/* Unified Transactions List */}
      <section className="rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200/90 dark:border-slate-800 overflow-hidden shadow-xs">
        {filteredItems.length === 0 ? (
          <div className="p-12 text-center">
            <ArrowUpDown className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
              কোনো লেনদেন পাওয়া যায়নি
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              তারিখ বা ফিল্টার পরিবর্তন করুন অথবা নতুন হিসাব যোগ করুন।
            </p>
            <button
              type="button"
              onClick={() => onAddTransaction('INCOME')}
              className="mt-4 min-h-[44px] px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-medium"
            >
              + নতুন হিসাব যোগ করুন
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredItems.map((item) => {
              const isInflow = item.flowDirection === 'IN';
              const isDebt = item.sourceGroup === 'DEBT';
              const isBill = item.sourceGroup === 'BILL';

              return (
                <div
                  key={item.id}
                  className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 hover:bg-emerald-50/40 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                      {item.titleBn}
                    </p>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <span
                        className={`font-semibold ${
                          item.sourceGroup === 'INCOME'
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : isDebt
                            ? 'text-amber-700 dark:text-amber-400'
                            : isBill
                            ? 'text-teal-700 dark:text-teal-400'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {item.typeLabelBn}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>খাত: {item.categoryBn}</span>
                      <span aria-hidden="true">·</span>
                      <span>হিসাব: {item.accountNameBn}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatDateBnEn(item.date, useBengaliDigits)}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 dark:border-slate-800">
                    <span
                      className={`text-base font-bold font-mono tabular-nums ${
                        isInflow
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-red-600 dark:text-red-400'
                      }`}
                    >
                      {isInflow ? '+' : '-'}
                      {formatBDT(item.amountPaisa, { useBengaliDigits })}
                    </span>

                    <div className="flex items-center gap-1">
                      {item.rawTransaction && (
                        <button
                          type="button"
                          onClick={() => onEditTransaction(item.rawTransaction!)}
                          className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          title="সম্পাদনা"
                          aria-label="সম্পাদনা"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onDeleteLedgerItem(item)}
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50 transition-colors"
                        title="মুছে ফেলুন"
                        aria-label="মুছে ফেলুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
