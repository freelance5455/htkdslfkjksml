import { useEffect, useRef, useState } from 'react';
import Markdown from 'react-markdown';
import { Check, Copy, RotateCcw, AlertCircle, ArrowUpRight } from 'lucide-react';
import type { ChatMessage } from '../types/chat';

interface ChatMessageListProps {
  messages: ChatMessage[];
  isStreaming: boolean;
  onSelectStarter: (question: string) => void;
  onRetry: () => void;
}

const STARTER_QUESTIONS = [
  {
    label: 'የኢትዮጵያ ቡና አመጣጥ',
    question: 'የኢትዮጵያ ቡና አመጣጥ እና ባህላዊ ጠቀሜታ በአጭሩ አብራራልኝ።',
    hint: 'Amharic',
  },
  {
    label: 'Explain photosynthesis',
    question: 'What is photosynthesis and why is it important for life on Earth?',
    hint: 'Ask in English · Answer in Amharic',
  },
  {
    label: 'ለጤናማ አኗኗር ምክሮች',
    question: 'በየቀኑ ጤናማ እና ንቁ ሆኖ ለመቆየት 5 ቀላል ልምዶችን ንገረኝ።',
    hint: 'Amharic',
  },
  {
    label: 'Write a polite email',
    question: 'Help me write a polite message asking my manager for two days off next week.',
    hint: 'Ask in English · Answer in Amharic',
  },
];

function formatTime(timestamp: number): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      hour: 'numeric',
      minute: '2-digit',
    }).format(new Date(timestamp));
  } catch {
    return '';
  }
}

export function ChatMessageList({
  messages,
  isStreaming,
  onSelectStarter,
  onRetry,
}: ChatMessageListProps) {
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, isStreaming]);

  const handleCopy = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => {
        setCopiedId((prev) => (prev === id ? null : prev));
      }, 2000);
    } catch {
      // Clipboard API unavailable
    }
  };

  if (messages.length === 0) {
    return (
      <div className="flex-1 overflow-y-auto overscroll-contain px-4 py-8 sm:px-6 lg:py-12">
        <div className="mx-auto max-w-2xl">
          <div className="mb-8">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl [text-wrap:balance]">
              ሰላም! እንዴት ልረዳዎት እችላለሁ?
            </h1>
            <p className="mt-2.5 text-base leading-relaxed text-slate-600">
              Ask any question in <span className="font-medium text-slate-900">Amharic</span> or{' '}
              <span className="font-medium text-slate-900">English</span>. Dawitai answers in clear
              Amharic by default.
            </p>
          </div>

          <div className="space-y-2.5">
            <p className="text-xs font-medium text-slate-500">
              Tap a question to try Dawitai
            </p>
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {STARTER_QUESTIONS.map((item) => (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => onSelectStarter(item.question)}
                  className="group flex min-h-[60px] w-full items-start justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 text-left transition-colors duration-150 hover:border-teal-600/40 hover:bg-teal-50/30 active:scale-[0.99] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-900 group-hover:text-teal-800">
                      {item.label}
                    </div>
                    <div className="mt-1 text-xs text-slate-500">{item.hint}</div>
                  </div>
                  <ArrowUpRight
                    className="mt-0.5 h-4 w-4 shrink-0 text-slate-400 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-teal-700"
                    aria-hidden="true"
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="flex-1 overflow-y-auto overscroll-contain px-4 py-5 sm:px-6 lg:py-8"
      aria-live="polite"
    >
      <div className="mx-auto flex max-w-3xl flex-col gap-6">
        {messages.map((msg, index) => {
          const isLast = index === messages.length - 1;
          const isCurrentlyStreaming = isStreaming && isLast && msg.role === 'assistant';

          if (msg.role === 'user') {
            return (
              <div key={msg.id} className="flex flex-col items-end">
                <div className="max-w-[88%] rounded-2xl rounded-br-md bg-[#0F766E] px-4 py-3 text-[15px] leading-relaxed text-white shadow-xs sm:max-w-[78%] sm:text-base">
                  <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                </div>
                <span className="mt-1.5 px-1 text-xs text-slate-400 tabular-nums">
                  You · {formatTime(msg.createdAt)}
                </span>
              </div>
            );
          }

          return (
            <div key={msg.id} className="flex flex-col items-start">
              <div className="w-full rounded-2xl border border-slate-200/90 bg-white px-4 py-4 shadow-xs sm:px-5 sm:py-5">
                <div className="mb-2.5 flex items-center justify-between gap-3 border-b border-slate-100 pb-2.5">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-slate-900">Dawitai</span>
                    <span aria-hidden="true">·</span>
                    <span>{msg.replyLanguage === 'english' ? 'English' : 'አማርኛ'}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{formatTime(msg.createdAt)}</span>
                  </div>

                  {!isCurrentlyStreaming && msg.content && !msg.error && (
                    <button
                      type="button"
                      onClick={() => handleCopy(msg.id, msg.content)}
                      aria-label={copiedId === msg.id ? 'Copied answer' : 'Copy answer'}
                      className="-my-2 -mr-2 flex min-h-[44px] min-w-[44px] items-center justify-center gap-1.5 rounded-xl px-2.5 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-teal-700"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="h-4 w-4 text-teal-700" aria-hidden="true" />
                          <span className="text-teal-700">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4" aria-hidden="true" />
                          <span className="hidden sm:inline">Copy</span>
                        </>
                      )}
                    </button>
                  )}
                </div>

                {msg.error ? (
                  <div className="flex flex-col gap-3 rounded-xl bg-red-50 p-3.5 text-sm text-red-900">
                    <div className="flex items-start gap-2.5">
                      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
                      <p className="leading-relaxed">{msg.content}</p>
                    </div>
                    {isLast && !isStreaming && (
                      <div>
                        <button
                          type="button"
                          onClick={onRetry}
                          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-2 text-xs font-semibold text-red-800 transition-colors hover:bg-red-100 focus-visible:outline-2 focus-visible:outline-red-700"
                        >
                          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Try again</span>
                        </button>
                      </div>
                    )}
                  </div>
                ) : msg.content ? (
                  <div className="prose-dawitai text-[15px] text-slate-800 sm:text-base">
                    <Markdown>{msg.content}</Markdown>
                    {isCurrentlyStreaming && (
                      <span
                        className="ml-1 inline-block h-4 w-1.5 translate-y-0.5 animate-pulse rounded-xs bg-teal-700"
                        aria-hidden="true"
                      />
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 py-1 text-sm text-slate-500">
                    <span className="inline-block h-2 w-2 animate-bounce rounded-full bg-teal-700 [animation-delay:-0.2s]" />
                    <span className="inline-block h-2 w-2 animate-bounce rounded-full bg-teal-700 [animation-delay:-0.1s]" />
                    <span className="inline-block h-2 w-2 animate-bounce rounded-full bg-teal-700" />
                    <span className="ml-1">Dawitai is thinking...</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} className="h-2" />
      </div>
    </div>
  );
}
