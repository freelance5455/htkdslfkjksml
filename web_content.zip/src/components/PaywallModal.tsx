import React, { useState } from 'react';
import { X, Check, Lock, Sparkles, Users, CreditCard } from 'lucide-react';
import { TierLevel } from '../types';
import { TIERS_CONFIG } from '../data/tiers';
import confetti from 'canvas-confetti';

interface PaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetTier?: TierLevel;
  inviteCount: number;
  paidInviteCount: number;
  onSubscribeDirectly: (plan: 'monthly' | 'annual') => void;
  onSimulateInviteePayment: () => void;
  inviteCode: string;
}

export const PaywallModal: React.FC<PaywallModalProps> = ({
  isOpen,
  onClose,
  targetTier = 3,
  paidInviteCount,
  onSubscribeDirectly,
  onSimulateInviteePayment,
  inviteCode,
}) => {
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'annual'>('annual');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const targetConfig = TIERS_CONFIG[targetTier];
  const neededPaidInvites = targetConfig.requiredPaidInvites;

  const handleCopy = () => {
    navigator.clipboard.writeText(`https://calai.app/join?ref=${inviteCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDirectPayment = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
    onSubscribeDirectly(selectedPlan);
    onClose();
  };

  const handleFriendPay = () => {
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 },
    });
    onSimulateInviteePayment();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header banner */}
        <div className="p-6 bg-gradient-to-br from-amber-500/20 via-slate-900 to-slate-900 border-b border-slate-800">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/80 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold mb-2">
            <Lock className="w-4 h-4" />
            <span>نظام المستويات والاشتراك الإجباري</span>
          </div>

          <h2 className="text-xl font-bold text-white tracking-tight">
            الترقية إلى {targetConfig.nameAr}
          </h2>
          <p className="text-sm text-slate-300 mt-1 leading-relaxed">
            وفقاً لنظام التطبيق: بداية من المستوى 3 وما فوق، الدفع إجباري للحصول على الميزات الاحترافية عبر أحد المسارين أدناه.
          </p>
        </div>

        <div className="p-6 space-y-6">
          {/* Rule Card */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="text-xs font-bold text-slate-400 tracking-wider">
              قاعدة فتح المستوى 3 وفوق:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800/80">
                <span className="font-bold text-emerald-400 block mb-1">المسار الأول: اشتراكك المباشر</span>
                <span className="text-slate-400">اشترك مباشرة في الخطة لتفعيل المستوى فوراً لك وحدك.</span>
              </div>
              <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800/80">
                <span className="font-bold text-amber-400 block mb-1">المسار الثاني: اشتراك مدعويك</span>
                <span className="text-slate-400">
                  اشترك {paidInviteCount} من أصل {neededPaidInvites} مدعوين مطلوبين لفتح المستوى مجاناً لك!
                </span>
              </div>
            </div>
          </div>

          {/* Path 1: Direct Subscription Options */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                المسار الأول: الاشتراك الشخصي المباشر
              </span>
              <span className="text-xs text-emerald-400 font-semibold">تفعيل فوري</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setSelectedPlan('annual')}
                className={`p-3.5 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedPlan === 'annual'
                    ? 'border-emerald-500 bg-emerald-950/20 shadow-sm shadow-emerald-500/10'
                    : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-emerald-400">الخطة السنوية</span>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded">وفر 50%</span>
                </div>
                <div className="text-base font-bold text-white tabular-nums">$59.99 <span className="text-xs font-normal text-slate-400">/سنة</span></div>
                <div className="text-[11px] text-slate-400 mt-1">ما يعادل $4.99/شهر فقط</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPlan('monthly')}
                className={`p-3.5 rounded-xl border text-right transition-all cursor-pointer ${
                  selectedPlan === 'monthly'
                    ? 'border-emerald-500 bg-emerald-950/20 shadow-sm shadow-emerald-500/10'
                    : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-slate-300 mb-1">الخطة الشهرية</div>
                <div className="text-base font-bold text-white tabular-nums">$9.99 <span className="text-xs font-normal text-slate-400">/شهر</span></div>
                <div className="text-[11px] text-slate-400 mt-1">تجدد شهرياً، إلغاء بأي وقت</div>
              </button>
            </div>

            <button
              onClick={handleDirectPayment}
              className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition-transform active:scale-[0.99] cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>تأكيد الاشتراك وتفعيل المستوى 3 فوراً</span>
            </button>
          </div>

          {/* Divider */}
          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-800"></div>
            <span className="shrink-0 mx-4 text-xs font-semibold text-slate-500">أو بدلاً من الدفع</span>
            <div className="flex-grow border-t border-slate-800"></div>
          </div>

          {/* Path 2: Invite Friends to Pay */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white flex items-center gap-1.5">
                <Users className="w-4 h-4 text-amber-400" />
                المسار الثاني: دعوة أصدقاء يشتركون
              </span>
              <span className="text-xs font-semibold text-amber-400 tabular-nums">
                {paidInviteCount} / {neededPaidInvites} مشتركين
              </span>
            </div>

            <p className="text-xs text-slate-400">
              إذا اشترك {neededPaidInvites} من أصدقائك الذين دعوتهم برابطك، ستفتح ميزات المستوى مجاناً تماماً لك!
            </p>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={`https://calai.app/join?ref=${inviteCode}`}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-300 dir-ltr"
              />
              <button
                onClick={handleCopy}
                className="shrink-0 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-medium transition-colors cursor-pointer"
              >
                {copied ? 'تم النسخ!' : 'نسخ الرابط'}
              </button>
            </div>

            {/* Test Simulation Button */}
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">لتجربة الفتح فوراً بدون دفع حقيقي:</span>
              <button
                onClick={handleFriendPay}
                className="px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                + محاكاة اشتراك صديق مدعو
              </button>
            </div>
          </div>

          {/* Features preview list */}
          <div className="pt-1">
            <div className="text-xs font-semibold text-slate-400 mb-2">ميزات {targetConfig.nameAr}:</div>
            <ul className="space-y-1.5">
              {targetConfig.featuresAr.map((feat, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
