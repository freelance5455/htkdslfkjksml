import React, { useState, useEffect } from 'react';
import { LauncherSettings } from '../types/launcher';
import {
  X,
  Zap,
  Volume2,
  Tv,
  Wifi,
  Cable,
  Monitor,
  ExternalLink,
  RotateCcw,
  Terminal,
} from 'lucide-react';

interface SettingsDrawerProps {
  isOpen: boolean;
  settings: LauncherSettings;
  onClose: () => void;
  onUpdateSettings: (newSettings: Partial<LauncherSettings>) => void;
  onOpenWifiModal: () => void;
  onOpenInputModal: () => void;
  onLaunchAndroidSettings: () => void;
  onResetCatalog: () => void;
}

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  settings,
  onClose,
  onUpdateSettings,
  onOpenWifiModal,
  onOpenInputModal,
  onLaunchAndroidSettings,
  onResetCatalog,
}) => {
  const [copied, setCopied] = useState(false);
  const [focusIndex, setFocusIndex] = useState(0);

  // Targets:
  // 0: "Launch OS Settings"
  // 1: "Wi-Fi Network"
  // 2: "TV Inputs"
  // 3: "Low-End Hardware Mode" toggle
  // 4: "Navigation Audio" toggle
  // 5: "Reset Dock"
  // 6: "Close"
  const totalTargets = 7;

  useEffect(() => {
    if (isOpen) {
      setFocusIndex(0);
    }
  }, [isOpen]);

  const adbSettingsCommand = 'adb shell am start -a android.settings.SETTINGS';

  const handleCopyAdb = () => {
    navigator.clipboard.writeText(adbSettingsCommand).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Keyboard & TV remote navigation inside drawer
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.keyCode === 20) {
        e.preventDefault();
        setFocusIndex((prev) => (prev < totalTargets - 1 ? prev + 1 : 0));
      } else if (e.key === 'ArrowUp' || e.keyCode === 19) {
        e.preventDefault();
        setFocusIndex((prev) => (prev > 0 ? prev - 1 : totalTargets - 1));
      } else if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 23 || e.keyCode === 66) {
        e.preventDefault();
        if (focusIndex === 0) {
          onLaunchAndroidSettings();
        } else if (focusIndex === 1) {
          onClose();
          onOpenWifiModal();
        } else if (focusIndex === 2) {
          onClose();
          onOpenInputModal();
        } else if (focusIndex === 3) {
          onUpdateSettings({ performanceMode: !settings.performanceMode });
        } else if (focusIndex === 4) {
          onUpdateSettings({ soundEffects: !settings.soundEffects });
        } else if (focusIndex === 5) {
          if (window.confirm('Reset dock apps?')) {
            onResetCatalog();
            onClose();
          }
        } else if (focusIndex === 6) {
          onClose();
        }
      } else if (e.key === 'Escape' || e.key === 'Backspace' || e.keyCode === 4 || e.keyCode === 111) {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isOpen,
    focusIndex,
    totalTargets,
    settings.performanceMode,
    settings.soundEffects,
    onLaunchAndroidSettings,
    onClose,
    onOpenWifiModal,
    onOpenInputModal,
    onUpdateSettings,
    onResetCatalog,
  ]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-xs select-none animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md h-full bg-[#101217] border-l border-white/15 p-6 md:p-8 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-200 text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div>
          <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                <Tv className="w-5 h-5 text-sky-400" />
                <span>TV System Settings</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Navigate with Remote Arrow Keys & OK
              </p>
            </div>
            <button
              onClick={onClose}
              className={`p-2 rounded-full transition-all cursor-pointer outline-hidden ${
                focusIndex === 6 ? 'bg-white text-slate-950 ring-2 ring-white' : 'bg-white/10 text-slate-300 hover:text-white'
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4 text-xs">
            {/* Direct Android TV Settings Link (Item 0) */}
            <div
              className={`p-4 rounded-2xl border transition-all ${
                focusIndex === 0
                  ? 'bg-sky-500/20 border-white ring-4 ring-white shadow-2xl'
                  : 'bg-sky-500/10 border-sky-500/20'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <Monitor className="w-4 h-4 text-sky-400" />
                  <span>Android TV OS Settings</span>
                </div>
                <button
                  onClick={onLaunchAndroidSettings}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer ${
                    focusIndex === 0 ? 'bg-white text-slate-950 font-bold' : 'bg-sky-500 text-white'
                  }`}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Launch OS Settings</span>
                </button>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Directly opens your television's native Android TV settings panel for system updates, Bluetooth remotes, and account setup.
              </p>
            </div>

            {/* Quick Links: Wi-Fi & TV Inputs (Items 1 & 2) */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  onClose();
                  onOpenWifiModal();
                }}
                className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer outline-hidden ${
                  focusIndex === 1
                    ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl border-white font-semibold'
                    : 'bg-white/5 hover:bg-white/10 border border-white/10 text-white'
                }`}
              >
                <div className={`flex items-center gap-2 font-semibold mb-1 ${focusIndex === 1 ? 'text-slate-950 font-bold' : 'text-emerald-400'}`}>
                  <Wifi className="w-4 h-4" />
                  <span>Wi-Fi Network</span>
                </div>
                <p className={`text-[11px] font-mono truncate ${focusIndex === 1 ? 'text-slate-800' : 'text-slate-300'}`}>{settings.connectedWifiSsid}</p>
                <p className={`text-[10px] mt-0.5 ${focusIndex === 1 ? 'text-slate-600' : 'text-slate-500'}`}>Press OK</p>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenInputModal();
                }}
                className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer outline-hidden ${
                  focusIndex === 2
                    ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl border-white font-semibold'
                    : 'bg-white/5 hover:bg-white/10 border border-white/10 text-white'
                }`}
              >
                <div className={`flex items-center gap-2 font-semibold mb-1 ${focusIndex === 2 ? 'text-slate-950 font-bold' : 'text-sky-400'}`}>
                  <Cable className="w-4 h-4" />
                  <span>TV Inputs</span>
                </div>
                <p className={`text-[11px] uppercase font-mono ${focusIndex === 2 ? 'text-slate-800' : 'text-slate-300'}`}>{settings.activeInput}</p>
                <p className={`text-[10px] mt-0.5 ${focusIndex === 2 ? 'text-slate-600' : 'text-slate-500'}`}>Press OK</p>
              </button>
            </div>

            {/* Performance Mode (Item 3) */}
            <div
              className={`p-4 rounded-2xl border transition-all ${
                focusIndex === 3 ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl border-white' : 'bg-white/5 border-white/10 text-white'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-xl border ${focusIndex === 3 ? 'bg-slate-950 text-white' : 'bg-amber-500/20 text-amber-400 border-amber-500/30'}`}>
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className={`text-sm font-semibold ${focusIndex === 3 ? 'text-slate-950 font-bold' : 'text-white'}`}>Low-End Hardware Mode</h3>
                    <p className={`mt-1 leading-relaxed text-[11px] ${focusIndex === 3 ? 'text-slate-700' : 'text-slate-400'}`}>
                      Bypasses background blurs for guaranteed 60 FPS on low-power TV sticks.
                    </p>
                  </div>
                </div>

                <div
                  className={`w-12 h-6.5 rounded-full transition-colors relative shrink-0 ${
                    settings.performanceMode ? 'bg-amber-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`block w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-200 absolute top-0.5 ${
                      settings.performanceMode ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </div>
              </div>
            </div>

            {/* Synthetic Sound Effects (Item 4) */}
            <div
              className={`p-4 rounded-2xl border transition-all space-y-2 ${
                focusIndex === 4 ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl border-white' : 'bg-white/5 border-white/10 text-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Volume2 className={`w-4 h-4 ${focusIndex === 4 ? 'text-slate-950' : 'text-sky-400'}`} />
                  <span className={`font-semibold text-sm ${focusIndex === 4 ? 'text-slate-950 font-bold' : 'text-white'}`}>Navigation Audio Feedback</span>
                </div>
                <div
                  className={`w-12 h-6.5 rounded-full transition-colors relative ${
                    settings.soundEffects ? 'bg-sky-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`block w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-200 absolute top-0.5 ${
                      settings.soundEffects ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </div>
              </div>
              <p className={`text-[11px] ${focusIndex === 4 ? 'text-slate-700' : 'text-slate-400'}`}>
                Directional click sounds synthesized with Web Audio API. Press OK to toggle.
              </p>
            </div>

            {/* Android ADB Settings Command */}
            <div className="p-3 rounded-2xl bg-black/40 border border-white/10 text-xs">
              <div className="flex items-center justify-between mb-1">
                <span className="flex items-center gap-1 text-[10px] font-mono text-amber-400">
                  <Terminal className="w-3.5 h-3.5" />
                  ADB Settings Intent
                </span>
                <button
                  onClick={handleCopyAdb}
                  className="text-[10px] text-slate-300 hover:text-white px-2 py-0.5 rounded bg-white/10 cursor-pointer"
                >
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <p className="font-mono text-[11px] text-slate-300 truncate">{adbSettingsCommand}</p>
            </div>
          </div>
        </div>

        {/* Footer (Item 5: Reset Dock) */}
        <div className="pt-4 border-t border-white/10">
          <button
            onClick={() => {
              if (window.confirm('Reset dock apps?')) {
                onResetCatalog();
                onClose();
              }
            }}
            className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold border transition-all cursor-pointer text-xs outline-hidden ${
              focusIndex === 5
                ? 'bg-red-500 text-white ring-4 ring-white shadow-2xl scale-102 border-white'
                : 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border-white/10'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Dock to Defaults</span>
          </button>
        </div>
      </div>
    </div>
  );
};
