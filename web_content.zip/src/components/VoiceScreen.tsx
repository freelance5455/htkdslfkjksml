import React, { useState, useEffect, useRef } from 'react';
import { BotVoiceState, ChatMessage, UserProfile } from '../types';
import { BotAvatar } from './BotAvatar';
import { AudioWaveVisualizer } from './AudioWaveVisualizer';
import { speechManager } from '../utils/speechUtils';
import {
  playMicTone,
  playReplyTone,
  playClickTone,
} from '../utils/audioEffects';
import { liveAudioAnalyser } from '../utils/liveAudioVisualizer';
import {
  Mic,
  MicOff,
  Settings,
  MessageSquare,
  Volume2,
  VolumeX,
  Keyboard,
  Send,
  Sparkles,
  RotateCcw,
  Check,
  Copy,
  Info,
} from 'lucide-react';

interface VoiceScreenProps {
  profile: UserProfile;
  messages: ChatMessage[];
  onAddMessage: (msg: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  onOpenSettings: () => void;
  onOpenHistory: () => void;
  currentUser: any | null;
  onOpenAuth: (mode?: 'login' | 'signup') => void;
  onSignOut: () => void;
}

export const VoiceScreen: React.FC<VoiceScreenProps> = ({
  profile,
  messages,
  onAddMessage,
  onOpenSettings,
  onOpenHistory,
  currentUser,
  onOpenAuth,
  onSignOut,
}) => {
  const [botState, setBotState] = useState<BotVoiceState>('idle');
  const [statusText, setStatusText] = useState('بات کرنے کے لیے مائیک دبائیں');
  const [currentTranscript, setCurrentTranscript] = useState('');
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);
  const [keyboardText, setKeyboardText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [micErrorNotice, setMicErrorNotice] = useState<string | null>(null);
  const [liveMicVolume, setLiveMicVolume] = useState<number>(0);

  const initialGreetingDone = useRef(false);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Clean up Web Audio stream & audio playback on unmount
  useEffect(() => {
    return () => {
      liveAudioAnalyser.stop();
      if (currentAudioRef.current) {
        try {
          currentAudioRef.current.pause();
          currentAudioRef.current = null;
        } catch (e) {}
      }
    };
  }, []);

  // Get most recent user and bot messages
  const lastBotMessage = [...messages].reverse().find((m) => m.role === 'model');
  const lastUserMessage = [...messages].reverse().find((m) => m.role === 'user');

  // Initial greeting on mount (matching user's Cordova deviceready logic)
  useEffect(() => {
    if (!initialGreetingDone.current) {
      initialGreetingDone.current = true;
      const isEnglish = profile.language === 'English';
      const greeting = isEnglish
        ? profile.gender === 'Female'
          ? `Hello ${profile.name}! I'm Ayesha. How has your day been going?`
          : `Hello ${profile.name}! I'm Hamza. How has your day been going?`
        : profile.gender === 'Female'
        ? `سلام ${profile.name}! میں عائشہ ہوں۔ آج تمہارا دن کیسا رہا؟`
        : `سلام ${profile.name}! میں حمزہ ہوں۔ آج تمہارا دن کیسا رہا؟`;

      // Small delay for clean entrance
      const timer = setTimeout(() => {
        onAddMessage({
          role: 'model',
          text: greeting,
        });
        speakBotReply(greeting);
      }, 700);

      return () => clearTimeout(timer);
    }
  }, [profile.name, profile.gender, profile.language]);

  const stopAnyPlayback = () => {
    if (currentAudioRef.current) {
      try {
        currentAudioRef.current.pause();
        currentAudioRef.current.currentTime = 0;
      } catch (e) {}
      currentAudioRef.current = null;
    }
    speechManager.stopSpeaking();
  };

  // Speak bot response using Gemini TTS WAV Audio with fallback
  const speakBotReply = async (text: string, audioBase64?: string | null) => {
    stopAnyPlayback();
    setBotState('speaking');
    setStatusText(text);

    const isEnglish = profile.language === 'English';
    const defaultIdleText = isEnglish ? 'Tap mic to speak' : 'بات کرنے کے لیے مائیک دبائیں';

    // 1. If audioBase64 is passed directly from /api/chat
    if (audioBase64) {
      try {
        const audio = new Audio(`data:audio/wav;base64,${audioBase64}`);
        currentAudioRef.current = audio;
        audio.playbackRate = profile.speechRate || 1.0;

        audio.onended = () => {
          setBotState('idle');
          setStatusText(defaultIdleText);
          currentAudioRef.current = null;
        };

        audio.onerror = () => {
          fallbackBrowserTTS(text, defaultIdleText);
        };

        await audio.play();
        return;
      } catch (err) {
        console.warn('Audio play error, using fallback:', err);
      }
    }

    // 2. Fetch from server /api/tts endpoint
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          botGender: profile.gender,
          language: profile.language || 'Urdu',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audioBase64) {
          const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
          currentAudioRef.current = audio;
          audio.playbackRate = profile.speechRate || 1.0;

          audio.onended = () => {
            setBotState('idle');
            setStatusText(defaultIdleText);
            currentAudioRef.current = null;
          };

          audio.onerror = () => {
            fallbackBrowserTTS(text, defaultIdleText);
          };

          await audio.play();
          return;
        }
      }
    } catch (e) {
      console.warn('TTS API fetch failed, falling back to browser synthesis:', e);
    }

    // 3. Fallback to client browser SpeechSynthesis
    fallbackBrowserTTS(text, defaultIdleText);
  };

  const fallbackBrowserTTS = (text: string, defaultIdleText: string) => {
    speechManager.speak(text, {
      gender: profile.gender,
      language: profile.language || 'Urdu',
      rate: profile.speechRate,
      pitch: profile.speechPitch,
      onStart: () => {
        setBotState('speaking');
      },
      onEnd: () => {
        setBotState('idle');
        setStatusText(defaultIdleText);
      },
      onError: () => {
        setBotState('idle');
        setStatusText(defaultIdleText);
      },
    });
  };

  // Send query to Gemini backend /api/chat
  const sendToBackend = async (userText: string) => {
    const isEnglish = profile.language === 'English';
    setBotState('thinking');
    setStatusText(isEnglish ? 'Thinking...' : 'سوچ رہا ہوں...');
    setMicErrorNotice(null);

    // Add user message to history
    onAddMessage({
      role: 'user',
      text: userText,
    });

    try {
      // Format recent turns for conversational continuity
      const historyPayload = messages.slice(-6).map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userMessage: userText,
          userName: profile.name,
          botGender: profile.gender,
          botPersona: profile.persona,
          language: profile.language || 'Urdu',
          history: historyPayload,
        }),
      });

      const data = await response.json();
      const reply =
        data.reply ||
        (isEnglish
          ? "Sorry, I couldn't hear that clearly. Could you please say that again?"
          : 'معذرت، میں آپ کی بات سمجھ نہیں سکا۔ براہ کرم دوبارہ کہیے۔');

      playReplyTone();

      // Add bot message to history
      onAddMessage({
        role: 'model',
        text: reply,
      });

      // Speak back using authentic native audio
      speakBotReply(reply, data.audioBase64);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorReply = isEnglish
        ? 'Sorry, there was a network or server issue. Please try again.'
        : 'معذرت، انٹرنیٹ یا سرور کا مسئلہ ہے۔ دوبارہ کوشش کریں۔';
      onAddMessage({
        role: 'model',
        text: errorReply,
      });
      speakBotReply(errorReply);
    }
  };

  // Microphone toggle
  const toggleListening = async () => {
    const isEnglish = profile.language === 'English';
    const defaultIdleText = isEnglish ? 'Tap mic to speak' : 'بات کرنے کے لیے مائیک دبائیں';
    const listeningText = isEnglish ? "I'm listening..." : 'میں سن رہا ہوں...';
    const retryText = isEnglish ? 'Please try again' : 'دوبارہ کوشش کریں';
    const recLang = isEnglish ? 'en-US' : 'ur-PK';

    if (botState === 'speaking') {
      stopAnyPlayback();
      liveAudioAnalyser.stop();
      setBotState('idle');
      setStatusText(defaultIdleText);
      return;
    }

    if (botState === 'listening') {
      speechManager.stopListening();
      liveAudioAnalyser.stop();
      setBotState('idle');
      setStatusText(defaultIdleText);
      return;
    }

    playMicTone();
    setCurrentTranscript('');
    setMicErrorNotice(null);

    // Initialize Web Audio API microphone stream for real-time visualization
    try {
      await liveAudioAnalyser.start();
    } catch (e) {
      console.warn('Web Audio stream start failed:', e);
    }

    const started = speechManager.startListening(
      {
        onStart: () => {
          setBotState('listening');
          setStatusText(listeningText);
        },
        onInterimResult: (transcript) => {
          setCurrentTranscript(transcript);
          setStatusText(transcript);
        },
        onFinalResult: (transcript) => {
          liveAudioAnalyser.stop();
          if (transcript) {
            sendToBackend(transcript);
          } else {
            setBotState('idle');
            setStatusText(defaultIdleText);
          }
        },
        onError: (errMsg) => {
          liveAudioAnalyser.stop();
          setBotState('idle');
          setStatusText(retryText);
          setMicErrorNotice(errMsg);
        },
        onEnd: () => {
          liveAudioAnalyser.stop();
          setBotState((prev) => {
            if (prev === 'listening') {
              setStatusText(defaultIdleText);
              return 'idle';
            }
            return prev;
          });
        },
      },
      recLang
    );

    if (!started) {
      liveAudioAnalyser.stop();
      // If browser doesn't support mic recognition, open keyboard input drawer
      setIsKeyboardOpen(true);
      setMicErrorNotice(
        'براؤزر میں مائیک ریکگنیشن فعال نہیں ہے۔ آپ نیچے کی بورڈ سے لکھ سکتے ہیں!'
      );
    }
  };

  const handleKeyboardSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = keyboardText.trim();
    if (!text) return;

    playClickTone();
    setKeyboardText('');
    setIsKeyboardOpen(false);
    sendToBackend(text);
  };

  const handleQuickPrompt = (promptText: string) => {
    playClickTone();
    sendToBackend(promptText);
  };

  const handleCopyText = (id: string, text: string) => {
    playClickTone();
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between p-4 sm:p-6 bg-[#081225] text-white select-none overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-[#E2C067]/10 blur-3xl pointer-events-none" />

      {/* Top Header Navigation */}
      <header className="relative z-10 w-full flex items-center justify-between pb-3 border-b border-[#1e3258]/60">
        {/* User Info */}
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#1e3258] to-[#111e38] border border-[#E2C067]/50 flex items-center justify-center font-bold text-sm text-[#E2C067] shadow">
            {profile.name.slice(0, 1).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-[#E2C067]">
                {profile.name}
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[#112244] text-gray-300 border border-[#2a4365]">
                {profile.gender === 'Female' ? (profile.language === 'English' ? 'Ayesha' : 'عائشہ') : (profile.language === 'English' ? 'Hamza' : 'حمزہ')}
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[#081225] text-[#E2C067] border border-[#E2C067]/40 font-semibold">
                {profile.language === 'English' ? '🇬🇧 EN' : '🇵🇰 اردو'}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-gray-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>آن لائن (AI Companion)</span>
            </div>
          </div>
        </div>

        {/* Action Buttons: Auth, History & Settings */}
        <div className="flex items-center gap-2">
          {/* User Auth Button */}
          {currentUser ? (
            <button
              onClick={() => {
                if (window.confirm(`${currentUser.email}\nکیا آپ لاگ آؤٹ کرنا چاہتے ہیں؟ (Log out?)`)) {
                  playClickTone();
                  onSignOut();
                }
              }}
              className="py-1.5 px-2.5 rounded-xl bg-[#111e38] border border-emerald-500/40 text-emerald-300 hover:bg-emerald-950/30 text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
              title={`Logged in as ${currentUser.email}. Click to log out.`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="hidden sm:inline max-w-[80px] truncate text-[11px]">
                {currentUser.displayName || currentUser.email?.split('@')[0]}
              </span>
            </button>
          ) : (
            <button
              onClick={() => {
                playClickTone();
                onOpenAuth('login');
              }}
              className="py-1.5 px-2.5 rounded-xl bg-[#E2C067]/15 border border-[#E2C067]/50 text-[#E2C067] hover:bg-[#E2C067]/25 text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span>لاگ ان</span>
            </button>
          )}

          {/* Conversation History button with count badge */}
          <button
            onClick={() => {
              playClickTone();
              onOpenHistory();
            }}
            className="relative p-2.5 rounded-xl bg-[#111e38] border border-[#2a4365] text-[#E2C067] hover:bg-[#182c50] transition-colors cursor-pointer shadow flex items-center gap-1.5"
            title="گفتگو کی تاریخ (Conversation History)"
            aria-label="Conversation History"
          >
            <MessageSquare className="w-5 h-5" />
            <span className="hidden sm:inline text-xs font-semibold">تاریخ</span>
            {messages.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#E2C067] text-[#081225] text-[10px] font-extrabold flex items-center justify-center shadow">
                {messages.length > 99 ? '99+' : messages.length}
              </span>
            )}
          </button>

          {/* Settings button */}
          <button
            onClick={() => {
              playClickTone();
              onOpenSettings();
            }}
            className="p-2.5 rounded-xl bg-[#111e38] border border-[#2a4365] text-[#E2C067] hover:bg-[#182c50] transition-colors cursor-pointer shadow"
            title="Settings & Admin"
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Center Voice Area */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center my-3 max-w-md mx-auto w-full">
        {/* Bot Interactive Avatar */}
        <div className="mb-4">
          <BotAvatar
            gender={profile.gender}
            state={botState}
            size={155}
            liveVolume={liveMicVolume}
            onClick={toggleListening}
          />
        </div>

        {/* Real-time Audio Waveform */}
        <AudioWaveVisualizer
          state={botState}
          height={52}
          onVolumeChange={setLiveMicVolume}
        />

        {/* Dynamic Status / Subtitle Pill */}
        <div className="mt-3 w-full px-4 text-center">
          <div
            className={`inline-block py-2 px-4 rounded-2xl text-sm transition-all max-w-full ${
              botState === 'listening'
                ? 'bg-red-950/50 border border-red-500/40 text-red-200'
                : botState === 'speaking'
                ? 'bg-[#142342] border border-[#E2C067]/40 text-[#E2C067] shadow-[0_0_20px_rgba(226,192,103,0.15)]'
                : botState === 'thinking'
                ? 'bg-sky-950/50 border border-sky-500/40 text-sky-200'
                : 'bg-[#111e38]/80 border border-[#1e3258] text-gray-300'
            }`}
          >
            <p className="font-urdu text-[15px] leading-relaxed line-clamp-3">
              {statusText}
            </p>
          </div>
        </div>

        {/* Mic Error Notice if permission was denied */}
        {micErrorNotice && (
          <div className="mt-2 text-xs text-amber-300 bg-amber-950/40 border border-amber-600/30 px-3 py-1.5 rounded-xl flex items-center gap-1.5 animate-in fade-in">
            <Info className="w-3.5 h-3.5 shrink-0" />
            <span>{micErrorNotice}</span>
          </div>
        )}

        {/* Conversation Subtitle Preview Card */}
        {lastBotMessage && (
          <div className="mt-4 w-full bg-[#111e38]/70 border border-[#1e3258] rounded-2xl p-3 shadow-md">
            <div className="flex items-center justify-between text-[11px] text-gray-400 pb-1.5 border-b border-white/5">
              <span className="text-[#E2C067] font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>
                  {profile.language === 'English'
                    ? profile.gender === 'Female'
                      ? "Ayesha's reply:"
                      : "Hamza's reply:"
                    : profile.gender === 'Female'
                    ? 'عائشہ کا جواب:'
                    : 'حمزہ کا جواب:'}
                </span>
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => speakBotReply(lastBotMessage.text)}
                  className="p-1 rounded text-gray-400 hover:text-[#E2C067] transition-colors cursor-pointer"
                  title="دوبارہ سنیں (Replay)"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleCopyText(lastBotMessage.id, lastBotMessage.text)}
                  className="p-1 rounded text-gray-400 hover:text-white transition-colors cursor-pointer"
                  title="کاپی کریں (Copy)"
                >
                  {copiedId === lastBotMessage.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>
            <p
              className={`text-sm text-gray-200 pt-2 leading-relaxed ${
                profile.language === 'English'
                  ? 'font-sans text-left'
                  : 'font-urdu text-right dir-rtl'
              }`}
            >
              {lastBotMessage.text}
            </p>
          </div>
        )}

        {/* Quick Suggestion Chips */}
        <div className="mt-4 w-full flex items-center justify-center gap-1.5 flex-wrap">
          {(profile.language === 'English'
            ? [
                'Hello! How are you?',
                "What's the weather today?",
                'Tell me a joke',
                'Share an interesting fact',
              ]
            : [
                'سلام! آپ کیسے ہیں؟',
                'آج موسم کیسا ہے؟',
                'لطیفہ سنائیں',
                'ایک دلچسپ بات بتائیں',
              ]
          ).map((prompt) => (
            <button
              key={prompt}
              onClick={() => handleQuickPrompt(prompt)}
              className={`px-2.5 py-1 text-[11px] rounded-lg bg-[#0e1b34] border border-[#233a61] text-gray-300 hover:text-[#E2C067] hover:border-[#E2C067]/60 transition-colors cursor-pointer ${
                profile.language === 'English' ? 'font-sans' : 'font-urdu'
              }`}
            >
              {prompt}
            </button>
          ))}
        </div>
      </main>

      {/* Bottom Controls Area */}
      <footer className="relative z-10 w-full max-w-md mx-auto flex flex-col items-center gap-3 pt-2">
        {/* Keyboard Input Drawer */}
        {isKeyboardOpen && (
          <form
            onSubmit={handleKeyboardSubmit}
            className="w-full bg-[#111e38] border border-[#2a4365] rounded-2xl p-2.5 shadow-2xl flex items-center gap-2 animate-in slide-in-from-bottom-3 duration-200"
          >
            <input
              type="text"
              autoFocus
              value={keyboardText}
              onChange={(e) => setKeyboardText(e.target.value)}
              placeholder={
                profile.language === 'English'
                  ? 'Type your message here...'
                  : 'اپنی بات یہاں لکھیں (Type message here)...'
              }
              className="flex-1 px-3 py-2 text-sm bg-[#081225] border border-[#2a4365] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-[#E2C067]"
            />
            <button
              type="submit"
              disabled={!keyboardText.trim()}
              className="p-2.5 rounded-xl bg-[#E2C067] text-[#081225] font-bold hover:brightness-110 disabled:opacity-40 transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Main Action Row */}
        <div className="w-full flex items-center justify-around px-4">
          {/* Keyboard toggle */}
          <button
            onClick={() => {
              playClickTone();
              setIsKeyboardOpen(!isKeyboardOpen);
            }}
            className={`p-3.5 rounded-full border transition-all cursor-pointer ${
              isKeyboardOpen
                ? 'bg-[#E2C067] text-[#081225] border-[#E2C067] shadow-lg'
                : 'bg-[#111e38] text-gray-300 border-[#2a4365] hover:border-gray-400'
            }`}
            title="Text Input"
            aria-label="Text Input"
          >
            <Keyboard className="w-5 h-5" />
          </button>

          {/* Large Central Glowing Mic Button */}
          <button
            onClick={toggleListening}
            className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer ${
              botState === 'listening'
                ? 'bg-red-600 text-white shadow-[0_0_35px_rgba(239,68,68,0.8)] scale-110'
                : botState === 'speaking'
                ? 'bg-gradient-to-br from-[#FFF2B2] via-[#E2C067] to-[#B89230] text-[#081225] shadow-[0_0_35px_rgba(226,192,103,0.7)] animate-pulse'
                : 'bg-gradient-to-br from-[#FFF2B2] via-[#E2C067] to-[#B89230] text-[#081225] shadow-[0_8px_25px_rgba(0,0,0,0.6)] hover:scale-105 active:scale-95'
            }`}
            title={botState === 'listening' ? 'Stop Listening' : 'Start Speaking'}
            aria-label="Microphone"
          >
            {/* Outer pulsating ring when listening */}
            {botState === 'listening' && (
              <span className="absolute inset-0 rounded-full border-4 border-red-400 animate-ping opacity-75" />
            )}

            {botState === 'listening' ? (
              <MicOff className="w-8 h-8" />
            ) : botState === 'speaking' ? (
              <VolumeX className="w-8 h-8" />
            ) : (
              <Mic className="w-8 h-8" />
            )}
          </button>

          {/* Speaker Mute/Stop button */}
          <button
            onClick={() => {
              playClickTone();
              if (botState === 'speaking') {
                stopAnyPlayback();
                setBotState('idle');
                setStatusText(
                  profile.language === 'English'
                    ? 'Tap mic to speak'
                    : 'بات کرنے کے لیے مائیک دبائیں'
                );
              } else if (lastBotMessage) {
                speakBotReply(lastBotMessage.text);
              }
            }}
            className="p-3.5 rounded-full bg-[#111e38] text-gray-300 border border-[#2a4365] hover:border-gray-400 transition-colors cursor-pointer"
            title={botState === 'speaking' ? 'Mute Voice' : 'Replay Voice'}
            aria-label="Sound control"
          >
            {botState === 'speaking' ? (
              <VolumeX className="w-5 h-5 text-red-400" />
            ) : (
              <Volume2 className="w-5 h-5 text-[#E2C067]" />
            )}
          </button>
        </div>

        {/* Small bottom caption */}
        <p className="text-[11px] text-gray-400 text-center">
          {botState === 'listening'
            ? '🔴 سن رہا ہے... بولنا بند کرنے کے بعد جواب ملے گا'
            : botState === 'speaking'
            ? '🔊 بول رہا ہے... روکنے کے لیے مائیک یا اسپیکر دبائیں'
            : 'مائیک دبائیں یا کی بورڈ سے پیغام بھیجیں'}
        </p>
      </footer>
    </div>
  );
};
