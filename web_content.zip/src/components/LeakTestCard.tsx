import React, { useState } from 'react';
import { ShieldCheck, ShieldAlert, CheckCircle2, AlertTriangle, RefreshCw, Lock, Eye, EyeOff, Radio } from 'lucide-react';
import { VpnServer, ConnectionStatus } from '../types/vpn';
import { Language, TRANSLATIONS } from '../translations';
import { USER_ORIGINAL_NETWORK } from '../data/servers';

interface LeakTestCardProps {
  status: ConnectionStatus;
  currentServer: VpnServer;
  language: Language;
}

export const LeakTestCard: React.FC<LeakTestCardProps> = ({
  status,
  currentServer,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const isConnected = status === 'connected';
  const [isScanning, setIsScanning] = useState(false);
  const [hasScanned, setHasScanned] = useState(false);

  const handleRunScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setHasScanned(true);
    }, 1200);
  };

  return (
    <div className="w-full bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t.privacyAuditTitle}
            </h3>
            <p className="text-xs text-slate-500">
              Zero-log audit & leak verification
            </p>
          </div>
        </div>

        <button
          onClick={handleRunScan}
          disabled={isScanning}
          className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-1.5 shadow-sm transition-all disabled:opacity-60"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
          <span>{isScanning ? t.testing : t.runLeakTest}</span>
        </button>
      </div>

      {/* 4 Security Pillars */}
      <div className="space-y-3 my-2">
        
        {/* 1. IP Masking */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            {isConnected ? (
              <EyeOff className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
            ) : (
              <Eye className="w-4 h-4 text-rose-500 mt-0.5 shrink-0" />
            )}
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                {t.ipMaskingTitle}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {isConnected
                  ? `Exposing virtual IP (${currentServer.ip}) instead of real (${USER_ORIGINAL_NETWORK.ip})`
                  : `Real ISP IP (${USER_ORIGINAL_NETWORK.ip}) is visible to everyone`}
              </div>
            </div>
          </div>
          <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
            isConnected
              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
              : 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
          }`}>
            {isConnected ? t.protected : t.vulnerable}
          </span>
        </div>

        {/* 2. DNS Leak Shield */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <Radio className={`w-4 h-4 mt-0.5 shrink-0 ${isConnected ? 'text-emerald-500' : 'text-amber-500'}`} />
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                {t.dnsLeakTitle}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {isConnected
                  ? 'DNS queries routed via 1.1.1.1 DoH with zero ISP interception'
                  : 'DNS queries routed through unencrypted local ISP servers'}
              </div>
            </div>
          </div>
          <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
            isConnected
              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
              : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
          }`}>
            {isConnected ? t.protected : 'Unencrypted'}
          </span>
        </div>

        {/* 3. WebRTC Leak Shield */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className={`w-4 h-4 mt-0.5 shrink-0 ${isConnected ? 'text-emerald-500' : 'text-slate-400'}`} />
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                {t.webrtcTitle}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Browser STUN/TURN binding requests are shielded against local IP leakage
              </div>
            </div>
          </div>
          <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
            {t.protected}
          </span>
        </div>

        {/* 4. Encryption Cipher */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <Lock className={`w-4 h-4 mt-0.5 shrink-0 ${isConnected ? 'text-indigo-500' : 'text-slate-400'}`} />
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                {t.encryptionTitle}
              </div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                {isConnected ? 'ChaCha20-Poly1305 (WireGuard 256-bit symmetric AEAD)' : 'No active encryption tunnel'}
              </div>
            </div>
          </div>
          <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
            isConnected
              ? 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
              : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
          }`}>
            {isConnected ? '256-bit' : 'None'}
          </span>
        </div>

      </div>

      {/* Diagnostics summary footer */}
      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
        <span>Public Resolver: 1.1.1.1 (Cloudflare)</span>
        <span className="font-mono text-[11px]">IPv6: Shielded</span>
      </div>
    </div>
  );
};
