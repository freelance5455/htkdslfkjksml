import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Transaction } from '../types';
import { t, formatCurrency, formatDateDisplay } from '../utils/translations';
import {
  Search,
  Filter,
  Plus,
  ArrowDownRight,
  ArrowUpRight,
  Printer,
  Download,
  Calendar,
  Wallet,
  Tag,
  Edit2,
  Trash2,
  BookOpen,
  ArrowUpDown,
  Smartphone,
  Monitor,
  ChevronDown,
  FileDown
} from 'lucide-react';
import { TransactionModal } from './Modals/TransactionModal';
import { DownloadAppModal } from './Modals/DownloadAppModal';

export const KhatavahiView: React.FC = () => {
  const { language, transactions, categories, accounts, deleteTransaction } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterCategoryId, setFilterCategoryId] = useState('all');
  const [filterAccountId, setFilterAccountId] = useState('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'this_month' | 'custom'>('this_month');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editItem, setEditItem] = useState<Transaction | null>(null);
  const [defaultModalType, setDefaultModalType] = useState<'income' | 'expense'>('income');
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);

  // Filter logic
  const filteredTransactions = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const currentYearMonth = today.slice(0, 7);

    return transactions
      .filter((tx) => {
        // Type filter
        if (filterType !== 'all' && tx.type !== filterType) return false;

        // Category filter
        if (filterCategoryId !== 'all' && tx.categoryId !== filterCategoryId) return false;

        // Account filter
        if (filterAccountId !== 'all' && tx.accountId !== filterAccountId) return false;

        // Date filter
        if (dateFilter === 'today' && tx.date !== today) return false;
        if (dateFilter === 'this_month' && !tx.date.startsWith(currentYearMonth)) return false;
        if (dateFilter === 'custom') {
          if (customStartDate && tx.date < customStartDate) return false;
          if (customEndDate && tx.date > customEndDate) return false;
        }

        // Search term
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          const matchTitle = tx.title.toLowerCase().includes(q);
          const matchParty = (tx.partyName || '').toLowerCase().includes(q);
          const matchRef = (tx.referenceNo || '').toLowerCase().includes(q);
          const matchNotes = (tx.notes || '').toLowerCase().includes(q);
          if (!matchTitle && !matchParty && !matchRef && !matchNotes) return false;
        }

        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [
    transactions,
    filterType,
    filterCategoryId,
    filterAccountId,
    dateFilter,
    customStartDate,
    customEndDate,
    searchTerm
  ]);

  // Aggregate totals
  const totalIncome = useMemo(() => {
    return filteredTransactions
      .filter((tx) => tx.type === 'income')
      .reduce((sum, tx) => sum + tx.amount, 0);
  }, [filteredTransactions]);

  const totalExpense = useMemo(() => {
    return filteredTransactions
      .filter((tx) => tx.type === 'expense')
      .reduce((sum, tx) => sum + tx.amount, 0);
  }, [filteredTransactions]);

  const netBalance = totalIncome - totalExpense;

  // Handlers
  const handleAddNew = (type: 'income' | 'expense') => {
    setEditItem(null);
    setDefaultModalType(type);
    setIsModalOpen(true);
  };

  const handleEdit = (tx: Transaction) => {
    setEditItem(tx);
    setDefaultModalType(tx.type);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    const confirmMsg =
      language === 'gu'
        ? 'શું તમે આ નોંધણી ખરેખર કાઢી નાખવા માંગો છો?'
        : 'Are you sure you want to delete this transaction?';
    if (window.confirm(confirmMsg)) {
      deleteTransaction(id);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const headers = ['Date', 'Type', 'Amount', 'Category', 'Account', 'Title', 'Party', 'Reference', 'Notes'];
    const rows = filteredTransactions.map((tx) => {
      const cat = categories.find((c) => c.id === tx.categoryId);
      const acc = accounts.find((a) => a.id === tx.accountId);
      return [
        tx.date,
        tx.type === 'income' ? 'Jama (Income)' : 'Udhar (Expense)',
        tx.amount,
        cat ? (language === 'gu' ? cat.nameGu : cat.nameEn) : '',
        acc ? acc.name : '',
        `"${(tx.title || '').replace(/"/g, '""')}"`,
        `"${(tx.partyName || '').replace(/"/g, '""')}"`,
        `"${(tx.referenceNo || '').replace(/"/g, '""')}"`,
        `"${(tx.notes || '').replace(/"/g, '""')}"`
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `khatavahi_daily_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Top Banner & Quick Totals (Chopda Style) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Total Jama (Income) */}
        <div className="rounded-2xl bg-white border border-stone-200 p-4 shadow-sm relative overflow-hidden flex items-center justify-between">
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-emerald-600" />
          <div className="pl-1">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider flex items-center gap-1">
              <ArrowDownRight className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('totalIncome', language)}</span>
            </span>
            <p className="text-xl sm:text-2xl font-black text-emerald-700 mt-1">
              {formatCurrency(totalIncome, language)}
            </p>
          </div>
          <button
            type="button"
            onClick={() => handleAddNew('income')}
            className="flex-shrink-0 p-2 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white transition-colors"
            title={t('income', language)}
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Total Udhar (Expense) */}
        <div className="rounded-2xl bg-white border border-stone-200 p-4 shadow-sm relative overflow-hidden flex items-center justify-between">
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-rose-600" />
          <div className="pl-1">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider flex items-center gap-1">
              <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
              <span>{t('totalExpense', language)}</span>
            </span>
            <p className="text-xl sm:text-2xl font-black text-rose-700 mt-1">
              {formatCurrency(totalExpense, language)}
            </p>
          </div>
          <button
            type="button"
            onClick={() => handleAddNew('expense')}
            className="flex-shrink-0 p-2 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-600 hover:text-white transition-colors"
            title={t('expense', language)}
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Net Savings / Balance */}
        <div className="rounded-2xl bg-gradient-to-br from-amber-900 to-red-950 text-white p-4 shadow-md relative overflow-hidden flex items-center justify-between border border-amber-500/40">
          <div>
            <span className="text-xs font-semibold text-amber-200/90 tracking-wide block">
              {t('netSurplus', language)}
            </span>
            <p
              className={`text-xl sm:text-2xl font-black mt-1 ${
                netBalance >= 0 ? 'text-amber-300' : 'text-rose-300'
              }`}
            >
              {formatCurrency(netBalance, language)}
            </p>
          </div>
          <span className="text-[11px] font-medium px-2 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-400/30">
            {filteredTransactions.length} નોંધ
          </span>
        </div>
      </div>

      {/* Filter and Action Bar */}
      <div className="rounded-2xl bg-white border border-stone-200 p-3.5 shadow-sm space-y-3 print-hide">
        <div className="flex flex-col md:flex-row gap-2.5 items-stretch md:items-center justify-between">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={language === 'gu' ? 'વિગત, વેપારીનું નામ કે નોંધ શોધો...' : 'Search title, party, notes...'}
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-300 text-xs text-stone-900 focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-stone-50/50"
            />
          </div>

          {/* Quick Date Filters */}
          <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl text-xs font-medium overflow-x-auto">
            <button
              type="button"
              onClick={() => setDateFilter('this_month')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
                dateFilter === 'this_month' ? 'bg-white shadow text-amber-900 font-bold' : 'text-stone-600'
              }`}
            >
              {language === 'gu' ? 'આ મહિનો' : 'This Month'}
            </button>
            <button
              type="button"
              onClick={() => setDateFilter('today')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
                dateFilter === 'today' ? 'bg-white shadow text-amber-900 font-bold' : 'text-stone-600'
              }`}
            >
              {language === 'gu' ? 'આજની' : 'Today'}
            </button>
            <button
              type="button"
              onClick={() => setDateFilter('all')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
                dateFilter === 'all' ? 'bg-white shadow text-amber-900 font-bold' : 'text-stone-600'
              }`}
            >
              {t('all', language)}
            </button>
            <button
              type="button"
              onClick={() => setDateFilter('custom')}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
                dateFilter === 'custom' ? 'bg-white shadow text-amber-900 font-bold' : 'text-stone-600'
              }`}
            >
              {language === 'gu' ? 'તારીખ પસંદ' : 'Custom'}
            </button>
          </div>

          {/* Actions: Export Menu (CSV, Print, APK, EXE) */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handlePrint}
              title={t('print', language)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-50 text-xs font-semibold transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t('print', language)}</span>
            </button>

            {/* Export & App Downloads Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{language === 'gu' ? 'એક્સપોર્ટ / ડાઉનલોડ' : 'Export & Downloads'}</span>
                <ChevronDown className="w-3 h-3 ml-0.5" />
              </button>

              {isExportMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-30"
                    onClick={() => setIsExportMenuOpen(false)}
                  />
                  <div className="absolute right-0 mt-1 w-64 rounded-xl bg-white border border-stone-200 shadow-xl py-1.5 z-40 text-stone-800 text-xs">
                    <div className="px-3 py-1 text-[10px] font-bold text-stone-400 uppercase tracking-wider border-b border-stone-100">
                      {language === 'gu' ? 'ડેટા એક્સપોર્ટ' : 'Data Export'}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setIsExportMenuOpen(false);
                        handleExportCSV();
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-amber-50 flex items-center gap-2 text-stone-700"
                    >
                      <Download className="w-4 h-4 text-amber-600" />
                      <div>
                        <span className="font-semibold block">{t('exportCsv', language)}</span>
                        <span className="text-[10px] text-stone-400">Excel / Spreadsheet format</span>
                      </div>
                    </button>

                    <div className="px-3 py-1 mt-1 text-[10px] font-bold text-stone-400 uppercase tracking-wider border-b border-t border-stone-100">
                      {language === 'gu' ? 'પ્રોજેક્ટ ફાઇલ્સમાંથી એપ ડાઉનલોડ' : 'Download Native App'}
                    </div>

                    {/* Direct APK Download */}
                    <a
                      href="/downloads/Khatavahi-v2.0.0.apk"
                      download="Khatavahi-v2.0.0.apk"
                      onClick={() => setIsExportMenuOpen(false)}
                      className="w-full text-left px-3 py-2 hover:bg-emerald-50 flex items-center gap-2 text-emerald-900 transition-colors"
                    >
                      <Smartphone className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <div>
                        <span className="font-bold block">Android APK (v2.0.0)</span>
                        <span className="text-[10px] text-emerald-700 font-medium">
                          {language === 'gu' ? 'મોબાઇલ માટે ઇન્સ્ટોલર ફાઇલ' : 'Android Installer Package'}
                        </span>
                      </div>
                    </a>

                    {/* Direct EXE Download */}
                    <a
                      href="/downloads/Khatavahi-Windows-Setup-x64.exe"
                      download="Khatavahi-Windows-Setup-x64.exe"
                      onClick={() => setIsExportMenuOpen(false)}
                      className="w-full text-left px-3 py-2 hover:bg-blue-50 flex items-center gap-2 text-blue-900 transition-colors"
                    >
                      <Monitor className="w-4 h-4 text-blue-600 flex-shrink-0" />
                      <div>
                        <span className="font-bold block">Windows EXE (Setup x64)</span>
                        <span className="text-[10px] text-blue-700 font-medium">
                          {language === 'gu' ? 'કોમ્પ્યુટર / લેપટોપ માટે' : 'Windows 10 / 11 Desktop'}
                        </span>
                      </div>
                    </a>

                    {/* Full details modal button */}
                    <div className="pt-1 mt-1 border-t border-stone-100">
                      <button
                        type="button"
                        onClick={() => {
                          setIsExportMenuOpen(false);
                          setIsDownloadModalOpen(true);
                        }}
                        className="w-full text-left px-3 py-1.5 hover:bg-stone-50 text-[11px] text-amber-800 font-bold flex items-center justify-between"
                      >
                        <span>{language === 'gu' ? 'બધી વિગત અને ઇન્સ્ટોલેશન ગાઇડ' : 'View Full App Details & Guide'} →</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Sub-Filters: Type, Category, Account */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-stone-100 text-xs">
          {/* Type filter */}
          <div className="flex items-center gap-2">
            <span className="text-stone-500 font-medium whitespace-nowrap">{t('status', language)}:</span>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 text-stone-800 bg-white"
            >
              <option value="all">{language === 'gu' ? 'બધી નોંધણી (જમા અને ઉધાર)' : 'All Entries (Jama & Udhar)'}</option>
              <option value="income">{t('income', language)} (જમા)</option>
              <option value="expense">{t('expense', language)} (ઉધાર)</option>
            </select>
          </div>

          {/* Category filter */}
          <div className="flex items-center gap-2">
            <span className="text-stone-500 font-medium whitespace-nowrap">{t('category', language)}:</span>
            <select
              value={filterCategoryId}
              onChange={(e) => setFilterCategoryId(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 text-stone-800 bg-white"
            >
              <option value="all">{t('allCategories', language)}</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {language === 'gu' ? c.nameGu : c.nameEn} ({c.type === 'income' ? 'જમા' : 'ઉધાર'})
                </option>
              ))}
            </select>
          </div>

          {/* Account filter */}
          <div className="flex items-center gap-2">
            <span className="text-stone-500 font-medium whitespace-nowrap">{t('account', language)}:</span>
            <select
              value={filterAccountId}
              onChange={(e) => setFilterAccountId(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 text-stone-800 bg-white"
            >
              <option value="all">{language === 'gu' ? 'તમામ ખાતાઓ (રોકડ + બેંક)' : 'All Accounts'}</option>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Custom Date Range if selected */}
        {dateFilter === 'custom' && (
          <div className="flex items-center gap-2 pt-1 text-xs">
            <span className="text-stone-500">{language === 'gu' ? 'તારીખથી:' : 'From:'}</span>
            <input
              type="date"
              value={customStartDate}
              onChange={(e) => setCustomStartDate(e.target.value)}
              className="px-2 py-1 rounded border border-stone-300 bg-white"
            />
            <span className="text-stone-500">{language === 'gu' ? 'તારીખ સુધી:' : 'To:'}</span>
            <input
              type="date"
              value={customEndDate}
              onChange={(e) => setCustomEndDate(e.target.value)}
              className="px-2 py-1 rounded border border-stone-300 bg-white"
            />
          </div>
        )}
      </div>

      {/* Chopda Ledger Table */}
      <div className="rounded-2xl bg-white border border-stone-200 shadow-sm overflow-hidden khatavahi-print-sheet">
        {/* Printable Header */}
        <div className="p-4 bg-gradient-to-r from-red-950 to-stone-900 text-white flex items-center justify-between border-b border-amber-500/50">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-amber-100">
                {language === 'gu' ? 'દૈનિક ખાતાવહી (રોજમેળ)' : 'Daily Khatavahi Ledger'}
              </h2>
              <p className="text-[11px] text-amber-200/80">
                {language === 'gu' ? 'જમા અને ઉધાર નોંધણી પત્રક' : 'Income & Expense Journal'}
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => handleAddNew('income')}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow print-hide"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('income', language)} (જમા)</span>
            </button>
            <button
              type="button"
              onClick={() => handleAddNew('expense')}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold transition-all shadow print-hide"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('expense', language)} (ઉધાર)</span>
            </button>
          </div>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center text-stone-500 space-y-3">
            <BookOpen className="w-10 h-10 text-stone-300 mx-auto" />
            <p className="text-sm font-semibold">
              {language === 'gu' ? 'કોઈ નોંધણી મળી નથી' : 'No transactions recorded yet'}
            </p>
            <p className="text-xs text-stone-400 max-w-sm mx-auto">
              {language === 'gu'
                ? 'ઉપર આપેલ "+ જમા" અથવા "+ ઉધાર" બટન દબાવીને નવી રોજિંદી નોંધણી કરો.'
                : 'Click on "+ Income" or "+ Expense" button above to record your first daily entry.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-amber-50/70 text-stone-700 font-bold border-b border-amber-200">
                <tr>
                  <th className="p-3 w-28">{t('date', language)}</th>
                  <th className="p-3">{language === 'gu' ? 'વિગત / નોંધ' : 'Description'}</th>
                  <th className="p-3">{t('partyName', language)}</th>
                  <th className="p-3">{t('category', language)}</th>
                  <th className="p-3">{t('account', language)}</th>
                  <th className="p-3 text-right text-emerald-800 w-32">{t('jama', language)} (₹)</th>
                  <th className="p-3 text-right text-rose-800 w-32">{t('udhar', language)} (₹)</th>
                  <th className="p-3 text-center w-20 print-hide">{language === 'gu' ? 'ક્રિયા' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200/80">
                {filteredTransactions.map((tx) => {
                  const cat = categories.find((c) => c.id === tx.categoryId);
                  const acc = accounts.find((a) => a.id === tx.accountId);

                  return (
                    <tr
                      key={tx.id}
                      className="hover:bg-amber-50/40 transition-colors ledger-line-row"
                    >
                      {/* Date */}
                      <td className="p-3 font-medium text-stone-700 whitespace-nowrap">
                        {formatDateDisplay(tx.date, language)}
                      </td>

                      {/* Title & Notes */}
                      <td className="p-3">
                        <div className="font-bold text-stone-900">{tx.title}</div>
                        {tx.notes && (
                          <div className="text-[11px] text-stone-500 truncate max-w-xs">{tx.notes}</div>
                        )}
                        {tx.referenceNo && (
                          <div className="text-[10px] text-amber-700 font-mono">Ref: {tx.referenceNo}</div>
                        )}
                      </td>

                      {/* Party */}
                      <td className="p-3 text-stone-700">
                        {tx.partyName || '-'}
                      </td>

                      {/* Category */}
                      <td className="p-3">
                        {cat ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-stone-100 text-stone-700 border border-stone-200">
                            {language === 'gu' ? cat.nameGu : cat.nameEn}
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>

                      {/* Account */}
                      <td className="p-3 text-stone-600 whitespace-nowrap">
                        {acc ? acc.name : '-'}
                      </td>

                      {/* Jama (Credit) */}
                      <td className="p-3 text-right font-extrabold text-emerald-700">
                        {tx.type === 'income' ? formatCurrency(tx.amount, language) : '-'}
                      </td>

                      {/* Udhar (Debit) */}
                      <td className="p-3 text-right font-extrabold text-rose-700">
                        {tx.type === 'expense' ? formatCurrency(tx.amount, language) : '-'}
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-center print-hide">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleEdit(tx)}
                            className="p-1 rounded text-stone-400 hover:text-amber-700 hover:bg-stone-100"
                            title={t('edit', language)}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(tx.id)}
                            className="p-1 rounded text-stone-400 hover:text-rose-600 hover:bg-stone-100"
                            title={t('delete', language)}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              {/* Table Footer Totals */}
              <tfoot className="bg-stone-100 border-t-2 border-stone-300 font-bold text-xs">
                <tr>
                  <td colSpan={5} className="p-3 text-right text-stone-700 uppercase tracking-wider">
                    {language === 'gu' ? 'કુલ સરવાળો (Total):' : 'Total Summary:'}
                  </td>
                  <td className="p-3 text-right text-emerald-800 font-black">
                    {formatCurrency(totalIncome, language)}
                  </td>
                  <td className="p-3 text-right text-rose-800 font-black">
                    {formatCurrency(totalExpense, language)}
                  </td>
                  <td className="p-3 print-hide" />
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      {/* Transaction Modal */}
      <TransactionModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        editTransaction={editItem}
        defaultType={defaultModalType}
      />

      {/* Download App Modal (APK & EXE) */}
      <DownloadAppModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
};
