"use client";

import { useEffect, useRef, useState } from "react";
import { Pause, Play, Square } from "lucide-react";
import { ayahAudioUrl, type Ayah } from "@/lib/quran";
import { toArabicDigits } from "@/lib/site";

/**
 * Renders the ayahs of a surah with per-ayah audio playback
 * (Mishary Alafasy) and a "play whole surah" mode that advances automatically.
 */
export function QuranReader({ ayahs, surahName }: { ayahs: Ayah[]; surahName: string }) {
  const [playingIndex, setPlayingIndex] = useState<number | null>(null);
  const [continuous, setContinuous] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const continuousRef = useRef(false);
  const ayahsRef = useRef(ayahs);

  const stopAudio = () => {
    const audio = audioRef.current;
    if (audio) {
      audio.pause();
      audio.removeAttribute("src");
      audio.load();
    }
    audioRef.current = null;
  };

  const playAt = (index: number) => {
    const list = ayahsRef.current;
    if (index < 0 || index >= list.length) {
      stopAudio();
      setPlayingIndex(null);
      continuousRef.current = false;
      setContinuous(false);
      return;
    }

    stopAudio();
    const audio = new Audio(ayahAudioUrl(list[index].number));
    audioRef.current = audio;
    audio.onended = () => {
      if (continuousRef.current) {
        playAt(index + 1);
      } else {
        setPlayingIndex(null);
      }
    };
    audio.onerror = () => {
      setPlayingIndex(null);
      continuousRef.current = false;
      setContinuous(false);
    };
    setPlayingIndex(index);
    audio.play().catch(() => {
      setPlayingIndex(null);
      continuousRef.current = false;
      setContinuous(false);
    });
  };

  const togglePlaySurah = () => {
    if (continuousRef.current) {
      continuousRef.current = false;
      setContinuous(false);
      stopAudio();
      setPlayingIndex(null);
      return;
    }
    continuousRef.current = true;
    setContinuous(true);
    playAt(0);
  };

  const toggleAyah = (index: number) => {
    if (playingIndex === index) {
      continuousRef.current = false;
      setContinuous(false);
      stopAudio();
      setPlayingIndex(null);
      return;
    }
    continuousRef.current = false;
    setContinuous(false);
    playAt(index);
  };

  // Stop any audio when leaving the page.
  useEffect(() => () => stopAudio(), []);

  return (
    <div>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-gold/30 bg-card p-5 shadow-[0_30px_60px_-40px_rgba(23,36,58,0.5)]">
        <div>
          <p className="text-sm text-gold">تلاوة الشيخ مشاري العفاسي</p>
          <p className="mt-1 font-serif text-2xl font-bold text-navy">{surahName}</p>
        </div>
        <button
          type="button"
          onClick={togglePlaySurah}
          className="inline-flex items-center gap-3 rounded-full bg-navy px-6 py-3 font-semibold text-ivory shadow-[0_20px_40px_-20px_rgba(23,36,58,0.9)] transition-all hover:-translate-y-0.5 hover:bg-royal"
        >
          {continuous ? <Square className="size-4" aria-hidden="true" /> : <Play className="size-4 -scale-x-100" aria-hidden="true" />}
          {continuous ? "إيقاف التلاوة" : "تشغيل السورة كاملة"}
        </button>
      </div>

      <ol className="space-y-4">
        {ayahs.map((ayah, index) => {
          const isPlaying = playingIndex === index;
          return (
            <li
              key={ayah.number}
              className={`flex items-start gap-4 rounded-3xl border p-5 transition-colors duration-300 sm:p-7 ${
                isPlaying ? "border-gold bg-gold/10" : "border-border bg-card hover:border-gold/50"
              }`}
              aria-current={isPlaying ? "true" : undefined}
            >
              <button
                type="button"
                onClick={() => toggleAyah(index)}
                aria-label={isPlaying ? `إيقاف الآية ${ayah.numberInSurah}` : `تشغيل الآية ${ayah.numberInSurah}`}
                className={`mt-2 grid size-11 shrink-0 place-items-center rounded-full border transition-all ${
                  isPlaying
                    ? "border-gold bg-gold text-navy"
                    : "border-gold/50 text-gold hover:bg-gold hover:text-navy"
                }`}
              >
                {isPlaying ? <Pause className="size-4" aria-hidden="true" /> : <Play className="size-4 -scale-x-100" aria-hidden="true" />}
              </button>

              <div className="min-w-0 flex-1">
                <p className="font-serif text-3xl leading-[2.2] text-navy sm:text-4xl" lang="ar">
                  {ayah.text}{" "}
                  <span className="inline-grid size-10 place-items-center rounded-full border border-gold/50 align-middle font-sans text-sm text-gold">
                    {toArabicDigits(ayah.numberInSurah)}
                  </span>
                </p>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
