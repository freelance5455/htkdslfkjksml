import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  BookOpen, 
  Heart, 
  Share2, 
  Check, 
  Bookmark, 
  Timer, 
  Flame, 
  Shield, 
  Sun,
  X
} from 'lucide-react';
import { audioEngine } from '../lib/audioEngine';

export interface SelahVerse {
  reference: string;
  text: string;
  theme: string;
  propheticReflection: string;
}

export const INSPIRATIONAL_SELAH_VERSES: SelahVerse[] = [
  {
    reference: 'Psalm 46:10',
    text: 'Be still, and know that I am God: I will be exalted among the heathen, I will be exalted in the earth.',
    theme: 'Sovereign Stillness & Trust',
    propheticReflection: 'As you rested in holy silence, God fought unseen battles on your behalf. Receive His sovereign peace that rules above all turbulence.'
  },
  {
    reference: 'Isaiah 30:15',
    text: 'In returning and rest shall ye be saved; in quietness and in confidence shall be your strength.',
    theme: 'Quiet Strength',
    propheticReflection: 'Your strength does not come from striving, but from quiet waiting upon the Lord. His power is now replenishing your spirit.'
  },
  {
    reference: 'Philippians 4:6-7',
    text: 'Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God. And the peace of God, which passeth all understanding, shall keep your hearts and minds through Christ Jesus.',
    theme: 'Transcendent Peace',
    propheticReflection: 'Every anxiety surrendered during this Selah has been exchanged for God’s supernatural peace that guards your mind and steps.'
  },
  {
    reference: '1 Kings 19:12',
    text: 'And after the earthquake a fire; but the Lord was not in the fire: and after the fire a still small voice.',
    theme: 'The Still Small Voice',
    propheticReflection: 'Listen closely to the gentle whisper in your heart. The Lord speaks not in noise or confusion, but in divine whispers of guidance.'
  },
  {
    reference: 'Isaiah 40:31',
    text: 'But they that wait upon the Lord shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.',
    theme: 'Supernatural Renewal',
    propheticReflection: 'Waiting in His presence has renewed your wings. Rise above your circumstances with eagle vision and holy endurance.'
  },
  {
    reference: 'Psalm 62:1-2',
    text: 'Truly my soul waiteth upon God: from Him cometh my salvation. He only is my rock and my salvation; He is my defence; I shall not be greatly moved.',
    theme: 'Unshakable Foundation',
    propheticReflection: 'Your soul is anchored to the Rock of Ages. No storm formed against your life shall cause you to be moved.'
  },
  {
    reference: 'Zephaniah 3:17',
    text: 'The Lord thy God in the midst of thee is mighty; He will save, He will rejoice over thee with joy; He will rest in His love, He will joy over thee with singing.',
    theme: 'Resting in Divine Love',
    propheticReflection: 'God is actively singing songs of deliverance and tender love over you right now. Rest securely in His unconditional grace.'
  },
  {
    reference: 'Matthew 11:28',
    text: 'Come unto me, all ye that labour and are heavy laden, and I will give you rest.',
    theme: 'Divine Rest for the Soul',
    propheticReflection: 'You have brought your burdens to Jesus. Walk away unburdened, clothed in His light yoke and joyful peace.'
  },
  {
    reference: 'John 14:27',
    text: 'Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.',
    theme: 'Christ’s Legacy of Peace',
    propheticReflection: 'Christ’s peace is an eternal covenant possession. No earthly report can strip away what Christ has sealed in your spirit.'
  },
  {
    reference: 'Lamentations 3:25-26',
    text: 'The Lord is good unto them that wait for Him, to the soul that seeketh Him. It is good that a man should both hope and quietly wait for the salvation of the Lord.',
    theme: 'The Goodness of Waiting',
    propheticReflection: 'Your quiet waiting has reached the throne of heaven. Expect unexpected favor and divine doors opening in this season.'
  }
];

interface SelahMeditationTimerProps {
  onSaveToJournal?: (entry: { title: string; prayerText: string; category: string }) => void;
}

export const SelahMeditationTimer: React.FC<SelahMeditationTimerProps> = ({ onSaveToJournal }) => {
  const [selectedMinutes, setSelectedMinutes] = useState<number>(5);
  const [customMinutes, setCustomMinutes] = useState<string>('');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(5 * 60);
  const [isActive, setIsActive] = useState<boolean>(false);
  const [audioMode, setAudioMode] = useState<'silence' | 'ambient'>('silence');
  
  // Prompt Modal state once timer elapses
  const [completedVerse, setCompletedVerse] = useState<SelahVerse | null>(null);
  const [showVerseModal, setShowVerseModal] = useState<boolean>(false);
  const [copiedVerse, setCopiedVerse] = useState<boolean>(false);
  const [savedJournalNotice, setSavedJournalNotice] = useState<boolean>(false);

  // Stillness breathing prompt
  const [breathCue, setBreathCue] = useState<string>('Breathe in Divine Grace');

  // Chime trigger on finish
  const playSacredBellChime = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const audioCtx = new AudioContextClass();
      
      const freqs = [528, 792, 1056]; // 528Hz Solfeggio triad harmonic
      freqs.forEach((f, index) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, audioCtx.currentTime + index * 0.15);
        gain.gain.setValueAtTime(0, audioCtx.currentTime + index * 0.15);
        gain.gain.linearRampToValueAtTime(0.25 / (index + 1), audioCtx.currentTime + index * 0.15 + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + index * 0.15 + 4.5);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(audioCtx.currentTime + index * 0.15);
        osc.stop(audioCtx.currentTime + index * 0.15 + 5);
      });
    } catch (e) {
      console.warn('Selah chime error:', e);
    }
  };

  // Timer interval
  useEffect(() => {
    let interval: number;
    if (isActive && secondsRemaining > 0) {
      interval = window.setInterval(() => {
        setSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (secondsRemaining === 0 && isActive) {
      setIsActive(false);
      if (audioMode === 'ambient') {
        try { audioEngine?.stopAll?.(); } catch (e) { /* ignore */ }
      }
      playSacredBellChime();

      // Pick a random or sequential verse
      const randomVerse = INSPIRATIONAL_SELAH_VERSES[Math.floor(Math.random() * INSPIRATIONAL_SELAH_VERSES.length)];
      setCompletedVerse(randomVerse);
      setShowVerseModal(true);
    }
    return () => clearInterval(interval);
  }, [isActive, secondsRemaining, audioMode]);

  // Breathing rhythm during active timer
  useEffect(() => {
    if (!isActive) return;
    const cues = [
      'Inhale: Receive His Holy Presence',
      'Hold: Resting in Sovereign Faith',
      'Exhale: Release All Weariness',
      'Selah: Listen in Perfect Peace'
    ];
    let idx = 0;
    const interval = window.setInterval(() => {
      idx = (idx + 1) % cues.length;
      setBreathCue(cues[idx]);
    }, 4500);
    return () => clearInterval(interval);
  }, [isActive]);

  const handleStartTimer = (durationMins?: number) => {
    const mins = durationMins !== undefined ? durationMins : selectedMinutes;
    setSecondsRemaining(mins * 60);
    setIsActive(true);

    if (audioMode === 'ambient') {
      try {
        audioEngine?.playTrackSyntheticSoundscape?.(528, 'soaking');
      } catch (e) {
        console.warn('AudioEngine ambient error:', e);
      }
    }
  };

  const handlePauseResume = () => {
    if (isActive) {
      setIsActive(false);
      if (audioMode === 'ambient') {
        try { audioEngine?.stopAll?.(); } catch (e) { /* ignore */ }
      }
    } else {
      setIsActive(true);
      if (audioMode === 'ambient') {
        try { audioEngine?.playTrackSyntheticSoundscape?.(528, 'soaking'); } catch (e) { /* ignore */ }
      }
    }
  };

  const handleReset = () => {
    setIsActive(false);
    setSecondsRemaining(selectedMinutes * 60);
    if (audioMode === 'ambient') {
      try { audioEngine?.stopAll?.(); } catch (e) { /* ignore */ }
    }
  };

  const handleSelectMinutes = (mins: number) => {
    setSelectedMinutes(mins);
    if (!isActive) {
      setSecondsRemaining(mins * 60);
    }
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(customMinutes, 10);
    if (!isNaN(val) && val > 0 && val <= 180) {
      setSelectedMinutes(val);
      if (!isActive) setSecondsRemaining(val * 60);
      setCustomMinutes('');
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const totalDuration = selectedMinutes * 60;
  const progressPercent = totalDuration > 0 ? ((totalDuration - secondsRemaining) / totalDuration) * 100 : 0;

  // Save to Prayer Journal action
  const handleSaveToPrayerJournal = () => {
    if (!completedVerse) return;
    try {
      const saved = localStorage.getItem('juhnkrix_prayer_journal');
      let entries = [];
      if (saved) {
        try { entries = JSON.parse(saved); } catch (e) { /* ignore */ }
      }
      const newEntry = {
        id: `selah-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        title: `Selah Stillness: ${completedVerse.reference}`,
        prayerText: `After completing ${selectedMinutes} minutes of silent Selah prayer, the Lord ministered:\n"${completedVerse.text}"\n\nProphetic Reflection: ${completedVerse.propheticReflection}`,
        testimony: 'Received divine peace and stillness in the presence of the Lord.',
        isAnswered: true,
        category: 'Peace' as const
      };
      entries.unshift(newEntry);
      localStorage.setItem('juhnkrix_prayer_journal', JSON.stringify(entries));
      setSavedJournalNotice(true);
      if (onSaveToJournal) {
        onSaveToJournal(newEntry);
      }
      setTimeout(() => setSavedJournalNotice(false), 3000);
    } catch (e) {
      console.warn('Failed to save to journal:', e);
    }
  };

  const handleCopyScripture = () => {
    if (!completedVerse) return;
    const textToCopy = `🕊️ Selah Scripture — ${completedVerse.reference}\n"${completedVerse.text}"\n\nProphetic Reflection: ${completedVerse.propheticReflection}\n— JUHNKRIX MUSIKA Sanctuary`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedVerse(true);
    setTimeout(() => setCopiedVerse(false), 2500);
  };

  return (
    <div className="w-full bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950/40 border-2 border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Background celestial watermark */}
      <div className="absolute -top-12 -right-12 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-purple-500/20 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 uppercase tracking-wider flex items-center space-x-1">
              <Sparkles className="w-3 h-3 text-purple-400" />
              <span>Selah (סֶלָה) Silent Sanctuary</span>
            </span>
            <span className="text-[11px] text-amber-400/90 font-serif italic">
              Pause • Rest • Listen
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold font-serif text-purple-100 mt-1">
            Selah Silent Prayer Meditation Timer
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
            Set a sacred duration for holy stillness. When the timer elapses, the Holy Spirit prompts you with an anointed Bible verse and prophetic reflection.
          </p>
        </div>

        {/* Audio Mode Toggle */}
        <div className="flex items-center space-x-2 bg-slate-950/80 p-1.5 rounded-2xl border border-purple-500/30">
          <button
            onClick={() => {
              setAudioMode('silence');
              if (isActive) {
                try { audioEngine?.stopAll?.(); } catch (e) { /* ignore */ }
              }
            }}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              audioMode === 'silence'
                ? 'bg-purple-500/30 text-purple-200 border border-purple-400/40 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Complete Holy Silence"
          >
            <VolumeX className="w-3.5 h-3.5" />
            <span>Holy Silence</span>
          </button>
          <button
            onClick={() => {
              setAudioMode('ambient');
              if (isActive) {
                try { audioEngine?.playTrackSyntheticSoundscape?.(528, 'soaking'); } catch (e) { /* ignore */ }
              }
            }}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              audioMode === 'ambient'
                ? 'bg-amber-500/30 text-amber-200 border border-amber-400/40 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="528Hz Ambient Pad Underneath"
          >
            <Volume2 className="w-3.5 h-3.5 text-amber-400" />
            <span>528Hz Pad</span>
          </button>
        </div>
      </div>

      {/* Main Timer Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left: Interactive Radial Clock & Breathing Ring (7 cols) */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center p-6 sm:p-8 bg-slate-950/70 rounded-3xl border border-purple-500/20 relative">
          {/* Animated Halo Glow */}
          <div className="relative flex items-center justify-center my-4">
            <div
              className={`w-64 h-64 sm:w-72 sm:h-72 rounded-full border-2 border-purple-400/30 flex items-center justify-center relative transition-all duration-1000 ${
                isActive
                  ? 'shadow-[0_0_60px_rgba(168,85,247,0.35)] border-purple-400/80 bg-purple-950/20'
                  : 'shadow-[0_0_20px_rgba(168,85,247,0.15)] bg-slate-900/40'
              }`}
            >
              {/* SVG Radial Progress Ring */}
              <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none">
                <circle
                  cx="50%"
                  cy="50%"
                  r="46%"
                  className="stroke-purple-900/40"
                  strokeWidth="6"
                  fill="transparent"
                />
                <circle
                  cx="50%"
                  cy="50%"
                  r="46%"
                  className="stroke-purple-400 transition-all duration-1000"
                  strokeWidth="6"
                  strokeDasharray="1000"
                  strokeDashoffset={1000 - (1000 * progressPercent) / 100}
                  strokeLinecap="round"
                  fill="transparent"
                />
              </svg>

              {/* Inner Contents */}
              <div className="text-center space-y-2 z-10 px-4">
                <span className="text-[10px] font-mono tracking-widest uppercase text-purple-300 font-bold block">
                  {isActive ? '● SELAH COUNTDOWN' : '○ READY FOR SILENT COMMUNION'}
                </span>
                <div className="text-4xl sm:text-5xl font-extrabold font-mono tracking-wider text-purple-100">
                  {formatTime(secondsRemaining)}
                </div>
                <div className="text-xs text-amber-300/90 font-serif italic max-w-xs mx-auto leading-relaxed">
                  {isActive ? breathCue : `"${selectedMinutes} minutes dedicated to silent prayer"`}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Action Controls */}
          <div className="flex flex-wrap items-center justify-center gap-3 w-full mt-2">
            {!isActive && secondsRemaining === selectedMinutes * 60 ? (
              <button
                onClick={() => handleStartTimer()}
                className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-500 via-purple-600 to-indigo-600 text-white font-extrabold text-sm flex items-center space-x-2 shadow-lg shadow-purple-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Begin Selah Pause ({selectedMinutes}m)</span>
              </button>
            ) : (
              <>
                <button
                  onClick={handlePauseResume}
                  className={`px-6 py-3 rounded-2xl font-bold text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                    isActive
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                      : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                  }`}
                >
                  {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-emerald-300" />}
                  <span>{isActive ? 'Pause Stillness' : 'Resume Stillness'}</span>
                </button>

                <button
                  onClick={handleReset}
                  className="px-5 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 font-bold text-xs flex items-center space-x-2 transition-all cursor-pointer"
                  title="Reset Timer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Right: Duration Presets & Spiritual Contemplation Guide (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Preset Durations Selector */}
          <div className="bg-slate-900/90 border border-purple-500/20 rounded-2xl p-4 sm:p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-200 uppercase tracking-wider flex items-center space-x-1.5">
                <Timer className="w-4 h-4 text-purple-400" />
                <span>Select Stillness Duration</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Silent Altar</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { mins: 1, label: 'Centering', desc: 'Quick breath' },
                { mins: 3, label: 'Stillness', desc: 'Heart calm' },
                { mins: 5, label: 'Communion', desc: 'Deep peace' },
                { mins: 10, label: 'Waiting', desc: 'Holy resting' },
                { mins: 15, label: 'Selah', desc: 'Prophetic ear' },
                { mins: 20, label: 'Deep Soak', desc: 'Spirit rest' }
              ].map((item) => (
                <button
                  key={item.mins}
                  onClick={() => handleSelectMinutes(item.mins)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedMinutes === item.mins
                      ? 'bg-purple-500/25 border-purple-400 text-purple-100 shadow-md shadow-purple-500/20'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-purple-500/30'
                  }`}
                >
                  <div className="flex items-baseline justify-between">
                    <span className="text-base font-extrabold font-mono text-amber-300">{item.mins}m</span>
                    <span className="text-[9px] uppercase font-bold text-purple-400">{item.label}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 truncate mt-0.5">{item.desc}</div>
                </button>
              ))}
            </div>

            {/* Custom Minutes Input */}
            <form onSubmit={handleCustomSubmit} className="pt-2 flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="180"
                value={customMinutes}
                onChange={(e) => setCustomMinutes(e.target.value)}
                placeholder="Custom minutes (e.g. 7)"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-purple-400 font-mono"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow transition-all cursor-pointer"
              >
                Set
              </button>
            </form>
          </div>

          {/* Theological Significance Card */}
          <div className="bg-slate-900/90 border border-purple-500/20 rounded-2xl p-4 sm:p-5 shadow-xl space-y-2.5 text-xs">
            <div className="flex items-center space-x-2 text-amber-300 font-serif font-bold">
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>What is a "Selah" Pause?</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Found over 70 times in the Psalms, <strong className="text-purple-200">Selah</strong> signifies a holy pause — an intentional halt where instruments fade, vocal chants rest, and worshippers stop to listen to God’s revelation.
            </p>
            <div className="bg-slate-950/80 p-3 rounded-xl border border-purple-500/20 text-[11px] text-purple-200 italic font-serif">
              &ldquo;Wait on the Lord: be of good courage, and He shall strengthen thine heart.&rdquo; — Psalm 27:14
            </div>
          </div>
        </div>
      </div>

      {/* COMPLETED SELAH PROMPT MODAL: Automatic Inspirational Bible Verse */}
      <AnimatePresence>
        {showVerseModal && completedVerse && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-gradient-to-b from-slate-900 via-slate-950 to-purple-950 border-2 border-purple-400/50 rounded-3xl p-6 sm:p-8 max-w-xl w-full shadow-2xl space-y-6 relative overflow-hidden"
            >
              {/* Close Button */}
              <button
                onClick={() => setShowVerseModal(false)}
                className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Modal Header */}
              <div className="text-center space-y-2 pt-2">
                <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/40 text-xs font-mono font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                  <span>Selah Stillness Elapsed • Receive Your Word</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold font-serif text-amber-100">
                  A Word for Your Spirit
                </h3>
                <p className="text-xs text-purple-300 font-mono">
                  Theme: {completedVerse.theme}
                </p>
              </div>

              {/* The Inspirational Bible Verse Card */}
              <div className="bg-slate-950/90 border border-amber-500/40 rounded-2xl p-6 text-center space-y-3 shadow-inner relative">
                <span className="text-xs font-mono font-bold text-amber-400 tracking-wider block uppercase">
                  📖 {completedVerse.reference}
                </span>
                <p className="text-base sm:text-lg font-serif italic text-amber-100 leading-relaxed">
                  &ldquo;{completedVerse.text}&rdquo;
                </p>
              </div>

              {/* Prophetic Reflection */}
              <div className="bg-purple-950/40 border border-purple-500/30 rounded-2xl p-4 text-xs space-y-1.5 text-slate-200 leading-relaxed">
                <div className="font-bold text-purple-300 flex items-center space-x-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>Prophetic Impartation for Today:</span>
                </div>
                <p>{completedVerse.propheticReflection}</p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={handleSaveToPrayerJournal}
                  className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg transition-all cursor-pointer"
                >
                  <Bookmark className="w-4 h-4" />
                  <span>{savedJournalNotice ? '✓ Saved to Journal!' : 'Save to Prayer Journal'}</span>
                </button>

                <button
                  onClick={handleCopyScripture}
                  className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold shadow transition-all cursor-pointer"
                >
                  {copiedVerse ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                  <span>{copiedVerse ? 'Copied to Clipboard!' : 'Copy Scripture'}</span>
                </button>

                <button
                  onClick={() => {
                    setShowVerseModal(false);
                    handleStartTimer(selectedMinutes);
                  }}
                  className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:opacity-95 text-white text-xs font-bold shadow transition-all cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Begin Another Selah Pause</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
