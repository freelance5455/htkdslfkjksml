import { useState } from 'react';
import { Lesson, Student } from '../types';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Calendar as CalendarIcon,
  Clock,
  Sparkles,
  DollarSign
} from 'lucide-react';

interface CalendarViewProps {
  lessons: Lesson[];
  students: Student[];
  onSelectLesson: (lesson: Lesson) => void;
  onAddNewLesson: (date?: string) => void;
  onMarkPayment: (student: Student, lesson?: Lesson) => void;
}

export const CalendarView = ({
  lessons,
  students,
  onSelectLesson,
  onAddNewLesson,
  onMarkPayment,
}: CalendarViewProps) => {
  const [currentDate, setCurrentDate] = useState<Date>(new Date(2026, 9, 1)); // Oct 2026
  const [selectedDayLessons, setSelectedDayLessons] = useState<string | null>('2026-10-07');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
    'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
  ];

  const daysOfWeek = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date(2026, 9, 7));
    setSelectedDayLessons('2026-10-07');
  };

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);

  const startDayIndex = (firstDayOfMonth.getDay() + 6) % 7;
  const totalDays = lastDayOfMonth.getDate();

  const daysArray: Array<{ dayNumber: number; dateStr: string; isCurrentMonth: boolean }> = [];

  const prevMonthLastDay = new Date(year, month, 0).getDate();
  for (let i = startDayIndex - 1; i >= 0; i--) {
    const d = prevMonthLastDay - i;
    const prevMonthNum = month === 0 ? 12 : month;
    const prevYear = month === 0 ? year - 1 : year;
    const dateStr = `${prevYear}-${String(prevMonthNum).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    daysArray.push({ dayNumber: d, dateStr, isCurrentMonth: false });
  }

  for (let d = 1; d <= totalDays; d++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    daysArray.push({ dayNumber: d, dateStr, isCurrentMonth: true });
  }

  const remainingSlots = 42 - daysArray.length;
  for (let d = 1; d <= remainingSlots; d++) {
    const nextMonthNum = month + 2 > 12 ? 1 : month + 2;
    const nextYear = month + 2 > 12 ? year + 1 : year;
    const dateStr = `${nextYear}-${String(nextMonthNum).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    daysArray.push({ dayNumber: d, dateStr, isCurrentMonth: false });
  }

  const activeDayLessons = selectedDayLessons
    ? lessons.filter((l) => l.date === selectedDayLessons).sort((a, b) => a.time.localeCompare(b.time))
    : [];

  return (
    <div className="space-y-5">
      {/* Calendar Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#121214] p-4 sm:p-5 rounded-2xl border border-zinc-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-zinc-900 text-rose-400 border border-zinc-800">
            <CalendarIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold font-serif text-white">
              {monthNames[month]} {year}
            </h2>
            <p className="text-xs text-stone-400">
              Ders planlaması ve ödeme takvimi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center bg-zinc-900 border border-zinc-800 p-1 rounded-xl">
            <button
              onClick={prevMonth}
              className="p-1.5 hover:bg-zinc-800 rounded-lg text-stone-300 transition-all cursor-pointer"
              title="Önceki Ay"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={goToToday}
              className="px-3 py-1 text-xs font-semibold hover:bg-zinc-800 rounded-lg text-stone-200 transition-all cursor-pointer"
            >
              Bugün
            </button>
            <button
              onClick={nextMonth}
              className="p-1.5 hover:bg-zinc-800 rounded-lg text-stone-300 transition-all cursor-pointer"
              title="Sonraki Ay"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => onAddNewLesson(selectedDayLessons || undefined)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-rose-950/40 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Ders Ekle</span>
          </button>
        </div>
      </div>

      {/* Main Grid & Day Detail Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Calendar Grid (2 cols) */}
        <div className="lg:col-span-2 bg-[#121214] rounded-2xl border border-zinc-800 p-3 sm:p-5 shadow-xl">
          {/* Day labels */}
          <div className="grid grid-cols-7 gap-1 text-center mb-2">
            {daysOfWeek.map((dayName, idx) => (
              <div
                key={dayName}
                className={`py-1.5 text-xs font-bold ${
                  idx >= 5 ? 'text-rose-400' : 'text-stone-400'
                }`}
              >
                {dayName}
              </div>
            ))}
          </div>

          {/* Month Grid Cells */}
          <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
            {daysArray.map((cell, idx) => {
              const dayLessons = lessons.filter((l) => l.date === cell.dateStr);
              const isSelected = selectedDayLessons === cell.dateStr;
              const isToday = cell.dateStr === '2026-10-07';
              const hasPaymentLesson = dayLessons.some((l) => l.isPaymentLesson);

              return (
                <div
                  key={idx}
                  onClick={() => setSelectedDayLessons(cell.dateStr)}
                  className={`min-h-[68px] sm:min-h-[84px] p-1.5 rounded-xl border transition-all flex flex-col justify-between cursor-pointer ${
                    isSelected
                      ? 'border-rose-500/80 bg-zinc-850 ring-2 ring-rose-500/30'
                      : cell.isCurrentMonth
                      ? 'border-zinc-800/80 hover:border-zinc-700 bg-zinc-900/60'
                      : 'border-transparent bg-zinc-950/40 opacity-30'
                  } ${isToday ? 'border-amber-500/60 bg-amber-950/20' : ''}`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-semibold inline-flex items-center justify-center w-5 h-5 rounded-full ${
                        isToday
                          ? 'bg-amber-500 text-stone-950 font-bold'
                          : isSelected
                          ? 'bg-rose-600 text-white font-bold'
                          : 'text-stone-300'
                      }`}
                    >
                      {cell.dayNumber}
                    </span>

                    {hasPaymentLesson && (
                      <span
                        title="Bu gün tahsilat / ödeme dersi var!"
                        className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-sm shadow-amber-400 animate-pulse ring-2 ring-amber-400/40"
                      />
                    )}
                  </div>

                  {/* Lesson indicators */}
                  <div className="space-y-1 mt-1 overflow-hidden">
                    {dayLessons.slice(0, 2).map((lesson) => (
                      <div
                        key={lesson.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectLesson(lesson);
                        }}
                        className={`text-[10px] px-1.5 py-0.5 rounded truncate font-medium flex items-center justify-between gap-0.5 ${
                          lesson.isPaymentLesson
                            ? 'bg-amber-950/80 text-amber-300 border border-amber-500/60 font-bold'
                            : lesson.subject === 'english'
                            ? 'bg-sky-950/80 text-sky-300 border border-sky-800/60'
                            : 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                        }`}
                      >
                        <span className="truncate">
                          {lesson.time} {lesson.studentName.split(' ')[0]}
                        </span>
                        {lesson.isPaymentLesson && (
                          <DollarSign className="w-2.5 h-2.5 shrink-0 text-amber-400" />
                        )}
                      </div>
                    ))}

                    {dayLessons.length > 2 && (
                      <div className="text-[9px] text-stone-400 font-semibold text-center">
                        +{dayLessons.length - 2} ders
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Color Legend */}
          <div className="mt-4 pt-3 border-t border-zinc-800 flex flex-wrap items-center gap-4 text-xs text-stone-400">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-sky-500/40 border border-sky-400" />
              <span>İngilizce</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-rose-500/40 border border-rose-400" />
              <span>Türkçe</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-amber-400 border border-amber-300" />
              <span className="font-semibold text-amber-400">💰 Ödeme Alınacak Ders</span>
            </div>
          </div>
        </div>

        {/* Selected Day Agenda Detail (1 col) */}
        <div className="bg-[#121214] rounded-2xl border border-zinc-800 p-4 sm:p-5 shadow-xl flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-4">
            <div>
              <h3 className="font-bold text-white text-sm">
                {selectedDayLessons ? (
                  new Date(selectedDayLessons).toLocaleDateString('tr-TR', {
                    day: 'numeric',
                    month: 'long',
                    weekday: 'long',
                  })
                ) : (
                  'Günün Dersleri'
                )}
              </h3>
              <p className="text-xs text-stone-400">
                {activeDayLessons.length} ders planlandı
              </p>
            </div>

            <button
              onClick={() => onAddNewLesson(selectedDayLessons || undefined)}
              className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-stone-200 text-xs flex items-center gap-1 transition-all cursor-pointer"
              title="Bu güne ders ekle"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Agenda items list */}
          <div className="space-y-3 flex-1 overflow-y-auto max-h-[420px] pr-1">
            {activeDayLessons.length === 0 ? (
              <div className="text-center py-12 text-stone-500">
                <CalendarIcon className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-xs font-medium">Bu tarihte planlanmış ders yok.</p>
                <button
                  onClick={() => onAddNewLesson(selectedDayLessons || undefined)}
                  className="mt-3 text-xs font-bold text-rose-400 hover:underline cursor-pointer"
                >
                  + Yeni ders oluştur
                </button>
              </div>
            ) : (
              activeDayLessons.map((lesson) => {
                const student = students.find((s) => s.id === lesson.studentId);
                const isPayment = lesson.isPaymentLesson;

                return (
                  <div
                    key={lesson.id}
                    onClick={() => onSelectLesson(lesson)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                      isPayment
                        ? 'bg-amber-950/40 border-amber-500/50 hover:bg-amber-950/60 shadow-lg shadow-amber-950/30'
                        : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-stone-100">
                          {lesson.studentName}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            lesson.subject === 'english'
                              ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          }`}
                        >
                          {lesson.subject === 'english' ? 'İngilizce' : 'Türkçe'}
                        </span>
                      </div>

                      <span className="text-xs font-mono font-bold text-stone-300 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-stone-500" />
                        {lesson.time}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-stone-400">
                      <span>
                        Döngü: {lesson.cycleNumber}/{student?.paymentFrequency || 4}. ders
                      </span>
                      <span className="font-bold text-stone-200">
                        {lesson.rate} {lesson.currency === 'USD' ? '$' : '₺'}
                      </span>
                    </div>

                    {isPayment && (
                      <div className="mt-2.5 pt-2 border-t border-amber-500/30 flex items-center justify-between">
                        <div className="flex items-center gap-1 text-[11px] font-bold text-amber-300">
                          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                          <span>Tahsilat Günü: {lesson.rate * (student?.paymentFrequency || 4)} {lesson.currency === 'USD' ? '$' : '₺'}</span>
                        </div>
                        {student && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onMarkPayment(student, lesson);
                            }}
                            className="px-2.5 py-1 text-[11px] font-bold bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-lg transition-all cursor-pointer shadow-sm"
                          >
                            Ödeme Al
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
