import React, { useState } from 'react';
import { SFXEvent } from '../types';
import { ChevronLeft, ChevronRight, Calendar, Sparkles, MapPin, Phone } from 'lucide-react';

interface CalendarViewProps {
  events: SFXEvent[];
  onSelectEvent: (event: SFXEvent) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ events, onSelectEvent }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const firstDayIndex = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  // Group events by YYYY-MM-DD
  const eventsByDate = events.reduce((acc, ev) => {
    if (!acc[ev.event_date]) acc[ev.event_date] = [];
    acc[ev.event_date].push(ev);
    return acc;
  }, {} as Record<string, SFXEvent[]>);

  const daysArray = [];
  // Leading blank days
  for (let i = 0; i < firstDayIndex; i++) {
    daysArray.push(null);
  }
  // Days of current month
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    daysArray.push({ day: d, dateStr, dayEvents: eventsByDate[dateStr] || [] });
  }

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm max-w-4xl mx-auto space-y-6">
      {/* Calendar Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#0f4c81]" />
            <span>Event Schedule Calendar</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            View all HI-TECH SFX bookings scheduled by date
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-slate-800 mr-2">
            {monthNames[month]} {year}
          </span>
          <button
            onClick={prevMonth}
            className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={nextMonth}
            className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Weekday headers */}
      <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-400 uppercase tracking-wider">
        <span>Sun</span>
        <span>Mon</span>
        <span>Tue</span>
        <span>Wed</span>
        <span>Thu</span>
        <span>Fri</span>
        <span>Sat</span>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-7 gap-2">
        {daysArray.map((item, idx) => {
          if (!item) {
            return <div key={`empty-${idx}`} className="h-24 bg-slate-50/50 rounded-xl" />;
          }

          const hasEvents = item.dayEvents.length > 0;
          const isToday =
            new Date().toISOString().split('T')[0] === item.dateStr;

          return (
            <div
              key={item.dateStr}
              className={`min-h-[100px] p-2 rounded-xl border transition flex flex-col justify-between ${
                isToday 
                  ? 'border-[#0f4c81] bg-sky-50/30 ring-1 ring-[#0f4c81]' 
                  : hasEvents 
                  ? 'border-blue-200 bg-white hover:border-[#0f4c81] hover:shadow-xs' 
                  : 'border-slate-100 bg-slate-50/30'
              }`}
            >
              <div className="flex justify-between items-start">
                <span className={`text-xs font-bold ${isToday ? 'text-[#0f4c81]' : 'text-slate-700'}`}>
                  {item.day}
                </span>
                {hasEvents && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                )}
              </div>

              <div className="space-y-1 mt-1 overflow-y-auto max-h-16">
                {item.dayEvents.map(ev => (
                  <button
                    key={ev.id}
                    onClick={() => onSelectEvent(ev)}
                    className="w-full text-left p-1 rounded-md bg-[#0f4c81] text-white hover:bg-[#0c3c66] transition block truncate cursor-pointer shadow-xs"
                    title={`${ev.customer} - ${ev.type || 'Event'}`}
                  >
                    <span className="text-[10px] font-bold block truncate">{ev.customer}</span>
                    <span className="text-[9px] text-sky-200 block truncate">₹{ev.amount || '0'}</span>
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
