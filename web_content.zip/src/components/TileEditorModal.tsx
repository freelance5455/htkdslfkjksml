import React, { useState, useEffect, useRef } from 'react';
import { AppItem } from '../types/launcher';
import { X, Save, Tv, Smartphone } from 'lucide-react';

interface TileEditorModalProps {
  isOpen: boolean;
  editingApp: AppItem | null;
  onClose: () => void;
  onSave: (app: Partial<AppItem>) => void;
}

const COLOR_PRESETS = [
  '#0071E3', // Apple Blue
  '#E50914', // Netflix Red
  '#1DB954', // Spotify Green
  '#9146FF', // Twitch Purple
  '#E5A00D', // Plex Amber
  '#00A8E1', // Prime Blue
  '#F59E0B', // Gold
  '#64748B', // Neutral Slate
];

export const TileEditorModal: React.FC<TileEditorModalProps> = ({
  isOpen,
  editingApp,
  onClose,
  onSave,
}) => {
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [packageName, setPackageName] = useState('');
  const [deepLinkUri, setDeepLinkUri] = useState('');
  const [webFallbackUrl, setWebFallbackUrl] = useState('');
  const [accentColor, setAccentColor] = useState(COLOR_PRESETS[0]);
  const [focusField, setFocusField] = useState(0);

  const titleRef = useRef<HTMLInputElement>(null);
  const subtitleRef = useRef<HTMLInputElement>(null);
  const packageRef = useRef<HTMLInputElement>(null);
  const deepLinkRef = useRef<HTMLInputElement>(null);
  const webRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingApp) {
      setTitle(editingApp.title);
      setSubtitle(editingApp.subtitle);
      setPackageName(editingApp.packageName);
      setDeepLinkUri(editingApp.deepLinkUri);
      setWebFallbackUrl(editingApp.webFallbackUrl);
      setAccentColor(editingApp.accentColor);
    } else {
      setTitle('');
      setSubtitle('Streaming App');
      setPackageName('com.example.androidtv');
      setDeepLinkUri('customapp://');
      setWebFallbackUrl('https://example.com');
      setAccentColor(COLOR_PRESETS[0]);
    }
    if (isOpen) {
      setFocusField(0);
      setTimeout(() => titleRef.current?.focus(), 80);
    }
  }, [editingApp, isOpen]);

  // TV Remote navigation inside TileEditorModal
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Backspace' || e.keyCode === 4 || e.keyCode === 111) {
        // If not actively typing or if empty/escape pressed
        if (e.key === 'Escape' || e.keyCode === 4 || e.keyCode === 111) {
          e.preventDefault();
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSave({
      id: editingApp ? editingApp.id : `custom_${Date.now()}`,
      title: title.trim(),
      subtitle: subtitle.trim() || 'Android App',
      packageName: packageName.trim() || 'com.example.app',
      deepLinkUri: deepLinkUri.trim() || 'https://example.com',
      webFallbackUrl: webFallbackUrl.trim() || 'https://example.com',
      accentColor,
      brandKey: 'custom',
      iconBgGradient: `linear-gradient(135deg, #11141c 0%, #1f2433 60%, ${accentColor} 100%)`,
      custom: true,
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in select-none"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-gradient-to-b from-[#181a20] to-[#0e1014] border border-white/20 rounded-3xl shadow-2xl p-6 md:p-8 text-white overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
          <div>
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Tv className="w-5 h-5 text-sky-400" />
              <span>{editingApp ? 'Edit TV App Tile' : 'Add Custom Tile to Dock'}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Configure Android package name and deep-link protocol
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1.5">App Title</label>
              <input
                ref={titleRef}
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Crunchyroll, Plex, Tivimate"
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Subtitle / Service</label>
              <input
                ref={subtitleRef}
                type="text"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                placeholder="Streaming Service"
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 font-medium mb-1.5 flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Android Package Name</span>
              </label>
              <input
                ref={packageRef}
                type="text"
                value={packageName}
                onChange={(e) => setPackageName(e.target.value)}
                placeholder="com.example.app"
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white font-mono text-xs placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1.5">Deep Link Scheme / URI</label>
              <input
                ref={deepLinkRef}
                type="text"
                value={deepLinkUri}
                onChange={(e) => setDeepLinkUri(e.target.value)}
                placeholder="appscheme:// or https://"
                className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white font-mono text-xs placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1.5">Web Fallback URL</label>
            <input
              ref={webRef}
              type="url"
              value={webFallbackUrl}
              onChange={(e) => setWebFallbackUrl(e.target.value)}
              placeholder="https://..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-white"
            />
          </div>

          {/* Accent Color Preset Picker */}
          <div>
            <label className="block text-slate-300 font-medium mb-2">Tile Accent Glow</label>
            <div className="flex items-center gap-2">
              {COLOR_PRESETS.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setAccentColor(color)}
                  className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer ${
                    accentColor === color ? 'scale-125 border-white ring-2 ring-white/50' : 'border-transparent hover:scale-110'
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>

          {/* Submit & Cancel */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 hover:text-white font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-white text-slate-950 hover:bg-slate-100 font-bold shadow-lg transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{editingApp ? 'Update Tile' : 'Add to Dock'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
