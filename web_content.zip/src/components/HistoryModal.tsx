/**
 * HELENA - Histórico de Consultas & Consenso
 * Shows queries asked to HELENA with consensus indicators (e.g. 2 de 2 concordam),
 * image analysis thumbnail if available, and individual answers of each brain.
 * Styled in dark green theme (--cor-anel, --cor-brilho, --cor-borda).
 */

import React, { useState, useEffect } from 'react';
import { Clock, X, CheckCheck, MessageSquare, ChevronDown, ChevronUp, AlertCircle, Trash2 } from 'lucide-react';
import { HistoryItem } from '../types';
import { loadHistory, clearHistory } from '../services/storage';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({ isOpen, onClose }) => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setHistory(loadHistory());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClear = () => {
    if (confirm('Deseja limpar todo o histórico de consultas?')) {
      clearHistory();
      setHistory([]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="bg-[#030d06] border border-[#14502D] rounded-2xl max-w-xl w-full p-5 flex flex-col max-h-[85vh] shadow-2xl text-[#CDEBD8]"
        style={{ borderColor: 'var(--cor-borda)' }}
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#14502D]/60">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-[#2FD16F]" />
            <h2 className="text-sm font-semibold text-white tracking-wide">
              Histórico & Consenso dos Cérebros
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={handleClear}
                className="p-1.5 text-red-400 hover:text-red-300 rounded hover:bg-red-950/30 transition text-xs flex items-center gap-1"
                title="Limpar histórico"
              >
                <Trash2 size={14} />
              </button>
            )}
            <button 
              onClick={onClose} 
              className="p-1 text-[#CDEBD8]/70 hover:text-white rounded min-h-[40px] min-w-[40px] flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto py-4 space-y-3">
          {history.length === 0 ? (
            <div className="py-12 text-center text-[#CDEBD8]/50 space-y-2">
              <MessageSquare className="w-8 h-8 mx-auto opacity-50" />
              <p className="text-xs">Nenhuma interação registrada ainda.</p>
              <p className="text-[11px] text-[#CDEBD8]/40">
                Fale "Helena" ou envie uma foto de campo para consultar os cérebros.
              </p>
            </div>
          ) : (
            history.map((item) => {
              const hasConsensus = item.consensusCount >= 2;
              const isExpanded = expandedId === item.id;

              return (
                <div
                  key={item.id}
                  className="bg-black/60 border border-[#14502D]/80 rounded-xl p-3.5 space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 flex-1">
                      {item.thumbnail && (
                        <img 
                          src={item.thumbnail} 
                          alt="Miniatura" 
                          className="w-12 h-12 rounded-lg object-cover border border-[#14502D] shrink-0" 
                        />
                      )}
                      <div>
                        <span className="text-xs font-semibold text-[#2FD16F] line-clamp-2">
                          "{item.query}"
                        </span>
                        <span className="text-[10px] text-[#CDEBD8]/40 font-mono block mt-0.5">
                          {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(item.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5 shrink-0">
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                          hasConsensus
                            ? 'bg-[#0E7A3D]/30 border-[#0E7A3D] text-[#2FD16F]'
                            : 'bg-amber-950/40 border-amber-800 text-amber-300'
                        }`}
                      >
                        {item.totalBrains === 2 && item.consensusCount === 1 
                          ? '1 cérebro' 
                          : `${item.consensusCount} de ${item.totalBrains || 2} cérebros`}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-[#CDEBD8]/80 leading-relaxed whitespace-pre-line line-clamp-3">
                    {item.response}
                  </p>

                  {/* Expand individual brain responses */}
                  {item.details && (item.details.gemini || item.details.groq) && (
                    <div className="pt-1.5 border-t border-[#14502D]/50">
                      <button
                        onClick={() => setExpandedId(isExpanded ? null : item.id)}
                        className="text-[11px] text-[#2FD16F] hover:underline flex items-center space-x-1"
                      >
                        <span>{isExpanded ? 'Ocultar detalhes' : 'Ver resposta de cada cérebro'}</span>
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>

                      {isExpanded && (
                        <div className="mt-2 space-y-2 pt-2 border-t border-[#14502D]/30 text-[11px] font-mono">
                          {item.details.gemini && (
                            <div className="p-2 rounded bg-black/40 border border-[#14502D]/50">
                              <span className="text-[#2FD16F] font-semibold block mb-0.5">
                                Cérebro 1 (Gemini):
                              </span>
                              <p className="text-[#CDEBD8]/80 whitespace-pre-line font-sans">
                                {item.details.gemini}
                              </p>
                            </div>
                          )}

                          {item.details.groq && (
                            <div className="p-2 rounded bg-black/40 border border-[#14502D]/50">
                              <span className="text-[#2FD16F] font-semibold block mb-0.5">
                                Cérebro 2 (Groq):
                              </span>
                              <p className="text-[#CDEBD8]/80 whitespace-pre-line font-sans">
                                {item.details.groq}
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
