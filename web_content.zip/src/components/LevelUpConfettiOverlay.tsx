import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, Award, ChevronUp, X } from 'lucide-react';
import { DifficultyLevel } from '../types';
import { playConfettiPopSound } from '../utils/audio';

interface LevelUpConfettiOverlayProps {
  tier: DifficultyLevel | null;
  onDismiss: () => void;
}

const TIER_META: Record<
  DifficultyLevel,
  {
    label: string;
    rankTitle: string;
    subtitle: string;
    accentClass: string;
    badgeBg: string;
    colors: string[];
  }
> = {
  beginner: {
    label: 'Beginner Tier',
    rankTitle: 'Foundation Initiate',
    subtitle: 'Completed your first workout in the Beginner difficulty tier!',
    accentClass: 'from-cyan-400 via-teal-300 to-emerald-400',
    badgeBg: 'border-cyan-400/50 bg-cyan-950/85 text-cyan-200',
    colors: ['#22d3ee', '#34d399', '#a5f3fc', '#f8fafc']
  },
  intermediate: {
    label: 'Intermediate Tier',
    rankTitle: 'Calisthenics Practitioner',
    subtitle: 'Completed your first workout in the Intermediate difficulty tier!',
    accentClass: 'from-cyan-400 via-sky-300 to-amber-300',
    badgeBg: 'border-amber-400/50 bg-amber-950/80 text-amber-200',
    colors: ['#22d3ee', '#fbbf24', '#38bdf8', '#fde68a']
  },
  advanced: {
    label: 'Advanced Tier',
    rankTitle: 'Elite Gravity Master',
    subtitle: 'Completed your first workout in the Advanced difficulty tier!',
    accentClass: 'from-amber-300 via-yellow-200 to-cyan-400',
    badgeBg: 'border-amber-300/60 bg-amber-950/90 text-amber-100',
    colors: ['#fbbf24', '#22d3ee', '#f59e0b', '#fef08a']
  }
};

export const triggerSubtleLevelUpConfetti = (tier: DifficultyLevel) => {
  const meta = TIER_META[tier];
  try {
    // Subtle left & right upper-arc burst
    confetti({
      particleCount: 36,
      angle: 65,
      spread: 55,
      origin: { x: 0.18, y: 0.32 },
      colors: meta.colors,
      ticks: 190,
      gravity: 0.85,
      scalar: 0.85,
      drift: 0.2,
      disableForReducedMotion: true,
      zIndex: 9999
    });

    setTimeout(() => {
      confetti({
        particleCount: 36,
        angle: 115,
        spread: 55,
        origin: { x: 0.82, y: 0.32 },
        colors: meta.colors,
        ticks: 190,
        gravity: 0.85,
        scalar: 0.85,
        drift: -0.2,
        disableForReducedMotion: true,
        zIndex: 9999
      });
    }, 160);
  } catch {
    // Fallback if canvas-confetti fails in non-canvas environments
  }
};

export const LevelUpConfettiOverlay: React.FC<LevelUpConfettiOverlayProps> = ({
  tier,
  onDismiss
}) => {
  useEffect(() => {
    if (!tier) return;

    playConfettiPopSound();
    triggerSubtleLevelUpConfetti(tier);

    const timer = window.setTimeout(() => {
      onDismiss();
    }, 5200);

    return () => window.clearTimeout(timer);
  }, [tier, onDismiss]);

  if (!tier) return null;

  const meta = TIER_META[tier];

  return (
    <div
      className="fixed inset-0 z-[80] pointer-events-none flex flex-col items-center justify-start pt-6 px-4 overflow-hidden"
      aria-live="polite"
    >
      {/* Subtle Ambient Top Radial Glow */}
      <div className="
        absolute top-0 left-1/2 -translate-x-1/2 w-[420px] h-[180px]
        bg-gradient-to-b from-cyan-500/20 via-amber-400/10 to-transparent
        blur-3xl pointer-events-none animate-pulse
      " />

      {/* Floating Level Up Toast / Crest Overlay */}
      <div className="pointer-events-auto relative w-full max-w-sm rounded-2xl bg-[#0f131c]/95 backdrop-blur-xl border border-cyan-400/50 shadow-[0_0_35px_-5px_rgba(34,211,238,0.35)] p-4 overflow-hidden animate-badge-pop">
        {/* Shimmer Highlight Sweep */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer pointer-events-none" />

        <div className="relative z-10 flex items-center gap-3.5">
          {/* Level Up Crest Icon */}
          <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-300 via-amber-400 to-cyan-400 p-[1.5px] shadow-lg shadow-cyan-500/25 shrink-0">
            <div className="w-full h-full rounded-[14px] bg-neutral-950 flex flex-col items-center justify-center">
              <ChevronUp className="w-4 h-4 text-amber-300 -mb-1.5 stroke-[3]" />
              <Award className="w-5 h-5 text-cyan-400" />
            </div>
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-neutral-950 flex items-center justify-center shadow">
              <Sparkles className="w-2.5 h-2.5 fill-neutral-950" />
            </span>
          </div>

          {/* Copy */}
          <div className="flex-1 min-w-0 text-left">
            <div className="flex items-center gap-1.5 mb-0.5">
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border bg-amber-400/20 border-amber-300/50 text-amber-200">
                Level Up
              </span>
              <span
                className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border ${meta.badgeBg}`}
              >
                {meta.label}
              </span>
            </div>

            <h4
              className={`text-sm font-black tracking-tight bg-gradient-to-r ${meta.accentClass} bg-clip-text text-transparent`}
            >
              {meta.rankTitle} Unlocked!
            </h4>
            <p className="text-[11px] text-slate-300 leading-snug mt-0.5">{meta.subtitle}</p>
          </div>

          {/* Dismiss Button */}
          <button
            type="button"
            onClick={onDismiss}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-neutral-800/80 transition-colors shrink-0"
            title="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
