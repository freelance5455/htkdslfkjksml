import React, { useState } from "react";
import {
  StickyNote,
  Pin,
  Star,
  Clock,
  Mic,
  Camera,
  Layers,
  Stamp,
  Sparkles,
  ChevronDown,
  ChevronUp,
  FileText,
  Shield,
  BookOpen,
  FolderKanban,
  CheckSquare
} from "lucide-react";
import { Note, ThemeAccent, FilterOption } from "../types";
import { THEME_ACCENTS } from "../utils/theme";

interface WorkspaceOverviewProps {
  notes: Note[];
  vaultCount: number;
  clipsCount: number;
  filterOption: FilterOption;
  setFilterOption: (f: FilterOption) => void;
  themeAccent?: ThemeAccent;
  onOpenNewNote: () => void;
  onOpenSideGallery: () => void;
  onOpenAIChat: () => void;
  onOpenDocumentHub: () => void;
}

export const WorkspaceOverview: React.FC<WorkspaceOverviewProps> = ({
  notes,
  vaultCount,
  clipsCount,
  filterOption,
  setFilterOption,
  themeAccent = "teal",
  onOpenNewNote,
  onOpenSideGallery,
  onOpenAIChat,
  onOpenDocumentHub,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;

  const totalNotes = notes.length;
  const pinnedNotes = notes.filter((n) => n.pinned).length;
  const favoriteNotes = notes.filter((n) => n.favorite).length;
  const reminderNotes = notes.filter((n) => n.reminder).length;
  const taskNotes = notes.filter((n) => n.tasks && n.tasks.length > 0).length;
  const audioNotes = notes.filter((n) => n.audioNotes && n.audioNotes.length > 0).length;

  return (
    <div className="bg-gradient-to-br from-white via-slate-50 to-slate-100/70 dark:from-slate-900 dark:via-slate-900/90 dark:to-slate-950 rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs transition-all select-none">
      {/* Header bar */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-xl ${themeDef.bgLight} ${themeDef.bgLightDark} ${themeDef.text} ${themeDef.textDark} flex items-center justify-center font-bold text-xs`}
          >
            ✦
          </div>
          <div>
            <h2 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white leading-tight">
              Çalışma Alanı & Hızlı Özet
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              {totalNotes} not • {pinnedNotes} sabitli • {favoriteNotes} favori
            </p>
          </div>
        </div>

        {/* Quick action buttons & toggle */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenSideGallery}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700/80 transition-colors shadow-2xs"
            title="Öğeler (Elements) & Çıkartma Kütüphanesi"
          >
            <Stamp className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>Öğeler & Çıkartmalar</span>
            {clipsCount > 0 && (
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-teal-500 text-white font-bold">
                {clipsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
            title={isExpanded ? "Özeti Daralt" : "Özeti Genişlet"}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Modern Horizontally Scrollable Filter Chips (Tümü, Favoriler, Görevler, Hatırlatıcı, vb.) */}
      <div
        className="flex flex-nowrap items-center gap-2 overflow-x-auto mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-800/80 text-xs scrollbar-none no-scrollbar touch-pan-x select-none"
        style={{
          scrollbarWidth: "none",
          msOverflowStyle: "none",
          WebkitOverflowScrolling: "touch",
        }}
      >
        {/* All notes */}
        <button
          onClick={() => setFilterOption("all")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border transition-all shrink-0 whitespace-nowrap cursor-pointer ${
            filterOption === "all"
              ? "bg-teal-600 dark:bg-teal-500 text-white border-teal-600 dark:border-teal-500 shadow-xs font-black"
              : "bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60"
          }`}
        >
          <StickyNote className="w-3.5 h-3.5" />
          <span>Tümü</span>
          <span
            className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
              filterOption === "all" ? "bg-white/25 text-white" : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
            }`}
          >
            {totalNotes}
          </span>
        </button>

        {/* Favorites */}
        <button
          onClick={() => setFilterOption(filterOption === "favorites" ? "all" : "favorites")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border transition-all shrink-0 whitespace-nowrap cursor-pointer ${
            filterOption === "favorites"
              ? "bg-amber-500 dark:bg-amber-600 text-white border-amber-500 dark:border-amber-600 shadow-xs font-black"
              : "bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60"
          }`}
        >
          <Star className="w-3.5 h-3.5" />
          <span>Favoriler</span>
          <span
            className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
              filterOption === "favorites" ? "bg-white/25 text-white" : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
            }`}
          >
            {favoriteNotes}
          </span>
        </button>

        {/* Tasks */}
        <button
          onClick={() => setFilterOption(filterOption === "tasks" ? "all" : "tasks")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border transition-all shrink-0 whitespace-nowrap cursor-pointer ${
            filterOption === "tasks"
              ? "bg-purple-600 dark:bg-purple-500 text-white border-purple-600 dark:border-purple-500 shadow-xs font-black"
              : "bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60"
          }`}
        >
          <CheckSquare className="w-3.5 h-3.5" />
          <span>Görevler</span>
          <span
            className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
              filterOption === "tasks" ? "bg-white/25 text-white" : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
            }`}
          >
            {taskNotes}
          </span>
        </button>

        {/* Reminders */}
        <button
          onClick={() => setFilterOption(filterOption === "reminders" ? "all" : "reminders")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border transition-all shrink-0 whitespace-nowrap cursor-pointer ${
            filterOption === "reminders"
              ? "bg-blue-600 dark:bg-blue-500 text-white border-blue-600 dark:border-blue-500 shadow-xs font-black"
              : "bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60"
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Hatırlatıcı</span>
          <span
            className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
              filterOption === "reminders" ? "bg-white/25 text-white" : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
            }`}
          >
            {reminderNotes}
          </span>
        </button>

        {/* Vault stats */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border bg-emerald-50/70 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 shrink-0 whitespace-nowrap">
          <Shield className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          <span>Kasa</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full font-extrabold bg-emerald-600 text-white">
            {vaultCount}
          </span>
        </div>

        {/* Photo clips count */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border bg-purple-50/70 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800 text-purple-800 dark:text-purple-300 shrink-0 whitespace-nowrap">
          <Camera className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
          <span>Enstantane</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full font-extrabold bg-purple-600 text-white">
            {clipsCount}
          </span>
        </div>
      </div>

      {/* Expanded quick feature discovery helper */}
      {isExpanded && (
        <div className="mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs animate-in fade-in">
          <div
            onClick={onOpenAIChat}
            className="p-2.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 cursor-pointer hover:border-amber-400 transition-colors"
          >
            <div className="flex items-center gap-1.5 font-bold text-amber-900 dark:text-amber-200 mb-1">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Yapay Zeka Asistanı</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
              Notlarınızı otomatik özetleyin, şemalandırın ve yeni fikirler üretin.
            </p>
          </div>

          <div
            onClick={onOpenDocumentHub}
            className="p-2.5 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/50 cursor-pointer hover:border-blue-400 transition-colors"
          >
            <div className="flex items-center gap-1.5 font-bold text-blue-900 dark:text-blue-200 mb-1">
              <FileText className="w-4 h-4 text-blue-500" />
              <span>Evrensel Belge Merkezi</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
              Word (.docx), PDF, Excel (.xlsx), Markdown ve TXT formatlarında içe/dışa aktarın.
            </p>
          </div>

          <div
            onClick={onOpenSideGallery}
            className="p-2.5 rounded-2xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-900/50 cursor-pointer hover:border-teal-400 transition-colors"
          >
            <div className="flex items-center gap-1.5 font-bold text-teal-900 dark:text-teal-200 mb-1">
              <Layers className="w-4 h-4 text-teal-600" />
              <span>30 Çerçeve & Fotoğraf</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
              Notlarınızı 30 özel çerçeveyle süsleyin ve yüksek çözünürlüklü fotoğraflara dönüştürün.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
