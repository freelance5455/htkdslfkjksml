"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import gsap from "gsap";

export default function HeroContent() {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        "[data-hero]",
        { opacity: 0, y: 40, filter: "blur(8px)" },
        { opacity: 1, y: 0, filter: "blur(0px)", duration: 1, stagger: 0.18, ease: "power3.out", delay: 0.3 }
      );
      gsap.to("[data-hero-float]", {
        y: -12,
        duration: 2.4,
        yoyo: true,
        repeat: -1,
        ease: "sine.inOut",
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <div ref={root} className="relative z-10 pt-10 text-center lg:pb-16 lg:pt-0 lg:text-left">
      <div
        data-hero
        data-hero-float
        className="mx-auto mb-6 inline-flex lg:mx-0 items-center gap-2 rounded-full border border-purple-400/30 bg-purple-500/10 px-4 py-1.5 text-xs font-semibold tracking-widest text-purple-300 backdrop-blur"
      >
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-purple-400" />
        THE NEXT GENERATION OF CALCULATION
      </div>

      <h1
        data-hero
        className="font-display text-[clamp(2.2rem,5.6vw,4.4rem)] font-black leading-[1.08] text-white"
      >
        Explore The <span className="text-gradient drop-shadow-[0_0_25px_rgba(139,92,246,0.5)]">Future</span>
        <br />
        of Calculation
      </h1>

      <p data-hero className="mx-auto mt-6 max-w-2xl text-lg text-slate-400 md:text-xl lg:mx-0">
        Discover Premium Models. Calculate Smarter. Shop Better.
      </p>

      <div data-hero className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row lg:justify-start">
        <Link
          href="#models"
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-purple-500 to-blue-600 px-8 py-4 font-bold text-white shadow-[0_0_35px_rgba(139,92,246,0.45)] transition hover:shadow-[0_0_55px_rgba(139,92,246,0.7)] sm:w-auto"
        >
          <span className="relative z-10 flex items-center justify-center gap-2">
            Explore Models
            <svg className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </span>
        </Link>
        <Link
          href="#calculator"
          className="w-full rounded-2xl border border-white/20 bg-white/5 px-8 py-4 font-bold text-white backdrop-blur transition hover:border-purple-400/60 hover:bg-white/10 sm:w-auto"
        >
          Try Calculator
        </Link>
      </div>

      <div data-hero className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          ["20+", "Premium Models"],
          ["7", "Collections"],
          ["12K+", "Happy Users"],
          ["৳ BDT", "Local Pricing"],
        ].map(([num, label]) => (
          <div key={label} className="glass rounded-2xl px-4 py-5">
            <p className="font-display text-2xl font-black text-gradient">{num}</p>
            <p className="mt-1 text-xs uppercase tracking-widest text-slate-400">{label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}