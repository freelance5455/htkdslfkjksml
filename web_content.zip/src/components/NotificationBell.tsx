import React from 'react';
import { Bell } from 'lucide-react';

interface NotificationBellProps {
  unreadCount: number;
  onClick: () => void;
  className?: string;
  hasNewNotification?: boolean;
}

export default function NotificationBell({
  unreadCount,
  onClick,
  className = '',
  hasNewNotification = false
}: NotificationBellProps) {
  const displayCount = unreadCount > 99 ? '99+' : unreadCount > 0 ? String(unreadCount) : null;

  return (
    <button
      type="button"
      id="edumind-top-notification-bell"
      onClick={onClick}
      aria-label={`Notifications ${unreadCount > 0 ? `(${unreadCount} unread)` : ''}`}
      className={`relative p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 text-slate-300 hover:text-white border border-slate-700/80 transition-all duration-200 cursor-pointer shadow-sm active:scale-95 group focus:outline-none focus:ring-2 focus:ring-indigo-500/50 ${
        hasNewNotification ? 'animate-bounce' : ''
      } ${className}`}
      title={unreadCount > 0 ? `${unreadCount} Unread Notifications` : 'Notification Center'}
    >
      {/* Bell Icon with hover effect */}
      <Bell className={`w-4 h-4 transition-transform duration-200 group-hover:rotate-12 ${
        unreadCount > 0 ? 'text-indigo-300 group-hover:text-indigo-200' : 'text-slate-300'
      }`} />

      {/* Unread Count Badge (Only shown when unreadCount > 0) */}
      {displayCount && (
        <span
          id="edumind-notification-badge"
          className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 bg-gradient-to-r from-rose-500 to-pink-600 text-white font-extrabold text-[10px] leading-tight flex items-center justify-center rounded-full ring-2 ring-slate-950 shadow-md shadow-rose-600/40 animate-in fade-in zoom-in-50 duration-200"
        >
          {displayCount}
        </span>
      )}

      {/* Subtle glowing ring if notifications exist */}
      {unreadCount > 0 && (
        <span className="absolute inset-0 rounded-xl bg-indigo-500/10 pointer-events-none group-hover:bg-indigo-500/20 transition-colors" />
      )}
    </button>
  );
}
