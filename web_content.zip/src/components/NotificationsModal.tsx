import React from 'react';
import { doc, updateDoc } from 'firebase/firestore';
import { Bell, CheckCheck, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { formatRelativeTime } from '../lib/mediaUtils';
import type { NotificationItem } from '../types';

interface NotificationsModalProps {
  open: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  open,
  onClose,
  notifications,
}) => {
  if (!open) return null;

  const markRead = async (id: string) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notifications/${id}`);
    }
  };

  const markAllRead = async () => {
    for (const n of notifications.filter((item) => !item.read)) {
      await markRead(n.id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md max-h-[85vh] flex flex-col overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-blue-600" />
            <h2 className="font-display font-bold text-base">Notifications</h2>
          </div>
          <div className="flex items-center gap-2">
            {notifications.some((n) => !n.read) && (
              <button
                type="button"
                onClick={() => void markAllRead()}
                className="text-xs font-semibold text-blue-700 dark:text-blue-400 flex items-center gap-1"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark all read</span>
              </button>
            )}
            <button type="button" onClick={onClose} className="p-1.5">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              No notifications yet. Activity from messages, friend requests, likes, and announcements will appear here.
            </div>
          ) : (
            notifications.map((n) => (
              <button
                key={n.id}
                type="button"
                onClick={() => void markRead(n.id)}
                className={`w-full text-left p-4 space-y-1 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors ${
                  !n.read ? 'bg-blue-50/60 dark:bg-blue-950/30' : ''
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-xs text-slate-900 dark:text-white">
                    {n.title}
                  </span>
                  <span className="text-[11px] text-slate-400">{formatRelativeTime(n.createdAt)}</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300">{n.body}</p>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
