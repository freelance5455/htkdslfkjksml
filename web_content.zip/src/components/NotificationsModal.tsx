import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Bell, 
  Flame, 
  MessageSquare, 
  Sparkles, 
  Trophy 
} from 'lucide-react';

export const NotificationsModal: React.FC = () => {
  const { isNotificationsOpen, setIsNotificationsOpen } = useApp();

  if (!isNotificationsOpen) return null;

  const demoNotifications = [
    { id: 'n1', icon: Flame, text: 'Your confession in #DU-NORTH hit 250+ likes!', time: '10m ago', unread: true, color: 'text-rose-400' },
    { id: 'n2', icon: MessageSquare, text: 'Someone replied to your maroon hoodie whisper: "Bro I am wearing a maroon hoodie right now..."', time: '45m ago', unread: true, color: 'text-cyan-400' },
    { id: 'n3', icon: Trophy, text: 'Badge unlocked: "Campus Oracle" earned for 300+ karma!', time: '3h ago', unread: false, color: 'text-amber-400' },
    { id: 'n4', icon: Sparkles, text: 'Funny Friday theme is now active! 2x Karma on funny confessions.', time: '1d ago', unread: false, color: 'text-purple-400' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#0e111d] border border-cyan-500/30 rounded-3xl p-5 shadow-2xl shadow-cyan-950/40 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-cyan-400" />
            <h3 className="font-display font-bold text-base text-slate-100">
              Whisper Notifications
            </h3>
          </div>
          <button
            onClick={() => setIsNotificationsOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="divide-y divide-slate-800/80 my-3 max-h-80 overflow-y-auto">
          {demoNotifications.map(n => {
            const Icon = n.icon;
            return (
              <div key={n.id} className="py-3 flex items-start gap-3">
                <div className={`p-2 rounded-xl bg-slate-900 border border-slate-800 ${n.color} shrink-0`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 text-xs">
                  <p className="text-slate-200 leading-relaxed font-sans">{n.text}</p>
                  <span className="text-[10px] text-slate-500 mt-1 block">{n.time}</span>
                </div>
                {n.unread && (
                  <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0 mt-1 shadow-sm shadow-cyan-400" />
                )}
              </div>
            );
          })}
        </div>

        <button
          onClick={() => setIsNotificationsOpen(false)}
          className="w-full py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 transition-colors"
        >
          Mark all as read
        </button>
      </div>
    </div>
  );
};
