import React, { useState } from 'react';
import { X, Bell, Heart, MessageCircle, UserPlus, CheckCheck, Sparkles } from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { NotificationItem } from '../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTarget?: (postId?: string) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onSelectTarget,
}) => {
  const { 
    notifications, 
    markNotificationAsRead, 
    markAllNotificationsAsRead, 
    unreadNotifsCount 
  } = useSocial();

  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  if (!isOpen) return null;

  const filtered = filter === 'unread' 
    ? notifications.filter(n => !n.isRead) 
    : notifications;

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="w-3.5 h-3.5 text-white fill-white" />;
      case 'comment':
        return <MessageCircle className="w-3.5 h-3.5 text-white fill-white" />;
      case 'follow':
        return <UserPlus className="w-3.5 h-3.5 text-white" />;
      default:
        return <Sparkles className="w-3.5 h-3.5 text-white" />;
    }
  };

  const getBadgeBg = (type: NotificationItem['type']) => {
    switch (type) {
      case 'like': return 'bg-rose-500';
      case 'comment': return 'bg-emerald-500';
      case 'follow': return 'bg-[#1877F2]';
      default: return 'bg-purple-500';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center p-3 sm:p-4 pt-12 sm:pt-16 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150 flex flex-col max-h-[80vh]">
        
        {/* Header */}
        <div className="p-3.5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="font-bold text-slate-900 text-lg">Notifications</h2>
            {unreadNotifsCount > 0 && (
              <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                {unreadNotifsCount} new
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {unreadNotifsCount > 0 && (
              <button
                onClick={markAllNotificationsAsRead}
                className="text-xs font-semibold text-[#1877F2] hover:underline flex items-center gap-1 cursor-pointer"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark read</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="px-4 py-2 border-b border-slate-100 flex items-center gap-2 bg-slate-50/50">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer ${
              filter === 'all' 
                ? 'bg-[#1877F2] text-white' 
                : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('unread')}
            className={`px-3 py-1 rounded-full text-xs font-bold transition-colors cursor-pointer ${
              filter === 'unread' 
                ? 'bg-[#1877F2] text-white' 
                : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            Unread ({unreadNotifsCount})
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <Bell className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="text-sm font-medium text-slate-600">No notifications to show</p>
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  markNotificationAsRead(item.id);
                  if (item.targetId && onSelectTarget) {
                    onSelectTarget(item.targetId);
                    onClose();
                  }
                }}
                className={`p-3 rounded-2xl flex items-start gap-3 cursor-pointer transition-colors ${
                  item.isRead ? 'hover:bg-slate-50' : 'bg-blue-50/60 hover:bg-blue-50'
                }`}
              >
                {/* Avatar with icon badge */}
                <div className="relative shrink-0">
                  <img
                    src={item.senderPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'}
                    alt={item.senderName}
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200"
                  />
                  <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full ${getBadgeBg(item.type)} flex items-center justify-center ring-2 ring-white shadow-xs`}>
                    {getIcon(item.type)}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm text-slate-800 leading-snug">
                    <strong className="font-bold text-slate-900">{item.senderName} </strong>
                    <span>{item.message}</span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1 font-medium">
                    {formatTimeAgo(item.createdAt)}
                  </p>
                </div>

                {/* Unread marker */}
                {!item.isRead && (
                  <span className="w-2.5 h-2.5 rounded-full bg-[#1877F2] shrink-0 mt-2"></span>
                )}
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};

function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const diffSec = Math.floor((Date.now() - date.getTime()) / 1000);
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHrs = Math.floor(diffMin / 60);
  if (diffHrs < 24) return `${diffHrs}h ago`;
  return `${Math.floor(diffHrs / 24)}d ago`;
}
