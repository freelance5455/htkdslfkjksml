import { Heart } from "lucide-react";
import type { FlowerEntry } from "../types/flower";
import { FlowerImage } from "./FlowerImage";

interface FlowerCardProps {
  flower: FlowerEntry;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onSelect: (flower: FlowerEntry) => void;
}

export function FlowerCard({
  flower,
  isFavorite,
  onToggleFavorite,
  onSelect,
}: FlowerCardProps) {
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-xl border border-[#EFE3E6] bg-white transition-all duration-200 hover:-translate-y-0.5 hover:border-[#DEC6CD] hover:shadow-[0_10px_30px_-12px_rgba(157,60,86,0.16)]">
      <div className="relative aspect-[4/3] w-full overflow-hidden">
        <button
          type="button"
          onClick={() => onSelect(flower)}
          className="block h-full w-full text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56]"
          aria-label={`${flower.uzName} haqida ma’lumotni ochish`}
        >
          <FlowerImage
            wikiQuery={flower.wikiQuery}
            latinName={flower.latinName}
            enName={flower.enName}
            uzName={flower.uzName}
            fallbackImage={flower.fallbackImage}
            className="h-full w-full"
          />
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(flower.id);
          }}
          aria-label={
            isFavorite
              ? `${flower.uzName}ni sevimlilardan olib tashlash`
              : `${flower.uzName}ni sevimlilarga qo‘shish`
          }
          aria-pressed={isFavorite}
          className={`absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full border transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56] ${
            isFavorite
              ? "border-[#9D3C56] bg-[#9D3C56] text-white"
              : "border-white/70 bg-white/90 text-[#6F4854] hover:bg-white hover:text-[#9D3C56]"
          }`}
        >
          <Heart
            className="h-4 w-4"
            fill={isFavorite ? "currentColor" : "none"}
            strokeWidth={1.8}
          />
        </button>
      </div>

      <button
        type="button"
        onClick={() => onSelect(flower)}
        className="flex flex-1 flex-col justify-between p-5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#9D3C56]"
      >
        <div>
          <p className="text-xs font-medium text-[#8C6470]">
            <span>{flower.color}</span>
            <span aria-hidden="true" className="mx-1.5">
              ·
            </span>
            <span>{flower.season}</span>
          </p>

          <h3 className="mt-1.5 font-display text-2xl font-semibold leading-snug text-[#2B1D22] group-hover:text-[#9D3C56] transition-colors">
            {flower.uzName}
          </h3>

          <p className="mt-0.5 font-display text-sm italic text-[#7B5A64]">
            {flower.latinName}
          </p>
        </div>

        <div className="mt-4 border-t border-[#F6ECEF] pt-3">
          <p className="line-clamp-1 text-xs leading-relaxed text-[#5C444C]">
            {flower.meaning}
          </p>
        </div>
      </button>
    </article>
  );
}
