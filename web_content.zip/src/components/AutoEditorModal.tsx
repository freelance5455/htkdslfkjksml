import React, { useState } from 'react';
import { Wand2, ArrowLeft, Check, Sparkles, AlertCircle, FileText } from 'lucide-react';
import { IdentifiedResource } from '../types';

interface AutoEditorModalProps {
  resources: IdentifiedResource[];
  packageName: string;
  onApplyAutomatic: (replacementValue: number) => void;
  onBack: () => void;
}

export const AutoEditorModal: React.FC<AutoEditorModalProps> = ({
  resources,
  packageName,
  onApplyAutomatic,
  onBack
}) => {
  const [replacementInput, setReplacementInput] = useState<string>('999999');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const presets = [
    { label: '100,000', value: 100000, desc: 'Balanced Boost' },
    { label: '999,999', value: 999999, desc: 'Most Popular' },
    { label: '1,000,000', value: 1000000, desc: 'Milestone' },
    { label: '9,999,999', value: 9999999, desc: 'High Tier' },
    { label: '99,999,999', value: 99999999, desc: 'Unlimited' }
  ];

  const handleInputChange = (val: string) => {
    const cleaned = val.replace(/[^0-9]/g, '');
    setReplacementInput(cleaned);
    setErrorMsg(null);
  };

  const handleSelectPreset = (val: number) => {
    setReplacementInput(String(val));
    setErrorMsg(null);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const parsed = parseInt(replacementInput, 10);
    if (isNaN(parsed) || parsed < 0) {
      setErrorMsg('Please enter a valid positive numerical currency value.');
      return;
    }
    if (parsed > 2147483647) {
      setErrorMsg('Value exceeds standard 32-bit integer limit (2,147,483,647). Please enter a smaller number.');
      return;
    }
    onApplyAutomatic(parsed);
  };

  const currentNumeric = parseInt(replacementInput, 10) || 0;

  // Count unique files affected
  const uniqueFiles = Array.from(new Set(resources.map((r) => r.filePath)));

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-xl mx-auto py-2">
      {/* Header */}
      <div className="w-full flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="text-center">
          <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider font-mono">
            Automatic Batch Modification
          </span>
          <h2 className="text-lg sm:text-xl font-bold text-white">
            Set Universal Currency Value
          </h2>
        </div>
        <div className="w-9" />
      </div>

      <div className="w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/10">
            <Wand2 className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Batch Resource Patcher</h3>
            <p className="text-xs text-slate-400">
              Target package: <span className="font-mono text-slate-300">{packageName}</span>
            </p>
          </div>
        </div>

        {/* PROMPT SPECIFIED IN USER REQUIREMENTS */}
        <form onSubmit={handleSubmit} className="mt-4">
          <label className="block text-sm font-semibold text-slate-200 mb-2">
            Specify the value to be used as a replacement for the existing in-game currency values:
          </label>

          {/* Primary Numeric Input */}
          <div className="relative mt-2">
            <input
              type="text"
              autoFocus
              value={currentNumeric ? currentNumeric.toLocaleString() : replacementInput}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="e.g. 999,999"
              className="w-full py-4 px-5 rounded-2xl bg-slate-950 border-2 border-emerald-500/50 focus:border-emerald-400 text-2xl font-mono font-bold text-emerald-300 focus:outline-none transition shadow-inner placeholder-slate-600"
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>UNITS</span>
            </div>
          </div>

          {errorMsg && (
            <div className="mt-2 text-xs text-rose-400 flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Preset Buttons */}
          <div className="mt-4">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Or pick a quick value preset:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {presets.map((preset) => (
                <button
                  key={preset.value}
                  type="button"
                  onClick={() => handleSelectPreset(preset.value)}
                  className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                    currentNumeric === preset.value
                      ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-sm'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  <span className="block text-xs font-mono font-bold">
                    {preset.label}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {preset.desc}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Scope Impact Preview Card */}
          <div className="mt-6 p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
              <FileText className="w-4 h-4 text-emerald-400" />
              Target Scope &amp; Modification Summary:
            </span>
            <div className="space-y-1.5 text-slate-400">
              <div className="flex justify-between">
                <span>Total Resource Locations:</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {resources.length} definitions
                </span>
              </div>
              <div className="flex justify-between">
                <span>Unique Files Affected:</span>
                <span className="font-mono text-slate-200">
                  {uniqueFiles.length} file(s)
                </span>
              </div>
              <div className="flex justify-between">
                <span>New Replaced Value:</span>
                <span className="font-mono text-amber-300 font-bold">
                  {currentNumeric.toLocaleString()} each
                </span>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <div className="mt-6 flex flex-col sm:flex-row items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="w-full sm:w-auto px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!currentNumeric}
              className="w-full flex-1 py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:via-teal-400 hover:to-emerald-500 disabled:opacity-50 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Apply Automatic Modification to All Files</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
