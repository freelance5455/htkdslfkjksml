import { useEffect, useRef, useState } from "react";
import { Flower2 } from "lucide-react";
import { useFlowerMedia } from "../hooks/useFlowerMedia";

interface FlowerImageProps {
  wikiQuery: string;
  latinName: string;
  enName: string;
  uzName: string;
  fallbackImage: string;
  preferFull?: boolean;
  className?: string;
}

export function FlowerImage({
  wikiQuery,
  latinName,
  enName,
  uzName,
  fallbackImage,
  preferFull = false,
  className = "",
}: FlowerImageProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isVisible, setIsVisible] = useState(preferFull);
  const [imgError, setImgError] = useState(false);
  const [fallbackError, setFallbackError] = useState(false);

  useEffect(() => {
    if (preferFull || isVisible) return;
    const node = containerRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: "200px" }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [preferFull, isVisible]);

  const { media } = useFlowerMedia(wikiQuery, latinName, enName, isVisible);

  const rawWikiUrl = preferFull
    ? media?.fullImageUrl || media?.imageUrl
    : media?.imageUrl;

  const proxiedUrl =
    rawWikiUrl && rawWikiUrl.startsWith("https://upload.wikimedia.org/")
      ? `/api/image-proxy?url=${encodeURIComponent(rawWikiUrl)}`
      : rawWikiUrl;

  const activeSrc = !imgError && proxiedUrl ? proxiedUrl : fallbackImage;

  useEffect(() => {
    setImgError(false);
  }, [proxiedUrl]);

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden bg-[#F6ECEF] ${className}`}
    >
      {!fallbackError ? (
        <img
          src={activeSrc}
          alt={`${uzName} (${latinName})`}
          referrerPolicy="no-referrer"
          loading="lazy"
          onError={() => {
            if (activeSrc !== fallbackImage) {
              setImgError(true);
            } else {
              setFallbackError(true);
            }
          }}
          className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#F9ECEF] via-[#FDF6F7] to-[#EFE1E6] p-4 text-center">
          <Flower2 className="h-9 w-9 text-[#9D3C56]/60" strokeWidth={1.5} />
          <span className="mt-2 font-display text-lg font-semibold text-[#4A2530]">
            {uzName}
          </span>
        </div>
      )}
    </div>
  );
}
