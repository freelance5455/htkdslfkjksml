import React from 'react';
import { useApp } from '../context/AppContext';
import { Globe, RefreshCw, LayoutDashboard, Send, Activity, Home, ShieldCheck, Sparkles, Crown } from 'lucide-react';

export const InvestorToolbar: React.FC = () => {
  const { 
    language, 
    toggleLanguage, 
    currentView, 
    setCurrentView, 
    resetDemoData, 
    requests,
    isAdminLoggedIn
  } = useApp();

  const isAr = language === 'ar';

  return (
    <div className="bg-black text-zinc-300 border-b border-[#D4AF37]/30 text-xs py-2 px-4 sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left: Brand Badge & Investor Demo Notice */}
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 bg-[#D4AF37]/15 text-amber-300 border border-[#D4AF37]/40 px-2.5 py-0.5 rounded-full font-bold shadow-[0_0_10px_rgba(212,175,55,0.15)]">
            <Crown className="w-3.5 h-3.5 text-[#D4AF37] animate-pulse" />
            <span>{isAr ? 'المواساة | نموذج العرض الذهبي' : 'Al-Mowasat | Gold Edition'}</span>
          </span>
          <span className="hidden md:inline text-zinc-400">
            {isAr 
              ? 'مُهيأ للعرض أمام المستثمرين والشركاء (بيانات تجريبية)' 
              : 'Configured for Investors & Healthcare Partners'}
          </span>
        </div>

        {/* Center: Fast Interactive Navigation */}
        <div className="flex items-center flex-wrap gap-1.5 sm:gap-2">
          <button
            onClick={() => setCurrentView('welcome')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              currentView === 'welcome' 
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-extrabold shadow-sm' 
                : 'bg-zinc-900/80 hover:bg-zinc-800 text-amber-300 border border-[#D4AF37]/30'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isAr ? 'واجهة الترحيب' : 'Splash'}</span>
          </button>

          <button
            onClick={() => setCurrentView('home')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              currentView === 'home' 
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-extrabold shadow-sm' 
                : 'hover:bg-zinc-900 text-zinc-300'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>{isAr ? 'الرئيسية' : 'Home'}</span>
          </button>

          <button
            onClick={() => setCurrentView('request-form')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              currentView === 'request-form' 
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-extrabold shadow-sm' 
                : 'hover:bg-zinc-900 text-zinc-300'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isAr ? 'طلب خدمة تجريبي' : 'Demo Request'}</span>
          </button>

          <button
            onClick={() => setCurrentView('tracking')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              currentView === 'tracking' 
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-extrabold shadow-sm' 
                : 'hover:bg-zinc-900 text-zinc-300'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>{isAr ? 'متابعة مريض' : 'Patient Portal'}</span>
          </button>

          <button
            onClick={() => setCurrentView('admin')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              currentView === 'admin' 
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-extrabold shadow-sm' 
                : 'bg-black text-amber-300 hover:bg-zinc-900 border border-[#D4AF37]/50'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'لوحة الإدارة' : 'Admin'}</span>
            <span className="bg-[#D4AF37]/20 text-amber-200 text-[10px] px-1.5 py-0.2 rounded-full ml-1 font-mono">
              {requests.length}
            </span>
          </button>
        </div>

        {/* Right: Language Switcher & Reset Data */}
        <div className="flex items-center gap-2">
          <button
            onClick={resetDemoData}
            title={isAr ? 'إعادة ضبط البيانات التجريبية الافتراضية' : 'Reset demo data to initial state'}
            className="flex items-center gap-1 hover:text-white text-zinc-400 hover:bg-zinc-900 px-2 py-1 rounded transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-zinc-400" />
            <span className="hidden sm:inline">{isAr ? 'إعادة الضبط' : 'Reset'}</span>
          </button>

          <div className="h-4 w-px bg-zinc-800 hidden sm:block"></div>

          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 bg-zinc-900 hover:bg-zinc-800 text-amber-300 px-2.5 py-1 rounded-lg border border-[#D4AF37]/30 font-medium transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'English' : 'عربي (RTL)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
