import React from 'react';
import { Delete, Space } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface InAppKeyboardProps {
  onKeyPress: (char: string) => void;
  onDelete: () => void;
  onSpace?: () => void;
}

// Exactly matching the provided layout image:
// Row 1 (Left to Right): ض ص ق ف غ ع ه خ ح ج
const ROW_1 = ['ض', 'ص', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج'];

// Row 2 (Left to Right): ش س ي ب ل ا ت ن م ك
const ROW_2 = ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك'];

// Row 3 (Left to Right): ظ ط ذ د ز ر و ة ث + Backspace
const ROW_3 = ['ظ', 'ط', 'ذ', 'د', 'ز', 'ر', 'و', 'ة', 'ث'];

// Auxiliary characters for full Arabic support (همزة، ياء مقصورة، واو مهموزة، نبرة)
const AUX_CHARS = ['ء', 'ى', 'ئ', 'ؤ'];

export const InAppKeyboard: React.FC<InAppKeyboardProps> = ({
  onKeyPress,
  onDelete,
  onSpace,
}) => {
  return (
    <div className="w-full bg-[#ede9e1] border-t-2 border-[#2c2c2c] p-1.5 sm:p-2.5 shadow-inner select-none flex flex-col gap-1.5 sm:gap-2">
      {/* Row 1 */}
      <div
        className="flex justify-center gap-1 sm:gap-1.5 w-full max-w-2xl mx-auto"
        style={{ direction: 'ltr' }}
      >
        {ROW_1.map((char) => (
          <button
            key={char}
            type="button"
            onClick={() => {
              soundManager.playKeyClick();
              onKeyPress(char);
            }}
            className="flex-1 min-w-0 h-10 sm:h-12 bg-[#fdfbf7] hover:bg-[#1a1a1a] hover:text-[#fdfbf7] active:bg-[#e6d5b8] active:text-[#1a1a1a] text-[#1a1a1a] text-base sm:text-xl font-bold rounded-xs border border-[#2c2c2c] shadow-2xs flex items-center justify-center transition-colors touch-manipulation font-arabic"
          >
            {char}
          </button>
        ))}
      </div>

      {/* Row 2 */}
      <div
        className="flex justify-center gap-1 sm:gap-1.5 w-full max-w-2xl mx-auto"
        style={{ direction: 'ltr' }}
      >
        {ROW_2.map((char) => (
          <button
            key={char}
            type="button"
            onClick={() => {
              soundManager.playKeyClick();
              onKeyPress(char);
            }}
            className="flex-1 min-w-0 h-10 sm:h-12 bg-[#fdfbf7] hover:bg-[#1a1a1a] hover:text-[#fdfbf7] active:bg-[#e6d5b8] active:text-[#1a1a1a] text-[#1a1a1a] text-base sm:text-xl font-bold rounded-xs border border-[#2c2c2c] shadow-2xs flex items-center justify-center transition-colors touch-manipulation font-arabic"
          >
            {char}
          </button>
        ))}
      </div>

      {/* Row 3: Letters + Delete Button (matching image layout) */}
      <div
        className="flex justify-center gap-1 sm:gap-1.5 w-full max-w-2xl mx-auto"
        style={{ direction: 'ltr' }}
      >
        {ROW_3.map((char) => (
          <button
            key={char}
            type="button"
            onClick={() => {
              soundManager.playKeyClick();
              onKeyPress(char);
            }}
            className="flex-1 min-w-0 h-10 sm:h-12 bg-[#fdfbf7] hover:bg-[#1a1a1a] hover:text-[#fdfbf7] active:bg-[#e6d5b8] active:text-[#1a1a1a] text-[#1a1a1a] text-base sm:text-xl font-bold rounded-xs border border-[#2c2c2c] shadow-2xs flex items-center justify-center transition-colors touch-manipulation font-arabic"
          >
            {char}
          </button>
        ))}

        {/* Backspace / Delete key at the end of Row 3 */}
        <button
          type="button"
          onClick={() => {
            soundManager.playDeleteClick();
            onDelete();
          }}
          aria-label="مسح الحرف"
          className="flex-1 min-w-0 h-10 sm:h-12 bg-[#d8d3c5] hover:bg-[#2c2c2c] hover:text-[#fdfbf7] active:bg-[#1a1a1a] active:text-[#fdfbf7] text-[#1a1a1a] rounded-xs border border-[#2c2c2c] shadow-2xs flex items-center justify-center transition-colors touch-manipulation"
          title="حذف"
        >
          <Delete className="w-5 h-5" />
        </button>
      </div>

      {/* Auxiliary Row: Space/Skip on the Left, Special Characters on the Right */}
      <div
        className="flex justify-between items-center gap-1 sm:gap-1.5 w-full max-w-2xl mx-auto px-0.5"
        style={{ direction: 'ltr' }}
      >
        {/* Space / Next button on Left */}
        {onSpace && (
          <button
            type="button"
            onClick={() => {
              soundManager.playSpaceClick();
              onSpace();
            }}
            aria-label="مسافة"
            title="مسافة"
            className="flex-1 h-8 sm:h-9 bg-[#fdfbf7] hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] text-[#1a1a1a] rounded-xs border border-[#2c2c2c] shadow-2xs flex items-center justify-center touch-manipulation transition-colors mr-2"
          >
            <Space className="w-5 h-5 text-[#2c2c2c]" />
          </button>
        )}

        {/* Special letters on Right: ء, ى, ئ, ؤ */}
        <div className="flex gap-1 sm:gap-1.5">
          {AUX_CHARS.map((char) => (
            <button
              key={char}
              type="button"
              onClick={() => {
                soundManager.playKeyClick();
                onKeyPress(char);
              }}
              className="w-8 sm:w-10 h-8 sm:h-9 bg-[#f4efe6] hover:bg-[#1a1a1a] hover:text-[#fdfbf7] active:bg-[#e6d5b8] text-[#2c2c2c] text-sm sm:text-base font-bold rounded-xs border border-[#8a8578] shadow-2xs flex items-center justify-center transition-colors touch-manipulation font-arabic"
            >
              {char}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

