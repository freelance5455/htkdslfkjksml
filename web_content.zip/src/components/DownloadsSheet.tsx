import React from 'react';
import { Download, X, CheckCircle2, ShieldCheck, FileText, Trash2 } from 'lucide-react';
import { DownloadFile } from '../types/browser';

interface DownloadsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  downloads: DownloadFile[];
  onDeleteDownload: (id: string) => void;
}

export const DownloadsSheet: React.FC<DownloadsSheetProps> = ({
  isOpen,
  onClose,
  downloads,
  onDeleteDownload,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm select-none animate-fade-in">
      <div className="flex-1" onClick={onClose} />

      <div className="w-full max-w-lg mx-auto bg-slate-900 border-t border-slate-700/80 rounded-t-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] animate-slide-up">
        <div className="pt-3 pb-1 flex justify-center cursor-grab" onClick={onClose}>
          <div className="w-12 h-1.5 rounded-full bg-slate-700" />
        </div>

        <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/80 text-cyan-400 border border-cyan-800/60">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Sandboxed Downloads</h3>
              <p className="text-xs text-slate-400">Integrated Hash & Malware Verification</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-2.5 no-scrollbar">
          {downloads.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs">
              No files downloaded during this session.
            </div>
          ) : (
            downloads.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2.5 rounded-xl bg-slate-800 text-slate-300">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-200 truncate">{item.name}</p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                      <span>{item.size}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                        <ShieldCheck className="w-3 h-3" />
                        Verified Clean
                      </span>
                    </div>
                    <p className="text-[9px] text-slate-500 font-mono mt-0.5 truncate">{item.hash}</p>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteDownload(item.id)}
                  className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg hover:bg-slate-800 shrink-0 ml-2"
                  title="Remove"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
