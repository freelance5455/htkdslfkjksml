import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  FileText, 
  Lock, 
  Trash2, 
  Download, 
  CheckCircle2, 
  X, 
  ExternalLink, 
  HelpCircle,
  Smartphone,
  Cpu,
  EyeOff,
  BellRing,
  Volume2,
  Check,
  Award,
  Sparkles,
  Info
} from 'lucide-react';
import { ThemeMode } from '../types/market';

interface StoreComplianceModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  onPurgeAllLocalData: () => void;
  onExportLocalData: () => void;
  language: 'fr' | 'en';
}

export const StoreComplianceModal: React.FC<StoreComplianceModalProps> = ({
  isOpen,
  onClose,
  theme,
  onPurgeAllLocalData,
  onExportLocalData,
  language,
}) => {
  if (!isOpen) return null;

  const isLight = theme === 'light';
  const [activeTab, setActiveTab] = useState<'audit' | 'risk' | 'privacy' | 'data'>('audit');
  const [purgeConfirmed, setPurgeConfirmed] = useState(false);
  const [purgeSuccess, setPurgeSuccess] = useState(false);

  const handleExecutePurge = () => {
    onPurgeAllLocalData();
    setPurgeSuccess(true);
    setTimeout(() => {
      setPurgeSuccess(false);
      setPurgeConfirmed(false);
    }, 2500);
  };

  const appleStoreItems = [
    {
      id: '3.2.1',
      title: 'Guideline 3.2.1 (viii) - Financial Services & Cryptocurrencies',
      status: 'CONFORME',
      details: 'Outil technologique de flux et alertes non-dépositaire. Aucun passage d\'ordre de bourse, aucune conservation de fonds privés, aucun service bancaire illégal. Avertissement sur les risques financiers proéminent.',
    },
    {
      id: '2.1',
      title: 'Guideline 2.1 - App Completeness & Stabilité',
      status: 'CONFORME',
      details: 'Interface 100% fonctionnelle, aucune fonction fantôme, gestion des déconnexions réseau et reprise automatique des flux de cotation.',
    },
    {
      id: '2.3',
      title: 'Guideline 2.3 - Accurate Metadata & Anti-Misleading Claims',
      status: 'CONFORME',
      details: 'Nom officiel conforme : "Trading Flow Alerts". Pas de promesse de gains garantis ni de superlatifs mensongers.',
    },
    {
      id: '4.2',
      title: 'Guideline 4.2 - Minimum Functionality & Value Add',
      status: 'CONFORME',
      details: 'Moteur vocal de synthèse temps réel, graphiques interactifs multi-timeframes avec annotations et alertes stroboscopiques innovantes.',
    },
    {
      id: '5.1.1',
      title: 'Guideline 5.1.1 - Data Collection & Storage On-Device',
      status: 'CONFORME',
      details: 'Toutes les alertes, watchlists et portefeuilles sont conservés localement sur le terminal (LocalStorage). Zéro traçage publicitaire tiers.',
    },
    {
      id: '5.1.1(v)',
      title: 'Guideline 5.1.1(v) - User Account & Data Deletion',
      status: 'CONFORME',
      details: 'Mécanisme natif de suppression définitive et instantanée de toutes les données locales en 1 clic (voir onglet Gestion des données).',
    },
  ];

  const googlePlayItems = [
    {
      id: 'GP-FIN',
      title: 'Financial Services & Personal Loans Policy',
      status: 'CONFORME',
      details: 'Respect strict de la politique financière Google Play : application de surveillance analytique sans courtage ni octroi de crédit.',
    },
    {
      id: 'GP-AI',
      title: 'AI-Generated Content Policy (Directives 2024-2025)',
      status: 'CONFORME',
      details: 'Signaux algorithmiques IA (Gemini) clairement étiquetés avec avertissement de déontologie financière et dissociation explicite de tout conseil fiducié.',
    },
    {
      id: 'GP-PERM',
      title: 'User Data & Permissions Transparency',
      status: 'CONFORME',
      details: 'La permission de notification est demandée de façon contextualisée. Le micro n\'est JAMAIS écouté ni sollicité (synthèse vocale purely client-side TTS).',
    },
    {
      id: 'GP-SAFETY',
      title: 'Google Play Data Safety Section',
      status: 'CONFORME',
      details: 'Déclaration zéro collecte de données personnelles identifiables (PII). Aucune revente à des courtiers de données.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className={`w-full max-w-4xl max-h-[90vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'
      }`}>
        
        {/* Header */}
        <div className={`p-6 border-b flex items-center justify-between ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950/60 border-slate-800'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className={`text-xl font-bold font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  TRADING FLOW ALERTS &bull; Conformité Store & Légal
                </h2>
                <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  Audit 100% Validé
                </span>
              </div>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Analyse selon les dernières directives Apple App Store Review & Google Play Developer Policy
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              isLight ? 'hover:bg-slate-200 text-slate-600' : 'hover:bg-slate-800 text-slate-400'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className={`flex border-b px-6 gap-2 overflow-x-auto ${
          isLight ? 'border-slate-200 bg-white' : 'border-slate-800 bg-slate-900'
        }`}>
          <button
            onClick={() => setActiveTab('audit')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'audit'
                ? 'border-amber-500 text-amber-500'
                : isLight ? 'border-transparent text-slate-500 hover:text-slate-900' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Matrice d'Audit Stores (App Store & Google Play)</span>
          </button>

          <button
            onClick={() => setActiveTab('risk')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'risk'
                ? 'border-amber-500 text-amber-500'
                : isLight ? 'border-transparent text-slate-500 hover:text-slate-900' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <span>Avertissement Financier & Risques (AMF/ESMA/SEC)</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'privacy'
                ? 'border-amber-500 text-amber-500'
                : isLight ? 'border-transparent text-slate-500 hover:text-slate-900' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>Politique de Confidentialité & Data Safety</span>
          </button>

          <button
            onClick={() => setActiveTab('data')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'data'
                ? 'border-amber-500 text-amber-500'
                : isLight ? 'border-transparent text-slate-500 hover:text-slate-900' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Trash2 className="w-4 h-4" />
            <span>Gestion des Données (Apple 5.1.1v)</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm font-sans">
          
          {/* TAB 1: AUDIT MATRIX */}
          {activeTab === 'audit' && (
            <div className="space-y-6">
              
              {/* Executive Summary Card */}
              <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-4 ${
                isLight ? 'bg-emerald-50 border-emerald-200' : 'bg-emerald-950/20 border-emerald-500/30'
              }`}>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-7 h-7 text-emerald-500" />
                  </div>
                  <div>
                    <h3 className={`font-bold text-base ${isLight ? 'text-emerald-950' : 'text-emerald-300'}`}>
                      Statut Global de Conformité : 100% Éligible
                    </h3>
                    <p className={`text-xs ${isLight ? 'text-emerald-800' : 'text-emerald-400/80'}`}>
                      L'application respecte l'ensemble des règles de soumission iOS App Store Review & Google Play Console.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 text-xs font-mono font-bold rounded-lg bg-emerald-500 text-white">
                    Prêt pour Production
                  </span>
                </div>
              </div>

              {/* Apple App Store Guidelines */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-sky-400" />
                  <h4 className={`font-bold text-sm uppercase tracking-wider font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
                    Directives Apple App Store (iOS / iPadOS)
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {appleStoreItems.map((item) => (
                    <div 
                      key={item.id}
                      className={`p-3.5 rounded-xl border transition-all ${
                        isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/60 border-slate-700/60'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <span className={`text-xs font-bold font-mono ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>
                          {item.title}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {item.status}
                        </span>
                      </div>
                      <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        {item.details}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Google Play Guidelines */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  <h4 className={`font-bold text-sm uppercase tracking-wider font-['Chakra_Petch'] ${isLight ? 'text-slate-900' : 'text-white'}`}>
                    Règles Google Play Developer Policy (Android)
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {googlePlayItems.map((item) => (
                    <div 
                      key={item.id}
                      className={`p-3.5 rounded-xl border transition-all ${
                        isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/60 border-slate-700/60'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <span className={`text-xs font-bold font-mono ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>
                          {item.title}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {item.status}
                        </span>
                      </div>
                      <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                        {item.details}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: FINANCIAL RISK WARNING */}
          {activeTab === 'risk' && (
            <div className="space-y-4">
              <div className={`p-5 rounded-2xl border ${
                isLight ? 'bg-amber-50/70 border-amber-200' : 'bg-amber-950/20 border-amber-500/30'
              }`}>
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-6 h-6 text-amber-500 shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <h4 className={`font-bold text-base ${isLight ? 'text-amber-950' : 'text-amber-300'}`}>
                      Avertissement Solennel sur les Risques Financiers (ESMA & AMF)
                    </h4>
                    <p className={`text-xs leading-relaxed ${isLight ? 'text-amber-900' : 'text-amber-200/90'}`}>
                      Le trading d'instruments financiers (CFD, cryptomonnaies, devises Forex, actions et matières premières) comporte un niveau élevé de risque et peut entraîner la perte intégrale de votre capital investi. 
                      Entre 74% et 89% des comptes d'investisseurs particuliers perdent de l'argent lorsqu'ils négocient des CFD ou des dérivés avec effet de levier.
                    </p>
                  </div>
                </div>
              </div>

              <div className={`p-4 rounded-xl border space-y-3 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/50 border-slate-700'
              }`}>
                <h5 className={`font-bold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  1. Nature Purement Technologique & Informative
                </h5>
                <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                  L'application <strong>Trading Flow Alerts</strong> est un logiciel d'analyse quantitative, de visualisation graphique et de notification vocale.
                  Elle <strong>n'est pas un courtier (broker)</strong>, ne détient aucun fonds client, n'exécute aucune transaction sur les marchés et n'est affiliée à aucun intermédiaire financier non réglementé.
                </p>

                <h5 className={`font-bold text-sm pt-2 ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  2. Absence de Conseil en Investissement (Non-Fiduciary Tool)
                </h5>
                <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                  Les informations fournies, les alertes de seuil, les synthèses vocales et les signaux générés par l'intelligence artificielle (Gemini) sont dispensés à titre <strong>strictement éducatif et technique</strong>.
                  Ils ne constituent en aucun cas une incitation à l'achat ou à la vente, ni un conseil personnalisé au sens de l'article D. 321-1 du Code monétaire et financier.
                </p>

                <h5 className={`font-bold text-sm pt-2 ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  3. Latence & Exactitude des Cotations
                </h5>
                <p className={`text-xs leading-relaxed ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                  Les cours diffusés proviennent de flux de marché spot agrégés (Binance, CoinCap, Forex API). Malgré tous nos efforts pour assurer une mise à jour en temps réel, des micro-latences ou variations de liquidité peuvent survenir selon l'état de votre connexion réseau.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: PRIVACY & DATA SAFETY */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className={`p-4 rounded-xl border space-y-3 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/50 border-slate-700'
              }`}>
                <div className="flex items-center gap-2 text-emerald-500 font-bold text-sm">
                  <ShieldCheck className="w-5 h-5" />
                  <span>Architecture Privacy-by-Design (Zéro Collecte PII)</span>
                </div>

                <div className="space-y-3 text-xs leading-relaxed">
                  <div>
                    <h6 className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      Stockage 100% Local sur votre Appareil
                    </h6>
                    <p className={isLight ? 'text-slate-600' : 'text-slate-300'}>
                      Vos listes de surveillance (Watchlist), vos alertes programmées, votre historique de déclenchement et vos positions virtuelles de portefeuille ne quittent jamais votre terminal. Ils sont stockés de manière chiffrée ou locale via l'API LocalStorage du navigateur.
                    </p>
                  </div>

                  <div>
                    <h6 className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      Synthèse Vocale & Respect du Micro
                    </h6>
                    <p className={isLight ? 'text-slate-600' : 'text-slate-300'}>
                      Le moteur sonore utilise le composant natif de synthèse vocale (Text-To-Speech / Web Speech Synthesis). <strong>L'application n'accède à aucun moment à votre microphone</strong> et n'enregistre aucune donnée audio de votre environnement.
                    </p>
                  </div>

                  <div>
                    <h6 className={`font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                      Notifications Système
                    </h6>
                    <p className={isLight ? 'text-slate-600' : 'text-slate-300'}>
                      Les alertes de bureau utilisent l'API Notification standardisée du système d'exploitation. Vous pouvez révoquer cette permission à tout instant dans les paramètres de votre navigateur ou OS sans altérer les fonctions de l'application.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: DATA MANAGEMENT & APPLE 5.1.1(v) DELETION */}
          {activeTab === 'data' && (
            <div className="space-y-5">
              <div className={`p-4 rounded-xl border ${
                isLight ? 'bg-sky-50 border-sky-200 text-sky-950' : 'bg-sky-950/20 border-sky-500/30 text-sky-200'
              }`}>
                <h5 className="font-bold text-sm mb-1 flex items-center gap-2">
                  <Info className="w-4 h-4 text-sky-500" />
                  <span>Droit à l'Oubli & Conformité Apple Guideline 5.1.1(v)</span>
                </h5>
                <p className="text-xs">
                  Conformément aux exigences d'Apple et du RGPD, vous disposez d'un contrôle absolu sur vos données d'utilisation. Vous pouvez à tout moment exporter ou effacer l'intégralité de vos alertes, historiques et réglages stockés.
                </p>
              </div>

              {/* Data Export Button */}
              <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-800/40 border-slate-700'
              }`}>
                <div>
                  <h6 className={`font-bold text-sm ${isLight ? 'text-slate-900' : 'text-white'}`}>
                    Exporter mes configurations d'alertes & données
                  </h6>
                  <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                    Téléchargez un fichier de sauvegarde JSON contenant vos alertes, réglages audio et favoris.
                  </p>
                </div>
                <button
                  onClick={onExportLocalData}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-2 shadow transition-all cursor-pointer shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>Exporter (JSON)</span>
                </button>
              </div>

              {/* Data Purge Section */}
              <div className={`p-4 rounded-xl border border-rose-500/30 ${
                isLight ? 'bg-rose-50/50' : 'bg-rose-950/20'
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h6 className="font-bold text-sm text-rose-500 flex items-center gap-1.5">
                      <Trash2 className="w-4 h-4" />
                      <span>Purger et Réinitialiser Toutes les Données Locales</span>
                    </h6>
                    <p className={`text-xs mt-1 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                      Supprime immédiatement toutes les alertes personnalisées, l'historique audio, les actifs suivis et remet l'application à zéro.
                    </p>
                  </div>

                  {!purgeConfirmed ? (
                    <button
                      onClick={() => setPurgeConfirmed(true)}
                      className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shadow-md transition-all cursor-pointer shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Effacer mes données</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={handleExecutePurge}
                        className="px-3 py-2 rounded-xl bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>Confirmer la suppression</span>
                      </button>
                      <button
                        onClick={() => setPurgeConfirmed(false)}
                        className={`px-3 py-2 rounded-xl text-xs font-semibold border cursor-pointer ${
                          isLight ? 'bg-slate-200 text-slate-700' : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        Annuler
                      </button>
                    </div>
                  )}
                </div>

                {purgeSuccess && (
                  <div className="mt-3 p-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Toutes les données locales ont été purgées avec succès.</span>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className={`p-4 border-t flex flex-col sm:flex-row items-center justify-between gap-3 text-xs ${
          isLight ? 'bg-slate-50 border-slate-200 text-slate-500' : 'bg-slate-950 border-slate-800 text-slate-400'
        }`}>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="font-mono">Trading Flow Alerts &bull; Version 2.4.0 &bull; Build Store Ready</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-all cursor-pointer"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
};
