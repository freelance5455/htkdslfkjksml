import React, { useState, useEffect } from 'react';
import {
  Search,
  Bookmark,
  ArrowRight,
  Globe,
  Utensils,
  Share2,
  Check,
  Apple
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from './TopAppBar';
import { NUTRITION_DATA } from '../data/nutritionData';
import { NutritionItem, NutritionLanguage, NutritionCategory } from '../types/nutrition';
import { NutritionDetailView } from './NutritionDetailView';

interface NutritionDietViewProps {
  onBack: () => void;
}

export const NutritionDietView: React.FC<NutritionDietViewProps> = ({ onBack }) => {
  const [selectedLanguage, setSelectedLanguage] = useState<NutritionLanguage>('English');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedItem, setSelectedItem] = useState<NutritionItem | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);

  // Load bookmarks
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mediguide_bookmarked_nutrition');
      if (saved) {
        setBookmarkedIds(JSON.parse(saved));
      }
    } catch (err) {
      console.warn('Failed to load bookmarked nutrition plans:', err);
    }
  }, []);

  // Toggle bookmark
  const toggleBookmark = (itemId: string) => {
    setBookmarkedIds((prev) => {
      let updated: string[];
      if (prev.includes(itemId)) {
        updated = prev.filter((id) => id !== itemId);
      } else {
        updated = [...prev, itemId];
      }
      try {
        localStorage.setItem('mediguide_bookmarked_nutrition', JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save bookmarked nutrition:', err);
      }
      return updated;
    });
  };

  // Quick share card
  const handleQuickShare = async (e: React.MouseEvent, item: NutritionItem) => {
    e.stopPropagation();
    const content = item.content[selectedLanguage] || item.content.English;
    const text = `🥗 ${content.title}\n\n${content.summary}\n\nLearn more on Mediguide AI.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: content.title,
          text,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShareId(item.id);
      setTimeout(() => setCopiedShareId(null), 2000);
    } catch (err) {
      console.warn('Failed to copy:', err);
    }
  };

  // 15 Requested Categories with Trilingual Names
  const categoryCards: { id: NutritionCategory; emoji: string; nameEn: string; nameHi: string; nameMr: string }[] = [
    { id: 'Disease-wise Diet', emoji: '🥗', nameEn: 'Disease-wise Diet', nameHi: 'बीमारी अनुसार आहार', nameMr: 'आजारानुसार आहार' },
    { id: 'Healthy Eating', emoji: '🍎', nameEn: 'Healthy Eating', nameHi: 'स्वस्थ खानपान', nameMr: 'निरोगी आहार' },
    { id: 'Weight Management', emoji: '⚖️', nameEn: 'Weight Management', nameHi: 'वजन प्रबंधन', nameMr: 'वजन व्यवस्थापन' },
    { id: 'High Protein Diet', emoji: '💪', nameEn: 'High Protein Diet', nameHi: 'हाई प्रोटीन आहार', nameMr: 'हाय प्रोटीन आहार' },
    { id: 'Heart Healthy Diet', emoji: '❤️', nameEn: 'Heart Healthy Diet', nameHi: 'हृदय के लिए आहार', nameMr: 'हृदयासाठी आहार' },
    { id: 'Diabetes Diet', emoji: '🩸', nameEn: 'Diabetes Diet', nameHi: 'डायबिटीज आहार', nameMr: 'मधुमेह आहार' },
    { id: 'High Blood Pressure Diet', emoji: '🧂', nameEn: 'High Blood Pressure Diet', nameHi: 'हाई बीपी आहार', nameMr: 'रक्तदाब आहार' },
    { id: 'Kidney Friendly Diet', emoji: '🫘', nameEn: 'Kidney Friendly Diet', nameHi: 'किडनी आहार', nameMr: 'किडनीसाठी आहार' },
    { id: 'Liver Friendly Diet', emoji: '🫁', nameEn: 'Liver Friendly Diet', nameHi: 'लिवर आहार', nameMr: 'यकृतासाठी आहार' },
    { id: 'Low Cholesterol Diet', emoji: '🩺', nameEn: 'Low Cholesterol Diet', nameHi: 'कोलेस्ट्रॉल घटाने का आहार', nameMr: 'कोलेस्ट्रॉल आहार' },
    { id: 'Pregnancy Nutrition', emoji: '🤰', nameEn: 'Pregnancy Nutrition', nameHi: 'गर्भावस्था पोषण', nameMr: 'गर्भावस्था पोषण' },
    { id: 'Child Nutrition', emoji: '👶', nameEn: 'Child Nutrition', nameHi: 'बाल पोषण', nameMr: 'बाल पोषण' },
    { id: 'Senior Citizen Nutrition', emoji: '👴', nameEn: 'Senior Citizen Nutrition', nameHi: 'वरिष्ठ नागरिक पोषण', nameMr: 'ज्येष्ठ नागरिक पोषण' },
    { id: 'Vitamins & Minerals', emoji: '🥦', nameEn: 'Vitamins & Minerals', nameHi: 'विटामिन और मिनरल्स', nameMr: 'व्हिटॅमिन्स व मिनरल्स' },
    { id: 'Hydration Guide', emoji: '💧', nameEn: 'Hydration Guide', nameHi: 'हाइड्रेशन गाइड', nameMr: 'हायड्रेशन मार्गदर्शक' }
  ];

  // Filter nutrition plans based on search query & category
  const filteredItems = NUTRITION_DATA.filter((item) => {
    const content = item.content[selectedLanguage] || item.content.English;
    const query = searchQuery.toLowerCase().trim();

    // Search matches
    const matchesSearch =
      !query ||
      content.title.toLowerCase().includes(query) ||
      content.summary.toLowerCase().includes(query) ||
      content.categoryName.toLowerCase().includes(query) ||
      item.category.toLowerCase().includes(query) ||
      (content.diseaseDiet && content.diseaseDiet.diseaseName.toLowerCase().includes(query)) ||
      (content.diseaseDiet && content.diseaseDiet.foodsToEat.some(f => f.toLowerCase().includes(query))) ||
      (content.vitaminMineral && content.vitaminMineral.name.toLowerCase().includes(query));

    // Category filter
    let matchesCategory = true;
    if (selectedCategory === 'Bookmarked') {
      matchesCategory = bookmarkedIds.includes(item.id);
    } else if (selectedCategory !== 'All') {
      matchesCategory = item.category === selectedCategory;
    }

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Nutrition & Diet"
        subtitle="Nutrition & Diet Hub"
        onBack={onBack}
        badge="Verified Medical Nutrition"
        badgeColor="bg-emerald-100 text-emerald-800 border-emerald-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Banner Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-green-700 text-white p-5 rounded-3xl shadow-lg relative overflow-hidden space-y-3">
          <div className="flex items-start justify-between gap-3 relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-md border border-white/20 text-white shadow-inner">
                <Utensils className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight">Nutrition & Diet Hub</h1>
                <p className="text-xs text-emerald-100 mt-0.5 font-medium">
                  Verified diet guidelines, disease management meal plans & hydration advice.
                </p>
              </div>
            </div>
          </div>

          {/* Language Switcher Bar */}
          <div className="pt-3 border-t border-white/20 flex flex-wrap items-center justify-between gap-2 text-xs relative z-10">
            <div className="flex items-center gap-1.5 font-bold text-emerald-100">
              <Globe className="w-4 h-4 text-emerald-200" />
              <span>Language: English (हिन्दी / मराठी)</span>
            </div>

            <div className="flex bg-black/25 p-1 rounded-2xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as NutritionLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    selectedLanguage === lang
                      ? 'bg-white text-emerald-900 shadow-md'
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Disease or Diet..."
            className="w-full pl-11 pr-10 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs text-slate-900"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 text-xs font-bold bg-slate-100 rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category Cards Section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-500">
              {selectedLanguage === 'Hindi'
                ? 'पोषण श्रेणियां (Nutrition Categories)'
                : selectedLanguage === 'Marathi'
                ? 'पोषण वर्गवारी (Categories)'
                : 'Nutrition Categories'}
            </h2>
            {selectedCategory !== 'All' && (
              <button
                onClick={() => setSelectedCategory('All')}
                className="text-xs text-emerald-600 font-bold hover:underline cursor-pointer"
              >
                Clear Filter ({selectedCategory})
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {categoryCards.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const title =
                selectedLanguage === 'Hindi'
                  ? cat.nameHi
                  : selectedLanguage === 'Marathi'
                  ? cat.nameMr
                  : cat.nameEn;

              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? 'All' : cat.id)}
                  className={`p-3 rounded-2xl border transition-all text-left flex items-center gap-2.5 cursor-pointer shadow-2xs hover:shadow-md ${
                    isSelected
                      ? 'bg-emerald-950 text-white border-emerald-950 ring-2 ring-emerald-950/20'
                      : 'bg-white text-slate-800 border-slate-200/90 hover:border-emerald-300 hover:bg-emerald-50/40'
                  }`}
                >
                  <span className="text-xl shrink-0">{cat.emoji}</span>
                  <div className="overflow-hidden">
                    <p className="text-xs font-extrabold truncate leading-tight">{title}</p>
                    <p className={`text-[10px] truncate ${isSelected ? 'text-emerald-200' : 'text-slate-400'}`}>
                      {cat.nameEn}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Results counter & Bookmarked filter */}
        <div className="flex items-center justify-between text-xs font-bold text-slate-500 px-1 pt-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedCategory(selectedCategory === 'Bookmarked' ? 'All' : 'Bookmarked')}
              className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'Bookmarked'
                  ? 'bg-amber-400 text-slate-950 shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Bookmark className={`w-3.5 h-3.5 ${bookmarkedIds.length > 0 ? 'fill-amber-500 text-amber-600' : ''}`} />
              <span>Saved ({bookmarkedIds.length})</span>
            </button>
            <span>
              {selectedLanguage === 'Hindi'
                ? `कुल ${filteredItems.length} पोषण योजनाएं उपलब्ध हैं`
                : selectedLanguage === 'Marathi'
                ? `एकूण ${filteredItems.length} आहार योजना उपलब्ध आहेत`
                : `Showing ${filteredItems.length} verified nutrition guides`}
            </span>
          </div>

          <span className="text-[11px] text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 font-semibold">
            {selectedLanguage === 'English' ? 'English' : selectedLanguage === 'Hindi' ? 'हिन्दी' : 'मराठी'}
          </span>
        </div>

        {/* Nutrition Cards Grid */}
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200/80 space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <Apple className="w-6 h-6 text-emerald-600" />
            </div>
            <h3 className="font-extrabold text-slate-800 text-sm">
              {selectedLanguage === 'Hindi'
                ? 'कोई पोषण योजना नहीं मिली'
                : selectedLanguage === 'Marathi'
                ? 'कोणतीही आहार योजना आढळली नाही'
                : 'No Nutrition Guides Found'}
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              {selectedCategory === 'Bookmarked'
                ? 'You have not saved any diet plans yet. Click the bookmark icon on any nutrition card to save it.'
                : 'Try searching by condition (e.g. Diabetes, Anemia, Dengue, High BP) or nutrition topic.'}
            </p>
            {(searchQuery || selectedCategory !== 'All') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700 transition-colors cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredItems.map((item) => {
              const content = item.content[selectedLanguage] || item.content.English;
              const isBookmarked = bookmarkedIds.includes(item.id);

              return (
                <motion.div
                  key={item.id}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => setSelectedItem(item)}
                  className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between space-y-3 cursor-pointer group"
                >
                  <div className="space-y-2">
                    {/* Badge & Buttons */}
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-extrabold ${item.badgeBg} ${item.badgeText} px-2.5 py-0.5 rounded-lg border`}>
                        {item.category}
                      </span>

                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => toggleBookmark(item.id)}
                          className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                            isBookmarked
                              ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                              : 'bg-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-200'
                          }`}
                          title="Bookmark Plan"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-600' : ''}`} />
                        </button>

                        <button
                          onClick={(e) => handleQuickShare(e, item)}
                          className="p-1.5 bg-slate-100 text-slate-500 rounded-xl hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
                          title="Share Plan"
                        >
                          {copiedShareId === item.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Share2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex items-start gap-3 pt-1">
                      <div className={`p-3 bg-gradient-to-br ${item.bgGradient} rounded-2xl shrink-0 text-2xl shadow-xs group-hover:scale-105 transition-transform`}>
                        {item.categoryEmoji}
                      </div>

                      <div className="space-y-1 overflow-hidden">
                        <h3 className="font-extrabold text-sm text-slate-900 leading-snug group-hover:text-emerald-700 transition-colors">
                          {content.title}
                        </h3>
                        <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                          {content.summary}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Bar */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-emerald-700">
                    <span className="text-[10px] text-slate-400 font-medium">Educational Nutrition Guide</span>
                    <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      {selectedLanguage === 'Hindi'
                        ? 'आहार योजना देखें'
                        : selectedLanguage === 'Marathi'
                        ? 'आहार योजना पाहा'
                        : 'View Full Diet Plan'}
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedItem && (
          <NutritionDetailView
            item={selectedItem}
            currentLanguage={selectedLanguage}
            onLanguageChange={(lang) => setSelectedLanguage(lang)}
            isBookmarked={bookmarkedIds.includes(selectedItem.id)}
            onToggleBookmark={toggleBookmark}
            onClose={() => setSelectedItem(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};
