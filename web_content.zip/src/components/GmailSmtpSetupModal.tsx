import React, { useState, useEffect } from 'react';
import { 
  Mail, 
  Key, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  ExternalLink, 
  X, 
  Send,
  Sparkles
} from 'lucide-react';

interface GmailSmtpSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultEmail?: string;
  onConfigSuccess?: (userEmail: string) => void;
}

export const GmailSmtpSetupModal: React.FC<GmailSmtpSetupModalProps> = ({
  isOpen,
  onClose,
  defaultEmail = 'brahmprakashsingh8@gmail.com',
  onConfigSuccess
}) => {
  const [gmailUser, setGmailUser] = useState(defaultEmail);
  const [appPassword, setAppPassword] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isConfigured, setIsConfigured] = useState(false);

  useEffect(() => {
    // Check current status
    fetch('/api/smtp-status')
      .then(res => res.json())
      .then(data => {
        if (data.configured) {
          setIsConfigured(true);
          if (data.user) setGmailUser(data.user);
        }
      })
      .catch(() => {});
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveAndTest = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    const cleanUser = gmailUser.trim();
    const cleanPass = appPassword.trim().replace(/\s/g, '');

    if (!cleanUser || !cleanPass) {
      setStatusMessage({ type: 'error', text: 'Please enter your Gmail and 16-character App Password.' });
      return;
    }

    setIsTesting(true);
    try {
      const res = await fetch('/api/save-smtp-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user: cleanUser,
          pass: cleanPass,
          host: 'smtp.gmail.com',
          port: 465,
          secure: true
        })
      });

      const data = await res.json();
      if (data.success) {
        setIsConfigured(true);
        setStatusMessage({ type: 'success', text: data.message });
        if (onConfigSuccess) onConfigSuccess(cleanUser);
      } else {
        setStatusMessage({ type: 'error', text: data.message });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: 'Could not connect to server gateway. Please try again.' });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0c0f1d] border border-cyan-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-100 space-y-4">
        
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <span className="p-2.5 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              <Mail className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <span>Live Gmail OTP Dispatch</span>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-mono">
                  SMTP
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Deliver verification codes directly to Gmail inboxes
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Status Banner */}
        {isConfigured && (
          <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Gmail SMTP is connected! Live emails will be delivered to recipients.</span>
          </div>
        )}

        {statusMessage && (
          <div className={`p-3 rounded-2xl text-xs flex items-start gap-2 ${
            statusMessage.type === 'success' 
              ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' 
              : 'bg-rose-500/10 border border-rose-500/30 text-rose-300'
          }`}>
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSaveAndTest} className="space-y-3">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Sender Gmail Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                required
                value={gmailUser}
                onChange={e => setGmailUser(e.target.value)}
                placeholder="yourname@gmail.com"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-400 text-xs text-white outline-none"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-300">
                Google 16-Character App Password
              </label>
              <a
                href="https://myaccount.google.com/apppasswords"
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-cyan-400 hover:underline flex items-center gap-0.5 font-medium"
              >
                <span>Get App Password</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div className="relative">
              <Key className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="password"
                required
                value={appPassword}
                onChange={e => setAppPassword(e.target.value)}
                placeholder="xxxx xxxx xxxx xxxx"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-400 text-xs text-cyan-300 font-mono outline-none"
              />
            </div>
          </div>

          {/* Quick Guide */}
          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-300 space-y-1 leading-relaxed">
            <div className="font-bold text-cyan-300 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              <span>How to get 16-char App Password (30 seconds):</span>
            </div>
            <p>1. Open Google Account &rarr; Security &rarr; Enable 2-Step Verification.</p>
            <p>2. Search <strong>"App Passwords"</strong> or visit the link above.</p>
            <p>3. Create name "Secret Gossip" &rarr; Copy the 16-letter code &rarr; Paste here.</p>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isTesting}
              className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Verifying with Google...' : 'Test & Activate Real Gmail OTP'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
