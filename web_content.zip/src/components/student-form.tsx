"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { School, Stream } from "@/lib/bac/types";

export type StudentFormValues = {
  firstName: string;
  lastName: string;
  birthDate: string;
  birthPlace: string;
  gender: "male" | "female";
  schoolId: number;
  streamId: number;
};

export function StudentForm({
  streams,
  schools,
  initial,
  submitLabel,
  pending,
  onSubmit,
}: {
  streams: Stream[];
  schools: School[];
  initial?: Partial<StudentFormValues>;
  submitLabel: string;
  pending?: boolean;
  onSubmit: (values: StudentFormValues) => void;
}) {
  const [values, setValues] = useState<StudentFormValues>({
    firstName: initial?.firstName ?? "",
    lastName: initial?.lastName ?? "",
    birthDate: initial?.birthDate ?? "2007-01-01",
    birthPlace: initial?.birthPlace ?? "",
    gender: initial?.gender ?? "male",
    schoolId: initial?.schoolId ?? schools[0]?.id ?? 0,
    streamId: initial?.streamId ?? streams[0]?.id ?? 0,
  });

  return (
    <form
      className="grid gap-3 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit(values);
      }}
    >
      <div className="space-y-1.5">
        <Label htmlFor="lastName">اللقب</Label>
        <Input
          id="lastName"
          required
          value={values.lastName}
          onChange={(e) => setValues((v) => ({ ...v, lastName: e.target.value }))}
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="firstName">الاسم</Label>
        <Input
          id="firstName"
          required
          value={values.firstName}
          onChange={(e) => setValues((v) => ({ ...v, firstName: e.target.value }))}
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="birthDate">تاريخ الميلاد</Label>
        <Input
          id="birthDate"
          type="date"
          required
          value={values.birthDate}
          onChange={(e) => setValues((v) => ({ ...v, birthDate: e.target.value }))}
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="birthPlace">مكان الميلاد</Label>
        <Input
          id="birthPlace"
          required
          value={values.birthPlace}
          onChange={(e) => setValues((v) => ({ ...v, birthPlace: e.target.value }))}
        />
      </div>
      <div className="space-y-1.5">
        <Label>الجنس</Label>
        <Select
          value={values.gender}
          onValueChange={(gender) =>
            setValues((v) => ({ ...v, gender: gender as "male" | "female" }))
          }
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="male">ذكر</SelectItem>
            <SelectItem value="female">أنثى</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label>الشعبة</Label>
        <Select
          value={String(values.streamId)}
          onValueChange={(id) => setValues((v) => ({ ...v, streamId: Number(id) }))}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {streams.map((s) => (
              <SelectItem key={s.id} value={String(s.id)}>
                {s.nameAr}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label>الثانوية</Label>
        <Select
          value={String(values.schoolId)}
          onValueChange={(id) => setValues((v) => ({ ...v, schoolId: Number(id) }))}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {schools.map((s) => (
              <SelectItem key={s.id} value={String(s.id)}>
                {s.name} — {s.wilaya}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="sm:col-span-2">
        <Button type="submit" className="w-full sm:w-auto" disabled={pending}>
          {pending ? "جاري الحفظ…" : submitLabel}
        </Button>
      </div>
    </form>
  );
}
