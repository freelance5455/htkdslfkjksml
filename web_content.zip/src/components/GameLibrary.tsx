import React, { useState, useEffect } from 'react';
import { Play, Download, Star } from 'lucide-react';

interface Game {
  id: string;
  name: string;
  icon: string;
  rating: number;
  size: string;
  installed: boolean;
}

const SAMPLE_GAMES: Game[] = [
  {
    id: '1',
    name: 'Genshin Impact',
    icon: '🌟',
    rating: 4.8,
    size: '18.5GB',
    installed: true,
  },
  {
    id: '2',
    name: 'Call of Duty Mobile',
    icon: '🎯',
    rating: 4.5,
    size: '32.2GB',
    installed: true,
  },
  {
    id: '3',
    name: 'PUBG Mobile',
    icon: '🔫',
    rating: 4.3,
    size: '35.8GB',
    installed: true,
  },
  {
    id: '4',
    name: 'League of Legends: Wild Rift',
    icon: '⚔️',
    rating: 4.6,
    size: '4.2GB',
    installed: true,
  },
  {
    id: '5',
    name: 'Honkai: Star Rail',
    icon: '✨',
    rating: 4.7,
    size: '14.8GB',
    installed: false,
  },
  {
    id: '6',
    name: 'Zenless Zone Zero',
    icon: '⚡',
    rating: 4.9,
    size: '12.3GB',
    installed: false,
  },
  {
    id: '7',
    name: 'Diablo Immortal',
    icon: '👿',
    rating: 4.1,
    size: '28.5GB',
    installed: false,
  },
  {
    id: '8',
    name: 'Monster Hunter Now',
    icon: '🐉',
    rating: 4.4,
    size: '2.8GB',
    installed: true,
  },
];

export function GameLibrary() {
  const [games, setGames] = useState<Game[]>(SAMPLE_GAMES);
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [filter, setFilter] = useState<'all' | 'installed' | 'available'>('all');

  const filteredGames = games.filter(game => {
    if (filter === 'installed') return game.installed;
    if (filter === 'available') return !game.installed;
    return true;
  });

  const handleLaunchGame = (game: Game) => {
    if (game.installed) {
      setSelectedGame(game);
      // Simulate launch with toast
      console.log(`Launching ${game.name}...`);
    }
  };

  const handleDownloadGame = (game: Game) => {
    setGames(prev =>
      prev.map(g =>
        g.id === game.id ? { ...g, installed: true } : g
      )
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Game Library</h2>
        <div className="text-sm text-gray-400">
          {filteredGames.length} games
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 border-b border-gray-700">
        {[
          { id: 'all', label: 'All Games', count: games.length },
          { id: 'installed', label: 'Installed', count: games.filter(g => g.installed).length },
          { id: 'available', label: 'Available', count: games.filter(g => !g.installed).length },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id as any)}
            className={`px-4 py-3 font-semibold text-sm transition-all duration-200 border-b-2 ${
              filter === tab.id
                ? 'border-red-600 text-red-500'
                : 'border-transparent text-gray-400 hover:text-gray-300'
            }`}
          >
            {tab.label}
            <span className="ml-2 text-xs opacity-70">({tab.count})</span>
          </button>
        ))}
      </div>

      {/* Game Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredGames.map(game => (
          <div
            key={game.id}
            className="bg-gray-800/50 border border-gray-700 rounded-xl overflow-hidden
                       hover:border-red-600/50 transition-all duration-200 hover:shadow-lg
                       hover:shadow-red-600/20 group cursor-pointer"
          >
            {/* Game Icon/Cover */}
            <div className="aspect-square bg-gradient-to-br from-gray-700 to-gray-900
                          flex items-center justify-center relative overflow-hidden">
              <span className="text-6xl group-hover:scale-110 transition-transform duration-300">
                {game.icon}
              </span>

              {/* Badge */}
              {game.installed && (
                <div className="absolute top-2 right-2 bg-green-600/80 px-2 py-1 rounded-lg text-xs font-semibold text-white">
                  ✓ Installed
                </div>
              )}

              {!game.installed && (
                <div className="absolute top-2 right-2 bg-blue-600/80 px-2 py-1 rounded-lg text-xs font-semibold text-white">
                  Available
                </div>
              )}
            </div>

            {/* Game Info */}
            <div className="p-4 space-y-3">
              <h3 className="font-bold text-white text-sm line-clamp-2 group-hover:text-red-400 transition-colors">
                {game.name}
              </h3>

              {/* Rating */}
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span className="text-sm font-semibold text-white">{game.rating}</span>
                <span className="text-xs text-gray-500">({Math.floor(game.rating * 1000)})</span>
              </div>

              {/* Size */}
              <p className="text-xs text-gray-400">{game.size}</p>

              {/* Action Button */}
              <button
                onClick={() => game.installed ? handleLaunchGame(game) : handleDownloadGame(game)}
                className={`w-full py-2 px-3 rounded-lg font-semibold text-sm transition-all duration-200
                           flex items-center justify-center gap-2 ${
                  game.installed
                    ? 'bg-red-600 hover:bg-red-700 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {game.installed ? (
                  <>
                    <Play className="w-4 h-4" />
                    <span>Launch</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>Download</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Game Details Modal */}
      {selectedGame && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 border border-gray-700 rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center gap-4">
              <span className="text-5xl">{selectedGame.icon}</span>
              <div>
                <h3 className="text-xl font-bold text-white">{selectedGame.name}</h3>
                <p className="text-gray-400 text-sm">Ready to Launch</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 py-4 border-y border-gray-700">
              <div>
                <p className="text-gray-400 text-xs mb-1">Rating</p>
                <p className="text-white font-bold">{selectedGame.rating}</p>
              </div>
              <div>
                <p className="text-gray-400 text-xs mb-1">Size</p>
                <p className="text-white font-bold">{selectedGame.size}</p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setSelectedGame(null)}
                className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2
                         rounded-lg transition-all duration-200"
              >
                Close
              </button>
              <button
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2
                         rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4" />
                Play Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
