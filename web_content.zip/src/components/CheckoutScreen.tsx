import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MapPin, 
  CreditCard, 
  Banknote, 
  Smartphone, 
  ShieldCheck, 
  ChevronRight, 
  CheckCircle2, 
  Plus,
  Lock,
  Layers
} from 'lucide-react';
import { CartItem, DeliveryAddress } from '../types/ecommerce';
import { DEFAULT_ADDRESSES } from '../data/mockData';

interface CheckoutScreenProps {
  items: CartItem[];
  subtotal: number;
  shippingFee: number;
  discountAmount: number;
  onBack: () => void;
  onOrderSuccess: (orderDetails: any) => void;
}

export const CheckoutScreen: React.FC<CheckoutScreenProps> = ({
  items,
  subtotal,
  shippingFee,
  discountAmount,
  onBack,
  onOrderSuccess
}) => {
  const [addresses, setAddresses] = useState<DeliveryAddress[]>(DEFAULT_ADDRESSES);
  const [selectedAddressId, setSelectedAddressId] = useState<string>('addr-1');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cod' | 'wallet' | 'installments'>('card');
  const [deliverySpeed, setDeliverySpeed] = useState<'standard' | 'express'>('standard');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showNewAddressModal, setShowNewAddressModal] = useState(false);

  // New address form fields
  const [newAddrName, setNewAddrName] = useState('');
  const [newAddrPhone, setNewAddrPhone] = useState('');
  const [newAddrLine, setNewAddrLine] = useState('');
  const [newAddrCity, setNewAddrCity] = useState('');

  const currentAddress = addresses.find(a => a.id === selectedAddressId) || addresses[0];
  const finalShipping = deliverySpeed === 'standard' ? shippingFee : shippingFee + 300;
  const grandTotal = Math.max(0, subtotal + finalShipping - discountAmount);

  const handlePlaceOrder = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onOrderSuccess({
        orderNumber: 'SEW-' + Math.floor(100000 + Math.random() * 900000),
        items,
        totalAmount: grandTotal,
        paymentMethod: paymentMethod === 'card' ? 'Visa / Mastercard (Ending 4242)' : paymentMethod === 'cod' ? 'Cash on Delivery' : paymentMethod === 'wallet' ? 'Mobile Wallet (FriMi/eZ Cash)' : 'Koko 3x Installments',
        address: currentAddress,
        trackingNumber: 'LK-EXP-' + Math.floor(1000000 + Math.random() * 9000000),
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      });
    }, 1200);
  };

  const handleAddNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddrName || !newAddrLine || !newAddrCity) return;
    const newAddr: DeliveryAddress = {
      id: 'addr-' + Date.now(),
      name: newAddrName,
      phone: newAddrPhone || '+94 77 000 0000',
      addressLine: newAddrLine,
      city: newAddrCity,
      postalCode: '10000',
      isDefault: false,
      label: 'Home'
    };
    setAddresses([...addresses, newAddr]);
    setSelectedAddressId(newAddr.id);
    setShowNewAddressModal(false);
  };

  return (
    <div className="pb-28 bg-slate-100 min-h-screen">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md px-3 py-3 border-b border-slate-200 flex items-center justify-between">
        <button
          onClick={onBack}
          className="p-1 rounded-full hover:bg-slate-100 text-slate-700 transition-colors"
          aria-label="Back to Cart"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-sm font-bold text-slate-900">Checkout</h2>
        <div className="flex items-center gap-1 text-[11px] text-emerald-600 font-bold">
          <Lock className="w-3.5 h-3.5" />
          <span>SSL Secured</span>
        </div>
      </div>

      <div className="p-2.5 space-y-3">
        {/* 1. Delivery Address Selector */}
        <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-2xs space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
              <MapPin className="w-4 h-4 text-[#FF6600]" />
              <span>Delivery Address</span>
            </div>
            <button
              onClick={() => setShowNewAddressModal(true)}
              className="text-[11px] text-[#FF6600] font-bold flex items-center gap-0.5 hover:underline"
            >
              <Plus className="w-3 h-3" /> Add New
            </button>
          </div>

          <div className="space-y-2">
            {addresses.map((addr) => (
              <label
                key={addr.id}
                className={`p-2.5 rounded-xl border flex items-start gap-2.5 cursor-pointer transition-all ${
                  selectedAddressId === addr.id
                    ? 'border-[#FF6600] bg-orange-50/30 ring-1 ring-[#FF6600]'
                    : 'border-slate-200 bg-white'
                }`}
              >
                <input
                  type="radio"
                  name="delivery_address"
                  checked={selectedAddressId === addr.id}
                  onChange={() => setSelectedAddressId(addr.id)}
                  className="mt-1 text-[#FF6600] focus:ring-[#FF6600]"
                />
                <div className="flex-1 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{addr.name}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 rounded font-semibold">
                      {addr.label}
                    </span>
                    <span className="text-slate-400 font-mono text-[11px]">{addr.phone}</span>
                  </div>
                  <p className="text-slate-600 text-[11px] mt-0.5">{addr.addressLine}, {addr.city}</p>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* 2. Delivery Method */}
        <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-2xs space-y-2">
          <span className="text-xs font-bold text-slate-900">Delivery Speed</span>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setDeliverySpeed('standard')}
              className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                deliverySpeed === 'standard'
                  ? 'border-[#FF6600] bg-orange-50/40 text-slate-900'
                  : 'border-slate-200 bg-white text-slate-700'
              }`}
            >
              <div className="font-bold">Standard Delivery</div>
              <div className="text-[10px] text-slate-500">2–3 Days · Rs. {shippingFee}</div>
            </button>
            <button
              onClick={() => setDeliverySpeed('express')}
              className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                deliverySpeed === 'express'
                  ? 'border-[#FF6600] bg-orange-50/40 text-slate-900'
                  : 'border-slate-200 bg-white text-slate-700'
              }`}
            >
              <div className="font-bold">Express Courier</div>
              <div className="text-[10px] text-slate-500">Next Day · Rs. {shippingFee + 300}</div>
            </button>
          </div>
        </div>

        {/* 3. Items Summary Preview */}
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-2xs space-y-2">
          <div className="flex justify-between text-xs font-bold text-slate-900">
            <span>Items Ordered ({items.length})</span>
            <span className="text-slate-400 font-normal">Package 1 of 1</span>
          </div>
          <div className="flex gap-2 overflow-x-auto py-1">
            {items.map((it) => (
              <div key={it.id} className="w-14 h-14 rounded-lg bg-slate-100 overflow-hidden shrink-0 border border-slate-200 relative">
                <img src={it.product.images[0]} alt="" className="w-full h-full object-cover" />
                <span className="absolute bottom-0 right-0 bg-slate-900/80 text-white text-[9px] font-bold px-1 rounded-tl">
                  x{it.quantity}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Payment Gateway Options */}
        <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-2xs space-y-2.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
            <CreditCard className="w-4 h-4 text-[#FF6600]" />
            <span>Select Payment Gateway</span>
          </div>

          <div className="space-y-2">
            {/* Credit / Debit Card */}
            <label
              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                paymentMethod === 'card'
                  ? 'border-[#FF6600] bg-orange-50/30 ring-1 ring-[#FF6600]'
                  : 'border-slate-200 bg-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <input
                  type="radio"
                  name="payment_option"
                  checked={paymentMethod === 'card'}
                  onChange={() => setPaymentMethod('card')}
                  className="text-[#FF6600] focus:ring-[#FF6600]"
                />
                <CreditCard className="w-5 h-5 text-slate-700" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Credit / Debit Card</div>
                  <div className="text-[10px] text-slate-500">Visa, MasterCard, Amex (Instant verification)</div>
                </div>
              </div>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-1.5 py-0.5 rounded">
                Extra 5% Cashback
              </span>
            </label>

            {/* Cash on Delivery */}
            <label
              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                paymentMethod === 'cod'
                  ? 'border-[#FF6600] bg-orange-50/30 ring-1 ring-[#FF6600]'
                  : 'border-slate-200 bg-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <input
                  type="radio"
                  name="payment_option"
                  checked={paymentMethod === 'cod'}
                  onChange={() => setPaymentMethod('cod')}
                  className="text-[#FF6600] focus:ring-[#FF6600]"
                />
                <Banknote className="w-5 h-5 text-emerald-600" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Cash on Delivery (COD)</div>
                  <div className="text-[10px] text-slate-500">Pay cash upon delivery to your doorstep</div>
                </div>
              </div>
              <span className="text-[10px] text-slate-500 font-medium">Free</span>
            </label>

            {/* Mobile Wallet */}
            <label
              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                paymentMethod === 'wallet'
                  ? 'border-[#FF6600] bg-orange-50/30 ring-1 ring-[#FF6600]'
                  : 'border-slate-200 bg-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <input
                  type="radio"
                  name="payment_option"
                  checked={paymentMethod === 'wallet'}
                  onChange={() => setPaymentMethod('wallet')}
                  className="text-[#FF6600] focus:ring-[#FF6600]"
                />
                <Smartphone className="w-5 h-5 text-blue-600" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Mobile Wallet</div>
                  <div className="text-[10px] text-slate-500">eZ Cash, FriMi, Genie & Apple Pay</div>
                </div>
              </div>
              <span className="text-[10px] bg-blue-50 text-blue-700 font-bold px-1.5 py-0.5 rounded">
                1-Tap Pay
              </span>
            </label>

            {/* Installments */}
            <label
              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                paymentMethod === 'installments'
                  ? 'border-[#FF6600] bg-orange-50/30 ring-1 ring-[#FF6600]'
                  : 'border-slate-200 bg-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <input
                  type="radio"
                  name="payment_option"
                  checked={paymentMethod === 'installments'}
                  onChange={() => setPaymentMethod('installments')}
                  className="text-[#FF6600] focus:ring-[#FF6600]"
                />
                <Layers className="w-5 h-5 text-purple-600" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Buy Now, Pay Later</div>
                  <div className="text-[10px] text-slate-500">3 interest-free installments with Koko / Mintpay</div>
                </div>
              </div>
              <span className="text-[10px] text-purple-700 font-bold">0% Interest</span>
            </label>
          </div>
        </div>

        {/* 5. Cost Summary */}
        <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-2xs space-y-1.5 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Items Total</span>
            <span className="font-semibold tabular-nums">Rs. {subtotal.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Shipping Fee</span>
            <span className="font-semibold tabular-nums">Rs. {finalShipping.toLocaleString()}</span>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600 font-semibold">
              <span>Voucher Savings</span>
              <span className="tabular-nums">-Rs. {discountAmount.toLocaleString()}</span>
            </div>
          )}
          <div className="border-t border-slate-100 pt-2 flex justify-between text-base font-black text-slate-900">
            <span>Total Payment</span>
            <span className="text-[#FF6600] tabular-nums">Rs. {grandTotal.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Sticky Place Order Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 px-4 py-3 flex items-center justify-between shadow-2xl max-w-md mx-auto md:max-w-none">
        <div>
          <span className="text-[10px] text-slate-400 uppercase font-semibold">Grand Total</span>
          <div className="text-base font-extrabold text-[#FF6600] tabular-nums">
            Rs. {grandTotal.toLocaleString()}
          </div>
        </div>

        <button
          onClick={handlePlaceOrder}
          disabled={isProcessing}
          className="bg-[#FF6600] text-white font-bold text-xs px-8 py-3 rounded-xl shadow-lg hover:bg-orange-600 active:scale-98 transition-all flex items-center gap-2"
        >
          {isProcessing ? (
            <>
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              <span>Processing...</span>
            </>
          ) : (
            <>
              <span>Place Order</span>
              <CheckCircle2 className="w-4 h-4" />
            </>
          )}
        </button>
      </div>

      {/* Add New Address Modal */}
      {showNewAddressModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full shadow-2xl">
            <h3 className="font-bold text-slate-900 text-sm mb-3">Add New Delivery Address</h3>
            <form onSubmit={handleAddNewAddress} className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={newAddrName}
                  onChange={(e) => setNewAddrName(e.target.value)}
                  placeholder="e.g. Kasun Perera"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-slate-800"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={newAddrPhone}
                  onChange={(e) => setNewAddrPhone(e.target.value)}
                  placeholder="+94 77 123 4567"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-slate-800"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Street Address</label>
                <input
                  type="text"
                  required
                  value={newAddrLine}
                  onChange={(e) => setNewAddrLine(e.target.value)}
                  placeholder="Apartment, house no., street"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-slate-800"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">City / Region</label>
                <input
                  type="text"
                  required
                  value={newAddrCity}
                  onChange={(e) => setNewAddrCity(e.target.value)}
                  placeholder="e.g. Colombo, Kandy"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-slate-800"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewAddressModal(false)}
                  className="flex-1 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-lg bg-[#FF6600] text-white text-xs font-bold hover:bg-orange-600"
                >
                  Save Address
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
