import React, { useState, useEffect } from 'react';
import { Tv, X, Check, Terminal, ExternalLink, Cable } from 'lucide-react';
import { TV_INPUT_OPTIONS } from '../services/catalogData';
import { TvInputSource } from '../types/launcher';

interface InputSettingsModalProps {
  isOpen: boolean;
  activeInput: TvInputSource;
  onClose: () => void;
  onSelectInput: (inputId: TvInputSource) => void;
  onLaunchAndroidInputSettings: () => void;
}

export const InputSettingsModal: React.FC<InputSettingsModalProps> = ({
  isOpen,
  activeInput,
  onClose,
  onSelectInput,
  onLaunchAndroidInputSettings,
}) => {
  const [copied, setCopied] = useState(false);
  const [focusIndex, setFocusIndex] = useState(0);

  // Targets:
  // 0 to 3: TV Input Options (HDMI 1, HDMI 2, HDMI 3, Tuner)
  // 4: Launch Native TV Input Manager
  // 5: Close / Cancel
  const totalTargets = TV_INPUT_OPTIONS.length + 2;

  useEffect(() => {
    if (isOpen) {
      const activeIdx = TV_INPUT_OPTIONS.findIndex((o) => o.id === activeInput);
      setFocusIndex(activeIdx >= 0 ? activeIdx : 0);
    }
  }, [isOpen, activeInput]);

  const adbInputCommand = 'adb shell am start -a android.media.tv.action.VIEW_INPUT';

  const handleCopyAdb = () => {
    navigator.clipboard.writeText(adbInputCommand).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Keyboard & TV remote navigation inside modal
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.keyCode === 20) {
        e.preventDefault();
        setFocusIndex((prev) => (prev < totalTargets - 1 ? prev + 1 : 0));
      } else if (e.key === 'ArrowUp' || e.keyCode === 19) {
        e.preventDefault();
        setFocusIndex((prev) => (prev > 0 ? prev - 1 : totalTargets - 1));
      } else if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 23 || e.keyCode === 66) {
        e.preventDefault();
        if (focusIndex < TV_INPUT_OPTIONS.length) {
          const opt = TV_INPUT_OPTIONS[focusIndex];
          if (opt) {
            onSelectInput(opt.id);
            onClose();
          }
        } else if (focusIndex === TV_INPUT_OPTIONS.length) {
          onLaunchAndroidInputSettings();
        } else if (focusIndex === totalTargets - 1) {
          onClose();
        }
      } else if (e.key === 'Escape' || e.key === 'Backspace' || e.keyCode === 4 || e.keyCode === 111) {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, focusIndex, totalTargets, onSelectInput, onLaunchAndroidInputSettings, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in select-none"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-gradient-to-b from-[#181a20] to-[#0e1014] border border-white/20 rounded-3xl shadow-2xl p-6 md:p-8 text-white overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <Cable className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white">TV Input Sources</h2>
              <p className="text-xs text-slate-400 mt-0.5">Switch HDMI & Antenna (Use TV Remote)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Inputs List */}
        <div className="space-y-3 mb-6">
          {TV_INPUT_OPTIONS.map((opt, idx) => {
            const isSelected = opt.id === activeInput;
            const isItemFocused = focusIndex === idx;

            return (
              <div
                key={opt.id}
                onClick={() => {
                  onSelectInput(opt.id);
                  onClose();
                }}
                className={`flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all ${
                  isItemFocused
                    ? 'bg-white text-slate-950 ring-4 ring-white shadow-2xl scale-102 font-bold'
                    : isSelected
                    ? 'bg-sky-500/20 border-2 border-sky-400 text-white'
                    : 'bg-white/5 hover:bg-white/10 border border-white/10 text-white'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      isItemFocused
                        ? 'bg-slate-950 text-white'
                        : isSelected
                        ? 'bg-sky-400 text-slate-950 font-bold'
                        : 'bg-white/10 text-slate-300'
                    }`}
                  >
                    <Tv className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className={`text-sm ${isItemFocused ? 'text-slate-950 font-bold' : 'text-white font-bold'}`}>{opt.label}</h3>
                      {isSelected && (
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                          isItemFocused ? 'bg-slate-950 text-white' : 'bg-sky-500 text-white'
                        }`}>
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <p className={`text-xs mt-0.5 ${isItemFocused ? 'text-slate-700 font-medium' : 'text-slate-300'}`}>{opt.detail}</p>
                    <p className={`text-[10px] font-mono mt-0.5 ${isItemFocused ? 'text-slate-600' : 'text-slate-500'}`}>{opt.resolution}</p>
                  </div>
                </div>

                {isSelected ? (
                  <Check className={`w-5 h-5 ${isItemFocused ? 'text-slate-950' : 'text-sky-400'}`} />
                ) : (
                  <span className={`text-xs font-medium ${isItemFocused ? 'text-slate-900 font-bold' : 'text-slate-400'}`}>Switch</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Android TV Intent Shell Command */}
        <div className="p-3 rounded-2xl bg-black/40 border border-white/10 mb-4 text-xs">
          <div className="flex items-center justify-between mb-1">
            <span className="flex items-center gap-1 text-[10px] font-mono text-amber-400">
              <Terminal className="w-3.5 h-3.5" />
              Android TV Input Intent
            </span>
            <button
              onClick={handleCopyAdb}
              className="text-[10px] text-slate-300 hover:text-white px-2 py-0.5 rounded bg-white/10 cursor-pointer"
            >
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <p className="font-mono text-[11px] text-slate-300 truncate">{adbInputCommand}</p>
        </div>

        {/* Footer actions (Focusable) */}
        <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs">
          <button
            onClick={onLaunchAndroidInputSettings}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer outline-hidden ${
              focusIndex === TV_INPUT_OPTIONS.length
                ? 'bg-sky-400 text-slate-950 font-bold ring-2 ring-white'
                : 'text-sky-400 hover:text-sky-300'
            }`}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Launch Native TV Input Manager</span>
          </button>

          <button
            onClick={onClose}
            className={`px-5 py-2.5 rounded-xl font-medium transition-all cursor-pointer outline-hidden ${
              focusIndex === totalTargets - 1
                ? 'bg-white text-slate-950 ring-4 ring-white font-bold scale-105'
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
