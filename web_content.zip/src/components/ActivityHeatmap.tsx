import React, { useState, useMemo } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import { Calendar, Flame, ChevronLeft, ChevronRight } from 'lucide-react';

export const ActivityHeatmap: React.FC = () => {
  const { climbs } = useClimbing();

  // Selected month offset: 0 is current month, -1 is previous month, etc.
  const [monthOffset, setMonthOffset] = useState<number>(0);
  const [hoveredDay, setHoveredDay] = useState<{ date: string; count: number; routes: string[] } | null>(null);

  // Compute reference month
  const targetDate = useMemo(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + monthOffset);
    return d;
  }, [monthOffset]);

  const year = targetDate.getFullYear();
  const month = targetDate.getMonth(); // 0-indexed
  const monthName = targetDate.toLocaleString('default', { month: 'long', year: 'numeric' });

  // Map climbs by YYYY-MM-DD
  const climbsByDate = useMemo(() => {
    const map: Record<string, { count: number; routes: string[] }> = {};
    climbs.forEach(c => {
      if (!map[c.date]) {
        map[c.date] = { count: 0, routes: [] };
      }
      map[c.date].count += 1;
      map[c.date].routes.push(`${c.routeName} (${c.grade})`);
    });
    return map;
  }, [climbs]);

  // Generate calendar days for the current displayed month
  const calendarDays = useMemo(() => {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDayIndex = new Date(year, month, 1).getDay(); // 0 is Sunday, 1 is Monday...
    // Adjust to Monday first (0 = Mon, 6 = Sun)
    const startingOffset = firstDayIndex === 0 ? 6 : firstDayIndex - 1;

    const days = [];

    // Empty lead cells
    for (let i = 0; i < startingOffset; i++) {
      days.push(null);
    }

    // Days of month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const entry = climbsByDate[dateString];
      days.push({
        dayNumber: day,
        dateString,
        count: entry ? entry.count : 0,
        routes: entry ? entry.routes : []
      });
    }

    return days;
  }, [year, month, climbsByDate]);

  // Compute monthly stats
  const monthlyStats = useMemo(() => {
    let activeDays = 0;
    let totalMonthlyClimbs = 0;
    calendarDays.forEach(d => {
      if (d && d.count > 0) {
        activeDays += 1;
        totalMonthlyClimbs += d.count;
      }
    });
    return { activeDays, totalMonthlyClimbs };
  }, [calendarDays]);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-xs space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-950/80 text-orange-600 dark:text-orange-400 flex items-center justify-center font-bold shrink-0">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Climbing Activity Heatmap</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Session frequency & wall attendance
            </p>
          </div>
        </div>

        {/* Month Navigation & Stats */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setMonthOffset(prev => prev - 1)}
              className="p-1 hover:text-orange-600 rounded transition-colors"
              title="Previous Month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 py-0.5 whitespace-nowrap text-slate-800 dark:text-slate-200">
              {monthName}
            </span>
            <button
              type="button"
              onClick={() => setMonthOffset(prev => Math.min(0, prev + 1))}
              disabled={monthOffset >= 0}
              className={`p-1 rounded transition-colors ${monthOffset >= 0 ? 'opacity-30 cursor-not-allowed' : 'hover:text-orange-600'}`}
              title="Next Month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Monthly Summary Badges */}
      <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-1.5 font-medium">
          <Flame className="w-4 h-4 text-orange-600 shrink-0" />
          <span>Active Days:</span>
          <span className="font-bold text-slate-900 dark:text-white font-mono tabular-nums">
            {monthlyStats.activeDays} days
          </span>
        </div>
        <div className="flex items-center gap-1.5 font-medium">
          <span>Monthly Ascents:</span>
          <span className="font-bold text-orange-600 dark:text-orange-400 font-mono tabular-nums">
            {monthlyStats.totalMonthlyClimbs} climbs
          </span>
        </div>
      </div>

      {/* SVG Calendar Grid */}
      <div className="space-y-1">
        {/* Day-of-week headers */}
        <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase pb-1">
          <span>Mon</span>
          <span>Tue</span>
          <span>Wed</span>
          <span>Thu</span>
          <span>Fri</span>
          <span>Sat</span>
          <span>Sun</span>
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {calendarDays.map((cell, idx) => {
            if (!cell) {
              return (
                <div
                  key={`empty-${idx}`}
                  className="h-9 sm:h-11 rounded-lg bg-slate-50/50 dark:bg-slate-800/20 border border-transparent"
                />
              );
            }

            const { dayNumber, count, dateString, routes } = cell;

            // Determine intensity color
            let bgClass = 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700/60 text-slate-600 dark:text-slate-400';
            if (count === 1) {
              bgClass = 'bg-orange-200 dark:bg-orange-950/80 border-orange-300 dark:border-orange-800 text-orange-900 dark:text-orange-200 font-bold';
            } else if (count === 2) {
              bgClass = 'bg-orange-400 text-white border-orange-500 font-bold shadow-xs';
            } else if (count >= 3) {
              bgClass = 'bg-orange-600 text-white border-orange-700 font-extrabold shadow-xs';
            }

            return (
              <div
                key={dateString}
                onMouseEnter={() => setHoveredDay({ date: dateString, count, routes })}
                onMouseLeave={() => setHoveredDay(null)}
                onClick={() => setHoveredDay(hoveredDay?.date === dateString ? null : { date: dateString, count, routes })}
                className={`h-9 sm:h-11 rounded-lg border flex flex-col items-center justify-center p-1 transition-all cursor-pointer relative ${bgClass} hover:scale-105`}
              >
                <span className="text-[11px] font-mono leading-none">{dayNumber}</span>
                {count > 0 && (
                  <span className="text-[9px] font-mono leading-none mt-0.5 opacity-90">
                    {count}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Tooltip / Active Inspection Bar */}
      {hoveredDay && (
        <div className="p-3 bg-slate-900 text-white rounded-lg text-xs space-y-1 shadow-md animate-in fade-in">
          <div className="flex items-center justify-between font-mono">
            <span className="font-bold text-orange-400">{hoveredDay.date}</span>
            <span>{hoveredDay.count} {hoveredDay.count === 1 ? 'climb logged' : 'climbs logged'}</span>
          </div>
          {hoveredDay.routes.length > 0 && (
            <p className="text-[11px] text-slate-300 truncate">
              {hoveredDay.routes.slice(0, 3).join(' · ')}
              {hoveredDay.routes.length > 3 ? ` +${hoveredDay.routes.length - 3} more` : ''}
            </p>
          )}
        </div>
      )}

      {/* Legend */}
      <div className="flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800">
        <span>Less active</span>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" title="0 climbs" />
          <span className="w-3 h-3 rounded bg-orange-200 dark:bg-orange-950 border border-orange-300" title="1 climb" />
          <span className="w-3 h-3 rounded bg-orange-400 border border-orange-500" title="2 climbs" />
          <span className="w-3 h-3 rounded bg-orange-600 border border-orange-700" title="3+ climbs" />
        </div>
        <span>More active</span>
      </div>
    </div>
  );
};
