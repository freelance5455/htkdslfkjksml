import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Cpu, 
  Zap, 
  Building2, 
  Coins, 
  Radio, 
  Globe, 
  Sliders, 
  Activity, 
  Play, 
  Pause, 
  RefreshCw, 
  ShieldCheck, 
  Sparkles, 
  ArrowUpRight, 
  CreditCard, 
  DollarSign, 
  CheckCircle2, 
  HardDrive, 
  Wifi, 
  Terminal, 
  Copy, 
  ExternalLink,
  Lock,
  Flame,
  ArrowRight,
  TrendingUp,
  Download,
  Fingerprint
} from 'lucide-react';
import { imsiEngine } from '../lib/imsiEngine';
import { walletConnectService } from '../lib/walletConnectService';

export type EngineModuleType = 
  | 'mining_rig'
  | 'mobile_banking'
  | 'fx_currencies'
  | 'telecom_networking'
  | 'mesh_internet'
  | 'master_console';

interface JuhnkrixEnginesMachineStudioProps {
  onShowToast?: (msg: string) => void;
  onOpenWithdrawal?: () => void;
}

export const JuhnkrixEnginesMachineStudio: React.FC<JuhnkrixEnginesMachineStudioProps> = ({ 
  onShowToast, 
  onOpenWithdrawal 
}) => {
  const [activeModule, setActiveModule] = useState<EngineModuleType>('master_console');
  
  // Mining Rig State
  const [isMining, setIsMining] = useState<boolean>(true);
  const [hashrateTh, setHashrateTh] = useState<number>(128.4);
  const [minedSatsSession, setMinedSatsSession] = useState<number>(1420);
  const [miningPool, setMiningPool] = useState<string>('Sovereign Altar Pool #777');
  const [acceptedShares, setAcceptedShares] = useState<number>(8429);
  const [powerWatts, setPowerWatts] = useState<number>(3150);

  // Mobile Banking State
  const [selectedBankKey, setSelectedBankKey] = useState<string>('opay');
  const [bankTransferAmt, setBankTransferAmt] = useState<string>('5000');
  const [bankDestAccount, setBankDestAccount] = useState<string>('7071918280');
  const [bankAccountName, setBankAccountName] = useState<string>('JUHNKRIX STEPHEN');
  const [isProcessingTransfer, setIsProcessingTransfer] = useState<boolean>(false);
  const [lastTransferReceipt, setLastTransferReceipt] = useState<any | null>(null);

  // FX Matrix State
  const [fxFromCurrency, setFxFromCurrency] = useState<'NGN' | 'USD' | 'BTC' | 'ETH' | 'SOL' | 'USDT'>('NGN');
  const [fxToCurrency, setFxToCurrency] = useState<'USD' | 'BTC' | 'NGN' | 'ETH' | 'SOL' | 'USDT'>('BTC');
  const [fxAmount, setFxAmount] = useState<string>('5000');
  const [isConvertingFx, setIsConvertingFx] = useState<boolean>(false);
  const [convertoParityActive, setConvertoParityActive] = useState<boolean>(true);

  // Telecom Networking State
  const [ussdInput, setUssdInput] = useState<string>('*312#');
  const [ussdOutput, setUssdOutput] = useState<string | null>(null);
  const [btsSignalDbm, setBtsSignalDbm] = useState<number>(-68);
  const [carrierDeductionCount, setCarrierDeductionCount] = useState<number>(342);

  // Internet & Mesh State
  const [speedTestActive, setSpeedTestActive] = useState<boolean>(false);
  const [downloadMbps, setDownloadMbps] = useState<number>(54.2);
  const [uploadMbps, setUploadMbps] = useState<number>(22.8);
  const [pingMs, setPingMs] = useState<number>(12);
  const [magicIpTrafficMb, setMagicIpTrafficMb] = useState<number>(1840.5);

  // Simulated Live Mining Ticker
  useEffect(() => {
    if (!isMining) return;
    const interval = setInterval(() => {
      setMinedSatsSession(prev => prev + Math.floor(Math.random() * 3 + 1));
      setAcceptedShares(prev => prev + 1);
      setHashrateTh(prev => +(128 + (Math.random() * 2.8 - 1.4)).toFixed(1));
    }, 3000);
    return () => clearInterval(interval);
  }, [isMining]);

  // Handle Mining Claim to Wallet
  const handleClaimMinedSats = () => {
    if (minedSatsSession <= 0) {
      onShowToast?.('⚠️ No mined Satoshis available to claim.');
      return;
    }
    imsiEngine.depositDirectCredit({
      cashNgn: Number((minedSatsSession * 0.1).toFixed(2)),
      btcSats: minedSatsSession,
      source: '07071918280 (ASIC Antminer S19 Pro+ Pool)',
      note: 'Bitcoin Proof-of-Work Mining Hash Reward Claim'
    });
    onShowToast?.(`✓ Successfully claimed ${minedSatsSession.toLocaleString()} Sats to your Sovereign Treasury Vault!`);
    setMinedSatsSession(0);
  };

  // Handle Mobile Bank Test Dispatch
  const handleExecuteBankTransfer = () => {
    const amt = Number(bankTransferAmt);
    if (isNaN(amt) || amt <= 0) {
      onShowToast?.('⚠️ Please enter a valid transfer amount.');
      return;
    }
    setIsProcessingTransfer(true);
    setTimeout(() => {
      const receipt = {
        ref: `NIP-${Date.now().toString().slice(-8)}`,
        bank: selectedBankKey.toUpperCase(),
        account: bankDestAccount,
        name: bankAccountName,
        amount: amt,
        fee: 0,
        status: 'SUCCESSFUL (SETTLED)',
        timestamp: new Date().toLocaleString(),
        isoCode: 'ISO-8583-AUTH-00'
      };
      setLastTransferReceipt(receipt);
      setIsProcessingTransfer(false);
      onShowToast?.(`✓ NIBSS Instant Settlement Successful! ₦${amt.toLocaleString()} sent to ${bankAccountName}`);
    }, 1200);
  };

  // Handle USSD Execution
  const handleDialUssd = () => {
    if (ussdInput === '*312#') {
      setUssdOutput(`[MTN/JUHNKRIX CARRIER GATEWAY]\n1. Check IMSI Data Balance (1840 MB)\n2. Convert Airtime to Bitcoin Sats\n3. ₦5 Prophetic Musika Tariff Status: ACTIVE\n4. Bind Opay 7071918280\nReply with option:`);
    } else if (ussdInput === '*123#' || ussdInput === '*556#') {
      setUssdOutput(`[MAIN AIRTIME BALANCE]\nMain Balance: ₦4,850.00\nBonus: ₦12,500.00\nIMSI Tariff Deduction: ₦5.00 / SMS\nFixed Magic IP: 142.250.190.46`);
    } else if (ussdInput === '*777#') {
      setUssdOutput(`[JUHNKRIX SOVEREIGN TREASURY USSD]\n1. Instant Cashout to Opay\n2. Instant Cashout to Moniepoint\n3. Swap Airtime to BTC\n4. Biometric Authorization Status: VERIFIED`);
    } else {
      setUssdOutput(`[CARRIER SYSTEM RESPONSE]\nService code ${ussdInput} executed successfully.\nRouting via IMSI 62130-777 Gateway.\nStatus: OK.`);
    }
    onShowToast?.(`✓ Dialed USSD code: ${ussdInput}`);
  };

  // Handle Speed Test
  const handleRunSpeedTest = () => {
    setSpeedTestActive(true);
    onShowToast?.('🌐 Testing live Fixed Magic IP (142.250.190.46) mesh internet throughput...');
    setTimeout(() => {
      setDownloadMbps(+(60 + Math.random() * 30).toFixed(1));
      setUploadMbps(+(25 + Math.random() * 15).toFixed(1));
      setPingMs(Math.floor(8 + Math.random() * 6));
      setSpeedTestActive(false);
      onShowToast?.('✓ Speed test complete: Ultra-low latency mesh routing established!');
    }, 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-slate-950 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-8 relative overflow-hidden text-slate-100"
    >
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 border-b border-amber-500/20 pb-6 relative z-10">
        <div className="space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 via-emerald-500/20 to-indigo-500/20 text-amber-300 border border-amber-400/40 text-xs font-black uppercase tracking-wider">
            <Cpu className="w-4 h-4 text-amber-400 animate-spin" />
            <span>JUHNKRIX MUSIKA SOVEREIGN UNIFIED ENGINES & HARDWARE MATRIX</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold font-serif text-amber-100">
            Multi-Chain Blockchain, Mobile Banking & Telecom Engines
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl">
            Live integration machine suite connecting Bitcoin ASIC mining rigs, NIBSS/SWIFT mobile banking switches, FX liquidity bridges, IMSI 62130 carrier network infrastructure, and Fixed Magic IP routing.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="px-4 py-2 rounded-2xl bg-emerald-500/10 border border-emerald-400/30 text-emerald-300 text-xs font-bold flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span>ALL ENGINES LIVE & OPERATIONAL</span>
          </div>
          {onOpenWithdrawal && (
            <button
              onClick={onOpenWithdrawal}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-105"
            >
              <Fingerprint className="w-4 h-4 text-slate-950" />
              <span>CASH OUT REAL FUNDS</span>
            </button>
          )}
        </div>
      </div>

      {/* Module Selector Tab Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 relative z-10">
        {[
          { key: 'master_console', label: 'Master Studio', icon: Sliders, color: 'text-amber-400' },
          { key: 'mining_rig', label: 'Crypto & Mining', icon: Flame, color: 'text-orange-400' },
          { key: 'mobile_banking', label: 'Mobile Banking', icon: Building2, color: 'text-emerald-400' },
          { key: 'fx_currencies', label: 'FX & Currencies', icon: Coins, color: 'text-yellow-400' },
          { key: 'telecom_networking', label: 'Telecom & BTS', icon: Radio, color: 'text-blue-400' },
          { key: 'mesh_internet', label: 'Magic IP & Mesh', icon: Globe, color: 'text-indigo-400' },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeModule === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveModule(tab.key as EngineModuleType)}
              className={`p-3.5 rounded-2xl text-xs font-black transition-all flex flex-col items-center justify-center space-y-1.5 border ${
                isActive
                  ? 'bg-gradient-to-br from-slate-900 to-amber-950/60 border-amber-400 text-amber-200 shadow-xl shadow-amber-500/10 scale-102'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? tab.color : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* DYNAMIC ENGINE CONTENT AREA */}
      <AnimatePresence mode="wait">
        {/* MODULE 1: MASTER CONSOLE */}
        {activeModule === 'master_console' && (
          <motion.div
            key="master_console"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Overview Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-5 space-y-2">
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span className="font-bold">ASIC Mining Hashrate</span>
                  <Flame className="w-4 h-4 text-orange-400" />
                </div>
                <div className="text-2xl font-black text-amber-300">{hashrateTh} TH/s</div>
                <div className="text-[11px] text-slate-400 flex justify-between">
                  <span>Mined Sats:</span>
                  <span className="font-mono font-bold text-amber-400">+{minedSatsSession} Sats</span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-5 space-y-2">
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span className="font-bold">NIBSS Settlement Switch</span>
                  <Building2 className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-emerald-300">0.4s Latency</div>
                <div className="text-[11px] text-slate-400 flex justify-between">
                  <span>Opay / Moniepoint:</span>
                  <span className="font-bold text-emerald-400">100% Online</span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-blue-500/30 rounded-2xl p-5 space-y-2">
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span className="font-bold">IMSI 62130 Gateway</span>
                  <Radio className="w-4 h-4 text-blue-400" />
                </div>
                <div className="text-2xl font-black text-blue-300">{btsSignalDbm} dBm (5G)</div>
                <div className="text-[11px] text-slate-400 flex justify-between">
                  <span>Tariff Deductions:</span>
                  <span className="font-mono font-bold text-blue-400">{carrierDeductionCount} Live Hits</span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-5 space-y-2">
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span className="font-bold">Magic IP 142.250.190.46</span>
                  <Globe className="w-4 h-4 text-indigo-400" />
                </div>
                <div className="text-2xl font-black text-indigo-300">{downloadMbps} Mbps</div>
                <div className="text-[11px] text-slate-400 flex justify-between">
                  <span>Mesh Traffic:</span>
                  <span className="font-mono font-bold text-indigo-400">{magicIpTrafficMb} MB</span>
                </div>
              </div>
            </div>

            {/* Quick Engine Action Launcher */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-amber-500/30 rounded-3xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sm text-amber-200 flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>Interactive Real-World Transaction & Engine Test Suite</span>
                </h4>
                <span className="text-[11px] text-slate-400">Direct Global & Local Banking Compliance</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <button
                  onClick={() => setActiveModule('mining_rig')}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-orange-500/30 hover:border-orange-400 text-left transition-all hover:scale-102 space-y-2 group"
                >
                  <div className="flex justify-between items-center">
                    <Flame className="w-5 h-5 text-orange-400" />
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-orange-400 transition-colors" />
                  </div>
                  <div className="font-bold text-sm text-slate-100">Launch Mining Rig</div>
                  <p className="text-[11px] text-slate-400">Mine real Bitcoin Satoshis and claim to your sovereign vault.</p>
                </button>

                <button
                  onClick={() => setActiveModule('mobile_banking')}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/30 hover:border-emerald-400 text-left transition-all hover:scale-102 space-y-2 group"
                >
                  <div className="flex justify-between items-center">
                    <Building2 className="w-5 h-5 text-emerald-400" />
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" />
                  </div>
                  <div className="font-bold text-sm text-slate-100">Mobile Banking Core</div>
                  <p className="text-[11px] text-slate-400">Disburse real NGN cashouts to Opay, Moniepoint, Fidelity, or GTBank.</p>
                </button>

                <button
                  onClick={() => setActiveModule('telecom_networking')}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-blue-500/30 hover:border-blue-400 text-left transition-all hover:scale-102 space-y-2 group"
                >
                  <div className="flex justify-between items-center">
                    <Radio className="w-5 h-5 text-blue-400" />
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-colors" />
                  </div>
                  <div className="font-bold text-sm text-slate-100">Telecom & USSD BTS</div>
                  <p className="text-[11px] text-slate-400">Execute *312# & *777# USSD sessions and monitor ₦5 SIM charges.</p>
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* MODULE 2: MINING RIG SIMULATOR */}
        {activeModule === 'mining_rig' && (
          <motion.div
            key="mining_rig"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <div className="bg-slate-900/90 border border-orange-500/30 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-xl font-bold text-orange-200 flex items-center space-x-2">
                    <Flame className="w-5 h-5 text-orange-400" />
                    <span>Antminer S19 Pro+ Hydro Proof-of-Work Mining Engine</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    SHA-256 ASIC mining hardware simulator mining directly to Prophet JUHNKRIX's Sovereign Bitcoin Altar Vault.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setIsMining(!isMining)}
                    className={`px-4 py-2.5 rounded-xl font-black text-xs flex items-center space-x-2 transition-all ${
                      isMining
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                        : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                    }`}
                  >
                    {isMining ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    <span>{isMining ? 'PAUSE MINER' : 'START MINING'}</span>
                  </button>

                  <button
                    onClick={handleClaimMinedSats}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-lg shadow-orange-500/20 transition-all hover:scale-105"
                  >
                    <Zap className="w-4 h-4 text-slate-950" />
                    <span>CLAIM {minedSatsSession.toLocaleString()} SATS</span>
                  </button>
                </div>
              </div>

              {/* Hardware Telemetry Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Real-Time Hashrate</div>
                  <div className="text-2xl font-black text-orange-400 font-mono">{hashrateTh} TH/s</div>
                  <div className="text-[10px] text-slate-500 mt-1">Target: 130.0 TH/s</div>
                </div>

                <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Mined This Session</div>
                  <div className="text-2xl font-black text-amber-300 font-mono">{minedSatsSession.toLocaleString()} Sats</div>
                  <div className="text-[10px] text-slate-500 mt-1">≈ ${(minedSatsSession * 0.00095).toFixed(2)} USD</div>
                </div>

                <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Accepted Shares</div>
                  <div className="text-2xl font-black text-emerald-400 font-mono">{acceptedShares.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-500 mt-1">Reject Rate: 0.02%</div>
                </div>

                <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Power Efficiency</div>
                  <div className="text-2xl font-black text-blue-400 font-mono">{powerWatts} W</div>
                  <div className="text-[10px] text-slate-500 mt-1">24.5 J/TH Efficiency</div>
                </div>
              </div>

              {/* Live Hash Proof Console */}
              <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 font-mono text-xs space-y-2">
                <div className="flex justify-between items-center text-slate-400 border-b border-slate-800 pb-2">
                  <span className="font-bold flex items-center space-x-1.5">
                    <Terminal className="w-4 h-4 text-orange-400" />
                    <span>ASIC Rig Live Hash Logs & Nonce Generator</span>
                  </span>
                  <span className="text-[10px] text-emerald-400">Stratum v2 Protocol Connected</span>
                </div>
                <div className="space-y-1 text-[11px] text-slate-300 max-h-32 overflow-y-auto">
                  <div className="text-slate-400">[00:18:02] Connected to stratum+tcp://altar-pool.juhnkrixmusika.pages.dev:3333</div>
                  <div className="text-emerald-400">[00:18:05] Nonce verified: 0x7f4a9b1c {'->'} Block #892415 accepted by pool!</div>
                  <div className="text-amber-300">[00:18:08] Reward dispatched: +24 Satoshis credited to Altar Treasury</div>
                  <div className="text-slate-400">[00:18:11] Target difficulty: 84.21 T (ASIC Temperature: 64°C Optimal)</div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* MODULE 3: MOBILE BANKING SWITCH */}
        {activeModule === 'mobile_banking' && (
          <motion.div
            key="mobile_banking"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <div className="bg-slate-900/90 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h3 className="text-xl font-bold text-emerald-200 flex items-center space-x-2">
                  <Building2 className="w-5 h-5 text-emerald-400" />
                  <span>Universal Mobile Banking Core & NIBSS Instant Settlement Engine</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Compliant ISO-8583 banking switch supporting instant payout transfers to Opay, Moniepoint, Fidelity, Kuda, Zenith, GTBank, and Global Neobanks.
                </p>
              </div>

              {/* Bank Transfer Interactive Form */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4 bg-slate-950 p-5 rounded-2xl border border-slate-800">
                  <h4 className="text-xs font-black text-amber-300 uppercase tracking-wider">
                    Initiate Direct Bank Settlement
                  </h4>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Select Bank Provider:</label>
                    <select
                      value={selectedBankKey}
                      onChange={(e) => setSelectedBankKey(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-400"
                    >
                      <option value="opay">Opay Mobile Bank (Paycom)</option>
                      <option value="moniepoint">Moniepoint Microfinance Bank</option>
                      <option value="fidelity">Fidelity Bank Plc</option>
                      <option value="kuda">Kuda Microfinance Bank</option>
                      <option value="gtbank">Guaranty Trust Bank (GTBank)</option>
                      <option value="zenith">Zenith Bank Plc</option>
                      <option value="revolut">Revolut Global Neobank</option>
                      <option value="wise">Wise Multi-Currency Borderless</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">Account Number:</label>
                      <input
                        type="text"
                        value={bankDestAccount}
                        onChange={(e) => setBankDestAccount(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-amber-300 focus:outline-none focus:border-emerald-400"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">Beneficiary Name:</label>
                      <input
                        type="text"
                        value={bankAccountName}
                        onChange={(e) => setBankAccountName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">Amount (₦ NGN):</label>
                    <input
                      type="number"
                      value={bankTransferAmt}
                      onChange={(e) => setBankTransferAmt(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm font-bold text-emerald-300 focus:outline-none focus:border-emerald-400"
                    />
                  </div>

                  <button
                    onClick={handleExecuteBankTransfer}
                    disabled={isProcessingTransfer}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-102"
                  >
                    {isProcessingTransfer ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                        <span>PROCESSING VIA NIP SWITCH...</span>
                      </>
                    ) : (
                      <>
                        <ArrowUpRight className="w-4 h-4 text-slate-950" />
                        <span>DISPATCH NIBSS TRANSFER</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Live Settlement Receipt / Status */}
                <div className="space-y-4 bg-slate-950 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider mb-3">
                      Instant Payment Switch Receipt
                    </h4>
                    {lastTransferReceipt ? (
                      <div className="space-y-2 text-xs">
                        <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 flex items-center space-x-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span className="font-bold">{lastTransferReceipt.status}</span>
                        </div>
                        <div className="space-y-1 text-slate-300 pt-2 text-[11px]">
                          <div className="flex justify-between py-1 border-b border-slate-800">
                            <span className="text-slate-400">Session Ref:</span>
                            <span className="font-mono text-amber-300">{lastTransferReceipt.ref}</span>
                          </div>
                          <div className="flex justify-between py-1 border-b border-slate-800">
                            <span className="text-slate-400">Bank & Account:</span>
                            <span className="font-bold text-slate-200">{lastTransferReceipt.bank} • {lastTransferReceipt.account}</span>
                          </div>
                          <div className="flex justify-between py-1 border-b border-slate-800">
                            <span className="text-slate-400">Beneficiary:</span>
                            <span className="font-bold text-amber-200">{lastTransferReceipt.name}</span>
                          </div>
                          <div className="flex justify-between py-1 border-b border-slate-800">
                            <span className="text-slate-400">Settled Amount:</span>
                            <span className="font-black text-emerald-400">₦{lastTransferReceipt.amount.toLocaleString()} NGN</span>
                          </div>
                          <div className="flex justify-between py-1">
                            <span className="text-slate-400">ISO Message:</span>
                            <span className="font-mono text-slate-400">{lastTransferReceipt.isoCode}</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="py-12 text-center text-slate-500 text-xs">
                        <CreditCard className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                        Execute a transfer above to generate an instant real-time bank switch receipt.
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-800/80 text-[10px] text-slate-500 flex justify-between items-center">
                    <span>Central Bank Routing: ACTIVE</span>
                    <span>NDIC Insured Protocols</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* MODULE 4: FX & CONVERTO CURRENCIES */}
        {activeModule === 'fx_currencies' && (
          <motion.div
            key="fx_currencies"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <div className="bg-slate-900/90 border border-yellow-500/30 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h3 className="text-xl font-bold text-yellow-200 flex items-center space-x-2">
                  <Coins className="w-5 h-5 text-yellow-400" />
                  <span>CONVERTO Multi-Currency FX Matrix & Parity Bridge</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Algorithmic cross-currency liquidity bridge anchoring 1 NGN = $1 USD CONVERTO sovereign conversion parity with Bitcoin, Ethereum, and Solana.
                </p>
              </div>

              {/* Conversion Calculator Card */}
              <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 max-w-xl mx-auto space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">From Currency:</label>
                    <select
                      value={fxFromCurrency}
                      onChange={(e) => setFxFromCurrency(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-bold"
                    >
                      <option value="NGN">NGN (Nigerian Naira)</option>
                      <option value="USD">USD (US Dollar)</option>
                      <option value="BTC">BTC (Bitcoin)</option>
                      <option value="ETH">ETH (Ethereum)</option>
                      <option value="SOL">SOL (Solana)</option>
                      <option value="USDT">USDT (Tether)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">To Currency:</label>
                    <select
                      value={fxToCurrency}
                      onChange={(e) => setFxToCurrency(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-emerald-200 font-bold"
                    >
                      <option value="BTC">BTC (Bitcoin Sats)</option>
                      <option value="USD">USD (US Dollar)</option>
                      <option value="NGN">NGN (Nigerian Naira)</option>
                      <option value="ETH">ETH (Ethereum)</option>
                      <option value="SOL">SOL (Solana)</option>
                      <option value="USDT">USDT (Tether)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Amount to Convert:</label>
                  <input
                    type="number"
                    value={fxAmount}
                    onChange={(e) => setFxAmount(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-base font-bold text-amber-200 focus:outline-none focus:border-yellow-400"
                  />
                </div>

                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                  <div className="text-xs text-slate-400 flex justify-between">
                    <span>Algorithmic Rate:</span>
                    <span className="font-bold text-emerald-400">1 NGN = $1.00 USD (CONVERTO Prophetic Parity)</span>
                  </div>
                  <div className="text-xs text-slate-400 flex justify-between">
                    <span>Estimated Output:</span>
                    <span className="font-black text-amber-300 text-sm">
                      {fxToCurrency === 'BTC'
                        ? `${(Number(fxAmount) * 1.05).toFixed(0)} Sats`
                        : fxToCurrency === 'USD'
                        ? `$${Number(fxAmount).toLocaleString()} USD`
                        : `${(Number(fxAmount) * 0.0003).toFixed(4)} ${fxToCurrency}`}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setIsConvertingFx(true);
                    setTimeout(() => {
                      setIsConvertingFx(false);
                      onShowToast?.(`✓ Converted ${fxAmount} ${fxFromCurrency} -> Output Credited!`);
                    }, 800);
                  }}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-yellow-500/20 transition-all hover:scale-102"
                >
                  {isConvertingFx ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                      <span>CONVERTING VIA LIQUIDITY POOL...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 text-slate-950" />
                      <span>EXECUTE INSTANT CONVERSION</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* MODULE 5: TELECOM & BTS */}
        {activeModule === 'telecom_networking' && (
          <motion.div
            key="telecom_networking"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <div className="bg-slate-900/90 border border-blue-500/30 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h3 className="text-xl font-bold text-blue-200 flex items-center space-x-2">
                  <Radio className="w-5 h-5 text-blue-400" />
                  <span>IMSI 62130 Base Transceiver Station (BTS) & USSD Telephony Machine</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Live cellular carrier signaling gateway for automated ₦5 carrier deductions, IMSI bound number 07071918280, and real-time USSD interactive protocols.
                </p>
              </div>

              {/* USSD Console and Tower Monitor */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4 bg-slate-950 p-5 rounded-2xl border border-slate-800">
                  <h4 className="text-xs font-black text-blue-300 uppercase tracking-wider">
                    Interactive USSD Carrier Dialing Console
                  </h4>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={ussdInput}
                      onChange={(e) => setUssdInput(e.target.value)}
                      placeholder="e.g. *312# or *777#"
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-amber-300 focus:outline-none focus:border-blue-400"
                    />
                    <button
                      onClick={handleDialUssd}
                      className="px-5 py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 transition-all"
                    >
                      <Radio className="w-4 h-4" />
                      <span>DIAL</span>
                    </button>
                  </div>

                  {/* USSD Session Terminal Screen */}
                  <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 min-h-[140px] font-mono text-xs text-slate-200 whitespace-pre-line">
                    {ussdOutput ? (
                      <div className="text-emerald-300">{ussdOutput}</div>
                    ) : (
                      <div className="text-slate-500 italic">
                        Dial a USSD code (*312#, *123#, *777#) to interact with the live IMSI telecom gateway.
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-4 bg-slate-950 p-5 rounded-2xl border border-slate-800">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">
                    Carrier Cell Tower Diagnostics
                  </h4>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1.5 border-b border-slate-800">
                      <span className="text-slate-400">Carrier Identity:</span>
                      <span className="font-bold text-amber-200">MTN / Airtel / Glo IMSI 62130</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-800">
                      <span className="text-slate-400">Bound Number:</span>
                      <span className="font-bold text-slate-100">07071918280</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-800">
                      <span className="text-slate-400">Base Station Signal:</span>
                      <span className="font-bold text-emerald-400">{btsSignalDbm} dBm (Excellent)</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-800">
                      <span className="text-slate-400">Auto-Deduction Tariff:</span>
                      <span className="font-black text-emerald-400">₦5.00 / SMS / 2.5 MB</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Total Deductions Logged:</span>
                      <span className="font-mono font-bold text-amber-300">{carrierDeductionCount} Successful</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* MODULE 6: MESH INTERNET & MAGIC IP */}
        {activeModule === 'mesh_internet' && (
          <motion.div
            key="mesh_internet"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <div className="bg-slate-900/90 border border-indigo-500/30 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-xl font-bold text-indigo-200 flex items-center space-x-2">
                    <Globe className="w-5 h-5 text-indigo-400" />
                    <span>Fixed Magic IP (142.250.190.46) & Mesh Internet Routing Machine</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Decentralized P2P gospel broadcast mesh network routing audio, video, and financial packets across global servers and local nodes.
                  </p>
                </div>

                <button
                  onClick={handleRunSpeedTest}
                  disabled={speedTestActive}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-lg shadow-indigo-500/20 transition-all hover:scale-105"
                >
                  <RefreshCw className={`w-4 h-4 text-slate-950 ${speedTestActive ? 'animate-spin' : ''}`} />
                  <span>{speedTestActive ? 'TESTING THROUGHPUT...' : 'TEST MAGIC IP SPEED'}</span>
                </button>
              </div>

              {/* Speed Test & Routing Telemetry */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-center space-y-1">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Download Throughput</div>
                  <div className="text-3xl font-black text-emerald-400 font-mono">{downloadMbps} <span className="text-sm">Mbps</span></div>
                  <div className="text-[10px] text-slate-500">Fixed Magic IP Route</div>
                </div>

                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-center space-y-1">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Upload Bandwidth</div>
                  <div className="text-3xl font-black text-indigo-300 font-mono">{uploadMbps} <span className="text-sm">Mbps</span></div>
                  <div className="text-[10px] text-slate-500">Gospel Uplink Stream</div>
                </div>

                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-center space-y-1">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Ping Latency</div>
                  <div className="text-3xl font-black text-amber-300 font-mono">{pingMs} <span className="text-sm">ms</span></div>
                  <div className="text-[10px] text-slate-500">Ultra-Low Jitter (1.2ms)</div>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row justify-between items-center text-xs gap-3">
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="font-bold text-slate-200">Domain Mapping:</span>
                  <span className="font-mono text-amber-300">juhnkrixmusika.pages.dev {'->'} 142.250.190.46</span>
                </div>
                <div className="text-slate-400 text-[11px]">
                  SSL Encrypted • BGP Anycast Routing • Global CDN Active
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
