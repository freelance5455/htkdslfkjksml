import React, { useState } from 'react';
import { X, AlertTriangle, Check, Folder, Info, Trash2 } from 'lucide-react';
import { Carpeta } from '../types';

interface NombreDialogProps {
  titulo: string;
  inicial?: string;
  existentes: string[];
  placeholder?: string;
  onAceptar: (nombre: string) => void;
  onCancelar: () => void;
}

export const NombreDialog: React.FC<NombreDialogProps> = ({
  titulo,
  inicial = '',
  existentes,
  placeholder = 'Ej. Placa ABC-123 / Ford Ranger',
  onAceptar,
  onCancelar,
}) => {
  const [texto, setTexto] = useState(inicial);
  const nombreLimpio = texto.trim();

  let error: string | null = null;
  if (nombreLimpio.length === 0) {
    error = 'El nombre no puede estar vacío';
  } else if (/[/\\:*?"<>|.]/.test(nombreLimpio)) {
    error = 'Caracteres no permitidos (/ \\ : * ? " < > | .)';
  } else if (
    existentes.some(
      (n) => n.toLowerCase() === nombreLimpio.toLowerCase() && n.toLowerCase() !== inicial.trim().toLowerCase()
    )
  ) {
    error = 'Ya existe una carpeta con ese nombre';
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!error) {
      onAceptar(nombreLimpio);
    }
  };

  const sugerenciasRapidas = ['Placa ', 'Toyota ', 'Chevrolet ', 'Ford ', 'Nissan ', 'Revisión Frenos', 'Chapa y Pintura'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transform transition-all">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📁</span>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">{titulo}</h3>
          </div>
          <button
            onClick={onCancelar}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
              Nombre de la carpeta (vehículo / orden)
            </label>
            <input
              type="text"
              autoFocus
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
              placeholder={placeholder}
              className={`w-full px-4 py-3 rounded-xl border text-sm transition outline-hidden ${
                error && texto.length > 0
                  ? 'border-red-500 bg-red-50/50 dark:bg-red-950/20 text-red-900 dark:text-red-200'
                  : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20'
              }`}
            />
            {error && texto.length > 0 && (
              <p className="mt-1.5 text-xs text-red-600 dark:text-red-400 flex items-center gap-1 font-medium">
                <AlertTriangle size={14} />
                {error}
              </p>
            )}
          </div>

          <div>
            <span className="text-xs text-slate-400 dark:text-slate-500 block mb-1">Sugerencias rápidas:</span>
            <div className="flex flex-wrap gap-1.5">
              {sugerenciasRapidas.map((sug) => (
                <button
                  key={sug}
                  type="button"
                  onClick={() => setTexto((prev) => (prev ? `${prev} ${sug}` : sug))}
                  className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-amber-100 dark:hover:bg-amber-950/40 hover:text-amber-800 dark:hover:text-amber-300 transition"
                >
                  +{sug}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onCancelar}
              className="px-4 py-2.5 text-sm font-medium rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!!error}
              className={`px-5 py-2.5 text-sm font-semibold rounded-xl text-white transition shadow-sm flex items-center gap-2 ${
                error
                  ? 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed opacity-60'
                  : 'bg-amber-600 hover:bg-amber-500 active:scale-95 shadow-amber-600/30'
              }`}
            >
              <Check size={16} />
              Aceptar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface ConfirmarDialogProps {
  titulo: string;
  mensaje: string;
  textoOk?: string;
  textoCancelar?: string;
  esPeligroso?: boolean;
  onOk: () => void;
  onCancelar: () => void;
}

export const ConfirmarDialog: React.FC<ConfirmarDialogProps> = ({
  titulo,
  mensaje,
  textoOk = 'Sí, continuar',
  textoCancelar = 'Cancelar',
  esPeligroso = false,
  onOk,
  onCancelar,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 text-center space-y-4">
        <div
          className={`w-14 h-14 mx-auto rounded-full flex items-center justify-center ${
            esPeligroso
              ? 'bg-red-100 text-red-600 dark:bg-red-950/40 dark:text-red-400'
              : 'bg-amber-100 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400'
          }`}
        >
          {esPeligroso ? <Trash2 size={26} /> : <AlertTriangle size={26} />}
        </div>
        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">{titulo}</h3>
        <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{mensaje}</p>

        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            onClick={onCancelar}
            className="flex-1 px-4 py-2.5 text-sm font-medium rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            {textoCancelar}
          </button>
          <button
            onClick={onOk}
            className={`flex-1 px-4 py-2.5 text-sm font-semibold rounded-xl text-white transition active:scale-95 shadow-sm ${
              esPeligroso
                ? 'bg-red-600 hover:bg-red-500 shadow-red-600/30'
                : 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/30'
            }`}
          >
            {textoOk}
          </button>
        </div>
      </div>
    </div>
  );
};

interface MoverDialogProps {
  carpetaActualId: string;
  todasLasCarpetas: Carpeta[];
  onSeleccionarCarpeta: (nuevaCarpetaId: string) => void;
  onCancelar: () => void;
}

export const MoverDialog: React.FC<MoverDialogProps> = ({
  carpetaActualId,
  todasLasCarpetas,
  onSeleccionarCarpeta,
  onCancelar,
}) => {
  const otrasCarpetas = todasLasCarpetas.filter((c) => c.id !== carpetaActualId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xl">📁</span>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Mover foto a…</h3>
          </div>
          <button
            onClick={onCancelar}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-4 max-h-72 overflow-y-auto space-y-2">
          {otrasCarpetas.length === 0 ? (
            <p className="text-center text-sm text-slate-500 dark:text-slate-400 py-6">
              No hay otras carpetas disponibles. Crea otra carpeta primero en la pantalla principal.
            </p>
          ) : (
            otrasCarpetas.map((c) => (
              <button
                key={c.id}
                onClick={() => onSeleccionarCarpeta(c.id)}
                className="w-full text-left px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-amber-500 hover:bg-amber-50/50 dark:hover:bg-amber-950/20 flex items-center gap-3 transition"
              >
                <Folder className="text-amber-500 shrink-0" size={20} />
                <span className="text-sm font-medium text-slate-800 dark:text-slate-200 truncate">{c.nombre}</span>
              </button>
            ))
          )}
        </div>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 text-right">
          <button
            onClick={onCancelar}
            className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
};

interface DetallesDialogProps {
  nombreArchivo: string;
  nombreCarpeta: string;
  fechaTexto: string;
  tamanoTexto: string;
  dimensiones?: string;
  onCerrar: () => void;
}

export const DetallesDialog: React.FC<DetallesDialogProps> = ({
  nombreArchivo,
  nombreCarpeta,
  fechaTexto,
  tamanoTexto,
  dimensiones,
  onCerrar,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
            <Info size={22} />
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Detalles de la foto</h3>
          </div>
          <button onClick={onCerrar} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-3.5 text-sm">
          <div>
            <span className="text-xs uppercase font-semibold text-slate-400 block">Carpeta de Vehículo</span>
            <p className="font-semibold text-slate-800 dark:text-slate-200">{nombreCarpeta}</p>
          </div>
          <div>
            <span className="text-xs uppercase font-semibold text-slate-400 block">Fecha y Hora</span>
            <p className="text-slate-700 dark:text-slate-300 font-mono">{fechaTexto}</p>
          </div>
          <div>
            <span className="text-xs uppercase font-semibold text-slate-400 block">Tamaño de Archivo</span>
            <p className="text-slate-700 dark:text-slate-300 font-mono">{tamanoTexto}</p>
          </div>
          {dimensiones && (
            <div>
              <span className="text-xs uppercase font-semibold text-slate-400 block">Resolución</span>
              <p className="text-slate-700 dark:text-slate-300 font-mono">{dimensiones}</p>
            </div>
          )}
          <div>
            <span className="text-xs uppercase font-semibold text-slate-400 block">Nombre de Archivo</span>
            <p className="text-slate-600 dark:text-slate-400 font-mono text-xs break-all">{nombreArchivo}</p>
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 text-center">
          <button
            onClick={onCerrar}
            className="w-full py-2.5 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-xl transition shadow-sm"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
