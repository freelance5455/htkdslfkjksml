import React, { useState } from 'react';
import {
  Code,
  FileCode,
  Copy,
  Check,
  Shield,
  Layers,
  Terminal,
  Download,
  BookOpen,
  Cpu,
} from 'lucide-react';

export const FlutterCodeCenter: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<string>('pubspec.yaml');
  const [copied, setCopied] = useState<boolean>(false);

  const flutterFiles: Record<string, { language: string; description: string; code: string }> = {
    'pubspec.yaml': {
      language: 'yaml',
      description: 'Flutter project manifest with dependencies for BLoC, Firebase Auth, Firestore, Razorpay, and Cache',
      code: `name: pcmart_app
description: "PCMART — Premium Choice Mart (Har Choice, Premium Choice)"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.2.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  
  # State Management & Architecture
  flutter_bloc: ^8.1.3
  equatable: ^2.0.5

  # Firebase Suite for Auth & Firestore
  firebase_core: ^3.1.0
  firebase_auth: ^5.1.0
  cloud_firestore: ^5.0.1
  firebase_storage: ^12.0.1

  # Network & Approved Payments
  http: ^1.2.1
  razorpay_flutter: ^1.3.7
  crypto: ^3.0.3

  # UI, Media & Reels Player
  video_player: ^2.8.6
  cached_network_image: ^3.3.1
  google_fonts: ^6.2.1
  flutter_svg: ^2.0.10+1
  intl: ^0.19.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
  assets:
    - assets/images/
    - assets/icons/
`,
    },
    'lib/main.dart': {
      language: 'dart',
      description: 'Flutter entry point with Material 3 Theme (#1746A2 & #FFD447) and BLoC Providers',
      code: `import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'blocs/cart/cart_bloc.dart';
import 'blocs/auth/auth_bloc.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Firebase (Firebase.initializeApp)
  runApp(const PCMartApp());
}

class PCMartApp extends StatelessWidget {
  const PCMartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(create: (_) => AuthBloc()..add(CheckAuthSession())),
        BlocProvider<CartBloc>(create: (_) => CartBloc()),
      ],
      child: MaterialApp(
        title: 'PCMART',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF1746A2), // PCMART Royal Blue
            primary: const Color(0xFF1746A2),
            secondary: const Color(0xFFFFD447), // Premium Yellow
            surface: const Color(0xFF0F172A),
            background: const Color(0xFF020617),
          ),
          textTheme: GoogleFonts.plusJakartaSansTextTheme(
            ThemeData.dark().textTheme,
          ),
        ),
        home: const SplashScreen(),
      ),
    );
  }
}
`,
    },
    'firestore.rules': {
      language: 'javascript',
      description: 'Production Firestore Security Rules enforcing Multi-Vendor RBAC and Preventing Overselling',
      code: `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function isCustomer() {
      return isAuthenticated() && request.auth.token.role == 'CUSTOMER';
    }
    
    function isSeller(sellerId) {
      return isAuthenticated() && (request.auth.uid == sellerId || request.auth.token.role == 'SELLER');
    }
    
    function isAdmin() {
      return isAuthenticated() && request.auth.token.role == 'ADMIN';
    }

    // Public catalog read, seller-restricted write
    match /products/{productId} {
      allow read: if true; // Guest & customer browsing
      allow create: if isSeller(request.resource.data.sellerId);
      allow update: if isSeller(resource.data.sellerId) || isAdmin();
      allow delete: if isAdmin();
    }

    // Customer orders: Customer can only read own orders, sellers read items where sellerId matches
    match /orders/{orderId} {
      allow create: if isCustomer() && request.resource.data.customerId == request.auth.uid;
      allow read: if isAuthenticated() && (
        resource.data.customerId == request.auth.uid ||
        resource.data.sellerIds.hasAny([request.auth.uid]) ||
        isAdmin()
      );
      // Status update: Customers can only cancel before shipment
      allow update: if isAuthenticated() && (
        (resource.data.customerId == request.auth.uid && request.resource.data.status in ['CANCELLED', 'RETURN_REQUESTED']) ||
        (isSeller(request.auth.uid) && request.resource.data.status in ['PACKED', 'SHIPPED']) ||
        isAdmin()
      );
    }

    // Financial settlements: Strictly seller-read-own, admin full control
    match /settlements/{settlementId} {
      allow read: if isAuthenticated() && (resource.data.sellerId == request.auth.uid || isAdmin());
      allow write: if isAdmin();
    }

    // Audit logs: Append-only for system/admin, read-only for admin
    match /audit_logs/{logId} {
      allow read: if isAdmin();
      allow create: if isAuthenticated();
      allow update, delete: if false; // Immutable
    }
  }
}
`,
    },
    'lib/services/payment_service.dart': {
      language: 'dart',
      description: 'Approved Payment Gateway Service with HMAC SHA-256 Server Signature Verification',
      code: `import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';

class PaymentService {
  static const String baseUrl = 'https://api.pcmart.in/api';

  /// Pre-creates order on secure backend to reserve stock and receive HMAC token
  static Future<Map<String, dynamic>> initiateOrder({
    required String orderId,
    required double amount,
    required String customerId,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/checkout/create-order'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'orderId': orderId,
        'amount': amount,
        'currency': 'INR',
        'customerId': customerId,
      }),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Payment initialization failed: \${response.body}');
    }
  }

  /// Verifies payment signature server-side before confirming fulfillment
  static Future<bool> verifyPaymentSignature({
    required String orderId,
    required String paymentId,
    required String signature,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/checkout/verify-payment'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'orderId': orderId,
        'paymentId': paymentId,
        'signature': signature,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['verified'] == true;
    }
    return false;
  }
}
`,
    },
    'android/app/build.gradle': {
      language: 'groovy',
      description: 'Android App Build Configuration for Google Play Store Release',
      code: `plugins {
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
    id "com.google.gms.google-services"
}

android {
    namespace = "in.pcmart.app"
    compileSdk = 34
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    defaultConfig {
        applicationId = "in.pcmart.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        multiDexEnabled = true
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.debug
            minifyEnabled = true
            shrinkResources = true
            proguardFiles getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro"
        }
    }
}
`,
    },
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(flutterFiles[selectedFile].code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 overflow-y-auto">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5 text-[#FFD447]" />
            <h1 className="text-xl font-black text-white">Flutter & Backend Architecture Center</h1>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Complete Android codebase, BLoC state management, Firestore security rules, and HMAC payment gateway integration.
          </p>
        </div>

        <button
          onClick={handleCopyCode}
          className="px-4 py-2 bg-[#1746A2] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1.5 transition-all"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          {copied ? 'Copied to Clipboard!' : 'Copy Current File'}
        </button>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-4 gap-6 flex-1">
        {/* File tree sidebar */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2 h-fit">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
            Flutter Project Tree
          </span>
          {Object.entries(flutterFiles).map(([filename, meta]) => (
            <button
              key={filename}
              onClick={() => setSelectedFile(filename)}
              className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-center justify-between ${
                selectedFile === filename
                  ? 'bg-[#1746A2] text-white font-bold shadow'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span className="flex items-center gap-2 truncate">
                <FileCode className="w-3.5 h-3.5 shrink-0" />
                {filename}
              </span>
            </button>
          ))}

          {/* Android build instructions card */}
          <div className="mt-4 pt-4 border-t border-slate-800 text-[11px] text-slate-400 space-y-2">
            <span className="font-bold text-white block">CLI Build Instructions:</span>
            <div className="bg-slate-950 p-2.5 rounded-lg font-mono text-[10px] text-emerald-400 space-y-1">
              <div># 1. Fetch dependencies</div>
              <div className="text-white">flutter pub get</div>
              <div className="pt-1"># 2. Build Android APK</div>
              <div className="text-white">flutter build apk --release</div>
            </div>
          </div>
        </div>

        {/* Code viewer */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col overflow-hidden">
          <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-[#FFD447]">{selectedFile}</span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-400">{flutterFiles[selectedFile].description}</span>
            </div>
            <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-900 px-2 py-0.5 rounded">
              {flutterFiles[selectedFile].language}
            </span>
          </div>

          <div className="flex-1 p-4 bg-slate-950 overflow-x-auto font-mono text-xs text-slate-300 leading-relaxed max-h-[600px] overflow-y-auto">
            <pre>
              <code>{flutterFiles[selectedFile].code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
