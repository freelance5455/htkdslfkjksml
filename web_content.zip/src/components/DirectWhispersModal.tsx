import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Send, 
  Lock 
} from 'lucide-react';

export const DirectWhispersModal: React.FC = () => {
  const { 
    isDirectWhisperModalOpen, 
    setIsDirectWhisperModalOpen, 
    activeWhisperPartner, 
    whispers, 
    sendDirectWhisper 
  } = useApp();

  const [inputMsg, setInputMsg] = useState('');

  if (!isDirectWhisperModalOpen || !activeWhisperPartner) return null;

  const currentConv = whispers.find(w => w.confessionId === activeWhisperPartner.confessionId);
  const messages = currentConv?.messages || [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;
    sendDirectWhisper(activeWhisperPartner.confessionId, inputMsg);
    setInputMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#0e111d] border border-indigo-500/40 rounded-3xl shadow-2xl shadow-indigo-950/40 flex flex-col h-[520px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Header */}
        <div className="p-3.5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-indigo-950 border border-indigo-500/50 flex items-center justify-center text-lg">
              {activeWhisperPartner.authorEmoji}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-xs text-slate-100">
                  {activeWhisperPartner.authorName}
                </span>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-1 py-0.2 rounded border border-cyan-500/30">
                  ANON DM
                </span>
              </div>
              <p className="text-[10px] text-slate-400 line-clamp-1 italic max-w-[220px]">
                "{activeWhisperPartner.snippet}"
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsDirectWhisperModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Security Banner */}
        <div className="px-3 py-1.5 bg-indigo-950/30 border-b border-indigo-500/20 text-[10px] text-indigo-300 flex items-center justify-center gap-1.5">
          <Lock className="w-3 h-3 text-cyan-400" />
          <span>Both parties are anonymous. Neither of you can reveal real identities.</span>
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0a0c14]/50">
          {messages.length === 0 ? (
            <div className="text-center py-10 space-y-2">
              <span className="text-3xl block">🤫</span>
              <p className="text-xs font-semibold text-slate-300">
                Start an Anonymous Direct Whisper
              </p>
              <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                Reach out privately to the author of this confession without either of you exposing who you are.
              </p>
            </div>
          ) : (
            messages.map(m => (
              <div 
                key={m.id}
                className={`flex items-start gap-2 ${m.sender === 'me' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] rounded-2xl p-3 text-xs ${
                  m.sender === 'me' 
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white rounded-tr-none' 
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}>
                  <p className="leading-relaxed font-sans">{m.text}</p>
                  <span className={`text-[9px] block mt-1 ${m.sender === 'me' ? 'text-cyan-200 text-right' : 'text-slate-500'}`}>
                    {m.timestamp}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center gap-2">
          <input
            type="text"
            value={inputMsg}
            onChange={(e) => setInputMsg(e.target.value)}
            placeholder="Send an anonymous whisper..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
          />
          <button
            type="submit"
            disabled={!inputMsg.trim()}
            className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-40 transition-all shrink-0 active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
