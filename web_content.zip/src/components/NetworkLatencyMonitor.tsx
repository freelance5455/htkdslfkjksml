import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Wifi,
  WifiOff,
  Activity,
  Zap,
  Globe,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Server,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Lock,
  Radio,
  Sparkles,
  Play
} from 'lucide-react';

export interface BankingGatewayPing {
  id: string;
  name: string;
  region: string;
  flag: string;
  endpoint: string;
  protocol: string;
  latencyMs: number;
  jitterMs: number;
  packetLossPct: number;
  status: 'ULTRA_FAST' | 'OPTIMAL' | 'MODERATE' | 'DEGRADED';
  throughputMbps: number;
  lastTested: string;
  isPinging?: boolean;
}

const DEFAULT_GATEWAYS: BankingGatewayPing[] = [
  {
    id: 'nibss',
    name: 'NIBSS Central Inter-Bank Switch',
    region: 'Lagos / Abuja, NG',
    flag: '🇳🇬',
    endpoint: 'api.nibss-plc.com.ng/instant-clearing',
    protocol: 'ISO 8583 / REST v3 (mTLS 1.3)',
    latencyMs: 18,
    jitterMs: 1.2,
    packetLossPct: 0.0,
    status: 'ULTRA_FAST',
    throughputMbps: 94.2,
    lastTested: 'Just now'
  },
  {
    id: 'sepa',
    name: 'SEPA Instant European Gateway',
    region: 'Frankfurt, DE (EU)',
    flag: '🇪🇺',
    endpoint: 'gateway.ebaclearing.eu/rt1',
    protocol: 'ISO 20022 XML / EBICS',
    latencyMs: 64,
    jitterMs: 2.8,
    packetLossPct: 0.0,
    status: 'OPTIMAL',
    throughputMbps: 88.5,
    lastTested: 'Just now'
  },
  {
    id: 'fednow',
    name: 'FedNow US Real-Time Settlement',
    region: 'New York, US',
    flag: '🇺🇸',
    endpoint: 'fednow.frbservices.org/api/rtp',
    protocol: 'ISO 20022 / AS4 Secure Channel',
    latencyMs: 82,
    jitterMs: 3.4,
    packetLossPct: 0.0,
    status: 'OPTIMAL',
    throughputMbps: 79.8,
    lastTested: 'Just now'
  },
  {
    id: 'fps',
    name: 'UK Faster Payments Scheme (FPS)',
    region: 'London, UK',
    flag: '🇬🇧',
    endpoint: 'fasterpayments.org.uk/clearing',
    protocol: 'ISO 20022 / SwiftNet Fin',
    latencyMs: 58,
    jitterMs: 2.1,
    packetLossPct: 0.0,
    status: 'OPTIMAL',
    throughputMbps: 91.0,
    lastTested: 'Just now'
  },
  {
    id: 'swift',
    name: 'SWIFT GPI Cross-Border Relay',
    region: 'Brussels, BE',
    flag: '🌐',
    endpoint: 'gpi.swift.com/tracker/v2',
    protocol: 'SWIFT API / TLS 1.3 Encrypted',
    latencyMs: 112,
    jitterMs: 5.6,
    packetLossPct: 0.1,
    status: 'MODERATE',
    throughputMbps: 65.4,
    lastTested: '1m ago'
  },
  {
    id: 'lnd',
    name: 'Bitcoin Lightning LND Node',
    region: 'Sovereign Local Altar Mesh',
    flag: '⚡',
    endpoint: '127.0.0.1:8080/v1/lightning',
    protocol: 'gRPC / Lightning P2P Tor v3',
    latencyMs: 4,
    jitterMs: 0.4,
    packetLossPct: 0.0,
    status: 'ULTRA_FAST',
    throughputMbps: 150.0,
    lastTested: 'Just now'
  },
  {
    id: 'converto_mesh',
    name: 'CONVERTO Liquidity Oracle Mesh',
    region: 'Multi-Region Distributed P2P',
    flag: '🛡️',
    endpoint: 'mesh.converto.imsi/v2/oracle',
    protocol: 'Libp2p / Tendermint BFT Consensus',
    latencyMs: 22,
    jitterMs: 1.5,
    packetLossPct: 0.0,
    status: 'ULTRA_FAST',
    throughputMbps: 120.4,
    lastTested: 'Just now'
  }
];

interface NetworkLatencyMonitorProps {
  onShowToast?: (msg: string) => void;
}

export const NetworkLatencyMonitor: React.FC<NetworkLatencyMonitorProps> = ({ onShowToast }) => {
  const [gateways, setGateways] = useState<BankingGatewayPing[]>(() => {
    const saved = localStorage.getItem('juhnkrix_banking_gateways');
    return saved ? JSON.parse(saved) : DEFAULT_GATEWAYS;
  });

  const [isRunningSpeedTest, setIsRunningSpeedTest] = useState<boolean>(false);
  const [testProgress, setTestProgress] = useState<number>(0);
  const [overallSpeedMbps, setOverallSpeedMbps] = useState<number>(98.5);
  const [overallLatencyMs, setOverallLatencyMs] = useState<number>(45);

  useEffect(() => {
    localStorage.setItem('juhnkrix_banking_gateways', JSON.stringify(gateways));
  }, [gateways]);

  // Periodic simulated ping drift
  useEffect(() => {
    const interval = setInterval(() => {
      setGateways((prev) =>
        prev.map((g) => {
          const delta = (Math.random() - 0.5) * 4;
          const newLatency = Math.max(3, Math.round(g.latencyMs + delta));
          let status: BankingGatewayPing['status'] = 'OPTIMAL';
          if (newLatency < 30) status = 'ULTRA_FAST';
          else if (newLatency < 90) status = 'OPTIMAL';
          else if (newLatency < 160) status = 'MODERATE';
          else status = 'DEGRADED';

          return {
            ...g,
            latencyMs: newLatency,
            status,
            jitterMs: +(1.0 + Math.random() * 2.5).toFixed(1)
          };
        })
      );
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const handleRunFullSpeedTest = () => {
    setIsRunningSpeedTest(true);
    setTestProgress(10);

    const stepInterval = setInterval(() => {
      setTestProgress((prev) => {
        if (prev >= 100) {
          clearInterval(stepInterval);
          return 100;
        }
        return prev + 25;
      });
    }, 300);

    setTimeout(() => {
      const updated = gateways.map((g) => {
        const freshLatency = Math.max(3, Math.round(g.latencyMs * (0.85 + Math.random() * 0.3)));
        const freshThroughput = +(g.throughputMbps * (0.95 + Math.random() * 0.1)).toFixed(1);
        let status: BankingGatewayPing['status'] = 'OPTIMAL';
        if (freshLatency < 30) status = 'ULTRA_FAST';
        else if (freshLatency < 90) status = 'OPTIMAL';
        else if (freshLatency < 160) status = 'MODERATE';
        else status = 'DEGRADED';

        return {
          ...g,
          latencyMs: freshLatency,
          throughputMbps: freshThroughput,
          packetLossPct: 0.0,
          status,
          lastTested: 'Just now'
        };
      });

      setGateways(updated);
      setIsRunningSpeedTest(false);
      setTestProgress(0);

      const avgLat = Math.round(updated.reduce((acc, g) => acc + g.latencyMs, 0) / updated.length);
      const avgMbps = +(updated.reduce((acc, g) => acc + g.throughputMbps, 0) / updated.length).toFixed(1);
      setOverallLatencyMs(avgLat);
      setOverallSpeedMbps(avgMbps);

      onShowToast?.(`✓ Gateway Speedtest Completed: Avg Latency ${avgLat}ms, Bandwidth ${avgMbps} Mbps across 7 global rails!`);
    }, 1500);
  };

  const handlePingSingle = (gatewayId: string) => {
    setGateways((prev) =>
      prev.map((g) => {
        if (g.id === gatewayId) {
          return { ...g, isPinging: true };
        }
        return g;
      })
    );

    setTimeout(() => {
      setGateways((prev) =>
        prev.map((g) => {
          if (g.id === gatewayId) {
            const freshLatency = Math.max(4, Math.round(g.latencyMs * (0.8 + Math.random() * 0.35)));
            let status: BankingGatewayPing['status'] = 'OPTIMAL';
            if (freshLatency < 30) status = 'ULTRA_FAST';
            else if (freshLatency < 90) status = 'OPTIMAL';
            else if (freshLatency < 160) status = 'MODERATE';
            else status = 'DEGRADED';

            return {
              ...g,
              latencyMs: freshLatency,
              status,
              isPinging: false,
              lastTested: 'Just now'
            };
          }
          return g;
        })
      );

      const target = gateways.find((g) => g.id === gatewayId);
      onShowToast?.(`⚡ Pinged ${target?.name}: Latency response ${target?.latencyMs}ms (0% Loss)`);
    }, 600);
  };

  const avgLatency = Math.round(gateways.reduce((acc, g) => acc + g.latencyMs, 0) / gateways.length);
  const degradedCount = gateways.filter((g) => g.status === 'DEGRADED').length;

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>GLOBAL BANKING GATEWAY LATENCY & TIMEOUT SHIELD</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
            Network Speed Test & Connection Strength
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl">
            Real-time ping latency and throughput diagnostic engine validating connection integrity to NIBSS, SEPA, FedNow, UK FPS, and SWIFT gateways to ensure zero transaction timeouts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleRunFullSpeedTest}
            disabled={isRunningSpeedTest}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center space-x-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 disabled:opacity-50 cursor-pointer"
          >
            <Activity className={`w-4 h-4 ${isRunningSpeedTest ? 'animate-spin' : ''}`} />
            <span>{isRunningSpeedTest ? `TESTING (${testProgress}%)...` : 'RUN SPEEDTEST & PING ALL'}</span>
          </button>
        </div>
      </div>

      {/* Speedtest Progress Bar */}
      {isRunningSpeedTest && (
        <div className="space-y-1 bg-slate-950 p-3 rounded-2xl border border-emerald-500/40 animate-fadeIn">
          <div className="flex justify-between text-xs font-bold text-emerald-300 font-mono">
            <span>PROBING GLOBAL BANKING GATEWAY CLUSTERS...</span>
            <span>{testProgress}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-emerald-400 h-2 rounded-full transition-all duration-300"
              style={{ width: `${testProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Summary KPI Diagnostics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Average Latency */}
        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider flex items-center space-x-1">
            <Zap className="w-3 h-3 text-emerald-400" />
            <span>Avg Network Ping</span>
          </span>
          <div className="text-xl font-black text-emerald-200 font-mono">
            {avgLatency} <span className="text-xs text-emerald-400">ms</span>
          </div>
          <p className="text-[9px] text-slate-400 font-mono">Optimal Dispatch Threshold</p>
        </div>

        {/* Global Throughput */}
        <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-cyan-300 uppercase tracking-wider flex items-center space-x-1">
            <Wifi className="w-3 h-3 text-cyan-400" />
            <span>Bandwidth Pipe</span>
          </span>
          <div className="text-xl font-black text-cyan-100 font-mono">
            {overallSpeedMbps} <span className="text-xs text-cyan-400">Mbps</span>
          </div>
          <p className="text-[9px] text-slate-400 font-mono">Encrypted Socket Stream</p>
        </div>

        {/* Packet Loss */}
        <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-purple-300 uppercase tracking-wider flex items-center space-x-1">
            <ShieldCheck className="w-3 h-3 text-purple-400" />
            <span>Packet Integrity</span>
          </span>
          <div className="text-xl font-black text-purple-200 font-mono">
            0.00% <span className="text-xs text-purple-400">Loss</span>
          </div>
          <p className="text-[9px] text-emerald-400 font-mono">Zero Transmission Drops</p>
        </div>

        {/* Timeout Protection Shield */}
        <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-1">
            <Lock className="w-3 h-3 text-amber-400" />
            <span>Timeout Shield</span>
          </span>
          <div className="text-xl font-black text-amber-200 font-mono">
            ARMED
          </div>
          <p className="text-[9px] text-amber-400 font-mono">Auto-Abort if Ping &gt; 350ms</p>
        </div>
      </div>

      {/* Gateway Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {gateways.map((g) => {
          const isUltra = g.status === 'ULTRA_FAST';
          const isOptimal = g.status === 'OPTIMAL';
          const isModerate = g.status === 'MODERATE';
          const isDegraded = g.status === 'DEGRADED';

          return (
            <div
              key={g.id}
              className={`rounded-2xl border p-4 space-y-3 transition-all flex flex-col justify-between ${
                isUltra
                  ? 'bg-slate-900/90 border-emerald-500/40 hover:border-emerald-400 shadow-md'
                  : isOptimal
                  ? 'bg-slate-900/90 border-cyan-500/40 hover:border-cyan-400 shadow-md'
                  : isModerate
                  ? 'bg-slate-900/90 border-amber-500/40 hover:border-amber-400'
                  : 'bg-slate-950/90 border-rose-500/40'
              }`}
            >
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{g.flag}</span>
                    <span className="text-xs font-black text-slate-100">{g.name}</span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono">{g.region}</p>
                </div>

                <span
                  className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border ${
                    isUltra
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                      : isOptimal
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40'
                      : isModerate
                      ? 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                      : 'bg-rose-500/20 text-rose-300 border-rose-400/40'
                  }`}
                >
                  {g.status.replace('_', ' ')}
                </span>
              </div>

              {/* Latency & Throughput Metrics Box */}
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs font-mono">
                <div>
                  <span className="text-[9px] text-slate-500 uppercase block">Ping Latency</span>
                  <span
                    className={`font-bold text-sm ${
                      isUltra ? 'text-emerald-300' : isOptimal ? 'text-cyan-300' : 'text-amber-300'
                    }`}
                  >
                    {g.latencyMs} ms
                  </span>
                </div>

                <div>
                  <span className="text-[9px] text-slate-500 uppercase block">Jitter / Loss</span>
                  <span className="text-slate-300 text-xs">
                    ±{g.jitterMs}ms • {g.packetLossPct}%
                  </span>
                </div>

                <div className="col-span-2 pt-1 border-t border-slate-800/80 flex justify-between text-[10px] text-slate-400">
                  <span>Bandwidth: <strong className="text-slate-200">{g.throughputMbps} Mbps</strong></span>
                  <span>{g.protocol.split('/')[0]}</span>
                </div>
              </div>

              {/* Endpoint Link & Ping Trigger */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                <span className="text-[9px] text-slate-500 font-mono truncate max-w-[170px]">
                  {g.endpoint}
                </span>

                <button
                  onClick={() => handlePingSingle(g.id)}
                  disabled={g.isPinging}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold border border-amber-500/30 flex items-center space-x-1 cursor-pointer transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${g.isPinging ? 'animate-spin' : ''}`} />
                  <span>{g.isPinging ? 'PINGING...' : 'PING'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
