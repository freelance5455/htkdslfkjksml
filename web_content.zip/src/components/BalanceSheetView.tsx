import React, { useState } from 'react';
import { Scale, CheckCircle2, ChevronDown, ChevronRight, Layers, ArrowRight, ShieldCheck } from 'lucide-react';
import { Ledger, StockItem } from '../types/tally';
import { computeBalanceSheet, formatCurrency } from '../utils/tallyEngine';
import { triggerHaptic } from '../utils/haptics';

interface BalanceSheetViewProps {
  ledgers: Ledger[];
  stockItems: StockItem[];
  onSelectLedger?: (ledgerId: string) => void;
}

export const BalanceSheetView: React.FC<BalanceSheetViewProps> = ({
  ledgers,
  stockItems,
  onSelectLedger,
}) => {
  const [activeTab, setActiveTab] = useState<'both' | 'liabilities' | 'assets'>('both');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    capital: true,
    creditors: true,
    debtors: true,
    banks: true,
  });

  const bs = computeBalanceSheet(ledgers, stockItems);

  const toggleExpand = (section: string) => {
    triggerHaptic('light');
    setExpandedSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  return (
    <div className="flex-1 flex flex-col pb-8 text-slate-800 dark:text-slate-100">
      {/* Header bar */}
      <div className="bg-emerald-900 text-white px-4 py-3 shadow-xs">
        <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
          Final Accounts
        </div>
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold">Balance Sheet (Financial Position)</h2>
          <div className="flex items-center gap-1 text-[11px] bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
            <span>As on 31-Mar-2027</span>
          </div>
        </div>
      </div>

      {/* Verification & Working Capital Banner */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-1.5 font-bold text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>Balance Sheet Matched</span>
          </div>
          <span className="text-slate-500">
            Working Capital: <strong className="text-slate-900 dark:text-white">{formatCurrency(bs.workingCapital)}</strong>
          </span>
        </div>

        {/* Tab switch for mobile */}
        <div className="grid grid-cols-3 gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveTab('both')}
            className={`py-1 rounded-lg transition-colors ${
              activeTab === 'both' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs font-semibold' : 'text-slate-500'
            }`}
          >
            All Columns
          </button>
          <button
            onClick={() => setActiveTab('liabilities')}
            className={`py-1 rounded-lg transition-colors ${
              activeTab === 'liabilities' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs font-semibold' : 'text-slate-500'
            }`}
          >
            Liabilities ({formatCurrency(bs.totalLiabilities)})
          </button>
          <button
            onClick={() => setActiveTab('assets')}
            className={`py-1 rounded-lg transition-colors ${
              activeTab === 'assets' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs font-semibold' : 'text-slate-500'
            }`}
          >
            Assets ({formatCurrency(bs.totalAssets)})
          </button>
        </div>
      </div>

      <div className="p-3 space-y-4">
        {/* LIABILITIES SECTION */}
        {(activeTab === 'both' || activeTab === 'liabilities') && (
          <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
            <div className="px-3 py-2 bg-slate-100 dark:bg-slate-800 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200">
              <span>Liabilities & Equities</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
                {formatCurrency(bs.totalLiabilities)}
              </span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs">
              {/* Capital Account */}
              <div className="p-3 space-y-1.5">
                <div
                  onClick={() => toggleExpand('capital')}
                  className="flex items-center justify-between cursor-pointer font-semibold text-slate-900 dark:text-white"
                >
                  <div className="flex items-center gap-1.5">
                    {expandedSections.capital ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                    <span>Capital Account (Net Worth)</span>
                  </div>
                  <span className="font-mono tabular-nums">{formatCurrency(bs.capital.totalCapital)}</span>
                </div>

                {expandedSections.capital && (
                  <div className="pl-5 space-y-1 text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                    <div className="flex justify-between">
                      <span>Opening Equity:</span>
                      <span>{formatCurrency(bs.capital.baseAmount)}</span>
                    </div>
                    <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                      <span>Add: Profit for the Year (P&L):</span>
                      <span>+{formatCurrency(bs.capital.netProfitAddition)}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Loans (Liability) */}
              {bs.loansLiability > 0 && (
                <div className="p-3 flex items-center justify-between font-semibold">
                  <span>Loans (Liability)</span>
                  <span className="font-mono tabular-nums">{formatCurrency(bs.loansLiability)}</span>
                </div>
              )}

              {/* Current Liabilities */}
              <div className="p-3 space-y-2">
                <div className="flex items-center justify-between font-bold text-slate-800 dark:text-slate-200">
                  <span>Current Liabilities</span>
                  <span className="font-mono tabular-nums">{formatCurrency(bs.currentLiabilities.total)}</span>
                </div>

                {/* Sundry Creditors drilldown */}
                <div className="pl-3 space-y-1">
                  <div
                    onClick={() => toggleExpand('creditors')}
                    className="flex items-center justify-between text-slate-600 dark:text-slate-300 cursor-pointer font-medium"
                  >
                    <div className="flex items-center gap-1">
                      {expandedSections.creditors ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                      <span>Sundry Creditors (Suppliers)</span>
                    </div>
                    <span className="font-mono tabular-nums">{formatCurrency(bs.currentLiabilities.sundryCreditors)}</span>
                  </div>

                  {expandedSections.creditors && (
                    <div className="pl-4 space-y-1 text-[11px] font-mono text-slate-500">
                      {bs.currentLiabilities.creditorsList.map((c, i) => (
                        <div key={i} className="flex justify-between py-0.5">
                          <span>{c.name}</span>
                          <span className="tabular-nums">{formatCurrency(c.amount)}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Duties & Taxes */}
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-300 font-medium pt-1">
                    <span>Duties & Taxes (Net GST Payable)</span>
                    <span className="font-mono tabular-nums">{formatCurrency(bs.currentLiabilities.dutiesAndTaxes)}</span>
                  </div>
                </div>
              </div>

              {/* Liabilities Total */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 flex items-center justify-between font-bold text-sm text-slate-900 dark:text-white">
                <span>TOTAL LIABILITIES</span>
                <span className="font-mono tabular-nums">{formatCurrency(bs.totalLiabilities)}</span>
              </div>
            </div>
          </div>
        )}

        {/* ASSETS SECTION */}
        {(activeTab === 'both' || activeTab === 'assets') && (
          <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
            <div className="px-3 py-2 bg-slate-100 dark:bg-slate-800 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200">
              <span>Assets & Resources</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
                {formatCurrency(bs.totalAssets)}
              </span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs">
              {/* Fixed Assets */}
              <div className="p-3 space-y-1.5">
                <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white">
                  <span>Fixed Assets</span>
                  <span className="font-mono tabular-nums">{formatCurrency(bs.fixedAssets.total)}</span>
                </div>
                <div className="pl-4 space-y-0.5 text-[11px] font-mono text-slate-500">
                  {bs.fixedAssets.list.map((fa, i) => (
                    <div key={i} className="flex justify-between">
                      <span>{fa.name}</span>
                      <span className="tabular-nums">{formatCurrency(fa.amount)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Current Assets */}
              <div className="p-3 space-y-2">
                <div className="flex items-center justify-between font-bold text-slate-800 dark:text-slate-200">
                  <span>Current Assets</span>
                  <span className="font-mono tabular-nums">{formatCurrency(bs.currentAssets.total)}</span>
                </div>

                <div className="pl-3 space-y-1.5">
                  {/* Closing Stock */}
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-300 font-medium">
                    <span>Closing Stock (Valuation)</span>
                    <span className="font-mono tabular-nums">{formatCurrency(bs.currentAssets.closingStock)}</span>
                  </div>

                  {/* Sundry Debtors */}
                  <div>
                    <div
                      onClick={() => toggleExpand('debtors')}
                      className="flex items-center justify-between text-slate-600 dark:text-slate-300 cursor-pointer font-medium"
                    >
                      <div className="flex items-center gap-1">
                        {expandedSections.debtors ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                        <span>Sundry Debtors (Receivables)</span>
                      </div>
                      <span className="font-mono tabular-nums">{formatCurrency(bs.currentAssets.sundryDebtors)}</span>
                    </div>

                    {expandedSections.debtors && (
                      <div className="pl-4 space-y-1 text-[11px] font-mono text-slate-500 mt-1">
                        {bs.currentAssets.debtorsList.map((d, i) => (
                          <div key={i} className="flex justify-between py-0.5">
                            <span>{d.name}</span>
                            <span className="tabular-nums">{formatCurrency(d.amount)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Bank Accounts */}
                  <div>
                    <div
                      onClick={() => toggleExpand('banks')}
                      className="flex items-center justify-between text-slate-600 dark:text-slate-300 cursor-pointer font-medium"
                    >
                      <div className="flex items-center gap-1">
                        {expandedSections.banks ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                        <span>Bank Accounts</span>
                      </div>
                      <span className="font-mono tabular-nums">{formatCurrency(bs.currentAssets.bankAccounts)}</span>
                    </div>

                    {expandedSections.banks && (
                      <div className="pl-4 space-y-1 text-[11px] font-mono text-slate-500 mt-1">
                        {bs.currentAssets.banksList.map((b, i) => (
                          <div key={i} className="flex justify-between py-0.5">
                            <span>{b.name}</span>
                            <span className="tabular-nums">{formatCurrency(b.amount)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Cash in hand */}
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-300 font-medium">
                    <span>Cash-in-hand</span>
                    <span className="font-mono tabular-nums">{formatCurrency(bs.currentAssets.cashInHand)}</span>
                  </div>
                </div>
              </div>

              {/* Assets Total */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 flex items-center justify-between font-bold text-sm text-slate-900 dark:text-white">
                <span>TOTAL ASSETS</span>
                <span className="font-mono tabular-nums">{formatCurrency(bs.totalAssets)}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
