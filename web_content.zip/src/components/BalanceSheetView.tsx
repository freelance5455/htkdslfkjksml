import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { t, formatCurrency, formatDateDisplay } from '../utils/translations';
import { calculateLoanDetailed } from '../utils/interestCalculator';
import {
  Printer,
  Scale,
  TrendingUp,
  TrendingDown,
  Building,
  Wallet,
  ShieldCheck,
  Calendar,
  Sparkles,
  ArrowRight,
  PieChart,
  Download
} from 'lucide-react';
import { DownloadAppModal } from './Modals/DownloadAppModal';

export const BalanceSheetView: React.FC = () => {
  const { language, accounts, getAccountBalance, loans, transactions, categories } = useApp();

  const [asOfDate, setAsOfDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // 1. Assets Calculation
  // 1a. Cash & Bank
  const cashAccounts = accounts.filter((a) => a.type === 'cash');
  const bankAccounts = accounts.filter((a) => a.type === 'bank' || a.type === 'wallet');

  const totalCashBalance = cashAccounts.reduce((sum, a) => sum + getAccountBalance(a.id), 0);
  const totalBankBalance = bankAccounts.reduce((sum, a) => sum + getAccountBalance(a.id), 0);
  const totalLiquidAssets = totalCashBalance + totalBankBalance;

  // 1b. Money Lent (Assets)
  const lentLoans = loans.filter((l) => l.type === 'lent' && l.status === 'active');
  const lentCalculations = lentLoans.map((l) => ({
    loan: l,
    calc: calculateLoanDetailed(l, asOfDate)
  }));

  const totalLentPrincipal = lentCalculations.reduce((sum, item) => sum + item.calc.currentPrincipal, 0);
  const totalLentAccruedInterest = lentCalculations.reduce(
    (sum, item) => sum + item.calc.currentAccruedInterest,
    0
  );
  const totalLentAssetValue = totalLentPrincipal + totalLentAccruedInterest;

  const totalAssets = totalLiquidAssets + totalLentAssetValue;

  // 2. Liabilities Calculation
  // 2a. Money Borrowed (Liabilities)
  const borrowedLoans = loans.filter((l) => l.type === 'borrowed' && l.status === 'active');
  const borrowedCalculations = borrowedLoans.map((l) => ({
    loan: l,
    calc: calculateLoanDetailed(l, asOfDate)
  }));

  const totalBorrowedPrincipal = borrowedCalculations.reduce(
    (sum, item) => sum + item.calc.currentPrincipal,
    0
  );
  const totalBorrowedAccruedInterest = borrowedCalculations.reduce(
    (sum, item) => sum + item.calc.currentAccruedInterest,
    0
  );
  const totalLiabilities = totalBorrowedPrincipal + totalBorrowedAccruedInterest;

  // 3. Net Worth / Pure Capital
  const netWorth = totalAssets - totalLiabilities;

  // 4. Income & Expense Aggregates
  const totalIncome = transactions
    .filter((tx) => tx.type === 'income')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const totalExpense = transactions
    .filter((tx) => tx.type === 'expense')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const netSavings = totalIncome - totalExpense;

  // Category-wise expense breakdown
  const categoryExpenses = categories
    .filter((c) => c.type === 'expense')
    .map((cat) => {
      const spent = transactions
        .filter((tx) => tx.categoryId === cat.id && tx.type === 'expense')
        .reduce((sum, tx) => sum + tx.amount, 0);
      return {
        category: cat,
        amount: spent,
        percentage: totalExpense > 0 ? (spent / totalExpense) * 100 : 0
      };
    })
    .filter((c) => c.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-stone-200 shadow-sm print-hide">
        <div className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-amber-700" />
          <div>
            <h2 className="text-base font-bold text-stone-900">
              {t('balanceSheetTitle', language)}
            </h2>
            <p className="text-xs text-stone-500">
              {language === 'gu'
                ? 'સંપૂર્ણ સંપત્તિ, દેવું, રોકડ-બેંક અને વ્યાજ સહિતનું પાકું સરવૈયું'
                : 'Complete Statement of Assets, Liabilities, Vyaj & Net Capital'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-stone-600 bg-stone-50 px-3 py-1.5 rounded-xl border border-stone-200">
            <span>તારીખ સુધી:</span>
            <input
              type="date"
              value={asOfDate}
              onChange={(e) => setAsOfDate(e.target.value)}
              className="bg-transparent font-semibold text-stone-900 focus:outline-none"
            />
          </div>

          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-900 hover:bg-red-800 text-amber-100 text-xs font-bold transition-all shadow-md"
          >
            <Printer className="w-4 h-4" />
            <span>{t('print', language)}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsDownloadModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>APK / EXE</span>
          </button>
        </div>
      </div>

      {/* Printable Comprehensive Balance Sheet Document */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-md overflow-hidden khatavahi-print-sheet">
        {/* Traditional Auspicious Letterhead */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-stone-950 text-white p-6 text-center border-b-2 border-amber-500">
          <div className="text-xs font-bold tracking-widest text-amber-300">
            || શ્રી ગણેશાય નમઃ || શ્રી લક્ષ્મીનારાયણાય નમઃ || શ્રી સવા ૧ ||
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-amber-100 mt-1 tracking-tight">
            {language === 'gu' ? 'વાર્ષિક પાકું સરવૈયું (બેલેન્સ શીટ)' : 'Comprehensive Khatavahi Balance Sheet'}
          </h1>
          <p className="text-xs text-amber-200/80 mt-1">
            તારીખ: {formatDateDisplay(asOfDate, language)} સુધીની સ્થિતિ
          </p>
        </div>

        {/* Executive Highlights (Net Worth Badge) */}
        <div className="p-4 sm:p-6 bg-amber-50/60 border-b border-amber-200/70 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
          <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-2xs">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block">
              {t('assets', language)} (કુલ સંપત્તિ)
            </span>
            <p className="text-xl sm:text-2xl font-black text-emerald-700 mt-1">
              {formatCurrency(totalAssets, language)}
            </p>
            <span className="text-[11px] text-stone-500 mt-1 block">
              રોકડ/બેંક + ધીરેલ નાણાં વ્યાજ સહિત
            </span>
          </div>

          <div className="bg-white p-4 rounded-xl border border-rose-200 shadow-2xs">
            <span className="text-xs font-bold text-rose-800 uppercase tracking-wider block">
              {t('liabilities', language)} (કુલ દેવું)
            </span>
            <p className="text-xl sm:text-2xl font-black text-rose-700 mt-1">
              {formatCurrency(totalLiabilities, language)}
            </p>
            <span className="text-[11px] text-stone-500 mt-1 block">
              લીધેલ રકમ + ચડેલ વ્યાજ જવાબદારી
            </span>
          </div>

          <div className="bg-gradient-to-br from-red-950 to-stone-900 text-white p-4 rounded-xl border border-amber-500/50 shadow-md">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-wider block">
              {t('netWorth', language)}
            </span>
            <p className="text-xl sm:text-2xl font-black text-amber-400 mt-1">
              {formatCurrency(netWorth, language)}
            </p>
            <span className="text-[11px] text-amber-200/80 mt-1 block">
              {netWorth >= 0 ? 'ચોખ્ખી શુદ્ધ સંપત્તિ' : 'ચોખ્ખી ખોટ / ઋણ'}
            </span>
          </div>
        </div>

        {/* Two-Column Ledger Balance Sheet (Assets vs Liabilities) */}
        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-stone-200">
          {/* LEFT: Assets (લેણું / મિલકતો) */}
          <div className="p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b-2 border-emerald-600">
              <h3 className="text-sm font-black text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span>{t('assets', language)}</span>
              </h3>
              <span className="text-sm font-black text-emerald-800">
                {formatCurrency(totalAssets, language)}
              </span>
            </div>

            {/* 1. Cash in Hand */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-stone-700 flex items-center justify-between">
                <span>૧. {t('cash', language)}:</span>
                <span className="font-extrabold text-stone-900">
                  {formatCurrency(totalCashBalance, language)}
                </span>
              </h4>
              <div className="pl-4 space-y-1 text-xs text-stone-600">
                {cashAccounts.map((a) => (
                  <div key={a.id} className="flex justify-between">
                    <span>{a.name}</span>
                    <span className="font-medium">{formatCurrency(getAccountBalance(a.id), language)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Bank Accounts */}
            <div className="space-y-2 pt-2 border-t border-stone-100">
              <h4 className="text-xs font-bold text-stone-700 flex items-center justify-between">
                <span>૨. {t('bank', language)}:</span>
                <span className="font-extrabold text-stone-900">
                  {formatCurrency(totalBankBalance, language)}
                </span>
              </h4>
              <div className="pl-4 space-y-1 text-xs text-stone-600">
                {bankAccounts.map((a) => (
                  <div key={a.id} className="flex justify-between">
                    <span>
                      {a.name} {a.accountNumber ? `(${a.accountNumber})` : ''}
                    </span>
                    <span className="font-medium">{formatCurrency(getAccountBalance(a.id), language)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. Money Lent on Interest */}
            <div className="space-y-2 pt-2 border-t border-stone-100">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-stone-700">
                  ૩. {t('lentLoansTotal', language)}:
                </h4>
                <span className="text-xs font-extrabold text-emerald-700">
                  {formatCurrency(totalLentAssetValue, language)}
                </span>
              </div>

              {lentCalculations.length === 0 ? (
                <p className="text-xs text-stone-400 pl-4">કોઈ સક્રિય ધીરેલ લોન નથી.</p>
              ) : (
                <div className="pl-4 space-y-1.5 text-xs">
                  {lentCalculations.map(({ loan, calc }) => (
                    <div
                      key={loan.id}
                      className="p-2 rounded-lg bg-stone-50 border border-stone-200/80 flex items-center justify-between"
                    >
                      <div>
                        <span className="font-bold text-stone-900 block">{loan.partyName}</span>
                        <span className="text-[11px] text-stone-500">
                          મુદ્દલ: {formatCurrency(calc.currentPrincipal, language)} + વ્યાજ: {formatCurrency(calc.currentAccruedInterest, language)}
                        </span>
                      </div>
                      <span className="font-bold text-emerald-800">
                        {formatCurrency(calc.totalBalanceRemaining, language)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* RIGHT: Liabilities (દેવું / જવાબદારી) */}
          <div className="p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b-2 border-rose-600">
              <h3 className="text-sm font-black text-rose-900 uppercase tracking-wider flex items-center gap-1.5">
                <TrendingDown className="w-4 h-4 text-rose-600" />
                <span>{t('liabilities', language)}</span>
              </h3>
              <span className="text-sm font-black text-rose-800">
                {formatCurrency(totalLiabilities, language)}
              </span>
            </div>

            {/* 1. Money Borrowed on Interest */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-stone-700">
                  ૧. {t('borrowedLoansTotal', language)}:
                </h4>
                <span className="text-xs font-extrabold text-rose-700">
                  {formatCurrency(totalLiabilities, language)}
                </span>
              </div>

              {borrowedCalculations.length === 0 ? (
                <p className="text-xs text-stone-400 pl-4">કોઈ સક્રિય લીધેલ લોન / દેવું નથી.</p>
              ) : (
                <div className="pl-4 space-y-1.5 text-xs">
                  {borrowedCalculations.map(({ loan, calc }) => (
                    <div
                      key={loan.id}
                      className="p-2 rounded-lg bg-stone-50 border border-stone-200/80 flex items-center justify-between"
                    >
                      <div>
                        <span className="font-bold text-stone-900 block">{loan.partyName}</span>
                        <span className="text-[11px] text-stone-500">
                          બાકી મુદ્દલ: {formatCurrency(calc.currentPrincipal, language)} + વ્યાજ: {formatCurrency(calc.currentAccruedInterest, language)}
                        </span>
                      </div>
                      <span className="font-bold text-rose-800">
                        {formatCurrency(calc.totalBalanceRemaining, language)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Net Worth Re-cap box on Liabilities side */}
            <div className="mt-8 rounded-xl bg-amber-50/70 p-4 border border-amber-300/80 text-xs space-y-2">
              <div className="flex items-center justify-between font-bold text-stone-800">
                <span>{t('netWorth', language)}:</span>
                <span className="text-base font-extrabold text-amber-900">
                  {formatCurrency(netWorth, language)}
                </span>
              </div>
              <p className="text-[11px] text-amber-950/80">
                {language === 'gu'
                  ? 'કુલ સંપત્તિમાંથી તમામ દેવાં અને વ્યાજ ચૂકવણી બાદ કરતાં વધેલી શુદ્ધ મૂડી.'
                  : 'Total capital surplus remaining after deducting all obligations.'}
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Income & Expense Statement Summary */}
        <div className="p-6 bg-stone-50 border-t-2 border-stone-200 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
              <PieChart className="w-4 h-4 text-amber-600" />
              <span>{t('incomeExpenseSummary', language)}</span>
            </h3>

            <div className="flex items-center gap-4 text-xs font-bold">
              <span className="text-emerald-700">
                કુલ આવક: {formatCurrency(totalIncome, language)}
              </span>
              <span className="text-rose-700">
                કુલ ખર્ચ: {formatCurrency(totalExpense, language)}
              </span>
              <span className="text-stone-900">
                બચત: {formatCurrency(netSavings, language)}
              </span>
            </div>
          </div>

          {/* Category-wise Expenses Progress Bars */}
          {categoryExpenses.length > 0 && (
            <div className="space-y-2 pt-2">
              <span className="text-xs font-semibold text-stone-600">મુખ્ય ખર્ચ કેટેગરીઝ:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {categoryExpenses.slice(0, 6).map(({ category, amount, percentage }) => (
                  <div key={category.id} className="bg-white p-2.5 rounded-lg border border-stone-200">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-semibold text-stone-800">
                        {language === 'gu' ? category.nameGu : category.nameEn}
                      </span>
                      <span className="font-bold text-stone-900">
                        {formatCurrency(amount, language)} ({percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="w-full bg-stone-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-amber-600 h-1.5 rounded-full"
                        style={{ width: `${Math.min(100, percentage)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer for print sign-off */}
        <div className="p-6 border-t border-stone-200 flex items-center justify-between text-xs text-stone-500">
          <div>
            ખાતાવહી હિસાબ તારીખ: {new Date().toLocaleDateString()} • ૧૦૦% ઓફલાઇન ચોપડો
          </div>
          <div className="font-semibold text-stone-800">
            હસ્તાક્ષર / Signature: ____________________
          </div>
        </div>
      </div>

      {/* Download App Modal (APK & EXE) */}
      <DownloadAppModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
};
