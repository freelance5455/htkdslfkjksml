"use client";

import { useEffect } from "react";

/**
 * Navigation shim for the packaged static build.
 *
 * The export emits flat files (`history.html`, `scorer.html`, …) so that every
 * page sits at the package root and relative `./_next/…` asset URLs resolve.
 * Internal links, however, are still written as `/history` or `/scorer?id=…`,
 * which a plain static server or a `file://` WebView cannot resolve.
 *
 * This component rewrites those clicks to the matching `.html` file. It is
 * compiled in only when NEXT_PUBLIC_STATIC_EXPORT=1 (set by the static build),
 * so the normal server build keeps full client-side routing.
 */
export function StaticNav() {
  useEffect(() => {
    if (process.env.NEXT_PUBLIC_STATIC_EXPORT !== "1") return;

    const toFile = (url: URL): string => {
      let path = url.pathname.replace(/\/+$/, "");
      if (path === "" || path === "/index") path = "/index";
      // Already a file reference — leave it alone.
      if (/\.[a-z0-9]+$/i.test(path)) return path.slice(1) + url.search + url.hash;
      return `${path.slice(1)}.html${url.search}${url.hash}`;
    };

    const onClick = (e: MouseEvent) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
      const anchor = (e.target as HTMLElement | null)?.closest?.("a");
      if (!anchor) return;

      const href = anchor.getAttribute("href");
      if (!href || href.startsWith("#")) return;
      if (anchor.target && anchor.target !== "_self") return;
      // External links keep their normal behaviour.
      if (/^[a-z]+:/i.test(href) && !href.startsWith(location.origin)) return;

      const url = new URL(href, location.href);
      if (url.origin !== location.origin && location.protocol !== "file:") return;

      e.preventDefault();
      location.assign(toFile(url));
    };

    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, []);

  return null;
}
