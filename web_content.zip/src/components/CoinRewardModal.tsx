import React, { useState } from 'react';
import {
  X,
  Coins,
  Sparkles,
  Gift,
  CheckCircle2,
  Zap,
  TrendingUp,
  Share2,
} from 'lucide-react';

interface CoinRewardModalProps {
  isOpen: boolean;
  coins: number;
  onClose: () => void;
  onAddCoins: (amount: number) => void;
}

export const CoinRewardModal: React.FC<CoinRewardModalProps> = ({
  isOpen,
  coins,
  onClose,
  onAddCoins,
}) => {
  const [claimedDaily, setClaimedDaily] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleClaimDaily = () => {
    if (claimedDaily) return;
    onAddCoins(100);
    setClaimedDaily(true);
    setToastMessage('🎉 +100 Coins added to your balance!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleBonusTask = (amount: number, taskName: string) => {
    onAddCoins(amount);
    setToastMessage(`✨ +${amount} Coins rewarded for ${taskName}!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl bg-slate-900 border border-amber-500/30 p-6 sm:p-7 shadow-2xl shadow-amber-950/50">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/15">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center text-slate-950 shadow-md">
              <Coins className="w-6 h-6 fill-amber-950 text-amber-950" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-1.5">
                Coins Wallet
              </h3>
              <p className="text-xs text-amber-300/80">
                Earn & Redeem Free Growth Coins
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Balance Display */}
        <div className="mt-5 p-5 rounded-2xl bg-gradient-to-b from-amber-950/40 via-slate-950/80 to-amber-950/20 border border-amber-500/30 text-center relative overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent" />
          <span className="text-xs font-semibold text-amber-300/80 uppercase tracking-widest">
            Total Available Coins
          </span>
          <div className="text-4xl font-black text-amber-400 font-mono mt-1 flex items-center justify-center gap-2">
            <span>{coins.toLocaleString()}</span>
            <span className="text-xl text-amber-300">🪙</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Redeemable for any follower boost package
          </p>
        </div>

        {/* Toast Alert */}
        {toastMessage && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Earn Coins Options */}
        <div className="mt-5 space-y-3">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Free Coins Rewards
          </div>

          {/* Daily Reward */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-purple-500/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center">
                <Gift className="w-5 h-5 text-pink-400" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">Daily Login Reward</p>
                <p className="text-[11px] text-slate-400">+100 free coins every 24h</p>
              </div>
            </div>
            <button
              onClick={handleClaimDaily}
              disabled={claimedDaily}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                claimedDaily
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-pink-600 to-purple-600 hover:brightness-110 text-white shadow-md'
              }`}
            >
              {claimedDaily ? 'Claimed ✓' : 'Claim +100'}
            </button>
          </div>

          {/* Social Share Reward */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-purple-500/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center">
                <Share2 className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">Bonus Lucky Reward</p>
                <p className="text-[11px] text-slate-400">Claim extra boost reward</p>
              </div>
            </div>
            <button
              onClick={() => handleBonusTask(250, 'Bonus Reward')}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:brightness-110 text-slate-950 text-xs font-bold shadow-md transition-all active:scale-95"
            >
              Claim +250
            </button>
          </div>
        </div>

        {/* Close Button */}
        <div className="mt-6">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            Close Wallet
          </button>
        </div>
      </div>
    </div>
  );
};
