import { ScreenHeader } from "@/components/phone-shell";
import { Button } from "@/components/ui/button";
import { formatPhone, isEmergencyNumber } from "@/lib/emergency";
import { useAppStore } from "@/lib/store";
import { Delete, Phone, PhoneIncoming } from "lucide-react";
import { useState } from "react";

const KEYS = [
  { d: "1", l: "" },
  { d: "2", l: "ABC" },
  { d: "3", l: "DEF" },
  { d: "4", l: "GHI" },
  { d: "5", l: "JKL" },
  { d: "6", l: "MNO" },
  { d: "7", l: "PQRS" },
  { d: "8", l: "TUV" },
  { d: "9", l: "WXYZ" },
  { d: "*", l: "" },
  { d: "0", l: "+" },
  { d: "#", l: "" },
];

export function KeypadView() {
  const [digits, setDigits] = useState("");
  const placeOutgoing = useAppStore((s) => s.placeOutgoing);
  const setOverlay = useAppStore((s) => s.setOverlay);

  const display = digits.startsWith("+") ? formatPhone(digits) || digits : digits;
  const emergency = isEmergencyNumber(digits);

  function press(k: string) {
    setDigits((d) => {
      if (k === "+") return d.startsWith("+") ? d : `+${d}`;
      return (d + k).slice(0, 18);
    });
  }

  return (
    <div className="flex min-h-full flex-col">
      <ScreenHeader
        title="Keypad"
        subtitle="Place a call, or demo an incoming ring"
        action={
          <button
            type="button"
            onClick={() => setOverlay({ kind: "demo-ring" })}
            className="flex size-11 items-center justify-center rounded-full bg-muted text-accent"
            aria-label="Simulate incoming call"
          >
            <PhoneIncoming className="size-5" />
          </button>
        }
      />

      <div className="flex flex-1 flex-col justify-end px-5 pb-4">
        <div className="mb-2 min-h-16 text-center">
          <p className="text-[1.85rem] leading-tight font-medium tracking-wide break-all">
            {display || <span className="text-subtle">Enter a number</span>}
          </p>
          {emergency ? (
            <p className="mt-2 text-xs text-warn">Emergency numbers are never handled by Lisa.</p>
          ) : digits ? (
            <button
              type="button"
              className="mt-2 text-sm text-accent"
              onClick={() => {
                setOverlay({ kind: "new-contact", number: digits });
              }}
            >
              Add contact
            </button>
          ) : (
            <button
              type="button"
              className="mt-2 text-sm text-muted-foreground"
              onClick={() => setOverlay({ kind: "demo-ring" })}
            >
              Ring a demo call
            </button>
          )}
        </div>

        <div className="mx-auto grid w-full max-w-xs grid-cols-3 gap-x-4 gap-y-3 py-3">
          {KEYS.map((k) => (
            <button
              key={k.d}
              type="button"
              onClick={() => press(k.d)}
              onContextMenu={(e) => {
                if (k.d === "0") {
                  e.preventDefault();
                  press("+");
                }
              }}
              className="flex h-[4.25rem] flex-col items-center justify-center rounded-full bg-muted active:scale-95"
            >
              <span className="text-[1.7rem] leading-none font-medium">{k.d}</span>
              {k.l ? (
                <span className="mt-1 text-[0.62rem] tracking-[0.18em] text-muted-foreground">
                  {k.l}
                </span>
              ) : (
                <span className="mt-1 h-3" />
              )}
            </button>
          ))}
        </div>

        <div className="mt-2 mb-1 flex items-center justify-center gap-10">
          <span className="size-12" />
          <Button
            variant="success"
            size="icon"
            className="size-16"
            disabled={!digits}
            aria-label="Call"
            onClick={() => placeOutgoing(digits)}
          >
            <Phone className="size-7 fill-current" />
          </Button>
          <button
            type="button"
            aria-label="Delete"
            className="grid size-12 place-items-center text-muted-foreground disabled:opacity-0"
            disabled={!digits}
            onClick={() => setDigits((d) => d.slice(0, -1))}
            onContextMenu={(e) => {
              e.preventDefault();
              setDigits("");
            }}
          >
            <Delete className="size-6" />
          </button>
        </div>
      </div>
    </div>
  );
}
