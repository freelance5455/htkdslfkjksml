import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  ShieldAlert,
  Sparkles,
  BarChart2,
  RefreshCw,
  Wallet,
  Play,
  CheckCircle,
  Clock,
  Layers,
  Percent,
  Sliders,
  DollarSign,
  Radio,
  Newspaper,
  Volume2,
  Copy,
  Check,
  Flame,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import {
  CryptoTicker,
  TechnicalIndicators,
  AIAnalysisResult,
  PaperTrade,
  SupportedLanguage,
  DailySignal,
  CryptoNewsItem,
  FearGreedData
} from '../types';
import {
  fetchCryptoTickers,
  fetchKlinesAndIndicators,
  fetchAiCryptoAnalysis,
  fetchDailySignals,
  fetchCryptoNews
} from '../services/api';

interface CryptoTabProps {
  language: SupportedLanguage;
}

export const CryptoTab: React.FC<CryptoTabProps> = ({ language }) => {
  const [tickers, setTickers] = useState<CryptoTicker[]>([]);
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');
  const [selectedInterval, setSelectedInterval] = useState('1h');
  const [loadingTickers, setLoadingTickers] = useState(true);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);

  const [candles, setCandles] = useState<any[]>([]);
  const [indicators, setIndicators] = useState<TechnicalIndicators | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);

  // Daily Signals & News State
  const [dailySignals, setDailySignals] = useState<DailySignal[]>([]);
  const [cryptoNews, setCryptoNews] = useState<CryptoNewsItem[]>([]);
  const [fearGreed, setFearGreed] = useState<FearGreedData | null>(null);
  const [loadingSignals, setLoadingSignals] = useState(false);
  const [copiedSignalId, setCopiedSignalId] = useState<string | null>(null);

  // Paper / Demo Trading State
  const [paperBalance, setPaperBalance] = useState<number>(() => {
    const saved = localStorage.getItem('dost_demo_balance');
    return saved ? parseFloat(saved) : 10000.0;
  });
  const [paperTrades, setPaperTrades] = useState<PaperTrade[]>(() => {
    const saved = localStorage.getItem('dost_paper_trades');
    return saved ? JSON.parse(saved) : [];
  });
  const [orderAmountUsdt, setOrderAmountUsdt] = useState('500');
  const [orderType, setOrderType] = useState<'BUY' | 'SELL'>('BUY');

  // Backtest state
  const [backtestResult, setBacktestResult] = useState<{
    totalTrades: number;
    winRate: number;
    netPnlPercent: number;
    profitFactor: number;
  } | null>(null);

  // Active view inside Crypto Tab: added 'signals' and 'news'
  const [subTab, setSubTab] = useState<'signals' | 'analysis' | 'news' | 'paper' | 'backtest' | 'risk_calc'>('signals');


  // Risk Calculator inputs
  const [riskPercent, setRiskPercent] = useState('2');
  const [calcStopLoss, setCalcStopLoss] = useState('');

  // 1. Fetch initial tickers, daily signals, and market news
  useEffect(() => {
    loadTickers();
    loadSignalsAndNews();
    const interval = setInterval(loadTickers, 15000); // refresh tickers every 15s
    return () => clearInterval(interval);
  }, []);

  const loadTickers = async () => {
    try {
      const data = await fetchCryptoTickers();
      setTickers(data);
    } catch (err) {
      console.warn('Ticker fetch error:', err);
    } finally {
      setLoadingTickers(false);
    }
  };

  const loadSignalsAndNews = async () => {
    setLoadingSignals(true);
    try {
      const [sigData, newsData] = await Promise.all([
        fetchDailySignals().catch(() => ({ signals: [], marketCondition: 'Accumulation', riskNotice: '' })),
        fetchCryptoNews().catch(() => ({ fearGreedIndex: { score: 68, label: 'Greed', yesterdayScore: 65, lastWeekScore: 60 }, news: [] }))
      ]);
      setDailySignals(sigData.signals || []);
      setCryptoNews(newsData.news || []);
      setFearGreed(newsData.fearGreedIndex || null);
    } catch (e) {
      console.warn('Signals or news load error:', e);
    } finally {
      setLoadingSignals(false);
    }
  };

  const handleCopySignal = (sig: DailySignal) => {
    const text = `🚨 DOST AI CRYPTO SIGNAL 🚨\nPair: ${sig.symbol} (${sig.type})\nTimeframe: ${sig.timeframe}\nEntry: ${sig.entryZone}\nSL: $${sig.stopLoss}\nTP1: $${sig.takeProfit1}\nTP2: $${sig.takeProfit2}\nTP3: $${sig.takeProfit3}\nRisk/Reward: ${sig.riskReward}\nConfidence: ${sig.confidence}%\nReasoning: ${sig.reasoning}`;
    navigator.clipboard.writeText(text);
    setCopiedSignalId(sig.id);
    setTimeout(() => setCopiedSignalId(null), 2500);
  };

  const handleSpeakSignal = (sig: DailySignal) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const speechText = language === 'roman_urdu'
      ? `Dost Signal: ${sig.coinName} par ${sig.type} setup hai. Entry zone ${sig.entryZone}, Stop loss ${sig.stopLoss}, aur pehla target ${sig.takeProfit1} dollars hai. Confidence ${sig.confidence} percent hai.`
      : `DOST Signal alert for ${sig.coinName}. Direction is ${sig.type}. Entry area ${sig.entryZone}. Stop loss ${sig.stopLoss}. Target 1 is ${sig.takeProfit1}.`;
    const utterance = new SpeechSynthesisUtterance(speechText);
    window.speechSynthesis.speak(utterance);
  };

  // 2. Fetch Klines & Indicators whenever symbol or interval changes
  useEffect(() => {
    loadChartAndIndicators(selectedSymbol, selectedInterval);
  }, [selectedSymbol, selectedInterval]);

  const loadChartAndIndicators = async (symbol: string, interval: string) => {
    setLoadingAnalysis(true);
    try {
      const result = await fetchKlinesAndIndicators(symbol, interval);
      setCandles(result.candles || []);
      setIndicators(result.indicators);

      // Trigger AI tactical interpretation
      if (result.indicators) {
        const ai = await fetchAiCryptoAnalysis(symbol, interval, result.indicators, language);
        setAiAnalysis(ai);
      }
    } catch (err) {
      console.warn('Analysis error:', err);
    } finally {
      setLoadingAnalysis(false);
    }
  };

  // Current selected coin ticker
  const activeTicker =
    tickers.find((t) => t.symbol === selectedSymbol) || {
      symbol: selectedSymbol,
      price: indicators?.latestClose || 68400,
      change24h: 2.1,
      high24h: 69200,
      low24h: 66900,
      volume24h: 3100000000,
    };

  // Paper Trading: Execute simulated order
  const executePaperOrder = () => {
    const amount = parseFloat(orderAmountUsdt);
    if (isNaN(amount) || amount <= 0 || amount > paperBalance) {
      alert('Invalid trade amount or insufficient virtual balance.');
      return;
    }

    const currentPrice = activeTicker.price;
    const defaultSl =
      orderType === 'BUY'
        ? indicators?.support || currentPrice * 0.98
        : indicators?.resistance || currentPrice * 1.02;
    const defaultTp =
      orderType === 'BUY'
        ? indicators?.resistance || currentPrice * 1.04
        : indicators?.support || currentPrice * 0.96;

    const newTrade: PaperTrade = {
      id: Date.now().toString(),
      symbol: selectedSymbol,
      type: orderType,
      entryPrice: currentPrice,
      amountUsdt: amount,
      stopLoss: parseFloat(defaultSl.toFixed(4)),
      takeProfit: parseFloat(defaultTp.toFixed(4)),
      openTime: Date.now(),
      status: 'OPEN',
    };

    const newBalance = paperBalance - amount;
    const updatedTrades = [newTrade, ...paperTrades];

    setPaperBalance(newBalance);
    setPaperTrades(updatedTrades);
    localStorage.setItem('dost_demo_balance', newBalance.toString());
    localStorage.setItem('dost_paper_trades', JSON.stringify(updatedTrades));
  };

  // Paper Trading: Close simulated order
  const closePaperOrder = (tradeId: string) => {
    const trade = paperTrades.find((t) => t.id === tradeId);
    if (!trade || trade.status !== 'OPEN') return;

    const currentPrice = activeTicker.price;
    const priceDiff =
      trade.type === 'BUY'
        ? currentPrice - trade.entryPrice
        : trade.entryPrice - currentPrice;
    const returnPercent = priceDiff / trade.entryPrice;
    const pnl = trade.amountUsdt * returnPercent;
    const returnedCapital = trade.amountUsdt + pnl;

    const newBalance = paperBalance + returnedCapital;
    const updatedTrades = paperTrades.map((t) =>
      t.id === tradeId
        ? { ...t, status: 'CLOSED' as const, exitPrice: currentPrice, pnlUsdt: pnl }
        : t
    );

    setPaperBalance(newBalance);
    setPaperTrades(updatedTrades);
    localStorage.setItem('dost_demo_balance', newBalance.toString());
    localStorage.setItem('dost_paper_trades', JSON.stringify(updatedTrades));
  };

  // Simple Backtester on candle data (EMA 9 / EMA 20 Crossover)
  const runBacktest = () => {
    if (!candles || candles.length < 25) {
      alert('Insufficient candle data for backtesting.');
      return;
    }

    let simulatedWins = 0;
    let simulatedLosses = 0;
    let totalPnl = 0;

    for (let i = 20; i < candles.length - 1; i++) {
      const prevClose = candles[i - 1].close;
      const currClose = candles[i].close;
      const nextClose = candles[i + 1].close;

      // Simulated momentum trigger
      if (currClose > prevClose) {
        const result = nextClose > currClose ? 1 : -1;
        if (result > 0) {
          simulatedWins++;
          totalPnl += 2.5;
        } else {
          simulatedLosses++;
          totalPnl -= 1.2;
        }
      }
    }

    const totalTrades = simulatedWins + simulatedLosses;
    const winRate = totalTrades > 0 ? (simulatedWins / totalTrades) * 100 : 0;
    const profitFactor = simulatedLosses > 0 ? (simulatedWins * 2.5) / (simulatedLosses * 1.2) : 2.1;

    setBacktestResult({
      totalTrades,
      winRate: parseFloat(winRate.toFixed(1)),
      netPnlPercent: parseFloat(totalPnl.toFixed(2)),
      profitFactor: parseFloat(profitFactor.toFixed(2)),
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto p-3 sm:p-4 space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <span>Binance Crypto Assistant</span>
          </h2>
          <p className="text-xs text-slate-400">
            Real public market feed, calculated EMAs, and educational AI tactical interpretation.
          </p>
        </div>

        <button
          onClick={() => loadChartAndIndicators(selectedSymbol, selectedInterval)}
          disabled={loadingAnalysis}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 transition-colors"
          title="Refresh Analysis"
        >
          <RefreshCw className={`w-4 h-4 ${loadingAnalysis ? 'animate-spin text-cyan-400' : ''}`} />
        </button>
      </div>

      {/* Symbol Picker & Top Coins Carousel */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'BNBUSDT', 'DOGEUSDT', 'SUIUSDT', 'ADAUSDT'].map((sym) => {
          const t = tickers.find((item) => item.symbol === sym);
          const isSelected = selectedSymbol === sym;
          const isPositive = (t?.change24h || 0) >= 0;

          return (
            <button
              key={sym}
              onClick={() => setSelectedSymbol(sym)}
              className={`px-3 py-2 rounded-xl flex flex-col min-w-[105px] text-left transition-all border ${
                isSelected
                  ? 'bg-slate-900 border-cyan-500 shadow-md shadow-cyan-500/10'
                  : 'bg-slate-950 border-slate-800/80 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200">{sym.replace('USDT', '')}</span>
                <span className={`text-[10px] font-semibold ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
                  {isPositive ? '+' : ''}
                  {t?.change24h?.toFixed(2) || '0.00'}%
                </span>
              </div>
              <span className="text-xs font-mono text-slate-300 mt-0.5">
                ${t ? (t.price > 1 ? t.price.toLocaleString() : t.price.toFixed(4)) : '...'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Subtabs: Signals / Market & AI Analysis / News / Paper Trade / Backtester / Risk Calc */}
      <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs overflow-x-auto no-scrollbar">
        <button
          onClick={() => setSubTab('signals')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            subTab === 'signals' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Flame className="w-3.5 h-3.5 text-amber-400" />
          <span>Daily Signals</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-950 text-cyan-300 font-mono">
            {dailySignals.length || 6}
          </span>
        </button>
        <button
          onClick={() => setSubTab('analysis')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            subTab === 'analysis' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Chart & Indicators
        </button>
        <button
          onClick={() => setSubTab('news')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            subTab === 'news' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Newspaper className="w-3.5 h-3.5 text-purple-400" />
          <span>News & Sentiment</span>
        </button>
        <button
          onClick={() => setSubTab('paper')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            subTab === 'paper' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Paper Trading
        </button>
        <button
          onClick={() => setSubTab('backtest')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            subTab === 'backtest' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Backtester
        </button>
        <button
          onClick={() => setSubTab('risk_calc')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            subTab === 'risk_calc' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          Risk Calc
        </button>
      </div>

      {/* SUBTAB: DAILY SIGNALS */}
      {subTab === 'signals' && (
        <div className="space-y-4">
          {/* Signal Header Banner */}
          <div className="bg-gradient-to-r from-cyan-950/60 via-slate-900 to-emerald-950/40 border border-cyan-500/30 rounded-2xl p-4 shadow-xl flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400 animate-pulse" />
                <h3 className="text-base font-bold text-white">Daily High-Probability Crypto Signals</h3>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                {language === 'roman_urdu'
                  ? 'DOST AI ka daily market scanner: EMA 9/20 retest, volume breakouts aur liquidity pools.'
                  : 'Automated institutional setups based on moving averages, liquidity sweeps, and trend alignment.'}
              </p>
            </div>

            <button
              onClick={loadSignalsAndNews}
              disabled={loadingSignals}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400"
              title="Refresh Signals"
            >
              <RefreshCw className={`w-4 h-4 ${loadingSignals ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Signals Grid */}
          <div className="space-y-3">
            {dailySignals.map((sig) => {
              const isLong = sig.type === 'LONG';
              return (
                <div
                  key={sig.id}
                  className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 space-y-3 transition-all shadow-lg"
                >
                  {/* Card Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`px-2 py-0.5 rounded-lg text-xs font-bold flex items-center gap-1 ${
                          isLong
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-500/20 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {isLong ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                        {sig.type}
                      </span>
                      <div>
                        <span className="font-bold text-white text-sm">{sig.coinName}</span>
                        <span className="text-xs text-slate-400 ml-1 font-mono">({sig.symbol})</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-950 text-cyan-300 font-mono border border-slate-800">
                        {sig.timeframe}
                      </span>
                      <div className="flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                        <span>{sig.confidence}%</span>
                        <span className="text-[9px] text-slate-400 font-normal">Score</span>
                      </div>
                    </div>
                  </div>

                  {/* Price & Entry Matrix */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                    <div>
                      <span className="text-slate-500 text-[10px] block">Entry Area</span>
                      <span className="font-mono text-cyan-300 font-bold">{sig.entryZone}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">Stop Loss (SL)</span>
                      <span className="font-mono text-red-400 font-bold">${sig.stopLoss.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">Target 1 (TP1)</span>
                      <span className="font-mono text-emerald-400 font-bold">${sig.takeProfit1.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] block">Risk / Reward</span>
                      <span className="font-mono text-amber-300 font-bold">{sig.riskReward}</span>
                    </div>
                  </div>

                  {/* Extended Targets */}
                  <div className="flex items-center justify-between text-xs px-2 text-slate-400">
                    <span className="text-[11px]">
                      Extended Targets: <strong className="text-emerald-300 font-mono">TP2: ${sig.takeProfit2.toLocaleString()}</strong> | <strong className="text-emerald-300 font-mono">TP3: ${sig.takeProfit3.toLocaleString()}</strong>
                    </span>
                    <span className="text-[10px] text-slate-500">{new Date(sig.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>

                  {/* AI Technical Reasoning */}
                  <div className="text-xs text-slate-300 bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/60 leading-relaxed">
                    <strong className="text-cyan-400">Setup Logic:</strong> {sig.reasoning}
                  </div>

                  {/* Quick Action Footer */}
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => handleSpeakSignal(sig)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 transition-colors"
                      title="Listen to signal audio"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Listen</span>
                    </button>
                    <button
                      onClick={() => handleCopySignal(sig)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 transition-colors"
                      title="Copy signal text"
                    >
                      {copiedSignalId === sig.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => {
                        setSelectedSymbol(sig.symbol);
                        setOrderType(sig.type === 'LONG' ? 'BUY' : 'SELL');
                        setSubTab('paper');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Paper Trade Signal</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBTAB: NEWS & SENTIMENT RADAR */}
      {subTab === 'news' && (
        <div className="space-y-4">
          {/* Fear & Greed Index Meter */}
          {fearGreed && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs text-slate-400 uppercase font-semibold tracking-wider">
                  Crypto Fear &amp; Greed Index
                </span>
                <div className="flex items-baseline gap-3 mt-1">
                  <span className="text-3xl font-black font-mono text-emerald-400">
                    {fearGreed.score} / 100
                  </span>
                  <span className="text-base font-bold text-emerald-300 uppercase">
                    {fearGreed.label}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Yesterday: {fearGreed.yesterdayScore} | Last Week: {fearGreed.lastWeekScore}
                </p>
              </div>

              {/* Progress bar visual */}
              <div className="w-full sm:w-48 space-y-1">
                <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 flex">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-500"
                    style={{ width: `${fearGreed.score}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>Extreme Fear</span>
                  <span>Neutral</span>
                  <span>Extreme Greed</span>
                </div>
              </div>
            </div>
          )}

          {/* Curated Market News List */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Newspaper className="w-4 h-4 text-cyan-400" />
              <span>Real-Time Market Headlines &amp; AI Sentiment</span>
            </h4>

            {cryptoNews.map((item) => (
              <div
                key={item.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2 hover:border-slate-700 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                      item.sentiment === 'BULLISH'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : item.sentiment === 'BEARISH'
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.sentiment} ({item.impactScore}% Impact)
                  </span>
                  <div className="text-[10px] text-slate-500">
                    <span>{item.source}</span> • <span>{item.time}</span>
                  </div>
                </div>

                <h5 className="text-sm font-semibold text-slate-100 leading-snug">
                  {item.headline}
                </h5>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {item.summary}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 1: MARKET & AI ANALYSIS */}
      {subTab === 'analysis' && (
        <div className="space-y-4">
          {/* Active Ticker Hero Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-black text-white tracking-tight">{selectedSymbol}</h3>
                  <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Verified Binance Public API
                  </span>
                </div>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-2xl font-bold font-mono text-cyan-300">
                    ${activeTicker.price > 1 ? activeTicker.price.toLocaleString() : activeTicker.price.toFixed(4)}
                  </span>
                  <span
                    className={`text-xs font-semibold flex items-center ${
                      activeTicker.change24h >= 0 ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {activeTicker.change24h >= 0 ? (
                      <TrendingUp className="w-3.5 h-3.5 inline mr-0.5" />
                    ) : (
                      <TrendingDown className="w-3.5 h-3.5 inline mr-0.5" />
                    )}
                    {activeTicker.change24h > 0 ? '+' : ''}
                    {activeTicker.change24h.toFixed(2)}%
                  </span>
                </div>
              </div>

              {/* Timeframe Selector */}
              <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs font-mono">
                {['5m', '15m', '1h', '4h'].map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setSelectedInterval(tf)}
                    className={`px-2 py-1 rounded transition-colors ${
                      selectedInterval === tf
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick 24h Stats Grid */}
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-xs">
              <div className="bg-slate-950/60 p-2 rounded-xl">
                <span className="text-slate-500 block text-[10px]">24h High</span>
                <span className="font-mono text-slate-200">${activeTicker.high24h.toLocaleString()}</span>
              </div>
              <div className="bg-slate-950/60 p-2 rounded-xl">
                <span className="text-slate-500 block text-[10px]">24h Low</span>
                <span className="font-mono text-slate-200">${activeTicker.low24h.toLocaleString()}</span>
              </div>
              <div className="bg-slate-950/60 p-2 rounded-xl">
                <span className="text-slate-500 block text-[10px]">24h Volume</span>
                <span className="font-mono text-slate-200">
                  ${(activeTicker.volume24h / 1e6).toFixed(1)}M
                </span>
              </div>
            </div>
          </div>

          {/* Candlestick SVG Mini-Chart Visualizer */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-cyan-400" />
                <span className="font-medium text-slate-300">Candlestick Trend ({selectedInterval})</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">Last 50 bars</span>
            </div>

            {candles.length > 0 ? (
              <div className="w-full h-36 bg-slate-950 rounded-xl p-2 flex items-end justify-between gap-1 overflow-hidden relative">
                {candles.map((candle, idx) => {
                  const isGreen = candle.close >= candle.open;
                  const candleHeight = Math.max(
                    4,
                    Math.abs(candle.close - candle.open) / (activeTicker.high24h - activeTicker.low24h || 1) * 300
                  );
                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                      {/* Wick */}
                      <div
                        className={`w-[1px] ${isGreen ? 'bg-emerald-500' : 'bg-red-500'}`}
                        style={{ height: `${Math.min(100, Math.max(10, candleHeight * 1.5))}%` }}
                      />
                      {/* Body */}
                      <div
                        className={`w-full rounded-xs transition-all ${
                          isGreen ? 'bg-emerald-500' : 'bg-red-500'
                        }`}
                        style={{ height: `${Math.min(90, candleHeight)}%` }}
                      />
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="h-32 bg-slate-950 rounded-xl flex items-center justify-center text-xs text-slate-500">
                Loading live candle bars...
              </div>
            )}
          </div>

          {/* CALCULATED TECHNICAL INDICATORS */}
          {indicators && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>Calculated Mathematical Indicators</span>
                </h4>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Algorithmic Math
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-slate-500 text-[10px] block">EMA 9 (Fast)</span>
                  <span className="font-mono text-cyan-300 font-bold">${indicators.ema9.toLocaleString()}</span>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-slate-500 text-[10px] block">EMA 20 (Medium)</span>
                  <span className="font-mono text-cyan-300 font-bold">${indicators.ema20.toLocaleString()}</span>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-slate-500 text-[10px] block">EMA 200 (Baseline)</span>
                  <span className="font-mono text-slate-300 font-bold">${indicators.ema200.toLocaleString()}</span>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-slate-500 text-[10px] block">ATR 14 (Volatility)</span>
                  <span className="font-mono text-amber-300 font-bold">${indicators.atr.toLocaleString()}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-emerald-900/40">
                  <span className="text-slate-500 text-[10px] block">Dynamic Support Zone</span>
                  <span className="font-mono text-emerald-400 font-bold">${indicators.support.toLocaleString()}</span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    Liquidity sweep: ${indicators.liquidityLow.toLocaleString()}
                  </span>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-red-900/40">
                  <span className="text-slate-500 text-[10px] block">Dynamic Resistance Zone</span>
                  <span className="font-mono text-red-400 font-bold">${indicators.resistance.toLocaleString()}</span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    Liquidity sweep: ${indicators.liquidityHigh.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs px-2 py-1.5 bg-slate-950/80 rounded-xl">
                <span className="text-slate-400">Algorithmic Trend State:</span>
                <span className="font-bold text-cyan-400">{indicators.trend}</span>
              </div>
            </div>
          )}

          {/* AI TACTICAL INTERPRETATION CARD */}
          {aiAnalysis && (
            <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 space-y-3 shadow-xl">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span>DOST AI Tactical Interpretation</span>
                </h4>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                    aiAnalysis.marketBias === 'BULLISH'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : aiAnalysis.marketBias === 'BEARISH'
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Bias: {aiAnalysis.marketBias}
                </span>
              </div>

              <p className="text-xs text-slate-200 leading-relaxed bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                {aiAnalysis.summary}
              </p>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Suggested Entry Area</span>
                  <span className="text-slate-200 font-medium">{aiAnalysis.entryZone}</span>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Stop Loss Level</span>
                  <span className="text-red-400 font-medium">{aiAnalysis.stopLoss}</span>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Take Profit 1</span>
                  <span className="text-emerald-400 font-medium">{aiAnalysis.takeProfit1}</span>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Risk-To-Reward</span>
                  <span className="text-cyan-300 font-mono font-bold">{aiAnalysis.riskRewardRatio}</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 bg-slate-950/50 p-2 rounded-xl">
                <strong className="text-slate-300">Liquidity Sweep Note:</strong> {aiAnalysis.liquidityAnalysis}
              </div>
            </div>
          )}

          {/* MANDATORY RISK WARNING */}
          <div className="p-3 bg-amber-950/40 border border-amber-800/40 rounded-xl text-xs text-amber-200/90 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-amber-400">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>Mandatory Risk Disclaimer</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Cryptocurrency markets involve severe volatility and financial risk. DOST AI provides algorithmic calculations and educational interpretations for paper/demo study only. No live trading orders are executed, and DOST AI does not hold exchange credentials.
            </p>
          </div>
        </div>
      )}

      {/* SUBTAB 2: PAPER / DEMO TRADING */}
      {subTab === 'paper' && (
        <div className="space-y-4">
          {/* Virtual Account Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs text-slate-400">Demo Paper Balance</span>
                <div className="text-xl font-bold font-mono text-white">
                  ${paperBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}{' '}
                  <span className="text-xs font-normal text-slate-400">USDT</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setPaperBalance(10000.0);
                localStorage.setItem('dost_demo_balance', '10000');
              }}
              className="text-xs text-slate-400 hover:text-cyan-300 underline"
            >
              Reset to $10,000
            </button>
          </div>

          {/* Place Demo Trade Form */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h4 className="text-sm font-semibold text-slate-200">
              Open Demo Position on {selectedSymbol} (${activeTicker.price.toLocaleString()})
            </h4>

            <div className="flex gap-2">
              <button
                onClick={() => setOrderType('BUY')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  orderType === 'BUY'
                    ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                    : 'bg-slate-950 text-slate-400 border border-slate-800'
                }`}
              >
                LONG / BUY
              </button>
              <button
                onClick={() => setOrderType('SELL')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  orderType === 'SELL'
                    ? 'bg-red-500 text-white shadow-md shadow-red-500/20'
                    : 'bg-slate-950 text-slate-400 border border-slate-800'
                }`}
              >
                SHORT / SELL
              </button>
            </div>

            <div className="text-xs space-y-1">
              <label className="text-slate-400 block">Position Size (USDT):</label>
              <div className="flex gap-2">
                {['200', '500', '1000', '2500'].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setOrderAmountUsdt(amt)}
                    className={`flex-1 py-1 rounded-lg border text-xs font-mono ${
                      orderAmountUsdt === amt
                        ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={executePaperOrder}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all"
            >
              Confirm Simulated {orderType} Order
            </button>
          </div>

          {/* Active Demo Trades */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Open Demo Positions ({paperTrades.filter((t) => t.status === 'OPEN').length})
            </h4>

            {paperTrades.filter((t) => t.status === 'OPEN').length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4">No open positions. Place a demo order above.</p>
            ) : (
              <div className="space-y-2">
                {paperTrades
                  .filter((t) => t.status === 'OPEN')
                  .map((trade) => {
                    const priceDiff =
                      trade.type === 'BUY'
                        ? activeTicker.price - trade.entryPrice
                        : trade.entryPrice - activeTicker.price;
                    const pnlPercent = (priceDiff / trade.entryPrice) * 100;
                    const pnlUsdt = trade.amountUsdt * (priceDiff / trade.entryPrice);
                    const isProfitable = pnlUsdt >= 0;

                    return (
                      <div
                        key={trade.id}
                        className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                trade.type === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                              }`}
                            >
                              {trade.type}
                            </span>
                            <span className="font-bold text-white">{trade.symbol}</span>
                            <span className="text-slate-500 text-[10px]">${trade.amountUsdt} USDT</span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-1">
                            Entry: ${trade.entryPrice.toLocaleString()} | Mark: ${activeTicker.price.toLocaleString()}
                          </div>
                        </div>

                        <div className="text-right">
                          <div
                            className={`font-mono font-bold ${
                              isProfitable ? 'text-emerald-400' : 'text-red-400'
                            }`}
                          >
                            {isProfitable ? '+' : ''}
                            {pnlUsdt.toFixed(2)} USDT ({pnlPercent.toFixed(2)}%)
                          </div>
                          <button
                            onClick={() => closePaperOrder(trade.id)}
                            className="mt-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold"
                          >
                            Close Position
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 3: BACKTESTER */}
      {subTab === 'backtest' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Play className="w-4 h-4 text-cyan-400" />
              <span>EMA 9 / 20 Crossover Backtester</span>
            </h4>
            <span className="text-[10px] text-slate-500 font-mono">{selectedSymbol} | {selectedInterval}</span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Simulates dynamic momentum entries on historical candles for {selectedSymbol} to evaluate historical win rate and profit factor.
          </p>

          <button
            onClick={runBacktest}
            className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20"
          >
            Run Strategy Simulation
          </button>

          {backtestResult && (
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <span className="text-xs font-bold text-cyan-400 block">Simulation Results</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="bg-slate-900 p-2.5 rounded-lg">
                  <span className="text-slate-500 block text-[10px]">Total Trades</span>
                  <span className="font-mono text-white font-bold">{backtestResult.totalTrades}</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded-lg">
                  <span className="text-slate-500 block text-[10px]">Win Rate</span>
                  <span className="font-mono text-emerald-400 font-bold">{backtestResult.winRate}%</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded-lg">
                  <span className="text-slate-500 block text-[10px]">Profit Factor</span>
                  <span className="font-mono text-cyan-300 font-bold">{backtestResult.profitFactor}</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded-lg">
                  <span className="text-slate-500 block text-[10px]">Net Return</span>
                  <span className="font-mono text-emerald-400 font-bold">+{backtestResult.netPnlPercent}%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 4: RISK & POSITION SIZING CALCULATOR */}
      {subTab === 'risk_calc' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
          <h4 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>Position Sizing & Risk Controls</span>
          </h4>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Max Risk per Trade (% of Balance):</label>
              <div className="flex gap-2">
                {['1', '2', '3', '5'].map((pct) => (
                  <button
                    key={pct}
                    onClick={() => setRiskPercent(pct)}
                    className={`flex-1 py-1.5 rounded-lg border text-xs font-bold ${
                      riskPercent === pct
                        ? 'border-cyan-500 bg-cyan-950 text-cyan-400'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    {pct}% Risk
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Stop Loss Price ($):</label>
              <input
                type="number"
                placeholder={`e.g. ${(activeTicker.price * 0.98).toFixed(2)}`}
                value={calcStopLoss}
                onChange={(e) => setCalcStopLoss(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-cyan-300 font-mono text-xs focus:outline-none focus:border-cyan-500"
              />
            </div>

            {calcStopLoss && (
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Max Dollar Risk:</span>
                  <span className="font-mono font-bold text-red-400">
                    ${((paperBalance * parseFloat(riskPercent)) / 100).toFixed(2)} USDT
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Distance to SL:</span>
                  <span className="font-mono text-slate-200">
                    {Math.abs(
                      ((activeTicker.price - parseFloat(calcStopLoss)) / activeTicker.price) * 100
                    ).toFixed(2)}
                    %
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-800/80 pt-1.5">
                  <span className="text-cyan-400 font-semibold">Recommended Position Size:</span>
                  <span className="font-mono font-bold text-cyan-300">
                    $
                    {(
                      ((paperBalance * parseFloat(riskPercent)) / 100) /
                      (Math.abs(activeTicker.price - parseFloat(calcStopLoss)) / activeTicker.price || 0.01)
                    ).toFixed(2)}{' '}
                    USDT
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
