import { Link } from 'react-router-dom';
import {
  Atom,
  BookOpen,
  ChevronLeft,
  Dna,
  FlaskConical,
  FunctionSquare,
  Globe2,
  Languages,
  Moon,
} from 'lucide-react';
import type { IconKey, Subject, Teacher } from '../../types';
import { subjectProgress } from '../../services/progress';
import { initials, cn } from '../../utils/format';
import { ProgressBar } from '../ui/Card';

const ICONS: Record<IconKey, typeof Atom> = {
  function: FunctionSquare,
  atom: Atom,
  flask: FlaskConical,
  dna: Dna,
  book: BookOpen,
  language: Languages,
  globe: Globe2,
  moon: Moon,
};

export function SubjectIcon({ icon, size = 20 }: { icon: IconKey; size?: number }) {
  const Icon = ICONS[icon] ?? BookOpen;
  return <Icon size={size} />;
}

export function SubjectGlyph({
  subject,
  size = 'md',
}: {
  subject: Subject;
  size?: 'sm' | 'md' | 'lg';
}) {
  const dim = size === 'lg' ? 'h-14 w-14' : size === 'sm' ? 'h-9 w-9' : 'h-11 w-11';
  return (
    <span
      className={cn('flex shrink-0 items-center justify-center rounded-2xl', dim)}
      style={{ background: `${subject.color}18`, color: subject.color }}
    >
      <SubjectIcon icon={subject.icon} size={size === 'lg' ? 26 : size === 'sm' ? 18 : 21} />
    </span>
  );
}

export function TeacherAvatar({ teacher, size = 48 }: { teacher: Teacher; size?: number }) {
  if (teacher.avatarUrl) {
    return (
      <img
        src={teacher.avatarUrl}
        alt={teacher.name}
        width={size}
        height={size}
        loading="lazy"
        className="rounded-2xl object-cover"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <span
      className="flex shrink-0 items-center justify-center rounded-2xl bg-[var(--brand)] font-display text-[var(--brand-ink)]"
      style={{ width: size, height: size, fontSize: size * 0.34 }}
      aria-hidden="true"
    >
      {initials(teacher.name)}
    </span>
  );
}

export function SubjectCard({ subject }: { subject: Subject }) {
  const progress = subjectProgress(subject);
  const lessons = subject.units.reduce((sum, u) => sum + u.lessons.length, 0);
  return (
    <Link
      to={`/subject/${subject.id}`}
      className="focus-ring card group relative overflow-hidden p-4 transition-transform duration-200 hover:-translate-y-0.5"
    >
      <span
        className="absolute -end-6 -top-6 h-20 w-20 rounded-full opacity-12 blur-xl transition-opacity group-hover:opacity-25"
        style={{ background: subject.color }}
        aria-hidden="true"
      />
      <div className="flex items-start gap-3">
        <SubjectGlyph subject={subject} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-[0.95rem] text-[var(--ink)]">{subject.name}</p>
          <p className="mt-0.5 text-[0.7rem] text-[var(--ink-soft)]">
            {subject.units.length} وحدات · {lessons} درساً
          </p>
        </div>
        <ChevronLeft size={16} className="mt-1 text-[var(--ink-soft)] transition-transform group-hover:-translate-x-0.5" />
      </div>
      <div className="mt-3 flex items-center gap-2">
        <ProgressBar value={progress} height={6} color={subject.color} label={`تقدم ${subject.name}`} />
        <span className="w-9 shrink-0 text-end text-[0.7rem] font-semibold text-[var(--ink-soft)]">{progress}%</span>
      </div>
    </Link>
  );
}
