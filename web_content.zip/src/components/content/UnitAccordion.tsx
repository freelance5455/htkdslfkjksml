import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, ChevronDown, Clock3, PlayCircle } from 'lucide-react';
import type { Lesson, Subject, Unit } from '../../types';
import { getProgressMap, unitProgress } from '../../services/progress';
import { cn, formatDuration } from '../../utils/format';
import { ProgressBar } from '../ui/Card';

export function LessonRow({
  lesson,
  subject,
  index,
  active,
}: {
  lesson: Lesson;
  subject: Subject;
  index: number;
  active?: boolean;
}) {
  const progress = getProgressMap()[lesson.id];
  return (
    <Link
      to={`/lesson/${subject.id}/${lesson.id}`}
      className={cn(
        'focus-ring group flex items-center gap-3 rounded-2xl px-2 py-2.5 transition-colors hover:bg-[var(--surface-2)]',
        active && 'bg-[var(--surface-2)]',
      )}
    >
      <span
        className={cn(
          'flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[0.72rem] font-semibold',
          progress?.completed
            ? 'bg-[#e6f7ef] text-[#0b6b4f] dark:bg-[#0e3a2f] dark:text-[#6fe3bd]'
            : 'bg-[var(--surface-2)] text-[var(--ink-soft)]',
        )}
      >
        {progress?.completed ? <Check size={15} /> : Number(index) + 1}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[0.86rem] font-medium text-[var(--ink)]">{lesson.title}</span>
        <span className="mt-0.5 flex items-center gap-2 text-[0.68rem] text-[var(--ink-soft)]">
          <Clock3 size={11} /> {formatDuration(lesson.duration)}
          {progress && progress.position > 5 && !progress.completed ? (
            <span className="text-[var(--gold)]">· توقفت عند {formatDuration(progress.position)}</span>
          ) : null}
          {progress?.completed ? <span className="text-[var(--success)]">· مكتمل</span> : null}
        </span>
      </span>
      <PlayCircle size={19} className="shrink-0 text-[var(--ink-soft)] transition-colors group-hover:text-[var(--gold)]" />
    </Link>
  );
}

export function UnitAccordion({
  unit,
  subject,
  defaultOpen,
  activeLessonId,
}: {
  unit: Unit;
  subject: Subject;
  defaultOpen?: boolean;
  activeLessonId?: string;
}) {
  const [open, setOpen] = useState(Boolean(defaultOpen));
  const progress = unitProgress(unit.lessons);

  return (
    <div className="card overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="focus-ring flex w-full items-center gap-3 p-4 text-start"
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="truncate font-display text-[0.95rem] text-[var(--ink)]">{unit.title}</h3>
            {progress === 100 ? (
              <span className="rounded-full bg-[#e6f7ef] px-1.5 py-0.5 text-[0.6rem] text-[#0b6b4f] dark:bg-[#0e3a2f] dark:text-[#6fe3bd]">
                مكتملة
              </span>
            ) : null}
          </div>
          <p className="mt-0.5 line-clamp-2 text-[0.72rem] leading-relaxed text-[var(--ink-soft)]">{unit.summary}</p>
          <div className="mt-2 flex items-center gap-2">
            <ProgressBar value={progress} height={5} color={subject.color} label={`تقدم ${unit.title}`} />
            <span className="w-8 shrink-0 text-end text-[0.65rem] text-[var(--ink-soft)]">{progress}%</span>
          </div>
        </div>
        <ChevronDown
          size={18}
          className={cn('shrink-0 text-[var(--ink-soft)] transition-transform', open && 'rotate-180')}
        />
      </button>

      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden border-t border-[var(--line)]"
          >
            <div className="space-y-0.5 p-2">
              {unit.lessons.map((lesson, index) => (
                <LessonRow
                  key={lesson.id}
                  lesson={lesson}
                  subject={subject}
                  index={index}
                  active={lesson.id === activeLessonId}
                />
              ))}
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
