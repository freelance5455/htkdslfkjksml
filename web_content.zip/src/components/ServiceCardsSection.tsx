import React from 'react';
import { useApp } from '../context/AppContext';
import { ServiceType } from '../types';
import { translations } from '../data/translations';
import { 
  HeartPulse, 
  Building2, 
  Palmtree, 
  Plane, 
  Activity, 
  Globe2, 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  Send,
  Crown
} from 'lucide-react';

export const ServiceCardsSection: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const services = [
    {
      type: 'medical_sector' as ServiceType,
      targetView: 'medical' as const,
      title: t.s1Title,
      desc: t.s1Desc,
      icon: <HeartPulse className="w-7 h-7 text-[#D4AF37]" />,
      badge: isAr ? 'مستشفيات معتمدة' : 'Accredited Hospitals',
      features: isAr ? [
        'نخبة كبار أساتذة الجراحة وزراعة الأعضاء بمصر',
        'مستشفيات حائزة على اعتمادات JCI و GAHAR الذهبي',
        'مراكز أورام وقلب وقسطرة تداخلية متطورة',
        'استشارات طبية تمهيدية ودراسة الملفات قبل السفر'
      ] : [
        'Top surgical professors and organ transplant teams',
        'JCI and GAHAR Gold accredited academic hospitals',
        'Advanced oncology, cardiology and catheterization hubs',
        'Preliminary clinical board evaluation prior to travel'
      ]
    },
    {
      type: 'addiction_rehab' as ServiceType,
      targetView: 'rehab' as const,
      title: t.s2Title,
      desc: t.s2Desc,
      icon: <Building2 className="w-7 h-7 text-[#D4AF37]" />,
      badge: isAr ? 'سرية وخصوصية تامة' : 'Strict Confidentiality',
      features: isAr ? [
        'منتجعات استشفائية وتأهيلية مرخصة في بيئات معزولة',
        'بروتوكولات سحب السموم الطبية الآمنة بدون ألم',
        'العلاج السلوكي المعرفي وبرامج الدعم الأسري المتكامل',
        'متابعة مستمرة لعام كامل بعد الخروج لمنع الانتكاس'
      ] : [
        'Licensed secluded rehabilitation & wellness retreats',
        'Pain-free medically monitored clinical detoxification',
        'Cognitive behavioral therapy & intensive family guidance',
        '12-month proactive aftercare to prevent relapse'
      ]
    },
    {
      type: 'medical_tourism' as ServiceType,
      targetView: 'tourism' as const,
      title: t.s3Title,
      desc: t.s3Desc,
      icon: <Palmtree className="w-7 h-7 text-[#D4AF37]" />,
      badge: isAr ? 'استشفاء بيئي داعم' : 'Curative Nature',
      features: isAr ? [
        'واحة سيوة: حمامات الرمال الساخنة وبحيرات الملح الطبيعية',
        'أسوان: العلاج المناخي الخالي من الرطوبة لالتهابات المفاصل',
        'سفاجا: الرمال السوداء والمياه عالية الملوحة للصدفية',
        'إشراف طبي منظم دون استبدال العلاج السريري الأساسي'
      ] : [
        'Siwa Oasis: Therapeutic hot sand & pure mineral salt lakes',
        'Aswan: Dry winter climatotherapy for rheumatology & asthma',
        'Safaga: Red Sea black sands for natural skin wellness',
        'Strict medical screening as complementary rehabilitation'
      ]
    },
    {
      type: 'foreign_reception' as ServiceType,
      targetView: 'reception' as const,
      title: t.s4Title,
      desc: t.s4Desc,
      icon: <Plane className="w-7 h-7 text-[#D4AF37]" />,
      badge: isAr ? 'لوجستيات VIP متكاملة' : 'Full Concierge',
      features: isAr ? [
        'استقبال خاص من بوابة المطار وإنهاء إجراءات الجوازات',
        'أسطول سيارات خاصة وإسعاف طبي مجهز عند اللزوم',
        'حجوزات فندقية وشقق فندقية راقية بالقرب من المستشفيات',
        'مترجمون معتمدون ومرافق شخصي للمريض طوال الرحلة'
      ] : [
        'VIP tarmac greeting & seamless immigration customs passage',
        'Dedicated vehicle fleet with equipped medical ambulances',
        'Luxury hotel & apartment bookings adjacent to clinical hubs',
        'Certified medical interpreters & dedicated patient companion'
      ]
    },
    {
      type: 'patient_followup' as ServiceType,
      targetView: 'tracking' as const,
      title: t.s5Title,
      desc: t.s5Desc,
      icon: <Activity className="w-7 h-7 text-[#D4AF37]" />,
      badge: isAr ? 'بوابة المريض الرقمية' : 'Digital Health Record',
      features: isAr ? [
        'ملف صحي رقمي يوثق جميع مراحل العلاج والتنسيق',
        'جدول تفاعلي للمواعيد والعمليات والفحوصات',
        'تواصل دائم مع الطبيب الاستشاري والمنسق الميداني',
        'تقارير طبية مترجمة تسلم للمريض لمتابعة حالته بوطنه'
      ] : [
        'Encrypted digital record documenting all clinical stages',
        'Interactive calendar for tests, rounds, and surgeries',
        'Direct messaging line with assigned physician & navigator',
        'Bilingual discharge summaries & continued telehealth checkups'
      ]
    },
    {
      type: 'international_services' as ServiceType,
      targetView: 'international' as const,
      title: t.s6Title,
      desc: t.s6Desc,
      icon: <Globe2 className="w-7 h-7 text-[#D4AF37]" />,
      badge: isAr ? 'عالمي وعابر للحدود' : 'Cross-Border Care',
      features: isAr ? [
        'تيسير تأشيرات العلاج المصرية بالتعاون مع الجهات الرسمية',
        'استشارات مرئية دولية Telemedicine قبل السفر',
        'حاسبة شفافة للتكاليف التقديرية بالدولار والعملات المحلية',
        'شبكة تمثيلية في دول الخليج وإفريقيا وأوروبا الشرقية'
      ] : [
        'Official coordination for Egyptian medical entry visas',
        'Pre-travel cross-border telehealth consultations',
        'Transparent multi-currency cost calculator & breakdowns',
        'Liaison desks across GCC, Africa, and Eastern Europe'
      ]
    }
  ];

  return (
    <section id="services-grid" className="py-20 bg-zinc-950 text-white border-b border-[#D4AF37]/20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 bg-black text-amber-300 text-xs font-bold px-3.5 py-1.5 rounded-full border border-[#D4AF37]/40 shadow-sm">
            <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'منظومة الرعاية المتكاملة' : 'Comprehensive Healthcare Pillars'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
            {t.servicesTitle}
          </h2>
          <p className="text-base text-zinc-400 leading-relaxed">
            {t.servicesSubtitle}
          </p>
        </div>

        {/* 6 Services Grid in Black & Gold */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((item, idx) => (
            <div
              key={idx}
              className="bg-black/90 rounded-3xl p-7 border border-[#D4AF37]/30 hover:border-[#D4AF37] shadow-xl transition-all duration-300 flex flex-col justify-between group hover:shadow-[0_0_25px_rgba(212,175,55,0.2)]"
            >
              <div>
                {/* Card Top: Icon & Badge */}
                <div className="flex items-center justify-between mb-5">
                  <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-[#D4AF37]/40 flex items-center justify-center transition-transform group-hover:scale-110 duration-300 shadow-md">
                    {item.icon}
                  </div>
                  <span className="text-[11px] font-bold px-3 py-1 rounded-full border border-[#D4AF37]/40 bg-[#D4AF37]/15 text-amber-300">
                    {item.badge}
                  </span>
                </div>

                {/* Title & Description */}
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-amber-300 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed mb-6">
                  {item.desc}
                </p>

                {/* Feature Bullets */}
                <ul className="space-y-2.5 mb-8">
                  {item.features.map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2 text-xs text-zinc-300">
                      <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Bottom Buttons */}
              <div className="pt-4 border-t border-zinc-800 flex items-center gap-2">
                <button
                  onClick={() => {
                    setCurrentView(item.targetView);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="flex-1 py-2.5 px-3 bg-zinc-900 hover:bg-zinc-800 text-amber-200 text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5 border border-zinc-800 hover:border-[#D4AF37]/40"
                >
                  <span>{t.learnMore}</span>
                  <ArrowIcon className="w-3.5 h-3.5 text-[#D4AF37]" />
                </button>

                <button
                  onClick={() => openRequestModalForService(item.type)}
                  className="py-2.5 px-4 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs font-black rounded-xl transition-all shadow-md flex items-center gap-1.5"
                  title={t.requestThisService}
                >
                  <Send className="w-3.5 h-3.5 text-black" />
                  <span className="hidden sm:inline">{isAr ? 'طلب' : 'Request'}</span>
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
