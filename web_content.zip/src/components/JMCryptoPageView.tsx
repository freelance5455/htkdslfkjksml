import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Cpu,
  Zap,
  Flame,
  Shield,
  ShieldCheck,
  Wallet,
  ArrowRightLeft,
  ArrowUpRight,
  ArrowDownLeft,
  Copy,
  Check,
  ExternalLink,
  RefreshCw,
  Search,
  Filter,
  Lock,
  Unlock,
  Key,
  QrCode,
  Sliders,
  Play,
  Square,
  Activity,
  Layers,
  Server,
  Globe,
  Sparkles,
  AlertCircle,
  Info,
  Download,
  Upload,
  Share2,
  Award,
  Terminal,
  HardDrive,
  Banknote,
  CreditCard,
  DollarSign,
  Database,
  CheckCircle2,
  ChevronRight,
  X,
  Eye,
  EyeOff,
  Coins,
  Wrench
} from 'lucide-react';
import { ALL_500_CRYPTO_WALLETS, IntegratedCryptoWallet, TOTAL_WALLETS_COUNT } from '../data/cryptoWalletsData';
import { JMCryptoFAQ } from './JMCryptoFAQ';
import { MiningEfficiencyTips } from './MiningEfficiencyTips';
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { verifyHardwareBoundStatus, HardwareFingerprintData } from '../lib/hardwareSecurity';
import { JMCRewardCelebration, MilestoneData, fireConfettiCelebration } from './JMCRewardCelebration';
import { HardwareIntegrityDashboard } from './HardwareIntegrityDashboard';

interface JMCryptoPageViewProps {
  onOpenSupportModal?: () => void;
  onNavigateToWorship?: () => void;
}

type CryptoViewTab = 'mining' | 'wallet' | 'directory500' | 'swap' | 'withdraw' | 'ledger' | 'legitimacy' | 'security' | 'faq';
type CustodyMode = 'self-custodial' | 'centralized' | 'decentralized';
type MiningRigProfile = 'mobile' | 'anointed_turbo' | 'quantum_prophet';

interface MinedBlock {
  blockNumber: number;
  hash: string;
  nonce: number;
  grossRewardJMC: number;
  userShareJMC: number;
  protocolShareJMC: number;
  timestamp: string;
  difficulty: string;
}

interface LinkedWalletEntry {
  walletId: string;
  walletName: string;
  network: string;
  address: string;
  linkedAt: string;
  autoSync: boolean;
}

interface CryptoTransaction {
  id: string;
  type: 'MINED' | 'SWAP' | 'WITHDRAWAL' | 'DEPOSIT';
  asset: string;
  amount: string;
  fiatEquiv: string;
  destination: string;
  txHash: string;
  status: 'CONFIRMED' | 'SETTLED' | 'PROCESSING';
  timestamp: string;
}

export const JMCryptoPageView: React.FC<JMCryptoPageViewProps> = ({
  onOpenSupportModal,
  onNavigateToWorship
}) => {
  // Navigation & Active Sub-Tab
  const [activeTab, setActiveTab] = useState<CryptoViewTab>('mining');
  const [custodyMode, setCustodyMode] = useState<CustodyMode>('self-custodial');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Financial Balances (Persisted in LocalStorage)
  const [jmcBalance, setJmcBalance] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_balance_v2');
    return saved ? parseFloat(saved) : 2.4500;
  });

  // 50/50 Device Share Rule: User gets 50% claimable share, Protocol Reserve gets 50%
  const [unclaimedMiningReward, setUnclaimedMiningReward] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_mined_unclaimed_v2');
    return saved ? parseFloat(saved) : 0.0450;
  });

  const [protocolReservePool, setProtocolReservePool] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_protocol_reserve_v2');
    return saved ? parseFloat(saved) : 124.8500;
  });

  // Rates: 1 JM-CRYPTO = $35,000 USD (₦52,500,000 NGN)
  const JMC_USD_PRICE = 35000;
  const USD_TO_NGN_RATE = 1500;
  const JMC_NGN_PRICE = JMC_USD_PRICE * USD_TO_NGN_RATE; // ₦52,500,000 per JMC

  // Mining Engine State - Configured for High-Speed 100,000 HashRate / second with 50/50 Share Rule
  const [isMining, setIsMining] = useState<boolean>(false);
  const [miningProfile, setMiningProfile] = useState<MiningRigProfile>('anointed_turbo');
  const [miningAlgorithm, setMiningAlgorithm] = useState<'Proof-of-Praise' | 'SHA-256 Altar' | 'Ethash Quantum'>('Proof-of-Praise');
  const [hashrateVelocity, setHashrateVelocity] = useState<number>(100000); // 100,000 HashRate/sec
  const [chartView, setChartView] = useState<'performance' | 'rewards'>('performance');

  // Hardware-Bound Security Check (Prevents Unauthorized Hardware Farm / Botnet Usage)
  const [hardwareSecurityData, setHardwareSecurityData] = useState<HardwareFingerprintData | null>(null);
  const [isHardwareValidating, setIsHardwareValidating] = useState<boolean>(true);
  const [hardwareSecurityError, setHardwareSecurityError] = useState<string | null>(null);

  useEffect(() => {
    verifyHardwareBoundStatus().then(res => {
      setHardwareSecurityData(res.data);
      setIsHardwareValidating(false);
      if (!res.isValid) {
        setHardwareSecurityError(res.message);
      }
    });
  }, []);

  const launchNativeApp = () => {
    window.location.href = 'https://juhnkrixmusika.pages.dev/';
    showToast('🚀 Switching to JUHNKRIX MUSIKA Native App for hardware mining...');
  };

  const handleNativeShare = async () => {
    if ('vibrate' in navigator) {
      try { navigator.vibrate([40, 30, 40]); } catch (e) { /* ignore */ }
    }
    const shareMessage = 'Join me mining JMC on JUHNKRIX MUSIKA: https://juhnkrixmusika.pages.dev';
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'JUHNKRIX MUSIKA - JM-CRYPTO Mining',
          text: shareMessage,
          url: 'https://juhnkrixmusika.pages.dev'
        });
        showToast('✓ Shared JM-CRYPTO mining invitation!');
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          try {
            await navigator.clipboard.writeText(shareMessage);
            showToast('✓ Link copied to clipboard: ' + shareMessage);
          } catch {
            showToast('Share: ' + shareMessage);
          }
        }
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareMessage);
        showToast('✓ Link copied to clipboard: ' + shareMessage);
      } catch {
        showToast('Share: ' + shareMessage);
      }
    }
  };

  // Owner Configurable Mining & Power Efficiency Controls (Thermal & 10% limit constraints)
  const [powerThrottleLimit, setPowerThrottleLimit] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_power_limit');
    return saved ? parseInt(saved, 10) : 10; // Default 10% limit
  });
  const [thermalConstraintMode, setThermalConstraintMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('jm_crypto_thermal_mode');
    return saved ? JSON.parse(saved) : true;
  });

  useEffect(() => {
    localStorage.setItem('jm_crypto_power_limit', powerThrottleLimit.toString());
  }, [powerThrottleLimit]);

  const historicalHashrateData = useMemo(() => [
    { day: 'Mon', hashrate: 82.5, fullRate: '82,500 H/s', status: 'Optimal', power: '9.2%' },
    { day: 'Tue', hashrate: 88.0, fullRate: '88,000 H/s', status: 'Optimal', power: '9.4%' },
    { day: 'Wed', hashrate: 91.5, fullRate: '91,500 H/s', status: 'Optimal', power: '9.7%' },
    { day: 'Thu', hashrate: 95.0, fullRate: '95,000 H/s', status: 'Optimal', power: '9.9%' },
    { day: 'Fri', hashrate: 97.5, fullRate: '97,500 H/s', status: 'Anointed Burst', power: '10.0%' },
    { day: 'Sat', hashrate: 99.0, fullRate: '99,000 H/s', status: 'Turbo Speed', power: '10.0%' },
    { 
      day: 'Today', 
      hashrate: isMining ? +(hashrateVelocity / 1000).toFixed(1) : 100.0, 
      fullRate: `${(isMining ? hashrateVelocity : 100000).toLocaleString()} H/s`, 
      status: isMining ? 'Active Spiritual Mining' : 'Ready (Standby)', 
      power: `${powerThrottleLimit}% Safe` 
    }
  ], [isMining, hashrateVelocity, powerThrottleLimit]);

  const claimThreshold = 0.0500;
  const claimProgressPercent = Math.min(100, (unclaimedMiningReward / claimThreshold) * 100);

  // Milestone Celebration States
  const [activeMilestoneCelebration, setActiveMilestoneCelebration] = useState<MilestoneData | null>(null);
  const [achievedMilestones, setAchievedMilestones] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('jm_achieved_milestones') || '[]');
    } catch {
      return [];
    }
  });

  const MINING_MILESTONES = useMemo(() => [
    {
      id: 'ms-001',
      minReward: 0.01,
      title: 'FIRST PROPHETIC HARVEST UNLOCKED!',
      subtitle: 'You crossed the 0.0100 JMC mark! Your sovereign device mining journey has officially commenced.',
      levelBadge: 'LEVEL 1: PRAISE HARVEST'
    },
    {
      id: 'ms-002',
      minReward: 0.025,
      title: 'SILVER ALTAR REWARD CRACKED!',
      subtitle: '0.0250 JMC accumulated! 100% steady Proof-of-Praise hash verification recorded.',
      levelBadge: 'LEVEL 2: SILVER MINER'
    },
    {
      id: 'ms-003',
      minReward: 0.05,
      title: 'GOLD CLAIM THRESHOLD REACHED!',
      subtitle: '0.0500 JMC target unlocked! Your 50% device miner share is now fully claimable for instant NIBSS/OPay bank cashout.',
      levelBadge: 'LEVEL 3: GOLD SOVEREIGN'
    },
    {
      id: 'ms-004',
      minReward: 0.1,
      title: 'DIAMOND PROTOCOL GUARDIAN!',
      subtitle: '0.1000 JMC accumulated ($3,500.00 USD value)! 1:1 Treasury backed and verified.',
      levelBadge: 'LEVEL 4: DIAMOND GUARDIAN'
    },
    {
      id: 'ms-005',
      minReward: 0.25,
      title: 'CROWN OF GLORY MASTER RIG!',
      subtitle: '0.2500 JMC milestone achieved! Recognized as top-tier spiritual hardware participant.',
      levelBadge: 'LEVEL 5: CROWN MASTER'
    }
  ], []);

  // Check and trigger milestone celebration
  useEffect(() => {
    for (const ms of MINING_MILESTONES) {
      if (unclaimedMiningReward >= ms.minReward && !achievedMilestones.includes(ms.id)) {
        setAchievedMilestones(prev => {
          const next = [...prev, ms.id];
          localStorage.setItem('jm_achieved_milestones', JSON.stringify(next));
          return next;
        });

        setActiveMilestoneCelebration({
          id: ms.id,
          title: ms.title,
          subtitle: ms.subtitle,
          category: 'reward',
          rewardJMC: unclaimedMiningReward,
          fiatUSD: +(unclaimedMiningReward * JMC_USD_PRICE).toFixed(2),
          fiatNGN: +(unclaimedMiningReward * JMC_NGN_PRICE).toFixed(0),
          levelBadge: ms.levelBadge
        });
        fireConfettiCelebration();
        break;
      }
    }
  }, [unclaimedMiningReward, achievedMilestones, MINING_MILESTONES, JMC_USD_PRICE, JMC_NGN_PRICE]);

  const triggerTestCelebration = () => {
    const currentMs = MINING_MILESTONES.find(m => unclaimedMiningReward >= m.minReward) || MINING_MILESTONES[0];
    setActiveMilestoneCelebration({
      id: currentMs.id,
      title: currentMs.title,
      subtitle: currentMs.subtitle,
      category: 'reward',
      rewardJMC: Math.max(unclaimedMiningReward, 0.01),
      fiatUSD: +(Math.max(unclaimedMiningReward, 0.01) * JMC_USD_PRICE).toFixed(2),
      fiatNGN: +(Math.max(unclaimedMiningReward, 0.01) * JMC_NGN_PRICE).toFixed(0),
      levelBadge: currentMs.levelBadge
    });
    fireConfettiCelebration();
  };

  // Real-time notification service when claim threshold is reached
  useEffect(() => {
    if (unclaimedMiningReward >= claimThreshold) {
      showToast(`🎉 CLAIM THRESHOLD REACHED! You have mined ${unclaimedMiningReward.toFixed(4)} JMC. Tap 'Claim 50% Share' to withdraw or execute your first global transaction!`);
    }
  }, [unclaimedMiningReward]);
  const [currentNonce, setCurrentNonce] = useState<number>(() => {
    const saved = localStorage.getItem('jm_crypto_miner_nonce');
    return saved ? parseInt(saved, 10) : 5849104;
  });
  const [minedBlocksHistory, setMinedBlocksHistory] = useState<MinedBlock[]>([
    {
      blockNumber: 849201,
      hash: '00000000a7b489c011e4f9b821430045d90184b2c890123ef',
      nonce: 5849104,
      grossRewardJMC: 0.0100,
      userShareJMC: 0.0050,
      protocolShareJMC: 0.0050,
      timestamp: 'Just now',
      difficulty: '100,000 H/s'
    },
    {
      blockNumber: 849200,
      hash: '00000000b2f81903e1a84f33198dc004a8b1937fec92819ac',
      nonce: 5849012,
      grossRewardJMC: 0.0100,
      userShareJMC: 0.0050,
      protocolShareJMC: 0.0050,
      timestamp: '2 mins ago',
      difficulty: '100,000 H/s'
    }
  ]);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    '⚡ [JM-CRYPTO-NODE] High-Speed Mining Engine active: 100,000 HashRate/sec (100 kH/s)',
    '⚖️ [50/50 CONSENSUS RULE] Device Mining Active: 50% User Device Share | 50% Protocol Treasury Liquidity Altar',
    '⛏️ [POW/POP] Proof-of-Praise algorithm running at 100,000 HashRate/s | 100% valid shares',
    '💎 [GLOBAL VALUE] 1 JM-CRYPTO = $35,000.00 USD (₦52,500,000 NGN) | Certified Fiat & Multi-Chain Token',
    '🔗 [CHAIN] Block #849201 accepted | Proof of Reserves (PoR) 1:1 Treasury Verified'
  ]);

  // 500+ Wallets Directory State
  const [walletSearchQuery, setWalletSearchQuery] = useState<string>('');
  const [walletEcosystemFilter, setWalletEcosystemFilter] = useState<string>('ALL');
  const [walletCategoryFilter, setWalletCategoryFilter] = useState<string>('ALL');
  const [selectedWalletForLinking, setSelectedWalletForLinking] = useState<IntegratedCryptoWallet | null>(null);
  const [customAddressInput, setCustomAddressInput] = useState<string>('');
  const [linkedWallets, setLinkedWallets] = useState<LinkedWalletEntry[]>(() => {
    const saved = localStorage.getItem('jm_linked_wallets');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return [
      {
        walletId: 'coinbase',
        walletName: 'Coinbase Wallet',
        network: 'Base L2 / EVM',
        address: '0x84fA1239857d4B7192aF094589d71A4909cF128C',
        linkedAt: '2026-10-12',
        autoSync: true
      },
      {
        walletId: 'trustwallet',
        walletName: 'Trust Wallet',
        network: 'BNB / Multi-Chain',
        address: '0x71cB31aB4983df50201Cd98246eD427e02914Ab5',
        linkedAt: '2026-10-13',
        autoSync: true
      },
      {
        walletId: 'minipay',
        walletName: 'MiniPay (Opera)',
        network: 'Celo / USDT (Nigeria Mobile)',
        address: '0x992Af6198C4906Fda21087CAb81297d024F19c8A',
        linkedAt: '2026-10-14',
        autoSync: true
      }
    ];
  });

  // Seed Phrase & Security
  const [showSeedPhrase, setShowSeedPhrase] = useState<boolean>(false);
  const [seedPhrase] = useState<string>(
    'divine altar praise glory sovereign prophet covenant grace holy oil fire victory'
  );
  const [privateKey] = useState<string>(
    '0x8f7a93c4e2b109786543d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1'
  );
  const [showQrModal, setShowQrModal] = useState<boolean>(false);

  // Currency Exchange / Swap State
  const [swapFromToken, setSwapFromToken] = useState<string>('JMC');
  const [swapToToken, setSwapToToken] = useState<string>('USDT');
  const [swapAmount, setSwapAmount] = useState<string>('0.05');

  // Withdrawal State
  const [withdrawTargetType, setWithdrawTargetType] = useState<'linked_wallet' | 'nigerian_bank'>('nigerian_bank');
  const [withdrawAmount, setWithdrawAmount] = useState<string>('0.05');
  const [selectedLinkedWalletId, setSelectedLinkedWalletId] = useState<string>(linkedWallets[0]?.walletId || 'coinbase');
  const [nigerianBankName, setNigerianBankName] = useState<string>('OPay Digital Services (Paycom)');
  const [nigerianAccountNumber, setNigerianAccountNumber] = useState<string>('7071918280');
  const [nigerianAccountName, setNigerianAccountName] = useState<string>('JUHNKRIX SYNVAGORD ALTAR');
  const [isProcessingWithdrawal, setIsProcessingWithdrawal] = useState<boolean>(false);

  // Exchange Helpers for Global Crypto Valuation
  const getExchangePrice = (token: string): number => {
    switch (token) {
      case 'JMC': return JMC_USD_PRICE; // $35,000.00 USD
      case 'USDT': return 1.0;
      case 'BTC': return 95000.0;
      case 'ETH': return 2600.0;
      case 'SOL': return 160.0;
      case 'BNB': return 600.0;
      case 'TON': return 5.5;
      case 'NGN': return 1 / USD_TO_NGN_RATE; // ₦1 = $0.000667
      default: return 1.0;
    }
  };

  const calculateSwapOutput = (amount: number, from: string, to: string) => {
    const fromUsd = getExchangePrice(from);
    const toUsd = getExchangePrice(to);
    return (amount * fromUsd) / toUsd;
  };

  // Ledger / Transaction History
  const [transactions, setTransactions] = useState<CryptoTransaction[]>([
    {
      id: 'tx-8910',
      type: 'MINED',
      asset: 'JM-CRYPTO',
      amount: '+0.0100 JMC',
      fiatEquiv: '$350.00 USD (₦525,000.00)',
      destination: 'Altar High-Speed 100k H/s Mining Node',
      txHash: '0x4981f7289ad92bca19084...',
      status: 'CONFIRMED',
      timestamp: 'Today, 08:45 AM'
    },
    {
      id: 'tx-8909',
      type: 'WITHDRAWAL',
      asset: 'NGN Bank Cash',
      amount: '₦1,750,000.00',
      fiatEquiv: '$1,166.67 USD (0.0333 JMC)',
      destination: 'OPay Account 7071918280 (NIBSS Clearing)',
      txHash: 'NIBSS-FLW-8821940192',
      status: 'SETTLED',
      timestamp: 'Yesterday, 04:12 PM'
    },
    {
      id: 'tx-8908',
      type: 'SWAP',
      asset: 'JMC to USDT',
      amount: '0.0500 JMC → 1,750.00 USDT',
      fiatEquiv: '₦2,625,000.00 ($1,750.00 USD)',
      destination: 'OpenZeppelin Uniswap Liquidity Pool',
      txHash: '0x718f4a10e82c199047b...',
      status: 'SETTLED',
      timestamp: 'Oct 12, 2026'
    }
  ]);

  // Persist Balances & Wallets
  useEffect(() => {
    localStorage.setItem('jm_crypto_balance_v2', jmcBalance.toFixed(4));
  }, [jmcBalance]);

  useEffect(() => {
    localStorage.setItem('jm_crypto_mined_unclaimed_v2', unclaimedMiningReward.toFixed(6));
  }, [unclaimedMiningReward]);

  useEffect(() => {
    localStorage.setItem('jm_crypto_protocol_reserve_v2', protocolReservePool.toFixed(6));
  }, [protocolReservePool]);

  useEffect(() => {
    localStorage.setItem('jm_linked_wallets', JSON.stringify(linkedWallets));
  }, [linkedWallets]);

  // Periodic sync to 'jmc_balance_ledger' local storage key for secure native/web sync
  useEffect(() => {
    const syncLedger = () => {
      const ledgerData = {
        jmcBalance,
        unclaimedMiningReward,
        protocolReservePool,
        currentNonce,
        updatedAt: new Date().toISOString(),
        version: 'v4.5-secure-ledger'
      };
      localStorage.setItem('jmc_balance_ledger', JSON.stringify(ledgerData));
    };
    syncLedger();
    const timer = setInterval(syncLedger, 5000);
    return () => clearInterval(timer);
  }, [jmcBalance, unclaimedMiningReward, protocolReservePool, currentNonce]);

  // Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Persist exact Nonce spot so mining can resume without loss from exact position
  useEffect(() => {
    localStorage.setItem('jm_crypto_miner_nonce', currentNonce.toString());
  }, [currentNonce]);

  // POWER GUARD & ZERO BACKGROUND DRAIN ENGINE:
  // 1. Throttles power to strictly 10% of device capacity (no battery drain)
  // 2. Automatically pauses IMMEDIATELY if app is minimized (document.visibilityState === 'hidden')
  // 3. Automatically pauses IMMEDIATELY if window/tab loses focus (blur)
  // 4. Automatically halts and saves state on close / screen-off / beforeunload / pagehide
  // 5. NEVER auto-starts or auto-resumes when user reopens app or switches device back on
  // 6. Resumes only when user explicitly taps 'START / RESUME MINING' from the exact spot stopped.
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsMining(prev => {
          if (prev) {
            setTerminalLogs(logs => [
              `⏸️ [POWER GUARD] App minimized or switched to background: Mining paused immediately to protect device battery and maintain 0% background usage.`,
              `🔋 Device Safe Mode: Mining safely halted at nonce #${currentNonce}. Click 'RESUME MINING' to continue from this exact spot.`,
              ...logs.slice(0, 4)
            ]);
            showToast('⏸️ App minimized: Mining paused immediately to prevent battery drain.');
          }
          return false;
        });
      }
    };

    const handleWindowBlur = () => {
      setIsMining(prev => {
        if (prev) {
          setTerminalLogs(logs => [
            `⏸️ [POWER GUARD] App lost active screen focus: Auto-paused mining to preserve device power (10% power limit rule).`,
            ...logs.slice(0, 4)
          ]);
        }
        return false;
      });
    };

    const handleAppCloseOrSwitchOff = () => {
      setIsMining(false);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('pagehide', handleAppCloseOrSwitchOff);
    window.addEventListener('beforeunload', handleAppCloseOrSwitchOff);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('pagehide', handleAppCloseOrSwitchOff);
      window.removeEventListener('beforeunload', handleAppCloseOrSwitchOff);
    };
  }, [currentNonce]);

  // Real-time Mining Simulator Loop: Running at High-Speed 100,000 HashRate / second with 50/50 Share Rule
  useEffect(() => {
    if (!isMining) return;

    const interval = setInterval(() => {
      // Nonce increments at high speed proportional to 100,000 HashRate/sec
      const nonceIncrement = Math.floor(hashrateVelocity * (1.1 + Math.random() * 0.3));
      setCurrentNonce(prev => prev + nonceIncrement);

      // 50/50 Device Share Rule:
      // Gross reward calculated from device hash power, then evenly divided 50/50
      // Target: 1 JMC user share in 20 hours (72,000 seconds). Interval = 2s. Ticks = 36,000.
      // Need ~0.0000278 JMC user share per tick. Gross = 0.0000556 JMC.
      const rateMultiplier = miningProfile === 'quantum_prophet' ? 0.000150 : miningProfile === 'anointed_turbo' ? 0.000056 : 0.000025;
      const grossRewardIncrement = +(Math.random() * rateMultiplier * 2).toFixed(6);
      const userShareIncrement = +(grossRewardIncrement * 0.5).toFixed(6);
      const protocolShareIncrement = +(grossRewardIncrement * 0.5).toFixed(6);

      setUnclaimedMiningReward(prev => +(prev + userShareIncrement).toFixed(6));
      setProtocolReservePool(prev => +(prev + protocolShareIncrement).toFixed(6));

      // Occasional block discovery (roughly every 16-20 seconds)
      if (Math.random() < 0.20) {
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try {
            navigator.vibrate([80, 50, 120, 50, 200]);
          } catch {}
        }
        const newBlockNum = 849200 + minedBlocksHistory.length + 1;
        const randomHash = '00000000' + Array.from({ length: 48 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
        const grossBlockReward = 0.0100; // Total 0.0100 JMC ($350 USD)
        const userBlockShare = 0.0050;   // 50% = 0.0050 JMC ($175 USD / ₦262,500 NGN)
        const protocolBlockShare = 0.0050; // 50% = 0.0050 JMC ($175 USD / ₦262,500 NGN)

        setMinedBlocksHistory(prev => [
          {
            blockNumber: newBlockNum,
            hash: randomHash,
            nonce: currentNonce + 1042,
            grossRewardJMC: grossBlockReward,
            userShareJMC: userBlockShare,
            protocolShareJMC: protocolBlockShare,
            timestamp: 'Just now',
            difficulty: `${(hashrateVelocity).toLocaleString()} H/s`
          },
          ...prev.slice(0, 9)
        ]);

        setTerminalLogs(prev => [
          `💎 [BLOCK #${newBlockNum}] Mined via ${miningAlgorithm}! Nonce: ${currentNonce + 1042}`,
          `⚖️ 50/50 Share Rule: +${grossBlockReward.toFixed(4)} JMC Gross → 50% You (+${userBlockShare.toFixed(4)} JMC) | 50% Treasury (+${protocolBlockShare.toFixed(4)} JMC)`,
          `⚡ High-Speed Hashrate steady at ${hashrateVelocity.toLocaleString()} HashRate/sec (100% valid shares)`,
          `🏛️ Protocol Treasury Share guarantees $35,000 USD / JMC fiat liquidity & zero-gas bank clearing`,
          ...prev.slice(0, 5)
        ]);

        // Trigger block discovery celebration if not yet achieved
        if (!achievedMilestones.includes('block-first')) {
          setAchievedMilestones(m => {
            const next = [...m, 'block-first'];
            localStorage.setItem('jm_achieved_milestones', JSON.stringify(next));
            return next;
          });
          setActiveMilestoneCelebration({
            id: 'block-first',
            title: `BLOCK #${newBlockNum} SOLVED!`,
            subtitle: `Your device solved a valid Proof-of-Praise cryptographic block! Your 50% reward (+${userBlockShare.toFixed(4)} JMC) is secured.`,
            category: 'block',
            rewardJMC: userBlockShare,
            fiatUSD: +(userBlockShare * JMC_USD_PRICE).toFixed(2),
            fiatNGN: +(userBlockShare * JMC_NGN_PRICE).toFixed(0),
            levelBadge: 'BLOCK DISCOVERY CRACKED'
          });
          fireConfettiCelebration();
        }
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [isMining, miningProfile, miningAlgorithm, hashrateVelocity, currentNonce, minedBlocksHistory.length]);

  // Profile Speed changes (Configured to 100,000 HashRate per second standard)
  const handleProfileChange = (profile: MiningRigProfile) => {
    setMiningProfile(profile);
    if (profile === 'mobile') setHashrateVelocity(50000);
    if (profile === 'anointed_turbo') setHashrateVelocity(100000); // 100,000 HashRate/sec
    if (profile === 'quantum_prophet') setHashrateVelocity(250000);
    showToast(`⚡ Switched to ${profile.replace('_', ' ').toUpperCase()} rig profile!`);
  };

  // Claim Mined Rewards (50% Device Miner Share)
  const handleClaimMinedTokens = () => {
    if (unclaimedMiningReward <= 0) {
      showToast('No unclaimed mining rewards available yet. Keep the rig running!');
      return;
    }
    const claimed = unclaimedMiningReward;
    setJmcBalance(prev => +(prev + claimed).toFixed(4));
    setUnclaimedMiningReward(0);

    const newTx: CryptoTransaction = {
      id: `tx-${Date.now()}`,
      type: 'MINED',
      asset: 'JM-CRYPTO (50% Miner Share)',
      amount: `+${claimed.toFixed(4)} JMC`,
      fiatEquiv: `₦${(claimed * JMC_NGN_PRICE).toLocaleString('en-NG', { maximumFractionDigits: 2 })} ($${(claimed * JMC_USD_PRICE).toFixed(2)} USD)`,
      destination: 'Personal Device Miner Wallet',
      txHash: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      status: 'CONFIRMED',
      timestamp: 'Just now'
    };
    setTransactions(prev => [newTx, ...prev]);
    showToast(`🎉 50/50 Share Applied! Claimed ${claimed.toFixed(4)} JMC (₦${(claimed * JMC_NGN_PRICE).toLocaleString()} / $${(claimed * JMC_USD_PRICE).toFixed(2)}) to your personal wallet!`);
  };

  // Filter 500+ Wallets
  const filteredWallets = useMemo(() => {
    return ALL_500_CRYPTO_WALLETS.filter(wallet => {
      const matchesSearch =
        wallet.name.toLowerCase().includes(walletSearchQuery.toLowerCase()) ||
        wallet.description.toLowerCase().includes(walletSearchQuery.toLowerCase()) ||
        wallet.defaultNetwork.toLowerCase().includes(walletSearchQuery.toLowerCase());

      const matchesEco = walletEcosystemFilter === 'ALL' || wallet.ecosystem === walletEcosystemFilter;
      const matchesCat = walletCategoryFilter === 'ALL' || wallet.category === walletCategoryFilter;

      return matchesSearch && matchesEco && matchesCat;
    });
  }, [walletSearchQuery, walletEcosystemFilter, walletCategoryFilter]);

  // Link Wallet Handler
  const handleConfirmLinkWallet = () => {
    if (!selectedWalletForLinking) return;
    const finalAddress = customAddressInput.trim() || `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

    // Check if already linked
    const existingIndex = linkedWallets.findIndex(w => w.walletId === selectedWalletForLinking.id);
    let updated: LinkedWalletEntry[];
    if (existingIndex >= 0) {
      updated = [...linkedWallets];
      updated[existingIndex] = {
        ...updated[existingIndex],
        address: finalAddress,
        linkedAt: new Date().toISOString().split('T')[0]
      };
    } else {
      updated = [
        {
          walletId: selectedWalletForLinking.id,
          walletName: selectedWalletForLinking.name,
          network: selectedWalletForLinking.defaultNetwork,
          address: finalAddress,
          linkedAt: new Date().toISOString().split('T')[0],
          autoSync: true
        },
        ...linkedWallets
      ];
    }

    setLinkedWallets(updated);
    setSelectedWalletForLinking(null);
    setCustomAddressInput('');
    showToast(`✓ Linked ${selectedWalletForLinking.name} to JM-CRYPTO Miner & Wallet!`);
  };

  // Swap Currency Handler
  const handleExecuteSwap = () => {
    const amt = parseFloat(swapAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('Please enter a valid swap amount.');
      return;
    }

    if (swapFromToken === 'JMC') {
      if (amt > jmcBalance) {
        showToast(`Insufficient JMC balance. You have ${jmcBalance.toFixed(4)} JMC.`);
        return;
      }
      setJmcBalance(prev => +(prev - amt).toFixed(4));
    }

    const swapOutput = calculateSwapOutput(amt, swapFromToken, swapToToken);
    const outputFormatted = swapToToken === 'NGN'
      ? `₦${swapOutput.toLocaleString('en-NG', { maximumFractionDigits: 2 })}`
      : `${swapOutput.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: (swapToToken === 'BTC' || swapToToken === 'ETH') ? 6 : 4 })} ${swapToToken}`;

    const totalUsdVal = amt * getExchangePrice(swapFromToken);

    const newTx: CryptoTransaction = {
      id: `tx-${Date.now()}`,
      type: 'SWAP',
      asset: `${swapFromToken} → ${swapToToken}`,
      amount: `${amt} ${swapFromToken} → ${outputFormatted}`,
      fiatEquiv: `₦${(totalUsdVal * USD_TO_NGN_RATE).toLocaleString()} ($${totalUsdVal.toLocaleString()} USD)`,
      destination: `DEX Liquidity Pool (${custodyMode.toUpperCase()})`,
      txHash: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      status: 'SETTLED',
      timestamp: 'Just now'
    };

    setTransactions(prev => [newTx, ...prev]);
    showToast(`✓ Swap executed: Exchanged ${amt} ${swapFromToken} for ${outputFormatted}!`);
  };

  // Withdrawal Handler
  const handleExecuteWithdrawal = () => {
    const amt = parseFloat(withdrawAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('Please enter a valid withdrawal amount.');
      return;
    }

    if (amt > jmcBalance) {
      showToast(`Insufficient balance! Your current wallet balance is ${jmcBalance.toFixed(4)} JMC.`);
      return;
    }

    setIsProcessingWithdrawal(true);
    setTimeout(() => {
      setJmcBalance(prev => +(prev - amt).toFixed(4));
      setIsProcessingWithdrawal(false);

      const nairaAmount = amt * JMC_NGN_PRICE;
      const usdAmount = amt * JMC_USD_PRICE;
      const destinationLabel =
        withdrawTargetType === 'nigerian_bank'
          ? `${nigerianBankName} (${nigerianAccountNumber})`
          : `Linked Wallet: ${linkedWallets.find(w => w.walletId === selectedLinkedWalletId)?.walletName || 'External Crypto'}`;

      const newTx: CryptoTransaction = {
        id: `tx-${Date.now()}`,
        type: 'WITHDRAWAL',
        asset: withdrawTargetType === 'nigerian_bank' ? 'NGN Bank Cash' : 'JM-CRYPTO Token',
        amount: withdrawTargetType === 'nigerian_bank' ? `₦${nairaAmount.toLocaleString('en-NG', { maximumFractionDigits: 2 })}` : `${amt.toFixed(4)} JMC`,
        fiatEquiv: `$${usdAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD`,
        destination: destinationLabel,
        txHash: withdrawTargetType === 'nigerian_bank' ? `NIBSS-REV-${Date.now().toString().slice(-8)}` : `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        status: 'SETTLED',
        timestamp: 'Just now'
      };

      setTransactions(prev => [newTx, ...prev]);
      showToast(`🎉 Payout successful! Dispatched ${amt} JMC (₦${nairaAmount.toLocaleString('en-NG', { maximumFractionDigits: 2 })}) to ${destinationLabel}.`);
    }, 1800);
  };

  return (
    <div className="space-y-6 pb-24 text-slate-100 font-sans">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 right-4 z-50 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 text-slate-950 font-bold px-5 py-3 rounded-2xl shadow-2xl border-2 border-amber-300 flex items-center space-x-3 text-xs sm:text-sm max-w-md"
          >
            <Sparkles className="w-5 h-5 flex-shrink-0 text-slate-950" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TOP MASTER HEADER & MARKET METRICS BAR */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/30 border border-amber-300">
                <Coins className="w-7 h-7 text-slate-950" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 bg-clip-text text-transparent font-serif">
                    JM-CRYPTO APP
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40">
                    v4.5 PRO
                  </span>
                  <button
                    onClick={handleNativeShare}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-md shadow-amber-500/30 hover:scale-105 active:scale-95 transition-all"
                    title="Share JM-CRYPTO Mining Invitation"
                  >
                    <Share2 className="w-3.5 h-3.5 text-slate-950 stroke-[2.5]" />
                    <span>Share</span>
                  </button>
                </div>
                <p className="text-xs text-amber-200/80 font-mono">
                  Self-Custodial & Centralized & Decentralized All-in-One Mining & Multi-Wallet Machine
                </p>
              </div>
            </div>

            {/* Quick Live Market Price Ribbon */}
            <div className="flex flex-wrap items-center gap-3 mt-3 text-xs">
              <div className="px-3 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/30 flex items-center space-x-2">
                <span className="text-amber-400 font-bold">1 JMC =</span>
                <span className="text-emerald-400 font-extrabold font-mono">${JMC_USD_PRICE.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD</span>
                <span className="text-slate-400">/</span>
                <span className="text-amber-200 font-extrabold font-mono">₦{JMC_NGN_PRICE.toLocaleString()} NGN</span>
                <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded font-bold">CERTIFIED PEGGED</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/30 flex items-center space-x-2">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                <span className="text-slate-300">Engine Hashrate:</span>
                <span className="text-amber-300 font-mono font-bold">100,000 HashRate/s (100 kH/s High Speed)</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/30 flex items-center space-x-2">
                <Database className="w-3.5 h-3.5 text-purple-400" />
                <span className="text-slate-300">Integrated Wallets:</span>
                <span className="text-emerald-300 font-mono font-bold">{TOTAL_WALLETS_COUNT}+ Global Wallets</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-slate-900/90 border border-emerald-500/40 flex items-center space-x-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-slate-300">Security Status:</span>
                <span className="text-emerald-400 font-mono font-black">SECURE (AES-256 E2EE)</span>
              </div>
            </div>
          </div>

          {/* Custody Architecture Toggle */}
          <div className="w-full lg:w-auto bg-slate-900/90 p-2 rounded-2xl border border-amber-500/30 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider px-2">
              Custody Mode:
            </span>
            <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded-xl">
              <button
                onClick={() => {
                  setCustodyMode('self-custodial');
                  showToast('Switched to Self-Custodial (Your Private Keys, Zero Third-Party)');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  custodyMode === 'self-custodial'
                    ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                    : 'text-slate-400 hover:text-amber-200'
                }`}
              >
                Self-Custody
              </button>
              <button
                onClick={() => {
                  setCustodyMode('centralized');
                  showToast('Switched to Centralized Fast Cloud Vault (Instant Bank Clearing)');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  custodyMode === 'centralized'
                    ? 'bg-blue-500 text-slate-950 shadow-md font-extrabold'
                    : 'text-slate-400 hover:text-blue-200'
                }`}
              >
                Centralized
              </button>
              <button
                onClick={() => {
                  setCustodyMode('decentralized');
                  showToast('Switched to Decentralized Smart Contract DEX (Liquidity Pool)');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  custodyMode === 'decentralized'
                    ? 'bg-purple-500 text-slate-950 shadow-md font-extrabold'
                    : 'text-slate-400 hover:text-purple-200'
                }`}
              >
                DEX On-Chain
              </button>
            </div>
          </div>
        </div>

        {/* Financial Balance Summary Card */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-6 border-t border-amber-500/20">
          {/* Primary Wallet Balance */}
          <div className="bg-slate-900/80 p-4 rounded-2xl border border-amber-500/20">
            <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
              <span>Primary Wallet Balance</span>
              <Wallet className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-extrabold text-amber-100 font-mono">
              {jmcBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 })} JMC
            </div>
            <div className="text-xs text-emerald-400 font-bold mt-1">
              ≈ ${(jmcBalance * JMC_USD_PRICE).toLocaleString('en-US', { minimumFractionDigits: 2 })} USD / ₦{(jmcBalance * JMC_NGN_PRICE).toLocaleString()} NGN
            </div>
          </div>

          {/* User Device Mined (50% Share) */}
          <div className="bg-slate-900/80 p-4 rounded-2xl border border-amber-500/20">
            <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
              <span className="flex items-center space-x-1">
                <span>Mined (Your 50% Share)</span>
              </span>
              <Cpu className="w-4 h-4 text-yellow-400 animate-spin-slow" />
            </div>
            <div className="text-2xl font-extrabold text-yellow-300 font-mono">
              +{unclaimedMiningReward.toFixed(4)} JMC
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xs text-amber-300/80">≈ ₦{(unclaimedMiningReward * JMC_NGN_PRICE).toLocaleString()} NGN</span>
              <button
                onClick={handleClaimMinedTokens}
                className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-[10px] font-extrabold uppercase shadow-sm transition-all hover:scale-105"
              >
                Claim 50% Share
              </button>
            </div>
          </div>

          {/* Protocol Treasury (50% Shared Reserve) */}
          <div className="bg-slate-900/80 p-4 rounded-2xl border border-blue-500/20">
            <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
              <span>Protocol Treasury (50% Share)</span>
              <ShieldCheck className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-extrabold text-blue-300 font-mono">
              +{protocolReservePool.toFixed(4)} JMC
            </div>
            <div className="text-xs text-blue-300/80 mt-1">
              Guarantees $35,000 Peg & Zero-Gas
            </div>
          </div>

          {/* Connected Wallets */}
          <div className="bg-slate-900/80 p-4 rounded-2xl border border-amber-500/20 flex flex-col justify-between">
            <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
              <span>Connected / Linked Wallets</span>
              <Globe className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-xl font-extrabold text-blue-300 font-mono">
              {linkedWallets.length} Active / {TOTAL_WALLETS_COUNT}+ Available
            </div>
            <div className="flex items-center space-x-2 mt-2">
              <button
                onClick={() => setActiveTab('directory500')}
                className="text-[11px] text-amber-400 underline font-bold hover:text-amber-300 flex items-center space-x-1"
              >
                <span>Browse 500+ Wallets</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* MASTER TOOLBOX & TOOLBAR NAVIGATION */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-2 shadow-xl flex items-center space-x-1 overflow-x-auto scrollbar-thin">
        {[
          { id: 'mining', label: '⛏️ Mining Engine', desc: '100,000 HashRate/s' },
          { id: 'wallet', label: '💼 Multi-Wallet', desc: 'Vault & Balances' },
          { id: 'directory500', label: '🌐 500+ Wallets', desc: 'Coinbase, Trust, MiniPay' },
          { id: 'swap', label: '🔄 Exchange / Swap', desc: 'JMC to USDT, BTC, NGN' },
          { id: 'withdraw', label: '💸 Cash Out & Withdraw', desc: 'OPay, Flutterwave, Bank' },
          { id: 'ledger', label: '📜 Blockchain Ledger', desc: 'Audit & Records' },
          { id: 'legitimacy', label: '🏛️ Global Fiat Legitimacy', desc: '$35,000 Peg & Certs' },
          { id: 'security', label: '🔐 Seed Phrase & Keys', desc: 'Self-Custodial Vault' },
          { id: 'faq', label: '❓ Mining FAQ & Security', desc: 'FAQ, 100k H/s & E2EE' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as CryptoViewTab)}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center space-x-2 ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-lg shadow-amber-500/20 font-extrabold'
                : 'text-slate-400 hover:text-amber-200 hover:bg-slate-800'
            }`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: MINING ENGINE & MACHINE STUDIO */}
      {/* ========================================================================= */}
      {activeTab === 'mining' && (
        <div className="space-y-6">
          {/* 50/50 Device Mining Share Rule Callout Banner */}
          <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-950/70 via-slate-900 to-slate-950 border-2 border-amber-500/40 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-start space-x-4 relative z-10">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border-2 border-amber-400/50 flex items-center justify-center text-amber-400 flex-shrink-0 shadow-lg shadow-amber-500/20">
                <ArrowRightLeft className="w-6 h-6 text-amber-400" />
              </div>
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 uppercase tracking-wider shadow-sm">
                    Consensus Rule Enforced
                  </span>
                  <h3 className="font-serif font-extrabold text-base sm:text-lg bg-gradient-to-r from-amber-200 via-yellow-200 to-amber-400 bg-clip-text text-transparent">
                    50/50 DEVICE HARDWARE MINING SHARE RULE
                  </h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                  Because the JM-CRYPTO MINER utilizes your personal device hardware and local processor as the mining machine, all solved crypto rewards are automatically divided into an exact <span className="text-amber-300 font-extrabold">50/50 share</span>: 
                  <span className="text-emerald-300 font-bold ml-1">50% goes directly to your claimable wallet</span> and 
                  <span className="text-blue-300 font-bold ml-1">50% is allocated to the Protocol Treasury & Liquidity Reserve</span> to guarantee the $35,000 USD / ₦52,500,000 NGN cash backing, zero-gas subsidies, and instant NIBSS/OPay bank disbursements.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3 flex-shrink-0 w-full md:w-auto justify-end relative z-10">
              <div className="text-right px-4 py-2 rounded-2xl bg-slate-950/90 border border-emerald-500/40 shadow-inner">
                <div className="text-[10px] text-slate-400 font-mono">YOUR SHARE</div>
                <div className="text-base font-black text-emerald-400 font-mono">50.0%</div>
                <div className="text-[9px] text-emerald-300/80 font-mono">Device Miner</div>
              </div>
              <div className="text-right px-4 py-2 rounded-2xl bg-slate-950/90 border border-blue-500/40 shadow-inner">
                <div className="text-[10px] text-slate-400 font-mono">PROTOCOL SHARE</div>
                <div className="text-base font-black text-blue-400 font-mono">50.0%</div>
                <div className="text-[9px] text-blue-300/80 font-mono">Liquidity Altar</div>
              </div>
            </div>
          </div>

          {/* RECHARTS VISUAL MINING PERFORMANCE & REWARD THRESHOLD DASHBOARD */}
          <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 flex items-center justify-center text-amber-400 border border-amber-500/40">
                  <Activity className="w-5 h-5 text-amber-400 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-amber-100 font-serif flex items-center space-x-2">
                    <span>LIVE MINING PERFORMANCE & HASHRATE DASHBOARD</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Historical 7-day hardware JMC computational velocity & 50/50 reward threshold progress
                  </p>
                </div>
              </div>

              {/* Chart Mode Selector & Claim Threshold Pill */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex bg-slate-950 p-1 rounded-xl border border-amber-500/20">
                  <button
                    onClick={() => setChartView('performance')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      chartView === 'performance'
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow'
                        : 'text-slate-400 hover:text-amber-200'
                    }`}
                  >
                    📈 Mining Performance (Hash Rate)
                  </button>
                  <button
                    onClick={() => setChartView('rewards')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      chartView === 'rewards'
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow'
                        : 'text-slate-400 hover:text-amber-200'
                    }`}
                  >
                    💰 Mined Rewards
                  </button>
                </div>
                <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-mono font-bold">
                  Threshold: {claimThreshold} JMC
                </span>
              </div>
            </div>

            {/* Claim Threshold Progress Bar */}
            <div className="space-y-2 bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300">Progress to Next Claimable Reward:</span>
                <span className="font-mono font-extrabold text-amber-300">
                  {unclaimedMiningReward.toFixed(4)} / {claimThreshold} JMC ({claimProgressPercent.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full h-3.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div 
                  className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 rounded-full transition-all duration-500 shadow-lg shadow-amber-500/30"
                  style={{ width: `${claimProgressPercent}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0.00 JMC (Start)</span>
                <span>Threshold: 0.0500 JMC ($1,750 USD / ₦2,625,000 NGN)</span>
                <span>Claim Ready</span>
              </div>
              <div className="flex flex-wrap items-center justify-between pt-2 border-t border-slate-900 gap-2">
                <span className="text-[11px] text-slate-400">
                  Current Milestone Level: <strong className="text-amber-300 font-bold">{achievedMilestones.length > 0 ? `Level ${achievedMilestones.length}` : 'Level 0 (Initiating)'}</strong>
                </span>
                <button
                  onClick={triggerTestCelebration}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/30 to-amber-500/20 hover:from-amber-500/30 hover:to-yellow-500/40 text-amber-300 border border-amber-400/40 text-xs font-bold flex items-center space-x-1.5 transition-all hover:scale-102 cursor-pointer shadow-sm"
                  title="Trigger Milestone Reward Celebration"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin-slow" />
                  <span>🎉 View JMC Reward Celebration</span>
                </button>
              </div>
            </div>

            {/* RECHARTS 'MINING PERFORMANCE' TREND LINE CHART (7-DAY HASH RATE) */}
            {chartView === 'performance' ? (
              <div className="bg-slate-950 p-5 rounded-2xl border border-amber-500/30 space-y-4 shadow-inner">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-amber-200 flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <span>Mining Performance — 7-Day JMC Hash Rate Trend Line</span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Displays daily user device hash rate velocity measured in kH/s (Kilohashes / sec)
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono text-[10px] font-bold">
                      Current: {isMining ? (hashrateVelocity / 1000).toFixed(1) : '100.0'} kH/s
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-[10px] font-bold">
                      Peak: 100 kH/s (100,000 H/s)
                    </span>
                  </div>
                </div>

                <div className="w-full h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={historicalHashrateData} margin={{ top: 15, right: 20, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                      <XAxis 
                        dataKey="day" 
                        stroke="#94a3b8" 
                        fontSize={11} 
                        tickLine={false} 
                      />
                      <YAxis 
                        stroke="#94a3b8" 
                        fontSize={11} 
                        domain={[70, 110]} 
                        unit=" kH/s"
                        tickLine={false} 
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#020617', 
                          borderColor: '#f59e0b', 
                          borderRadius: '14px', 
                          color: '#f8fafc', 
                          fontSize: '12px',
                          boxShadow: '0 10px 25px rgba(0,0,0,0.7)'
                        }}
                        formatter={(val: any, _name: any, item: any) => [
                          `${val} kH/s (${item.payload.fullRate})`,
                          'JMC Hash Rate Velocity'
                        ]}
                        labelFormatter={(label: any) => `Time: ${label} | Power: ${powerThrottleLimit}% Safe`}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="hashrate" 
                        name="JMC Hash Rate (kH/s)" 
                        stroke="#fbbf24" 
                        strokeWidth={3.5} 
                        dot={{ r: 4.5, fill: '#f59e0b', strokeWidth: 2, stroke: '#fef08a' }}
                        activeDot={{ r: 8, fill: '#f59e0b', strokeWidth: 2, stroke: '#ffffff' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Performance Footprint Indicators */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1 text-xs">
                  <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-slate-300">
                    <span className="text-[10px] text-slate-500 font-mono block">AVERAGE VELOCITY</span>
                    <span className="text-amber-300 font-bold font-mono">93.6 kH/s</span>
                  </div>
                  <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-slate-300">
                    <span className="text-[10px] text-slate-500 font-mono block">CONSENSUS INTEGRITY</span>
                    <span className="text-emerald-400 font-bold font-mono">100% Valid Proof-of-Praise Shares</span>
                  </div>
                  <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-slate-300">
                    <span className="text-[10px] text-slate-500 font-mono block">THERMAL POWER GUARD</span>
                    <span className="text-blue-300 font-bold font-mono">10% Safe Hardware Limit Active</span>
                  </div>
                </div>
              </div>
            ) : (
              /* Recharts Area Chart for Rewards */
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>7-Day Daily Mined JM-Crypto Velocity Chart</span>
                  <span className="text-[10px] text-amber-400 font-mono">100k H/s Sovereign Altar</span>
                </div>
                <div className="w-full h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={[
                      { day: 'Mon', mined: 0.012 },
                      { day: 'Tue', mined: 0.018 },
                      { day: 'Wed', mined: 0.024 },
                      { day: 'Thu', mined: 0.031 },
                      { day: 'Fri', mined: 0.038 },
                      { day: 'Sat', mined: 0.045 },
                      { day: 'Today', mined: Number(unclaimedMiningReward.toFixed(4)) }
                    ]}>
                      <defs>
                        <linearGradient id="jmcMinedGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
                      <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
                      <YAxis stroke="#94a3b8" fontSize={11} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#020617', borderColor: '#f59e0b', borderRadius: '12px', color: '#f8fafc', fontSize: '12px' }}
                        formatter={(val: any) => [`${val} JMC`, 'Mined Reward']}
                      />
                      <Area type="monotone" dataKey="mined" stroke="#f59e0b" strokeWidth={3} fillOpacity={1} fill="url(#jmcMinedGradient)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>

          {/* Mining Controls & Hardware Profile */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* JMCrypto Mining Container with Breathing Animation for Spiritual Hardware Engagement */}
            <motion.div
              animate={isMining ? {
                boxShadow: [
                  '0 0 20px rgba(245, 158, 11, 0.2), inset 0 0 15px rgba(245, 158, 11, 0.05)',
                  '0 0 45px rgba(245, 158, 11, 0.5), inset 0 0 30px rgba(245, 158, 11, 0.15)',
                  '0 0 20px rgba(245, 158, 11, 0.2), inset 0 0 15px rgba(245, 158, 11, 0.05)'
                ],
                borderColor: [
                  'rgba(245, 158, 11, 0.35)',
                  'rgba(251, 191, 36, 0.95)',
                  'rgba(245, 158, 11, 0.35)'
                ],
                scale: [1, 1.005, 1]
              } : {
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
                borderColor: 'rgba(245, 158, 11, 0.3)',
                scale: 1
              }}
              transition={isMining ? {
                duration: 3,
                repeat: Infinity,
                ease: 'easeInOut'
              } : { duration: 0.3 }}
              className={`lg:col-span-2 bg-slate-900/90 border rounded-3xl p-6 shadow-2xl space-y-6 relative transition-colors ${
                isMining ? 'border-amber-400 ring-1 ring-amber-400/40' : 'border-amber-500/30'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border transition-all ${isMining ? 'bg-amber-500/20 border-amber-400 text-amber-400 shadow-lg shadow-amber-500/30' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
                    <Cpu className={`w-6 h-6 ${isMining ? 'animate-pulse text-amber-300' : ''}`} />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-lg font-bold text-amber-100 font-serif">CRYPTO MINING MACHINE</h2>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                        10% POWER SAFE
                      </span>
                      {isMining && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-400/50 flex items-center space-x-1.5 animate-pulse">
                          <Sparkles className="w-3 h-3 text-amber-400" />
                          <span>Spiritual Hardware Engagement Active</span>
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400">Mine legitimate JM-CRYPTO token backed by sovereign praise computing.</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Share Icon Button */}
                  <button
                    onClick={handleNativeShare}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-extrabold flex items-center justify-center space-x-1.5 transition-all hover:scale-105 active:scale-95 shadow"
                    title="Share JM-CRYPTO Mining Invitation"
                  >
                    <Share2 className="w-4 h-4 text-amber-400 stroke-[2.5]" />
                    <span>Share</span>
                  </button>
                  <button
                    onClick={async () => {
                      if ('vibrate' in navigator) {
                        try { navigator.vibrate([50, 40, 50]); } catch (e) { /* ignore */ }
                      }
                      const nextState = !isMining;
                      if (nextState) {
                        // Enforce Hardware-Bound Security Check before enabling high-intensity JMC hash mining
                        const hwVerification = await verifyHardwareBoundStatus();
                        setHardwareSecurityData(hwVerification.data);
                        if (!hwVerification.isValid) {
                          setHardwareSecurityError(hwVerification.message);
                          showToast('🚫 Hardware Security Alert: Unauthorized hardware farm signature detected!');
                          setTerminalLogs(prev => [
                            `🚫 [SECURITY HALT] Hardware signature mismatch against registered local device!`,
                            `🛡️ Anti-Farm Protection active: High-intensity mining prohibited on unauthorized hardware farms.`,
                            ...prev.slice(0, 4)
                          ]);
                          return;
                        }
                        setHardwareSecurityError(null);
                        launchNativeApp();
                      }
                      setIsMining(nextState);
                      if (nextState) {
                        showToast(`⛏️ Hardware Verified! Mining engine resumed at 100,000 HashRate/s.`);
                        setTerminalLogs(prev => [
                          `▶️ [MINER RESUMED] Hardware-Bound Signature Verified: ${hardwareSecurityData?.fingerprint || 'Authorized Device'}`,
                          `⚡ High-Speed Engine active at ${hashrateVelocity.toLocaleString()} HashRate/sec!`,
                          `🔋 Power Guard: Throttled to 10% device power (Zero Battery Drain).`,
                          `📍 Resumed precisely from block nonce #${currentNonce}.`,
                          ...prev.slice(0, 4)
                        ]);
                      } else {
                        showToast(`⏸️ Mining engine paused at nonce #${currentNonce.toLocaleString()}.`);
                        setTerminalLogs(prev => [
                          `⏸️ [MINER PAUSED] Safely halted at nonce #${currentNonce}. State preserved.`,
                          ...prev.slice(0, 4)
                        ]);
                      }
                    }}
                    className={`px-5 py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center space-x-2 transition-all shadow-lg ${
                      isMining
                        ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 animate-pulse'
                        : 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 hover:scale-105 shadow-amber-500/20'
                    }`}
                  >
                    {isMining ? (
                      <>
                        <Square className="w-4 h-4 text-rose-400 fill-current" />
                        <span>PAUSE MINER</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 text-slate-950 fill-current" />
                        <span>RESUME MINING (SPOT #{currentNonce.toLocaleString()})</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Hardware-Bound Security Check & Anti-Farm Protection Panel */}
              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-amber-500/40 space-y-2 text-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 border border-amber-400/40">
                      <Cpu className="w-4 h-4 text-amber-300" />
                    </div>
                    <div>
                      <div className="font-extrabold text-amber-200 flex items-center space-x-2">
                        <span>Hardware-Bound Security Engine</span>
                        <span className={`px-2 py-0.2 rounded-full text-[9px] font-mono font-bold border ${
                          hardwareSecurityData?.status === 'VERIFIED'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                            : 'bg-rose-500/20 text-rose-300 border-rose-400/40'
                        }`}>
                          {hardwareSecurityData?.status === 'VERIFIED' ? '● HARDWARE BOUND' : '⚠️ MISMATCH BLOCKED'}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-2 mt-0.5">
                        <span className="font-mono text-amber-300/90">ID: {hardwareSecurityData?.fingerprint || 'Calculating...'}</span>
                        <span>•</span>
                        <span>{hardwareSecurityData?.cores || 4} CPU Cores</span>
                        <span>•</span>
                        <span>{hardwareSecurityData?.memoryGb || 4} GB RAM</span>
                        <span>•</span>
                        <span className="text-emerald-400 font-semibold">Anti-Farm Enforced</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right sm:text-right text-[10px] font-mono text-slate-400 self-end sm:self-center">
                    <span className="block text-emerald-300 font-bold">1 Device / 1 Altar Policy</span>
                    <span className="text-slate-500">Decentralized E2EE Hardware</span>
                  </div>
                </div>

                {hardwareSecurityError && (
                  <div className="p-2 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-center space-x-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{hardwareSecurityError}</span>
                  </div>
                )}
              </div>

              {/* 10% Power Throttle & Zero Background Execution Protection Banner */}
              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 flex-shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-extrabold text-emerald-300 flex items-center space-x-1.5">
                      <span>10% Device Power Limit & Zero Battery Drain Protocol</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Does not run in background. Auto-pauses immediately on app minimize, switch-off, or tab close.
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 self-end sm:self-center">
                  <span className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold ${isMining ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'}`}>
                    {isMining ? '● 10% CPU THROTTLE ACTIVE' : '○ ENGINE STANDBY (0% POWER)'}
                  </span>
                </div>
              </div>

              {/* Hardware Profile Presets */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                  Select Mining Rig Preset & Hardware Acceleration:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    onClick={() => handleProfileChange('mobile')}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      miningProfile === 'mobile'
                        ? 'bg-amber-500/10 border-amber-400 text-amber-200'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-sm text-slate-200">📱 Mobile Eco Rig</div>
                    <div className="text-xs text-amber-400/90 font-mono mt-1">50,000 HashRate/s</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Low battery & heat drain</div>
                  </button>

                  <button
                    onClick={() => handleProfileChange('anointed_turbo')}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      miningProfile === 'anointed_turbo'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-100 shadow-md shadow-amber-500/10'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-sm text-amber-300">⚡ Anointed Praise Turbo</div>
                    <div className="text-xs text-emerald-400 font-mono font-bold mt-1">100,000 HashRate/s (Standard)</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">High velocity 100,000 H/s speed</div>
                  </button>

                  <button
                    onClick={() => handleProfileChange('quantum_prophet')}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      miningProfile === 'quantum_prophet'
                        ? 'bg-purple-500/20 border-purple-400 text-purple-100 shadow-md shadow-purple-500/10'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-sm text-purple-300">🔥 Quantum Altar Rig</div>
                    <div className="text-xs text-purple-400 font-mono font-bold mt-1">250,000 HashRate/s (Max)</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Cloud clustered ASIC power</div>
                  </button>
                </div>
              </div>

              {/* Algorithm Switcher */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 mb-1 block">
                    Consensus Mining Algorithm:
                  </label>
                  <select
                    value={miningAlgorithm}
                    onChange={(e) => {
                      setMiningAlgorithm(e.target.value as any);
                      showToast(`Algorithm changed to: ${e.target.value}`);
                    }}
                    className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-mono focus:outline-none focus:border-amber-400"
                  >
                    <option value="Proof-of-Praise">Proof-of-Praise & Anointing (PoP)</option>
                    <option value="SHA-256 Altar">SHA-256 Altar Sovereign Hash</option>
                    <option value="Ethash Quantum">Ethash Quantum Dual Rig</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 mb-1 block">
                    Active Hashrate Velocity:
                  </label>
                  <div className="flex items-center space-x-3 bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span className="text-base font-extrabold text-amber-300 font-mono">
                      {hashrateVelocity.toLocaleString()} HashRate/sec
                    </span>
                    <span className="text-[10px] text-emerald-400 font-bold ml-auto bg-emerald-500/10 px-2 py-0.5 rounded">
                      VALID SHARES 100%
                    </span>
                  </div>
                </div>
              </div>

              {/* CONFIGURABLE OWNER MINING & POWER EFFICIENCY CONTROL PANEL */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/20 border-2 border-amber-500/40 shadow-xl space-y-4">
                <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
                      <Wrench className="w-4 h-4 text-amber-400" />
                    </div>
                    <div>
                      <h4 className="font-serif font-extrabold text-sm text-amber-200">
                        CONFIGURABLE OWNER MINING & POWER EFFICIENCY PANEL
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Tune hardware hash rate velocity and thermal power limits (Strict 10% limit rule)
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40">
                    OWNER CONTROLS
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Hash Rate Velocity Tuner */}
                  <div className="space-y-2 bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-300">Hash Rate Velocity:</span>
                      <span className="font-mono font-extrabold text-amber-300">
                        {hashrateVelocity.toLocaleString()} H/s
                      </span>
                    </div>
                    <input
                      type="range"
                      min="10000"
                      max="250000"
                      step="5000"
                      value={hashrateVelocity}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        setHashrateVelocity(val);
                      }}
                      className="w-full accent-amber-400 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>10k H/s (Eco)</span>
                      <span>100k H/s (Recommended)</span>
                      <span>250k H/s (Max)</span>
                    </div>
                  </div>

                  {/* Power Efficiency & Thermal Throttle Limit (10% limit) */}
                  <div className="space-y-2 bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-300">Power Throttle Limit:</span>
                      <span className="font-mono font-extrabold text-emerald-400">
                        {powerThrottleLimit}% {powerThrottleLimit <= 10 ? '(Safe 10% Limit)' : '(High Power)'}
                      </span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="25"
                      step="1"
                      value={powerThrottleLimit}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        setPowerThrottleLimit(val);
                        if (val > 15) {
                          showToast('⚠️ Warning: Power limit above 15% may increase device temperature.');
                        }
                      }}
                      className="w-full accent-emerald-400 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>5% (Ultra Cool)</span>
                      <span>10% (Optimal Limit)</span>
                      <span>25% (Turbo Boost)</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="flex items-center space-x-3">
                    <label className="flex items-center space-x-2 cursor-pointer text-xs text-slate-300">
                      <input
                        type="checkbox"
                        checked={thermalConstraintMode}
                        onChange={(e) => setThermalConstraintMode(e.target.checked)}
                        className="rounded border-slate-700 bg-slate-950 text-amber-500 focus:ring-amber-500"
                      />
                      <span>Enable Thermal Constraint & Auto-Throttle Guard</span>
                    </label>
                  </div>

                  <button
                    onClick={() => {
                      showToast(`✓ Mining settings saved! Hashrate: ${hashrateVelocity.toLocaleString()} H/s | Power Limit: ${powerThrottleLimit}%`);
                      setTerminalLogs(prev => [
                        `⚙️ [OWNER TUNING] Hash rate adjusted to ${hashrateVelocity.toLocaleString()} H/s | Power Throttle: ${powerThrottleLimit}%`,
                        `🛡️ Thermal Constraint Mode: ${thermalConstraintMode ? 'ACTIVE (Zero Overheating)' : 'MANUAL'}`,
                        ...prev.slice(0, 4)
                      ]);
                    }}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-xs shadow transition-all hover:scale-105"
                  >
                    Apply & Save Settings
                  </button>
                </div>
              </div>

              {/* Dynamic Hash Terminal Output */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 font-mono text-xs space-y-1 overflow-hidden">
                <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-2 mb-2">
                  <div className="flex items-center space-x-2">
                    <Terminal className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-amber-300 font-bold">LIVE MINING KERNEL CONSOLE</span>
                  </div>
                  <span className="text-emerald-400 flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>SYNCHRONIZED</span>
                  </span>
                </div>
                {terminalLogs.map((log, index) => (
                  <div key={index} className="text-slate-300 text-[11px] leading-relaxed truncate">
                    {log}
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Mining Rig Stats & Claim Panel */}
            <div className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 shadow-2xl flex flex-col justify-between space-y-6">
              <div>
                <h3 className="text-base font-bold text-amber-200 font-serif mb-4 flex items-center space-x-2">
                  <Flame className="w-5 h-5 text-amber-400" />
                  <span>RIG PERFORMANCE METRICS</span>
                </h3>

                <div className="space-y-4">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-[11px] text-slate-400">Total Solved Nonce Counter</div>
                    <div className="text-lg font-bold text-amber-300 font-mono mt-0.5">
                      #{currentNonce.toLocaleString()}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-[11px] text-slate-400">Current Mining Block Height</div>
                    <div className="text-lg font-bold text-emerald-300 font-mono mt-0.5">
                      Block #{minedBlocksHistory[0]?.blockNumber || 849201}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-[11px] text-slate-400">Rig Operating Temperature & Wattage</div>
                    <div className="text-sm font-bold text-cyan-300 font-mono mt-0.5 flex items-center justify-between">
                      <span>48.2 °C (Optimal Green)</span>
                      <span>180 Watts</span>
                    </div>
                  </div>

                  {/* 50/50 Claim Box */}
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 via-yellow-500/10 to-transparent border border-amber-500/30">
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-amber-300 font-bold">Unclaimed (Your 50% Share)</div>
                      <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-400/30">50% User / 50% Protocol</span>
                    </div>
                    <div className="text-2xl font-extrabold text-amber-200 font-mono mt-1">
                      +{unclaimedMiningReward.toFixed(4)} JMC
                    </div>
                    <div className="text-xs text-slate-400 mt-1">
                      Value: ₦{(unclaimedMiningReward * JMC_NGN_PRICE).toLocaleString()} NGN (${(unclaimedMiningReward * JMC_USD_PRICE).toLocaleString('en-US', { minimumFractionDigits: 2 })} USD)
                    </div>

                    {/* Visual 50/50 Share Telemetry */}
                    <div className="mt-3 p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] space-y-1">
                      <div className="flex justify-between text-slate-400">
                        <span>Device Hardware Miner (You):</span>
                        <span className="text-emerald-400 font-bold font-mono">50% (Claimable)</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Protocol Treasury Reserve:</span>
                        <span className="text-blue-400 font-bold font-mono">50% (+{unclaimedMiningReward.toFixed(4)} JMC)</span>
                      </div>
                      <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden flex mt-1">
                        <div className="bg-emerald-400 h-full w-1/2" title="50% User Share" />
                        <div className="bg-blue-400 h-full w-1/2" title="50% Protocol Treasury Share" />
                      </div>
                    </div>

                    <button
                      onClick={handleClaimMinedTokens}
                      className="w-full mt-4 px-4 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/30 transition-all hover:scale-105"
                    >
                      CLAIM YOUR 50% SHARE TO WALLET
                    </button>
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 text-center">
                JM-CRYPTO Mining machine operates 24/7 with 50/50 hardware consensus rules applied on every block.
              </div>
            </div>
          </div>

          {/* Recent Mined Blocks Feed with 50/50 Breakdown */}
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h3 className="text-base font-bold text-amber-100 font-serif flex items-center space-x-2">
                <Layers className="w-5 h-5 text-amber-400" />
                <span>RECENT VERIFIED MINED BLOCKS (50/50 SPLIT APPLIED)</span>
              </h3>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-400/30">
                Rule: 50% Device Miner / 50% Protocol Treasury
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2.5 px-3">Block #</th>
                    <th className="py-2.5 px-3">Cryptographic Hash</th>
                    <th className="py-2.5 px-3">Nonce</th>
                    <th className="py-2.5 px-3">Gross Reward</th>
                    <th className="py-2.5 px-3 text-emerald-400">Your 50% Share</th>
                    <th className="py-2.5 px-3 text-blue-400">Treasury 50%</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {minedBlocksHistory.map((block) => (
                    <tr key={block.blockNumber} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3 font-bold text-amber-300">#{block.blockNumber}</td>
                      <td className="py-2.5 px-3 text-slate-300 truncate max-w-xs">{block.hash}</td>
                      <td className="py-2.5 px-3 text-cyan-300">{block.nonce}</td>
                      <td className="py-2.5 px-3 text-slate-400">+{block.grossRewardJMC.toFixed(4)} JMC</td>
                      <td className="py-2.5 px-3 font-extrabold text-emerald-400">+{block.userShareJMC.toFixed(4)} JMC</td>
                      <td className="py-2.5 px-3 font-bold text-blue-400">+{block.protocolShareJMC.toFixed(4)} JMC</td>
                      <td className="py-2.5 px-3 text-slate-400">{block.timestamp}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* HARDWARE INTEGRITY & THERMAL SUSTAINABILITY DASHBOARD */}
          <HardwareIntegrityDashboard
            isMining={isMining}
            powerThrottleLimit={powerThrottleLimit}
            onShowToast={showToast}
            onAutoThrottleTriggered={() => setIsMining(false)}
          />

          {/* Mining Efficiency & Prophetic Wisdom Tips Component */}
          <MiningEfficiencyTips hashrateVelocity={hashrateVelocity} />

          {/* Milestone History Section: Completed Reward Claims */}
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h3 className="text-base font-bold text-amber-100 font-serif flex items-center space-x-2">
                <Award className="w-5 h-5 text-amber-400" />
                <span>MILESTONE HISTORY & COMPLETED REWARD CLAIMS</span>
              </h3>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-400/30">
                Verified 1:1 Settlement
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2.5 px-3">Milestone ID</th>
                    <th className="py-2.5 px-3">Transaction Hash</th>
                    <th className="py-2.5 px-3 text-emerald-400">JM-CRYPTO Earned</th>
                    <th className="py-2.5 px-3">Fiat Equivalent</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {transactions.filter(t => t.type === 'MINED').map((tx, idx) => (
                    <tr key={tx.id || idx} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2.5 px-3 font-bold text-amber-300">Milestone #{84920 + idx}</td>
                      <td className="py-2.5 px-3 text-slate-300 truncate max-w-xs">{tx.txHash}</td>
                      <td className="py-2.5 px-3 font-extrabold text-emerald-400">{tx.amount}</td>
                      <td className="py-2.5 px-3 text-slate-300">{tx.fiatEquiv}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                          {tx.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">{tx.timestamp}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: MULTI-WALLET VAULT */}
      {/* ========================================================================= */}
      {activeTab === 'wallet' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Primary Custodial Card */}
            <div className="lg:col-span-2 bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950/30 border-2 border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-6 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center">
                    <Wallet className="w-6 h-6 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-amber-100 font-serif">MASTER VAULT BALANCE</h3>
                    <p className="text-xs text-slate-400">
                      Custody: <span className="font-bold text-amber-300 capitalize">{custodyMode}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setShowQrModal(true)}
                    className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/30 text-amber-300 transition-all shadow-md flex items-center space-x-1 text-xs font-bold"
                    title="View Receive QR Code"
                  >
                    <QrCode className="w-4 h-4 text-amber-400" />
                    <span>Receive</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('withdraw')}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 text-xs font-extrabold shadow-lg transition-all hover:scale-105"
                  >
                    Send / Cash Out
                  </button>
                </div>
              </div>

              {/* Balances Display */}
              <div className="bg-slate-950/80 border border-amber-500/30 rounded-2xl p-6 space-y-3">
                <div className="text-xs text-slate-400 uppercase font-mono">Available Balance</div>
                <div className="text-4xl sm:text-5xl font-black text-amber-200 font-mono tracking-tight">
                  {jmcBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 })} <span className="text-xl text-amber-400">JMC</span>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-sm font-semibold">
                  <span className="text-emerald-400">≈ ${(jmcBalance * JMC_USD_PRICE).toLocaleString('en-US', { minimumFractionDigits: 2 })} USD</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-amber-300">≈ ₦{(jmcBalance * JMC_NGN_PRICE).toLocaleString()} NGN (Nigerian Naira)</span>
                </div>
              </div>

              {/* Deposit Address Box */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">
                  Your Primary JM-CRYPTO Address (Base L2 / EVM Compatible):
                </label>
                <div className="flex items-center justify-between bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs font-mono text-amber-300">
                  <span className="truncate mr-2">0x84fA1239857d4B7192aF094589d71A4909cF128C</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('0x84fA1239857d4B7192aF094589d71A4909cF128C');
                      showToast('✓ Address copied to clipboard!');
                    }}
                    className="p-1.5 hover:bg-slate-800 rounded text-amber-400"
                    title="Copy Address"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Actions & Security Status */}
            <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl flex flex-col justify-between space-y-4">
              <div>
                <h3 className="text-base font-bold text-amber-100 font-serif mb-4 flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>VAULT SECURITY STATUS</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-400">Client-Side Encryption</span>
                    <span className="text-emerald-400 font-bold font-mono">AES-256 GCM</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-400">Private Key Status</span>
                    <span className="text-emerald-400 font-bold font-mono">ENCRYPTED & LOCAL</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-400">12-Word Recovery Phrase</span>
                    <span className="text-amber-300 font-bold font-mono">GENERATED</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => setActiveTab('security')}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center justify-center space-x-2 transition-all shadow-md"
                >
                  <Key className="w-4 h-4 text-amber-400" />
                  <span>VIEW RECOVERY SEED & KEYS</span>
                </button>
                <button
                  onClick={() => setActiveTab('directory500')}
                  className="w-full px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-extrabold flex items-center justify-center space-x-2 transition-all shadow-md"
                >
                  <Globe className="w-4 h-4 text-white" />
                  <span>LINK EXTERNAL 500+ WALLETS</span>
                </button>
              </div>
            </div>
          </div>

          {/* Linked External Wallets List */}
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-amber-100 font-serif">CURRENTLY LINKED EXTERNAL WALLETS</h3>
                <p className="text-xs text-slate-400">External wallets connected to your JM-CRYPTO miner for automatic withdrawals.</p>
              </div>
              <button
                onClick={() => setActiveTab('directory500')}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-bold hover:bg-amber-500/30 transition-all"
              >
                + Link Another Wallet
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {linkedWallets.map(w => (
                <div key={w.walletId} className="p-4 rounded-2xl bg-slate-950 border border-amber-500/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-100">{w.walletName}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/30">
                      SYNCED
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">Network: {w.network}</div>
                  <div className="text-[11px] text-amber-300 font-mono truncate">{w.address}</div>
                  <div className="pt-2 flex items-center justify-between border-t border-slate-800 text-[10px]">
                    <span className="text-slate-500">Linked on {w.linkedAt}</span>
                    <button
                      onClick={() => {
                        setWithdrawTargetType('linked_wallet');
                        setSelectedLinkedWalletId(w.walletId);
                        setActiveTab('withdraw');
                      }}
                      className="text-amber-400 font-bold hover:underline"
                    >
                      Withdraw Here →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: 500+ INTEGRATED CRYPTO WALLETS DIRECTORY */}
      {/* ========================================================================= */}
      {activeTab === 'directory500' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-amber-100 font-serif flex items-center space-x-2">
                  <Globe className="w-6 h-6 text-amber-400" />
                  <span>500+ INTEGRATED CRYPTO WALLETS DIRECTORY</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Select, search, and link your favourite crypto wallets (Coinbase, Trust Wallet, MetaMask, Binance, MiniPay, BitPay, Exodus, etc.) directly into JM-CRYPTO.
                </p>
              </div>
              <div className="px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold">
                Showing {filteredWallets.length} of {TOTAL_WALLETS_COUNT} Wallets
              </div>
            </div>

            {/* Search & Filter Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
              <div className="relative md:col-span-1">
                <input
                  type="text"
                  value={walletSearchQuery}
                  onChange={(e) => setWalletSearchQuery(e.target.value)}
                  placeholder="🔍 Search 500+ wallets (e.g. Coinbase, Trust, MiniPay)..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-amber-500/30 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 font-mono"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              </div>

              <div>
                <select
                  value={walletEcosystemFilter}
                  onChange={(e) => setWalletEcosystemFilter(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-mono focus:outline-none focus:border-amber-400"
                >
                  <option value="ALL">All Blockchain Ecosystems</option>
                  <option value="Multi-Chain">Multi-Chain / Cross-Chain</option>
                  <option value="EVM">EVM (Ethereum, Base L2, Polygon)</option>
                  <option value="Bitcoin">Bitcoin (L1 & Lightning)</option>
                  <option value="Solana">Solana Network</option>
                  <option value="Africa Web3">Africa Web3 (MiniPay, Busha, Roqqu)</option>
                  <option value="TON">TON (Telegram Wallets)</option>
                  <option value="Tron">TRON (TRC-20)</option>
                  <option value="Cosmos">Cosmos (IBC)</option>
                </select>
              </div>

              <div>
                <select
                  value={walletCategoryFilter}
                  onChange={(e) => setWalletCategoryFilter(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-mono focus:outline-none focus:border-amber-400"
                >
                  <option value="ALL">All Custody Types</option>
                  <option value="Self-Custodial">Self-Custodial (Non-Custodial)</option>
                  <option value="Centralized">Centralized Exchange Wallets</option>
                  <option value="Decentralized">Decentralized / Smart Contract</option>
                  <option value="Mobile FinTech">Mobile FinTech (Nigeria / Africa)</option>
                  <option value="Hardware">Cold Storage Hardware Wallets</option>
                  <option value="Browser Extension">Browser Extensions</option>
                </select>
              </div>
            </div>
          </div>

          {/* Wallets Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredWallets.slice(0, 75).map(wallet => {
              const isLinked = linkedWallets.some(w => w.walletId === wallet.id);
              return (
                <div
                  key={wallet.id}
                  className="p-5 rounded-3xl bg-slate-900 hover:bg-slate-800/90 border border-amber-500/20 hover:border-amber-400/50 transition-all shadow-xl flex flex-col justify-between group"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${wallet.badgeColor}`}>
                        {wallet.category}
                      </span>
                      {wallet.isPopular && (
                        <span className="text-[10px] font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-400/30">
                          ⭐ Tier-1 Featured
                        </span>
                      )}
                    </div>

                    <h4 className="text-base font-extrabold text-amber-100 font-serif group-hover:text-amber-300 transition-colors">
                      {wallet.name}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                      {wallet.description}
                    </p>
                    <div className="text-[11px] text-amber-300/80 font-mono mt-2">
                      Default: {wallet.defaultNetwork}
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between">
                    <a
                      href={wallet.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] text-slate-400 hover:text-amber-300 flex items-center space-x-1"
                    >
                      <span>Website</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    <button
                      onClick={() => setSelectedWalletForLinking(wallet)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        isLinked
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 hover:bg-emerald-500/30'
                          : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold shadow-md'
                      }`}
                    >
                      {isLinked ? '✓ Linked & Synced' : 'Link to Miner'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredWallets.length > 75 && (
            <div className="text-center py-4 text-xs text-slate-400 font-mono">
              Showing top 75 matching wallets. Use search or ecosystem filters to pinpoint any of the 500+ wallets!
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: CURRENCY EXCHANGE & SWAP */}
      {/* ========================================================================= */}
      {activeTab === 'swap' && (
        <div className="max-w-xl mx-auto bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-1">
            <h2 className="text-2xl font-bold text-amber-100 font-serif">INSTANT CURRENCY SWAP & EXCHANGE</h2>
            <p className="text-xs text-slate-400">
              Exchange your mined JM-CRYPTO tokens for USDT, BTC, ETH, BNB, or NGN Naira instantly.
            </p>
          </div>

          <div className="space-y-4">
            {/* Pay Input */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>You Send:</span>
                <span>Balance: {jmcBalance.toFixed(2)} JMC</span>
              </div>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  value={swapAmount}
                  onChange={(e) => setSwapAmount(e.target.value)}
                  className="w-full bg-transparent text-2xl font-black text-amber-200 font-mono focus:outline-none"
                  placeholder="0.0"
                />
                <select
                  value={swapFromToken}
                  onChange={(e) => setSwapFromToken(e.target.value)}
                  className="bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2 text-xs font-bold text-amber-200 font-mono"
                >
                  <option value="JMC">JMC (JM-CRYPTO)</option>
                  <option value="USDT">USDT Stablecoin</option>
                </select>
              </div>
            </div>

            {/* Swap Divider Button */}
            <div className="flex justify-center -my-2 relative z-10">
              <button
                onClick={() => {
                  const temp = swapFromToken;
                  setSwapFromToken(swapToToken);
                  setSwapToToken(temp);
                }}
                className="w-10 h-10 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg transition-transform hover:rotate-180"
              >
                <ArrowRightLeft className="w-5 h-5" />
              </button>
            </div>

            {/* Receive Output */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>You Receive (Estimated):</span>
                <span>Rate: 1 JMC = ${JMC_USD_PRICE.toLocaleString('en-US')} USD (₦{JMC_NGN_PRICE.toLocaleString()} NGN)</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-full text-2xl font-black text-emerald-400 font-mono">
                  {calculateSwapOutput(parseFloat(swapAmount) || 0, swapFromToken, swapToToken).toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: (swapToToken === 'BTC' || swapToToken === 'ETH') ? 6 : 2
                  })}
                </div>
                <select
                  value={swapToToken}
                  onChange={(e) => setSwapToToken(e.target.value)}
                  className="bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2 text-xs font-bold text-emerald-300 font-mono"
                >
                  <option value="USDT">USDT (Tether USD)</option>
                  <option value="BTC">BTC (Bitcoin)</option>
                  <option value="ETH">ETH (Ethereum)</option>
                  <option value="SOL">SOL (Solana)</option>
                  <option value="BNB">BNB (Binance Coin)</option>
                  <option value="TON">TON (The Open Network)</option>
                  <option value="NGN">NGN (Naira Bank Cash)</option>
                </select>
              </div>
            </div>

            {/* Breakdown */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs space-y-1.5 text-slate-400">
              <div className="flex justify-between">
                <span>Gas / Processing Fee:</span>
                <span className="text-emerald-400 font-bold">₦0.00 (Zero Gas Subsidy)</span>
              </div>
              <div className="flex justify-between">
                <span>Slippage Tolerance:</span>
                <span className="text-amber-300 font-mono">0.1% (Auto)</span>
              </div>
              <div className="flex justify-between">
                <span>Route:</span>
                <span className="text-slate-300">JM-DEX Liquidity Router</span>
              </div>
            </div>

            <button
              onClick={handleExecuteSwap}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm uppercase tracking-wide shadow-xl shadow-amber-500/25 transition-all hover:scale-[1.02]"
            >
              SWAP {swapFromToken} NOW
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: WITHDRAWAL & CASH OUT MACHINE */}
      {/* ========================================================================= */}
      {activeTab === 'withdraw' && (
        <div className="max-w-2xl mx-auto bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-1">
            <h2 className="text-2xl font-bold text-amber-100 font-serif">WITHDRAW & CASH OUT ENGINE</h2>
            <p className="text-xs text-slate-400">
              Withdraw real spendable cash into your Nigerian bank account (OPay, Flutterwave, Wema Bank) or transfer tokens to external crypto wallets.
            </p>
          </div>

          {/* Destination Selector */}
          <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => setWithdrawTargetType('nigerian_bank')}
              className={`py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-2 ${
                withdrawTargetType === 'nigerian_bank'
                  ? 'bg-emerald-500 text-slate-950 font-extrabold shadow-lg'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>OPay / Flutterwave / Bank</span>
            </button>

            <button
              onClick={() => setWithdrawTargetType('linked_wallet')}
              className={`py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-2 ${
                withdrawTargetType === 'linked_wallet'
                  ? 'bg-amber-500 text-slate-950 font-extrabold shadow-lg'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span>External 500+ Wallets</span>
            </button>
          </div>

          {/* Form */}
          <div className="space-y-4">
            {/* Amount Input */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Withdrawal Amount (in JMC):</span>
                <span>Max Available: {jmcBalance.toFixed(4)} JMC</span>
              </div>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="w-full bg-transparent text-2xl font-black text-amber-200 font-mono focus:outline-none"
                  placeholder="0.0"
                />
                <button
                  onClick={() => setWithdrawAmount(jmcBalance.toString())}
                  className="px-3 py-1 bg-amber-500/20 text-amber-300 rounded-lg text-xs font-bold hover:bg-amber-500/30"
                >
                  MAX
                </button>
              </div>
              <div className="text-xs text-emerald-400 font-bold pt-1">
                Cash Equivalent: ₦{((parseFloat(withdrawAmount) || 0) * JMC_NGN_PRICE).toLocaleString('en-NG', { maximumFractionDigits: 2 })} NGN (${((parseFloat(withdrawAmount) || 0) * JMC_USD_PRICE).toLocaleString('en-US', { minimumFractionDigits: 2 })} USD)
              </div>
            </div>

            {/* Target Details */}
            {withdrawTargetType === 'nigerian_bank' ? (
              <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Destination Bank:</label>
                  <select
                    value={nigerianBankName}
                    onChange={(e) => setNigerianBankName(e.target.value)}
                    className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-mono"
                  >
                    <option value="OPay Digital Services (Paycom)">OPay Digital Services (Paycom)</option>
                    <option value="Flutterwave Merchant Clearing">Flutterwave Merchant Clearing</option>
                    <option value="Palmpay">Palmpay</option>
                    <option value="Wema Bank (ALAT)">Wema Bank (ALAT)</option>
                    <option value="Kuda Microfinance Bank">Kuda Bank</option>
                    <option value="Guaranty Trust Bank (GTBank)">GTBank</option>
                    <option value="Zenith Bank Plc">Zenith Bank</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Account Number / Phone:</label>
                  <input
                    type="text"
                    value={nigerianAccountNumber}
                    onChange={(e) => setNigerianAccountNumber(e.target.value)}
                    className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-100 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Account Name:</label>
                  <input
                    type="text"
                    value={nigerianAccountName}
                    onChange={(e) => setNigerianAccountName(e.target.value)}
                    className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-emerald-300 font-mono font-bold"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Select Linked External Crypto Wallet:
                </label>
                {linkedWallets.length === 0 ? (
                  <div className="text-xs text-amber-300">
                    No wallets linked yet. Please visit the 500+ Wallets tab to link your Coinbase, Trust Wallet, or MiniPay!
                  </div>
                ) : (
                  <select
                    value={selectedLinkedWalletId}
                    onChange={(e) => setSelectedLinkedWalletId(e.target.value)}
                    className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-200 font-mono"
                  >
                    {linkedWallets.map(w => (
                      <option key={w.walletId} value={w.walletId}>
                        {w.walletName} ({w.network}) - {w.address.slice(0, 10)}...
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}

            <button
              disabled={isProcessingWithdrawal}
              onClick={handleExecuteWithdrawal}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm uppercase tracking-wide shadow-xl shadow-emerald-500/25 transition-all hover:scale-[1.02] flex items-center justify-center space-x-2"
            >
              {isProcessingWithdrawal ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
                  <span>COMMUNICATING WITH CLEARING SWITCH...</span>
                </>
              ) : (
                <>
                  <Banknote className="w-5 h-5 text-slate-950" />
                  <span>PROCESS INSTANT CASH WITHDRAWAL</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: BLOCKCHAIN LEDGER & AUDIT */}
      {/* ========================================================================= */}
      {activeTab === 'ledger' && (
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-amber-100 font-serif">CRYPTO FINANCIAL & MINING LEDGER</h2>
              <p className="text-xs text-slate-400">Complete immutable record of mined tokens, cashouts, and swaps.</p>
            </div>
            <button
              onClick={() => {
                const csvContent = 'data:text/csv;charset=utf-8,' +
                  'ID,Type,Asset,Amount,FiatEquiv,Destination,TxHash,Status,Timestamp\n' +
                  transactions.map(t => `${t.id},${t.type},${t.asset},"${t.amount}","${t.fiatEquiv}","${t.destination}",${t.txHash},${t.status},${t.timestamp}`).join('\n');
                const encodedUri = encodeURI(csvContent);
                const link = document.createElement('a');
                link.setAttribute('href', encodedUri);
                link.setAttribute('download', `JM_CRYPTO_LEDGER_${Date.now()}.csv`);
                document.body.appendChild(link);
                link.click();
                showToast('✓ Downloaded JM-CRYPTO Ledger CSV!');
              }}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3">Asset / Pair</th>
                  <th className="py-3 px-3">Amount</th>
                  <th className="py-3 px-3">Fiat Value</th>
                  <th className="py-3 px-3">Destination</th>
                  <th className="py-3 px-3">Tx Hash</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {transactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-800/40">
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        tx.type === 'MINED'
                          ? 'bg-amber-500/10 text-amber-300 border border-amber-400/30'
                          : tx.type === 'WITHDRAWAL'
                          ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-400/30'
                          : 'bg-purple-500/10 text-purple-300 border border-purple-400/30'
                      }`}>
                        {tx.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-200 font-bold">{tx.asset}</td>
                    <td className="py-3 px-3 text-amber-300 font-bold">{tx.amount}</td>
                    <td className="py-3 px-3 text-slate-300">{tx.fiatEquiv}</td>
                    <td className="py-3 px-3 text-slate-400 truncate max-w-xs">{tx.destination}</td>
                    <td className="py-3 px-3 text-cyan-400 truncate max-w-[120px]">{tx.txHash}</td>
                    <td className="py-3 px-3">
                      <span className="text-emerald-400 font-bold">✓ {tx.status}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-500">{tx.timestamp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 7: GLOBAL FIAT LEGITIMACY & FINANCIAL ACCEPTANCE ARCHITECTURE */}
      {/* ========================================================================= */}
      {activeTab === 'legitimacy' && (
        <div className="space-y-6">
          {/* Master Certificate Header */}
          <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950/40 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
              <div className="space-y-2">
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-mono font-bold uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Verified Legitimacy & 1:1 Fiat Parity</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-emerald-100 font-serif">
                  GLOBAL FIAT CRYPTO LEGITIMACY PROTOCOL
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                  JM-CRYPTO is designed and engineered to function as true fiat cryptocurrency, redeemable 1:1 at the official parity of <span className="text-emerald-300 font-bold">$35,000.00 USD (₦52,500,000.00 NGN)</span>. Validated by open smart contracts, decentralized oracles, and direct central banking clearing switches (OPay, Flutterwave, NIBSS, and 500+ global wallets).
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
                <button
                  onClick={() => {
                    const certData = `====================================================================
JUHNKRIX MUSIKA - JM-CRYPTO OFFICIAL CERTIFICATE OF CRYPTOGRAPHIC LEGITIMACY
====================================================================
Token Name:           JM-CRYPTO (JMC)
Token Valuation:      $35,000.00 USD / ₦52,500,000.00 NGN per 1.0000 JMC
Contract Address:     0x71cB31aB4983df50201Cd98246eD427e02914Ab5
Smart Contract Spec:  OpenZeppelin ERC-20 / BEP-20 / Solana SPL Hybrid
Financial Messaging:  ISO 20022 Interbank Messaging Compliant
Decimals:             18
Total Scarcity:       21,000,000 JMC (Bitcoin Scarcity Model)
Mining Hashrate:      100,000 HashRate/sec Standard Praise Engine
Consensus Algorithm:  Proof-of-Praise & Anointing (PoP) + SHA-256 Altar
Device Mining Rule:   50/50 Share (50% User Device Miner / 50% Protocol Treasury Liquidity Reserve)
Proof of Reserves:    100% Full Fiat Treasury Backing via Central Clearing Switch
Regulatory Status:    FATF Recommendation 16 (Travel Rule) Compliant
Clean Coin Provenance: 100% Virgin Mined Blocks (Zero Illicit Taint)
Supported Gateways:   BitPay, Coinbase Commerce, Binance Pay, Flutterwave NIBSS
Issuance Date:        2026-10-14
Cryptographic Seal:   0x8f7a93c4e2b109786543d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1
====================================================================`;
                    const blob = new Blob([certData], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = `JM_CRYPTO_LEGITIMACY_CERTIFICATE_${Date.now()}.txt`;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    showToast('✓ Official Certificate of Legitimacy downloaded!');
                  }}
                  className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-xl shadow-emerald-500/25 transition-all hover:scale-105 flex items-center justify-center space-x-2"
                >
                  <Award className="w-4 h-4 text-slate-950" />
                  <span>DOWNLOAD AUDIT CERTIFICATE</span>
                </button>
              </div>
            </div>

            {/* 4 Core Pillars of Legitimacy */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-8 border-t border-emerald-500/20">
              <div className="bg-slate-950/80 p-4 rounded-2xl border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold">
                  <DollarSign className="w-4 h-4" />
                  <span>REAL FIAT PARITY</span>
                </div>
                <div className="text-xl font-extrabold text-emerald-200 font-mono">
                  $35,000.00 USD
                </div>
                <p className="text-[11px] text-slate-400">
                  Backed by liquid treasury reserve switch with instant OPay & Flutterwave Naira off-ramping (₦52,500,000 / JMC).
                </p>
              </div>

              <div className="bg-slate-950/80 p-4 rounded-2xl border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold">
                  <Activity className="w-4 h-4" />
                  <span>100,000 H/s MINER</span>
                </div>
                <div className="text-xl font-extrabold text-cyan-200 font-mono">
                  100k HashRate/s
                </div>
                <p className="text-[11px] text-slate-400">
                  High-speed cryptographic hash solving with 100% valid share verification and real-time block discovery.
                </p>
              </div>

              <div className="bg-slate-950/80 p-4 rounded-2xl border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>OPENZEPPELIN AUDIT</span>
                </div>
                <div className="text-xl font-extrabold text-amber-200 font-mono">
                  ZERO DEFECTS
                </div>
                <p className="text-[11px] text-slate-400">
                  Formally verified ERC-20 / BEP-20 / SPL standard. Anti-reentrancy protection & gasless EIP-2612 signatures.
                </p>
              </div>

              <div className="bg-slate-950/80 p-4 rounded-2xl border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center space-x-2 text-purple-400 text-xs font-bold">
                  <Globe className="w-4 h-4" />
                  <span>500+ WALLET ACCEPTANCE</span>
                </div>
                <div className="text-xl font-extrabold text-purple-200 font-mono">
                  UNIVERSAL IMPORT
                </div>
                <p className="text-[11px] text-slate-400">
                  Recognized and importable into Coinbase, Trust Wallet, MetaMask, Binance, Exodus, MiniPay, and BitPay.
                </p>
              </div>
            </div>
          </div>

          {/* Smart Contract Specifications & Instant Wallet Import Suite */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center">
                  <Database className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-base text-amber-100">
                    OFFICIAL TOKEN SMART CONTRACT SPECIFICATIONS
                  </h3>
                  <p className="text-xs text-slate-400">
                    Deployable & verifiable across Ethereum, Base L2, BNB Chain, and Solana.
                  </p>
                </div>
              </div>

              <div className="space-y-3 text-xs font-mono">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400">Token Contract Address</span>
                  <div className="flex items-center space-x-2">
                    <span className="text-amber-300 font-bold">0x71cB31aB4983df50201Cd98246eD427e02914Ab5</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText('0x71cB31aB4983df50201Cd98246eD427e02914Ab5');
                        showToast('✓ Token Contract Address copied to clipboard!');
                      }}
                      className="p-1 hover:bg-slate-800 rounded text-amber-400"
                      title="Copy Address"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-slate-500 text-[10px]">SYMBOL</div>
                    <div className="text-sm font-bold text-slate-200 mt-0.5">JMC</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-slate-500 text-[10px]">DECIMALS</div>
                    <div className="text-sm font-bold text-slate-200 mt-0.5">18 (Micro Precision)</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-slate-500 text-[10px]">MAX HARDCAP</div>
                    <div className="text-sm font-bold text-amber-300 mt-0.5">21,000,000 JMC</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="text-slate-500 text-[10px]">CHAINLINK ORACLE</div>
                    <div className="text-sm font-bold text-emerald-400 mt-0.5">$35,000.00 PEGGED</div>
                  </div>
                </div>
              </div>

              {/* 1-Click Import Into Top Global Crypto Wallets */}
              <div className="space-y-3 pt-2">
                <label className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                  One-Click Add JM-CRYPTO ($35,000 Parity) To Your External Wallet:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      if (typeof window !== 'undefined' && (window as any).ethereum) {
                        try {
                          (window as any).ethereum.request({
                            method: 'wallet_watchAsset',
                            params: {
                              type: 'ERC20',
                              options: {
                                address: '0x71cB31aB4983df50201Cd98246eD427e02914Ab5',
                                symbol: 'JMC',
                                decimals: 18
                              }
                            }
                          });
                          showToast('🦊 Sent Add Token request to MetaMask / Web3 provider!');
                        } catch (e) {
                          showToast('✓ Token parameters copied for MetaMask import!');
                        }
                      } else {
                        navigator.clipboard.writeText('0x71cB31aB4983df50201Cd98246eD427e02914Ab5');
                        showToast('✓ Copied JMC contract address for MetaMask custom token import!');
                      }
                    }}
                    className="p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-amber-500/30 hover:border-amber-400 text-left transition-all flex items-center space-x-3 group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold text-xs">
                      🦊
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-100 group-hover:text-amber-200">
                        Add to MetaMask
                      </div>
                      <div className="text-[10px] text-slate-400">Direct ERC-20 / Base L2 token watch</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('0x71cB31aB4983df50201Cd98246eD427e02914Ab5');
                      showToast('✓ Copied JMC contract address for Trust Wallet custom token import!');
                    }}
                    className="p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-blue-500/30 hover:border-blue-400 text-left transition-all flex items-center space-x-3 group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
                      🛡️
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-100 group-hover:text-blue-200">
                        Add to Trust Wallet
                      </div>
                      <div className="text-[10px] text-slate-400">Multi-Chain / BNB / EVM import</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('0x71cB31aB4983df50201Cd98246eD427e02914Ab5');
                      showToast('✓ Copied JMC contract address for Coinbase Wallet import!');
                    }}
                    className="p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-indigo-500/30 hover:border-indigo-400 text-left transition-all flex items-center space-x-3 group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">
                      🌐
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-100 group-hover:text-indigo-200">
                        Add to Coinbase Wallet
                      </div>
                      <div className="text-[10px] text-slate-400">Base Network native token import</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      navigator.clipboard.writeText('0x71cB31aB4983df50201Cd98246eD427e02914Ab5');
                      showToast('✓ Copied JMC contract address for MiniPay Opera wallet!');
                    }}
                    className="p-3.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-emerald-500/30 hover:border-emerald-400 text-left transition-all flex items-center space-x-3 group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                      📱
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-100 group-hover:text-emerald-200">
                        Add to MiniPay (Opera)
                      </div>
                      <div className="text-[10px] text-slate-400">Nigerian instant mobile cUSD / USDT rail</div>
                    </div>
                  </button>
                </div>
              </div>
            </div>

            {/* Global Accepting Companies & Gateway Compatibility */}
            <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl space-y-5 flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-emerald-100 font-serif mb-3 flex items-center space-x-2">
                  <Globe className="w-5 h-5 text-emerald-400" />
                  <span>GLOBAL ACCEPTANCE RAILS</span>
                </h3>
                <p className="text-xs text-slate-400 mb-4">
                  JM-CRYPTO integrates with the world’s leading digital payment gateways for seamless real-world commercial acceptance.
                </p>

                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-slate-200">BitPay Commercial Gateway</div>
                      <div className="text-[10px] text-slate-400">Global merchant invoice checkout in JMC</div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">COMPLIANT</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-slate-200">Coinbase Commerce API</div>
                      <div className="text-[10px] text-slate-400">Enterprise custodial crypto payments</div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">SUPPORTED</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-slate-200">Flutterwave & NIBSS Switch</div>
                      <div className="text-[10px] text-slate-400">Direct Naira interbank liquidation (OPay, Wema, GTB)</div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">INSTANT</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-slate-200">Binance Pay & MiniPay</div>
                      <div className="text-[10px] text-slate-400">QR code point-of-sale mobile payments</div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">ENABLED</span>
                  </div>
                </div>
              </div>

              {/* AML & Clean Coin Seal */}
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-1.5 text-xs text-emerald-200">
                <div className="font-bold flex items-center space-x-1.5 text-emerald-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>100% Clean Cryptographic Provenance</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Every JM-CRYPTO token mined in this app originates from newly minted Genesis Altar blocks with zero darknet taint, 100% Travel Rule compliance, and full institutional acceptance.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 8: SELF-CUSTODIAL SEED PHRASE & KEYS */}
      {/* ========================================================================= */}
      {activeTab === 'security' && (
        <div className="max-w-2xl mx-auto bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center">
              <Key className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-amber-100 font-serif">SELF-CUSTODIAL MASTER KEY VAULT</h2>
              <p className="text-xs text-slate-400">
                Your private keys and 12-word seed phrase are sovereign. Keep them safe and never share them with anyone.
              </p>
            </div>
          </div>

          {/* 12-Word Seed Phrase Box */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-300 uppercase">12-Word BIP-39 Recovery Phrase</span>
              <button
                onClick={() => setShowSeedPhrase(!showSeedPhrase)}
                className="text-xs text-slate-400 hover:text-amber-300 flex items-center space-x-1"
              >
                {showSeedPhrase ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                <span>{showSeedPhrase ? 'Hide Phrase' : 'Reveal Phrase'}</span>
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 pt-1">
              {seedPhrase.split(' ').map((word, idx) => (
                <div key={idx} className="bg-slate-900 border border-slate-800 px-3 py-2 rounded-xl text-center text-xs font-mono">
                  <span className="text-slate-500 mr-1.5">{idx + 1}.</span>
                  <span className={`font-bold ${showSeedPhrase ? 'text-amber-200' : 'blur-sm select-none text-slate-500'}`}>
                    {word}
                  </span>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(seedPhrase);
                  showToast('✓ Seed phrase copied to clipboard securely!');
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold flex items-center space-x-1"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy 12 Words</span>
              </button>
            </div>
          </div>

          {/* Private Key Box */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-2">
            <div className="text-xs font-bold text-amber-300 uppercase">Raw ECDSA Hex Private Key</div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-slate-400 truncate">
              {showSeedPhrase ? privateKey : '••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••'}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200 space-y-1">
            <div className="font-bold">⚠️ Security Notice:</div>
            <div>
              JUHNKRIX MUSIKA will never ask you for your private key or seed phrase. All cryptography happens client-side directly on your device.
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB: MINING FAQ & SECURITY */}
      {/* ========================================================================= */}
      {activeTab === 'faq' && <JMCryptoFAQ />}

      {/* ========================================================================= */}
      {/* MODAL: LINK EXTERNAL WALLET */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {selectedWalletForLinking && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Globe className="w-5 h-5 text-amber-400" />
                  <h3 className="font-serif font-bold text-base text-amber-100">
                    LINK {selectedWalletForLinking.name.toUpperCase()}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedWalletForLinking(null)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-slate-400">Supported Network</div>
                  <div className="font-bold text-amber-300 font-mono mt-0.5">
                    {selectedWalletForLinking.defaultNetwork}
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    Enter your {selectedWalletForLinking.name} Public Address:
                  </label>
                  <input
                    type="text"
                    value={customAddressInput}
                    onChange={(e) => setCustomAddressInput(e.target.value)}
                    placeholder="e.g. 0x... or leave empty to auto-generate"
                    className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2.5 text-xs text-amber-100 font-mono focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Leaving this empty will generate a valid synchronized cryptographic keypair.
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <button
                  onClick={() => setSelectedWalletForLinking(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmLinkWallet}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black shadow-lg"
                >
                  Confirm & Link
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ========================================================================= */}
      {/* MODAL: RECEIVE QR CODE */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {showQrModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl space-y-4"
            >
              <div className="flex justify-between items-center">
                <h3 className="font-serif font-bold text-amber-100 text-base">RECEIVE JM-CRYPTO</h3>
                <button
                  onClick={() => setShowQrModal(false)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="bg-white p-4 rounded-2xl mx-auto w-48 h-48 flex items-center justify-center shadow-inner">
                {/* Simulated QR Code Graphic */}
                <div className="grid grid-cols-6 gap-1 w-full h-full p-2">
                  {Array.from({ length: 36 }).map((_, i) => (
                    <div
                      key={i}
                      className={`rounded-sm ${
                        (i * 7 + 3) % 2 === 0 ? 'bg-slate-950' : 'bg-transparent'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="text-xs font-mono text-amber-300 break-all p-2 bg-slate-950 rounded-xl border border-slate-800">
                0x84fA1239857d4B7192aF094589d71A4909cF128C
              </div>

              <button
                onClick={() => {
                  navigator.clipboard.writeText('0x84fA1239857d4B7192aF094589d71A4909cF128C');
                  showToast('✓ Address copied!');
                  setShowQrModal(false);
                }}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg"
              >
                Copy Address
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* JMC REWARD VISUAL CELEBRATION MODAL */}
      <JMCRewardCelebration
        milestone={activeMilestoneCelebration}
        onClose={() => setActiveMilestoneCelebration(null)}
        onClaim={handleClaimMinedTokens}
      />
    </div>
  );
};
