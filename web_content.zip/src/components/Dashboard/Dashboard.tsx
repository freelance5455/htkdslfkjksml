import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Star,
  Clock,
  LayoutGrid,
  Settings as SettingsIcon,
  MoreVertical,
  Trash2,
  Copy,
  Edit2,
  Download,
  Share2,
  FolderOpen,
  Sparkles,
} from 'lucide-react';
import { Board, AppSettings } from '../../canvas/types';
import { PWAInstallButton } from '../PWAInstallButton';
import { exportBoardToPNG, exportBoardToJSON } from '../../canvas/export';

interface DashboardProps {
  boards: Board[];
  onOpenBoard: (boardId: string) => void;
  onCreateBoard: () => void;
  onRenameBoard: (boardId: string, newTitle: string) => void;
  onDuplicateBoard: (boardId: string) => void;
  onDeleteBoard: (boardId: string) => void;
  onToggleFavorite: (boardId: string) => void;
  onOpenSettings: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  boards,
  onOpenBoard,
  onCreateBoard,
  onRenameBoard,
  onDuplicateBoard,
  onDeleteBoard,
  onToggleFavorite,
  onOpenSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'recent' | 'favorites'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameText, setRenameText] = useState('');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // Filtered boards
  const filteredBoards = useMemo(() => {
    return boards.filter((b) => {
      const matchesSearch = b.title.toLowerCase().includes(searchQuery.toLowerCase().trim());
      if (!matchesSearch) return false;

      if (activeTab === 'favorites') return b.isFavorite;
      if (activeTab === 'recent') {
        // Last 7 days
        return Date.now() - b.updatedAt < 86400000 * 7;
      }
      return true;
    });
  }, [boards, searchQuery, activeTab]);

  const handleStartRename = (b: Board, e: React.MouseEvent) => {
    e.stopPropagation();
    setRenamingId(b.id);
    setRenameText(b.title);
    setActiveMenuId(null);
  };

  const handleCommitRename = (boardId: string) => {
    if (renameText.trim()) {
      onRenameBoard(boardId, renameText.trim());
    }
    setRenamingId(null);
  };

  const formatRelativeTime = (timestamp: number) => {
    const diffSec = Math.floor((Date.now() - timestamp) / 1000);
    if (diffSec < 60) return 'Just now';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHour = Math.floor(diffMin / 60);
    if (diffHour < 24) return `${diffHour}h ago`;
    const diffDays = Math.floor(diffHour / 24);
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays}d ago`;
    return new Date(timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  return (
    <div className="flex h-screen w-full bg-[var(--md-sys-color-surface)] text-[var(--md-sys-color-on-surface)] overflow-hidden">
      
      {/* Android Tablet Navigation Rail */}
      <nav
        aria-label="Main Navigation"
        className="hidden md:flex flex-col items-center py-6 px-3 w-20 shrink-0 bg-[var(--md-sys-color-surface-container-low)] border-r border-[var(--md-sys-color-outline-variant)] select-none justify-between z-20"
      >
        <div className="flex flex-col items-center gap-6 w-full">
          {/* Logo Monogram */}
          <div className="w-12 h-12 rounded-2xl bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] flex items-center justify-center font-bold text-lg shadow-sm">
            xv
          </div>

          {/* Navigation Items */}
          <div className="flex flex-col items-center gap-3 w-full">
            <button
              onClick={() => setActiveTab('all')}
              aria-label="All Boards"
              className={`flex flex-col items-center gap-1 p-2 w-full rounded-2xl transition ${
                activeTab === 'all'
                  ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]'
                  : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
              }`}
            >
              <LayoutGrid className="w-5 h-5" />
              <span className="text-[10px] font-medium">Boards</span>
            </button>

            <button
              onClick={() => setActiveTab('recent')}
              aria-label="Recent Boards"
              className={`flex flex-col items-center gap-1 p-2 w-full rounded-2xl transition ${
                activeTab === 'recent'
                  ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]'
                  : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
              }`}
            >
              <Clock className="w-5 h-5" />
              <span className="text-[10px] font-medium">Recent</span>
            </button>

            <button
              onClick={() => setActiveTab('favorites')}
              aria-label="Favorite Boards"
              className={`flex flex-col items-center gap-1 p-2 w-full rounded-2xl transition ${
                activeTab === 'favorites'
                  ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]'
                  : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
              }`}
            >
              <Star className="w-5 h-5" />
              <span className="text-[10px] font-medium">Favorites</span>
            </button>
          </div>
        </div>

        {/* Bottom Actions: Settings & PWA */}
        <div className="flex flex-col items-center gap-3">
          <button
            onClick={onOpenSettings}
            aria-label="Settings"
            className="p-3 rounded-2xl text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)] transition"
          >
            <SettingsIcon className="w-5 h-5" />
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden bg-[var(--md-sys-color-surface)]">
        
        {/* Top App Bar */}
        <header className="flex items-center justify-between px-6 py-4 border-b border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container-low)] gap-4 shrink-0">
          
          <div className="flex items-center gap-3">
            <div className="md:hidden w-10 h-10 rounded-2xl bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] flex items-center justify-center font-bold text-base shadow-sm">
              xv
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-[var(--md-sys-color-on-surface)]">xvBOARD</h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]">
                  M3 Pro
                </span>
              </div>
              <p className="text-xs text-[var(--md-sys-color-on-surface-variant)] hidden sm:block">
                Material Design 3 Infinite Whiteboard
              </p>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-2">
            <div className="relative flex items-center">
              <Search className="w-4 h-4 absolute left-3.5 text-[var(--md-sys-color-on-surface-variant)] pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search boards..."
                aria-label="Search boards"
                className="w-full pl-10 pr-4 py-2 text-sm rounded-full bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] placeholder:text-[var(--md-sys-color-on-surface-variant)] border border-transparent focus:border-[var(--md-sys-color-primary)] focus:outline-none transition"
              />
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            <PWAInstallButton compact />

            <button
              onClick={onOpenSettings}
              aria-label="Open Settings"
              className="md:hidden p-2.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface-variant)] transition"
            >
              <SettingsIcon className="w-5 h-5" />
            </button>

            <button
              onClick={onCreateBoard}
              aria-label="Create New Board"
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-sm font-semibold hover:opacity-95 shadow-md active:scale-95 transition"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">New Board</span>
            </button>
          </div>
        </header>

        {/* Mobile Filter Tabs (visible on small mobile screens) */}
        <div className="md:hidden flex border-b border-[var(--md-sys-color-outline-variant)] px-4 bg-[var(--md-sys-color-surface-container-low)]">
          <button
            onClick={() => setActiveTab('all')}
            className={`flex-1 py-2 text-xs font-medium text-center border-b-2 transition ${
              activeTab === 'all'
                ? 'border-[var(--md-sys-color-primary)] text-[var(--md-sys-color-primary)]'
                : 'border-transparent text-[var(--md-sys-color-on-surface-variant)]'
            }`}
          >
            All Boards
          </button>
          <button
            onClick={() => setActiveTab('recent')}
            className={`flex-1 py-2 text-xs font-medium text-center border-b-2 transition ${
              activeTab === 'recent'
                ? 'border-[var(--md-sys-color-primary)] text-[var(--md-sys-color-primary)]'
                : 'border-transparent text-[var(--md-sys-color-on-surface-variant)]'
            }`}
          >
            Recent
          </button>
          <button
            onClick={() => setActiveTab('favorites')}
            className={`flex-1 py-2 text-xs font-medium text-center border-b-2 transition ${
              activeTab === 'favorites'
                ? 'border-[var(--md-sys-color-primary)] text-[var(--md-sys-color-primary)]'
                : 'border-transparent text-[var(--md-sys-color-on-surface-variant)]'
            }`}
          >
            Favorites
          </button>
        </div>

        {/* Scrollable Boards Grid */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-8" onClick={() => setActiveMenuId(null)}>
          <div className="max-w-7xl mx-auto space-y-6">
            
            {/* Tab header & counts */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-[var(--md-sys-color-on-surface)]">
                  {activeTab === 'all' && 'All Whiteboards'}
                  {activeTab === 'recent' && 'Recently Edited'}
                  {activeTab === 'favorites' && 'Starred Boards'}
                </h2>
                <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                  {filteredBoards.length} {filteredBoards.length === 1 ? 'board' : 'boards'} available offline
                </p>
              </div>
            </div>

            {/* Empty State */}
            {filteredBoards.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 px-4 text-center rounded-3xl bg-[var(--md-sys-color-surface-container-low)] border border-dashed border-[var(--md-sys-color-outline-variant)]">
                <div className="w-16 h-16 rounded-3xl bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] flex items-center justify-center mb-4">
                  <LayoutGrid className="w-8 h-8 opacity-80" />
                </div>
                <h3 className="text-base font-semibold text-[var(--md-sys-color-on-surface)]">
                  {searchQuery ? 'No matching boards found' : 'No whiteboards yet'}
                </h3>
                <p className="text-xs text-[var(--md-sys-color-on-surface-variant)] max-w-sm mt-1 mb-5">
                  {searchQuery
                    ? `Try searching with a different keyword or clear your query.`
                    : `Create your first infinite canvas with pressure-sensitive drawing and sticky notes.`}
                </p>
                <button
                  onClick={onCreateBoard}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-sm font-medium hover:opacity-95 transition"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create New Board</span>
                </button>
              </div>
            )}

            {/* Grid of Board Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filteredBoards.map((b) => (
                <div
                  key={b.id}
                  onClick={() => onOpenBoard(b.id)}
                  className="group relative flex flex-col rounded-3xl bg-[var(--md-sys-color-surface-container)] hover:bg-[var(--md-sys-color-surface-container-high)] border border-[var(--md-sys-color-outline-variant)] hover:border-[var(--md-sys-color-primary)] hover:shadow-xl transition-all duration-200 cursor-pointer overflow-hidden"
                >
                  {/* Card Thumbnail / Preview */}
                  <div className="relative w-full aspect-video bg-[#121418] border-b border-[var(--md-sys-color-outline-variant)] flex items-center justify-center overflow-hidden">
                    {b.thumbnail ? (
                      <img
                        src={b.thumbnail}
                        alt={b.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="flex flex-col items-center gap-2 text-slate-500">
                        <FolderOpen className="w-8 h-8 opacity-40" />
                        <span className="text-[11px] opacity-60">Canvas Preview</span>
                      </div>
                    )}

                    {/* Star / Favorite quick toggle */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(b.id);
                      }}
                      aria-label={b.isFavorite ? 'Unfavorite' : 'Favorite'}
                      className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition ${
                        b.isFavorite
                          ? 'bg-amber-400/90 text-amber-950 shadow-sm'
                          : 'bg-black/40 text-white/70 hover:text-white hover:bg-black/60'
                      }`}
                    >
                      <Star className={`w-4 h-4 ${b.isFavorite ? 'fill-current' : ''}`} />
                    </button>

                    {/* Objects count badge */}
                    <div className="absolute bottom-3 left-3 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-[10px] text-white/90 font-medium">
                      {b.elements.length} {b.elements.length === 1 ? 'object' : 'objects'}
                    </div>
                  </div>

                  {/* Card Details */}
                  <div className="p-4 flex flex-col justify-between flex-1 gap-2">
                    <div className="flex items-start justify-between gap-2">
                      {renamingId === b.id ? (
                        <div
                          className="flex items-center gap-1.5 w-full"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <input
                            type="text"
                            value={renameText}
                            onChange={(e) => setRenameText(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleCommitRename(b.id);
                              if (e.key === 'Escape') setRenamingId(null);
                            }}
                            autoFocus
                            className="w-full px-2 py-1 text-sm font-semibold rounded-lg bg-[var(--md-sys-color-surface-container-highest)] border border-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-surface)] outline-none"
                          />
                          <button
                            onClick={() => handleCommitRename(b.id)}
                            className="px-2 py-1 rounded bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-xs font-semibold"
                          >
                            Save
                          </button>
                        </div>
                      ) : (
                        <h3 className="font-semibold text-sm text-[var(--md-sys-color-on-surface)] truncate leading-tight group-hover:text-[var(--md-sys-color-primary)] transition">
                          {b.title}
                        </h3>
                      )}

                      {/* Dropdown 3-dot Menu */}
                      <div className="relative shrink-0">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveMenuId(activeMenuId === b.id ? null : b.id);
                          }}
                          aria-label="Board options"
                          className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-highest)] text-[var(--md-sys-color-on-surface-variant)] transition"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>

                        {activeMenuId === b.id && (
                          <div
                            onClick={(e) => e.stopPropagation()}
                            className="absolute right-0 bottom-full mb-1 w-44 rounded-2xl bg-[var(--md-sys-color-surface-container-highest)] shadow-xl border border-[var(--md-sys-color-outline-variant)] py-1.5 z-30 animate-in fade-in zoom-in-95"
                          >
                            <button
                              onClick={(e) => handleStartRename(b, e)}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container)] transition text-left"
                            >
                              <Edit2 className="w-3.5 h-3.5 text-[var(--md-sys-color-on-surface-variant)]" />
                              <span>Rename Board</span>
                            </button>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onDuplicateBoard(b.id);
                                setActiveMenuId(null);
                              }}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container)] transition text-left"
                            >
                              <Copy className="w-3.5 h-3.5 text-[var(--md-sys-color-on-surface-variant)]" />
                              <span>Duplicate</span>
                            </button>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                exportBoardToPNG(b);
                                setActiveMenuId(null);
                              }}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container)] transition text-left"
                            >
                              <Download className="w-3.5 h-3.5 text-[var(--md-sys-color-on-surface-variant)]" />
                              <span>Export as PNG</span>
                            </button>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                exportBoardToJSON(b);
                                setActiveMenuId(null);
                              }}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container)] transition text-left"
                            >
                              <Share2 className="w-3.5 h-3.5 text-[var(--md-sys-color-on-surface-variant)]" />
                              <span>Export .xvboard</span>
                            </button>

                            <div className="my-1 border-t border-[var(--md-sys-color-outline-variant)]" />

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteBoard(b.id);
                                setActiveMenuId(null);
                              }}
                              className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-500 hover:bg-rose-500/10 transition text-left"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Delete Board</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-[var(--md-sys-color-on-surface-variant)] mt-1">
                      <span>Edited {formatRelativeTime(b.updatedAt)}</span>
                      <span className="capitalize">{b.bgType} grid</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>

      </main>
    </div>
  );
};
