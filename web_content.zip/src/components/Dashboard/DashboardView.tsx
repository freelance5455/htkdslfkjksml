import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ShoppingBag, 
  Calendar, 
  Printer, 
  ArrowUpRight, 
  ArrowDownRight, 
  AlertCircle, 
  Plus, 
  Trash2, 
  FileText,
  Clock,
  Layers,
  PieChart
} from 'lucide-react';
import { SaleInvoice, Expense, PurchaseRecord, ExpenseCategory, UserRole, StoreProfile } from '../../types';
import { formatTaka, toBnNum, formatBengaliDateTime } from '../../utils/formatters';

interface DashboardViewProps {
  invoices: SaleInvoice[];
  expenses: Expense[];
  purchases: PurchaseRecord[];
  onAddExpense: (expense: Omit<Expense, 'id' | 'date'>) => void;
  onDeleteExpense: (id: string) => void;
  activeRole: UserRole;
  storeProfile: StoreProfile;
}

const EXPENSE_CATEGORIES: { id: ExpenseCategory; label: string }[] = [
  { id: 'RENT', label: 'দোকান ভাড়া' },
  { id: 'ELECTRICITY', label: 'বিদ্যুৎ বিল' },
  { id: 'SALARY', label: 'কর্মচারীর বেতন' },
  { id: 'TEA_SNACK', label: 'আপ্যায়ন ও চা-নাস্তা' },
  { id: 'TRANSPORT', label: 'পরিবহন ও যাতায়াত' },
  { id: 'REPAIR', label: 'মেরামত ও অন্যান্য' },
  { id: 'OTHER', label: 'বিবিধ খরচ' },
];

export const DashboardView: React.FC<DashboardViewProps> = ({
  invoices,
  expenses,
  purchases,
  onAddExpense,
  onDeleteExpense,
  activeRole,
  storeProfile,
}) => {
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [expenseTitle, setExpenseTitle] = useState('');
  const [expenseCategory, setExpenseCategory] = useState<ExpenseCategory>('TEA_SNACK');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseNote, setExpenseNote] = useState('');

  // Report view tab: 'daily' | 'monthly' | 'pl_report'
  const [activeReportTab, setActiveReportTab] = useState<'daily' | 'monthly' | 'pl_report'>('daily');

  // Dates
  const now = new Date();
  const todayDateStr = now.toDateString();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  // 1. TODAY'S METRICS (আজকের হিসাব)
  const todayMetrics = useMemo(() => {
    const todayInvoices = invoices.filter(
      (inv) => new Date(inv.createdAt).toDateString() === todayDateStr
    );
    const todayPurchases = purchases.filter(
      (p) => new Date(p.date).toDateString() === todayDateStr
    );
    const todayExpenses = expenses.filter(
      (e) => new Date(e.date).toDateString() === todayDateStr
    );

    const sales = todayInvoices.reduce((sum, i) => sum + i.netTotal, 0);
    const collectedCash = todayInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
    const dues = todayInvoices.reduce((sum, i) => sum + i.dueAmount, 0);
    const purchasesTotal = todayPurchases.reduce((sum, p) => sum + p.totalCost, 0);
    const cogs = todayInvoices.reduce((sum, i) => sum + i.totalCost, 0);
    const grossProfit = +(sales - cogs).toFixed(2);
    const expenseTotal = todayExpenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = +(grossProfit - expenseTotal).toFixed(2);

    return {
      count: todayInvoices.length,
      sales,
      collectedCash,
      dues,
      purchasesTotal,
      grossProfit,
      expenseTotal,
      netProfit,
    };
  }, [invoices, purchases, expenses, todayDateStr]);

  // 2. THIS MONTH'S METRICS (চলতি মাসের হিসাব)
  const monthMetrics = useMemo(() => {
    const monthInvoices = invoices.filter((inv) => {
      const d = new Date(inv.createdAt);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });
    const monthPurchases = purchases.filter((p) => {
      const d = new Date(p.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });
    const monthExpenses = expenses.filter((e) => {
      const d = new Date(e.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const sales = monthInvoices.reduce((sum, i) => sum + i.netTotal, 0);
    const collectedCash = monthInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
    const dues = monthInvoices.reduce((sum, i) => sum + i.dueAmount, 0);
    const purchasesTotal = monthPurchases.reduce((sum, p) => sum + p.totalCost, 0);
    const cogs = monthInvoices.reduce((sum, i) => sum + i.totalCost, 0);
    const grossProfit = +(sales - cogs).toFixed(2);
    const expenseTotal = monthExpenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = +(grossProfit - expenseTotal).toFixed(2);

    return {
      count: monthInvoices.length,
      sales,
      collectedCash,
      dues,
      purchasesTotal,
      cogs,
      grossProfit,
      expenseTotal,
      netProfit,
      marginPercent: sales > 0 ? +((grossProfit / sales) * 100).toFixed(1) : 0,
    };
  }, [invoices, purchases, expenses, currentMonth, currentYear]);

  // Total Outstanding Receivables (দোকানের মোট বাকি)
  const totalReceivableDues = useMemo(() => {
    return invoices.reduce((sum, i) => sum + i.dueAmount, 0);
  }, [invoices]);

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(expenseAmount);
    if (!expenseTitle.trim() || isNaN(amt) || amt <= 0) {
      alert('সঠিক খরচের খাত ও টাকার অঙ্ক প্রদান করুন');
      return;
    }
    onAddExpense({
      title: expenseTitle.trim(),
      category: expenseCategory,
      amount: amt,
      note: expenseNote.trim() || undefined,
    });
    setExpenseTitle('');
    setExpenseAmount('');
    setExpenseNote('');
    setShowExpenseModal(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Header & Tab Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            দৈনিক ও মাসিক লাভ-ক্ষতি ড্যাশবোর্ড
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            প্রতিদিন ও মাসের কেনা-বেচা, বাকি এবং নিট মুনাফার স্বয়ংক্রিয় হিসাব
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Tab Selector */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveReportTab('daily')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                activeReportTab === 'daily'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              আজকের হিসাব
            </button>
            <button
              onClick={() => setActiveReportTab('monthly')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                activeReportTab === 'monthly'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              মাসিক হিসাব
            </button>
            <button
              onClick={() => setActiveReportTab('pl_report')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                activeReportTab === 'pl_report'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              লাভ-ক্ষতি রিপোর্ট (P&L)
            </button>
          </div>

          {/* Add Expense Button */}
          <button
            onClick={() => setShowExpenseModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-xs transition"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>খরচ যোগ করুন</span>
          </button>
        </div>
      </div>

      {/* VIEW 1: DAILY REPORT (আজকের হিসাব) */}
      {activeReportTab === 'daily' && (
        <div className="space-y-6">
          <div className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 inline-block">
            📅 আজকের তারিখ: {new Date().toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>

          {/* 4 Primary Daily KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Today Sales */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-1 text-xs">
                <span>আজকের মোট বিক্রি</span>
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
                  <ArrowUpRight className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
                ৳ {toBnNum(todayMetrics.sales)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                নগদ আদায়: <strong className="text-emerald-700">৳ {toBnNum(todayMetrics.collectedCash)}</strong> ({toBnNum(todayMetrics.count)} টি মেমো)
              </p>
            </div>

            {/* Today Purchases */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-1 text-xs">
                <span>আজকের মাল কেনা (ক্রয়)</span>
                <span className="p-1.5 rounded-lg bg-blue-50 text-blue-700">
                  <ShoppingBag className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-bold font-mono text-blue-900 tabular-nums">
                ৳ {toBnNum(todayMetrics.purchasesTotal)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                আড়ত / পাইকারি সরবরাহকারী থেকে
              </p>
            </div>

            {/* Today Dues */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-1 text-xs">
                <span>আজকের বাকি দেওয়া হলো</span>
                <span className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
                  <AlertCircle className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-bold font-mono text-amber-800 tabular-nums">
                ৳ {toBnNum(todayMetrics.dues)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                বাকির খাতায় যুক্ত হয়েছে
              </p>
            </div>

            {/* Today Net Profit */}
            <div className="bg-white p-4 rounded-2xl border border-emerald-300 bg-gradient-to-br from-emerald-50/50 to-white shadow-xs">
              <div className="flex items-center justify-between text-slate-500 mb-1 text-xs">
                <span className="font-semibold text-emerald-900">আজকের প্রকৃত লাভ</span>
                <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
                  <TrendingUp className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-800 tabular-nums">
                ৳ {toBnNum(todayMetrics.netProfit)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                মোট লাভ ৳{toBnNum(todayMetrics.grossProfit)} - খরচ ৳{toBnNum(todayMetrics.expenseTotal)}
              </p>
            </div>

          </div>

          {/* Daily Cash Breakdown & Expenses */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Left: Today's Purchases details */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
              <h3 className="font-bold text-slate-900 text-sm flex items-center justify-between">
                <span>আজকের মাল তোলার তালিকা (ক্রয় রেকর্ড)</span>
                <span className="text-xs text-slate-500 font-mono">
                  মোট: ৳{toBnNum(todayMetrics.purchasesTotal)}
                </span>
              </h3>
              <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
                {purchases.filter(p => new Date(p.date).toDateString() === todayDateStr).length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center">
                    আজকে নতুন কোনো পাইকারি মাল ক্রয় এন্ট্রি করা হয়নি।
                  </p>
                ) : (
                  purchases
                    .filter(p => new Date(p.date).toDateString() === todayDateStr)
                    .map((pur) => (
                      <div key={pur.id} className="py-2 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-semibold text-slate-800">{pur.productName}</div>
                          <div className="text-[11px] text-slate-500">{pur.supplierName || 'আড়ত'}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono font-bold text-slate-900">
                            ৳{toBnNum(pur.totalCost)}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            {toBnNum(pur.quantity)} {pur.unit} × ৳{toBnNum(pur.unitCost)}
                          </div>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>

            {/* Right: Today's Expenses details */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 text-sm">আজকের দোকান পরিচালনা খরচ</h3>
                <span className="text-xs font-mono font-bold text-red-700">
                  মোট খরচ: ৳{toBnNum(todayMetrics.expenseTotal)}
                </span>
              </div>
              <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
                {expenses.filter(e => new Date(e.date).toDateString() === todayDateStr).length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center">
                    আজকে কোনো অতিরিক্ত দোকান খরচ এন্ট্রি করা হয়নি।
                  </p>
                ) : (
                  expenses
                    .filter(e => new Date(e.date).toDateString() === todayDateStr)
                    .map((exp) => (
                      <div key={exp.id} className="py-2 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-semibold text-slate-800">{exp.title}</div>
                          <div className="text-[11px] text-slate-500">
                            {EXPENSE_CATEGORIES.find(c => c.id === exp.category)?.label}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-red-600">
                            - ৳{toBnNum(exp.amount)}
                          </span>
                          <button
                            onClick={() => onDeleteExpense(exp.id)}
                            className="text-slate-400 hover:text-red-600 p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* VIEW 2: MONTHLY REPORT (মাসিক হিসাব) */}
      {activeReportTab === 'monthly' && (
        <div className="space-y-6">
          <div className="text-xs font-semibold text-blue-900 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200 inline-block">
            📅 চলতি মাস: {new Date().toLocaleDateString('bn-BD', { month: 'long', year: 'numeric' })}
          </div>

          {/* 4 Monthly KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">চলতি মাসের মোট বিক্রি</span>
              <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
                ৳ {toBnNum(monthMetrics.sales)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                নগদ আদায়: <strong>৳{toBnNum(monthMetrics.collectedCash)}</strong>
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">চলতি মাসের মোট মাল ক্রয়</span>
              <div className="text-2xl font-bold font-mono text-blue-900 mt-1 tabular-nums">
                ৳ {toBnNum(monthMetrics.purchasesTotal)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                স্টকে নতুন মাল তোলা
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500">দোকানের মোট বাকি (পাওনা)</span>
              <div className="text-2xl font-bold font-mono text-amber-800 mt-1 tabular-nums">
                ৳ {toBnNum(totalReceivableDues)}
              </div>
              <p className="text-[11px] text-amber-700 mt-1">
                এই মাসে বাকি দেওয়া: ৳{toBnNum(monthMetrics.dues)}
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-emerald-300 bg-gradient-to-br from-emerald-50/50 to-white shadow-xs">
              <span className="text-xs font-semibold text-emerald-900">চলতি মাসের নিট প্রকৃত লাভ</span>
              <div className="text-2xl font-bold font-mono text-emerald-800 mt-1 tabular-nums">
                ৳ {toBnNum(monthMetrics.netProfit)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                মুনাফার হার: <strong className="text-emerald-700">{toBnNum(monthMetrics.marginPercent)}%</strong>
              </p>
            </div>

          </div>

          {/* Monthly Expense Breakdown */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <h3 className="font-bold text-slate-900 text-sm mb-3">
              চলতি মাসের দোকান পরিচালন খরচের খতিয়ান
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {EXPENSE_CATEGORIES.map((cat) => {
                const totalForCat = expenses
                  .filter((e) => {
                    const d = new Date(e.date);
                    return d.getMonth() === currentMonth && d.getFullYear() === currentYear && e.category === cat.id;
                  })
                  .reduce((sum, e) => sum + e.amount, 0);

                return (
                  <div key={cat.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-xs text-slate-600 block">{cat.label}</span>
                    <span className="text-sm font-bold font-mono text-slate-900 mt-1 block">
                      ৳ {toBnNum(totalForCat)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: AUTOMATED PROFIT & LOSS STATEMENT (মাসিক স্বয়ংক্রিয় লাভ-ক্ষতি বিবরণী) */}
      {activeReportTab === 'pl_report' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-6 max-w-3xl mx-auto space-y-6">
          
          {/* Statement Header */}
          <div className="text-center pb-4 border-b border-slate-200">
            <h2 className="text-xl font-bold text-slate-900">{storeProfile.name}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{storeProfile.address} | ফোন: {storeProfile.phone}</p>
            <div className="mt-2 inline-block px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-bold text-xs">
              স্বয়ংক্রিয় লাভ-ক্ষতি বিবরণী (Profit & Loss Statement)
            </div>
            <p className="text-xs text-slate-500 mt-1">
              হিসাবের সময়কাল: {new Date().toLocaleDateString('bn-BD', { month: 'long', year: 'numeric' })}
            </p>
          </div>

          {/* Statement Table */}
          <div className="space-y-4 text-xs sm:text-sm">
            
            {/* 1. Revenue */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div className="flex justify-between items-center font-bold text-slate-900">
                <span>১. মোট বিক্রয় আয় (Total Sales Revenue):</span>
                <span className="font-mono text-base text-emerald-900">৳ {toBnNum(monthMetrics.sales)}</span>
              </div>
              <div className="flex justify-between text-slate-500 text-xs mt-1 pl-3">
                <span>- নগদ বিক্রয় আদায়:</span>
                <span className="font-mono">৳ {toBnNum(monthMetrics.collectedCash)}</span>
              </div>
              <div className="flex justify-between text-slate-500 text-xs pl-3">
                <span>- বকেয়া / বাকি বিক্রয়:</span>
                <span className="font-mono">৳ {toBnNum(monthMetrics.dues)}</span>
              </div>
            </div>

            {/* 2. COGS */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div className="flex justify-between items-center font-bold text-slate-900">
                <span>২. বাদ: বিক্রিত পণ্যের ক্রয়মূল্য (Cost of Goods Sold - COGS):</span>
                <span className="font-mono text-base text-red-700">- ৳ {toBnNum(monthMetrics.cogs)}</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 pl-3">
                (যে মালামাল বিক্রি হয়েছে তার প্রকৃত পাইকারি ক্রয়মূল্য)
              </p>
            </div>

            {/* 3. Gross Profit */}
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 flex justify-between items-center text-emerald-950 font-bold">
              <span>৩. মোট ব্যবসায়িক লাভ (Gross Profit):</span>
              <span className="text-lg font-mono text-emerald-800">৳ {toBnNum(monthMetrics.grossProfit)}</span>
            </div>

            {/* 4. Operating Expenses */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5">
              <div className="flex justify-between items-center font-bold text-slate-900">
                <span>৪. বাদ: দোকান পরিচালনা খরচ (Operating Expenses):</span>
                <span className="font-mono text-base text-red-700">- ৳ {toBnNum(monthMetrics.expenseTotal)}</span>
              </div>
              <div className="pl-3 space-y-1 text-slate-600 text-xs pt-1">
                {EXPENSE_CATEGORIES.map((cat) => {
                  const catAmt = expenses
                    .filter(e => {
                      const d = new Date(e.date);
                      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && e.category === cat.id;
                    })
                    .reduce((sum, e) => sum + e.amount, 0);

                  if (catAmt === 0) return null;
                  return (
                    <div key={cat.id} className="flex justify-between">
                      <span>• {cat.label}:</span>
                      <span className="font-mono">৳ {toBnNum(catAmt)}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 5. NET PROFIT (নিট প্রকৃত লাভ) */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-800 to-emerald-900 text-white flex justify-between items-center shadow-lg">
              <div>
                <span className="text-xs uppercase tracking-wider text-emerald-200 font-semibold block">
                  মাস শেষে মোট নিট মুনাফা (Net Profit)
                </span>
                <span className="text-xs text-emerald-100/80">
                  সকল খরচ ও কেনাকাটা বাদ দিয়ে পকেটের টাকা
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono text-white tabular-nums">
                ৳ {toBnNum(monthMetrics.netProfit)}
              </div>
            </div>

          </div>

          {/* Print Report Button */}
          <div className="pt-2 flex justify-end gap-2 no-print">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs"
            >
              <Printer className="w-4 h-4" />
              <span>রিপোর্ট প্রিন্ট করুন</span>
            </button>
          </div>

        </div>
      )}

      {/* Add Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm">দোকানের খরচ এন্ট্রি করুন</h3>
              <button
                onClick={() => setShowExpenseModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  খরচের বিবরণ / নাম*
                </label>
                <input
                  type="text"
                  placeholder="যেমন: কর্মচারীর বেতন, বিদ্যুৎ বিল, সকালের নাস্তা"
                  value={expenseTitle}
                  onChange={(e) => setExpenseTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  খরচের খাত (Category)
                </label>
                <select
                  value={expenseCategory}
                  onChange={(e) => setExpenseCategory(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  {EXPENSE_CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>{c.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  টাকার পরিমাণ (৳)*
                </label>
                <input
                  type="number"
                  placeholder="৳ ৫০০"
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-base font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  মন্তব্য (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  placeholder="যেমন: রশিদের মেমো নং বা পরিশোধের মাধ্যম"
                  value={expenseNote}
                  onChange={(e) => setExpenseNote(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowExpenseModal(false)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-800 text-white rounded-lg font-bold hover:bg-emerald-700"
                >
                  খরচ সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
