import React from 'react';
import { useApp } from '../../context/AppContext';

export const WeeklyProgressChart: React.FC = () => {
  const { weeklyActivity, t } = useApp();

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            {t.weeklyOverview}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t.weeklyHabitConsistency}
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <span className="w-2.5 h-2.5 rounded-full bg-violet-500 inline-block" />
          <span>Active</span>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2 items-end pt-2 pb-1">
        {weeklyActivity.map((day, idx) => {
          const heightPercent = Math.max(12, day.percent);
          return (
            <div key={idx} className="flex flex-col items-center gap-2">
              <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                {day.percent}%
              </div>
              
              {/* Bar track */}
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-24 flex items-end p-1 relative overflow-hidden">
                <div
                  className={`w-full rounded-full transition-all duration-500 ${
                    day.isToday
                      ? 'bg-linear-to-t from-violet-600 to-indigo-400 shadow-xs shadow-violet-500/40'
                      : day.percent >= 70
                      ? 'bg-violet-400/80 dark:bg-violet-500/70'
                      : day.percent > 0
                      ? 'bg-sky-400/70 dark:bg-sky-500/60'
                      : 'bg-transparent'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                />
              </div>

              {/* Day label */}
              <span
                className={`text-xs font-medium ${
                  day.isToday
                    ? 'font-bold text-violet-600 dark:text-violet-400'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {day.dayLabel}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
