import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  Circle,
  Plus,
  Flame,
  ArrowRight,
  Sparkles,
  Calendar,
  Check,
  Target,
  MoonStar,
  Quote,
  Clock,
  AlertCircle,
  Settings2,
  Lock,
  Edit2,
  Minus,
  ChevronDown,
  ChevronUp,
  CheckCheck,
  Bell,
  Trash2,
  WifiOff,
  Info,
  X,
  Volume2,
  BookOpen,
  Heart,
  Smartphone,
} from 'lucide-react';
import { useApp, getTodayString } from '../../context/AppContext';
import { WeeklyProgressChart } from './WeeklyProgressChart';
import { DailyPrayers, Task, Habit, Goal } from '../../types';
import {
  getAllPrayerStatuses,
  getActivePrayerWaqt,
  formatTo12Hour,
  toBengaliNumerals,
} from '../../utils/prayerTimes';
import { CustomizePrayerTimesModal } from '../Prayer/CustomizePrayerTimesModal';
import { AlarmToneSelectorModal } from '../Alarm/AlarmToneSelectorModal';
import { AndroidAlarmSettingsModal } from '../Alarm/AndroidAlarmSettingsModal';
import { HabivioWeatherWidget, WeatherCondition } from '../Weather/HabivioWeatherWidget';

interface HomeDashboardProps {
  onOpenTaskModal: (task?: Task) => void;
  onOpenHabitModal: (habit?: Habit) => void;
  onOpenGoalModal: (goal?: Goal) => void;
  onTestLockScreenAlarm?: () => void;
}

// Convert date to authentic Bengali format
function getBengaliFullDate(date: Date = new Date()): string {
  const daysBn = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
  const monthsBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];
  const dayName = daysBn[date.getDay()];
  const dayNum = toBengaliNumerals(date.getDate());
  const monthName = monthsBn[date.getMonth()];
  const yearNum = toBengaliNumerals(date.getFullYear());
  return `${dayName}, ${dayNum} ${monthName} ${yearNum}`;
}

// Grammatically correct Bengali possessive prayer name
function getPrayerPossessiveName(name: string): string {
  if (name === 'ফজর') return 'ফজরের';
  if (name === 'যোহর') return 'যোহরের';
  if (name === 'আসর') return 'আসরের';
  if (name === 'মাগরিব') return 'মাগরিবের';
  if (name === 'এশা') return 'এশার';
  if (name === 'তাহাজ্জুদ') return 'তাহাজ্জুদের';
  return `${name}ের`;
}

// Days remaining calculation
function getDaysRemaining(targetDateStr: string, isBn: boolean): string {
  if (!targetDateStr) return '';
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const target = new Date(targetDateStr);
  target.setHours(0, 0, 0, 0);
  const diffTime = target.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return isBn ? 'মেয়াদ উত্তীর্ণ' : 'Overdue';
  }
  if (diffDays === 0) {
    return isBn ? 'আজই শেষ দিন' : 'Due today';
  }
  return isBn ? `আর ${toBengaliNumerals(diffDays)} দিন বাকি` : `${diffDays} days left`;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onOpenTaskModal,
  onOpenHabitModal,
  onOpenGoalModal,
  onTestLockScreenAlarm,
}) => {
  const {
    tasks,
    habits,
    goals,
    prayers,
    togglePrayer,
    toggleTaskCompleted,
    deleteTask,
    incrementHabitCount,
    decrementHabitCount,
    toggleGoalMilestone,
    todayMetrics,
    t,
    setActiveTab,
    language,
  } = useApp();

  const [isCustomizeTimesOpen, setIsCustomizeTimesOpen] = useState(false);
  const [isRingtoneModalOpen, setIsRingtoneModalOpen] = useState(false);
  const [taskFilter, setTaskFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [expandedGoalId, setExpandedGoalId] = useState<string | null>(null);
  const [isOfflineInfoModalOpen, setIsOfflineInfoModalOpen] = useState(false);
  const [isAndroidAlarmModalOpen, setIsAndroidAlarmModalOpen] = useState(false);
  const [homeWeather, setHomeWeather] = useState<{ condition: WeatherCondition; tempC: number }>({
    condition: 'rain',
    tempC: 26,
  });
  const [isWeatherSectionVisible, setIsWeatherSectionVisible] = useState(true);

  const isBn = language === 'bn';
  const todayStr = getTodayString();
  const todayTasks = tasks.filter((t) => t.dueDate === todayStr || t.isRoutine);
  const routineTasks = tasks.filter((t) => t.isRoutine);
  const activeGoals = goals.slice(0, 3);
  const todayPrayers = (prayers[todayStr] || {
    fajr: false,
    dhuhr: false,
    asr: false,
    maghrib: false,
    isha: false,
    tahajjud: false,
  }) as Record<string, any>;

  // Friday / Jummah special detection
  const isActualFriday = new Date().getDay() === 5;
  const [isForceFriday, setIsForceFriday] = useState(() => isActualFriday);
  const isFriday = isForceFriday;

  // Friday Sunnah trackers
  const [duroodCount, setDuroodCount] = useState<number>(() => {
    if (typeof window === 'undefined') return 0;
    return Number(localStorage.getItem('habivio_durood_count') || '0');
  });
  const [kahfRead, setKahfRead] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('habivio_kahf_read') === 'true';
  });
  const [ghuslDone, setGhuslDone] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('habivio_ghusl_done') === 'true';
  });

  const handleIncrementDurood = () => {
    const next = duroodCount + 1;
    setDuroodCount(next);
    localStorage.setItem('habivio_durood_count', String(next));
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(25);
    }
  };

  const handleToggleKahf = () => {
    const next = !kahfRead;
    setKahfRead(next);
    localStorage.setItem('habivio_kahf_read', String(next));
  };

  const handleToggleGhusl = () => {
    const next = !ghuslDone;
    setGhuslDone(next);
    localStorage.setItem('habivio_ghusl_done', String(next));
  };

  // Filtered tasks for today
  const filteredTodayTasks = useMemo(() => {
    if (taskFilter === 'pending') return todayTasks.filter((t) => !t.completed);
    if (taskFilter === 'completed') return todayTasks.filter((t) => t.completed);
    return todayTasks;
  }, [todayTasks, taskFilter]);

  // Motivational quote determination
  const getMotivationalMessage = () => {
    if (todayMetrics.overallPercent === 100) return t.quoteComplete;
    if (todayMetrics.overallPercent >= 75) return t.quote4;
    if (todayMetrics.overallPercent >= 50) return t.quote2;
    if (todayMetrics.overallPercent >= 25) return t.quote5;
    return t.quote3;
  };

  // Prayer list item configuration (Strict sequence: Fajr -> Dhuhr/Jummah -> Asr -> Maghrib -> Isha)
  const prayerItems: Array<{ key: keyof DailyPrayers; label: string; icon: string }> = [
    { key: 'fajr', label: t.fajr, icon: '🌅' },
    { key: 'dhuhr', label: isFriday ? (isBn ? 'জুম্মা' : 'Jummah') : t.dhuhr, icon: isFriday ? '🕌' : '☀️' },
    { key: 'asr', label: t.asr, icon: '⛅' },
    { key: 'maghrib', label: t.maghrib, icon: '🌇' },
    { key: 'isha', label: t.isha, icon: '🌙' },
    { key: 'tahajjud', label: t.tahajjud, icon: '✨' },
  ];

  // Daily 5 obligatory prayers sequence (Fajr to Isha)
  const daily5Keys: Array<keyof DailyPrayers> = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const daily5DoneCount = daily5Keys.filter((k) => Boolean(todayPrayers[k])).length;
  const isAllDaily5Done = daily5DoneCount === 5;

  const allStatuses = getAllPrayerStatuses(todayPrayers as any, new Date(), isBn);
  const activeWaqt = getActivePrayerWaqt(todayPrayers as any, new Date(), isBn);
  const upcomingWaqt = !activeWaqt ? allStatuses.find((s) => s.isUpcoming) : null;

  return (
    <div className="space-y-5 pb-6">
      {/* Date & Day Header Bar with Ringtone and Alarm quick triggers */}
      <div className="flex items-center justify-between px-1 flex-wrap gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-violet-600 dark:text-violet-400">
              {isBn ? 'আজকের দিন' : 'Today'}
            </span>
            {isFriday && (
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-600 dark:text-emerald-400 text-[10px] font-extrabold flex items-center gap-1">
                <span>🕌</span>
                <span>{isBn ? 'পবিত্র জুম্মার দিন' : 'Holy Jummah'}</span>
              </span>
            )}
          </div>
          <h2 className="text-sm font-extrabold text-slate-800 dark:text-slate-100">
            {isBn ? getBengaliFullDate(new Date()) : new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' })}
          </h2>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Live Weather Indicator Pill with °C on Home Screen */}
          <button
            type="button"
            onClick={() => setIsWeatherSectionVisible((prev) => !prev)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-50 dark:bg-sky-950/60 border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-300 text-xs font-bold hover:bg-sky-100 dark:hover:bg-sky-900 transition-all active:scale-95 shadow-xs cursor-pointer"
            title={isBn ? 'হোম স্ক্রিন আবহাওয়া অ্যানিমেশন ও আপডেট' : 'Live weather animation & update'}
          >
            <span className="text-sm">
              {homeWeather.condition === 'rain'
                ? '🌧️'
                : homeWeather.condition === 'cold'
                ? '❄️'
                : homeWeather.condition === 'wind'
                ? '💨'
                : homeWeather.condition === 'heat'
                ? '☀️'
                : '✨'}
            </span>
            <span className="text-[11px] font-mono font-black">
              {isBn ? `${toBengaliNumerals(homeWeather.tempC)}° সে.` : `${homeWeather.tempC}°C`}
            </span>
          </button>

          {/* Android Smart Alarm System Pill */}
          <button
            type="button"
            onClick={() => setIsAndroidAlarmModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800/80 text-indigo-700 dark:text-indigo-300 text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-all active:scale-95 shadow-xs cursor-pointer"
            title={isBn ? 'অ্যান্ড্রয়েড ও রেডমি স্মার্ট অ্যালার্ম সেটিংস' : 'Android & Redmi Smart Alarm Settings'}
          >
            <Smartphone size={13} className="text-indigo-600 dark:text-indigo-400" />
            <span className="text-[11px]">{isBn ? 'স্মার্ট অ্যালার্ম' : 'Smart Alarm'}</span>
          </button>

          {/* Ringtone Selector Button */}
          <button
            type="button"
            onClick={() => setIsRingtoneModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-violet-50 dark:bg-violet-950/60 border border-violet-200 dark:border-violet-800 text-violet-700 dark:text-violet-300 text-xs font-bold hover:bg-violet-100 dark:hover:bg-violet-900 transition-all active:scale-95 shadow-xs cursor-pointer"
            title={isBn ? 'অ্যালার্মের রিংটোন পরিবর্তন বা বন্ধ করুন' : 'Change or mute alarm ringtone'}
          >
            <Volume2 size={13} className="text-violet-600 dark:text-violet-400" />
            <span className="text-[11px]">{isBn ? 'রিংটোন' : 'Ringtone'}</span>
          </button>

          {/* Lock Screen Alarm Status Pill with Test Trigger */}
          {onTestLockScreenAlarm && (
            <button
              onClick={onTestLockScreenAlarm}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800/80 text-rose-700 dark:text-rose-300 text-xs font-bold hover:bg-rose-100 dark:hover:bg-rose-900 transition-all active:scale-95 shadow-xs cursor-pointer"
              title={isBn ? 'ফোন লক থাকা অবস্থায় অ্যালার্ম টেস্ট করুন' : 'Test alarm with phone locked'}
            >
              <Lock size={12} className="text-rose-600 dark:text-rose-400" />
              <span className="text-[11px]">{isBn ? 'লক টেস্ট' : 'Test Alarm'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Home Screen Live Weather Animation Card with °C (কিছু সেকেন্ডের অ্যানিমেশন ও লাইভ আপডেট) */}
      {isWeatherSectionVisible && (
        <HabivioWeatherWidget
          isBn={isBn}
          onWeatherChange={(cond, t) => setHomeWeather({ condition: cond, tempC: t })}
          showTestPills={true}
        />
      )}

      {/* 1. Ultra-Luxury Daily Completion Hero Card */}
      <section className="relative overflow-hidden rounded-3xl bg-linear-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 text-white shadow-2xl shadow-indigo-950/50 p-6 transition-all font-bangla-display">
        {/* Iridescent radial ambient lighting */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-64 h-64 bg-violet-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-52 h-52 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="space-y-3 flex-1">
            {/* Top Badge: Tagline & Friday indicator */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-xs font-bold tracking-wide text-indigo-200">
                <Sparkles size={13} className="text-amber-300" />
                <span>{t.tagline}</span>
              </div>

              {isFriday && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-xs font-bold text-emerald-200">
                  <span>🕌</span>
                  <span>{isBn ? 'জুম্মা মোবারক • নেক আমলের সুবর্ণ সুযোগ' : 'Jummah Mubarak'}</span>
                </div>
              )}
            </div>

            {/* Main Percentage Headline with Gradient Text */}
            <div className="flex items-baseline gap-2.5 pt-0.5">
              <h2 className="text-4xl sm:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-linear-to-r from-white via-indigo-100 to-sky-200 font-bangla-display">
                {isBn ? `${toBengaliNumerals(todayMetrics.overallPercent)}%` : `${todayMetrics.overallPercent}%`}
              </h2>
              <span className="text-xl sm:text-2xl font-extrabold text-slate-200 font-bangla-display">
                {t.completed}
              </span>
            </div>

            <p className="text-slate-300 text-xs sm:text-sm font-medium leading-relaxed font-bangla-display max-w-md">
              {t.dailyProgressSubtitle}
            </p>

            {/* 3 Pillar Micro Stats Panels (Tasks, Habits, Prayers) */}
            <div className="grid grid-cols-1 xs:grid-cols-3 sm:flex items-center gap-2 pt-2 text-xs font-semibold">
              {/* Tasks Metric */}
              <div className="flex items-center gap-2 bg-slate-800/80 border border-sky-500/30 px-3 py-2 rounded-2xl shadow-xs">
                <div className="w-2 h-2 rounded-full bg-sky-400 shrink-0 animate-pulse" />
                <span className="text-white font-extrabold text-xs">
                  {isBn ? toBengaliNumerals(todayMetrics.tasksDone) : todayMetrics.tasksDone}/{isBn ? toBengaliNumerals(todayMetrics.tasksTotal) : todayMetrics.tasksTotal}
                </span>
                <span className="text-slate-300 text-[11px] truncate">
                  {t.tasksCompleted}
                </span>
              </div>

              {/* Habits Metric */}
              <div className="flex items-center gap-2 bg-slate-800/80 border border-emerald-500/30 px-3 py-2 rounded-2xl shadow-xs">
                <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 animate-pulse" />
                <span className="text-white font-extrabold text-xs">
                  {isBn ? toBengaliNumerals(todayMetrics.habitsDone) : todayMetrics.habitsDone}/{isBn ? toBengaliNumerals(todayMetrics.habitsTotal) : todayMetrics.habitsTotal}
                </span>
                <span className="text-slate-300 text-[11px] truncate">
                  {t.habitsChecked}
                </span>
              </div>

              {/* Prayers Metric */}
              <div className="flex items-center gap-2 bg-slate-800/80 border border-amber-500/30 px-3 py-2 rounded-2xl shadow-xs">
                <div className="w-2 h-2 rounded-full bg-amber-400 shrink-0 animate-pulse" />
                <span className="text-white font-extrabold text-xs">
                  {isBn ? toBengaliNumerals(todayMetrics.prayersDone) : todayMetrics.prayersDone}/{isBn ? '৫' : '5'}
                </span>
                <span className="text-slate-300 text-[11px] truncate">
                  {t.prayersDone}
                </span>
              </div>
            </div>
          </div>

          {/* Luxury Circular Progress Gauge with Radiant Multi-Stop Gradient */}
          <div className="relative shrink-0 self-center sm:self-auto p-1">
            <svg className="w-26 h-26 transform -rotate-90">
              <defs>
                <linearGradient id="heroGradientStroke" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#38bdf8" />
                  <stop offset="50%" stopColor="#818cf8" />
                  <stop offset="100%" stopColor="#34d399" />
                </linearGradient>
              </defs>
              <circle
                cx="52"
                cy="52"
                r="44"
                className="text-slate-800"
                strokeWidth="8"
                stroke="currentColor"
                fill="transparent"
              />
              <circle
                cx="52"
                cy="52"
                r="44"
                stroke="url(#heroGradientStroke)"
                strokeWidth="8"
                strokeDasharray={2 * Math.PI * 44}
                strokeDashoffset={2 * Math.PI * 44 * (1 - todayMetrics.overallPercent / 100)}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-black font-bangla-display text-white">
                {isBn ? toBengaliNumerals(todayMetrics.overallPercent) : todayMetrics.overallPercent}%
              </span>
              <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider">
                {isBn ? 'আজকের লক্ষ্য' : t.today}
              </span>
            </div>
          </div>
        </div>

        {/* Motivational Banner with Authentic Bengali Serif Typography */}
        <div className="mt-5 pt-3.5 border-t border-white/10 flex items-start gap-2.5 text-white/95 bg-slate-950/40 p-3 rounded-2xl">
          <Quote size={18} className="text-amber-300 shrink-0 mt-0.5" />
          <p className="font-bangla-serif italic tracking-wide text-xs sm:text-[13px] leading-relaxed text-amber-100/90 font-medium">
            "{getMotivationalMessage()}"
          </p>
        </div>
      </section>

      {/* Habivio AI Executive Supervisor & Security Status Banner */}
      <section 
        onClick={() => setActiveTab('ai')}
        className="cursor-pointer group p-4 rounded-3xl bg-linear-to-r from-violet-900/90 via-indigo-900/90 to-slate-900/95 border border-violet-500/40 text-white shadow-lg shadow-violet-950/30 hover:border-violet-400 transition-all active:scale-[0.99]"
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative shrink-0 w-11 h-11 rounded-2xl bg-linear-to-tr from-violet-600 to-indigo-500 flex items-center justify-center shadow-md shadow-violet-500/30 group-hover:scale-105 transition-transform">
              <Sparkles size={20} className="text-white animate-pulse" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-900" />
            </div>

            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-white group-hover:text-violet-300 transition-colors">
                  {isBn ? 'হাবিভিও এআই সহকারী ও সিকিউরিটি শিল্ড' : 'Habivio Executive AI & Shield'}
                </h4>
                <span className="px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                  {isBn ? '২৪/৭ সজাগ' : '24/7 Active'}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 line-clamp-1 leading-snug">
                {isBn
                  ? 'আপনার অনুমতি নিয়ে পুরো অ্যাপ ম্যানেজ করছে • ভাইরাস ও হুমকি থেকে ১০০% সুরক্ষিত'
                  : 'Manages app with your permission • 100% secure from viruses and leaks'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-bold text-violet-300 group-hover:text-white shrink-0">
            <span className="hidden xs:inline">{isBn ? 'ম্যানেজার খুলুন' : 'Open AI'}</span>
            <ArrowRight size={15} className="group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>
      </section>

      {/* Special Holy Friday / Jummah Barakah Card */}
      {isFriday && (
        <section className="relative overflow-hidden rounded-3xl bg-linear-to-br from-emerald-950/90 via-teal-950/90 to-slate-900/95 border border-emerald-500/40 text-white shadow-xl shadow-emerald-950/40 p-5 transition-all font-bangla-display">
          <div className="absolute top-0 right-0 -mt-8 -mr-8 w-48 h-48 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-2xl shadow-inner">
                  🕌
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 text-[10px] font-extrabold uppercase tracking-wider">
                      {isBn ? 'সাপ্তাহিক শ্রেষ্ঠ দিন' : 'Best Day of Week'}
                    </span>
                    <span className="text-xs text-amber-300 font-bold">
                      {isBn ? 'আজ পবিত্র জুম্মা' : 'Holy Jummah'}
                    </span>
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-white mt-0.5">
                    {isBn ? 'পবিত্র জুম্মা মোবারক • বিশেষ বরকত ও আমল' : 'Jummah Mubarak • Special Blessings & Sunnahs'}
                  </h3>
                </div>
              </div>

              <div className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-200 text-xs font-bold border border-emerald-400/30">
                {isBn ? 'দোয়া কবুলের দিন' : 'Day of Acceptance'}
              </div>
            </div>

            {/* Hadith Quote */}
            <div className="p-3 rounded-2xl bg-slate-900/60 border border-emerald-500/20 text-xs text-emerald-100/90 italic flex items-start gap-2">
              <Quote size={14} className="shrink-0 text-amber-300 mt-0.5" />
              <span>
                {isBn
                  ? 'রাসূলুল্লাহ (ﷺ) বলেছেন: "যে ব্যক্তি জুম্মার দিনে সূরা আল-কাহফ পাঠ করবে, তার জন্য এক জুম্মা হতে অন্য জুম্মা পর্যন্ত বিশেষ নূর জ্যোতির্ময় থাকবে।"'
                  : 'Prophet (ﷺ) said: "Whoever recites Surah Al-Kahf on Friday, light will shine for him from one Friday to the next."'}
              </span>
            </div>

            {/* Friday Sunnah Interactive Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
              {/* Sunnah 1: Ghusl */}
              <button
                type="button"
                onClick={handleToggleGhusl}
                className={`p-3 rounded-2xl border text-left flex items-center justify-between gap-2.5 transition-all active:scale-95 cursor-pointer ${
                  ghuslDone
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                    : 'bg-slate-900/50 border-slate-700/80 text-slate-300 hover:border-emerald-500/40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">🚿</span>
                  <div>
                    <span className="text-xs font-bold block">{isBn ? 'গোসল ও পরিচ্ছন্নতা' : 'Ghusl & Cleanliness'}</span>
                    <span className="text-[10px] text-slate-400">{isBn ? 'জুম্মার সুন্নাহ গোসল' : 'Friday Sunnah bath'}</span>
                  </div>
                </div>
                <div className={`w-5 h-5 rounded-lg flex items-center justify-center ${ghuslDone ? 'bg-emerald-500 text-white' : 'border border-slate-600'}`}>
                  {ghuslDone && <Check size={12} className="stroke-[3]" />}
                </div>
              </button>

              {/* Sunnah 2: Surah Al-Kahf */}
              <button
                type="button"
                onClick={handleToggleKahf}
                className={`p-3 rounded-2xl border text-left flex items-center justify-between gap-2.5 transition-all active:scale-95 cursor-pointer ${
                  kahfRead
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                    : 'bg-slate-900/50 border-slate-700/80 text-slate-300 hover:border-emerald-500/40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">📖</span>
                  <div>
                    <span className="text-xs font-bold block">{isBn ? 'সূরা আল-কাহফ তিলাওয়াত' : 'Surah Al-Kahf'}</span>
                    <span className="text-[10px] text-slate-400">{isBn ? 'জুম্মার নূরময় আমল' : 'Blessed recitation'}</span>
                  </div>
                </div>
                <div className={`w-5 h-5 rounded-lg flex items-center justify-center ${kahfRead ? 'bg-emerald-500 text-white' : 'border border-slate-600'}`}>
                  {kahfRead && <Check size={12} className="stroke-[3]" />}
                </div>
              </button>

              {/* Sunnah 3: Durood Sharif Tap Counter */}
              <div className="p-3 rounded-2xl border bg-slate-900/50 border-slate-700/80 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-lg">📿</span>
                  <div className="min-w-0">
                    <span className="text-xs font-bold block truncate">{isBn ? 'দরূদ শরীফ পাঠ' : 'Durood Sharif'}</span>
                    <span className="text-[10px] text-amber-300 font-mono font-bold">
                      {isBn ? `${toBengaliNumerals(duroodCount)} বার পঠিত` : `${duroodCount} recited`}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleIncrementDurood}
                  className="px-2.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold flex items-center gap-1 active:scale-90 transition-transform shadow-xs shrink-0 cursor-pointer"
                  title={isBn ? 'দরূদ পাঠ সংখ্যা ১ বাড়ান' : 'Increment Durood count'}
                >
                  <Plus size={12} />
                  <span>{isBn ? 'পাঠ' : '+1'}</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* 2. Enhanced Prayer Waqt Center (With Hours First, Then Minutes Countdown & In-Place Editing) */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors space-y-4">
        {/* Section Header with Settings & Edit Button */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400">
              <MoonStar size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>{t.prayerProgress}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-violet-100 dark:bg-violet-950/80 text-violet-700 dark:text-violet-300">
                  {isBn ? `${toBengaliNumerals(daily5DoneCount)}/৫ ওয়াক্ত` : `${daily5DoneCount}/5 Done`}
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isBn ? 'ওয়াক্তের শুরু ও শেষ সময় এবং লাইভ ঘণ্টা-মিনিট হিসাব' : 'Live prayer waqt start, end & hour-minute countdown'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsCustomizeTimesOpen(true)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:border-violet-400 text-xs font-semibold flex items-center gap-1.5 transition-colors active:scale-95 shadow-xs cursor-pointer"
              title={isBn ? 'ওয়াক্তের সময় পরিবর্তন ও এডিট করুন' : 'Edit prayer start/end times'}
            >
              <Settings2 size={13} className="text-violet-500" />
              <span>{isBn ? 'ওয়াক্ত এডিট' : 'Edit Times'}</span>
            </button>
            <button
              onClick={() => setActiveTab('prayer')}
              className="p-1.5 text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors"
              aria-label="View Prayer section"
            >
              <ArrowRight size={16} />
            </button>
          </div>
        </div>

        {/* Daily 5 Prayers Step-by-Step Progress Track (Fajr -> Dhuhr/Jummah -> Asr -> Maghrib -> Isha) */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 space-y-2.5 font-bangla-display">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <span>📿</span>
              <span>{isBn ? 'দৈনিক ৫ ওয়াক্ত নামাজের ধারাবাহিক যাত্রা (ফজর ➔ এশা)' : 'Daily 5 Prayers Sequence (Fajr ➔ Isha)'}</span>
            </span>
            <span className={`font-mono font-bold px-2 py-0.5 rounded-full text-[11px] ${
              isAllDaily5Done
                ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                : 'bg-violet-500/15 text-violet-700 dark:text-violet-300'
            }`}>
              {isBn ? `${toBengaliNumerals(daily5DoneCount)}/৫ ওয়াক্ত সম্পূর্ণ` : `${daily5DoneCount}/5 Prayers Completed`}
            </span>
          </div>

          {/* Stepper nodes */}
          <div className="grid grid-cols-5 gap-1 relative">
            {daily5Keys.map((key, idx) => {
              const isDone = Boolean(todayPrayers[key]);
              const item = prayerItems.find((p) => p.key === key);
              const label = item ? item.label : key;
              const icon = item ? item.icon : '🕌';

              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => togglePrayer(key)}
                  className={`p-2 rounded-xl flex flex-col items-center justify-center transition-all active:scale-95 border cursor-pointer ${
                    isDone
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400/80 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300'
                      : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-violet-300'
                  }`}
                  title={`${label}: ${isDone ? (isBn ? 'আদায় সম্পন্ন' : 'Completed') : (isBn ? 'ক্লিক করে আদায় মার্ক করুন' : 'Click to complete')}`}
                >
                  <span className="text-base mb-0.5">{icon}</span>
                  <span className="text-[11px] font-bold truncate max-w-full">{label}</span>
                  <div className="mt-1 flex items-center justify-center">
                    {isDone ? (
                      <span className="w-4 h-4 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                        <Check size={10} className="stroke-[3]" />
                      </span>
                    ) : (
                      <span className="w-4 h-4 rounded-full border border-slate-300 dark:border-slate-600 text-[9px] font-mono flex items-center justify-center text-slate-400">
                        {isBn ? toBengaliNumerals(idx + 1) : idx + 1}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* All 5 Completed Celebration Message */}
          {isAllDaily5Done && (
            <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-400/30 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
              <Sparkles size={14} className="text-amber-400 shrink-0" />
              <span>
                {isBn
                  ? 'আলহামদুলিল্লাহ! আজকের ফজর থেকে এশা পর্যন্ত সকল ৫ ওয়াক্ত নামাজ সফলভাবে আদায় সম্পন্ন হয়েছে।'
                  : 'Alhamdulillah! All 5 daily prayers from Fajr to Isha are successfully completed today.'}
              </span>
            </div>
          )}
        </div>

        {/* Highlighted Active Waqt Banner */}
        {activeWaqt ? (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-500/40 text-white shadow-md space-y-3 font-bangla-display">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-2xl shadow-inner shrink-0">
                  {activeWaqt.icon}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 text-[10px] font-extrabold uppercase tracking-wider">
                      {isBn ? 'বর্তমান ওয়াক্ত' : 'Current Waqt'}
                    </span>
                    <span className="text-xs text-slate-300 font-mono">
                      {isBn ? 'শুরু: ' : 'Start: '}{formatTo12Hour(activeWaqt.startTime, isBn)} • {isBn ? 'শেষ: ' : 'End: '}{formatTo12Hour(activeWaqt.endTime, isBn)}
                    </span>
                  </div>
                  <h4 className="text-base sm:text-lg font-black text-white mt-1">
                    {isBn ? `${getPrayerPossessiveName(activeWaqt.name)} ওয়াক্ত চলছে` : `Current: ${activeWaqt.name} Waqt`}
                  </h4>
                </div>
              </div>

              {/* 1-Tap Check Action */}
              <button
                onClick={() => togglePrayer(activeWaqt.key as any)}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 shrink-0 cursor-pointer ${
                  todayPrayers[activeWaqt.key]
                    ? 'bg-emerald-500 text-white shadow-sm shadow-emerald-500/30'
                    : 'bg-white/15 hover:bg-white/25 text-white border border-white/20'
                }`}
              >
                {todayPrayers[activeWaqt.key] ? (
                  <>
                    <CheckCheck size={14} className="stroke-[3]" />
                    <span>{isBn ? 'আদায় সম্পন্ন' : 'Completed'}</span>
                  </>
                ) : (
                  <span>+ {isBn ? 'নামাজ আদায় করেছি' : 'Mark Done'}</span>
                )}
              </button>
            </div>

            {/* Countdown Box: Hours First, Then Minutes ("আগে ঘন্টা পরে মিনিট") */}
            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
                  <Clock size={16} />
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block font-medium">
                    {isBn ? 'ওয়াক্ত শেষ হওয়ার বাকি সময় (ঘণ্টা : মিনিট):' : 'Remaining Waqt Time (Hours : Minutes):'}
                  </span>
                  <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                    {activeWaqt.remainingHours > 0 && (
                      <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 font-mono font-extrabold text-xs border border-amber-500/30">
                        {isBn ? toBengaliNumerals(activeWaqt.remainingHours) : activeWaqt.remainingHours} {isBn ? 'ঘণ্টা' : 'hr'}
                      </span>
                    )}
                    <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 font-mono font-extrabold text-xs border border-amber-500/30">
                      {isBn ? toBengaliNumerals(activeWaqt.remainingMinsOnly) : activeWaqt.remainingMinsOnly} {isBn ? 'মিনিট' : 'min'}
                    </span>
                    <span className="text-xs text-amber-200 font-bold ml-1">
                      {isBn ? 'বাকি' : 'remaining'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="text-left sm:text-right border-t sm:border-t-0 sm:border-l border-slate-800 pt-2 sm:pt-0 sm:pl-3">
                <span className="text-[10px] text-slate-400 block">
                  {isBn ? 'ওয়াক্ত সমাপ্তি' : 'Waqt Ends At'}
                </span>
                <span className="text-xs font-mono font-bold text-rose-300">
                  {formatTo12Hour(activeWaqt.endTime, isBn)}
                </span>
              </div>
            </div>

            {/* Elapsed Waqt Progress bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[10px] text-slate-300 font-medium font-mono">
                <span>{isBn ? 'শুরু: ' : 'Start: '}{formatTo12Hour(activeWaqt.startTime, isBn)}</span>
                <span className="text-amber-300 font-mono">
                  {isBn ? `${toBengaliNumerals(activeWaqt.progressPercent)}% অতিবাহিত` : `${activeWaqt.progressPercent}% elapsed`}
                </span>
                <span>{isBn ? 'শেষ: ' : 'End: '}{formatTo12Hour(activeWaqt.endTime, isBn)}</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div
                  className="h-full bg-linear-to-r from-emerald-400 via-teal-400 to-amber-400 rounded-full transition-all duration-500"
                  style={{ width: `${activeWaqt.progressPercent}%` }}
                />
              </div>
            </div>
          </div>
        ) : upcomingWaqt ? (
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between gap-3 font-bangla-display">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">{upcomingWaqt.icon}</span>
              <div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                  {isBn ? `পরবর্তী ওয়াক্ত: ${upcomingWaqt.name}` : `Upcoming: ${upcomingWaqt.name}`}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-mono">
                  {isBn ? 'শুরু সময়: ' : 'Starts: '}{formatTo12Hour(upcomingWaqt.startTime, isBn)}
                </span>
              </div>
            </div>
            <div className="px-2.5 py-1 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 text-xs font-bold font-mono">
              {upcomingWaqt.formattedRemaining}
            </div>
          </div>
        ) : null}

        {/* 6-Prayer Grid with Start & End Time, Red Expired Badge, and Quick Edit Trigger */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-1 font-bangla-display">
          {prayerItems.map((p) => {
            const isDone = Boolean(todayPrayers[p.key]);
            const statusInfo = allStatuses.find((s) => s.key === p.key);
            const isExpired = statusInfo?.isExpired && !isDone && p.key !== 'tahajjud';
            const isActive = statusInfo?.isActive;

            let tileClasses = 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700/60 text-slate-700 dark:text-slate-300 hover:border-violet-300 dark:hover:border-violet-600';
            if (isDone) {
              tileClasses = 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300/80 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 shadow-xs';
            } else if (isExpired) {
              tileClasses = 'bg-rose-50/95 dark:bg-rose-950/50 border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-300 shadow-xs ring-1 ring-rose-500/20';
            } else if (isActive) {
              tileClasses = 'bg-indigo-50/60 dark:bg-indigo-950/40 border-indigo-400 dark:border-indigo-600 ring-2 ring-indigo-500/30 text-indigo-900 dark:text-indigo-200';
            }

            return (
              <div
                key={p.key}
                className={`group flex flex-col items-center justify-center p-2.5 rounded-2xl border transition-all text-center relative ${tileClasses}`}
              >
                {/* Red warning indicator dot if expired and not offered */}
                {isExpired && (
                  <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600"></span>
                  </span>
                )}

                {/* Edit Pencil to customize times */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsCustomizeTimesOpen(true);
                  }}
                  className="absolute top-1 left-1 p-1 rounded-md text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 hover:bg-slate-200/60 dark:hover:bg-slate-700/60 opacity-0 group-hover:opacity-100 transition-opacity"
                  title={isBn ? 'ওয়াক্তের সময় এডিট করুন' : 'Edit Waqt time'}
                >
                  <Edit2 size={11} />
                </button>

                <button
                  type="button"
                  onClick={() => togglePrayer(p.key)}
                  className="w-full flex flex-col items-center justify-center active:scale-95 transition-transform cursor-pointer"
                >
                  <span className="text-xl mb-0.5">{p.icon}</span>
                  <span className="text-xs font-bold leading-tight">{p.label}</span>

                  {/* Exact Waqt Start & End Time Range */}
                  {statusInfo && (
                    <div className="mt-1 text-[9px] font-mono leading-tight text-slate-500 dark:text-slate-400">
                      <div>{formatTo12Hour(statusInfo.startTime, isBn, false)}</div>
                      <div className="text-[8px] text-slate-400 dark:text-slate-400">{isBn ? 'থেকে' : 'to'}</div>
                      <div>{formatTo12Hour(statusInfo.endTime, isBn, false)}</div>
                    </div>
                  )}

                  {/* Status Indicator */}
                  <span
                    className={`text-[10px] mt-1.5 font-bold flex items-center gap-0.5 ${
                      isDone
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : isExpired
                        ? 'text-rose-600 dark:text-rose-400'
                        : isActive
                        ? 'text-indigo-600 dark:text-indigo-400'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {isDone ? (
                      <>
                        <Check size={11} className="stroke-[3]" />
                        <span>{t.prayerRecorded}</span>
                      </>
                    ) : isExpired ? (
                      <>
                        <AlertCircle size={10} />
                        <span>{t.prayerWaqtExpired}</span>
                      </>
                    ) : isActive ? (
                      <span>{isBn ? 'চলছে' : 'Active'}</span>
                    ) : (
                      <span>{isBn ? '+ আদায়' : '+ Log'}</span>
                    )}
                  </span>
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. Today's Tasks Section with Inline Edit Buttons & Filter Tabs */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400">
              <Calendar size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>{t.todaysTasks}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 dark:bg-sky-950/70 text-sky-700 dark:text-sky-300">
                  {isBn ? toBengaliNumerals(todayTasks.length) : todayTasks.length} {isBn ? 'টি' : 'items'}
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isBn ? 'ট্যাপ করে সম্পন্ন করুন বা এডিট আইকন চেপে পরিবর্তন করুন' : 'Tap to complete or tap edit icon to modify'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenTaskModal()}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold shadow-xs transition-colors active:scale-95"
            >
              <Plus size={14} />
              <span>{t.quickAddTask}</span>
            </button>
            <button
              onClick={() => setActiveTab('planner')}
              className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
              aria-label="View Planner"
            >
              <ArrowRight size={18} />
            </button>
          </div>
        </div>

        {/* Task Quick Filters */}
        <div className="flex items-center gap-1.5 pb-2 mb-3 border-b border-slate-100 dark:border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setTaskFilter('all')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
              taskFilter === 'all'
                ? 'bg-violet-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {isBn ? 'সকল কাজ' : 'All'} ({isBn ? toBengaliNumerals(todayTasks.length) : todayTasks.length})
          </button>
          <button
            type="button"
            onClick={() => setTaskFilter('pending')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
              taskFilter === 'pending'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {isBn ? 'বাকি' : 'Pending'} ({isBn ? toBengaliNumerals(todayTasks.filter((t) => !t.completed).length) : todayTasks.filter((t) => !t.completed).length})
          </button>
          <button
            type="button"
            onClick={() => setTaskFilter('completed')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
              taskFilter === 'completed'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {isBn ? 'সম্পন্ন' : 'Completed'} ({isBn ? toBengaliNumerals(todayTasks.filter((t) => t.completed).length) : todayTasks.filter((t) => t.completed).length})
          </button>
        </div>

        {filteredTodayTasks.length === 0 ? (
          <div className="text-center py-7 px-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-200 dark:border-slate-800">
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              {taskFilter === 'pending'
                ? (isBn ? 'আলহামদুলিল্লাহ! আপনার আর কোনো বাকি কাজ নেই।' : 'No pending tasks left today!')
                : t.emptyTasksToday}
            </p>
            {taskFilter === 'all' && (
              <button
                onClick={() => onOpenTaskModal()}
                className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 text-xs font-semibold hover:bg-violet-200 transition-colors"
              >
                <Plus size={14} />
                <span>{t.addTask}</span>
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredTodayTasks.slice(0, 6).map((task) => (
              <div
                key={task.id}
                className={`group flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                  task.completed
                    ? 'bg-slate-50/80 dark:bg-slate-800/30 border-slate-200/60 dark:border-slate-800/60 opacity-80'
                    : 'bg-white dark:bg-slate-850 border-slate-200/80 dark:border-slate-800 hover:border-violet-300 dark:hover:border-violet-700 hover:shadow-xs'
                }`}
              >
                {/* Left: Checkbox & Details */}
                <div
                  onClick={() => toggleTaskCompleted(task.id)}
                  className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                >
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleTaskCompleted(task.id);
                    }}
                    className={`shrink-0 transition-colors ${
                      task.completed
                        ? 'text-emerald-500 dark:text-emerald-400'
                        : 'text-slate-400 group-hover:text-violet-500'
                    }`}
                  >
                    {task.completed ? <CheckCircle2 size={22} className="fill-emerald-100 dark:fill-emerald-950" /> : <Circle size={22} />}
                  </button>

                  <div className="min-w-0 flex-1">
                    <p
                      className={`text-sm font-semibold truncate ${
                        task.completed
                          ? 'line-through text-slate-400 dark:text-slate-500'
                          : 'text-slate-800 dark:text-slate-100'
                      }`}
                    >
                      {task.title}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 flex-wrap">
                      {task.dueTime && (
                        <span className="flex items-center gap-1 font-mono text-violet-600 dark:text-violet-400 font-bold">
                          <Clock size={11} />
                          {isBn ? toBengaliNumerals(task.dueTime) : task.dueTime}
                        </span>
                      )}
                      <span className="capitalize px-1.5 py-0.2 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-medium">
                        {task.category}
                      </span>
                      {task.alarmEnabled && (
                        <span className="text-amber-500 dark:text-amber-400 flex items-center gap-0.5 text-[10px] font-bold">
                          <Bell size={11} />
                          <span>{task.alarmMinutesBefore ? `${task.alarmMinutesBefore}m` : 'On'}</span>
                        </span>
                      )}
                      {task.isRoutine && (
                        <span className="text-indigo-500 dark:text-indigo-400 font-semibold text-[10px]">
                          • Routine
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right: Priority & Dedicated Edit Trigger */}
                <div className="flex items-center gap-2 shrink-0 ml-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      task.priority === 'high'
                        ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                        : task.priority === 'medium'
                        ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {task.priority === 'high' ? 'High' : task.priority === 'medium' ? 'Med' : 'Low'}
                  </span>

                  {/* Direct Edit Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenTaskModal(task);
                    }}
                    className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-violet-600 dark:hover:text-violet-400 hover:border-violet-300 transition-all active:scale-95"
                    title={isBn ? 'কাজটি এডিট করুন' : 'Edit Task'}
                    aria-label="Edit Task"
                  >
                    <Edit2 size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 4. Habit Completion Summary with Direct Edit & Decrement/Increment Controls */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <Flame size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>{t.habitSummary}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300">
                  {isBn ? toBengaliNumerals(todayMetrics.habitsDone) : todayMetrics.habitsDone}/{isBn ? toBengaliNumerals(habits.length) : habits.length}
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isBn ? '+ / - বাটন দিয়ে পরিমাণ ঠিক করুন এবং পেন আইকন চেপে এডিট করুন' : 'Use +/- to adjust count and tap edit to customize'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenHabitModal()}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold shadow-xs transition-colors active:scale-95"
            >
              <Plus size={14} />
              <span>{t.addHabit}</span>
            </button>
            <button
              onClick={() => setActiveTab('habits')}
              className="text-xs font-semibold text-violet-600 dark:text-violet-400 hover:text-violet-700 flex items-center gap-1 transition-colors"
            >
              <ArrowRight size={16} />
            </button>
          </div>
        </div>

        {habits.length === 0 ? (
          <div className="text-center py-6 px-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-200 dark:border-slate-800">
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              {t.emptyHabitsToday}
            </p>
            <button
              onClick={() => onOpenHabitModal()}
              className="mt-3 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700 transition-colors"
            >
              <Plus size={14} />
              <span>{t.addHabit}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {habits.slice(0, 4).map((habit) => {
              const count = habit.history[todayStr] || 0;
              const isTargetMet = count >= habit.targetCount;
              const percent = Math.min(100, Math.round((count / habit.targetCount) * 100));

              return (
                <div
                  key={habit.id}
                  className={`p-4 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                    isTargetMet
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200/80 dark:border-emerald-800/50 shadow-xs'
                      : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-700/60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: habit.color }} />
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {habit.title}
                        </h4>
                      </div>
                      <div className="flex items-center gap-2.5 mt-1 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                          {isBn ? toBengaliNumerals(count) : count} / {isBn ? toBengaliNumerals(habit.targetCount) : habit.targetCount} {habit.unit}
                        </span>
                        <span className="flex items-center gap-0.5 text-amber-500 font-bold bg-amber-500/10 px-1.5 py-0.2 rounded-md">
                          <Flame size={12} className="fill-amber-500" />
                          <span>{isBn ? toBengaliNumerals(habit.currentStreak) : habit.currentStreak}d</span>
                        </span>
                        {isTargetMet && (
                          <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/15 px-1.5 py-0.2 rounded-md">
                            ✓ {isBn ? 'পূরণ' : 'Done'}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Direct Edit Trigger */}
                    <button
                      type="button"
                      onClick={() => onOpenHabitModal(habit)}
                      className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-500 hover:text-violet-600 dark:hover:text-violet-400 transition-colors active:scale-95 shadow-2xs"
                      title={isBn ? 'অভ্যাস এডিট করুন' : 'Edit Habit'}
                    >
                      <Edit2 size={13} />
                    </button>
                  </div>

                  {/* Micro Progress Bar */}
                  <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${percent}%`,
                        backgroundColor: habit.color || '#10b981',
                      }}
                    />
                  </div>

                  {/* Actions: Decrement & Increment directly from Home */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-400 font-medium">
                      {isBn ? `${toBengaliNumerals(percent)}% সম্পন্ন` : `${percent}% completed`}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {count > 0 && (
                        <button
                          type="button"
                          onClick={() => decrementHabitCount(habit.id)}
                          className="w-8 h-8 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs hover:border-rose-400 hover:text-rose-600 transition-all active:scale-90"
                          title="-1 Decrement"
                        >
                          <Minus size={13} />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => incrementHabitCount(habit.id)}
                        className={`h-8 px-3 rounded-xl flex items-center justify-center font-bold text-xs gap-1 transition-all active:scale-95 ${
                          isTargetMet
                            ? 'bg-emerald-500 text-white shadow-xs'
                            : 'bg-violet-600 hover:bg-violet-700 text-white shadow-xs'
                        }`}
                        title={isTargetMet ? t.completed : `+1 ${habit.unit}`}
                      >
                        {isTargetMet ? <Check size={14} className="stroke-[3]" /> : <Plus size={14} />}
                        <span>+1</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 5. Daily Routine Overview with Direct Edit Button */}
      {routineTasks.length > 0 && (
        <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
              <span>{t.routineOverview}</span>
            </h3>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-bold">
              {isBn ? toBengaliNumerals(routineTasks.filter((r) => r.completed).length) : routineTasks.filter((r) => r.completed).length} / {isBn ? toBengaliNumerals(routineTasks.length) : routineTasks.length} {t.completed}
            </span>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
            {routineTasks.map((routine) => (
              <div
                key={routine.id}
                className={`group shrink-0 flex items-center gap-2 pl-3 pr-2 py-2 rounded-xl border text-xs font-medium transition-all ${
                  routine.completed
                    ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggleTaskCompleted(routine.id)}
                  className="flex items-center gap-1.5 focus:outline-hidden"
                >
                  {routine.completed ? <CheckCircle2 size={15} /> : <Circle size={15} />}
                  <span className="truncate max-w-[140px] font-semibold">{routine.title}</span>
                </button>
                {/* Direct Edit Icon */}
                <button
                  type="button"
                  onClick={() => onOpenTaskModal(routine)}
                  className="p-1 rounded-md text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors ml-1"
                  title={isBn ? 'রুটিন এডিট করুন' : 'Edit Routine'}
                >
                  <Edit2 size={11} />
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Active Goals Highlights with Direct Edit Button & Milestone Tracker */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-5 shadow-xs transition-colors">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400">
              <Target size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {t.goalHighlights}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isBn ? toBengaliNumerals(activeGoals.length) : activeGoals.length} {language === 'bn' ? 'টি সক্রিয় লক্ষ্য' : 'active targets'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenGoalModal()}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold shadow-xs transition-colors active:scale-95"
            >
              <Plus size={14} />
              <span>{t.addGoal}</span>
            </button>
            <button
              onClick={() => setActiveTab('habits')}
              className="text-xs font-semibold text-violet-600 dark:text-violet-400 hover:text-violet-700 flex items-center gap-1 transition-colors"
            >
              <ArrowRight size={16} />
            </button>
          </div>
        </div>

        {activeGoals.length === 0 ? (
          <div className="text-center py-6 px-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-200 dark:border-slate-800">
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              {t.emptyGoals}
            </p>
            <button
              onClick={() => onOpenGoalModal()}
              className="mt-3 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700 transition-colors"
            >
              <Plus size={14} />
              <span>{t.addGoal}</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {activeGoals.map((goal) => {
              const isExpanded = expandedGoalId === goal.id;
              const daysLeftStr = getDaysRemaining(goal.targetDate, isBn);

              return (
                <div
                  key={goal.id}
                  className="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700/60 transition-all space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: goal.color || '#8b5cf6' }} />
                        <h4 className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                          {goal.title}
                        </h4>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500 dark:text-slate-400 flex-wrap">
                        <span className="font-mono font-bold text-violet-600 dark:text-violet-400">
                          {isBn ? toBengaliNumerals(goal.progress) : goal.progress}%
                        </span>
                        <span>•</span>
                        <span className="font-medium text-amber-600 dark:text-amber-400">
                          {daysLeftStr}
                        </span>
                        <span>•</span>
                        <span>
                          {isBn ? toBengaliNumerals(goal.milestones.filter((m) => m.completed).length) : goal.milestones.filter((m) => m.completed).length}/{isBn ? toBengaliNumerals(goal.milestones.length) : goal.milestones.length} মাইলস্টোন
                        </span>
                      </div>
                    </div>

                    {/* Direct Edit Trigger */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => onOpenGoalModal(goal)}
                        className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-violet-600 dark:hover:text-violet-400 transition-colors active:scale-95 shadow-2xs"
                        title={isBn ? 'লক্ষ্য এডিট করুন' : 'Edit Goal'}
                      >
                        <Edit2 size={13} />
                      </button>
                      {goal.milestones.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setExpandedGoalId(isExpanded ? null : goal.id)}
                          className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                          title="মাইলস্টোন তালিকা"
                        >
                          {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${goal.progress}%`,
                        backgroundColor: goal.color || '#8b5cf6',
                      }}
                    />
                  </div>

                  {/* Expandable Milestone Check-off directly on Home */}
                  {isExpanded && goal.milestones.length > 0 && (
                    <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 space-y-1.5 animate-in fade-in">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                        {isBn ? 'মাইলস্টোন চেক করুন:' : 'Check milestones:'}
                      </span>
                      {goal.milestones.map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => toggleGoalMilestone(goal.id, m.id)}
                          className={`w-full flex items-center gap-2 p-2 rounded-xl text-xs text-left transition-colors ${
                            m.completed
                              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-semibold line-through'
                              : 'bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {m.completed ? <CheckCircle2 size={14} className="text-emerald-500 shrink-0" /> : <Circle size={14} className="text-slate-400 shrink-0" />}
                          <span className="truncate">{m.title}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 7. Weekly Progress Summary Chart */}
      <WeeklyProgressChart />

      {/* Customize Prayer Waqt Times Modal */}
      <CustomizePrayerTimesModal
        isOpen={isCustomizeTimesOpen}
        onClose={() => setIsCustomizeTimesOpen(false)}
      />

      {/* Offline Alarm Assurance Modal */}
      {isOfflineInfoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="relative w-full max-w-sm rounded-3xl bg-linear-to-b from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/40 p-6 shadow-2xl text-white space-y-4 animate-in zoom-in-95 font-bangla-display"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setIsOfflineInfoModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white bg-slate-800/80 transition-colors"
              aria-label="Close"
            >
              <X size={16} />
            </button>

            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
                <WifiOff size={22} />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">
                  {isBn ? 'ডাটা ছাড়াই কি অ্যালার্ম বাজবে?' : 'Does alarm ring offline?'}
                </h3>
                <span className="text-xs text-emerald-300 font-bold block mt-0.5">
                  {isBn ? '✓ হ্যাঁ, ১০০% নিশ্চিতভাবে বাজবে' : '✓ Yes, 100% Guaranteed'}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-xs text-slate-300 space-y-2.5 leading-relaxed">
              <p>
                <strong className="text-white block font-bold mb-0.5">১. কোনো ইন্টারনেট বা ডাটা প্যাক লাগে না:</strong>
                অ্যালার্মের সাইরেন সাউন্ড কোনো অনলাইন সার্ভার থেকে বাজে না; এটি আপনার মোবাইলের মেমোরিতে সরাসরি সিন্থেসাইজারে উৎপন্ন হয়। ফলে ডাটা অফ থাকলেও সাউন্ড যথাসময়ে বাজে।
              </p>
              <p>
                <strong className="text-white block font-bold mb-0.5">২. ফোন লক বা ফ্লাইট মোডেও কার্যকর:</strong>
                হাবিবির ব্যাকগ্রাউন্ড টাইমার এবং সাউন্ড সিস্টেম সরাসরি আপনার ফোনের স্পিকার ও ভাইব্রেশন ইঞ্জিন দিয়ে পরিচালিত হয়।
              </p>
              <p>
                <strong className="text-white block font-bold mb-0.5">৩. সম্পূর্ণ নিরাপদ ও নির্ভরযোগ্য:</strong>
                আপনার কাজের সময় ও অ্যালার্মের তথ্য ডিভাইসেই সংরক্ষিত থাকে।
              </p>
            </div>

            {onTestLockScreenAlarm && (
              <button
                type="button"
                onClick={() => {
                  setIsOfflineInfoModalOpen(false);
                  onTestLockScreenAlarm();
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/30 active:scale-95 transition-all"
              >
                <Lock size={14} />
                <span>{isBn ? 'এখনই ৫ সেকেন্ডের অফলাইন টেস্ট চালান' : 'Run 5s Offline Test Now'}</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Alarm Ringtone Customization Modal */}
      <AlarmToneSelectorModal
        isOpen={isRingtoneModalOpen}
        onClose={() => setIsRingtoneModalOpen(false)}
      />

      {/* Android & Redmi Smart Alarm Settings Modal */}
      <AndroidAlarmSettingsModal
        isOpen={isAndroidAlarmModalOpen}
        onClose={() => setIsAndroidAlarmModalOpen(false)}
        onTestScreenOffAlarm={onTestLockScreenAlarm || (() => {})}
      />
    </div>
  );
};
