import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  Calendar as CalendarIcon,
  Ticket as TicketIcon,
  Send,
  ChevronLeft,
  ChevronRight,
  Download,
  Printer,
  Trash2,
  AlertTriangle,
  Clock,
  Sparkles,
  MapPin,
  Check,
  RotateCcw,
} from 'lucide-react';
import { PurchasedTicket } from '../types';
import { VirtualTicketPass } from './VirtualTicketPass';
import { downloadTicketPass } from '../utils/downloadTicket';
import { SearchBar } from './ui/SearchBar';
import { EmptyState } from './ui/EmptyState';
import { triggerHaptic } from '../utils/haptics';

export const MyTicketsPage: React.FC = () => {
  const {
    user,
    tickets,
    deleteTicket,
    setCurrentPage,
    transferTicket,
    showToast,
    formatKsh,
    activeVirtualTicket,
    setActiveVirtualTicket,
    closeVirtualTicket,
  } = useApp();

  const [mainView, setMainView] = useState<'passes' | 'calendar'>('passes');
  const [activeTab, setActiveTab] = useState<'active' | 'past' | 'refunded'>('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [ticketToTransfer, setTicketToTransfer] = useState<PurchasedTicket | null>(null);
  const [ticketToDelete, setTicketToDelete] = useState<PurchasedTicket | null>(null);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [isTransferring, setIsTransferring] = useState(false);

  // In-app calendar state (Default to Nov 2026 where primary events occur)
  const [currentMonth, setCurrentMonth] = useState<number>(10); // 10 = November (0-indexed)
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<number | null>(14);

  // Passholder filtering: Show tickets that belong to the current user/holder account
  const userTickets = useMemo(() => {
    if (!user) return tickets;
    return tickets.filter(
      (t) =>
        t.userId === user.id ||
        (user.email && t.holderEmail?.toLowerCase() === user.email.toLowerCase()) ||
        (user.phone && t.holderPhone === user.phone) ||
        (user.e164Phone && t.holderPhone === user.e164Phone) ||
        (user.mpesaNumber && t.holderPhone === user.mpesaNumber) ||
        !t.userId
    );
  }, [tickets, user]);

  const activeTickets = userTickets.filter((t) => t.status === 'active');
  const pastTickets = userTickets.filter((t) => t.status === 'used' || t.status === 'transferred');
  const refundedTickets = userTickets.filter((t) => t.status === 'refunded');

  // Filtered tickets based on search
  const displayedTickets = useMemo(() => {
    const list =
      activeTab === 'active'
        ? activeTickets
        : activeTab === 'past'
        ? pastTickets
        : refundedTickets;
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase().trim();
    return list.filter(
      (t) =>
        t.eventTitle.toLowerCase().includes(q) ||
        t.venue.toLowerCase().includes(q) ||
        t.city.toLowerCase().includes(q) ||
        t.ticketCode.toLowerCase().includes(q) ||
        t.orderNumber.toLowerCase().includes(q)
    );
  }, [activeTab, activeTickets, pastTickets, refundedTickets, searchQuery]);

  // Calendar helpers
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayIndex = new Date(currentYear, currentMonth, 1).getDay();

  // Match active tickets to dates
  const selectedDateEvents = activeTickets.filter((ticket) => {
    if (selectedCalendarDate === null) return false;
    const d = new Date(ticket.isoDate);
    return (
      d.getDate() === selectedCalendarDate &&
      d.getMonth() === currentMonth &&
      d.getFullYear() === currentYear
    );
  });

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
    setSelectedCalendarDate(null);
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
    setSelectedCalendarDate(null);
  };

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketToTransfer) return;
    setIsTransferring(true);

    setTimeout(() => {
      const ok = transferTicket(ticketToTransfer.ticketId, recipientEmail);
      setIsTransferring(false);
      if (ok) {
        setTicketToTransfer(null);
        setRecipientEmail('');
      }
    }, 600);
  };

  const handleConfirmDelete = () => {
    if (ticketToDelete) {
      deleteTicket(ticketToDelete.ticketId);
      setTicketToDelete(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#090a0d] text-[#f4f4f6] pt-24 pb-28 transition-colors">
      <div className="max-w-5xl mx-auto px-5 sm:px-8 space-y-6">
        {/* Header with Title and View Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-200/80 dark:border-neutral-800">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">
              Digital Passbook
            </span>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-neutral-900 dark:text-white mt-0.5">
              My Passes & Tickets
            </h1>
          </div>

          {/* Primary View Switcher: Digital Passes vs In-App Calendar */}
          <div className="inline-flex items-center p-1 bg-neutral-100 dark:bg-neutral-850 rounded-full border border-neutral-200/60 dark:border-neutral-800">
            <button
              onClick={() => setMainView('passes')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
                mainView === 'passes'
                  ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs font-bold'
                  : 'text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <TicketIcon className="w-3.5 h-3.5" />
              <span>Passes ({activeTickets.length})</span>
            </button>

            <button
              onClick={() => setMainView('calendar')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-full transition-all cursor-pointer flex items-center gap-1.5 ${
                mainView === 'calendar'
                  ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs font-bold'
                  : 'text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              <CalendarIcon className="w-3.5 h-3.5 text-emerald-500" />
              <span>App Calendar</span>
            </button>
          </div>
        </div>

        {/* ======================================================== */}
        {/* VIEW 1: PASSES LIST                                      */}
        {/* ======================================================== */}
        {mainView === 'passes' && (
          <div className="space-y-6">
            {/* Search Bar & Active/Past Switcher */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="w-full sm:w-72">
                <SearchBar
                  value={searchQuery}
                  onChange={setSearchQuery}
                  placeholder="Filter by event or pass code..."
                  resultCount={displayedTickets.length}
                />
              </div>

              <div className="inline-flex items-center p-1 bg-[#16181f] border border-[#232733] rounded-full text-xs">
                <button
                  onClick={() => {
                    triggerHaptic('selection');
                    setActiveTab('active');
                  }}
                  className={`px-3.5 py-1.5 rounded-full font-semibold transition-colors cursor-pointer ${
                    activeTab === 'active'
                      ? 'bg-emerald-500 text-white shadow-xs font-bold'
                      : 'text-[#9496a1] hover:text-white'
                  }`}
                >
                  Active Passes ({activeTickets.length})
                </button>
                <button
                  onClick={() => {
                    triggerHaptic('selection');
                    setActiveTab('past');
                  }}
                  className={`px-3.5 py-1.5 rounded-full font-semibold transition-colors cursor-pointer ${
                    activeTab === 'past'
                      ? 'bg-[#252834] text-white shadow-xs font-bold border border-[#353a4b]'
                      : 'text-[#9496a1] hover:text-white'
                  }`}
                >
                  Past ({pastTickets.length})
                </button>
                <button
                  onClick={() => {
                    triggerHaptic('selection');
                    setActiveTab('refunded');
                  }}
                  className={`px-3.5 py-1.5 rounded-full font-semibold transition-colors cursor-pointer ${
                    activeTab === 'refunded'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 shadow-xs font-bold'
                      : 'text-[#9496a1] hover:text-white'
                  }`}
                >
                  Refunded & Returned ({refundedTickets.length})
                </button>
              </div>
            </div>

            {/* Passes Grid */}
            {displayedTickets.length === 0 ? (
              <EmptyState
                icon={<TicketIcon className="w-6 h-6" />}
                title={
                  searchQuery
                    ? 'No matching tickets'
                    : activeTab === 'refunded'
                    ? 'No Refunded Passes'
                    : 'No passes in this category'
                }
                description={
                  searchQuery
                    ? `No passes found matching "${searchQuery}".`
                    : activeTab === 'refunded'
                    ? 'When an event organizer cancels an event, your passes will automatically reflect their returned funds and refund receipt here.'
                    : 'Browse upcoming concerts, festivals, and live experiences to book your verified entry passes.'
                }
                actionText={searchQuery ? 'Clear Filter' : 'Explore Events'}
                onAction={() => {
                  if (searchQuery) setSearchQuery('');
                  else setCurrentPage('events');
                }}
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {displayedTickets.map((ticket) => {
                  const isRefunded = ticket.status === 'refunded';
                  const isAdmitted = ticket.status === 'used';

                  return (
                    <div
                      key={ticket.ticketId}
                      className={`p-5 rounded-3xl bg-[#111317] border transition-all flex flex-col justify-between space-y-4 shadow-sm ${
                        isRefunded
                          ? 'border-rose-500/30 bg-[#140f12]'
                          : 'border-[#1f2229] hover:border-emerald-500/40'
                      }`}
                    >
                      {/* Event Banner & Details */}
                      <div className="flex items-start gap-4">
                        <img
                          src={ticket.eventImage}
                          alt={ticket.eventTitle}
                          className="w-16 h-16 rounded-2xl object-cover shrink-0 border border-[#1f2229]"
                        />

                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <span
                              className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md ${
                                isRefunded
                                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                  : isAdmitted
                                  ? 'bg-[#17191f] text-[#646875] border border-[#1f2229]'
                                  : ticket.status === 'transferred'
                                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              }`}
                            >
                              {isRefunded
                                ? 'Refunded & Returned'
                                : isAdmitted
                                ? 'Admitted'
                                : ticket.status === 'transferred'
                                ? 'Transferred'
                                : 'Valid Pass'}
                            </span>

                            <span className="text-[11px] font-mono font-bold text-[#9496a1]">
                              {formatKsh(ticket.totalPaid)}
                            </span>
                          </div>

                          <h3 className="text-sm font-bold text-[#f4f4f6] truncate">
                            {ticket.eventTitle}
                          </h3>

                          <p className="text-xs text-[#9496a1] truncate flex items-center gap-1">
                            <MapPin className="w-3 h-3 shrink-0 text-emerald-500" />
                            <span>{ticket.venue} · {ticket.city}</span>
                          </p>
                        </div>
                      </div>

                      {/* Refund Notice Banner if Refunded */}
                      {isRefunded && (
                        <div className="p-3 bg-rose-500/10 border border-rose-500/25 rounded-2xl text-xs space-y-1">
                          <div className="flex items-center justify-between text-rose-400 font-bold">
                            <span className="flex items-center gap-1.5">
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>100% Refund Processed</span>
                            </span>
                            <span>{formatKsh(ticket.refundAmount || ticket.totalPaid)} Returned</span>
                          </div>
                          <p className="text-[11px] text-[#b8b9c2] leading-relaxed">
                            Event canceled by host. Money returned to your original payment method. Ref: <strong className="text-white font-mono">{ticket.refundRef || 'RFD-AUTOPAY'}</strong>
                          </p>
                        </div>
                      )}

                      {/* Logistics & Distinct Code */}
                      <div className="p-3 rounded-2xl bg-[#17191f] border border-[#1f2229] flex items-center justify-between text-xs">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-[#646875] block">
                            Schedule
                          </span>
                          <span className="font-semibold text-[#f4f4f6]">
                            {ticket.date.split(',')[1] || ticket.date} · {ticket.time}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] uppercase font-bold text-[#646875] block">
                            Distinct Code
                          </span>
                          <span className="font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                            {ticket.ticketCode}
                          </span>
                        </div>
                      </div>

                      {/* 1-Click Action Buttons: View, Download (No Print or Share) */}
                      <div className="pt-2 border-t border-[#1f2229] flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => setActiveVirtualTicket(ticket)}
                            className="py-1.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold active:scale-95 transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>View Pass</span>
                          </button>

                          {!isRefunded && (
                            <button
                              onClick={() => {
                                downloadTicketPass(ticket);
                                showToast(`Downloaded pass: ${ticket.ticketCode}.png`);
                              }}
                              className="py-1.5 px-2.5 rounded-xl border border-[#1f2229] bg-[#17191f] hover:bg-[#1f2229] text-xs font-medium text-[#9496a1] hover:text-[#f4f4f6] transition-colors cursor-pointer"
                              title="Download Pass PNG"
                            >
                              <Download className="w-3.5 h-3.5 text-emerald-400" />
                            </button>
                          )}
                        </div>

                        <div className="flex items-center gap-1">
                          {!isRefunded && !isAdmitted && (
                            <button
                              onClick={() => setTicketToTransfer(ticket)}
                              className="py-1.5 px-2.5 rounded-xl border border-[#1f2229] bg-[#17191f] hover:bg-[#1f2229] text-xs font-medium text-[#9496a1] hover:text-[#f4f4f6] transition-colors cursor-pointer"
                              title="Transfer Ticket"
                            >
                              <Send className="w-3 h-3" />
                            </button>
                          )}

                          <button
                            onClick={() => setTicketToDelete(ticket)}
                            className="p-1.5 rounded-xl border border-red-500/25 bg-red-500/5 hover:bg-red-500/15 text-red-400 transition-colors cursor-pointer"
                            title="Remove Pass from Wallet"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* VIEW 2: IN-APP CALENDAR                                  */}
        {/* ======================================================== */}
        {mainView === 'calendar' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Calendar Grid */}
            <div className="lg:col-span-7 p-6 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 shadow-2xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
                <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                  {monthNames[currentMonth]} {currentYear}
                </h3>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handlePrevMonth}
                    className="p-1.5 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-600 dark:text-neutral-400 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleNextMonth}
                    className="p-1.5 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-600 dark:text-neutral-400 cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Day of Week Headers */}
              <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold uppercase text-neutral-400">
                {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
                  <div key={d} className="py-1">
                    {d}
                  </div>
                ))}
              </div>

              {/* Dates Grid */}
              <div className="grid grid-cols-7 gap-1.5">
                {Array.from({ length: firstDayIndex }).map((_, i) => (
                  <div key={`empty-${i}`} className="h-10" />
                ))}

                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const dayNum = i + 1;
                  const hasPass = activeTickets.some((t) => {
                    const d = new Date(t.isoDate);
                    return (
                      d.getDate() === dayNum &&
                      d.getMonth() === currentMonth &&
                      d.getFullYear() === currentYear
                    );
                  });
                  const isSelected = selectedCalendarDate === dayNum;

                  return (
                    <button
                      key={dayNum}
                      onClick={() => setSelectedCalendarDate(dayNum)}
                      className={`h-10 rounded-2xl text-xs font-semibold flex flex-col items-center justify-center relative transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold shadow-sm'
                          : hasPass
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold ring-1 ring-emerald-500/40'
                          : 'hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                      }`}
                    >
                      <span>{dayNum}</span>
                      {hasPass && (
                        <span
                          className={`w-1 h-1 rounded-full ${
                            isSelected ? 'bg-emerald-400' : 'bg-emerald-500'
                          }`}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Date Pass Details */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 shadow-2xs space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white pb-3 border-b border-neutral-100 dark:border-neutral-800">
                Bookings for {monthNames[currentMonth]} {selectedCalendarDate}, {currentYear}
              </h3>

              {selectedDateEvents.length === 0 ? (
                <div className="py-12 text-center text-xs text-neutral-400 dark:text-neutral-500 space-y-2">
                  <CalendarIcon className="w-8 h-8 mx-auto opacity-30" />
                  <p>No active event passes booked on this date.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {selectedDateEvents.map((t) => (
                    <div
                      key={t.ticketId}
                      className="p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-850/70 border border-neutral-200/60 dark:border-neutral-800 space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="text-xs font-bold text-neutral-900 dark:text-white">
                            {t.eventTitle}
                          </h4>
                          <span className="text-[11px] text-neutral-500">
                            {t.venue} · {t.time}
                          </span>
                        </div>
                        <span className="font-mono text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/70 px-2 py-0.5 rounded">
                          {t.ticketCode}
                        </span>
                      </div>

                      <button
                        onClick={() => setActiveVirtualTicket(t)}
                        className="w-full py-2 rounded-xl bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 text-xs font-bold hover:opacity-90 transition-opacity flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>View Admission Pass</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Virtual Ticket Modal */}
      {activeVirtualTicket && (
        <VirtualTicketPass
          ticket={activeVirtualTicket}
          onClose={closeVirtualTicket}
        />
      )}

      {/* Transfer Pass Modal */}
      {ticketToTransfer && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setTicketToTransfer(null)}
        >
          <div
            className="w-full max-w-sm bg-white dark:bg-neutral-900 rounded-3xl p-6 shadow-2xl border border-neutral-200 dark:border-neutral-800 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                Transfer Pass
              </h3>
              <button
                onClick={() => setTicketToTransfer(null)}
                className="text-xs text-neutral-400 hover:text-neutral-700 cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleTransferSubmit} className="space-y-3">
              <p className="text-xs text-neutral-500 leading-relaxed">
                Enter the recipient's email address to transfer pass{' '}
                <strong className="text-neutral-900 dark:text-white">{ticketToTransfer.ticketCode}</strong>.
              </p>
              <input
                type="email"
                required
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="friend@example.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-850 text-xs font-medium text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
              <button
                type="submit"
                disabled={isTransferring}
                className="w-full py-2.5 rounded-full bg-neutral-900 dark:bg-white text-white dark:text-neutral-950 text-xs font-bold hover:opacity-90 transition-opacity cursor-pointer shadow-sm disabled:opacity-50"
              >
                {isTransferring ? 'Transferring...' : 'Send Ticket Pass'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Delete Ticket Confirmation */}
      {ticketToDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setTicketToDelete(null)}
        >
          <div
            className="w-full max-w-sm bg-white dark:bg-neutral-900 rounded-3xl p-6 shadow-2xl border border-neutral-200 dark:border-neutral-800 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6 stroke-[2]" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                Delete Ticket Pass?
              </h3>
              <p className="text-xs text-neutral-500">
                Are you sure you want to remove pass <strong className="font-mono text-blue-600">{ticketToDelete.ticketCode}</strong> from your passbook?
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={handleConfirmDelete}
                className="py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer transition-colors"
              >
                Delete Pass
              </button>
              <button
                onClick={() => setTicketToDelete(null)}
                className="py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 text-xs font-medium cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
