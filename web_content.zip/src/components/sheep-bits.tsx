import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import {
  ageLabel,
  compareSheep,
  formatKg,
  isLamb,
  isPregnant,
  sexLabel,
  statusLabel,
} from "@/lib/flock/logic";
import type { BreedingRecord, Sheep } from "@/lib/flock/types";

export function SheepBadges({
  sheep,
  breeding,
}: {
  sheep: Sheep;
  breeding: BreedingRecord[];
}) {
  const young = isLamb(sheep);
  const pregnant = sheep.sex === "ewe" && isPregnant(sheep.id, breeding);
  return (
    <div className="flex flex-wrap justify-end gap-1">
      {sheep.status === "sick" ? <Badge variant="danger">مريض</Badge> : null}
      {pregnant ? <Badge variant="warn">حامل</Badge> : null}
      {young ? <Badge>صغير</Badge> : null}
      {sheep.status === "sold" ? <Badge>مبيع</Badge> : null}
      {sheep.status === "dead" ? <Badge>نافق</Badge> : null}
      {sheep.status === "active" && !pregnant && !young ? (
        <Badge variant="ok">{statusLabel(sheep.status)}</Badge>
      ) : null}
    </div>
  );
}

export function SheepCard({
  sheep,
  breeding,
}: {
  sheep: Sheep;
  breeding: BreedingRecord[];
}) {
  const young = isLamb(sheep);
  const meta = [sexLabel(sheep.sex, young), sheep.name, sheep.breed, sheep.pen]
    .filter(Boolean)
    .join(" · ");
  return (
    <Link
      to="/sheep/$id"
      params={{ id: sheep.id }}
      className="block rounded-3xl border border-border bg-card p-4"
    >
      <div className="flex items-start justify-between gap-3">
        <p className="text-xl font-semibold break-all tabular-nums tracking-tight">
          {sheep.tag}
        </p>
        <SheepBadges sheep={sheep} breeding={breeding} />
      </div>
      <p className="mt-2 text-sm text-muted-foreground">{meta}</p>
      <p className="mt-1 text-sm">
        {ageLabel(sheep.birthDate)}
        <span className="text-muted-foreground"> · </span>
        <span className="tabular-nums">{formatKg(sheep.weightKg)}</span>
      </p>
    </Link>
  );
}

export function sortSheep(list: Sheep[]) {
  return list.slice().sort(compareSheep);
}
