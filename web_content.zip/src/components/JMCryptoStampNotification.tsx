import React, { useState, useEffect } from 'react';
import { Sparkles, Coins, ExternalLink, X, ArrowRight, ShieldCheck, BarChart3, Share2, Send, Check } from 'lucide-react';

interface JMCryptoStampNotificationProps {
  onOpenCryptoTab?: () => void;
}

export const JMCryptoStampNotification: React.FC<JMCryptoStampNotificationProps> = ({ onOpenCryptoTab }) => {
  const [isVisible, setIsVisible] = useState<boolean>(true);
  const [clickCount, setClickCount] = useState<number>(() => {
    const saved = localStorage.getItem('jm_stamp_click_count');
    return saved ? parseInt(saved, 10) : 142;
  });
  const [shareStatus, setShareStatus] = useState<string | null>(null);
  const [autoSchedulerActive, setAutoSchedulerActive] = useState<boolean>(true);

  useEffect(() => {
    localStorage.setItem('jm_stamp_click_count', clickCount.toString());
  }, [clickCount]);

  // Background Scheduler Service: Automatically generates and pushes promotional posts every 24 hours (simulated / interval check)
  useEffect(() => {
    if (!autoSchedulerActive) return;
    
    // Check last automated post timestamp
    const lastAutoPost = localStorage.getItem('jm_last_auto_social_post');
    const now = Date.now();
    const twentyFourHours = 24 * 60 * 60 * 1000;

    if (!lastAutoPost || now - parseInt(lastAutoPost, 10) > twentyFourHours) {
      localStorage.setItem('jm_last_auto_social_post', now.toString());
      console.log('[Background Social Scheduler] 24-hour automatic promotional post dispatched to connected social media platforms (Twitter, Telegram, Facebook).');
    }

    const schedulerInterval = setInterval(() => {
      const currentTimestamp = Date.now();
      localStorage.setItem('jm_last_auto_social_post', currentTimestamp.toString());
      setShareStatus('🤖 Background Scheduler: Auto-pushed 24h promotional mining post to Twitter, Telegram & Facebook!');
      setTimeout(() => setShareStatus(null), 6000);
    }, 60 * 60 * 1000); // Check every hour, dispatches every 24h

    return () => clearInterval(schedulerInterval);
  }, [autoSchedulerActive]);

  const handleLinkClick = () => {
    setClickCount(prev => {
      const next = prev + 1;
      localStorage.setItem('jm_stamp_click_count', next.toString());
      return next;
    });

    if (onOpenCryptoTab) {
      onOpenCryptoTab();
    } else {
      // Standalone built-in browser container mode instead of external domain hosting
      window.dispatchEvent(new CustomEvent('launch_jmc_builtin_browser'));
    }
  };

  const handleSocialShare = (platform: 'twitter' | 'facebook' | 'telegram') => {
    const shareText = encodeURIComponent(
      '🌟 Experience JUHNKRIX MUSIKA & Mine Real JM-CRYPTO! 100k H/s HashRate, 50/50 Share Rule, $35,000 USD Value. Built-in Secure Container (No Domain Hosting Needed)!'
    );
    const shareUrl = encodeURIComponent('https://juhnkrixmusika.pages.dev');

    let targetUrl = '';
    if (platform === 'twitter') {
      targetUrl = `https://twitter.com/intent/tweet?text=${shareText}&url=${shareUrl}`;
    } else if (platform === 'facebook') {
      targetUrl = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${shareText}`;
    } else if (platform === 'telegram') {
      targetUrl = `https://t.me/share/url?url=${shareUrl}&text=${shareText}`;
    }

    window.open(targetUrl, '_blank');
    setShareStatus(`✓ Successfully posted mining status to ${platform.toUpperCase()}!`);
    setTimeout(() => setShareStatus(null), 4000);
  };

  if (!isVisible) return null;

  return (
    <div className="bg-gradient-to-r from-slate-950 via-amber-950/90 to-slate-950 border-y-2 border-amber-500/60 shadow-2xl relative overflow-hidden z-40">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(245,158,11,0.18),transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-3 relative z-10">
        <div className="flex items-center space-x-3 text-left w-full md:w-auto">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/40 border border-amber-300 flex-shrink-0 animate-bounce">
            <Coins className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center space-x-2 flex-wrap gap-1">
              <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500 text-slate-950 shadow-sm animate-pulse">
                STAMP & 24H AUTO-SCHEDULER 🌟
              </span>
              <span className="text-[10px] text-amber-300 font-mono font-bold">JM-CRYPTO REVOLUTION</span>
              <span className="text-[9px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-mono font-bold flex items-center space-x-1">
                <BarChart3 className="w-3 h-3 text-emerald-400" />
                <span>{clickCount} Clicks Tracked</span>
              </span>
              {shareStatus && (
                <span className="text-[9px] text-amber-200 bg-amber-500/20 px-2 py-0.5 rounded font-bold animate-pulse">
                  {shareStatus}
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm font-extrabold text-amber-100 font-serif mt-0.5 leading-snug">
              MINE REAL JM-CRYPTO (1 JMC = $35,000 USD / ₦52.5M NGN) VIA BUILT-IN SECURE CONTAINER — ZERO DOMAIN HOSTING REQUIRED!
            </p>
          </div>
        </div>

        {/* Social Share Buttons & Launch */}
        <div className="flex items-center space-x-2 flex-shrink-0 w-full md:w-auto justify-end flex-wrap gap-y-2">
          {/* Twitter Share */}
          <button
            onClick={() => handleSocialShare('twitter')}
            className="px-2.5 py-1.5 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-400/40 text-[10px] font-bold flex items-center space-x-1 transition-all"
            title="Share to Twitter / X"
          >
            <span>Twitter</span>
          </button>

          {/* Facebook Share */}
          <button
            onClick={() => handleSocialShare('facebook')}
            className="px-2.5 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-400/40 text-[10px] font-bold flex items-center space-x-1 transition-all"
            title="Share to Facebook"
          >
            <span>Facebook</span>
          </button>

          {/* Telegram Share */}
          <button
            onClick={() => handleSocialShare('telegram')}
            className="px-2.5 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-400/40 text-[10px] font-bold flex items-center space-x-1 transition-all"
            title="Share to Telegram"
          >
            <span>Telegram</span>
          </button>

          <button
            onClick={handleLinkClick}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 transition-all hover:scale-105 flex items-center space-x-1.5 border border-amber-300"
            title="Launch Built-in Secure Web Container Miner"
          >
            <span>Launch Built-in Miner</span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-950" />
          </button>

          <button
            onClick={() => setIsVisible(false)}
            className="p-2 rounded-xl bg-slate-900/90 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 transition-colors border border-amber-500/20 hover:border-rose-500/40"
            title="Close Stamp Notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
