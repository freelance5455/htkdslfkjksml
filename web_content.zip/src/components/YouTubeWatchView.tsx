import React, { useState, useRef, useEffect } from 'react';
import { useVideo } from '../context/VideoContext';
import { VideoItem } from '../types/video';
import { formatDuration, formatTimeCode, formatViews } from '../utils/format';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  Volume1,
  VolumeX,
  Maximize,
  Minimize,
  ThumbsUp,
  ThumbsDown,
  Share2,
  Bookmark,
  Check,
  Bell,
  MessageSquare,
  ArrowLeft,
  Tv,
  CheckCircle2,
  Send,
  MoreVertical,
  Film,
  Sparkles,
} from 'lucide-react';

interface YouTubeWatchViewProps {
  video: VideoItem;
  onClose: () => void;
  onOpenNetflixPlayer: (video: VideoItem) => void;
}

export const YouTubeWatchView: React.FC<YouTubeWatchViewProps> = ({
  video,
  onClose,
  onOpenNetflixPlayer,
}) => {
  const {
    videos,
    filteredVideos,
    myList,
    toggleMyList,
    likedVideos,
    reactToVideo,
    saveWatchProgress,
    currentProfile,
    language,
  } = useVideo();

  const [currentVideo, setCurrentVideo] = useState<VideoItem>(video);
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(video.duration || 120);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [subscribersCount, setSubscribersCount] = useState(1480000);
  const [isDescExpanded, setIsDescExpanded] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [autoPlayNext, setAutoPlayNext] = useState(true);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [sidebarFilter, setSidebarFilter] = useState<'all' | 'related' | 'popular'>('all');

  // Comments state
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<
    { id: string; user: string; avatar: string; text: string; time: string; likes: number }[]
  >([
    {
      id: 'c1',
      user: 'CreativeStudio',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      text: 'The visual effects and cinematic score here are genuinely top tier! Loving this YouTube watch view.',
      time: '3 hours ago',
      likes: 42,
    },
    {
      id: 'c2',
      user: 'CinemaGeek99',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80',
      text: 'Streaming speed is instantaneous and seeking works flawlessly with HTTP 206 range requests.',
      time: '1 day ago',
      likes: 19,
    },
    {
      id: 'c3',
      user: 'Hamza Khan',
      avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=100&auto=format&fit=crop&q=80',
      text: 'بہت زبردست ویڈیو پلیئر ہے! یوٹیوب کے جیسا لے آؤٹ اور کمنٹس کا نظام کمال کا ہے۔',
      time: '2 days ago',
      likes: 27,
    },
  ]);

  const videoRef = useRef<HTMLVideoElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);

  // Sync when prop changes
  useEffect(() => {
    setCurrentVideo(video);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
  }, [video.id]);

  // Periodic watch progress saving
  useEffect(() => {
    const interval = setInterval(() => {
      if (videoRef.current && !videoRef.current.paused) {
        saveWatchProgress(
          currentVideo.id,
          videoRef.current.currentTime,
          videoRef.current.duration || duration
        );
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [currentVideo.id, duration, saveWatchProgress]);

  const isInMyList = myList.includes(currentVideo.id);
  const isLiked = likedVideos.includes(currentVideo.id);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const skip = (secs: number) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = Math.max(0, Math.min(videoRef.current.currentTime + secs, duration));
  };

  const handleVolume = (vol: number) => {
    if (!videoRef.current) return;
    videoRef.current.volume = vol;
    setVolume(vol);
    setIsMuted(vol === 0);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      setIsMuted(false);
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  const handleScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || !videoRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, clickX / rect.width));
    const newTime = percentage * duration;
    videoRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSubscribe = () => {
    setIsSubscribed(!isSubscribed);
    setSubscribersCount((prev) => (isSubscribed ? prev - 1 : prev + 1));
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setComments([
      {
        id: `c-${Date.now()}`,
        user: currentProfile?.name || 'You',
        avatar: currentProfile?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
        text: commentText.trim(),
        time: 'Just now',
        likes: 0,
      },
      ...comments,
    ]);
    setCommentText('');
  };

  // Recommendations for the sidebar
  const rawRecommended = filteredVideos
    .filter((v) => v.id !== currentVideo.id)
    .filter((v) => {
      if (sidebarFilter === 'related') return v.category === currentVideo.category;
      if (sidebarFilter === 'popular') return v.matchScore >= 95;
      return true;
    });
  const recommendedVideos = Array.from(
    new Map(rawRecommended.map((v) => [v.id, v])).values()
  );

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-[#f1f1f1] select-none flex flex-col">
      {/* YouTube Style Top Navbar */}
      <header className="sticky top-0 z-40 bg-[#0f0f0f] border-b border-white/10 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onClose}
            className="flex items-center space-x-2 text-zinc-300 hover:text-white px-2 py-1.5 rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
            title="Back to Netflix Browse"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-xs font-semibold hidden sm:inline">
              {language === 'ur' ? 'نیٹ فلکس براؤز' : 'Netflix Browse'}
            </span>
          </button>

          {/* YouTube-style CineStream Logo */}
          <div className="flex items-center space-x-1.5 cursor-pointer" onClick={onClose}>
            <div className="w-7 h-5 rounded bg-[#E50914] flex items-center justify-center">
              <Play className="w-3 h-3 text-white fill-white ml-0.5" />
            </div>
            <span className="font-extrabold text-lg tracking-tight font-['Plus_Jakarta_Sans',sans-serif]">
              Cine<span className="text-[#E50914]">Tube</span>
            </span>
          </div>
        </div>

        {/* View Switcher button */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => onOpenNetflixPlayer(currentVideo)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 border border-white/10 transition-colors cursor-pointer"
          >
            <Tv className="w-3.5 h-3.5 text-red-500" />
            <span>{language === 'ur' ? 'نیٹ فلکس سنیما موڈ' : 'Switch to Netflix Cinema Mode'}</span>
          </button>

          {currentProfile && (
            <img
              src={currentProfile.avatar}
              alt={currentProfile.name}
              className="w-8 h-8 rounded-full object-cover ring-1 ring-zinc-700"
            />
          )}
        </div>
      </header>

      {/* Main 2-Column Content */}
      <div className="max-w-[1720px] mx-auto w-full px-3 sm:px-6 lg:px-8 py-4 sm:py-6 grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        {/* LEFT COLUMN: Video Player, Title, Channel, Actions, Description, Comments */}
        <div className="lg:col-span-2 space-y-4">
          {/* 16:9 Custom Video Player */}
          <div className="relative aspect-video w-full bg-black rounded-xl overflow-hidden shadow-2xl group/player">
            <video
              ref={videoRef}
              src={currentVideo.videoUrl}
              poster={currentVideo.backdropUrl || currentVideo.thumbnailUrl}
              autoPlay
              playsInline
              onTimeUpdate={() => videoRef.current && setCurrentTime(videoRef.current.currentTime)}
              onLoadedMetadata={() => videoRef.current && setDuration(videoRef.current.duration)}
              onEnded={() => {
                if (autoPlayNext && recommendedVideos.length > 0) {
                  setCurrentVideo(recommendedVideos[0]);
                }
              }}
              className="w-full h-full object-contain cursor-pointer"
              onClick={togglePlay}
            />

            {/* Bottom Scrubber & Controls (Hover overlay) */}
            <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/95 via-black/50 to-transparent opacity-0 group-hover/player:opacity-100 transition-opacity duration-200">
              {/* Progress bar */}
              <div
                ref={progressBarRef}
                onClick={handleScrub}
                className="relative h-1.5 hover:h-2.5 bg-white/20 rounded-full cursor-pointer transition-all mb-3 group/bar"
              >
                <div
                  className="absolute top-0 left-0 bottom-0 bg-[#E50914] rounded-full flex items-center justify-end"
                  style={{ width: `${progressPercent}%` }}
                >
                  <div className="w-3 h-3 bg-red-600 rounded-full shadow scale-0 group-hover/bar:scale-100 transition-transform -mr-1" />
                </div>
              </div>

              {/* Controls bar */}
              <div className="flex items-center justify-between text-white text-xs">
                <div className="flex items-center space-x-3">
                  <button onClick={togglePlay} className="p-1 hover:text-red-500 cursor-pointer">
                    {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                  </button>
                  <button onClick={() => skip(-10)} className="p-1 hover:text-red-500 cursor-pointer">
                    <RotateCcw className="w-4 h-4" />
                  </button>
                  <button onClick={() => skip(10)} className="p-1 hover:text-red-500 cursor-pointer">
                    <RotateCw className="w-4 h-4" />
                  </button>
                  <div className="flex items-center space-x-1">
                    <button onClick={toggleMute} className="p-1 cursor-pointer">
                      {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={isMuted ? 0 : volume}
                      onChange={(e) => handleVolume(parseFloat(e.target.value))}
                      className="w-16 h-1 bg-white/30 rounded accent-red-600 cursor-pointer"
                    />
                  </div>
                  <span className="font-mono text-zinc-300">
                    {formatTimeCode(currentTime)} / {formatTimeCode(duration)}
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      const nextRate = playbackRate === 1 ? 1.5 : playbackRate === 1.5 ? 2 : 1;
                      setPlaybackRate(nextRate);
                      if (videoRef.current) videoRef.current.playbackRate = nextRate;
                    }}
                    className="px-2 py-0.5 rounded bg-zinc-800 text-xs font-mono font-bold cursor-pointer"
                  >
                    {playbackRate}x
                  </button>

                  <button
                    onClick={() => onOpenNetflixPlayer(currentVideo)}
                    className="p-1 hover:text-red-500 cursor-pointer"
                    title="Cinema Fullscreen"
                  >
                    <Maximize className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Video Title */}
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-snug">
            {currentVideo.title}
          </h1>

          {/* Channel Row & Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-white/10">
            {/* Channel Info & Subscribe */}
            <div className="flex items-center space-x-3.5">
              <img
                src={currentVideo.thumbnailUrl}
                alt="Channel avatar"
                className="w-10 h-10 rounded-full object-cover ring-1 ring-zinc-700"
              />
              <div>
                <div className="flex items-center space-x-1.5">
                  <span className="font-bold text-sm text-white">
                    {currentVideo.director || currentVideo.uploaderName || 'CineStream Official'}
                  </span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-zinc-400 fill-zinc-400 text-black" />
                </div>
                <span className="text-xs text-zinc-400">
                  {formatViews(subscribersCount)} subscribers
                </span>
              </div>

              {/* Red YouTube Subscribe Button */}
              <button
                onClick={handleSubscribe}
                className={`ml-2 px-4 py-2 rounded-full text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                  isSubscribed
                    ? 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
                    : 'bg-[#E50914] hover:bg-red-700 text-white shadow-md'
                }`}
              >
                {isSubscribed ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{language === 'ur' ? 'سبسکرائب شدہ' : 'Subscribed'}</span>
                    <Bell className="w-3 h-3 ml-1 text-zinc-300" />
                  </>
                ) : (
                  <span>{language === 'ur' ? 'سبسکرائب کریں' : 'Subscribe'}</span>
                )}
              </button>
            </div>

            {/* Right Action Pills: Like/Dislike, Share, Save */}
            <div className="flex items-center space-x-2 text-xs font-semibold">
              {/* Like / Dislike Pill */}
              <div className="flex items-center bg-zinc-800 hover:bg-zinc-700/80 rounded-full overflow-hidden border border-white/5">
                <button
                  onClick={() => reactToVideo(currentVideo.id, isLiked ? 'none' : 'like')}
                  className={`flex items-center space-x-1.5 px-3 py-2 hover:bg-zinc-700 transition-colors cursor-pointer ${
                    isLiked ? 'text-red-500' : 'text-zinc-200'
                  }`}
                >
                  <ThumbsUp className={`w-4 h-4 ${isLiked ? 'fill-red-500' : ''}`} />
                  <span>{currentVideo.likes || 18}</span>
                </button>
                <div className="w-[1px] h-4 bg-zinc-600" />
                <button
                  onClick={() => reactToVideo(currentVideo.id, 'dislike')}
                  className="px-3 py-2 hover:bg-zinc-700 text-zinc-200 transition-colors cursor-pointer"
                >
                  <ThumbsDown className="w-4 h-4" />
                </button>
              </div>

              {/* Share Pill */}
              <button
                onClick={handleShare}
                className="flex items-center space-x-1.5 px-3.5 py-2 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-white/5 cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>{copiedLink ? 'Copied!' : 'Share'}</span>
              </button>

              {/* Save / Watchlist Pill */}
              <button
                onClick={() => toggleMyList(currentVideo.id)}
                className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-full transition-colors border border-white/5 cursor-pointer ${
                  isInMyList
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
                }`}
              >
                {isInMyList ? <Check className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                <span>{isInMyList ? 'Saved' : 'Save'}</span>
              </button>
            </div>
          </div>

          {/* Expandable YouTube Description Box */}
          <div
            onClick={() => setIsDescExpanded(!isDescExpanded)}
            className="p-3.5 bg-zinc-900/90 hover:bg-zinc-900 rounded-xl cursor-pointer text-xs space-y-2 border border-white/5 transition-colors"
          >
            <div className="flex items-center space-x-2 font-bold text-zinc-200">
              <span>{formatViews(currentVideo.views || 142000)}</span>
              <span>•</span>
              <span>{currentVideo.releaseYear}</span>
              <span>•</span>
              <span className="text-red-400">
                {currentVideo.tags.map((t) => `#${t.replace(/\s+/g, '')}`).join(' ')}
              </span>
            </div>

            <p className={`text-zinc-300 leading-relaxed ${isDescExpanded ? '' : 'line-clamp-2'}`}>
              {currentVideo.description}
            </p>

            {isDescExpanded && (
              <div className="pt-2 border-t border-zinc-800 space-y-1.5 text-zinc-400">
                {currentVideo.cast && currentVideo.cast.length > 0 && (
                  <p>
                    <span className="text-zinc-200 font-semibold">Starring:</span> {currentVideo.cast.join(', ')}
                  </p>
                )}
                {currentVideo.director && (
                  <p>
                    <span className="text-zinc-200 font-semibold">Directed by:</span> {currentVideo.director}
                  </p>
                )}
                <p>
                  <span className="text-zinc-200 font-semibold">Streaming Protocol:</span> HTTP 206 Partial Content (Dynamic Seeking)
                </p>
              </div>
            )}

            <button className="text-zinc-400 font-semibold hover:text-white pt-1 block">
              {isDescExpanded ? 'Show less' : '...more'}
            </button>
          </div>

          {/* YouTube Comments Section */}
          <div className="pt-4 space-y-5">
            <div className="flex items-center space-x-6">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center space-x-2">
                <MessageSquare className="w-5 h-5 text-red-500" />
                <span>{comments.length} Comments</span>
              </h3>
              <span className="text-xs text-zinc-400 cursor-pointer hover:text-white font-medium">
                Sort by: Top comments
              </span>
            </div>

            {/* Add Comment Input Form */}
            <form onSubmit={handleAddComment} className="flex items-start space-x-3">
              <img
                src={currentProfile?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                alt="Profile"
                className="w-9 h-9 rounded-full object-cover"
              />
              <div className="flex-1 space-y-2">
                <input
                  type="text"
                  placeholder={language === 'ur' ? 'ایک عوامی تبصرہ شامل کریں...' : 'Add a comment...'}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="w-full bg-transparent border-b border-zinc-700 focus:border-white py-1.5 text-sm text-white focus:outline-none placeholder-zinc-500 transition-colors"
                />
                {commentText && (
                  <div className="flex items-center justify-end space-x-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setCommentText('')}
                      className="px-3 py-1.5 text-xs text-zinc-400 hover:text-white font-semibold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-full bg-[#E50914] hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
                    >
                      Comment
                    </button>
                  </div>
                )}
              </div>
            </form>

            {/* Comments Stream */}
            <div className="space-y-4 pt-2">
              {comments.map((c) => (
                <div key={c.id} className="flex items-start space-x-3 text-xs">
                  <img src={c.avatar} alt={c.user} className="w-9 h-9 rounded-full object-cover" />
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-white text-xs">@{c.user.replace(/\s+/g, '')}</span>
                      <span className="text-zinc-500 text-[11px]">{c.time}</span>
                    </div>
                    <p className="text-zinc-200 text-sm leading-relaxed">{c.text}</p>
                    <div className="flex items-center space-x-3 pt-1 text-zinc-400">
                      <button className="flex items-center space-x-1 hover:text-white cursor-pointer">
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>{c.likes > 0 ? c.likes : ''}</span>
                      </button>
                      <button className="hover:text-white cursor-pointer">
                        <ThumbsDown className="w-3.5 h-3.5" />
                      </button>
                      <button className="hover:text-white font-semibold cursor-pointer">Reply</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Up Next / Recommended Sidebar */}
        <div className="space-y-4">
          {/* Top Bar with Filter Chips and Autoplay Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              {[
                { id: 'all', label: 'All' },
                { id: 'related', label: 'Related' },
                { id: 'popular', label: 'Top Rated' },
              ].map((chip) => (
                <button
                  key={chip.id}
                  onClick={() => setSidebarFilter(chip.id as any)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    sidebarFilter === chip.id
                      ? 'bg-white text-black'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Autoplay Switch */}
            <div className="flex items-center space-x-1.5 text-xs text-zinc-400">
              <span className="text-[11px]">Autoplay</span>
              <button
                onClick={() => setAutoPlayNext(!autoPlayNext)}
                className={`w-8 h-4 rounded-full transition-colors relative cursor-pointer ${
                  autoPlayNext ? 'bg-red-600' : 'bg-zinc-700'
                }`}
              >
                <div
                  className={`w-3 h-3 bg-white rounded-full absolute top-0.5 transition-transform ${
                    autoPlayNext ? 'right-0.5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Vertical Stack of YouTube Cards */}
          <div className="space-y-3">
            {recommendedVideos.map((rec) => (
              <div
                key={rec.id}
                onClick={() => setCurrentVideo(rec)}
                className="flex items-start space-x-3 group cursor-pointer hover:bg-zinc-900/60 p-1.5 rounded-lg transition-colors"
              >
                {/* 16:9 Thumbnail */}
                <div className="relative w-40 sm:w-44 aspect-video bg-zinc-800 rounded-lg overflow-hidden flex-shrink-0">
                  <img
                    src={rec.thumbnailUrl}
                    alt={rec.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                  <div className="absolute bottom-1 right-1 bg-black/80 text-white font-mono text-[10px] px-1 py-0.5 rounded">
                    {formatDuration(rec.duration)}
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0 space-y-1">
                  <h4 className="text-white text-xs sm:text-sm font-semibold line-clamp-2 leading-tight group-hover:text-red-400 transition-colors">
                    {rec.title}
                  </h4>
                  <p className="text-zinc-400 text-xs truncate">
                    {rec.director || rec.uploaderName || 'CineStream'}
                  </p>
                  <p className="text-zinc-500 text-[11px]">
                    {formatViews(rec.views || 89000)} • {rec.matchScore}% Match
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
