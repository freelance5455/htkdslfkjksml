import React, { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';
import { Product, StoreSettings } from '../types';
import { X, Printer, Download, Barcode as BarcodeIcon } from 'lucide-react';

interface BarcodeTagModalProps {
  product: Product;
  settings: StoreSettings;
  onClose: () => void;
}

export const BarcodeTagModal: React.FC<BarcodeTagModalProps> = ({
  product,
  settings,
  onClose
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (svgRef.current && product.code) {
      try {
        JsBarcode(svgRef.current, product.code, {
          format: 'CODE128',
          lineColor: '#0f172a',
          width: 2,
          height: 55,
          displayValue: true,
          font: 'monospace',
          fontSize: 14,
          margin: 10,
          background: '#ffffff'
        });
      } catch (err) {
        console.error('Failed to generate barcode:', err);
      }
    }
  }, [product.code]);

  const handlePrintTag = () => {
    window.print();
  };

  const handleDownloadSVG = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const source = serializer.serializeToString(svgRef.current);
    const blob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `barcode-${product.code}-${product.name.replace(/[^a-z0-9]/gi, '_')}.svg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2 text-cyan-400">
            <BarcodeIcon className="w-5 h-5" />
            <h3 className="font-bold text-slate-100">Product Barcode Label</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-center">
          {/* Printable Label preview */}
          <div 
            id="printableArea"
            className="bg-white text-slate-950 p-6 rounded-xl border border-slate-200 shadow-inner flex flex-col items-center justify-center mx-auto"
          >
            <div className="text-[11px] font-bold tracking-wider text-slate-600 uppercase">
              {settings.storeName}
            </div>
            <div className="text-sm font-bold text-slate-900 mt-1 max-w-[240px] truncate">
              {product.name}
            </div>
            <div className="text-xl font-extrabold text-slate-950 my-1">
              {settings.currency}{product.price.toFixed(2)}
            </div>
            <div className="my-1 overflow-x-auto max-w-full">
              <svg ref={svgRef} className="max-w-full h-auto"></svg>
            </div>
            <div className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">
              SKU: {product.code} • {product.category}
            </div>
          </div>

          <p className="text-xs text-slate-400">
            Print this tag onto adhesive paper or sticker labels for physical store shelves.
          </p>

          <div className="flex gap-3 pt-2">
            <button
              onClick={handlePrintTag}
              className="flex-1 py-2.5 px-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg transition"
            >
              <Printer className="w-4 h-4" />
              Print Label
            </button>
            <button
              onClick={handleDownloadSVG}
              className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 border border-slate-700 transition"
            >
              <Download className="w-4 h-4" />
              Download SVG
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
