import React, { useState } from 'react';
import { ServerInfo, ConnectionConfig } from '../types.ts';
import {
  Copy,
  Check,
  RefreshCw,
  Settings,
  Volume2,
  VolumeX,
  Radio,
  Server
} from 'lucide-react';
import { sounds } from '../utils/audio.ts';

interface ServerHeaderProps {
  serverInfo: ServerInfo | null;
  config: ConnectionConfig;
  playerCount: number;
  isLoading: boolean;
  onRefresh: () => void;
  onOpenSettings: () => void;
  onToggleSound: () => void;
  countdown: number;
}

export const ServerHeader: React.FC<ServerHeaderProps> = ({
  serverInfo,
  config,
  playerCount,
  isLoading,
  onRefresh,
  onOpenSettings,
  onToggleSound,
  countdown
}) => {
  const [copiedIp, setCopiedIp] = useState(false);

  const serverAddress = `${config.host}:${config.port}`;
  const motd = serverInfo?.motd || 'Minecraft Server';
  const isOnline = serverInfo?.online !== false;

  const handleCopyIp = () => {
    navigator.clipboard.writeText(config.host);
    setCopiedIp(true);
    if (config.soundEnabled) sounds.playClickSound();
    setTimeout(() => setCopiedIp(false), 2000);
  };

  return (
    <header className="w-full bg-zinc-900/90 border border-zinc-800 rounded-2xl p-5 sm:p-6 shadow-xl backdrop-blur-md">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5">
        {/* Server Brand & Identity */}
        <div className="space-y-2">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                  <span>{motd}</span>
                </h1>
                <span
                  className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    isOnline
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                      : 'bg-red-950/80 text-red-300 border border-red-500/30'
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-red-500'
                    }`}
                  />
                  {isOnline ? 'Online' : 'Offline'}
                </span>
              </div>
              <p className="text-xs text-zinc-400 font-mono flex items-center gap-2 mt-0.5">
                <span>{serverAddress}</span>
                {serverInfo?.tps && (
                  <>
                    <span className="text-zinc-600">·</span>
                    <span className="text-emerald-400/90 font-medium">
                      {serverInfo.tps} TPS
                    </span>
                  </>
                )}
                {serverInfo?.version && (
                  <>
                    <span className="text-zinc-600">·</span>
                    <span className="text-zinc-400 truncate max-w-[120px] sm:max-w-none">
                      {serverInfo.version.split(' ')[0]}
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls & Stats */}
        <div className="flex items-center gap-2.5 sm:gap-3 flex-wrap sm:flex-nowrap justify-between md:justify-end">
          {/* Active Players Count Badge */}
          <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800/80 border border-zinc-700/60 text-sm">
            <Radio className="w-4 h-4 text-emerald-400" />
            <span className="text-zinc-400 text-xs sm:text-sm font-medium">Spieler:</span>
            <span className="font-bold text-white text-sm sm:text-base">
              {playerCount}
              {serverInfo?.maxPlayers ? (
                <span className="text-zinc-500 font-normal text-xs sm:text-sm">
                  {' '}/ {serverInfo.maxPlayers}
                </span>
              ) : ''}
            </span>
          </div>

          {/* Copy Server IP Button */}
          <button
            onClick={handleCopyIp}
            title="Server-Adresse kopieren"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300 hover:text-white border border-zinc-700/60 text-xs sm:text-sm font-medium transition-colors"
          >
            {copiedIp ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">Kopiert</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span className="hidden sm:inline">IP</span>
              </>
            )}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            title={config.soundEnabled ? 'Ton ausschalten' : 'Ton einschalten'}
            className="p-2 sm:px-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300 hover:text-white border border-zinc-700/60 transition-colors"
          >
            {config.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-zinc-500" />
            )}
          </button>

          {/* Refresh Button with Countdown Ring */}
          <button
            onClick={onRefresh}
            disabled={isLoading}
            title={
              config.refreshInterval > 0
                ? `Aktualisieren (Auto-Refresh in ${countdown}s)`
                : 'Aktualisieren'
            }
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600/90 hover:bg-emerald-600 text-white text-xs sm:text-sm font-medium transition-all shadow-sm hover:shadow-emerald-900/30 disabled:opacity-50"
          >
            <RefreshCw
              className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`}
            />
            <span className="hidden sm:inline">Aktualisieren</span>
            {config.refreshInterval > 0 && (
              <span className="text-[11px] opacity-80 font-mono">
                {countdown}s
              </span>
            )}
          </button>

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            title="ServerTap Verbindungseinstellungen"
            className="p-2 sm:px-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-400 hover:text-white border border-zinc-700/60 transition-colors"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
