import React from "react";
import { Dish } from "../types";

interface FoodCardProps {
  dish: Dish;
  onSelect: (dish: Dish) => void;
}

export const FoodCard: React.FC<FoodCardProps> = ({ dish, onSelect }) => {
  const isNonVeg = dish.dietaryLabel?.some(
    (label) => label.toLowerCase().includes("non-veg") || label.toLowerCase().includes("chicken") || label.toLowerCase().includes("fish") || label.toLowerCase().includes("prawn")
  );

  return (
    <article
      onClick={() => onSelect(dish)}
      className="group cursor-pointer flex flex-col justify-between bg-[#FDFBF7] border border-[#D8D0C2]/80 rounded-sm p-4 sm:p-5 transition-all duration-300 hover:border-[#17201C] hover:shadow-md relative"
    >
      <div>
        {/* Top Header: Dietary indicator + Category/Dietary tags + Price */}
        <div className="flex items-start justify-between gap-3 mb-2.5">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Authentic Food Type Symbol (Green square for veg, Brown/Red for non-veg) */}
            <span
              className={`inline-flex items-center justify-center w-4 h-4 border rounded-[2px] shrink-0 ${
                isNonVeg
                  ? "border-[#B96D52] bg-transparent"
                  : "border-emerald-700 bg-transparent"
              }`}
              title={isNonVeg ? "Non-Vegetarian" : "Vegetarian"}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  isNonVeg ? "bg-[#B96D52]" : "bg-emerald-700"
                }`}
              />
            </span>

            {dish.dietaryLabel && dish.dietaryLabel.length > 0 && (
              <span className="text-[10px] font-medium tracking-wider uppercase px-2 py-0.5 rounded-full bg-[#EAE4D7]/70 text-[#17201C]/80 border border-[#D8D0C2]/50">
                {dish.dietaryLabel[0]}
              </span>
            )}
          </div>

          {/* Price */}
          {dish.price && (
            <span className="font-serif font-medium text-base sm:text-lg text-[#17201C] group-hover:text-[#B96D52] transition-colors shrink-0">
              {dish.price}
            </span>
          )}
        </div>

        {/* Dish Name */}
        <h4 className="font-serif text-lg sm:text-xl text-[#17201C] group-hover:text-[#B96D52] transition-colors leading-snug mb-2">
          {dish.name}
        </h4>

        {/* Short Description */}
        <p className="text-xs sm:text-sm text-[#17201C]/75 font-sans leading-relaxed line-clamp-3">
          {dish.description}
        </p>
      </div>

      {/* Subtle Footer */}
      <div className="mt-4 pt-3 border-t border-[#D8D0C2]/50 flex items-center justify-between text-[11px] text-[#17201C]/60">
        <span className="font-sans group-hover:text-[#17201C] transition-colors">
          View details & customization
        </span>
        <span className="text-xs font-serif text-[#9BAF82] group-hover:translate-x-1 transition-transform">
          →
        </span>
      </div>
    </article>
  );
};
