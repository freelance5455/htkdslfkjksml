import { useState, useEffect } from 'react';
import { Lesson, Student } from '../types';
import { Clock, AlertCircle, Sparkles, BookOpen, ChevronRight } from 'lucide-react';

interface CountdownTimerProps {
  lesson: Lesson | null;
  student?: Student;
  onViewLesson?: (lesson: Lesson) => void;
  onOpenQuickPayment?: (student: Student, lesson?: Lesson) => void;
}

interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
  totalMs: number;
}

export const CountdownTimer = ({
  lesson,
  student,
  onViewLesson,
  onOpenQuickPayment,
}: CountdownTimerProps) => {
  const [timeLeft, setTimeLeft] = useState<TimeRemaining | null>(null);

  useEffect(() => {
    if (!lesson) {
      setTimeLeft(null);
      return;
    }

    const calculateTime = () => {
      const [year, month, day] = lesson.date.split('-').map(Number);
      const [hour, minute] = lesson.time.split(':').map(Number);
      const targetTime = new Date(year, month - 1, day, hour, minute).getTime();
      const now = new Date().getTime();
      const diff = targetTime - now;

      if (diff <= 0) {
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
          isPast: true,
          totalMs: diff,
        });
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({
        days,
        hours,
        minutes,
        seconds,
        isPast: false,
        totalMs: diff,
      });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [lesson]);

  if (!lesson) {
    return (
      <div className="bg-[#121214] text-stone-100 rounded-3xl p-6 shadow-2xl border border-zinc-800">
        <div className="flex items-center gap-3 mb-2 text-stone-400">
          <Clock className="w-5 h-5 text-rose-400" />
          <span className="text-xs font-semibold tracking-wider uppercase">Sonraki Ders Sayacı</span>
        </div>
        <p className="text-lg font-medium text-stone-300">Planlanmış aktif ders bulunmuyor.</p>
        <p className="text-xs text-stone-400 mt-1">Öğrenci veya ders ekleyerek takvimi doldurabilirsiniz.</p>
      </div>
    );
  }

  const isPayment = lesson.isPaymentLesson;
  const cycleMax = student ? student.paymentFrequency : 4;
  const cycleTotal = student ? student.hourlyRate * student.paymentFrequency : lesson.rate;
  const currencySymbol = lesson.currency === 'USD' ? '$' : '₺';

  return (
    <div
      className={`relative overflow-hidden rounded-3xl p-6 sm:p-8 text-white shadow-2xl transition-all border ${
        isPayment
          ? 'bg-gradient-to-br from-[#1a1202] via-[#121214] to-[#241703] border-amber-500/60 shadow-amber-950/40'
          : 'bg-gradient-to-br from-[#161619] via-[#121214] to-[#0c0c0e] border-zinc-800 shadow-zinc-950/60'
      }`}
    >
      {/* Decorative ambient glowing backdrop */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-rose-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      {isPayment && (
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-500/20 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20" />
      )}

      {/* Header pill & lesson state */}
      <div className="relative flex flex-wrap items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-zinc-900/80 backdrop-blur-md border border-zinc-700/60 text-stone-200">
            <Clock className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            Sonraki Derse Kalan Süre
          </span>

          <span
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
              lesson.subject === 'english'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-400/30'
                : 'bg-rose-500/20 text-rose-300 border border-rose-400/30'
            }`}
          >
            <BookOpen className="w-3 h-3" />
            {lesson.subject === 'english' ? 'İngilizce' : 'Türkçe'}
          </span>
        </div>

        {isPayment && (
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold bg-amber-400 text-stone-950 shadow-md shadow-amber-500/40 animate-pulse">
            <Sparkles className="w-3.5 h-3.5 fill-stone-950" />
            💰 BU DERS ÖDEME ALINACAK ({cycleTotal.toLocaleString('tr-TR')} {currencySymbol})
          </div>
        )}
      </div>

      {/* Student and Schedule Info */}
      <div className="relative flex flex-col md:flex-row md:items-end justify-between gap-6 mb-7">
        <div>
          <div className="flex items-center gap-3">
            <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-serif text-white">
              {lesson.studentName}
            </h3>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-zinc-800 text-stone-300 font-mono border border-zinc-700">
              Döngü: {lesson.cycleNumber}/{cycleMax}. ders
            </span>
          </div>

          <p className="text-sm text-stone-300 mt-1 flex items-center gap-2">
            <span>📅 {new Date(lesson.date).toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
            <span>•</span>
            <span className="font-semibold text-rose-400">⏰ {lesson.time}</span>
            <span>({lesson.durationMinutes} dk)</span>
          </p>

          {isPayment && (
            <div className="mt-2.5 text-xs flex items-center gap-1.5 text-amber-300 bg-amber-950/60 border border-amber-500/40 px-3 py-1.5 rounded-xl w-fit">
              <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                {lesson.cycleNumber}. ders tamamlandığında {cycleTotal.toLocaleString('tr-TR')} {currencySymbol} ödeme tahsil edilecek.
              </span>
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2.5 shrink-0">
          {isPayment && student && onOpenQuickPayment && (
            <button
              onClick={() => onOpenQuickPayment(student, lesson)}
              className="px-4 py-2 text-xs font-bold bg-amber-400 hover:bg-amber-300 text-stone-950 rounded-xl transition-all shadow-lg shadow-amber-500/30 active:scale-95 flex items-center gap-1.5 cursor-pointer"
            >
              <span>Ödeme Al</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
          {onViewLesson && (
            <button
              onClick={() => onViewLesson(lesson)}
              className="px-3.5 py-2 text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-stone-200 rounded-xl transition-all cursor-pointer"
            >
              Ders Detayı
            </button>
          )}
        </div>
      </div>

      {/* Countdown Grid (Gün, Saat, Dakika, Saniye) */}
      <div className="relative grid grid-cols-4 gap-2 sm:gap-4 max-w-xl">
        <div className="bg-black/60 backdrop-blur-md rounded-2xl p-2.5 sm:p-3.5 text-center border border-zinc-800">
          <div className="text-2xl sm:text-4xl font-extrabold font-mono tracking-tight text-white">
            {timeLeft ? String(timeLeft.days).padStart(2, '0') : '00'}
          </div>
          <div className="text-[10px] sm:text-xs font-semibold text-stone-400 uppercase tracking-wider mt-1">
            Gün
          </div>
        </div>

        <div className="bg-black/60 backdrop-blur-md rounded-2xl p-2.5 sm:p-3.5 text-center border border-zinc-800">
          <div className="text-2xl sm:text-4xl font-extrabold font-mono tracking-tight text-white">
            {timeLeft ? String(timeLeft.hours).padStart(2, '0') : '00'}
          </div>
          <div className="text-[10px] sm:text-xs font-semibold text-stone-400 uppercase tracking-wider mt-1">
            Saat
          </div>
        </div>

        <div className="bg-black/60 backdrop-blur-md rounded-2xl p-2.5 sm:p-3.5 text-center border border-zinc-800">
          <div className="text-2xl sm:text-4xl font-extrabold font-mono tracking-tight text-rose-400">
            {timeLeft ? String(timeLeft.minutes).padStart(2, '0') : '00'}
          </div>
          <div className="text-[10px] sm:text-xs font-semibold text-stone-400 uppercase tracking-wider mt-1">
            Dakika
          </div>
        </div>

        <div className="bg-black/60 backdrop-blur-md rounded-2xl p-2.5 sm:p-3.5 text-center border border-zinc-800">
          <div className="text-2xl sm:text-4xl font-extrabold font-mono tracking-tight text-amber-400">
            {timeLeft ? String(timeLeft.seconds).padStart(2, '0') : '00'}
          </div>
          <div className="text-[10px] sm:text-xs font-semibold text-stone-400 uppercase tracking-wider mt-1">
            Saniye
          </div>
        </div>
      </div>
    </div>
  );
};
