import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Camera,
  Upload,
  LayoutTemplate,
  Music,
  Lock,
  Globe,
  Users,
  ChevronRight,
  Sparkles,
  StopCircle,
  Video,
  Check,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { createNewPost } from '../services/db';
import { Post } from '../types';

interface CreateScreenProps {
  onClose: () => void;
  onPostCreated: (post: Post) => void;
}

const TEMPLATES = [
  {
    name: 'Skate no Pôr do Sol',
    category: 'trends',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1520045892732-304bc3ac5d8e?auto=format&fit=crop&w=800&q=80',
    caption: 'Manobras perfeitas com a golden hour ao fundo 🛹🌇 #vibes #skate #sunset',
    musicTitle: 'Lo-Fi Chillbeats · Sunset Cruise',
  },
  {
    name: 'Vibez Neon Urbana',
    category: 'dance',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80',
    caption: 'Energia surreal na noite da cidade ✨🔥 #dance #vibes #clipshare',
    musicTitle: 'Ana Clara · Vibez da Noite (Original Sound)',
  },
  {
    name: 'Cyberpunk & Drift',
    category: 'arte',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    caption: 'Velocidade, estética e luzes futuristas 🏎️⚡️ #cyber #arte #drift',
    musicTitle: 'Synthwave 84 · Electric Horizon',
  },
];

const MUSIC_LIBRARY = [
  'Lo-Fi Chillbeats · Sunset Cruise',
  'Ana Clara · Vibez da Noite (Original Sound)',
  'Synthwave 84 · Electric Horizon',
  'Bielzin · Midnight Studio Session',
  'Trap Nation · Neon Bass 2026',
  'Summer Vibes · Tropical Island',
];

export const CreateScreen: React.FC<CreateScreenProps> = ({ onClose, onPostCreated }) => {
  const { userProfile } = useAuth();
  const [activeTool, setActiveTool] = useState<'gravar' | 'upload' | 'templates'>('templates');
  const [selectedMediaUrl, setSelectedMediaUrl] = useState<string>(TEMPLATES[0].videoUrl);
  const [selectedCoverUrl, setSelectedCoverUrl] = useState<string>(TEMPLATES[0].coverUrl);
  const [mediaType, setMediaType] = useState<'video' | 'image'>('video');
  const [caption, setCaption] = useState('Skate no pôr do sol 🌅 #vibes #skate #sunset');
  const [selectedHashtags, setSelectedHashtags] = useState<string[]>(['vibes', 'skate', 'sunset']);
  const [customTagInput, setCustomTagInput] = useState('');
  const [selectedMusic, setSelectedMusic] = useState('Lo-Fi Chillbeats · Sunset Cruise');
  const [privacy, setPrivacy] = useState<'public' | 'followers' | 'private'>('public');

  // Modals & Pickers
  const [showMusicPicker, setShowMusicPicker] = useState(false);
  const [showPrivacyPicker, setShowPrivacyPicker] = useState(false);
  const [showTemplatePicker, setShowTemplatePicker] = useState(false);

  // Camera Recording States
  const [isRecording, setIsRecording] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  // Upload Progress
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Camera stream handler
  const startCamera = async () => {
    try {
      setActiveTool('gravar');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 1280 } },
        audio: true,
      });
      if (videoPreviewRef.current) {
        videoPreviewRef.current.srcObject = stream;
        videoPreviewRef.current.play();
      }
      setCameraActive(true);
    } catch (err) {
      console.warn('Camera access denied or unavailable, switching to templates:', err);
      alert('Não foi possível acessar a câmera. Você pode selecionar vídeos ou templates.');
      setActiveTool('templates');
    }
  };

  const stopCamera = () => {
    if (videoPreviewRef.current && videoPreviewRef.current.srcObject) {
      const stream = videoPreviewRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoPreviewRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const handleToggleRecord = () => {
    if (!cameraActive) {
      startCamera();
      return;
    }

    if (!isRecording) {
      if (!videoPreviewRef.current?.srcObject) return;
      const stream = videoPreviewRef.current.srcObject as MediaStream;
      const recorder = new MediaRecorder(stream);
      recordedChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/mp4' });
        const videoUrl = URL.createObjectURL(blob);
        setSelectedMediaUrl(videoUrl);
        setMediaType('video');
        stopCamera();
      };

      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    } else {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
    }
  };

  // File Upload handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVid = file.type.startsWith('video');
    setMediaType(isVid ? 'video' : 'image');

    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setSelectedMediaUrl(result);
      setSelectedCoverUrl(result);
    };
    reader.readAsDataURL(file);
    setActiveTool('upload');
  };

  const handleAddHashtag = (tag: string) => {
    const clean = tag.replace(/#/g, '').trim().toLowerCase();
    if (clean && !selectedHashtags.includes(clean)) {
      setSelectedHashtags([...selectedHashtags, clean]);
    }
    setCustomTagInput('');
  };

  const handleRemoveHashtag = (tag: string) => {
    setSelectedHashtags(selectedHashtags.filter((t) => t !== tag));
  };

  const handleSelectTemplate = (t: typeof TEMPLATES[0]) => {
    setSelectedMediaUrl(t.videoUrl);
    setSelectedCoverUrl(t.coverUrl);
    setCaption(t.caption);
    setSelectedMusic(t.musicTitle);
    setShowTemplatePicker(false);
  };

  const handleShare = async () => {
    if (!selectedMediaUrl) {
      alert('Selecione ou grave um vídeo primeiro!');
      return;
    }

    setIsUploading(true);
    // Simulate real upload progress bar
    for (let i = 10; i <= 95; i += 20) {
      setUploadProgress(i);
      await new Promise((r) => setTimeout(r, 120));
    }

    const currentCreator = userProfile || {
      id: 'user-joaovibes',
      username: 'joaovibes',
      displayName: 'João Vibes',
      photoURL: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80',
      isVerified: true,
    };

    try {
      const newPost = await createNewPost({
        userId: currentCreator.id,
        username: currentCreator.username,
        userDisplayName: currentCreator.displayName,
        userPhotoURL: currentCreator.photoURL,
        isVerified: !!currentCreator.isVerified,
        mediaType,
        mediaUrl: selectedMediaUrl,
        coverUrl: selectedCoverUrl,
        caption,
        hashtags: selectedHashtags,
        musicTitle: selectedMusic,
        privacy,
        category: 'trends',
      });

      setUploadProgress(100);
      onPostCreated(newPost);
      onClose();
    } catch (err) {
      console.error('Error creating post:', err);
      setIsUploading(false);
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md overflow-y-auto animate-fade-in select-none">
      <div className="w-full max-w-lg min-h-screen md:min-h-0 md:max-h-[92vh] bg-[#050505] md:bg-[#101014] md:border md:border-[#19191F] md:rounded-3xl flex flex-col justify-between p-6 shadow-2xl relative">
        {/* Header matching reference image Screen 4:
            Criar + Close button */}
        <div className="flex items-center justify-between pb-4 border-b border-[#19191F]">
          <h2 className="text-xl font-extrabold text-white">Criar</h2>
          <button
            onClick={onClose}
            className="p-1.5 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F] transition-colors cursor-pointer"
          >
            <X size={22} />
          </button>
        </div>

        {/* 3 Tool Cards matching reference image:
            🎥 Gravar | ⬆️ Upload | 🎨 Templates */}
        <div className="grid grid-cols-3 gap-3 my-4">
          {/* Gravar Card */}
          <button
            onClick={handleToggleRecord}
            className={`flex flex-col items-center justify-center py-4 px-2 rounded-2xl transition-all cursor-pointer ${
              activeTool === 'gravar'
                ? 'bg-clipshare-gradient glow-clipshare text-white font-bold'
                : 'bg-[#19191F] text-[#A1A1AA] hover:text-white hover:bg-[#22222b]'
            }`}
          >
            {isRecording ? (
              <StopCircle size={28} className="animate-pulse text-white mb-1.5" />
            ) : (
              <Camera size={26} className="mb-1.5" />
            )}
            <span className="text-xs">{isRecording ? 'Parar' : 'Gravar'}</span>
          </button>

          {/* Upload Card */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className={`flex flex-col items-center justify-center py-4 px-2 rounded-2xl transition-all cursor-pointer ${
              activeTool === 'upload'
                ? 'bg-clipshare-gradient glow-clipshare text-white font-bold'
                : 'bg-[#19191F] text-[#A1A1AA] hover:text-white hover:bg-[#22222b]'
            }`}
          >
            <Upload size={26} className="mb-1.5" />
            <span className="text-xs">Upload</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*,image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          {/* Templates Card */}
          <button
            onClick={() => {
              setActiveTool('templates');
              setShowTemplatePicker(true);
            }}
            className={`flex flex-col items-center justify-center py-4 px-2 rounded-2xl transition-all cursor-pointer ${
              activeTool === 'templates'
                ? 'bg-clipshare-gradient glow-clipshare text-white font-bold'
                : 'bg-[#19191F] text-[#A1A1AA] hover:text-white hover:bg-[#22222b]'
            }`}
          >
            <LayoutTemplate size={26} className="mb-1.5" />
            <span className="text-xs">Templates</span>
          </button>
        </div>

        {/* Media Preview Card with "Editar capa" button */}
        <div className="relative w-full aspect-[16/10] bg-[#19191F] rounded-2xl overflow-hidden border border-[#272730] shadow-inner mb-4">
          {cameraActive ? (
            <video
              ref={videoPreviewRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          ) : mediaType === 'video' ? (
            <video
              src={selectedMediaUrl}
              autoPlay
              loop
              muted
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              src={selectedMediaUrl}
              alt="Pré-visualização"
              className="w-full h-full object-cover"
            />
          )}

          {/* "Editar capa" button matching reference image Screen 4 */}
          <button
            onClick={() => alert('Capa selecionada com sucesso.')}
            className="absolute bottom-3 right-3 px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur-md text-[11px] font-semibold text-white hover:bg-black/80 transition-colors cursor-pointer border border-white/20"
          >
            Editar capa
          </button>
        </div>

        {/* Caption Field matching reference image: "Escreva uma legenda..." */}
        <div className="mb-3">
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Escreva uma legenda..."
            rows={2}
            className="w-full bg-[#19191F] border border-[#272730] rounded-2xl p-3 text-xs md:text-sm text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#FF008C]"
          />
        </div>

        {/* Hashtags Chips: #vibes #skate #sunset + */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          {selectedHashtags.map((tag) => (
            <span
              key={tag}
              onClick={() => handleRemoveHashtag(tag)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#19191F] border border-[#272730] text-xs font-semibold text-white/90 hover:border-[#FF008C] cursor-pointer"
            >
              #{tag}
              <X size={12} className="text-[#A1A1AA]" />
            </span>
          ))}

          <div className="flex items-center gap-1 bg-[#19191F] border border-[#272730] rounded-full px-2.5 py-1 text-xs">
            <span className="text-[#A1A1AA]">#</span>
            <input
              type="text"
              value={customTagInput}
              onChange={(e) => setCustomTagInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddHashtag(customTagInput)}
              placeholder="adicionar"
              className="w-16 bg-transparent text-white focus:outline-none text-xs"
            />
            <button
              onClick={() => handleAddHashtag(customTagInput)}
              className="text-[#FF008C] font-bold"
            >
              +
            </button>
          </div>
        </div>

        {/* Option Row: 🎵 Adicionar música */}
        <div
          onClick={() => setShowMusicPicker(true)}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#19191F] hover:bg-[#22222b] transition-colors mb-2.5 cursor-pointer border border-[#272730]"
        >
          <div className="flex items-center gap-3">
            <Music size={18} className="text-[#FF008C]" />
            <span className="text-xs md:text-sm font-medium text-white truncate max-w-[220px]">
              {selectedMusic || 'Adicionar música'}
            </span>
          </div>
          <ChevronRight size={16} className="text-[#A1A1AA]" />
        </div>

        {/* Option Row: 👥 Quem pode ver este vídeo? -> Público */}
        <div
          onClick={() => setShowPrivacyPicker(true)}
          className="flex items-center justify-between p-3.5 rounded-2xl bg-[#19191F] hover:bg-[#22222b] transition-colors mb-4 cursor-pointer border border-[#272730]"
        >
          <div className="flex items-center gap-3">
            <Users size={18} className="text-[#A1A1AA]" />
            <span className="text-xs md:text-sm font-medium text-white">
              Quem pode ver este vídeo?
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-[#FF3B30] capitalize">
              {privacy === 'public' ? 'Público' : privacy === 'followers' ? 'Seguidores' : 'Somente eu'}
            </span>
            <ChevronRight size={16} className="text-[#A1A1AA]" />
          </div>
        </div>

        {/* Big Bottom Button: "Compartilhar" with official red-to-purple gradient! */}
        <div className="pt-2">
          {isUploading && (
            <div className="mb-2">
              <div className="flex justify-between text-xs text-[#A1A1AA] mb-1">
                <span>Publicando clipe...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full h-1.5 bg-[#19191F] rounded-full overflow-hidden">
                <div
                  className="h-full bg-clipshare-gradient transition-all duration-200"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          <button
            onClick={handleShare}
            disabled={isUploading}
            className="w-full py-4 rounded-full font-bold text-base text-white bg-clipshare-gradient glow-clipshare hover:opacity-95 active:scale-98 transition-all cursor-pointer shadow-xl disabled:opacity-50"
          >
            {isUploading ? 'Enviando...' : 'Compartilhar'}
          </button>
        </div>

        {/* Music Picker Modal */}
        {showMusicPicker && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
            <div className="w-full max-w-sm bg-[#101014] border border-[#272730] rounded-3xl p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-white">Selecionar música</h3>
                <button onClick={() => setShowMusicPicker(false)}>
                  <X size={18} className="text-[#A1A1AA]" />
                </button>
              </div>
              <div className="space-y-2">
                {MUSIC_LIBRARY.map((m) => (
                  <div
                    key={m}
                    onClick={() => {
                      setSelectedMusic(m);
                      setShowMusicPicker(false);
                    }}
                    className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition-colors ${
                      selectedMusic === m ? 'bg-clipshare-gradient text-white' : 'bg-[#19191F] text-white hover:bg-[#22222b]'
                    }`}
                  >
                    <span className="text-xs font-semibold">{m}</span>
                    {selectedMusic === m && <Check size={16} />}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Privacy Picker Modal */}
        {showPrivacyPicker && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
            <div className="w-full max-w-sm bg-[#101014] border border-[#272730] rounded-3xl p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-white">Privacidade</h3>
                <button onClick={() => setShowPrivacyPicker(false)}>
                  <X size={18} className="text-[#A1A1AA]" />
                </button>
              </div>
              <div className="space-y-2">
                {[
                  { id: 'public', label: 'Público', desc: 'Qualquer pessoa no ClipShare pode assistir' },
                  { id: 'followers', label: 'Seguidores', desc: 'Apenas quem segue você pode assistir' },
                  { id: 'private', label: 'Somente eu', desc: 'Apenas você pode ver este clipe' },
                ].map((opt) => (
                  <div
                    key={opt.id}
                    onClick={() => {
                      setPrivacy(opt.id as any);
                      setShowPrivacyPicker(false);
                    }}
                    className={`p-3 rounded-xl cursor-pointer transition-colors ${
                      privacy === opt.id ? 'bg-[#FF008C]/20 border border-[#FF008C]' : 'bg-[#19191F] border border-[#272730]'
                    }`}
                  >
                    <div className="text-xs font-bold text-white">{opt.label}</div>
                    <div className="text-[11px] text-[#A1A1AA]">{opt.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Template Picker Modal */}
        {showTemplatePicker && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
            <div className="w-full max-w-md bg-[#101014] border border-[#272730] rounded-3xl p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-white">Modelos Prontos</h3>
                <button onClick={() => setShowTemplatePicker(false)}>
                  <X size={18} className="text-[#A1A1AA]" />
                </button>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {TEMPLATES.map((tpl) => (
                  <div
                    key={tpl.name}
                    onClick={() => handleSelectTemplate(tpl)}
                    className="flex items-center gap-3 p-3 rounded-2xl bg-[#19191F] hover:bg-[#22222b] cursor-pointer border border-[#272730] transition-all"
                  >
                    <img
                      src={tpl.coverUrl}
                      alt={tpl.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0"
                    />
                    <div className="flex-1 min-w-0 text-left">
                      <h4 className="text-xs font-bold text-white">{tpl.name}</h4>
                      <p className="text-[11px] text-[#A1A1AA] truncate">{tpl.caption}</p>
                      <span className="text-[10px] text-[#FF008C] font-semibold mt-1 block">
                        🎵 {tpl.musicTitle}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
