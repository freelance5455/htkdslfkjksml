import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart,
  PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';

const BRAND = '#3b82f6';
const OK = '#34d399';
const WARN = '#fbbf24';
const BAD = '#f87171';
const MUTED = '#94a3b8';
const GRID = 'rgba(148,163,184,0.18)';

const axisProps = {
  stroke: MUTED,
  tick: { fill: MUTED, fontSize: 11 },
  tickLine: false,
  axisLine: false,
} as const;

const tooltipStyle = {
  contentStyle: {
    background: 'rgb(13 21 39)',
    border: '1px solid rgba(148,163,184,0.25)',
    borderRadius: 12,
    fontSize: 12,
    color: '#e9effa',
  },
  labelStyle: { color: '#e9effa', fontWeight: 600 },
  itemStyle: { color: '#cdd8ea' },
} as const;

export function TrendChart({ data, height = 220 }: { data: { date: string; accuracy: number; score?: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="accuracyFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={BRAND} stopOpacity={0.45} />
            <stop offset="100%" stopColor={BRAND} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="date" {...axisProps} tickFormatter={(v: string) => v.slice(5)} />
        <YAxis domain={[0, 100]} {...axisProps} width={40} tickFormatter={(v: number) => `${v}%`} />
        <Tooltip {...tooltipStyle} formatter={(value: number, name: string) => [name === 'accuracy' ? `${value}%` : value, name === 'accuracy' ? 'Accuracy' : 'Score %']} />
        <Area type="monotone" dataKey="accuracy" stroke={BRAND} strokeWidth={2.5} fill="url(#accuracyFill)" name="accuracy" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function SubjectBars({ data, height = 240 }: { data: { subject: string; accuracy?: number; mastery?: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }} barCategoryGap={18}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="subject" {...axisProps} interval={0} tickFormatter={(v: string) => v.length > 9 ? `${v.slice(0, 8)}…` : v} />
        <YAxis domain={[0, 100]} {...axisProps} width={40} tickFormatter={(v: number) => `${v}%`} />
        <Tooltip {...tooltipStyle} formatter={(v: number) => [`${v}%`, '']} />
        <Bar dataKey="accuracy" fill={BRAND} radius={[6, 6, 0, 0]} maxBarSize={44} />
        <Bar dataKey="mastery" fill={OK} radius={[6, 6, 0, 0]} maxBarSize={44} />
        <Legend wrapperStyle={{ fontSize: 12, color: MUTED }} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function HoursChart({ data, height = 200 }: { data: { date: string; minutes: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="date" {...axisProps} tickFormatter={(v: string) => v.slice(5)} />
        <YAxis {...axisProps} width={44} tickFormatter={(v: number) => `${Math.round((v / 60) * 10) / 10}h`} />
        <Tooltip {...tooltipStyle} formatter={(v: number) => [`${Math.round((v / 60) * 10) / 10} hours`, 'Studied']} />
        <Bar dataKey="minutes" fill={BRAND} radius={[4, 4, 0, 0]} maxBarSize={28} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function DifficultyRadar({ data, height = 240 }: { data: { difficulty: string; accuracy: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <RadarChart data={data} outerRadius="72%">
        <PolarGrid stroke={GRID} />
        <PolarAngleAxis dataKey="difficulty" tick={{ fill: MUTED, fontSize: 11 }} />
        <Radar dataKey="accuracy" stroke={BRAND} fill={BRAND} fillOpacity={0.3} strokeWidth={2} />
        <Tooltip {...tooltipStyle} formatter={(v: number) => [`${v}%`, 'Accuracy']} />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export function ScoreLine({ data, height = 220 }: { data: { title: string; percent: number }[]; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="title" {...axisProps} tickFormatter={(v: string) => v.length > 10 ? `${v.slice(0, 9)}…` : v} />
        <YAxis domain={[0, 100]} {...axisProps} width={40} tickFormatter={(v: number) => `${v}%`} />
        <Tooltip {...tooltipStyle} formatter={(v: number) => [`${v}%`, 'Score']} />
        <Line type="monotone" dataKey="percent" stroke={OK} strokeWidth={2.5} dot={{ r: 3, fill: OK }} activeDot={{ r: 5 }} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function MistakeBars({ data, height = 240 }: { data: { type: string; count: number }[]; height?: number }) {
  const colors = [BAD, WARN, '#a78bfa', BRAND, OK, '#22d3ee', '#fb923c'];
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
        <CartesianGrid stroke={GRID} horizontal={false} />
        <XAxis type="number" {...axisProps} allowDecimals={false} />
        <YAxis type="category" dataKey="type" {...axisProps} width={130} tickFormatter={(v: string) => v.replace(/-/g, ' ')} />
        <Tooltip {...tooltipStyle} />
        <Bar dataKey="count" radius={[0, 6, 6, 0]} maxBarSize={20}>
          {data.map((_, index) => (
            <Cell key={index} fill={colors[index % colors.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
