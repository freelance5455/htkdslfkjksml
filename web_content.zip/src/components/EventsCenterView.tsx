import React, { useMemo, useState } from 'react';
import { Bell, Check, CheckCheck } from 'lucide-react';
import { ClanDashboardState, ClanEventType } from '../shared/cocData';
import { apiFetchJson } from '../utils/apiClient';
import { formatDateTimeRu, formatRelativeTimeRu } from '../utils/formatters';

interface EventsCenterViewProps {
  state: ClanDashboardState;
  nowMs: number;
  onSelectPlayer: (tag: string) => void;
  onStateUpdated: (nextState: ClanDashboardState) => void;
}

type EventGroupFilter = 'all' | 'upgrades' | 'donations' | 'wars' | 'roster' | 'metrics';

const GROUP_OPTIONS: Array<{ id: EventGroupFilter; label: string }> = [
  { id: 'all', label: 'Все события' },
  { id: 'upgrades', label: 'Улучшения и TH' },
  { id: 'donations', label: 'Пожертвования' },
  { id: 'wars', label: 'Войны' },
  { id: 'roster', label: 'Состав клана' },
  { id: 'metrics', label: 'Опыт и трофеи' },
];

function matchEventGroup(t: ClanEventType, g: EventGroupFilter): boolean {
  if (g === 'all') return true;
  if (g === 'upgrades') {
    return (
      t === 'upgrade_townhall' ||
      t === 'upgrade_hero' ||
      t === 'upgrade_equipment' ||
      t === 'upgrade_troop' ||
      t === 'upgrade_spell' ||
      t === 'upgrade_siege' ||
      t === 'upgrade_pet'
    );
  }
  if (g === 'donations') return t === 'donations_change';
  if (g === 'wars') return t === 'war_result';
  if (g === 'roster') return t === 'roster_join' || t === 'roster_leave' || t === 'roster_role';
  return t === 'progress_metric';
}

const EVENT_TYPE_LABEL: Record<ClanEventType, string> = {
  upgrade_townhall: 'Ратуша',
  upgrade_hero: 'Герой',
  upgrade_equipment: 'Оборудование',
  upgrade_troop: 'Войско',
  upgrade_spell: 'Заклинание',
  upgrade_siege: 'Осадная машина',
  upgrade_pet: 'Питомец',
  progress_metric: 'Прогресс',
  donations_change: 'Пожертвования',
  war_result: 'Клановая война',
  roster_join: 'Вступление',
  roster_leave: 'Выход',
  roster_role: 'Роль в клане',
};

export const EventsCenterView: React.FC<EventsCenterViewProps> = ({
  state,
  nowMs,
  onSelectPlayer,
  onStateUpdated,
}) => {
  const [groupFilter, setGroupFilter] = useState<EventGroupFilter>('all');
  const [playerFilter, setPlayerFilter] = useState<string>('all');
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const unreadCount = useMemo(
    () => state.clanEvents.filter((e) => !e.read).length,
    [state.clanEvents]
  );

  const filteredEvents = useMemo(() => {
    return state.clanEvents.filter((ev) => {
      if (!matchEventGroup(ev.type, groupFilter)) return false;
      if (playerFilter !== 'all' && ev.playerTag !== playerFilter) return false;
      if (unreadOnly && ev.read) return false;
      return true;
    });
  }, [state.clanEvents, groupFilter, playerFilter, unreadOnly]);

  const handleMarkRead = async (eventId?: string) => {
    setBusyId(eventId ?? 'all');
    try {
      const resp = await apiFetchJson<{ state?: ClanDashboardState }>('/api/events/mark-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventId ? { eventId } : { markAll: true }),
      });
      if (resp.state) {
        onStateUpdated(resp.state);
      }
    } finally {
      setBusyId(null);
    }
  };

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Подключите клан на вкладке «Обзор», чтобы получать уведомления об изменениях и событиях клана.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            События клана и уведомления
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Центр событий по данным Supercell API: улучшения, донаты, итоги войн и изменения состава
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <span className="font-mono text-xs text-slate-400 tabular-nums">
            Непрочитанных: <strong className="text-amber-400">{unreadCount}</strong>
          </span>
          <button
            type="button"
            disabled={unreadCount === 0 || busyId === 'all'}
            onClick={() => handleMarkRead()}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-[#121824] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-amber-500/60 hover:text-amber-400 disabled:opacity-45 transition-colors whitespace-nowrap"
          >
            <CheckCheck className="h-3.5 w-3.5" />
            <span>Отметить все прочитанными</span>
          </button>
        </div>
      </section>

      {/* Filter Bar */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 overflow-x-auto pb-1">
            {GROUP_OPTIONS.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => setGroupFilter(g.id)}
                className={`px-3 py-1.5 text-xs rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  groupFilter === g.id
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'bg-[#0B0F17] text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <select
              value={playerFilter}
              onChange={(e) => setPlayerFilter(e.target.value)}
              className="rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-1.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              <option value="all">Все участники</option>
              {state.players.map((p) => (
                <option key={p.tag} value={p.tag}>
                  {p.name} ({p.tag})
                </option>
              ))}
            </select>

            <label className="inline-flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={unreadOnly}
                onChange={(e) => setUnreadOnly(e.target.checked)}
                className="h-3.5 w-3.5 accent-amber-500"
              />
              <span>Только непрочитанные</span>
            </label>
          </div>
        </div>
      </section>

      {/* Events Feed */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] divide-y divide-slate-800/70">
        {filteredEvents.map((ev) => (
          <div
            key={ev.id}
            className={`flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between transition-colors ${
              ev.read ? 'opacity-80' : 'bg-amber-500/[0.03]'
            }`}
          >
            <div className="min-w-0 space-y-1">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                {!ev.read && <span className="h-2 w-2 rounded-full bg-amber-400 shrink-0" />}
                <span className="font-mono text-[11px] font-semibold text-amber-400">
                  {EVENT_TYPE_LABEL[ev.type] ?? ev.type}
                </span>
                <span className="text-slate-600">·</span>
                <span className="font-mono text-[11px] text-slate-400">
                  {formatDateTimeRu(ev.timestamp)} ({formatRelativeTimeRu(ev.timestamp, nowMs)})
                </span>
                {ev.previousSnapshotAt && (
                  <>
                    <span className="text-slate-600">·</span>
                    <span className="font-mono text-[11px] text-slate-500">
                      снимок с {formatDateTimeRu(ev.previousSnapshotAt)}
                    </span>
                  </>
                )}
              </div>

              <div className="flex flex-wrap items-baseline gap-2">
                <span className="text-sm font-semibold text-slate-100">{ev.title}</span>
                {ev.deltaLabel && (
                  <span className="font-mono text-xs font-semibold text-emerald-400">
                    {ev.deltaLabel}
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-400">{ev.description}</p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {ev.playerTag && (
                <button
                  type="button"
                  onClick={() => onSelectPlayer(ev.playerTag!)}
                  className="rounded-md border border-slate-700 bg-[#0B0F17] px-3 py-1.5 text-xs text-slate-200 hover:border-amber-500/60 hover:text-amber-400 whitespace-nowrap"
                >
                  Профиль
                </button>
              )}
              {!ev.read && (
                <button
                  type="button"
                  disabled={busyId === ev.id}
                  onClick={() => handleMarkRead(ev.id)}
                  className="inline-flex items-center gap-1 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-2.5 py-1.5 text-xs text-emerald-300 hover:bg-emerald-500/20 whitespace-nowrap"
                >
                  <Check className="h-3.5 w-3.5" />
                  <span>Прочитано</span>
                </button>
              )}
            </div>
          </div>
        ))}

        {filteredEvents.length === 0 && (
          <div className="p-10 text-center space-y-2">
            <Bell className="mx-auto h-7 w-7 text-slate-600" />
            <div className="text-sm font-medium text-slate-300">Событий не найдено</div>
            <p className="mx-auto max-w-md text-xs text-slate-500 leading-relaxed">
              Новые уведомления формируются автоматически при появлении изменений между снимками (улучшения героев и войск, смена TH, рост донатов, завершение войн, вход/выход участников).
            </p>
          </div>
        )}
      </section>
    </div>
  );
};
