import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";
import { useCallback, useRef, useState, type ReactNode, type TouchEvent } from "react";

const THRESHOLD = 72;

export function PullToRefresh({
  onRefresh,
  children,
  className,
}: {
  onRefresh: () => Promise<unknown> | unknown;
  children: ReactNode;
  className?: string;
}) {
  const startY = useRef(0);
  const pulling = useRef(false);
  const [offset, setOffset] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const onTouchStart = useCallback(
    (e: TouchEvent<HTMLDivElement>) => {
      const el = e.currentTarget;
      if (el.scrollTop > 4 || refreshing) return;
      pulling.current = true;
      startY.current = e.touches[0]?.clientY ?? 0;
    },
    [refreshing],
  );

  const onTouchMove = useCallback(
    (e: TouchEvent<HTMLDivElement>) => {
      if (!pulling.current || refreshing) return;
      const y = e.touches[0]?.clientY ?? 0;
      const dy = y - startY.current;
      if (dy <= 8) {
        setOffset(0);
        return;
      }
      setOffset(Math.min(dy * 0.38, 88));
    },
    [refreshing],
  );

  const onTouchEnd = useCallback(async () => {
    if (!pulling.current) return;
    pulling.current = false;
    if (offset >= THRESHOLD && !refreshing) {
      setRefreshing(true);
      setOffset(52);
      try {
        await onRefresh();
      } catch {
        /* keep the feed alive */
      } finally {
        setRefreshing(false);
        setOffset(0);
      }
    } else {
      setOffset(0);
    }
  }, [offset, onRefresh, refreshing]);

  return (
    <div
      className={cn("scroll-pane relative min-h-0 flex-1 overflow-y-auto", className)}
      style={{ touchAction: "pan-y" }}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onTouchCancel={onTouchEnd}
    >
      <div
        className="pointer-events-none flex items-center justify-center overflow-hidden text-muted-foreground"
        style={{
          height: offset,
          transition: pulling.current
            ? "none"
            : "height var(--motion-fast) var(--ease-smooth-out)",
        }}
        aria-hidden={!refreshing && offset === 0}
      >
        <Loader2 className={cn("size-5", (refreshing || offset > 24) && "animate-spin")} />
      </div>
      {children}
    </div>
  );
}
