import React, { useState } from 'react';
import { KOTLIN_ANDROID_FILES, AndroidCodeFile } from '../data/kotlinCodebase';
import {
  Code2,
  Copy,
  Check,
  Download,
  FileCode,
  FolderGit2,
  Layers,
  Sparkles
} from 'lucide-react';

export const KotlinCodeViewer: React.FC = () => {
  const [activeFile, setActiveFile] = useState<AndroidCodeFile>(KOTLIN_ANDROID_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([activeFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFile.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 p-3 sm:p-5 space-y-4">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-600/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white flex items-center gap-2">
              <span>Native Android (Kotlin & Jetpack Compose)</span>
              <span className="px-2 py-0.5 text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full">
                Android Studio Ready
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Clean architecture with M3 Composables, StateFlow, Coroutines & Firebase Firestore
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Code</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownloadFile}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download {activeFile.filename}</span>
          </button>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-4 min-h-[550px]">
        {/* File Explorer Sidebar */}
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-col space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 px-2 py-1 flex items-center gap-1.5">
            <FolderGit2 className="w-4 h-4 text-indigo-400" />
            <span>Project Files</span>
          </div>

          <div className="space-y-1 overflow-y-auto">
            {KOTLIN_ANDROID_FILES.map((file) => {
              const isActive = activeFile.filename === file.filename;
              return (
                <button
                  key={file.filename}
                  onClick={() => setActiveFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl text-xs transition-all flex items-start gap-2.5 ${
                    isActive
                      ? 'bg-indigo-600/20 text-white border border-indigo-500/50 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                  }`}
                >
                  <FileCode className={`w-4 h-4 shrink-0 mt-0.5 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <div className="min-w-0">
                    <span className="font-semibold block truncate text-slate-200">
                      {file.filename}
                    </span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      {file.description}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Display Area */}
        <div className="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden flex flex-col">
          {/* File Tab Info */}
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300 font-mono">
              <span className="text-indigo-400">📄</span>
              <span className="font-semibold">{activeFile.path}</span>
            </div>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-slate-800 text-slate-400 rounded">
              {activeFile.language}
            </span>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-300 leading-relaxed bg-slate-950/80">
            <pre className="whitespace-pre">
              <code>{activeFile.code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
