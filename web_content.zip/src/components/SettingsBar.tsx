import React, { useState } from "react";
import {
  CompanionPersona,
  USER_MOODS,
  UserMoodOption,
  EmotionKey,
  MemoryItem,
  SuggestedSong,
  MoodTrendPoint,
  ChatMessage,
} from "../types";
import {
  ChevronDown,
  User,
  Sparkles,
  Music,
  Volume2,
  VolumeX,
  RotateCcw,
  Trash2,
  Check,
  Gauge,
  BookHeart,
  Bot,
} from "lucide-react";
import { ExpressiveAvatar } from "./ExpressiveAvatar";
import { EmotionMirrorPanel } from "./EmotionMirrorPanel";

export interface SettingsBarProps {
  isExpanded: boolean;
  onToggleExpanded: () => void;
  userName: string;
  onUpdateUserName: (name: string) => void;
  selectedPersona: CompanionPersona;
  onSelectPersona: (persona: CompanionPersona) => void;
  userMood: string;
  onSelectMood: (mood: UserMoodOption) => void;
  voiceEnabled: boolean;
  onToggleVoice: () => void;
  onTestVoice: () => void;
  speakingRate: number;
  onUpdateSpeakingRate: (rate: number) => void;
  onResetChat: () => void;
  onClearMemories: () => void;
  memoriesCount: number;
  messagesCount: number;

  // Embedded Avatar Props
  currentEmotion: EmotionKey;
  emotionIntensity: number;
  innerThought: string;
  gesture: string;
  isListening: boolean;
  isThinking: boolean;
  isSpeaking: boolean;
  audioLevel: number;
  onAffectionTap: () => void;

  // Embedded Emotion & Memories Panel Props
  emotionHistoryCounts: Record<EmotionKey, number>;
  memories: MemoryItem[];
  suggestedSongs: SuggestedSong[];
  moodTrend: MoodTrendPoint[];
  onAddMemory: (text: string, category: string) => void;
  onRemoveMemory: (id: string) => void;
  onTestEmotion: (emotion: EmotionKey) => void;
  messages: ChatMessage[];
  onSpeakText: (text: string, emotion: EmotionKey) => void;
  onOpenJournalModal?: (moodOption?: UserMoodOption) => void;
}

export const SettingsBar: React.FC<SettingsBarProps> = ({
  isExpanded,
  onToggleExpanded,
  userName,
  onUpdateUserName,
  selectedPersona,
  userMood,
  onSelectMood,
  voiceEnabled,
  onToggleVoice,
  onTestVoice,
  speakingRate,
  onUpdateSpeakingRate,
  onResetChat,
  onClearMemories,
  memoriesCount,
  messagesCount,

  // Avatar props
  currentEmotion,
  emotionIntensity,
  innerThought,
  gesture,
  isListening,
  isThinking,
  isSpeaking,
  audioLevel,
  onAffectionTap,

  // Emotion & Memories Panel props
  emotionHistoryCounts,
  memories,
  suggestedSongs,
  moodTrend,
  onAddMemory,
  onRemoveMemory,
  onTestEmotion,
  messages,
  onSpeakText,
  onOpenJournalModal,
}) => {
  const [tempName, setTempName] = useState(userName);
  const [isSavedNotice, setIsSavedNotice] = useState(false);
  const [activeTab, setActiveTab] = useState<
    "settings" | "avatar" | "emotions" | "memories" | "all"
  >("settings");

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempName.trim()) return;
    onUpdateUserName(tempName.trim());
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2000);
  };

  const handlePresetName = (name: string) => {
    setTempName(name);
    onUpdateUserName(name);
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2000);
  };

  if (!isExpanded) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
    >
      {/* Expanded Modal Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity animate-in fade-in"
        onClick={onToggleExpanded}
        aria-hidden="true"
      />

      {/* Expanded Settings Modal Drawer */}
      <div className="relative z-50 w-full max-w-4xl max-h-[88vh] flex flex-col rounded-t-3xl sm:rounded-3xl border border-slate-700/80 bg-[#0E1424] shadow-2xl animate-in slide-in-from-bottom duration-300 overflow-hidden">
        {/* Pull Handle */}
        <div
          className="mx-auto mt-2.5 h-1.5 w-14 rounded-full bg-slate-700/90 cursor-pointer hover:bg-amber-400/80 transition-colors"
          onClick={onToggleExpanded}
          title="বন্ধ করো"
        />

        {/* Drawer Header */}
        <div className="flex items-center justify-between border-b border-slate-800/90 px-6 py-3.5 bg-[#0C1220]">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_12px_rgba(245,158,11,0.3)] animate-electric-glow">
              <svg className="h-4 w-4" viewBox="0 0 100 100" fill="none">
                <path
                  d="M55 10 L25 54 L48 54 L40 90 L75 46 L52 46 Z"
                  fill="#F59E0B"
                />
              </svg>
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                <span>Thunder টুলস ও সেটিংস</span>
                <span className="rounded border border-amber-500/40 bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-mono text-amber-300 font-bold uppercase">
                  AI
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                অবতার, গানের অনুভূতি, স্মৃতির ডায়েরি ও কন্ঠস্বর নিয়ন্ত্রণ
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onToggleExpanded}
            aria-label="সেটিংস বন্ধ করো"
            className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/70 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
          >
            <span>বন্ধ করো</span>
            <ChevronDown className="h-4 w-4" />
          </button>
        </div>

        {/* Quick Filter Tabs */}
        <div className="flex items-center gap-1.5 border-b border-slate-800/80 px-6 py-2.5 overflow-x-auto no-scrollbar text-xs bg-[#0A0F1D]">
          {[
            { id: "settings", label: "⚙️ সেটিংস ও সম্বোধন" },
            { id: "avatar", label: "⚡ Thunder অবতার" },
            { id: "emotions", label: "🎵 গানের অনুভূতি ও ট্রেন্ড" },
            { id: "memories", label: "📖 স্মৃতির ডায়েরি" },
            { id: "all", label: "সব টুলস" },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`rounded-lg px-3 py-1.5 transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-amber-500 text-slate-950 font-semibold shadow-sm"
                  : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Scrollable Settings Content */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
          {/* TAB 1: AVATAR PRESENCE TOOL */}
          {(activeTab === "all" || activeTab === "avatar") && (
            <div className="rounded-2xl border border-slate-800/90 bg-[#121A2C] p-4.5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <Bot className="h-4 w-4 text-amber-400" />
                  <h3 className="text-sm font-semibold text-slate-200">
                    Thunder ভাই ও অবতার (Avatar Tool)
                  </h3>
                </div>
                <span className="text-xs text-amber-300">
                  মুখে স্পর্শ করে ভালোবাসা জানান
                </span>
              </div>

              <div className="max-w-md mx-auto">
                <ExpressiveAvatar
                  personaName={selectedPersona.name}
                  personaRole={selectedPersona.roleBn}
                  emotionKey={currentEmotion}
                  emotionIntensity={emotionIntensity}
                  innerThought={innerThought}
                  gesture={gesture}
                  isListening={isListening}
                  isThinking={isThinking}
                  isSpeaking={isSpeaking}
                  audioLevel={audioLevel}
                  voiceEnabled={voiceEnabled}
                  onToggleVoice={onToggleVoice}
                  onAffectionTap={onAffectionTap}
                />
              </div>
            </div>
          )}

          {/* TAB 2: SETTINGS & AUDIO CONTROLS */}
          {(activeTab === "all" || activeTab === "settings") && (
            <div className="space-y-4">
              {/* Addressing & Name */}
              <div className="rounded-xl border border-slate-800 bg-[#121A2C] p-4.5">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-amber-400" />
                    <h3 className="text-sm font-semibold text-slate-200">
                      তোমাকে কী বলে ডাকবে? (Addressing)
                    </h3>
                  </div>
                  <span className="font-mono text-xs tabular-nums text-amber-300">
                    বর্তমান ডাক: {userName}
                  </span>
                </div>

                <p className="mt-2.5 text-xs text-slate-400">
                  Thunder ভাই তোমাকে সবসময় পরম সম্মান ও আন্তরিকতায় এই নামে ডাকবে:
                </p>

                <form onSubmit={handleNameSubmit} className="mt-3 flex gap-2">
                  <input
                    type="text"
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    placeholder="যেমন: বস, স্যার, ভাই, বন্ধু..."
                    className="flex-1 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors whitespace-nowrap"
                  >
                    {isSavedNotice ? <Check className="h-3.5 w-3.5" /> : null}
                    <span>{isSavedNotice ? "সংরক্ষিত" : "সেভ"}</span>
                  </button>
                </form>

                {/* Quick Name Presets - "বস" is prominently featured */}
                <div className="mt-3 flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-slate-500">পছন্দের সম্বোধন:</span>
                  {["বস", "স্যার", "ভাই", "বন্ধু"].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => handlePresetName(preset)}
                      className={`rounded-md border px-2.5 py-1 font-medium transition-colors ${
                        userName === preset
                          ? "border-amber-500/50 bg-amber-500/20 text-amber-200 font-bold ring-1 ring-amber-400/40"
                          : "border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Current User Mood */}
              <div className="rounded-xl border border-slate-800 bg-[#121A2C] p-4.5">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2">
                    <Music className="h-4 w-4 text-amber-400" />
                    <h3 className="text-sm font-semibold text-slate-200">
                      মনের অবস্থা (Current Mood)
                    </h3>
                  </div>
                  <span className="text-xs text-amber-300">{userMood}</span>
                </div>

                <p className="mt-2.5 text-xs text-slate-400">
                  মেজাজ পরিবর্তন করলে Thunder সেই অনুযায়ী সান্ত্বনা ও গান সাজেস্ট করবে:
                </p>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {USER_MOODS.map((m) => {
                    const active = userMood === m.labelBn;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => onSelectMood(m)}
                        className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                          active
                            ? "border-amber-500/50 bg-amber-500/15 text-amber-200"
                            : "border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                        }`}
                      >
                        {m.labelBn}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Voice & Audio Controls */}
              <div className="rounded-xl border border-slate-800 bg-[#121A2C] p-4.5">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2">
                    <Volume2 className="h-4 w-4 text-amber-400" />
                    <h3 className="text-sm font-semibold text-slate-200">
                      কণ্ঠস্বর ও অডিও সেটিংস
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={onToggleVoice}
                    className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium border transition-colors ${
                      voiceEnabled
                        ? "border-amber-500/40 bg-amber-500/15 text-amber-200"
                        : "border-slate-700 bg-slate-800 text-slate-400"
                    }`}
                  >
                    {voiceEnabled ? (
                      <>
                        <Volume2 className="h-3 w-3 text-amber-400" />
                        <span>কণ্ঠ চালু</span>
                      </>
                    ) : (
                      <>
                        <VolumeX className="h-3 w-3" />
                        <span>নীরব</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-300">
                      Thunder-এর কণ্ঠস্বর পরীক্ষা করো
                    </p>
                    <p className="text-[11px] text-slate-500">
                      স্বাভাবিক কণ্ঠের টেস্ট বার্তা শুনবে
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={onTestVoice}
                    className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors"
                  >
                    <Volume2 className="h-3.5 w-3.5 text-amber-300" />
                    <span>টেস্ট ভয়েস</span>
                  </button>
                </div>

                {/* Speaking Rate Slider (0.5x to 1.5x) */}
                <div className="mt-4 border-t border-slate-800/80 pt-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Gauge className="h-3.5 w-3.5 text-amber-400" />
                      <span className="text-xs font-medium text-slate-300">
                        কথার গতি (Speaking Rate: 0.5x - 1.5x)
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-semibold tabular-nums text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-md">
                        {speakingRate.toFixed(2)}x
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {speakingRate < 0.85
                          ? "(ধীর / Slower)"
                          : speakingRate > 1.15
                          ? "(দ্রুত / Faster)"
                          : "(স্বাভাবিক / Normal)"}
                      </span>
                    </div>
                  </div>

                  <div className="mt-2.5 flex items-center gap-3">
                    <span className="font-mono text-[11px] text-slate-500">0.5x</span>
                    <input
                      type="range"
                      min="0.5"
                      max="1.5"
                      step="0.05"
                      value={speakingRate}
                      onChange={(e) => onUpdateSpeakingRate(parseFloat(e.target.value))}
                      className="h-2 flex-1 cursor-pointer appearance-none rounded-lg bg-slate-800 accent-amber-500 hover:bg-slate-700"
                    />
                    <span className="font-mono text-[11px] text-slate-500">1.5x</span>
                  </div>

                  {/* Preset quick buttons */}
                  <div className="mt-2.5 flex items-center gap-1.5 text-xs">
                    <span className="text-[11px] text-slate-500">প্রিসেট:</span>
                    {[
                      { rate: 0.75, label: "০.৭৫x (ধীর)" },
                      { rate: 1.0, label: "১.০x (স্বাভাবিক)" },
                      { rate: 1.25, label: "১.২৫x (দ্রুত)" },
                    ].map((p) => (
                      <button
                        key={p.rate}
                        type="button"
                        onClick={() => onUpdateSpeakingRate(p.rate)}
                        className={`rounded-md border px-2 py-0.5 text-[11px] transition-colors ${
                          Math.abs(speakingRate - p.rate) < 0.02
                            ? "border-amber-500/50 bg-amber-500/15 text-amber-200 font-semibold"
                            : "border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Chat Data & Reset Controls */}
              <div className="rounded-xl border border-slate-800 bg-[#121A2C] p-4.5">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-2">
                    <RotateCcw className="h-4 w-4 text-amber-400" />
                    <h3 className="text-sm font-semibold text-slate-200">
                      আড্ডা ও মেমোরি নিয়ন্ত্রণ
                    </h3>
                  </div>
                  <span className="font-mono text-xs tabular-nums text-slate-400">
                    {messagesCount} বার্তা · {memoriesCount} স্মৃতি
                  </span>
                </div>

                <div className="mt-3 space-y-2">
                  <button
                    type="button"
                    onClick={() => {
                      onResetChat();
                      onToggleExpanded();
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900/60 p-2.5 text-xs text-slate-300 hover:border-slate-700 hover:text-white transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <RotateCcw className="h-3.5 w-3.5 text-amber-400" />
                      <span>নতুন আড্ডা শুরু করো (Reset Chat)</span>
                    </span>
                    <span className="text-[11px] text-slate-500">পূর্বের বার্তা মুছবে</span>
                  </button>

                  <button
                    type="button"
                    onClick={onClearMemories}
                    className="w-full flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900/60 p-2.5 text-xs text-slate-300 hover:border-rose-500/40 hover:text-rose-300 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <Trash2 className="h-3.5 w-3.5 text-rose-400" />
                      <span>স্মৃতির ডায়েরি ক্লিয়ার করো</span>
                    </span>
                    <span className="text-[11px] text-slate-500">{memoriesCount}টি স্মৃতি</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3 & 4: EMOTION MIRROR & MEMORIES TOOLS */}
          {(activeTab === "all" || activeTab === "emotions" || activeTab === "memories") && (
            <div className="rounded-2xl border border-slate-800/90 bg-[#121A2C] p-2 sm:p-4">
              <div className="mb-3 flex items-center justify-between border-b border-slate-800/80 px-2 pb-2.5">
                <div className="flex items-center gap-2">
                  <BookHeart className="h-4 w-4 text-amber-400" />
                  <h3 className="text-sm font-semibold text-slate-200">
                    {activeTab === "memories"
                      ? "স্মৃতির ডায়েরি ও ডাউনলোড"
                      : "গানের অনুভূতি, ট্রেন্ড ও স্মৃতি"}
                  </h3>
                </div>
                <span className="text-xs text-slate-400">
                  {memories.length}টি ব্যক্তিগত স্মৃতি
                </span>
              </div>
              <EmotionMirrorPanel
                currentEmotion={currentEmotion}
                emotionIntensity={emotionIntensity}
                emotionHistoryCounts={emotionHistoryCounts}
                memories={memories}
                suggestedSongs={suggestedSongs}
                moodTrend={moodTrend}
                onLogMood={onSelectMood}
                onAddMemory={onAddMemory}
                onRemoveMemory={onRemoveMemory}
                onTestEmotion={onTestEmotion}
                personaName="Thunder"
                userName={userName}
                userMood={userMood}
                messages={messages}
                onSpeakText={onSpeakText}
                onOpenJournalModal={onOpenJournalModal}
              />
            </div>
          )}
        </div>

        {/* Drawer Footer */}
        <div className="border-t border-slate-800/90 p-3.5 flex items-center justify-between gap-3 bg-[#0A0F1D]">
          <span className="text-xs text-slate-400">
            টুলস ও সেটিংস সাথে সাথে সংরক্ষিত হয়
          </span>
          <button
            type="button"
            onClick={onToggleExpanded}
            className="rounded-xl bg-amber-500 px-6 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors"
          >
            সম্পন্ন
          </button>
        </div>
      </div>
    </div>
  );
};
