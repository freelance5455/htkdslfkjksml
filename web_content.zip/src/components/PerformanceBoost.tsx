import React, { useState, useEffect } from 'react';
import { Zap, Trash2, Cpu, BarChart3, TrendingUp } from 'lucide-react';

interface PerformanceBoostProps {
  isActive: boolean;
  onToggle: () => void;
}

interface PerformanceMetrics {
  cpuUsage: number;
  ramUsage: number;
  temperature: number;
  fps: number;
}

export function PerformanceBoost({ isActive, onToggle }: PerformanceBoostProps) {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    cpuUsage: 45,
    ramUsage: 87,
    temperature: 42,
    fps: 60,
  });

  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationHistory, setOptimizationHistory] = useState<string[]>([]);

  useEffect(() => {
    if (!isActive) return;

    // Simulate real-time metrics update
    const interval = setInterval(() => {
      setMetrics(prev => ({
        cpuUsage: Math.max(15, prev.cpuUsage - Math.random() * 5),
        ramUsage: Math.max(50, prev.ramUsage - Math.random() * 8),
        temperature: Math.max(35, prev.temperature - Math.random() * 2),
        fps: Math.min(120, prev.fps + Math.random() * 3),
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive]);

  const handleOptimizeMemory = async () => {
    setIsOptimizing(true);
    addLog('🧹 Starting memory cleanup...');

    // Simulate memory cleanup sequence
    const steps = [
      '📦 Scanning background processes...',
      '🗑️ Clearing cache files...',
      '💾 Defragmenting memory...',
      '⚡ Optimizing system resources...',
      '✅ Cleanup complete!',
    ];

    for (const step of steps) {
      await new Promise(resolve => setTimeout(resolve, 600));
      addLog(step);
    }

    // Simulate improved metrics
    setMetrics(prev => ({
      cpuUsage: Math.max(10, prev.cpuUsage * 0.6),
      ramUsage: Math.max(40, prev.ramUsage * 0.5),
      temperature: Math.max(32, prev.temperature * 0.8),
      fps: Math.min(120, prev.fps * 1.3),
    }));

    setIsOptimizing(false);
  };

  const addLog = (message: string) => {
    setOptimizationHistory(prev => [message, ...prev].slice(0, 10));
  };

  const getHealthColor = (value: number, maxValue: number = 100) => {
    const percentage = (value / maxValue) * 100;
    if (percentage > 80) return 'from-red-500 to-red-600';
    if (percentage > 60) return 'from-orange-500 to-orange-600';
    if (percentage > 40) return 'from-yellow-500 to-yellow-600';
    return 'from-green-500 to-green-600';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Zap className="w-6 h-6 text-red-500" />
            FPS Boost & Performance
          </h2>
          <p className="text-gray-400 text-sm mt-1">Advanced system optimization tools</p>
        </div>

        <button
          onClick={onToggle}
          className={`px-6 py-3 rounded-lg font-bold transition-all duration-300 ${
            isActive
              ? 'bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/50'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
          }`}
        >
          {isActive ? '🔥 Active' : 'Activate'}
        </button>
      </div>

      {/* Performance Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: 'CPU Usage',
            value: metrics.cpuUsage.toFixed(1),
            unit: '%',
            icon: Cpu,
            max: 100,
          },
          {
            label: 'Memory Usage',
            value: metrics.ramUsage.toFixed(1),
            unit: '%',
            icon: BarChart3,
            max: 100,
          },
          {
            label: 'Temperature',
            value: metrics.temperature.toFixed(1),
            unit: '°C',
            icon: TrendingUp,
            max: 85,
          },
          {
            label: 'Game FPS',
            value: metrics.fps.toFixed(0),
            unit: 'fps',
            icon: Zap,
            max: 120,
          },
        ].map((metric, i) => {
          const Icon = metric.icon;
          return (
            <div
              key={i}
              className="bg-gray-800/50 border border-gray-700 rounded-xl p-4 backdrop-blur-sm"
            >
              <div className="flex items-center justify-between mb-3">
                <p className="text-gray-400 text-sm font-medium">{metric.label}</p>
                <Icon className="w-5 h-5 text-gray-500" />
              </div>

              <div className="mb-3">
                <p className="text-2xl font-bold text-white">
                  {metric.value}
                  <span className="text-sm text-gray-400 ml-1">{metric.unit}</span>
                </p>
              </div>

              <div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${getHealthColor(
                    parseFloat(metric.value),
                    metric.max
                  )} transition-all duration-300`}
                  style={{
                    width: `${(parseFloat(metric.value) / metric.max) * 100}%`,
                  }}
                />
              </div>

              <p className="text-xs text-gray-500 mt-2">
                {parseFloat(metric.value) > 80 ? '⚠️ High' : parseFloat(metric.value) > 50 ? '📊 Normal' : '✅ Optimal'}
              </p>
            </div>
          );
        })}
      </div>

      {/* Main Boost Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Memory Cleanup Card */}
        <div className="bg-gradient-to-br from-gray-800/50 to-red-900/20 border border-red-700/30
                        rounded-xl p-6 backdrop-blur-sm space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-red-600/30 rounded-lg flex items-center justify-center">
              <Trash2 className="w-6 h-6 text-red-500" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Memory Cleanup</h3>
              <p className="text-gray-400 text-sm">Remove background processes & cache</p>
            </div>
          </div>

          <div className="bg-gray-900/50 rounded-lg p-4 space-y-2">
            <p className="text-sm text-gray-300">Current Memory Status:</p>
            <div className="flex justify-between items-center">
              <span className="text-white font-bold">{metrics.ramUsage.toFixed(1)}% Used</span>
              <span className="text-green-400 text-sm">
                {((100 - metrics.ramUsage) * 12 / 100).toFixed(1)}GB Free
              </span>
            </div>
          </div>

          <button
            onClick={handleOptimizeMemory}
            disabled={isOptimizing}
            className={`w-full py-3 rounded-lg font-bold transition-all duration-200 flex items-center justify-center gap-2 ${
              isOptimizing
                ? 'bg-gray-700 text-gray-300 cursor-not-allowed'
                : 'bg-red-600 hover:bg-red-700 text-white active:scale-95'
            }`}
          >
            {isOptimizing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Optimizing...
              </>
            ) : (
              <>
                <Trash2 className="w-5 h-5" />
                Clean Memory Now
              </>
            )}
          </button>
        </div>

        {/* Advanced Settings Card */}
        <div className="bg-gradient-to-br from-gray-800/50 to-blue-900/20 border border-blue-700/30
                        rounded-xl p-6 backdrop-blur-sm space-y-4">
          <h3 className="text-lg font-bold text-white mb-4">Optimization Features</h3>

          {[
            { name: 'Aggressive Cache Clearing', enabled: true },
            { name: 'Background Process Termination', enabled: true },
            { name: 'GPU Memory Optimization', enabled: false },
            { name: 'CPU Thermal Management', enabled: true },
            { name: 'Power Profile: Ultra Performance', enabled: isActive },
          ].map((feature, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
              <span className="text-gray-300 text-sm">{feature.name}</span>
              <div className={`w-3 h-3 rounded-full ${feature.enabled ? 'bg-green-500' : 'bg-gray-600'}`} />
            </div>
          ))}
        </div>
      </div>

      {/* Optimization Log */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-4 backdrop-blur-sm">
        <h4 className="text-sm font-bold text-white mb-3">Optimization Log</h4>
        <div className="max-h-40 overflow-y-auto space-y-2">
          {optimizationHistory.length === 0 ? (
            <p className="text-gray-500 text-xs">
              Click "Clean Memory Now" to start optimization...
            </p>
          ) : (
            optimizationHistory.map((log, i) => (
              <p key={i} className="text-xs text-gray-400 font-mono">
                <span className="text-green-400">&gt;</span> {log}
              </p>
            ))
          )}
        </div>
      </div>

      {/* Information Banner */}
      <div className="bg-blue-900/20 border border-blue-700/30 rounded-xl p-4">
        <p className="text-sm text-blue-300">
          ℹ️ <strong>100% Safe & Compliant:</strong> Uses only official Android APIs. No root access required,
          no game server bans, Google Play Protect verified.
        </p>
      </div>
    </div>
  );
}
