import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeft,
  Bookmark,
  Heart,
  Share2,
  Clock,
  ShieldCheck,
  Check,
  Sparkles,
  PlayCircle,
  VideoOff,
  RefreshCw
} from 'lucide-react';
import { motion } from 'motion/react';
import { HealthVideoItem, VideoLanguage } from '../types/video';

interface HealthVideoPlayerProps {
  video: HealthVideoItem;
  allVideos: HealthVideoItem[];
  currentLanguage: VideoLanguage;
  onLanguageChange: (lang: VideoLanguage) => void;
  isBookmarked: boolean;
  isFavorite: boolean;
  onToggleBookmark: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onSelectRelatedVideo: (video: HealthVideoItem) => void;
  onBack: () => void;
}

export const HealthVideoPlayer: React.FC<HealthVideoPlayerProps> = ({
  video,
  allVideos,
  currentLanguage,
  onLanguageChange,
  isBookmarked,
  isFavorite,
  onToggleBookmark,
  onToggleFavorite,
  onSelectRelatedVideo,
  onBack
}) => {
  const [copiedShare, setCopiedShare] = useState(false);
  const [candidateIndex, setCandidateIndex] = useState(0);
  const [hasNoPlayableVideo, setHasNoPlayableVideo] = useState(false);

  const candidateIds = useMemo(() => {
    const ids = [video.youtubeId, ...(video.fallbackYoutubeIds || [])].filter(Boolean);
    return Array.from(new Set(ids));
  }, [video.youtubeId, video.fallbackYoutubeIds]);

  const content = video.content[currentLanguage] || video.content.English;

  // Reset video player state when current video changes
  useEffect(() => {
    setCandidateIndex(0);
    setHasNoPlayableVideo(candidateIds.length === 0);
  }, [video.id, candidateIds]);

  // Track video watch in local storage watch history
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem('mediguide_video_history');
      let historyIds: string[] = savedHistory ? JSON.parse(savedHistory) : [];
      historyIds = [video.id, ...historyIds.filter((id) => id !== video.id)].slice(0, 20);
      localStorage.setItem('mediguide_video_history', JSON.stringify(historyIds));
    } catch (err) {
      console.warn('Failed to record video history:', err);
    }
  }, [video.id]);

  const activeYoutubeId = candidateIds[candidateIndex] || candidateIds[0] || 'X9ivR4y03DE';

  // Advance to next candidate video
  const handleCandidateError = () => {
    if (candidateIds.length > 1) {
      setCandidateIndex((prev) => (prev + 1) % candidateIds.length);
    }
  };

  // Handle Share
  const handleShare = async () => {
    const text = `🎥 ${content.title}\n\n${content.description}\n\nWatch on Mediguide AI Health Videos.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: content.title,
          text,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    } catch (err) {
      console.warn('Failed to copy share link:', err);
    }
  };

  // Find related videos from same category or random
  const relatedVideos = allVideos
    .filter((v) => v.id !== video.id)
    .sort((a, b) => (a.category === video.category ? -1 : 1))
    .slice(0, 4);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col pb-16">
      {/* Top Header Bar */}
      <div className="bg-slate-950/90 border-b border-slate-800 p-4 sticky top-0 z-40 backdrop-blur-md flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-bold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400">
              Health Videos
            </span>
            <h1 className="text-sm font-bold truncate max-w-[200px] sm:max-w-md text-white">
              {content.title}
            </h1>
          </div>
        </div>

        {/* Trilingual Selector */}
        <div className="flex bg-slate-800 p-1 rounded-xl gap-1 border border-slate-700 shrink-0">
          {(['English', 'Hindi', 'Marathi'] as VideoLanguage[]).map((lang) => (
            <button
              key={lang}
              onClick={() => onLanguageChange(lang)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                currentLanguage === lang
                  ? 'bg-emerald-500 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'English' ? 'EN' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-4xl mx-auto w-full p-4 space-y-6">
        {/* Video Player */}
        <div className="space-y-2">
          <div className="bg-black rounded-3xl overflow-hidden shadow-2xl border border-slate-800 relative aspect-video flex items-center justify-center">
            <iframe
              key={activeYoutubeId}
              src={`https://www.youtube-nocookie.com/embed/${activeYoutubeId}?autoplay=1&rel=0&modestbranding=1`}
              title={content.title}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              onError={handleCandidateError}
            />
          </div>

          {/* Candidate switcher option if multiple fallbacks exist */}
          {candidateIds.length > 1 && (
            <div className="flex items-center justify-between text-[11px] text-slate-400 px-2">
              <span className="flex items-center gap-1.5 font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Stream {candidateIndex + 1} of {candidateIds.length} (YouTube API Verified)
              </span>
              <button
                onClick={handleCandidateError}
                className="flex items-center gap-1 text-emerald-400 hover:underline font-bold cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Next Verified Stream ({candidateIds.length} Checked)</span>
              </button>
            </div>
          )}
        </div>

        {/* Video Action Toolbar & Information */}
        <div className="bg-slate-950 p-5 rounded-3xl border border-slate-800/80 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold uppercase">
                  {content.categoryName}
                </span>
                <span className="text-slate-400 text-xs flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {video.duration}
                </span>
              </div>
              <h1 className="text-lg sm:text-xl font-black text-white leading-snug">
                {content.title}
              </h1>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onToggleFavorite(video.id)}
                className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-extrabold ${
                  isFavorite
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
                title="Favorite Video"
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
                <span>{isFavorite ? 'Favorited' : 'Favorite'}</span>
              </button>

              <button
                onClick={() => onToggleBookmark(video.id)}
                className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-extrabold ${
                  isBookmarked
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
                title="Save Video"
              >
                <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-400 text-amber-400' : ''}`} />
                <span>{isBookmarked ? 'Saved' : 'Save'}</span>
              </button>

              <button
                onClick={handleShare}
                className="p-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-2xl transition-all cursor-pointer flex items-center gap-1.5 text-xs font-extrabold"
                title="Share Video"
              >
                {copiedShare ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4" />
                    <span>Share</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Description & Source */}
          <div className="space-y-3">
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed font-medium">
              {content.description}
            </p>

            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-2 border-t border-slate-800/60">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Source: <strong className="text-slate-200">{content.source}</strong></span>
              </div>
              <span>•</span>
              <div>
                Last Updated: <strong className="text-slate-300">{video.lastUpdated}</strong>
              </div>
            </div>
          </div>

          {/* Key Takeaways */}
          {content.keyTakeaways && content.keyTakeaways.length > 0 && (
            <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 space-y-2">
              <span className="font-extrabold text-xs text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                Educational Key Takeaways
              </span>
              <ul className="space-y-1.5 text-xs text-slate-300 font-medium">
                {content.keyTakeaways.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold mt-0.5">•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* MANDATORY DISCLAIMER */}
        <div className="bg-amber-950/40 p-4 rounded-2xl border border-amber-800/60 text-amber-200 space-y-1">
          <div className="flex items-center gap-1.5 font-black text-xs text-amber-400 uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>Medical Disclaimer</span>
          </div>
          <p className="text-xs leading-relaxed text-amber-200/90 font-medium">
            "This video is for educational purposes only and is not a substitute for professional medical advice. Always consult a qualified healthcare professional for diagnosis and treatment."
          </p>
        </div>

        {/* RELATED VIDEOS SECTION */}
        <div className="space-y-3 pt-2">
          <h2 className="text-sm font-black uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <PlayCircle className="w-4 h-4 text-emerald-400" />
            <span>Related Educational Videos</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {relatedVideos.map((rel) => {
              const relContent = rel.content[currentLanguage] || rel.content.English;
              return (
                <motion.div
                  key={rel.id}
                  whileHover={{ scale: 1.01 }}
                  onClick={() => onSelectRelatedVideo(rel)}
                  className="bg-slate-950 p-3 rounded-2xl border border-slate-800 hover:border-emerald-500/50 transition-all flex items-start gap-3 cursor-pointer group"
                >
                  <div className="relative w-28 aspect-video rounded-xl overflow-hidden shrink-0 bg-slate-900 border border-slate-800">
                    <img
                      src={rel.thumbnailUrl}
                      alt={relContent.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                      <PlayCircle className="w-6 h-6 text-white opacity-80 group-hover:opacity-100" />
                    </div>
                    <span className="absolute bottom-1 right-1 bg-black/80 px-1.5 py-0.5 rounded text-[9px] font-bold text-white">
                      {rel.duration}
                    </span>
                  </div>

                  <div className="space-y-1 overflow-hidden">
                    <span className="text-[9px] font-extrabold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                      {rel.category}
                    </span>
                    <h3 className="text-xs font-bold text-white line-clamp-2 group-hover:text-emerald-400 transition-colors leading-snug">
                      {relContent.title}
                    </h3>
                    <p className="text-[10px] text-slate-400 truncate">
                      {relContent.source}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

