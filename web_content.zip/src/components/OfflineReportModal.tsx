import React from 'react';
import { useGame } from '../context/GameContext.tsx';
import { Moon, Clock, CheckCircle2, X } from 'lucide-react';

export const OfflineReportModal: React.FC = () => {
  const { offlineReport, closeOfflineReport } = useGame();

  if (!offlineReport) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-stone-900 border-2 border-stone-700 rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-indigo-950/60 rounded-xl border border-indigo-500/40 text-indigo-300">
              <Moon className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-bold text-indigo-300 text-sm sm:text-base">
                Báo Cáo Nông Trại Khi Vắng Mặt
              </h3>
              <p className="text-xs text-stone-400">
                Tiến trình tự động tích lũy trong thời gian bạn rời game
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={closeOfflineReport}
            className="p-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2 bg-stone-950/80 p-3 rounded-2xl border border-stone-800 text-xs text-stone-300">
          {offlineReport.notes.map((n, idx) => (
            <div key={idx} className="flex items-center gap-2 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>{n}</span>
            </div>
          ))}

          {offlineReport.expGained > 0 && (
            <div className="pt-2 border-t border-stone-800 text-amber-300 font-bold">
              +{offlineReport.expGained} EXP đã được tích lũy an toàn!
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={closeOfflineReport}
          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow transition"
        >
          Xác Nhận & Tiếp Tục
        </button>
      </div>
    </div>
  );
};
