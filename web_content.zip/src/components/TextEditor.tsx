import React, { useRef } from 'react';
import { Trash2, Clipboard, BookOpen, Sparkles, Wand2 } from 'lucide-react';
import { getTeluguTextStats } from '../utils/textProcessor';

interface TextEditorProps {
  text: string;
  onChange: (val: string) => void;
  onOpenSampleModal: () => void;
  onQuickSampleSelect?: (sampleText: string) => void;
}

export const TextEditor: React.FC<TextEditorProps> = ({
  text,
  onChange,
  onOpenSampleModal,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const stats = getTeluguTextStats(text);

  const handleClear = () => {
    onChange('');
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handlePaste = async () => {
    try {
      if (navigator?.clipboard?.readText) {
        const clipText = await navigator.clipboard.readText();
        if (clipText) {
          onChange(text ? `${text}\n${clipText}` : clipText);
        }
      } else {
        alert('Please paste directly using Ctrl+V or Command+V');
      }
    } catch {
      // Fallback focus
      textareaRef.current?.focus();
    }
  };

  // Quick characters helper for typing diacritics / vowels
  const quickChars = ['అ', 'ఆ', 'ఇ', 'ఈ', 'ఉ', 'ఊ', 'ఎ', 'ఏ', 'ఐ', 'ఒ', 'ఓ', 'ఔ', 'ం', 'ః', '్', 'ా', 'ి', 'ీ', 'ు', 'ూ', 'ె', 'ే', 'ై', 'ొ', 'ో', 'ౌ'];

  const handleInsertChar = (char: string) => {
    if (!textareaRef.current) {
      onChange(text + char);
      return;
    }
    const elem = textareaRef.current;
    const start = elem.selectionStart ?? text.length;
    const end = elem.selectionEnd ?? text.length;
    const newText = text.substring(0, start) + char + text.substring(end);
    onChange(newText);
    setTimeout(() => {
      elem.focus();
      elem.setSelectionRange(start + char.length, start + char.length);
    }, 10);
  };

  return (
    <div className="w-full bg-[#101522] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40 relative overflow-hidden group">
      {/* Subtle top ambient gradient */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent" />

      {/* Editor Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <label htmlFor="telugu-text-input" className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span>తెలుగు స్క్రిప్ట్ / టెక్స్ట్ ఎడిటర్</span>
            <span className="text-xs text-slate-500 font-normal hidden sm:inline">(Telugu Text Editor)</span>
          </label>
        </div>

        {/* Action Buttons: Sample, Paste, Clear */}
        <div className="flex items-center gap-2">
          <button
            id="btn-sample-telugu"
            type="button"
            onClick={onOpenSampleModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition-all cursor-pointer"
            title="Load sample Telugu texts"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>ఉదాహరణ స్క్రిప్ట్స్ (Samples)</span>
          </button>

          <button
            id="btn-paste-text"
            type="button"
            onClick={handlePaste}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/80 transition-all cursor-pointer"
            title="Paste from clipboard"
          >
            <Clipboard className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">అంటించు (Paste)</span>
          </button>

          <button
            id="btn-clear-text"
            type="button"
            onClick={handleClear}
            disabled={!text}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/30 text-slate-400 border border-slate-700/80 disabled:opacity-40 disabled:pointer-events-none transition-all cursor-pointer"
            title="Clear text"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">తుడిచివేయి (Clear)</span>
          </button>
        </div>
      </div>

      {/* Main Text Area */}
      <div className="relative">
        <textarea
          id="telugu-text-input"
          ref={textareaRef}
          value={text}
          onChange={(e) => onChange(e.target.value)}
          placeholder="మీ కథ, స్క్రిప్ట్ లేదా టెక్స్ట్ను ఇక్కడ టైప్ చేయండి..."
          rows={6}
          dir="ltr"
          className="w-full bg-[#0a0d14]/80 border border-slate-800 rounded-xl p-4 text-base sm:text-lg text-slate-100 placeholder-slate-500/70 font-telugu leading-relaxed resize-y focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/60 transition-all selection:bg-cyan-500/30 shadow-inner"
        />
      </div>

      {/* Quick Telugu Characters Helper Toolbar */}
      <div className="mt-2.5 flex items-center gap-1 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-slate-800">
        <span className="text-[11px] text-slate-500 font-medium whitespace-nowrap mr-1">
          త్వరిత అక్షరాలు:
        </span>
        {quickChars.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => handleInsertChar(c)}
            className="px-2 py-0.5 rounded bg-slate-800/80 hover:bg-cyan-500/20 hover:text-cyan-300 text-slate-300 text-xs font-telugu transition-colors border border-slate-700/50 cursor-pointer shrink-0"
          >
            {c}
          </button>
        ))}
      </div>

      {/* Footer Stats & Realtime Info */}
      <div className="mt-3 pt-3 border-t border-slate-800/70 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">అక్షరాలు (Chars):</span>
            <span id="char-count" className="font-mono font-bold text-slate-200">
              {stats.chars}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">పదాలు (Words):</span>
            <span id="word-count" className="font-mono font-bold text-slate-200">
              {stats.words}
            </span>
          </div>
          <div className="flex items-center gap-1.5 hidden sm:flex">
            <span className="text-slate-500">వాక్యాలు (Sentences):</span>
            <span id="sentence-count" className="font-mono font-bold text-slate-200">
              {stats.sentences}
            </span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-cyan-400/80" />
          <span>Telugu Unicode & Numerics Auto-Normalizer Active</span>
        </div>
      </div>
    </div>
  );
};
