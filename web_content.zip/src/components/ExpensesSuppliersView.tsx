import React, { useMemo, useState } from 'react';
import type { Expense, StoreData, Supplier } from '../types';
import { fmtMoney, toDateKey, uid } from '../utils';
import { Icon } from './Icon';
import { ConfirmModal, CustomDatePicker, CustomSelect, Modal } from './SharedUI';

interface ExpensesSuppliersViewProps {
  data: StoreData;
  t: Record<string, string>;
  onSaveExpense: (exp: Expense, isEdit: boolean) => void;
  onDeleteExpense: (id: string) => void;
  onSaveSupplier: (sup: Supplier, isEdit: boolean) => void;
  onDeleteSupplier: (id: string) => void;
  onPaySupplier: (supId: string, amount: number) => void;
  notify: (msg: string, type?: 'success' | 'error') => void;
}

export const ExpensesSuppliersView: React.FC<ExpensesSuppliersViewProps> = ({
  data,
  t,
  onSaveExpense,
  onDeleteExpense,
  onSaveSupplier,
  onDeleteSupplier,
  onPaySupplier,
  notify,
}) => {
  const [activeTab, setActiveTab] = useState<'expenses' | 'suppliers'>('expenses');
  const [expModal, setExpModal] = useState(false);
  const [editingExp, setEditingExp] = useState<Expense | null>(null);
  const [deleteExpTarget, setDeleteExpTarget] = useState<Expense | null>(null);
  const [expForm, setExpForm] = useState({
    title: '',
    category: 'Rent',
    amount: '',
    date: toDateKey(new Date()),
    paymentMethod: 'Cash',
    notes: '',
  });

  const [supModal, setSupModal] = useState(false);
  const [editingSup, setEditingSup] = useState<Supplier | null>(null);
  const [deleteSupTarget, setDeleteSupTarget] = useState<Supplier | null>(null);
  const [supForm, setSupForm] = useState({ name: '', company: '', phone: '', address: '', duePayable: '' });
  const [payModalSup, setPayModalSup] = useState<Supplier | null>(null);
  const [payAmt, setPayAmt] = useState('');

  const expCategories = useMemo(
    () =>
      ['Rent', 'Electricity', 'Salary', 'Transport', 'Purchase', 'Maintenance', 'Other'].map((c) => ({
        value: c,
        label: t[`exp_${c}`] || c,
      })),
    [t]
  );

  const paymentOptions = useMemo(
    () => ['Cash', 'bKash', 'Nagad', 'Bank', 'Other'].map((m) => ({ value: m, label: t[m] || m })),
    [t]
  );

  const totalExpenses = useMemo(() => (data.expenses || []).reduce((s, e) => s + Number(e.amount || 0), 0), [data.expenses]);
  const totalPayable = useMemo(() => (data.suppliers || []).reduce((s, x) => s + Number(x.duePayable || 0), 0), [data.suppliers]);

  const openAddExp = () => {
    setEditingExp(null);
    setExpForm({ title: '', category: 'Rent', amount: '', date: toDateKey(new Date()), paymentMethod: 'Cash', notes: '' });
    setExpModal(true);
  };

  const openEditExp = (ex: Expense) => {
    setEditingExp(ex);
    setExpForm({
      title: ex.title,
      category: ex.category,
      amount: String(ex.amount),
      date: toDateKey(ex.date),
      paymentMethod: ex.paymentMethod,
      notes: ex.notes || '',
    });
    setExpModal(true);
  };

  const submitExp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expForm.title.trim() || !expForm.amount || Number(expForm.amount) <= 0) {
      notify(t.fillRequiredFields, 'error');
      return;
    }
    onSaveExpense(
      {
        id: editingExp ? editingExp.id : uid(),
        title: expForm.title.trim(),
        category: expForm.category,
        amount: Number(expForm.amount || 0),
        date: new Date((expForm.date || toDateKey(new Date())) + 'T12:00:00').toISOString(),
        paymentMethod: expForm.paymentMethod,
        notes: expForm.notes.trim(),
      },
      !!editingExp
    );
    setExpModal(false);
  };

  const openAddSup = () => {
    setEditingSup(null);
    setSupForm({ name: '', company: '', phone: '', address: '', duePayable: '0' });
    setSupModal(true);
  };

  const openEditSup = (s: Supplier) => {
    setEditingSup(s);
    setSupForm({
      name: s.name,
      company: s.company || '',
      phone: s.phone || '',
      address: s.address || '',
      duePayable: String(s.duePayable || 0),
    });
    setSupModal(true);
  };

  const submitSup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supForm.name.trim()) {
      notify(t.fillRequiredFields, 'error');
      return;
    }
    onSaveSupplier(
      {
        id: editingSup ? editingSup.id : uid(),
        name: supForm.name.trim(),
        company: supForm.company.trim(),
        phone: supForm.phone.trim(),
        address: supForm.address.trim(),
        duePayable: Math.max(0, Number(supForm.duePayable || 0)),
      },
      !!editingSup
    );
    setSupModal(false);
  };

  const inputClass =
    'w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition';

  return (
    <div className="space-y-4">
      <div className="surface-card p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="segmented-bar">
          <button
            type="button"
            onClick={() => setActiveTab('expenses')}
            className={`segmented-option tabular-nums ${activeTab === 'expenses' ? 'segmented-option-active !text-blue-600' : ''}`}
          >
            {t.expensesTab} ({fmtMoney(totalExpenses)})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('suppliers')}
            className={`segmented-option tabular-nums ${activeTab === 'suppliers' ? 'segmented-option-active !text-blue-600' : ''}`}
          >
            {t.suppliersTab} ({fmtMoney(totalPayable)})
          </button>
        </div>
        {activeTab === 'expenses' ? (
          <button type="button" onClick={openAddExp} className="btn-primary px-4 py-2.5 text-sm">
            <Icon name="plus" className="w-4 h-4" />
            <span>{t.addExpense}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={openAddSup}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold whitespace-nowrap transition"
          >
            <Icon name="plus" className="w-4 h-4" />
            <span>{t.addSupplier}</span>
          </button>
        )}
      </div>

      {activeTab === 'expenses' ? (
        <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left tabular-nums">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3 whitespace-nowrap">{t.date}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.expenseTitle}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.expenseCategory}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.paymentMethod}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.amount}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(data.expenses || []).length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-12 px-4">
                      <p className="text-slate-500 text-sm mb-3">{t.noData}</p>
                      <button
                        type="button"
                        onClick={openAddExp}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700"
                      >
                        <Icon name="plus" className="w-4 h-4" />
                        <span>{t.addExpense}</span>
                      </button>
                    </td>
                  </tr>
                ) : (
                  data.expenses.map((ex) => (
                    <tr key={ex.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 text-xs font-mono text-slate-500 whitespace-nowrap">{toDateKey(ex.date)}</td>
                      <td className="px-4 py-3 min-w-[160px]">
                        <p className="font-bold text-slate-800">{ex.title}</p>
                        {ex.notes && <p className="text-xs text-slate-400">{ex.notes}</p>}
                      </td>
                      <td className="px-4 py-3 text-slate-700 font-medium whitespace-nowrap">{t[`exp_${ex.category}`] || ex.category}</td>
                      <td className="px-4 py-3 whitespace-nowrap">{t[ex.paymentMethod] || ex.paymentMethod}</td>
                      <td className="px-4 py-3 text-right font-bold text-rose-600 whitespace-nowrap">{fmtMoney(ex.amount)}</td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <div className="inline-flex gap-1">
                          <button
                            type="button"
                            onClick={() => openEditExp(ex)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
                          >
                            <Icon name="edit" className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteExpTarget(ex)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                          >
                            <Icon name="trash" className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left tabular-nums">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3 whitespace-nowrap">{t.supplierName}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.companyName}</th>
                  <th className="px-4 py-3 whitespace-nowrap">{t.phone}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.linkedProducts}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.payableBalance}</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(data.suppliers || []).length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-12 px-4">
                      <p className="text-slate-500 text-sm mb-3">{t.noData}</p>
                      <button
                        type="button"
                        onClick={openAddSup}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700"
                      >
                        <Icon name="plus" className="w-4 h-4" />
                        <span>{t.addSupplier}</span>
                      </button>
                    </td>
                  </tr>
                ) : (
                  data.suppliers.map((sup) => {
                    const prodCount = data.products.filter(
                      (p) => p.supplier && (p.supplier === sup.company || p.supplier === sup.name)
                    ).length;
                    return (
                      <tr key={sup.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-4 py-3 font-bold text-slate-800 whitespace-nowrap">{sup.name}</td>
                        <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{sup.company || '-'}</td>
                        <td className="px-4 py-3 text-slate-500 font-mono text-xs whitespace-nowrap">{sup.phone || '-'}</td>
                        <td className="px-4 py-3 text-right font-semibold whitespace-nowrap">{prodCount}</td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <span className={`font-bold ${sup.duePayable > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                            {fmtMoney(sup.duePayable)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            {sup.duePayable > 0 && (
                              <button
                                type="button"
                                onClick={() => {
                                  setPayModalSup(sup);
                                  setPayAmt(String(sup.duePayable));
                                }}
                                className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-bold hover:bg-emerald-100 whitespace-nowrap"
                              >
                                {t.paySupplier}
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => openEditSup(sup)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
                            >
                              <Icon name="edit" className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteSupTarget(sup)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50"
                            >
                              <Icon name="trash" className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Expense Modal */}
      <Modal open={expModal} onClose={() => setExpModal(false)} title={editingExp ? t.editExpense : t.addExpense}>
        <form noValidate onSubmit={submitExp} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.expenseTitle} *</label>
            <input value={expForm.title} onChange={(e) => setExpForm({ ...expForm, title: e.target.value })} className={inputClass} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.expenseCategory}</label>
              <CustomSelect
                value={expForm.category}
                onChange={(val) => setExpForm({ ...expForm, category: val })}
                options={expCategories}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.amount} *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={expForm.amount}
                onChange={(e) => setExpForm({ ...expForm, amount: e.target.value })}
                className={`${inputClass} font-bold tabular-nums`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.date}</label>
              <CustomDatePicker value={expForm.date} onChange={(val) => setExpForm({ ...expForm, date: val })} allowClear={false} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.paymentMethod}</label>
              <CustomSelect
                value={expForm.paymentMethod}
                onChange={(val) => setExpForm({ ...expForm, paymentMethod: val })}
                options={paymentOptions}
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.notes}</label>
            <input value={expForm.notes} onChange={(e) => setExpForm({ ...expForm, notes: e.target.value })} className={inputClass} />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button type="button" onClick={() => setExpModal(false)} className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50">
              {t.cancel}
            </button>
            <button type="submit" className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold">
              {t.save}
            </button>
          </div>
        </form>
      </Modal>

      {/* Supplier Modal */}
      <Modal open={supModal} onClose={() => setSupModal(false)} title={editingSup ? t.editSupplier : t.addSupplier}>
        <form noValidate onSubmit={submitSup} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.supplierName} *</label>
            <input value={supForm.name} onChange={(e) => setSupForm({ ...supForm, name: e.target.value })} className={inputClass} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.companyName}</label>
              <input value={supForm.company} onChange={(e) => setSupForm({ ...supForm, company: e.target.value })} className={inputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.phone}</label>
              <input value={supForm.phone} onChange={(e) => setSupForm({ ...supForm, phone: e.target.value })} className={inputClass} />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.address}</label>
            <input value={supForm.address} onChange={(e) => setSupForm({ ...supForm, address: e.target.value })} className={inputClass} />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.payableBalance}</label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={supForm.duePayable}
              onChange={(e) => setSupForm({ ...supForm, duePayable: e.target.value })}
              className={`${inputClass} font-bold tabular-nums`}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button type="button" onClick={() => setSupModal(false)} className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50">
              {t.cancel}
            </button>
            <button type="submit" className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold">
              {t.save}
            </button>
          </div>
        </form>
      </Modal>

      {/* Pay Supplier Due Modal */}
      <Modal open={!!payModalSup} onClose={() => setPayModalSup(null)} title={`${t.paySupplier} — ${payModalSup?.name || ''}`}>
        <form
          noValidate
          onSubmit={(e) => {
            e.preventDefault();
            const a = Number(payAmt || 0);
            if (a <= 0) {
              notify(t.fillRequiredFields, 'error');
              return;
            }
            if (payModalSup) {
              onPaySupplier(payModalSup.id, a);
              setPayModalSup(null);
            }
          }}
          className="space-y-4"
        >
          <p className="text-sm text-slate-600 tabular-nums">
            {t.payableBalance}: <span className="font-bold text-rose-600">{fmtMoney(payModalSup?.duePayable)}</span>
          </p>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.paidAmount}</label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              max={payModalSup?.duePayable}
              value={payAmt}
              onChange={(e) => setPayAmt(e.target.value)}
              className={`${inputClass} font-bold tabular-nums`}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button type="button" onClick={() => setPayModalSup(null)} className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50">
              {t.cancel}
            </button>
            <button type="submit" className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold">
              {t.confirm}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={!!deleteExpTarget}
        title={t.confirmDeleteTitle}
        message={`${t.confirmDelete} (${deleteExpTarget?.title || ''})`}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onCancel={() => setDeleteExpTarget(null)}
        onConfirm={() => {
          if (deleteExpTarget) onDeleteExpense(deleteExpTarget.id);
          setDeleteExpTarget(null);
        }}
      />

      <ConfirmModal
        open={!!deleteSupTarget}
        title={t.confirmDeleteTitle}
        message={`${t.confirmDelete} (${deleteSupTarget?.name || ''})`}
        confirmLabel={t.delete}
        cancelLabel={t.cancel}
        onCancel={() => setDeleteSupTarget(null)}
        onConfirm={() => {
          if (deleteSupTarget) onDeleteSupplier(deleteSupTarget.id);
          setDeleteSupTarget(null);
        }}
      />
    </div>
  );
};
