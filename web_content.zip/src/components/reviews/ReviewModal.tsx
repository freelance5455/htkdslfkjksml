import React, { useState } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import { Star, X, Check, ThumbsUp } from 'lucide-react';

interface ReviewModalProps {
  bookingId: string;
  providerId: string;
  onClose: () => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  bookingId,
  providerId,
  onClose,
}) => {
  const { submitReview, providers } = useMohalla();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([
    'Arrived On Time',
    'Polite & Respectful',
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const provider = providers.find((p) => p.id === providerId);

  const availableTags = [
    'Arrived On Time',
    'Clean Work & No Mess',
    'Honest Pricing',
    'Polite & Respectful',
    'Expert Diagnostics',
    'Brought Genuine Parts',
  ];

  const handleToggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) {
      alert('Please provide a short comment on your experience.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      submitReview(bookingId, providerId, rating, comment.trim(), selectedTags);
      setIsSubmitting(false);
      onClose();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Rate Your Experience</h3>
            <p className="text-xs text-slate-500">
              For {provider?.businessName || 'Service Provider'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Star selector */}
          <div className="text-center py-2">
            <div className="flex items-center justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onClick={() => setRating(star)}
                  className="p-1 hover:scale-125 transition-transform cursor-pointer"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= rating
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-slate-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            <p className="text-xs font-bold text-slate-700 mt-2">
              {rating === 5 && '⭐⭐⭐⭐⭐ Excellent & Highly Recommended'}
              {rating === 4 && '⭐⭐⭐⭐ Very Good Experience'}
              {rating === 3 && '⭐⭐⭐ Average Job Done'}
              {rating === 2 && '⭐⭐ Below Expectations'}
              {rating === 1 && '⭐ Poor Service'}
            </p>
          </div>

          {/* Quick tags */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Highlight Provider Qualities
            </label>
            <div className="flex flex-wrap gap-1.5">
              {availableTags.map((tag) => {
                const active = selectedTags.includes(tag);
                return (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => handleToggleTag(tag)}
                    className={`text-[11px] px-2.5 py-1 rounded-full border transition-colors cursor-pointer ${
                      active
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800 font-bold'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {active ? '✓ ' : '+ '}
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Comment */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Your Review / Feedback
            </label>
            <textarea
              required
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="How was the punctuality, communication, cleanliness, and price?"
              className="w-full p-3 rounded-xl border border-slate-300 text-xs text-slate-800 focus:border-emerald-600 outline-hidden"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-md cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'Submitting...' : 'Post Verified Review'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
