import React, { useState } from 'react';
import { Logo } from './Logo';
import { Project } from '../types';
import { THEMES, ACCENTS } from '../constants';
import { 
  Plus, 
  FolderOpen, 
  Code2, 
  Trash2, 
  Edit3, 
  Sun, 
  Moon, 
  LogOut, 
  Check, 
  Palette,
  FolderGit2
} from 'lucide-react';

interface HomeViewProps {
  currentProject: Project;
  recentProjects: Project[];
  siteTheme: string;
  accentColor: string;
  userRole?: string;
  onSelectTheme: (themeId: string) => void;
  onSelectAccent: (accentId: string) => void;
  onCreateProject: () => void;
  onOpenProject: (project: Project) => void;
  onImportProject: () => void;
  onDeleteProject: (id: string) => void;
  onRenameProject: (newName: string, id?: string) => void;
  onSignOut?: () => void;
  onNavigateToEditor: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  currentProject,
  recentProjects,
  siteTheme,
  accentColor,
  userRole,
  onSelectTheme,
  onSelectAccent,
  onCreateProject,
  onOpenProject,
  onImportProject,
  onDeleteProject,
  onRenameProject,
  onSignOut,
  onNavigateToEditor,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const isLight = siteTheme === 'vscode-light' || siteTheme === 'github-light';
  const isCappedRole = userRole === 'student' || userRole === 'teacher';

  const handleStartRename = (proj: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(proj.id);
    setEditName(proj.name);
  };

  const handleSaveRename = (id: string) => {
    if (editName.trim()) {
      onRenameProject(editName.trim(), id);
    }
    setEditingId(null);
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 max-w-lg mx-auto flex flex-col justify-between theme-bg-main theme-text-main transition-colors select-none">
      <div className="space-y-6 pt-2">
        {/* Top Header Row */}
        <div className="flex items-center justify-between border-b theme-border pb-4">
          <div className="flex items-center space-x-3">
            <Logo size="lg" showName={true} />
          </div>

          <div className="flex items-center space-x-1">
            <button
              onClick={() => onSelectTheme(isLight ? 'vscode-dark' : 'vscode-light')}
              className="p-2 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded-lg transition-colors cursor-pointer"
              title={isLight ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            >
              {isLight ? (
                <Moon className="w-5 h-5 text-indigo-400" />
              ) : (
                <Sun className="w-5 h-5 text-amber-400" />
              )}
            </button>

            {onSignOut && (
              <button
                onClick={onSignOut}
                className="p-2 theme-text-muted hover:text-red-400 hover:theme-bg-surface-hover rounded-lg transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="space-y-2.5">
          <button
            onClick={onCreateProject}
            className="w-full theme-accent hover:theme-accent-hover font-semibold py-3 px-4 rounded-xl text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>Create Project</span>
          </button>

          <button
            onClick={onImportProject}
            className="w-full font-semibold py-3 px-4 rounded-xl text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer border theme-bg-surface theme-border theme-text-main hover:theme-bg-surface-hover"
          >
            <FolderOpen className="w-4 h-4 text-cyan-400" />
            <span>Open Project / Upload</span>
          </button>

          <button
            onClick={onNavigateToEditor}
            className="w-full border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 font-semibold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer"
          >
            <Code2 className="w-4 h-4" />
            <span>Continue Editing current project</span>
          </button>
        </div>

        {/* Recent Projects List */}
        {recentProjects.length > 0 && (
          <div className="space-y-3 pt-2">
            <h2 className="text-xs font-semibold uppercase tracking-wider theme-text-muted flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <FolderGit2 className="w-3.5 h-3.5 text-[#359efe]" />
                <span>
                  My Projects {isCappedRole ? `(${recentProjects.length} / 2 Max)` : `(${recentProjects.length})`}
                </span>
              </span>
            </h2>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {recentProjects.map((proj) => {
                const isCurrent = proj.id === currentProject?.id;
                const isEditing = editingId === proj.id;

                return (
                  <div
                    key={proj.id}
                    onClick={() => onOpenProject(proj)}
                    className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                      isCurrent
                        ? 'border-[#359efe] bg-[#359efe]/10'
                        : 'theme-border theme-bg-surface hover:theme-bg-surface-hover'
                    }`}
                  >
                    <div className="flex-grow truncate mr-2">
                      {isEditing ? (
                        <input
                          type="text"
                          autoFocus
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          onBlur={() => handleSaveRename(proj.id)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveRename(proj.id);
                            if (e.key === 'Escape') setEditingId(null);
                          }}
                          onClick={(e) => e.stopPropagation()}
                          className="w-full text-xs font-semibold border border-cyan-400 rounded px-2 py-1 outline-none bg-black/40 text-white"
                        />
                      ) : (
                        <div>
                          <div className="font-semibold text-xs truncate flex items-center space-x-2">
                            <span>{proj.name}</span>
                            {isCurrent && (
                              <span className="text-[10px] text-[#359efe] font-bold">
                                (Active)
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] theme-text-muted font-mono mt-0.5">
                            {proj.files.length} files · Updated {new Date(proj.updatedAt).toLocaleDateString()}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center space-x-1 shrink-0">
                      <button
                        onClick={(e) => handleStartRename(proj, e)}
                        className="p-1.5 theme-text-muted hover:text-[#359efe] rounded-lg transition-colors cursor-pointer"
                        title="Rename Project"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      {recentProjects.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteProject(proj.id);
                          }}
                          className="p-1.5 theme-text-muted hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                          title="Delete Project"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Theme Palette Chooser */}
        <div className="space-y-3 pt-2">
          <h2 className="text-xs font-semibold uppercase tracking-wider theme-text-muted flex items-center space-x-1.5">
            <Palette className="w-3.5 h-3.5 text-[#359efe]" />
            <span>Editor Theme & Accent</span>
          </h2>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {Object.values(THEMES).map((th) => {
              const isSelected = siteTheme === th.id;
              return (
                <button
                  key={th.id}
                  onClick={() => onSelectTheme(th.id)}
                  style={{ backgroundColor: th.surface, borderColor: th.border, color: th.text }}
                  className={`p-2.5 rounded-xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                    isSelected ? 'ring-2 ring-[#359efe] shadow-md font-bold' : 'hover:opacity-90'
                  }`}
                >
                  <span className="truncate text-[11px]">{th.name}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-[#359efe] shrink-0 ml-1" />}
                </button>
              );
            })}
          </div>

          {/* Accent Colors */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] theme-text-muted font-medium">Accent Color:</span>
            <div className="flex items-center space-x-2">
              {Object.values(ACCENTS).map((acc) => (
                <button
                  key={acc.id}
                  onClick={() => onSelectAccent(acc.id)}
                  style={{ backgroundColor: acc.color }}
                  className={`w-5 h-5 rounded-full transition-transform cursor-pointer ${
                    accentColor === acc.id ? 'scale-125 ring-2 ring-white shadow-sm' : 'hover:scale-110 opacity-80'
                  }`}
                  title={acc.name}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center py-6 text-[11px] theme-text-muted font-mono border-t theme-border mt-6">
        NEXORA Studio v2.0 · Designed by amaan
      </div>
    </div>
  );
};
