import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { TournamentMatch } from '../types/index.ts';

export const HomeView: React.FC = () => {
  const { setCurrentTab, openJoinModal, setIsDepositModalOpen, showToast } = useApp();

  // Dynamic countdown timers
  const [soloSeconds, setSoloSeconds] = useState(25 * 60 + 14);
  const [squadSeconds, setSquadSeconds] = useState(45 * 60 + 38);

  useEffect(() => {
    const interval = setInterval(() => {
      setSoloSeconds((prev) => (prev > 0 ? prev - 1 : 0));
      setSquadSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  const soloMatchData: TournamentMatch = {
    id: 'solo_home_1',
    matchNumber: '#1042',
    title: 'Solo Battle Royale - Bermuda Survival',
    mode: 'solo',
    map: 'Bermuda',
    kickoffTime: '9.00 PM IST',
    kickoffSubtext: 'Today',
    entryFee: 30,
    bountyOrPrize: '₹20 / Kill',
    bountyDescription: 'Earn ₹20 on every verified in-game kill! 2 kills recovers entry.',
    registeredCount: 32,
    totalCapacity: 48,
    statusBadge: 'Solo Bounty',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDQYORTQBzPK3DcSNwzz7dUFOxMJ-fwJZS9uGByOn6cITRZeiEXSgwNj4bpkKUp7LFWfBD1QmZt5O7x1EnZCip2xWF2YnKqGULpRRRfDTNtOjfojLSyJZRfSNoaQ2LKEVwM_ectW_4KFh7QoTRDT56SEPXtMr_0UAR7OW6wP0EmNg-JHREezOKPesK1GP39HbIDAXJV2JPiGFTLO7w9h1qIbA7mUWPD7ARe24fnCtnzHMcSkrudnkPiXQ',
    imageAlt: 'Bermuda Survival',
  };

  const squadMatchData: TournamentMatch = {
    id: 'squad_home_2',
    matchNumber: '#1045',
    title: 'Squad Battle Royale (4v4/Squads) - Purgatory Showdown',
    mode: 'squad',
    map: 'Purgatory',
    kickoffTime: '11.00 PM IST',
    kickoffSubtext: 'Tonight',
    entryFee: 50,
    bountyOrPrize: '₹200 Prize',
    bountyDescription: 'Disbursed automatically to squad leader upon Booyah closure.',
    registeredCount: 8,
    totalCapacity: 12,
    statusBadge: 'Prime Squad Cup',
    isHot: true,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBSe0QkW9t5GdDiIvVrf51m_kpYB2pxl1ngpijWFGg3cvPh9-4acxgo2yCmpTspPNUW_NM-TuMvDcsN21HI8pxZeL2e4vVtAMlwVFl6_k5w6UYRcz7djHAju7MaZgsyQ9g0FnizEpk4-g6NPsoTAmbvm9pg4V8odbYVXjzyMm9QfpVftM60_TKJi5pSEURA3WlnZAeu6HIvXfaZTr-yJ9r8mXvGa-FqTH87PEk4iGEUA9M7l5919FeO7A',
    imageAlt: 'Squad Battle Royale',
  };

  return (
    <div className="flex flex-col w-full">
      {/* Atmospheric Glow Backdrop */}
      <div className="relative w-full overflow-hidden">
        <div className="absolute -top-32 left-1/4 w-[600px] h-[600px] bg-primary-container/10 rounded-full blur-[140px] pointer-events-none"></div>
        <div className="absolute top-96 right-10 w-[500px] h-[500px] bg-tertiary-container/10 rounded-full blur-[150px] pointer-events-none"></div>

        {/* HERO SECTION */}
        <section className="relative w-full -mt-20 pt-28 pb-16 px-4 sm:px-6 lg:px-10 flex flex-col justify-center min-h-[640px] bg-gradient-to-b from-[#0b0e14] via-[#191c22] to-surface">
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#ab897d_1px,transparent_1px)] [background-size:24px_24px]"></div>
          <div className="relative max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
            {/* Left Hero Messaging */}
            <div className="lg:col-span-7 flex flex-col gap-4 z-10">
              <div className="inline-flex items-center gap-2 self-start px-3 py-1 rounded bg-[#272a31] text-[#7df4ff] shadow-sm">
                <span className="w-2 h-2 rounded-full bg-[#ff5e00] animate-ping"></span>
                <span className="font-label-sm text-label-sm tracking-widest uppercase text-[#00dbe9]">
                  OFFICIAL FREE FIRE CUSTOM ARENA • SEASON 14
                </span>
              </div>
              <h1 className="font-display-xl text-3xl sm:text-5xl lg:text-6xl uppercase text-on-surface tracking-tight leading-none font-bold">
                IGNITE YOUR <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff5e00] via-[#ffcb8d] to-[#ffdbce]">
                  FREE FIRE
                </span>
                <br />
                CHAMPIONSHIP
              </h1>
              <p className="font-body-lg text-base sm:text-lg text-on-surface-variant max-w-xl">
                Daily Solo &amp; Squad Battle Royale Custom Matches with Instant UPI Payouts. Dominate Bermuda and Purgatory, stack kill bounties, and withdraw winnings directly to your bank account within seconds.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => setCurrentTab('tournaments')}
                  className="px-6 sm:px-8 py-3.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-headline-sm text-headline-sm uppercase tracking-wider rounded transition-all duration-300 shadow-[0_0_24px_rgba(255,94,0,0.45)] hover:shadow-[0_0_36px_rgba(255,94,0,0.6)] flex items-center gap-2 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-2xl">sports_esports</span>
                  Explore Tournaments
                </button>
                <button
                  onClick={() => setCurrentTab('wallet')}
                  className="px-5 sm:px-6 py-3.5 bg-[#272a31] hover:bg-[#363940] text-on-surface font-label-lg text-label-lg uppercase rounded transition-all duration-200 shadow-md flex items-center gap-2 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[#00dbe9] text-xl">qr_code_scanner</span>
                  Add Coins via UPI
                </button>
              </div>

              {/* Mini Realtime Trust Badges */}
              <div className="flex flex-wrap items-center gap-6 pt-2 text-on-surface-variant">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-base text-[#00dbe9]">bolt</span>
                  <span className="font-label-md text-label-md uppercase font-semibold">Room ID Sent in App + SMS</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-base text-secondary">security</span>
                  <span className="font-label-md text-label-md uppercase font-semibold">Garena Safe Play</span>
                </div>
              </div>
            </div>

            {/* Right Hero Visual */}
            <div className="lg:col-span-5 relative flex justify-center">
              <div className="relative w-full max-w-md aspect-[4/5] rounded-xl overflow-hidden shadow-2xl bg-surface-container">
                <img
                  className="w-full h-full object-cover"
                  alt="Free Fire battle royale survivor cyborg soldier"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAgA8Sx-0sr22rVd6S-QUEosKtT4qAefLuZ6w3LDuW305CfFELkSgH7XsjsYvb-A0sFJrJHdPnsT42hqe267nwgHsmfYa8pFWDLsfzERQlf2oUDhzINeciIDXJTnRF27f23TyD1prj39jAFiIgO8k1LWRIAzqqXYLmWIOsaX_EMCN56lAXbBqFCGLxcW8N_mbTnsbk8NZz9AQkyx8ktQxw7re3KvLg5o4K9ODajkkDcjRTeOCLqcUDhww"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e14] via-transparent to-transparent"></div>

                {/* Live HUD Card Floater */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded bg-[#0b0e14]/90 backdrop-blur-md shadow-xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded bg-[#ff5e00]/20 flex items-center justify-center text-[#ff5e00]">
                      <span className="material-symbols-outlined text-2xl">military_tech</span>
                    </div>
                    <div>
                      <div className="font-headline-sm text-headline-sm uppercase text-on-surface leading-tight font-bold">
                        ₹1,000 POOL
                      </div>
                      <div className="font-label-sm text-label-sm uppercase text-[#00dbe9]">
                        Live Bermuda Custom
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-2.5 py-0.5 rounded bg-surface-container text-[#ffdbce] font-label-sm text-label-sm uppercase font-bold">
                      25m Left
                    </span>
                  </div>
                </div>

                {/* Kill Bounty Floating Tag */}
                <div className="absolute top-4 right-4 bg-[#0b0e14]/90 backdrop-blur-md px-3.5 py-1.5 rounded shadow-lg flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[#ff5e00] text-base">local_fire_department</span>
                  <span className="font-label-md text-label-md text-on-surface uppercase font-bold">
                    ₹20 / Kill Bounty
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* QUICK STATS BAR */}
        <section className="w-full bg-[#0b0e14] py-6 px-4 sm:px-6 lg:px-10 shadow-inner">
          <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-center gap-4 p-4 rounded bg-[#191c22] shadow-sm hover:bg-[#1d2026] transition-colors">
              <div className="w-12 h-12 rounded bg-[#272a31] flex items-center justify-center text-[#ff5e00] shadow-inner shrink-0">
                <span className="material-symbols-outlined text-2xl">groups</span>
              </div>
              <div>
                <div className="font-headline-md text-headline-md text-on-surface font-bold">24,500+</div>
                <div className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">Active FF Players</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded bg-[#191c22] shadow-sm hover:bg-[#1d2026] transition-colors">
              <div className="w-12 h-12 rounded bg-[#272a31] flex items-center justify-center text-secondary shadow-inner shrink-0">
                <span className="material-symbols-outlined text-2xl">currency_rupee</span>
              </div>
              <div>
                <div className="font-headline-md text-headline-md text-on-surface font-bold">₹12.5L+</div>
                <div className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">Prizes Distributed</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded bg-[#191c22] shadow-sm hover:bg-[#1d2026] transition-colors">
              <div className="w-12 h-12 rounded bg-[#272a31] flex items-center justify-center text-[#00dbe9] shadow-inner shrink-0">
                <span className="material-symbols-outlined text-2xl">verified_user</span>
              </div>
              <div>
                <div className="font-headline-md text-headline-md text-on-surface font-bold">100% Verified</div>
                <div className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">Anti-Cheat Engine</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded bg-[#191c22] shadow-sm hover:bg-[#1d2026] transition-colors">
              <div className="w-12 h-12 rounded bg-[#272a31] flex items-center justify-center text-[#7df4ff] shadow-inner shrink-0">
                <span className="material-symbols-outlined text-2xl">flash_on</span>
              </div>
              <div>
                <div className="font-headline-md text-headline-md text-on-surface font-bold">&lt; 60 Sec</div>
                <div className="font-label-sm text-label-sm uppercase text-on-surface-variant font-semibold">Instant UPI Withdrawals</div>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURED CUSTOM ROOMS */}
        <section className="w-full py-10 px-4 sm:px-6 lg:px-10 max-w-7xl mx-auto flex flex-col gap-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-2">
            <div>
              <div className="font-label-md text-label-md uppercase text-primary tracking-widest flex items-center gap-2 font-bold">
                <span className="material-symbols-outlined text-base">radar</span>
                BATTLE ARENA LOBBIES
              </div>
              <h2 className="font-headline-lg text-2xl sm:text-4xl uppercase text-on-surface font-bold">
                FEATURED CUSTOM ROOMS
              </h2>
            </div>
            <div className="flex items-center gap-2 text-on-surface-variant font-body-sm text-body-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00dbe9] animate-pulse"></span>
              Room ID &amp; Pass auto-unlocked 15m prior to start time
            </div>
          </div>

          {/* Matches Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* MATCH 1: Solo Battle Royale */}
            <div className="group relative rounded-xl bg-surface-container p-6 shadow-xl hover:shadow-[0_0_30px_rgba(255,94,0,0.25)] transition-all duration-300 flex flex-col justify-between overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary-container via-secondary to-primary-container"></div>
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-[#ff5e00] text-[#531900] font-label-sm text-label-sm uppercase font-bold tracking-wider">
                      SOLO
                    </span>
                    <span className="px-2.5 py-0.5 rounded bg-surface-container-high text-on-surface font-label-sm text-label-sm uppercase font-semibold">
                      MAP: BERMUDA
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-0.5 rounded bg-[#0b0e14] text-[#00dbe9]">
                    <span className="material-symbols-outlined text-sm">schedule</span>
                    <span className="font-label-sm text-label-sm uppercase font-bold">
                      Starts in {formatTimer(soloSeconds)}
                    </span>
                  </div>
                </div>

                <div>
                  <h3 className="font-headline-md text-headline-md uppercase text-on-surface group-hover:text-primary transition-colors font-bold">
                    Solo Battle Royale - Bermuda Survival
                  </h3>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    Class: Battle Royale | Version: Mobile Official | Spectator Anti-Cheat: Active
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-2 p-2 rounded bg-[#191c22] shadow-inner">
                  <div className="flex flex-col text-center p-2 bg-surface-container rounded">
                    <span className="font-label-sm text-label-sm uppercase text-on-surface-variant">Entry Fee</span>
                    <span className="font-headline-sm text-headline-sm text-secondary font-bold">₹30</span>
                  </div>
                  <div className="flex flex-col text-center p-2 bg-surface-container rounded">
                    <span className="font-label-sm text-label-sm uppercase text-primary-fixed">Kill Bounty</span>
                    <span className="font-headline-sm text-headline-sm text-[#ff5e00] font-bold">₹20 / Kill</span>
                  </div>
                  <div className="flex flex-col text-center p-2 bg-surface-container rounded">
                    <span className="font-label-sm text-label-sm uppercase text-on-surface-variant">Prize Pool</span>
                    <span className="font-headline-sm text-headline-sm text-[#00dbe9] font-bold">₹1,000</span>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between font-label-sm text-label-sm uppercase text-on-surface-variant">
                    <span>Slots Booked</span>
                    <span className="text-on-surface font-bold">32 / 48 Joined</span>
                  </div>
                  <div className="w-full h-2.5 rounded bg-surface-container-highest overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-secondary to-primary-container rounded" style={{ width: '66.6%' }}></div>
                  </div>
                  <div className="flex justify-between font-label-sm text-label-sm text-on-surface-variant pt-1">
                    <span>16 spots remaining</span>
                    <span className="text-tertiary">Room ID unlocks in 10 mins</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 flex items-center justify-between gap-4 bg-[#0b0e14]/60 -mx-6 -mb-6 p-6">
                <div className="flex flex-col">
                  <span className="font-label-sm text-label-sm uppercase text-on-surface-variant">Total Value</span>
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    ₹30 <span className="font-body-sm text-body-sm text-on-surface-variant font-normal">Coin Balance</span>
                  </span>
                </div>
                <button
                  onClick={() => openJoinModal(soloMatchData)}
                  className="px-6 py-2.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-label-lg text-label-lg uppercase rounded transition-all shadow-md flex items-center gap-2 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-lg">login</span>
                  Join Match (₹30)
                </button>
              </div>
            </div>

            {/* MATCH 2: Squad Battle Royale */}
            <div className="group relative rounded-xl bg-surface-container p-6 shadow-xl hover:shadow-[0_0_30px_rgba(0,219,233,0.25)] transition-all duration-300 flex flex-col justify-between overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-tertiary-container via-tertiary to-tertiary-fixed"></div>
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-[#00dbe9] text-[#00363a] font-label-sm text-label-sm uppercase font-bold tracking-wider">
                      SQUAD (4v4)
                    </span>
                    <span className="px-2.5 py-0.5 rounded bg-surface-container-high text-on-surface font-label-sm text-label-sm uppercase font-semibold">
                      MAP: PURGATORY
                    </span>
                  </div>
                  <div className="flex items-center gap-1 px-2.5 py-0.5 rounded bg-[#0b0e14] text-[#00dbe9]">
                    <span className="material-symbols-outlined text-sm">schedule</span>
                    <span className="font-label-sm text-label-sm uppercase font-bold">
                      Starts in {formatTimer(squadSeconds)}
                    </span>
                  </div>
                </div>

                <div>
                  <h3 className="font-headline-md text-headline-md uppercase text-on-surface group-hover:text-tertiary transition-colors font-bold">
                    Squad Battle Royale (4v4/Squads) - Purgatory Showdown
                  </h3>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    Class: 4-Player Roster | 12 Squad Custom | Standard Esports Gun-Properties Off
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-2 p-2 rounded bg-[#191c22] shadow-inner">
                  <div className="flex flex-col text-center p-2 bg-surface-container rounded">
                    <span className="font-label-sm text-label-sm uppercase text-on-surface-variant">Entry Fee</span>
                    <span className="font-headline-sm text-headline-sm text-secondary font-bold">₹50</span>
                  </div>
                  <div className="flex flex-col text-center p-2 bg-surface-container rounded">
                    <span className="font-label-sm text-label-sm uppercase text-tertiary-fixed font-semibold">Winning Squad</span>
                    <span className="font-headline-sm text-headline-sm text-[#00dbe9] font-bold">₹200 Prize</span>
                  </div>
                  <div className="flex flex-col text-center p-2 bg-surface-container rounded">
                    <span className="font-label-sm text-label-sm uppercase text-on-surface-variant">Team Size</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">4 Players</span>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between font-label-sm text-label-sm uppercase text-on-surface-variant">
                    <span>Squad Slots Registered</span>
                    <span className="text-on-surface font-bold">8 Squads (32 Players) / 12 Squads Joined</span>
                  </div>
                  <div className="w-full h-2.5 rounded bg-surface-container-highest overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-tertiary-container to-tertiary rounded" style={{ width: '66.6%' }}></div>
                  </div>
                  <div className="flex justify-between font-label-sm text-label-sm text-on-surface-variant pt-1">
                    <span>4 Squad slots open</span>
                    <span className="text-tertiary">Room ID unlocks in 30 mins</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 flex items-center justify-between gap-4 bg-[#0b0e14]/60 -mx-6 -mb-6 p-6">
                <div className="flex flex-col">
                  <span className="font-label-sm text-label-sm uppercase text-on-surface-variant">Squad Entry</span>
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    ₹50 <span className="font-body-sm text-body-sm text-on-surface-variant font-normal">/ Squad Leader</span>
                  </span>
                </div>
                <button
                  onClick={() => openJoinModal(squadMatchData)}
                  className="px-6 py-2.5 bg-[#00dbe9] hover:bg-[#00a3ad] text-[#00363a] font-label-lg text-label-lg uppercase rounded transition-all shadow-md flex items-center gap-2 font-bold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-lg">group_add</span>
                  Register Squad (₹50)
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* HOW TO PLAY & WIN REAL CASH */}
        <section className="w-full bg-[#191c22] py-12 px-4 sm:px-6 lg:px-10">
          <div className="max-w-7xl mx-auto flex flex-col gap-8">
            <div className="text-center max-w-2xl mx-auto flex flex-col gap-1">
              <span className="font-label-md text-label-md uppercase text-primary tracking-widest font-bold">
                TRANSPARENT WORKFLOW
              </span>
              <h2 className="font-headline-lg text-2xl sm:text-4xl uppercase text-on-surface font-bold">
                HOW TO PLAY &amp; WIN REAL CASH
              </h2>
              <p className="font-body-md text-body-md text-on-surface-variant">
                Follow these four simple steps from loading coins with UPI to getting automated payouts in your bank.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 relative">
              {/* Step 1 */}
              <div className="relative p-6 rounded-xl bg-surface-container flex flex-col gap-4 shadow-md">
                <div className="w-12 h-12 rounded bg-surface-container-highest flex items-center justify-center font-headline-md text-headline-md text-[#ff5e00] font-bold">
                  01
                </div>
                <div className="flex flex-col gap-1">
                  <h4 className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">Add Coins via UPI</h4>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    Scan direct UPI QR code or pay with GPay, PhonePe, Paytm. Rate is exactly ₹1 = 1 Coin with no hidden platform fee.
                  </p>
                </div>
                <div className="mt-auto pt-2 flex items-center gap-1.5 text-primary font-label-sm text-label-sm uppercase font-semibold">
                  <span className="material-symbols-outlined text-sm">qr_code</span> Auto Credited Instant
                </div>
              </div>

              {/* Step 2 */}
              <div className="relative p-6 rounded-xl bg-surface-container flex flex-col gap-4 shadow-md">
                <div className="w-12 h-12 rounded bg-surface-container-highest flex items-center justify-center font-headline-md text-headline-md text-secondary font-bold">
                  02
                </div>
                <div className="flex flex-col gap-1">
                  <h4 className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">Join Solo or Squad</h4>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    Enter either Solo (₹30) or assemble your team for Squad (₹50) battles. Lock your in-game Free Fire UID name correctly.
                  </p>
                </div>
                <div className="mt-auto pt-2 flex items-center gap-1.5 text-secondary font-label-sm text-label-sm uppercase font-semibold">
                  <span className="material-symbols-outlined text-sm">badge</span> Verified FF UID Match
                </div>
              </div>

              {/* Step 3 */}
              <div className="relative p-6 rounded-xl bg-surface-container flex flex-col gap-4 shadow-md">
                <div className="w-12 h-12 rounded bg-surface-container-highest flex items-center justify-center font-headline-md text-headline-md text-[#00dbe9] font-bold">
                  03
                </div>
                <div className="flex flex-col gap-1">
                  <h4 className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">Get Custom Room ID</h4>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    The Free Fire Custom Room ID and Password are disclosed precisely 15 minutes before match start in the Match Room tab.
                  </p>
                </div>
                <div className="mt-auto pt-2 flex items-center gap-1.5 text-tertiary font-label-sm text-label-sm uppercase font-semibold">
                  <span className="material-symbols-outlined text-sm">lock_open</span> 15m Countdown Reveal
                </div>
              </div>

              {/* Step 4 */}
              <div className="relative p-6 rounded-xl bg-surface-container flex flex-col gap-4 shadow-md">
                <div className="w-12 h-12 rounded bg-surface-container-highest flex items-center justify-center font-headline-md text-headline-md text-[#7df4ff] font-bold">
                  04
                </div>
                <div className="flex flex-col gap-1">
                  <h4 className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">Win &amp; Withdraw</h4>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    Secure kills (₹20 each in Solo) or grab Booyah! Enter your UPI VPA / Phone number and withdraw real rupees instantaneously.
                  </p>
                </div>
                <div className="mt-auto pt-2 flex items-center gap-1.5 text-tertiary-fixed font-label-sm text-label-sm uppercase font-semibold">
                  <span className="material-symbols-outlined text-sm">account_balance</span> 0% TDS Under ₹10k
                </div>
              </div>
            </div>

            {/* Instant Deposit Banner */}
            <div className="w-full p-6 rounded-xl bg-gradient-to-r from-surface-container-high to-surface-container flex flex-col md:flex-row items-center justify-between gap-4 shadow-md">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded bg-[#ff5e00]/20 flex items-center justify-center text-[#ff5e00] shrink-0">
                  <span className="material-symbols-outlined text-2xl">account_balance_wallet</span>
                </div>
                <div>
                  <div className="font-headline-sm text-headline-sm text-on-surface uppercase font-bold">
                    Need Coins To Enter The Arena?
                  </div>
                  <div className="font-body-sm text-body-sm text-on-surface-variant">
                    Top up using Google Pay, PhonePe, Paytm, or BHIM. Zero payment gateway charges.
                  </div>
                </div>
              </div>
              <button
                onClick={() => setCurrentTab('wallet')}
                className="px-6 py-3 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-label-md text-label-md uppercase rounded transition-colors whitespace-nowrap shadow-md flex items-center gap-2 font-bold cursor-pointer"
              >
                <span className="material-symbols-outlined text-base">add_card</span>
                Instant Deposit UPI
              </button>
            </div>
          </div>
        </section>

        {/* LIVE WINNER TELEMETRY */}
        <section className="w-full py-8 px-4 sm:px-6 lg:px-10 max-w-7xl mx-auto flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary font-label-sm text-label-sm uppercase tracking-widest font-bold">
              <span className="material-symbols-outlined text-base">military_tech</span>
              LIVE WINNER TELEMETRY
            </div>
            <div className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold">
              Updated 2m ago
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded bg-surface-container flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-secondary">
                  🏆
                </div>
                <div>
                  <div className="font-label-md text-label-md text-on-surface uppercase font-bold">RAHUL_FF99</div>
                  <div className="font-label-sm text-label-sm text-on-surface-variant">Solo Bermuda • 9 Kills</div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-headline-sm text-headline-sm text-primary font-bold">+₹480</span>
                <div className="font-label-sm text-label-sm text-[#00dbe9]">UPI Paid</div>
              </div>
            </div>

            <div className="p-4 rounded bg-surface-container flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-tertiary">
                  👑
                </div>
                <div>
                  <div className="font-label-md text-label-md text-on-surface uppercase font-bold">TEAM_X_LEGENDS</div>
                  <div className="font-label-sm text-label-sm text-on-surface-variant">Squad Purgatory • 1st</div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-headline-sm text-headline-sm text-[#00dbe9] font-bold">+₹200</span>
                <div className="font-label-sm text-label-sm text-[#00dbe9]">UPI Paid</div>
              </div>
            </div>

            <div className="p-4 rounded bg-surface-container flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-secondary">
                  🎯
                </div>
                <div>
                  <div className="font-label-md text-label-md text-on-surface uppercase font-bold">VIPER_SHOT_07</div>
                  <div className="font-label-sm text-label-sm text-on-surface-variant">Solo Bermuda • 6 Kills</div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-headline-sm text-headline-sm text-primary font-bold">+₹120</span>
                <div className="font-label-sm text-label-sm text-[#00dbe9]">UPI Paid</div>
              </div>
            </div>

            <div className="p-4 rounded bg-surface-container flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center font-headline-sm text-headline-sm text-tertiary">
                  ⚡
                </div>
                <div>
                  <div className="font-label-md text-label-md text-on-surface uppercase font-bold">GHOST_KILLER</div>
                  <div className="font-label-sm text-label-sm text-on-surface-variant">Solo Bermuda • 11 Kills</div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-headline-sm text-headline-sm text-primary font-bold">+₹520</span>
                <div className="font-label-sm text-label-sm text-[#00dbe9]">UPI Paid</div>
              </div>
            </div>
          </div>
        </section>

        {/* FREE FIRE RULES & NOTICE */}
        <section className="w-full py-10 px-4 sm:px-6 lg:px-10 max-w-7xl mx-auto">
          <div className="p-6 sm:p-8 rounded-xl bg-[#191c22] shadow-xl flex flex-col gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded bg-error-container/20 flex items-center justify-center text-error shrink-0">
                <span className="material-symbols-outlined text-2xl">gavel</span>
              </div>
              <div>
                <h3 className="font-headline-md text-xl sm:text-2xl text-on-surface uppercase font-bold">
                  Free Fire Tournament Rulebook &amp; Fair Play Notice
                </h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  Strict compliance mandated across all Solo and Squad custom matches.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-on-surface">
              <div className="p-4 rounded bg-surface-container flex flex-col gap-2">
                <div className="flex items-center gap-2 text-primary font-label-md text-label-md uppercase font-bold">
                  <span className="material-symbols-outlined text-base">block</span>
                  Zero Tolerance for Hacks
                </div>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  Any player caught using headshot configs, location scripts, or altered APKs will be permanently banned with wallet forfeit.
                </p>
              </div>

              <div className="p-4 rounded bg-surface-container flex flex-col gap-2">
                <div className="flex items-center gap-2 text-secondary font-label-md text-label-md uppercase font-bold">
                  <span className="material-symbols-outlined text-base">perm_device_information</span>
                  Mobile-Only Policy
                </div>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  PC Emulators (Bluestacks, LDPlayer) are strictly banned. Only native Android and iOS mobile devices are eligible to join custom rooms.
                </p>
              </div>

              <div className="p-4 rounded bg-surface-container flex flex-col gap-2">
                <div className="flex items-center gap-2 text-tertiary font-label-md text-label-md uppercase font-bold">
                  <span className="material-symbols-outlined text-base">screenshot</span>
                  Kill Proof &amp; Screenshots
                </div>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  Always capture an end-game screenshot or screen recording displaying final match placement and kill tallies in case of dispute.
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 font-label-sm text-label-sm text-on-surface-variant uppercase">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-tertiary text-sm">support_agent</span>
                Need assistance? Arbiters available 24/7 on WhatsApp &amp; Discord
              </div>
              <button
                onClick={() => {
                  setCurrentTab('tournaments');
                  setTimeout(() => {
                    document.getElementById('rules-section')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                }}
                className="text-primary hover:underline flex items-center gap-1 font-bold cursor-pointer"
              >
                Read Complete 18-Rule Guidelines <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
