import React from 'react';
import {
  Upload, Scissors, LayoutTemplate, Wand2, Plus, Sparkles,
  Play, Clock, ArrowRight, ShieldCheck, Video, Zap
} from 'lucide-react';
import { VideoProject, VideoTemplate } from '../types/project';
import { VIDEO_TEMPLATES } from '../data/templates';
import { formatTime } from '../utils/videoMath';

interface HomeViewProps {
  onNewProject: () => void;
  onUploadClick: () => void;
  onOpenSplitter: () => void;
  onOpenTemplates: () => void;
  onOpenEditor: () => void;
  onOpenAICommand: () => void;
  onOpenAITools: () => void;
  onLoadSample: () => void;
  isLoadingSample: boolean;
  projects: VideoProject[];
  onSelectProject: (p: VideoProject) => void;
  onSelectTemplate: (t: VideoTemplate) => void;
  lang: 'ar' | 'en';
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNewProject,
  onUploadClick,
  onOpenSplitter,
  onOpenTemplates,
  onOpenEditor,
  onOpenAICommand,
  onOpenAITools,
  onLoadSample,
  isLoadingSample,
  projects,
  onSelectProject,
  onSelectTemplate,
  lang
}) => {
  const topTemplates = VIDEO_TEMPLATES.slice(0, 4);

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-8 pb-28">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-950/80 via-[#13122c] to-[#0c0d1b] border border-purple-800/40 p-6 sm:p-10 shadow-2xl">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/40 border border-purple-600/40 text-purple-300 text-xs font-semibold backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>{lang === 'ar' ? 'الجيل الجديد من مونتاج الفيديو بالذكاء الاصطناعي' : 'Next-Gen AI Video Montage Studio'}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            <span>Designo </span>
            <span className="bg-gradient-to-r from-purple-400 via-indigo-300 to-pink-400 bg-clip-text text-transparent">
              {lang === 'ar' ? 'اصنع فيديوك بطريقتك' : 'Create Your Video'}
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            {lang === 'ar'
              ? 'محرر فيديو ذكي يدمج بين تقسيم المقاطع الدقيق، تحويل الأبعاد العمودية مع خلفيات ضبابية، القوالب الجاهزة، وأوامر الذكاء الاصطناعي باللغة الطبيعية.'
              : 'Smart video editor featuring precision segment splitting, vertical aspect transforms with smart blur, 16 templates, and AI command execution.'}
          </p>

          {/* Core Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={onUploadClick}
              className="py-3 px-5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-purple-900/40 transition active:scale-95 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>{lang === 'ar' ? 'رفع فيديو من هاتفك' : 'Upload Video'}</span>
            </button>

            <button
              onClick={onLoadSample}
              disabled={isLoadingSample}
              className="py-3 px-4 rounded-xl bg-purple-950/60 hover:bg-purple-900/70 border border-purple-700/50 text-purple-200 font-semibold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>
                {isLoadingSample
                  ? (lang === 'ar' ? 'جاري تجهيز الفيديو...' : 'Loading demo...')
                  : (lang === 'ar' ? 'تجربة فيديو افتراضي فوري' : 'Try Instant Demo Video')}
              </span>
            </button>

            <button
              onClick={onOpenAICommand}
              className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-xs sm:text-sm flex items-center gap-2 transition cursor-pointer"
            >
              <Wand2 className="w-4 h-4 text-purple-400" />
              <span>{lang === 'ar' ? 'أمر بالذكاء الاصطناعي' : 'AI Command'}</span>
            </button>
          </div>
        </div>

        {/* Decorative Glowing Elements */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 rounded-full bg-purple-600/20 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-indigo-600/20 blur-3xl pointer-events-none" />
      </div>

      {/* Feature Grid Shortcut Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {[
          {
            titleAr: 'تقسيم الفيديو',
            titleEn: 'Smart Splitter',
            descAr: '10s, 30s, 50s وتصدير ZIP',
            descEn: '10s, 30s, 50s & ZIP export',
            icon: <Scissors className="w-5 h-5 text-indigo-400" />,
            action: onOpenSplitter,
            color: 'from-indigo-600/20 to-purple-600/20 border-indigo-700/30'
          },
          {
            titleAr: 'القوالب الجاهزة',
            titleEn: '16 Ready Templates',
            descAr: 'TikTok, Reels, Gaming & Gold',
            descEn: 'TikTok, Reels, Sports & Gold',
            icon: <LayoutTemplate className="w-5 h-5 text-pink-400" />,
            action: onOpenTemplates,
            color: 'from-pink-600/20 to-purple-600/20 border-pink-700/30'
          },
          {
            titleAr: 'محرر الفيديو',
            titleEn: 'Video Studio',
            descAr: 'الأبعاد، الألوان، والنصوص',
            descEn: 'Canvas, aspect, colors & titles',
            icon: <Video className="w-5 h-5 text-purple-400" />,
            action: onOpenEditor,
            color: 'from-purple-600/20 to-indigo-600/20 border-purple-700/30'
          },
          {
            titleAr: 'أدوات AI والصوت',
            titleEn: 'AI Narration & Search',
            descAr: 'TTS، بحث Google، وتحليل الصور',
            descEn: 'TTS, Google Search & Images',
            icon: <Zap className="w-5 h-5 text-amber-400" />,
            action: onOpenAITools,
            color: 'from-amber-600/20 to-orange-600/20 border-amber-700/30'
          },
        ].map((item, idx) => (
          <div
            key={idx}
            onClick={item.action}
            className={`p-4 rounded-2xl bg-gradient-to-br ${item.color} border hover:border-purple-500/60 shadow-lg cursor-pointer transition hover:-translate-y-1`}
          >
            <div className="p-2.5 rounded-xl bg-black/40 w-fit mb-3">{item.icon}</div>
            <h3 className="font-bold text-sm text-white">
              {lang === 'ar' ? item.titleAr : item.titleEn}
            </h3>
            <p className="text-[11px] text-slate-400 mt-1">
              {lang === 'ar' ? item.descAr : item.descEn}
            </p>
          </div>
        ))}
      </div>

      {/* Big AI Command Prompt Card ("ماذا تريد أن أفعل بالفيديو؟") */}
      <div className="bg-[#111224] border border-purple-800/40 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex items-center gap-2 text-white font-bold text-base">
          <Wand2 className="w-5 h-5 text-purple-400" />
          <span>{lang === 'ar' ? 'ماذا تريد أن أفعل بالفيديو؟' : 'What do you want to do with the video?'}</span>
        </div>
        <p className="text-xs text-slate-400">
          {lang === 'ar'
            ? 'اكتب أمرك مثل: "قسّم الفيديو كل 40 ثانية واجعله عمودياً 9:16 مع خلفية ضبابية"'
            : 'Type instructions like: "Split every 40s, make vertical 9:16 with blur, and add my title"'}
        </p>
        <button
          onClick={onOpenAICommand}
          className="w-full py-3 px-4 rounded-xl bg-[#090a14] hover:bg-[#0d0e1c] border border-purple-800/40 text-purple-200 text-xs sm:text-sm font-medium text-start flex items-center justify-between transition cursor-pointer"
        >
          <span>{lang === 'ar' ? 'انقر هنا لكتابة أمرك للذكاء الاصطناعي...' : 'Click here to write natural instructions...'}</span>
          <ArrowRight className="w-4 h-4 text-purple-400" />
        </button>
      </div>

      {/* Top Templates Carousel / Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <LayoutTemplate className="w-5 h-5 text-purple-400" />
            <span>{lang === 'ar' ? 'القوالب الأكثر استخداماً' : 'Popular Templates'}</span>
          </h2>
          <button
            onClick={onOpenTemplates}
            className="text-xs text-purple-300 hover:text-purple-200 font-semibold cursor-pointer"
          >
            {lang === 'ar' ? 'عرض جميع الـ 16 قالباً ←' : 'View all 16 templates →'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {topTemplates.map((tpl) => (
            <div
              key={tpl.id}
              onClick={() => onSelectTemplate(tpl)}
              className="bg-[#111224] border border-purple-900/40 hover:border-purple-500 rounded-2xl overflow-hidden cursor-pointer transition hover:-translate-y-1 shadow-lg"
            >
              <div className={`h-28 bg-gradient-to-br ${tpl.bgGradient} p-3 flex flex-col justify-between`}>
                <span
                  style={{ backgroundColor: tpl.accentColor }}
                  className="text-[9px] uppercase font-black px-1.5 py-0.5 rounded text-white self-start"
                >
                  {tpl.badgeText}
                </span>
                <span className="text-xs font-bold text-white drop-shadow truncate">
                  {tpl.defaultTitle}
                </span>
              </div>
              <div className="p-3">
                <div className="font-bold text-xs text-white">{lang === 'ar' ? tpl.nameAr : tpl.nameEn}</div>
                <div className="text-[10px] text-slate-400 mt-1 line-clamp-1">{tpl.descriptionAr}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Projects Section */}
      {projects.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-400" />
            <span>{lang === 'ar' ? 'المشاريع الأخيرة' : 'Recent Projects'}</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {projects.slice(0, 3).map((p) => (
              <div
                key={p.id}
                onClick={() => onSelectProject(p)}
                className="p-4 rounded-xl bg-[#111224] border border-purple-900/40 hover:border-purple-600/50 transition cursor-pointer flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-xs text-white truncate max-w-[180px]">{p.name}</div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    {p.aspectRatio} • {formatTime(p.duration || 60)}
                  </div>
                </div>
                <Play className="w-4 h-4 text-purple-400" />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
