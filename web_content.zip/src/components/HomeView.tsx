import React from 'react';
import { useApp } from '../context/AppContext';
import { EbookCard } from './EbookCard';
import {
  Sparkles,
  ArrowRight,
  Search,
  BookOpen,
  Award,
  ShieldCheck,
  TrendingUp,
  FileCheck2,
  Calendar,
  Layers,
  Percent,
  CheckCircle2,
  Train,
  ShieldAlert,
  Landmark,
  Briefcase,
  Crosshair,
  ExternalLink,
  ChevronRight,
  Flame,
  Zap,
  Tag
} from 'lucide-react';

interface HomeViewProps {
  onOpenSearch: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onOpenSearch }) => {
  const {
    t,
    ebooks,
    categories,
    examUpdates,
    currentAffairs,
    setActiveTab,
    setSelectedCategory,
    setMockTestOpen,
    setSelectedEbook,
    showToast
  } = useApp();

  // Section Filters
  const popularEbooks = ebooks.slice(0, 4);
  const bestSellers = ebooks.filter((b) => b.isBestseller).slice(0, 4);
  const newArrivals = ebooks.filter((b) => b.isNewArrival || b.edition.includes('2026')).slice(0, 4);
  const freeEbooks = ebooks.filter((b) => b.isFree);
  const assamSpecialBooks = ebooks.filter((b) => b.categoryId.includes('assam') || b.language === 'Assamese').slice(0, 4);
  const comboOffers = ebooks.filter((b) => b.isComboOffer || b.discountPercent >= 65);
  const recommendedBooks = ebooks.filter((b) => b.rating >= 4.85).slice(0, 4);

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'railway': return Train;
      case 'assam-police': return ShieldAlert;
      case 'assam-govt-jobs': return Landmark;
      case 'ssc-central': return Award;
      case 'banking-finance': return Briefcase;
      case 'defence-tech': return Crosshair;
      default: return BookOpen;
    }
  };

  return (
    <div className="space-y-10 sm:space-y-14 pb-12">
      {/* 1. Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#0B192C] via-[#10243E] to-[#1E3E62] text-white pt-8 sm:pt-14 pb-12 sm:pb-16 px-4 sm:px-8 border-b-4 border-amber-400 shadow-xl">
        {/* Glow circles */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
          <div className="lg:col-span-7 space-y-4 sm:space-y-5 text-center lg:text-left">
            {/* Pill */}
            <div className="inline-flex items-center gap-2 bg-amber-400/15 border border-amber-400/30 text-amber-300 px-3.5 py-1.5 rounded-full text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>NEXA EXAM BOOKS • 2026 EDITION</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-5xl font-black tracking-tight leading-[1.15] text-white">
              {t.tagline}
            </h1>

            <p className="text-base sm:text-xl font-medium text-slate-200 max-w-xl mx-auto lg:mx-0">
              {t.subtitle}
            </p>

            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto lg:mx-0 leading-relaxed">
              Target ADRE Class III & IV, Assam Police SI & Constable, Railway NTPC/ALP, SSC CGL & GD, and State Banking exams with certified syllabus guides and offline HTML downloads.
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3">
              <button
                onClick={() => {
                  setActiveTab('categories');
                  window.scrollTo({ top: 300, behavior: 'smooth' });
                }}
                className="w-full sm:w-auto bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm px-7 py-3.5 rounded-xl shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center gap-2 group hover:scale-105"
              >
                <span>{t.exploreNow}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => setMockTestOpen(true)}
                className="w-full sm:w-auto bg-slate-800/90 hover:bg-slate-800 text-slate-100 font-bold text-sm px-6 py-3.5 rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-2 hover:border-amber-400/50"
              >
                <FileCheck2 className="w-4 h-4 text-amber-400" />
                <span>Take Live Mini Mock Test</span>
              </button>
            </div>

            {/* Quick Stats Banner */}
            <div className="pt-4 grid grid-cols-3 gap-2 max-w-md mx-auto lg:mx-0 border-t border-slate-700/60 text-center">
              <div>
                <span className="text-base sm:text-lg font-black text-amber-400">100%</span>
                <span className="block text-[10px] sm:text-[11px] text-slate-300">Verified Syllabus</span>
              </div>
              <div>
                <span className="text-base sm:text-lg font-black text-white">40,000+</span>
                <span className="block text-[10px] sm:text-[11px] text-slate-300">MCQs Solved</span>
              </div>
              <div>
                <span className="text-base sm:text-lg font-black text-emerald-400">Offline</span>
                <span className="block text-[10px] sm:text-[11px] text-slate-300">HTML Download</span>
              </div>
            </div>
          </div>

          {/* Right Hero Visual Cards */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-sm">
              {/* Highlight Card */}
              <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 sm:p-5 text-white shadow-2xl relative overflow-hidden">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-amber-400" /> Most Enrolled Guide 2026
                  </span>
                  <span className="text-[10px] bg-emerald-500 text-slate-950 font-extrabold px-2 py-0.5 rounded">
                    SLRC OFFICIAL
                  </span>
                </div>

                <div className="py-4 flex gap-3.5 items-center">
                  <div className="w-16 h-24 rounded-md bg-gradient-to-tr from-[#0F172A] to-[#1E3E62] p-2 flex flex-col justify-between text-white shrink-0 shadow-md border-l-4 border-l-amber-400">
                    <span className="text-[7px] font-bold text-amber-300">ADRE 2026</span>
                    <span className="text-[9px] font-extrabold leading-tight">Grade III Guide</span>
                    <span className="text-[7px] bg-black/40 px-1 rounded text-center">Assamese</span>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-white leading-snug">
                      Assam Direct Recruitment (ADRE) Grade III Complete Guide
                    </h4>
                    <p className="text-xs text-slate-300 mt-1">
                      Ancient & Modern Assam History • 5000+ MCQs • 5 Mock Tests
                    </p>
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className="text-lg font-black text-amber-400">₹199</span>
                      <span className="text-xs text-slate-400 line-through">₹499</span>
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-1.5 rounded">
                        60% OFF
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    const adreBook = ebooks.find((b) => b.id === 'nx-adre-gr3-mastery') || ebooks[0];
                    setSelectedEbook(adreBook);
                  }}
                  className="w-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs py-2.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5"
                >
                  <span>Quick View Book Details</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Search Box Bar */}
        <div className="max-w-xl mx-auto mt-6 md:hidden">
          <button
            onClick={onOpenSearch}
            className="w-full flex items-center gap-3 bg-slate-900/90 text-slate-400 px-4 py-3 rounded-xl border border-slate-700 text-left shadow-lg text-xs"
          >
            <Search className="w-4 h-4 text-amber-400" />
            <span className="truncate">{t.searchPlaceholder}</span>
          </button>
        </div>
      </section>

      {/* Main Home Sections Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12 sm:space-y-16">
        {/* 2. Explore Categories */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 block">
                Official Exam Verticals
              </span>
              <h2 className="text-lg sm:text-2xl font-black text-[#0B192C]">
                Explore by Exam Category
              </h2>
            </div>
            <button
              onClick={() => {
                setActiveTab('categories');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-xs sm:text-sm font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1"
            >
              <span>{t.viewAll}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {categories.map((cat) => {
              const Icon = getCategoryIcon(cat.id);
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setActiveTab('categories');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="group bg-white p-4 rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-lg transition-all text-left flex flex-col justify-between h-32"
                >
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 group-hover:bg-amber-100 text-slate-700 group-hover:text-amber-700 flex items-center justify-center transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-bold text-slate-400 group-hover:text-slate-700 font-mono">
                      {cat.count}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-slate-900 group-hover:text-blue-900 transition-colors line-clamp-2 leading-tight">
                      {cat.name}
                    </h3>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* 3. Limited-Time Discount Banner */}
        <section className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 rounded-2xl p-5 sm:p-6 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-slate-950 text-amber-400 flex items-center justify-center font-black text-xl shrink-0 shadow-md">
              %
            </div>
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider bg-slate-950 text-amber-300 px-2 py-0.5 rounded">
                LIMITED-TIME COUPON
              </span>
              <h3 className="text-base sm:text-lg font-black mt-1">
                Flat 20% OFF with Promo Code: <span className="underline decoration-slate-950 font-mono">NEXA20</span>
              </h3>
              <p className="text-xs font-semibold text-slate-900 mt-0.5">
                Applicable on all Railway, Assam Police, ADRE, and SSC ebook orders!
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setActiveTab('categories');
              showToast('Coupon NEXA20 copied! Apply it in your shopping cart.', 'info');
            }}
            className="shrink-0 bg-slate-950 hover:bg-slate-900 text-amber-400 font-black text-xs sm:text-sm px-6 py-3 rounded-xl shadow-md transition-all hover:scale-105"
          >
            Claim 20% Discount Now
          </button>
        </section>

        {/* 4. Popular Ebooks */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 block">
                Trending Choice
              </span>
              <h2 className="text-lg sm:text-2xl font-black text-[#0B192C]">
                Popular Exam Ebooks
              </h2>
            </div>
            <button
              onClick={() => {
                setActiveTab('categories');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-xs sm:text-sm font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1"
            >
              <span>{t.viewAll}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
            {popularEbooks.map((book) => (
              <EbookCard key={book.id} ebook={book} />
            ))}
          </div>
        </section>

        {/* 5. Special Assam Exams Section */}
        <section className="bg-gradient-to-br from-emerald-950 via-[#064E3B] to-[#047857] text-white rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
            <div>
              <span className="text-xs font-bold text-amber-300 bg-amber-400/20 px-2.5 py-0.5 rounded uppercase tracking-wider">
                Assam State Recruitment Special
              </span>
              <h2 className="text-xl sm:text-3xl font-black text-white mt-1">
                Assam Police & Direct Recruitment (ADRE 2.0)
              </h2>
              <p className="text-xs sm:text-sm text-emerald-100 mt-1 max-w-2xl">
                Dedicated guides written strictly following SLRC & SLPRB Assam patterns in Assamese and English mediums with in-depth local history and geography.
              </p>
            </div>

            <button
              onClick={() => {
                setSelectedCategory('assam-govt-jobs');
                setActiveTab('categories');
              }}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm px-5 py-2.5 rounded-xl transition-all shadow-md shrink-0"
            >
              View All Assam Exam Books
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
            {assamSpecialBooks.map((book) => (
              <EbookCard key={book.id} ebook={book} />
            ))}
          </div>
        </section>

        {/* 6. Best Sellers */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 block">
                Top Rated by Students
              </span>
              <h2 className="text-lg sm:text-2xl font-black text-[#0B192C]">
                Best Sellers Collection
              </h2>
            </div>
            <button
              onClick={() => {
                setActiveTab('categories');
              }}
              className="text-xs sm:text-sm font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1"
            >
              <span>{t.viewAll}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
            {bestSellers.map((book) => (
              <EbookCard key={book.id} ebook={book} />
            ))}
          </div>
        </section>

        {/* 7. Super Saver Combo Packs */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-rose-600 block">
                Save Up to 69%
              </span>
              <h2 className="text-lg sm:text-2xl font-black text-[#0B192C]">
                Combo Offers & All-In-One Packs
              </h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {comboOffers.map((combo) => (
              <div
                key={combo.id}
                onClick={() => setSelectedEbook(combo)}
                className="bg-white border-2 border-amber-300 rounded-2xl p-5 shadow-md hover:border-amber-500 cursor-pointer transition-all flex flex-col sm:flex-row items-center gap-4 group"
              >
                <div className={`w-28 h-36 rounded-lg bg-gradient-to-tr ${combo.coverGradient} text-white p-2.5 flex flex-col justify-between shrink-0 shadow-md group-hover:scale-105 transition-transform`}>
                  <span className="text-[7px] font-black uppercase text-amber-300">
                    {combo.coverBadge || 'COMBO'}
                  </span>
                  <span className="text-xs font-extrabold line-clamp-3">
                    {combo.title}
                  </span>
                  <span className="text-[8px] bg-black/40 px-1 rounded text-center">
                    {combo.pageCount} Pages
                  </span>
                </div>

                <div className="flex-1 text-center sm:text-left">
                  <span className="text-[10px] font-black text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full uppercase">
                    BUNDLE DEAL • SAVE {combo.discountPercent}%
                  </span>
                  <h3 className="text-sm sm:text-base font-extrabold text-slate-900 group-hover:text-blue-900 transition-colors mt-1">
                    {combo.title}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {combo.subtitle}
                  </p>
                  <div className="flex items-baseline justify-center sm:justify-start gap-2 mt-2">
                    <span className="text-xl font-black text-[#0B192C]">₹{combo.price}</span>
                    <span className="text-xs text-slate-400 line-through">₹{combo.originalPrice}</span>
                    <span className="text-xs font-bold text-emerald-600">Lifetime Access</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 8. Free Ebooks & Previous Year Papers */}
        <section className="bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 block">
                Open Access
              </span>
              <h2 className="text-lg sm:text-2xl font-black text-[#0B192C]">
                Free Ebooks & Budget Digests (₹0)
              </h2>
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full">
              No Payment Required
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {freeEbooks.map((book) => (
              <EbookCard key={book.id} ebook={book} />
            ))}
          </div>
        </section>

        {/* 9. Live Interactive Mini Mock Test Promo */}
        <section className="bg-gradient-to-r from-[#0B192C] to-[#1E3E62] text-white rounded-2xl p-6 sm:p-8 shadow-lg flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <span className="text-[11px] font-black text-amber-400 bg-amber-400/15 border border-amber-400/30 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              Free Self-Assessment
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              All-Assam & Central Exam Live Mini Mock Test
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Test your speed and accuracy in 10 questions covering Assam History, Geography, Indian Polity, and General Aptitude with negative marking and instant scorecard.
            </p>
          </div>

          <button
            onClick={() => setMockTestOpen(true)}
            className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm px-6 py-3.5 rounded-xl shadow-lg transition-all hover:scale-105 shrink-0 flex items-center gap-2"
          >
            <FileCheck2 className="w-4 h-4 text-slate-950" />
            <span>Start 10-Min Live Mock Test</span>
          </button>
        </section>

        {/* 10. Latest Official Exam Updates Feed */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 block">
                Verified Information
              </span>
              <h2 className="text-lg sm:text-2xl font-black text-[#0B192C]">
                Official Exam Updates & Calendar
              </h2>
            </div>
            <button
              onClick={() => {
                setActiveTab('exam-updates');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-xs sm:text-sm font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1"
            >
              <span>{t.viewAll}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {examUpdates.slice(0, 2).map((item) => (
              <div
                key={item.id}
                className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:border-amber-400 transition-colors space-y-2.5"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-md">
                    {item.organization}
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">{item.lastUpdated}</span>
                </div>
                <h3 className="text-sm font-black text-[#0B192C] leading-snug">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-600 line-clamp-2">
                  {item.summary}
                </p>
                <div className="pt-2 flex items-center justify-between text-xs border-t border-slate-100">
                  <span className="text-emerald-700 font-bold">{item.status}</span>
                  <a
                    href={item.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-700 font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Official Portal</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 11. New Arrivals */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 block">
                Fresh Releases
              </span>
              <h2 className="text-lg sm:text-2xl font-black text-[#0B192C]">
                New Arrivals (2026 Editions)
              </h2>
            </div>
            <button
              onClick={() => {
                setActiveTab('categories');
              }}
              className="text-xs sm:text-sm font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1"
            >
              <span>{t.viewAll}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
            {newArrivals.map((book) => (
              <EbookCard key={book.id} ebook={book} />
            ))}
          </div>
        </section>

        {/* 12. Bottom "Browse All Books" Big Action Button */}
        <section className="text-center py-6">
          <button
            onClick={() => {
              setActiveTab('categories');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 bg-[#0B192C] hover:bg-slate-800 text-amber-400 font-black text-sm sm:text-base px-8 py-4 rounded-2xl shadow-xl transition-all hover:scale-105"
          >
            <BookOpen className="w-5 h-5 text-amber-400" />
            <span>{t.browseAllBooks} ({ebooks.length} Active Guides)</span>
          </button>
        </section>
      </div>
    </div>
  );
};
