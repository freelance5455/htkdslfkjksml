import React, { useState } from 'react';
import { ThreeCharacterViewer } from './ThreeCharacterViewer';
import { NavTab, ModelMetadata } from '../types';
import { voiceService } from '../services/voiceService';
import { 
  MessageSquare, 
  Box, 
  Sparkles, 
  Volume2, 
  Heart, 
  Zap, 
  Cpu, 
  ShieldCheck, 
  ArrowRight
} from 'lucide-react';

interface HomeViewProps {
  onNavigate: (tab: NavTab) => void;
  characterMeta: ModelMetadata | null;
  onModelLoaded: (meta: ModelMetadata) => void;
  customModel?: { buffer: ArrayBuffer; name: string } | null;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNavigate,
  characterMeta,
  onModelLoaded,
  customModel = null,
}) => {
  const [greetingPlayed, setGreetingPlayed] = useState(false);
  const [speechBubbleText, setSpeechBubbleText] = useState(
    "Good to see you, Darling! All my neural telemetry is locked on you today."
  );

  const triggerVoiceGreeting = () => {
    const greetings = [
      "Darling! Our synchronization rate is at peak performance today!",
      "I'm keeping watch over your system. Don't worry, nobody gets past me.",
      "Are you ready for our next mission together, Darling?",
      "Sweet as honey! That's how I like our days to be.",
    ];
    const picked = greetings[Math.floor(Math.random() * greetings.length)];
    setSpeechBubbleText(picked);
    setGreetingPlayed(true);
    voiceService.speak(picked, () => setGreetingPlayed(false));
  };

  return (
    <div className="relative w-full h-full flex flex-col overflow-hidden bg-[#07070e]">
      {/* 3D Character Viewport (Centerpiece) */}
      <div className="relative flex-1 w-full h-[62%] sm:h-[68%]">
        <ThreeCharacterViewer
          onModelLoaded={onModelLoaded}
          interactiveControls={true}
          showModelUploadButton={false}
          activeLightingPreset="cyber-neon"
          externalGlbBuffer={customModel}
        />

        {/* Top Floating Companion Stats Card (Mobile-friendly) */}
        <div className="absolute top-4 left-4 right-4 pointer-events-none flex items-center justify-between">
          <div className="bg-[#0e0e1c]/80 backdrop-blur-md border border-[#ff2d78]/30 px-3.5 py-1.5 rounded-2xl shadow-xl pointer-events-auto">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff2d78] shadow-[0_0_8px_#ff2d78]" />
              <div>
                <span className="text-xs font-cyber font-bold tracking-wider text-white">002 AI COMPANION</span>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono-code">
                  <span>SYNC: 98.4%</span>
                  <span>•</span>
                  <span className="text-[#ff70a6]">MOOD: DEVOTED</span>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={triggerVoiceGreeting}
            className="bg-[#121224]/85 hover:bg-[#1a1a32] border border-[#ff2d78]/40 hover:border-[#ff2d78] text-[#ff70a6] hover:text-white p-2.5 rounded-2xl shadow-xl pointer-events-auto transition-all active:scale-95"
            title="Hear 002 Voice Greeting"
          >
            <Volume2 className="w-4 h-4" />
          </button>
        </div>

        {/* 002 Speech Callout Bubble (Grounded above dock) */}
        <div className="absolute bottom-16 left-4 right-4 max-w-md mx-auto pointer-events-none">
          <div className="bg-[#0f0f20]/90 border border-[#ff2d78]/40 backdrop-blur-md p-3 rounded-2xl shadow-2xl pointer-events-auto transition-all">
            <div className="flex items-start gap-2.5">
              <div className="w-6 h-6 rounded-full bg-[#ff2d78] text-white flex items-center justify-center font-cyber text-[10px] font-bold shrink-0 shadow-[0_0_8px_#ff2d78]">
                02
              </div>
              <p className="text-xs text-slate-200 leading-snug font-sans">
                {speechBubbleText}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Command Dashboard */}
      <div className="h-[38%] sm:h-[32%] bg-[#0a0a14] border-t border-[#ff2d78]/20 px-4 py-3 flex flex-col justify-between overflow-y-auto">
        {/* Quick Launch Cards */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* Chat with 002 Card */}
          <button
            onClick={() => onNavigate('chat')}
            className="p-3 rounded-2xl bg-gradient-to-br from-[#180f26] to-[#120a1f] border border-[#9333ea]/35 hover:border-[#ff2d78] text-left transition-all active:scale-98 group shadow-lg"
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="w-7 h-7 rounded-xl bg-[#9333ea]/20 flex items-center justify-center text-[#c084fc] group-hover:bg-[#ff2d78]/20 group-hover:text-[#ff2d78] transition-colors">
                <MessageSquare className="w-4 h-4" />
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition-colors" />
            </div>
            <h3 className="font-cyber font-bold text-xs text-white">NEURAL CHAT</h3>
            <p className="text-[10px] text-slate-400 font-sans line-clamp-1 mt-0.5">
              Converse with 002 via Gemini
            </p>
          </button>

          {/* 3D Character Studio Card */}
          <button
            onClick={() => onNavigate('character')}
            className="p-3 rounded-2xl bg-gradient-to-br from-[#260f1c] to-[#1a0a14] border border-[#ff2d78]/35 hover:border-[#ff2d78] text-left transition-all active:scale-98 group shadow-lg"
          >
            <div className="flex items-center justify-between mb-1.5">
              <div className="w-7 h-7 rounded-xl bg-[#ff2d78]/20 flex items-center justify-center text-[#ff70a6] group-hover:bg-[#ff2d78] group-hover:text-white transition-colors">
                <Box className="w-4 h-4" />
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition-colors" />
            </div>
            <h3 className="font-cyber font-bold text-xs text-white">3D STUDIO</h3>
            <p className="text-[10px] text-slate-400 font-sans line-clamp-1 mt-0.5">
              Import .glb & customize
            </p>
          </button>
        </div>

        {/* Telemetry Status Bar */}
        <div className="bg-[#10101f] border border-slate-800/80 rounded-xl p-2.5 mt-2 flex items-center justify-between text-[11px] font-mono-code text-slate-300">
          <div className="flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5 text-[#ff2d78]" />
            <span className="text-slate-400">Core:</span>
            <span className="text-slate-200">
              {characterMeta?.source === 'imported-glb' ? 'Custom 3D Mesh' : 'Procedural 002 Avatar'}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="text-emerald-400 font-semibold">ONLINE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
