import React, { useState } from 'react';
import { 
  Crown, 
  Lock, 
  Check, 
  Clock, 
  Flame, 
  Receipt,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp, isSubhodipUser } from '../../context/AppContext';
import { MembershipTier } from '../../types';
import { UpiPaymentModal } from './UpiPaymentModal';
import { VipPaymentHistoryModal } from './VipPaymentHistoryModal';
import { GoldMineInvestorProofModal } from '../investment/GoldMineInvestorProofModal';

export interface VipTierDefinition {
  id: MembershipTier;
  title: string;
  name: string;
  priceRupees: number;
  dailyEarningsRupees: number;
  tasksPerDay: number;
  taskRewardRupees: number;
  benefits: string[];
}

export const VIP_PLANS: VipTierDefinition[] = [
  {
    id: 'vip1',
    title: 'VIP 1 — ₹200',
    name: 'VIP 1',
    priceRupees: 200,
    dailyEarningsRupees: 400,
    tasksPerDay: 2,
    taskRewardRupees: 200,
    benefits: [
      '₹200 Reward per task',
      'Daily 2 Tasks (Earn ₹400/day)',
      'Unlimited instant cashouts',
      'Zero withdrawal fees'
    ],
  },
  {
    id: 'vip2',
    title: 'VIP 2 — ₹400',
    name: 'VIP 2',
    priceRupees: 400,
    dailyEarningsRupees: 800,
    tasksPerDay: 2,
    taskRewardRupees: 400,
    benefits: [
      '₹400 Reward per task',
      'Daily 2 Tasks (Earn ₹800/day)',
      'Unlimited instant cashouts',
      'VIP Priority Payouts'
    ],
  },
  {
    id: 'vip3',
    title: 'VIP 3 — ₹1,600',
    name: 'VIP 3',
    priceRupees: 1600,
    dailyEarningsRupees: 2000,
    tasksPerDay: 1,
    taskRewardRupees: 1600,
    benefits: [
      '₹1,600 Reward per task',
      'Daily Total ₹2,000 Earning',
      'Unlimited instant cashouts',
      'VIP Account Manager'
    ],
  },
  {
    id: 'vip4',
    title: 'VIP 4 — ₹2,000',
    name: 'VIP 4',
    priceRupees: 2000,
    dailyEarningsRupees: 4000,
    tasksPerDay: 2,
    taskRewardRupees: 2000,
    benefits: [
      '₹2,000 Reward per task',
      'Daily 2 Tasks (Earn ₹4,000/day)',
      'Unlimited instant cashouts',
      'Elite VIP Badge & Support'
    ],
  },
  {
    id: 'vip5',
    title: 'VIP 5: Gold Mine — ₹5,000 (30 Days)',
    name: 'Gold Mine VIP',
    priceRupees: 5000,
    dailyEarningsRupees: 300,
    tasksPerDay: 2,
    taskRewardRupees: 150,
    benefits: [
      'Daily Return: ₹300/Day (30 Days Total ₹9,000)',
      '30-Day Guaranteed Gold Mining Yield (+80% Profit)',
      'Special Instant ₹1,000 Task Withdrawal Unlocked',
      'VIP 24K Gold Bullion Vault Allocation & High Yield Daily Credited',
      '24/7 Dedicated Gold Account Manager'
    ],
  },
];

export const VipTasksView: React.FC<{ onOpenWallet: () => void }> = ({ onOpenWallet }) => {
  const { currentUser, adjustUserCoins, vipPayments } = useApp();
  
  const [completedVipTasks, setCompletedVipTasks] = useState<Record<string, number>>({});
  const [activeTaskRunning, setActiveTaskRunning] = useState<VipTierDefinition | null>(null);
  const [timerLeft, setTimerLeft] = useState(5);
  const [taskNotice, setTaskNotice] = useState<string | null>(null);

  // Modals state
  const [selectedPlanForUpi, setSelectedPlanForUpi] = useState<{
    id: MembershipTier;
    name: string;
    amountRupees: number;
    dailyEarningsRupees?: number;
    taskRewardRupees?: number;
  } | null>(null);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isGoldMineProofOpen, setIsGoldMineProofOpen] = useState(false);

  const userTier = currentUser?.membershipTier || 'basic';

  const isVipTierUnlocked = (tierId: MembershipTier) => {
    if (!currentUser) return false;
    if (userTier === 'pro') return true;
    if (userTier === tierId) return true;
    const tierRanks: Record<string, number> = { basic: 0, vip1: 1, vip2: 2, vip3: 3, vip4: 4, vip5: 5, premium: 2, pro: 5 };
    return (tierRanks[userTier] || 0) >= (tierRanks[tierId] || 1);
  };

  const getUserPendingPayment = (tierId: MembershipTier) => {
    if (!currentUser) return null;
    return vipPayments.find(p => 
      p.status === 'pending' && 
      p.vipTier === tierId &&
      (p.userId === currentUser.id || p.userEmail.toLowerCase() === currentUser.email.toLowerCase())
    );
  };

  const userPaymentsCount = currentUser 
    ? vipPayments.filter(p => p.userId === currentUser.id || p.userEmail.toLowerCase() === currentUser.email.toLowerCase()).length
    : 0;

  const handleStartVipTask = (tier: VipTierDefinition) => {
    setActiveTaskRunning(tier);
    setTimerLeft(5);
    setTaskNotice(null);

    const interval = setInterval(() => {
      setTimerLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          finishVipTask(tier);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const finishVipTask = (tier: VipTierDefinition) => {
    if (!currentUser) return;
    const doneCount = (completedVipTasks[tier.id] || 0) + 1;
    setCompletedVipTasks(prev => ({ ...prev, [tier.id]: doneCount }));

    const earnedRupees = tier.taskRewardRupees;
    adjustUserCoins(currentUser.id, earnedRupees, `VIP Task: ${tier.name}`);

    confetti({ particleCount: 90, spread: 60 });
    setTaskNotice(`Earned ₹${earnedRupees} INR (🪙 ${earnedRupees} Coins)! Transferred to wallet.`);
    setActiveTaskRunning(null);
  };

  const handleOpenUnlockModal = (tier: VipTierDefinition) => {
    setSelectedPlanForUpi({
      id: tier.id,
      name: tier.title,
      amountRupees: tier.priceRupees,
      dailyEarningsRupees: tier.dailyEarningsRupees,
      taskRewardRupees: tier.taskRewardRupees,
    });
  };

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-24 animate-in fade-in duration-200">
      
      {/* Top Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-3 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5">
            <Crown className="w-5 h-5 text-amber-400" />
            <h1 className="text-lg font-black text-white">VIP Tasks & Plans</h1>
          </div>
          <p className="text-xs text-slate-400">
            High-yield tasks with unlimited instant cashouts
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsHistoryOpen(true)}
          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
        >
          <Receipt className="w-3.5 h-3.5 text-amber-400" />
          <span>Payment History</span>
          {userPaymentsCount > 0 && (
            <span className="w-4 h-4 rounded-full bg-emerald-500 text-slate-950 font-black text-[9px] flex items-center justify-center">
              {userPaymentsCount}
            </span>
          )}
        </button>
      </div>

      {taskNotice && (
        <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{taskNotice}</span>
          </div>
          <button
            onClick={() => setTaskNotice(null)}
            className="text-[11px] underline text-emerald-400 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Featured: Subhodip Garai ₹5,000 24K Digital Gold Investment & Vault Proof Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-amber-950 via-slate-900 to-yellow-950/70 border-2 border-amber-500/50 shadow-xl space-y-3 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-center justify-between relative z-10 flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center text-lg font-bold shadow-md">
              🏆
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 block">
                {isSubhodipUser(currentUser)
                  ? "Subhodip Garai's Active Investment (User ID: user-subhodip-7654)"
                  : "Verified 24K Digital Gold Vault (VIP Exclusive)"}
              </span>
              <h3 className="text-sm sm:text-base font-black text-white tracking-tight">
                ₹5,000 Digital Gold Investment (24K 99.9% Pure Vault)
              </h3>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>100% Real Vault</span>
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs relative z-10 pt-1 border-t border-slate-800">
          <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Invested</span>
            <span className="font-black text-amber-400">₹5,000 INR</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/80 border border-emerald-800/40">
            <span className="text-[10px] text-slate-400 block">Gold Holding</span>
            <span className="font-black text-emerald-400">0.6825 g</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Vault Value</span>
            <span className="font-black text-white">₹7,000.00</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/80 border border-yellow-800/40">
            <span className="text-[10px] text-slate-400 block">Market Return</span>
            <span className="font-black text-amber-300">+1.65% Today</span>
          </div>
        </div>

        <div className="flex items-center gap-2 pt-1 flex-wrap relative z-10">
          <button
            type="button"
            onClick={onOpenWallet}
            className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Digital Gold Vault (₹5,000)</span>
          </button>

          <button
            type="button"
            onClick={onOpenWallet}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold text-xs flex items-center justify-center gap-1 cursor-pointer transition-all"
          >
            <span>Wallet & Payouts</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
          </button>
        </div>
      </div>

      {/* VIP Plans List */}
      <div className="space-y-3.5">
        {VIP_PLANS.map((tier) => {
          const isUnlocked = isVipTierUnlocked(tier.id);
          const pendingPayment = getUserPendingPayment(tier.id);
          const tasksDone = completedVipTasks[tier.id] || 0;
          const isLimitReached = tasksDone >= tier.tasksPerDay;

          return (
            <div
              key={tier.id}
              className={`p-5 rounded-3xl border transition-all space-y-4 ${
                isUnlocked
                  ? 'bg-slate-900/80 border-emerald-500/40 shadow-lg'
                  : pendingPayment
                  ? 'bg-slate-900/80 border-amber-500/40 shadow-lg'
                  : 'bg-slate-900/60 border-slate-800 shadow-sm'
              }`}
            >
              {/* Header: Plan Name & Purchase Price */}
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-white">
                      {tier.title}
                    </h3>
                    {isUnlocked && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        Active
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-emerald-400 font-bold mt-0.5">
                    Daily Earning: ₹{tier.dailyEarningsRupees} INR ({tier.tasksPerDay} Tasks / Day)
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-xl font-black text-amber-400">
                    ₹{tier.priceRupees}
                  </span>
                  <span className="text-[10px] text-slate-500 block">One-time UPI</span>
                </div>
              </div>

              {/* Benefits */}
              <div className="pt-2 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                {tier.benefits.map((benefit, bIndex) => (
                  <div key={bIndex} className="flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>

              {/* Progress if unlocked */}
              {isUnlocked && (
                <div className="space-y-1 pt-1">
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Tasks Done Today</span>
                    <span className="font-bold text-slate-200">{tasksDone} / {tier.tasksPerDay}</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500 rounded-full transition-all"
                      style={{ width: `${Math.min(100, (tasksDone / tier.tasksPerDay) * 100)}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Action Button */}
              <div className="pt-1">
                {activeTaskRunning?.id === tier.id ? (
                  <div className="w-full py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2">
                    <Clock className="w-4 h-4 animate-spin" />
                    <span>Running VIP Task... {timerLeft}s</span>
                  </div>
                ) : isUnlocked ? (
                  <button
                    type="button"
                    onClick={() => handleStartVipTask(tier)}
                    disabled={isLimitReached}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95 disabled:opacity-50 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Flame className="w-3.5 h-3.5 text-amber-300" />
                    <span>
                      {isLimitReached
                        ? `Daily Limit Done (Earned ₹${tier.dailyEarningsRupees})`
                        : `Start VIP Task (+₹${tier.taskRewardRupees} INR)`}
                    </span>
                  </button>
                ) : pendingPayment ? (
                  <button
                    type="button"
                    onClick={() => setIsHistoryOpen(true)}
                    className="w-full py-2.5 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                    <span>Pending Admin Verification (Locked)</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleOpenUnlockModal(tier)}
                    className="w-full py-3 rounded-xl bg-slate-100 hover:bg-white text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Unlock VIP ({tier.name} — ₹{tier.priceRupees})</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Professional UPI Modal */}
      <UpiPaymentModal
        isOpen={!!selectedPlanForUpi}
        onClose={() => setSelectedPlanForUpi(null)}
        vipPlan={selectedPlanForUpi}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      {/* Payment History Modal */}
      <VipPaymentHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onBuyPlan={() => {
          setIsHistoryOpen(false);
          if (VIP_PLANS[0]) handleOpenUnlockModal(VIP_PLANS[0]);
        }}
      />

      {/* Gold Mine Investor Proof & Certificate Modal */}
      <GoldMineInvestorProofModal
        isOpen={isGoldMineProofOpen}
        onClose={() => setIsGoldMineProofOpen(false)}
        onOpenWithdrawal={onOpenWallet}
      />

    </div>
  );
};
