import React from 'react';
import { 
  X, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  CreditCard, 
  Receipt, 
  ExternalLink,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface VipPaymentHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBuyPlan?: () => void;
}

export const VipPaymentHistoryModal: React.FC<VipPaymentHistoryModalProps> = ({
  isOpen,
  onClose,
  onBuyPlan,
}) => {
  const { currentUser, vipPayments, language } = useApp();

  if (!isOpen) return null;

  // Filter payments for current user (or demo user)
  const userPayments = vipPayments.filter(p => 
    currentUser ? (p.userId === currentUser.id || p.userEmail.toLowerCase() === currentUser.email.toLowerCase()) : true
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl relative max-h-[90vh] flex flex-col"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5 shrink-0">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shadow-xs">
            <Receipt className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
              VIP Purchases & Payment History
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              UPI Transactions & Admin Verification Status
            </p>
          </div>
        </div>

        {/* Payments List */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {userPayments.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-3">
              <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto text-2xl">
                💳
              </div>
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300">
                No VIP Purchases Found
              </h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                You haven't submitted any VIP plan payments yet. Unlock a VIP plan to access high-yield daily tasks!
              </p>
              {onBuyPlan && (
                <button
                  type="button"
                  onClick={() => { onClose(); onBuyPlan(); }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer inline-flex items-center gap-1.5"
                >
                  <span>Explore VIP Plans</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ) : (
            userPayments.map((p) => {
              const dateStr = new Date(p.createdAt).toLocaleString(undefined, {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={p.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-3"
                >
                  {/* Top line: Plan & Status */}
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                        <span>{p.planName}</span>
                      </h4>
                      <span className="text-[11px] text-slate-400">
                        {dateStr}
                      </span>
                    </div>

                    {/* Status Badge */}
                    <div>
                      {p.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                          <Clock className="w-3.5 h-3.5 animate-spin" />
                          <span>Pending Verification</span>
                        </span>
                      )}
                      {p.status === 'approved' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approved & Active</span>
                        </span>
                      )}
                      {p.status === 'rejected' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Payment Rejected</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Payment Details Grid */}
                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 text-xs grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">
                        Amount
                      </span>
                      <span className="font-black text-emerald-600 dark:text-emerald-400 text-sm">
                        ₹{p.amountRupees}
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">
                        UPI ID Paid To
                      </span>
                      <span className="font-mono text-slate-700 dark:text-slate-300">
                        {p.upiId}
                      </span>
                    </div>

                    <div className="col-span-2 pt-1 border-t border-slate-100 dark:border-slate-800">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">
                        UTR / Transaction Reference
                      </span>
                      <span className="font-mono font-bold text-slate-900 dark:text-slate-100 tracking-wider">
                        {p.utrNumber}
                      </span>
                    </div>
                  </div>

                  {/* Screenshot Thumbnail if uploaded */}
                  {p.screenshotUrl && (
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <img 
                        src={p.screenshotUrl} 
                        alt="Receipt" 
                        className="w-10 h-10 object-cover rounded-lg border border-slate-300 dark:border-slate-700"
                      />
                      <span>Payment receipt screenshot attached</span>
                    </div>
                  )}

                  {/* Rejection remark if any */}
                  {p.status === 'rejected' && p.adminRemark && (
                    <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 text-xs">
                      <strong>Admin Remark:</strong> {p.adminRemark}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 mt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
