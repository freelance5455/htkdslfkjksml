import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  QrCode, 
  ExternalLink, 
  ShieldCheck, 
  AlertCircle, 
  Upload, 
  CheckCircle2, 
  Clock, 
  Smartphone,
  Lock,
  Trash2,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MembershipTier } from '../../types';
import { PaytmQrCard } from '../common/PaytmQrCard';

interface UpiPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  vipPlan: {
    id: MembershipTier;
    name: string;
    amountRupees: number;
    dailyEarningsRupees?: number;
    taskRewardRupees?: number;
  } | null;
  onOpenHistory?: () => void;
}

export const UpiPaymentModal: React.FC<UpiPaymentModalProps> = ({
  isOpen,
  onClose,
  vipPlan,
  onOpenHistory
}) => {
  const { submitVipPayment, systemSettings } = useApp();

  const [step, setStep] = useState<'pay' | 'utr' | 'success'>('pay');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [paidAmount, setPaidAmount] = useState<number | string>(vipPlan?.amountRupees || 200);
  const [utrNumber, setUtrNumber] = useState('');
  const [screenshotData, setScreenshotData] = useState<string | null>(null);
  const [screenshotName, setScreenshotName] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  if (!isOpen || !vipPlan) return null;

  const upiId = systemSettings.adminUpiId || 'paytm.s19vihm@pty';
  const payeeName = 'Subhodip Garai';
  const amount = Number(paidAmount) || vipPlan.amountRupees;
  const planTitle = vipPlan.name.split('—')[0].trim();
  const transactionNote = `${planTitle} Unlock`;

  const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setFormError('Screenshot image must be under 5MB.');
      return;
    }

    setScreenshotName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      setScreenshotData(event.target?.result as string);
      setFormError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitProof = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const numericAmount = Number(paidAmount);
    if (!numericAmount || numericAmount <= 0) {
      setFormError('Please enter a valid paid amount in INR.');
      return;
    }

    const cleanUtr = utrNumber.trim();
    if (!cleanUtr || cleanUtr.length < 6) {
      setFormError('Please enter a valid UTR or Transaction ID.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = submitVipPayment({
        vipTier: vipPlan.id,
        planName: vipPlan.name,
        amountRupees: numericAmount,
        utrNumber: cleanUtr,
        screenshotUrl: screenshotData || undefined,
      });

      if (res.success) {
        setStep('success');
      } else {
        setFormError(res.message);
      }
    } catch (err: any) {
      setFormError(err.message || 'Submission failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetAndClose = () => {
    setStep('pay');
    setUtrNumber('');
    setScreenshotData(null);
    setScreenshotName(null);
    setFormError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={handleResetAndClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1 mb-3 pr-6">
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            UPI Verification & Referral Bonus
          </span>
          <h2 className="text-xl font-black text-white">
            Unlock {planTitle}
          </h2>
          <p className="text-xs text-slate-400">
            Amount: <strong className="text-emerald-400 text-sm">₹{vipPlan.amountRupees}</strong>
          </p>
        </div>

        {/* Bilingual Referral & Screenshot Note */}
        <div className="mb-3.5 p-3 rounded-2xl bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-indigo-500/10 border border-amber-500/30 text-[11px] space-y-1 text-amber-200">
          <p className="font-bold">
            🎁 Referral Bonus: আপনার বন্ধু রেফারেল লিংক দিয়ে VIP (₹200) কিনলে আপনি পাবেন ইনস্ট্যান্ট ₹50!
          </p>
          <p className="text-slate-300">
            (When your referred friend purchases VIP, you instantly get ₹50 cash commission. Attach your payment screenshot from gallery below).
          </p>
        </div>

        {/* STEP 1: Pay via UPI / Show QR */}
        {step === 'pay' && (
          <div className="space-y-4">
            {/* Authentic Paytm QR Poster */}
            <PaytmQrCard
              upiId={upiId}
              amount={vipPlan.amountRupees}
              payeeName="Subhodip Garai"
              transactionNote={`${planTitle} VIP Payment`}
              showDirectPayButton={true}
            />

            {/* Have you completed the payment? [ I Have Paid ] */}
            <div className="pt-2 border-t border-slate-800/80 space-y-2">
              <p className="text-xs text-slate-400 text-center font-medium">
                Have you completed the payment?
              </p>
              <button
                type="button"
                onClick={() => setStep('utr')}
                className="w-full py-3 rounded-xl bg-slate-100 hover:bg-white text-slate-950 font-black text-xs shadow-lg active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>I Have Paid — Enter Details</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Enter UTR & Upload Screenshot */}
        {step === 'utr' && (
          <form onSubmit={handleSubmitProof} className="space-y-3.5">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
              Enter paid amount and your 12-digit UTR from your bank or UPI app.
            </div>

            {formError && (
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Amount (INR) Input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 block">
                Amount (INR) <span className="text-rose-400">*</span>
              </label>
              <input
                type="number"
                required
                min={1}
                value={paidAmount}
                onChange={(e) => setPaidAmount(e.target.value)}
                placeholder="Enter Paid Amount"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Transaction ID / UTR Input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 block">
                Transaction ID / UTR <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={utrNumber}
                onChange={(e) => setUtrNumber(e.target.value)}
                placeholder="Enter UTR or Transaction ID"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Payment Screenshot */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 block">
                Payment Screenshot (Optional)
              </label>

              {screenshotData ? (
                <div className="p-2.5 rounded-xl border border-slate-700 bg-slate-950 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 truncate">
                    <img 
                      src={screenshotData} 
                      alt="Receipt" 
                      className="w-8 h-8 object-cover rounded-md border border-slate-700 shrink-0"
                    />
                    <span className="text-xs text-slate-300 truncate font-mono">
                      {screenshotName || 'Attached'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setScreenshotData(null); setScreenshotName(null); }}
                    className="p-1 text-rose-400 hover:text-rose-300 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="border border-dashed border-slate-700 hover:border-slate-500 rounded-xl p-3 flex flex-col items-center justify-center gap-1 cursor-pointer bg-slate-950/60 transition-colors">
                  <Upload className="w-4 h-4 text-slate-400" />
                  <span className="text-[11px] text-slate-400">Click to upload payment screenshot</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleScreenshotChange}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => setStep('pay')}
                className="px-3 py-2.5 rounded-xl border border-slate-800 text-slate-400 font-bold text-xs hover:bg-slate-800 cursor-pointer"
              >
                Back
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95 disabled:opacity-50 transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                {isSubmitting ? (
                  <span>Submitting...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Submit Payment</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: Submission Confirmed (Pending Verification) */}
        {step === 'success' && (
          <div className="text-center space-y-3 py-2">
            <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
              <Clock className="w-6 h-6 animate-pulse" />
            </div>

            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Status: Pending
              </span>
              <h3 className="text-base font-black text-white pt-1">
                Payment Submitted
              </h3>
              <p className="text-xs text-slate-400">
                Your UTR <strong>{utrNumber}</strong> has been received. Our admin will verify your payment before unlocking {planTitle}.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-left text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Plan:</span>
                <span className="font-bold text-slate-200">{vipPlan.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount:</span>
                <span className="font-bold text-emerald-400">₹{paidAmount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Status:</span>
                <span className="font-bold text-amber-400">Pending Verification</span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              {onOpenHistory && (
                <button
                  type="button"
                  onClick={() => { handleResetAndClose(); onOpenHistory(); }}
                  className="flex-1 py-2.5 rounded-xl border border-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-800 cursor-pointer"
                >
                  Payment History
                </button>
              )}
              <button
                type="button"
                onClick={handleResetAndClose}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs cursor-pointer shadow-md"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
