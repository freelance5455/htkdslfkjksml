import React, { useState, useMemo } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Repeat,
  Volume2,
  User,
  Loader2,
  X,
  Star,
  Sparkles,
  Moon,
  Search,
  Radio,
  BookOpen,
} from 'lucide-react';
import { Reciter, ActiveSpecialTrack } from '../types';
import { RECITERS } from '../data/reciters';
import { SURAH_METADATA } from '../data/quranMetadata';
import { RepeatMode } from '../hooks/useAudioPlayer';

interface AudioPlayerBarProps {
  isPlaying: boolean;
  isLoading: boolean;
  currentSurahNumber: number | null;
  currentAyahNumber: number | null;
  totalAyahsInSurah: number;
  activeReciter: Reciter;
  activeSpecialTrack?: ActiveSpecialTrack | null;
  favoriteReciterIds?: string[];
  repeatMode: RepeatMode;
  playbackSpeed: number;
  currentTime: number;
  duration: number;
  errorMessage: string | null;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onSeek: (fraction: number) => void;
  onSelectReciter: (reciter: Reciter) => void;
  onToggleFavoriteReciter?: (reciterId: string) => void;
  onSpeedChange: (speed: number) => void;
  onRepeatModeChange: (mode: RepeatMode) => void;
  onClose: () => void;
  onScrollToCurrentAyah?: () => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  isPlaying,
  isLoading,
  currentSurahNumber,
  currentAyahNumber,
  totalAyahsInSurah,
  activeReciter,
  activeSpecialTrack,
  favoriteReciterIds = [],
  repeatMode,
  playbackSpeed,
  currentTime,
  duration,
  errorMessage,
  onTogglePlay,
  onNext,
  onPrev,
  onSeek,
  onSelectReciter,
  onToggleFavoriteReciter,
  onSpeedChange,
  onRepeatModeChange,
  onClose,
  onScrollToCurrentAyah,
}) => {
  const [showReciterList, setShowReciterList] = useState(false);
  const [reciterSearch, setReciterSearch] = useState('');

  // Filter reciters
  const filteredReciters = useMemo(() => {
    if (!reciterSearch.trim()) return RECITERS;
    const query = reciterSearch.trim().toLowerCase();
    return RECITERS.filter(
      r => r.name.toLowerCase().includes(query) || r.subname.toLowerCase().includes(query)
    );
  }, [reciterSearch]);

  // Separate favorite reciters
  const favoriteRecitersList = useMemo(() => {
    return RECITERS.filter(r => favoriteReciterIds.includes(r.id));
  }, [favoriteReciterIds]);

  // Check if player has anything to play
  if (!activeSpecialTrack && (!currentSurahNumber || !currentAyahNumber)) {
    return null;
  }

  const surahMeta = currentSurahNumber ? SURAH_METADATA.find(s => s.number === currentSurahNumber) : null;
  const surahName = surahMeta ? surahMeta.name : (activeSpecialTrack?.surahName || (currentSurahNumber ? `سورة ${currentSurahNumber}` : ''));

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds === 0) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const cycleRepeatMode = () => {
    if (repeatMode === 'none') onRepeatModeChange('ayah');
    else if (repeatMode === 'ayah') onRepeatModeChange('surah');
    else onRepeatModeChange('none');
  };

  const cycleSpeed = () => {
    if (playbackSpeed === 1) onSpeedChange(1.25);
    else if (playbackSpeed === 1.25) onSpeedChange(1.5);
    else if (playbackSpeed === 1.5) onSpeedChange(0.75);
    else onSpeedChange(1);
  };

  return (
    <div
      id="android-audio-player-bar"
      className="fixed bottom-0 inset-x-0 z-40 bg-stone-900/95 dark:bg-stone-950/98 backdrop-blur-md text-white border-t border-emerald-800/40 shadow-2xl transition-all duration-300"
    >
      {/* Visual seek progress bar on the top border */}
      <div
        className="w-full h-1 bg-stone-800 cursor-pointer relative group"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          const fraction = Math.max(0, Math.min(1, clickX / rect.width));
          onSeek(fraction);
        }}
      >
        <div
          className={`h-full transition-all duration-100 relative ${
            activeSpecialTrack?.category === 'ramadan_maghrib'
              ? 'bg-amber-400 group-hover:bg-amber-300'
              : 'bg-emerald-400 group-hover:bg-emerald-300'
          }`}
          style={{ width: `${progressPercent}%` }}
        >
          <div className="absolute top-1/2 -right-1.5 -translate-y-1/2 w-3 h-3 rounded-full bg-amber-300 shadow opacity-0 group-hover:opacity-100 transition" />
        </div>
      </div>

      {/* Optional Quick Favorite Reciters Switcher Bar (when not in special recitation) */}
      {!activeSpecialTrack && favoriteRecitersList.length > 0 && (
        <div className="px-4 py-1 bg-stone-950/70 border-b border-stone-800/80 flex items-center justify-between gap-2 overflow-x-auto text-[11px]">
          <div className="flex items-center gap-1.5 text-amber-300 font-bold shrink-0">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>تبديل سريع:</span>
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto py-0.5 no-scrollbar">
            {favoriteRecitersList.map((fav) => {
              const isSelected = activeReciter.id === fav.id;
              return (
                <button
                  key={fav.id}
                  onClick={() => onSelectReciter(fav)}
                  className={`px-2.5 py-0.5 rounded-full whitespace-nowrap transition flex items-center gap-1 text-[11px] font-medium ${
                    isSelected
                      ? 'bg-amber-400 text-stone-950 font-bold shadow-xs'
                      : 'bg-stone-800/80 text-stone-300 hover:text-white hover:bg-stone-700'
                  }`}
                  title={`${fav.name} (${fav.subname})`}
                >
                  <span>{fav.name.replace('الشيخ ', '')}</span>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-stone-950" />}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="max-w-4xl mx-auto px-4 py-2.5 sm:py-3">
        {errorMessage && (
          <div className="text-xs text-rose-300 mb-1.5 text-center bg-rose-950/60 py-1 px-3 rounded-lg border border-rose-800/50">
            {errorMessage}
          </div>
        )}

        <div className="flex items-center justify-between gap-3">
          {/* Track Info */}
          <div
            className="flex items-center gap-2.5 min-w-0 flex-1 cursor-pointer"
            onClick={onScrollToCurrentAyah}
            title={activeSpecialTrack ? 'تلاوة مختارة' : 'انقر للانتقال إلى الآية'}
          >
            <div
              className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 shadow-md ${
                activeSpecialTrack?.category === 'ramadan_maghrib'
                  ? 'bg-gradient-to-br from-amber-700 to-amber-900 border-amber-500/40 text-amber-300'
                  : 'bg-gradient-to-br from-emerald-600 to-emerald-900 border-emerald-500/30 text-amber-300'
              }`}
            >
              {activeSpecialTrack?.category === 'ramadan_maghrib' ? (
                <Moon className="w-5 h-5 text-amber-300 animate-pulse" />
              ) : activeSpecialTrack?.category === 'khashia' ? (
                <Sparkles className="w-5 h-5 text-emerald-300 animate-pulse" />
              ) : (
                <Volume2 className="w-5 h-5 text-amber-300 animate-pulse" />
              )}
            </div>

            <div className="min-w-0">
              {activeSpecialTrack ? (
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-sm sm:text-base text-amber-300 truncate font-['Cairo',sans-serif]">
                      {activeSpecialTrack.title}
                    </span>
                    <span
                      className={`text-[10px] sm:text-xs px-2 py-0.5 rounded-full border shrink-0 font-medium ${
                        activeSpecialTrack.category === 'ramadan_maghrib'
                          ? 'bg-amber-950/80 text-amber-200 border-amber-600/60'
                          : 'bg-emerald-950/80 text-emerald-200 border-emerald-600/60'
                      }`}
                    >
                      {activeSpecialTrack.category === 'ramadan_maghrib'
                        ? '🌙 قرآن المغرب'
                        : '🕊️ تلاوة خاشعة'}
                    </span>
                  </div>
                  <p className="text-xs text-stone-400 truncate flex items-center gap-1.5 mt-0.5">
                    <span className="text-stone-200 font-medium">{activeSpecialTrack.reciterName}</span>
                    {activeSpecialTrack.stationOrOccasion && (
                      <span className="text-[11px] text-stone-400 hidden sm:inline">
                        • {activeSpecialTrack.stationOrOccasion}
                      </span>
                    )}
                  </p>
                </div>
              ) : (
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm sm:text-base text-amber-300 truncate font-['Cairo',sans-serif]">
                      سورة {surahName}
                    </span>
                    {currentAyahNumber && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-900/60 border border-emerald-700/50 text-emerald-200 shrink-0 font-sans">
                        الآية {currentAyahNumber} من {totalAyahsInSurah}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-400 truncate flex items-center gap-1.5 mt-0.5">
                    <span>بصوت:</span>
                    <span className="text-stone-200 font-medium">{activeReciter.name}</span>
                    {favoriteReciterIds.includes(activeReciter.id) && (
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400 inline" />
                    )}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Player Core Controls */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Previous */}
            <button
              id="audio-prev-btn"
              onClick={onPrev}
              disabled={!activeSpecialTrack && currentAyahNumber !== null && currentAyahNumber <= 1 && currentSurahNumber !== null && currentSurahNumber <= 1}
              className="p-2 sm:p-2.5 rounded-xl text-stone-300 hover:text-white hover:bg-stone-800/80 disabled:opacity-40 transition"
              aria-label={activeSpecialTrack ? 'التلاوة السابقة' : 'الآية السابقة'}
              title={activeSpecialTrack ? 'التلاوة السابقة' : 'الآية السابقة'}
            >
              <SkipForward className="w-5 h-5" />
            </button>

            {/* Play/Pause Button */}
            <button
              id="audio-play-pause"
              onClick={onTogglePlay}
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold flex items-center justify-center shadow-lg hover:shadow-amber-500/20 active:scale-95 transition"
              aria-label={isPlaying ? 'إيقاف مؤقت' : 'تشغيل التلاوة'}
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current translate-x-0.5" />
              )}
            </button>

            {/* Next */}
            <button
              id="audio-next-btn"
              onClick={onNext}
              className="p-2 sm:p-2.5 rounded-xl text-stone-300 hover:text-white hover:bg-stone-800/80 transition"
              aria-label={activeSpecialTrack ? 'التلاوة التالية' : 'الآية التالية'}
              title={activeSpecialTrack ? 'التلاوة التالية' : 'الآية التالية'}
            >
              <SkipBack className="w-5 h-5" />
            </button>

            {/* Reciter Picker Toggle (shown for regular recitation) */}
            {!activeSpecialTrack && (
              <div className="relative">
                <button
                  id="audio-reciter-menu-btn"
                  onClick={() => setShowReciterList(!showReciterList)}
                  className={`p-2 sm:p-2.5 rounded-xl transition relative ${
                    showReciterList
                      ? 'bg-emerald-800 text-amber-300'
                      : 'text-stone-300 hover:text-white hover:bg-stone-800/80'
                  }`}
                  aria-label="اختيار القارئ"
                  title="تغيير القارئ والمفضلة"
                >
                  <User className="w-5 h-5" />
                  {favoriteReciterIds.includes(activeReciter.id) && (
                    <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-amber-400 rounded-full" />
                  )}
                </button>

                {/* Reciters Dropdown with Favorites Section */}
                {showReciterList && (
                  <div
                    id="reciters-popover"
                    className="absolute bottom-full left-0 mb-3 w-72 sm:w-80 max-h-96 overflow-y-auto rounded-2xl bg-stone-900 border border-stone-700 shadow-2xl p-2 z-50 divide-y divide-stone-800/60"
                  >
                    {/* Header with Search */}
                    <div className="p-2 pb-2">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-amber-300">
                          اختيار القارئ
                        </span>
                        <span className="text-[10px] text-stone-400 font-sans">
                          ⭐ انقر النجمة لإضافة القارئ للمفضلة
                        </span>
                      </div>
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 text-stone-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={reciterSearch}
                          onChange={(e) => setReciterSearch(e.target.value)}
                          placeholder="ابحث عن قارئ..."
                          className="w-full pr-8 pl-3 py-1.5 rounded-lg bg-stone-800 text-xs text-white placeholder:text-stone-500 outline-none focus:ring-1 focus:ring-amber-400"
                        />
                      </div>
                    </div>

                    {/* Section 1: Favorite Reciters (if any) */}
                    {!reciterSearch && favoriteRecitersList.length > 0 && (
                      <div className="py-2">
                        <div className="px-2 py-1 text-[11px] font-bold text-amber-400 flex items-center gap-1.5">
                          <Star className="w-3.5 h-3.5 fill-amber-400" />
                          <span>القراء المفضلون ({favoriteRecitersList.length})</span>
                        </div>
                        <div className="space-y-1 mt-1">
                          {favoriteRecitersList.map((r) => {
                            const isCurrent = activeReciter.id === r.id;
                            return (
                              <div
                                key={`fav-${r.id}`}
                                className={`w-full px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between transition ${
                                  isCurrent
                                    ? 'bg-amber-950/60 border border-amber-600/50 text-amber-300 font-bold'
                                    : 'hover:bg-stone-800 text-stone-200'
                                }`}
                              >
                                <button
                                  type="button"
                                  onClick={() => {
                                    onSelectReciter(r);
                                    setShowReciterList(false);
                                  }}
                                  className="flex-1 text-right"
                                >
                                  <div>{r.name}</div>
                                  <div className="text-[10px] text-stone-400 font-normal">{r.subname}</div>
                                </button>

                                <div className="flex items-center gap-1 shrink-0 mr-1">
                                  {onToggleFavoriteReciter && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        onToggleFavoriteReciter(r.id);
                                      }}
                                      className="p-1 text-amber-400 hover:text-amber-200"
                                      title="إزالة من المفضلة"
                                    >
                                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                                    </button>
                                  )}
                                  {isCurrent && (
                                    <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Section 2: All Reciters */}
                    <div className="py-2 space-y-1">
                      <div className="px-2 py-1 text-[11px] font-bold text-stone-400 flex items-center justify-between">
                        <span>جميع القراء ({filteredReciters.length})</span>
                      </div>
                      {filteredReciters.map((r) => {
                        const isCurrent = activeReciter.id === r.id;
                        const isFavorite = favoriteReciterIds.includes(r.id);
                        return (
                          <div
                            key={r.id}
                            className={`w-full px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between transition ${
                              isCurrent
                                ? 'bg-emerald-900/60 border border-emerald-600/40 text-amber-300 font-bold'
                                : 'text-stone-200 hover:bg-stone-800'
                            }`}
                          >
                            <button
                              type="button"
                              onClick={() => {
                                onSelectReciter(r);
                                setShowReciterList(false);
                              }}
                              className="flex-1 text-right"
                            >
                              <div>{r.name}</div>
                              <div className="text-[10px] text-stone-400 font-normal">{r.subname}</div>
                            </button>

                            <div className="flex items-center gap-1.5 shrink-0 mr-1">
                              {onToggleFavoriteReciter && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onToggleFavoriteReciter(r.id);
                                  }}
                                  className={`p-1 transition ${
                                    isFavorite
                                      ? 'text-amber-400 hover:text-amber-300'
                                      : 'text-stone-500 hover:text-stone-300'
                                  }`}
                                  title={isFavorite ? 'إزالة من المفضلة' : 'إضافة للقراء المفضلين'}
                                >
                                  <Star
                                    className={`w-3.5 h-3.5 ${
                                      isFavorite ? 'fill-amber-400 text-amber-400' : 'text-stone-400'
                                    }`}
                                  />
                                </button>
                              )}
                              {isCurrent && (
                                <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Repeat Mode */}
            <button
              id="audio-repeat-mode-btn"
              onClick={cycleRepeatMode}
              className={`p-2 sm:p-2.5 rounded-xl transition relative ${
                repeatMode !== 'none'
                  ? 'bg-emerald-900 text-amber-300 border border-emerald-700'
                  : 'text-stone-400 hover:text-white hover:bg-stone-800/80'
              }`}
              title={
                repeatMode === 'none'
                  ? 'التكرار: معطل'
                  : repeatMode === 'ayah'
                  ? 'تكرار التلاوة الحالية'
                  : 'تكرار السورة كاملة'
              }
            >
              <Repeat className="w-4 h-4" />
              {repeatMode === 'ayah' && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 text-stone-950 rounded-full text-[9px] font-bold flex items-center justify-center">
                  1
                </span>
              )}
              {repeatMode === 'surah' && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                  ∞
                </span>
              )}
            </button>

            {/* Playback Speed */}
            <button
              id="audio-speed-btn"
              onClick={cycleSpeed}
              className="px-2 py-1 rounded-lg text-xs font-bold text-stone-300 hover:text-white hover:bg-stone-800 transition"
              title="سرعة التلاوة"
            >
              {playbackSpeed}x
            </button>

            {/* Close / Stop */}
            <button
              id="audio-close-btn"
              onClick={onClose}
              className="p-2 rounded-xl text-stone-400 hover:text-rose-300 hover:bg-stone-800/80 transition"
              aria-label="إغلاق المشغل"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Time elapsed / remaining */}
        <div className="flex justify-between text-[11px] text-stone-400 px-1 mt-1 font-mono">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>
    </div>
  );
};

