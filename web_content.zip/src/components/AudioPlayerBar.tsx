import React, { useState, useEffect } from 'react';
import { Track, TrackBookmark } from '../types';
import { Play, Pause, Maximize2, Sparkles, BookOpen, SkipBack, SkipForward, Share2, Check, Keyboard, X, Wallet, HeartHandshake, CreditCard, Facebook, Twitter, Instagram, Link2, ZoomIn, ZoomOut, Move, Bookmark, BookmarkCheck, BookmarkPlus, ShieldCheck, Video, ExternalLink } from 'lucide-react';
import { audioEngine } from '../lib/audioEngine';
import { offlineCache } from '../lib/offlineCache';
import { CircularProgressRing } from './CircularProgressRing';
import { WaveformVisualizer } from './WaveformVisualizer';
import { VerticalVolumeSlider } from './VerticalVolumeSlider';
import { ProfessionalFooter } from "./ProfessionalFooter";
import { StreamMetricsVisualizer } from "./StreamMetricsVisualizer";

interface AudioPlayerBarProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onOpenFullPlayer: () => void;
  onNextTrack: () => void;
  onPrevTrack: () => void;
  onOpenTextMessages?: () => void;
  onOpenWhatsApp?: () => void;
  onOpenDownloads?: () => void;
  onOpenSignup?: () => void;
  onOpenAdmin?: () => void;
  onHome?: () => void;
  onPrevPage?: () => void;
  onNextPage?: () => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  currentTrack,
  isPlaying,
  onTogglePlay,
  onOpenFullPlayer,
  onNextTrack,
  onPrevTrack,
  onOpenTextMessages,
  onOpenWhatsApp,
  onOpenDownloads,
  onOpenSignup,
  onOpenAdmin,
  onHome,
  onPrevPage,
  onNextPage,
}) => {
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [lowPowerMode, setLowPowerMode] = useState<boolean>(false);
  const [bookmarkFeedback, setBookmarkFeedback] = useState<string | null>(null);
  const [activeBookmark, setActiveBookmark] = useState<TrackBookmark | undefined>(undefined);

  // Ad placement modal & 5-second countdown state
  const [showAdModal, setShowAdModal] = useState<boolean>(false);
  const [adCountdown, setAdCountdown] = useState<number>(5);

  useEffect(() => {
    let timer: number;
    if (showAdModal && adCountdown > 0) {
      timer = window.setTimeout(() => {
        setAdCountdown(prev => prev - 1);
      }, 1000);
    } else if (showAdModal && adCountdown === 0) {
      if (currentTrack?.id) {
        localStorage.setItem(`ad_watched_${currentTrack.id}`, 'true');
      }
      // Notify worker /ad-webhook endpoint
      fetch('/ad-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trackId: currentTrack?.id, timestamp: Date.now(), status: 'AD_WATCHED_5S' })
      }).catch(() => {});

      setShowAdModal(false);
      onTogglePlay();
    }
    return () => clearTimeout(timer);
  }, [showAdModal, adCountdown, currentTrack?.id, onTogglePlay]);

  useEffect(() => {
    const unsub = offlineCache.subscribe(() => {
      if (currentTrack?.id) {
        const bm = offlineCache.getBookmarkForTrack(currentTrack.id);
        setActiveBookmark(bm);
      }
    });
    return () => {
      if (typeof unsub === 'function') unsub();
    };
  }, [currentTrack?.id]);

  // Simulated progress timer when playing
  useEffect(() => {
    let interval: number;
    if (isPlaying && currentTrack) {
      interval = window.setInterval(() => {
        setProgress((prev) => {
          if (prev >= currentTrack.duration) {
            onNextTrack();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentTrack, onNextTrack]);

  // Reset or restore progress when track changes & save playback position to localStorage
  useEffect(() => {
    if (currentTrack) {
      // If the track was loaded with a specific timestamp bookmark, jump directly to it
      if (currentTrack.timestampBookmark !== undefined && currentTrack.timestampBookmark > 0) {
        setProgress(currentTrack.timestampBookmark);
        localStorage.setItem(`audio_pos_${currentTrack.id}`, currentTrack.timestampBookmark.toString());
      } else {
        const savedPos = localStorage.getItem(`audio_pos_${currentTrack.id}`);
        if (savedPos) {
          const parsed = parseFloat(savedPos);
          if (!isNaN(parsed) && parsed < currentTrack.duration - 3) {
            setProgress(parsed);
          } else {
            setProgress(0);
          }
        } else {
          setProgress(0);
        }
      }
    }
  }, [currentTrack?.id, currentTrack?.timestampBookmark]);

  useEffect(() => {
    if (currentTrack && progress > 0) {
      localStorage.setItem(`audio_pos_${currentTrack.id}`, progress.toString());
    }
  }, [progress, currentTrack]);

  const handleSaveBookmark = () => {
    if (!currentTrack) return;
    if (navigator.vibrate) navigator.vibrate([20, 40, 20]);

    const formatted = formatTime(progress);
    const saved = offlineCache.saveBookmark({
      trackId: currentTrack.id,
      trackTitle: currentTrack.title,
      artist: currentTrack.artist,
      albumArt: currentTrack.albumArt,
      timestamp: progress,
      duration: currentTrack.duration,
      category: currentTrack.category,
      note: `Bookmarked at ${formatted}`
    });

    setActiveBookmark(saved);
    setBookmarkFeedback(`Bookmark saved at ${formatted}!`);
    setTimeout(() => setBookmarkFeedback(null), 3000);
  };

  const handleVolumeChange = (val: number) => {
    setVolume(val);
    setIsMuted(val === 0);
    audioEngine.setMasterVolume(val);
  };

  const handleTogglePlayHaptic = () => {
    if (navigator.vibrate) navigator.vibrate([15]);

    const isPurchased = currentTrack?.id === 'trk-1' || localStorage.getItem(`purchased_${currentTrack?.id}`) === 'true';
    const isAdWatched = localStorage.getItem(`ad_watched_${currentTrack?.id}`) === 'true';

    if (!isPurchased && !isAdWatched && currentTrack) {
      setShowAdModal(true);
      setAdCountdown(5);
      return;
    }

    onTogglePlay();
  };

  const handleNextHaptic = () => {
    if (navigator.vibrate) navigator.vibrate([15]);
    onNextTrack();
  };

  const handlePrevHaptic = () => {
    if (navigator.vibrate) navigator.vibrate([15]);
    onPrevTrack();
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      audioEngine.setMasterVolume(volume || 0.8);
    } else {
      setIsMuted(true);
      audioEngine.setMasterVolume(0);
    }
  };

  if (!currentTrack) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-slate-950/95 border-t border-amber-500/20 backdrop-blur-2xl shadow-2xl transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Track Info */}
        <div className="flex items-center space-x-3 min-w-0 w-1/3">
          <div
            onClick={onOpenFullPlayer}
            className="relative w-12 h-12 rounded-xl overflow-hidden cursor-pointer group flex-shrink-0 border border-amber-500/30 shadow-md"
          >
            <img
              src={currentTrack.albumArt}
              alt={currentTrack.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/20 flex items-center justify-center transition-colors">
              <Sparkles className="w-5 h-5 text-amber-300 opacity-0 group-hover:opacity-100 transition-opacity animate-pulse" />
            </div>
          </div>

          <div className="min-w-0">
            <h4
              onClick={onOpenFullPlayer}
              className="text-xs sm:text-sm font-semibold text-amber-100 hover:text-amber-300 truncate cursor-pointer transition-colors"
            >
              {currentTrack.title}
            </h4>
            <p className="text-[11px] text-amber-300/70 truncate">{currentTrack.artist}</p>
            <div className="hidden sm:flex items-center space-x-1.5 text-[10px] text-slate-400 mt-0.5">
              <span className="px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                {currentTrack.category}
              </span>
            </div>
          </div>
        </div>

        {/* Playback Controls with Circular Animated Progress Ring & Waveform Visualizer */}
        <div className="flex flex-col items-center justify-center w-1/3 max-w-md">
          <div className="flex items-center space-x-4">
            <button
              onClick={handlePrevHaptic}
              className="text-slate-400 hover:text-amber-300 transition-colors p-1"
              title="Previous Track"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            {/* Circular Progress Ring Surrounding Play Button */}
            <CircularProgressRing
              progress={progress}
              duration={currentTrack.duration}
              isPlaying={isPlaying}
              size={54}
              strokeWidth={3}
              onSeek={(newTime) => setProgress(newTime)}
            >
              <button
                onClick={handleTogglePlayHaptic}
                className="w-9 h-9 rounded-full bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/30 hover:scale-105 active:scale-95 transition-all"
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4 fill-slate-950 text-slate-950" />
                ) : (
                  <Play className="w-4 h-4 fill-slate-950 text-slate-950 ml-0.5" />
                )}
              </button>
            </CircularProgressRing>

            <button
              onClick={handleNextHaptic}
              className="text-slate-400 hover:text-amber-300 transition-colors p-1"
              title="Next Track"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            {/* Dynamic Waveform Visualizer or Low Power Static Circular Waveform */}
            <div className="hidden lg:block">
              {lowPowerMode ? (
                <div className="flex items-center space-x-1.5 px-3 py-1 rounded-xl bg-slate-900 border border-amber-500/30 text-[10px] text-amber-300 font-mono" title="Low-Power Mode: Static Minimalist Circular Waveform">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-400 border border-amber-200 animate-pulse" />
                  <span>⚡ Low-Power Circular Wave</span>
                </div>
              ) : (
                <WaveformVisualizer isPlaying={isPlaying} preset={currentTrack.synthPreset} barCount={14} />
              )}
            </div>
          </div>

          {/* Time indicator */}
          <div className="flex items-center space-x-2 text-[10px] text-slate-400 mt-0.5 font-mono">
            <span>{formatTime(progress)}</span>
            <span>/</span>
            <span>{formatTime(currentTrack.duration)}</span>
          </div>
        </div>        {/* Right Tools & Volume */}
        <div className="flex items-center justify-end space-x-2 sm:space-x-3 w-1/3">
          <StreamMetricsVisualizer isPlaying={isPlaying} />
          {/* Bookmark Timestamp Button with Feedback */}
          <div className="relative">
            <button
              onClick={handleSaveBookmark}
              className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition-all shadow-md ${
                activeBookmark
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400/50 hover:bg-amber-500/30'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-300 border-amber-500/30'
              }`}
              title={activeBookmark ? `Update Bookmark (Current: ${formatTime(activeBookmark.timestamp)})` : 'Save Timestamp Bookmark'}
            >
              {activeBookmark ? (
                <BookmarkCheck className="w-3.5 h-3.5 text-amber-400 fill-amber-400/30" />
              ) : (
                <Bookmark className="w-3.5 h-3.5 text-amber-400" />
              )}
              <span className="hidden sm:inline">
                {activeBookmark ? `BM ${formatTime(activeBookmark.timestamp)}` : 'Bookmark'}
              </span>
            </button>

            {/* Bookmark Floating Confirmation Badge */}
            {bookmarkFeedback && (
              <div className="absolute -top-9 right-0 bg-amber-500 text-slate-950 px-2.5 py-1 rounded-lg text-[10px] font-extrabold whitespace-nowrap shadow-lg animate-bounce flex items-center space-x-1">
                <Sparkles className="w-3 h-3" />
                <span>{bookmarkFeedback}</span>
              </div>
            )}
          </div>

          {/* Vertical Volume Slider on Hover */}
          <div className="hidden sm:block">
            <VerticalVolumeSlider
              volume={volume}
              isMuted={isMuted}
              onVolumeChange={handleVolumeChange}
              onToggleMute={toggleMute}
            />
          </div>

          {/* Soaking Room Full View */}
          <button
            onClick={onOpenFullPlayer}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-medium transition-all hover:border-amber-400 shadow-md"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Soaking Room</span>
          </button>
        </div>
      </div>


      <ProfessionalFooter 
        currentTrack={currentTrack} 
        lowPowerMode={lowPowerMode} 
        setLowPowerMode={setLowPowerMode} 
        onOpenTextMessages={onOpenTextMessages}
        onOpenWhatsApp={onOpenWhatsApp}
        onOpenDownloads={onOpenDownloads}
        onOpenSignup={onOpenSignup}
        onOpenAdmin={onOpenAdmin}
        onHome={onHome}
        onPrevPage={onPrevPage}
        onNextPage={onNextPage}
      />

      {/* 5-SECOND MANDATORY AD PLACEMENT MODAL */}
      {showAdModal && currentTrack && (
        <div className="fixed inset-0 z-[100] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl text-center space-y-6 relative overflow-hidden">
            <div className="absolute -top-20 -right-20 w-48 h-48 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-400 text-xs font-bold uppercase tracking-wider">
                Sponsored Ad Placement ({adCountdown}s)
              </span>
              <h3 className="text-xl font-black text-white">Watch Ad to Unlock Stream</h3>
              <p className="text-slate-400 text-xs">
                Per ministry requirements, unpurchased tracks require a brief 5-second sponsor placement before streaming unlocks. Linking to <code className="text-amber-300">/ad-webhook</code>.
              </p>
            </div>

            {/* Ad Banner Simulator */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">
              <div className="h-32 rounded-xl bg-gradient-to-tr from-amber-600/30 to-yellow-500/20 flex items-center justify-center relative overflow-hidden border border-amber-500/30">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Video className="w-12 h-12 text-amber-400/70 animate-pulse" />
                </div>
                <div className="absolute bottom-2 right-2 bg-slate-950/80 px-2 py-0.5 rounded text-[10px] text-amber-300 font-mono">
                  Ad Duration: {adCountdown}s remaining
                </div>
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-white">JUHNKRIX Global Revival Campaign</div>
                <div className="text-[11px] text-slate-400">Supporting prophetic media outreach & Sovereign Treasury.</div>
              </div>
            </div>

            <div className="pt-2">
              <button
                disabled={adCountdown > 0}
                onClick={() => {
                  setAdCountdown(0);
                }}
                className={`w-full py-3 rounded-2xl font-black text-xs uppercase tracking-wider shadow-xl transition-all flex items-center justify-center space-x-2 ${
                  adCountdown > 0
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 hover:scale-102 cursor-pointer shadow-amber-500/30'
                }`}
              >
                {adCountdown > 0 ? (
                  <span>Please wait {adCountdown}s to unlock stream...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>UNLOCK STREAM & CONTINUE</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
