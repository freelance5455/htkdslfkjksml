import React, { useRef, useEffect, useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Download,
  Sliders,
  Music,
  Mic,
  Activity,
  Layers,
} from 'lucide-react';
import { formatTime } from '../utils/scriptUtils';

interface AudioPlayerBarProps {
  ttsAudioUrl: string | null;
  musicAudioUrl: string | null;
  currentSceneTitle?: string;
  onClearAudio?: () => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  ttsAudioUrl,
  musicAudioUrl,
  currentSceneTitle = '2027 স্কিল ভিডিও ভয়েসওভার',
}) => {
  const ttsAudioRef = useRef<HTMLAudioElement | null>(null);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [voiceVolume, setVoiceVolume] = useState<number>(1.0);
  const [musicVolume, setMusicVolume] = useState<number>(0.35);
  const [autoDucking, setAutoDucking] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showMixer, setShowMixer] = useState<boolean>(false);

  // Initialize and sync audio elements
  useEffect(() => {
    const tts = ttsAudioRef.current;
    const music = musicAudioRef.current;

    if (!tts) return;

    const handleLoadedMetadata = () => {
      setDuration(tts.duration || 0);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(tts.currentTime || 0);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
      if (music) {
        music.pause();
        music.currentTime = 0;
      }
    };

    tts.addEventListener('loadedmetadata', handleLoadedMetadata);
    tts.addEventListener('timeupdate', handleTimeUpdate);
    tts.addEventListener('ended', handleEnded);

    return () => {
      tts.removeEventListener('loadedmetadata', handleLoadedMetadata);
      tts.removeEventListener('timeupdate', handleTimeUpdate);
      tts.removeEventListener('ended', handleEnded);
    };
  }, [ttsAudioUrl]);

  // Handle Play/Pause
  const togglePlay = () => {
    const tts = ttsAudioRef.current;
    const music = musicAudioRef.current;

    if (!tts && !music) return;

    if (isPlaying) {
      if (tts) tts.pause();
      if (music) music.pause();
      setIsPlaying(false);
    } else {
      if (tts && ttsAudioUrl) {
        tts.play().catch(console.error);
      }
      if (music && musicAudioUrl) {
        // Apply auto-ducking volume
        music.volume = autoDucking && ttsAudioUrl ? musicVolume * 0.35 : musicVolume;
        music.play().catch(console.error);
      }
      setIsPlaying(true);
    }
  };

  // Handle Seek
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    if (ttsAudioRef.current) {
      ttsAudioRef.current.currentTime = newTime;
    }
    if (musicAudioRef.current) {
      musicAudioRef.current.currentTime = newTime % (musicAudioRef.current.duration || 1);
    }
  };

  // Adjust volumes
  useEffect(() => {
    if (ttsAudioRef.current) {
      ttsAudioRef.current.volume = isMuted ? 0 : voiceVolume;
    }
    if (musicAudioRef.current) {
      const targetVolume = autoDucking && isPlaying && ttsAudioUrl ? musicVolume * 0.35 : musicVolume;
      musicAudioRef.current.volume = isMuted ? 0 : targetVolume;
    }
  }, [voiceVolume, musicVolume, autoDucking, isPlaying, isMuted, ttsAudioUrl]);

  const handleDownloadCombined = (type: 'tts' | 'music') => {
    const url = type === 'tts' ? ttsAudioUrl : musicAudioUrl;
    if (!url) return;
    const a = document.createElement('a');
    a.href = url;
    a.download = type === 'tts' ? 'Gemini3.8_Voiceover_2027Skills.wav' : 'Lyria_Music_Background.wav';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const hasAnyAudio = Boolean(ttsAudioUrl || musicAudioUrl);

  if (!hasAnyAudio) {
    return (
      <div className="fixed bottom-0 inset-x-0 bg-slate-950/95 border-t border-slate-800/80 p-2.5 sm:p-4 z-30 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4 text-xs text-slate-400 font-bengali">
          <div className="flex items-center gap-2 truncate">
            <Mic className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
            <span className="truncate">
              অডিও ট্র্যাক: <strong className="text-emerald-300">"ভয়েস জেনারেট"</strong> বা <strong className="text-cyan-300">"Lyria মিউজিক"</strong> চালু করুন।
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-3 text-xs text-slate-400 font-mono flex-shrink-0">
            <span className="flex items-center gap-1.5"><Mic className="w-3.5 h-3.5 text-emerald-400" /> Gemini 3.8 Flash TTS</span>
            <span className="flex items-center gap-1.5"><Music className="w-3.5 h-3.5 text-cyan-400" /> Lyria Clip / Pro</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-0 inset-x-0 bg-slate-950/95 border-t border-slate-800 shadow-2xl shadow-black z-30 backdrop-blur-lg">
      {/* Hidden audio tags */}
      {ttsAudioUrl && <audio ref={ttsAudioRef} src={ttsAudioUrl} preload="auto" />}
      {musicAudioUrl && <audio ref={musicAudioRef} src={musicAudioUrl} preload="auto" loop />}

      <div className="max-w-7xl mx-auto px-4 py-3">
        {/* Top bar info */}
        <div className="flex items-center justify-between text-xs mb-2">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="font-bengali text-slate-200 font-medium truncate max-w-xs sm:max-w-md">
              {currentSceneTitle}
            </span>
            {ttsAudioUrl && (
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                TTS: Active
              </span>
            )}
            {musicAudioUrl && (
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                Lyria: Active
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowMixer(!showMixer)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs transition cursor-pointer ${
                showMixer
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
              aria-label="Toggle Sound Mixer"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden sm:inline font-bengali">সাউন্ড মিক্সার</span>
            </button>

            {ttsAudioUrl && (
              <button
                onClick={() => handleDownloadCombined('tts')}
                className="flex items-center gap-1 px-2.5 py-1 rounded text-xs bg-slate-800 hover:bg-slate-700 text-emerald-300 transition cursor-pointer"
                title="Download Voice WAV"
                aria-label="Download Voice Audio"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline font-mono">TTS .wav</span>
              </button>
            )}

            {musicAudioUrl && (
              <button
                onClick={() => handleDownloadCombined('music')}
                className="flex items-center gap-1 px-2.5 py-1 rounded text-xs bg-slate-800 hover:bg-slate-700 text-cyan-300 transition cursor-pointer"
                title="Download Lyria Music WAV"
                aria-label="Download Lyria Music Audio"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline font-mono">BGM .wav</span>
              </button>
            )}
          </div>
        </div>

        {/* Floating Sound Mixer Panel */}
        {showMixer && (
          <div className="mb-3 p-3 rounded-xl bg-slate-900 border border-slate-700/80 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-bengali">
            {/* Voice Track Volume */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-1 text-emerald-400 font-medium">
                  <Mic className="w-3.5 h-3.5" /> ভয়েস ট্র্যাক (TTS)
                </span>
                <span className="font-mono text-slate-400">{Math.round(voiceVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={voiceVolume}
                onChange={(e) => setVoiceVolume(parseFloat(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            {/* Music Track Volume */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-1 text-cyan-400 font-medium">
                  <Music className="w-3.5 h-3.5" /> ব্যাকগ্রাউন্ড মিউজিক (Lyria)
                </span>
                <span className="font-mono text-slate-400">{Math.round(musicVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={musicVolume}
                onChange={(e) => setMusicVolume(parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Auto Ducking Toggle */}
            <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0">
              <div className="flex flex-col">
                <span className="text-slate-200 font-medium flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-amber-400" /> অটো-ডাকিং (Auto Ducking)
                </span>
                <span className="text-[11px] text-slate-400">ভয়েস চলাকালে মিউজিক কমানো</span>
              </div>
              <button
                onClick={() => setAutoDucking(!autoDucking)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  autoDucking ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
                aria-label="Toggle Auto-Ducking"
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                    autoDucking ? 'right-1' : 'left-1'
                  }`}
                />
              </button>
            </div>
          </div>
        )}

        {/* Main playback control row */}
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            onClick={() => {
              if (ttsAudioRef.current) ttsAudioRef.current.currentTime = 0;
              if (musicAudioRef.current) musicAudioRef.current.currentTime = 0;
              setCurrentTime(0);
            }}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="Reset to Start"
            aria-label="Reset audio to start"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={togglePlay}
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-lg shadow-emerald-500/25 cursor-pointer"
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-slate-950" /> : <Play className="w-5 h-5 fill-slate-950 ml-0.5" />}
          </button>

          {/* Progress timeline */}
          <div className="flex-1 flex items-center gap-3">
            <span className="text-xs font-mono text-slate-400 w-10 text-right">
              {formatTime(currentTime)}
            </span>
            <input
              type="range"
              min="0"
              max={duration || 100}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              className="flex-1 accent-emerald-500 cursor-pointer"
              aria-label="Seek audio timeline"
            />
            <span className="text-xs font-mono text-slate-400 w-10">
              {formatTime(duration)}
            </span>
          </div>

          {/* Mute button */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title={isMuted ? 'Unmute' : 'Mute'}
            aria-label={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
