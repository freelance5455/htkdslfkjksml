import { SectionIntro, Reveal } from "./ui";
import { ArrowUpRight } from "./Icons";

const CHAPTERS = [
  {
    number: "01",
    title: "Ignition",
    time: "23:04",
    text: "A single message lights up the garage: coast road is clear. You pull the cover off the Night Spec, thumb the starter, and the city turns into a smear of sodium light.",
    quote: "Every legend starts with a bad decision.",
  },
  {
    number: "02",
    title: "The gaps",
    time: "00:12",
    text: "Four lanes of strangers. One rule: never lift. Read the traffic two cars ahead, thread the space you can see, and let every near miss feed the nitro.",
    quote: "Speed is easy. Judgement is the sport.",
  },
  {
    number: "03",
    title: "The wall",
    time: "03:30",
    text: "The headlights thin out and the coastal straight opens. Somewhere behind you a record is still standing. Tonight, it belongs to whoever wants it more.",
    quote: "The wall remembers every metre.",
  },
];

export function Story() {
  return (
    <section id="story" className="relative scroll-mt-24 overflow-hidden border-t border-white/8 py-20 sm:py-28">
      <div className="pointer-events-none absolute -right-32 top-1/4 -z-10 h-[400px] w-[400px] rounded-full bg-[radial-gradient(circle,rgba(201,250,60,0.06),transparent_65%)] blur-2xl" />
      <div className="mx-auto max-w-[1360px] px-4 sm:px-6 lg:px-10">
        <SectionIntro
          label="The story"
          title={
            <>
              Three chapters.
              <br />
              <span className="font-serif font-normal italic text-volt">One endless night.</span>
            </>
          }
          copy={
            <>
              VANTA wasn't built for the daylight. It started as a text between friends and a stretch of coast road with no cameras. Now it's a ritual: one car, one shift, and a wall of distances that never gets easier to climb.
            </>
          }
        />

        <div className="mt-10 grid gap-5 sm:mt-12 lg:grid-cols-[1.02fr_0.98fr]">
          <Reveal className="min-h-0">
            <figure className="group relative h-full min-h-[380px] overflow-hidden rounded-[24px] border border-white/12 bg-ink-800 sm:min-h-[460px]">
              <img
                src="/images/night-highway.jpg"
                alt="Light trails sweeping along a coastal highway at night"
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.03]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/30 to-ink-950/15" />
              <div className="absolute inset-x-0 top-0 flex items-start justify-between p-4 sm:p-5">
                <span className="glass rounded-full border border-white/15 px-3 py-1.5 font-mono text-[8px] uppercase tracking-[0.18em] text-bone">
                  Highway 01 · coastal route
                </span>
                <span className="font-mono text-[8px] uppercase tracking-[0.18em] text-moss-300">23:47 / 14°c</span>
              </div>

              <figcaption className="absolute inset-x-0 bottom-0 p-5 sm:p-6">
                <p className="max-w-md text-balance font-serif text-xl italic leading-snug text-bone sm:text-[26px]">
                  “The city disappears in the mirror. The road doesn't ask questions.”
                </p>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/15 pt-3.5">
                  <span className="font-mono text-[8px] uppercase tracking-[0.16em] text-moss-400">Night shift · field recording 001</span>
                  <span className="flex items-center gap-1.5 font-mono text-[8px] uppercase tracking-[0.16em] text-volt">
                    <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" /> still rolling
                  </span>
                </div>
              </figcaption>
            </figure>
          </Reveal>

          <div className="flex flex-col justify-between border-y border-white/8">
            {CHAPTERS.map((chapter, index) => (
              <Reveal key={chapter.number} delay={index * 90}>
                <article className="group flex gap-4 py-5 sm:gap-5 sm:py-6">
                  <div className="flex flex-col items-center">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-volt/30 bg-volt/8 font-mono text-[10px] font-semibold text-volt transition-colors group-hover:bg-volt group-hover:text-ink-950">
                      {chapter.number}
                    </span>
                    {index < CHAPTERS.length - 1 && <span className="mt-2 w-px flex-1 bg-gradient-to-b from-white/15 to-white/0" />}
                  </div>
                  <div className="pb-1">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <h3 className="text-[19px] font-medium tracking-tight text-bone sm:text-xl">{chapter.title}</h3>
                      <span className="font-mono text-[8px] uppercase tracking-[0.18em] text-moss-500">{chapter.time}</span>
                    </div>
                    <p className="mt-2 max-w-[28rem] text-[13px] leading-relaxed text-moss-300">{chapter.text}</p>
                    <p className="mt-2.5 font-serif text-[15px] italic text-volt/80">{chapter.quote}</p>
                  </div>
                </article>
              </Reveal>
            ))}
            <Reveal className="border-t border-white/8">
              <a
                href="#circuit"
                className="group flex items-center justify-between gap-3 py-4 font-mono text-[9px] uppercase tracking-[0.16em] text-moss-400 transition hover:text-bone"
              >
                The wall keeps the names
                <span className="flex h-7 w-7 items-center justify-center rounded-full border border-white/12 transition group-hover:border-volt group-hover:text-volt">
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </span>
              </a>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
