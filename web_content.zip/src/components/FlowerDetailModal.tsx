import { useEffect, useState } from "react";
import {
  Check,
  Copy,
  ExternalLink,
  Heart,
  MapPin,
  Sparkles,
  Sun,
  X,
} from "lucide-react";
import type { FlowerEntry } from "../types/flower";
import { useFlowerMedia } from "../hooks/useFlowerMedia";
import { FlowerImage } from "./FlowerImage";

interface FlowerDetailModalProps {
  flower: FlowerEntry | null;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onClose: () => void;
}

export function FlowerDetailModal({
  flower,
  isFavorite,
  onToggleFavorite,
  onClose,
}: FlowerDetailModalProps) {
  const [copied, setCopied] = useState(false);

  const { media } = useFlowerMedia(
    flower?.wikiQuery || "",
    flower?.latinName || "",
    flower?.enName || "",
    Boolean(flower)
  );

  useEffect(() => {
    if (!flower) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = prevOverflow;
    };
  }, [flower, onClose]);

  if (!flower) return null;

  const handleCopyInfo = async () => {
    const summary = `${flower.uzName} (${flower.latinName})\nOilasi: ${flower.family}\nMa’nosi: ${flower.meaning}\nKelib chiqishi: ${flower.origin}\n\n${flower.description}`;
    try {
      await navigator.clipboard.writeText(summary);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#2B1D22]/45 p-4 backdrop-blur-xs sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="flower-detail-title"
      onClick={onClose}
    >
      <div
        className="relative flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-[#EFE3E6] bg-[#FDF9F8] shadow-2xl lg:flex-row"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Yopish"
          className="absolute right-4 top-4 z-20 flex h-10 w-10 items-center justify-center rounded-full border border-[#EFE3E6] bg-white/95 text-[#4A2F38] transition-colors hover:bg-[#9D3C56] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56]"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Left Image Column */}
        <div className="relative flex shrink-0 flex-col bg-[#F6ECEF] lg:w-[46%]">
          <div className="aspect-[4/3] w-full lg:aspect-auto lg:h-full">
            <FlowerImage
              wikiQuery={flower.wikiQuery}
              latinName={flower.latinName}
              enName={flower.enName}
              uzName={flower.uzName}
              fallbackImage={flower.fallbackImage}
              preferFull
              className="h-full w-full"
            />
          </div>
          {media?.sourceUrl && (
            <a
              href={media.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-lg bg-white/90 px-3 py-1.5 text-xs font-medium text-[#4A2F38] backdrop-blur-xs transition-colors hover:bg-white hover:text-[#9D3C56]"
            >
              <span>Botanik manba</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          )}
        </div>

        {/* Right Information Column */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8">
          <div className="pr-10">
            <p className="text-xs font-medium text-[#8C6470]">
              <span>{flower.category}</span>
              <span aria-hidden="true" className="mx-1.5">
                ·
              </span>
              <span>{flower.family}</span>
            </p>

            <h2
              id="flower-detail-title"
              className="mt-2 font-display text-3xl font-semibold leading-tight text-[#2B1D22] sm:text-4xl"
            >
              {flower.uzName}
            </h2>

            <p className="mt-1 font-display text-lg italic text-[#7B5A64]">
              {flower.latinName} · {flower.enName}
            </p>
          </div>

          <p className="mt-5 text-[15px] leading-relaxed text-[#433036]">
            {flower.description}
          </p>

          {/* Accession-style Botanical Metadata Grid */}
          <dl className="mt-6 divide-y divide-[#EFE3E6] border-y border-[#EFE3E6] text-sm">
            <div className="grid grid-cols-3 gap-3 py-3">
              <dt className="font-medium text-[#8C6470]">Ramziy ma’nosi</dt>
              <dd className="col-span-2 font-medium text-[#2B1D22]">
                {flower.meaning}
              </dd>
            </div>
            <div className="grid grid-cols-3 gap-3 py-3">
              <dt className="flex items-center gap-1.5 font-medium text-[#8C6470]">
                <MapPin className="h-3.5 w-3.5 shrink-0" />
                <span>Kelib chiqishi</span>
              </dt>
              <dd className="col-span-2 text-[#2B1D22]">{flower.origin}</dd>
            </div>
            <div className="grid grid-cols-3 gap-3 py-3">
              <dt className="font-medium text-[#8C6470]">Rangi va fasli</dt>
              <dd className="col-span-2 text-[#2B1D22]">
                {flower.color} · {flower.season}
              </dd>
            </div>
            <div className="grid grid-cols-3 gap-3 py-3">
              <dt className="flex items-center gap-1.5 font-medium text-[#8C6470]">
                <Sparkles className="h-3.5 w-3.5 shrink-0" />
                <span>Xushbo‘yligi</span>
              </dt>
              <dd className="col-span-2 text-[#2B1D22]">{flower.fragrance}</dd>
            </div>
            <div className="grid grid-cols-3 gap-3 py-3">
              <dt className="flex items-center gap-1.5 font-medium text-[#8C6470]">
                <Sun className="h-3.5 w-3.5 shrink-0" />
                <span>Parvarish siri</span>
              </dt>
              <dd className="col-span-2 leading-relaxed text-[#433036]">
                {flower.care}
              </dd>
            </div>
          </dl>

          {media?.extract && (
            <div className="mt-5 rounded-xl border border-[#EFE3E6] bg-white p-4">
              <p className="text-xs font-semibold text-[#8C6470]">
                Xalqaro botanik ma’lumot ({media.wikiTitle || flower.latinName})
              </p>
              <p className="mt-1.5 text-xs leading-relaxed text-[#5C444C]">
                {media.extract}
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onToggleFavorite(flower.id)}
              className={`inline-flex min-h-[42px] items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56] ${
                isFavorite
                  ? "bg-[#9D3C56] text-white hover:bg-[#822D44]"
                  : "border border-[#DEC6CD] bg-white text-[#2B1D22] hover:border-[#9D3C56] hover:text-[#9D3C56]"
              }`}
            >
              <Heart
                className="h-4 w-4"
                fill={isFavorite ? "currentColor" : "none"}
              />
              <span>
                {isFavorite ? "Sevimlilarda saqlangan" : "Sevimlilarga qo‘shish"}
              </span>
            </button>

            <button
              type="button"
              onClick={handleCopyInfo}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-[#EFE3E6] bg-white px-4 py-2.5 text-sm font-medium text-[#4A2F38] transition-colors whitespace-nowrap shrink-0 hover:border-[#DEC6CD] hover:text-[#2B1D22] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#9D3C56]"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 text-[#4A6B57]" />
                  <span>Nusxa olindi</span>
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  <span>Ma’lumotdan nusxa olish</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
