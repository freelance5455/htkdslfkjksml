import { useRef } from 'react';
import { Upload } from 'lucide-react';
import type {
  AndroidPermissionKey,
  ApkBuildConfig,
  ScreenOrientation,
} from '../types/apk';
import {
  convertImageFileToPngBase64,
  renderMonogramIconBase64,
} from '../lib/iconCanvas';

interface SectionProps {
  config: ApkBuildConfig;
  previewIconUrl: string;
  onChange: (patch: Partial<ApkBuildConfig>) => void;
}

const PRESET_COLORS = [
  '#16A34A',
  '#0F172A',
  '#2563EB',
  '#0D9488',
  '#D97706',
  '#DC2626',
];

const PERMISSION_OPTIONS: {
  key: AndroidPermissionKey;
  label: string;
  desc: string;
}[] = [
  {
    key: 'INTERNET',
    label: 'INTERNET',
    desc: 'Required for loading live websites or remote APIs.',
  },
  {
    key: 'ACCESS_NETWORK_STATE',
    label: 'ACCESS_NETWORK_STATE',
    desc: 'Allows checking Wi-Fi or cellular connectivity state.',
  },
  {
    key: 'CAMERA',
    label: 'CAMERA',
    desc: 'Enables WebRTC camera capture and QR scanning.',
  },
  {
    key: 'RECORD_AUDIO',
    label: 'RECORD_AUDIO',
    desc: 'Allows microphone input inside WebView pages.',
  },
  {
    key: 'ACCESS_FINE_LOCATION',
    label: 'ACCESS_FINE_LOCATION',
    desc: 'Enables HTML5 Geolocation API precision GPS.',
  },
  {
    key: 'READ_MEDIA_IMAGES',
    label: 'READ_MEDIA_IMAGES',
    desc: 'Allows <input type="file"> photo uploads on Android 13+.',
  },
  {
    key: 'VIBRATE',
    label: 'VIBRATE',
    desc: 'Permits navigator.vibrate() haptic feedback.',
  },
  {
    key: 'POST_NOTIFICATIONS',
    label: 'POST_NOTIFICATIONS',
    desc: 'Permits Android 13+ local notification prompts.',
  },
];

export function IdentityIconSection({
  config,
  previewIconUrl,
  onChange,
}: SectionProps) {
  const iconInputRef = useRef<HTMLInputElement | null>(null);

  const handleUploadIcon = async (file: File | undefined) => {
    if (!file) return;
    try {
      const pngBase64 = await convertImageFileToPngBase64(file, 192);
      onChange({ iconBase64Png: pngBase64 });
    } catch {
      // Ignore malformed image
    }
  };

  const handleResetMonogram = () => {
    const pngBase64 = renderMonogramIconBase64(
      config.appName,
      config.themeColor,
      192
    );
    onChange({ iconBase64Png: pngBase64 });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="app-name-input"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Application Name
          </label>
          <input
            id="app-name-input"
            type="text"
            maxLength={40}
            value={config.appName}
            onChange={(e) => onChange({ appName: e.target.value })}
            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>

        <div>
          <label
            htmlFor="package-id-input"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Android Package ID
          </label>
          <input
            id="package-id-input"
            type="text"
            value={config.packageId}
            onChange={(e) => onChange({ packageId: e.target.value.trim() })}
            placeholder="com.company.myapp"
            className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="version-name-input"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Version Name
          </label>
          <input
            id="version-name-input"
            type="text"
            value={config.versionName}
            onChange={(e) => onChange({ versionName: e.target.value })}
            className="w-full px-3.5 py-2 text-sm font-mono tabular-nums bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>

        <div>
          <label
            htmlFor="version-code-input"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Version Code (Integer)
          </label>
          <input
            id="version-code-input"
            type="number"
            min={1}
            step={1}
            value={config.versionCode}
            onChange={(e) =>
              onChange({
                versionCode: Math.max(1, parseInt(e.target.value || '1', 10)),
              })
            }
            className="w-full px-3.5 py-2 text-sm font-mono tabular-nums bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>
      </div>

      {/* Launcher Icon & Theme Color */}
      <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center gap-6">
        <div className="flex items-center gap-4">
          {previewIconUrl ? (
            <img
              src={previewIconUrl}
              alt="Android Launcher Icon"
              className="w-16 h-16 rounded-2xl border border-slate-200 shrink-0"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center text-white font-display font-bold text-xl shrink-0"
              style={{ backgroundColor: config.themeColor }}
            >
              {config.appName.slice(0, 2).toUpperCase()}
            </div>
          )}
          <div>
            <div className="text-xs font-medium text-slate-900">
              Launcher Icon (192×192 PNG)
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Compiled into <code className="font-mono">res/mipmap/ic_launcher.png</code>
            </p>
            <div className="mt-2 flex items-center gap-2">
              <input
                ref={iconInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml"
                onChange={(e) => void handleUploadIcon(e.target.files?.[0])}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => iconInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap"
              >
                <Upload className="w-3.5 h-3.5" />
                Upload Icon
              </button>
              <button
                type="button"
                onClick={handleResetMonogram}
                className="px-3 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors whitespace-nowrap"
              >
                Generate Monogram
              </button>
            </div>
          </div>
        </div>

        <div className="sm:ml-auto">
          <label className="block text-xs font-medium text-slate-700 mb-2">
            Brand & Status Bar Color
          </label>
          <div className="flex items-center gap-2">
            {PRESET_COLORS.map((hex) => (
              <button
                key={hex}
                type="button"
                aria-label={`Select color ${hex}`}
                onClick={() => onChange({ themeColor: hex })}
                className={`w-7 h-7 rounded-lg border transition-transform ${
                  config.themeColor.toUpperCase() === hex
                    ? 'border-slate-900 scale-110'
                    : 'border-slate-200 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
              />
            ))}
            <input
              type="color"
              aria-label="Custom theme color"
              value={config.themeColor}
              onChange={(e) => onChange({ themeColor: e.target.value })}
              className="w-8 h-7 rounded border border-slate-200 bg-white cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export function RuntimeConfigSection({
  config,
  onChange,
}: Pick<SectionProps, 'config' | 'onChange'>) {
  const toggles: {
    key: keyof ApkBuildConfig;
    label: string;
    desc: string;
  }[] = [
    {
      key: 'enableJavaScript',
      label: 'Enable JavaScript Execution',
      desc: 'Calls WebSettings.setJavaScriptEnabled(true) inside the compiled Dalvik Activity.',
    },
    {
      key: 'enableDomStorage',
      label: 'Enable DOM & localStorage Persistence',
      desc: 'Allows web apps and offline HTML bundles to store state via localStorage and IndexedDB.',
    },
    {
      key: 'enableZoomControls',
      label: 'Enable Pinch-to-Zoom',
      desc: 'Activates built-in WebView zoom gestures while hiding on-screen zoom buttons.',
    },
    {
      key: 'pullToRefresh',
      label: 'Swipe Down to Refresh (Gradle Export)',
      desc: 'Wraps the WebView in SwipeRefreshLayout in the Android Studio source export.',
    },
    {
      key: 'allowCleartextTraffic',
      label: 'Allow Cleartext HTTP Traffic',
      desc: 'Sets android:usesCleartextTraffic="true" for local http:// or mixed-content hosts.',
    },
    {
      key: 'fullscreen',
      label: 'Immersive Fullscreen Mode',
      desc: 'Hides the Android status bar using Theme.Material.Light.NoActionBar.Fullscreen.',
    },
  ];

  return (
    <div className="space-y-5">
      <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl">
        {toggles.map((item) => {
          const checked = Boolean(config[item.key]);
          return (
            <label
              key={item.key}
              className="flex items-start justify-between gap-4 p-4 cursor-pointer hover:bg-slate-50/70 transition-colors"
            >
              <div>
                <div className="text-sm font-medium text-slate-900">
                  {item.label}
                </div>
                <div className="text-xs text-slate-500 mt-0.5">{item.desc}</div>
              </div>
              <input
                type="checkbox"
                checked={checked}
                onChange={(e) => onChange({ [item.key]: e.target.checked })}
                className="mt-1 h-4 w-4 accent-emerald-600 rounded border-slate-300 cursor-pointer shrink-0"
              />
            </label>
          );
        })}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="status-bar-style"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Status Bar Foreground
          </label>
          <select
            id="status-bar-style"
            value={config.statusBarStyle}
            onChange={(e) =>
              onChange({
                statusBarStyle: e.target.value as 'light' | 'dark',
              })
            }
            className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900"
          >
            <option value="light">Light icons (for dark theme colors)</option>
            <option value="dark">Dark icons (for light theme colors)</option>
          </select>
        </div>

        <div>
          <label
            htmlFor="custom-ua-input"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Custom User-Agent (Optional)
          </label>
          <input
            id="custom-ua-input"
            type="text"
            value={config.customUserAgent}
            onChange={(e) => onChange({ customUserAgent: e.target.value })}
            placeholder="Default Android WebView User-Agent"
            className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>
      </div>
    </div>
  );
}

export function PermissionsSdkSection({
  config,
  onChange,
}: Pick<SectionProps, 'config' | 'onChange'>) {
  const togglePermission = (key: AndroidPermissionKey) => {
    const exists = config.permissions.includes(key);
    const next = exists
      ? config.permissions.filter((p) => p !== key)
      : [...config.permissions, key];
    onChange({ permissions: next });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label
            htmlFor="orientation-select"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Screen Orientation
          </label>
          <select
            id="orientation-select"
            value={config.orientation}
            onChange={(e) =>
              onChange({ orientation: e.target.value as ScreenOrientation })
            }
            className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900"
          >
            <option value="unspecified">Auto-Rotate (System)</option>
            <option value="portrait">Portrait Locked</option>
            <option value="landscape">Landscape Locked</option>
          </select>
        </div>

        <div>
          <label
            htmlFor="min-sdk-select"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Minimum Android SDK
          </label>
          <select
            id="min-sdk-select"
            value={config.minSdkVersion}
            onChange={(e) =>
              onChange({ minSdkVersion: parseInt(e.target.value, 10) })
            }
            className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-white border border-slate-200 rounded-lg text-slate-900"
          >
            <option value={24}>API 24 (Android 7.0)</option>
            <option value={26}>API 26 (Android 8.0)</option>
            <option value={29}>API 29 (Android 10)</option>
            <option value={31}>API 31 (Android 12)</option>
          </select>
        </div>

        <div>
          <label
            htmlFor="target-sdk-select"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Target Android SDK
          </label>
          <select
            id="target-sdk-select"
            value={config.targetSdkVersion}
            onChange={(e) =>
              onChange({ targetSdkVersion: parseInt(e.target.value, 10) })
            }
            className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-white border border-slate-200 rounded-lg text-slate-900"
          >
            <option value={33}>API 33 (Android 13)</option>
            <option value={34}>API 34 (Android 14)</option>
            <option value={35}>API 35 (Android 15)</option>
          </select>
        </div>
      </div>

      <div>
        <div className="text-xs font-medium text-slate-700 mb-2">
          Android Manifest Permissions ({config.permissions.length} selected)
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {PERMISSION_OPTIONS.map((perm) => {
            const active = config.permissions.includes(perm.key);
            return (
              <label
                key={perm.key}
                className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  active
                    ? 'border-emerald-600/60 bg-emerald-50/30'
                    : 'border-slate-200 bg-white hover:bg-slate-50/70'
                }`}
              >
                <input
                  type="checkbox"
                  checked={active}
                  onChange={() => togglePermission(perm.key)}
                  className="mt-0.5 h-4 w-4 accent-emerald-600 rounded border-slate-300 shrink-0"
                />
                <div className="min-w-0">
                  <div className="text-xs font-mono font-medium text-slate-900 truncate">
                    {perm.label}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                    {perm.desc}
                  </div>
                </div>
              </label>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function SigningConfigSection({
  config,
  onChange,
}: Pick<SectionProps, 'config' | 'onChange'>) {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label
            htmlFor="signing-org-input"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Certificate Organization (CN / O)
          </label>
          <input
            id="signing-org-input"
            type="text"
            value={config.signingOrg}
            onChange={(e) => onChange({ signingOrg: e.target.value })}
            placeholder="Acme Mobile Studio"
            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>

        <div>
          <label
            htmlFor="signing-alias-input"
            className="block text-xs font-medium text-slate-700 mb-1.5"
          >
            Key Alias
          </label>
          <input
            id="signing-alias-input"
            type="text"
            value={config.signingAlias}
            onChange={(e) => onChange({ signingAlias: e.target.value })}
            placeholder="release-key"
            className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
          />
        </div>
      </div>

      <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 text-xs text-slate-600 space-y-1.5 leading-relaxed">
        <div className="font-medium text-slate-900">
          Signature & Output Specification
        </div>
        <p>
          Direct <code className="font-mono">.apk</code> downloads are signed with an ephemeral RSA-2048 X.509 certificate (<code className="font-mono">SHA256withRSA</code> PKCS#7 v1 JAR signature) ready for USB/ADB or device sideloading.
        </p>
        <p>
          Each build also generates a complete Kotlin + Gradle Android Studio project (<code className="font-mono">.zip</code>) for compiling Google Play App Bundles (<code className="font-mono">.aab</code>).
        </p>
      </div>
    </div>
  );
}
