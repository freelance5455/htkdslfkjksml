import React from 'react';

interface IconProps {
  className?: string;
  active?: boolean;
}

export const RoutineVectorIcon: React.FC<IconProps> = ({ className = 'h-5 w-5', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <rect
      x="3.5"
      y="4.5"
      width="17"
      height="16"
      rx="4"
      fill="currentColor"
      fillOpacity={active ? 0.22 : 0.08}
      stroke="currentColor"
      strokeWidth="1.7"
    />
    <path
      d="M8 2.8v3.2M16 2.8v3.2M3.8 9.2h16.4"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
    <path
      d="M8 13.4l2.1 2.1 4.4-4.2"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M15.8 16.2h1.2"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
  </svg>
);

export const PomodoroVectorIcon: React.FC<IconProps> = ({ className = 'h-5 w-5', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <circle
      cx="12"
      cy="13"
      r="8"
      fill="currentColor"
      fillOpacity={active ? 0.2 : 0.07}
      stroke="currentColor"
      strokeWidth="1.7"
    />
    <path
      d="M12 13V8.8M12 13l3.1 1.8"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M9.5 2.8h5M12 2.8v2.2M17.8 6.4l1.4-1.4"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
    <circle cx="12" cy="13" r="1.2" fill="currentColor" />
  </svg>
);

export const TimerVectorIcon: React.FC<IconProps> = ({ className = 'h-5 w-5', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path
      d="M6.5 3.5h11M6.5 20.5h11"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
    />
    <path
      d="M7.5 3.5v3.2c0 2.1 1.8 3.8 4.5 5.3-2.7 1.5-4.5 3.2-4.5 5.3v3.2h9v-3.2c0-2.1-1.8-3.8-4.5-5.3 2.7-1.5 4.5-3.2 4.5-5.3V3.5h-9z"
      fill="currentColor"
      fillOpacity={active ? 0.22 : 0.08}
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinejoin="round"
    />
    <path
      d="M9.6 18.2c.8-.7 1.6-1.1 2.4-1.1s1.6.4 2.4 1.1"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

export const AlarmVectorIcon: React.FC<IconProps> = ({ className = 'h-5 w-5', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <circle
      cx="12"
      cy="13"
      r="7.5"
      fill="currentColor"
      fillOpacity={active ? 0.22 : 0.08}
      stroke="currentColor"
      strokeWidth="1.7"
    />
    <path
      d="M5.2 5.8L3.4 7.6M18.8 5.8l1.8 1.8M7 19.3l-1.5 1.8M17 19.3l1.5 1.8"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
    <path
      d="M12 9.4V13l2.6 1.6"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const ShieldWaveIcon: React.FC<IconProps> = ({ className = 'h-4 w-4', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path
      d="M12 3.2l7 2.8v5.4c0 4.8-3 8.5-7 9.8-4-1.3-7-5-7-9.8V6l7-2.8z"
      fill="currentColor"
      fillOpacity={active ? 0.24 : 0.08}
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinejoin="round"
    />
    <path
      d="M8.8 12.2l2.2 2.2 4.4-4.4"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const BellDomeIcon: React.FC<IconProps> = ({ className = 'h-4 w-4', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path
      d="M6.2 14.8c0-3.6 2.2-6.5 5.8-6.5s5.8 2.9 5.8 6.5l1.4 2.4H4.8l1.4-2.4z"
      fill="currentColor"
      fillOpacity={active ? 0.24 : 0.08}
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinejoin="round"
    />
    <path
      d="M12 4.2v1.6M9.8 19.2a2.4 2.4 0 004.4 0"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
  </svg>
);

export const SunFocusIcon: React.FC<IconProps> = ({ className = 'h-4 w-4', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <circle
      cx="12"
      cy="12"
      r="4.2"
      fill="currentColor"
      fillOpacity={active ? 0.26 : 0.1}
      stroke="currentColor"
      strokeWidth="1.7"
    />
    <path
      d="M12 3.2v2.2M12 18.6v2.2M3.2 12h2.2M18.6 12h2.2M5.8 5.8l1.6 1.6M16.6 16.6l1.6 1.6M18.2 5.8l-1.6 1.6M7.4 16.6l-1.6 1.6"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
  </svg>
);

export const DropletPaletteIcon: React.FC<IconProps> = ({ className = 'h-4 w-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path
      d="M12 3.4c3.6 4.4 6.2 7.8 6.2 11a6.2 6.2 0 11-12.4 0c0-3.2 2.6-6.6 6.2-11z"
      fill="currentColor"
      fillOpacity="0.14"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinejoin="round"
    />
    <path
      d="M9.4 14.8a2.8 2.8 0 002.6 2.6"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
  </svg>
);

export const SoundWaveIcon: React.FC<IconProps> = ({ className = 'h-4 w-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path
      d="M4.5 9.8v4.4h3.2l4.3 3.6V6.2L7.7 9.8H4.5z"
      fill="currentColor"
      fillOpacity="0.18"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinejoin="round"
    />
    <path
      d="M15.4 9.2a4.2 4.2 0 010 5.6M18 6.8a7.4 7.4 0 010 10.4"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
  </svg>
);

export const FocusLockVectorIcon: React.FC<IconProps> = ({ className = 'h-4 w-4', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <rect
      x="5"
      y="10.5"
      width="14"
      height="10"
      rx="3.2"
      fill="currentColor"
      fillOpacity={active ? 0.24 : 0.1}
      stroke="currentColor"
      strokeWidth="1.7"
    />
    <path
      d="M8.2 10.5V7.8a3.8 3.8 0 017.6 0v2.7"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
    <circle cx="12" cy="15.4" r="1.4" fill="currentColor" />
  </svg>
);

export const StatsGraphVectorIcon: React.FC<IconProps> = ({ className = 'h-4 w-4', active }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <rect
      x="4"
      y="12.5"
      width="3.6"
      height="7.5"
      rx="1.2"
      fill="currentColor"
      fillOpacity={active ? 0.35 : 0.14}
      stroke="currentColor"
      strokeWidth="1.6"
    />
    <rect
      x="10.2"
      y="8"
      width="3.6"
      height="12"
      rx="1.2"
      fill="currentColor"
      fillOpacity={active ? 0.35 : 0.14}
      stroke="currentColor"
      strokeWidth="1.6"
    />
    <rect
      x="16.4"
      y="4.5"
      width="3.6"
      height="15.5"
      rx="1.2"
      fill="currentColor"
      fillOpacity={active ? 0.35 : 0.14}
      stroke="currentColor"
      strokeWidth="1.6"
    />
  </svg>
);
