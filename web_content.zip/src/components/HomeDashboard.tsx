import React, { useState } from 'react';
import {
  ArrowUpRight,
  ArrowDownLeft,
  PackagePlus,
  Barcode,
  AlertTriangle,
  TrendingUp,
  Package,
  DollarSign,
  ChevronRight,
} from 'lucide-react';
import { CalculatedProduct, StoreData, PeriodSummary } from '../types';
import { formatMoney, formatNumber, formatShortNumber, getTodayIso } from '../utils/formatters';
import { feedback } from '../utils/haptics';

interface HomeDashboardProps {
  store: StoreData;
  calculated: Record<string, CalculatedProduct>;
  periodSummaries: {
    today: PeriodSummary;
    thisMonth: PeriodSummary;
    thisYear: PeriodSummary;
  };
  monthlyHistory: Array<{ key: string; buy: number; rev: number; cogs: number; pr: number; margin: number }>;
  onOpenSale: () => void;
  onOpenPurchase: () => void;
  onOpenAddItem: () => void;
  onOpenScanner: () => void;
  onViewLowStock: () => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  store,
  calculated,
  periodSummaries,
  monthlyHistory,
  onOpenSale,
  onOpenPurchase,
  onOpenAddItem,
  onOpenScanner,
  onViewLowStock,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [activeChartTooltip, setActiveChartTooltip] = useState<{
    key: string;
    rev: number;
    cogs: number;
    pr: number;
  } | null>(null);

  const calcList = Object.values(calculated);
  const totalUnits = calcList.reduce((sum, item) => sum + item.qty, 0);
  const totalValuation = calcList.reduce((sum, item) => sum + item.stockValue, 0);
  const totalPurchases = calcList.reduce((sum, item) => sum + item.buy, 0);
  const totalRevenue = calcList.reduce((sum, item) => sum + item.rev, 0);
  const totalCogs = calcList.reduce((sum, item) => sum + item.cogs, 0);
  const totalNetProfit = totalRevenue - totalCogs;
  const lowStockItems = calcList.filter((item) => item.isLowStock);

  // Widget lookup
  const widgetValues: Record<string, { val: string; sub?: string; color: string }> = {
    items: { val: formatNumber(store.products.length), sub: 'Catalog Items', color: 'border-l-blue-500' },
    units: { val: formatNumber(totalUnits), sub: 'Physical Units', color: 'border-l-indigo-500' },
    value: { val: formatMoney(totalValuation, store.cur), sub: 'At Cost Price', color: 'border-l-amber-500' },
    buy: { val: formatMoney(totalPurchases, store.cur), sub: 'Stock Restocks', color: 'border-l-orange-500' },
    rev: { val: formatMoney(totalRevenue, store.cur), sub: 'Gross Invoiced', color: 'border-l-emerald-500' },
    cost: { val: formatMoney(totalCogs, store.cur), sub: 'Goods Sold', color: 'border-l-rose-500' },
    profit: {
      val: formatMoney(totalNetProfit, store.cur),
      sub: totalRevenue > 0 ? `${((totalNetProfit / totalRevenue) * 100).toFixed(1)}% margin` : 'Net Margin',
      color: totalNetProfit >= 0 ? 'border-l-emerald-500' : 'border-l-red-500',
    },
    low: { val: formatNumber(lowStockItems.length), sub: 'Need Reorder', color: 'border-l-red-600' },
    today: { val: formatMoney(periodSummaries.today.pr, store.cur), sub: "Today's Profit", color: 'border-l-teal-500' },
    month: { val: formatMoney(periodSummaries.thisMonth.pr, store.cur), sub: 'This Month', color: 'border-l-emerald-600' },
  };

  const activeWidgets = store.widgets.filter((w) => w.on);

  // Chart calculations for 12 months
  const chartData = monthlyHistory.slice(-12);
  const maxChartVal = Math.max(1, ...chartData.flatMap((d) => [d.rev, d.cogs, Math.max(0, d.pr)]));

  return (
    <div className="space-y-4 pb-20">
      {/* Top Action Buttons (Android Material quick actions) */}
      <div className="grid grid-cols-4 gap-2">
        <button
          onClick={() => {
            feedback.vibrateSoft(hapticsEnabled);
            feedback.playTap(soundEnabled);
            onOpenSale();
          }}
          className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white shadow-sm transition group"
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
            <ArrowUpRight className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">+ Sale</span>
        </button>

        <button
          onClick={() => {
            feedback.vibrateSoft(hapticsEnabled);
            feedback.playTap(soundEnabled);
            onOpenPurchase();
          }}
          className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white shadow-sm transition group"
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
            <ArrowDownLeft className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">+ Purchase</span>
        </button>

        <button
          onClick={() => {
            feedback.vibrateSoft(hapticsEnabled);
            feedback.playTap(soundEnabled);
            onOpenAddItem();
          }}
          className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-900 active:scale-95 text-white shadow-sm transition group"
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
            <PackagePlus className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">+ Item</span>
        </button>

        <button
          onClick={() => {
            feedback.vibrateSoft(hapticsEnabled);
            feedback.playTap(soundEnabled);
            onOpenScanner();
          }}
          className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-white shadow-sm transition group"
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
            <Barcode className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">Scanner</span>
        </button>
      </div>

      {/* Empty State Banner when 0 products */}
      {store.products.length === 0 && (
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs text-center space-y-2.5">
          <div className="w-10 h-10 mx-auto rounded-2xl bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400 flex items-center justify-center">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-xs text-slate-900 dark:text-white">Inventory is Empty</h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              All items were cleared. You can start fresh by adding an item or load sample inventory.
            </p>
          </div>
          <div className="flex justify-center gap-2 pt-1">
            <button
              onClick={onOpenAddItem}
              className="py-2 px-3.5 rounded-xl bg-[#d9262c] text-white font-semibold text-xs flex items-center gap-1.5 shadow-xs"
            >
              <PackagePlus className="w-3.5 h-3.5" />
              + Add Item
            </button>
          </div>
        </div>
      )}

      {/* Low Stock Alert Alert Card */}
      {lowStockItems.length > 0 && (
        <div
          onClick={onViewLowStock}
          className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-center justify-between cursor-pointer hover:bg-amber-100/70 transition"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-slate-100">
                {lowStockItems.length} {lowStockItems.length === 1 ? 'item is' : 'items are'} low in stock!
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[210px] sm:max-w-xs">
                {lowStockItems.map((i) => i.p.name).join(', ')}
              </div>
            </div>
          </div>
          <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 flex items-center gap-0.5 shrink-0">
            Restock <ChevronRight className="w-4 h-4" />
          </span>
        </div>
      )}

      {/* Metrics Widgets Grid */}
      <div>
        <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
          Business Overview
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {activeWidgets.map((w) => {
            const data = widgetValues[w.id] || { val: '0', color: 'border-l-blue-500' };
            return (
              <div
                key={w.id}
                className={`p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 border-l-4 ${data.color} shadow-xs flex flex-col justify-between`}
              >
                <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate">
                  {w.title}
                </div>
                <div className="text-base font-extrabold text-slate-900 dark:text-white mt-1 tracking-tight truncate">
                  {data.val}
                </div>
                {data.sub && (
                  <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 truncate">
                    {data.sub}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily · Monthly · Yearly Quick Performance Table */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Performance Summary
          </div>
          <span className="text-[11px] text-slate-500">Auto calculated</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 text-[11px]">
                <th className="text-left font-medium pb-2">Period</th>
                <th className="text-right font-medium pb-2">Revenue</th>
                <th className="text-right font-medium pb-2">Cost</th>
                <th className="text-right font-medium pb-2">Profit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              <tr>
                <td className="py-2.5 font-semibold text-slate-800 dark:text-slate-200">Today</td>
                <td className="py-2.5 text-right font-medium text-slate-900 dark:text-white">
                  {formatMoney(periodSummaries.today.rev, store.cur)}
                </td>
                <td className="py-2.5 text-right text-slate-500">
                  {formatMoney(periodSummaries.today.cogs, store.cur)}
                </td>
                <td className={`py-2.5 text-right font-bold ${periodSummaries.today.pr >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                  {formatMoney(periodSummaries.today.pr, store.cur)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 font-semibold text-slate-800 dark:text-slate-200">This Month</td>
                <td className="py-2.5 text-right font-medium text-slate-900 dark:text-white">
                  {formatMoney(periodSummaries.thisMonth.rev, store.cur)}
                </td>
                <td className="py-2.5 text-right text-slate-500">
                  {formatMoney(periodSummaries.thisMonth.cogs, store.cur)}
                </td>
                <td className={`py-2.5 text-right font-bold ${periodSummaries.thisMonth.pr >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                  {formatMoney(periodSummaries.thisMonth.pr, store.cur)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 font-semibold text-slate-800 dark:text-slate-200">This Year</td>
                <td className="py-2.5 text-right font-medium text-slate-900 dark:text-white">
                  {formatMoney(periodSummaries.thisYear.rev, store.cur)}
                </td>
                <td className="py-2.5 text-right text-slate-500">
                  {formatMoney(periodSummaries.thisYear.cogs, store.cur)}
                </td>
                <td className={`py-2.5 text-right font-bold ${periodSummaries.thisYear.pr >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                  {formatMoney(periodSummaries.thisYear.pr, store.cur)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* 12-Month Interactive Trend Chart */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
              12 Months Revenue vs Profit
            </div>
            <div className="text-[11px] text-slate-500">Tap bars to inspect period figures</div>
          </div>
        </div>

        {activeChartTooltip && (
          <div className="mb-2 p-2.5 rounded-xl bg-slate-900 text-white text-xs flex items-center justify-between animate-in fade-in duration-100">
            <div>
              <span className="font-bold text-amber-400">{activeChartTooltip.key}</span>
            </div>
            <div className="flex gap-3 text-[11px]">
              <span>Rev: <b>{formatMoney(activeChartTooltip.rev, store.cur)}</b></span>
              <span>Cost: <b className="text-rose-300">{formatMoney(activeChartTooltip.cogs, store.cur)}</b></span>
              <span>Profit: <b className="text-emerald-400">{formatMoney(activeChartTooltip.pr, store.cur)}</b></span>
            </div>
          </div>
        )}

        {/* SVG Chart */}
        <div className="w-full overflow-hidden">
          <svg viewBox="0 0 640 220" className="w-full h-auto select-none" role="img" aria-label="Monthly Trend">
            {/* Grid lines */}
            {[0, 1, 2, 3, 4].map((i) => {
              const y = 190 - (160 * i) / 4;
              return (
                <g key={i}>
                  <line x1="45" x2="630" y1={y} y2={y} stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeWidth="1" />
                  <text x="38" y={y + 3} textAnchor="end" className="text-[10px] fill-slate-400 dark:fill-slate-600 font-mono">
                    {formatShortNumber((maxChartVal * i) / 4)}
                  </text>
                </g>
              );
            })}

            {/* Bars */}
            {chartData.map((d, i) => {
              const n = chartData.length;
              const gw = (630 - 45) / n;
              const bw = Math.min(13, gw / 3.4);
              const cx = 45 + i * gw + gw / 2;

              const hRev = (d.rev / maxChartVal) * 160;
              const hCogs = (d.cogs / maxChartVal) * 160;
              const hPr = (Math.max(0, d.pr) / maxChartVal) * 160;

              return (
                <g
                  key={d.key}
                  className="cursor-pointer transition-opacity hover:opacity-80"
                  onClick={() => {
                    setActiveChartTooltip(d);
                    feedback.vibrateSoft(hapticsEnabled);
                  }}
                >
                  {/* Revenue Bar */}
                  <rect
                    x={cx - 1.5 * bw}
                    y={190 - hRev}
                    width={bw}
                    height={Math.max(2, hRev)}
                    rx="3"
                    className="fill-blue-600 dark:fill-blue-500"
                  />
                  {/* Cost Bar */}
                  <rect
                    x={cx - 0.5 * bw}
                    y={190 - hCogs}
                    width={bw}
                    height={Math.max(2, hCogs)}
                    rx="3"
                    className="fill-rose-500 dark:fill-rose-600"
                  />
                  {/* Profit Bar */}
                  <rect
                    x={cx + 0.5 * bw}
                    y={190 - hPr}
                    width={bw}
                    height={Math.max(2, hPr)}
                    rx="3"
                    className="fill-emerald-500 dark:fill-emerald-400"
                  />

                  {/* Label on X-axis */}
                  <text
                    x={cx}
                    y={208}
                    textAnchor="middle"
                    className="text-[9px] fill-slate-500 font-medium"
                  >
                    {d.key.slice(5)}/{d.key.slice(2, 4)}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-5 mt-2 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-blue-600" />
            <span className="text-slate-600 dark:text-slate-300">Revenue</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-rose-500" />
            <span className="text-slate-600 dark:text-slate-300">Cost</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
            <span className="text-slate-600 dark:text-slate-300">Profit</span>
          </div>
        </div>
      </div>
    </div>
  );
};
