import React, { useState, useEffect } from 'react';
import { ActiveTab } from '../types';
import { 
  Eye, 
  EyeOff, 
  Volume2, 
  Headphones, 
  RotateCcw, 
  ArrowLeft, 
  Wrench, 
  Sparkles, 
  ShieldCheck, 
  Cpu, 
  Zap, 
  Smartphone, 
  Activity, 
  CheckCircle2, 
  Layers, 
  Unlock, 
  CreditCard, 
  Languages, 
  Play,
  Download
} from 'lucide-react';
import { requestScreenWakeLock, releaseScreenWakeLock, isWakeLockActive } from '../utils/wakeLock';
import { executeAudioUnstickSequence, playSpeakerTestSound } from '../utils/audioEngine';

interface HomeDashboardProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenBillboard: () => void;
  onOpenInstallModal: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({ setActiveTab, onOpenBillboard, onOpenInstallModal }) => {
  // Master toggle state
  const [isWakeEnabled, setIsWakeEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('screensound_keep_screen_on_call');
    return saved ? JSON.parse(saved) : true;
  });

  const [isAudioFixing, setIsAudioFixing] = useState<boolean>(false);
  const [audioQuickSuccess, setAudioQuickSuccess] = useState<boolean | null>(null);
  const [isPlayingTestTone, setIsPlayingTestTone] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('screensound_keep_screen_on_call', JSON.stringify(isWakeEnabled));
    if (isWakeEnabled) {
      requestScreenWakeLock();
    } else {
      releaseScreenWakeLock();
    }
  }, [isWakeEnabled]);

  const toggleWakeLock = async () => {
    setIsWakeEnabled((prev) => !prev);
  };

  const handleQuickAudioFix = async () => {
    setIsAudioFixing(true);
    setAudioQuickSuccess(null);
    try {
      const res = await executeAudioUnstickSequence();
      setAudioQuickSuccess(res.success);
    } catch {
      setAudioQuickSuccess(false);
    } finally {
      setIsAudioFixing(false);
    }
  };

  const handlePlayTone = async () => {
    if (isPlayingTestTone) return;
    setIsPlayingTestTone(true);
    try {
      await playSpeakerTestSound();
    } finally {
      setIsPlayingTestTone(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="relative bg-gradient-to-br from-slate-900 via-slate-900 to-red-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl overflow-hidden">
        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
            <span className="font-bold text-red-500 uppercase tracking-widest font-mono">
              ScreenSound Fixer
            </span>
            <span aria-hidden="true">·</span>
            <span>العجردي لصيانة وبرمجة الجوال</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-medium">يعمل دون اتصال 100%</span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white font-heading tracking-tight leading-tight">
            حل مشاكل الشاشة والصوت بضغطة زر واحدة
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
            أداتك العملية لإبقاء شاشة الهاتف مضاءة أثناء المكالمات عند تعطل حساس القرب، وإصلاح انقطاع صوت الوسائط وإخراج الهاتف من وضع السماعة العالقة.
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => setActiveTab('screen')}
              className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg shadow-red-950 transition-all cursor-pointer"
            >
              <Eye className="w-4 h-4" />
              <span>إدارة إبقاء الشاشة</span>
            </button>

            <button
              onClick={() => setActiveTab('audio')}
              className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 font-bold text-xs sm:text-sm px-5 py-3 rounded-xl border border-slate-700 transition-all cursor-pointer"
            >
              <Volume2 className="w-4 h-4 text-red-500" />
              <span>إصلاح صوت الوسائط</span>
            </button>

            <button
              onClick={onOpenInstallModal}
              className="inline-flex items-center gap-2 bg-emerald-700 hover:bg-emerald-600 active:scale-95 text-white font-bold text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg transition-all cursor-pointer"
            >
              <Smartphone className="w-4 h-4" />
              <span>تثبيت التطبيق على الهاتف</span>
            </button>

            <a
              href="/ScreenSound_Fixer_App.zip"
              download="ScreenSound_Fixer_App.zip"
              className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 active:scale-95 text-slate-200 font-bold text-xs sm:text-sm px-5 py-3 rounded-xl border border-slate-700 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-red-500" />
              <span>تحميل نسخة طبق الأصل (ZIP)</span>
            </a>
          </div>
        </div>

        {/* Ambient radial red light */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Two Core Functional Sections: Screen Wake & Audio Fix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Section 1: إبقاء الشاشة أثناء المكالمة */}
        <div className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-6 shadow-md flex flex-col justify-between transition-all">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="w-12 h-12 rounded-2xl bg-red-600/10 text-red-500 flex items-center justify-center font-bold">
                <Eye className="w-6 h-6" />
              </div>

              <span className={`text-xs font-bold px-3 py-1 rounded-full border ${
                isWakeEnabled 
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800' 
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}>
                {isWakeEnabled ? 'مفعّل ومحفوظ' : 'متوقف حالياً'}
              </span>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white font-heading">
                إبقاء الشاشة أثناء المكالمة
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1.5 leading-relaxed">
                يمنع انطفاء الشاشة المفاجئ عند ورود أو إجراء مكالمة هاتفية، حتى إذا كان حساس القرب العلوي مسدوداً بالغبار أو معطلاً.
              </p>
            </div>

            {/* Quick Interactive Switch Card */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 flex items-center justify-between gap-4">
              <div>
                <span className="text-sm font-bold text-white block">
                  إبقاء الهاتف شغّالًا أثناء المكالمة
                </span>
                <span className="text-[11px] text-slate-400">
                  {isWakeEnabled ? 'النظام يمنع خمول الشاشة تلقائياً' : 'انقر على المفتاح للتشغيل'}
                </span>
              </div>

              <button
                type="button"
                role="switch"
                aria-checked={isWakeEnabled}
                onClick={toggleWakeLock}
                className={`relative inline-flex h-8 w-14 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  isWakeEnabled ? 'bg-red-600' : 'bg-slate-800'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-7 w-7 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                    isWakeEnabled ? '-translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">
              يشمل محاكي المكالمات وأكواد المعايرة
            </span>
            <button
              onClick={() => setActiveTab('screen')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-red-400 hover:text-red-300 transition-colors cursor-pointer"
            >
              <span>فتح الصفحة الكاملة</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Section 2: إصلاح صوت الوسائط */}
        <div className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-6 shadow-md flex flex-col justify-between transition-all">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="w-12 h-12 rounded-2xl bg-red-600/10 text-red-500 flex items-center justify-center font-bold">
                <Volume2 className="w-6 h-6" />
              </div>

              <span className="text-xs font-bold px-3 py-1 rounded-full bg-slate-950 text-slate-400 border border-slate-800">
                إصلاح مسارات الصوت
              </span>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white font-heading">
                إصلاح صوت الوسائط ومكبر الهاتف
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1.5 leading-relaxed">
                معالجة مشكلة اختفاء صوت الألعاب والفيديوهات عندما يعتقد الهاتف أن سماعة الرأس لا تزال موصولة.
              </p>
            </div>

            {/* Quick Action Buttons in Card */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                onClick={handleQuickAudioFix}
                disabled={isAudioFixing}
                className="w-full bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-xs py-3 px-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-60"
              >
                <RotateCcw className={`w-4 h-4 ${isAudioFixing ? 'animate-spin' : ''}`} />
                <span>{isAudioFixing ? 'جارٍ بث النبضات...' : 'بدء نبضات إزالة التعليق'}</span>
              </button>

              <button
                onClick={handlePlayTone}
                disabled={isPlayingTestTone}
                className="w-full bg-slate-950 hover:bg-slate-800 active:scale-95 text-slate-200 border border-slate-800 font-bold text-xs py-3 px-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 text-emerald-400 fill-current" />
                <span>{isPlayingTestTone ? 'تشغيل النغمة...' : 'تجربة مكبر الصوت'}</span>
              </button>
            </div>

            {audioQuickSuccess !== null && (
              <div className={`p-2.5 rounded-xl text-xs flex items-center gap-2 border ${
                audioQuickSuccess 
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800' 
                  : 'bg-amber-950/40 text-amber-300 border-amber-800'
              }`}>
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>
                  {audioQuickSuccess 
                    ? 'تم إرسال إشارات التفريغ الكهرومغناطيسية بنجاح إلى مكبر الصوت.' 
                    : 'تحقق من المنفذ يدوياً عبر دليل التنظيف في صفحة إصلاح الصوت.'}
                </span>
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">
              يشمل إرشادات التنظيف اليدوي باللغة العربية
            </span>
            <button
              onClick={() => setActiveTab('audio')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-red-400 hover:text-red-300 transition-colors cursor-pointer"
            >
              <span>فتح الصفحة الكاملة</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Quick Access to Al-Ajradi Shop Showcase */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-lg font-bold text-white font-heading">
              العجردي لصيانة وبرمجة الجوال
            </h3>
            <p className="text-xs text-slate-400">
              خدمات شاملة متوفرة في المحل مع أفضل أجهزة الفحص المجهري والبرمجة
            </p>
          </div>

          <button
            onClick={onOpenBillboard}
            className="inline-flex items-center gap-2 bg-red-600/10 hover:bg-red-600 hover:text-white text-red-500 text-xs font-bold px-4 py-2 rounded-xl border border-red-900/50 transition-all cursor-pointer self-start sm:self-auto"
          >
            <span>مشاهدة لوحة المحل الرسمية</span>
          </button>
        </div>

        {/* The 9 service icons row/grid */}
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-2">
          {[
            'قطع غيار أصلية',
            'إكسسوارات',
            'صيانة',
            'برمجة',
            'شحن فوري',
            'فك شفرات',
            'شرائح',
            'كروت',
            'تعريب',
          ].map((item) => (
            <div
              key={item}
              onClick={() => setActiveTab('services')}
              className="bg-slate-950 hover:bg-slate-800 border border-slate-800 p-2.5 rounded-xl text-center cursor-pointer transition-colors"
            >
              <span className="text-[11px] font-bold text-slate-300 block truncate">
                {item}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
