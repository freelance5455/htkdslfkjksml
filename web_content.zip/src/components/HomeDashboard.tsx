import { CheckCircle2, ChevronRight, Clock, Pencil, Plus, Users } from 'lucide-react';
import type { Department, GlobalOverview, ShiftType } from '../types/attendance';
import { computeDepartmentSummary, formatDisplayDate, formatShiftLabel } from '../utils/attendanceLogic';
import { MonthlyOverviewCard } from './MonthlyOverviewCard';
import { OverviewStats } from './OverviewStats';
import { ShiftToggle } from './ShiftToggle';

interface HomeDashboardProps {
  departments: Department[];
  overview: GlobalOverview;
  todayDate: string;
  selectedShift: ShiftType;
  onChangeShift: (shift: ShiftType) => void;
  onSelectDepartment: (departmentId: string) => void;
  onOpenAddDepartment: () => void;
  onOpenEditDepartment: (department: Department) => void;
}

export function HomeDashboard({
  departments,
  overview,
  todayDate,
  selectedShift,
  onChangeShift,
  onSelectDepartment,
  onOpenAddDepartment,
  onOpenEditDepartment,
}: HomeDashboardProps) {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900">
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <h1 className="text-base sm:text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap truncate">
            Daily Attendance System
          </h1>
          <button
            type="button"
            onClick={onOpenAddDepartment}
            className="min-h-[44px] px-3 sm:px-4 py-2 inline-flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] rounded-xl shadow-xs transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Department</span>
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-slate-600">
            Today · <span className="font-medium text-slate-900">{formatDisplayDate(todayDate)}</span>
          </p>
          <ShiftToggle selectedShift={selectedShift} onChangeShift={onChangeShift} />
        </div>

        <OverviewStats overview={overview} />

        <MonthlyOverviewCard
          departments={departments}
          todayDate={todayDate}
          selectedShift={selectedShift}
        />

        <section aria-labelledby="departments-heading" className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-1">
            <h2 id="departments-heading" className="text-lg font-semibold text-slate-900">
              Departments
            </h2>
            <p className="text-sm text-slate-500">
              {formatShiftLabel(selectedShift)} · {formatDisplayDate(todayDate)}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {departments.map((dept) => {
              const summary = computeDepartmentSummary(dept, todayDate, selectedShift);
              const hasAnyMarks = summary.present > 0 || summary.absent > 0;

              let statusBadge: {
                label: string;
                className: string;
                icon: 'check' | 'clock';
              };

              if (summary.submitted) {
                statusBadge = {
                  label: 'Submitted',
                  className: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                  icon: 'check',
                };
              } else if (hasAnyMarks) {
                statusBadge = {
                  label: 'In Progress',
                  className: 'bg-amber-50 text-amber-700 border-amber-200',
                  icon: 'clock',
                };
              } else {
                statusBadge = {
                  label: 'Pending',
                  className: 'bg-slate-100 text-slate-600 border-slate-200',
                  icon: 'clock',
                };
              }

              return (
                <article
                  key={dept.id}
                  className={`relative bg-white rounded-2xl border shadow-sm transition-all duration-150 hover:border-blue-300 hover:shadow-md ${
                    dept.isPrimary
                      ? 'border-blue-200 ring-1 ring-blue-600/10 md:col-span-2'
                      : 'border-slate-200/90'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => onSelectDepartment(dept.id)}
                    aria-label={`Open ${dept.name} attendance register`}
                    className="absolute inset-0 z-0 rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 cursor-pointer"
                  />
                  <div className="p-5 sm:p-6 pointer-events-none">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2.5">
                          <h3 className="text-lg sm:text-xl font-bold text-slate-900 truncate">
                            {dept.name}
                          </h3>
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg border text-xs font-semibold ${statusBadge.className}`}
                          >
                            {statusBadge.icon === 'check' ? (
                              <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                            ) : (
                              <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                            )}
                            <span>{statusBadge.label}</span>
                          </span>
                        </div>
                        <p className="mt-1 text-sm text-slate-600">
                          Supervisor: <span className="font-medium text-slate-900">{dept.supervisor}</span>
                          {dept.isPrimary && (
                            <>
                              <span className="mx-2 text-slate-300" aria-hidden="true">
                                ·
                              </span>
                              <span className="text-blue-700 font-medium">Primary Department</span>
                            </>
                          )}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => onOpenEditDepartment(dept)}
                        aria-label={`Edit ${dept.name} department`}
                        className="relative z-10 pointer-events-auto min-w-[44px] min-h-[44px] -mt-1 -mr-1 flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors shrink-0 cursor-pointer"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                        <span className="inline-flex items-center gap-1.5 font-medium text-slate-700 tabular-nums">
                          <Users className="w-4 h-4 text-slate-400" aria-hidden="true" />
                          <span>
                            {summary.total} {summary.total === 1 ? 'Worker' : 'Workers'}
                          </span>
                        </span>
                        <span className="text-slate-300" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-emerald-700 font-medium tabular-nums">
                          {summary.present} Present
                        </span>
                        <span className="text-rose-600 font-medium tabular-nums">
                          {summary.absent} Absent
                        </span>
                      </div>

                      <span className="min-h-[36px] px-3.5 py-1.5 inline-flex items-center gap-1.5 text-sm font-semibold text-[#2563EB] bg-blue-50 rounded-xl whitespace-nowrap shrink-0">
                        <span>Open Register</span>
                        <ChevronRight className="w-4 h-4" aria-hidden="true" />
                      </span>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
}
