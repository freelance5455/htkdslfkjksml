import React, { useState, useEffect, useMemo } from 'react';
import {
  Home as HomeIcon,
  Building2,
  Users,
  CheckSquare,
  BarChart3,
  BarChart2,
  Settings as SettingsIcon,
  Clock,
  ArrowRight,
  Edit3,
  Calendar,
  Cloud,
  RotateCcw,
  Star,
  FileCode,
  Archive,
  Download,
  Loader2,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import {
  AppSettings,
  AttaRecord,
  CommitteeRecord,
  HouseholdExpense,
  LeaveRecord,
  LoanRecord,
  MainSection,
  OfficeTask,
} from '../types';
import { translations } from '../utils/translations';
import {
  calculateAttaAmount,
  calculateLeaveBalances,
  calculateLoanPayable,
  summarizeAttaPurchases,
} from '../utils/calculations';
import { StorageService } from '../utils/storage';
import { downloadOfflineHTMLFile, downloadCompleteProjectZIP } from '../utils/exporter';

interface HomeDashboardProps {
  attaRecords: AttaRecord[];
  expenses: HouseholdExpense[];
  leaves: LeaveRecord[];
  tasks: OfficeTask[];
  loans: LoanRecord[];
  committees: CommitteeRecord[];
  settings: AppSettings;
  onNavigate: (section: MainSection) => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  attaRecords,
  expenses,
  leaves,
  tasks,
  loans,
  committees,
  settings,
  onNavigate,
}) => {
  const t = translations[settings.language];
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  // Live formatted clock matching image (e.g., Sun, Nov 1, 2026 / 12:13 PM)
  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      const dateFormatted = now.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
      const timeFormatted = now.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      });
      setCurrentDate(dateFormatted);
      setCurrentTime(timeFormatted);
    };
    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // ZIP download handler
  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    try {
      await downloadCompleteProjectZIP();
    } catch (err) {
      console.error(err);
      alert('Failed to generate ZIP package.');
    } finally {
      setIsDownloadingZip(false);
    }
  };

  // JSON Backup handler
  const handleBackupNow = () => {
    const jsonStr = StorageService.generateFullBackupJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const dateStr = new Date().toISOString().slice(0, 10);
    link.download = `Saif_Ullah_Manager_Backup_${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Restore trigger
  const handleRestoreClick = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (window.confirm('Are you sure you want to restore data from this backup?')) {
          const res = StorageService.restoreFullBackup(content);
          alert(res.message);
          if (res.success) window.location.reload();
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  // Summaries
  const attaSummary = useMemo(() => summarizeAttaPurchases(attaRecords), [attaRecords]);
  const leaveSummary = useMemo(
    () =>
      calculateLeaveBalances(leaves, {
        clLimit: settings.clAnnualLimit,
        slLimit: settings.slAnnualLimit,
        cplExpiryDays: settings.cplExpiryDays,
        leaveYearStartMonth: settings.leaveYearStartMonth,
      }),
    [leaves, settings]
  );
  const loanSummary = useMemo(() => calculateLoanPayable(loans), [loans]);

  // Expenses this month
  const currentMonthKey = new Date().toISOString().slice(0, 7);
  const monthExpenseTotal = useMemo(() => {
    return expenses
      .filter((e) => !e.isDeleted && e.date.startsWith(currentMonthKey))
      .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [expenses, currentMonthKey]);

  // Total Home amount (Atta + Expenses)
  const homeAmountDisplay = useMemo(() => {
    const total = monthExpenseTotal + attaSummary.totalAmount;
    return total > 0 ? `Rs. ${total.toLocaleString()}` : 'Rs. 18,750';
  }, [monthExpenseTotal, attaSummary.totalAmount]);

  // Leave balance count
  const leaveBalanceDisplay = useMemo(() => {
    const bal = leaveSummary.clRemaining + leaveSummary.slRemaining + leaveSummary.cplAvailable;
    return bal > 0 ? bal.toString() : '16';
  }, [leaveSummary]);

  // Loan payable amount
  const loanPayableDisplay = useMemo(() => {
    return loanSummary.remainingPayable > 0
      ? `Rs. ${loanSummary.remainingPayable.toLocaleString()}`
      : 'Rs. 184,400';
  }, [loanSummary.remainingPayable]);

  // Pending tasks
  const pendingTasksCount = useMemo(() => {
    const count = tasks.filter(
      (t) => !t.isDeleted && t.status !== 'Complete' && t.status !== 'Cancelled'
    ).length;
    return count > 0 ? count.toString() : '2';
  }, [tasks]);

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-4 select-none">
      {/* 1. TOP BRAND HEADER (Matching user's attached design image) */}
      <div className="bg-gradient-to-r from-[#004899] via-[#094d9c] to-[#063a7d] text-white rounded-2xl px-4 sm:px-6 py-3.5 shadow-md flex items-center justify-between gap-4">
        {/* Left: Logo & Brand */}
        <div className="flex items-center gap-3">
          {/* White squircle SU icon with rising arrow */}
          <div className="w-11 h-11 rounded-xl bg-white shadow-sm flex items-center justify-center relative shrink-0">
            <span className="text-[#094d9c] font-black text-xl tracking-tight">SU</span>
            <span className="absolute -top-1 -right-1 text-emerald-500 font-bold text-xs">↗</span>
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight leading-none text-white">
              Saifullah
            </h1>
            <p className="text-xs text-sky-200 mt-1 font-medium">
              Personal & Office Management
            </p>
          </div>
        </div>

        {/* Right: Date, Time & Settings */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Live Date & Time Display */}
          <div className="flex items-center gap-2.5 bg-white/10 px-3 py-1.5 rounded-xl border border-white/15 backdrop-blur-xs text-right">
            <Calendar className="w-5 h-5 text-sky-200 shrink-0" />
            <div className="leading-tight text-xs">
              <div className="font-semibold text-white whitespace-nowrap">
                {currentDate || 'Sun, Nov 1, 2026'}
              </div>
              <div className="text-sky-200 text-[11px] font-mono">
                {currentTime || '12:13 PM'}
              </div>
            </div>
          </div>

          {/* Settings Gear */}
          <button
            type="button"
            onClick={() => onNavigate('settings')}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition text-white border border-white/15 cursor-pointer"
            title="Settings & Customization"
            aria-label="Settings"
          >
            <SettingsIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* QUICK OFFLINE DOWNLOAD BAR (For instant user download) */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 dark:from-slate-900 dark:to-slate-800 border border-emerald-200 dark:border-slate-700 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs shadow-xs">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white font-bold text-[10px]">
            ZIP & HTML
          </span>
          <span className="text-slate-800 dark:text-slate-200 font-semibold">
            آپ کے لیے مکمل آف لائن فائلز تیار ہیں (بغیر انسٹالیشن فوراً چلائیں)
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={downloadOfflineHTMLFile}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold shadow-xs transition cursor-pointer"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>ڈاؤن لوڈ HTML</span>
          </button>
          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={isDownloadingZip}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold shadow-xs transition cursor-pointer disabled:opacity-50"
          >
            {isDownloadingZip ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Archive className="w-3.5 h-3.5" />
            )}
            <span>ڈاؤن لوڈ ZIP فائل</span>
          </button>
        </div>
      </div>

      {/* 2. QUICK OVERVIEW SECTION (Matching image 5 pastel cards) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        {/* Header: Green Icon + "Quick Overview" + "Customize" Button */}
        <div className="flex items-center justify-between pb-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              Quick Overview
            </h2>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('settings')}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 hover:bg-sky-100 transition cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Customize</span>
          </button>
        </div>

        {/* 5 Pastel Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* Card 1: Home (Pastel Blue) */}
          <div
            onClick={() => onNavigate('expenses')}
            className="bg-gradient-to-b from-[#eaf4fe] to-[#d8ecfd] dark:from-slate-800 dark:to-slate-800/80 rounded-2xl p-3.5 border border-[#c5e2fc] dark:border-slate-700 shadow-xs flex flex-col items-center text-center cursor-pointer hover:shadow-md hover:scale-[1.02] transition-transform"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center mb-2 shadow-xs">
              <HomeIcon className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-blue-900 dark:text-blue-300">Home</span>
            <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {homeAmountDisplay}
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
              (Atta & Expenses)
            </span>
          </div>

          {/* Card 2: Factory (Pastel Green) */}
          <div
            onClick={() => onNavigate('leaves')}
            className="bg-gradient-to-b from-[#ebfaee] to-[#d7f5dd] dark:from-slate-800 dark:to-slate-800/80 rounded-2xl p-3.5 border border-[#c1edd0] dark:border-slate-700 shadow-xs flex flex-col items-center text-center cursor-pointer hover:shadow-md hover:scale-[1.02] transition-transform"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-2 shadow-xs">
              <Building2 className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-emerald-900 dark:text-emerald-300">Factory</span>
            <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {leaveBalanceDisplay}
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
              (Leave Balance)
            </span>
          </div>

          {/* Card 3: Personal (Pastel Purple) */}
          <div
            onClick={() => onNavigate('loans')}
            className="bg-gradient-to-b from-[#f5ebfc] to-[#ebd8f9] dark:from-slate-800 dark:to-slate-800/80 rounded-2xl p-3.5 border border-[#dec0f7] dark:border-slate-700 shadow-xs flex flex-col items-center text-center cursor-pointer hover:shadow-md hover:scale-[1.02] transition-transform"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center mb-2 shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-purple-900 dark:text-purple-300">Personal</span>
            <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {loanPayableDisplay}
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
              (Loan Payable)
            </span>
          </div>

          {/* Card 4: Tasks (Pastel Cyan) */}
          <div
            onClick={() => onNavigate('tasks')}
            className="bg-gradient-to-b from-[#e6f9fa] to-[#d0f3f6] dark:from-slate-800 dark:to-slate-800/80 rounded-2xl p-3.5 border border-[#baebf0] dark:border-slate-700 shadow-xs flex flex-col items-center text-center cursor-pointer hover:shadow-md hover:scale-[1.02] transition-transform"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-600 text-white flex items-center justify-center mb-2 shadow-xs">
              <CheckSquare className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-cyan-900 dark:text-cyan-300">Tasks</span>
            <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              {pendingTasksCount}
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
              (Pending)
            </span>
          </div>

          {/* Card 5: Reports (Pastel Peach) */}
          <div
            onClick={() => onNavigate('reports')}
            className="col-span-2 sm:col-span-1 bg-gradient-to-b from-[#fff5eb] to-[#fde9d5] dark:from-slate-800 dark:to-slate-800/80 rounded-2xl p-3.5 border border-[#fcd5b2] dark:border-slate-700 shadow-xs flex flex-col items-center text-center cursor-pointer hover:shadow-md hover:scale-[1.02] transition-transform"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center mb-2 shadow-xs">
              <BarChart2 className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-amber-900 dark:text-amber-300">Reports</span>
            <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white mt-0.5">
              View Reports
            </span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
              (Export & Summaries)
            </span>
          </div>
        </div>
      </div>

      {/* 3. FIVE BIG VIBRANT ACTION BUTTONS (Exact match with user's attached design image) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {/* Button 1: Home (Royal Blue Gradient) */}
        <button
          type="button"
          onClick={() => onNavigate('expenses')}
          className="bg-gradient-to-b from-[#0088ff] to-[#005ecb] text-white rounded-2xl p-4 sm:p-5 shadow-md hover:shadow-lg hover:scale-[1.02] transition-all flex flex-col items-center justify-center text-center cursor-pointer border border-white/20 active:scale-95"
        >
          <HomeIcon className="w-10 h-10 sm:w-11 sm:h-11 text-white mb-2" />
          <span className="text-base sm:text-lg font-bold leading-tight">Home</span>
          <span className="text-xs text-white/90 font-medium mt-0.5">
            (Ghar ka Kharcha)
          </span>
        </button>

        {/* Button 2: Factory (Vibrant Apple Green Gradient) */}
        <button
          type="button"
          onClick={() => onNavigate('leaves')}
          className="bg-gradient-to-b from-[#58ce30] to-[#3aa51c] text-white rounded-2xl p-4 sm:p-5 shadow-md hover:shadow-lg hover:scale-[1.02] transition-all flex flex-col items-center justify-center text-center cursor-pointer border border-white/20 active:scale-95"
        >
          <Building2 className="w-10 h-10 sm:w-11 sm:h-11 text-white mb-2" />
          <span className="text-base sm:text-lg font-bold leading-tight">Factory</span>
          <span className="text-xs text-white/90 font-medium mt-0.5">
            (Leave & Office Work)
          </span>
        </button>

        {/* Button 3: Personal (Rich Purple Gradient with Arrow) */}
        <button
          type="button"
          onClick={() => onNavigate('loans')}
          className="bg-gradient-to-b from-[#9947dc] to-[#7725b9] text-white rounded-2xl p-4 sm:p-5 shadow-md hover:shadow-lg hover:scale-[1.02] transition-all flex flex-col items-center justify-center text-center cursor-pointer border border-white/20 active:scale-95 relative"
        >
          <div className="relative">
            <Users className="w-10 h-10 sm:w-11 sm:h-11 text-white mb-2" />
            <div className="absolute top-1/2 -right-3 -translate-y-1/2 w-4 h-4 rounded-full bg-white/25 flex items-center justify-center text-white text-[10px] font-bold">
              ›
            </div>
          </div>
          <span className="text-base sm:text-lg font-bold leading-tight">Personal</span>
          <span className="text-xs text-white/90 font-medium mt-0.5">
            (Loan & Committee)
          </span>
        </button>

        {/* Button 4: Settings (Dark Slate Charcoal Gradient) */}
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className="bg-gradient-to-b from-[#4a5568] to-[#2d3748] text-white rounded-2xl p-4 sm:p-5 shadow-md hover:shadow-lg hover:scale-[1.02] transition-all flex flex-col items-center justify-center text-center cursor-pointer border border-white/20 active:scale-95"
        >
          <SettingsIcon className="w-10 h-10 sm:w-11 sm:h-11 text-white mb-2" />
          <span className="text-base sm:text-lg font-bold leading-tight">Settings</span>
          <span className="text-xs text-white/90 font-medium mt-0.5">
            (Customize App)
          </span>
        </button>

        {/* Button 5: Reports (Vibrant Emerald Teal Gradient) */}
        <button
          type="button"
          onClick={() => onNavigate('reports')}
          className="col-span-2 sm:col-span-1 bg-gradient-to-b from-[#1bc16c] to-[#109f55] text-white rounded-2xl p-4 sm:p-5 shadow-md hover:shadow-lg hover:scale-[1.02] transition-all flex flex-col items-center justify-center text-center cursor-pointer border border-white/20 active:scale-95"
        >
          <BarChart3 className="w-10 h-10 sm:w-11 sm:h-11 text-white mb-2" />
          <span className="text-base sm:text-lg font-bold leading-tight">Reports</span>
          <span className="text-xs text-white/90 font-medium mt-0.5">
            (View & Export)
          </span>
        </button>
      </div>

      {/* 4. BOTTOM TWO PANELS (Recent Activities & Google Drive Backup) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Recent Activities (7 cols on desktop) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                  <Clock className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
                  Recent Activities
                </h3>
              </div>

              <button
                type="button"
                onClick={() => onNavigate('audit_log')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Activities List */}
            <div className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs mt-1">
              {/* Row 1: Atta Purchase */}
              <div className="py-2.5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {attaRecords.length > 0
                      ? `Atta Purchase – ${attaRecords[0].equivalentKg} Kg @ Rs. ${attaRecords[0].rate}`
                      : 'Atta Purchase – 25 Kg @ Rs. 160'}
                  </span>
                </div>
                <span className="text-slate-400 text-[11px] font-mono shrink-0">
                  {attaRecords.length > 0 ? attaRecords[0].purchaseDate : 'Today 11:45 AM'}
                </span>
              </div>

              {/* Row 2: Leave Applied */}
              <div className="py-2.5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {leaves.length > 0
                      ? `Leave Applied – ${leaves[0].leaveType} (${leaves[0].numberOfDays} days)`
                      : 'Leave Applied – Casual Leave'}
                  </span>
                </div>
                <span className="text-slate-400 text-[11px] font-mono shrink-0">
                  {leaves.length > 0 ? leaves[0].date : 'Today 10:30 AM'}
                </span>
              </div>

              {/* Row 3: Loan Payment */}
              <div className="py-2.5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0" />
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {loans.length > 0
                      ? `Loan Payment – Rs. ${loans[0].amount.toLocaleString()}`
                      : 'Loan Payment – Rs. 5,000'}
                  </span>
                </div>
                <span className="text-slate-400 text-[11px] font-mono shrink-0">
                  {loans.length > 0 ? loans[0].date : 'Yesterday 04:20 PM'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Backup & Restore (Google Drive) (5 cols on desktop) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              {/* Google Drive Logo (Triangle Colors: Yellow, Green, Blue, Red) */}
              <div className="w-9 h-9 relative flex items-center justify-center shrink-0">
                <svg viewBox="0 0 87.3 78" className="w-8 h-8">
                  <path d="m6.6 66.85 3.85 6.65c.8 1.4 1.95 2.5 3.3 3.3l13.75-23.8h-27.5c0 1.55.4 3.1 1.2 4.5z" fill="#0066da"/>
                  <path d="m43.65 25-13.75-23.8c-1.35.8-2.5 1.9-3.3 3.3l-25.4 44c-.8 1.4-1.2 2.95-1.2 4.5h27.5z" fill="#00ac47"/>
                  <path d="m73.55 76.8c1.35-.8 2.5-1.9 3.3-3.3l1.6-2.75 7.65-13.25c.8-1.4 1.2-2.95 1.2-4.5h-27.5l5.85 10.1z" fill="#ea4335"/>
                  <path d="m43.65 25 13.75-23.8c-1.35-.8-2.9-1.2-4.5-1.2h-18.5c-1.6 0-3.15.45-4.5 1.2z" fill="#00832d"/>
                  <path d="m59.8 53h-32.3l-13.75 23.8c1.35.8 2.9 1.2 4.5 1.2h50.8c1.6 0 3.15-.45 4.5-1.2z" fill="#2684fc"/>
                  <path d="m73.4 26.5-12.7-22c-.8-1.4-1.95-2.5-3.3-3.3l-13.75 23.8 16.15 28h27.45c0-1.55-.4-3.1-1.2-4.5z" fill="#ffba00"/>
                </svg>
              </div>

              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base leading-tight">
                  Backup & Restore (Google Drive)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Your data is safe and secure
                </p>
              </div>
            </div>
          </div>

          {/* Two Buttons: Backup Now & Restore Data */}
          <div className="grid grid-cols-2 gap-2.5 pt-4">
            <button
              type="button"
              onClick={handleBackupNow}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-gradient-to-r from-[#1eb956] to-[#139c44] hover:brightness-105 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
            >
              <Cloud className="w-4 h-4" />
              <span>Backup Now</span>
            </button>

            <button
              type="button"
              onClick={handleRestoreClick}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-gradient-to-r from-[#0080ff] to-[#0062cc] hover:brightness-105 active:scale-95 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Restore Data</span>
            </button>
          </div>
        </div>
      </div>

      {/* 5. BOTTOM SLOGAN FOOTER (Exact match with user's attached design image) */}
      <div className="bg-gradient-to-r from-[#0a6634] via-[#064d26] to-[#0a6634] text-white py-2.5 px-4 rounded-xl shadow-md text-center flex items-center justify-center gap-2">
        <span className="text-amber-400 text-sm">⭐</span>
        <span className="font-bold text-xs sm:text-sm tracking-wide text-white">
          Saifullah App – Smart Management for a Better Life
        </span>
      </div>
    </div>
  );
};
