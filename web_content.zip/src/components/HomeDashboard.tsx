import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  Volume2,
  CheckCircle2,
  Circle,
  Plus,
  ArrowRight,
  TrendingUp,
  Clock,
  Calendar,
  Wallet,
  Zap,
  Target,
  Bell,
  Check,
  Flame,
  ChevronRight,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const HomeDashboard: React.FC = () => {
  const {
    profile,
    tasks,
    toggleTask,
    reminders,
    toggleReminder,
    habits,
    toggleHabit,
    transactions,
    monthlyBudget,
    totalExpense,
    setActiveScreen,
    speakText,
    isSpeaking,
    setQuickActionOpen,
  } = useApp();

  // Dynamic greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const completedTasks = tasks.filter((t) => t.completed).length;
  const totalTasks = tasks.length;
  const taskProgress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const completedHabits = habits.filter((h) => h.completedToday).length;
  const totalHabits = habits.length;

  const remainingBudget = Math.max(0, monthlyBudget - totalExpense);
  const budgetPercent = Math.min(100, Math.round((totalExpense / monthlyBudget) * 100));

  const briefingText = `Good day, ${profile.name}! You have ${totalTasks - completedTasks} pending priorities today, featuring a prime focus session scheduled this morning. Your hydration habit streak is at 19 days, and you are comfortably on track with 39% remaining in your monthly budget. Take one task at a time.`;

  const handleSpeakBriefing = () => {
    sound.playClick();
    speakText(briefingText);
  };

  return (
    <div className="pb-24 pt-3 px-4 max-w-md mx-auto space-y-5">
      {/* 1. Header & Dynamic Greeting */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>DAILY BRIEFING</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {getGreeting()}, {profile.name.split(' ')[0]}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {new Date().toLocaleDateString('en-US', {
              weekday: 'long',
              month: 'short',
              day: 'numeric',
            })}
          </p>
        </div>

        {/* User Avatar with status */}
        <button
          onClick={() => {
            sound.playClick();
            setActiveScreen('profile');
          }}
          className="relative group p-0.5 rounded-full ring-2 ring-indigo-500/30 hover:ring-indigo-500 transition-all"
        >
          <img
            src={profile.avatarUrl}
            alt={profile.name}
            className="w-11 h-11 rounded-full object-cover"
            referrerPolicy="no-referrer"
          />
          <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
        </button>
      </div>

      {/* 2. AI-Powered Daily Briefing Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-indigo-800 text-white p-5 shadow-xl shadow-indigo-600/20">
        {/* Soft background glow */}
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-sky-400/20 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full overflow-hidden bg-white/20 p-0.5 backdrop-blur-xs">
                <img
                  src="/src/assets/images/hibuddy_orb_avatar_1794042543018.jpg"
                  alt="HiBuddy"
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="text-xs font-semibold tracking-wide uppercase text-indigo-100">
                HiBuddy Insight
              </span>
            </div>

            <button
              onClick={handleSpeakBriefing}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                isSpeaking
                  ? 'bg-white text-indigo-700 shadow-sm animate-pulse'
                  : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>{isSpeaking ? 'Listening...' : 'Listen'}</span>
            </button>
          </div>

          <p className="text-xs sm:text-sm font-normal text-indigo-50 leading-relaxed">
            {briefingText}
          </p>

          <div className="pt-1 flex items-center justify-between border-t border-white/15 text-xs text-indigo-100">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-300" /> 19-day streak
              </span>
              <span>·</span>
              <span>{totalTasks - completedTasks} tasks to go</span>
            </div>
            <button
              onClick={() => {
                sound.playClick();
                setActiveScreen('buddy');
              }}
              className="flex items-center gap-1 text-white font-medium hover:underline text-xs"
            >
              <span>Ask Buddy</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 3. Daily Goals & Progress Overview */}
      <div className="grid grid-cols-3 gap-2.5">
        {/* Tasks Progress */}
        <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Tasks</span>
            <CheckCircle2 className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="my-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
              {completedTasks}/{totalTasks}
            </span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-indigo-600 h-full rounded-full transition-all duration-500"
              style={{ width: `${taskProgress}%` }}
            />
          </div>
        </div>

        {/* Habits Progress */}
        <div
          onClick={() => {
            sound.playClick();
            setActiveScreen('goals');
          }}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex flex-col justify-between cursor-pointer hover:border-slate-300 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Habits</span>
            <Target className="w-4 h-4 text-rose-500" />
          </div>
          <div className="my-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
              {completedHabits}/{totalHabits}
            </span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-rose-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${(completedHabits / totalHabits) * 100}%` }}
            />
          </div>
        </div>

        {/* Money Remaining */}
        <div
          onClick={() => {
            sound.playClick();
            setActiveScreen('money');
          }}
          className="p-3.5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex flex-col justify-between cursor-pointer hover:border-slate-300 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Budget</span>
            <Wallet className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="my-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
              ${remainingBudget}
            </span>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                budgetPercent > 80 ? 'bg-amber-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${budgetPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* 4. Quick Actions Row */}
      <div className="flex items-center justify-between gap-2">
        <button
          onClick={() => setQuickActionOpen(true)}
          className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border border-indigo-200/80 dark:border-indigo-800/80 text-xs font-semibold text-indigo-700 dark:text-indigo-300 flex items-center justify-center gap-1.5 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Action</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveScreen('planner');
          }}
          className="flex-1 py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
        >
          <Calendar className="w-4 h-4 text-indigo-500" />
          <span>Full Planner</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveScreen('buddy');
          }}
          className="flex-1 py-2.5 px-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
        >
          <Sparkles className="w-4 h-4 text-violet-500" />
          <span>Chat AI</span>
        </button>
      </div>

      {/* 5. Today's Tasks */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">
              Today's Schedule
            </h3>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              {completedTasks}/{totalTasks}
            </span>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              setActiveScreen('planner');
            }}
            className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2">
          {tasks.slice(0, 4).map((task) => (
            <div
              key={task.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-start gap-3 ${
                task.completed
                  ? 'bg-slate-50/80 dark:bg-slate-900/50 border-slate-200/60 dark:border-slate-800 opacity-75'
                  : 'bg-white dark:bg-slate-800/90 border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-slate-300'
              }`}
            >
              <button
                onClick={() => toggleTask(task.id)}
                className="mt-0.5 text-slate-400 hover:text-indigo-600 transition-colors"
                aria-label={task.completed ? 'Mark incomplete' : 'Mark completed'}
              >
                {task.completed ? (
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                ) : (
                  <Circle className="w-5 h-5 hover:text-indigo-500" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <p
                  className={`text-xs sm:text-sm font-semibold truncate ${
                    task.completed
                      ? 'line-through text-slate-400 dark:text-slate-500'
                      : 'text-slate-900 dark:text-white'
                  }`}
                >
                  {task.title}
                </p>
                <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  <span className="flex items-center gap-1 font-mono">
                    <Clock className="w-3 h-3" />
                    {task.time}
                  </span>
                  <span>·</span>
                  <span className="capitalize">{task.category}</span>
                  {task.priority === 'high' && (
                    <>
                      <span>·</span>
                      <span className="text-rose-500 font-medium">Priority</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6. Upcoming Reminders */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white tracking-tight">
              Reminders
            </h3>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {reminders.filter((r) => !r.completed).length} active
          </span>
        </div>

        <div className="space-y-1.5">
          {reminders.slice(0, 3).map((reminder) => (
            <div
              key={reminder.id}
              onClick={() => toggleReminder(reminder.id)}
              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                reminder.completed
                  ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
                  : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 shadow-xs hover:border-slate-300'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                    reminder.completed
                      ? 'border-indigo-600 bg-indigo-600 text-white'
                      : 'border-slate-400'
                  }`}
                >
                  {reminder.completed && <Check className="w-3 h-3" />}
                </div>
                <span
                  className={`text-xs font-medium truncate ${
                    reminder.completed
                      ? 'line-through text-slate-400'
                      : 'text-slate-800 dark:text-slate-200'
                  }`}
                >
                  {reminder.title}
                </span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono shrink-0 ml-2">
                {reminder.timeStr}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 7. Money Snapshot Card */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Monthly Spending
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                ${totalExpense.toFixed(2)} spent of ${monthlyBudget} budget
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              setActiveScreen('money');
            }}
            className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            Details
          </button>
        </div>

        {/* Progress gauge */}
        <div className="w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
          <div
            className="bg-emerald-500 h-full rounded-full transition-all duration-500"
            style={{ width: `${budgetPercent}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>{budgetPercent}% used</span>
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            ${remainingBudget.toFixed(2)} safe to spend
          </span>
        </div>
      </div>
    </div>
  );
};
