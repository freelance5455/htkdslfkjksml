import React from 'react';
import { PromoBanner } from './PromoBanner';
import { ChapterData } from '../data/biologyData';

interface HomeDashboardProps {
  selectedClass: '11' | '12';
  onSelectCategory: (category: 'premium_notes' | 'handwritten_notes' | 'ncert_book' | 'ncert_solutions' | 'video_classes' | 'mcq_pdf' | 'important_questions' | 'mind_maps') => void;
  onOpenPremium: () => void;
  isPremiumUser: boolean;
  onViewAll: () => void;
  onSelectChapter: (chapter: ChapterData) => void;
  recentChapter: ChapterData;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  selectedClass,
  onSelectCategory,
  onOpenPremium,
  isPremiumUser,
  onViewAll,
  onSelectChapter,
  recentChapter,
}) => {
  return (
    <div className="w-full pb-20">
      {/* Top Promotional Carousel Banner */}
      <PromoBanner onOpenPremium={onOpenPremium} isPremiumUser={isPremiumUser} />

      <main className="max-w-md mx-auto px-4 pt-3 space-y-5">
        {/* SECTION 1: कक्षा 11 जीव विज्ञान नोट्स */}
        <section aria-labelledby="section-notes-heading">
          <h2
            id="section-notes-heading"
            className="text-base font-bold text-slate-800 tracking-tight font-devanagari mb-2.5"
          >
            कक्षा {selectedClass} जीव विज्ञान नोट्स
          </h2>

          {/* Two Large Cards: प्रीमियम नोट्स & हस्तलिखित नोट्स */}
          <div className="grid grid-cols-2 gap-3">
            {/* Card 1: प्रीमियम नोट्स */}
            <button
              onClick={() => onSelectCategory('premium_notes')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center gap-3 text-left shadow-sm hover:shadow transition-all group active:scale-[0.98] border-l-4 border-l-sky-500"
            >
              {/* Spiral Notebook with Pencil Illustration */}
              <div className="w-12 h-12 shrink-0 flex items-center justify-center">
                <svg viewBox="0 0 64 64" className="w-12 h-12 drop-shadow-sm" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Notebook Body */}
                  <rect x="14" y="8" width="40" height="48" rx="6" fill="#E2E8F0" />
                  <rect x="18" y="10" width="34" height="44" rx="4" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="2" />
                  {/* Ruled lines */}
                  <line x1="22" y1="18" x2="48" y2="18" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="24" x2="48" y2="24" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="30" x2="48" y2="30" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="36" x2="42" y2="36" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="42" x2="46" y2="42" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  {/* Spiral bindings on left */}
                  <circle cx="15" cy="16" r="2" fill="#64748B" />
                  <circle cx="15" cy="24" r="2" fill="#64748B" />
                  <circle cx="15" cy="32" r="2" fill="#64748B" />
                  <circle cx="15" cy="40" r="2" fill="#64748B" />
                  <circle cx="15" cy="48" r="2" fill="#64748B" />
                  <path d="M13 16C13 16 11 15 11 16C11 17 13 17 15 17" stroke="#475569" strokeWidth="2" strokeLinecap="round" />
                  <path d="M13 24C13 24 11 23 11 24C11 25 13 25 15 25" stroke="#475569" strokeWidth="2" strokeLinecap="round" />
                  <path d="M13 32C13 32 11 31 11 32C11 33 13 33 15 33" stroke="#475569" strokeWidth="2" strokeLinecap="round" />
                  <path d="M13 40C13 40 11 39 11 40C11 41 13 41 15 41" stroke="#475569" strokeWidth="2" strokeLinecap="round" />
                  <path d="M13 48C13 48 11 47 11 48C11 49 13 49 15 49" stroke="#475569" strokeWidth="2" strokeLinecap="round" />
                  {/* Diagonal pencil */}
                  <g transform="rotate(25 42 36)">
                    <rect x="36" y="16" width="6" height="26" rx="1" fill="#F59E0B" stroke="#B45309" strokeWidth="1" />
                    <polygon points="36,42 42,42 39,48" fill="#FDE68A" stroke="#B45309" strokeWidth="1" />
                    <polygon points="38,46 40,46 39,48" fill="#1E293B" />
                    <rect x="36" y="12" width="6" height="4" fill="#F43F5E" />
                    <rect x="36" y="16" width="6" height="2" fill="#94A3B8" />
                  </g>
                </svg>
              </div>

              <div>
                <span className="text-base font-bold text-slate-800 font-devanagari block leading-tight group-hover:text-sky-600 transition-colors">
                  प्रीमियम
                </span>
                <span className="text-base font-bold text-slate-800 font-devanagari block leading-tight group-hover:text-sky-600 transition-colors">
                  नोट्स
                </span>
              </div>
            </button>

            {/* Card 2: हस्तलिखित नोट्स */}
            <button
              onClick={() => onSelectCategory('handwritten_notes')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center gap-3 text-left shadow-sm hover:shadow transition-all group active:scale-[0.98] border-l-4 border-l-teal-500"
            >
              {/* Spiral Notebook with Pencil Illustration */}
              <div className="w-12 h-12 shrink-0 flex items-center justify-center">
                <svg viewBox="0 0 64 64" className="w-12 h-12 drop-shadow-sm" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="14" y="8" width="40" height="48" rx="6" fill="#E2E8F0" />
                  <rect x="18" y="10" width="34" height="44" rx="4" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="2" />
                  <line x1="22" y1="18" x2="48" y2="18" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="24" x2="48" y2="24" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="30" x2="48" y2="30" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="36" x2="44" y2="36" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <line x1="22" y1="42" x2="46" y2="42" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                  <circle cx="15" cy="16" r="2" fill="#64748B" />
                  <circle cx="15" cy="24" r="2" fill="#64748B" />
                  <circle cx="15" cy="32" r="2" fill="#64748B" />
                  <circle cx="15" cy="40" r="2" fill="#64748B" />
                  <circle cx="15" cy="48" r="2" fill="#64748B" />
                  {/* Diagonal pencil */}
                  <g transform="rotate(25 42 36)">
                    <rect x="36" y="16" width="6" height="26" rx="1" fill="#F59E0B" stroke="#B45309" strokeWidth="1" />
                    <polygon points="36,42 42,42 39,48" fill="#FDE68A" stroke="#B45309" strokeWidth="1" />
                    <polygon points="38,46 40,46 39,48" fill="#1E293B" />
                    <rect x="36" y="12" width="6" height="4" fill="#F43F5E" />
                    <rect x="36" y="16" width="6" height="2" fill="#94A3B8" />
                  </g>
                </svg>
              </div>

              <div>
                <span className="text-base font-bold text-slate-800 font-devanagari block leading-tight group-hover:text-teal-600 transition-colors">
                  हस्तलिखित
                </span>
                <span className="text-base font-bold text-slate-800 font-devanagari block leading-tight group-hover:text-teal-600 transition-colors">
                  नोट्स
                </span>
              </div>
            </button>
          </div>
        </section>

        {/* SECTION 2: कक्षा 11 जीव विज्ञान अन्य */}
        <section aria-labelledby="section-other-heading">
          <div className="flex items-center justify-between mb-2.5">
            <h2
              id="section-other-heading"
              className="text-base font-bold text-slate-800 tracking-tight font-devanagari"
            >
              कक्षा {selectedClass} जीव विज्ञान अन्य
            </h2>
            <button
              onClick={onViewAll}
              className="text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200 px-3 py-1 rounded-lg transition-colors font-devanagari cursor-pointer active:scale-95"
            >
              सभी देखें
            </button>
          </div>

          {/* 6-Grid matching exact layout of screenshot */}
          <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
            {/* 1. NCERT बुक */}
            <button
              onClick={() => onSelectCategory('ncert_book')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-sm hover:shadow transition-all group active:scale-95 min-h-[110px]"
            >
              <div className="w-12 h-12 flex items-center justify-center mb-1.5">
                {/* 3 Colorful Stacked Books Illustration */}
                <svg viewBox="0 0 64 64" className="w-11 h-11" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Bottom book (amber) */}
                  <path d="M12 44L34 52L52 44L30 36L12 44Z" fill="#F59E0B" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M12 44V49L34 57V52L12 44Z" fill="#D97706" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M34 57L52 49V44L34 52V57Z" fill="#FEF3C7" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  {/* Middle book (red/crimson) */}
                  <path d="M12 33L34 41L52 33L30 25L12 33Z" fill="#EF4444" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M12 33V38L34 46V41L12 33Z" fill="#DC2626" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M34 46L52 38V33L34 41V46Z" fill="#FEE2E2" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  {/* Top book (blue) */}
                  <path d="M12 22L34 30L52 22L30 14L12 22Z" fill="#3B82F6" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M12 22V27L34 35V30L12 22Z" fill="#2563EB" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M34 35L52 27V22L34 30V35Z" fill="#DBEAFE" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                </svg>
              </div>
              <span className="text-xs font-bold text-slate-800 font-devanagari group-hover:text-sky-600 transition-colors">
                NCERT बुक
              </span>
            </button>

            {/* 2. NCERT समाधान */}
            <button
              onClick={() => onSelectCategory('ncert_solutions')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-sm hover:shadow transition-all group active:scale-95 min-h-[110px]"
            >
              <div className="w-12 h-12 flex items-center justify-center mb-1.5">
                {/* Lightbulb over Open Book Illustration */}
                <svg viewBox="0 0 64 64" className="w-11 h-11" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Open Book */}
                  <path d="M14 42C20 40 28 41 32 44C36 41 44 40 50 42V54C44 52 36 53 32 56C28 53 20 52 14 54V42Z" fill="#E0F2FE" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M32 44V56" stroke="#000" strokeWidth="2" />
                  {/* Lightbulb head */}
                  <circle cx="32" cy="24" r="12" fill="#FDE047" stroke="#000" strokeWidth="2" />
                  <path d="M26 34H38V38C38 39.5 36.5 41 35 41H29C27.5 41 26 39.5 26 38V34Z" fill="#CBD5E1" stroke="#000" strokeWidth="2" />
                  {/* Eyes & Smile */}
                  <circle cx="28" cy="22" r="1.5" fill="#000" />
                  <circle cx="36" cy="22" r="1.5" fill="#000" />
                  <path d="M29 27C30.5 29 33.5 29 35 27" stroke="#000" strokeWidth="1.5" strokeLinecap="round" />
                  {/* Light rays */}
                  <line x1="32" y1="6" x2="32" y2="9" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                  <line x1="18" y1="12" x2="20" y2="15" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                  <line x1="46" y1="12" x2="44" y2="15" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <span className="text-xs font-bold text-slate-800 font-devanagari group-hover:text-sky-600 transition-colors">
                NCERT समाधान
              </span>
            </button>

            {/* 3. वीडियो कक्षाएँ */}
            <button
              onClick={() => onSelectCategory('video_classes')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-sm hover:shadow transition-all group active:scale-95 min-h-[110px]"
            >
              <div className="w-12 h-12 flex items-center justify-center mb-1.5">
                {/* Computer Monitor with formula & Play button */}
                <svg viewBox="0 0 64 64" className="w-11 h-11" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Monitor Stand */}
                  <rect x="22" y="52" width="20" height="3" rx="1.5" fill="#64748B" stroke="#000" strokeWidth="2" />
                  <path d="M30 46H34V52H30V46Z" fill="#94A3B8" stroke="#000" strokeWidth="2" />
                  {/* Monitor Body */}
                  <rect x="10" y="14" width="44" height="32" rx="4" fill="#0284C7" stroke="#000" strokeWidth="2" />
                  <rect x="13" y="17" width="38" height="26" rx="2" fill="#F0F9FF" />
                  {/* Play badge at top */}
                  <rect x="26" y="12" width="12" height="7" rx="2" fill="#EF4444" stroke="#000" strokeWidth="1.5" />
                  <polygon points="31,14 34,15.5 31,17" fill="#FFF" />
                  {/* Text formula on screen: E=mc² */}
                  <text x="32" y="34" fontSize="9" fontWeight="bold" fontFamily="sans-serif" textAnchor="middle" fill="#0369A1">E=mc²</text>
                </svg>
              </div>
              <span className="text-xs font-bold text-slate-800 font-devanagari group-hover:text-sky-600 transition-colors">
                वीडियो कक्षाएँ
              </span>
            </button>

            {/* 4. MCQs पीडीएफ़ */}
            <button
              onClick={() => onSelectCategory('mcq_pdf')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-sm hover:shadow transition-all group active:scale-95 min-h-[110px]"
            >
              <div className="w-12 h-12 flex items-center justify-center mb-1.5">
                {/* Question bubble with question mark */}
                <svg viewBox="0 0 64 64" className="w-11 h-11" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Green double speech bubble */}
                  <path d="M14 28C14 18 22 10 32 10C42 10 50 18 50 28C50 38 42 46 32 46C29 46 26 45 23 44L14 48L16 40C14.5 36.5 14 32.5 14 28Z" fill="#86EFAC" stroke="#16A34A" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M20 28C20 22 25 17 32 17C39 17 44 22 44 28C44 34 39 39 32 39C30 39 28 38.5 26 38L21 40L22 35C20.5 33 20 30.5 20 28Z" fill="#DCFCE7" stroke="#16A34A" strokeWidth="1.5" />
                  {/* Orange Question Mark Badge */}
                  <circle cx="21" cy="20" r="7" fill="#F97316" stroke="#000" strokeWidth="1.5" />
                  <text x="21" y="24" fontSize="10" fontWeight="bold" fontFamily="sans-serif" textAnchor="middle" fill="#FFF">?</text>
                  {/* Small inner question mark */}
                  <path d="M30 24C30 22 31.5 21 33 21C34.5 21 35.5 22 35.5 23.5C35.5 25 33 26 33 28" stroke="#166534" strokeWidth="2" strokeLinecap="round" />
                  <circle cx="33" cy="32" r="1" fill="#166534" />
                </svg>
              </div>
              <span className="text-xs font-bold text-slate-800 font-devanagari group-hover:text-sky-600 transition-colors">
                MCQs पीडीएफ़
              </span>
            </button>

            {/* 5. महत्वपूर्ण प्रश्नोत्तर */}
            <button
              onClick={() => onSelectCategory('important_questions')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-sm hover:shadow transition-all group active:scale-95 min-h-[110px]"
            >
              <div className="w-12 h-12 flex items-center justify-center mb-1.5">
                {/* Q&A document blocks with smiley face */}
                <svg viewBox="0 0 64 64" className="w-11 h-11" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Top Block (Q:) */}
                  <rect x="14" y="14" width="36" height="14" rx="3" fill="#FDE047" stroke="#000" strokeWidth="2" />
                  <text x="18" y="25" fontSize="9" fontWeight="bold" fontFamily="sans-serif" fill="#000">Q =</text>
                  <line x1="32" y1="20" x2="44" y2="20" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                  <line x1="32" y1="24" x2="41" y2="24" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                  {/* Bottom Block (A:) */}
                  <rect x="14" y="32" width="36" height="15" rx="3" fill="#4ADE80" stroke="#000" strokeWidth="2" />
                  <text x="18" y="44" fontSize="9" fontWeight="bold" fontFamily="sans-serif" fill="#000">A =</text>
                  <line x1="32" y1="38" x2="44" y2="38" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                  {/* Yellow smiley icon on right */}
                  <circle cx="43" cy="46" r="5" fill="#FACC15" stroke="#000" strokeWidth="1.5" />
                  <circle cx="41.5" cy="45" r="0.8" fill="#000" />
                  <circle cx="44.5" cy="45" r="0.8" fill="#000" />
                  <path d="M41.5 47.5C42.2 48.5 43.8 48.5 44.5 47.5" stroke="#000" strokeWidth="1" strokeLinecap="round" />
                </svg>
              </div>
              <span className="text-xs font-bold text-slate-800 font-devanagari group-hover:text-sky-600 transition-colors">
                महत्वपूर्ण प्रश्नोत्तर
              </span>
            </button>

            {/* 6. माइंड मैप */}
            <button
              onClick={() => onSelectCategory('mind_maps')}
              className="bg-white hover:bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-sm hover:shadow transition-all group active:scale-95 min-h-[110px]"
            >
              <div className="w-12 h-12 flex items-center justify-center mb-1.5">
                {/* Mind Map Lightbulb character studying */}
                <svg viewBox="0 0 64 64" className="w-11 h-11" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Open Book at bottom */}
                  <path d="M14 42C20 40 28 41 32 44C36 41 44 40 50 42V54C44 52 36 53 32 56C28 53 20 52 14 54V42Z" fill="#FCE7F3" stroke="#000" strokeWidth="2" strokeLinejoin="round" />
                  <path d="M32 44V56" stroke="#000" strokeWidth="2" />
                  {/* Lightbulb head */}
                  <circle cx="32" cy="24" r="12" fill="#FDE047" stroke="#000" strokeWidth="2" />
                  <path d="M26 34H38V38C38 39.5 36.5 41 35 41H29C27.5 41 26 39.5 26 38V34Z" fill="#CBD5E1" stroke="#000" strokeWidth="2" />
                  {/* Closed happy eyes & smile */}
                  <path d="M26 23C27 21 29 21 30 23" stroke="#000" strokeWidth="1.5" strokeLinecap="round" />
                  <path d="M34 23C35 21 37 21 38 23" stroke="#000" strokeWidth="1.5" strokeLinecap="round" />
                  <path d="M29 27C30.5 29 33.5 29 35 27" stroke="#000" strokeWidth="1.5" strokeLinecap="round" />
                  {/* Pink cheeks */}
                  <circle cx="26" cy="25" r="1.5" fill="#F472B6" />
                  <circle cx="38" cy="25" r="1.5" fill="#F472B6" />
                  {/* Light spark rays */}
                  <line x1="32" y1="6" x2="32" y2="9" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                  <line x1="18" y1="12" x2="20" y2="15" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                  <line x1="46" y1="12" x2="44" y2="15" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <span className="text-xs font-bold text-slate-800 font-devanagari group-hover:text-sky-600 transition-colors">
                माइंड मैप
              </span>
            </button>
          </div>
        </section>

        {/* Quick Continue Reading / Recent Chapter card */}
        <section className="bg-gradient-to-r from-teal-50 to-sky-50 border border-teal-200/80 rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-teal-800">
              हाल ही में पढ़ा गया अध्याय
            </span>
            <span className="text-[11px] text-teal-600 font-semibold">
              अध्याय {recentChapter.chapterNumber}
            </span>
          </div>
          <h3 className="text-sm font-bold text-slate-900 font-devanagari mb-1">
            {recentChapter.title} ({recentChapter.englishTitle})
          </h3>
          <p className="text-xs text-slate-600 line-clamp-2 mb-3">
            {recentChapter.premiumNotes.summary}
          </p>
          <div className="flex items-center justify-between gap-2">
            <button
              onClick={() => onSelectChapter(recentChapter)}
              className="text-xs font-bold text-white bg-[#00838f] hover:bg-[#006064] px-4 py-2 rounded-xl transition-colors cursor-pointer active:scale-95 shadow-sm"
            >
              पढ़ना जारी रखें →
            </button>
            <span className="text-[11px] text-slate-500 font-medium">
              अनुमानित समय: {recentChapter.readTime}
            </span>
          </div>
        </section>
      </main>
    </div>
  );
};
