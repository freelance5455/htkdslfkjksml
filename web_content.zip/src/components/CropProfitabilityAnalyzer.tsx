import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  TrendingUp,
  DollarSign,
  Globe2,
  Calendar,
  Layers,
  Scale,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Sliders,
  Store,
  FileDown,
  Award,
  ChevronDown,
  ChevronUp,
  Info,
  Droplets,
  LandPlot,
  Check,
  Zap,
  Ship,
  Clock,
  CircleDollarSign,
  Activity,
  Lightbulb,
} from 'lucide-react';
import {
  Language,
  UserProfile,
  FarmPlotRecord,
  CropProfitabilityModel,
} from '../types';
import { CROP_PROFITABILITY_MODELS } from '../data/profitabilityData';
import { playKeyTap, playSuccessSound, playSuccessChime } from '../utils/audio';

interface CropProfitabilityAnalyzerProps {
  language: Language;
  user: UserProfile;
  plots: FarmPlotRecord[];
  onApplyCropToPlot?: (plotId: string, cropNameSw: string, cropNameEn: string) => void;
  onNavigateToSuppliers?: () => void;
  onNavigateToCreditDossier?: () => void;
}

type MarketScope = 'export' | 'domestic' | 'all';
type SeasonType = 'masika' | 'vuli' | 'irrigation';
type SortMetric = 'netProfit' | 'roi' | 'profitPerDay' | 'yield';

export default function CropProfitabilityAnalyzer({
  language,
  user,
  plots,
  onApplyCropToPlot,
  onNavigateToSuppliers,
  onNavigateToCreditDossier,
}: CropProfitabilityAnalyzerProps) {
  const isSw = language === 'sw';

  // Analysis Inputs
  const [selectedPlotId, setSelectedPlotId] = useState<string>(plots[0]?.id || 'custom');
  const [customAcres, setCustomAcres] = useState<number>(3.5);
  const [selectedSeason, setSelectedSeason] = useState<SeasonType>('masika');
  const [marketScope, setMarketScope] = useState<MarketScope>('export');
  const [sortMetric, setSortMetric] = useState<SortMetric>('netProfit');

  // Simulation Sensitivity Sliders
  const [priceFluctuationPercent, setPriceFluctuationPercent] = useState<number>(0); // -25% to +30%
  const [yieldScenarioMultiplier, setYieldScenarioMultiplier] = useState<number>(1.0); // 0.8 (conservative), 1.0 (baseline), 1.2 (optimal)

  // Expanded detailed card
  const [expandedCropId, setExpandedCropId] = useState<string | null>(CROP_PROFITABILITY_MODELS[0].id);

  // Success notifications
  const [appliedCropMessage, setAppliedCropMessage] = useState<string | null>(null);
  const [isExportReportCopied, setIsExportReportCopied] = useState<boolean>(false);

  // Selected plot object or custom
  const currentPlot = plots.find((p) => p.id === selectedPlotId);
  const activeAcres = currentPlot ? currentPlot.sizeAcres : customAcres;

  // Real-time calculations for each crop model
  const analyzedCrops = useMemo(() => {
    return CROP_PROFITABILITY_MODELS.map((crop) => {
      // Adjusted price per kg
      const basePrice =
        marketScope === 'export'
          ? crop.exportPriceTshKg
          : marketScope === 'domestic'
          ? crop.localMarketPriceTshKg
          : (crop.exportPriceTshKg * 0.7 + crop.localMarketPriceTshKg * 0.3); // blended

      const adjustedPriceKg = Math.round(basePrice * (1 + priceFluctuationPercent / 100));

      // Adjusted yield
      const adjustedYieldPerAcre = Math.round(crop.averageYieldKgPerAcre * yieldScenarioMultiplier);
      const totalYieldKg = adjustedYieldPerAcre * activeAcres;
      const totalYieldMt = Number((totalYieldKg / 1000).toFixed(2));

      // Production Costs
      const costs = crop.costBreakdownPerAcre;
      const totalCostPerAcre =
        costs.seedsTsh +
        costs.landPrepTsh +
        costs.fertilizerTsh +
        costs.cropProtectionTsh +
        costs.laborTsh +
        costs.transportPortTsh;

      const totalPlotProductionCost = totalCostPerAcre * activeAcres;

      // Revenue and Profit
      const grossRevenueTsh = Math.round(totalYieldKg * adjustedPriceKg);
      const netProfitTsh = grossRevenueTsh - totalPlotProductionCost;
      const netProfitPerAcreTsh = Math.round(netProfitTsh / activeAcres);
      const roiPercent = totalPlotProductionCost > 0
        ? Math.round((netProfitTsh / totalPlotProductionCost) * 100)
        : 0;
      const profitPerDayTsh = Math.round(netProfitTsh / crop.daysToHarvest);

      // Suitability match for selected season
      const isSeasonMatch = crop.bestSeasons.includes(selectedSeason);

      return {
        ...crop,
        adjustedPriceKg,
        adjustedYieldPerAcre,
        totalYieldKg,
        totalYieldMt,
        totalCostPerAcre,
        totalPlotProductionCost,
        grossRevenueTsh,
        netProfitTsh,
        netProfitPerAcreTsh,
        roiPercent,
        profitPerDayTsh,
        isSeasonMatch,
      };
    });
  }, [activeAcres, marketScope, priceFluctuationPercent, yieldScenarioMultiplier, selectedSeason]);

  // Sorted crops
  const sortedCrops = useMemo(() => {
    const list = [...analyzedCrops];
    return list.sort((a, b) => {
      if (sortMetric === 'netProfit') return b.netProfitTsh - a.netProfitTsh;
      if (sortMetric === 'roi') return b.roiPercent - a.roiPercent;
      if (sortMetric === 'profitPerDay') return b.profitPerDayTsh - a.profitPerDayTsh;
      if (sortMetric === 'yield') return b.totalYieldKg - a.totalYieldKg;
      return 0;
    });
  }, [analyzedCrops, sortMetric]);

  const topCrop = sortedCrops[0];

  // Handle applying crop to plot
  const handleApplyCrop = (crop: typeof sortedCrops[0]) => {
    playSuccessChime();
    if (onApplyCropToPlot && selectedPlotId !== 'custom') {
      onApplyCropToPlot(selectedPlotId, crop.nameSw, crop.nameEn);
    }
    const msg = isSw
      ? `Zao la ${crop.nameSw} limewekwa kwenye ${currentPlot?.name || 'shamba lako'}!`
      : `Applied ${crop.nameEn} to ${currentPlot?.name || 'your farm plot'}!`;
    setAppliedCropMessage(msg);
    setTimeout(() => setAppliedCropMessage(null), 4000);
  };

  // Export report summary
  const handleDownloadReport = () => {
    playSuccessSound();
    const summaryText = `ARDHI AI PROFITABILITY REPORT (UCHAMBUZI WA FAIDA YA MAZAO)
=====================================================
Mkulima: ${user.name} | Eneo: ${activeAcres} Hekari | Msimu: ${selectedSeason.toUpperCase()}
Chanzo cha Soko: ${marketScope.toUpperCase()}
Mabadiliko ya Bei: ${priceFluctuationPercent > 0 ? '+' : ''}${priceFluctuationPercent}%

ORODHA YA MAZAO YENYE FAIDA ZAIDI (AI RANKING):
-----------------------------------------------------
${sortedCrops
  .map(
    (c, idx) =>
      `#${idx + 1} ${c.nameSw} (${c.nameEn})
   Faida Halisi: Tsh ${(c.netProfitTsh / 1000000).toFixed(2)}M (ROI: +${c.roiPercent}%)
   Mavuno: ${c.totalYieldKg.toLocaleString()} kg | Faida/Siku: Tsh ${c.profitPerDayTsh.toLocaleString()}
   Soko Kuu: ${c.primaryExportMarket.flag} ${c.primaryExportMarket.country} ($${c.primaryExportMarket.fobUsdMt}/MT)
   Gharama za Uzalishaji: Tsh ${c.totalPlotProductionCost.toLocaleString()}
`
  )
  .join('\n')}
=====================================================
Imezalishwa na Mfumo wa Ardhi AI · ${new Date().toLocaleDateString()}`;

    try {
      navigator.clipboard.writeText(summaryText);
      setIsExportReportCopied(true);
      setTimeout(() => setIsExportReportCopied(false), 3000);
    } catch {
      // fallback
    }
  };

  return (
    <div className="space-y-4" id="crop-profitability-analyzer-container">
      {/* 1. Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-950 via-slate-900 to-teal-950 text-white p-5 border border-emerald-500/20 shadow-lg">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-60 h-60 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-[11px] font-bold">
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              <span>{isSw ? 'Uchambuzi wa Faida wa AI (Real-Time)' : 'AI Profitability Analyzer'}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <h2 className="text-xl sm:text-2xl font-display font-extrabold tracking-tight text-white">
              {isSw
                ? 'Mazao Yenye Faida Kubwa Zaidi Kupanda Sasa'
                : 'Most Profitable Crops to Plant Today'}
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              {isSw
                ? 'Mfumo unachambua mahitaji ya sasa ya masoko ya kimataifa (China, EU, Marekani, India) na gharama halisi za pembejeo za ndani nchini Tanzania ili kukupendekezea zao litakalokupa faida ya juu zaidi ya fedha.'
                : 'Cross-analyzes current global export demand corridors (China, EU, US, India) against local verified input production costs to pinpoint crops delivering the maximum net profit margin.'}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              id="btn-export-profitability-report"
              onClick={handleDownloadReport}
              className="py-2.5 px-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
            >
              {isExportReportCopied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-300">{isSw ? 'Ripoti Imenakiliwa!' : 'Report Copied!'}</span>
                </>
              ) : (
                <>
                  <FileDown className="w-4 h-4 text-slate-300" />
                  <span>{isSw ? 'Pakua Ripoti' : 'Export Report'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Highlight Stats of Top Crop */}
        {topCrop && (
          <div className="mt-4 pt-4 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 relative z-10">
            <div className="p-3 rounded-2xl bg-emerald-900/40 border border-emerald-500/30">
              <span className="text-[10px] text-emerald-300 uppercase tracking-wider font-bold block">
                {isSw ? '🏆 Zao Lililopendekezwa' : '🏆 Top AI Recommendation'}
              </span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xl">{topCrop.icon}</span>
                <span className="font-display font-extrabold text-white text-sm truncate">
                  {isSw ? topCrop.nameSw : topCrop.nameEn}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/60 border border-white/10">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium block">
                {isSw ? 'Faida Halisi Iliyokadiriwa' : 'Projected Net Profit'}
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="font-display font-extrabold text-emerald-400 text-lg">
                  Tsh {(topCrop.netProfitTsh / 1000000).toFixed(2)}M
                </span>
                <span className="text-[10px] text-emerald-300/80 font-bold">
                  (+{topCrop.roiPercent}% ROI)
                </span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/60 border border-white/10">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium block">
                {isSw ? 'Soko & Ushuru' : 'Destination Corridor'}
              </span>
              <div className="mt-1 flex items-center gap-1.5 text-xs text-white font-semibold truncate">
                <span>{topCrop.primaryExportMarket.flag}</span>
                <span className="truncate">{topCrop.primaryExportMarket.country}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
                  0% Duty
                </span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/60 border border-white/10">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium block">
                {isSw ? 'Faida kwa Siku' : 'Cashflow Velocity'}
              </span>
              <div className="mt-1 font-display font-extrabold text-amber-300 text-base">
                Tsh {topCrop.profitPerDayTsh.toLocaleString()}{' '}
                <span className="text-[10px] font-normal text-slate-300">/{isSw ? 'siku' : 'day'}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Applied Notification Banner */}
      <AnimatePresence>
        {appliedCropMessage && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold flex items-center justify-between gap-3 shadow-xs"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span>{appliedCropMessage}</span>
            </div>
            {onNavigateToSuppliers && (
              <button
                onClick={onNavigateToSuppliers}
                className="py-1 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer transition-colors"
              >
                {isSw ? 'Agiza Mbegu' : 'Order Seeds'}
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Interactive Analysis Parameters & Stress Test Controls */}
      <div className="p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-xs space-y-4">
        <div className="flex items-center justify-between gap-2 border-b border-[var(--line)] pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[var(--forest)]" />
            <h3 className="font-display font-bold text-sm text-[var(--ink)]">
              {isSw ? 'Vigezo vya Shamba & Jaribio la Bei (Scenarios)' : 'Farm Parameters & Market Simulation'}
            </h3>
          </div>
          <span className="text-[11px] text-[var(--ink-soft)]">
            {isSw ? 'Gusa kubadili vigezo' : 'Adjust scenario dynamically'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Plot Selector */}
          <div>
            <label className="block text-[11px] font-bold text-[var(--ink-soft)] mb-1.5">
              {isSw ? '1. Chagua Shamba Lako' : '1. Select Farm Plot'}
            </label>
            <select
              id="profitability-select-plot"
              value={selectedPlotId}
              onChange={(e) => {
                playKeyTap();
                setSelectedPlotId(e.target.value);
              }}
              className="w-full py-2 px-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)] focus:outline-none focus:ring-2 focus:ring-[var(--forest)] cursor-pointer"
            >
              {plots.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.sizeAcres} {isSw ? 'Hekari' : 'Acres'})
                </option>
              ))}
              <option value="custom">{isSw ? 'Eneo Maalum (Weka Hekari)' : 'Custom Acreage'}</option>
            </select>
          </div>

          {/* Custom Acres if selected */}
          {selectedPlotId === 'custom' ? (
            <div>
              <label className="block text-[11px] font-bold text-[var(--ink-soft)] mb-1.5">
                {isSw ? 'Ukubwa wa Shamba (Hekari)' : 'Plot Acreage (Acres)'}
              </label>
              <input
                type="number"
                min="0.5"
                max="500"
                step="0.5"
                value={customAcres}
                onChange={(e) => setCustomAcres(Math.max(0.5, parseFloat(e.target.value) || 1))}
                className="w-full py-2 px-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)] focus:outline-none focus:ring-2 focus:ring-[var(--forest)]"
              />
            </div>
          ) : (
            <div>
              <label className="block text-[11px] font-bold text-[var(--ink-soft)] mb-1.5">
                {isSw ? '2. Msimu Unaolengwa' : '2. Target Planting Season'}
              </label>
              <div className="flex rounded-2xl bg-[var(--bg)] p-1 border border-[var(--line)]">
                {[
                  { id: 'masika' as SeasonType, labelSw: 'Masika', labelEn: 'Main Rains' },
                  { id: 'vuli' as SeasonType, labelSw: 'Vuli', labelEn: 'Short Rains' },
                  { id: 'irrigation' as SeasonType, labelSw: 'Umwagiliaji', labelEn: 'Irrigation' },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      playKeyTap();
                      setSelectedSeason(s.id);
                    }}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                      selectedSeason === s.id
                        ? 'bg-[var(--forest)] text-white shadow-xs'
                        : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
                    }`}
                  >
                    {isSw ? s.labelSw : s.labelEn}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Market Preference */}
          <div>
            <label className="block text-[11px] font-bold text-[var(--ink-soft)] mb-1.5">
              {isSw ? '3. Soko Linalolengwa' : '3. Target Market Destination'}
            </label>
            <div className="flex rounded-2xl bg-[var(--bg)] p-1 border border-[var(--line)]">
              {[
                { id: 'export' as MarketScope, labelSw: 'Kimataifa (Export)', labelEn: 'Global Export' },
                { id: 'domestic' as MarketScope, labelSw: 'Soko la Ndani', labelEn: 'Domestic' },
                { id: 'all' as MarketScope, labelSw: 'Yote', labelEn: 'Blended' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    playKeyTap();
                    setMarketScope(m.id);
                  }}
                  className={`flex-1 py-1.5 px-1.5 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
                    marketScope === m.id
                      ? 'bg-[var(--forest)] text-white shadow-xs'
                      : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
                  }`}
                >
                  {isSw ? m.labelSw : m.labelEn}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Simulation Sliders (Stress-test price fluctuations) */}
        <div className="pt-3 border-t border-[var(--line)] grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <div className="flex items-center justify-between text-[11px] mb-1">
              <span className="font-bold text-[var(--ink)] flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-blue-500" />
                {isSw ? 'Jaribio la Mabadiliko ya Bei ya Soko' : 'Market Price Fluctuation Simulation'}
              </span>
              <span
                className={`font-mono font-bold text-xs ${
                  priceFluctuationPercent > 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : priceFluctuationPercent < 0
                    ? 'text-rose-600 dark:text-rose-400'
                    : 'text-[var(--ink-soft)]'
                }`}
              >
                {priceFluctuationPercent > 0 ? `+${priceFluctuationPercent}% (Kupanda)` : `${priceFluctuationPercent}%`}
              </span>
            </div>
            <input
              type="range"
              min="-25"
              max="30"
              step="5"
              value={priceFluctuationPercent}
              onChange={(e) => setPriceFluctuationPercent(parseInt(e.target.value, 10))}
              className="w-full accent-[var(--forest)] h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[var(--ink-soft)] mt-1">
              <span>-25% ({isSw ? 'Bei ikishuka' : 'Bearish Slump'})</span>
              <span>0% ({isSw ? 'Bei ya sasa' : 'Spot Current'})</span>
              <span>+30% ({isSw ? 'Msimu wa kilele' : 'Peak Export'})</span>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-[11px] mb-1">
              <span className="font-bold text-[var(--ink)] flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-teal-500" />
                {isSw ? 'Mazingira ya Mavuno (Yield Scenario)' : 'Yield Scenario Expectation'}
              </span>
              <span className="font-mono font-bold text-xs text-[var(--forest)]">
                {yieldScenarioMultiplier === 0.8
                  ? isSw ? 'Hali ya Chini (80%)' : 'Conservative (80%)'
                  : yieldScenarioMultiplier === 1.0
                  ? isSw ? 'Wastani (100%)' : 'Baseline (100%)'
                  : isSw ? 'Uzalishaji Bora (120%)' : 'High Input/Irrigated (120%)'}
              </span>
            </div>
            <div className="flex gap-2">
              {[
                { val: 0.8, labelSw: 'Ukame / Wastani wa Chini', labelEn: 'Low Rainfall' },
                { val: 1.0, labelSw: 'Kawaida (TARI Standard)', labelEn: 'Normal Rains' },
                { val: 1.2, labelSw: 'Pembejeo Kamili / Njia Bora', labelEn: 'Optimal Tech' },
              ].map((sc) => (
                <button
                  key={sc.val}
                  onClick={() => {
                    playKeyTap();
                    setYieldScenarioMultiplier(sc.val);
                  }}
                  className={`flex-1 py-1.5 px-2 rounded-xl text-[10px] font-semibold border transition-all cursor-pointer ${
                    yieldScenarioMultiplier === sc.val
                      ? 'border-[var(--forest)] bg-[var(--forest)]/10 text-[var(--forest)] font-bold'
                      : 'border-[var(--line)] bg-[var(--bg)] text-[var(--ink-soft)]'
                  }`}
                >
                  {isSw ? sc.labelSw : sc.labelEn}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 3. Sorting and Ranking Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        <div>
          <h3 className="font-display font-extrabold text-base text-[var(--ink)] flex items-center gap-2">
            <span>{isSw ? 'Matokeo ya Uchambuzi wa Mazao' : 'Ranked Crop Profitability Analysis'}</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[var(--forest)]/15 text-[var(--forest)] font-mono font-bold">
              {sortedCrops.length} {isSw ? 'Mazao' : 'Crops'}
            </span>
          </h3>
          <p className="text-[11px] text-[var(--ink-soft)] mt-0.5">
            {isSw
              ? `Hesabu zinatokana na hekari ${activeAcres} na bei halisi za leo bandarini na masoko ya ndani.`
              : `Calculated for ${activeAcres} acres using today's live port FOB and local market prices.`}
          </p>
        </div>

        {/* Metric Sorting Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-[11px] text-[var(--ink-soft)] font-medium mr-1 flex-shrink-0">
            {isSw ? 'Panga kwa:' : 'Sort by:'}
          </span>
          {[
            { id: 'netProfit' as SortMetric, labelSw: 'Faida Halisi (Tsh)', labelEn: 'Net Profit' },
            { id: 'roi' as SortMetric, labelSw: 'ROI %', labelEn: 'ROI %' },
            { id: 'profitPerDay' as SortMetric, labelSw: 'Faida/Siku', labelEn: 'Profit/Day' },
            { id: 'yield' as SortMetric, labelSw: 'Mavuno (kg)', labelEn: 'Volume' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                playKeyTap();
                setSortMetric(tab.id);
              }}
              className={`py-1.5 px-2.5 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer ${
                sortMetric === tab.id
                  ? 'bg-[var(--forest)] text-white shadow-xs'
                  : 'bg-[var(--paper)] text-[var(--ink-soft)] border border-[var(--line)] hover:text-[var(--ink)]'
              }`}
            >
              {isSw ? tab.labelSw : tab.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Crop Cards Grid */}
      <div className="space-y-3.5">
        {sortedCrops.map((crop, index) => {
          const isTopRanked = index === 0;
          const isExpanded = expandedCropId === crop.id;

          // Badges determination
          let badgeText = '';
          let badgeClass = '';
          if (isTopRanked) {
            badgeText = isSw ? '🥇 Zao Bora Zaidi' : '🥇 Top AI Pick';
            badgeClass = 'bg-amber-500 text-slate-950 font-extrabold';
          } else if (crop.roiPercent > 180) {
            badgeText = isSw ? '🚀 Faida Kubwa ya Mtaji' : '🚀 High ROI';
            badgeClass = 'bg-emerald-600 text-white font-bold';
          } else if (crop.climateRisk === 'low') {
            badgeText = isSw ? '🛡️ Hatari Ndogo ya Ukame' : '🛡️ Climate Resilient';
            badgeClass = 'bg-teal-600 text-white font-bold';
          } else if (crop.daysToHarvest <= 105) {
            badgeText = isSw ? '⚡ Mzunguko wa Haraka' : '⚡ Fast Cycle';
            badgeClass = 'bg-indigo-600 text-white font-bold';
          }

          return (
            <motion.div
              key={crop.id}
              layout
              className={`rounded-3xl border transition-all ${
                isTopRanked
                  ? 'bg-gradient-to-b from-[var(--paper)] to-emerald-500/5 border-emerald-500/40 shadow-md ring-1 ring-emerald-500/20'
                  : 'bg-[var(--paper)] border-[var(--line)] hover:border-slate-300 dark:hover:border-slate-700 shadow-xs'
              }`}
            >
              {/* Main Card Summary */}
              <div className="p-4 sm:p-5">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  {/* Left: Icon, Name, Category, Corridors */}
                  <div className="flex items-start gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-center text-2xl flex-shrink-0 shadow-xs">
                      {crop.icon}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-display font-extrabold text-base text-[var(--ink)]">
                          {isSw ? crop.nameSw : crop.nameEn}
                        </h4>
                        {badgeText && (
                          <span className={`px-2 py-0.5 rounded-full text-[10px] ${badgeClass}`}>
                            {badgeText}
                          </span>
                        )}
                        {crop.isSeasonMatch && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-500/20">
                            {isSw ? 'Msimu Unafaa' : 'Season Match'}
                          </span>
                        )}
                      </div>

                      {/* Corridor & Target Market Pill */}
                      <div className="flex items-center gap-2 text-xs text-[var(--ink-soft)] flex-wrap">
                        <span className="inline-flex items-center gap-1 font-semibold text-[var(--ink)]">
                          <span>{crop.primaryExportMarket.flag}</span>
                          <span>{crop.primaryExportMarket.country}</span>
                        </span>
                        <span>•</span>
                        <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                          {isSw ? crop.primaryExportMarket.tariffProtocolSw : crop.primaryExportMarket.tariffProtocolEn}
                        </span>
                        <span>•</span>
                        <span className="text-[11px]">
                          {crop.daysToHarvest} {isSw ? 'siku za kukomaa' : 'days cycle'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Net Profit, ROI, Action CTA */}
                  <div className="flex sm:flex-col items-end justify-between sm:justify-start gap-1 flex-shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-[var(--line)]">
                    <div className="text-left sm:text-right">
                      <span className="text-[10px] text-[var(--ink-soft)] uppercase font-semibold block">
                        {isSw ? `Faida Halisi (${activeAcres} Hekari)` : `Net Profit (${activeAcres} Ac)`}
                      </span>
                      <div className="font-display font-black text-lg sm:text-xl text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <span>Tsh {(crop.netProfitTsh / 1000000).toFixed(2)}M</span>
                        <span className="text-xs font-bold text-[var(--forest)]">
                          (+{crop.roiPercent}%)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      <button
                        onClick={() => handleApplyCrop(crop)}
                        className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-all active:scale-95 shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isSw ? 'Panda Hili' : 'Plant This'}</span>
                      </button>

                      <button
                        onClick={() => {
                          playKeyTap();
                          setExpandedCropId(isExpanded ? null : crop.id);
                        }}
                        className="p-1.5 rounded-xl bg-[var(--bg)] hover:bg-slate-200 dark:hover:bg-slate-800 text-[var(--ink-soft)] border border-[var(--line)] cursor-pointer transition-colors"
                        title={isExpanded ? 'Collapse' : 'Expand Details'}
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* 3 Metric Pills on Card */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3 pt-3 border-t border-[var(--line)] text-xs">
                  <div className="p-2 rounded-xl bg-[var(--bg)] border border-[var(--line)]">
                    <span className="text-[10px] text-[var(--ink-soft)] block">
                      {isSw ? 'Bei ya Kuuzia' : 'Selling Price'}
                    </span>
                    <span className="font-mono font-bold text-[var(--ink)]">
                      Tsh {crop.adjustedPriceKg.toLocaleString()} / kg
                    </span>
                    <span className="text-[9px] text-emerald-600 dark:text-emerald-400 block font-medium">
                      FOB ${crop.primaryExportMarket.fobUsdMt}/MT
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-[var(--bg)] border border-[var(--line)]">
                    <span className="text-[10px] text-[var(--ink-soft)] block">
                      {isSw ? 'Mavuno Yaliyotarajiwa' : 'Expected Harvest'}
                    </span>
                    <span className="font-mono font-bold text-[var(--ink)]">
                      {crop.totalYieldKg.toLocaleString()} kg ({crop.totalYieldMt} MT)
                    </span>
                    <span className="text-[9px] text-[var(--ink-soft)] block">
                      ~{crop.adjustedYieldPerAcre} kg / {isSw ? 'hekari' : 'acre'}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-[var(--bg)] border border-[var(--line)]">
                    <span className="text-[10px] text-[var(--ink-soft)] block">
                      {isSw ? 'Gharama za Uzalishaji' : 'Production Capital'}
                    </span>
                    <span className="font-mono font-bold text-amber-700 dark:text-amber-400">
                      Tsh {(crop.totalPlotProductionCost / 1000000).toFixed(2)}M
                    </span>
                    <span className="text-[9px] text-[var(--ink-soft)] block">
                      Tsh {(crop.totalCostPerAcre / 1000).toFixed(0)}k / {isSw ? 'hekari' : 'acre'}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-[var(--bg)] border border-[var(--line)]">
                    <span className="text-[10px] text-[var(--ink-soft)] block">
                      {isSw ? 'Kasi ya Pesa (Velocity)' : 'Profit Velocity'}
                    </span>
                    <span className="font-mono font-bold text-teal-700 dark:text-teal-400">
                      Tsh {crop.profitPerDayTsh.toLocaleString()}
                    </span>
                    <span className="text-[9px] text-[var(--ink-soft)] block">
                      {isSw ? 'kwa kila siku ya mzunguko' : 'per day of cycle'}
                    </span>
                  </div>
                </div>

                {/* AI Brief Verdict Strip */}
                <div className="mt-2.5 p-2.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-500/20 flex items-start gap-2 text-[11px] text-emerald-900 dark:text-emerald-200">
                  <Lightbulb className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="leading-snug">
                    <strong className="font-bold mr-1">
                      {isSw ? 'Ushauri wa AI:' : 'AI Strategic Insight:'}
                    </strong>
                    {isSw ? crop.aiVerdictSw : crop.aiVerdictEn}
                  </p>
                </div>
              </div>

              {/* Expanded In-Depth Breakdown Drawer */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-[var(--line)] bg-[var(--bg)]/50 p-4 sm:p-5 rounded-b-3xl space-y-4"
                  >
                    {/* Cost Itemization Breakdown Table */}
                    <div>
                      <h5 className="font-display font-bold text-xs text-[var(--ink)] flex items-center justify-between mb-2">
                        <span className="flex items-center gap-1.5">
                          <CircleDollarSign className="w-3.5 h-3.5 text-[var(--forest)]" />
                          {isSw ? 'Mchanganuo Kamili wa Gharama kwa Hekari (Local Production Costs)' : 'Itemized Production Cost Breakdown (Per Acre)'}
                        </span>
                        <span className="text-[11px] font-mono text-[var(--ink-soft)]">
                          Jumla: Tsh {crop.totalCostPerAcre.toLocaleString()} / hekari
                        </span>
                      </h5>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                        <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                          <span className="text-[10px] text-[var(--ink-soft)] block">{isSw ? 'Mbegu Zilizoidhinishwa (TOSCI)' : 'TOSCI Certified Seed'}</span>
                          <span className="font-mono font-bold text-[var(--ink)]">
                            Tsh {crop.costBreakdownPerAcre.seedsTsh.toLocaleString()}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                          <span className="text-[10px] text-[var(--ink-soft)] block">{isSw ? 'Kutayarisha Shamba (Tractor)' : 'Tillage & Land Prep'}</span>
                          <span className="font-mono font-bold text-[var(--ink)]">
                            Tsh {crop.costBreakdownPerAcre.landPrepTsh.toLocaleString()}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                          <span className="text-[10px] text-[var(--ink-soft)] block">{isSw ? 'Mbolea za TFRA (Basal/Top)' : 'TFRA Mineral/Organic'}</span>
                          <span className="font-mono font-bold text-[var(--ink)]">
                            Tsh {crop.costBreakdownPerAcre.fertilizerTsh.toLocaleString()}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                          <span className="text-[10px] text-[var(--ink-soft)] block">{isSw ? 'Kinga ya Mazao (TPRI Bio-IPM)' : 'Crop Protection (IPM)'}</span>
                          <span className="font-mono font-bold text-[var(--ink)]">
                            Tsh {crop.costBreakdownPerAcre.cropProtectionTsh.toLocaleString()}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                          <span className="text-[10px] text-[var(--ink-soft)] block">{isSw ? 'Vibarua (Palizi, Uvunaji)' : 'Labor & Harvesting'}</span>
                          <span className="font-mono font-bold text-[var(--ink)]">
                            Tsh {crop.costBreakdownPerAcre.laborTsh.toLocaleString()}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                          <span className="text-[10px] text-[var(--ink-soft)] block">{isSw ? 'Vifungashio & Usafiri Port' : 'Packaging & Port Freight'}</span>
                          <span className="font-mono font-bold text-[var(--ink)]">
                            Tsh {crop.costBreakdownPerAcre.transportPortTsh.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Market Comparison: Export Corridor vs Local Market Gap */}
                    <div className="p-3.5 rounded-2xl bg-[var(--paper)] border border-[var(--line)] space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[var(--ink)] flex items-center gap-1.5">
                          <Globe2 className="w-3.5 h-3.5 text-blue-500" />
                          {isSw ? 'Tofauti ya Bei: Soko la Kimataifa dhidi ya Soko la Ndani' : 'Price Premium: Global Export vs Local Market'}
                        </span>
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">
                          +{Math.round(((crop.exportPriceTshKg - crop.localMarketPriceTshKg) / crop.localMarketPriceTshKg) * 100)}% {isSw ? 'Faida ya Zaidi ya Kusafirisha Nje' : 'Export Premium'}
                        </span>
                      </div>

                      {/* Visual Comparison Bars */}
                      <div className="space-y-1.5 pt-1">
                        <div>
                          <div className="flex justify-between text-[10px] text-[var(--ink-soft)] mb-0.5">
                            <span>{crop.primaryExportMarket.flag} {crop.primaryExportMarket.country} ({isSw ? 'Mauzo ya Nje' : 'Export FOB'})</span>
                            <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">Tsh {crop.exportPriceTshKg.toLocaleString()} / kg</span>
                          </div>
                          <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                            <div className="h-full rounded-full bg-emerald-500" style={{ width: '100%' }} />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[10px] text-[var(--ink-soft)] mb-0.5">
                            <span>🇹🇿 {isSw ? 'Masoko ya Ndani (Kariakoo/Mtwara/Mbeya)' : 'Domestic Tanzania Local Markets'}</span>
                            <span className="font-mono font-bold text-slate-600 dark:text-slate-300">Tsh {crop.localMarketPriceTshKg.toLocaleString()} / kg</span>
                          </div>
                          <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-slate-400 dark:bg-slate-500"
                              style={{
                                width: `${Math.round((crop.localMarketPriceTshKg / crop.exportPriceTshKg) * 100)}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Agro-ecological & Variety details */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="p-3 rounded-2xl bg-[var(--paper)] border border-[var(--line)] space-y-1">
                        <span className="text-[10px] font-bold text-[var(--ink-soft)] block uppercase">
                          {isSw ? 'Mbegu Iliyopendekezwa & Wanunuzi' : 'Recommended Variety & Offtakers'}
                        </span>
                        <p className="text-xs text-[var(--ink)] font-semibold">
                          {isSw ? crop.recommendedVarietySw : crop.recommendedVarietyEn}
                        </p>
                        <p className="text-[11px] text-[var(--ink-soft)]">
                          <strong>{isSw ? 'Mshirika wa Soko:' : 'Buyer Partner:'}</strong>{' '}
                          {isSw ? crop.buyerNetworkPartnerSw : crop.buyerNetworkPartnerEn}
                        </p>
                      </div>

                      <div className="p-3 rounded-2xl bg-[var(--paper)] border border-[var(--line)] space-y-1">
                        <span className="text-[10px] font-bold text-[var(--ink-soft)] block uppercase">
                          {isSw ? 'Mahitaji ya Maji & Udongo' : 'Water & Soil Requirements'}
                        </span>
                        <p className="text-xs text-[var(--ink)] font-semibold">
                          {isSw ? crop.waterRequirementSw : crop.waterRequirementEn}
                        </p>
                        <p className="text-[11px] text-[var(--ink-soft)]">
                          <strong>{isSw ? 'Udongo Bora:' : 'Best Soils:'}</strong>{' '}
                          {crop.bestSoilTypes.join(', ')}
                        </p>
                      </div>
                    </div>

                    {/* Action Hub */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[var(--line)]">
                      <div className="flex items-center gap-2">
                        {onNavigateToSuppliers && (
                          <button
                            onClick={onNavigateToSuppliers}
                            className="py-2 px-3 rounded-xl bg-[var(--paper)] hover:bg-slate-100 dark:hover:bg-slate-800 text-[var(--forest)] border border-[var(--line)] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <Store className="w-3.5 h-3.5" />
                            <span>{isSw ? 'Agiza Mbegu za TOSCI' : 'Order Certified Seeds'}</span>
                          </button>
                        )}

                        {onNavigateToCreditDossier && (
                          <button
                            onClick={onNavigateToCreditDossier}
                            className="py-2 px-3 rounded-xl bg-[var(--paper)] hover:bg-slate-100 dark:hover:bg-slate-800 text-emerald-700 dark:text-emerald-400 border border-[var(--line)] font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <Award className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{isSw ? 'Jumuisha kwenye Dhamana' : 'Add to Credit Dossier'}</span>
                          </button>
                        )}
                      </div>

                      <button
                        onClick={() => handleApplyCrop(crop)}
                        className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-sm"
                      >
                        <Check className="w-4 h-4" />
                        <span>{isSw ? 'Tekeleza Zao Hili kwenye Shamba' : 'Apply Crop to This Plot'}</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
