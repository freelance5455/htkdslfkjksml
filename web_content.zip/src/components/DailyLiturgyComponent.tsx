import React, { useState, useEffect } from 'react';
import { BookOpen, Sparkles, CheckCircle, Flame, Calendar, ChevronRight } from 'lucide-react';

interface LiturgyDay {
  day: number;
  theme: string;
  scripture: string;
  highlight: string;
  prayer: string;
}

interface LiturgyPlan {
  planTitle: string;
  days: LiturgyDay[];
}

export const DailyLiturgyComponent: React.FC = () => {
  const [liturgy, setLiturgy] = useState<LiturgyPlan | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [completedDays, setCompletedDays] = useState<number[]>(() => {
    const saved = localStorage.getItem('juhnkrix_liturgy_completed');
    return saved ? JSON.parse(saved) : [1];
  });
  const [activeDayIndex, setActiveDayIndex] = useState<number>(0);

  useEffect(() => {
    const fetchLiturgy = async () => {
      try {
        const res = await fetch('/api/daily-liturgy', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        });
        if (!res.ok) throw new Error('Network response was not ok');
        const data = await res.json();
        setLiturgy(data);
      } catch (e) {
        console.warn('Using fallback 7-day liturgy plan for static deployment', e);
        setLiturgy({
          planTitle: "7-Day Prophetic Awakening & Soaking Liturgy",
          days: [
            {
              day: 1,
              theme: "Day 1: Encountering the 528Hz Glory Atmosphere",
              scripture: "Psalm 24:7 - 'Lift up your heads, you gates; be lifted up, you ancient doors, that the King of glory may come in.'",
              highlight: "Soak in stillness for 15 minutes listening to frequency pads. Allow the Holy Spirit to quiet every distraction.",
              prayer: "Lord, open the gates of my heart to receive Your fresh glory today."
            },
            {
              day: 2,
              theme: "Day 2: The Mantle of Divine Acceleration",
              scripture: "Amos 9:13 - 'The days are coming... when the reaper will be overtaken by the plowman.'",
              highlight: "Write down your delayed petitions and decree supernatural speed over your family and ministry.",
              prayer: "Father, release Your divine acceleration in every area of my life in Jesus' name."
            },
            {
              day: 3,
              theme: "Day 3: Healing Streams & Restoration",
              scripture: "Isaiah 53:5 - 'By His wounds we are healed.'",
              highlight: "Meditate on physical and emotional restoration. Release bitterness and receive complete wholeness.",
              prayer: "Jesus, let Your healing virtue flow through my spirit, soul, and body."
            },
            {
              day: 4,
              theme: "Day 4: Walking in Supernatural Favor",
              scripture: "Psalm 5:12 - 'Surely, Lord, you bless the righteous; you surround them with your favor as with a shield.'",
              highlight: "Visualize divine favor going ahead of you into every meeting, interview, and endeavor.",
              prayer: "Lord, surround me with Your impenetrable shield of favor."
            },
            {
              day: 5,
              theme: "Day 5: Unshakable Peace in the Storm",
              scripture: "John 14:27 - 'Peace I leave with you; my peace I give you.'",
              highlight: "Breathe in divine tranquility. Cast all anxiety onto the Lord's altar.",
              prayer: "Holy Spirit, let Your transcendent peace guard my mind today."
            },
            {
              day: 6,
              theme: "Day 6: The Anointing of Generational Wealth",
              scripture: "Deuteronomy 8:18 - 'Remember the Lord your God, for it is he who gives you the ability to produce wealth.'",
              highlight: "Pray for divine wisdom in stewardship and resource multiplication for Kingdom impact.",
              prayer: "Father, bless the work of my hands to fund Kingdom transformation."
            },
            {
              day: 7,
              theme: "Day 7: Fullness of Joy & Continuous Praise",
              scripture: "Psalm 16:11 - 'You make known to me the path of life; you will fill me with joy in your presence.'",
              highlight: "Spend an extended hour in worship, thanksgiving, and communion with God.",
              prayer: "Lord, fill my vessel to overflowing with Your uncontainable joy."
            }
          ]
        });
      } finally {
        setLoading(false);
      }
    };
    fetchLiturgy();
  }, []);

  const toggleDayComplete = (dayNum: number) => {
    setCompletedDays((prev) => {
      const updated = prev.includes(dayNum) ? prev.filter(d => d !== dayNum) : [...prev, dayNum];
      localStorage.setItem('juhnkrix_liturgy_completed', JSON.stringify(updated));
      return updated;
    });
  };

  if (loading) {
    return (
      <div className="bg-slate-900/80 p-8 rounded-3xl border border-amber-500/30 text-center space-y-3">
        <Sparkles className="w-8 h-8 text-amber-400 animate-spin mx-auto" />
        <p className="text-xs text-amber-200">Loading 7-Day Prophetic Liturgy & Scripture Plan...</p>
      </div>
    );
  }

  if (!liturgy) return null;

  const activeDay = liturgy.days[activeDayIndex] || liturgy.days[0];
  const isCompleted = completedDays.includes(activeDay.day);

  return (
    <div className="bg-gradient-to-br from-amber-950/70 via-slate-900 to-slate-950 p-6 sm:p-8 rounded-3xl border border-amber-500/40 shadow-2xl space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-amber-500/20">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-mono font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Gemini AI Prophetic Reading Plan</span>
          </div>
          <h3 className="text-xl font-bold font-serif text-amber-100">{liturgy.planTitle}</h3>
        </div>
        <span className="text-xs font-mono text-amber-300 bg-slate-950 px-3 py-1.5 rounded-xl border border-amber-500/30">
          Completed {completedDays.length} of {liturgy.days.length} Days
        </span>
      </div>

      {/* Visual Progress Bar */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-xs text-slate-300 font-mono">
          <span>7-Day Reading Plan Progress</span>
          <span className="text-amber-300 font-bold">
            {Math.round((completedDays.length / liturgy.days.length) * 100)}% Completed
          </span>
        </div>
        <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden p-0.5 border border-amber-500/30 shadow-inner">
          <div
            className="bg-gradient-to-r from-amber-500 to-yellow-300 h-full rounded-full transition-all duration-500 shadow-sm shadow-amber-500/50"
            style={{ width: `${(completedDays.length / liturgy.days.length) * 100}%` }}
          />
        </div>
      </div>

      {/* 7 Days Selector Bar */}
      <div className="grid grid-cols-7 gap-2">
        {liturgy.days.map((d, idx) => {
          const isSelected = activeDayIndex === idx;
          const done = completedDays.includes(d.day);
          return (
            <button
              key={d.day}
              onClick={() => setActiveDayIndex(idx)}
              className={`p-2.5 rounded-2xl border text-center transition-all flex flex-col items-center justify-center space-y-1 ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg font-bold'
                  : done
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/30 hover:bg-emerald-900/60'
                  : 'bg-slate-950/80 text-slate-300 border-amber-500/20 hover:border-amber-400'
              }`}
            >
              <span className="text-[10px] uppercase font-mono">Day {d.day}</span>
              <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs">
                {done ? '✓' : d.day}
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Day Detail Card */}
      <div className="bg-slate-950/90 p-6 rounded-2xl border border-amber-500/30 space-y-5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-amber-400 font-mono uppercase tracking-wider">
            Day {activeDay.day} • {activeDay.theme}
          </span>
          <button
            onClick={() => toggleDayComplete(activeDay.day)}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
              isCompleted
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md'
            }`}
          >
            <CheckCircle className="w-4 h-4" />
            <span>{isCompleted ? 'Day Completed ✓' : 'Mark Day Completed'}</span>
          </button>
        </div>

        <div className="bg-slate-900/80 p-5 rounded-xl border border-amber-500/20 space-y-2">
          <div className="flex items-center space-x-2 text-xs text-amber-300 font-bold">
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span>Scripture Highlight: {activeDay.scripture}</span>
          </div>
          <p className="text-amber-100 font-serif text-base italic leading-relaxed">
            &ldquo;{activeDay.highlight}&rdquo;
          </p>
        </div>

        <div className="space-y-2">
          <h5 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>Daily Prayer & Prophetic Decree</span>
          </h5>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans bg-amber-950/20 p-4 rounded-xl border border-amber-500/20">
            &ldquo;{activeDay.prayer}&rdquo;
          </p>
        </div>
      </div>
    </div>
  );
};
