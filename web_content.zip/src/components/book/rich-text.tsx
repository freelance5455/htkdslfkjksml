import type { Vocab } from "@/data/types";

type Segment =
  | { type: "text"; text: string }
  | { type: "word"; text: string; vocab: Vocab };

function overlaps(ranges: { i: number; j: number }[], i: number, j: number) {
  return ranges.some((r) => i < r.j && j > r.i);
}

function endBoundary(text: string, j: number) {
  return j >= text.length || !/[A-Za-z0-9]/.test(text[j] ?? "");
}

function startBoundary(text: string, i: number) {
  return i === 0 || !/[A-Za-z0-9]/.test(text[i - 1] ?? "");
}

const SUFFIXES = ["ing", "ies", "es", "ed", "s", "d"];

function matchEnd(text: string, lower: string, i: number, needle: string) {
  const base = i + needle.length;
  if (endBoundary(text, base)) return base;
  if (needle.length < 5 || needle.includes(" ")) return -1;
  const rest = lower.slice(base);
  for (const suffix of SUFFIXES) {
    if (!rest.startsWith(suffix)) continue;
    const j = base + suffix.length;
    if (endBoundary(text, j)) return j;
  }
  if (needle.endsWith("y")) {
    const stem = needle.slice(0, -1) + "ies";
    const j = i + stem.length;
    if (lower.startsWith(stem, i) && endBoundary(text, j)) return j;
  }
  return -1;
}

export function segmentText(text: string, vocab: Vocab[]): Segment[] {
  const ranges: { i: number; j: number; vocab: Vocab }[] = [];
  const lower = text.toLowerCase();
  const sorted = [...vocab].sort((a, b) => b.word.length - a.word.length);
  for (const entry of sorted) {
    const needle = entry.word.toLowerCase();
    if (needle.length < 2) continue;
    let from = 0;
    while (from < lower.length) {
      const i = lower.indexOf(needle, from);
      if (i < 0) break;
      const j = matchEnd(text, lower, i, needle);
      if (startBoundary(text, i) && j > i && !overlaps(ranges, i, j)) {
        ranges.push({ i, j, vocab: entry });
      }
      from = i + Math.max(1, needle.length);
    }
  }
  ranges.sort((a, b) => a.i - b.i);
  const out: Segment[] = [];
  let cursor = 0;
  for (const range of ranges) {
    if (range.i > cursor) out.push({ type: "text", text: text.slice(cursor, range.i) });
    out.push({ type: "word", text: text.slice(range.i, range.j), vocab: range.vocab });
    cursor = range.j;
  }
  if (cursor < text.length) out.push({ type: "text", text: text.slice(cursor) });
  return out;
}

function highlight(text: string, query: string) {
  const q = query.trim();
  if (q.length < 2) return text;
  const lower = text.toLowerCase();
  const needle = q.toLowerCase();
  const bits: { text: string; hit: boolean }[] = [];
  let from = 0;
  while (from < text.length) {
    const i = lower.indexOf(needle, from);
    if (i < 0) {
      bits.push({ text: text.slice(from), hit: false });
      break;
    }
    if (i > from) bits.push({ text: text.slice(from, i), hit: false });
    bits.push({ text: text.slice(i, i + needle.length), hit: true });
    from = i + needle.length;
  }
  return bits.map((bit, idx) =>
    bit.hit ? (
      <mark key={idx} className="bg-mark text-ink rounded-sm px-0.5">
        {bit.text}
      </mark>
    ) : (
      <span key={idx}>{bit.text}</span>
    ),
  );
}

export function RichText({
  text,
  vocab,
  query,
  onWord,
  className,
}: {
  text: string;
  vocab: Vocab[];
  query: string;
  onWord: (vocab: Vocab) => void;
  className?: string;
}) {
  const parts = segmentText(text, vocab);
  return (
    <span className={className}>
      {parts.map((part, i) =>
        part.type === "text" ? (
          <span key={i}>{highlight(part.text, query)}</span>
        ) : (
          <button
            key={i}
            type="button"
            className="text-banner underline decoration-banner/40 decoration-1 underline-offset-[3px] hover:decoration-banner focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-banner"
            onClick={() => onWord(part.vocab)}
            aria-haspopup="dialog"
          >
            {highlight(part.text, query)}
          </button>
        ),
      )}
    </span>
  );
}
