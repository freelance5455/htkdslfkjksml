import { useMemo, useState } from "react";
import type { Question } from "@/data/types";
import { Check, RotateCcw } from "lucide-react";

type Verdict = "ok" | "bad" | "idle";

function norm(value: string) {
  return value
    .toLowerCase()
    .replace(/[“”"‘’'.?,!;:]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function fillMatches(input: string, answers: string[]) {
  const n = norm(input);
  if (!n) return false;
  return answers.some((answer) => {
    const an = norm(answer);
    if (!an) return false;
    if (n === an) return true;
    if (an.length >= 4 && n.includes(an)) return true;
    if (n.length >= 8 && an.includes(n)) return true;
    return false;
  });
}

function shuffle<T>(items: T[], seed: string) {
  const copy = [...items];
  let h = 2166136261;
  for (const ch of seed) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  for (let i = copy.length - 1; i > 0; i--) {
    h = Math.imul(h ^ (h >>> 16), 2246822519);
    const j = Math.abs(h) % (i + 1);
    const tmp = copy[i];
    copy[i] = copy[j]!;
    copy[j] = tmp!;
  }
  return copy;
}

export function ExerciseBlock({
  title,
  instruction,
  items,
  seed,
}: {
  title: string;
  instruction?: string;
  items: Question[];
  seed: string;
}) {
  const [resetKey, setResetKey] = useState(0);
  return (
    <section className="mt-6 rounded-card border border-line bg-card px-4 py-4 sm:px-5">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <h4 className="font-ui text-sm font-bold tracking-wide text-maroon uppercase">
            {title}
          </h4>
          {instruction ? (
            <p className="font-body mt-1 text-[1.02rem] leading-relaxed text-ink">
              {instruction}
            </p>
          ) : null}
        </div>
        <button
          type="button"
          onClick={() => setResetKey((n) => n + 1)}
          className="font-ui inline-flex min-h-11 shrink-0 items-center gap-1 rounded-full px-3 text-sm text-muted hover:bg-chip"
        >
          <RotateCcw className="size-3.5" />
          Reset
        </button>
      </div>
      <ol className="flex flex-col gap-4" key={resetKey}>
        {items.map((item, index) => (
          <li key={index} className="border-t border-line pt-3 first:border-t-0 first:pt-0">
            <QuestionView item={item} index={index} seed={`${seed}-${index}`} />
          </li>
        ))}
      </ol>
    </section>
  );
}

function QuestionView({ item, index, seed }: { item: Question; index: number; seed: string }) {
  if (item.kind === "mcq") return <Mcq item={item} index={index} />;
  if (item.kind === "tf") return <Tf item={item} index={index} />;
  if (item.kind === "fill") return <Fill item={item} index={index} />;
  if (item.kind === "match") return <Match item={item} seed={seed} />;
  if (item.kind === "classify") return <Classify item={item} />;
  if (item.kind === "open") return <Open item={item} index={index} />;
  return null;
}

function Mcq({
  item,
  index,
}: {
  item: Extract<Question, { kind: "mcq" }>;
  index: number;
}) {
  const [picked, setPicked] = useState<number | null>(null);
  const letters = "abcdefghijklmnopqrstuvwxyz";
  return (
    <div>
      <p className="font-body text-[1.02rem] leading-relaxed">
        <span className="font-ui mr-2 text-sm font-semibold text-muted">{index + 1}.</span>
        {item.q}
      </p>
      <div className="mt-2 grid gap-2">
        {item.options.map((option, optionIndex) => {
          const chosen = picked === optionIndex;
          const show = picked !== null;
          const correct = optionIndex === item.answer;
          let tone = "border-line bg-paper text-ink hover:border-banner";
          if (show && correct) tone = "border-ok bg-ok-soft text-ok";
          else if (show && chosen && !correct) tone = "border-bad bg-bad-soft text-bad";
          return (
            <button
              key={option}
              type="button"
              disabled={picked !== null}
              onClick={() => setPicked(optionIndex)}
              className={`font-ui min-h-11 rounded-xl border px-3 py-2 text-left text-[0.98rem] ${tone}`}
            >
              <span className="mr-2 font-semibold">{letters[optionIndex] ?? optionIndex + 1}.</span>
              {option}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Tf({
  item,
  index,
}: {
  item: Extract<Question, { kind: "tf" }>;
  index: number;
}) {
  const [picked, setPicked] = useState<boolean | null>(null);
  return (
    <div>
      <p className="font-body text-[1.02rem] leading-relaxed">
        <span className="font-ui mr-2 text-sm font-semibold text-muted">{index + 1}.</span>
        {item.q}
      </p>
      <div className="mt-2 flex gap-2">
        {[true, false].map((value) => {
          const label = value ? "True" : "False";
          const chosen = picked === value;
          const show = picked !== null;
          const correct = value === item.answer;
          let tone = "border-line bg-paper text-ink hover:border-banner";
          if (show && correct) tone = "border-ok bg-ok-soft text-ok";
          else if (show && chosen && !correct) tone = "border-bad bg-bad-soft text-bad";
          return (
            <button
              key={label}
              type="button"
              disabled={picked !== null}
              onClick={() => setPicked(value)}
              className={`font-ui min-h-11 min-w-24 rounded-full border px-4 text-sm font-semibold ${tone}`}
            >
              {label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Fill({
  item,
  index,
}: {
  item: Extract<Question, { kind: "fill" }>;
  index: number;
}) {
  const [value, setValue] = useState("");
  const [verdict, setVerdict] = useState<Verdict>("idle");
  const good = verdict === "ok";
  const bad = verdict === "bad";
  return (
    <div>
      <label className="font-body block text-[1.02rem] leading-relaxed">
        <span className="font-ui mr-2 text-sm font-semibold text-muted">{index + 1}.</span>
        {item.q}
      </label>
      {item.hint ? <p className="font-ui mt-1 text-sm text-muted">Hint: {item.hint}</p> : null}
      <div className="mt-2 flex flex-col gap-2 sm:flex-row">
        <input
          value={value}
          onChange={(event) => {
            setValue(event.target.value);
            setVerdict("idle");
          }}
          className={
            "font-ui min-h-11 w-full rounded-xl border bg-paper px-3 text-ink outline-none " +
            (good ? "border-ok bg-ok-soft" : bad ? "border-bad bg-bad-soft" : "border-line")
          }
          placeholder="Type your answer"
        />
        <button
          type="button"
          onClick={() => setVerdict(fillMatches(value, item.answers) ? "ok" : "bad")}
          className="font-ui inline-flex min-h-11 items-center justify-center gap-1 rounded-full bg-banner px-4 text-sm font-semibold text-card"
        >
          <Check className="size-4" />
          Check
        </button>
      </div>
      {bad ? (
        <p className="font-ui mt-2 text-sm text-bad">
          Not quite. A correct answer: <span className="font-semibold">{item.answers[0]}</span>
        </p>
      ) : null}
      {good ? <p className="font-ui mt-2 text-sm font-semibold text-ok">Correct.</p> : null}
    </div>
  );
}

function Match({
  item,
  seed,
}: {
  item: Extract<Question, { kind: "match" }>;
  seed: string;
}) {
  const options = useMemo(
    () => shuffle(item.pairs.map((pair) => pair.right), seed),
    [item.pairs, seed],
  );
  const [picks, setPicks] = useState<Record<number, string>>({});
  const [checked, setChecked] = useState(false);
  return (
    <div>
      {item.q ? <p className="font-body mb-2 text-[1.02rem]">{item.q}</p> : null}
      <div className="flex flex-col gap-2">
        {item.pairs.map((pair, index) => {
          const pick = picks[index] ?? "";
          const show = checked && pick !== "";
          const correct = pick === pair.right;
          let border = "border-line";
          if (show && correct) border = "border-ok bg-ok-soft";
          else if (show && !correct) border = "border-bad bg-bad-soft";
          return (
            <label key={pair.left} className="grid gap-1 sm:grid-cols-[1fr_1.2fr] sm:items-center sm:gap-3">
              <span className="font-ui text-[0.98rem] font-semibold text-ink">{pair.left}</span>
              <select
                value={pick}
                onChange={(event) => {
                  setPicks((prev) => ({ ...prev, [index]: event.target.value }));
                  setChecked(false);
                }}
                className={`font-ui min-h-11 rounded-xl border bg-paper px-2 text-sm text-ink ${border}`}
              >
                <option value="">Choose a meaning</option>
                {options.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
          );
        })}
      </div>
      <button
        type="button"
        onClick={() => setChecked(true)}
        className="font-ui mt-3 inline-flex min-h-11 items-center gap-1 rounded-full bg-banner px-4 text-sm font-semibold text-card"
      >
        <Check className="size-4" />
        Check matches
      </button>
      {checked ? (
        <p className="font-ui mt-2 text-sm text-muted">
          {item.pairs.filter((pair, index) => picks[index] === pair.right).length} of {item.pairs.length} correct.
          Green is right, red is wrong.
        </p>
      ) : null}
    </div>
  );
}

function Classify({ item }: { item: Extract<Question, { kind: "classify" }> }) {
  const [picks, setPicks] = useState<Record<number, number | null>>({});
  const [checked, setChecked] = useState(false);
  return (
    <div>
      <p className="font-body text-[1.02rem] leading-relaxed">{item.q}</p>
      <div className="mt-3 flex flex-col gap-3">
        {item.cards.map((card, index) => {
          const pick = picks[index];
          const show = checked && pick !== undefined && pick !== null;
          return (
            <div key={card.text} className="rounded-xl border border-line bg-paper p-3">
              <p className="font-body text-[1.02rem]">{card.text}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {item.buckets.map((bucket, bucketIndex) => {
                  const chosen = pick === bucketIndex;
                  const correct = bucketIndex === card.bucket;
                  let tone = "border-line bg-card text-ink";
                  if (show && correct) tone = "border-ok bg-ok-soft text-ok";
                  else if (show && chosen && !correct) tone = "border-bad bg-bad-soft text-bad";
                  else if (chosen) tone = "border-banner bg-banner-soft text-banner";
                  return (
                    <button
                      key={bucket}
                      type="button"
                      onClick={() => {
                        setPicks((prev) => ({ ...prev, [index]: bucketIndex }));
                        setChecked(false);
                      }}
                      className={`font-ui min-h-11 rounded-full border px-3 text-sm font-semibold ${tone}`}
                    >
                      {bucket}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      <button
        type="button"
        onClick={() => setChecked(true)}
        className="font-ui mt-3 inline-flex min-h-11 items-center gap-1 rounded-full bg-banner px-4 text-sm font-semibold text-card"
      >
        <Check className="size-4" />
        Check
      </button>
    </div>
  );
}

function Open({
  item,
  index,
}: {
  item: Extract<Question, { kind: "open" }>;
  index: number;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <p className="font-body text-[1.02rem] leading-relaxed">
        <span className="font-ui mr-2 text-sm font-semibold text-muted">{index + 1}.</span>
        {item.q}
      </p>
      {item.model ? (
        <>
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            className="font-ui mt-2 inline-flex min-h-11 items-center rounded-full border border-line px-3 text-sm font-semibold text-banner"
          >
            {open ? "Hide model answer" : "Show model answer"}
          </button>
          {open ? (
            <p className="font-body mt-2 rounded-xl bg-banner-soft px-3 py-3 text-[1.02rem] leading-relaxed whitespace-pre-wrap text-ink">
              {item.model}
            </p>
          ) : null}
        </>
      ) : null}
    </div>
  );
}
