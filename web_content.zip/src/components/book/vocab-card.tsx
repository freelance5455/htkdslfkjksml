import type { Vocab } from "@/data/types";
import { X } from "lucide-react";

export function VocabBody({ vocab }: { vocab: Vocab }) {
  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="font-ui text-xs font-semibold uppercase tracking-[0.16em] text-maroon">
          {vocab.pos || "Word"}
        </p>
        <h3 className="font-display text-3xl leading-tight text-ink sm:text-4xl">
          {vocab.word}
        </h3>
      </div>
      <p className="font-ui text-base leading-relaxed text-ink">{vocab.meaning}</p>
      {vocab.urdu ? (
        <p
          className="font-urdu text-right text-2xl leading-[2.1] text-banner sm:text-3xl"
          dir="rtl"
          lang="ur"
        >
          {vocab.urdu}
        </p>
      ) : null}
      <div className="grid gap-3 sm:grid-cols-2">
        <ChipList label="Synonyms" items={vocab.synonyms} tone="banner" />
        <ChipList label="Antonyms" items={vocab.antonyms} tone="maroon" />
      </div>
      {vocab.sentences.length > 0 ? (
        <div className="rounded-card bg-example-soft px-4 py-3">
          <p className="font-ui mb-1 text-xs font-semibold uppercase tracking-[0.14em] text-example">
            In a sentence
          </p>
          {vocab.sentences.map((sentence) => (
            <p
              key={sentence}
              className="font-body text-[1.05rem] leading-relaxed font-medium text-example italic"
            >
              {sentence}
            </p>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function ChipList({
  label,
  items,
  tone,
}: {
  label: string;
  items: string[];
  tone: "banner" | "maroon";
}) {
  const clean = items.filter((item) => item && item !== "—" && item !== "-");
  return (
    <div>
      <p className="font-ui mb-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-muted">
        {label}
      </p>
      <div className="flex flex-wrap gap-1.5">
        {clean.length === 0 ? (
          <span className="font-ui text-sm text-muted">—</span>
        ) : (
          clean.map((item) => (
            <span
              key={item}
              className={
                "font-ui rounded-full px-2.5 py-1 text-sm " +
                (tone === "banner"
                  ? "bg-banner-soft text-banner"
                  : "bg-maroon-soft text-maroon")
              }
            >
              {item}
            </span>
          ))
        )}
      </div>
    </div>
  );
}

export function VocabDialog({
  vocab,
  onClose,
}: {
  vocab: Vocab | null;
  onClose: () => void;
}) {
  if (!vocab) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button
        type="button"
        aria-label="Close word card"
        className="absolute inset-0 bg-ink/40"
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="vocab-word"
        className="relative z-10 m-3 max-h-[86vh] w-full max-w-lg overflow-y-auto rounded-card border border-line bg-card p-5 shadow-[0_18px_50px_rgba(28,24,20,0.18)] sm:p-6"
      >
        <button
          type="button"
          onClick={onClose}
          className="font-ui absolute top-3 right-3 inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-chip"
          aria-label="Close"
        >
          <X className="size-5" />
        </button>
        <div id="vocab-word">
          <VocabBody vocab={vocab} />
        </div>
      </div>
    </div>
  );
}
