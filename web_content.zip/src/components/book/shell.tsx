import { useEffect, useMemo, useState } from "react";
import { BookOpen, Library, Menu, Search, X } from "lucide-react";
import { allVocab, units } from "@/data/book";
import type { Vocab } from "@/data/types";
import { UnitView } from "./lesson-view";
import { VocabBody, VocabDialog } from "./vocab-card";

type View = "contents" | "unit" | "glossary";

type Hit = {
  id: string;
  label: string;
  detail: string;
  unitId?: string;
  lessonId?: string;
  vocab?: Vocab;
};

export function BookShell() {
  const [view, setView] = useState<View>("contents");
  const [unitId, setUnitId] = useState(units[0]?.id ?? "");
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [vocab, setVocab] = useState<Vocab | null>(null);
  const [pending, setPending] = useState<string | null>(null);
  const [glossaryQuery, setGlossaryQuery] = useState("");

  const unit = units.find((item) => item.id === unitId) ?? units[0];

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setVocab(null);
        setSearchOpen(false);
        setNavOpen(false);
      }
      if (event.key === "/" && !(event.target instanceof HTMLInputElement)) {
        event.preventDefault();
        document.getElementById("book-search")?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!pending || view !== "unit") return;
    const node = document.getElementById(`lesson-${pending}`);
    if (!node) return;
    node.scrollIntoView({ behavior: "smooth", block: "start" });
    setPending(null);
  }, [pending, view, unitId]);

  const hits = useMemo(() => searchHits(query), [query]);

  function openLesson(nextUnit: string, lessonId: string) {
    setUnitId(nextUnit);
    setView("unit");
    setPending(lessonId);
    setNavOpen(false);
    setSearchOpen(false);
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-30 border-b border-line bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-2 px-3 py-2 sm:px-5">
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-full hover:bg-chip lg:hidden"
            onClick={() => setNavOpen(true)}
            aria-label="Open contents"
          >
            <Menu className="size-5" />
          </button>
          <button
            type="button"
            onClick={() => setView("contents")}
            className="font-display hidden text-left text-lg leading-none sm:block"
          >
            My English 8
          </button>
          <div className="relative min-w-0 flex-1">
            <label className="sr-only" htmlFor="book-search">
              Search units, lessons, and words
            </label>
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <input
              id="book-search"
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setSearchOpen(true);
              }}
              onFocus={() => setSearchOpen(true)}
              placeholder="Search a unit, lesson, or word"
              className="font-ui min-h-11 w-full rounded-full border border-line bg-card pr-3 pl-9 text-sm outline-none placeholder:text-muted focus:border-banner"
            />
            {searchOpen && query.trim().length >= 2 ? (
              <div className="absolute top-12 right-0 left-0 z-40 max-h-80 overflow-y-auto rounded-card border border-line bg-card shadow-[0_12px_30px_rgba(28,24,20,0.12)]">
                {hits.length === 0 ? (
                  <p className="font-ui px-3 py-3 text-sm text-muted">No matches in the book.</p>
                ) : (
                  hits.map((hit) => (
                    <button
                      key={hit.id}
                      type="button"
                      className="font-ui block w-full px-3 py-2.5 text-left hover:bg-banner-soft"
                      onClick={() => {
                        if (hit.vocab) {
                          setVocab(hit.vocab);
                          if (hit.unitId && hit.lessonId) openLesson(hit.unitId, hit.lessonId);
                          setSearchOpen(false);
                          return;
                        }
                        if (hit.unitId && hit.lessonId) openLesson(hit.unitId, hit.lessonId);
                        else if (hit.unitId) {
                          setUnitId(hit.unitId);
                          setView("unit");
                          setNavOpen(false);
                          setSearchOpen(false);
                        }
                      }}
                    >
                      <span className="block text-sm font-semibold text-ink">{hit.label}</span>
                      <span className="block text-xs text-muted">{hit.detail}</span>
                    </button>
                  ))
                )}
              </div>
            ) : null}
          </div>
          <button
            type="button"
            onClick={() => setView(view === "glossary" ? "contents" : "glossary")}
            className="font-ui inline-flex min-h-11 items-center gap-1 rounded-full px-3 text-sm font-semibold text-banner hover:bg-banner-soft"
          >
            <Library className="size-4" />
            <span className="hidden sm:inline">Glossary</span>
          </button>
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl lg:grid-cols-[17.5rem_1fr]">
        <aside className="hidden border-r border-line lg:block">
          <div className="sticky top-16 max-h-[calc(100vh-4rem)] overflow-y-auto px-4 py-5">
            <Contents
              activeUnit={unit?.id}
              activeView={view}
              onContents={() => setView("contents")}
              onLesson={openLesson}
              onGlossary={() => setView("glossary")}
            />
          </div>
        </aside>
        <main className="min-w-0 px-4 py-6 sm:px-8 sm:py-8">
          {view === "contents" ? (
            <ContentsPage onLesson={openLesson} onUnit={(id) => { setUnitId(id); setView("unit"); }} />
          ) : null}
          {view === "unit" && unit ? (
            <UnitView unit={unit} query={query} onWord={setVocab} />
          ) : null}
          {view === "glossary" ? (
            <Glossary
              query={glossaryQuery}
              onQuery={setGlossaryQuery}
              onOpen={(item) => setVocab(item)}
            />
          ) : null}
          <footer className="font-ui mt-12 border-t border-line pt-4 text-xs leading-relaxed text-muted">
            Study edition of My English Book 8, Sindh Textbook Board, Jamshoro, for Class VIII.
            Difficult words in the lessons are underlined. Click a word for its meaning in this
            lesson, the Urdu, synonyms, antonyms, and an example sentence.
          </footer>
        </main>
      </div>

      {navOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button
            type="button"
            aria-label="Close contents"
            className="absolute inset-0 bg-ink/40"
            onClick={() => setNavOpen(false)}
          />
          <div className="absolute top-0 bottom-0 left-0 w-[min(100%,20rem)] overflow-y-auto bg-paper px-4 py-4">
            <div className="mb-3 flex items-center justify-between">
              <p className="font-display text-xl">Contents</p>
              <button
                type="button"
                className="inline-flex size-11 items-center justify-center rounded-full hover:bg-chip"
                onClick={() => setNavOpen(false)}
                aria-label="Close"
              >
                <X className="size-5" />
              </button>
            </div>
            <Contents
              activeUnit={unit?.id}
              activeView={view}
              onContents={() => {
                setView("contents");
                setNavOpen(false);
              }}
              onLesson={openLesson}
              onGlossary={() => {
                setView("glossary");
                setNavOpen(false);
              }}
            />
          </div>
        </div>
      ) : null}

      <VocabDialog vocab={vocab} onClose={() => setVocab(null)} />
    </div>
  );
}

function Contents({
  activeUnit,
  activeView,
  onContents,
  onLesson,
  onGlossary,
}: {
  activeUnit?: string;
  activeView: View;
  onContents: () => void;
  onLesson: (unitId: string, lessonId: string) => void;
  onGlossary: () => void;
}) {
  return (
    <nav aria-label="Table of contents">
      <button
        type="button"
        onClick={onContents}
        className={
          "font-ui mb-2 flex min-h-11 w-full items-center gap-2 rounded-xl px-2 text-left text-sm font-semibold " +
          (activeView === "contents" ? "bg-banner text-card" : "hover:bg-chip")
        }
      >
        <BookOpen className="size-4" />
        Table of contents
      </button>
      <button
        type="button"
        onClick={onGlossary}
        className={
          "font-ui mb-4 flex min-h-11 w-full items-center gap-2 rounded-xl px-2 text-left text-sm font-semibold " +
          (activeView === "glossary" ? "bg-banner text-card" : "hover:bg-chip")
        }
      >
        <Library className="size-4" />
        Glossary
      </button>
      <ol className="flex flex-col gap-4">
        {units.map((unit) => (
          <li key={unit.id}>
            <p className={"font-ui text-xs font-bold tracking-[0.14em] uppercase " + (activeUnit === unit.id && activeView === "unit" ? "text-banner" : "text-maroon")}>
              Unit {unit.number}
            </p>
            <p className="font-display text-base leading-snug">{unit.title}</p>
            <ul className="mt-1">
              {unit.lessons.map((lesson) => (
                <li key={lesson.id}>
                  <button
                    type="button"
                    onClick={() => onLesson(unit.id, lesson.id)}
                    className="font-ui min-h-10 w-full rounded-lg px-2 py-1.5 text-left text-sm text-ink hover:bg-banner-soft"
                  >
                    <span className="text-muted">{lesson.code}</span> {lesson.subtitle || lesson.title}
                  </button>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ol>
    </nav>
  );
}

function ContentsPage({
  onLesson,
  onUnit,
}: {
  onLesson: (unitId: string, lessonId: string) => void;
  onUnit: (unitId: string) => void;
}) {
  return (
    <div>
      <section className="overflow-hidden rounded-card border border-line bg-card">
        <div className="bg-banner px-6 py-8 text-card sm:px-10 sm:py-12">
          <p className="font-ui text-xs font-semibold tracking-[0.2em] uppercase text-card/80">
            Sindh Textbook Board · Class VIII
          </p>
          <h1 className="font-display mt-2 text-5xl leading-none sm:text-7xl">
            My English
          </h1>
          <p className="font-display mt-2 text-3xl text-mark sm:text-4xl">Book 8</p>
          <p className="font-ui mt-4 max-w-xl text-base leading-relaxed text-card/90">
            A searchable study book. Jump to any unit or lesson, click a difficult word
            for its meaning and Urdu, and check exercises as you go.
          </p>
        </div>
        <div className="grid gap-px bg-line sm:grid-cols-3">
          {[
            ["Search", "Type a unit, a lesson, or a word."],
            ["Words", "Underlined words open a meaning card."],
            ["Exercises", "A right choice turns green. A wrong one turns red."],
          ].map(([title, copy]) => (
            <div key={title} className="bg-card px-5 py-4">
              <p className="font-ui text-sm font-bold text-banner">{title}</p>
              <p className="font-body mt-1 text-[1.02rem] leading-relaxed">{copy}</p>
            </div>
          ))}
        </div>
      </section>

      <h2 className="font-display mt-8 text-3xl">Contents</h2>
      <ol className="mt-4 flex flex-col gap-4">
        {units.map((unit) => (
          <li key={unit.id} className="rounded-card border border-line bg-card px-4 py-4 sm:px-5">
            <button type="button" onClick={() => onUnit(unit.id)} className="text-left">
              <p className="font-ui text-xs font-bold tracking-[0.16em] text-banner uppercase">
                Unit {unit.number}
              </p>
              <h3 className="font-display text-2xl leading-tight">{unit.title}</h3>
            </button>
            <ul className="mt-2 grid gap-1 sm:grid-cols-2">
              {unit.lessons.map((lesson) => (
                <li key={lesson.id}>
                  <button
                    type="button"
                    onClick={() => onLesson(unit.id, lesson.id)}
                    className="font-ui min-h-11 w-full rounded-lg px-2 text-left text-sm hover:bg-banner-soft"
                  >
                    <span className="font-semibold text-maroon">{lesson.code}</span>{" "}
                    {lesson.subtitle || lesson.title}
                  </button>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ol>
    </div>
  );
}

function Glossary({
  query,
  onQuery,
  onOpen,
}: {
  query: string;
  onQuery: (value: string) => void;
  onOpen: (vocab: Vocab) => void;
}) {
  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return allVocab()
      .filter(({ vocab, unit }) => {
        if (!q) return true;
        return (
          vocab.word.toLowerCase().includes(q) ||
          vocab.meaning.toLowerCase().includes(q) ||
          vocab.urdu.includes(query.trim()) ||
          unit.title.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => a.vocab.word.localeCompare(b.vocab.word));
  }, [query]);

  return (
    <div>
      <h2 className="font-display text-4xl">Glossary</h2>
      <p className="font-body mt-2 max-w-2xl text-[1.05rem] leading-relaxed text-muted">
        Every difficult word from the lessons. The headword and the definition use different
        type. Example sentences are in italics and light blue. Urdu is set in Nastaliq.
      </p>
      <input
        value={query}
        onChange={(event) => onQuery(event.target.value)}
        placeholder="Filter words"
        className="font-ui mt-4 min-h-11 w-full max-w-md rounded-full border border-line bg-card px-4 text-sm outline-none focus:border-banner"
      />
      <p className="font-ui mt-3 text-sm text-muted">{rows.length} words</p>
      <div className="mt-4 grid gap-4">
        {rows.map(({ unit, vocab }) => (
          <article
            key={`${unit.id}-${vocab.word}`}
            className="rounded-card border border-line bg-card px-4 py-4 sm:px-5"
          >
            <p className="font-ui mb-2 text-xs font-semibold tracking-wide text-muted uppercase">
              Unit {unit.number} · {unit.title}
            </p>
            <VocabBody vocab={vocab} />
            <button
              type="button"
              onClick={() => onOpen(vocab)}
              className="font-ui mt-3 min-h-11 text-sm font-semibold text-banner"
            >
              Open as pop-up
            </button>
          </article>
        ))}
      </div>
    </div>
  );
}

function blockText(block: import("@/data/types").Block): string {
  if (block.type === "p" || block.type === "h" || block.type === "note") return block.text;
  if (block.type === "callout") return `${block.title ?? ""} ${block.text}`;
  if (block.type === "poem") return block.lines.join(" ");
  if (block.type === "list") return block.items.join(" ");
  if (block.type === "dialogue") return block.lines.map((line) => `${line.who} ${line.text}`).join(" ");
  if (block.type === "exercise") return `${block.title} ${block.instruction ?? ""}`;
  return "";
}

function searchHits(query: string): Hit[] {
  const q = query.trim().toLowerCase();
  if (q.length < 2) return [];
  const hits: Hit[] = [];
  const seen = new Set<string>();
  const push = (hit: Hit) => {
    if (seen.has(hit.id) || hits.length >= 18) return;
    seen.add(hit.id);
    hits.push(hit);
  };
  for (const unit of units) {
    if (unit.title.toLowerCase().includes(q) || `unit ${unit.number}`.includes(q)) {
      push({
        id: `u-${unit.id}`,
        label: `Unit ${unit.number}: ${unit.title}`,
        detail: "Unit",
        unitId: unit.id,
        lessonId: unit.lessons[0]?.id,
      });
    }
    for (const lesson of unit.lessons) {
      const titleBlob = `${lesson.code} ${lesson.title} ${lesson.subtitle ?? ""}`.toLowerCase();
      if (titleBlob.includes(q)) {
        push({
          id: `l-${lesson.id}`,
          label: `${lesson.code} ${lesson.subtitle || lesson.title}`,
          detail: `Unit ${unit.number} · ${unit.title}`,
          unitId: unit.id,
          lessonId: lesson.id,
        });
      }
      const body = lesson.blocks.map(blockText).join(" ").toLowerCase();
      if (body.includes(q)) {
        const idx = body.indexOf(q);
        const snippet = body.slice(Math.max(0, idx - 40), idx + q.length + 50).trim();
        push({
          id: `t-${lesson.id}`,
          label: `${lesson.code} ${lesson.subtitle || lesson.title}`,
          detail: snippet,
          unitId: unit.id,
          lessonId: lesson.id,
        });
      }
    }
    for (const word of unit.vocab) {
      if (
        word.word.toLowerCase().includes(q) ||
        word.meaning.toLowerCase().includes(q) ||
        word.urdu.includes(query.trim())
      ) {
        push({
          id: `v-${unit.id}-${word.word}`,
          label: word.word,
          detail: `Word · Unit ${unit.number} · ${word.urdu}`,
          unitId: unit.id,
          lessonId: unit.lessons[0]?.id,
          vocab: word,
        });
      }
    }
  }
  return hits;
}

export function bookReady() {
  return units.length > 0;
}
