import type { Block, Lesson, Unit, Vocab } from "@/data/types";
import { RichText } from "./rich-text";
import { ExerciseBlock } from "./exercises";

const kindLabel: Record<Lesson["kind"], string> = {
  reading: "Reading",
  speaking: "Speaking",
  language: "Language",
  writing: "Writing",
  study: "Study skills",
  fun: "Fun",
};

export function UnitView({
  unit,
  query,
  onWord,
}: {
  unit: Unit;
  query: string;
  onWord: (vocab: Vocab) => void;
}) {
  return (
    <article>
      <header className="overflow-hidden rounded-card bg-banner text-card">
        <div className="px-5 py-6 sm:px-8 sm:py-8">
          <p className="font-ui text-xs font-semibold tracking-[0.18em] uppercase text-card/80">
            Unit {unit.number}
          </p>
          <h2 className="font-display mt-1 text-3xl leading-tight sm:text-5xl">{unit.title}</h2>
        </div>
      </header>

      <section className="mt-5 rounded-card border border-line bg-card px-5 py-5 sm:px-6">
        <h3 className="font-display text-2xl text-maroon">What will I learn?</h3>
        <div className="mt-3 grid gap-4">
          {unit.learn.map((group) => (
            <div key={group.skill}>
              <p className="font-ui text-xs font-bold tracking-[0.16em] text-banner uppercase">
                {group.skill}
              </p>
              <ul className="mt-1 list-disc pl-5">
                {group.points.map((point) => (
                  <li key={point} className="font-body text-[1.02rem] leading-relaxed">
                    {point}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <div className="mt-8 flex flex-col gap-10">
        {unit.lessons.map((lesson) => (
          <LessonView
            key={lesson.id}
            lesson={lesson}
            vocab={unit.vocab}
            query={query}
            onWord={onWord}
          />
        ))}
      </div>
    </article>
  );
}

function LessonView({
  lesson,
  vocab,
  query,
  onWord,
}: {
  lesson: Lesson;
  vocab: Vocab[];
  query: string;
  onWord: (vocab: Vocab) => void;
}) {
  return (
    <section id={`lesson-${lesson.id}`} className="scroll-mt-24">
      <div className="border-b border-line pb-2">
        <p className="font-ui text-xs font-bold tracking-[0.16em] text-banner uppercase">
          {lesson.code} · {kindLabel[lesson.kind] ?? lesson.kind}
        </p>
        <h3 className="font-display text-2xl text-ink sm:text-3xl">{lesson.title}</h3>
        {lesson.subtitle ? (
          <p className="font-display text-lg text-maroon italic">{lesson.subtitle}</p>
        ) : null}
      </div>
      <div className="mt-4">
        {lesson.blocks.map((block, index) => (
          <BlockView
            key={index}
            block={block}
            vocab={vocab}
            query={query}
            onWord={onWord}
            seed={`${lesson.id}-${index}`}
          />
        ))}
      </div>
    </section>
  );
}

function BlockView({
  block,
  vocab,
  query,
  onWord,
  seed,
}: {
  block: Block;
  vocab: Vocab[];
  query: string;
  onWord: (vocab: Vocab) => void;
  seed: string;
}) {
  if (block.type === "h") {
    return (
      <h4 className="font-display mt-6 text-xl text-banner first:mt-0">{block.text}</h4>
    );
  }
  if (block.type === "p") {
    return (
      <p className="font-body mt-3 text-[1.08rem] leading-[1.7] text-ink">
        <RichText text={block.text} vocab={vocab} query={query} onWord={onWord} />
      </p>
    );
  }
  if (block.type === "poem") {
    return (
      <div className="mt-4 rounded-card border border-line bg-card px-5 py-4">
        {block.lines.map((line, index) =>
          line.trim() === "" ? (
            <div key={index} className="h-4" />
          ) : (
            <p key={index} className="font-body text-[1.06rem] leading-relaxed italic">
              <RichText text={line} vocab={vocab} query={query} onWord={onWord} />
            </p>
          ),
        )}
      </div>
    );
  }
  if (block.type === "list") {
    const ListTag = block.ordered ? "ol" : "ul";
    return (
      <ListTag
        className={
          "mt-3 space-y-1 pl-6 " + (block.ordered ? "list-decimal" : "list-disc")
        }
      >
        {block.items.map((item) => (
          <li key={item} className="font-body text-[1.05rem] leading-relaxed">
            <RichText text={item} vocab={vocab} query={query} onWord={onWord} />
          </li>
        ))}
      </ListTag>
    );
  }
  if (block.type === "note") {
    return (
      <p className="font-ui mt-3 rounded-xl bg-banner-soft px-3 py-2 text-sm leading-relaxed text-banner">
        {block.text}
      </p>
    );
  }
  if (block.type === "dialogue") {
    return (
      <div className="mt-4 flex flex-col gap-2">
        {block.lines.map((line, index) => (
          <p key={index} className="grid grid-cols-[6.5rem_1fr] gap-2 sm:grid-cols-[8rem_1fr]">
            <span className="font-ui text-sm font-bold text-maroon">{line.who}</span>
            <span className="font-body text-[1.05rem] leading-relaxed">
              <RichText text={line.text} vocab={vocab} query={query} onWord={onWord} />
            </span>
          </p>
        ))}
      </div>
    );
  }
  if (block.type === "callout") {
    return (
      <aside className="mt-4 rounded-card border border-maroon/20 bg-maroon-soft px-4 py-3">
        {block.title ? (
          <p className="font-ui text-xs font-bold tracking-[0.14em] text-maroon uppercase">
            {block.title}
          </p>
        ) : null}
        <p className="font-body mt-1 text-[1.05rem] leading-relaxed whitespace-pre-wrap">
          <RichText text={block.text} vocab={vocab} query={query} onWord={onWord} />
        </p>
      </aside>
    );
  }
  if (block.type === "table") {
    return (
      <div className="mt-4 overflow-x-auto rounded-card border border-line">
        {block.caption ? (
          <p className="font-ui bg-chip px-3 py-2 text-sm font-semibold text-ink">
            {block.caption}
          </p>
        ) : null}
        <table className="w-full min-w-[28rem] border-collapse text-left">
          {block.headers?.length ? (
            <thead className="bg-banner text-card">
              <tr>
                {block.headers.map((header) => (
                  <th key={header} className="font-ui px-3 py-2 text-sm font-semibold">
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
          ) : null}
          <tbody>
            {(block.rows ?? []).map((row, rowIndex) => (
              <tr key={rowIndex} className={rowIndex % 2 ? "bg-paper" : "bg-card"}>
                {row.map((cell, cellIndex) => (
                  <td key={cellIndex} className="font-body border-t border-line px-3 py-2 text-[0.98rem] leading-relaxed">
                    <RichText text={String(cell ?? "")} vocab={vocab} query={query} onWord={onWord} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
  if (block.type === "exercise") {
    return (
      <ExerciseBlock
        title={block.title}
        instruction={block.instruction}
        items={block.items ?? []}
        seed={seed}
      />
    );
  }
  if (block.type === "words") {
    return (
      <div className="mt-4 rounded-card border border-line bg-card px-4 py-4">
        {block.intro ? <p className="font-body text-[1.05rem]">{block.intro}</p> : null}
        <div className="mt-3 flex flex-wrap gap-2">
          {block.words.map((word) => (
            <span
              key={word}
              className="font-ui rounded-full bg-banner-soft px-3 py-1.5 text-sm font-semibold text-banner"
            >
              {word}
            </span>
          ))}
        </div>
      </div>
    );
  }
  return null;
}
