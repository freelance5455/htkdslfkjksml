import React,{useState} from "react";
import {Mic,MicOff,Radio} from "lucide-react";
export default function RKCommander({onCommand}){
 const [listening,setListening]=useState(false); const [msg,setMsg]=useState("RK ready");
 function speak(text){setMsg(text); try{speechSynthesis?.speak(new SpeechSynthesisUtterance(text))}catch{}}
 function toggle(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){speak("Speech recognition is not available in this browser.");return}
  const r=new SR(); r.lang="en-IN"; r.interimResults=false;
  r.onstart=()=>{setListening(true);setMsg("Listening...")}; r.onend=()=>setListening(false);
  r.onresult=e=>{const t=e.results[0][0].transcript.toLowerCase(); if(t.includes("auto-pilot")){onCommand("autopilot");speak("Yes sir, internal auto-pilot initialized.")} else if(t.includes("output")){onCommand("outputs");speak("Opening live outputs.")} else speak("Command received. Internal intent parser found no matching action.")};
  r.start();
 }
 return <div className="fixed bottom-6 right-6 z-40 flex items-end gap-3"><div className="glass rounded-2xl px-4 py-2 text-xs max-w-48">{msg}</div><button onClick={toggle} className={`rk-orb h-16 w-16 rounded-full grid place-items-center bg-cyan-400 text-slate-950 ${listening?"ring-4 ring-cyan-300/30":""}`}>{listening?<MicOff/>:<Mic/>}</button></div>
}