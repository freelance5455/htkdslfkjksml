import { useMemo } from "react";
import { formulasByClassSubject, getFormulasForSyllabusChapter } from "../data";
import type { ClassLevel, Subject } from "../data/types";
import { getBoardChapters, getChapterEntry, STATUS_COLOR, STATUS_LABEL } from "../data/syllabus";
import { useAppState } from "../state/AppState";
import FormulaCard from "./FormulaCard";

const subjects: Subject[] = ["Mathematics", "Physics", "Chemistry"];
const subjectIcon: Record<Subject, string> = { Mathematics: "📐", Physics: "⚡", Chemistry: "🧪" };

export default function ClassExplorer({ classLevel, subject, chapter }: { classLevel: ClassLevel; subject?: Subject; chapter?: string }) {
  const { navigate, board } = useAppState();

  const chapterEntries = useMemo(() => (subject ? getBoardChapters(board, classLevel, subject) : []), [board, classLevel, subject]);

  const activeChapter = useMemo(() => (subject && chapter ? getChapterEntry(board, classLevel, subject, chapter) : undefined), [board, classLevel, subject, chapter]);

  const matchedFormulas = useMemo(() => {
    if (!subject || !chapter) return [];
    return getFormulasForSyllabusChapter(classLevel, subject, chapter);
  }, [classLevel, subject, chapter]);

  const topicsGrouped = useMemo(() => {
    const map: Record<string, typeof matchedFormulas> = {};
    matchedFormulas.forEach((f) => {
      if (!map[f.topic]) map[f.topic] = [];
      map[f.topic].push(f);
    });
    return map;
  }, [matchedFormulas]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Breadcrumb classLevel={classLevel} subject={subject} chapter={chapter} />

      {!subject && (
        <>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">
            {board} · Class {classLevel}
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Choose a subject to explore its chapters.</p>
          <div className="mt-6 grid gap-5 sm:grid-cols-3">
            {subjects.map((s) => (
              <button
                key={s}
                onClick={() => navigate({ name: "class", classLevel, subject: s })}
                className="rounded-2xl border border-slate-200 bg-white p-6 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="text-3xl">{subjectIcon[s]}</div>
                <h2 className="mt-3 text-lg font-bold text-slate-800 dark:text-slate-100">{s}</h2>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  {getBoardChapters(board, classLevel, s).length} chapters · {formulasByClassSubject[classLevel][s].length} interactive formulas
                </p>
              </button>
            ))}
          </div>
        </>
      )}

      {subject && !chapter && (
        <>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">
            {board} · Class {classLevel} · {subject}
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Pick a chapter to view its topics and formulas.</p>
          {chapterEntries.length === 0 ? (
            <div className="mt-8 rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
              The chapter library for this selection hasn't been added yet. Try the Search or AI Tutor instead.
            </div>
          ) : (
            <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {chapterEntries.map((c) => {
                const count = getFormulasForSyllabusChapter(classLevel, subject, c.chapter).length;
                return (
                  <button
                    key={c.chapter}
                    onClick={() => navigate({ name: "class", classLevel, subject, chapter: c.chapter })}
                    className="flex flex-col gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium text-slate-700 dark:text-slate-200">{c.chapter}</span>
                      {count > 0 && <span className="shrink-0 rounded-full bg-indigo-50 px-2 py-0.5 text-xs text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">{count}</span>}
                    </div>
                    <span className={`inline-block w-fit rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${STATUS_COLOR[c.status]}`}>{STATUS_LABEL[c.status]}</span>
                  </button>
                );
              })}
            </div>
          )}
        </>
      )}

      {subject && chapter && (
        <>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">{chapter}</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {board} · Class {classLevel} · {subject}
          </p>

          {activeChapter && (
            <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`rounded-md px-2 py-0.5 text-xs font-semibold ${STATUS_COLOR[activeChapter.status]}`}>{STATUS_LABEL[activeChapter.status]}</span>
              </div>
              <h3 className="mt-3 text-xs font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">Topics in this chapter</h3>
              <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-slate-600 dark:text-slate-300">
                {activeChapter.topics.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
              {activeChapter.note && <p className="mt-3 text-xs text-slate-400 dark:text-slate-500">ℹ {activeChapter.note}</p>}
              {activeChapter.source && (
                <a href={activeChapter.source.url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-xs font-medium text-indigo-600 underline dark:text-indigo-400">
                  Source: {activeChapter.source.name} ↗
                </a>
              )}
            </div>
          )}

          <div className="mt-6 space-y-8">
            {Object.entries(topicsGrouped).map(([topic, list]) => (
              <div key={topic}>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400 dark:text-slate-500">{topic}</h3>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {list.map((f) => (
                    <FormulaCard key={f.id} formula={f} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          {matchedFormulas.length === 0 && (
            <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-6 text-center dark:border-slate-800 dark:bg-slate-900/60">
              <p className="text-sm text-slate-500 dark:text-slate-400">
                FormulaVerse doesn't have an interactive formula page for this chapter yet — but you don't have to leave empty-handed.
              </p>
              <div className="mt-4 flex flex-wrap justify-center gap-3">
                <button
                  onClick={() => navigate({ name: "ai" })}
                  className="rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-2 text-sm font-semibold text-white shadow-md transition hover:opacity-90"
                >
                  Ask the AI Tutor about {chapter} →
                </button>
                <button
                  onClick={() => navigate({ name: "quiz" })}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  Practice with a Quiz →
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Breadcrumb({ classLevel, subject, chapter }: { classLevel: ClassLevel; subject?: Subject; chapter?: string }) {
  const { navigate, board } = useAppState();
  return (
    <div className="mb-5 flex flex-wrap items-center gap-1 text-sm text-slate-400 dark:text-slate-500">
      <button onClick={() => navigate({ name: "home" })} className="hover:text-indigo-500">
        Home
      </button>
      <span>/</span>
      <span className="text-slate-500 dark:text-slate-400">{board}</span>
      <span>/</span>
      <button onClick={() => navigate({ name: "class", classLevel })} className="hover:text-indigo-500">
        Class {classLevel}
      </button>
      {subject && (
        <>
          <span>/</span>
          <button onClick={() => navigate({ name: "class", classLevel, subject })} className="hover:text-indigo-500">
            {subject}
          </button>
        </>
      )}
      {chapter && (
        <>
          <span>/</span>
          <span className="text-slate-600 dark:text-slate-300">{chapter}</span>
        </>
      )}
    </div>
  );
}
