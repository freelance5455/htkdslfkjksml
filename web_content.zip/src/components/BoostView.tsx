import React from 'react';
import { Zap, BatteryCharging, Activity, Cpu, Server, Coins, Sparkles, ArrowUpCircle } from 'lucide-react';
import { UpgradeItem } from '../types';
import { soundEngine, triggerHaptic } from '../utils/audio';

interface BoostViewProps {
  coins: number;
  upgrades: UpgradeItem[];
  onUpgrade: (upgradeId: string) => void;
  tapPower: number;
  maxEnergy: number;
  passiveRate: number;
  critChance: number;
}

export const BoostView: React.FC<BoostViewProps> = ({
  coins,
  upgrades,
  onUpgrade,
  tapPower,
  maxEnergy,
  passiveRate,
  critChance,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Zap':
        return <Zap className="w-5 h-5 text-amber-400" />;
      case 'BatteryCharging':
        return <BatteryCharging className="w-5 h-5 text-emerald-400" />;
      case 'Activity':
        return <Activity className="w-5 h-5 text-cyan-400" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-indigo-400" />;
      case 'Server':
        return <Server className="w-5 h-5 text-purple-400" />;
      case 'Coins':
        return <Coins className="w-5 h-5 text-yellow-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-pink-400" />;
      default:
        return <Zap className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-3 space-y-4 pb-20">
      {/* Overview Stat Badges */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-center">
          <span className="text-[10px] text-slate-400 font-semibold uppercase block">Tap Power</span>
          <span className="text-base font-black text-amber-400 font-mono-num font-display">
            +{tapPower}
          </span>
          <span className="text-[10px] text-slate-500 block">per tap</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-center">
          <span className="text-[10px] text-slate-400 font-semibold uppercase block">Idle Miner</span>
          <span className="text-base font-black text-indigo-400 font-mono-num font-display">
            +{passiveRate}
          </span>
          <span className="text-[10px] text-slate-500 block">coins / sec</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-center">
          <span className="text-[10px] text-slate-400 font-semibold uppercase block">Max Energy</span>
          <span className="text-base font-black text-emerald-400 font-mono-num font-display">
            {maxEnergy}
          </span>
          <span className="text-[10px] text-slate-500 block">stamina</span>
        </div>
      </div>

      {/* Upgrade List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Upgrades & Auto-Mining Bots
          </h2>
          <span className="text-xs text-slate-500">Tap to upgrade</span>
        </div>

        {upgrades.map((item) => {
          const cost = Math.round(item.baseCost * Math.pow(item.costMultiplier, item.level));
          const canAfford = coins >= cost;
          const isMaxed = item.level >= item.maxLevel;

          return (
            <div
              key={item.id}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 flex items-center justify-between gap-3 transition-colors hover:border-slate-700"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700/60 flex items-center justify-center shrink-0">
                  {getIcon(item.iconName)}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold text-white leading-none">
                      {item.title}
                    </h3>
                    <span className="text-[10px] text-slate-400 font-mono font-medium">
                      Lvl {item.level}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                    {item.description}
                  </p>

                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] font-bold text-amber-300">
                      {item.effectLabel}
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                disabled={!canAfford || isMaxed}
                onClick={() => {
                  triggerHaptic('medium');
                  soundEngine.playCoin();
                  onUpgrade(item.id);
                }}
                className={`py-2 px-3 rounded-xl font-bold text-xs shrink-0 flex flex-col items-center justify-center min-w-[80px] transition-transform active:scale-95 ${
                  isMaxed
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    : canAfford
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 hover:brightness-105 shadow-md shadow-amber-500/10'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {isMaxed ? (
                  <span>MAX</span>
                ) : (
                  <>
                    <span className="font-mono-num font-black leading-tight">
                      🪙 {cost.toLocaleString()}
                    </span>
                    <span className="text-[9px] opacity-80 leading-tight">Upgrade</span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
