import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Flame, 
  Globe, 
  ExternalLink, 
  Lock, 
  Cpu, 
  Zap, 
  BookOpen, 
  Terminal, 
  CheckCircle2, 
  ArrowRight,
  Shield,
  Smartphone,
  EyeOff,
  AlertCircle,
  Clock,
  Sparkles,
  MessageSquare
} from 'lucide-react';
import { Tab, PageContent, Bookmark } from '../types/browser';
import { SAMPLE_SEARCH_RESULTS } from '../data/mockWeb';

interface WebCanvasProps {
  currentTab: Tab;
  bookmarks: Bookmark[];
  onNavigate: (url: string) => void;
  onOpenShield: () => void;
  onTriggerFire: () => void;
}

export const WebCanvas: React.FC<WebCanvasProps> = ({
  currentTab,
  bookmarks,
  onNavigate,
  onOpenShield,
  onTriggerFire,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [effTesting, setEffTesting] = useState(false);
  const [effCompleted, setEffCompleted] = useState(false);
  const [effStep, setEffStep] = useState(0);

  const isHome = currentTab.url === 'about:blank' || currentTab.url === 'aegis://home';

  // Handle DuckDuckGo search submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate(`https://duckduckgo.com/?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  // Run EFF test simulation
  const handleStartEffTest = () => {
    setEffTesting(true);
    setEffCompleted(false);
    setEffStep(1);

    setTimeout(() => setEffStep(2), 700);
    setTimeout(() => setEffStep(3), 1400);
    setTimeout(() => setEffStep(4), 2100);
    setTimeout(() => {
      setEffTesting(false);
      setEffCompleted(true);
    }, 2800);
  };

  // Render New Tab / Home
  if (isHome) {
    return (
      <div className="flex-1 overflow-y-auto bg-slate-950 p-4 space-y-6 text-slate-200 no-scrollbar select-none">
        {/* Shield Hero Banner */}
        <div className="pt-2 flex flex-col items-center text-center">
          <div className="relative mb-3">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-950 via-slate-900 to-slate-800 border border-emerald-500/40 flex items-center justify-center shadow-xl shadow-emerald-950/50">
              <ShieldCheck className="w-8 h-8 text-emerald-400" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-900 border border-emerald-400/80 flex items-center justify-center">
              <Lock className="w-2.5 h-2.5 text-emerald-400" />
            </div>
          </div>

          <h1 className="text-xl font-extrabold text-white tracking-tight">
            Aegis Privacy
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xs">
            Zero telemetry. Ephemeral memory. Fingerprint resistance enabled.
          </p>
        </div>

        {/* Omnibox Search Box */}
        <form onSubmit={handleSearchSubmit} className="relative w-full max-w-md mx-auto">
          <div className="flex items-center bg-slate-900 border border-slate-800 focus-within:border-emerald-500/80 focus-within:ring-2 focus-within:ring-emerald-500/20 rounded-2xl p-1.5 shadow-xl transition-all">
            <div className="pl-3 pr-2 text-slate-400">
              <Search className="w-4 h-4 text-emerald-400" />
            </div>
            <input
              type="text"
              id="home-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search privately on DuckDuckGo..."
              className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none py-1.5"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors active:scale-95 shrink-0"
            >
              Search
            </button>
          </div>
        </form>

        {/* Protection Metrics Pill Bar */}
        <div className="grid grid-cols-3 gap-2.5 max-w-md mx-auto">
          <div 
            onClick={onOpenShield}
            className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 cursor-pointer text-center transition-all"
          >
            <div className="text-base font-mono font-bold text-emerald-400">41</div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Trackers Blocked</div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 text-center">
            <div className="text-base font-mono font-bold text-cyan-400">1.8 MB</div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Data Saved</div>
          </div>

          <div 
            onClick={onTriggerFire}
            className="p-3 rounded-2xl bg-slate-900/80 border border-orange-900/30 hover:border-orange-600/50 cursor-pointer text-center transition-all group"
          >
            <div className="text-base font-mono font-bold text-orange-400 flex items-center justify-center gap-1">
              <Flame className="w-4 h-4 fill-orange-500/20 group-hover:scale-110 transition-transform" />
              <span>Burn</span>
            </div>
            <div className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Shred Session</div>
          </div>
        </div>

        {/* Quick Private Bookmarks Grid */}
        <div className="max-w-md mx-auto space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span className="font-semibold uppercase tracking-wider text-[10px]">Verified Privacy Portals</span>
            <span className="text-[10px] text-emerald-400 font-medium">100% Track-Free</span>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            {bookmarks.map((bm) => (
              <button
                key={bm.id}
                onClick={() => onNavigate(bm.url)}
                className="p-3 rounded-2xl bg-slate-900 border border-slate-800/90 hover:border-emerald-500/60 flex flex-col items-center text-center gap-2 transition-all active:scale-95 group shadow-sm"
              >
                <div className="w-9 h-9 rounded-xl bg-slate-800/90 group-hover:bg-emerald-950/60 border border-slate-700/60 group-hover:border-emerald-700/60 flex items-center justify-center text-slate-200 group-hover:text-emerald-400 transition-colors">
                  <Globe className="w-4 h-4" />
                </div>
                <span className="text-xs font-semibold text-slate-200 group-hover:text-white line-clamp-1">
                  {bm.title}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Educational Privacy Insights */}
        <div className="max-w-md mx-auto p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Fingerprint Jamming Active</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Ordinary browsers leak your screen dimensions, GPU vendor, and canvas rendering traits. Aegis injects subtle cryptographic noise into canvas calls to guarantee your device looks identical to millions of other Android devices.
          </p>
          <div className="pt-1">
            <button
              onClick={() => onNavigate('https://coveryourtracks.eff.org')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>Test browser fingerprint resistance</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Render DuckDuckGo Search View
  if (currentTab.content?.interactiveType === 'duckduckgo' || currentTab.url.includes('duckduckgo.com')) {
    // Extract query parameter if present
    let queryParam = 'privacy';
    try {
      const u = new URL(currentTab.url);
      queryParam = u.searchParams.get('q') || 'privacy';
    } catch {
      queryParam = 'privacy';
    }

    const matchedResults = SAMPLE_SEARCH_RESULTS[queryParam.toLowerCase()] || [
      {
        title: `Search results for "${queryParam}" — DuckDuckGo`,
        url: `https://duckduckgo.com/?q=${encodeURIComponent(queryParam)}`,
        snippet: `Zero tracking search results for query "${queryParam}". Aegis browser stripped all tracking tags and referrer tokens before requesting.`,
      },
      {
        title: 'Privacy Guides: Safe Browsing on Android',
        url: 'https://privacyguides.org',
        snippet: 'Discover tools that defend your rights. Avoid surveillance capitalism and protect your browsing history.',
      },
      {
        title: 'EFF: Surveillance Self-Defense Guide',
        url: 'https://coveryourtracks.eff.org',
        snippet: 'Defending against tracking beacons, AAID advertisers, and cross-site user fingerprinting.',
      },
    ];

    return (
      <div className="flex-1 overflow-y-auto bg-slate-950 p-4 space-y-4 text-slate-200 no-scrollbar">
        {/* DuckDuckGo Mini Header */}
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold text-xs border border-orange-500/40">
              DDG
            </div>
            <div>
              <h2 className="text-xs font-bold text-slate-100">DuckDuckGo Search</h2>
              <p className="text-[10px] text-slate-400">Encrypted • No Search History Stored</p>
            </div>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/40">
            0 TRACKERS
          </span>
        </div>

        {/* Search Results List */}
        <div className="space-y-3 max-w-lg mx-auto">
          {matchedResults.map((res, i) => (
            <div
              key={i}
              onClick={() => onNavigate(res.url)}
              className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800/80 hover:border-emerald-500/60 cursor-pointer transition-all active:scale-[0.99] space-y-1 group"
            >
              <span className="text-[10px] font-mono text-slate-500 truncate block">
                {res.url}
              </span>
              <h3 className="text-sm font-bold text-emerald-400 group-hover:underline">
                {res.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {res.snippet}
              </p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Render EFF Cover Your Tracks Live Test
  if (currentTab.content?.interactiveType === 'eff_test' || currentTab.url.includes('coveryourtracks.eff.org')) {
    return (
      <div className="flex-1 overflow-y-auto bg-slate-950 p-4 space-y-5 text-slate-200 no-scrollbar select-none">
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 text-center">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-950/80 border border-emerald-600/50 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Cover Your Tracks Audit</h2>
            <p className="text-xs text-slate-400 mt-1">
              Electronic Frontier Foundation Browser Fingerprint Diagnostic
            </p>
          </div>

          {!effCompleted && !effTesting && (
            <button
              id="start-eff-test-btn"
              onClick={handleStartEffTest}
              className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              <span>Run Live Fingerprint Audit</span>
            </button>
          )}

          {effTesting && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-center gap-2 text-xs font-semibold text-emerald-400 animate-pulse">
                <Cpu className="w-4 h-4 animate-spin" />
                <span>Auditing Aegis Defensive Layers...</span>
              </div>
              <div className="space-y-1.5 text-[11px] text-slate-400 text-left">
                <p className={effStep >= 1 ? 'text-emerald-400 font-semibold' : 'text-slate-600'}>
                  {effStep >= 1 ? '✓' : '•'} 1. Testing WebGL Canvas Jitter...
                </p>
                <p className={effStep >= 2 ? 'text-emerald-400 font-semibold' : 'text-slate-600'}>
                  {effStep >= 2 ? '✓' : '•'} 2. Checking AudioContext Hash resistance...
                </p>
                <p className={effStep >= 3 ? 'text-emerald-400 font-semibold' : 'text-slate-600'}>
                  {effStep >= 3 ? '✓' : '•'} 3. Verifying Global Privacy Control (GPC) signal...
                </p>
                <p className={effStep >= 4 ? 'text-emerald-400 font-semibold' : 'text-slate-600'}>
                  {effStep >= 4 ? '✓' : '•'} 4. Assessing tracker blacklists...
                </p>
              </div>
            </div>
          )}

          {effCompleted && (
            <div className="space-y-3 pt-2">
              <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>TEST PASSED: STRONG PROTECTION (GRADE A+)</span>
              </div>

              <div className="text-left space-y-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">Tracking Ads Blocked</span>
                  <span className="text-emerald-400 font-bold">100% Yes</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">Invisible Trackers Blocked</span>
                  <span className="text-emerald-400 font-bold">100% Yes</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">Canvas Fingerprint Uniqueness</span>
                  <span className="text-emerald-400 font-bold">Randomized Noise (Zero Bits)</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">Global Privacy Control (GPC)</span>
                  <span className="text-emerald-400 font-bold">Respected (DNT=1)</span>
                </div>
              </div>

              <button
                onClick={handleStartEffTest}
                className="text-xs text-slate-400 hover:text-slate-200 underline pt-1"
              >
                Re-run Audit
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Render Privacy Guides Hub
  if (currentTab.content?.interactiveType === 'privacy_guides' || currentTab.url.includes('privacyguides.org')) {
    return (
      <div className="flex-1 overflow-y-auto bg-slate-950 p-4 space-y-4 text-slate-200 no-scrollbar">
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider">
            <BookOpen className="w-4 h-4" />
            <span>Privacy Guides Knowledge Base</span>
          </div>
          <h2 className="text-base font-bold text-white">Recommended Android Defenses</h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            Essential software choices for sovereign computing and data minimization.
          </p>
        </div>

        <div className="space-y-3">
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-100">Private Browsing on Android</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/40 font-bold">
                Tier 1
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Use browsers with strict isolation, ephemeral tabs, and automatic cookie destruction. Aegis Android prevents cross-origin session leaks.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-100">Encrypted Messaging</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800/40 font-bold">
                Signal
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Signal Protocol ensures forward secrecy and zero metadata logging for text, calls, and files.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-100">Encrypted DNS (DoH)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/40 font-bold">
                Quad9 / Cloudflare
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Encrypt your domain lookups over port 443 so your ISP or local Wi-Fi provider cannot catalog the domains you visit.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Render Hacker News
  if (currentTab.content?.interactiveType === 'hackernews' || currentTab.url.includes('news.ycombinator.com')) {
    const hnPosts = [
      { id: 1, title: 'Show HN: Aegis – Zero-telemetry Android browser with canvas jitter', points: 342, comments: 89, by: 'antigravity_dev', time: '2 hours ago' },
      { id: 2, title: 'EFF updates Cover Your Tracks with new fingerprinting resistance tests', points: 198, comments: 45, by: 'torvalds_fan', time: '4 hours ago' },
      { id: 3, title: 'Why Android needs system-level cookie partitioning by default', points: 276, comments: 112, by: 'sec_researcher', time: '6 hours ago' },
      { id: 4, title: 'Tor Project announces next-gen onion relay circuit routing protocol', points: 415, comments: 160, by: 'cryptonerd', time: '8 hours ago' },
    ];

    return (
      <div className="flex-1 overflow-y-auto bg-slate-950 p-4 space-y-3 text-slate-200 no-scrollbar">
        <div className="p-3 bg-orange-950/50 border border-orange-700/50 rounded-2xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-orange-600 text-white flex items-center justify-center font-bold text-xs">
              Y
            </div>
            <h2 className="text-xs font-bold text-slate-100">Hacker News (Clean Reader)</h2>
          </div>
          <span className="text-[10px] text-orange-400 font-mono">Stripped Ads & Trackers</span>
        </div>

        <div className="space-y-2 max-w-lg mx-auto">
          {hnPosts.map((post) => (
            <div
              key={post.id}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1"
            >
              <h3 className="text-xs font-bold text-slate-200 hover:text-emerald-400 transition-colors">
                {post.title}
              </h3>
              <div className="flex items-center gap-2 text-[10px] text-slate-400">
                <span>{post.points} points</span>
                <span>•</span>
                <span>by {post.by}</span>
                <span>•</span>
                <span>{post.time}</span>
                <span>•</span>
                <span className="flex items-center gap-1 text-slate-300">
                  <MessageSquare className="w-3 h-3" />
                  {post.comments} comments
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Render Standard Article / Clean Reader View
  return (
    <div className={`flex-1 overflow-y-auto p-5 space-y-5 no-scrollbar ${
      currentTab.readerMode ? 'bg-slate-950 text-slate-200 font-serif leading-relaxed' : 'bg-slate-950 text-slate-200'
    }`}>
      {/* Article Header */}
      <div className="space-y-2 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          <Globe className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-mono">{currentTab.url}</span>
          {currentTab.content?.readTime && (
            <>
              <span>•</span>
              <span className="flex items-center gap-1 text-slate-400">
                <Clock className="w-3 h-3" />
                {currentTab.content.readTime}
              </span>
            </>
          )}
        </div>

        <h1 className="text-lg font-bold text-white tracking-tight">
          {currentTab.title}
        </h1>

        {currentTab.content?.summary && (
          <p className="text-xs text-slate-400 leading-relaxed font-sans">
            {currentTab.content.summary}
          </p>
        )}
      </div>

      {/* Article Sections */}
      {currentTab.content?.sections?.map((sec, idx) => (
        <div key={idx} className="space-y-3">
          {sec.heading && (
            <h2 className="text-sm font-bold text-slate-100 font-sans tracking-wide">
              {sec.heading}
            </h2>
          )}

          {sec.paragraphs.map((p, pIdx) => (
            <p key={pIdx} className="text-xs text-slate-300 leading-relaxed">
              {p}
            </p>
          ))}

          {sec.quote && (
            <blockquote className="p-3 my-2 border-l-2 border-emerald-500 bg-slate-900/60 rounded-r-xl italic text-xs text-emerald-200">
              "{sec.quote}"
            </blockquote>
          )}

          {sec.list && (
            <ul className="space-y-1.5 pl-4 list-disc text-xs text-slate-300 marker:text-emerald-400">
              {sec.list.map((item, iIdx) => (
                <li key={iIdx}>{item}</li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  );
};
