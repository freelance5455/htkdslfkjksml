import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  RefreshCw, 
  AlertCircle, 
  Play, 
  Square, 
  MessageSquare,
  ShieldAlert,
  Volume1
} from 'lucide-react';
import { Subject } from '../types';

interface VoiceTalkProps {
  language: string;
}

export default function VoiceTalk({ language }: VoiceTalkProps) {
  const [activeSubject, setActiveSubject] = useState<Subject>('Science');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'model'; text: string }[]>([]);
  const [currentTranscription, setCurrentTranscription] = useState<string>('');

  // Voice Speech settings
  const [voiceRate, setVoiceRate] = useState<number>(1.0);
  const [voiceGender, setVoiceGender] = useState<'female' | 'male'>('female');

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const activeUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const translations: Record<string, Record<string, string>> = {
    en: {
      title: 'Voice Interactive Tutor',
      sub: 'Speak your question out loud, and hear the AI tutor respond in real time. Learn just like talking to a real teacher!',
      selectSubject: 'Select Focus Subject:',
      startMic: 'Start Speaking (Tap the Mic)',
      stopMic: 'Done Speaking / Stop',
      listening: 'StudySkill is listening... Ask your question now',
      processing: 'StudySkill is thinking...',
      voiceTeacher: 'Voice Gender:',
      female: 'Female Voice',
      male: 'Male Voice',
      speed: 'Voice Speech Speed:',
      normal: 'Normal Speed',
      clearChat: 'Clear History',
      welcomeMsg: 'Hello there! I am your StudySkill Voice Teacher. Speak up and ask me any questions in history, science or languages. I am listening!',
      placeholder: 'Your transcriptions will appear here...',
      notSupported: 'Web speech API is not fully active in some frames. Consider opening in a new browser window.'
    },
    bn: {
      title: 'ভয়েস কথোপকথন (Voice Conversation)',
      sub: 'মুখে প্রশ্ন করো, AI মুখে উত্তর দেবে। একদম জীবন্ত শিক্ষকের মতো কথা বলে শেখার রোমাঞ্চকর সুযোগ!',
      selectSubject: 'কথোপকথনের মূল বিষয়:',
      startMic: 'কথা বলা শুরু করুন (গ্লোয়িং বাটনে ক্লিক করুন)',
      stopMic: 'কথা বলা সম্পন্ন হয়েছে',
      listening: 'AI শুনছে... এখন আপনার প্রশ্নটি মুখে বলুন',
      processing: 'AI চিন্তা করছে...',
      voiceTeacher: 'কণ্ঠের ধরণ:',
      female: 'নারী কণ্ঠ (Female)',
      male: 'পুরুষ কণ্ঠ (Male)',
      speed: 'কথা বলার গতি:',
      normal: 'স্বাভাবিক',
      clearChat: 'কথোপকথন মুছুন',
      welcomeMsg: 'হ্যালো! আমি তোমার StudySkill AI ভয়েস শিক্ষক। বিজ্ঞান, ইতিহাস বা গণিত সম্পর্কে যেকোনো প্রশ্ন মুখে জিজ্ঞেস করো। আমি উত্তর দেবো!',
      placeholder: 'কথা বলার পর আপনার বাক্য এখানে প্রদর্শিত হবে...',
      notSupported: 'অনুগ্রহ করে ক্রোম ব্রাউজার ব্যবহার করুন বা নতুন ট্যাবে অ্যাপটি খুলুন।'
    },
    hi: {
      title: 'वॉइस ट्यूटर बातचीत (Voice Tutor)',
      sub: 'मुंह से प्रश्न पूछें, AI मुंह से उत्तर देगा। बिल्कुल असली शिक्षक की तरह बात करके सीखने का अनोखा अनुभव!',
      selectSubject: 'बातचीत का मुख्य विषय:',
      startMic: 'बात करना शुरू करें (माइक पर क्लिक करें)',
      stopMic: 'बातचीत बंद करें',
      listening: 'AI सुन रहा है... अब अपना प्रश्न बोलें',
      processing: 'AI सोच रहा है...',
      voiceTeacher: 'आवाज़ का प्रकार:',
      female: 'महिला आवाज़ (Female)',
      male: 'पुरुष आवाज़ (Male)',
      speed: 'आवाज़ की गति:',
      normal: 'सामान्य',
      clearChat: 'इतिहास साफ़ करें',
      welcomeMsg: 'नमस्ते! मैं आपका एआई वॉयस शिक्षक हूँ। विज्ञान, इतिहास या गणित के बारे में कोई भी प्रश्न मुझसे पूछें। मैं जवाब दूंगा!',
      placeholder: 'बोलने के बाद आपका वाक्य यहाँ दिखाई देगा...',
      notSupported: 'वेब स्पीच एपीआई कुछ फ्रेम में पूरी तरह से सक्रिय नहीं है।'
    },
    es: {
      title: 'Tutor de Voz Interactivo',
      sub: 'Haz tu pregunta en voz alta y escucha la respuesta del tutor de IA en tiempo real. ¡Aprende hablando como con un profesor real!',
      selectSubject: 'Materia del Enfoque:',
      startMic: 'Comenzar a Hablar (Toca el Micrófono)',
      stopMic: 'Terminar de Hablar / Detener',
      listening: 'StudySkill está escuchando... Haz tu pregunta ahora',
      processing: 'StudySkill está pensando...',
      voiceTeacher: 'Género de Voz:',
      female: 'Voz Femenina',
      male: 'Voz Masculina',
      speed: 'Velocidad de Voz:',
      normal: 'Normal',
      clearChat: 'Limpiar Historial',
      welcomeMsg: '¡Hola! Soy tu tutor de voz de StudySkill. Hazme cualquier pregunta sobre ciencias, historia o matemáticas en voz alta. ¡Te escucho!',
      placeholder: 'Tus transcripciones aparecerán aquí...',
      notSupported: 'La API de voz web no está totalmente disponible en algunos marcos. Intenta abrir la app en una pestaña nueva.'
    },
    fr: {
      title: 'Tuteur Vocal Interactif',
      sub: 'Posez votre question à haute voix et écoutez le tuteur IA vous répondre en temps réel. Apprenez comme avec un vrai professeur !',
      selectSubject: 'Matière Focus :',
      startMic: 'Parler (Appuyer sur le Micro)',
      stopMic: 'Arrêter de Parler',
      listening: 'StudySkill vous écoute... Posez votre question maintenant',
      processing: 'StudySkill réfléchit...',
      voiceTeacher: 'Genre de la voix :',
      female: 'Voix Féminine',
      male: 'Voix Masculine',
      speed: 'Vitesse de parole :',
      normal: 'Normale',
      clearChat: 'Effacer l\'historique',
      welcomeMsg: 'Bonjour ! Je suis votre tuteur vocal StudySkill. Posez-moi vos questions de sciences, d\'histoire ou de mathématiques à haute voix. Je vous écoute !',
      placeholder: 'Votre texte transcrit s\'affichera ici...',
      notSupported: 'L\'API de reconnaissance vocale n\'est pas entièrement disponible dans cette iframe. Veuillez l\'ouvrir dans un nouvel onglet.'
    },
    ar: {
      title: 'المعلم الصوتي التفاعلي بالذكاء الاصطناعي',
      sub: 'تحدث بسؤالك بصوت مسموع، واستمع إلى إجابة معلمك الذكي فورياً وبشكل مباشر.',
      selectSubject: 'موضوع المحادثة:',
      startMic: 'ابدأ التحدث (اضغط على الميكروفون)',
      stopMic: 'إنهاء التحدث / إيقاف',
      listening: 'المعلم إدوميند يستمع إليك... تفضل بطرح سؤالك الآن',
      processing: 'المعلم إدوميند يفكر في الإجابة...',
      voiceTeacher: 'جنس صوت المعلم:',
      female: 'صوت نسائي',
      male: 'صوت رجالي',
      speed: 'سرعة نطق الصوت:',
      normal: 'طبيعي',
      clearChat: 'مسح السجل',
      welcomeMsg: 'مرحباً بك! أنا معلمك الصوتي الذكي من إدوميند. اسألني أي سؤال في العلوم، التاريخ أو الرياضيات وسأجيبك فوراً بالصوت!',
      placeholder: 'سيظهر النص المنطوق هنا مباشرة...',
      notSupported: 'خاصية التعرف على الصوت ليست مدعومة بالكامل داخل هذا الإطار المدمج. يرجى فتح التطبيق في نافذة متصفح جديدة.'
    }
  };

  const t = translations[language] || translations['en'];

  useEffect(() => {
    // Set welcome message depending on language choice
    setChatHistory([
      { role: 'model', text: t.welcomeMsg }
    ]);

    // Setup speech synthesis
    if (typeof window !== 'undefined') {
      synthRef.current = window.speechSynthesis;
    }

    // Setup speech recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      
      // Auto assign language
      if (language === 'bn') rec.lang = 'bn-IN';
      else if (language === 'hi') rec.lang = 'hi-IN';
      else rec.lang = 'en-US';

      rec.onstart = () => {
        setIsListening(true);
        setCurrentTranscription('');
      };

      rec.onresult = (event: any) => {
        const transcript = event?.results?.[0]?.[0]?.transcript;
        if (transcript) {
          setCurrentTranscription(transcript);
          handleSendVoicePrompt(transcript);
        }
      };

      rec.onerror = (event: any) => {
        console.error('Recognition error:', event);
        setError('Microphone or Speech Recognition timed out. Try clicking the mic again.');
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    } else {
      setError('Web Speech API is not supported in this browser. Please use Chrome.');
    }

    // Cleanup voices on leave
    return () => {
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, [language]);

  // Read AI Text Aloud
  const speakText = (text: string) => {
    if (!synthRef.current) return;
    
    // Cancel prior speech
    synthRef.current.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Choose voice language
    if (language === 'bn') {
      utterance.lang = 'bn-IN';
    } else if (language === 'hi') {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-US';
    }

    // Adjust rate and pitch
    utterance.rate = voiceRate;
    utterance.pitch = voiceGender === 'female' ? 1.1 : 0.85;

    // Retrieve compatible browser voices
    const voices = synthRef.current.getVoices();
    const matches = voices.filter(v => v.lang.startsWith(utterance.lang));
    
    if (matches.length > 0) {
      // Pick voice matching gender choice
      const preferred = matches.find(v => 
        voiceGender === 'female' 
          ? v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('zira') || v.name.toLowerCase().includes('google')
          : v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('david')
      );
      utterance.voice = preferred || matches[0];
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    activeUtteranceRef.current = utterance;
    synthRef.current.speak(utterance);
  };

  const handleSendVoicePrompt = async (transcript: string) => {
    if (!transcript.trim()) return;

    setLoading(true);
    setError('');

    // Append student's voice to chat UI
    const updatedHistory = [...chatHistory, { role: 'user' as const, text: transcript }];
    setChatHistory(updatedHistory);

    try {
      const response = await fetch('/api/gemini/chat-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: transcript,
          history: updatedHistory,
          subject: activeSubject,
          language
        })
      });

      if (!response.ok) {
        throw new Error('Low-latency Voice service failed.');
      }

      const data = await response.json();
      setChatHistory([...updatedHistory, { role: 'model', text: data.text }]);
      
      // AI immediately speaks the response aloud!
      speakText(data.text);
    } catch (err: any) {
      setError(err.message || 'Speech generation failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleMicClick = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      if (synthRef.current) {
        synthRef.current.cancel(); // Stop talking before listening
      }
      setError('');
      recognitionRef.current?.start();
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-6 md:p-10 space-y-8">
      {/* Title */}
      <div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-800 font-display tracking-tight flex items-center gap-2">
          <Mic className="w-7 h-7 text-indigo-500 animate-pulse" /> {t.title}
        </h1>
        <p className="text-sm text-slate-500 mt-1">{t.sub}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Interaction Panel */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm p-6 md:p-8 flex flex-col justify-between min-h-[500px]">
          
          {/* Header config */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">{t.selectSubject}</span>
              <select
                value={activeSubject}
                onChange={(e) => setActiveSubject(e.target.value as Subject)}
                className="text-xs bg-slate-100 border-none px-2 py-1.5 rounded-lg font-bold text-slate-700 focus:outline-none"
              >
                <option value="Science">Science (বিজ্ঞান)</option>
                <option value="Mathematics">Mathematics (গণিত)</option>
                <option value="History">History (ইতিহাস)</option>
                <option value="Geography">Geography (ভূগোল)</option>
              </select>
            </div>
            
            <button
              onClick={() => {
                setChatHistory([{ role: 'model', text: t.welcomeMsg }]);
                setCurrentTranscription('');
                if (synthRef.current) synthRef.current.cancel();
              }}
              className="text-xs font-bold text-slate-400 hover:text-slate-600 transition-colors"
            >
              {t.clearChat}
            </button>
          </div>

          {/* Chat transcript history lists */}
          <div className="flex-1 overflow-y-auto py-6 space-y-4 max-h-[300px]">
            {chatHistory.map((chat, idx) => (
              <div 
                key={idx} 
                className={`flex gap-3 max-w-[85%] ${chat.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
              >
                <div className={`p-3.5 rounded-2xl text-xs font-medium leading-relaxed shadow-sm ${
                  chat.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-none'
                    : 'bg-slate-50 border border-slate-100 text-slate-800 rounded-tl-none'
                }`}>
                  {chat.text}
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="flex gap-3 max-w-[85%]">
                <div className="p-3.5 rounded-2xl bg-indigo-50/50 border border-indigo-100 text-indigo-800 rounded-tl-none text-xs font-semibold flex items-center gap-2">
                  <RefreshCw className="w-4.5 h-4.5 animate-spin" />
                  {t.processing}
                </div>
              </div>
            )}
          </div>

          {/* MIC TRIGGERS & STATUS INDICATORS */}
          <div className="border-t border-slate-100 pt-6 space-y-4 text-center">
            
            {/* Live transcribing text */}
            {currentTranscription && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 max-w-md mx-auto text-xs font-mono text-indigo-600">
                "{currentTranscription}"
              </div>
            )}

            {/* Glowing Microphone Button */}
            <div className="flex flex-col items-center gap-3">
              <button
                onClick={handleMicClick}
                className={`w-20 h-20 rounded-full flex items-center justify-center text-white transition-all duration-300 relative ${
                  isListening
                    ? 'bg-rose-500 hover:bg-rose-600 voice-pulse scale-105'
                    : isSpeaking
                    ? 'bg-emerald-500 hover:bg-emerald-600'
                    : 'bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-600/25 hover:scale-105'
                }`}
              >
                {isListening ? (
                  <MicOff className="w-8 h-8" />
                ) : isSpeaking ? (
                  <Volume2 className="w-8 h-8 animate-bounce" />
                ) : (
                  <Mic className="w-8 h-8" />
                )}
              </button>

              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {isListening ? t.listening : isSpeaking ? 'AI শিক্ষক কথা বলছেন...' : t.startMic}
              </span>
            </div>

          </div>

        </div>

        {/* Configuration Column */}
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-5">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">{t.voiceTeacher}</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">গলা বা কণ্ঠের বৈশিষ্ট্য নির্ধারণ করুন</p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setVoiceGender('female');
                  if (chatHistory.length > 0) speakText(chatHistory[chatHistory.length - 1].text);
                }}
                className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                  voiceGender === 'female'
                    ? 'bg-indigo-50 border-indigo-400 text-indigo-900 font-semibold shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                👩 {t.female}
              </button>
              <button
                onClick={() => {
                  setVoiceGender('male');
                  if (chatHistory.length > 0) speakText(chatHistory[chatHistory.length - 1].text);
                }}
                className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                  voiceGender === 'male'
                    ? 'bg-indigo-50 border-indigo-400 text-indigo-900 font-semibold shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                👨 {t.male}
              </button>
            </div>

            {/* Speaking Speed rate control */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs text-slate-500 font-bold">
                <span>{t.speed}</span>
                <span className="font-mono text-indigo-600">{voiceRate}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                value={voiceRate}
                onChange={(e) => {
                  const rate = parseFloat(e.target.value);
                  setVoiceRate(rate);
                }}
                className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[9px] text-slate-400 font-semibold">
                <span>ধীর</span>
                <span>{t.normal}</span>
                <span>দ্রুত</span>
              </div>
            </div>
          </div>

          {/* Support Notes */}
          {error && (
            <div className="bg-amber-50 border border-amber-100 text-amber-800 p-4 rounded-2xl flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 shrink-0 text-amber-500 mt-0.5" />
              <div>
                <h4 className="font-bold text-xs">নোটিশ / ত্রুটি</h4>
                <p className="text-[10px] text-amber-700 leading-relaxed mt-1">{error}</p>
                <span className="text-[9px] font-semibold text-indigo-600 block mt-1.5">{t.notSupported}</span>
              </div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
