import React from 'react';
import { X, Share2, Printer, Phone, Mail, MapPin, Calendar, FileText } from 'lucide-react';
import { Ledger, Voucher, Company } from '../types/tally';
import { formatCurrency, formatINR, formatDateDisplay } from '../utils/tallyEngine';
import { triggerHaptic } from '../utils/haptics';

interface LedgerStatementModalProps {
  ledger: Ledger;
  vouchers: Voucher[];
  company: Company;
  onClose: () => void;
  onOpenVoucher: (vch: Voucher) => void;
}

export const LedgerStatementModal: React.FC<LedgerStatementModalProps> = ({
  ledger,
  vouchers,
  company,
  onClose,
  onOpenVoucher,
}) => {
  // Find all vouchers involving this ledger
  const relatedVouchers = vouchers.filter((vch) => {
    if (vch.partyLedgerId === ledger.id) return true;
    if (vch.salesPurchaseLedgerId === ledger.id) return true;
    if (vch.rows?.some((r) => r.ledgerId === ledger.id)) return true;
    return false;
  });

  // Calculate chronological entries with running balance
  let runningBal = ledger.openingBalanceType === 'Dr' ? ledger.openingBalance : -ledger.openingBalance;

  const statementRows = relatedVouchers.map((vch) => {
    let debit = 0;
    let credit = 0;
    let particulars = '';

    if (vch.voucherType === 'sales') {
      if (vch.partyLedgerId === ledger.id) {
        debit = vch.totalAmount;
        particulars = `Sales - Inv #${vch.voucherNumber}`;
      } else if (vch.salesPurchaseLedgerId === ledger.id) {
        credit = vch.taxableAmount;
        particulars = `Sales to ${vch.partyLedgerName || 'Customer'}`;
      }
    } else if (vch.voucherType === 'purchase') {
      if (vch.partyLedgerId === ledger.id) {
        credit = vch.totalAmount;
        particulars = `Purchase - Bill #${vch.voucherNumber}`;
      } else if (vch.salesPurchaseLedgerId === ledger.id) {
        debit = vch.taxableAmount;
        particulars = `Purchases from ${vch.partyLedgerName || 'Supplier'}`;
      }
    } else if (vch.rows) {
      const match = vch.rows.find((r) => r.ledgerId === ledger.id);
      if (match) {
        if (match.type === 'Dr') debit = match.amount;
        else credit = match.amount;
        const otherRows = vch.rows.filter((r) => r.ledgerId !== ledger.id);
        particulars = otherRows.map((r) => r.ledgerName).join(', ') || vch.voucherType.toUpperCase();
      }
    }

    runningBal += debit - credit;

    return {
      voucher: vch,
      date: vch.date,
      voucherType: vch.voucherType,
      voucherNo: vch.voucherNumber,
      particulars,
      debit,
      credit,
      runningBalance: Math.abs(runningBal),
      runningType: runningBal >= 0 ? 'Dr' : 'Cr',
    };
  });

  const handleShareWhatsApp = () => {
    triggerHaptic('light');
    const text = `*Account Confirmation Statement*\n*${ledger.name}*\nBalance: ${formatCurrency(ledger.currentBalance)} ${ledger.currentBalanceType}\nStatement from: ${company.name}\nFor queries contact: ${company.phone}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handlePrint = () => {
    triggerHaptic('light');
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4">
      <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-slate-800 dark:text-slate-100">
        {/* Header */}
        <div className="bg-emerald-900 text-white px-4 py-3 flex items-center justify-between shrink-0">
          <div>
            <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
              Ledger Account Statement
            </div>
            <h2 className="text-base font-bold truncate max-w-xs sm:max-w-md">
              {ledger.name}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-emerald-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Ledger Metadata Card */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 shrink-0 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 font-mono">
              Group: {ledger.group}
            </span>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-sans">Closing Balance</span>
              <span className="text-sm font-bold font-mono text-emerald-700 dark:text-emerald-400 tabular-nums">
                {formatCurrency(ledger.currentBalance)} {ledger.currentBalanceType}
              </span>
            </div>
          </div>

          {(ledger.gstin || ledger.phone || ledger.address) && (
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex flex-wrap gap-x-4 gap-y-1 font-mono">
              {ledger.gstin && <span>GSTIN: {ledger.gstin}</span>}
              {ledger.phone && <span>Ph: {ledger.phone}</span>}
              {ledger.address && <span>Addr: {ledger.address}</span>}
            </div>
          )}

          {/* Quick Actions */}
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleShareWhatsApp}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium shadow-xs touch-press"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share WhatsApp</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium hover:bg-slate-300 touch-press"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Statement</span>
            </button>
          </div>
        </div>

        {/* Chronological Statement List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {/* Opening balance row */}
          <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-mono flex items-center justify-between text-slate-600 dark:text-slate-300">
            <div>
              <span className="font-bold">Opening Balance b/f</span>
              <div className="text-[10px] text-slate-400">01-Apr-2026</div>
            </div>
            <span className="font-bold tabular-nums">
              {formatCurrency(ledger.openingBalance)} {ledger.openingBalanceType}
            </span>
          </div>

          {statementRows.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-400">
              No transactions recorded in this financial period.
            </div>
          ) : (
            statementRows.map((row, idx) => (
              <div
                key={idx}
                onClick={() => onOpenVoucher(row.voucher)}
                className="p-2.5 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 hover:border-emerald-500/50 cursor-pointer text-xs font-mono space-y-1.5 transition-all shadow-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold uppercase text-slate-900 dark:text-white">
                      {row.voucherNo}
                    </span>
                    <span className="text-[10px] text-slate-400">({row.voucherType})</span>
                  </div>
                  <span className="text-[11px] text-slate-400">{formatDateDisplay(row.date)}</span>
                </div>

                <div className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-1 font-sans">
                  {row.particulars}
                </div>

                <div className="pt-1 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                  <div>
                    {row.debit > 0 && (
                      <span className="text-emerald-600 dark:text-emerald-400 font-semibold mr-2">
                        Dr: {formatINR(row.debit)}
                      </span>
                    )}
                    {row.credit > 0 && (
                      <span className="text-rose-600 dark:text-rose-400 font-semibold">
                        Cr: {formatINR(row.credit)}
                      </span>
                    )}
                  </div>
                  <div className="text-slate-500 font-medium">
                    Run Bal: {formatINR(row.runningBalance)} {row.runningType}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
