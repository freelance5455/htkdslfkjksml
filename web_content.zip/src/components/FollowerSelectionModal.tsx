import React, { useState } from 'react';
import {
  X,
  Users,
  Sparkles,
  Flame,
  Zap,
  ShieldCheck,
  Coins,
  CheckCircle2,
  Send,
  AlertCircle,
} from 'lucide-react';
import { FollowerPackage } from '../types';

interface FollowerSelectionModalProps {
  username: string;
  userCoins: number;
  onClose: () => void;
  onConfirmSend: (followersCount: number) => void;
}

const PACKAGES: FollowerPackage[] = [
  {
    count: 100,
    label: 'Starter Boost',
    costCoins: 50,
    speed: '1 - 2 Hours',
    retentionRate: '98%',
    tag: 'Quick Test',
  },
  {
    count: 250,
    label: 'Standard Growth',
    costCoins: 100,
    speed: '2 - 4 Hours',
    retentionRate: '99%',
  },
  {
    count: 500,
    label: 'Pro Growth',
    costCoins: 200,
    speed: '4 - 8 Hours',
    retentionRate: '99.5%',
    tag: '🔥 Most Popular',
    highlight: true,
  },
  {
    count: 1000,
    label: 'Mega Influencer',
    costCoins: 350,
    speed: '6 - 12 Hours',
    retentionRate: '99.9%',
    tag: '⚡ Best Value',
    highlight: true,
  },
  {
    count: 2500,
    label: 'Celebrity Tier',
    costCoins: 450,
    speed: '12 - 18 Hours',
    retentionRate: '100%',
    tag: '👑 VIP Pro',
  },
  {
    count: 5000,
    label: 'Viral Explosion',
    costCoins: 500,
    speed: '18 - 24 Hours',
    retentionRate: '100%',
    tag: '🚀 Maximum',
  },
];

export const FollowerSelectionModal: React.FC<FollowerSelectionModalProps> = ({
  username,
  userCoins,
  onClose,
  onConfirmSend,
}) => {
  const [selectedCount, setSelectedCount] = useState<number>(500);

  const selectedPkg = PACKAGES.find((p) => p.count === selectedCount) || PACKAGES[2];
  const hasEnoughCoins = userCoins >= selectedPkg.costCoins;

  const handleSend = () => {
    onConfirmSend(selectedCount);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-purple-500/30 p-6 sm:p-7 shadow-2xl shadow-purple-950/80">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-purple-500/15">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-900/50">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Select Followers
                <span className="text-xs font-mono font-normal text-pink-300 bg-pink-500/15 px-2 py-0.5 rounded-full border border-pink-500/25">
                  @{username}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                चुनें कि आप अपने खाते के लिए कितने फॉलोअर्स चाहते हैं
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Coins indicator in modal */}
        <div className="mt-4 p-3 rounded-2xl bg-slate-950/60 border border-purple-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Coins className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs text-slate-300">Your Available Balance:</span>
          </div>
          <div className="flex items-center gap-1.5 font-mono font-bold text-sm text-amber-300">
            <span>{userCoins.toLocaleString()} Coins</span>
            <span className="text-[10px] text-emerald-400 font-sans font-semibold bg-emerald-500/15 px-1.5 py-0.5 rounded">
              Active
            </span>
          </div>
        </div>

        {/* Follower Packages Grid */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-3 gap-3">
          {PACKAGES.map((pkg) => {
            const isSelected = selectedCount === pkg.count;
            return (
              <button
                key={pkg.count}
                type="button"
                onClick={() => setSelectedCount(pkg.count)}
                className={`relative p-3.5 rounded-2xl text-left transition-all duration-200 border flex flex-col justify-between ${
                  isSelected
                    ? 'bg-gradient-to-b from-purple-950/80 to-pink-950/60 border-pink-500 shadow-lg shadow-pink-950/50 scale-[1.02] ring-2 ring-pink-500/30'
                    : 'bg-slate-950/50 hover:bg-slate-800/60 border-purple-500/20 hover:border-purple-500/40'
                }`}
              >
                {pkg.tag && (
                  <span
                    className={`absolute -top-2.5 right-2 px-2 py-0.5 rounded-full text-[10px] font-bold tracking-tight shadow-md ${
                      pkg.highlight
                        ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-white'
                        : 'bg-purple-600 text-purple-100'
                    }`}
                  >
                    {pkg.tag}
                  </span>
                )}

                <div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl sm:text-2xl font-extrabold text-white">
                      +{pkg.count.toLocaleString()}
                    </span>
                  </div>
                  <div className="text-[11px] font-medium text-purple-200/80 mt-0.5">
                    Followers
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-purple-500/15 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1 font-mono">
                    <Zap className="w-3 h-3 text-amber-400" />
                    {pkg.speed}
                  </span>
                  <span className="font-bold text-amber-300 font-mono flex items-center gap-0.5">
                    🪙 {pkg.costCoins}
                  </span>
                </div>

                {isSelected && (
                  <div className="absolute top-2.5 left-2.5">
                    <CheckCircle2 className="w-4 h-4 text-pink-400 fill-pink-400/20" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Selected Package Details Box */}
        <div className="mt-5 p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 via-slate-950/60 to-pink-950/40 border border-purple-500/20 space-y-2 text-xs">
          <div className="flex items-center justify-between text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Delivery Protocol:
            </span>
            <span className="text-white font-semibold">Gradual Organic Drip (Anti-Drop)</span>
          </div>
          <div className="flex items-center justify-between text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-pink-400" />
              Account Quality:
            </span>
            <span className="text-pink-300 font-semibold">100% Real Active Profiles</span>
          </div>
          <div className="flex items-center justify-between text-slate-300 font-medium">
            <span className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              Completion Window:
            </span>
            <span className="text-amber-300 font-semibold">Within 24 Hours</span>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-6 flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-1/3 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleSend}
            className="w-2/3 py-3 rounded-xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:brightness-110 active:scale-[0.98] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-pink-900/50 transition-all"
          >
            <Send className="w-4 h-4" />
            <span>Send +{selectedCount.toLocaleString()} Followers</span>
          </button>
        </div>
      </div>
    </div>
  );
};
