import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Download,
  Video,
  Upload,
  Image as ImageIcon,
  Palette,
  Layers,
  Wand2,
  RefreshCw,
  Check,
  Copy,
  ExternalLink,
  Sliders,
  Maximize2,
  Info
} from 'lucide-react';
import { AppSettings, AspectRatio, ImageSize, LogoItem } from '../types';
import { saveLogo } from '../utils/storage';

interface LogoDesignerProps {
  settings: AppSettings;
  onAnimateLogo: (logo: LogoItem) => void;
  onLogoCreated: (logo: LogoItem) => void;
  savedLogos: LogoItem[];
}

const INDUSTRIES = [
  { id: 'tech', name: 'Technology & AI', icon: '💻' },
  { id: 'cyber', name: 'Cyber & Cloud', icon: '🛡️' },
  { id: 'gaming', name: 'Gaming & Esports', icon: '🎮' },
  { id: 'luxury', name: 'Luxury & Fashion', icon: '✨' },
  { id: 'food', name: 'Café & Restaurant', icon: '☕' },
  { id: 'fitness', name: 'Fitness & Health', icon: '⚡' },
  { id: 'finance', name: 'Finance & Crypto', icon: '💎' },
  { id: 'eco', name: 'Eco & Sustainability', icon: '🌱' },
  { id: 'creative', name: 'Studio & Design', icon: '🎨' },
  { id: 'automotive', name: 'Automotive & EV', icon: '🏎️' },
];

const STYLES = [
  { id: 'minimal', name: 'Minimalist Vector', desc: 'Clean, flat geometry, iconic silhouette' },
  { id: '3d-emblem', name: '3D Metallic Emblem', desc: 'Glossy reflections, bevel, dynamic lighting' },
  { id: 'cyberpunk', name: 'Cyberpunk Neon', desc: 'Futuristic glow, neon accents, dark backdrop' },
  { id: 'vintage', name: 'Vintage Mascot Badge', desc: 'Retro typography, detailed line art badge' },
  { id: 'luxury', name: 'Royal Gold Monogram', desc: 'Interlocking letters, sophisticated filigree' },
  { id: 'geometric', name: 'Abstract Geometric', desc: 'Golden ratio curves, polygonal precision' },
  { id: 'gradient', name: 'Modern Gradient Mesh', desc: 'Vibrant fluid blending, tech aesthetic' },
];

const COLOR_PALETTES = [
  { name: 'Neon Cyber', colors: ['#06b6d4', '#a855f7', '#ec4899'] },
  { name: 'Royal Gold', colors: ['#eab308', '#ca8a04', '#1e293b'] },
  { name: 'Silicon Blue', colors: ['#3b82f6', '#1d4ed8', '#60a5fa'] },
  { name: 'Emerald Eco', colors: ['#10b981', '#059669', '#34d399'] },
  { name: 'Sunset Warmth', colors: ['#f97316', '#ef4444', '#fbbf24'] },
  { name: 'Monochrome Dark', colors: ['#ffffff', '#94a3b8', '#0f172a'] },
];

export const LogoDesigner: React.FC<LogoDesignerProps> = ({
  settings,
  onAnimateLogo,
  onLogoCreated,
  savedLogos,
}) => {
  // Input fields
  const [activeTab, setActiveTab] = useState<'create' | 'upload'>('create');
  const [brandName, setBrandName] = useState('Zenith Dynamics');
  const [tagline, setTagline] = useState('Pioneering the Next Era');
  const [industry, setIndustry] = useState('Technology & AI');
  const [style, setStyle] = useState('Minimalist Vector');
  const [selectedPalette, setSelectedPalette] = useState(COLOR_PALETTES[0]);
  const [customColors, setCustomColors] = useState('');
  const [description, setDescription] = useState(
    'A sleek stylized origami falcon combined with a glowing neural network nexus, symbolizing speed and intelligence.'
  );

  // Mandatory affordance for Image Size: 1K, 2K, 4K
  const [imageSize, setImageSize] = useState<ImageSize>('1K');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');

  // Generation states
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [currentLogo, setCurrentLogo] = useState<LogoItem | null>(() => {
    return savedLogos.length > 0 ? savedLogos[0] : null;
  });
  const [copied, setCopied] = useState(false);

  // File upload ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // AI Prompt Enhancement
  const handleEnhancePrompt = () => {
    const enhancements = [
      `Sleek iconic emblem for "${brandName || 'Brand'}" in ${industry}. Featuring sharp precision contours, bold balanced negative space, isolated on a neutral studio backdrop with ${selectedPalette.name} accents.`,
      `Award-winning minimalist insignia for "${brandName || 'Brand'}". ${description}. Crisp vector outlines, timeless branding, premium finish.`,
      `High-concept corporate identity mark for "${brandName || 'Brand'}". Incorporating stylized motifs of ${industry}, dynamic symmetry, and professional visual hierarchy.`,
    ];
    setDescription(enhancements[Math.floor(Math.random() * enhancements.length)]);
  };

  // Generate Logo API Call (mandated model: gemini-3-pro-image-preview)
  const handleGenerateLogo = async () => {
    if (!brandName.trim()) {
      setErrorMsg('Please enter a company or brand name.');
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);

    const colors = customColors
      ? customColors.split(',').map(c => c.trim())
      : selectedPalette.colors;

    try {
      const response = await fetch('/api/generate-logo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          brandName: brandName.trim(),
          industry,
          style,
          description: description.trim(),
          colors,
          tagline: tagline.trim(),
          imageSize, // Affordance: 1K, 2K, 4K
          aspectRatio, // 1:1, 16:9, etc.
          apiKeyOverride: settings.activeProvider === 'gemini' ? settings.geminiApiKey : '',
          modelOverride: settings.geminiModel || 'gemini-3-pro-image-preview',
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate logo');
      }

      const newLogo: LogoItem = {
        id: `logo_${Date.now()}`,
        brandName: brandName.trim(),
        industry,
        style,
        colors,
        tagline: tagline.trim(),
        description: description.trim(),
        imageSize,
        aspectRatio,
        imageUrl: data.imageUrl,
        imageBase64: data.imageBase64,
        mimeType: data.mimeType || 'image/png',
        timestamp: Date.now(),
        promptUsed: data.promptUsed,
        modelUsed: data.modelUsed || 'gemini-3-pro-image-preview',
      };

      setCurrentLogo(newLogo);
      saveLogo(newLogo);
      onLogoCreated(newLogo);
    } catch (err: any) {
      console.error('Logo generation error:', err);
      setErrorMsg(err.message || 'Error occurred while generating logo. Please check network/API status.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Upload custom photo / logo
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      const base64Data = result.replace(/^data:image\/[a-z]+;base64,/, '');

      const uploadedLogo: LogoItem = {
        id: `upload_${Date.now()}`,
        brandName: file.name.replace(/\.[^/.]+$/, ''),
        industry: 'Uploaded Media',
        style: 'Custom Image',
        colors: ['#6366f1'],
        tagline: 'Custom Upload',
        description: 'User uploaded image ready for animation',
        imageSize: '1K',
        aspectRatio: '1:1',
        imageUrl: result,
        imageBase64: base64Data,
        mimeType: file.type,
        timestamp: Date.now(),
        promptUsed: 'User custom upload',
        modelUsed: 'uploaded',
      };

      setCurrentLogo(uploadedLogo);
      saveLogo(uploadedLogo);
      onLogoCreated(uploadedLogo);
      setActiveTab('create');
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadImage = () => {
    if (!currentLogo) return;
    const a = document.createElement('a');
    a.href = currentLogo.imageUrl;
    a.download = `${currentLogo.brandName.toLowerCase().replace(/\s+/g, '_')}_logo_${currentLogo.imageSize}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleCopyImage = async () => {
    if (!currentLogo) return;
    try {
      await navigator.clipboard.writeText(currentLogo.imageUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 p-4 lg:p-6 w-full max-w-7xl mx-auto">
      {/* Left Column: Form & Design Controls */}
      <div className="w-full lg:w-7/12 flex flex-col gap-5">
        {/* Header banner */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl lg:text-2xl font-extrabold tracking-tight text-white flex items-center gap-2.5">
              <Sparkles className="w-6 h-6 text-indigo-400" />
              Company Logo Designer
            </h2>
            <p className="text-xs lg:text-sm text-slate-400 mt-0.5">
              Craft bespoke vector logos powered by <span className="text-indigo-300 font-semibold">gemini-3-pro-image-preview</span> and animate them in 4K.
            </p>
          </div>

          {/* Tab Switcher: Create vs Upload */}
          <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-xl text-xs">
            <button
              onClick={() => setActiveTab('create')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === 'create' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Generate AI
            </button>
            <button
              onClick={() => setActiveTab('upload')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
                activeTab === 'upload' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Image
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-red-200 text-xs flex items-center justify-between">
            <span>{errorMsg}</span>
            <button onClick={() => setErrorMsg(null)} className="text-red-400 hover:text-red-200 text-sm ml-2">
              ×
            </button>
          </div>
        )}

        {activeTab === 'create' ? (
          <div className="space-y-4">
            {/* Brand Name & Tagline */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Company / Brand Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  placeholder="e.g. Zenith Motors, Solarix, Café Velvet"
                  className="w-full bg-slate-900/90 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Tagline / Slogan (Optional)</label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="e.g. Empowering Tomorrow"
                  className="w-full bg-slate-900/90 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Industry Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Industry Category</label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {INDUSTRIES.map((ind) => (
                  <button
                    key={ind.id}
                    type="button"
                    onClick={() => setIndustry(ind.name)}
                    className={`p-2 rounded-xl text-xs text-left border transition-all flex items-center gap-1.5 truncate ${
                      industry === ind.name
                        ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 font-semibold shadow-sm'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    <span>{ind.icon}</span>
                    <span className="truncate">{ind.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Design Style Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Design Style</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {STYLES.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setStyle(st.name)}
                    className={`p-2.5 rounded-xl text-left border transition-all ${
                      style === st.name
                        ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-sm'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-semibold text-xs text-indigo-300">{st.name}</div>
                    <div className="text-[11px] text-slate-400">{st.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* MANDATORY AFFORDANCE: Image Size (1K, 2K, 4K) & Aspect Ratio */}
            <div className="p-4 bg-gradient-to-r from-slate-900 to-indigo-950/40 border border-indigo-500/30 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5" /> High-Resolution Output Config
                </span>
                <span className="text-[10px] text-indigo-400 font-mono">gemini-3-pro-image-preview</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Image Size Affordance (1K, 2K, 4K) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                    <span>Resolution Size</span>
                    <span className="text-[10px] text-slate-400">Crisp vector clarity</span>
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['1K', '2K', '4K'] as ImageSize[]).map((size) => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setImageSize(size)}
                        className={`py-2 px-3 rounded-xl text-xs font-bold transition-all border text-center ${
                          imageSize === size
                            ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/30'
                            : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-600'
                        }`}
                      >
                        {size}
                        <span className="block text-[9px] font-normal opacity-70">
                          {size === '1K' ? '1024px' : size === '2K' ? '2048px' : '4096px'}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Aspect Ratio */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                    <span>Aspect Ratio</span>
                    <span className="text-[10px] text-slate-400">Framing format</span>
                  </label>
                  <div className="grid grid-cols-5 gap-1.5">
                    {(['1:1', '16:9', '9:16', '4:3', '3:4'] as AspectRatio[]).map((ar) => (
                      <button
                        key={ar}
                        type="button"
                        onClick={() => setAspectRatio(ar)}
                        className={`py-2 px-1.5 rounded-xl text-xs font-bold transition-all border text-center ${
                          aspectRatio === ar
                            ? 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-600/30'
                            : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-600'
                        }`}
                      >
                        {ar}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Color Palette Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Brand Color Palette</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {COLOR_PALETTES.map((pal) => (
                  <button
                    key={pal.name}
                    type="button"
                    onClick={() => {
                      setSelectedPalette(pal);
                      setCustomColors('');
                    }}
                    className={`p-2 rounded-xl border flex items-center justify-between transition-all ${
                      selectedPalette.name === pal.name && !customColors
                        ? 'bg-indigo-950/40 border-indigo-500'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-xs text-slate-300">{pal.name}</span>
                    <div className="flex -space-x-1.5">
                      {pal.colors.map((c, i) => (
                        <span
                          key={i}
                          className="w-4 h-4 rounded-full border border-slate-900"
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Concept Description & AI Enhancement */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">Detailed Concept / Motif Prompt</label>
                <button
                  type="button"
                  onClick={handleEnhancePrompt}
                  className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
                >
                  <Wand2 className="w-3.5 h-3.5" /> Enhance Idea
                </button>
              </div>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                placeholder="Describe symbols, shapes, motifs, or mood (e.g., geometric lion head with solar corona)..."
                className="w-full bg-slate-900/90 border border-slate-700/80 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerateLogo}
              disabled={isGenerating || !brandName.trim()}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:via-purple-500 hover:to-pink-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Generating High-Res {imageSize} Logo ({industry})...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Generate {imageSize} Logo with gemini-3-pro-image-preview
                </>
              )}
            </button>
          </div>
        ) : (
          /* Upload Existing Image Tab */
          <div className="p-8 border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-2xl bg-slate-900/50 flex flex-col items-center justify-center text-center transition-colors">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*"
              className="hidden"
            />
            <div className="w-16 h-16 rounded-2xl bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4 shadow-lg">
              <Upload className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-white text-base mb-1">Upload Your Logo or Photo</h3>
            <p className="text-xs text-slate-400 max-w-sm mb-4">
              Select any existing company logo, emblem, or picture from your computer or phone to animate it into a video.
            </p>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all"
            >
              Browse Image Files
            </button>
          </div>
        )}
      </div>

      {/* Right Column: Preview & Animate Action */}
      <div className="w-full lg:w-5/12 flex flex-col gap-4">
        <div className="glass-panel rounded-3xl p-5 border border-slate-800 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-indigo-400" />
              Generated Logo Preview
            </h3>
            {currentLogo && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-indigo-300 border border-slate-700">
                {currentLogo.imageSize} • {currentLogo.aspectRatio}
              </span>
            )}
          </div>

          {/* Logo Canvas Display */}
          <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-gradient-to-b from-slate-900 to-black border border-slate-800 flex items-center justify-center group shadow-2xl">
            {isGenerating ? (
              <div className="flex flex-col items-center gap-3 p-6 text-center">
                <div className="relative">
                  <div className="w-16 h-16 rounded-2xl border-4 border-indigo-500/30 border-t-indigo-500 animate-spin" />
                  <Sparkles className="w-6 h-6 text-pink-400 absolute inset-0 m-auto animate-pulse" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">Synthesizing {imageSize} Logo...</p>
                  <p className="text-xs text-slate-400 mt-1">Prompting gemini-3-pro-image-preview</p>
                </div>
              </div>
            ) : currentLogo ? (
              <>
                <img
                  src={currentLogo.imageUrl}
                  alt={currentLogo.brandName}
                  className="w-full h-full object-contain p-4 transition-transform duration-300 group-hover:scale-105"
                />

                {/* Overlay actions on hover */}
                <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 backdrop-blur-xs">
                  <button
                    onClick={handleDownloadImage}
                    className="p-2.5 rounded-xl bg-slate-900/90 text-white hover:bg-slate-800 shadow-md text-xs flex items-center gap-1.5"
                    title="Download PNG"
                  >
                    <Download className="w-4 h-4" /> Download
                  </button>
                  <button
                    onClick={handleCopyImage}
                    className="p-2.5 rounded-xl bg-slate-900/90 text-white hover:bg-slate-800 shadow-md text-xs flex items-center gap-1.5"
                    title="Copy Data URL"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-500 text-center p-6">
                <ImageIcon className="w-12 h-12 stroke-[1.2]" />
                <p className="text-xs">No logo generated yet. Fill in details and click "Generate Logo"!</p>
              </div>
            )}
          </div>

          {/* Current Logo Info & Prominent "Animate into Video" Button */}
          {currentLogo && (
            <div className="space-y-3">
              <div>
                <h4 className="font-extrabold text-white text-base">{currentLogo.brandName}</h4>
                {currentLogo.tagline && (
                  <p className="text-xs text-slate-400 italic">"{currentLogo.tagline}"</p>
                )}
                <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">{currentLogo.description}</p>
              </div>

              {/* HERO CALL TO ACTION: ANIMATE INTO VIDEO */}
              <button
                onClick={() => onAnimateLogo(currentLogo)}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:from-pink-500 hover:via-purple-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
              >
                <Video className="w-4 h-4" />
                Animate this Logo into Video (Gemini Omni Flash)
              </button>
            </div>
          )}

          {/* Saved Logos Carousel */}
          {savedLogos.length > 1 && (
            <div className="pt-2 border-t border-slate-800/80">
              <span className="text-[11px] font-semibold text-slate-400 block mb-2">Previous Designs</span>
              <div className="flex gap-2 overflow-x-auto pb-1">
                {savedLogos.slice(0, 6).map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setCurrentLogo(item)}
                    className={`w-14 h-14 rounded-xl border overflow-hidden shrink-0 transition-transform ${
                      currentLogo?.id === item.id ? 'border-indigo-500 ring-2 ring-indigo-500/40 scale-105' : 'border-slate-800 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={item.imageUrl} alt={item.brandName} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
