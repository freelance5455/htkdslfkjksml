import { useEffect, useState } from "react";
import { listPosts } from "@/lib/cutegirls/api";
import type { FeedQuery, PostView } from "@/lib/cutegirls/model";
import { useSalon } from "@/lib/cutegirls/store";
import { EmptyNote, SkeletonCard } from "./bits";
import { PostCard } from "./post-card";

export function FeedView({
  query,
  variant,
  emptyTitle,
  emptyBody,
  meId,
}: {
  query: FeedQuery;
  variant: "feed" | "reel" | "subliminal";
  emptyTitle: string;
  emptyBody: string;
  meId: string;
}) {
  const tick = useSalon((s) => s.tick);
  const [posts, setPosts] = useState<PostView[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    listPosts({ data: query })
      .then((result) => {
        if (!live) return;
        if (!result.ok) setError(result.error);
        else {
          setError(null);
          setPosts(result.posts);
        }
      })
      .catch((err: unknown) => {
        if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
      });
    return () => {
      live = false;
    };
  }, [tick, query.surface, query.kind, query.scope, query.slug, query.username]);

  if (error) return <p className="rounded-3xl bg-paper px-4 py-6 text-sm text-rose shadow-card">{error}</p>;
  if (!posts) {
    return (
      <div className="space-y-3">
        <SkeletonCard />
        <SkeletonCard />
      </div>
    );
  }
  if (!posts.length) return <EmptyNote title={emptyTitle} body={emptyBody} />;
  return (
    <div className={variant === "reel" ? "space-y-4" : "space-y-3"}>
      {posts.map((post) => (
        <PostCard
          key={post.id}
          post={post}
          variant={variant}
          mine={post.userId === meId}
          onRemoved={(id) => setPosts((list) => list?.filter((item) => item.id !== id) ?? list)}
        />
      ))}
    </div>
  );
}
