import React from 'react';
import { Sparkles, Bomb, Flame, Play } from 'lucide-react';

interface TutorialModalProps {
  onStart: () => void;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({ onStart }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md px-5 py-4 select-none animate-in fade-in duration-200">
      <div className="flex w-full max-w-sm flex-col items-center rounded-3xl bg-slate-900 border border-slate-800 p-6 text-center shadow-2xl">
        {/* Badge */}
        <div className="mb-2 flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-black tracking-wide text-emerald-400 border border-emerald-500/30">
          <span>HOW TO PLAY (3 SECONDS)</span>
        </div>

        <h2 className="text-2xl font-black text-white">READY TO RUSH?</h2>

        {/* 3 Step Visual Cards */}
        <div className="my-4 flex flex-col gap-2.5 w-full text-left">
          {/* Step 1: Match Color */}
          <div className="flex items-center gap-3 rounded-2xl bg-slate-950/80 p-3 border border-slate-800">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.6)]">
              <span className="font-mono text-sm font-black text-white">1</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white">Match the Target</span>
              <span className="text-[11px] text-slate-400">
                Tap the button below that matches the color circle at top!
              </span>
            </div>
          </div>

          {/* Step 2: 10 Streak Fever */}
          <div className="flex items-center gap-3 rounded-2xl bg-slate-950/80 p-3 border border-slate-800">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.6)]">
              <Flame className="h-5 w-5 fill-white text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white">10 Streak = Fever Mode</span>
              <span className="text-[11px] text-slate-400">
                Get 10 in a row to ignite Fever Mode with 2x Score!
              </span>
            </div>
          </div>

          {/* Step 3: Danger Bomb & Golden Bonus */}
          <div className="flex items-center gap-3 rounded-2xl bg-slate-950/80 p-3 border border-slate-800">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-950 border border-rose-600 shadow-[0_0_15px_rgba(239,68,68,0.4)]">
              <Bomb className="h-5 w-5 text-rose-500" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white">Avoid Bombs!</span>
              <span className="text-[11px] text-slate-400">
                Never tap bombs! Tap Golden buttons for +5 points and coins.
              </span>
            </div>
          </div>
        </div>

        {/* Start Game Action */}
        <button
          onClick={onStart}
          className="flex h-13 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 font-black text-base text-white shadow-[0_8px_30px_rgba(16,185,129,0.4)] transition-all active:scale-95 hover:brightness-110"
        >
          <Play className="h-5 w-5 fill-white" />
          <span>START PLAYING</span>
        </button>
      </div>
    </div>
  );
};
