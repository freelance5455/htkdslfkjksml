import React, { useState, useRef, useEffect } from 'react';
import {
  Radio,
  Mic,
  Volume2,
  Users,
  Key,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Play,
  Square,
  RotateCcw,
  Share2,
  Copy,
  Sparkles,
  HelpCircle,
  X,
  Smartphone,
  Shield,
  Zap,
  Check
} from 'lucide-react';

interface TutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlockPro: (key: string) => boolean;
  isPro: boolean;
  channelId: string;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({
  isOpen,
  onClose,
  onUnlockPro,
  isPro,
  channelId
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [copied, setCopied] = useState(false);
  
  // Audio loopback test state
  const [isRecordingTest, setIsRecordingTest] = useState(false);
  const [isPlayingTest, setIsPlayingTest] = useState(false);
  const [testAudioUrl, setTestAudioUrl] = useState<string | null>(null);
  const [micLevel, setMicLevel] = useState(0);
  const [testError, setTestError] = useState<string | null>(null);

  // Key unlock inside tutorial
  const [keyInput, setKeyInput] = useState('');
  const [keySuccess, setKeySuccess] = useState(false);
  const [keyError, setKeyError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const testAudioElementRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
      if (testAudioUrl) URL.revokeObjectURL(testAudioUrl);
    };
  }, [testAudioUrl]);

  if (!isOpen) return null;

  // Copy app link
  const handleCopyLink = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }).catch(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  // Start Loopback Mic Test
  const startMicTest = async () => {
    setTestError(null);
    setTestAudioUrl(null);
    audioChunksRef.current = [];

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioCtx;
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;

      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const checkVolume = () => {
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        setMicLevel(Math.min(100, Math.round((avg / 128) * 100)));
        animFrameRef.current = requestAnimationFrame(checkVolume);
      };
      checkVolume();

      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
        setMicLevel(0);
        stream.getTracks().forEach(track => track.stop());

        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setTestAudioUrl(url);
        setIsRecordingTest(false);

        // Auto-play the test audio with simulated walkie-talkie reception
        setTimeout(() => {
          playRecordedAudio(url);
        }, 400);
      };

      recorder.start();
      setIsRecordingTest(true);

      // Record automatically for 4 seconds
      setTimeout(() => {
        if (recorder.state === 'recording') {
          recorder.stop();
        }
      }, 4000);

    } catch (err: any) {
      console.error('Error accessing mic for test:', err);
      setTestError('No se pudo acceder al micrófono. Verifica los permisos de tu navegador.');
      setIsRecordingTest(false);
    }
  };

  const playRecordedAudio = (urlToPlay?: string) => {
    const targetUrl = urlToPlay || testAudioUrl;
    if (!targetUrl) return;

    if (testAudioElementRef.current) {
      testAudioElementRef.current.pause();
    }

    const audio = new Audio(targetUrl);
    testAudioElementRef.current = audio;
    setIsPlayingTest(true);

    audio.onended = () => {
      setIsPlayingTest(false);
    };

    audio.onerror = () => {
      setIsPlayingTest(false);
      setTestError('Error al reproducir el audio de prueba.');
    };

    audio.play().catch(e => {
      console.error('Playback error:', e);
      setIsPlayingTest(false);
    });
  };

  const stopRecordedAudio = () => {
    if (testAudioElementRef.current) {
      testAudioElementRef.current.pause();
      setIsPlayingTest(false);
    }
  };

  const handleApplyKey = () => {
    if (keyInput.trim() === '369174') {
      const ok = onUnlockPro(keyInput.trim());
      if (ok) {
        setKeySuccess(true);
        setKeyError(null);
      }
    } else {
      setKeyError('Clave incorrecta. La clave autorizada es 369174');
      setKeySuccess(false);
    }
  };

  const steps = [
    {
      id: 'step-intro',
      title: '¡Bienvenido a SONÓ RADIO!',
      subtitle: 'Sistema de Walkie-Talkie Táctico en Tiempo Real',
      icon: Radio,
      badge: 'GUÍA RÁPIDA',
      color: '#9D00FF',
      content: (
        <div className="space-y-4 text-left">
          <p className="text-xs text-gray-300 leading-relaxed">
            SONÓ RADIO te permite comunicarte mediante <strong className="text-white">transmisión y recepción de voz real</strong> en canales de alta velocidad, con cifrado militar, inteligencia artificial Sonó Zero y herramientas tácticas.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="bg-black/60 border border-purple-900/50 p-3 rounded-xl">
              <Mic className="w-5 h-5 text-[#9D00FF] mb-1.5" />
              <h5 className="text-[11px] font-black text-white uppercase">Transmisión PTT</h5>
              <p className="text-[10px] text-gray-400 mt-1">Presiona para hablar, suelta para transmitir con tono táctico.</p>
            </div>
            <div className="bg-black/60 border border-pink-900/50 p-3 rounded-xl">
              <Volume2 className="w-5 h-5 text-[#FF0044] mb-1.5" />
              <h5 className="text-[11px] font-black text-white uppercase">Recepción en Vivo</h5>
              <p className="text-[10px] text-gray-400 mt-1">Tu altavoz reproduce la voz en tiempo real sin pulsar nada.</p>
            </div>
            <div className="bg-black/60 border border-emerald-900/50 p-3 rounded-xl">
              <Users className="w-5 h-5 text-[#00ff88] mb-1.5" />
              <h5 className="text-[11px] font-black text-white uppercase">Canales 1 - 16</h5>
              <p className="text-[10px] text-gray-400 mt-1">Sintoniza la misma frecuencia para hablar en grupo o privado.</p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'step-ptt',
      title: 'Cómo Transmitir (Emisión Real)',
      subtitle: 'Botón PTT (Push-To-Talk) y Teclas de Acceso Rápido',
      icon: Mic,
      badge: 'PASO 1',
      color: '#FF0044',
      content: (
        <div className="space-y-4 text-left">
          <div className="bg-black/60 border border-[#FF0044]/40 p-3.5 rounded-xl space-y-2.5">
            <div className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-[#FF0044] text-white flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5">1</span>
              <div>
                <p className="text-xs text-white font-bold">Mantén presionado el botón central PTT</p>
                <p className="text-[10px] text-gray-300 mt-0.5">En dispositivos móviles usa tu dedo; en computadora también puedes usar la <span className="bg-gray-800 text-[#00ff88] px-1.5 py-0.5 rounded font-mono font-bold">[Barra Espaciadora]</span>.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-[#FF0044] text-white flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5">2</span>
              <div>
                <p className="text-xs text-white font-bold">Habla claramente hacia el micrófono</p>
                <p className="text-[10px] text-gray-300 mt-0.5">El visualizador central mostrará ondas de audio reactivas en tiempo real mientras capturas tu voz.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-[#FF0044] text-white flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5">3</span>
              <div>
                <p className="text-xs text-white font-bold">Suelta el botón al terminar de hablar</p>
                <p className="text-[10px] text-gray-300 mt-0.5">Sonará el tono táctico <em>Roger Beep</em> y tu audio se emitirá de inmediato a todos los operadores sintonizados.</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'step-receive',
      title: 'Cómo Recibir (Escucha Real)',
      subtitle: 'Reproducción Automática y Monitoreo Activo',
      icon: Volume2,
      badge: 'PASO 2',
      color: '#00ff88',
      content: (
        <div className="space-y-4 text-left">
          <div className="bg-black/60 border border-[#00ff88]/40 p-3.5 rounded-xl space-y-2.5">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#00ff88] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-white font-bold">Reproducción 100% Automática</p>
                <p className="text-[10px] text-gray-300 mt-0.5">No necesitas presionar nada para escuchar. Cuando alguien transmita en tu canal, su voz saldrá por tu altavoz o auriculares.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#00ff88] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-white font-bold">Identificación del Operador</p>
                <p className="text-[10px] text-gray-300 mt-0.5">La pantalla resalta el indicativo del usuario que está transmitiendo: <em>"Escuchando a [Usuario]"</em> con transcripción en vivo si está habilitada.</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#00ff88] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-white font-bold">Segundo Plano y Pantalla Bloqueada</p>
                <p className="text-[10px] text-gray-300 mt-0.5">Gracias al motor de audio en segundo plano, la radio sigue activa mientras navegas en otras aplicaciones.</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'step-test',
      title: 'Prueba de Micrófono y Altavoz (Eco Test)',
      subtitle: 'Comprueba tu transmisión y recepción ahora mismo',
      icon: Sparkles,
      badge: 'HERRAMIENTA EN VIVO',
      color: '#00e5ff',
      content: (
        <div className="space-y-4 text-left">
          <p className="text-xs text-gray-300 leading-relaxed">
            Graba 4 segundos de tu voz. El sistema la procesará y la reproducirá al instante por tu altavoz como si fuera una transmisión de radio recibida:
          </p>

          <div className="bg-black/80 border-2 border-[#00e5ff]/50 rounded-2xl p-4 text-center space-y-3 shadow-[0_0_25px_rgba(0,229,255,0.15)]">
            {/* Vu-meter */}
            <div className="w-full bg-gray-950 h-3 rounded-full overflow-hidden border border-gray-800 p-0.5">
              <div
                className="h-full bg-gradient-to-r from-[#00ff88] via-[#ffd600] to-[#FF0044] rounded-full transition-all duration-75"
                style={{ width: `${isRecordingTest ? micLevel : isPlayingTest ? 80 : 0}%` }}
              />
            </div>

            <div className="flex items-center justify-center gap-3">
              {!isRecordingTest ? (
                <button
                  onClick={startMicTest}
                  disabled={isPlayingTest}
                  className="bg-[#00e5ff] hover:bg-[#00e5ff]/80 text-black font-black text-xs px-4 py-2.5 rounded-xl uppercase tracking-wider transition shadow-[0_0_15px_rgba(0,229,255,0.4)] flex items-center gap-2"
                >
                  <Mic className="w-4 h-4" /> Grabar Prueba (4s)
                </button>
              ) : (
                <div className="flex items-center gap-2 text-[#FF0044] font-black text-xs animate-pulse font-mono uppercase tracking-widest bg-red-950/60 border border-red-500/40 px-4 py-2.5 rounded-xl">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                  Grabando tu voz... Habla ahora
                </div>
              )}

              {testAudioUrl && !isRecordingTest && (
                <button
                  onClick={isPlayingTest ? stopRecordedAudio : () => playRecordedAudio()}
                  className="bg-[#00ff88] hover:bg-[#00ff88]/80 text-black font-black text-xs px-4 py-2.5 rounded-xl uppercase tracking-wider transition shadow-[0_0_15px_rgba(0,255,136,0.4)] flex items-center gap-2"
                >
                  {isPlayingTest ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {isPlayingTest ? 'Detener' : 'Repetir Audio'}
                </button>
              )}
            </div>

            {testError && (
              <p className="text-[11px] text-red-400 font-bold bg-red-950/40 border border-red-900/50 p-2 rounded-lg">
                ⚠️ {testError}
              </p>
            )}

            {testAudioUrl && !isPlayingTest && (
              <p className="text-[11px] text-[#00ff88] font-bold flex items-center justify-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> ¡Prueba exitosa! Tu micrófono y altavoz están 100% operativos.
              </p>
            )}
          </div>
        </div>
      )
    },
    {
      id: 'step-two-devices',
      title: 'Prueba Real con 2 Dispositivos / Pestañas',
      subtitle: 'Comprueba la transmisión en vivo con otra persona o teléfono',
      icon: Smartphone,
      badge: 'PASO 3',
      color: '#ffd600',
      content: (
        <div className="space-y-4 text-left">
          <p className="text-xs text-gray-300 leading-relaxed">
            Sigue estos 3 pasos sencillos para verificar la transmisión en vivo entre 2 equipos:
          </p>

          <div className="space-y-2">
            <div className="bg-black/60 border border-gray-800 p-3 rounded-xl flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-amber-500 text-black font-black flex items-center justify-center text-[10px] shrink-0">1</span>
              <div className="flex-1">
                <p className="text-xs text-white font-bold">Abre el enlace en otro dispositivo o pestaña de incógnito</p>
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={handleCopyLink}
                    className="bg-gray-800 hover:bg-gray-700 text-white font-bold text-[11px] px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition border border-gray-700"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-[#00ff88]" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? '¡Enlace Copiado!' : 'Copiar Enlace'}
                  </button>
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent('Únete a mi canal en SONÓ RADIO: ' + window.location.href)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-[11px] px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition"
                  >
                    <Share2 className="w-3.5 h-3.5" /> Enviar por WhatsApp
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-black/60 border border-gray-800 p-3 rounded-xl flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-amber-500 text-black font-black flex items-center justify-center text-[10px] shrink-0">2</span>
              <div>
                <p className="text-xs text-white font-bold">Sintoniza el mismo canal en ambos (Ej: Canal {channelId})</p>
                <p className="text-[10px] text-gray-400 mt-0.5">En el selector superior verifica que ambos estén en el mismo canal o frecuencia.</p>
              </div>
            </div>

            <div className="bg-black/60 border border-gray-800 p-3 rounded-xl flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-amber-500 text-black font-black flex items-center justify-center text-[10px] shrink-0">3</span>
              <div>
                <p className="text-xs text-white font-bold">Presiona PTT en el Dispositivo A y habla</p>
                <p className="text-[10px] text-gray-400 mt-0.5">Al soltar, el Dispositivo B emitirá tu voz real de forma instantánea.</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'step-pro-key',
      title: 'Desbloqueo de Suscripción PRO',
      subtitle: 'Clave de Activación Oficial: 369174',
      icon: Key,
      badge: 'CLAVE DE PAGO',
      color: '#00ff88',
      content: (
        <div className="space-y-4 text-left">
          <p className="text-xs text-gray-300 leading-relaxed">
            Para desbloquear todas las funciones de pago (Modo Táctico, Sonó Zero avanzado, llamadas privadas cifradas y módulos Enterprise), se requiere la clave oficial de activación.
          </p>

          <div className="bg-[#110022] border-2 border-[#00ff88]/70 rounded-2xl p-4 shadow-[0_0_25px_rgba(0,255,136,0.2)] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black text-[#00ff88] uppercase tracking-wider flex items-center gap-1.5">
                <Key className="w-4 h-4 text-[#00ff88]" /> Clave Autorizada:
              </span>
              <span className="font-mono text-sm bg-[#00ff88]/20 text-[#00ff88] px-3 py-0.5 rounded-lg border border-[#00ff88]/50 font-black tracking-widest">
                369174
              </span>
            </div>

            {isPro || keySuccess ? (
              <div className="bg-[#00ff88]/15 border border-[#00ff88] rounded-xl p-3 flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#00ff88] shrink-0" />
                <div>
                  <p className="text-xs font-black text-[#00ff88] uppercase tracking-wider">¡Funciones PRO Desbloqueadas!</p>
                  <p className="text-[10px] text-gray-300">Tienes acceso ilimitado a todas las herramientas avanzadas.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-[10px] text-gray-300">
                  Introduce la clave <strong className="text-[#00ff88]">369174</strong> para desbloquearlo en este momento:
                </p>
                <div className="flex gap-2">
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={10}
                    value={keyInput}
                    onChange={(e) => {
                      setKeyInput(e.target.value);
                      setKeyError(null);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleApplyKey();
                    }}
                    placeholder="Ingresa 369174..."
                    className="bg-black/90 border border-gray-700 focus:border-[#00ff88] text-white text-xs font-mono tracking-widest px-3 py-2.5 rounded-xl flex-1 outline-none text-center"
                  />
                  <button
                    onClick={handleApplyKey}
                    className="bg-[#00ff88] hover:bg-[#00ff88]/80 text-black font-black text-xs px-4 py-2.5 rounded-xl uppercase tracking-wider transition shadow-[0_0_15px_rgba(0,255,136,0.3)] whitespace-nowrap"
                  >
                    Activar
                  </button>
                </div>
                {keyError && (
                  <p className="text-[10px] text-red-400 font-bold">⚠️ {keyError}</p>
                )}
              </div>
            )}
          </div>
        </div>
      )
    }
  ];

  const currentStepData = steps[currentStep];
  const StepIcon = currentStepData.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-[#0d0d12] border-2 border-[#9D00FF]/50 rounded-3xl p-6 text-white shadow-[0_0_50px_rgba(157,0,255,0.3)] flex flex-col max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with Step Indicator */}
        <div className="flex items-center gap-3 mb-4 pr-8">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center border shrink-0"
            style={{
              backgroundColor: `${currentStepData.color}20`,
              borderColor: currentStepData.color
            }}
          >
            <StepIcon className="w-6 h-6" style={{ color: currentStepData.color }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span
                className="text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full border"
                style={{
                  backgroundColor: `${currentStepData.color}25`,
                  borderColor: currentStepData.color,
                  color: currentStepData.color
                }}
              >
                {currentStepData.badge}
              </span>
              <span className="text-[10px] text-gray-400 font-mono">
                {currentStep + 1} de {steps.length}
              </span>
            </div>
            <h3 className="text-base font-black uppercase tracking-wider text-white mt-1">
              {currentStepData.title}
            </h3>
            <p className="text-[11px] text-gray-400 font-medium">
              {currentStepData.subtitle}
            </p>
          </div>
        </div>

        {/* Step Progress Dots */}
        <div className="flex items-center gap-1.5 mb-4">
          {steps.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === currentStep
                  ? 'w-8 bg-[#00ff88]'
                  : idx < currentStep
                  ? 'w-3 bg-purple-500'
                  : 'w-2 bg-gray-800'
              }`}
            />
          ))}
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto pr-1 my-1">
          {currentStepData.content}
        </div>

        {/* Navigation Footer */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t border-gray-800/80 mt-2">
          {currentStep > 0 ? (
            <button
              onClick={() => setCurrentStep(prev => prev - 1)}
              className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white font-bold px-3 py-2 rounded-xl transition"
            >
              <ArrowLeft className="w-4 h-4" /> Anterior
            </button>
          ) : (
            <button
              onClick={onClose}
              className="text-xs text-gray-500 hover:text-gray-300 font-semibold px-3 py-2 transition"
            >
              Saltar Tutorial
            </button>
          )}

          {currentStep < steps.length - 1 ? (
            <button
              onClick={() => setCurrentStep(prev => prev + 1)}
              className="flex items-center gap-2 bg-[#9D00FF] hover:bg-[#9D00FF]/80 text-white font-black text-xs px-5 py-2.5 rounded-xl uppercase tracking-wider transition shadow-[0_0_15px_rgba(157,0,255,0.4)]"
            >
              Siguiente <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="flex items-center gap-2 bg-[#00ff88] hover:bg-[#00ff88]/80 text-black font-black text-xs px-6 py-2.5 rounded-xl uppercase tracking-wider transition shadow-[0_0_20px_rgba(0,255,136,0.4)]"
            >
              ¡Entendido, Iniciar Radio! <CheckCircle2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
