import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Zap, Dumbbell, Briefcase, Heart, Baby, Users, ShieldAlert, GraduationCap } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface TutorialModalProps {
  onClose: () => void;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({ onClose }) => {
  const [step, setStep] = useState(0);

  const steps = [
    {
      title: '🌟 مرحباً بك في لعبة الحياة!',
      icon: <Zap className="w-8 h-8 text-amber-400" />,
      content: (
        <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <p>أنت تبدأ حياتك في القاهرة برصيد أولي متواضع (350 ج.م). كل قرار تتخذه يؤثر مباشرة على صحتك، طاقتك، أموالك، وعلاقاتك.</p>
          <p className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200">
            💡 <b>سر النجاح:</b> وازن بين العمل الحلال، الراحة والنوم، والاهتمام بشريكة حياتك وأسرتك.
          </p>
        </div>
      )
    },
    {
      title: '🏋️ نظام الجيم وزيادة سعة الطاقة',
      icon: <Dumbbell className="w-8 h-8 text-cyan-400" />,
      content: (
        <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <p>
            طاقتك الأولية هي <b>100 نقطة</b>. عندما تتمرن في الجيم، تكتسب خبرة لياقة بدنية (Fitness XP).
          </p>
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-200 space-y-1">
            <p>⚡ <b>زيادة البار:</b> مع كل مستوى لياقة جديد (Level Up)، يزيد الحد الأقصى للبار تلقائياً (+10 لكل مستوى)!</p>
            <p>📈 متطلبات الخبرة تصبح أكثر تدرجاً وصعوبة مع الصعود في المستويات، مما يعطيك شعوراً حقيقياً بالتطور.</p>
          </div>
        </div>
      )
    },
    {
      title: '💼 العمل والكورسات وتأثير المزاج',
      icon: <Briefcase className="w-8 h-8 text-emerald-400" />,
      content: (
        <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <p>
            الوظائف تتطلب مهارة ومعدات. لا يمكنك جني الملايين في دقائق؛ المصاريف اليومية والإيجار تتطلب خطة مالية واعية.
          </p>
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 space-y-1">
            <p>🧠 <b>المزاج يؤثر في الشغل:</b> المزاج العالي يعطيك علاوة <b>+20%</b> في الإنتاجية والراتب! أما الاكتئاب والإجهاد فيخصم حتى <b>-35%</b>.</p>
            <p>🎓 <b>الكورسات التعليمية:</b> لها مدة زمنية بالأيام (3-10 أيام)، حضورك المحاضرات يرفع مهاراتك ويفتح لك وظائف عالية الدخل.</p>
          </div>
        </div>
      )
    },
    {
      title: '❤️ الحب، مؤقت الحمل، وأسماء المواليد',
      icon: <Baby className="w-8 h-8 text-rose-400" />,
      content: (
        <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <p>
            علاقتك بشريكتك تبدأ بالتعارف وتتطور عبر الهدايا، العشاء على النيل، ونزهات الغروب، حتى الخطوبة والزواج المستقر.
          </p>
          <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-200 space-y-1">
            <p>🤰 <b>مؤقت الحمل المرئي:</b> عند بدء الحمل، يظهر شريط عد تنازلي يوضح الأيام المتبقية حتى الولادة.</p>
            <p>🩺 <b>السونار:</b> يمكنك زيارة الطبيب وإجراء سونار لمعرفة نوع الجنين (ولد أم بنت) والاطمئنان عليه.</p>
            <p>✍️ <b>حرية التسمية:</b> عند الولادة، لديك حرية مطلقة لكتابة واختيار اسم الولد أو البنت بنفسك!</p>
          </div>
        </div>
      )
    },
    {
      title: '🎒 تعليم الأولاد، الدرجات، والعقاب',
      icon: <GraduationCap className="w-8 h-8 text-purple-400" />,
      content: (
        <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <p>
            يمر الأطفال بمراحل دراسية: الحضانة، الابتدائية، الإعدادية، الثانوية، والجامعة.
          </p>
          <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-200 space-y-1">
            <p>📊 <b>شهادة الدرجات:</b> افحص درجات أولادك في الامتحانات لتعرف تقديرهم (A / B / C / D / F).</p>
            <p>⚖️ <b>التربية والعقاب:</b> يمكنك التوجيه بالنصيحة، أو سحب الألعاب والموبايل عند التقصير لرفع الانضباط، أو مكافأتهم بهدايا عند التفوق.</p>
          </div>
        </div>
      )
    },
    {
      title: '👥 شبكة الأصدقاء وعالم الجريمة',
      icon: <Users className="w-8 h-8 text-amber-400" />,
      content: (
        <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <p>
            لديك أصدقاء متميزون (رامي، حسام، د. محمود، كابتن طارق). كل صديق يقدم لك ميزة وسنداً وقت الحاجة وسلفة مالية.
          </p>
          <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-200 space-y-1">
            <p>🕶️ <b>عالم الظلام والجريمة:</b> يمكنك الدخول فيه للمخاطرة، لكن الشرطة والمفتش كريم يراقبونك، والريس سعد يطالب بالولاء، وإذا كُشفت أسرارك ستفقد ثقة زوجتك!</p>
          </div>
        </div>
      )
    }
  ];

  const handleNext = () => {
    playClickSound();
    if (step < steps.length - 1) setStep(step + 1);
    else onClose();
  };

  const handlePrev = () => {
    playClickSound();
    if (step > 0) setStep(step - 1);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-amber-400 border border-slate-700 font-bold">
              خطوة {step + 1} من {steps.length}
            </span>
            <span className="text-xs text-slate-400 font-medium">دليل اللعبة التفاعلي</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60 shadow-inner">
              {steps[step].icon}
            </div>
            <h3 className="text-lg font-bold text-slate-100">{steps[step].title}</h3>
          </div>
          {steps[step].content}
        </div>

        {/* Progress dots */}
        <div className="flex justify-center gap-1.5 py-2">
          {steps.map((_, i) => (
            <button
              key={i}
              onClick={() => { playClickSound(); setStep(i); }}
              className={`h-2 rounded-full transition-all ${
                i === step ? 'w-6 bg-amber-400' : 'w-2 bg-slate-800 hover:bg-slate-700'
              }`}
            />
          ))}
        </div>

        <div className="flex items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={handlePrev}
            disabled={step === 0}
            className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center gap-1 transition ${
              step === 0
                ? 'opacity-40 cursor-not-allowed border-slate-800 text-slate-500'
                : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
            }`}
          >
            <ChevronRight className="w-4 h-4" />
            <span>السابق</span>
          </button>

          <button
            type="button"
            onClick={handleNext}
            className="py-2.5 px-5 rounded-xl bg-amber-400 text-slate-950 font-black text-xs hover:bg-amber-300 flex items-center gap-1.5 shadow-md shadow-amber-400/20 transition active:scale-95"
          >
            <span>{step === steps.length - 1 ? 'فهمت، لنبدأ! 🚀' : 'التالي'}</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
