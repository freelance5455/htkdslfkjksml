import React, { useState } from 'react';
import { X, Play, Link2, AlertCircle, CheckCircle, Sparkles } from 'lucide-react';
import { SportsChannel } from '../types';

interface CustomStreamModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLaunchCustomStream: (channel: SportsChannel) => void;
}

export const CustomStreamModal: React.FC<CustomStreamModalProps> = ({
  isOpen,
  onClose,
  onLaunchCustomStream,
}) => {
  const [streamName, setStreamName] = useState('');
  const [streamUrl, setStreamUrl] = useState('');
  const [quality, setQuality] = useState<'4K' | 'FHD' | 'HD'>('FHD');

  if (!isOpen) return null;

  const sampleStreams = [
    {
      name: 'بث تجريبي HLS مفتوح (Akamai)',
      url: 'https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8',
    },
    {
      name: 'بث تجريبي MP4 بجودة FHD',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    },
    {
      name: 'بث تجريبي رياضي فائق السرعة',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!streamUrl.trim()) return;

    const customChannel: SportsChannel = {
      id: `custom-${Date.now()}`,
      name: streamName.trim() || 'بث مباشر خاص',
      category: 'Open',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/d/d3/Soccerball.svg',
      quality,
      currentShow: 'بث مباشر مخصص عبر مشغل IRAQI LIVE',
      viewers: '1',
      videoUrl: streamUrl.trim(),
      servers: [
        {
          id: 'cust-1',
          name: 'السيرفر المخصص المباشر',
          quality: `${quality} Live`,
          url: streamUrl.trim(),
        },
      ],
    };

    onLaunchCustomStream(customChannel);
    onClose();
  };

  return (
    <div
      id="custom-stream-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="relative w-full max-w-lg bg-[#101625] border border-slate-700/80 rounded-3xl p-6 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-rose-600/20 border border-rose-500/40 flex items-center justify-center">
              <Link2 className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base font-['Changa']">
                تشغيل رابط بث مباشر مخصص (M3U8 / MP4)
              </h3>
              <p className="text-xs text-slate-400">
                يدعم روابط IPTV المباشرة وملفات HLS بدون أي تطبيق إضافي
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              اسم القناة أو البث (اختياري):
            </label>
            <input
              type="text"
              placeholder="مثال: beIN Sports 1 الخاص بي..."
              value={streamName}
              onChange={(e) => setStreamName(e.target.value)}
              className="w-full bg-[#161e31] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              رابط البث المباشر (Stream URL):
            </label>
            <input
              type="url"
              required
              placeholder="https://example.com/live/stream.m3u8 أو .mp4"
              value={streamUrl}
              onChange={(e) => setStreamUrl(e.target.value)}
              className="w-full bg-[#161e31] border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              الجودة المتوقعة:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['4K', 'FHD', 'HD'] as const).map((q) => (
                <button
                  type="button"
                  key={q}
                  onClick={() => setQuality(q)}
                  className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                    quality === q
                      ? 'bg-rose-600 text-white border-rose-500 shadow-md'
                      : 'bg-[#161e31] text-slate-300 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Preset Samples */}
          <div className="pt-2">
            <span className="text-[11px] font-bold text-slate-400 block mb-2">
              روابط تجريبية جاهزة للاختبار الفوري:
            </span>
            <div className="space-y-1.5">
              {sampleStreams.map((sample, i) => (
                <button
                  type="button"
                  key={i}
                  onClick={() => {
                    setStreamName(sample.name);
                    setStreamUrl(sample.url);
                  }}
                  className="w-full text-right p-2 rounded-xl bg-[#161e31] hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 flex items-center justify-between transition-colors"
                >
                  <span className="font-semibold truncate">{sample.name}</span>
                  <span className="text-[10px] text-rose-400 font-bold shrink-0">اختيار</span>
                </button>
              ))}
            </div>
          </div>

          {/* Submit */}
          <div className="pt-3 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center gap-1.5 shadow-lg shadow-rose-600/30 transition-all"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>تشغيل البث الآن</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
