"use client";

import React, { useState } from "react";
import {
  CoinTechnicalAnalysis,
  formatPriceNumber,
} from "@/services/technicalEngine";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  XCircle,
  RotateCcw,
  Clock,
  CheckCircle2,
  ShieldAlert,
} from "lucide-react";

export interface PaperPositionItem {
  id: number;
  symbol: string;
  side: "LONG" | "SHORT";
  entryPrice: number;
  exitPrice?: number | null;
  sizeUsdt: number;
  notionalUsdt: number;
  quantity: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
  liquidationPrice: number;
  status: string;
  realizedPnlUsdt: number;
  closeReason?: string | null;
  copiedFromTrader?: string | null;
  openedAt: string;
}

export interface PaperLimitOrderItem {
  id: number;
  symbol: string;
  side: "LONG" | "SHORT";
  limitPrice: number;
  sizeUsdt: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
  status: string;
  createdAt: string;
}

interface PaperTradingModuleProps {
  virtualBalanceUsdt: number;
  realizedPnlUsdt: number;
  coins: CoinTechnicalAnalysis[];
  openPositions: PaperPositionItem[];
  closedPositions: PaperPositionItem[];
  limitOrders: PaperLimitOrderItem[];
  onOpenMarketPosition: (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    entryPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
  }) => Promise<void>;
  onPlaceLimitOrder: (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    limitPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
  }) => Promise<void>;
  onCancelLimitOrder: (orderId: number) => Promise<void>;
  onClosePosition: (positionId: number, exitPrice: number) => Promise<void>;
  onResetAccount: () => Promise<void>;
}

export function PaperTradingModule({
  virtualBalanceUsdt,
  realizedPnlUsdt,
  coins,
  openPositions,
  closedPositions,
  limitOrders,
  onOpenMarketPosition,
  onPlaceLimitOrder,
  onCancelLimitOrder,
  onClosePosition,
  onResetAccount,
}: PaperTradingModuleProps) {
  const safeCoins = Array.isArray(coins) ? coins : [];
  const safeOpen = Array.isArray(openPositions) ? openPositions : [];
  const safeClosed = Array.isArray(closedPositions) ? closedPositions : [];
  const safeLimitOrders = Array.isArray(limitOrders)
    ? limitOrders.filter((o) => o.status === "PENDING")
    : [];

  const [selectedSymbol, setSelectedSymbol] = useState<string>("BTCUSDT");
  const [orderType, setOrderType] = useState<"MARKET" | "LIMIT">("MARKET");
  const [side, setSide] = useState<"LONG" | "SHORT">("LONG");
  const [marginUsdt, setMarginUsdt] = useState<number>(500);
  const [leverage, setLeverage] = useState<number>(4);
  const [customLimitPrice, setCustomLimitPrice] = useState<string>("");
  const [submitting, setSubmitting] = useState<boolean>(false);

  const selectedCoin =
    safeCoins.find((c) => c.symbol === selectedSymbol) || safeCoins[0];
  const livePrice = selectedCoin?.currentPrice || 94280;

  // Live price map for Unrealized P&L calculation
  const priceMap: Record<string, number> = {};
  for (const c of safeCoins) {
    priceMap[c.symbol] = c.currentPrice;
  }

  const totalMarginInPositions = safeOpen.reduce(
    (acc, p) => acc + (p.sizeUsdt || 0),
    0
  );

  const totalUnrealizedPnl = safeOpen.reduce((acc, p) => {
    const mark = priceMap[p.symbol] || p.entryPrice;
    const diff =
      p.side === "LONG" ? mark - p.entryPrice : p.entryPrice - mark;
    return acc + diff * p.quantity;
  }, 0);

  const totalEquityUsdt =
    virtualBalanceUsdt + totalMarginInPositions + totalUnrealizedPnl;

  const effectiveEntryPrice =
    orderType === "LIMIT" && Number(customLimitPrice) > 0
      ? Number(customLimitPrice)
      : livePrice;

  const previewNotional = marginUsdt * leverage;
  const previewLiqPrice =
    side === "LONG"
      ? effectiveEntryPrice * (1 - 0.92 / leverage)
      : effectiveEntryPrice * (1 + 0.92 / leverage);
  const previewSl =
    side === "LONG"
      ? effectiveEntryPrice * 0.975
      : effectiveEntryPrice * 1.025;
  const previewTp =
    side === "LONG"
      ? effectiveEntryPrice * 1.048
      : effectiveEntryPrice * 0.952;

  return (
    <div dir="rtl" className="space-y-6">
      {/* Top Virtual Portfolio Equity Strip */}
      <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#00E676]/15 text-[#00E676]">
              <Wallet className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#F1F5F9]">
                סימולטור מסחר דמו חי ($10,000 USDT Virtual Terminal)
              </h2>
              <p className="text-xs text-[#94A3B8]">
                ביצוע פקודות שוק (Market) ולימיט (Limit) על מחירי Bybit/Binance בזמן
                אמת עם חישוב בטחונות ומחיר הנזלה.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onResetAccount}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#181F2C] px-3.5 py-2 text-xs font-semibold text-[#94A3B8] transition hover:border-[#3B82F6] hover:text-white"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>אפס תיק דמו ל-$10,000</span>
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">שווי תיק כולל (Equity)</span>
            <div className="mt-1 font-mono text-2xl font-extrabold text-[#F1F5F9]">
              ${totalEquityUsdt.toFixed(2)}
            </div>
            <span className="text-[11px] text-[#64748B]">
              הון התחלתי: $10,000.00 USDT
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">יתרה זמינה למסחר (Free Cash)</span>
            <div className="mt-1 font-mono text-2xl font-extrabold text-[#3B82F6]">
              ${virtualBalanceUsdt.toFixed(2)}
            </div>
            <span className="text-[11px] text-[#64748B]">
              בטחונות בפוזיציות: ${totalMarginInPositions.toFixed(2)}
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">
              רווח/הפסד צף (Unrealized P&amp;L)
            </span>
            <div
              className={`mt-1 font-mono text-2xl font-extrabold ${
                totalUnrealizedPnl >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
              }`}
            >
              {totalUnrealizedPnl >= 0 ? "+" : ""}${totalUnrealizedPnl.toFixed(2)}
            </div>
            <span className="text-[11px] text-[#64748B]">
              מתעדכן בכל טיק מ-WebSocket
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">
              רווח ממומש מצטבר (Realized P&amp;L)
            </span>
            <div
              className={`mt-1 font-mono text-2xl font-extrabold ${
                realizedPnlUsdt >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
              }`}
            >
              {realizedPnlUsdt >= 0 ? "+" : ""}${realizedPnlUsdt.toFixed(2)}
            </div>
            <span className="text-[11px] text-[#64748B]">
              מסונכרן ליומן מס ישראלי
            </span>
          </div>
        </div>
      </div>

      {/* Main Split: Order Execution Ticket (4 cols) + Active Positions & Limit Orders (8 cols) */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Order Ticket Panel */}
        <div className="lg:col-span-4 rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
          <h3 className="mb-3 text-base font-bold text-[#F1F5F9]">
            שיגור פקודת מסחר חדשה (דמו)
          </h3>

          {/* Market vs Limit Toggle */}
          <div className="mb-4 grid grid-cols-2 gap-2 rounded-lg bg-[#0B0E14] p-1">
            <button
              type="button"
              onClick={() => setOrderType("MARKET")}
              className={`rounded-md py-2 text-xs font-bold transition ${
                orderType === "MARKET"
                  ? "bg-[#3B82F6] text-white"
                  : "text-[#94A3B8] hover:text-white"
              }`}
            >
              פקודת שוק (Market)
            </button>
            <button
              type="button"
              onClick={() => {
                setOrderType("LIMIT");
                if (!customLimitPrice) {
                  setCustomLimitPrice(
                    String(Number((livePrice * 0.992).toPrecision(6)))
                  );
                }
              }}
              className={`rounded-md py-2 text-xs font-bold transition ${
                orderType === "LIMIT"
                  ? "bg-[#3B82F6] text-white"
                  : "text-[#94A3B8] hover:text-white"
              }`}
            >
              פקודת לימיט (Limit)
            </button>
          </div>

          <div className="space-y-3.5">
            {/* Symbol Selector */}
            <div>
              <label className="mb-1 block text-xs text-[#94A3B8]">
                בחר צמד מסחר (Linear USDT):
              </label>
              <select
                value={selectedSymbol}
                onChange={(e) => {
                  setSelectedSymbol(e.target.value);
                  setCustomLimitPrice("");
                }}
                className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
              >
                {safeCoins.map((c) => (
                  <option key={c.symbol} value={c.symbol}>
                    {c.symbol} — ${formatPriceNumber(c.currentPrice)} (
                    {c.change24hPct >= 0 ? "+" : ""}
                    {c.change24hPct}%)
                  </option>
                ))}
              </select>
            </div>

            {/* Direction Toggle */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSide("LONG")}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2.5 text-xs font-extrabold transition ${
                  side === "LONG"
                    ? "bg-[#00E676] text-[#0B0E14]"
                    : "border border-[#222B3A] bg-[#0B0E14] text-[#94A3B8]"
                }`}
              >
                <TrendingUp className="h-4 w-4" />
                לונג / קנייה (LONG)
              </button>
              <button
                type="button"
                onClick={() => setSide("SHORT")}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2.5 text-xs font-extrabold transition ${
                  side === "SHORT"
                    ? "bg-[#FF3B69] text-white"
                    : "border border-[#222B3A] bg-[#0B0E14] text-[#94A3B8]"
                }`}
              >
                <TrendingDown className="h-4 w-4" />
                שורט / מכירה (SHORT)
              </button>
            </div>

            {/* Limit Price Input if LIMIT selected */}
            {orderType === "LIMIT" && (
              <div>
                <label className="mb-1 block text-xs text-[#94A3B8]">
                  מחיר יעד לביצוע לימיט ($ USDT):
                </label>
                <input
                  type="number"
                  step="any"
                  value={customLimitPrice}
                  onChange={(e) => setCustomLimitPrice(e.target.value)}
                  className="w-full rounded-lg border border-[#3B82F6] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:outline-none"
                />
              </div>
            )}

            {/* Margin Size Input */}
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-[#94A3B8]">סכום בטחונות ($ USDT):</span>
                <span className="font-mono text-[#3B82F6]">
                  זמין: ${virtualBalanceUsdt.toFixed(0)}
                </span>
              </div>
              <input
                type="number"
                min={25}
                max={Math.max(50, virtualBalanceUsdt)}
                step={25}
                value={marginUsdt}
                onChange={(e) => setMarginUsdt(Number(e.target.value))}
                className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
              />
              <div className="mt-1.5 flex gap-1.5">
                {[10, 25, 50, 75].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() =>
                      setMarginUsdt(
                        Math.max(25, Math.floor((virtualBalanceUsdt * pct) / 100))
                      )
                    }
                    className="flex-1 rounded bg-[#181F2C] py-1 font-mono text-[11px] text-[#94A3B8] hover:bg-[#3B82F6] hover:text-white"
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            {/* Leverage Slider (1x - 20x) */}
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-[#94A3B8]">מינוף חוזה (Leverage):</span>
                <span className="font-mono font-bold text-[#F59E0B]">
                  {leverage}x
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={20}
                value={leverage}
                onChange={(e) => setLeverage(Number(e.target.value))}
                className="w-full accent-[#3B82F6]"
              />
              <div className="flex justify-between font-mono text-[10px] text-[#64748B]">
                <span>1x</span>
                <span>3x (מומלץ)</span>
                <span>5x</span>
                <span>10x</span>
                <span>20x</span>
              </div>
            </div>

            {/* Order Summary Preview */}
            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">שווי חשיפה כולל (Notional):</span>
                <span className="font-mono font-bold text-[#F1F5F9]">
                  ${previewNotional.toLocaleString()} USDT
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">מחיר כניסה משוער:</span>
                <span className="font-mono text-[#F1F5F9]">
                  ${formatPriceNumber(effectiveEntryPrice)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">מחיר הנזלה (Liquidation):</span>
                <span className="font-mono font-bold text-[#F59E0B]">
                  ${formatPriceNumber(previewLiqPrice)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">הגנות אוטומטיות (TP / SL):</span>
                <span className="font-mono text-[11px]">
                  <span className="text-[#00E676]">
                    ${formatPriceNumber(previewTp)}
                  </span>{" "}
                  /{" "}
                  <span className="text-[#FF3B69]">
                    ${formatPriceNumber(previewSl)}
                  </span>
                </span>
              </div>
            </div>

            <button
              type="button"
              disabled={submitting}
              onClick={async () => {
                setSubmitting(true);
                if (orderType === "MARKET") {
                  await onOpenMarketPosition({
                    symbol: selectedSymbol,
                    side,
                    entryPrice: livePrice,
                    sizeUsdt: marginUsdt,
                    leverage,
                    stopLoss: Number(previewSl.toPrecision(6)),
                    takeProfit: Number(previewTp.toPrecision(6)),
                  });
                } else {
                  await onPlaceLimitOrder({
                    symbol: selectedSymbol,
                    side,
                    limitPrice: effectiveEntryPrice,
                    sizeUsdt: marginUsdt,
                    leverage,
                    stopLoss: Number(previewSl.toPrecision(6)),
                    takeProfit: Number(previewTp.toPrecision(6)),
                  });
                }
                setSubmitting(false);
              }}
              className={`w-full rounded-lg py-3 text-sm font-extrabold transition ${
                side === "LONG"
                  ? "bg-[#00E676] text-[#0B0E14] hover:brightness-110"
                  : "bg-[#FF3B69] text-white hover:brightness-110"
              }`}
            >
              {orderType === "MARKET"
                ? `בצע עסקת ${side === "LONG" ? "לונג (LONG)" : "שורט (SHORT)"} מיידית`
                : `שגר פקודת לימיט (${side}) במחיר $${formatPriceNumber(
                    effectiveEntryPrice
                  )}`}
            </button>
          </div>
        </div>

        {/* Right Panel: Active Open Positions + Limit Orders + Closed History (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {/* Open Positions Card */}
          <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
            <div className="mb-3 flex items-center justify-between border-b border-[#222B3A] pb-3">
              <h3 className="text-base font-bold text-[#F1F5F9]">
                פוזיציות דמו פתוחות בזמן אמת ({safeOpen.length})
              </h3>
              <span className="text-xs text-[#94A3B8]">
                SL/TP אוטומטי מופעל מול זרם המחירים
              </span>
            </div>

            {safeOpen.length === 0 ? (
              <div className="rounded-lg bg-[#0B0E14] p-6 text-center text-sm text-[#94A3B8]">
                אין פוזיציות פתוחות כרגע. השתמש בטופס משמאל או בכפתור &quot;בצע
                בעסקת דמו&quot; מתוך כרטיסי האיתותים.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="border-b border-[#222B3A] text-[#64748B]">
                      <th className="py-2 pr-2">נכס / כיוון</th>
                      <th className="py-2">כניסה / שוק חי</th>
                      <th className="py-2">בטחונות (מינוף)</th>
                      <th className="py-2">הנזלה (Liq)</th>
                      <th className="py-2">רווח/הפסד (P&amp;L)</th>
                      <th className="py-2 text-left">פעולה</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#222B3A]/60 font-mono">
                    {safeOpen.map((pos) => {
                      const markPrice =
                        priceMap[pos.symbol] || pos.entryPrice;
                      const diff =
                        pos.side === "LONG"
                          ? markPrice - pos.entryPrice
                          : pos.entryPrice - markPrice;
                      const uPnl = diff * pos.quantity;
                      const uPnlPct = (uPnl / Math.max(1, pos.sizeUsdt)) * 100;

                      return (
                        <tr key={pos.id} className="hover:bg-[#181F2C]/60">
                          <td className="py-3 pr-2">
                            <div className="flex items-center gap-2">
                              <span
                                className={`rounded px-2 py-0.5 text-[10px] font-extrabold ${
                                  pos.side === "LONG"
                                    ? "bg-[#00E676]/15 text-[#00E676]"
                                    : "bg-[#FF3B69]/15 text-[#FF3B69]"
                                }`}
                              >
                                {pos.side} {pos.leverage}x
                              </span>
                              <strong className="text-sm text-[#F1F5F9]">
                                {pos.symbol}
                              </strong>
                            </div>
                            {pos.copiedFromTrader && (
                              <span className="mt-0.5 block font-sans text-[10px] text-[#3B82F6]">
                                שוכפל מ: {pos.copiedFromTrader}
                              </span>
                            )}
                          </td>
                          <td className="py-3">
                            <span className="block text-[#94A3B8]">
                              כניסה: ${formatPriceNumber(pos.entryPrice)}
                            </span>
                            <span className="font-bold text-[#F1F5F9]">
                              חי: ${formatPriceNumber(markPrice)}
                            </span>
                          </td>
                          <td className="py-3">
                            <span className="font-bold text-[#F1F5F9]">
                              ${pos.sizeUsdt.toFixed(0)}
                            </span>
                            <span className="block text-[10px] text-[#64748B]">
                              חשיפה: ${pos.notionalUsdt.toFixed(0)}
                            </span>
                          </td>
                          <td className="py-3 text-[#F59E0B]">
                            ${formatPriceNumber(pos.liquidationPrice)}
                            <span className="block text-[10px] text-[#64748B]">
                              SL: ${formatPriceNumber(pos.stopLoss)}
                            </span>
                          </td>
                          <td className="py-3">
                            <span
                              className={`text-sm font-extrabold ${
                                uPnl >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
                              }`}
                            >
                              {uPnl >= 0 ? "+" : ""}${uPnl.toFixed(2)}
                            </span>
                            <span
                              className={`block text-[10px] ${
                                uPnl >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
                              }`}
                            >
                              ({uPnlPct >= 0 ? "+" : ""}
                              {uPnlPct.toFixed(2)}%)
                            </span>
                          </td>
                          <td className="py-3 text-left">
                            <button
                              type="button"
                              onClick={() => onClosePosition(pos.id, markPrice)}
                              className="inline-flex items-center gap-1 rounded-lg bg-[#FF3B69]/20 px-3 py-1.5 font-sans text-xs font-bold text-[#FF3B69] transition hover:bg-[#FF3B69] hover:text-white"
                            >
                              <XCircle className="h-3.5 w-3.5" />
                              <span>סגור בשוק</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Pending Limit Orders Card */}
          <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
            <div className="mb-3 flex items-center justify-between border-b border-[#222B3A] pb-2.5">
              <h3 className="flex items-center gap-2 text-sm font-bold text-[#F1F5F9]">
                <Clock className="h-4 w-4 text-[#F59E0B]" />
                פקודות לימיט ממתינות בספר (Open Limit Orders: {safeLimitOrders.length})
              </h3>
            </div>

            {safeLimitOrders.length === 0 ? (
              <p className="text-xs text-[#94A3B8]">
                אין פקודות לימיט ממתינות כרגע.
              </p>
            ) : (
              <div className="space-y-2">
                {safeLimitOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3.5 py-2.5 text-xs"
                  >
                    <div className="flex items-center gap-3 font-mono">
                      <span
                        className={`rounded px-2 py-0.5 font-bold ${
                          ord.side === "LONG"
                            ? "bg-[#00E676]/15 text-[#00E676]"
                            : "bg-[#FF3B69]/15 text-[#FF3B69]"
                        }`}
                      >
                        LIMIT {ord.side} {ord.leverage}x
                      </span>
                      <strong className="text-[#F1F5F9]">{ord.symbol}</strong>
                      <span className="text-[#94A3B8]">
                        מחיר יעד:{" "}
                        <strong className="text-[#3B82F6]">
                          ${formatPriceNumber(ord.limitPrice)}
                        </strong>
                      </span>
                      <span className="text-[#94A3B8]">
                        בטחונות: ${ord.sizeUsdt}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onCancelLimitOrder(ord.id)}
                      className="rounded border border-[#FF3B69]/40 bg-[#FF3B69]/10 px-3 py-1 text-xs font-bold text-[#FF3B69] hover:bg-[#FF3B69] hover:text-white"
                    >
                      בטל פקודה
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Closed Positions History */}
          <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-[#F1F5F9]">
              <CheckCircle2 className="h-4 w-4 text-[#00E676]" />
              היסטוריית עסקאות סגורות ({safeClosed.length})
            </h3>
            <div className="space-y-2">
              {safeClosed.slice(0, 6).map((cPos) => (
                <div
                  key={cPos.id}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-[#0B0E14] px-3.5 py-2 font-mono text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#F1F5F9]">{cPos.symbol}</span>
                    <span className="text-[#94A3B8]">({cPos.side})</span>
                    <span className="text-[#64748B]">
                      ${formatPriceNumber(cPos.entryPrice)} → $
                      {formatPriceNumber(cPos.exitPrice || cPos.entryPrice)}
                    </span>
                  </div>
                  <span
                    className={`font-bold ${
                      (cPos.realizedPnlUsdt || 0) >= 0
                        ? "text-[#00E676]"
                        : "text-[#FF3B69]"
                    }`}
                  >
                    {(cPos.realizedPnlUsdt || 0) >= 0 ? "+" : ""}$
                    {(cPos.realizedPnlUsdt || 0).toFixed(2)} USDT
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
