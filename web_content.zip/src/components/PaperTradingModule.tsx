"use client";

import React, { useState, useMemo } from "react";
import {
  CoinTechnicalAnalysis,
  OHLCVCandle,
  runIntradayBacktest,
  formatPriceNumber,
} from "../services/technicalEngine";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  XCircle,
  RotateCcw,
  Clock,
  CheckCircle2,
  ShieldAlert,
  Play,
  BarChart2,
  AlertOctagon,
} from "lucide-react";

export interface PaperPositionItem {
  id: number;
  symbol: string;
  side: "LONG" | "SHORT";
  entryPrice: number;
  exitPrice?: number | null;
  sizeUsdt: number;
  notionalUsdt: number;
  quantity: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
  liquidationPrice: number;
  status: string;
  realizedPnlUsdt: number;
  closeReason?: string | null;
  copiedFromTrader?: string | null;
  openedAt: string;
}

export interface PaperLimitOrderItem {
  id: number;
  symbol: string;
  side: "LONG" | "SHORT";
  limitPrice: number;
  sizeUsdt: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
  status: string;
  createdAt: string;
}

interface PaperTradingModuleProps {
  virtualBalanceUsdt: number;
  realizedPnlUsdt: number;
  coins: CoinTechnicalAnalysis[];
  candles?: OHLCVCandle[];
  openPositions: PaperPositionItem[];
  closedPositions: PaperPositionItem[];
  limitOrders: PaperLimitOrderItem[];
  dailyCircuitBreakerPct?: number;
  onUpdateCircuitBreakerPct?: (pct: number) => void;
  onOpenMarketPosition: (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    entryPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
  }) => Promise<void>;
  onPlaceLimitOrder: (payload: {
    symbol: string;
    side: "LONG" | "SHORT";
    limitPrice: number;
    sizeUsdt: number;
    leverage: number;
    stopLoss: number;
    takeProfit: number;
  }) => Promise<void>;
  onCancelLimitOrder: (orderId: number) => Promise<void>;
  onClosePosition: (positionId: number, exitPrice: number) => Promise<void>;
  onResetAccount: () => Promise<void>;
}

export function PaperTradingModule({
  virtualBalanceUsdt,
  realizedPnlUsdt,
  coins,
  candles = [],
  openPositions,
  closedPositions,
  limitOrders,
  dailyCircuitBreakerPct = 2.5,
  onUpdateCircuitBreakerPct,
  onOpenMarketPosition,
  onPlaceLimitOrder,
  onCancelLimitOrder,
  onClosePosition,
  onResetAccount,
}: PaperTradingModuleProps) {
  const safeCoins = Array.isArray(coins) ? coins : [];
  const safeOpen = Array.isArray(openPositions) ? openPositions : [];
  const safeClosed = Array.isArray(closedPositions) ? closedPositions : [];
  const safeLimitOrders = Array.isArray(limitOrders)
    ? limitOrders.filter((o) => o.status === "PENDING")
    : [];

  const [selectedSymbol, setSelectedSymbol] = useState<string>("BTCUSDT");
  const [orderType, setOrderType] = useState<
    "MARKET" | "LIMIT" | "STOP_LIMIT" | "TRAILING_STOP"
  >("MARKET");
  const [side, setSide] = useState<"LONG" | "SHORT">("LONG");
  const [marginUsdt, setMarginUsdt] = useState<number>(500);
  const [leverage, setLeverage] = useState<number>(4);
  const [customLimitPrice, setCustomLimitPrice] = useState<string>("");
  const [trailingCallbackPct, setTrailingCallbackPct] = useState<number>(1.0);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Intraday Backtesting State
  const [btStrategy, setBtStrategy] = useState<
    "EMA_9_20_CROSS" | "VWAP_BOUNCE_SCALP" | "RSI_EXTREME_REVERSAL"
  >("EMA_9_20_CROSS");
  const [btTimeframe, setBtTimeframe] = useState<"1m" | "5m" | "15m">("5m");

  const selectedCoin =
    safeCoins.find((c) => c.symbol === selectedSymbol) || safeCoins[0];
  const livePrice = selectedCoin?.currentPrice || 94280;

  const priceMap: Record<string, number> = {};
  for (const c of safeCoins) {
    priceMap[c.symbol] = c.currentPrice;
  }

  const totalMarginInPositions = safeOpen.reduce(
    (acc, p) => acc + (p.sizeUsdt || 0),
    0
  );

  const totalUnrealizedPnl = safeOpen.reduce((acc, p) => {
    const mark = priceMap[p.symbol] || p.entryPrice;
    const diff =
      p.side === "LONG" ? mark - p.entryPrice : p.entryPrice - mark;
    return acc + diff * p.quantity;
  }, 0);

  const totalEquityUsdt =
    virtualBalanceUsdt + totalMarginInPositions + totalUnrealizedPnl;

  const dailyDrawdownPct = Number(
    Math.max(0, ((10000 - totalEquityUsdt) / 10000) * 100).toFixed(2)
  );
  const isCircuitBreakerTriggered =
    dailyDrawdownPct >= dailyCircuitBreakerPct;

  const effectiveEntryPrice =
    (orderType === "LIMIT" || orderType === "STOP_LIMIT") &&
    Number(customLimitPrice) > 0
      ? Number(customLimitPrice)
      : livePrice;

  const previewNotional = marginUsdt * leverage;
  const previewLiqPrice =
    side === "LONG"
      ? effectiveEntryPrice * (1 - 0.92 / leverage)
      : effectiveEntryPrice * (1 + 0.92 / leverage);
  const previewSl =
    orderType === "TRAILING_STOP"
      ? side === "LONG"
        ? effectiveEntryPrice * (1 - trailingCallbackPct / 100)
        : effectiveEntryPrice * (1 + trailingCallbackPct / 100)
      : side === "LONG"
      ? effectiveEntryPrice * 0.985
      : effectiveEntryPrice * 1.015;
  const previewTp =
    side === "LONG"
      ? effectiveEntryPrice * 1.032
      : effectiveEntryPrice * 0.968;

  const backtestResult = useMemo(
    () =>
      runIntradayBacktest(
        candles,
        btStrategy,
        btTimeframe,
        totalEquityUsdt > 0 ? totalEquityUsdt : 10000
      ),
    [candles, btStrategy, btTimeframe, totalEquityUsdt]
  );

  return (
    <div dir="rtl" className="space-y-6">
      {/* Top Virtual Portfolio Equity & Daily Loss Circuit Breaker Strip */}
      <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#00E676]/15 text-[#00E676]">
              <Wallet className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#F1F5F9]">
                סימולטור מסחר יומי ($10,000 USDT), פקודות מתקדמות ומנוע Backtest
              </h2>
              <p className="text-xs text-[#94A3B8]">
                תמיכה בפקודות Market, Limit, Stop-Limit ו-Trailing Stop, מנגנון הגנת
                הפסד יומי מרבי (Circuit Breaker) ו-Backtesting תוך-יומי.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Daily Loss Circuit Breaker Selector */}
            <div className="flex items-center gap-2 rounded-lg border border-[#F59E0B]/40 bg-[#0B0E14] px-3 py-1.5 text-xs">
              <AlertOctagon className="h-4 w-4 text-[#F59E0B]" />
              <span className="text-[#94A3B8]">הגנת הפסד יומי מרבי:</span>
              <select
                value={dailyCircuitBreakerPct}
                onChange={(e) =>
                  onUpdateCircuitBreakerPct &&
                  onUpdateCircuitBreakerPct(Number(e.target.value))
                }
                className="rounded bg-[#181F2C] px-2 py-0.5 font-mono font-bold text-[#00E676]"
              >
                <option value={1.5}>1.5%</option>
                <option value={2.5}>2.5% (מומלץ)</option>
                <option value={4.0}>4.0%</option>
                <option value={5.0}>5.0%</option>
              </select>
            </div>

            <button
              type="button"
              onClick={onResetAccount}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#181F2C] px-3.5 py-2 text-xs font-semibold text-[#94A3B8] transition hover:border-[#3B82F6] hover:text-white"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>אפס תיק דמו ל-$10,000</span>
            </button>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">שווי תיק כולל (Equity)</span>
            <div className="mt-1 font-mono text-2xl font-extrabold text-[#F1F5F9]">
              ${totalEquityUsdt.toFixed(2)}
            </div>
            <span className="text-[11px] text-[#64748B]">
              הון התחלתי: $10,000.00 USDT
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">יתרה זמינה למסחר (Free Cash)</span>
            <div className="mt-1 font-mono text-2xl font-extrabold text-[#3B82F6]">
              ${virtualBalanceUsdt.toFixed(2)}
            </div>
            <span className="text-[11px] text-[#64748B]">
              בטחונות בפוזיציות: ${totalMarginInPositions.toFixed(2)}
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">
              רווח/הפסד צף (Unrealized P&amp;L)
            </span>
            <div
              className={`mt-1 font-mono text-2xl font-extrabold ${
                totalUnrealizedPnl >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
              }`}
            >
              {totalUnrealizedPnl >= 0 ? "+" : ""}${totalUnrealizedPnl.toFixed(2)}
            </div>
            <span className="text-[11px] text-[#64748B]">
              מתעדכן בכל טיק מ-Binance/CoinCap
            </span>
          </div>

          <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
            <span className="text-xs text-[#94A3B8]">
              סטטוס מנגנון הגנת הפסד יומי
            </span>
            <div
              className={`mt-1 font-mono text-lg font-extrabold ${
                isCircuitBreakerTriggered ? "text-[#FF3B69]" : "text-[#00E676]"
              }`}
            >
              {isCircuitBreakerTriggered
                ? "נעול (חריגת הפסד יומי)"
                : `תקין (${dailyDrawdownPct}% / ${dailyCircuitBreakerPct}%)`}
            </div>
            <span className="text-[11px] text-[#64748B]">
              רווח ממומש: +${realizedPnlUsdt.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Main Split: Order Execution Ticket (4 cols) + Active Positions & Limit Orders (8 cols) */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Order Ticket Panel */}
        <div className="lg:col-span-4 rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
          <h3 className="mb-3 text-base font-bold text-[#F1F5F9]">
            שיגור פקודת מסחר יומית (Market / Limit / Stop / Trailing)
          </h3>

          {/* 4-Mode Order Type Selector */}
          <div className="mb-4 grid grid-cols-2 gap-1.5 rounded-lg bg-[#0B0E14] p-1.5 text-[11px]">
            {(
              [
                { id: "MARKET", label: "שוק (Market)" },
                { id: "LIMIT", label: "לימיט (Limit)" },
                { id: "STOP_LIMIT", label: "סטופ-לימיט (Stop-Limit)" },
                { id: "TRAILING_STOP", label: "נגרר (Trailing Stop)" },
              ] as const
            ).map((ot) => (
              <button
                key={ot.id}
                type="button"
                onClick={() => {
                  setOrderType(ot.id);
                  if (
                    (ot.id === "LIMIT" || ot.id === "STOP_LIMIT") &&
                    !customLimitPrice
                  ) {
                    setCustomLimitPrice(
                      String(Number((livePrice * 0.994).toPrecision(6)))
                    );
                  }
                }}
                className={`rounded-md py-1.5 font-bold transition ${
                  orderType === ot.id
                    ? "bg-[#3B82F6] text-white"
                    : "text-[#94A3B8] hover:text-white"
                }`}
              >
                {ot.label}
              </button>
            ))}
          </div>

          <div className="space-y-3.5">
            {/* Symbol Selector */}
            <div>
              <label className="mb-1 block text-xs text-[#94A3B8]">
                בחר צמד מסחר (Spot / Perp USDT):
              </label>
              <select
                value={selectedSymbol}
                onChange={(e) => {
                  setSelectedSymbol(e.target.value);
                  setCustomLimitPrice("");
                }}
                className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
              >
                {safeCoins.map((c) => (
                  <option key={c.symbol} value={c.symbol}>
                    {c.symbol} — ${formatPriceNumber(c.currentPrice)} (
                    {c.change24hPct >= 0 ? "+" : ""}
                    {c.change24hPct}%)
                  </option>
                ))}
              </select>
            </div>

            {/* Direction Toggle */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSide("LONG")}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2.5 text-xs font-extrabold transition ${
                  side === "LONG"
                    ? "bg-[#00E676] text-[#0B0E14]"
                    : "border border-[#222B3A] bg-[#0B0E14] text-[#94A3B8]"
                }`}
              >
                <TrendingUp className="h-4 w-4" />
                לונג / קנייה (LONG)
              </button>
              <button
                type="button"
                onClick={() => setSide("SHORT")}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2.5 text-xs font-extrabold transition ${
                  side === "SHORT"
                    ? "bg-[#FF3B69] text-white"
                    : "border border-[#222B3A] bg-[#0B0E14] text-[#94A3B8]"
                }`}
              >
                <TrendingDown className="h-4 w-4" />
                שורט / מכירה (SHORT)
              </button>
            </div>

            {(orderType === "LIMIT" || orderType === "STOP_LIMIT") && (
              <div>
                <label className="mb-1 block text-xs text-[#94A3B8]">
                  {orderType === "STOP_LIMIT"
                    ? "מחיר טריגר ולימיט ($ USDT):"
                    : "מחיר יעד לביצוע לימיט ($ USDT):"}
                </label>
                <input
                  type="number"
                  step="any"
                  value={customLimitPrice}
                  onChange={(e) => setCustomLimitPrice(e.target.value)}
                  className="w-full rounded-lg border border-[#3B82F6] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:outline-none"
                />
              </div>
            )}

            {orderType === "TRAILING_STOP" && (
              <div>
                <label className="mb-1 block text-xs text-[#94A3B8]">
                  מרווח עקיבה דינמי (Trailing Callback %):
                </label>
                <input
                  type="number"
                  step="0.25"
                  min={0.25}
                  max={10}
                  value={trailingCallbackPct}
                  onChange={(e) =>
                    setTrailingCallbackPct(Number(e.target.value))
                  }
                  className="w-full rounded-lg border border-[#00E676] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:outline-none"
                />
              </div>
            )}

            {/* Margin Size Input */}
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-[#94A3B8]">סכום בטחונות ($ USDT):</span>
                <span className="font-mono text-[#3B82F6]">
                  זמין: ${virtualBalanceUsdt.toFixed(0)}
                </span>
              </div>
              <input
                type="number"
                min={25}
                max={Math.max(50, virtualBalanceUsdt)}
                step={25}
                value={marginUsdt}
                onChange={(e) => setMarginUsdt(Number(e.target.value))}
                className="w-full rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-2 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
              />
              <div className="mt-1.5 flex gap-1.5">
                {[10, 25, 50, 75].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() =>
                      setMarginUsdt(
                        Math.max(25, Math.floor((virtualBalanceUsdt * pct) / 100))
                      )
                    }
                    className="flex-1 rounded bg-[#181F2C] py-1 font-mono text-[11px] text-[#94A3B8] hover:bg-[#3B82F6] hover:text-white"
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            {/* Leverage Slider */}
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-[#94A3B8]">מינוף חוזה (Leverage):</span>
                <span className="font-mono font-bold text-[#F59E0B]">
                  {leverage}x
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={20}
                value={leverage}
                onChange={(e) => setLeverage(Number(e.target.value))}
                className="w-full accent-[#3B82F6]"
              />
              <div className="flex justify-between font-mono text-[10px] text-[#64748B]">
                <span>1x</span>
                <span>3x (מומלץ)</span>
                <span>5x</span>
                <span>10x</span>
                <span>20x</span>
              </div>
            </div>

            {/* Order Summary Preview */}
            <div className="rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">שווי חשיפה כולל (Notional):</span>
                <span className="font-mono font-bold text-[#F1F5F9]">
                  ${previewNotional.toLocaleString()} USDT
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">מחיר כניסה / טריגר:</span>
                <span className="font-mono text-[#F1F5F9]">
                  ${formatPriceNumber(effectiveEntryPrice)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">מחיר הנזלה (Liquidation):</span>
                <span className="font-mono font-bold text-[#F59E0B]">
                  ${formatPriceNumber(previewLiqPrice)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#94A3B8]">הגנות אוטומטיות (TP / SL):</span>
                <span className="font-mono text-[11px]">
                  <span className="text-[#00E676]">
                    ${formatPriceNumber(previewTp)}
                  </span>{" "}
                  /{" "}
                  <span className="text-[#FF3B69]">
                    ${formatPriceNumber(previewSl)}
                  </span>
                </span>
              </div>
            </div>

            <button
              type="button"
              disabled={submitting || isCircuitBreakerTriggered}
              onClick={async () => {
                setSubmitting(true);
                if (orderType === "MARKET" || orderType === "TRAILING_STOP") {
                  await onOpenMarketPosition({
                    symbol: selectedSymbol,
                    side,
                    entryPrice: livePrice,
                    sizeUsdt: marginUsdt,
                    leverage,
                    stopLoss: Number(previewSl.toPrecision(6)),
                    takeProfit: Number(previewTp.toPrecision(6)),
                  });
                } else {
                  await onPlaceLimitOrder({
                    symbol: selectedSymbol,
                    side,
                    limitPrice: effectiveEntryPrice,
                    sizeUsdt: marginUsdt,
                    leverage,
                    stopLoss: Number(previewSl.toPrecision(6)),
                    takeProfit: Number(previewTp.toPrecision(6)),
                  });
                }
                setSubmitting(false);
              }}
              className={`w-full rounded-lg py-3 text-sm font-extrabold transition ${
                side === "LONG"
                  ? "bg-[#00E676] text-[#0B0E14] hover:brightness-110"
                  : "bg-[#FF3B69] text-white hover:brightness-110"
              } disabled:opacity-50`}
            >
              {orderType === "MARKET"
                ? `בצע עסקת ${side === "LONG" ? "לונג (LONG)" : "שורט (SHORT)"} מיידית`
                : orderType === "TRAILING_STOP"
                ? `פתח פוזיציה עם Trailing Stop (${trailingCallbackPct}%)`
                : `שגר פקודת ${orderType} (${side}) במחיר $${formatPriceNumber(
                    effectiveEntryPrice
                  )}`}
            </button>
          </div>
        </div>

        {/* Right Panel: Active Open Positions + Limit Orders (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {/* Open Positions Card */}
          <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
            <div className="mb-3 flex items-center justify-between border-b border-[#222B3A] pb-3">
              <h3 className="text-base font-bold text-[#F1F5F9]">
                פוזיציות מסחר יומי פתוחות בזמן אמת ({safeOpen.length})
              </h3>
              <span className="text-xs text-[#94A3B8]">
                SL/TP אוטומטי מופעל מול זרם המחירים
              </span>
            </div>

            {safeOpen.length === 0 ? (
              <div className="rounded-lg bg-[#0B0E14] p-6 text-center text-sm text-[#94A3B8]">
                אין פוזיציות פתוחות כרגע. השתמש בטופס משמאל או בסוכן ה-MCP.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="border-b border-[#222B3A] text-[#64748B]">
                      <th className="py-2 pr-2">נכס / כיוון</th>
                      <th className="py-2">כניסה / שוק חי</th>
                      <th className="py-2">בטחונות (מינוף)</th>
                      <th className="py-2">הנזלה (Liq)</th>
                      <th className="py-2">רווח/הפסד (P&amp;L)</th>
                      <th className="py-2 text-left">פעולה</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#222B3A]/60 font-mono">
                    {safeOpen.map((pos) => {
                      const markPrice =
                        priceMap[pos.symbol] || pos.entryPrice;
                      const diff =
                        pos.side === "LONG"
                          ? markPrice - pos.entryPrice
                          : pos.entryPrice - markPrice;
                      const uPnl = diff * pos.quantity;
                      const uPnlPct = (uPnl / Math.max(1, pos.sizeUsdt)) * 100;

                      return (
                        <tr key={pos.id} className="hover:bg-[#181F2C]/60">
                          <td className="py-3 pr-2">
                            <div className="flex items-center gap-2">
                              <span
                                className={`rounded px-2 py-0.5 text-[10px] font-extrabold ${
                                  pos.side === "LONG"
                                    ? "bg-[#00E676]/15 text-[#00E676]"
                                    : "bg-[#FF3B69]/15 text-[#FF3B69]"
                                }`}
                              >
                                {pos.side} {pos.leverage}x
                              </span>
                              <strong className="text-sm text-[#F1F5F9]">
                                {pos.symbol}
                              </strong>
                            </div>
                            {pos.copiedFromTrader && (
                              <span className="mt-0.5 block font-sans text-[10px] text-[#3B82F6]">
                                שוכפל מ: {pos.copiedFromTrader}
                              </span>
                            )}
                          </td>
                          <td className="py-3">
                            <span className="block text-[#94A3B8]">
                              כניסה: ${formatPriceNumber(pos.entryPrice)}
                            </span>
                            <span className="font-bold text-[#F1F5F9]">
                              חי: ${formatPriceNumber(markPrice)}
                            </span>
                          </td>
                          <td className="py-3">
                            <span className="font-bold text-[#F1F5F9]">
                              ${pos.sizeUsdt.toFixed(0)}
                            </span>
                            <span className="block text-[10px] text-[#64748B]">
                              חשיפה: ${pos.notionalUsdt.toFixed(0)}
                            </span>
                          </td>
                          <td className="py-3 text-[#F59E0B]">
                            ${formatPriceNumber(pos.liquidationPrice)}
                            <span className="block text-[10px] text-[#64748B]">
                              SL: ${formatPriceNumber(pos.stopLoss)}
                            </span>
                          </td>
                          <td className="py-3">
                            <span
                              className={`text-sm font-extrabold ${
                                uPnl >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
                              }`}
                            >
                              {uPnl >= 0 ? "+" : ""}${uPnl.toFixed(2)}
                            </span>
                            <span
                              className={`block text-[10px] ${
                                uPnl >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
                              }`}
                            >
                              ({uPnlPct >= 0 ? "+" : ""}
                              {uPnlPct.toFixed(2)}%)
                            </span>
                          </td>
                          <td className="py-3 text-left">
                            <button
                              type="button"
                              onClick={() => onClosePosition(pos.id, markPrice)}
                              className="inline-flex items-center gap-1 rounded-lg bg-[#FF3B69]/20 px-3 py-1.5 font-sans text-xs font-bold text-[#FF3B69] transition hover:bg-[#FF3B69] hover:text-white"
                            >
                              <XCircle className="h-3.5 w-3.5" />
                              <span>סגור בשוק</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Pending Limit / Stop-Limit Orders Card */}
          <div className="rounded-xl border border-[#222B3A] bg-[#11161F] p-5">
            <div className="mb-3 flex items-center justify-between border-b border-[#222B3A] pb-2.5">
              <h3 className="flex items-center gap-2 text-sm font-bold text-[#F1F5F9]">
                <Clock className="h-4 w-4 text-[#F59E0B]" />
                פקודות לימיט ו-Stop-Limit ממתינות ({safeLimitOrders.length})
              </h3>
            </div>

            {safeLimitOrders.length === 0 ? (
              <p className="text-xs text-[#94A3B8]">
                אין פקודות לימיט ממתינות כרגע.
              </p>
            ) : (
              <div className="space-y-2">
                {safeLimitOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3.5 py-2.5 text-xs"
                  >
                    <div className="flex items-center gap-3 font-mono">
                      <span
                        className={`rounded px-2 py-0.5 font-bold ${
                          ord.side === "LONG"
                            ? "bg-[#00E676]/15 text-[#00E676]"
                            : "bg-[#FF3B69]/15 text-[#FF3B69]"
                        }`}
                      >
                        LIMIT {ord.side} {ord.leverage}x
                      </span>
                      <strong className="text-[#F1F5F9]">{ord.symbol}</strong>
                      <span className="text-[#94A3B8]">
                        מחיר יעד:{" "}
                        <strong className="text-[#3B82F6]">
                          ${formatPriceNumber(ord.limitPrice)}
                        </strong>
                      </span>
                      <span className="text-[#94A3B8]">
                        בטחונות: ${ord.sizeUsdt}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onCancelLimitOrder(ord.id)}
                      className="rounded border border-[#FF3B69]/40 bg-[#FF3B69]/10 px-3 py-1 text-xs font-bold text-[#FF3B69] hover:bg-[#FF3B69] hover:text-white"
                    >
                      בטל פקודה
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Intraday Backtesting Engine Card ("מנוע Backtest למסחר יומי") */}
      <div className="rounded-xl border border-[#3B82F6]/40 bg-[#11161F] p-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#222B3A] pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#3B82F6]/15 text-[#3B82F6]">
              <BarChart2 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#F1F5F9]">
                מנוע Backtest תוך-יומי על 200 נרות היסטוריים ({selectedSymbol})
              </h3>
              <p className="text-xs text-[#94A3B8]">
                בדיקת ביצועי אסטרטגיות סקאלפינג (EMA 9/20, VWAP Bounce, RSI
                Reversal) על נתוני השוק האמיתיים לפני סיכון הון.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={btStrategy}
              onChange={(e) =>
                setBtStrategy(
                  e.target.value as
                    | "EMA_9_20_CROSS"
                    | "VWAP_BOUNCE_SCALP"
                    | "RSI_EXTREME_REVERSAL"
                )
              }
              className="rounded-lg border border-[#222B3A] bg-[#0B0E14] px-3 py-1.5 text-xs font-bold text-[#F1F5F9]"
            >
              <option value="EMA_9_20_CROSS">
                חציית ממוצעים EMA 9/20 + מסנן VWAP
              </option>
              <option value="VWAP_BOUNCE_SCALP">
                סקאלפינג ריבאונד מ-VWAP מוסדי
              </option>
              <option value="RSI_EXTREME_REVERSAL">
                היפוך RSI(14) + נקודת POC
              </option>
            </select>

            {(["1m", "5m", "15m"] as const).map((tf) => (
              <button
                key={tf}
                type="button"
                onClick={() => setBtTimeframe(tf)}
                className={`rounded-lg px-3 py-1.5 font-mono text-xs font-bold ${
                  btTimeframe === tf
                    ? "bg-[#3B82F6] text-white"
                    : "bg-[#0B0E14] text-[#94A3B8]"
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* Backtest KPIs */}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5 font-mono">
          <div className="rounded-lg bg-[#0B0E14] p-3">
            <span className="block font-sans text-[11px] text-[#94A3B8]">
              אחוז הצלחה (Win-Rate)
            </span>
            <strong className="text-lg font-extrabold text-[#00E676]">
              {backtestResult.winRatePct}%
            </strong>
          </div>
          <div className="rounded-lg bg-[#0B0E14] p-3">
            <span className="block font-sans text-[11px] text-[#94A3B8]">
              רווח נקי בסימולציה
            </span>
            <strong className="text-lg font-extrabold text-[#00E676]">
              +${backtestResult.netProfitUsdt} (+{backtestResult.netReturnPct}%)
            </strong>
          </div>
          <div className="rounded-lg bg-[#0B0E14] p-3">
            <span className="block font-sans text-[11px] text-[#94A3B8]">
              סה״כ עסקאות שנבדקו
            </span>
            <strong className="text-lg font-bold text-[#F1F5F9]">
              {backtestResult.totalTrades} ({backtestResult.winningTrades}W /{" "}
              {backtestResult.losingTrades}L)
            </strong>
          </div>
          <div className="rounded-lg bg-[#0B0E14] p-3">
            <span className="block font-sans text-[11px] text-[#94A3B8]">
              מכפיל רווח (Profit Factor)
            </span>
            <strong className="text-lg font-bold text-[#3B82F6]">
              {backtestResult.profitFactor}x
            </strong>
          </div>
          <div className="rounded-lg bg-[#0B0E14] p-3">
            <span className="block font-sans text-[11px] text-[#94A3B8]">
              נסיגה מקסימלית (Max DD)
            </span>
            <strong className="text-lg font-bold text-[#F59E0B]">
              {backtestResult.maxDrawdownPct}%
            </strong>
          </div>
        </div>
      </div>
    </div>
  );
}
