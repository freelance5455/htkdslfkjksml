import React, { useState, useEffect } from "react";
import {
  StickyNote,
  FileText,
  Network,
  Shield,
  BookOpen,
  User,
  Sparkles,
  Sliders,
  ArrowUp,
  ArrowDown,
  Trash2,
  Plus,
  RotateCcw,
  Check,
  X,
  Layers,
  Search,
  CheckCircle2,
  Mic,
  LayoutGrid,
  Zap,
  MoveHorizontal,
  CircleDot,
  Radio,
  SlidersHorizontal,
  Flame,
  HelpCircle,
} from "lucide-react";
import { ActiveTab, ThemeAccent } from "../types";
import {
  DEFAULT_MENU_ORDER,
  saveStoredMenuOrder,
  PlusButtonConfig,
  getStoredPlusButtonConfig,
  saveStoredPlusButtonConfig,
} from "../utils/storage";
import { THEME_ACCENTS } from "../utils/theme";

export interface MenuSectionCatalogItem {
  id: ActiveTab;
  title: string;
  desc: string;
  category: "core" | "action" | "smart";
  icon: React.ReactNode;
  colorClass: string;
  badge?: string;
  isPlusAction?: boolean;
}

export const ALL_MENU_SECTIONS_CATALOG: MenuSectionCatalogItem[] = [
  {
    id: "plus_action",
    title: "Hızlı Ekleme Butonu (+)",
    desc: "Yeni not, ses, görev veya zihin haritası başlatan ana eylem butonu. İstediğiniz sıraya taşıyabilirsiniz.",
    category: "action",
    icon: <Plus className="w-4 h-4 text-teal-500 stroke-[3]" />,
    colorClass: "from-teal-500/20 to-emerald-500/20 border-teal-400 text-teal-700 dark:text-teal-300",
    badge: "Ana Eylem (+)",
    isPlusAction: true,
  },
  {
    id: "home",
    title: "Tüm Notlar & Akış",
    desc: "Zengin metin notları, filtreler, sayaçlar ve arama merkezi",
    category: "core",
    icon: <StickyNote className="w-4 h-4 text-teal-500" />,
    colorClass: "from-teal-500/20 to-emerald-500/20 border-teal-400 text-teal-700 dark:text-teal-300",
    badge: "Temel",
  },
  {
    id: "docs",
    title: "Belge İnceleyici Hub",
    desc: "PDF, Word ve Markdown belge yönetimi ve okuyucu",
    category: "core",
    icon: <FileText className="w-4 h-4 text-blue-500" />,
    colorClass: "from-blue-500/20 to-indigo-500/20 border-blue-400 text-blue-700 dark:text-blue-300",
    badge: "Ofis",
  },
  {
    id: "mindmap",
    title: "Zihin Haritası & Tuval",
    desc: "PKM zihin düğümleri, görsel ilişki ağaçları ve tuval",
    category: "core",
    icon: <Network className="w-4 h-4 text-purple-500" />,
    colorClass: "from-purple-500/20 to-pink-500/20 border-purple-400 text-purple-700 dark:text-purple-300",
    badge: "PKM",
  },
  {
    id: "vault",
    title: "Şifreli Güvenli Kasa",
    desc: "AES-256-GCM askeri şifreleme ile korunan gizli kayıtlar",
    category: "core",
    icon: <Shield className="w-4 h-4 text-emerald-500" />,
    colorClass: "from-emerald-500/20 to-teal-500/20 border-emerald-400 text-emerald-700 dark:text-emerald-300",
    badge: "Güvenlik",
  },
  {
    id: "study",
    title: "Öğrenme & Çalışma Kartları",
    desc: "Flashcard modülü, testler ve aralıklı tekrar algoritması",
    category: "core",
    icon: <BookOpen className="w-4 h-4 text-amber-500" />,
    colorClass: "from-amber-500/20 to-yellow-500/20 border-amber-400 text-amber-700 dark:text-amber-300",
    badge: "Eğitim",
  },
  {
    id: "profile",
    title: "Profil & Arayüz Ayarları",
    desc: "Kullanıcı hesabı, görsel temalar ve radyal menü ayarları",
    category: "core",
    icon: <User className="w-4 h-4 text-indigo-500" />,
    colorClass: "from-indigo-500/20 to-violet-500/20 border-indigo-400 text-indigo-700 dark:text-indigo-300",
    badge: "Kullanıcı",
  },
  {
    id: "tips",
    title: "İpuçları Rehberi",
    desc: "Uygulama kullanım kısayolları, tüyolar ve püf noktaları",
    category: "core",
    icon: <Sparkles className="w-4 h-4 text-rose-500" />,
    colorClass: "from-rose-500/20 to-pink-500/20 border-rose-400 text-rose-700 dark:text-rose-300",
    badge: "Rehber",
  },
  {
    id: "settings",
    title: "Sistem Ayarları",
    desc: "Yerel depolama, dışa aktarma, yedekleme ve sıfırlama",
    category: "core",
    icon: <Sliders className="w-4 h-4 text-slate-500" />,
    colorClass: "from-slate-500/20 to-gray-500/20 border-slate-400 text-slate-700 dark:text-slate-300",
    badge: "Sistem",
  },
  {
    id: "ai_chat",
    title: "Yapay Zeka Asistan & Sohbet",
    desc: "Gemini destekli akıllı soru-cevap ve not analizi",
    category: "smart",
    icon: <Sparkles className="w-4 h-4 text-teal-400" />,
    colorClass: "from-teal-500/20 to-cyan-500/20 border-teal-400 text-teal-700 dark:text-teal-300",
    badge: "AI Akıllı",
  },
  {
    id: "quick_search",
    title: "Hızlı Komut Paleti & Arama",
    desc: "Uygulama genelinde anlık hızlı filtre ve arama çubuğu",
    category: "smart",
    icon: <Search className="w-4 h-4 text-blue-400" />,
    colorClass: "from-blue-500/20 to-sky-500/20 border-blue-400 text-blue-700 dark:text-blue-300",
    badge: "Hızlı Arama",
  },
  {
    id: "voice_memo",
    title: "Hızlı Sesli Not Kaydedici",
    desc: "Tek tıkla mikrofondan ses kaydı ve transkripsiyon başlatır",
    category: "action",
    icon: <Mic className="w-4 h-4 text-rose-400" />,
    colorClass: "from-rose-500/20 to-amber-500/20 border-rose-400 text-rose-700 dark:text-rose-300",
    badge: "Sesli Not",
  },
];

interface MenuSectionsManagerProps {
  menuOrder: ActiveTab[];
  onUpdateMenuOrder: (order: ActiveTab[]) => void;
  themeAccent?: ThemeAccent;
}

export const MenuSectionsManager: React.FC<MenuSectionsManagerProps> = ({
  menuOrder,
  onUpdateMenuOrder,
  themeAccent = "teal",
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCatalogCategory, setSelectedCatalogCategory] = useState<"all" | "core" | "action" | "smart">("all");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Plus button custom configuration state
  const [plusConfig, setPlusConfig] = useState<PlusButtonConfig>(getStoredPlusButtonConfig);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleUpdatePlusConfig = (updated: Partial<PlusButtonConfig>) => {
    const next = { ...plusConfig, ...updated };
    setPlusConfig(next);
    saveStoredPlusButtonConfig(next);
    showToast("✓ '+' Buton ayarları güncellendi.");
  };

  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    const next = [...menuOrder];
    const temp = next[index - 1];
    next[index - 1] = next[index];
    next[index] = temp;
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    showToast(`'${getItemTitle(next[index - 1])}' yukarı taşındı.`);
  };

  const handleMoveDown = (index: number) => {
    if (index >= menuOrder.length - 1) return;
    const next = [...menuOrder];
    const temp = next[index + 1];
    next[index + 1] = next[index];
    next[index] = temp;
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    showToast(`'${getItemTitle(next[index + 1])}' aşağı taşındı.`);
  };

  const handleMoveToTop = (index: number) => {
    if (index === 0) return;
    const next = [...menuOrder];
    const [item] = next.splice(index, 1);
    next.unshift(item);
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    showToast(`'${getItemTitle(item)}' en başa (sola) taşındı.`);
  };

  const handleMoveToBottom = (index: number) => {
    if (index === menuOrder.length - 1) return;
    const next = [...menuOrder];
    const [item] = next.splice(index, 1);
    next.push(item);
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    showToast(`'${getItemTitle(item)}' en sona (sağa) taşındı.`);
  };

  // Move '+' button specifically to center
  const handleMovePlusToCenter = () => {
    const withoutPlus: ActiveTab[] = menuOrder.filter((id) => id !== "plus_action");
    const mid = Math.floor(withoutPlus.length / 2);
    withoutPlus.splice(mid, 0, "plus_action");
    onUpdateMenuOrder(withoutPlus);
    saveStoredMenuOrder(withoutPlus);
    showToast("🎯 '+' butonu tam ortaya (dengeli konuma) yerleştirildi.");
  };

  const handleMovePlusToStart = () => {
    const withoutPlus = menuOrder.filter((id) => id !== "plus_action");
    const next: ActiveTab[] = ["plus_action", ...withoutPlus];
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    showToast("👈 '+' butonu en başa (sol uca) yerleştirildi.");
  };

  const handleMovePlusToEnd = () => {
    const withoutPlus = menuOrder.filter((id) => id !== "plus_action");
    const next: ActiveTab[] = [...withoutPlus, "plus_action"];
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    showToast("👉 '+' butonu en sona (sağ uca) yerleştirildi.");
  };

  const handleRemoveSection = (tabId: ActiveTab) => {
    if (menuOrder.length <= 1) {
      showToast("⚠️ En az 1 menü kesiti navigasyon çubuğunda kalmalıdır.");
      return;
    }
    const next = menuOrder.filter((id) => id !== tabId);
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    showToast(`✓ '${getItemTitle(tabId)}' navigasyon çubuğundan kaldırıldı.`);
  };

  const handleAddSection = (tabId: ActiveTab) => {
    if (menuOrder.includes(tabId)) return;
    const next = [...menuOrder, tabId];
    onUpdateMenuOrder(next);
    saveStoredMenuOrder(next);
    setIsAddModalOpen(false);
    showToast(`✓ '${getItemTitle(tabId)}' navigasyon çubuğuna eklendi.`);
  };

  const handleApplyPreset = (preset: "center" | "left" | "right" | "minimal" | "pkm" | "ai") => {
    let newOrder: ActiveTab[] = [];
    switch (preset) {
      case "center":
        newOrder = ["home", "docs", "mindmap", "plus_action", "vault", "study", "profile", "settings"];
        break;
      case "left":
        newOrder = ["plus_action", "home", "docs", "mindmap", "vault", "study", "profile", "settings"];
        break;
      case "right":
        newOrder = ["home", "docs", "mindmap", "vault", "study", "profile", "settings", "plus_action"];
        break;
      case "minimal":
        newOrder = ["home", "mindmap", "plus_action", "vault", "profile"];
        break;
      case "pkm":
        newOrder = ["home", "docs", "mindmap", "plus_action", "study", "vault", "tips", "settings"];
        break;
      case "ai":
        newOrder = ["home", "ai_chat", "plus_action", "docs", "mindmap", "profile"];
        break;
      default:
        newOrder = DEFAULT_MENU_ORDER;
    }
    onUpdateMenuOrder(newOrder);
    saveStoredMenuOrder(newOrder);
    showToast("✓ Hazır düzen şablonu uygulandı.");
  };

  const handleResetToDefault = () => {
    onUpdateMenuOrder(DEFAULT_MENU_ORDER);
    saveStoredMenuOrder(DEFAULT_MENU_ORDER);
    showToast("Menü sıralaması fabrika ayarlarına sıfırlandı.");
  };

  const getItemTitle = (id: ActiveTab): string => {
    const item = ALL_MENU_SECTIONS_CATALOG.find((s) => s.id === id);
    return item ? item.title : id;
  };

  // Find sections not yet in menuOrder
  const hiddenSections = ALL_MENU_SECTIONS_CATALOG.filter(
    (s) => !menuOrder.includes(s.id)
  );

  const filteredHiddenSections = hiddenSections.filter((s) => {
    if (selectedCatalogCategory !== "all" && s.category !== selectedCatalogCategory) {
      return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return s.title.toLowerCase().includes(q) || s.desc.toLowerCase().includes(q);
  });

  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;
  const plusIndex = menuOrder.indexOf("plus_action");

  return (
    <div className="space-y-6">
      {/* Toast Notice */}
      {toastMessage && (
        <div className="p-3 sm:p-4 rounded-2xl bg-emerald-600 text-white flex items-center justify-between shadow-xl animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{toastMessage}</span>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="p-1 hover:bg-emerald-700 rounded-lg text-emerald-100"
          >
            ✕
          </button>
        </div>
      )}

      {/* Header Info & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-500" />
              <span>Özelleştirilebilir Menü Kesitleri & Sıralama</span>
            </h3>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
              {menuOrder.length} Aktif Öğe
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Navigasyon çubuğundaki sekmeleri ve <strong>'+' oluşturma butonunu</strong> istediğiniz sıraya taşıyın, silin veya yeni özellikler ekleyin.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto flex-wrap">
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            title="Navigasyon çubuğuna yeni kesit veya eylem ekle"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Yeni Kesit / Araç Ekle</span>
          </button>

          <button
            type="button"
            onClick={handleResetToDefault}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 transition-colors cursor-pointer"
            title="Varsayılan Sıralamaya Sıfırla"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. CANLI NAVİGASYON ÇUBUĞU ÖNİZLEMESİ                                      */}
      {/* ========================================================================= */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white border border-slate-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Canlı Navigasyon Çubuğu Önizlemesi (Gerçek Zamanlı)</span>
          </span>
          {plusIndex !== -1 && (
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-950 border border-teal-800 text-teal-300 font-bold">
              '+' Konumu: {plusIndex === 0 ? "En Başta (Sol)" : plusIndex === menuOrder.length - 1 ? "En Sonda (Sağ)" : `Pozisyon #${plusIndex + 1}`}
            </span>
          )}
        </div>

        {/* Realistic Mini Dock Preview */}
        <div className="py-2 flex items-center justify-center">
          <div className="flex items-center gap-1 sm:gap-1.5 p-1.5 bg-white/10 dark:bg-slate-900/90 backdrop-blur-xl rounded-full border border-white/20 dark:border-slate-700 shadow-2xl max-w-full overflow-x-auto no-scrollbar">
            {menuOrder.map((tabId, idx) => {
              if (tabId === "plus_action") {
                return (
                  <div
                    key="plus-preview"
                    className="px-1 shrink-0 relative group"
                    title={`'+' Butonu (Sıra: #${idx + 1})`}
                  >
                    <div
                      className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-tr ${themeDef.gradient} flex items-center justify-center text-white shadow-lg font-bold relative transition-transform group-hover:scale-110 cursor-pointer`}
                      style={{ boxShadow: `0 6px 16px -2px ${themeDef.preview}80` }}
                    >
                      <Plus className="w-5 h-5 stroke-[3]" />
                      {plusConfig.effect === "glow" && (
                        <span
                          className="absolute inset-0 rounded-full animate-ping opacity-30 pointer-events-none"
                          style={{ backgroundColor: themeDef.preview }}
                        />
                      )}
                    </div>
                  </div>
                );
              }

              const sec = ALL_MENU_SECTIONS_CATALOG.find((s) => s.id === tabId);
              return (
                <div
                  key={tabId}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-full text-[11px] font-bold text-slate-200 bg-white/5 border border-white/10 hover:bg-white/15 transition-all shrink-0 cursor-default"
                >
                  <span className="w-3.5 h-3.5 flex items-center justify-center">
                    {sec?.icon}
                  </span>
                  <span className="text-[10px]">{sec?.title.split(" ")[0]}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick '+' Position Shortcuts */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between flex-wrap gap-2 text-xs">
          <span className="text-[11px] text-slate-400 font-medium">
            '+' Butonunu Hızlı Konumlandır:
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={handleMovePlusToStart}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                plusIndex === 0
                  ? "bg-teal-600 text-white"
                  : "bg-slate-800 hover:bg-slate-700 text-slate-300"
              }`}
            >
              👈 En Başa (Sol)
            </button>
            <button
              type="button"
              onClick={handleMovePlusToCenter}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                plusIndex > 0 && plusIndex < menuOrder.length - 1
                  ? "bg-teal-600 text-white"
                  : "bg-slate-800 hover:bg-slate-700 text-slate-300"
              }`}
            >
              🎯 Ortaya (Dengeli)
            </button>
            <button
              type="button"
              onClick={handleMovePlusToEnd}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                plusIndex === menuOrder.length - 1
                  ? "bg-teal-600 text-white"
                  : "bg-slate-800 hover:bg-slate-700 text-slate-300"
              }`}
            >
              👉 En Sona (Sağ)
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. HAZIR DÜZEN ŞABLONLARI (PRESETS)                                       */}
      {/* ========================================================================= */}
      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
            <LayoutGrid className="w-4 h-4 text-indigo-500" />
            <span>Hazır Menü & Navigasyon Şablonları</span>
          </span>
          <span className="text-[11px] text-slate-400">Tek tıkla uygula</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => handleApplyPreset("center")}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-all cursor-pointer group"
          >
            <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 flex items-center gap-1">
              <span>🎯 Klasik Merkez FAB</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              '+' ortada, tüm sekmeler dengeli
            </p>
          </button>

          <button
            type="button"
            onClick={() => handleApplyPreset("left")}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-all cursor-pointer group"
          >
            <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 flex items-center gap-1">
              <span>👈 Sol Başparmak Odaklı</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              '+' en solda, sol el ile hızlı erişim
            </p>
          </button>

          <button
            type="button"
            onClick={() => handleApplyPreset("right")}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-all cursor-pointer group"
          >
            <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 flex items-center gap-1">
              <span>👉 Sağ Başparmak Odaklı</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              '+' en sağda, sağ el ile hızlı erişim
            </p>
          </button>

          <button
            type="button"
            onClick={() => handleApplyPreset("minimal")}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-all cursor-pointer group"
          >
            <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 flex items-center gap-1">
              <span>⚡ Minimalist (4 Araç)</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              Sadece temel notlar, tuval ve kasa
            </p>
          </button>

          <button
            type="button"
            onClick={() => handleApplyPreset("pkm")}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-all cursor-pointer group"
          >
            <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 flex items-center gap-1">
              <span>🧠 Bilgi Mimarı (PKM)</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              Zihin haritası, çalışma ve belgeler
            </p>
          </button>

          <button
            type="button"
            onClick={() => handleApplyPreset("ai")}
            className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-indigo-400 text-left transition-all cursor-pointer group"
          >
            <div className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 flex items-center gap-1">
              <span>🤖 Yapay Zeka Odaklı</span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              AI Sohbet ve asistan ön planda
            </p>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. '+' BUTONUNA ÖZEL GELİŞMİŞ AYARLAR KARTI                                */}
      {/* ========================================================================= */}
      <div className="p-4 sm:p-5 rounded-3xl border-2 border-teal-500/40 bg-teal-50/20 dark:bg-teal-950/20 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-500 text-white flex items-center justify-center shadow-md">
              <Plus className="w-5 h-5 stroke-[3]" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">
                '+' Eylem Butonu Özel Ayarları & Davranışı
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Tıklama anında gerçekleşecek eylemi ve butonun görsel stilini belirleyin.
              </p>
            </div>
          </div>
          <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300">
            Özelleştirilebilir
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Action on click */}
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1.5">
            <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
              Tıklama Eylemi:
            </label>
            <select
              value={plusConfig.action}
              onChange={(e) =>
                handleUpdatePlusConfig({
                  action: e.target.value as PlusButtonConfig["action"],
                })
              }
              className="w-full text-xs font-semibold py-1.5 px-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="create_menu">Yeni Oluştur Menüsü (Varsayılan)</option>
              <option value="quick_note">Doğrudan Boş Not Aç</option>
              <option value="voice_record">Doğrudan Ses Kaydı Başlat</option>
              <option value="mindmap">Zihin Haritasına Git</option>
              <option value="vault">Şifreli Kasayı Aç</option>
              <option value="radial_menu">Radyal Menüyü Tetikle</option>
            </select>
          </div>

          {/* Button Size */}
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1.5">
            <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
              Buton Boyutu:
            </label>
            <div className="grid grid-cols-3 gap-1">
              {(["compact", "normal", "large"] as const).map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => handleUpdatePlusConfig({ size: sz })}
                  className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                    plusConfig.size === sz
                      ? "bg-teal-600 text-white shadow-xs"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200"
                  }`}
                >
                  {sz === "compact" ? "Küçük" : sz === "normal" ? "Normal" : "Büyük"}
                </button>
              ))}
            </div>
          </div>

          {/* Visual Effect */}
          <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1.5">
            <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
              Görsel Efekt & Aura:
            </label>
            <div className="grid grid-cols-3 gap-1">
              {(["glow", "minimal", "double_ring"] as const).map((eff) => (
                <button
                  key={eff}
                  type="button"
                  onClick={() => handleUpdatePlusConfig({ effect: eff })}
                  className={`py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                    plusConfig.effect === eff
                      ? "bg-teal-600 text-white shadow-xs"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200"
                  }`}
                >
                  {eff === "glow" ? "Parlama" : eff === "minimal" ? "Sade" : "Çift Halka"}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. SIRALANABİLİR & SİLİNEBİLİR TÜM MENÜ KESİTLERİ LİSTESİ                  */}
      {/* ========================================================================= */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
            Sıralama Listesi (Sırayı değiştirmek için okları veya kısayolları kullanın)
          </span>
          <span className="text-xs text-slate-400">
            Toplam: {menuOrder.length} Öğe
          </span>
        </div>

        {menuOrder.map((tabId, index) => {
          const sectionInfo: MenuSectionCatalogItem = ALL_MENU_SECTIONS_CATALOG.find((s) => s.id === tabId) || {
            id: tabId,
            title: tabId,
            desc: "Menü kesiti",
            category: "core",
            icon: <StickyNote className="w-4 h-4 text-slate-500" />,
            colorClass: "border-slate-200 text-slate-700",
            badge: undefined,
          };
          const isFirst = index === 0;
          const isLast = index === menuOrder.length - 1;
          const isPlus = tabId === "plus_action";

          return (
            <div
              key={tabId}
              className={`p-3 sm:p-3.5 rounded-2xl border transition-all shadow-xs flex items-center justify-between gap-3 group ${
                isPlus
                  ? "border-teal-400/80 bg-teal-50/40 dark:bg-teal-950/40 hover:border-teal-500 shadow-teal-500/10"
                  : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-indigo-300 dark:hover:border-indigo-800"
              }`}
            >
              {/* Left Rank & Info */}
              <div className="flex items-center gap-3 min-w-0">
                <span
                  className={`w-6 h-6 rounded-lg text-xs font-black font-mono flex items-center justify-center shrink-0 border ${
                    isPlus
                      ? "bg-teal-500 text-white border-teal-600 shadow-xs"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700"
                  }`}
                >
                  {index + 1}
                </span>

                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-2xs ${
                    isPlus
                      ? "bg-gradient-to-tr from-teal-500 to-emerald-500 text-white"
                      : "bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                  }`}
                >
                  {isPlus ? <Plus className="w-5 h-5 stroke-[3]" /> : sectionInfo.icon}
                </div>

                <div className="min-w-0 truncate">
                  <div className="flex items-center gap-2">
                    <h4
                      className={`text-xs sm:text-sm font-black truncate ${
                        isPlus ? "text-teal-900 dark:text-teal-200 font-extrabold" : "text-slate-900 dark:text-white"
                      }`}
                    >
                      {sectionInfo.title}
                    </h4>
                    {sectionInfo.badge && (
                      <span
                        className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded-md ${
                          isPlus
                            ? "bg-teal-500 text-white"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                        }`}
                      >
                        {sectionInfo.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {sectionInfo.desc}
                  </p>
                </div>
              </div>

              {/* Right Action Buttons: Up, Down, Top/Bottom, Delete */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => handleMoveToTop(index)}
                  disabled={isFirst}
                  className="hidden sm:flex w-7 h-7 rounded-lg bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 items-center justify-center text-[10px] font-bold text-slate-500 dark:text-slate-400 disabled:opacity-20 disabled:pointer-events-none transition-colors cursor-pointer"
                  title="En Başa (Sola) Al"
                >
                  ⇤
                </button>

                <button
                  type="button"
                  onClick={() => handleMoveUp(index)}
                  disabled={isFirst}
                  className="w-8 h-8 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 disabled:opacity-25 disabled:pointer-events-none transition-colors cursor-pointer"
                  title="Yukarı Taşı"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => handleMoveDown(index)}
                  disabled={isLast}
                  className="w-8 h-8 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 disabled:opacity-25 disabled:pointer-events-none transition-colors cursor-pointer"
                  title="Aşağı Taşı"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => handleMoveToBottom(index)}
                  disabled={isLast}
                  className="hidden sm:flex w-7 h-7 rounded-lg bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 items-center justify-center text-[10px] font-bold text-slate-500 dark:text-slate-400 disabled:opacity-20 disabled:pointer-events-none transition-colors cursor-pointer"
                  title="En Sona (Sağa) Al"
                >
                  ⇥
                </button>

                {/* Delete / Remove Section button */}
                <button
                  type="button"
                  onClick={() => handleRemoveSection(tabId)}
                  className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/50 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 flex items-center justify-center transition-colors cursor-pointer ml-1"
                  title="Navigasyon Çubuğundan Sil / Çıkar"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* 5. ADD SECTION / EXTENDED FEATURES MODAL                                   */}
      {/* ========================================================================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[85vh] flex flex-col animate-in slide-in-from-bottom-3 duration-200">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white">
                    Navigasyon Çubuğuna Kesit / Araç Ekle
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Eklemek istediğiniz menü aracını veya yeni özelliği seçin.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Category Filter & Search */}
            <div className="p-3.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Kesit, araç veya özellik ara..."
                  className="w-full pl-9 pr-4 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
                {(
                  [
                    { id: "all", label: "Tümü" },
                    { id: "core", label: "Temel Sekmeler" },
                    { id: "action", label: "Hızlı Eylemler" },
                    { id: "smart", label: "Akıllı / AI" },
                  ] as const
                ).map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setSelectedCatalogCategory(c.id)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                      selectedCatalogCategory === c.id
                        ? "bg-indigo-600 text-white"
                        : "bg-slate-200/70 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-300 dark:hover:bg-slate-700"
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            {/* List of Available Sections to Add */}
            <div className="p-4 overflow-y-auto flex-1 space-y-2 max-h-[50vh]">
              {filteredHiddenSections.length === 0 ? (
                <div className="text-center py-8 space-y-2">
                  <Check className="w-8 h-8 text-emerald-500 mx-auto" />
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Tüm kesitler ve araçlar şu anda navigasyon çubuğunuzda aktif!
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Gelecekte eklenecek her yeni özellik bu kütüphanede otomatik listelenecektir.
                  </p>
                </div>
              ) : (
                filteredHiddenSections.map((sec) => (
                  <div
                    key={sec.id}
                    className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-indigo-300 dark:hover:border-indigo-800 flex items-center justify-between gap-3 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center shrink-0">
                        {sec.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">
                            {sec.title}
                          </h4>
                          {sec.badge && (
                            <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                              {sec.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {sec.desc}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleAddSection(sec.id)}
                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0 shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Ekle</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
