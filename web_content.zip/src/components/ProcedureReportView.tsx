import React, { useState, useRef } from 'react';
import {
  FileText,
  Plus,
  Search,
  Printer,
  Download,
  FileSpreadsheet,
  Edit2,
  Trash2,
  Camera,
  Upload,
  CheckCircle2,
  XCircle,
  Clock,
  Layers,
  Image as ImageIcon,
  Check,
  AlertTriangle,
  X,
  Loader2,
  Share2,
  ArrowLeft,
  Home,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  PenTool,
  Type,
  AlignLeft,
  Copy,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  Calendar,
  User,
  Tag
} from 'lucide-react';
import {
  ProcedureReport,
  ProcedureBlock,
  ProcedureBlockType,
  ProcedureCategory,
  MaintenancePlantLine
} from '../types/domain';
import { compressImage } from '../services/storage';
import { exportProcedureToExcel, generateProcedureExcelBlob } from '../services/industryStorage';
import { downloadElementAsPdf, printHtmlSafely, generateElementPdfBlob } from '../utils/pdfGenerator';
import { ShareFileModal } from './ShareFileModal';
import { FingerSignatureCanvas } from './FingerSignatureCanvas';

interface Props {
  reports: ProcedureReport[];
  onSaveReport: (report: ProcedureReport) => void;
  onDeleteReport: (id: string) => void;
  onOpenPhotoLightbox: (url: string, caption: string, title: string, tag?: string) => void;
  onBackToMenu?: () => void;
}

const CATEGORIES: string[] = [
  'Procedura Operativa',
  'Scheda Tecnica Libera',
  'Report Fotografico Ispezione',
  'Istruzione di Lavoro',
  'Verbale di Consegna & Firma',
  'Non Conformità & Riparazione',
  'Altro'
];

/**
 * Normalizes legacy reports into the free-form block system
 */
function getReportBlocks(report: ProcedureReport): ProcedureBlock[] {
  if (report.blocks && report.blocks.length > 0) {
    return report.blocks;
  }
  const blocks: ProcedureBlock[] = [];
  if (report.scope) {
    blocks.push({
      id: 'legacy-scope',
      type: 'text',
      bodyText: report.scope
    });
  }
  (report.steps || []).forEach((s, sIdx) => {
    blocks.push({
      id: `legacy-step-title-${sIdx}`,
      type: 'title',
      titleText: s.title,
      subtitleText: s.checkpoints ? `Criteri: ${s.checkpoints}` : undefined
    });
    if (s.description) {
      blocks.push({
        id: `legacy-step-text-${sIdx}`,
        type: 'text',
        bodyText: s.description
      });
    }
    (s.images || []).forEach((img, iIdx) => {
      blocks.push({
        id: `legacy-step-img-${sIdx}-${iIdx}`,
        type: 'photo',
        photoUrl: img.url,
        photoCaption: img.caption,
        photoTag: img.tag
      });
    });
  });
  return blocks;
}

export const ProcedureReportView: React.FC<Props> = ({
  reports,
  onSaveReport,
  onDeleteReport,
  onOpenPhotoLightbox,
  onBackToMenu
}) => {
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedReport, setSelectedReport] = useState<ProcedureReport | null>(reports[0] || null);

  // Form modal state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<ProcedureReport | null>(null);

  // Sharing & PDF states
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const sheetRef = useRef<HTMLDivElement>(null);

  // Filtered reports
  const filteredReports = reports.filter((r) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.title.toLowerCase().includes(q) ||
      r.code.toLowerCase().includes(q) ||
      (r.client && r.client.toLowerCase().includes(q)) ||
      (r.jobOrder && r.jobOrder.toLowerCase().includes(q)) ||
      (r.author && r.author.toLowerCase().includes(q)) ||
      (r.category && r.category.toLowerCase().includes(q))
    );
  });

  const handleCreateNew = () => {
    setEditingReport(null);
    setIsFormOpen(true);
  };

  const handleEdit = (report: ProcedureReport) => {
    setEditingReport(report);
    setIsFormOpen(true);
  };

  const handleDuplicate = (report: ProcedureReport) => {
    const blocks = getReportBlocks(report);
    const duplicated: ProcedureReport = {
      ...report,
      id: `proc-${Date.now()}`,
      code: `${report.code}-COPIA`,
      title: `${report.title} (Copia)`,
      date: new Date().toISOString().slice(0, 10),
      status: 'bozza',
      blocks: blocks.map((b) => ({ ...b, id: `block-${Date.now()}-${Math.random().toString(36).substr(2, 6)}` })),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    onSaveReport(duplicated);
    setSelectedReport(duplicated);
    setViewMode('detail');
    setActionFeedback('Scheda duplicata con successo.');
    setTimeout(() => setActionFeedback(null), 3000);
  };

  const handleDelete = (report: ProcedureReport) => {
    if (window.confirm(`Eliminare definitivamente la scheda "${report.title}"?`)) {
      onDeleteReport(report.id);
      const remaining = reports.filter((r) => r.id !== report.id);
      setSelectedReport(remaining[0] || null);
      if (remaining.length === 0) {
        setViewMode('list');
      }
      setActionFeedback('Scheda eliminata.');
      setTimeout(() => setActionFeedback(null), 3000);
    }
  };

  // Excel Export
  const handleExportExcel = (report: ProcedureReport) => {
    exportProcedureToExcel(report);
    setActionFeedback('Scheda esportata in Excel (.xls).');
    setTimeout(() => setActionFeedback(null), 3000);
  };

  // PDF Download
  const handleDownloadPdf = async (report: ProcedureReport) => {
    if (!sheetRef.current) return;
    setIsGeneratingPdf(true);
    setActionFeedback('Generazione PDF in corso...');
    try {
      const safeName = `Scheda_${report.code.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
      await downloadElementAsPdf(sheetRef.current, safeName);
      setActionFeedback('PDF scaricato con successo.');
    } catch (err) {
      console.error(err);
      if (sheetRef.current) {
        printHtmlSafely(sheetRef.current.innerHTML, `${report.code} - ${report.title}`);
      }
    } finally {
      setIsGeneratingPdf(false);
      setTimeout(() => setActionFeedback(null), 3000);
    }
  };

  // Native Print
  const handleNativePrint = (report: ProcedureReport) => {
    if (sheetRef.current) {
      printHtmlSafely(sheetRef.current.innerHTML, `${report.code} - ${report.title}`);
    } else {
      window.print();
    }
  };

  const activeBlocks = selectedReport ? getReportBlocks(selectedReport) : [];

  return (
    <div className="space-y-6 pb-16 sm:pb-0">
      {/* Mobile Top Back Banner for Google Pixel 9 */}
      {onBackToMenu && (
        <div className="flex items-center justify-between bg-neutral-900 text-white px-3.5 py-2.5 rounded-2xl shadow-sm md:hidden">
          <button
            onClick={onBackToMenu}
            className="inline-flex items-center gap-2 text-xs font-bold hover:text-amber-300 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← Torna al Menù Principale</span>
          </button>
          <span className="text-[10px] font-mono text-neutral-400">Google Pixel 9</span>
        </div>
      )}

      {/* Top Banner (no-print) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-neutral-200 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-neutral-900">
              Procedure & Schede Libere
            </h1>
            <span className="text-[11px] font-mono font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-200">
              Compositore Libero
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-0.5">
            Crea schede tecniche e relazioni con titoli, foto, didascalie e firme col dito in qualsiasi ordine e quantità, esportabili in PDF ed Excel.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleCreateNew}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-xl transition-colors whitespace-nowrap shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Nuova Scheda Libera</span>
          </button>
        </div>
      </div>

      {/* Action feedback */}
      {actionFeedback && (
        <div className="p-3 bg-neutral-900 text-white text-xs rounded-xl flex items-center justify-between no-print shadow-sm">
          <div className="flex items-center gap-2">
            {isGeneratingPdf ? (
              <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
            ) : (
              <Check className="w-4 h-4 text-emerald-400" />
            )}
            <span>{actionFeedback}</span>
          </div>
          <button onClick={() => setActionFeedback(null)} className="text-neutral-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* VIEW MODE CONDITIONAL: LISTATA PRINCIPALE O DETTAGLIO */}
      {viewMode === 'list' ? (
        /* ================= LISTATA PRINCIPALE (A PIENO SCHERMO) ================= */
        <div className="space-y-4 max-w-4xl mx-auto no-print">
          {/* Search Bar & Controls */}
          <div className="bg-white border border-neutral-200 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cerca per titolo scheda, codice, cliente, autore o note..."
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-neutral-50 border border-neutral-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900 text-neutral-900"
                />
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-2 text-xs font-mono text-neutral-600">
                <span className="bg-neutral-100 px-3 py-1.5 rounded-xl font-semibold">
                  {filteredReports.length} {filteredReports.length === 1 ? 'Scheda' : 'Schede'}
                </span>
                <button
                  type="button"
                  onClick={handleCreateNew}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Nuova Scheda</span>
                </button>
              </div>
            </div>
          </div>

          {/* List of Procedure Cards */}
          <div className="space-y-3">
            {filteredReports.length === 0 ? (
              <div className="p-10 bg-white border border-neutral-200 rounded-3xl text-center space-y-3 shadow-xs">
                <FileText className="w-10 h-10 text-neutral-300 mx-auto" />
                <h3 className="text-sm font-bold text-neutral-800">Nessuna Scheda o Procedura trovata</h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                  Crea una procedura libera personalizzata inserendo titoli, foto, didascalie e firme touch secondo le tue esigenze.
                </p>
                <button
                  type="button"
                  onClick={handleCreateNew}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Crea la prima Scheda Libera</span>
                </button>
              </div>
            ) : (
              filteredReports.map((r) => {
                const blocks = getReportBlocks(r);
                const titleCount = blocks.filter((b) => b.type === 'title').length;
                const photoCount = blocks.filter((b) => b.type === 'photo').length;
                const textCount = blocks.filter((b) => b.type === 'text').length;
                const signCount = blocks.filter((b) => b.type === 'signature').length;

                return (
                  <div
                    key={r.id}
                    onClick={() => {
                      setSelectedReport(r);
                      setViewMode('detail');
                    }}
                    className="bg-white border border-neutral-200 hover:border-neutral-400 rounded-2xl p-4 sm:p-5 shadow-xs hover:shadow-md transition-all cursor-pointer group"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-neutral-100">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs sm:text-sm font-bold text-neutral-900 bg-neutral-100 px-2.5 py-1 rounded-lg border border-neutral-200">
                          {r.code}
                        </span>
                        <span className="text-[11px] font-mono text-neutral-500">
                          📅 {r.date}
                        </span>
                        <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-900 border border-emerald-200">
                          {r.category || 'Procedura'}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 self-start sm:self-auto">
                        <span className="text-[10px] font-mono text-neutral-500">
                          {r.revision || 'Rev. 00'}
                        </span>
                      </div>
                    </div>

                    <div className="py-2.5 space-y-1">
                      <h3 className="text-sm sm:text-base font-extrabold text-neutral-900 group-hover:text-emerald-700 transition-colors">
                        {r.title}
                      </h3>
                      {(r.client || r.author) && (
                        <p className="text-xs text-neutral-600">
                          {r.client ? `Cliente/Progetto: ${r.client}` : ''}
                          {r.client && r.author ? ' · ' : ''}
                          {r.author ? `Compilatore: ${r.author}` : ''}
                        </p>
                      )}
                    </div>

                    {/* Blocks summary pills */}
                    <div className="pt-2.5 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium flex-wrap">
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <Type className="w-3 h-3 text-neutral-700" />
                          {titleCount} Titoli
                        </span>
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <ImageIcon className="w-3 h-3 text-neutral-700" />
                          {photoCount} Foto
                        </span>
                        <span className="inline-flex items-center gap-1 bg-neutral-100 px-2 py-0.5 rounded-md text-[11px]">
                          <AlignLeft className="w-3 h-3 text-neutral-700" />
                          {textCount} Testi
                        </span>
                        {signCount > 0 && (
                          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-md text-[11px] font-bold">
                            <PenTool className="w-3 h-3 text-emerald-600" />
                            {signCount} {signCount === 1 ? 'Firma' : 'Firme'}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                        {/* Instant WhatsApp / App Share Button */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReport(r);
                            setIsShareModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                          title="Condividi subito questa scheda su WhatsApp o altre App"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Condividi</span>
                        </button>

                        {/* Open Report Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedReport(r);
                            setViewMode('detail');
                          }}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                        >
                          <span>Apri Scheda</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        /* ================= DETTAGLIO SCHEDA A PIENO SCHERMO ================= */
        <div className="space-y-4 max-w-5xl mx-auto">
          {/* Top Back Navigation Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-neutral-900 text-white p-3 rounded-2xl shadow-sm no-print">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition-colors"
              >
                <ArrowLeft className="w-4 h-4 text-amber-400" />
                <span>← Torna all'Elenco Schede</span>
              </button>

              {onBackToMenu && (
                <button
                  type="button"
                  onClick={onBackToMenu}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-neutral-300 hover:text-white text-xs font-medium transition-colors"
                >
                  <Home className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Menù Principale</span>
                </button>
              )}
            </div>

            {selectedReport && (
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-neutral-400 hidden sm:inline">Scheda:</span>
                <span className="bg-neutral-800 text-emerald-300 font-bold px-2.5 py-1 rounded-lg">
                  {selectedReport.code}
                </span>
              </div>
            )}
          </div>

          {selectedReport ? (
            <>
              {/* Document Action Bar (no-print) */}
              <div className="bg-white border border-neutral-200 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3 no-print shadow-xs">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-neutral-900 bg-neutral-100 px-2 py-0.5 rounded">
                    {selectedReport.code}
                  </span>
                  <span className="text-xs font-bold text-neutral-800 truncate max-w-xs">
                    {selectedReport.title}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Share on WhatsApp / Native Android Share Sheet */}
                  <button
                    onClick={() => setIsShareModalOpen(true)}
                    title="Condividi PDF o Excel su WhatsApp o altre App"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-xl transition-colors shadow-xs"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>Condividi su WhatsApp o altre App</span>
                  </button>

                  {/* Export Formatted Excel (.xls) */}
                  <button
                    onClick={() => handleExportExcel(selectedReport)}
                    title="Esporta foglio Excel formattato con tutti i blocchi"
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-xl transition-colors"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    <span>Esporta Excel (.xls)</span>
                  </button>

                  {/* Direct PDF Download */}
                  <button
                    onClick={() => handleDownloadPdf(selectedReport)}
                    disabled={isGeneratingPdf}
                    title="Genera e scarica file PDF in alta risoluzione"
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-xl transition-colors disabled:opacity-50"
                  >
                    {isGeneratingPdf ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    <span>{isGeneratingPdf ? 'Creazione PDF...' : 'Scarica PDF'}</span>
                  </button>

                  {/* Native Print Dialog */}
                  <button
                    onClick={() => handleNativePrint(selectedReport)}
                    title="Stampa documento ufficiale"
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-xl transition-colors"
                  >
                    <Printer className="w-4 h-4" />
                    <span className="hidden sm:inline">Stampa</span>
                  </button>

                  {/* Edit Form Modal */}
                  <button
                    onClick={() => handleEdit(selectedReport)}
                    title="Modifica blocchi e contenuti"
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-xl transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                    <span>Modifica</span>
                  </button>

                  {/* Duplicate */}
                  <button
                    onClick={() => handleDuplicate(selectedReport)}
                    title="Duplica questa scheda"
                    className="p-2 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-xl transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                  </button>

                  {/* Delete */}
                  <button
                    onClick={() => handleDelete(selectedReport)}
                    title="Elimina scheda"
                    className="p-2 text-neutral-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Printable / Viewable Document Container */}
              <div
                ref={sheetRef}
                className="bg-white border border-neutral-300 rounded-2xl shadow-sm p-4 sm:p-8 space-y-6 printable-report"
              >
                {/* Document Official Header */}
                <div className="border-b-2 border-neutral-900 pb-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl sm:text-2xl font-black tracking-tight text-neutral-900">
                          SFILLER
                        </span>
                        <span className="text-xs font-mono font-bold text-neutral-600 px-2 py-0.5 rounded bg-neutral-100 border border-neutral-200">
                          SCHEDA TECNICA & PROCEDURA LIBERA
                        </span>
                      </div>
                      <h2 className="text-lg sm:text-xl font-bold text-neutral-900 mt-1">
                        {selectedReport.title}
                      </h2>
                    </div>

                    <div className="text-right sm:self-start bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 text-xs font-mono shrink-0">
                      <div>
                        Codice: <strong>{selectedReport.code}</strong>
                      </div>
                      <div>
                        Data: <strong>{selectedReport.date}</strong>
                      </div>
                      {selectedReport.revision && (
                        <div className="text-neutral-500">
                          {selectedReport.revision}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Document metadata chips */}
                  <div className="flex flex-wrap gap-2 text-xs pt-1">
                    {selectedReport.category && (
                      <span className="bg-neutral-100 text-neutral-800 px-2.5 py-1 rounded-lg font-medium">
                        📂 {selectedReport.category}
                      </span>
                    )}
                    {selectedReport.author && (
                      <span className="bg-neutral-100 text-neutral-800 px-2.5 py-1 rounded-lg font-medium">
                        👤 Compilatore: {selectedReport.author}
                      </span>
                    )}
                    {selectedReport.client && (
                      <span className="bg-neutral-100 text-neutral-800 px-2.5 py-1 rounded-lg font-medium">
                        🏢 Cliente: {selectedReport.client}
                      </span>
                    )}
                    {selectedReport.jobOrder && (
                      <span className="bg-neutral-100 text-neutral-800 px-2.5 py-1 rounded-lg font-medium">
                        🏷️ Commessa: {selectedReport.jobOrder}
                      </span>
                    )}
                  </div>
                </div>

                {/* THE BLOCKS (RENDERED IN EXACT SEQUENTIAL ORDER) */}
                <div className="space-y-6 pt-2">
                  {activeBlocks.length === 0 ? (
                    <div className="p-8 text-center border-2 border-dashed border-neutral-200 rounded-2xl text-neutral-400 text-xs">
                      Nessun blocco inserito in questo documento. Clicca &quot;Modifica&quot; per aggiungere titoli, foto, testi o firme col dito.
                    </div>
                  ) : (
                    activeBlocks.map((block, idx) => {
                      if (block.type === 'title') {
                        return (
                          <div key={block.id || idx} className="pt-2">
                            <div className="flex items-center gap-2 pb-2 border-b-2 border-neutral-800">
                              <span className="w-2.5 h-2.5 rounded-full bg-neutral-900" />
                              <h3 className="text-base sm:text-lg font-extrabold text-neutral-900 tracking-tight">
                                {block.titleText || 'Titolo Sezione'}
                              </h3>
                            </div>
                            {block.subtitleText && (
                              <p className="text-xs text-neutral-500 font-medium mt-1">
                                {block.subtitleText}
                              </p>
                            )}
                          </div>
                        );
                      }

                      if (block.type === 'text') {
                        return (
                          <div key={block.id || idx} className="text-xs sm:text-sm text-neutral-800 leading-relaxed bg-neutral-50/50 p-4 rounded-xl border border-neutral-200/60 whitespace-pre-line">
                            {block.bodyText || ''}
                          </div>
                        );
                      }

                      if (block.type === 'photo') {
                        return (
                          <div key={block.id || idx} className="space-y-2">
                            {block.photoUrl ? (
                              <div className="border border-neutral-300 rounded-2xl overflow-hidden shadow-xs bg-neutral-100">
                                <div
                                  className="relative aspect-16/9 sm:aspect-2/1 cursor-pointer bg-neutral-900"
                                  onClick={() =>
                                    onOpenPhotoLightbox(
                                      block.photoUrl!,
                                      block.photoCaption || '',
                                      selectedReport.title,
                                      block.photoTag
                                    )
                                  }
                                >
                                  <img
                                    src={block.photoUrl}
                                    alt={block.photoCaption || 'Foto rilievo'}
                                    referrerPolicy="no-referrer"
                                    className="w-full h-full object-contain"
                                  />
                                  {block.photoTag && (
                                    <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-md bg-neutral-900/80 text-white font-mono text-[10px] font-bold">
                                      {block.photoTag}
                                    </div>
                                  )}
                                </div>
                                {block.photoCaption && (
                                  <div className="p-3 bg-neutral-50 border-t border-neutral-200 text-xs text-neutral-800 font-medium">
                                    📸 <strong>Didascalia:</strong> {block.photoCaption}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <div className="p-4 bg-neutral-50 border border-dashed border-neutral-300 rounded-xl text-center text-xs text-neutral-400">
                                Nessuna immagine caricata per questo blocco fotografico.
                              </div>
                            )}
                          </div>
                        );
                      }

                      if (block.type === 'signature') {
                        return (
                          <div key={block.id || idx} className="bg-neutral-50 border border-neutral-300 rounded-2xl p-4 space-y-2">
                            <div className="flex items-center justify-between pb-2 border-b border-neutral-200 text-xs">
                              <span className="font-bold text-neutral-800 uppercase tracking-wide flex items-center gap-1.5">
                                <PenTool className="w-3.5 h-3.5 text-neutral-700" />
                                Spazio Firma con il Dito
                              </span>
                              <span className="text-[11px] font-mono text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full font-semibold">
                                ✓ Acquisita Touch
                              </span>
                            </div>

                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
                              {block.signatureDataUrl ? (
                                <div className="bg-white border border-neutral-300 rounded-xl p-2 max-w-xs shadow-inner">
                                  <img
                                    src={block.signatureDataUrl}
                                    alt="Firma con il dito"
                                    className="h-20 w-auto object-contain mx-auto"
                                  />
                                </div>
                              ) : (
                                <div className="h-20 flex items-center justify-center border-2 border-dashed border-neutral-300 rounded-xl text-xs text-neutral-400 italic px-6">
                                  Nessun tratto firma disegnato
                                </div>
                              )}

                              <div className="text-xs space-y-1">
                                <div>
                                  <span className="text-neutral-500 block text-[10px] uppercase font-bold">Firmatario:</span>
                                  <strong className="text-neutral-900 text-sm">{block.signerName || 'Non specificato'}</strong>
                                </div>
                                <div>
                                  <span className="text-neutral-500 block text-[10px] uppercase font-bold">Ruolo:</span>
                                  <span className="text-neutral-800">{block.signerRole || 'Operatore'}</span>
                                </div>
                                <div>
                                  <span className="text-neutral-500 block text-[10px] uppercase font-bold">Data Apposizione:</span>
                                  <span className="font-mono text-neutral-700">{block.signedAt || selectedReport.date}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      }

                      return null;
                    })
                  )}
                </div>

                {/* Footer Reference */}
                <div className="pt-6 border-t border-neutral-200 text-[10px] text-neutral-400 flex flex-wrap justify-between items-center gap-2 font-mono">
                  <span>SFILLER · Sistema di Gestione Schede & Procedure Libere</span>
                  <span>Generato: {new Date().toLocaleDateString('it-IT')}</span>
                </div>
              </div>
            </>
          ) : (
            <div className="p-12 bg-white border border-neutral-200 rounded-2xl text-center space-y-3">
              <FileText className="w-10 h-10 text-neutral-400 mx-auto" />
              <h3 className="text-sm font-semibold text-neutral-900">
                Nessuna Scheda Selezionata
              </h3>
              <button
                onClick={() => setViewMode('list')}
                className="px-4 py-2 text-xs font-semibold text-white bg-neutral-900 rounded-xl"
              >
                Torna all'Elenco Schede
              </button>
            </div>
          )}
        </div>
      )}

      {/* Share Modal (WhatsApp / Android Share) */}
      {selectedReport && (
        <ShareFileModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          title={`Scheda ${selectedReport.title}`}
          subtitle={`${selectedReport.category || 'Procedura'} · ${selectedReport.code}`}
          codeOrNumber={selectedReport.code}
          getPdfBlob={() => generateElementPdfBlob(sheetRef.current!)}
          getExcelBlob={() => generateProcedureExcelBlob(selectedReport)}
        />
      )}

      {/* Dynamic Free-Form Procedure Modal Editor */}
      {isFormOpen && (
        <FreeformProcedureFormModal
          isOpen={isFormOpen}
          initialReport={editingReport}
          onClose={() => {
            setIsFormOpen(false);
            setEditingReport(null);
          }}
          onSave={(saved) => {
            onSaveReport(saved);
            setSelectedReport(saved);
            setViewMode('detail');
            setIsFormOpen(false);
            setEditingReport(null);
            setActionFeedback('Scheda salvata con successo.');
            setTimeout(() => setActionFeedback(null), 3000);
          }}
        />
      )}

      {/* Google Pixel 9 Mobile Sticky Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-neutral-200 p-2 sm:hidden z-40 flex items-center justify-around gap-1 shadow-lg">
        {viewMode === 'detail' ? (
          <>
            <button
              onClick={() => setViewMode('list')}
              className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
            >
              <ArrowLeft className="w-4 h-4 mb-0.5 text-amber-600" />
              <span>← Elenco</span>
            </button>
            {selectedReport && (
              <button
                onClick={() => setIsShareModalOpen(true)}
                className="flex flex-col items-center justify-center py-1 px-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-emerald-700"
              >
                <Share2 className="w-4 h-4 mb-0.5" />
                <span>Condividi</span>
              </button>
            )}
            <button
              onClick={handleCreateNew}
              className="flex flex-col items-center justify-center py-1 px-3 bg-neutral-900 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-black"
            >
              <Plus className="w-4 h-4 mb-0.5" />
              <span>Nuova</span>
            </button>
            {selectedReport && (
              <button
                onClick={() => handleExportExcel(selectedReport)}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-emerald-800 active:bg-emerald-50 rounded-lg"
              >
                <FileSpreadsheet className="w-4 h-4 mb-0.5" />
                <span>Excel</span>
              </button>
            )}
            {selectedReport && (
              <button
                onClick={() => handleDownloadPdf(selectedReport)}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-800 active:bg-neutral-100 rounded-lg"
              >
                <Download className="w-4 h-4 mb-0.5" />
                <span>PDF</span>
              </button>
            )}
          </>
        ) : (
          <>
            {onBackToMenu && (
              <button
                onClick={onBackToMenu}
                className="flex flex-col items-center justify-center py-1 px-2.5 text-[10px] font-bold text-neutral-700 active:text-neutral-900"
              >
                <Home className="w-4 h-4 mb-0.5" />
                <span>Menù</span>
              </button>
            )}
            {reports.length > 0 && (
              <button
                onClick={() => {
                  setSelectedReport(reports[0]);
                  setIsShareModalOpen(true);
                }}
                className="flex flex-col items-center justify-center py-1 px-3 bg-emerald-600 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-emerald-700"
              >
                <Share2 className="w-4 h-4 mb-0.5" />
                <span>Condividi</span>
              </button>
            )}
            <button
              onClick={handleCreateNew}
              className="flex flex-col items-center justify-center py-1 px-3 bg-neutral-900 text-white rounded-xl text-[10px] font-bold shadow-xs active:bg-black"
            >
              <Plus className="w-4 h-4 mb-0.5" />
              <span>+ Nuova</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};

// ======================== MODAL BUILDER PER SCHEDE LIBERE ========================

interface FormProps {
  isOpen: boolean;
  initialReport: ProcedureReport | null;
  onClose: () => void;
  onSave: (report: ProcedureReport) => void;
}

const FreeformProcedureFormModal: React.FC<FormProps> = ({
  isOpen,
  initialReport,
  onClose,
  onSave
}) => {
  const [title, setTitle] = useState(initialReport?.title || '');
  const [code, setCode] = useState(initialReport?.code || `SCHEDA-${Date.now().toString().slice(-4)}`);
  const [date, setDate] = useState(initialReport?.date || new Date().toISOString().slice(0, 10));
  const [category, setCategory] = useState(initialReport?.category || 'Procedura Operativa');
  const [author, setAuthor] = useState(initialReport?.author || 'M. Preato');
  const [client, setClient] = useState(initialReport?.client || '');
  const [jobOrder, setJobOrder] = useState(initialReport?.jobOrder || '');

  // The dynamic customizable blocks in user-chosen order
  const [blocks, setBlocks] = useState<ProcedureBlock[]>(() => {
    if (initialReport) {
      return getReportBlocks(initialReport);
    }
    // Default starter blocks for a fresh procedure
    return [
      {
        id: `blk-${Date.now()}-1`,
        type: 'title',
        titleText: '1. Scopo e Descrizione Operativa'
      },
      {
        id: `blk-${Date.now()}-2`,
        type: 'text',
        bodyText: 'Inserisci qui la descrizione libera, i parametri o le note operative...'
      }
    ];
  });

  if (!isOpen) return null;

  // Add block handlers
  const handleAddBlock = (type: ProcedureBlockType) => {
    const newId = `blk-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    let newBlock: ProcedureBlock;

    if (type === 'title') {
      newBlock = {
        id: newId,
        type: 'title',
        titleText: 'Nuova Sezione / Titolo',
        subtitleText: ''
      };
    } else if (type === 'text') {
      newBlock = {
        id: newId,
        type: 'text',
        bodyText: ''
      };
    } else if (type === 'photo') {
      newBlock = {
        id: newId,
        type: 'photo',
        photoUrl: '',
        photoCaption: '',
        photoTag: 'Dettaglio'
      };
    } else {
      newBlock = {
        id: newId,
        type: 'signature',
        signatureDataUrl: '',
        signerName: author || '',
        signerRole: 'Operatore',
        signedAt: date
      };
    }

    setBlocks([...blocks, newBlock]);
  };

  const handleMoveBlock = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === blocks.length - 1) return;
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const newBlocks = [...blocks];
    const temp = newBlocks[index];
    newBlocks[index] = newBlocks[targetIdx];
    newBlocks[targetIdx] = temp;
    setBlocks(newBlocks);
  };

  const handleRemoveBlock = (index: number) => {
    setBlocks(blocks.filter((_, i) => i !== index));
  };

  const handleUpdateBlock = (index: number, patch: Partial<ProcedureBlock>) => {
    const newBlocks = [...blocks];
    newBlocks[index] = { ...newBlocks[index], ...patch };
    setBlocks(newBlocks);
  };

  const handlePhotoUpload = async (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImage(file, 1200, 0.8);
      handleUpdateBlock(index, { photoUrl: compressed.dataUrl });
    } catch (err) {
      console.error('Errore compressione foto:', err);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Inserisci il titolo della scheda');
      return;
    }

    const saved: ProcedureReport = {
      id: initialReport?.id || `proc-${Date.now()}`,
      code: code.trim() || `SCHEDA-${Date.now().toString().slice(-4)}`,
      title: title.trim(),
      category,
      client: client.trim() || undefined,
      jobOrder: jobOrder.trim() || undefined,
      date,
      revision: initialReport?.revision || 'Rev. 00',
      status: initialReport?.status || 'approvato',
      author: author.trim() || 'Operatore',
      blocks,
      createdAt: initialReport?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSave(saved);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-neutral-200 overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-900 text-white shrink-0">
          <div>
            <h2 className="text-base sm:text-lg font-bold">
              {initialReport ? 'Modifica Scheda / Procedura' : 'Crea Nuova Scheda Libera'}
            </h2>
            <p className="text-xs text-neutral-400">
              Aggiungi e ordina i campi a piacere: titoli, foto con didascalia, testo libero e firma con il dito
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Scroll Area */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Header Metadata Section */}
          <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-bold text-neutral-800 uppercase tracking-wide">
              Dati Generali Documento
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Titolo della Scheda / Procedura *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="es. Procedura Ispezione Saldature, Verbale Collaudo..."
                  className="w-full text-xs sm:text-sm px-3 py-2 bg-white border border-neutral-300 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900 font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Codice / Riferimento
                </label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="es. DOC-2026-004"
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-xl font-mono focus:outline-none focus:ring-1 focus:ring-neutral-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Data Documento
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Tipologia / Categoria
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Compilatore / Autore
                </label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="es. M. Preato"
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Cliente (opzionale)
                </label>
                <input
                  type="text"
                  value={client}
                  onChange={(e) => setClient(e.target.value)}
                  placeholder="es. Ansaldo, Baker Hughes..."
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-700 uppercase mb-1">
                  Commessa / Cantiere (opzionale)
                </label>
                <input
                  type="text"
                  value={jobOrder}
                  onChange={(e) => setJobOrder(e.target.value)}
                  placeholder="es. COMM-2026-08"
                  className="w-full text-xs px-3 py-2 bg-white border border-neutral-300 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900 font-mono"
                />
              </div>
            </div>
          </div>

          {/* DYNAMIC BLOCKS SECTION */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-neutral-200">
              <div>
                <h3 className="text-sm font-extrabold text-neutral-900">
                  Composizione Scheda ({blocks.length} {blocks.length === 1 ? 'Blocco' : 'Blocchi'})
                </h3>
                <p className="text-xs text-neutral-500">
                  Aggiungi qualsiasi campo quante volte vuoi e riordinalo con i tasti ↑ / ↓
                </p>
              </div>

              {/* Add Blocks Toolbar */}
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleAddBlock('title')}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-xl transition-colors shadow-2xs"
                >
                  <Type className="w-3.5 h-3.5 text-neutral-700" />
                  <span>+ Titolo</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleAddBlock('photo')}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 rounded-xl transition-colors shadow-2xs"
                >
                  <Camera className="w-3.5 h-3.5 text-sky-600" />
                  <span>+ Foto</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleAddBlock('text')}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-xl transition-colors shadow-2xs"
                >
                  <AlignLeft className="w-3.5 h-3.5 text-neutral-700" />
                  <span>+ Testo</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleAddBlock('signature')}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl transition-colors shadow-2xs"
                >
                  <PenTool className="w-3.5 h-3.5 text-emerald-600" />
                  <span>+ Firma col Dito</span>
                </button>
              </div>
            </div>

            {/* Blocks List */}
            {blocks.length === 0 ? (
              <div className="p-8 text-center border-2 border-dashed border-neutral-300 rounded-2xl text-xs text-neutral-400 space-y-2">
                <p>Nessun blocco presente. Clicca sui pulsanti sopra per aggiungere campi alla scheda.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {blocks.map((block, idx) => {
                  return (
                    <div
                      key={block.id || idx}
                      className="bg-white border-2 border-neutral-200 rounded-2xl p-4 space-y-3 shadow-xs hover:border-neutral-300 transition-all"
                    >
                      {/* Block Control Bar */}
                      <div className="flex items-center justify-between pb-2 border-b border-neutral-100 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[10px] font-bold text-white bg-neutral-900 w-5 h-5 rounded-full flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                              block.type === 'title'
                                ? 'bg-neutral-100 text-neutral-800'
                                : block.type === 'photo'
                                ? 'bg-sky-100 text-sky-800'
                                : block.type === 'text'
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {block.type === 'title' && 'Titolo Sezione'}
                            {block.type === 'photo' && 'Foto & Didascalia'}
                            {block.type === 'text' && 'Testo Libero'}
                            {block.type === 'signature' && 'Firma con il Dito'}
                          </span>
                        </div>

                        {/* Order & Delete Buttons */}
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => handleMoveBlock(idx, 'up')}
                            className="p-1 hover:bg-neutral-100 rounded text-neutral-600 disabled:opacity-30"
                            title="Sposta su"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={idx === blocks.length - 1}
                            onClick={() => handleMoveBlock(idx, 'down')}
                            className="p-1 hover:bg-neutral-100 rounded text-neutral-600 disabled:opacity-30"
                            title="Sposta giù"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveBlock(idx)}
                            className="p-1 hover:bg-rose-50 text-neutral-400 hover:text-rose-600 rounded transition-colors ml-1"
                            title="Rimuovi blocco"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Block Specific Form Fields */}
                      {block.type === 'title' && (
                        <div className="space-y-2 text-xs">
                          <div>
                            <label className="block text-[10px] font-bold text-neutral-600 uppercase mb-1">
                              Testo Titolo / Intestazione
                            </label>
                            <input
                              type="text"
                              value={block.titleText || ''}
                              onChange={(e) => handleUpdateBlock(idx, { titleText: e.target.value })}
                              placeholder="es. Fase 1: Ispezione Visiva e Pulizia"
                              className="w-full text-xs sm:text-sm px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-neutral-900 font-bold"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-neutral-500 uppercase mb-1">
                              Sottotitolo o Note Sezione (opzionale)
                            </label>
                            <input
                              type="text"
                              value={block.subtitleText || ''}
                              onChange={(e) => handleUpdateBlock(idx, { subtitleText: e.target.value })}
                              placeholder="es. Tolleranza accettazione: SSPC-SP 1"
                              className="w-full text-xs px-3 py-1.5 bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-neutral-900"
                            />
                          </div>
                        </div>
                      )}

                      {block.type === 'text' && (
                        <div className="text-xs">
                          <label className="block text-[10px] font-bold text-neutral-600 uppercase mb-1">
                            Testo / Didascalia / Istruzione
                          </label>
                          <textarea
                            rows={3}
                            value={block.bodyText || ''}
                            onChange={(e) => handleUpdateBlock(idx, { bodyText: e.target.value })}
                            placeholder="Scrivi qui qualsiasi nota descrittiva, parametri tecnici, istruzioni operative o rilievi..."
                            className="w-full text-xs sm:text-sm p-3 bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-neutral-900 leading-relaxed"
                          />
                        </div>
                      )}

                      {block.type === 'photo' && (
                        <div className="space-y-3 text-xs">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                            {/* Photo Picker */}
                            <div>
                              <label className="block text-[10px] font-bold text-neutral-600 uppercase mb-1">
                                Immagine Fotografica
                              </label>
                              <div className="relative border-2 border-dashed border-neutral-300 rounded-2xl p-4 text-center hover:bg-neutral-50 transition-colors">
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="environment"
                                  onChange={(e) => handlePhotoUpload(idx, e)}
                                  className="absolute inset-0 opacity-0 cursor-pointer z-10 w-full h-full"
                                />
                                <div className="space-y-1">
                                  <Camera className="w-6 h-6 text-neutral-400 mx-auto" />
                                  <span className="text-xs font-semibold text-neutral-800 block">
                                    {block.photoUrl ? 'Cambia Fotografia' : 'Scatta o Carica Foto'}
                                  </span>
                                  <span className="text-[10px] text-neutral-400 block font-mono">
                                    Fotocamera Pixel 9 o Galleria
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Preview */}
                            <div>
                              {block.photoUrl ? (
                                <div className="relative aspect-16/9 rounded-xl overflow-hidden border border-neutral-300 bg-neutral-900">
                                  <img
                                    src={block.photoUrl}
                                    alt="Anteprima foto"
                                    className="w-full h-full object-contain"
                                  />
                                </div>
                              ) : (
                                <div className="h-28 flex items-center justify-center border border-neutral-200 rounded-xl bg-neutral-50 text-neutral-400 text-xs italic">
                                  Nessuna foto selezionata
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <div className="sm:col-span-2">
                              <label className="block text-[10px] font-bold text-neutral-600 uppercase mb-1">
                                Didascalia Foto
                              </label>
                              <input
                                type="text"
                                value={block.photoCaption || ''}
                                onChange={(e) => handleUpdateBlock(idx, { photoCaption: e.target.value })}
                                placeholder="es. Evidenza pulizia superficiale zona saldata prima della verniciatura..."
                                className="w-full text-xs px-3 py-1.5 bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-neutral-900"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-bold text-neutral-600 uppercase mb-1">
                                Etichetta / Tag
                              </label>
                              <input
                                type="text"
                                value={block.photoTag || ''}
                                onChange={(e) => handleUpdateBlock(idx, { photoTag: e.target.value })}
                                placeholder="es. Prima / Dopo / Dettaglio"
                                className="w-full text-xs px-3 py-1.5 bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-neutral-900"
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      {block.type === 'signature' && (
                        <div>
                          <FingerSignatureCanvas
                            initialSignature={block.signatureDataUrl}
                            initialSignerName={block.signerName || author}
                            initialSignerRole={block.signerRole || 'Operatore'}
                            initialDate={block.signedAt || date}
                            onChange={(sigData) => {
                              handleUpdateBlock(idx, {
                                signatureDataUrl: sigData.signatureDataUrl,
                                signerName: sigData.signerName,
                                signerRole: sigData.signerRole,
                                signedAt: sigData.signedAt
                              });
                            }}
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Quick Add Button Bar at bottom of blocks list */}
          <div className="bg-neutral-50 border-2 border-dashed border-neutral-200 rounded-2xl p-4 text-center space-y-2">
            <span className="text-xs font-bold text-neutral-700 block">
              + Aggiungi un altro blocco a questa scheda
            </span>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                type="button"
                onClick={() => handleAddBlock('title')}
                className="px-3 py-1.5 bg-white border border-neutral-300 hover:border-neutral-900 text-xs font-semibold rounded-xl transition-colors shadow-2xs"
              >
                + Titolo / Sezione
              </button>
              <button
                type="button"
                onClick={() => handleAddBlock('photo')}
                className="px-3 py-1.5 bg-sky-50 border border-sky-300 hover:bg-sky-100 text-sky-800 text-xs font-semibold rounded-xl transition-colors shadow-2xs"
              >
                + Foto con Didascalia
              </button>
              <button
                type="button"
                onClick={() => handleAddBlock('text')}
                className="px-3 py-1.5 bg-white border border-neutral-300 hover:border-neutral-900 text-xs font-semibold rounded-xl transition-colors shadow-2xs"
              >
                + Testo Libero
              </button>
              <button
                type="button"
                onClick={() => handleAddBlock('signature')}
                className="px-3 py-1.5 bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-xl transition-colors shadow-2xs"
              >
                + Firma col Dito
              </button>
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-xl transition-colors"
            >
              Annulla
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-neutral-900 hover:bg-neutral-800 active:bg-black rounded-xl transition-all shadow-md"
            >
              Salva Scheda & Apri
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
