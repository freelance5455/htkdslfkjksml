import React, { useState } from 'react';
import {
  Mic,
  Zap,
  Plus,
  Trash2,
  Play,
  Check,
  X,
  Volume2,
  Sparkles,
  Smartphone,
  Monitor,
  HelpCircle,
  FileText,
  Sliders,
  Settings,
  Search
} from 'lucide-react';
import { VoiceCommandTrigger, VoiceActionType, PersonaType, ToneType } from '../types';

interface VoiceCommandsModalProps {
  isOpen: boolean;
  onClose: () => void;
  triggers: VoiceCommandTrigger[];
  onAddTrigger: (trigger: Omit<VoiceCommandTrigger, 'id'>) => void;
  onToggleTrigger: (id: string) => void;
  onDeleteTrigger: (id: string) => void;
  onTestTrigger: (trigger: VoiceCommandTrigger) => void;
  continuousListening: boolean;
  onToggleContinuousListening: (val: boolean) => void;
  lastExecutedCommand?: { phrase: string; time: number } | null;
}

export const VoiceCommandsModal: React.FC<VoiceCommandsModalProps> = ({
  isOpen,
  onClose,
  triggers,
  onAddTrigger,
  onToggleTrigger,
  onDeleteTrigger,
  onTestTrigger,
  continuousListening,
  onToggleContinuousListening,
  lastExecutedCommand,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newPhrase, setNewPhrase] = useState('');
  const [newAction, setNewAction] = useState<VoiceActionType>('clear_tasks');
  const [newPayload, setNewPayload] = useState('');
  const [newDesc, setNewDesc] = useState('');

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhrase.trim()) {
      alert('Kripya voice trigger phrase enter karein (e.g. "Hey Nova, clear my tasks")');
      return;
    }

    let defaultDesc = newDesc.trim();
    if (!defaultDesc) {
      if (newAction === 'clear_tasks') defaultDesc = 'Clears all pending reminders & phone tasks';
      else if (newAction === 'read_screen') defaultDesc = 'Captures active screen & runs accessibility OCR';
      else if (newAction === 'open_phone_tools') defaultDesc = 'Opens Phone Assistant & device sensors';
      else if (newAction === 'open_screen_reader') defaultDesc = 'Opens Screen Reader & Accessibility panel';
      else if (newAction === 'clear_chat') defaultDesc = 'Clears chat history conversation';
      else if (newAction === 'export_chat') defaultDesc = 'Exports chat history to text file';
      else if (newAction === 'toggle_auto_speak') defaultDesc = 'Toggles speech audio voice auto-speak';
      else if (newAction === 'switch_persona') defaultDesc = `Switches AI persona to ${newPayload || 'Mast AI'}`;
      else if (newAction === 'switch_tone') defaultDesc = `Switches tone to ${newPayload || 'Chatpata'}`;
      else if (newAction === 'send_custom_prompt') defaultDesc = `Sends AI prompt: "${newPayload}"`;
    }

    onAddTrigger({
      phrase: newPhrase.trim(),
      action: newAction,
      actionPayload: newPayload.trim() || undefined,
      description: defaultDesc,
      enabled: true,
      isBuiltIn: false,
    });

    setNewPhrase('');
    setNewPayload('');
    setNewDesc('');
    setShowAddForm(false);
  };

  const getActionBadge = (action: VoiceActionType, payload?: string) => {
    switch (action) {
      case 'wake_greeting':
        return (
          <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> Wake Greeting
          </span>
        );
      case 'open_search':
        return (
          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Search className="w-3 h-3" /> Search History
          </span>
        );
      case 'clear_tasks':
        return (
          <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Trash2 className="w-3 h-3" /> Clear Tasks
          </span>
        );
      case 'read_screen':
        return (
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Monitor className="w-3 h-3" /> Read Screen
          </span>
        );
      case 'open_phone_tools':
        return (
          <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Smartphone className="w-3 h-3" /> Phone Tools
          </span>
        );
      case 'open_screen_reader':
        return (
          <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Sliders className="w-3 h-3" /> Accessibility
          </span>
        );
      case 'clear_chat':
        return (
          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Trash2 className="w-3 h-3" /> Clear Chat
          </span>
        );
      case 'export_chat':
        return (
          <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[11px] font-semibold flex items-center gap-1">
            <FileText className="w-3 h-3" /> Export Chat
          </span>
        );
      case 'toggle_auto_speak':
        return (
          <span className="px-2 py-0.5 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Volume2 className="w-3 h-3" /> Toggle Voice
          </span>
        );
      case 'switch_persona':
        return (
          <span className="px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> Persona: {payload || 'Default'}
          </span>
        );
      case 'switch_tone':
        return (
          <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-semibold flex items-center gap-1">
            <Zap className="w-3 h-3" /> Tone: {payload || 'Default'}
          </span>
        );
      case 'send_custom_prompt':
        return (
          <span className="px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/30 text-[11px] font-semibold flex items-center gap-1 truncate max-w-[150px]">
            <Sparkles className="w-3 h-3" /> Prompt: {payload || 'Custom'}
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-cyan-950/40 via-slate-900 to-violet-950/40 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Mic className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Custom Voice Command Triggers
                <span className="text-xs font-normal px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Wake Phrases
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Define phrases like "Hey Nova, clear my tasks" to trigger instant app actions
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-sm text-slate-200">
          {/* Continuous Voice Wake Word Option */}
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-lg ${
                  continuousListening ? 'bg-emerald-500/20 text-emerald-400 animate-pulse' : 'bg-slate-700/50 text-slate-400'
                }`}
              >
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-white">Continuous Voice Trigger Detection</div>
                <div className="text-xs text-slate-400">
                  When enabled, speaking any registered phrase while mic is active automatically executes the action
                </div>
              </div>
            </div>
            <button
              onClick={() => onToggleContinuousListening(!continuousListening)}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition cursor-pointer ${
                continuousListening ? 'bg-cyan-500 justify-end' : 'bg-slate-700 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-md" />
            </button>
          </div>

          {/* Last Executed Notification */}
          {lastExecutedCommand && (
            <div className="px-3.5 py-2 rounded-xl bg-emerald-950/60 border border-emerald-500/40 flex items-center justify-between text-xs text-emerald-300">
              <span className="flex items-center gap-1.5 font-medium">
                <Check className="w-4 h-4 text-emerald-400" />
                Last Trigger Executed: <strong className="text-white font-mono">"{lastExecutedCommand.phrase}"</strong>
              </span>
              <span className="text-[10px] text-emerald-400/80 font-mono">
                {new Date(lastExecutedCommand.time).toLocaleTimeString()}
              </span>
            </div>
          )}

          {/* Action to add new trigger */}
          {!showAddForm ? (
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Configured Voice Triggers ({triggers.length})
              </span>
              <button
                onClick={() => setShowAddForm(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition cursor-pointer shadow-md"
              >
                <Plus className="w-3.5 h-3.5" /> Define New Trigger
              </button>
            </div>
          ) : (
            /* Add Trigger Form */
            <form
              onSubmit={handleCreate}
              className="p-4 rounded-xl bg-slate-800/90 border border-cyan-500/40 shadow-xl space-y-3 animate-in fade-in"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-cyan-400" /> Define Custom Voice Trigger
                </h3>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="text-slate-400 hover:text-white text-xs cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              {/* Phrase input */}
              <div>
                <label className="text-xs font-medium text-slate-300 mb-1 block">
                  Voice Trigger Phrase (Jo aap bolenge):
                </label>
                <input
                  type="text"
                  placeholder='e.g. "Hey Nova, clear my tasks" or "Nova read screen"'
                  value={newPhrase}
                  onChange={(e) => setNewPhrase(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                  required
                />
              </div>

              {/* Action Dropdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-300 mb-1 block">
                    Execution Action:
                  </label>
                  <select
                    value={newAction}
                    onChange={(e) => {
                      const act = e.target.value as VoiceActionType;
                      setNewAction(act);
                      if (act === 'switch_persona') setNewPayload('coder');
                      else if (act === 'switch_tone') setNewPayload('chatpata');
                      else if (act === 'send_custom_prompt') setNewPayload('Ek mast joke sunao');
                      else setNewPayload('');
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="wake_greeting">✨ Hey Nova Greeting (Wake Audio Reply)</option>
                    <option value="open_search">🔍 Search Chat History & Files</option>
                    <option value="clear_tasks">🧹 Clear Tasks / Reminders</option>
                    <option value="read_screen">🖥️ Capture & Read Screen</option>
                    <option value="open_phone_tools">📱 Open Phone Tools & Sensors</option>
                    <option value="open_screen_reader">👁️ Open Screen Reader Settings</option>
                    <option value="clear_chat">🗑️ Clear Chat History</option>
                    <option value="export_chat">💾 Export Chat</option>
                    <option value="toggle_auto_speak">🔊 Toggle Voice Auto-Speak</option>
                    <option value="switch_persona">🎭 Switch AI Persona</option>
                    <option value="switch_tone">⚡ Switch Response Tone</option>
                    <option value="send_custom_prompt">💬 Send Custom AI Prompt</option>
                  </select>
                </div>

                {/* Conditional Payload Input */}
                <div>
                  {newAction === 'switch_persona' && (
                    <>
                      <label className="text-xs font-medium text-slate-300 mb-1 block">
                        Select Persona:
                      </label>
                      <select
                        value={newPayload || 'mast_friend'}
                        onChange={(e) => setNewPayload(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-500"
                      >
                        <option value="mast_friend">🔥 Mast AI (Dildaar)</option>
                        <option value="coder">💻 Super Coder</option>
                        <option value="screen_accessibility">🖥️ Screen Reader</option>
                        <option value="phone_assistant">📱 Phone Assistant</option>
                        <option value="tutor">🎓 Study Tutor</option>
                        <option value="creative">✨ Creative Storyteller</option>
                      </select>
                    </>
                  )}

                  {newAction === 'switch_tone' && (
                    <>
                      <label className="text-xs font-medium text-slate-300 mb-1 block">
                        Select Tone:
                      </label>
                      <select
                        value={newPayload || 'chatpata'}
                        onChange={(e) => setNewPayload(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-500"
                      >
                        <option value="chatpata">🔥 Mast & Chatpata</option>
                        <option value="concise">⚡ Short & Crisp</option>
                        <option value="detailed">📖 Deep & Detailed</option>
                        <option value="shuddh_hindi">🇮🇳 Hindi</option>
                        <option value="english">🌐 English</option>
                      </select>
                    </>
                  )}

                  {newAction === 'send_custom_prompt' && (
                    <>
                      <label className="text-xs font-medium text-slate-300 mb-1 block">
                        Custom Prompt to send:
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Ek mast joke sunao!"
                        value={newPayload}
                        onChange={(e) => setNewPayload(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-500"
                        required
                      />
                    </>
                  )}

                  {newAction !== 'switch_persona' &&
                    newAction !== 'switch_tone' &&
                    newAction !== 'send_custom_prompt' && (
                      <>
                        <label className="text-xs font-medium text-slate-400 mb-1 block">
                          Optional Description:
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Clear pending tasks from phone"
                          value={newDesc}
                          onChange={(e) => setNewDesc(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-500"
                        />
                      </>
                    )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition cursor-pointer shadow-md"
                >
                  Save Trigger
                </button>
              </div>
            </form>
          )}

          {/* Trigger List */}
          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {triggers.map((trig) => (
              <div
                key={trig.id}
                className={`p-3.5 rounded-xl border transition flex items-center justify-between gap-3 ${
                  trig.enabled
                    ? 'bg-slate-800/60 border-slate-700/80 hover:border-slate-600'
                    : 'bg-slate-900/40 border-slate-800/50 opacity-60'
                }`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-mono font-bold text-white text-xs sm:text-sm bg-slate-900/90 px-2 py-0.5 rounded-md border border-slate-700/60 text-cyan-300">
                      "{trig.phrase}"
                    </span>
                    {getActionBadge(trig.action, trig.actionPayload)}
                    {trig.isBuiltIn && (
                      <span className="text-[10px] text-slate-500 font-medium">Default</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 truncate">{trig.description}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {/* Test button */}
                  <button
                    onClick={() => onTestTrigger(trig)}
                    className="p-1.5 rounded-lg bg-slate-700/60 hover:bg-cyan-600/40 text-slate-300 hover:text-cyan-200 transition cursor-pointer flex items-center gap-1 text-xs"
                    title="Test this trigger action immediately"
                  >
                    <Play className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="hidden sm:inline text-[11px]">Test</span>
                  </button>

                  {/* Enable / Disable */}
                  <button
                    onClick={() => onToggleTrigger(trig.id)}
                    className={`w-9 h-5 flex items-center rounded-full p-0.5 transition cursor-pointer ${
                      trig.enabled ? 'bg-cyan-600 justify-end' : 'bg-slate-700 justify-start'
                    }`}
                    title={trig.enabled ? 'Disable trigger' : 'Enable trigger'}
                  >
                    <div className="w-3.5 h-3.5 rounded-full bg-white shadow-sm" />
                  </button>

                  {/* Delete (if custom) */}
                  {!trig.isBuiltIn && (
                    <button
                      onClick={() => onDeleteTrigger(trig.id)}
                      className="p-1.5 rounded-lg hover:bg-rose-500/20 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                      title="Delete trigger"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Info note */}
          <div className="p-3 rounded-xl bg-slate-800/30 border border-slate-700/40 text-xs text-slate-400 space-y-1">
            <div className="font-semibold text-slate-300 flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5 text-cyan-400" /> Tips on Voice Triggers:
            </div>
            <p>
              • Jab aap Mic on karte hain, aap inme se koi bhi phrase (jaise <em>"Hey Nova, clear my tasks"</em> ya <em>"Nova read screen"</em>) bolein.
            </p>
            <p>
              • AI matching case-insensitive hoti hai aur punctuation ko ignore karke seedha action execute karti hai.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>{triggers.filter((t) => t.enabled).length} Active Voice Commands</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
