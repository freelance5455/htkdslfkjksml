import { useEffect, useRef, useState } from 'react';
import { MoveUpRight, RefreshCw } from 'lucide-react';
import * as THREE from 'three';
import { createNatureWorld, lakeDistance, terrainHeight } from '../scene/createNatureWorld';
import { createSummitWorld } from '../scene/createSummitWorld';
import type { Settings, WorldId } from '../data/worlds';

interface Scene3DProps {
  world: WorldId;
  settings: Settings;
  sensorMoving: () => boolean;
  paused: boolean;
  manualForward: boolean;
  orientationAllowed: boolean;
  resetKey: number;
  onProgress: (distance: number, moving: boolean) => void;
  onStep: () => void;
  onReady: () => void;
}

export default function Scene3D(props: Scene3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const live = useRef(props);
  const journey = useRef<{ world: WorldId; position: THREE.Vector3; distance: number; yaw: number; pitch: number } | null>(null);
  const [error, setError] = useState(false);
  useEffect(() => { live.current = props; }, [props]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    } catch {
      setError(true);
      return;
    }
    setError(false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, props.settings.quality === 'high' ? 1.7 : 1.25));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = false;
    renderer.shadowMap.needsUpdate = true;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.98;
    renderer.domElement.setAttribute('aria-label', 'Interactive 3D Nature Realm');
    container.appendChild(renderer.domElement);

    // Support distinct maps: Mountain Summit map or Lakeside/Forest/Meadow map
    const isSummit = props.world === 'summit';
    const nature = isSummit
      ? createSummitWorld(props.settings)
      : createNatureWorld(props.world, props.settings);

    const camera = new THREE.PerspectiveCamera(68, 1, 0.1, 750);
    const stereo = new THREE.StereoCamera();
    stereo.aspect = 0.5;
    stereo.eyeSep = 0.064;
    const savedJourney = journey.current?.world === props.world ? journey.current : null;
    const position = savedJourney?.position.clone() ?? nature.startPosition.clone();
    camera.position.copy(position);

    const calcGroundHeight = (x: number, z: number) => {
      return nature.getHeight ? nature.getHeight(x, z) : terrainHeight(x, z);
    };

    camera.position.y = calcGroundHeight(position.x, position.z) + 1.72;
    const keys = new Set<string>();
    // When starting on mountain summit, look forward (+z) with a slight downward tilt (-0.14) to view the lush valley, river, and trees below!
    // When on mountain summit, position gaze slightly downward (-0.28 rad, ~16 degrees down) so the river, trees, and valley are immediately visible right in front of the viewer
    let yaw = savedJourney?.yaw ?? 0;
    let pitch = savedJourney?.pitch ?? (isSummit ? -0.28 : -0.085);
    let width = 1;
    let height = 1;
    let distance = savedJourney?.distance ?? 0;
    let stepDistance = 0;
    let velocity = 0;
    let animationId = 0;
    let previousTime = performance.now();
    let elapsed = 0;
    let lastPublish = 0;
    let lastReset = props.resetKey;
    let dragged = false;
    let pointerX = 0;
    let pointerY = 0;
    let deviceOrientation: DeviceOrientationEvent | null = null;
    let calibration: THREE.Quaternion | null = null;
    const direction = new THREE.Vector3();
    const quaternion = new THREE.Quaternion();
    const deviceEuler = new THREE.Euler();
    const lookEuler = new THREE.Euler(0, 0, 0, 'YXZ');
    const deviceCorrection = new THREE.Quaternion(-Math.sqrt(0.5), 0, 0, Math.sqrt(0.5));
    const screenCorrection = new THREE.Quaternion();
    const screenAxis = new THREE.Vector3(0, 0, 1);
    const rotationSpeed = 0.003;

    const resize = () => {
      width = Math.max(1, container.clientWidth);
      height = Math.max(1, container.clientHeight);
      renderer.setSize(width, height);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(container);
    resize();
    const handleKeyDown = (event: KeyboardEvent) => {
      const target = event.target;
      if (live.current.paused || event.defaultPrevented) return;
      if (target instanceof HTMLElement && (target.isContentEditable || target.closest('input, select, textarea') || (event.code === 'Space' && target.closest('button')))) return;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(event.code)) {
        event.preventDefault();
        keys.add(event.code);
      }
    };
    const handleKeyUp = (event: KeyboardEvent) => { keys.delete(event.code); };
    const clearKeys = () => { keys.clear(); dragged = false; };
    const pointerDown = (event: PointerEvent) => {
      if (live.current.paused) return;
      dragged = true;
      pointerX = event.clientX;
      pointerY = event.clientY;
      renderer.domElement.setPointerCapture(event.pointerId);
    };
    const pointerMove = (event: PointerEvent) => {
      if (!dragged || live.current.paused) return;
      yaw -= (event.clientX - pointerX) * rotationSpeed;
      pitch = THREE.MathUtils.clamp(pitch - (event.clientY - pointerY) * rotationSpeed, -1.1, 1.1);
      pointerX = event.clientX;
      pointerY = event.clientY;
    };
    const pointerUp = () => { dragged = false; };
    const handleOrientation = (event: DeviceOrientationEvent) => {
      if (event.alpha !== null && event.beta !== null && event.gamma !== null) deviceOrientation = event;
    };
    const handleContextLost = (event: Event) => {
      event.preventDefault();
      cancelAnimationFrame(animationId);
      setError(true);
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', clearKeys);
    window.addEventListener('deviceorientation', handleOrientation, { passive: true });
    renderer.domElement.addEventListener('pointerdown', pointerDown);
    renderer.domElement.addEventListener('pointermove', pointerMove);
    renderer.domElement.addEventListener('pointerup', pointerUp);
    renderer.domElement.addEventListener('pointercancel', pointerUp);
    renderer.domElement.addEventListener('lostpointercapture', pointerUp);
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    const animate = (now: number) => {
      const current = live.current;
      const dt = Math.min((now - previousTime) / 1000, 0.1);
      previousTime = now;
      if (current.resetKey !== lastReset) {
        position.copy(nature.startPosition);
        distance = 0;
        stepDistance = 0;
        velocity = 0;
        yaw = 0;
        pitch = isSummit ? -0.28 : -0.085;
        calibration = null;
        lastReset = current.resetKey;
        current.onProgress(0, false);
      }
      if (!current.paused) {
        elapsed += dt;
        if (keys.has('ArrowLeft') || keys.has('KeyA')) yaw += dt * 0.8;
        if (keys.has('ArrowRight') || keys.has('KeyD')) yaw -= dt * 0.8;
        lookEuler.set(pitch, yaw, 0, 'YXZ');
        camera.quaternion.setFromEuler(lookEuler);
        if (current.settings.headTracking && current.orientationAllowed && deviceOrientation) {
          const orientation = deviceOrientation as DeviceOrientationEvent;
          const rad = THREE.MathUtils.DEG2RAD;
          deviceEuler.set((orientation.beta ?? 0) * rad, (orientation.alpha ?? 0) * rad, -(orientation.gamma ?? 0) * rad, 'YXZ');
          quaternion.setFromEuler(deviceEuler).multiply(deviceCorrection);
          screenCorrection.setFromAxisAngle(screenAxis, -(window.screen.orientation?.angle ?? 0) * rad);
          quaternion.multiply(screenCorrection);
          if (!calibration) calibration = quaternion.clone().invert();
          camera.quaternion.multiply(calibration).multiply(quaternion);
        }
        const forward = (current.settings.motionEnabled && current.sensorMoving()) || current.manualForward || keys.has('Space') || keys.has('KeyW') || keys.has('ArrowUp');
        const backward = keys.has('KeyS') || keys.has('ArrowDown');
        const target = (forward ? 1 : backward ? -0.6 : 0) * current.settings.speed;
        velocity = THREE.MathUtils.damp(velocity, target, target === 0 ? 16 : 9, dt);
        if (Math.abs(velocity) > 0.01) {
          camera.getWorldDirection(direction);
          direction.y = 0;
          direction.normalize();
          const oldX = position.x;
          const oldZ = position.z;
          position.addScaledVector(direction, velocity * dt);

          if (!isSummit) {
            const d = lakeDistance(position.x, position.z);
            if (d < 1.045) {
              position.x *= 1.045 / d;
              position.z = (position.z + 8) * (1.045 / d) - 8;
            }
            position.x = THREE.MathUtils.clamp(position.x, -110, 110);
            position.z = THREE.MathUtils.clamp(position.z, -110, 110);
          } else {
            // Keep player on summit peak exploration area (radius ~ 28m on mountain top)
            const summitRad = Math.hypot(position.x, position.z);
            if (summitRad > 24) {
              position.x *= 24 / summitRad;
              position.z *= 24 / summitRad;
            }
          }

          const moved = Math.hypot(position.x - oldX, position.z - oldZ);
          distance += moved;
          stepDistance += moved;
          if (stepDistance > 0.65) { current.onStep(); stepDistance %= 0.65; }
        }
        camera.position.x = position.x;
        camera.position.z = position.z;
        const eyeHeight = calcGroundHeight(position.x, position.z) + 1.72;
        camera.position.y = THREE.MathUtils.damp(camera.position.y, eyeHeight, 9, dt);
        nature.animate(elapsed);
      } else {
        velocity = 0;
        keys.clear();
      }
      if (now - lastPublish > 220) {
        current.onProgress(distance, !current.paused && Math.abs(velocity) > 0.1);
        lastPublish = now;
      }
      camera.updateMatrixWorld();
      renderer.setScissorTest(false);
      renderer.setViewport(0, 0, width, height);
      renderer.clear();
      if (current.settings.displayMode === 'stereo') {
        stereo.update(camera);
        renderer.setScissorTest(true);
        renderer.setScissor(0, 0, width / 2, height);
        renderer.setViewport(0, 0, width / 2, height);
        renderer.render(nature.scene, stereo.cameraL);
        renderer.setScissor(width / 2, 0, width / 2, height);
        renderer.setViewport(width / 2, 0, width / 2, height);
        renderer.render(nature.scene, stereo.cameraR);
        renderer.setScissorTest(false);
      } else {
        renderer.setScissor(0, 0, width, height);
        renderer.setViewport(0, 0, width, height);
        renderer.render(nature.scene, camera);
      }
      animationId = requestAnimationFrame(animate);
    };
    animationId = requestAnimationFrame(animate);
    live.current.onReady();

    return () => {
      journey.current = { world: props.world, position: position.clone(), distance, yaw, pitch };
      cancelAnimationFrame(animationId);
      observer.disconnect();
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', clearKeys);
      window.removeEventListener('deviceorientation', handleOrientation);
      renderer.domElement.removeEventListener('pointerdown', pointerDown);
      renderer.domElement.removeEventListener('pointermove', pointerMove);
      renderer.domElement.removeEventListener('pointerup', pointerUp);
      renderer.domElement.removeEventListener('pointercancel', pointerUp);
      renderer.domElement.removeEventListener('lostpointercapture', pointerUp);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      nature.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [props.world, props.settings.quality, props.settings.timeOfDay]);

  return (
    <div className="scene-container" ref={containerRef}>
      {error && (
        <div className="scene-error">
          <RefreshCw size={30} />
          <h2>3D Scene Needs Reloading</h2>
          <p>Please enable WebGL or hardware acceleration in your browser settings and try again.</p>
          <button className="primary-button" onClick={() => window.location.reload()}>
            Reload Scene <MoveUpRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
