"use client";

import Calculator3D from "./Calculator3D";
import { useCalculator } from "@/lib/useCalculator";

// Demo expression shown on first load (like the fx-991ES Plus photo): √2÷2 + √3÷3
const DEMO = ["√(", "2", ")", "÷", "2", "+", "√(", "3", ")", "÷", "3"];

export default function Hero3D() {
  const calc = useCalculator({ initial: DEMO });
  return (
    <Calculator3D
      screen={calc.screen}
      onKey={calc.pressKey}
      pressedId={calc.pressedId}
      bodyColor="#1c1d22"
      accent="#8b5cf6"
      sway={0.4}
      intro
      cameraZ={14.5}
      className="h-full w-full"
    />
  );
}
