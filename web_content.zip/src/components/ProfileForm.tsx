"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { apiPatch, ApiError } from "@/lib/client/api";
import { useToast } from "./ui";
import { PLATFORMS, TONES } from "@/lib/ai/tools";

export default function ProfileForm({
  name,
  email,
  preferences,
  niches,
}: {
  name: string;
  email: string;
  preferences: { defaultPlatform: string; defaultNiche: string; defaultTone: string };
  niches: string[];
}) {
  const router = useRouter();
  const { show, node } = useToast();
  const [form, setForm] = useState({ name, ...preferences });
  const [saving, setSaving] = useState(false);

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      await apiPatch("/api/auth/me", form);
      show("Profile updated");
      router.refresh();
    } catch (error) {
      show(error instanceof ApiError ? error.message : "Could not save", "bad");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={save} className="card space-y-3 p-4">
      {node}
      <div>
        <p className="text-sm font-semibold">Account</p>
        <p className="text-xs text-[color:var(--muted)]">{email}</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="name">
            Display name
          </label>
          <input id="name" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div>
          <label className="label" htmlFor="platform">
            Default platform
          </label>
          <select
            id="platform"
            className="select"
            value={form.defaultPlatform}
            onChange={(e) => setForm({ ...form, defaultPlatform: e.target.value })}
          >
            {PLATFORMS.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="niche">
            Default niche
          </label>
          <select
            id="niche"
            className="select"
            value={form.defaultNiche}
            onChange={(e) => setForm({ ...form, defaultNiche: e.target.value })}
          >
            {niches.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="tone">
            Default tone
          </label>
          <select
            id="tone"
            className="select"
            value={form.defaultTone}
            onChange={(e) => setForm({ ...form, defaultTone: e.target.value })}
          >
            {TONES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>
      <button type="submit" className="btn btn-primary" disabled={saving}>
        {saving ? "Saving…" : "Save changes"}
      </button>
    </form>
  );
}
