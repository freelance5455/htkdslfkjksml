import React, { useState, useEffect } from "react";
import {
  Maximize2,
  Upload,
  RefreshCw,
  X,
  Sparkles,
  Layers,
  MapPin,
  Check,
  Camera,
  ExternalLink,
} from "lucide-react";
import { EXTRA_GALLERY_FRAMES, GalleryFrame } from "../data/extraFrames";
import { RESTAURANT_INFO } from "../data/restaurantInfo";

export const SpaceSection: React.FC = () => {
  // Store custom image replacements in LocalStorage
  const [frameOverrides, setFrameOverrides] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem("kaloreez_frame_overrides");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [selectedFrame, setSelectedFrame] = useState<GalleryFrame | null>(null);
  const [isReplaceModalOpen, setIsReplaceModalOpen] = useState(false);
  const [frameToReplace, setFrameToReplace] = useState<GalleryFrame | null>(null);
  const [inputUrl, setInputUrl] = useState("");
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [mobileViewMode, setMobileViewMode] = useState<"carousel" | "stack">("carousel");
  const [carouselIndex, setCarouselIndex] = useState(0);

  useEffect(() => {
    try {
      localStorage.setItem("kaloreez_frame_overrides", JSON.stringify(frameOverrides));
    } catch {
      // ignore
    }
  }, [frameOverrides]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveCustomImage = (frameId: string, url: string) => {
    if (!url.trim()) return;
    setFrameOverrides((prev) => ({
      ...prev,
      [frameId]: url.trim(),
    }));
    setIsReplaceModalOpen(false);
    setInputUrl("");
    showToast("Frame image updated successfully");
  };

  const handleResetFrame = (frameId: string) => {
    setFrameOverrides((prev) => {
      const next = { ...prev };
      delete next[frameId];
      return next;
    });
    showToast("Restored curated placeholder");
  };

  const handleFileUpload = (frameId: string, file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setFrameOverrides((prev) => ({
          ...prev,
          [frameId]: reader.result as string,
        }));
        setIsReplaceModalOpen(false);
        showToast("Uploaded photo set as frame asset");
      }
    };
    reader.readAsDataURL(file);
  };

  const filteredFrames = activeFilter === "all"
    ? EXTRA_GALLERY_FRAMES
    : activeFilter === "space"
    ? EXTRA_GALLERY_FRAMES.filter((f) => f.category === "Architecture & Heritage" || f.category === "Interior Atmosphere")
    : EXTRA_GALLERY_FRAMES.filter((f) => f.category !== "Architecture & Heritage" && f.category !== "Interior Atmosphere");

  return (
    <section id="space" className="py-24 sm:py-32 px-6 bg-[#17201C] text-[#F4F0E7] relative overflow-hidden">
      {/* Subtle architectural background texture */}
      <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#F4F0E7_1px,transparent_1px)] [background-size:24px_24px]" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14 border-b border-[#D8D0C2]/15 pb-10">
          <div className="max-w-2xl">
            <div className="text-xs font-semibold tracking-[0.25em] uppercase text-[#9BAF82] mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#9BAF82] animate-pulse" />
              <span>THE PHYSICAL SPACE & ARCHIVE FRAMES</span>
            </div>
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#F4F0E7] leading-[1.05] tracking-tight mb-4">
              ATMOSPHERE, ARCH &
              <br />
              <span className="italic font-light text-[#D8D0C2]">KITCHEN MOMENTS.</span>
            </h2>
            <p className="text-xs sm:text-sm text-[#D8D0C2]/80 font-sans leading-relaxed">
              Curated frames capturing our olive stucco entrance, glowing neon dining room, and honest wholesome plates in Daspalla Hills, Vizag.
            </p>
          </div>

          {/* Filter Chips & Customizer Hint */}
          <div className="flex flex-wrap items-center justify-between gap-3 w-full lg:w-auto">
            {/* Category Filter Chips */}
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <button
                onClick={() => setActiveFilter("all")}
                className={`px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs font-sans tracking-wider uppercase transition-all cursor-pointer ${
                  activeFilter === "all"
                    ? "bg-[#9BAF82] text-[#17201C] font-semibold shadow-md"
                    : "bg-white/5 text-[#D8D0C2] hover:bg-white/10 border border-[#D8D0C2]/20"
                }`}
              >
                All 5 Frames
              </button>
              <button
                onClick={() => setActiveFilter("space")}
                className={`px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs font-sans tracking-wider uppercase transition-all cursor-pointer ${
                  activeFilter === "space"
                    ? "bg-[#9BAF82] text-[#17201C] font-semibold shadow-md"
                    : "bg-white/5 text-[#D8D0C2] hover:bg-white/10 border border-[#D8D0C2]/20"
                }`}
              >
                Space & Facade
              </button>
              <button
                onClick={() => setActiveFilter("culinary")}
                className={`px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs font-sans tracking-wider uppercase transition-all cursor-pointer ${
                  activeFilter === "culinary"
                    ? "bg-[#9BAF82] text-[#17201C] font-semibold shadow-md"
                    : "bg-white/5 text-[#D8D0C2] hover:bg-white/10 border border-[#D8D0C2]/20"
                }`}
              >
                Plates & Toast
              </button>
            </div>

            {/* Mobile View Toggle (Swipe Deck vs Grid) */}
            <div className="flex md:hidden items-center gap-1 bg-white/10 p-0.5 rounded-full border border-white/10">
              <button
                onClick={() => setMobileViewMode("carousel")}
                className={`px-2.5 py-1 rounded-full text-[10px] font-sans uppercase tracking-wider transition-colors ${
                  mobileViewMode === "carousel"
                    ? "bg-[#9BAF82] text-[#17201C] font-semibold"
                    : "text-[#D8D0C2]/80"
                }`}
              >
                Swipe Deck
              </button>
              <button
                onClick={() => setMobileViewMode("stack")}
                className={`px-2.5 py-1 rounded-full text-[10px] font-sans uppercase tracking-wider transition-colors ${
                  mobileViewMode === "stack"
                    ? "bg-[#9BAF82] text-[#17201C] font-semibold"
                    : "text-[#D8D0C2]/80"
                }`}
              >
                Grid
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Gallery Composition: Responsive Touch Carousel or Grid */}
        <div
          className={
            mobileViewMode === "carousel"
              ? "flex md:grid md:grid-cols-12 overflow-x-auto md:overflow-visible snap-x snap-mandatory gap-5 sm:gap-8 pb-4 scrollbar-none items-start"
              : "grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 items-start"
          }
        >
          {filteredFrames.map((frame, index) => {
            const currentImg = frameOverrides[frame.id] || frame.defaultImageUrl;
            const isCustom = !!frameOverrides[frame.id];

            const colSpan =
              frame.id === "frame-storefront"
                ? "md:col-span-7"
                : frame.id === "frame-neon-dining"
                ? "md:col-span-5"
                : "md:col-span-4";

            return (
              <div
                key={frame.id}
                className={`${colSpan} ${
                  mobileViewMode === "carousel"
                    ? "w-[85vw] sm:w-[70vw] shrink-0 snap-center md:w-auto"
                    : "w-full"
                } group relative flex flex-col justify-between`}
              >
                {/* Museum Frame Container */}
                <div className="p-3 bg-[#202B25] rounded-xs border border-[#D8D0C2]/25 shadow-xl transition-all duration-300 hover:border-[#9BAF82]/60 hover:shadow-2xl">
                  {/* Photo Display */}
                  <div
                    className="relative w-full overflow-hidden rounded-xs bg-[#17201C] cursor-pointer"
                    style={{ aspectRatio: frame.id === "frame-neon-dining" ? "16/10" : "4/3" }}
                    onClick={() => setSelectedFrame(frame)}
                  >
                    <img
                      src={currentImg}
                      alt={frame.title}
                      loading="lazy"
                      className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-103"
                    />

                    {/* Gradient Overlay & Actions: Visible on mobile touch without needing hover */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#17201C]/85 via-[#17201C]/20 to-transparent opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-200 flex items-end justify-between p-3 sm:p-4">
                      <span className="text-[10px] sm:text-[11px] font-sans tracking-wider uppercase text-[#F4F0E7] flex items-center gap-1.5 bg-[#17201C]/80 px-2.5 py-1 rounded-full backdrop-blur-xs">
                        <Maximize2 className="w-3 h-3 text-[#9BAF82]" />
                        <span>Inspect</span>
                      </span>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setFrameToReplace(frame);
                          setInputUrl(frameOverrides[frame.id] || "");
                          setIsReplaceModalOpen(true);
                        }}
                        className="text-[10px] sm:text-[11px] font-sans tracking-wider uppercase text-[#17201C] bg-[#9BAF82] hover:bg-white active:scale-95 px-2.5 py-1 rounded-full font-semibold transition-all flex items-center gap-1 shadow-sm"
                        title="Upload your own photo or paste URL"
                      >
                        <Upload className="w-3 h-3" />
                        <span>Replace</span>
                      </button>
                    </div>

                    {/* Badge Pill */}
                    <div className="absolute top-2.5 left-2.5 sm:top-3 sm:left-3 flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-full bg-[#17201C]/85 text-[#9BAF82] border border-[#D8D0C2]/30 text-[10px] uppercase font-sans tracking-wider backdrop-blur-xs">
                        {frame.badge}
                      </span>
                      {isCustom && (
                        <span className="px-1.5 py-0.5 rounded-full bg-emerald-700/90 text-white text-[9px] uppercase font-sans tracking-wider">
                          Custom
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Frame Description & Metadata */}
                  <div className="pt-3 pb-1">
                    <div className="flex items-baseline justify-between gap-2 mb-1">
                      <h3 className="font-serif text-base sm:text-xl text-[#F4F0E7] leading-snug">
                        {frame.title}
                      </h3>
                    </div>
                    <div className="text-[10px] sm:text-[11px] uppercase tracking-wider text-[#9BAF82] font-mono mb-1.5">
                      {frame.subtitle}
                    </div>
                    <p className="text-xs text-[#D8D0C2]/75 font-sans leading-relaxed line-clamp-2">
                      {frame.description}
                    </p>

                    {/* Frame Tools / Reset */}
                    <div className="mt-3 pt-2.5 border-t border-[#D8D0C2]/15 flex items-center justify-between text-[11px] text-[#D8D0C2]/60 font-sans">
                      <span className="italic text-[10px] sm:text-[11px]">{frame.category}</span>
                      {isCustom ? (
                        <button
                          type="button"
                          onClick={() => handleResetFrame(frame.id)}
                          className="text-[#9BAF82] hover:underline flex items-center gap-1 text-[10px] sm:text-[11px]"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>Reset</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setFrameToReplace(frame);
                            setInputUrl("");
                            setIsReplaceModalOpen(true);
                          }}
                          className="hover:text-[#9BAF82] transition-colors flex items-center gap-1 text-[10px] uppercase tracking-wider"
                        >
                          <Upload className="w-3 h-3 text-[#9BAF82]" />
                          <span>Insert Real Photo</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile Swipe Deck Hint & Indicator Dots */}
        {mobileViewMode === "carousel" && (
          <div className="flex md:hidden items-center justify-center gap-2 mt-4 text-[11px] text-[#D8D0C2]/70 font-sans">
            <span>← Swipe horizontally to explore all {filteredFrames.length} real frames →</span>
          </div>
        )}
      </div>

      {/* Frame Inspection Lightbox Modal */}
      {selectedFrame && (
        <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 sm:p-8 bg-[#17201C]/90 backdrop-blur-md">
          <div
            className="fixed inset-0"
            onClick={() => setSelectedFrame(null)}
          />
          <div className="relative z-10 w-full max-w-4xl bg-[#1F2B24] border border-[#D8D0C2]/40 rounded-sm overflow-hidden shadow-2xl p-4 sm:p-6 text-[#F4F0E7] my-auto max-h-[92vh] flex flex-col md:flex-row gap-6">
            <button
              onClick={() => setSelectedFrame(null)}
              className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-[#17201C]/80 border border-[#D8D0C2]/40 flex items-center justify-center text-[#F4F0E7] hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Lightbox Image Preview */}
            <div className="w-full md:w-3/5 rounded-xs overflow-hidden bg-[#17201C] flex items-center justify-center border border-[#D8D0C2]/20">
              <img
                src={frameOverrides[selectedFrame.id] || selectedFrame.defaultImageUrl}
                alt={selectedFrame.title}
                className="w-full h-full max-h-[60vh] object-cover"
              />
            </div>

            {/* Lightbox Content */}
            <div className="w-full md:w-2/5 flex flex-col justify-between space-y-4">
              <div>
                <span className="px-2.5 py-1 rounded-full bg-white/10 text-[#9BAF82] border border-[#D8D0C2]/20 text-[10px] uppercase font-sans tracking-widest">
                  {selectedFrame.badge}
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#F4F0E7] mt-3 mb-1 leading-tight">
                  {selectedFrame.title}
                </h3>
                <div className="text-xs font-mono uppercase tracking-wider text-[#9BAF82] mb-3">
                  {selectedFrame.subtitle}
                </div>
                <p className="text-xs sm:text-sm text-[#D8D0C2]/80 font-sans leading-relaxed mb-4">
                  {selectedFrame.description}
                </p>

                <div className="p-3 bg-[#17201C]/60 rounded-xs border border-[#D8D0C2]/20 text-[11px] text-[#D8D0C2]/70 font-sans space-y-1">
                  <div className="text-[#9BAF82] font-semibold uppercase tracking-wider text-[10px]">
                    Photo Context:
                  </div>
                  <div>{selectedFrame.notes}</div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#D8D0C2]/20 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setFrameToReplace(selectedFrame);
                    setInputUrl(frameOverrides[selectedFrame.id] || "");
                    setIsReplaceModalOpen(true);
                  }}
                  className="flex-grow py-2.5 px-4 rounded-full bg-[#9BAF82] text-[#17201C] font-sans text-xs font-semibold uppercase tracking-wider hover:bg-white transition-colors flex items-center justify-center gap-2"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Update Frame Asset</span>
                </button>

                {frameOverrides[selectedFrame.id] && (
                  <button
                    type="button"
                    onClick={() => handleResetFrame(selectedFrame.id)}
                    className="p-2.5 rounded-full border border-[#D8D0C2]/30 text-[#D8D0C2] hover:text-[#F4F0E7] hover:border-white transition-colors"
                    title="Reset to placeholder"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Frame Replacement / Upload Modal */}
      {isReplaceModalOpen && frameToReplace && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-[#17201C]/85 backdrop-blur-xs">
          <div
            className="fixed inset-0"
            onClick={() => setIsReplaceModalOpen(false)}
          />
          <div className="relative z-10 w-full max-w-md bg-[#FDFBF7] text-[#17201C] rounded-xs border border-[#D8D0C2] shadow-2xl p-6 sm:p-8 paper-frame">
            <button
              onClick={() => setIsReplaceModalOpen(false)}
              className="absolute top-4 right-4 w-7 h-7 rounded-full bg-white border border-[#D8D0C2] flex items-center justify-center text-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>

            <div className="text-[10px] uppercase tracking-widest text-[#9BAF82] font-semibold mb-1">
              Frame Asset Manager
            </div>
            <h3 className="font-serif text-2xl text-[#17201C] mb-2">
              Update {frameToReplace.badge}
            </h3>
            <p className="text-xs text-[#17201C]/70 font-sans mb-4">
              Paste an image link or select a file from your device. You can swap this anytime as your photo library grows.
            </p>

            {/* Paste URL Option */}
            <div className="space-y-4 text-xs font-sans">
              <div>
                <label className="block uppercase tracking-wider font-semibold text-[#17201C]/70 mb-1">
                  Image Web URL
                </label>
                <input
                  type="url"
                  value={inputUrl}
                  onChange={(e) => setInputUrl(e.target.value)}
                  placeholder="https://... (direct .jpg/.png link)"
                  className="w-full p-2.5 bg-white border border-[#D8D0C2] rounded-xs focus:outline-none focus:border-[#9BAF82]"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveCustomImage(frameToReplace.id, inputUrl)}
                  disabled={!inputUrl.trim()}
                  className="flex-grow py-2.5 rounded-full bg-[#17201C] text-[#F4F0E7] font-semibold uppercase tracking-wider hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Apply Image URL
                </button>
              </div>

              <div className="relative flex items-center justify-center my-3">
                <div className="border-t border-[#D8D0C2] w-full" />
                <span className="bg-[#FDFBF7] px-2 text-[10px] uppercase tracking-widest text-[#17201C]/50 absolute">
                  OR UPLOAD FILE
                </span>
              </div>

              {/* Upload File Input */}
              <label className="border-2 border-dashed border-[#D8D0C2] hover:border-[#17201C] rounded-xs p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors bg-white/60">
                <Camera className="w-5 h-5 text-[#9BAF82]" />
                <span className="text-xs font-medium text-[#17201C]">
                  Select photo from phone or computer
                </span>
                <span className="text-[10px] text-[#17201C]/50">
                  PNG, JPG, WEBP (Saved locally in your browser)
                </span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(frameToReplace.id, file);
                  }}
                />
              </label>

              {frameOverrides[frameToReplace.id] && (
                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => {
                      handleResetFrame(frameToReplace.id);
                      setIsReplaceModalOpen(false);
                    }}
                    className="text-xs text-[#B96D52] hover:underline"
                  >
                    Restore default placeholder
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[150] px-4 py-2.5 rounded-full bg-[#9BAF82] text-[#17201C] text-xs font-sans font-semibold uppercase tracking-wider shadow-xl animate-in fade-in slide-in-from-bottom-3 duration-200 flex items-center gap-2">
          <Check className="w-3.5 h-3.5" />
          <span>{toastMessage}</span>
        </div>
      )}
    </section>
  );
};
