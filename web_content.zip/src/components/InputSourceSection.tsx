import React, { useRef, useState } from 'react';
import { UploadCloud, FileArchive, Globe, Code2, Sparkles, Check, FileCode, Trash2, Eye } from 'lucide-react';
import { InputMode, WebFile } from '../types/apk';
import { SAMPLE_APPS, SampleApp } from '../utils/sampleApps';
import { loadAndAnalyzeZip, ZipAnalysisResult } from '../utils/zipLoader';

interface InputSourceSectionProps {
  inputMode: InputMode;
  setInputMode: (mode: InputMode) => void;
  webFiles: WebFile[];
  setWebFiles: (files: WebFile[]) => void;
  onApplySample: (sample: SampleApp) => void;
  onZipLoaded: (result: ZipAnalysisResult) => void;
  rawHtmlInput: string;
  setRawHtmlInput: (val: string) => void;
  urlInput: string;
  setUrlInput: (val: string) => void;
  onApplyUrl: (url: string) => void;
  selectedFileForPreview: WebFile | null;
  setSelectedFileForPreview: (file: WebFile | null) => void;
}

export const InputSourceSection: React.FC<InputSourceSectionProps> = ({
  inputMode,
  setInputMode,
  webFiles,
  setWebFiles,
  onApplySample,
  onZipLoaded,
  rawHtmlInput,
  setRawHtmlInput,
  urlInput,
  setUrlInput,
  onApplyUrl,
  selectedFileForPreview,
  setSelectedFileForPreview,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const htmlInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoadingZip, setIsLoadingZip] = useState(false);
  const [zipError, setZipError] = useState<string | null>(null);

  const handleZipFile = async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.zip')) {
      setZipError('Please upload a valid .zip file archive');
      return;
    }
    setZipError(null);
    setIsLoadingZip(true);
    try {
      const result = await loadAndAnalyzeZip(file);
      onZipLoaded(result);
    } catch (err: any) {
      setZipError(err.message || 'Failed to read zip archive');
    } finally {
      setIsLoadingZip(false);
    }
  };

  const handleHtmlFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setRawHtmlInput(content);
      const newFile: WebFile = {
        name: file.name,
        path: 'index.html',
        content,
        isBinary: false,
        size: content.length,
      };
      setWebFiles([newFile]);
    };
    reader.readAsText(file);
  };

  const handleRawHtmlChange = (text: string) => {
    setRawHtmlInput(text);
    const updated: WebFile = {
      name: 'index.html',
      path: 'index.html',
      content: text,
      isBinary: false,
      size: text.length,
    };
    setWebFiles([updated]);
  };

  const totalBytes = webFiles.reduce((acc, f) => acc + f.size, 0);

  return (
    <div className="space-y-6">
      {/* Mode Selector Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded-xl">
        <button
          onClick={() => setInputMode('zip')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
            inputMode === 'zip'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <FileArchive className="w-4 h-4 text-emerald-400" />
          <span>ZIP Archive</span>
        </button>
        <button
          onClick={() => setInputMode('html')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
            inputMode === 'html'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Code2 className="w-4 h-4 text-emerald-400" />
          <span>HTML / Code</span>
        </button>
        <button
          onClick={() => setInputMode('url')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
            inputMode === 'url'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Globe className="w-4 h-4 text-emerald-400" />
          <span>Web URL</span>
        </button>
        <button
          onClick={() => setInputMode('samples')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
            inputMode === 'samples'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>Quick Demos</span>
        </button>
      </div>

      {/* ZIP Upload Mode */}
      {inputMode === 'zip' && (
        <div className="space-y-4">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              const file = e.dataTransfer.files[0];
              if (file) handleZipFile(file);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-emerald-400 bg-emerald-950/20'
                : 'border-slate-800 hover:border-slate-700 bg-slate-900/40 hover:bg-slate-900/70'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".zip,application/zip"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleZipFile(file);
              }}
            />

            <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-center mx-auto mb-3 text-emerald-400">
              <UploadCloud className="w-6 h-6" />
            </div>

            <p className="text-sm font-semibold text-white mb-1">
              {isLoadingZip ? 'Extracting & analyzing ZIP contents...' : 'Drop your project ZIP file here, or click to browse'}
            </p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Supports HTML5 web games, React/Vue static dist folders, PWA assets, or any zip containing an index.html
            </p>
          </div>

          {zipError && (
            <div className="p-3 bg-rose-950/50 border border-rose-800 text-rose-300 text-xs rounded-lg">
              {zipError}
            </div>
          )}
        </div>
      )}

      {/* HTML / Code Editor Mode */}
      {inputMode === 'html' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Direct HTML & JavaScript Source</span>
            <div className="flex items-center gap-2">
              <input
                ref={htmlInputRef}
                type="file"
                accept=".html,.htm"
                className="hidden"
                onChange={handleHtmlFileUpload}
              />
              <button
                onClick={() => htmlInputRef.current?.click()}
                className="text-xs text-slate-300 hover:text-white px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-md border border-slate-700 transition-colors"
              >
                Upload .html File
              </button>
            </div>
          </div>

          <div className="relative rounded-xl border border-slate-800 bg-slate-950 overflow-hidden">
            <div className="px-4 py-2 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">index.html</span>
              <span>{rawHtmlInput.length} chars</span>
            </div>
            <textarea
              value={rawHtmlInput}
              onChange={(e) => handleRawHtmlChange(e.target.value)}
              placeholder="<!DOCTYPE html><html>...</html>"
              rows={12}
              className="w-full p-4 bg-transparent text-slate-200 font-mono text-xs leading-relaxed outline-none resize-y"
              spellCheck={false}
            />
          </div>
        </div>
      )}

      {/* Web URL to APK Mode */}
      {inputMode === 'url' && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl space-y-3">
            <label className="block text-xs font-medium text-slate-300">
              Wrap Live Website or Web Application into APK
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://mywebapp.com"
                className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={() => onApplyUrl(urlInput)}
                className="px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors cursor-pointer"
              >
                Generate Bundle
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              Creates a native Android WebView container that automatically connects to your live domain with full caching, hardware acceleration, and back button handling.
            </p>
          </div>
        </div>
      )}

      {/* Quick Demos Mode */}
      {inputMode === 'samples' && (
        <div className="space-y-3">
          <p className="text-xs text-slate-400">
            Choose a ready-to-test sample app to evaluate the APK builder immediately:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {SAMPLE_APPS.map((sample) => (
              <div
                key={sample.id}
                onClick={() => onApplySample(sample)}
                className="p-4 bg-slate-900/50 hover:bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-xl cursor-pointer transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] text-emerald-400 font-semibold tracking-wider uppercase">
                      {sample.category}
                    </span>
                    <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {sample.suggestedIcon.symbol}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors mb-1">
                    {sample.name}
                  </h4>
                  <p className="text-xs text-slate-400 leading-snug line-clamp-2">
                    {sample.description}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span className="font-mono text-[11px] truncate max-w-[120px]">{sample.suggestedPackage}</span>
                  <span className="text-emerald-400 font-medium group-hover:translate-x-0.5 transition-transform">
                    Use Template &rarr;
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Extracted / Packaged Files Inspector */}
      {webFiles.length > 0 && (
        <div className="rounded-xl border border-slate-800 bg-slate-900/30 overflow-hidden">
          {webFiles.some(f => f.path.includes('build.gradle') || f.path.includes('AndroidManifest.xml') || f.path.endsWith('.kt') || f.path.endsWith('.java')) && (
            <div className="p-3 bg-emerald-950/40 border-b border-emerald-500/20 flex items-center gap-2 text-xs text-emerald-300">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
              <span><strong>Native Android Project Detected:</strong> Automatic Gradle & Android SDK compilation enabled.</span>
            </div>
          )}
          <div className="px-4 py-3 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-white">Bundled Web Assets</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400 font-mono">{webFiles.length} files</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400 font-mono">
                {totalBytes >= 1024 * 1024 ? `${(totalBytes / (1024 * 1024)).toFixed(2)} MB` : `${(totalBytes / 1024).toFixed(1)} KB`}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setWebFiles([])}
                className="text-xs text-slate-400 hover:text-rose-400 transition-colors p-1"
                title="Clear all files"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="max-h-52 overflow-y-auto divide-y divide-slate-800/40 text-xs">
            {webFiles.map((f, idx) => (
              <div
                key={idx}
                className="px-4 py-2 flex items-center justify-between hover:bg-slate-800/40 transition-colors"
              >
                <div className="flex items-center gap-2 truncate pr-2">
                  <FileCode className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <span className="font-mono text-slate-300 truncate">{f.path}</span>
                  {f.path.toLowerCase().endsWith('index.html') && (
                    <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-medium shrink-0">
                      Entry Point
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="font-mono text-slate-500 text-[11px]">
                    {f.size > 1024 ? `${(f.size / 1024).toFixed(1)} KB` : `${f.size} B`}
                  </span>
                  {!f.isBinary && typeof f.content === 'string' && (
                    <button
                      onClick={() => setSelectedFileForPreview(f)}
                      className="text-slate-400 hover:text-white"
                      title="Inspect code"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
