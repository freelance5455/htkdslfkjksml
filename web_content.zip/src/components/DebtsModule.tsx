import React, { useState, useMemo } from 'react';
import {
  Plus,
  Phone,
  CheckCircle2,
  AlertCircle,
  Clock,
  Edit3,
  Trash2,
  History,
  X,
} from 'lucide-react';
import {
  Account,
  DebtDirection,
  DebtRecord,
  RepaymentRecord,
} from '../types/finance';
import {
  formatBDT,
  formatDateBnEn,
  getTodayISO,
  paisaToInputString,
  parseAmountToPaisa,
} from '../utils/money';

interface DebtsModuleProps {
  debts: DebtRecord[];
  accounts: Account[];
  useBengaliDigits: boolean;
  onSaveDebt: (
    debtData: Omit<DebtRecord, 'id' | 'createdAt' | 'repayments'>,
    existingId?: string
  ) => void;
  onDeleteDebt: (debt: DebtRecord) => void;
  onAddRepayment: (
    debtId: string,
    repayment: Omit<RepaymentRecord, 'id' | 'debtId' | 'createdAt'>
  ) => void;
  onDeleteRepayment: (debtId: string, repaymentId: string) => void;
}

const DIRECTION_OPTIONS: {
  dir: DebtDirection;
  labelBn: string;
  group: 'RECEIVABLE' | 'PAYABLE';
}[] = [
  {
    dir: 'LENT',
    labelBn: 'ধার দেওয়া',
    group: 'RECEIVABLE',
  },
  {
    dir: 'RECEIVABLE_OTHER',
    labelBn: 'বাকিতে বিক্রয় পাওনা',
    group: 'RECEIVABLE',
  },
  {
    dir: 'BORROWED',
    labelBn: 'ধার নেওয়া',
    group: 'PAYABLE',
  },
  {
    dir: 'PAYABLE_OTHER',
    labelBn: 'বাকিতে ক্রয় দেনা',
    group: 'PAYABLE',
  },
];

export const DebtsModule: React.FC<DebtsModuleProps> = ({
  debts,
  accounts,
  useBengaliDigits,
  onSaveDebt,
  onDeleteDebt,
  onAddRepayment,
  onDeleteRepayment,
}) => {
  const todayISO = getTodayISO();

  const [filterTab, setFilterTab] = useState<
    'ALL' | 'RECEIVABLE' | 'PAYABLE' | 'OVERDUE' | 'PAID'
  >('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const [showDebtModal, setShowDebtModal] = useState(false);
  const [editingDebt, setEditingDebt] = useState<DebtRecord | null>(null);
  const [direction, setDirection] = useState<DebtDirection>('LENT');
  const [contactName, setContactName] = useState('');
  const [phone, setPhone] = useState('');
  const [principalInput, setPrincipalInput] = useState('');
  const [date, setDate] = useState(todayISO);
  const [dueDate, setDueDate] = useState('');
  const [accountId, setAccountId] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const [activeDebtForRepayment, setActiveDebtForRepayment] =
    useState<DebtRecord | null>(null);
  const [repayAmountInput, setRepayAmountInput] = useState('');
  const [repayDate, setRepayDate] = useState(todayISO);
  const [repayAccountId, setRepayAccountId] = useState<string>(
    accounts[0]?.id ?? ''
  );
  const [repayNote, setRepayNote] = useState('');
  const [repayError, setRepayError] = useState<string | null>(null);

  const [expandedHistoryDebtId, setExpandedHistoryDebtId] = useState<
    string | null
  >(null);

  const openNewDebtModal = (defaultDir: DebtDirection = 'LENT') => {
    setEditingDebt(null);
    setDirection(defaultDir);
    setContactName('');
    setPhone('');
    setPrincipalInput('');
    setDate(todayISO);
    setDueDate('');
    setAccountId('');
    setNotes('');
    setFormError(null);
    setShowDebtModal(true);
  };

  const openEditDebtModal = (debt: DebtRecord) => {
    setEditingDebt(debt);
    setDirection(debt.direction);
    setContactName(debt.contactName);
    setPhone(debt.phone ?? '');
    setPrincipalInput(paisaToInputString(debt.principalPaisa));
    setDate(debt.date);
    setDueDate(debt.dueDate ?? '');
    setAccountId(debt.accountId ?? '');
    setNotes(debt.notes);
    setFormError(null);
    setShowDebtModal(true);
  };

  const handleSaveDebtSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!contactName.trim()) {
      setFormError('অনুগ্রহ করে নাম লিখুন।');
      return;
    }

    const parsedPrincipal = parseAmountToPaisa(principalInput);
    if (parsedPrincipal === null || parsedPrincipal <= 0) {
      setFormError('অনুগ্রহ করে সঠিক টাকার পরিমাণ লিখুন।');
      return;
    }

    if (editingDebt) {
      const alreadyRepaid = editingDebt.repayments.reduce(
        (s, r) => s + r.amountPaisa,
        0
      );
      if (parsedPrincipal < alreadyRepaid) {
        setFormError(
          `মূল টাকার পরিমাণ ইতিমধ্যে পরিশোধিত টাকার (${formatBDT(alreadyRepaid, {
            useBengaliDigits,
          })}) চেয়ে কম হতে পারবে না।`
        );
        return;
      }
    }

    onSaveDebt(
      {
        direction,
        contactName: contactName.trim(),
        phone: phone.trim() || undefined,
        principalPaisa: parsedPrincipal,
        date,
        dueDate: dueDate || undefined,
        accountId: accountId || undefined,
        notes: notes.trim(),
      },
      editingDebt?.id
    );
    setShowDebtModal(false);
  };

  const openRepaymentModal = (debt: DebtRecord) => {
    const repaid = debt.repayments.reduce((s, r) => s + r.amountPaisa, 0);
    const remaining = Math.max(0, debt.principalPaisa - repaid);
    setActiveDebtForRepayment(debt);
    setRepayAmountInput(paisaToInputString(remaining));
    setRepayDate(todayISO);
    setRepayAccountId(debt.accountId || accounts[0]?.id || '');
    setRepayNote('');
    setRepayError(null);
  };

  const handleRepaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDebtForRepayment) return;
    setRepayError(null);

    const parsed = parseAmountToPaisa(repayAmountInput);
    if (parsed === null || parsed <= 0) {
      setRepayError('অনুগ্রহ করে সঠিক কিস্তির পরিমাণ লিখুন।');
      return;
    }

    const repaidSoFar = activeDebtForRepayment.repayments.reduce(
      (s, r) => s + r.amountPaisa,
      0
    );
    const remaining = Math.max(
      0,
      activeDebtForRepayment.principalPaisa - repaidSoFar
    );

    if (parsed > remaining) {
      setRepayError(
        `পরিশোধের পরিমাণ বকেয়া টাকার (${formatBDT(remaining, {
          useBengaliDigits,
        })}) চেয়ে বেশি হতে পারবে না।`
      );
      return;
    }

    onAddRepayment(activeDebtForRepayment.id, {
      amountPaisa: parsed,
      date: repayDate,
      accountId: repayAccountId || undefined,
      note: repayNote.trim() || 'কিস্তি পরিশোধ',
    });
    setActiveDebtForRepayment(null);
  };

  const summary = useMemo(() => {
    let lentOutstanding = 0;
    let otherReceivableOutstanding = 0;
    let borrowedOutstanding = 0;
    let otherPayableOutstanding = 0;
    let overdueCount = 0;

    for (const d of debts) {
      const repaid = d.repayments.reduce((s, r) => s + r.amountPaisa, 0);
      const rem = Math.max(0, d.principalPaisa - repaid);
      if (rem <= 0) continue;

      if (d.direction === 'LENT') lentOutstanding += rem;
      else if (d.direction === 'RECEIVABLE_OTHER')
        otherReceivableOutstanding += rem;
      else if (d.direction === 'BORROWED') borrowedOutstanding += rem;
      else if (d.direction === 'PAYABLE_OTHER') otherPayableOutstanding += rem;

      if (d.dueDate && d.dueDate < todayISO) {
        overdueCount += 1;
      }
    }

    return {
      totalReceivable: lentOutstanding + otherReceivableOutstanding,
      lentOutstanding,
      otherReceivableOutstanding,
      totalPayable: borrowedOutstanding + otherPayableOutstanding,
      borrowedOutstanding,
      otherPayableOutstanding,
      overdueCount,
    };
  }, [debts, todayISO]);

  const filteredDebts = useMemo(() => {
    return debts.filter((d) => {
      const repaid = d.repayments.reduce((s, r) => s + r.amountPaisa, 0);
      const rem = Math.max(0, d.principalPaisa - repaid);
      const isPaid = rem === 0;
      const isOverdue = !isPaid && Boolean(d.dueDate && d.dueDate < todayISO);
      const isReceivable =
        d.direction === 'LENT' || d.direction === 'RECEIVABLE_OTHER';

      if (filterTab === 'RECEIVABLE' && (!isReceivable || isPaid)) return false;
      if (filterTab === 'PAYABLE' && (isReceivable || isPaid)) return false;
      if (filterTab === 'OVERDUE' && !isOverdue) return false;
      if (filterTab === 'PAID' && !isPaid) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = d.contactName.toLowerCase().includes(q);
        const matchPhone = (d.phone ?? '').toLowerCase().includes(q);
        const matchNote = d.notes.toLowerCase().includes(q);
        if (!matchName && !matchPhone && !matchNote) return false;
      }
      return true;
    });
  }, [debts, filterTab, searchQuery, todayISO]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            দেনা ও পাওনা ব্যবস্থাপনা
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            ধার দেওয়া, ধার নেওয়া ও বাকির হিসাব
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => openNewDebtModal('LENT')}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>পাওনা যোগ করুন</span>
          </button>
          <button
            type="button"
            onClick={() => openNewDebtModal('BORROWED')}
            className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>দেনা যোগ করুন</span>
          </button>
        </div>
      </div>

      {/* 4-Card Summary Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">মোট পাওনা</p>
          <p className="mt-1 text-2xl font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
            {formatBDT(summary.totalReceivable, { useBengaliDigits })}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            ধার দেওয়া: {formatBDT(summary.lentOutstanding, { useBengaliDigits })}
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            বাকিতে বিক্রয় পাওনা
          </p>
          <p className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {formatBDT(summary.otherReceivableOutstanding, { useBengaliDigits })}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            ক্রেতার নিকট বকেয়া
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">মোট দেনা</p>
          <p className="mt-1 text-2xl font-bold font-mono tabular-nums text-amber-700 dark:text-amber-400">
            {formatBDT(summary.totalPayable, { useBengaliDigits })}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            ধার নেওয়া: {formatBDT(summary.borrowedOutstanding, { useBengaliDigits })}
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            বাকিতে ক্রয় দেনা
          </p>
          <p className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
            {formatBDT(summary.otherPayableOutstanding, { useBengaliDigits })}
          </p>
          <p className="mt-1 text-xs text-red-600 dark:text-red-400 font-medium">
            মেয়াদোত্তীর্ণ হিসাব: {summary.overdueCount}টি
          </p>
        </div>
      </section>

      {/* Filter Bar */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          {(
            [
              { id: 'ALL', label: 'সকল হিসাব' },
              { id: 'RECEIVABLE', label: 'পাওনা' },
              { id: 'PAYABLE', label: 'দেনা' },
              { id: 'OVERDUE', label: 'মেয়াদোত্তীর্ণ' },
              { id: 'PAID', label: 'পরিশোধিত' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilterTab(tab.id)}
              className={`min-h-[38px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                filterTab === tab.id
                  ? 'bg-slate-900 text-white dark:bg-emerald-600'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="নাম, ফোন নম্বর বা বিবরণ দিয়ে খুঁজুন..."
          className="w-full md:w-72 min-h-[40px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
        />
      </section>

      {/* Debts List */}
      <div className="space-y-4">
        {filteredDebts.length === 0 ? (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-12 text-center">
            <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
              কোনো দেনা বা পাওনার তথ্য পাওয়া যায়নি
            </p>
            <p className="text-xs text-slate-500 mt-1">
              উপরের বাটনে ক্লিক করে নতুন ধার বা বাকির হিসাব যোগ করুন।
            </p>
          </div>
        ) : (
          filteredDebts.map((debt) => {
            const repaidPaisa = debt.repayments.reduce(
              (s, r) => s + r.amountPaisa,
              0
            );
            const remainingPaisa = Math.max(
              0,
              debt.principalPaisa - repaidPaisa
            );
            const isPaid = remainingPaisa === 0;
            const isPartial = !isPaid && repaidPaisa > 0;
            const isOverdue =
              !isPaid && Boolean(debt.dueDate && debt.dueDate < todayISO);
            const isReceivable =
              debt.direction === 'LENT' ||
              debt.direction === 'RECEIVABLE_OTHER';

            const dirOption = DIRECTION_OPTIONS.find(
              (o) => o.dir === debt.direction
            );
            const isHistoryOpen = expandedHistoryDebtId === debt.id;

            return (
              <div
                key={debt.id}
                className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 transition-colors"
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                        {debt.contactName}
                      </h3>
                      <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">
                        ·
                      </span>
                      <span
                        className={`text-xs font-semibold ${
                          isReceivable
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-amber-700 dark:text-amber-400'
                        }`}
                      >
                        {dirOption?.labelBn}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      {debt.phone && (
                        <>
                          <span className="inline-flex items-center gap-1 font-mono">
                            <Phone className="w-3 h-3" /> {debt.phone}
                          </span>
                          <span aria-hidden="true">·</span>
                        </>
                      )}
                      <span>তারিখ: {formatDateBnEn(debt.date, useBengaliDigits)}</span>
                      {debt.dueDate && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>
                            শেষ তারিখ: {formatDateBnEn(debt.dueDate, useBengaliDigits)}
                          </span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>

                      {isPaid ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" /> পরিশোধিত
                        </span>
                      ) : isOverdue ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-red-600 dark:text-red-400">
                          <AlertCircle className="w-3.5 h-3.5" /> মেয়াদোত্তীর্ণ
                        </span>
                      ) : isPartial ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-amber-700 dark:text-amber-400">
                          <Clock className="w-3.5 h-3.5" /> আংশিক পরিশোধিত
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 font-medium text-slate-600 dark:text-slate-300">
                          <Clock className="w-3.5 h-3.5" /> চলমান
                        </span>
                      )}
                    </div>

                    {debt.notes && (
                      <p className="text-xs text-slate-600 dark:text-slate-300 pt-0.5">
                        বিবরণ: {debt.notes}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center gap-4 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-100 dark:border-slate-800 shrink-0">
                    <div className="sm:text-right">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        বাকি পরিমাণ:
                      </p>
                      <p
                        className={`text-xl font-bold font-mono tabular-nums ${
                          isPaid
                            ? 'text-slate-400 dark:text-slate-500'
                            : isReceivable
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-amber-700 dark:text-amber-400'
                        }`}
                      >
                        {formatBDT(remainingPaisa, { useBengaliDigits })}
                      </p>
                      <p className="text-[11px] font-mono tabular-nums text-slate-500">
                        মোট: {formatBDT(debt.principalPaisa, { useBengaliDigits })} · জমা:{' '}
                        {formatBDT(repaidPaisa, { useBengaliDigits })}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {!isPaid && (
                        <button
                          type="button"
                          onClick={() => openRepaymentModal(debt)}
                          className="min-h-[40px] px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                        >
                          + কিস্তি জমা
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() =>
                          setExpandedHistoryDebtId(
                            isHistoryOpen ? null : debt.id
                          )
                        }
                        className="min-h-[40px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                      >
                        <History className="w-3.5 h-3.5" />
                        <span>কিস্তির ইতিহাস ({debt.repayments.length})</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => openEditDebtModal(debt)}
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="সম্পাদনা"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteDebt(debt)}
                        className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {isHistoryOpen && (
                  <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                    <h4 className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">
                      কিস্তি ও পরিশোধের তালিকা
                    </h4>
                    {debt.repayments.length === 0 ? (
                      <p className="text-xs text-slate-500 py-2">
                        এখনো কোনো কিস্তি জমা হয়নি।
                      </p>
                    ) : (
                      <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
                        {debt.repayments.map((rep) => {
                          const accName = rep.accountId
                            ? accounts.find((a) => a.id === rep.accountId)
                                ?.nameBn
                            : undefined;
                          return (
                            <div
                              key={rep.id}
                              className="py-2.5 flex items-center justify-between gap-4 text-xs"
                            >
                              <div>
                                <span className="font-medium text-slate-800 dark:text-slate-200">
                                  {rep.note}
                                </span>
                                <span className="text-slate-400 mx-1.5">·</span>
                                <span className="text-slate-500">
                                  {formatDateBnEn(rep.date, useBengaliDigits)}
                                </span>
                                {accName && (
                                  <>
                                    <span className="text-slate-400 mx-1.5">
                                      ·
                                    </span>
                                    <span className="text-slate-500">
                                      {accName}
                                    </span>
                                  </>
                                )}
                              </div>
                              <div className="flex items-center gap-3 shrink-0">
                                <span className="font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                                  {formatBDT(rep.amountPaisa, {
                                    useBengaliDigits,
                                  })}
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    onDeleteRepayment(debt.id, rep.id)
                                  }
                                  className="text-slate-400 hover:text-red-600 p-1"
                                  title="এই কিস্তি মুছে ফেলুন"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Debt Modal */}
      {showDebtModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-lg rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 max-h-[92vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                {editingDebt ? 'হিসাব সম্পাদনা করুন' : 'নতুন দেনা বা পাওনা যোগ করুন'}
              </h2>
              <button
                type="button"
                onClick={() => setShowDebtModal(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDebtSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  হিসাবের ধরন *
                </label>
                <select
                  value={direction}
                  onChange={(e) =>
                    setDirection(e.target.value as DebtDirection)
                  }
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                >
                  {DIRECTION_OPTIONS.map((opt) => (
                    <option key={opt.dir} value={opt.dir}>
                      {opt.labelBn}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    নাম *
                  </label>
                  <input
                    type="text"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    placeholder="যেমন: রফিকুল ইসলাম"
                    required
                    className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    মোবাইল নম্বর
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="017XX-XXXXXX"
                    className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    টাকার পরিমাণ (৳) *
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={principalInput}
                    onChange={(e) => setPrincipalInput(e.target.value)}
                    placeholder="১২০০"
                    required
                    className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono tabular-nums text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    তারিখ *
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    required
                    className="w-full min-h-[44px] px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    পরিশোধের শেষ তারিখ
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full min-h-[44px] px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  কোন হিসাবে যাবে
                </label>
                <select
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                >
                  <option value="">কোনো হিসাব নয় (বাকিতে মালামাল)</option>
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.nameBn}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  বিবরণ
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="অতিরিক্ত তথ্য..."
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowDebtModal(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-700 dark:text-slate-300"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Partial Repayment Modal */}
      {activeDebtForRepayment && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  কিস্তি জমা করুন
                </h3>
                <p className="text-xs text-slate-500">
                  {activeDebtForRepayment.contactName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveDebtForRepayment(null)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRepaymentSubmit} className="mt-4 space-y-4">
              {repayError && (
                <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300">
                  {repayError}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    পরিমাণ (৳) *
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={repayAmountInput}
                    onChange={(e) => setRepayAmountInput(e.target.value)}
                    required
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-mono tabular-nums text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    তারিখ *
                  </label>
                  <input
                    type="date"
                    value={repayDate}
                    onChange={(e) => setRepayDate(e.target.value)}
                    required
                    className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  কোন হিসাবে যাবে
                </label>
                <select
                  value={repayAccountId}
                  onChange={(e) => setRepayAccountId(e.target.value)}
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                >
                  <option value="">কোনো হিসাব ব্যালেন্স পরিবর্তন করবেন না</option>
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.nameBn}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  বিবরণ
                </label>
                <input
                  type="text"
                  value={repayNote}
                  onChange={(e) => setRepayNote(e.target.value)}
                  placeholder="যেমন: ২য় কিস্তি প্রাপ্ত..."
                  className="w-full min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveDebtForRepayment(null)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium"
                >
                  জমা নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
