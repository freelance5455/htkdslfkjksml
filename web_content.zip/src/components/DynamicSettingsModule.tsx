import React, { useMemo, useState } from 'react';
import {
  Archive,
  ArrowDown,
  ArrowUp,
  Check,
  Eye,
  EyeOff,
  Plus,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { evaluateFormula, formatNumber } from '../utils/calculations';
import { generateId } from '../utils/storage';
import type { CustomFieldDef, CustomFieldType, CustomModuleDef } from '../types';

const FIELD_TYPES: { value: CustomFieldType; label: string }[] = [
  { value: 'short_text', label: 'Short Text' },
  { value: 'long_text', label: 'Long Text' },
  { value: 'number', label: 'Number (Integer)' },
  { value: 'decimal', label: 'Decimal' },
  { value: 'date', label: 'Date' },
  { value: 'dropdown', label: 'Dropdown' },
  { value: 'multi_select', label: 'Multi-Select' },
  { value: 'checkbox', label: 'Checkbox' },
  { value: 'formula', label: 'Calculated / Formula' },
];

export const DynamicSettingsModule: React.FC = () => {
  const { state, saveCustomModules, updateSettings, themeTokens, notify, navigate } = useApp();

  // Draft copy so user can preview before applying
  const [draftModules, setDraftModules] = useState<CustomModuleDef[]>(() =>
    JSON.parse(JSON.stringify(state.customModules))
  );
  const [selectedModId, setSelectedModId] = useState<string>(state.customModules[0]?.id || '');
  const [hasUnsaved, setHasUnsaved] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  // New module form
  const [newModName, setNewModName] = useState('');
  const [newModDesc, setNewModDesc] = useState('');

  // New submodule
  const [newSubName, setNewSubName] = useState('');

  // New field form
  const [fLabel, setFLabel] = useState('');
  const [fType, setFType] = useState<CustomFieldType>('short_text');
  const [fRequired, setFRequired] = useState(false);
  const [fDefault, setFDefault] = useState('');
  const [fPlaceholder, setFPlaceholder] = useState('');
  const [fUnit, setFUnit] = useState('');
  const [fOptions, setFOptions] = useState('');
  const [fFormula, setFFormula] = useState('');
  const [fShowForm, setFShowForm] = useState(true);
  const [fShowTable, setFShowTable] = useState(true);
  const [fShowReport, setFShowReport] = useState(true);

  const selectedMod = useMemo(
    () => draftModules.find((m) => m.id === selectedModId) || null,
    [draftModules, selectedModId]
  );

  const numericFieldKeys = useMemo(
    () =>
      (selectedMod?.fields || []).filter(
        (f) => !f.archived && (f.type === 'number' || f.type === 'decimal' || f.type === 'formula')
      ),
    [selectedMod]
  );

  const markDraft = (next: CustomModuleDef[]) => {
    setDraftModules(next);
    setHasUnsaved(true);
  };

  const handleCreateModule = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newModName.trim();
    if (!name) return;
    const mod: CustomModuleDef = {
      id: generateId('cmod'),
      name,
      description: newModDesc.trim(),
      icon: 'boxes',
      order: draftModules.length + 1,
      visible: true,
      archived: false,
      submodules: [],
      fields: [],
      summaryAggregation: 'count',
    };
    const next = [...draftModules, mod];
    markDraft(next);
    setSelectedModId(mod.id);
    setNewModName('');
    setNewModDesc('');
  };

  const updateSelectedMod = (patch: Partial<CustomModuleDef>) => {
    if (!selectedMod) return;
    markDraft(draftModules.map((m) => (m.id === selectedMod.id ? { ...m, ...patch } : m)));
  };

  const handleAddSubmodule = () => {
    if (!selectedMod || !newSubName.trim()) return;
    const sub = {
      id: generateId('csub'),
      name: newSubName.trim(),
      description: '',
      order: selectedMod.submodules.length + 1,
      visible: true,
      archived: false,
    };
    updateSelectedMod({ submodules: [...selectedMod.submodules, sub] });
    setNewSubName('');
  };

  const handleAddField = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMod || !fLabel.trim()) return;
    const rawKey = fLabel
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_|_$/g, '');
    const key =
      selectedMod.fields.some((f) => f.key === rawKey) || !rawKey
        ? `${rawKey || 'field'}_${selectedMod.fields.length + 1}`
        : rawKey;

    const field: CustomFieldDef = {
      id: generateId('cf'),
      key,
      label: fLabel.trim(),
      type: fType,
      required: fRequired,
      defaultValue: fDefault,
      placeholder: fPlaceholder,
      unit: fUnit.trim(),
      options:
        fType === 'dropdown' || fType === 'multi_select'
          ? fOptions
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean)
          : [],
      formula: fType === 'formula' ? fFormula.trim() : '',
      order: selectedMod.fields.length + 1,
      visible: true,
      archived: false,
      showInForm: fShowForm,
      showInTable: fShowTable,
      showInReport: fShowReport,
    };

    updateSelectedMod({ fields: [...selectedMod.fields, field] });
    setFLabel('');
    setFType('short_text');
    setFRequired(false);
    setFDefault('');
    setFPlaceholder('');
    setFUnit('');
    setFOptions('');
    setFFormula('');
  };

  const moveField = (idx: number, dir: -1 | 1) => {
    if (!selectedMod) return;
    const target = idx + dir;
    if (target < 0 || target >= selectedMod.fields.length) return;
    const copy = [...selectedMod.fields];
    [copy[idx], copy[target]] = [copy[target], copy[idx]];
    updateSelectedMod({ fields: copy.map((f, i) => ({ ...f, order: i + 1 })) });
  };

  const applyChanges = () => {
    saveCustomModules(draftModules, `Applied Dynamic Settings (${draftModules.length} custom modules)`);
    setHasUnsaved(false);
    notify('Dynamic Settings saved and applied.');
  };

  const discardChanges = () => {
    setDraftModules(JSON.parse(JSON.stringify(state.customModules)));
    setHasUnsaved(false);
    notify('Draft changes discarded.', 'info');
  };

  // Sample test values for formula preview
  const samplePreviewResult = useMemo(() => {
    if (!fFormula.trim()) return 0;
    const sample: Record<string, number> = {};
    numericFieldKeys.forEach((f, idx) => {
      sample[f.key] = (idx + 1) * 10;
    });
    return evaluateFormula(fFormula, sample);
  }, [fFormula, numericFieldKeys]);

  const builtInVis = state.settings.builtInModuleVisibility;

  return (
    <div className="space-y-6">
      {/* Header & Apply Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">Dynamic Settings / App Builder</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Create working custom modules, submodules, fields, dropdown lists, and calculated formulas without editing code. Built-in modules are protected from deletion.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowPreview((v) => !v)}
            className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            {showPreview ? 'Hide Preview' : 'Preview Form'}
          </button>
          {hasUnsaved && (
            <button
              type="button"
              onClick={discardChanges}
              className="rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              Discard Draft
            </button>
          )}
          <button
            type="button"
            onClick={applyChanges}
            className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white whitespace-nowrap ${themeTokens.accentBg} ${themeTokens.accentHover}`}
          >
            <Check className="h-4 w-4" />
            <span>{hasUnsaved ? 'Apply & Save Changes' : 'Saved'}</span>
          </button>
        </div>
      </div>

      {/* Built-in Modules Protection & Visibility */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-900">Built-In Modules (Protected)</h3>
          <span className="text-xs text-slate-500">Built-in formulas &amp; ledgers cannot be deleted</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {(['home', 'factory', 'personal'] as const).map((key) => (
            <div
              key={key}
              className="flex items-center justify-between rounded-lg border border-slate-200 px-3.5 py-2.5 text-sm"
            >
              <span className="font-medium capitalize text-slate-800">{key} Module</span>
              <button
                type="button"
                onClick={() =>
                  updateSettings(
                    {
                      builtInModuleVisibility: {
                        ...builtInVis,
                        [key]: !builtInVis[key],
                      },
                    },
                    `Toggled visibility of ${key} module`
                  )
                }
                className="inline-flex items-center gap-1 text-xs font-medium text-slate-600 hover:text-emerald-700"
              >
                {builtInVis[key] ? <Eye className="h-4 w-4 text-emerald-600" /> : <EyeOff className="h-4 w-4" />}
                <span>{builtInVis[key] ? 'Visible' : 'Hidden'}</span>
              </button>
            </div>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Custom Modules List & Creator */}
        <div className="lg:col-span-4 space-y-4">
          <form onSubmit={handleCreateModule} className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
            <h3 className="text-sm font-semibold text-slate-900">Create Custom Module</h3>
            <div>
              <label htmlFor="cm-name" className="block text-xs font-medium text-slate-700 mb-1">
                Module Name *
              </label>
              <input
                id="cm-name"
                type="text"
                value={newModName}
                onChange={(e) => setNewModName(e.target.value)}
                placeholder="e.g. Vehicle Fuel Log"
                required
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="cm-desc" className="block text-xs font-medium text-slate-700 mb-1">
                Description
              </label>
              <input
                id="cm-desc"
                type="text"
                value={newModDesc}
                onChange={(e) => setNewModDesc(e.target.value)}
                placeholder="Track fuel, mileage & cost"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <button
              type="submit"
              className={`w-full inline-flex items-center justify-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
            >
              <Plus className="h-4 w-4" />
              <span>Add Custom Module</span>
            </button>
          </form>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 text-xs font-semibold text-slate-700">
              Custom Modules ({draftModules.length})
            </div>
            {draftModules.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                No custom modules created yet.
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {draftModules.map((mod) => (
                  <div
                    key={mod.id}
                    className={`flex items-center justify-between gap-2 px-4 py-3 cursor-pointer ${
                      selectedModId === mod.id ? 'bg-emerald-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setSelectedModId(mod.id)}
                      className="flex-1 text-start min-w-0"
                    >
                      <div
                        className={`text-sm font-medium truncate ${
                          mod.archived ? 'line-through text-slate-400' : 'text-slate-900'
                        }`}
                      >
                        {mod.name}
                      </div>
                      <div className="text-xs text-slate-500">
                        {mod.fields.filter((f) => !f.archived).length} fields ·{' '}
                        {mod.archived ? 'Archived' : mod.visible ? 'Visible' : 'Hidden'}
                      </div>
                    </button>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() =>
                          markDraft(
                            draftModules.map((m) =>
                              m.id === mod.id ? { ...m, visible: !m.visible } : m
                            )
                          )
                        }
                        aria-label={`Toggle visibility for ${mod.name}`}
                        className="p-1 text-slate-500 hover:text-slate-900"
                      >
                        {mod.visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          markDraft(
                            draftModules.map((m) =>
                              m.id === mod.id ? { ...m, archived: !m.archived } : m
                            )
                          )
                        }
                        aria-label={mod.archived ? `Recover ${mod.name}` : `Archive ${mod.name}`}
                        className="p-1 text-slate-500 hover:text-amber-700"
                      >
                        {mod.archived ? (
                          <RotateCcw className="h-3.5 w-3.5" />
                        ) : (
                          <Archive className="h-3.5 w-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Selected Module Designer */}
        <div className="lg:col-span-8 space-y-5">
          {!selectedMod ? (
            <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
              Create or select a custom module on the left to configure its fields, formulas, submodules, and summary mapping.
            </div>
          ) : (
            <>
              {/* Module Details & Summary Mapping */}
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-sm font-semibold text-slate-900">
                    Module Settings: {selectedMod.name}
                  </h3>
                  {!hasUnsaved && !selectedMod.archived && (
                    <button
                      type="button"
                      onClick={() => navigate(`custom:${selectedMod.id}`)}
                      className="text-xs font-medium text-emerald-700 hover:underline"
                    >
                      Open Live Module
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Module Name</label>
                    <input
                      type="text"
                      value={selectedMod.name}
                      onChange={(e) => updateSelectedMod({ name: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Dashboard Summary Metric
                    </label>
                    <div className="flex gap-2">
                      <select
                        value={selectedMod.summaryAggregation || 'count'}
                        onChange={(e) =>
                          updateSelectedMod({
                            summaryAggregation: e.target.value as 'sum' | 'count' | 'avg',
                          })
                        }
                        className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs bg-white"
                      >
                        <option value="count">Record Count</option>
                        <option value="sum">Sum Field</option>
                        <option value="avg">Average Field</option>
                      </select>
                      {selectedMod.summaryAggregation !== 'count' && (
                        <select
                          value={selectedMod.summaryFieldKey || ''}
                          onChange={(e) => updateSelectedMod({ summaryFieldKey: e.target.value })}
                          className="flex-1 rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs bg-white"
                        >
                          <option value="">Select numeric field...</option>
                          {numericFieldKeys.map((f) => (
                            <option key={f.id} value={f.key}>
                              {f.label}
                            </option>
                          ))}
                        </select>
                      )}
                    </div>
                  </div>
                </div>

                {/* Submodules */}
                <div className="pt-2 border-t border-slate-100 space-y-2">
                  <div className="text-xs font-semibold text-slate-700">Submodules (Optional Tabs)</div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newSubName}
                      onChange={(e) => setNewSubName(e.target.value)}
                      placeholder="Submodule name (e.g. Bike, Car)"
                      className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs"
                    />
                    <button
                      type="button"
                      onClick={handleAddSubmodule}
                      className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                    >
                      Add Submodule
                    </button>
                  </div>
                  {selectedMod.submodules.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-1">
                      {selectedMod.submodules.map((sub) => (
                        <div
                          key={sub.id}
                          className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs"
                        >
                          <span>{sub.name}</span>
                          <button
                            type="button"
                            onClick={() =>
                              updateSelectedMod({
                                submodules: selectedMod.submodules.filter((s) => s.id !== sub.id),
                              })
                            }
                            aria-label={`Remove submodule ${sub.name}`}
                            className="text-slate-400 hover:text-red-600"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Add Field Form */}
              <form onSubmit={handleAddField} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <h3 className="text-sm font-semibold text-slate-900">Add Field to {selectedMod.name}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label htmlFor="cf-label" className="block text-xs font-medium text-slate-700 mb-1">
                      Field Label *
                    </label>
                    <input
                      id="cf-label"
                      type="text"
                      value={fLabel}
                      onChange={(e) => setFLabel(e.target.value)}
                      placeholder="e.g. Liters, Rate, Total Cost"
                      required
                      className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
                    />
                  </div>
                  <div>
                    <label htmlFor="cf-type" className="block text-xs font-medium text-slate-700 mb-1">
                      Field Type
                    </label>
                    <select
                      id="cf-type"
                      value={fType}
                      onChange={(e) => setFType(e.target.value as CustomFieldType)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm bg-white"
                    >
                      {FIELD_TYPES.map((ft) => (
                        <option key={ft.value} value={ft.value}>
                          {ft.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="cf-unit" className="block text-xs font-medium text-slate-700 mb-1">
                      Unit (Optional)
                    </label>
                    <input
                      id="cf-unit"
                      type="text"
                      value={fUnit}
                      onChange={(e) => setFUnit(e.target.value)}
                      placeholder="PKR, Liters, KM..."
                      className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
                    />
                  </div>
                </div>

                {(fType === 'dropdown' || fType === 'multi_select') && (
                  <div>
                    <label htmlFor="cf-opts" className="block text-xs font-medium text-slate-700 mb-1">
                      Options (comma-separated)
                    </label>
                    <input
                      id="cf-opts"
                      type="text"
                      value={fOptions}
                      onChange={(e) => setFOptions(e.target.value)}
                      placeholder="Petrol, Diesel, Hi-Octane"
                      className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
                    />
                  </div>
                )}

                {fType === 'formula' && (
                  <div className="space-y-2 rounded-lg border border-emerald-200 bg-emerald-50/40 p-3">
                    <label htmlFor="cf-formula" className="block text-xs font-semibold text-emerald-900">
                      Formula Builder (Use {'{field_key}'} with +, -, *, /)
                    </label>
                    <input
                      id="cf-formula"
                      type="text"
                      value={fFormula}
                      onChange={(e) => setFFormula(e.target.value)}
                      placeholder="e.g. {liters} * {rate}"
                      className="w-full rounded-lg border border-emerald-300 bg-white px-3 py-1.5 text-sm font-mono"
                    />
                    {numericFieldKeys.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5 text-xs">
                        <span className="text-slate-600">Insert field:</span>
                        {numericFieldKeys.map((nf) => (
                          <button
                            key={nf.id}
                            type="button"
                            onClick={() => setFFormula((prev) => `${prev}{${nf.key}}`)}
                            className="rounded border border-emerald-300 bg-white px-2 py-0.5 font-mono text-emerald-800 hover:bg-emerald-100"
                          >
                            {`{${nf.key}}`}
                          </button>
                        ))}
                      </div>
                    )}
                    {fFormula && (
                      <div className="text-xs text-emerald-800 tabular-nums">
                        Sample preview output: {formatNumber(samplePreviewResult)}
                      </div>
                    )}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <div className="flex flex-wrap gap-4 text-xs text-slate-700">
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={fRequired}
                        onChange={(e) => setFRequired(e.target.checked)}
                      />
                      <span>Required</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={fShowForm}
                        onChange={(e) => setFShowForm(e.target.checked)}
                      />
                      <span>In Form</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={fShowTable}
                        onChange={(e) => setFShowTable(e.target.checked)}
                      />
                      <span>In Table</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={fShowReport}
                        onChange={(e) => setFShowReport(e.target.checked)}
                      />
                      <span>In Report</span>
                    </label>
                  </div>
                  <button
                    type="submit"
                    className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-xs font-semibold text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Add Field</span>
                  </button>
                </div>
              </form>

              {/* Fields List */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200 text-xs font-semibold text-slate-700">
                  Configured Fields ({selectedMod.fields.length})
                </div>
                {selectedMod.fields.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No fields added yet. Add fields above to start recording entries.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {selectedMod.fields.map((f, idx) => (
                      <div key={f.id} className="flex items-center justify-between gap-2 px-4 py-2.5 text-xs">
                        <div className="min-w-0">
                          <span className={`font-semibold ${f.archived ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                            {f.label}
                          </span>
                          <span className="ms-2 font-mono text-slate-400">{`{${f.key}}`}</span>
                          <span className="ms-2 text-slate-500">
                            · {f.type}
                            {f.required ? ' · Required' : ''}
                            {f.formula ? ` · = ${f.formula}` : ''}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => moveField(idx, -1)}
                            disabled={idx === 0}
                            aria-label={`Move ${f.label} up`}
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30"
                          >
                            <ArrowUp className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveField(idx, 1)}
                            disabled={idx === selectedMod.fields.length - 1}
                            aria-label={`Move ${f.label} down`}
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30"
                          >
                            <ArrowDown className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              updateSelectedMod({
                                fields: selectedMod.fields.map((x) =>
                                  x.id === f.id ? { ...x, archived: !x.archived } : x
                                ),
                              })
                            }
                            aria-label={f.archived ? `Restore ${f.label}` : `Archive ${f.label}`}
                            className="p-1 text-slate-500 hover:text-amber-700"
                          >
                            {f.archived ? (
                              <RotateCcw className="h-3.5 w-3.5" />
                            ) : (
                              <Archive className="h-3.5 w-3.5" />
                            )}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Live Preview before applying */}
              {showPreview && (
                <div className="bg-slate-900 text-white rounded-xl p-5 space-y-3">
                  <div className="text-xs font-semibold text-emerald-400">
                    Form Preview: {selectedMod.name}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {selectedMod.fields
                      .filter((f) => !f.archived && f.showInForm)
                      .map((f) => (
                        <div key={f.id} className="rounded-lg bg-slate-800 p-3">
                          <div className="text-xs text-slate-300">
                            {f.label} {f.required ? '*' : ''}
                          </div>
                          <div className="mt-1 text-xs text-slate-400">
                            [{f.type}] {f.formula ? `Formula: ${f.formula}` : f.placeholder || ''}
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
