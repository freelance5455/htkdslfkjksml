import { motion } from "framer-motion";
import { ArrowUpRight, Check, ChevronRight, CircleAlert, Clock3, Heart, LoaderCircle, Radio, ShieldCheck } from "lucide-react";
import type { ProxyRecord } from "../types";
import { COUNTRY_NAMES } from "../data/sources";
import { relativeTime, typeLabel } from "../lib/proxy";

interface ProxyRowProps {
  proxy: ProxyRecord;
  index: number;
  favorite: boolean;
  onFavorite: () => void;
  onConnect: () => void;
  onDetails: () => void;
}

export function ProxyRow({ proxy, index, favorite, onFavorite, onConnect, onDetails }: ProxyRowProps) {
  const live = proxy.live;
  const statusLabel = live?.state === "online" ? "Доступен сейчас"
    : live?.state === "offline" ? "Не отвечает checker"
      : live?.state === "error" ? "Ошибка проверки"
        : proxy.verification === "telegram" ? "Telegram DC подтверждён"
          : proxy.verification === "handshake" ? "Handshake подтверждён"
            : proxy.verification === "tcp" ? "Доступность подтверждена" : "Добавлен вручную";
  const ping = live?.state === "online" && live.latency !== null ? live.latency : proxy.latency;
  const pingTone = ping === null ? "text-ink/35" : ping <= 100 ? "text-[#23734a]" : ping <= 250 ? "text-[#9a6a16]" : "text-[#a44b42]";

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.32, delay: Math.min(index * 0.025, 0.2) }}
      className="group relative grid grid-cols-[1fr_auto] gap-4 border-b border-ink/[0.08] bg-white px-4 py-5 transition-colors last:border-b-0 hover:bg-[#fafbf8] sm:px-6 lg:grid-cols-[minmax(250px,1.7fr)_.6fr_auto] lg:items-center lg:gap-5 xl:grid-cols-[minmax(250px,1.7fr)_.65fr_.6fr_.6fr_.6fr_auto]"
    >
      <div className="min-w-0">
        <div className="flex items-center gap-2.5">
          <span className={`h-2 w-2 shrink-0 rounded-full ${live?.state === "offline" || live?.state === "error" ? "bg-[#c46a5e]" : proxy.isManual ? "bg-ink/25" : "bg-[#55ad79]"}`} />
          <h3 className="truncate font-mono text-[13px] font-semibold tracking-tight text-ink sm:text-sm" title={proxy.server}>{proxy.server}</h3>
          <span className="shrink-0 font-mono text-xs text-ink/35">:{proxy.port}</span>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1.5 pl-[18px] text-[10px] text-ink/40">
          <span className="inline-flex items-center gap-1.5">
            {live?.state === "checking" ? <LoaderCircle size={12} className="animate-spin" /> : live?.state === "error" || live?.state === "offline" ? <CircleAlert size={12} /> : proxy.isManual ? <Radio size={12} /> : <ShieldCheck size={12} className="text-[#4a9c6d]" />}
            {live?.state === "checking" ? "Проверяем…" : statusLabel}
          </span>
          <span className="hidden items-center gap-1 sm:inline-flex"><Clock3 size={11} />{relativeTime(proxy.lastChecked)}</span>
        </div>
      </div>

      <div className="col-span-2 grid grid-cols-3 gap-3 border-y border-ink/[0.06] py-3 lg:col-span-1 lg:contents lg:border-0 lg:py-0">
        <div className="lg:hidden xl:block">
          <div className="text-[9px] font-semibold uppercase tracking-[0.13em] text-ink/30">Задержка</div>
          <div className={`mt-1.5 font-display text-lg font-semibold ${pingTone}`}>{ping !== null ? ping : "—"}<span className="ml-1 text-[9px] font-normal text-ink/30">{ping !== null ? "мс" : "нет RTT"}</span></div>
        </div>
        <div className="lg:hidden xl:block">
          <div className="text-[9px] font-semibold uppercase tracking-[0.13em] text-ink/30">Uptime</div>
          <div className="mt-1.5 font-display text-lg font-semibold text-ink/75">{proxy.uptime !== null ? Math.round(proxy.uptime) : "—"}<span className="ml-1 text-[9px] font-normal text-ink/30">{proxy.uptime !== null ? "%" : "нет данных"}</span></div>
        </div>
        <div className="lg:hidden xl:block">
          <div className="text-[9px] font-semibold uppercase tracking-[0.13em] text-ink/30">Оценка</div>
          <div className="mt-1.5 flex items-center gap-2"><span className="font-display text-lg font-semibold text-ink/75">{proxy.score}</span><span className="hidden h-1 w-10 overflow-hidden rounded-full bg-ink/10 2xl:block"><span className="block h-full rounded-full bg-ink" style={{ width: `${proxy.score}%` }} /></span></div>
        </div>
      </div>

      <div className="hidden min-w-0 lg:block">
        <span className={`inline-flex rounded-md px-2 py-1 text-[9px] font-bold tracking-wide ${proxy.type === "faketls" ? "bg-[#e8f5df] text-[#407535]" : "bg-ink/[0.05] text-ink/50"}`}>{typeLabel(proxy.type)}</span>
        <div className="mt-2 truncate text-[10px] text-ink/40">{proxy.country ? `${proxy.country} · ${COUNTRY_NAMES[proxy.country] ?? "Регион"}` : "Регион неизвестен"}</div>
      </div>

      <div className="col-span-2 flex items-center justify-between gap-2 lg:col-span-1 lg:justify-end">
        <div className="flex items-center gap-1">
          <button onClick={onFavorite} className={`grid h-10 w-10 place-items-center rounded-full transition-colors ${favorite ? "bg-[#eaf5e2] text-[#477c3b]" : "text-ink/30 hover:bg-ink/[0.05] hover:text-ink"}`} aria-label={favorite ? "Удалить из избранного" : "Добавить в избранное"}><Heart size={17} fill={favorite ? "currentColor" : "none"} /></button>
          <button onClick={onDetails} className="grid h-10 w-10 place-items-center rounded-full text-ink/30 transition-colors hover:bg-ink/[0.05] hover:text-ink" aria-label="Подробнее о прокси"><ChevronRight size={18} /></button>
        </div>
        <button onClick={onConnect} className="group/button inline-flex h-10 items-center gap-2 rounded-full bg-ink px-4 text-[11px] font-bold text-white transition-all hover:bg-[#263c33] sm:px-5">
          Подключить <ArrowUpRight size={14} className="transition-transform group-hover/button:-translate-y-0.5 group-hover/button:translate-x-0.5" />
        </button>
      </div>

      {proxy.sourceIds.length > 1 && <span className="absolute right-4 top-3 hidden items-center gap-1 text-[9px] font-semibold text-[#4c8863] xl:flex"><Check size={10} />{proxy.sourceIds.length} подтверждения</span>}
    </motion.article>
  );
}
