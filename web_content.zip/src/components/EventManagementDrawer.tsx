import React, { useState, useRef, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  TrendingUp,
  Ticket,
  Users,
  User,
  Plus,
  Trash2,
  Calendar,
  Clock,
  MapPin,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Search,
  DollarSign,
  Smartphone,
  CreditCard,
  RotateCcw,
  ShieldCheck,
  Check,
  Edit,
  ArrowRight,
  ExternalLink,
  Loader2,
  Lock,
} from 'lucide-react';
import { EventItem, CustomGroupTier, PurchasedTicket, EventCategory, EventTicketTier } from '../types';
import { triggerHaptic } from '../utils/haptics';

interface EventManagementDrawerProps {
  event: EventItem;
  onClose: () => void;
}

type DrawerTab = 'analytics' | 'edit' | 'cancel';

export const EventManagementDrawer: React.FC<EventManagementDrawerProps> = ({ event, onClose }) => {
  const {
    tickets,
    updateEvent,
    deleteEvent,
    showToast,
    formatKsh,
    checkInTicket,
  } = useApp();

  const [activeTab, setActiveTab] = useState<DrawerTab>('analytics');

  // ==========================================
  // REAL-TIME PER-EVENT DYNAMIC METRICS
  // ==========================================
  const eventTickets = useMemo(() => {
    return tickets.filter((t) => t.eventId === event.id);
  }, [tickets, event.id]);

  const nonRefundedTickets = useMemo(() => {
    return eventTickets.filter((t) => t.status !== 'refunded');
  }, [eventTickets]);

  // Baseline addition for curated showcase events if not user created
  const baseRevenueOffset = event.isUserCreated ? 0 : 36000;
  const basePassesOffset = event.isUserCreated ? 0 : 12;
  const baseAdmittedOffset = event.isUserCreated ? 0 : 4;

  const eventGrossSales = useMemo(() => {
    const raw = nonRefundedTickets.reduce((acc, t) => acc + (t.totalPaid || 0), 0);
    return raw + baseRevenueOffset;
  }, [nonRefundedTickets, baseRevenueOffset]);

  const usdEquivalent = Math.round(eventGrossSales / 130);

  const eventPassesSold = useMemo(() => {
    const raw = nonRefundedTickets.reduce((acc, t) => acc + (t.quantity || 1), 0);
    return raw + basePassesOffset;
  }, [nonRefundedTickets, basePassesOffset]);

  const totalCapacity = event.capacity || 1000;
  const remainingInventory = Math.max(0, totalCapacity - eventPassesSold);
  const soldPercentage = Math.min(100, Math.round((eventPassesSold / totalCapacity) * 100));

  const eventAdmittedCount = useMemo(() => {
    const raw = eventTickets.filter((t) => t.status === 'used').reduce((acc, t) => acc + (t.quantity || 1), 0);
    return raw + baseAdmittedOffset;
  }, [eventTickets, baseAdmittedOffset]);

  // Available / Settled balance for this single event
  const settledBalance = eventGrossSales;

  // ==========================================
  // LIVE BUYER FEED SEARCH & FILTER
  // ==========================================
  const [buyerSearch, setBuyerSearch] = useState('');
  const [buyerFilter, setBuyerFilter] = useState<'all' | 'active' | 'used' | 'refunded'>('all');

  const filteredBuyerTickets = useMemo(() => {
    return eventTickets.filter((t) => {
      const q = buyerSearch.toLowerCase().trim();
      const matchSearch =
        !q ||
        t.holderName.toLowerCase().includes(q) ||
        (t.holderEmail && t.holderEmail.toLowerCase().includes(q)) ||
        (t.holderPhone && t.holderPhone.toLowerCase().includes(q)) ||
        t.ticketCode.toLowerCase().includes(q) ||
        (t.orderNumber && t.orderNumber.toLowerCase().includes(q)) ||
        (t.transactionRef && t.transactionRef.toLowerCase().includes(q));

      if (!matchSearch) return false;
      if (buyerFilter === 'active') return t.status === 'active';
      if (buyerFilter === 'used') return t.status === 'used';
      if (buyerFilter === 'refunded') return t.status === 'refunded';
      return true;
    });
  }, [eventTickets, buyerSearch, buyerFilter]);

  // ==========================================
  // EVENT MODIFICATION FORM STATE
  // ==========================================
  const [title, setTitle] = useState(event.title);
  const [subtitle, setSubtitle] = useState(event.subtitle || '');
  const [category, setCategory] = useState<EventCategory>(event.category || 'concerts');
  const [city, setCity] = useState(event.city || 'Nairobi');
  const [venue, setVenue] = useState(event.venue);
  const [address, setAddress] = useState(event.address || `${event.venue}, ${event.city}`);
  const [date, setDate] = useState(event.date);
  const [time, setTime] = useState(event.time);
  const [doorTime, setDoorTime] = useState(event.doorTime || '5:00 PM (1 hr prior)');
  const [description, setDescription] = useState(event.description || '');
  const [posterImage, setPosterImage] = useState(event.image);
  const [personalPrice, setPersonalPrice] = useState(String(event.personalPrice || event.price || 2500));
  const [capacityInput, setCapacityInput] = useState(String(event.capacity || 1000));

  // Social Links
  const [instagram, setInstagram] = useState(event.instagram || '');
  const [tiktok, setTiktok] = useState(event.tiktok || '');
  const [gmail, setGmail] = useState(event.gmail || event.hostEmail || '');

  // Admission Ticket Tiers (Early Bird, Regular, VIP, VVIP) with Customizable Passes to Sell to Any Amount
  const [admissionTiers, setAdmissionTiers] = useState<EventTicketTier[]>(
    event.tiers && event.tiers.length > 0
      ? event.tiers
      : [
          {
            id: 'tier_early',
            name: 'Early Bird Pass',
            price: Math.round((event.personalPrice || event.price || 2500) * 0.85),
            capacity: 200,
            description: 'Exclusive early admission with expedited gate entry',
            perks: 'Fast-track gate pass',
          },
          {
            id: 'tier_regular',
            name: 'Regular Admission',
            price: event.personalPrice || event.price || 2500,
            capacity: 800,
            description: 'Standard festival entry to all main stages and grounds',
            perks: 'General admission, all stages',
          },
          {
            id: 'tier_vip',
            name: 'VIP Raised Lounge',
            price: Math.round((event.personalPrice || event.price || 2500) * 1.8),
            capacity: 150,
            description: 'Priority lounge access, private bar, and elevated view',
            perks: 'VIP Lounge, private bar',
          },
          {
            id: 'tier_vvip',
            name: 'VVIP Diamond Access',
            price: Math.round((event.personalPrice || event.price || 2500) * 3.5),
            capacity: 50,
            description: 'Backstage pass, artist meet & greet, all-inclusive hospitality',
            perks: 'All-inclusive backstage pass',
          },
        ]
  );

  // Group Tiers
  const [groupTiers, setGroupTiers] = useState<CustomGroupTier[]>(
    event.groupTiers && event.groupTiers.length > 0
      ? event.groupTiers
      : [
          {
            id: `tier_${Date.now()}_1`,
            name: 'Squad Group Pass (4 Guests)',
            size: 4,
            price: Math.round((event.personalPrice || event.price || 2500) * 4 * 0.85),
            perks: '4 wristbands, 15% bundle discount, expedited gate entry',
          },
        ]
  );

  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Host M-Pesa PIN Cancellation & Automated B2C Refund State
  const [showCancelConfirmModal, setShowCancelConfirmModal] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [hostMpesaPin, setHostMpesaPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [refundReversalDone, setRefundReversalDone] = useState<{
    reversalRef: string;
    amount: number;
    count: number;
  } | null>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPosterImage(reader.result);
          showToast('Custom artwork loaded for event!');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddAdmissionTier = (preset?: { name: string; price: number; capacity: number; description: string; perks: string }) => {
    triggerHaptic('light');
    const newTier: EventTicketTier = preset
      ? {
          id: `tier_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          ...preset,
        }
      : {
          id: `tier_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
          name: 'Custom Admission Tier',
          price: Number(personalPrice || 2500),
          capacity: 100,
          description: 'Special access pass',
          perks: 'Gate entry',
        };
    setAdmissionTiers((prev) => [...prev, newTier]);
  };

  const handleUpdateAdmissionTier = (id: string, updates: Partial<EventTicketTier>) => {
    setAdmissionTiers((prev) =>
      prev.map((tier) => (tier.id === id ? { ...tier, ...updates } : tier))
    );
  };

  const handleRemoveAdmissionTier = (id: string) => {
    triggerHaptic('light');
    setAdmissionTiers((prev) => prev.filter((tier) => tier.id !== id));
  };

  const handleAddGroupTier = () => {
    triggerHaptic('light');
    const newTier: CustomGroupTier = {
      id: `tier_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: `VIP Table Experience (${groupTiers.length + 5} Guests)`,
      size: groupTiers.length + 5,
      price: Math.round(Number(personalPrice || 2500) * (groupTiers.length + 5) * 0.9),
      perks: 'VIP lounge passes & dedicated bottle service',
    };
    setGroupTiers([...groupTiers, newTier]);
  };

  const handleRemoveTier = (id: string) => {
    triggerHaptic('light');
    setGroupTiers(groupTiers.filter((t) => t.id !== id));
  };

  const handleUpdateTier = (id: string, updates: Partial<CustomGroupTier>) => {
    setGroupTiers(groupTiers.map((t) => (t.id === id ? { ...t, ...updates } : t)));
  };

  const handleSaveEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');
    setIsSaving(true);
    try {
      const pPrice = admissionTiers.length > 0 ? admissionTiers[0].price : (Number(personalPrice) || 2500);
      const cap = admissionTiers.reduce((acc, t) => acc + (t.capacity || 0), 0) || (Number(capacityInput) || 1000);
      await updateEvent(event.id, {
        title: title.trim(),
        subtitle: subtitle.trim(),
        category,
        city: city.trim(),
        venue: venue.trim(),
        address: address.trim(),
        date: date.trim(),
        time: time.trim(),
        doorTime: doorTime.trim(),
        description: description.trim(),
        image: posterImage,
        price: pPrice,
        personalPrice: pPrice,
        capacity: cap,
        instagram: instagram.trim(),
        tiktok: tiktok.trim(),
        gmail: gmail.trim(),
        tiers: admissionTiers,
        groupTiers,
      });
      triggerHaptic('success');
      showToast('Event details and ticket tiers synchronized in real-time');
      setActiveTab('analytics');
    } catch {
      triggerHaptic('error');
      showToast('Error updating event');
    } finally {
      setIsSaving(false);
    }
  };

  const handleAuthorizeHostMpesaRefund = async () => {
    if (hostMpesaPin.length !== 4) {
      triggerHaptic('error');
      setPinError('Please enter your 4-digit M-Pesa PIN');
      return;
    }
    setPinError(null);
    setIsCancelling(true);
    triggerHaptic('medium');

    try {
      // Simulate Safaricom Daraja B2C reverse-payment handshake with host PIN
      await new Promise((r) => setTimeout(r, 1400));
      const reversalRef = `NW${Math.floor(100000 + Math.random() * 900000)}REV`;
      await deleteEvent(event.id, hostMpesaPin);
      triggerHaptic('success');
      setRefundReversalDone({
        reversalRef,
        amount: eventGrossSales,
        count: nonRefundedTickets.length,
      });
      showToast(`B2C Reversal confirmed (${reversalRef}). Debited from Host M-Pesa (${event.hostMpesa}).`);
      setTimeout(() => {
        setShowCancelConfirmModal(false);
        onClose();
      }, 2200);
    } catch {
      triggerHaptic('error');
      showToast('Failed to process M-Pesa B2C refund reversal');
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <>
      {/* Drawer Overlay */}
      <div
        className="fixed inset-0 z-50 flex items-center justify-end bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
        onClick={onClose}
      >
        {/* Slide-over Drawer Panel */}
        <div
          className="relative w-full max-w-3xl h-full bg-[#0d0f14] border-l border-[#1f2229] shadow-2xl flex flex-col text-[#f4f4f6] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Drawer Top Header */}
          <div className="p-5 sm:p-6 bg-[#111317] border-b border-[#1f2229] shrink-0">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3.5 min-w-0">
                <img
                  src={event.image}
                  alt={event.title}
                  className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-[#262934]"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      {event.categoryLabel || event.category}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Live Cloud Sync
                    </span>
                  </div>

                  <h2 className="text-lg sm:text-xl font-black text-white truncate mt-1">
                    {event.title}
                  </h2>
                  <p className="text-xs text-[#9496a1] truncate mt-0.5">
                    {event.venue} · {event.city} · {event.date}
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-[#16181f] border border-[#232733] hover:bg-[#1f222b] text-[#9496a1] hover:text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
                aria-label="Close Drawer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Segmented View Tabs */}
            <div className="mt-5 grid grid-cols-3 gap-1 p-1 bg-[#16181f] rounded-2xl border border-[#232733]">
              <button
                onClick={() => setActiveTab('analytics')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeTab === 'analytics'
                    ? 'bg-[#252834] text-white shadow-xs border border-[#353a4b]'
                    : 'text-[#9496a1] hover:text-white'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                <span>Live Feed & Metrics</span>
              </button>

              <button
                onClick={() => setActiveTab('edit')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeTab === 'edit'
                    ? 'bg-[#252834] text-white shadow-xs border border-[#353a4b]'
                    : 'text-[#9496a1] hover:text-white'
                }`}
              >
                <Edit className="w-3.5 h-3.5 text-blue-400" />
                <span>Edit Event & Tiers</span>
              </button>

              <button
                onClick={() => setActiveTab('cancel')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeTab === 'cancel'
                    ? 'bg-rose-500/20 text-rose-300 shadow-xs border border-rose-500/30'
                    : 'text-[#9496a1] hover:text-rose-400'
                }`}
              >
                <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
                <span>Cancel & Refunds</span>
              </button>
            </div>
          </div>

          {/* Drawer Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
            {/* ======================================================== */}
            {/* TAB 1: DEDICATED PER-EVENT FINANCIALS & LIVE BUYER FEED  */}
            {/* ======================================================== */}
            {activeTab === 'analytics' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                {/* 1. PER-EVENT DYNAMIC METRICS */}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#9496a1] mb-3">
                    Per-Event Financial & Inventory Metrics
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    {/* Metric 1: Event Gross Sales */}
                    <div className="p-4.5 rounded-2xl bg-[#111317] border border-[#1f2229] shadow-sm flex flex-col justify-between">
                      <div className="flex items-center justify-between text-[#9496a1]">
                        <span className="text-[11px] font-bold uppercase tracking-wider">Gross Sales</span>
                        <div className="w-7 h-7 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                          <TrendingUp className="w-3.5 h-3.5" />
                        </div>
                      </div>
                      <div className="mt-3">
                        <span className="text-xl sm:text-2xl font-black text-white tracking-tight">
                          {formatKsh(eventGrossSales)}
                        </span>
                        <p className="text-[10px] text-emerald-400 font-medium mt-0.5">
                          ~${usdEquivalent.toLocaleString()} USD net
                        </p>
                      </div>
                    </div>

                    {/* Metric 2: Passes Sold vs Remaining Inventory */}
                    <div className="p-4.5 rounded-2xl bg-[#111317] border border-[#1f2229] shadow-sm flex flex-col justify-between">
                      <div className="flex items-center justify-between text-[#9496a1]">
                        <span className="text-[11px] font-bold uppercase tracking-wider">Passes Sold</span>
                        <div className="w-7 h-7 rounded-full bg-blue-500/10 text-blue-400 flex items-center justify-center">
                          <Ticket className="w-3.5 h-3.5" />
                        </div>
                      </div>
                      <div className="mt-3">
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-xl sm:text-2xl font-black text-white tracking-tight">
                            {eventPassesSold}
                          </span>
                          <span className="text-xs text-[#9496a1]">/ {totalCapacity}</span>
                        </div>
                        <p className="text-[10px] text-[#9496a1] font-medium mt-0.5">
                          {remainingInventory} remaining passes
                        </p>
                      </div>
                    </div>

                    {/* Metric 3: Event Available / Settled Balance */}
                    <div className="p-4.5 rounded-2xl bg-[#111317] border border-[#1f2229] shadow-sm flex flex-col justify-between">
                      <div className="flex items-center justify-between text-[#9496a1]">
                        <span className="text-[11px] font-bold uppercase tracking-wider">Settled Balance</span>
                        <div className="w-7 h-7 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center">
                          <DollarSign className="w-3.5 h-3.5" />
                        </div>
                      </div>
                      <div className="mt-3">
                        <span className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight">
                          {formatKsh(settledBalance)}
                        </span>
                        <p className="text-[10px] text-[#9496a1] font-medium mt-0.5">
                          {eventAdmittedCount} checked in at turnstile
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Inventory Capacity Progress Bar */}
                  <div className="mt-3 p-3.5 rounded-2xl bg-[#111317] border border-[#1f2229] space-y-2">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-[#9496a1]">Capacity Allocation:</span>
                      <span className="text-white">{soldPercentage}% Sold Out</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-[#1e212b] overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                        style={{ width: `${soldPercentage}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* 2. REAL-TIME LIVE TICKET BUYER FEED */}
                <div className="p-5 sm:p-6 rounded-[28px] bg-[#111317] border border-[#1f2229] shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1f2229]">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                        <h4 className="text-sm font-bold text-white">
                          Real-Time Ticket Buyer Feed
                        </h4>
                      </div>
                      <p className="text-[11px] text-[#9496a1] mt-0.5">
                        Live stream of transactions for this event across all devices.
                      </p>
                    </div>

                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Streaming Active</span>
                    </div>
                  </div>

                  {/* Search and Status Filter */}
                  <div className="flex flex-col sm:flex-row gap-2.5">
                    <div className="relative flex-1">
                      <Search className="w-3.5 h-3.5 absolute left-3.5 top-3.5 text-[#646875]" />
                      <input
                        type="text"
                        value={buyerSearch}
                        onChange={(e) => setBuyerSearch(e.target.value)}
                        placeholder="Search buyer name, email, phone, or ticket code..."
                        className="w-full h-10 pl-9 pr-3 text-xs rounded-xl border border-[#232733] bg-[#16181f] text-white placeholder:text-[#5d606f] font-medium focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div className="flex items-center gap-1 p-0.5 bg-[#16181f] rounded-xl border border-[#232733]">
                      {(['all', 'active', 'used', 'refunded'] as const).map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setBuyerFilter(tab)}
                          className={`px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all capitalize cursor-pointer ${
                            buyerFilter === tab
                              ? 'bg-[#252834] text-white shadow-2xs'
                              : 'text-[#9496a1] hover:text-white'
                          }`}
                        >
                          {tab}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Itemized Attendee List */}
                  {filteredBuyerTickets.length === 0 ? (
                    <div className="py-12 text-center text-xs text-[#646875] space-y-2">
                      <Ticket className="w-8 h-8 mx-auto opacity-30 text-[#9496a1]" />
                      <p>
                        {eventTickets.length === 0
                          ? 'No ticket purchases recorded yet for this event.'
                          : 'No ticket transactions match the selected filter.'}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                      {filteredBuyerTickets.map((tkt) => {
                        const isAdmitted = tkt.status === 'used';
                        const isRefunded = tkt.status === 'refunded';
                        const paymentIcon =
                          tkt.paymentMethod === 'paypal' ? (
                            <CreditCard className="w-3 h-3 text-blue-400" />
                          ) : (
                            <Smartphone className="w-3 h-3 text-emerald-400" />
                          );

                        return (
                          <div
                            key={tkt.ticketId}
                            className={`p-3.5 rounded-2xl border transition-all space-y-2.5 ${
                              isRefunded
                                ? 'bg-[#181214] border-rose-900/30'
                                : isAdmitted
                                ? 'bg-[#13171e] border-blue-900/30'
                                : 'bg-[#16181f] border-[#232733] hover:border-emerald-500/40'
                            }`}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                              {/* Buyer Avatar & Names */}
                              <div className="flex items-center gap-3">
                                <div
                                  className={`w-9 h-9 rounded-full font-bold flex items-center justify-center text-xs shrink-0 ${
                                    isRefunded
                                      ? 'bg-rose-500/20 text-rose-300'
                                      : isAdmitted
                                      ? 'bg-blue-500/20 text-blue-300'
                                      : 'bg-emerald-500/20 text-emerald-300'
                                  }`}
                                >
                                  {tkt.holderName.charAt(0).toUpperCase()}
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2">
                                    <h5 className="text-xs font-bold text-white truncate">
                                      {tkt.holderName}
                                    </h5>
                                    <span className="font-mono text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                                      {tkt.ticketCode}
                                    </span>
                                  </div>
                                  <span className="text-[11px] text-[#9496a1] block truncate">
                                    {tkt.holderEmail || tkt.holderPhone || 'passholder@eventra.live'} · {tkt.holderPhone || '+254 Mobile'}
                                  </span>
                                </div>
                              </div>

                              {/* Amount & Status Badge */}
                              <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-1 shrink-0">
                                <span className="text-xs font-bold text-white">
                                  {formatKsh(tkt.totalPaid || (tkt.quantity * (event.price || 2500)))}
                                </span>
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                    isRefunded
                                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                      : isAdmitted
                                      ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                      : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  }`}
                                >
                                  {isRefunded
                                    ? '100% Refunded'
                                    : isAdmitted
                                    ? `Admitted (${tkt.checkedInAt || 'Verified'})`
                                    : 'Confirmed & Issued'}
                                </span>
                              </div>
                            </div>

                            {/* Transaction details row */}
                            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#1f2229] text-[10px] text-[#9496a1]">
                              <div className="flex items-center gap-2">
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#1c1f28] text-white font-medium">
                                  {paymentIcon}
                                  <span>{(tkt.paymentMethod || 'mpesa').toUpperCase()}</span>
                                </span>
                                <span>Tier: <strong className="text-white">{tkt.ticketType === 'group' ? 'Group Pass' : 'Individual'} (x{tkt.quantity})</strong></span>
                                {tkt.transactionRef && (
                                  <span className="font-mono text-[#646875]">Ref: {tkt.transactionRef}</span>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                <Clock className="w-3 h-3 text-[#646875]" />
                                <span>{tkt.purchasedAt || 'Recent transaction'}</span>

                                {!isAdmitted && !isRefunded && (
                                  <button
                                    onClick={() => checkInTicket(tkt.ticketId, 'Host Portal')}
                                    className="ml-2 px-2 py-0.5 rounded bg-emerald-500 hover:bg-emerald-600 text-white font-bold cursor-pointer transition-colors"
                                    title="Check in attendee"
                                  >
                                    Admit Pass
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ======================================================== */}
            {/* TAB 2: FULL EVENT MODIFICATION SUITE                     */}
            {/* ======================================================== */}
            {activeTab === 'edit' && (
              <form onSubmit={handleSaveEvent} className="space-y-6 animate-in fade-in duration-150">
                {/* 1. Artwork Upload */}
                <div className="p-5 rounded-2xl bg-[#111317] border border-[#1f2229] space-y-3">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#9496a1] block">
                    Event Artwork & Poster
                  </label>
                  <div className="flex flex-col sm:flex-row items-center gap-4">
                    <img
                      src={posterImage}
                      alt="Artwork Preview"
                      className="w-full sm:w-36 h-28 rounded-xl object-cover border border-[#262934] shrink-0"
                    />
                    <div className="w-full space-y-2">
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handlePhotoUpload}
                        accept="image/*"
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full h-11 px-4 rounded-xl border border-dashed border-[#262934] hover:border-emerald-500 transition-colors flex items-center justify-center gap-2 text-xs font-semibold text-white bg-[#16181f] cursor-pointer"
                      >
                        <Upload className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Upload New Poster Artwork</span>
                      </button>
                      <span className="text-[10px] text-[#646875] block">
                        Recommended: High resolution 16:9 or 4:3 JPG/PNG image
                      </span>
                    </div>
                  </div>
                </div>

                {/* 2. Core Event Details */}
                <div className="p-5 rounded-2xl bg-[#111317] border border-[#1f2229] space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#9496a1]">
                    Event Information & Schedule
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div className="sm:col-span-2 space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Event Title
                      </label>
                      <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Subtitle / Tagline
                      </label>
                      <input
                        type="text"
                        value={subtitle}
                        onChange={(e) => setSubtitle(e.target.value)}
                        placeholder="Curated live concert with special visual showcase"
                        className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Date
                      </label>
                      <input
                        type="text"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Showtime
                      </label>
                      <input
                        type="text"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Venue
                      </label>
                      <input
                        type="text"
                        value={venue}
                        onChange={(e) => setVenue(e.target.value)}
                        className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        City
                      </label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Description
                      </label>
                      <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        rows={3}
                        className="w-full p-3.5 text-xs font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none resize-none"
                      />
                    </div>
                  </div>
                </div>

                {/* 3. Ticket Tiers & Capacity Quotas */}
                <div className="p-5 rounded-2xl bg-[#111317] border border-[#1f2229] space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-[#9496a1]">
                        Ticket Tiers & Pricing Quotas
                      </h4>
                      <p className="text-[11px] text-[#646875] mt-0.5">
                        Adjust standard admission and bundle pricing even while live.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleAddGroupTier}
                      className="px-3 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Group Tier</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Base Admission Price (KSh)
                      </label>
                      <input
                        type="number"
                        value={personalPrice}
                        onChange={(e) => setPersonalPrice(e.target.value)}
                        className="w-full h-12 px-4 text-xs font-mono font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-[#b8b9c2] block">
                        Total Venue Capacity (Inventory Quota)
                      </label>
                      <input
                        type="number"
                        value={capacityInput}
                        onChange={(e) => setCapacityInput(e.target.value)}
                        className="w-full h-12 px-4 text-xs font-mono font-medium rounded-xl border border-[#262934] bg-[#16181f] text-white focus:border-emerald-500 focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  {/* Individual Admission Tiers Editor (Early Bird, Regular, VIP, VVIP) */}
                  <div className="space-y-3 pt-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="text-xs font-bold uppercase tracking-wider text-white block">
                          Individual Admission Tiers ({admissionTiers.length})
                        </span>
                        <span className="text-[11px] text-[#9496a1]">
                          Customize pass quotas/capacity to any amount (e.g. 50, 200, 1500)
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleAddAdmissionTier({
                            name: 'Early Bird Pass',
                            price: Math.round(Number(personalPrice || 2500) * 0.8),
                            capacity: 200,
                            description: 'Early admission discount with expedited gate entry',
                            perks: 'Fast-track gate pass',
                          })}
                          className="px-2.5 py-1 rounded-full border border-[#262934] bg-[#16181f] text-[10px] font-bold text-[#b8b9c2] hover:text-white hover:border-emerald-500/50 transition-colors cursor-pointer"
                        >
                          + Early Bird
                        </button>
                        <button
                          type="button"
                          onClick={() => handleAddAdmissionTier({
                            name: 'VIP Raised Lounge',
                            price: Math.round(Number(personalPrice || 2500) * 1.8),
                            capacity: 100,
                            description: 'VIP elevated balcony deck and private bar',
                            perks: 'VIP Lounge access',
                          })}
                          className="px-2.5 py-1 rounded-full border border-[#262934] bg-[#16181f] text-[10px] font-bold text-[#b8b9c2] hover:text-white hover:border-emerald-500/50 transition-colors cursor-pointer"
                        >
                          + VIP Lounge
                        </button>
                        <button
                          type="button"
                          onClick={() => handleAddAdmissionTier()}
                          className="px-3 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add Tier</span>
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      {admissionTiers.map((tier) => (
                        <div
                          key={tier.id}
                          className="p-3.5 rounded-2xl bg-[#16181f] border border-[#232733] hover:border-[#353a4b] transition-all space-y-2.5"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <Ticket className="w-4 h-4 text-emerald-400 shrink-0" />
                              <input
                                type="text"
                                value={tier.name}
                                onChange={(e) => handleUpdateAdmissionTier(tier.id, { name: e.target.value })}
                                className="h-9 px-3 text-xs font-bold rounded-lg border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none w-full max-w-xs"
                                placeholder="Tier Title (e.g. Early Bird)"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => handleRemoveAdmissionTier(tier.id)}
                              className="p-2 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-rose-500/10 cursor-pointer shrink-0"
                              title="Remove tier"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                            <div>
                              <span className="text-[10px] text-[#9496a1] block mb-1">Price per Pass (KSh):</span>
                              <input
                                type="number"
                                value={tier.price}
                                onChange={(e) => handleUpdateAdmissionTier(tier.id, { price: Number(e.target.value) || 0 })}
                                className="w-full h-9 px-3 text-xs font-mono font-medium rounded-lg border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                              />
                            </div>
                            <div>
                              <span className="text-[10px] text-[#9496a1] block mb-1">Passes Quota (Any Amount):</span>
                              <input
                                type="number"
                                value={tier.capacity}
                                onChange={(e) => handleUpdateAdmissionTier(tier.id, { capacity: Number(e.target.value) || 0 })}
                                placeholder="e.g. 50, 200, 1500"
                                className="w-full h-9 px-3 text-xs font-mono font-bold rounded-lg border border-[#262934] bg-[#111317] text-emerald-400 focus:border-emerald-500 focus:outline-none"
                              />
                            </div>
                            <div>
                              <span className="text-[10px] text-[#9496a1] block mb-1">Description / Perks:</span>
                              <input
                                type="text"
                                value={tier.description || ''}
                                onChange={(e) => handleUpdateAdmissionTier(tier.id, { description: e.target.value, perks: e.target.value })}
                                placeholder="e.g. Express lane entry"
                                className="w-full h-9 px-3 text-xs rounded-lg border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Group Bundles */}
                  {groupTiers.length > 0 && (
                    <div className="space-y-2.5 pt-2">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-[#9496a1] block">
                        Custom Group Passes
                      </label>
                      {groupTiers.map((tier) => (
                        <div
                          key={tier.id}
                          className="p-3.5 rounded-xl bg-[#16181f] border border-[#232733] space-y-2.5"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <input
                              type="text"
                              value={tier.name}
                              onChange={(e) => handleUpdateTier(tier.id, { name: e.target.value })}
                              className="h-9 px-3 text-xs font-bold rounded-lg border border-[#262934] bg-[#111317] text-white flex-1 focus:border-emerald-500 focus:outline-none"
                              placeholder="Tier Title"
                            />
                            <button
                              type="button"
                              onClick={() => handleRemoveTier(tier.id)}
                              className="p-2 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-rose-500/10 cursor-pointer"
                              title="Remove tier"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <span className="text-[10px] text-[#9496a1] block mb-1">Passes per bundle:</span>
                              <input
                                type="number"
                                min={2}
                                max={20}
                                value={tier.size}
                                onChange={(e) => handleUpdateTier(tier.id, { size: Number(e.target.value) || 2 })}
                                className="w-full h-9 px-3 text-xs font-mono font-medium rounded-lg border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                              />
                            </div>
                            <div>
                              <span className="text-[10px] text-[#9496a1] block mb-1">Bundle Price (KSh):</span>
                              <input
                                type="number"
                                value={tier.price}
                                onChange={(e) => handleUpdateTier(tier.id, { price: Number(e.target.value) || 5000 })}
                                className="w-full h-9 px-3 text-xs font-mono font-medium rounded-lg border border-[#262934] bg-[#111317] text-white focus:border-emerald-500 focus:outline-none"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* 4. Social Links & Official Accounts */}
                <div className="p-5 rounded-2xl bg-[#111317] border border-[#1f2229] space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#9496a1]">
                    Connected Social Channels & Support
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-semibold text-[#b8b9c2] flex items-center gap-1.5">
                        <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24" fill="none">
                          <rect width="24" height="24" rx="6" fill="url(#ig-grad-edit)" />
                          <circle cx="12" cy="12" r="4.2" stroke="white" strokeWidth="1.8" />
                          <circle cx="17.2" cy="6.8" r="1.1" fill="white" />
                          <defs>
                            <linearGradient id="ig-grad-edit" x1="2" y1="22" x2="22" y2="2" gradientUnits="userSpaceOnUse">
                              <stop stopColor="#f09433" />
                              <stop offset="0.25" stopColor="#e6683c" />
                              <stop offset="0.5" stopColor="#dc2743" />
                              <stop offset="0.75" stopColor="#cc2366" />
                              <stop offset="1" stopColor="#bc1888" />
                            </linearGradient>
                          </defs>
                        </svg>
                        <span>Instagram</span>
                      </label>
                      <input
                        type="text"
                        value={instagram}
                        onChange={(e) => setInstagram(e.target.value)}
                        placeholder="@aurorafestival"
                        className="w-full h-11 px-3 text-xs rounded-xl border border-[#262934] bg-[#16181f] text-white font-medium focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-semibold text-[#b8b9c2] flex items-center gap-1.5">
                        <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24" fill="none">
                          <rect width="24" height="24" rx="6" fill="#010101" />
                          <path
                            d="M16.6 5.82s.51.98 1.48 1.58c.98.6 2.02.66 2.02.66v2.96s-1.18-.04-2.18-.46c-1-.42-1.72-1.04-1.72-1.04v6.24c0 1.25-.44 2.4-1.22 3.17-.79.77-1.85 1.17-2.98 1.17-2.32 0-4.2-1.88-4.2-4.2 0-2.32 1.88-4.2 4.2-4.2.45 0 .88.08 1.28.22v3.08c-.38-.2-.8-.3-1.28-.3-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2V4h2.6v1.82z"
                            fill="#25F4EE"
                          />
                          <path
                            d="M16 6s.51.98 1.48 1.58c.98.6 2.02.66 2.02.66v2.96s-1.18-.04-2.18-.46c-1-.42-1.72-1.04-1.72-1.04v6.24c0 1.25-.44 2.4-1.22 3.17-.79.77-1.85 1.17-2.98 1.17-2.32 0-4.2-1.88-4.2-4.2 0-2.32 1.88-4.2 4.2-4.2.45 0 .88.08 1.28.22v3.08c-.38-.2-.8-.3-1.28-.3-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2V4H16v2z"
                            fill="#FE2C55"
                          />
                          <path
                            d="M16.3 5.91s.51.98 1.48 1.58c.98.6 2.02.66 2.02.66v2.96s-1.18-.04-2.18-.46c-1-.42-1.72-1.04-1.72-1.04v6.24c0 1.25-.44 2.4-1.22 3.17-.79.77-1.85 1.17-2.98 1.17-2.32 0-4.2-1.88-4.2-4.2 0-2.32 1.88-4.2 4.2-4.2.45 0 .88.08 1.28.22v3.08c-.38-.2-.8-.3-1.28-.3-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2V4h2.3v1.91z"
                            fill="white"
                          />
                        </svg>
                        <span>TikTok</span>
                      </label>
                      <input
                        type="text"
                        value={tiktok}
                        onChange={(e) => setTiktok(e.target.value)}
                        placeholder="@auroralive"
                        className="w-full h-11 px-3 text-xs rounded-xl border border-[#262934] bg-[#16181f] text-white font-medium focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-semibold text-[#b8b9c2] flex items-center gap-1.5">
                        <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24" fill="none">
                          <rect width="24" height="24" rx="6" fill="#1e2028" />
                          <path d="M4 7.5L12 13L20 7.5V17.5C20 18.05 19.55 18.5 19 18.5H5C4.45 18.5 4 18.05 4 17.5V7.5Z" fill="#EA4335" />
                          <path d="M20 7.5L12 13L4 7.5C4 6.95 4.45 6.5 5 6.5H19C19.55 6.5 20 6.95 20 7.5Z" fill="#4285F4" />
                          <path d="M4 7.5L12 13V18.5H5C4.45 18.5 4 18.05 4 17.5V7.5Z" fill="#34A853" fillOpacity="0.4" />
                        </svg>
                        <span>Inquiry Gmail</span>
                      </label>
                      <input
                        type="email"
                        value={gmail}
                        onChange={(e) => setGmail(e.target.value)}
                        placeholder="aurora.tickets@gmail.com"
                        className="w-full h-11 px-3 text-xs rounded-xl border border-[#262934] bg-[#16181f] text-white font-medium focus:border-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Save Button */}
                <button
                  type="submit"
                  disabled={isSaving}
                  className="w-full h-12 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-98"
                >
                  {isSaving ? 'Synchronizing Changes...' : 'Save & Propagate Live Event Updates'}
                </button>
              </form>
            )}

            {/* ======================================================== */}
            {/* TAB 3: DANGER ZONE & AUTOMATED BUYER REFUND              */}
            {/* ======================================================== */}
            {activeTab === 'cancel' && (
              <div className="p-6 rounded-[28px] bg-rose-950/20 border border-rose-900/40 space-y-4 animate-in fade-in duration-150">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      Automated Cancellation & Full Buyer Refund Pipeline
                    </h4>
                    <p className="text-xs text-rose-200/80 mt-1 leading-relaxed">
                      Canceling this event immediately purges the listing worldwide from all devices.
                      All {eventPassesSold} issued tickets will be instantly marked as refunded in buyers’ passbooks, and total ticket funds ({formatKsh(eventGrossSales)}) will be automatically refunded back to buyers’ original M-Pesa or PayPal accounts.
                    </p>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setShowCancelConfirmModal(true)}
                    className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-98"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Initiate Full Cancellation & Process All Refunds</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Host M-Pesa PIN B2C Refund Authorization Modal */}
      {showCancelConfirmModal && (
        <div
          className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => {
            if (!isCancelling) setShowCancelConfirmModal(false);
          }}
        >
          <div
            className="w-full max-w-md bg-[#111317] rounded-[32px] p-6 shadow-2xl border border-rose-900/40 text-[#f4f4f6] space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header / Security Badge */}
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/15 text-rose-400 flex items-center justify-center mx-auto border border-rose-500/25">
                <Lock className="w-6 h-6" />
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-bold uppercase tracking-wider">
                <Smartphone className="w-3 h-3" />
                <span>Host M-Pesa B2C Authorization</span>
              </div>
              <h3 className="text-lg font-bold tracking-tight text-white">
                Authorize Event Refund
              </h3>
              <p className="text-xs text-[#9496a1] leading-relaxed">
                Canceling <strong className="text-white">"{event.title}"</strong> triggers an automated Safaricom B2C reversal directly from your Host M-Pesa line to all buyers.
              </p>
            </div>

            {/* Reversal Ledger Breakdown */}
            <div className="p-4 rounded-2xl bg-[#090a0d] border border-rose-900/30 space-y-2 text-xs">
              <div className="flex items-center justify-between text-[#9496a1]">
                <span>Host Debit Line:</span>
                <span className="font-mono text-emerald-400 font-bold">{event.hostMpesa || '0712 345 678'}</span>
              </div>
              <div className="flex items-center justify-between text-[#9496a1]">
                <span>Refund Beneficiaries:</span>
                <span className="text-white font-medium">{nonRefundedTickets.length} buyer pass(es)</span>
              </div>
              <div className="flex items-center justify-between text-[#9496a1] pt-1 border-t border-[#1f2229]">
                <span className="font-bold text-white">Total Debited from Host:</span>
                <strong className="text-rose-400 font-mono text-sm">{formatKsh(eventGrossSales)}</strong>
              </div>
            </div>

            {/* Success State view */}
            {refundReversalDone ? (
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-2 animate-in zoom-in-95">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-bold text-emerald-400">
                  B2C Reversals Dispatched!
                </h4>
                <p className="text-xs text-[#9496a1] font-mono leading-relaxed">
                  Ref: <strong className="text-white">{refundReversalDone.reversalRef}</strong>. {formatKsh(refundReversalDone.amount)} debited from Host M-Pesa ({event.hostMpesa || '0712 345 678'}). All buyer passes revoked and refunded.
                </p>
              </div>
            ) : (
              <>
                {/* PIN Input Section */}
                <div className="space-y-3 pt-1">
                  <div className="text-center">
                    <label className="text-xs font-semibold text-[#b8b9c2] block mb-2">
                      Enter Host 4-Digit M-Pesa PIN to Authorize
                    </label>

                    {/* Masked PIN bubbles */}
                    <div className="flex items-center justify-center gap-3 mb-2">
                      {[0, 1, 2, 3].map((index) => {
                        const isFilled = hostMpesaPin.length > index;
                        return (
                          <div
                            key={index}
                            className={`w-4 h-4 rounded-full transition-all duration-150 ${
                              isFilled
                                ? 'bg-emerald-400 scale-110 shadow-xs shadow-emerald-500/50'
                                : 'bg-[#1f2229] border border-[#2a2e3a]'
                            }`}
                          />
                        );
                      })}
                    </div>

                    <input
                      type="password"
                      maxLength={4}
                      value={hostMpesaPin}
                      onChange={(e) => {
                        triggerHaptic('light');
                        setHostMpesaPin(e.target.value.replace(/\D/g, ''));
                      }}
                      placeholder="••••"
                      className="w-40 h-10 text-center font-mono text-base tracking-widest bg-[#16181f] border border-[#262934] focus:border-emerald-500 rounded-xl text-white focus:outline-none mx-auto block"
                      disabled={isCancelling}
                    />

                    {pinError && (
                      <span className="text-xs text-rose-400 font-semibold block mt-1.5">
                        {pinError}
                      </span>
                    )}
                  </div>

                  {/* Interactive Tactile Keypad */}
                  <div className="grid grid-cols-3 gap-1.5 max-w-[240px] mx-auto pt-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                      <button
                        key={num}
                        type="button"
                        disabled={isCancelling || hostMpesaPin.length >= 4}
                        onClick={() => {
                          triggerHaptic('light');
                          if (hostMpesaPin.length < 4) {
                            setHostMpesaPin((prev) => prev + String(num));
                          }
                        }}
                        className="h-10 rounded-xl bg-[#16181f] hover:bg-[#20232c] active:scale-95 text-white font-mono font-bold text-sm border border-[#232733] transition-colors cursor-pointer disabled:opacity-40"
                      >
                        {num}
                      </button>
                    ))}
                    <button
                      type="button"
                      disabled={isCancelling}
                      onClick={() => {
                        triggerHaptic('light');
                        setHostMpesaPin('');
                      }}
                      className="h-10 rounded-xl bg-[#16181f] hover:bg-[#20232c] active:scale-95 text-[#9496a1] font-semibold text-xs border border-[#232733] transition-colors cursor-pointer"
                    >
                      Clear
                    </button>
                    <button
                      type="button"
                      disabled={isCancelling || hostMpesaPin.length >= 4}
                      onClick={() => {
                        triggerHaptic('light');
                        if (hostMpesaPin.length < 4) {
                          setHostMpesaPin((prev) => prev + '0');
                        }
                      }}
                      className="h-10 rounded-xl bg-[#16181f] hover:bg-[#20232c] active:scale-95 text-white font-mono font-bold text-sm border border-[#232733] transition-colors cursor-pointer disabled:opacity-40"
                    >
                      0
                    </button>
                    <button
                      type="button"
                      disabled={isCancelling}
                      onClick={() => {
                        triggerHaptic('light');
                        setHostMpesaPin((prev) => prev.slice(0, -1));
                      }}
                      className="h-10 rounded-xl bg-[#16181f] hover:bg-[#20232c] active:scale-95 text-[#9496a1] font-semibold text-xs border border-[#232733] transition-colors cursor-pointer"
                    >
                      ⌫
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5 pt-2">
                    <button
                      type="button"
                      disabled={isCancelling}
                      onClick={() => {
                        triggerHaptic('light');
                        setShowCancelConfirmModal(false);
                      }}
                      className="py-3 rounded-2xl border border-[#232733] bg-[#16181f] hover:bg-[#1f222b] text-xs font-semibold text-[#f4f4f6] cursor-pointer"
                    >
                      Keep Event
                    </button>

                    <button
                      type="button"
                      disabled={isCancelling || hostMpesaPin.length !== 4}
                      onClick={handleAuthorizeHostMpesaRefund}
                      className="py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-xs font-bold text-white cursor-pointer shadow-md flex items-center justify-center gap-1.5 active:scale-98"
                    >
                      {isCancelling ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Authorizing B2C...</span>
                        </>
                      ) : (
                        <>
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Authorize & Disburse</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
};
