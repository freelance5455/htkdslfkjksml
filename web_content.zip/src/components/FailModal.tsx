import React from 'react';
import { motion } from 'motion/react';
import { RotateCcw, Lightbulb, Home, AlertCircle } from 'lucide-react';
import { Language } from '../types';
import { getTranslations } from '../services/i18n';

interface FailModalProps {
  onRetry: () => void;
  onUseHint: () => void;
  onHome: () => void;
  hintsRemaining: number;
  language?: Language;
}

export const FailModal: React.FC<FailModalProps> = ({
  onRetry,
  onUseHint,
  onHome,
  hintsRemaining,
  language = 'en',
}) => {
  const t = getTranslations(language);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm select-none">
      <motion.div
        initial={{ scale: 0.8, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-100 dark:border-slate-700 p-6 flex flex-col items-center text-center relative"
      >
        <div className="w-16 h-16 rounded-2xl bg-rose-100 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-center justify-center text-rose-500 mb-3 shadow-inner">
          <AlertCircle className="w-8 h-8" />
        </div>

        <h3 className="text-2xl font-black text-slate-800 dark:text-white tracking-tight">
          {t.tryAgain}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
          {t.tryAgainSub}
        </p>

        <div className="w-full flex flex-col gap-2.5 mt-6">
          <button
            id="btn-fail-retry"
            type="button"
            onClick={onRetry}
            className="w-full h-12 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-bold shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2 active:scale-98 transition"
          >
            <RotateCcw className="w-5 h-5" />
            <span>{t.retryPuzzle}</span>
          </button>

          <button
            id="btn-fail-hint"
            type="button"
            onClick={onUseHint}
            className="w-full h-11 rounded-2xl bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 dark:hover:bg-amber-900/50 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 font-bold text-xs flex items-center justify-center gap-2 active:scale-98 transition"
          >
            <Lightbulb className="w-4 h-4 text-amber-500" />
            <span>{t.useHint} ({hintsRemaining})</span>
          </button>

          <button
            id="btn-fail-home"
            type="button"
            onClick={onHome}
            className="w-full h-10 rounded-xl bg-slate-100 dark:bg-slate-700/70 text-slate-700 dark:text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 active:scale-98 transition"
          >
            <Home className="w-4 h-4" />
            <span>{t.home}</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
