import React, { useState } from 'react';
import { WeeklyPlanDay, WorkoutType } from '../types';
import { StorageService } from '../services/storage';
import {
  Calendar,
  CheckCircle,
  Clock,
  Zap,
  Play,
  RotateCcw,
  Sparkles,
  ChevronDown,
  ChevronUp,
  AlertCircle,
} from 'lucide-react';

interface WeeklyPlanProps {
  plan: WeeklyPlanDay[];
  onUpdatePlan: (plan: WeeklyPlanDay[]) => void;
  onStartSpecificWorkout: (type: WorkoutType) => void;
  onAskCoachAboutDay: (day: WeeklyPlanDay) => void;
}

export const WeeklyPlan: React.FC<WeeklyPlanProps> = ({
  plan,
  onUpdatePlan,
  onStartSpecificWorkout,
  onAskCoachAboutDay,
}) => {
  const [expandedDayId, setExpandedDayId] = useState<string>(
    // default expand Monday or first uncompleted day
    plan.find((d) => !d.completed)?.id || 'mon'
  );

  const toggleComplete = (dayId: string) => {
    const updated = StorageService.toggleDayCompletion(dayId);
    onUpdatePlan(updated);
  };

  const resetWeeklyPlan = () => {
    if (window.confirm('Reset all completed days for a new training week?')) {
      const reset = plan.map((d) => ({ ...d, completed: false, completedWorkoutId: undefined }));
      StorageService.saveWeeklyPlan(reset);
      onUpdatePlan(reset);
    }
  };

  // Helper intensity badge colors
  const getIntensityBadge = (intensity: 'low' | 'moderate' | 'high') => {
    switch (intensity) {
      case 'high':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      case 'moderate':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      case 'low':
        return 'bg-[#00FF66]/15 text-[#00FF66] border-[#00FF66]/30';
    }
  };

  const completedCount = plan.filter((d) => d.completed).length;

  return (
    <div className="space-y-4 pb-24">
      {/* Header Overview Card */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#00FF66]" />
              <h1 className="font-athletic text-xl font-black uppercase text-white tracking-wide">
                1600M 7-Day Plan
              </h1>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Target 4:50 &bull; Polarized Aerobic & Speed Cycle
            </p>
          </div>
          <button
            onClick={resetWeeklyPlan}
            className="flex items-center gap-1 text-[11px] font-semibold text-zinc-400 hover:text-white px-2.5 py-1.5 rounded-lg bg-black border border-zinc-800 transition"
          >
            <RotateCcw className="w-3 h-3" />
            <span>New Week</span>
          </button>
        </div>

        {/* Weekly Completion Progress Bar */}
        <div className="space-y-1.5 mt-3 pt-3 border-t border-zinc-800/80">
          <div className="flex justify-between items-center text-xs">
            <span className="font-semibold text-zinc-300">
              Completed {completedCount} of 7 Workouts
            </span>
            <span className="font-mono-numbers font-bold text-[#00FF66]">
              {Math.round((completedCount / 7) * 100)}%
            </span>
          </div>
          <div className="w-full h-2 bg-black rounded-full overflow-hidden border border-zinc-800">
            <div
              className="h-full bg-[#00FF66] transition-all duration-500 glow-neon-sm"
              style={{ width: `${(completedCount / 7) * 100}%` }}
            />
          </div>
        </div>

        {/* Golden Rule Coach Reminder */}
        <div className="mt-3 p-3 bg-zinc-950/80 border border-zinc-800/80 rounded-xl flex items-start gap-2.5 text-xs text-zinc-300">
          <AlertCircle className="w-4 h-4 text-[#00FF66] shrink-0 mt-0.5" />
          <p className="leading-snug">
            <strong>Coach Rule:</strong> Never stack two hard interval sessions on consecutive days. If Wednesday is missed, shift it to Thursday and make Friday easy aerobic.
          </p>
        </div>
      </div>

      {/* 7-Day Workout Cards */}
      <div className="space-y-3">
        {plan.map((day) => {
          const isExpanded = expandedDayId === day.id;

          return (
            <div
              key={day.id}
              className={`rounded-2xl border transition-all ${
                day.completed
                  ? 'bg-zinc-950/70 border-zinc-800 opacity-80'
                  : isExpanded
                  ? 'bg-zinc-900 border-[#00FF66]/50 shadow-lg glow-neon-sm'
                  : 'bg-zinc-900/90 border-zinc-800 hover:border-zinc-700'
              }`}
            >
              {/* Collapsed Header Bar */}
              <div
                onClick={() => setExpandedDayId(isExpanded ? '' : day.id)}
                className="p-4 flex items-center justify-between cursor-pointer select-none"
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleComplete(day.id);
                    }}
                    className={`w-7 h-7 rounded-full flex items-center justify-center border-2 transition ${
                      day.completed
                        ? 'bg-[#00FF66] border-[#00FF66] text-black'
                        : 'border-zinc-600 hover:border-[#00FF66] text-transparent'
                    }`}
                  >
                    <CheckCircle className="w-4 h-4 fill-current" />
                  </button>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-athletic text-xs font-black tracking-wider text-zinc-400">
                        {day.dayName}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${getIntensityBadge(
                          day.intensity
                        )}`}
                      >
                        {day.intensity}
                      </span>
                    </div>
                    <h3
                      className={`text-sm font-bold mt-0.5 ${
                        day.completed ? 'line-through text-zinc-400' : 'text-white'
                      }`}
                    >
                      {day.title}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1 text-xs text-zinc-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>~{day.targetDurationMin}m</span>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-zinc-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-zinc-400" />
                  )}
                </div>
              </div>

              {/* Expanded Detail Body */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 space-y-3 border-t border-zinc-800/80 text-xs">
                  {/* Warm-Up */}
                  <div className="bg-black/40 p-3 rounded-xl border border-zinc-800/70">
                    <span className="font-bold text-[#00FF66] uppercase tracking-wider block mb-1">
                      1. Warm-Up & Drills
                    </span>
                    <p className="text-zinc-300 leading-relaxed">{day.warmUp}</p>
                  </div>

                  {/* Main Workout */}
                  <div className="bg-black/60 p-3 rounded-xl border border-zinc-700/80">
                    <span className="font-bold text-white uppercase tracking-wider block mb-1 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#00FF66]" />
                      2. Main Set
                    </span>
                    <p className="text-zinc-200 font-medium leading-relaxed">{day.mainWorkout}</p>
                  </div>

                  {/* Recovery Guidance */}
                  <div className="bg-black/40 p-3 rounded-xl border border-zinc-800/70">
                    <span className="font-bold text-amber-400 uppercase tracking-wider block mb-1">
                      3. Recovery & Rest Pacing
                    </span>
                    <p className="text-zinc-300 leading-relaxed">{day.recoveryGuidance}</p>
                  </div>

                  {/* Cooldown */}
                  <div className="bg-black/40 p-3 rounded-xl border border-zinc-800/70">
                    <span className="font-bold text-cyan-400 uppercase tracking-wider block mb-1">
                      4. Cooldown
                    </span>
                    <p className="text-zinc-300 leading-relaxed">{day.cooldown}</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => onStartSpecificWorkout(day.workoutType)}
                      className="flex-1 py-2.5 rounded-xl bg-[#00FF66] text-black font-athletic font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 hover:bg-[#10B981] active:scale-95 transition glow-neon-sm"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Start This Run (GPS)</span>
                    </button>

                    <button
                      onClick={() => onAskCoachAboutDay(day)}
                      className="px-3 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-300 font-semibold text-xs flex items-center gap-1 transition"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#00FF66]" />
                      <span>Ask Coach</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
