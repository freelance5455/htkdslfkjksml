import React, { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  FileCode2,
  FolderArchive,
  Lock,
  Play,
  Plus,
  RotateCcw,
  Shield,
  Smartphone,
  Trash2,
} from 'lucide-react';
import {
  DEFAULT_EXAMBRO_CONFIG,
  ExambroConfig,
  SecurityOptions,
} from '../types/exambro';
import {
  downloadAndroidProjectZip,
  generateAndroidFiles,
} from '../utils/androidProjectGenerator';
import { PWAInstallButton } from './PWAInstallButton';

interface ApkBuilderWorkspaceProps {
  config: ExambroConfig;
  onChangeConfig: (next: ExambroConfig) => void;
  onLaunchExamMode: () => void;
}

const SECURITY_ITEMS: Array<{
  key: keyof Omit<SecurityOptions, 'examToken'>;
  title: string;
  description: string;
  androidApi: string;
}> = [
  {
    key: 'lockTaskMode',
    title: 'Kunci Aplikasi (Lock Task / Screen Pinning)',
    description:
      'Mengunci tombol Home, Recent Apps, dan bilah notifikasi agar siswa tidak dapat berpindah ke aplikasi lain.',
    androidApi: 'Activity.startLockTask()',
  },
  {
    key: 'flagSecure',
    title: 'Anti-Screenshot & Rekam Layar',
    description:
      'Menghitamkan tangkapan layar dan memblokir screen recorder saat soal asesmen ditampilkan.',
    androidApi: 'WindowManager.LayoutParams.FLAG_SECURE',
  },
  {
    key: 'blockSplitScreen',
    title: 'Blokir Layar Terbagi (Split-Screen) & PiP',
    description:
      'Menolak mode multi-window agar siswa tidak dapat membuka browser atau AI berdampingan.',
    androidApi: 'resizeableActivity="false"',
  },
  {
    key: 'detectFloatingApps',
    title: 'Deteksi Jendela Mengambang (Floating Window)',
    description:
      'Mengunci layar ujian dan membunyikan alarm jika fokus jendela berpindah ke overlay aplikasi lain.',
    androidApi: 'onWindowFocusChanged()',
  },
  {
    key: 'muteAudio',
    title: 'Bisukan Volume Media & Notifikasi',
    description:
      'Menonaktifkan audio sistem selama sesi ujian dan memulihkannya setelah keluar dengan PIN.',
    androidApi: 'AudioManager.setStreamVolume()',
  },
  {
    key: 'blockBackNavigation',
    title: 'Kunci Tombol Kembali (Back)',
    description:
      'Mencegah siswa keluar secara tidak sengaja maupun paksa melalui navigasi sistem Android.',
    androidApi: 'OnBackPressedDispatcher',
  },
  {
    key: 'clearDataOnExit',
    title: 'Hapus Cache, Riwayat & Cookie Otomatis',
    description:
      'Membersihkan seluruh sesi login Google Forms / browser setiap kali sesi ujian diakhiri.',
    androidApi: 'CookieManager.removeAllCookies()',
  },
  {
    key: 'kioskSoundAlarm',
    title: 'Alarm Suara Saat Pelanggaran Terdeteksi',
    description:
      'Membunyikan nada peringatan keras di HP siswa maupun Mode Web Kiosk bila mencoba keluar.',
    androidApi: 'ToneGenerator / WebAudio',
  },
];

export const ApkBuilderWorkspace: React.FC<ApkBuilderWorkspaceProps> = ({
  config,
  onChangeConfig,
  onLaunchExamMode,
}) => {
  const androidFiles = useMemo(() => generateAndroidFiles(config), [config]);
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [newDomain, setNewDomain] = useState('');
  const [copiedPath, setCopiedPath] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);

  const activeFile = androidFiles[selectedFileIndex] || androidFiles[0];

  const updateField = <K extends keyof ExambroConfig>(
    key: K,
    value: ExambroConfig[K],
  ) => {
    onChangeConfig({ ...config, [key]: value });
  };

  const updateSecurity = <K extends keyof SecurityOptions>(
    key: K,
    value: SecurityOptions[K],
  ) => {
    onChangeConfig({
      ...config,
      security: {
        ...config.security,
        [key]: value,
      },
    });
  };

  const handleAddDomain = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newDomain
      .trim()
      .toLowerCase()
      .replace(/^https?:\/\//, '')
      .split('/')[0];
    if (!cleaned || config.allowedDomains.includes(cleaned)) {
      setNewDomain('');
      return;
    }
    updateField('allowedDomains', [...config.allowedDomains, cleaned]);
    setNewDomain('');
  };

  const handleRemoveDomain = (domain: string) => {
    updateField(
      'allowedDomains',
      config.allowedDomains.filter((d) => d !== domain),
    );
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopiedPath(activeFile.path);
      window.setTimeout(() => setCopiedPath(null), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadAndroidProjectZip(config);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-6 py-4">
          <a
            href="#beranda"
            className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            Exambro MTs Inayatul Marzuki
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a
              href="#beranda"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Beranda
            </a>
            <a
              href="#konfigurasi"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Konfigurasi
            </a>
            <a
              href="#source-apk"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Source APK
            </a>
            <a
              href="#panduan"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Panduan Build
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={onLaunchExamMode}
              className="inline-flex items-center gap-2 rounded-lg bg-emerald-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-emerald-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-700 whitespace-nowrap shrink-0"
            >
              <Play className="h-4 w-4" aria-hidden="true" />
              Mulai Mode Ujian
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-10 space-y-12">
        {/* Hero Section */}
        <section
          id="beranda"
          className="rounded-xl border border-slate-200 bg-white p-6 md:p-8"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span>MTs Inayatul Marzuki</span>
                <span aria-hidden="true">·</span>
                <span>Asesmen Akhir Semester Tahun 2026-2027</span>
                <span aria-hidden="true">·</span>
                <span>Android Native & Web Kiosk</span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 [text-wrap:balance]">
                Exambrowser Anti-Aplikasi Lain & Generator APK Android
              </h1>

              <p className="max-w-2xl text-sm sm:text-base leading-relaxed text-slate-600">
                Terintegrasi langsung dengan portal asesmen madrasah. Jalankan
                langsung sebagai aplikasi web terkunci (PWA / Kiosk) atau unduh
                paket proyek Android Studio lengkap untuk dikompilasi menjadi
                file <span className="font-mono text-slate-800">.apk</span>{' '}
                dengan penguncian layar tingkat sistem.
              </p>

              <div className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-xs font-medium text-slate-500">
                    URL Asesmen Tertanam
                  </div>
                  <div className="truncate font-mono text-xs text-slate-800">
                    {config.examUrl}
                  </div>
                </div>
                <a
                  href={config.examUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 hover:text-emerald-800 whitespace-nowrap shrink-0"
                >
                  Buka Sumber
                  <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                </a>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={onLaunchExamMode}
                  className="inline-flex items-center gap-2 rounded-lg bg-emerald-700 px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-emerald-800 whitespace-nowrap shrink-0"
                >
                  <Lock className="h-4 w-4" aria-hidden="true" />
                  Uji Coba Mode Ujian Terkunci
                </button>

                <button
                  type="button"
                  onClick={() => void handleDownloadZip()}
                  disabled={isZipping}
                  className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:opacity-60 whitespace-nowrap shrink-0"
                >
                  <FolderArchive className="h-4 w-4" aria-hidden="true" />
                  {isZipping
                    ? 'Menyiapkan ZIP...'
                    : 'Unduh Project Android Studio (.ZIP)'}
                </button>

                <PWAInstallButton />
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col items-center justify-center rounded-xl border border-slate-200 bg-slate-900 p-6 text-center">
              <img
                src="/src/assets/images/exambro_shield_emblem_1794998133936.jpg"
                alt="Lambang Keamanan Exambro MTs Inayatul Marzuki"
                referrerPolicy="no-referrer"
                className="h-36 w-36 rounded-2xl object-cover border border-slate-700 shadow-lg"
              />
              <div className="mt-4 text-sm font-semibold text-white">
                {config.appName}
              </div>
              <div className="mt-1 font-mono text-xs text-emerald-300">
                {config.packageName}
              </div>
              <div className="mt-3 flex items-center gap-3 text-xs text-slate-400 font-mono tabular-nums">
                <span>PIN: {config.exitPin}</span>
                <span aria-hidden="true">·</span>
                <span>{config.durationMinutes} Menit</span>
              </div>
            </div>
          </div>
        </section>

        {/* Configuration & Native Security Matrix */}
        <section id="konfigurasi" className="space-y-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900">
                01. Konfigurasi Aplikasi & Penguncian Anti-Aplikasi Lain
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Setiap perubahan langsung memperbarui source code Kotlin APK dan
                Mode Ujian Web Kiosk.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onChangeConfig(DEFAULT_EXAMBRO_CONFIG)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              Reset Default Madrasah
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Identity, URL, PIN & Whitelist */}
            <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-6 space-y-5">
              <div>
                <label
                  htmlFor="cfg-exam-url"
                  className="block text-xs font-semibold text-slate-700"
                >
                  URL Halaman Asesmen
                </label>
                <input
                  id="cfg-exam-url"
                  type="url"
                  value={config.examUrl}
                  onChange={(e) => updateField('examUrl', e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="cfg-app-name"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Nama Aplikasi APK
                  </label>
                  <input
                    id="cfg-app-name"
                    type="text"
                    value={config.appName}
                    onChange={(e) => updateField('appName', e.target.value)}
                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="cfg-school-name"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Nama Madrasah / Sekolah
                  </label>
                  <input
                    id="cfg-school-name"
                    type="text"
                    value={config.schoolName}
                    onChange={(e) => updateField('schoolName', e.target.value)}
                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="cfg-exam-title"
                  className="block text-xs font-semibold text-slate-700"
                >
                  Judul Asesmen
                </label>
                <input
                  id="cfg-exam-title"
                  type="text"
                  value={config.examTitle}
                  onChange={(e) => updateField('examTitle', e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="cfg-pkg-name"
                  className="block text-xs font-semibold text-slate-700"
                >
                  Android Package Name (Application ID)
                </label>
                <input
                  id="cfg-pkg-name"
                  type="text"
                  value={config.packageName}
                  onChange={(e) => updateField('packageName', e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label
                    htmlFor="cfg-pin"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    PIN Pengawas
                  </label>
                  <input
                    id="cfg-pin"
                    type="text"
                    value={config.exitPin}
                    onChange={(e) => updateField('exitPin', e.target.value)}
                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="cfg-duration"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Durasi (Menit)
                  </label>
                  <input
                    id="cfg-duration"
                    type="number"
                    min={10}
                    max={300}
                    value={config.durationMinutes}
                    onChange={(e) =>
                      updateField(
                        'durationMinutes',
                        Math.max(10, Number(e.target.value) || 90),
                      )
                    }
                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="cfg-max-viol"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Batas Langgar
                  </label>
                  <input
                    id="cfg-max-viol"
                    type="number"
                    min={1}
                    max={10}
                    value={config.maxViolationsBeforeLock}
                    onChange={(e) =>
                      updateField(
                        'maxViolationsBeforeLock',
                        Math.max(1, Number(e.target.value) || 3),
                      )
                    }
                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>
              </div>

              {/* Token Gate */}
              <div className="border-t border-slate-200 pt-4 space-y-3">
                <label className="flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <div className="text-xs font-semibold text-slate-800">
                      Wajibkan Token Masuk Sebelum Ujian
                    </div>
                    <div className="text-xs text-slate-500">
                      Siswa diminta memasukkan token ruang sebelum soal dimuat.
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.security.requireToken}
                    onChange={(e) =>
                      updateSecurity('requireToken', e.target.checked)
                    }
                    className="h-4 w-4 rounded border-slate-300 text-emerald-700 focus:ring-emerald-700"
                  />
                </label>

                {config.security.requireToken && (
                  <div>
                    <label
                      htmlFor="cfg-token"
                      className="block text-xs font-semibold text-slate-700"
                    >
                      Kode Token Ujian
                    </label>
                    <input
                      id="cfg-token"
                      type="text"
                      value={config.security.examToken}
                      onChange={(e) =>
                        updateSecurity('examToken', e.target.value.toUpperCase())
                      }
                      className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm uppercase text-slate-900 focus:border-emerald-700 focus:outline-none"
                    />
                  </div>
                )}
              </div>

              {/* Domain Whitelist */}
              <div className="border-t border-slate-200 pt-4 space-y-3">
                <div>
                  <div className="text-xs font-semibold text-slate-800">
                    Whitelist Domain Diizinkan (APK WebView)
                  </div>
                  <div className="text-xs text-slate-500">
                    Link ke luar domain ini (WhatsApp, Google Search, AI, media
                    sosial) diblokir otomatis.
                  </div>
                </div>

                <form onSubmit={handleAddDomain} className="flex gap-2">
                  <input
                    type="text"
                    value={newDomain}
                    onChange={(e) => setNewDomain(e.target.value)}
                    placeholder="misal: quizizz.com"
                    className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0"
                  >
                    <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                    Tambah
                  </button>
                </form>

                <ul className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                  {config.allowedDomains.map((domain) => (
                    <li
                      key={domain}
                      className="flex items-center justify-between gap-2 px-3 py-2 text-xs"
                    >
                      <span className="font-mono text-slate-700 truncate">
                        {domain}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveDomain(domain)}
                        className="text-slate-400 hover:text-red-600 p-0.5"
                        aria-label={`Hapus domain ${domain}`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Right Column: Security Matrix */}
            <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white divide-y divide-slate-200">
              <div className="px-6 py-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-2.5">
                  <Shield
                    className="h-5 w-5 text-emerald-700"
                    aria-hidden="true"
                  />
                  <h3 className="text-base font-semibold text-slate-900">
                    Proteksi Sistem Android & Web Kiosk
                  </h3>
                </div>
                <span className="font-mono text-xs text-slate-500 tabular-nums">
                  {
                    SECURITY_ITEMS.filter(
                      (item) => config.security[item.key],
                    ).length
                  }{' '}
                  / {SECURITY_ITEMS.length} Aktif
                </span>
              </div>

              {SECURITY_ITEMS.map((item) => {
                const enabled = Boolean(config.security[item.key]);
                return (
                  <label
                    key={item.key}
                    className="flex items-start justify-between gap-4 px-6 py-4 cursor-pointer hover:bg-slate-50/80 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold text-slate-900">
                          {item.title}
                        </span>
                        <span className="font-mono text-xs text-slate-400">
                          {item.androidApi}
                        </span>
                      </div>
                      <p className="text-xs leading-relaxed text-slate-600">
                        {item.description}
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={enabled}
                      onChange={(e) =>
                        updateSecurity(item.key, e.target.checked)
                      }
                      className="mt-1 h-4 w-4 rounded border-slate-300 text-emerald-700 focus:ring-emerald-700 shrink-0"
                    />
                  </label>
                );
              })}
            </div>
          </div>
        </section>

        {/* Live Android Source Code Inspector */}
        <section id="source-apk" className="space-y-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900">
                02. Source Code Project Android APK Siap Kompilasi
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Kode sumber Kotlin, Manifest, Gradle, dan GitHub Actions
                otomatis menyesuaikan konfigurasi di atas.
              </p>
            </div>
            <button
              type="button"
              onClick={() => void handleDownloadZip()}
              disabled={isZipping}
              className="inline-flex items-center gap-2 rounded-lg bg-emerald-700 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-800 disabled:opacity-60 whitespace-nowrap shrink-0"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              Unduh Semua File (.ZIP)
            </button>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-950 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 bg-slate-900 px-4 py-2.5">
              <div className="flex items-center gap-1 overflow-x-auto">
                {androidFiles.slice(0, 5).map((file, idx) => (
                  <button
                    key={file.path}
                    type="button"
                    onClick={() => setSelectedFileIndex(idx)}
                    className={`rounded-md px-3 py-1.5 font-mono text-xs transition-colors whitespace-nowrap shrink-0 ${
                      selectedFileIndex === idx
                        ? 'bg-emerald-700 text-white font-medium'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {file.label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => void handleCopyCode()}
                className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 whitespace-nowrap shrink-0"
              >
                {copiedPath === activeFile.path ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    Tersalin
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    Salin Kode
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center justify-between border-b border-slate-900 bg-slate-950 px-4 py-2 text-xs text-slate-400 font-mono">
              <span className="inline-flex items-center gap-2 truncate">
                <FileCode2 className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                {activeFile.path}
              </span>
              <span className="shrink-0">
                {activeFile.content.split('\n').length} baris
              </span>
            </div>

            <pre className="max-h-[460px] overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200">
              <code>{activeFile.content}</code>
            </pre>
          </div>
        </section>

        {/* Build & Deployment Guide */}
        <section id="panduan" className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              03. Panduan Kompilasi File .APK & Penggunaan di Ruang Ujian
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              Pilih cara build APK yang paling mudah bagi panitia IT MTs
              Inayatul Marzuki.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <article className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
              <div className="text-xs font-semibold text-emerald-700">
                01. Kompilasi di Android Studio
              </div>
              <h3 className="text-base font-semibold text-slate-900">
                Build APK Lokal (Laptop/PC)
              </h3>
              <ol className="space-y-2 text-xs leading-relaxed text-slate-600 list-decimal list-inside">
                <li>
                  Klik tombol{' '}
                  <strong>Unduh Project Android Studio (.ZIP)</strong> di atas
                  lalu ekstrak foldernya.
                </li>
                <li>
                  Buka aplikasi <strong>Android Studio</strong>, pilih{' '}
                  <strong>Open</strong> dan arahkan ke folder hasil ekstrak.
                </li>
                <li>
                  Setelah Gradle selesai sinkronisasi, klik menu{' '}
                  <strong>
                    Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)
                  </strong>
                  .
                </li>
                <li>
                  File <span className="font-mono">app-debug.apk</span> siap
                  dibagikan ke HP siswa.
                </li>
              </ol>
            </article>

            <article className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
              <div className="text-xs font-semibold text-emerald-700">
                02. Build Cloud Tanpa Android Studio
              </div>
              <h3 className="text-base font-semibold text-slate-900">
                Otomatis via GitHub Actions
              </h3>
              <ol className="space-y-2 text-xs leading-relaxed text-slate-600 list-decimal list-inside">
                <li>
                  Buat repository baru di GitHub dan unggah seluruh isi ZIP
                  (sudah termasuk file{' '}
                  <span className="font-mono">
                    .github/workflows/build-apk.yml
                  </span>
                  ).
                </li>
                <li>
                  Buka tab <strong>Actions</strong> di repository GitHub Anda.
                </li>
                <li>
                  Pilih workflow <strong>Build Exambro Android APK</strong> lalu
                  klik <strong>Run workflow</strong>.
                </li>
                <li>
                  Setelah selesai (~2 menit), unduh file{' '}
                  <span className="font-mono">.apk</span> langsung dari bagian{' '}
                  <strong>Artifacts</strong>.
                </li>
              </ol>
            </article>

            <article className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
              <div className="text-xs font-semibold text-emerald-700">
                03. Kunci Layar di HP Siswa
              </div>
              <h3 className="text-base font-semibold text-slate-900">
                Mode Sematkan Layar & PWA
              </h3>
              <div className="space-y-2 text-xs leading-relaxed text-slate-600">
                <p>
                  Saat siswa membuka APK untuk pertama kali, Android akan
                  menampilkan konfirmasi{' '}
                  <strong>Sematkan Aplikasi / Screen Pinning</strong>. Siswa
                  wajib menekan <strong>Mengerti / Ya</strong> agar tombol Home
                  dan Recent Apps terkunci total.
                </p>
                <p>
                  Untuk penggunaan cepat tanpa menginstal APK, siswa juga dapat
                  memasang aplikasi ini sebagai <strong>PWA</strong> via Chrome
                  Android dan mengaktifkan mode{' '}
                  <strong>Uji Coba Mode Ujian Terkunci</strong>.
                </p>
                <div className="pt-1 flex items-center gap-2 text-emerald-800 font-medium">
                  <Smartphone className="h-4 w-4 shrink-0" />
                  <span>
                    PIN Keluar Default:{' '}
                    <span className="font-mono">{config.exitPin}</span>
                  </span>
                </div>
              </div>
            </article>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white py-6 mt-12">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 text-xs text-slate-500">
          <span>
            Exambro MTs Inayatul Marzuki · Asesmen Akhir Semester 2026-2027
          </span>
          <span className="font-mono">
            {config.packageName} · v{config.versionName}
          </span>
        </div>
      </footer>
    </div>
  );
};
