import { useEffect, useState } from "react";
import { store, useStore } from "../lib/store";
import { RARITY_LABEL, RARITY_TINT, itemById } from "../lib/catalog";
import { SEGMENTS } from "../lib/wheel";
import { toFa } from "../lib/fa";
import { boop, fanfare } from "../lib/sound";
import { Btn } from "./Hud";
import { CoinIcon } from "./icons";
import { ItemIcon } from "./ItemIcon";

function Dock({ children }: { children: React.ReactNode }) {
  return (
    <div className="pointer-events-none flex justify-center px-2 pb-2 sm:px-3 sm:pb-3">
      <div
        className="card no-scrollbar pointer-events-auto flex w-full max-w-md flex-col gap-2 overflow-y-auto rounded-3xl p-2.5"
        style={{ maxHeight: "min(46dvh, 340px)" }}
      >
        {children}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  prize reveal card                                                  */
/* ================================================================== */
function PrizeCard() {
  const prize = useStore((s) => s.wheel?.prize ?? null);
  const item = itemById(prize?.itemId);

  useEffect(() => {
    if (prize && prize.kind !== "nothing") fanfare();
  }, [prize]);

  if (!prize) return null;

  const win = prize.kind !== "nothing";
  const rarity = item?.rarity;

  return (
    <div className="pointer-events-auto fixed inset-0 z-45 flex items-center justify-center px-4">
      <div className="fade-in absolute inset-0 bg-slate-950/75" onClick={() => store.closeWheelResult()} />

      <div className="sheet panel relative w-full max-w-[320px] overflow-hidden rounded-3xl p-5 text-center">
        {/* rarity aura */}
        {win && (
          <div
            className="pointer-events-none absolute -top-16 left-1/2 size-56 -translate-x-1/2 rounded-full blur-3xl"
            style={{
              background: rarity ? RARITY_TINT[rarity] : "#FFD166",
              opacity: 0.34,
            }}
          />
        )}

        <div className="relative">
          <div className="text-[11px] font-black tracking-widest text-amber-900/50">
            {win ? "تبریک!" : "این دفعه نشد"}
          </div>

          <div className="my-3 text-6xl">{prize.emoji}</div>

          {rarity && (
            <span
              className="inline-block rounded-full px-2.5 py-1 text-[10px] font-black text-white"
              style={{ background: RARITY_TINT[rarity] }}
            >
              {RARITY_LABEL[rarity]}
            </span>
          )}

          <div className="mt-2 text-[16px] font-black text-amber-950">{prize.label}</div>

          {prize.amount != null && (
            <div className="mt-1 inline-flex items-center gap-1 text-2xl font-black tabular-nums text-emerald-600">
              <CoinIcon className="size-5" />+{toFa(prize.amount)}
            </div>
          )}

          {item && (
            <>
              <div className="mx-auto mt-3 grid size-24 place-items-center rounded-2xl bg-white/10 p-2 ring-2 ring-white/20">
                <ItemIcon id={item.id} className="size-full" />
              </div>
              <div className="mt-2 text-[10.5px] font-bold text-amber-900/60">
                خودکار روی جیکو پوشیده شد ✓
              </div>
            </>
          )}

          {prize.kind === "respin" && (
            <div className="mt-2 text-[11px] font-bold text-amber-800">
              می‌تونی همین حالا دوباره بچرخونی
            </div>
          )}

          <div className="mt-4">
            <Btn full size="lg" onClick={() => store.closeWheelResult()}>
              باشه
            </Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  dock                                                               */
/* ================================================================== */
export function WheelDock() {
  const wheel = useStore((s) => s.wheel);
  const freeSpins = useStore((s) => s.freeSpins);
  const lastSpin = useStore((s) => s.lastSpin);
  const [, force] = useState(0);

  // refresh the "available" state when the day rolls over
  useEffect(() => {
    const id = window.setInterval(() => force((v) => v + 1), 5000);
    return () => window.clearInterval(id);
  }, []);

  if (!wheel) return null;

  const today = new Date().setHours(0, 0, 0, 0);
  const dailyLeft = lastSpin < today;
  const can = dailyLeft || freeSpins > 0;
  const spinning = wheel.phase === "spinning";

  return (
    <>
      <Dock>
        <div className="flex items-center gap-2 rounded-2xl bg-gradient-to-l from-fuchsia-500/30 to-amber-400/15 px-3 py-2">
          <span className="text-xl">🎡</span>
          <div className="min-w-0 flex-1">
            <div className="text-[12px] font-black text-purple-950">گردونه‌ی شانس</div>
            <div className="text-[10px] font-bold text-purple-900/60">
              {spinning
                ? "در حال چرخش…"
                : can
                  ? dailyLeft
                    ? "چرخش روزانه‌ت آماده‌ست"
                    : `${toFa(freeSpins)} چرخش رایگان داری`
                  : "چرخش امروزت تموم شد — فردا بیا"}
            </div>
          </div>
          {freeSpins > 0 && (
            <span className="shrink-0 rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-black text-amber-950">
              +{toFa(freeSpins)}
            </span>
          )}
        </div>

        <Btn
          full
          size="lg"
          disabled={!can || spinning}
          onClick={() => {
            store.spinWheel();
            boop();
          }}
        >
          {spinning ? "🎡 در حال چرخش…" : can ? "🎯 بچرخون!" : "⏳ فردا برگرد"}
        </Btn>

        <Btn full tone="ghost" disabled={spinning} onClick={() => store.leaveWheel()}>
          برگشت به خونه
        </Btn>
      </Dock>

      {wheel.phase === "result" && <PrizeCard />}
    </>
  );
}

/* ================================================================== */
/*  panel entry — replaces the old daily gift                          */
/* ================================================================== */
export function WheelEntry() {
  const freeSpins = useStore((s) => s.freeSpins);
  const lastSpin = useStore((s) => s.lastSpin);
  const today = new Date().setHours(0, 0, 0, 0);
  const ready = lastSpin < today || freeSpins > 0;

  return (
    <button
      type="button"
      onClick={() => {
        store.goWheel();
        boop();
      }}
      className={`relative flex items-center gap-3 overflow-hidden rounded-2xl border p-3 text-right transition hover:-translate-y-0.5 ${
        ready
          ? "border-fuchsia-400/70 bg-gradient-to-l from-fuchsia-500/30 to-amber-400/15"
          : "tile opacity-80"
      }`}
    >
      <span className={`text-2xl ${ready ? "animate-floaty" : ""}`}>🎡</span>
      <div className="min-w-0 flex-1">
        <div className="text-[12.5px] font-black text-purple-950">گردونه‌ی شانس</div>
        <div className="text-[10px] font-bold text-purple-900/60">
          {ready ? "روزی یک چرخش رایگان — آماده‌ست!" : "امروز چرخوندی، فردا بیا"}
        </div>
      </div>
      {ready && (
        <span className="shrink-0 rounded-full bg-fuchsia-600 px-2 py-1 text-[9.5px] font-black text-white">
          آماده
        </span>
      )}
    </button>
  );
}

/** Small strip showing what the wheel can drop. */
export function WheelOdds() {
  const total = SEGMENTS.reduce((a, s) => a + s.weight, 0);
  return (
    <div className="tile rounded-2xl p-3">
      <div className="mb-1.5 text-[12px] font-black text-amber-950">جوایز گردونه</div>
      <div className="flex flex-col gap-1">
        {SEGMENTS.map((s) => {
          const pct = total ? (s.weight / total) * 100 : 0;
          return (
            <div key={s.id} className="flex items-center gap-2 text-[10.5px] font-bold">
              <span className="w-5 shrink-0 text-center">{s.emoji}</span>
              <span className="min-w-0 flex-1 truncate text-amber-900/75">{s.label}</span>
              <span
                className={`shrink-0 tabular-nums ${
                  s.weight === 0 ? "text-rose-500" : "text-amber-900/50"
                }`}
              >
                {s.weight === 0 ? "غیرقابل‌دسترس" : `${toFa(pct.toFixed(1).replace(".", "٫"))}٪`}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
