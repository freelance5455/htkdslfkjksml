import React, { useMemo, useState } from 'react';
import { Check, Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import type { DayFilter, Language, RoutineItem } from '../types/study';
import { RoutineVectorIcon } from './LiquidIcons';

interface RoutinePlannerProps {
  lang: Language;
  routines: RoutineItem[];
  onAdd: (item: Omit<RoutineItem, 'id' | 'completed' | 'createdAt'>) => void;
  onUpdate: (id: string, patch: Partial<RoutineItem>) => void;
  onDelete: (id: string) => void;
  onClearCompleted: () => void;
  onLoadSample: () => void;
}

const DAYS: Array<Exclude<DayFilter, 'all'>> = [
  'প্রতিদিন',
  'শনিবার',
  'রবিবার',
  'সোমবার',
  'মঙ্গলবার',
  'বুধবার',
  'বৃহস্পতিবার',
  'শুক্রবার',
];

const DAY_EN_MAP: Record<Exclude<DayFilter, 'all'>, string> = {
  প্রতিদিন: 'Daily',
  শনিবার: 'Sat',
  রবিবার: 'Sun',
  সোমবার: 'Mon',
  মঙ্গলবার: 'Tue',
  বুধবার: 'Wed',
  বৃহস্পতিবার: 'Thu',
  শুক্রবার: 'Fri',
};

export const RoutinePlanner: React.FC<RoutinePlannerProps> = ({
  lang,
  routines,
  onAdd,
  onUpdate,
  onDelete,
  onClearCompleted,
  onLoadSample,
}) => {
  const isBn = lang === 'bn';
  const [day, setDay] = useState<Exclude<DayFilter, 'all'>>('প্রতিদিন');
  const [startTime, setStartTime] = useState('06:00');
  const [endTime, setEndTime] = useState('07:30');
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const [filterDay, setFilterDay] = useState<DayFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanSubject = subject.trim();
    const cleanTopic = topic.trim();
    if (!cleanSubject) return;

    if (editingId) {
      onUpdate(editingId, {
        day,
        startTime,
        endTime,
        subject: cleanSubject,
        topic: cleanTopic,
      });
      setEditingId(null);
    } else {
      onAdd({
        day,
        startTime,
        endTime,
        subject: cleanSubject,
        topic: cleanTopic,
      });
    }

    setSubject('');
    setTopic('');
  };

  const startEdit = (item: RoutineItem) => {
    setEditingId(item.id);
    setDay(item.day);
    setStartTime(item.startTime);
    setEndTime(item.endTime);
    setSubject(item.subject);
    setTopic(item.topic);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setSubject('');
    setTopic('');
  };

  const filteredRoutines = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return [...routines]
      .filter((r) => (filterDay === 'all' ? true : r.day === filterDay))
      .filter((r) =>
        q
          ? r.subject.toLowerCase().includes(q) ||
            r.topic.toLowerCase().includes(q) ||
            r.day.toLowerCase().includes(q) ||
            DAY_EN_MAP[r.day].toLowerCase().includes(q)
          : true
      )
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [routines, filterDay, searchQuery]);

  const completedCount = routines.filter((r) => r.completed).length;

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
      {/* Left Form Panel */}
      <section className="liquid-glass rounded-3xl p-5 sm:p-6 lg:col-span-5">
        <div className="flex items-center justify-between gap-4 border-b border-white/12 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-sky-300/30 bg-sky-400/15 text-sky-200">
              <RoutineVectorIcon active className="h-5 w-5" />
            </div>
            <h2 className="text-lg font-semibold text-white">
              {editingId
                ? isBn
                  ? 'রুটিন এডিট'
                  : 'Edit Routine'
                : isBn
                  ? 'নতুন রুটিন'
                  : 'New Routine'}
            </h2>
          </div>
          {editingId && (
            <button
              type="button"
              onClick={cancelEdit}
              className="inline-flex min-h-[36px] items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium text-slate-300 hover:bg-white/10 hover:text-white whitespace-nowrap shrink-0"
            >
              <X className="h-3.5 w-3.5" />
              <span>{isBn ? 'বাতিল' : 'Cancel'}</span>
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label htmlFor="routine-day" className="block text-xs font-medium text-slate-200">
              {isBn ? 'দিন' : 'Day'}
            </label>
            <select
              id="routine-day"
              value={day}
              onChange={(e) => setDay(e.target.value as Exclude<DayFilter, 'all'>)}
              className="glass-input mt-1.5 w-full min-h-[44px] rounded-xl px-3.5 text-sm"
            >
              {DAYS.map((d) => (
                <option key={d} value={d}>
                  {isBn ? d : DAY_EN_MAP[d]}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="routine-start" className="block text-xs font-medium text-slate-200">
                {isBn ? 'শুরু' : 'Start'}
              </label>
              <input
                id="routine-start"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                required
                className="glass-input font-mono-tabular mt-1.5 w-full min-h-[44px] rounded-xl px-3 text-sm"
              />
            </div>
            <div>
              <label htmlFor="routine-end" className="block text-xs font-medium text-slate-200">
                {isBn ? 'শেষ' : 'End'}
              </label>
              <input
                id="routine-end"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                required
                className="glass-input font-mono-tabular mt-1.5 w-full min-h-[44px] rounded-xl px-3 text-sm"
              />
            </div>
          </div>

          <div>
            <label htmlFor="routine-subject" className="block text-xs font-medium text-slate-200">
              {isBn ? 'বিষয়' : 'Subject'}
            </label>
            <input
              id="routine-subject"
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder={isBn ? 'যেমন: গণিত' : 'e.g. Mathematics'}
              required
              maxLength={60}
              className="glass-input mt-1.5 w-full min-h-[44px] rounded-xl px-3.5 text-sm"
            />
          </div>

          <div>
            <label htmlFor="routine-topic" className="block text-xs font-medium text-slate-200">
              {isBn ? 'টপিক' : 'Topic'}
            </label>
            <input
              id="routine-topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder={isBn ? 'অধ্যায় বা টপিক' : 'Chapter or topic'}
              maxLength={100}
              className="glass-input mt-1.5 w-full min-h-[44px] rounded-xl px-3.5 text-sm"
            />
          </div>

          <button
            type="submit"
            className="inline-flex w-full min-h-[46px] items-center justify-center gap-2 rounded-xl bg-sky-400 px-5 py-2.5 text-sm font-semibold text-slate-950 shadow-sm transition hover:bg-sky-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-300 whitespace-nowrap"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            <span>
              {editingId
                ? isBn
                  ? 'সেভ করুন'
                  : 'Save'
                : isBn
                  ? 'যোগ করুন'
                  : 'Add Routine'}
            </span>
          </button>
        </form>
      </section>

      {/* Right List Panel */}
      <section className="liquid-glass rounded-3xl p-5 sm:p-6 lg:col-span-7">
        <div className="flex flex-col gap-3 border-b border-white/10 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {isBn ? 'পড়ার তালিকা' : 'Study Schedule'}
            </h2>
            <p className="mt-0.5 text-xs text-slate-300 tabular-nums">
              {isBn
                ? `মোট: ${routines.length} · সম্পন্ন: ${completedCount}`
                : `Total: ${routines.length} · Done: ${completedCount}`}
            </p>
          </div>
          {completedCount > 0 && (
            <button
              type="button"
              onClick={onClearCompleted}
              className="inline-flex min-h-[38px] items-center gap-1.5 self-start rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-200 transition hover:bg-white/15 whitespace-nowrap shrink-0 sm:self-auto"
            >
              <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{isBn ? 'সম্পন্ন মুছুন' : 'Clear Done'}</span>
            </button>
          )}
        </div>

        {/* Search & Day Filter */}
        <div className="mt-4 space-y-3">
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isBn ? 'খুঁজুন...' : 'Search...'}
              className="glass-input w-full min-h-[42px] rounded-xl pl-10 pr-4 text-sm"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setFilterDay('all')}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition whitespace-nowrap shrink-0 ${
                filterDay === 'all'
                  ? 'bg-white text-slate-950'
                  : 'bg-white/5 text-slate-300 hover:bg-white/12 hover:text-white'
              }`}
            >
              {isBn ? 'সব' : 'All'}
            </button>
            {DAYS.map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setFilterDay(d)}
                className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition whitespace-nowrap shrink-0 ${
                  filterDay === d
                    ? 'bg-white text-slate-950'
                    : 'bg-white/5 text-slate-300 hover:bg-white/12 hover:text-white'
                }`}
              >
                {isBn ? d : DAY_EN_MAP[d]}
              </button>
            ))}
          </div>
        </div>

        {/* Routine Rows */}
        <div className="mt-4 divide-y divide-white/10">
          {filteredRoutines.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-sm font-medium text-slate-200">
                {routines.length === 0
                  ? isBn
                    ? 'কোনো রুটিন নেই'
                    : 'No routines yet'
                  : isBn
                    ? 'পাওয়া যায়নি'
                    : 'No matches'}
              </p>
              {routines.length === 0 && (
                <button
                  type="button"
                  onClick={onLoadSample}
                  className="mt-4 inline-flex min-h-[40px] items-center rounded-xl border border-white/20 bg-white/10 px-4 py-2 text-xs font-medium text-white transition hover:bg-white/20 whitespace-nowrap"
                >
                  {isBn ? 'নমুনা লোড' : 'Load Sample'}
                </button>
              )}
            </div>
          ) : (
            filteredRoutines.map((item) => (
              <div
                key={item.id}
                className="flex items-start justify-between gap-3 py-3.5 transition-colors hover:bg-white/[0.03] -mx-2 px-2 rounded-xl"
              >
                <div className="flex min-w-0 items-start gap-3">
                  <button
                    type="button"
                    onClick={() => onUpdate(item.id, { completed: !item.completed })}
                    aria-label={item.subject}
                    className={`mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border transition ${
                      item.completed
                        ? 'border-emerald-400/50 bg-emerald-400/20 text-emerald-300'
                        : 'border-white/20 bg-white/5 text-transparent hover:border-white/40'
                    }`}
                  >
                    <Check className="h-4 w-4" />
                  </button>

                  <div className="min-w-0">
                    <h3
                      className={`text-sm font-semibold leading-snug ${
                        item.completed ? 'text-slate-400 line-through' : 'text-white'
                      }`}
                    >
                      {item.subject}
                    </h3>
                    {item.topic && (
                      <p className="mt-0.5 text-xs text-slate-300 break-words">{item.topic}</p>
                    )}
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-300">
                      <span className="font-mono-tabular text-sky-300">
                        {item.startTime} – {item.endTime}
                      </span>
                      <span aria-hidden="true" className="text-slate-500">
                        ·
                      </span>
                      <span>{isBn ? item.day : DAY_EN_MAP[item.day]}</span>
                      {item.completed && (
                        <>
                          <span aria-hidden="true" className="text-slate-500">
                            ·
                          </span>
                          <span className="text-emerald-300">{isBn ? 'সম্পন্ন' : 'Done'}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex shrink-0 items-center gap-1">
                  <button
                    type="button"
                    onClick={() => startEdit(item)}
                    aria-label={isBn ? 'এডিট' : 'Edit'}
                    className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-300 transition hover:bg-white/10 hover:text-white"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDelete(item.id)}
                    aria-label={isBn ? 'মুছুন' : 'Delete'}
                    className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-300 transition hover:bg-rose-500/20 hover:text-rose-300"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
};
