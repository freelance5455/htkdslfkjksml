import React, { useState } from 'react';
import { audioEngine } from '../services/audioEngine';
import { Moon, Clock, X, Check, VolumeX } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  remainingSeconds: number | null;
}

export const SleepTimerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  remainingSeconds,
}) => {
  const [customMinutes, setCustomMinutes] = useState('20');

  if (!isOpen) return null;

  const handleSetTimer = (minutes: number | 'end-of-track') => {
    audioEngine.setSleepTimer(minutes);
    onClose();
  };

  const handleCancelTimer = () => {
    audioEngine.clearSleepTimer();
    onClose();
  };

  const formatRemaining = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s < 10 ? '0' : ''}${s}s`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative text-left">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            <Moon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-white">Temporizador de Apagado</h3>
            <p className="text-xs text-slate-400">Apagado automático con desvanecimiento suave</p>
          </div>
        </div>

        {/* Current status if active */}
        {remainingSeconds !== null && remainingSeconds > 0 && (
          <div className="mb-4 p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-indigo-300 font-medium">
              <Clock className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Tiempo restante:</span>
            </div>
            <span className="font-mono tabular-nums text-sm font-bold text-white">
              {formatRemaining(remainingSeconds)}
            </span>
          </div>
        )}

        <div className="space-y-2 mb-5">
          <label className="text-xs font-medium text-slate-400 block">Elige duración:</label>
          <div className="grid grid-cols-3 gap-2">
            {[15, 30, 45, 60].map((m) => (
              <button
                key={m}
                onClick={() => handleSetTimer(m)}
                className="py-2.5 text-xs font-semibold rounded-xl bg-slate-800/80 hover:bg-indigo-600 hover:text-white border border-slate-700/60 text-slate-200 transition"
              >
                {m} minutos
              </button>
            ))}

            <button
              onClick={() => handleSetTimer('end-of-track')}
              className="col-span-2 py-2.5 text-xs font-semibold rounded-xl bg-slate-800/80 hover:bg-indigo-600 hover:text-white border border-slate-700/60 text-slate-200 transition"
            >
              Fin de la canción
            </button>
          </div>

          {/* Custom Minutes Input */}
          <div className="pt-2">
            <label className="text-[11px] text-slate-400 block mb-1">Minutos personalizados:</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="360"
                value={customMinutes}
                onChange={(e) => setCustomMinutes(e.target.value)}
                className="flex-1 px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none"
              />
              <button
                onClick={() => {
                  const val = parseInt(customMinutes);
                  if (val > 0) handleSetTimer(val);
                }}
                className="px-4 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm"
              >
                Iniciar
              </button>
            </div>
          </div>
        </div>

        {/* Cancel button if active */}
        {remainingSeconds !== null && (
          <button
            onClick={handleCancelTimer}
            className="w-full py-2.5 px-4 text-xs font-semibold text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded-xl transition flex items-center justify-center gap-2"
          >
            <VolumeX className="w-4 h-4" />
            <span>Cancelar Temporizador</span>
          </button>
        )}
      </div>
    </div>
  );
};
