import React, { useState, useRef, useMemo, useEffect } from 'react';
import { FileItem } from '../types';
import { 
  Folder, 
  FolderOpen, 
  FileCode, 
  FileText, 
  Image as ImageIcon, 
  Plus, 
  FolderPlus, 
  Upload, 
  Trash2, 
  Edit3, 
  Copy, 
  ChevronRight, 
  ChevronDown,
  MoreVertical
} from 'lucide-react';

interface FileExplorerProps {
  files: FileItem[];
  activeFileId: string | null;
  copiedFile?: FileItem | null;
  onSelectFile: (id: string) => void;
  onOpenFileInEditor?: (id: string) => void;
  onCreateFile: (name: string, isFolder: boolean, parentId?: string | null, content?: string) => void;
  onRenameFile: (id: string, newName: string) => void;
  onDeleteFile: (id: string) => void;
  onMoveFile?: (id: string, targetFolderId: string | null) => void;
  onCopyFile?: (file: FileItem) => void;
  onPasteFile?: (targetFolderId?: string | null) => void;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({
  files,
  activeFileId,
  copiedFile,
  onSelectFile,
  onOpenFileInEditor,
  onCreateFile,
  onRenameFile,
  onDeleteFile,
  onCopyFile,
  onPasteFile,
}) => {
  // Guarantee unique files by id to prevent duplicate React keys
  const uniqueFiles = useMemo(() => {
    const seen = new Set<string>();
    return files.filter((f) => {
      if (!f || !f.id || seen.has(f.id)) return false;
      seen.add(f.id);
      return true;
    });
  }, [files]);
  const [openFolders, setOpenFolders] = useState<Record<string, boolean>>({});
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [newPrompt, setNewPrompt] = useState<{ isFolder: boolean; parentId: string | null } | null>(null);
  const [newItemName, setNewItemName] = useState('');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  useEffect(() => {
    if (!activeMenuId) return;
    const handleClickOutside = () => setActiveMenuId(null);
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, [activeMenuId]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleFolder = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenFolders((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const startRename = (file: FileItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setEditingId(file.id);
    setEditName(file.name);
    setActiveMenuId(null);
  };

  const submitRename = (id: string) => {
    const trimmed = editName.trim();
    if (trimmed) {
      onRenameFile(id, trimmed);
    }
    setEditingId(null);
  };

  const submitCreate = () => {
    if (!newPrompt) return;
    const trimmed = newItemName.trim();
    if (trimmed) {
      onCreateFile(trimmed, newPrompt.isFolder, newPrompt.parentId);
    }
    setNewPrompt(null);
    setNewItemName('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadFiles = e.target.files;
    if (!uploadFiles || uploadFiles.length === 0) return;

    for (let i = 0; i < uploadFiles.length; i++) {
      const file = uploadFiles[i];
      const isImg = file.type.startsWith('image/');

      const reader = new FileReader();
      if (isImg) {
        reader.onload = (event) => {
          const content = event.target?.result as string;
          onCreateFile(file.name, false, null, content);
        };
        reader.readAsDataURL(file);
      } else {
        reader.onload = (event) => {
          const content = (event.target?.result as string) || '';
          onCreateFile(file.name, false, null, content);
        };
        reader.readAsText(file);
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const getFileIcon = (file: FileItem) => {
    if (file.isFolder) {
      return openFolders[file.id] ? (
        <FolderOpen className="w-4 h-4 text-[#359efe] shrink-0" />
      ) : (
        <Folder className="w-4 h-4 text-[#359efe] shrink-0" />
      );
    }

    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (['png', 'jpg', 'jpeg', 'svg', 'webp', 'gif', 'ico'].includes(ext) || file.content?.startsWith('data:image/')) {
      return <ImageIcon className="w-4 h-4 text-emerald-400 shrink-0" />;
    }
    if (ext === 'html') {
      return <FileCode className="w-4 h-4 text-orange-400 shrink-0" />;
    }
    if (ext === 'css') {
      return <FileText className="w-4 h-4 text-blue-400 shrink-0" />;
    }
    if (['js', 'ts', 'jsx', 'tsx'].includes(ext)) {
      return <FileCode className="w-4 h-4 text-yellow-400 shrink-0" />;
    }
    return <FileText className="w-4 h-4 theme-text-muted shrink-0" />;
  };

  const renderTree = (parentId: string | null = null, depth = 0) => {
    const items = uniqueFiles.filter((f) => (f.parentId || null) === parentId);

    // Folders first
    items.sort((a, b) => {
      if (a.isFolder === b.isFolder) return a.name.localeCompare(b.name);
      return a.isFolder ? -1 : 1;
    });

    return items.map((item) => {
      const isSelected = activeFileId === item.id;
      const isOpen = !!openFolders[item.id];

      return (
        <div key={item.id} className="w-full">
          <div
            onClick={() => {
              if (item.isFolder) {
                setOpenFolders((prev) => ({ ...prev, [item.id]: !prev[item.id] }));
              } else {
                onSelectFile(item.id);
                onOpenFileInEditor?.(item.id);
              }
            }}
            onContextMenu={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setActiveMenuId(activeMenuId === item.id ? null : item.id);
            }}
            style={{ paddingLeft: `${depth * 14 + 10}px` }}
            className={`group flex items-center justify-between py-1.5 pr-2 rounded text-xs font-mono cursor-pointer transition-colors relative select-none ${
              isSelected
                ? 'theme-bg-surface text-slate-100 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:theme-bg-surface-hover'
            }`}
          >
            <div className="flex items-center space-x-1.5 truncate flex-grow mr-1">
              {item.isFolder ? (
                <span onClick={(e) => toggleFolder(item.id, e)} className="p-0.5">
                  {isOpen ? (
                    <ChevronDown className="w-3 h-3 text-slate-500" />
                  ) : (
                    <ChevronRight className="w-3 h-3 text-slate-500" />
                  )}
                </span>
              ) : (
                <span className="w-3.5" />
              )}

              {getFileIcon(item)}

              {editingId === item.id ? (
                <input
                  type="text"
                  autoFocus
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  onBlur={() => submitRename(item.id)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') submitRename(item.id);
                    if (e.key === 'Escape') setEditingId(null);
                  }}
                  onClick={(e) => e.stopPropagation()}
                  className="bg-transparent border border-[#359efe] text-xs font-mono px-1 py-0.5 rounded outline-none text-white w-28"
                />
              ) : (
                <span className="truncate">{item.name}</span>
              )}
            </div>

            {/* Quick Actions / Hover Menu & File Options Button */}
            <div className="flex items-center space-x-0.5 shrink-0">
              <div className="hidden group-hover:flex items-center space-x-0.5">
                {item.isFolder && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setOpenFolders((prev) => ({ ...prev, [item.id]: true }));
                      setNewPrompt({ isFolder: false, parentId: item.id });
                    }}
                    className="p-1 hover:text-white rounded"
                    title="New File inside"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                )}

                <button
                  onClick={(e) => startRename(item, e)}
                  className="p-1 hover:text-cyan-300 rounded"
                  title="Rename"
                >
                  <Edit3 className="w-3 h-3" />
                </button>

                {onCopyFile && !item.isFolder && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCopyFile(item);
                    }}
                    className="p-1 hover:text-[#359efe] rounded"
                    title="Copy file"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                )}

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (window.confirm(`Are you sure you want to delete "${item.name}"?`)) {
                      onDeleteFile(item.id);
                    }
                  }}
                  className="p-1 hover:text-red-400 rounded"
                  title="Delete File"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>

              {/* 3-dots File Option Button (always accessible) */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveMenuId(activeMenuId === item.id ? null : item.id);
                }}
                className={`p-1 rounded transition-colors ${
                  activeMenuId === item.id
                    ? 'text-[#359efe] bg-[#2e3144]'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
                title="File Options"
              >
                <MoreVertical className="w-3 h-3" />
              </button>
            </div>

            {/* Floating File Options Dropdown Menu */}
            {activeMenuId === item.id && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-2 top-7 z-50 bg-[#1c1d26] border border-[#2e3144] rounded-xl shadow-2xl py-1 w-44 text-xs font-sans text-slate-200 animate-in fade-in zoom-in-95 duration-100"
              >
                <div className="px-3 py-1.5 text-[10px] uppercase font-mono text-slate-500 border-b border-slate-800 truncate">
                  {item.name}
                </div>

                {item.isFolder && (
                  <button
                    onClick={() => {
                      setOpenFolders((prev) => ({ ...prev, [item.id]: true }));
                      setNewPrompt({ isFolder: false, parentId: item.id });
                      setActiveMenuId(null);
                    }}
                    className="w-full px-3 py-1.5 text-left flex items-center space-x-2 hover:bg-[#282a38] text-slate-300 hover:text-white cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-cyan-400" />
                    <span>New File Inside</span>
                  </button>
                )}

                <button
                  onClick={() => startRename(item)}
                  className="w-full px-3 py-1.5 text-left flex items-center space-x-2 hover:bg-[#282a38] text-slate-300 hover:text-white cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Rename</span>
                </button>

                {onCopyFile && !item.isFolder && (
                  <button
                    onClick={() => {
                      onCopyFile(item);
                      setActiveMenuId(null);
                    }}
                    className="w-full px-3 py-1.5 text-left flex items-center space-x-2 hover:bg-[#282a38] text-slate-300 hover:text-white cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 text-[#359efe]" />
                    <span>Duplicate / Copy</span>
                  </button>
                )}

                <div className="border-t border-slate-800 my-1" />

                <button
                  onClick={() => {
                    setActiveMenuId(null);
                    if (window.confirm(`Are you sure you want to delete "${item.name}"?`)) {
                      onDeleteFile(item.id);
                    }
                  }}
                  className="w-full px-3 py-1.5 text-left flex items-center space-x-2 hover:bg-red-500/20 text-red-400 hover:text-red-300 font-medium cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete {item.isFolder ? 'Folder' : 'File'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Render children if folder is open */}
          {item.isFolder && isOpen && renderTree(item.id, depth + 1)}
        </div>
      );
    });
  };

  return (
    <div className="flex flex-col h-full w-full select-none font-sans text-xs theme-text-main overflow-hidden">
      {/* Explorer Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b theme-border shrink-0">
        <span className="font-semibold uppercase tracking-wider text-[11px] theme-text-muted">
          Files
        </span>

        <div className="flex items-center space-x-1">
          {/* New File */}
          <button
            onClick={() => setNewPrompt({ isFolder: false, parentId: null })}
            className="p-1 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded transition-colors cursor-pointer"
            title="New File"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          {/* New Folder */}
          <button
            onClick={() => setNewPrompt({ isFolder: true, parentId: null })}
            className="p-1 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded transition-colors cursor-pointer"
            title="New Folder"
          >
            <FolderPlus className="w-3.5 h-3.5" />
          </button>

          {/* Upload Files */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-1 theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover rounded transition-colors cursor-pointer"
            title="Upload Files & Images"
          >
            <Upload className="w-3.5 h-3.5" />
          </button>
          <input
            type="file"
            ref={fileInputRef}
            multiple
            onChange={handleFileUpload}
            className="hidden"
            accept=".html,.css,.js,.jsx,.ts,.tsx,.json,.svg,.png,.jpg,.jpeg,.gif,.webp"
          />
        </div>
      </div>

      {/* New File / Folder input prompt */}
      {newPrompt && (
        <div className="px-3 py-2 border-b theme-border theme-bg-surface">
          <div className="flex items-center space-x-1.5 mb-1.5">
            {newPrompt.isFolder ? (
              <Folder className="w-3.5 h-3.5 text-[#359efe]" />
            ) : (
              <FileCode className="w-3.5 h-3.5 text-cyan-400" />
            )}
            <span className="text-[11px] font-medium text-slate-300">
              {newPrompt.isFolder ? 'New Folder Name' : 'New File Name'}
            </span>
          </div>
          <div className="flex items-center space-x-1.5">
            <input
              type="text"
              autoFocus
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder={newPrompt.isFolder ? 'components' : 'app.js'}
              onKeyDown={(e) => {
                if (e.key === 'Enter') submitCreate();
                if (e.key === 'Escape') setNewPrompt(null);
              }}
              className="w-full px-2 py-1 text-xs font-mono rounded border theme-border theme-bg-main theme-text-main focus:outline-none focus:border-[#359efe]"
            />
            <button
              onClick={submitCreate}
              className="px-2 py-1 bg-[#359efe] hover:bg-[#2563eb] text-white rounded text-[11px] font-bold cursor-pointer"
            >
              Add
            </button>
            <button
              onClick={() => setNewPrompt(null)}
              className="px-2 py-1 theme-bg-surface hover:theme-bg-surface-hover theme-text-muted rounded text-[11px] cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* File Tree List */}
      <div className="flex-grow overflow-y-auto px-1.5 py-2 space-y-0.5">
        {uniqueFiles.length === 0 ? (
          <div className="text-center py-8 theme-text-muted text-[11px] px-4">
            No files in project. Click + above to create a file.
          </div>
        ) : (
          renderTree(null, 0)
        )}
      </div>

      {/* Bottom Drop Zone Hint */}
      <div
        onClick={() => fileInputRef.current?.click()}
        className="m-2 p-2.5 rounded-lg border border-dashed theme-border theme-text-muted hover:theme-text-main hover:theme-bg-surface-hover text-center text-[10px] cursor-pointer transition-colors"
      >
        Drop images or files here or click to browse
      </div>
    </div>
  );
};
