import { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import {
  ChevronRight,
  ChevronLeft,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Download,
  ExternalLink,
  AlertCircle,
} from 'lucide-react';
import { getFastFileBytes } from '../lib/fileDb';
import { TactileButton } from './InteractiveButton';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

interface PdfViewerProps {
  fileUrl: string;
  blob: Blob | null;
  fileName: string;
  onDownload: () => void;
}

interface CachedPageCanvas {
  canvas: HTMLCanvasElement;
  zoom: number;
  dpr: number;
}

export function PdfViewer({ fileUrl, blob, fileName, onDownload }: PdfViewerProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pdfDocRef = useRef<pdfjsLib.PDFDocumentProxy | null>(null);
  const renderTaskRef = useRef<pdfjsLib.RenderTask | null>(null);
  const preRenderedRef = useRef<Map<number, CachedPageCanvas>>(new Map());

  const [numPages, setNumPages] = useState(0);
  const [pageNumber, setPageNumber] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [loadProgress, setLoadProgress] = useState(0);
  const [docLoading, setDocLoading] = useState(true);
  const [firstPageReady, setFirstPageReady] = useState(false);
  const [pageRendering, setPageRendering] = useState(false);
  const [loadError, setLoadError] = useState(false);

  // Load PDF document from Memory / CacheStorage / IndexedDB, or fetch once and cache
  useEffect(() => {
    let cancelled = false;
    let activeLoadingTask: pdfjsLib.PDFDocumentLoadingTask | null = null;

    preRenderedRef.current.clear();
    setDocLoading(true);
    setFirstPageReady(false);
    setLoadError(false);
    setLoadProgress(15);
    setPageNumber(1);
    setNumPages(0);
    setZoom(1);

    const loadPdf = async () => {
      try {
        const dataBytes = await getFastFileBytes(
          fileUrl,
          blob,
          'application/pdf',
          fileName,
          (pct) => {
            if (!cancelled) setLoadProgress(pct);
          }
        );

        if (cancelled) return;

        activeLoadingTask = pdfjsLib.getDocument({
          data: dataBytes,
          disableAutoFetch: false,
          disableStream: false,
        });
        activeLoadingTask.onProgress = (progressData: { loaded: number; total: number }) => {
          if (cancelled || !progressData.total) return;
          const pct = Math.min(
            98,
            Math.max(80, Math.round((progressData.loaded / progressData.total) * 98))
          );
          setLoadProgress(pct);
        };

        const doc = await activeLoadingTask.promise;
        if (cancelled) {
          await doc.cleanup().catch(() => {});
          return;
        }

        if (pdfDocRef.current) {
          await pdfDocRef.current.cleanup().catch(() => {});
        }
        pdfDocRef.current = doc;
        setNumPages(doc.numPages);
        setLoadProgress(100);
        setDocLoading(false);
      } catch {
        if (!cancelled) {
          setLoadError(true);
          setDocLoading(false);
        }
      }
    };

    void loadPdf();

    return () => {
      cancelled = true;
      preRenderedRef.current.clear();
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch {
          // ignore
        }
        renderTaskRef.current = null;
      }
      if (pdfDocRef.current) {
        void pdfDocRef.current.cleanup().catch(() => {});
        pdfDocRef.current = null;
      }
      if (activeLoadingTask) {
        void activeLoadingTask.destroy().catch(() => {});
      }
    };
  }, [fileUrl, blob, fileName]);

  // Render active page immediately: medium quality at zoom=1, high quality when zoomed in
  useEffect(() => {
    const doc = pdfDocRef.current;
    const canvas = canvasRef.current;
    if (!doc || !canvas || docLoading || loadError || pageNumber < 1 || pageNumber > numPages) {
      return;
    }

    // Medium quality on initial open (dpr = 1) for instant paint; HD quality when zoomed
    const targetDpr = zoom > 1 ? Math.min(window.devicePixelRatio || 1, 2) : 1;

    // Instant offscreen canvas cache hit when pre-rendered in background!
    const cached = preRenderedRef.current.get(pageNumber);
    if (cached && cached.zoom === zoom && cached.dpr >= targetDpr) {
      canvas.width = cached.canvas.width;
      canvas.height = cached.canvas.height;
      canvas.style.width = cached.canvas.style.width;
      canvas.style.height = cached.canvas.style.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(cached.canvas, 0, 0);
        setPageRendering(false);
        setFirstPageReady(true);
        return;
      }
    }

    let cancelled = false;
    setPageRendering(true);

    const renderPage = async () => {
      try {
        if (renderTaskRef.current) {
          try {
            renderTaskRef.current.cancel();
          } catch {
            // ignore
          }
          renderTaskRef.current = null;
        }

        const page = await doc.getPage(pageNumber);
        if (cancelled) return;

        const baseViewport = page.getViewport({ scale: 1 });
        const containerWidth = containerRef.current?.clientWidth
          ? Math.max(260, containerRef.current.clientWidth - 24)
          : 640;
        // Medium initial fit scale on default open for fast rendering
        const maxInitialFit = zoom === 1 ? 1.1 : 1.45;
        const fitScale = Math.min(maxInitialFit, containerWidth / baseViewport.width);
        const effectiveScale = Math.max(0.45, fitScale * zoom);
        const viewport = page.getViewport({ scale: effectiveScale });

        canvas.width = Math.floor(viewport.width * targetDpr);
        canvas.height = Math.floor(viewport.height * targetDpr);
        canvas.style.width = `${Math.floor(viewport.width)}px`;
        canvas.style.height = `${Math.floor(viewport.height)}px`;

        const task = page.render({
          canvas,
          viewport,
          transform: targetDpr !== 1 ? [targetDpr, 0, 0, targetDpr, 0, 0] : undefined,
        });
        renderTaskRef.current = task;
        await task.promise;
        if (!cancelled) {
          setPageRendering(false);
          setFirstPageReady(true);
        }
      } catch (err) {
        const name = (err as { name?: string })?.name;
        if (!cancelled && name !== 'RenderingCancelledException') {
          setLoadError(true);
          setPageRendering(false);
        }
      }
    };

    void renderPage();

    return () => {
      cancelled = true;
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch {
          // ignore
        }
      }
    };
  }, [docLoading, loadError, pageNumber, numPages, zoom]);

  // Progressive background pre-rendering: page-by-page after Page 1 is visible
  useEffect(() => {
    const doc = pdfDocRef.current;
    if (!doc || docLoading || !firstPageReady || loadError || numPages <= 1) return;

    let cancelled = false;
    let timerId: number | null = null;
    const bgZoom = zoom;
    const bgDpr = bgZoom > 1 ? Math.min(window.devicePixelRatio || 1, 2) : 1;

    // Prioritize nearby pages first (next 1..8 pages, then preceding)
    const queue: number[] = [];
    for (let offset = 1; offset <= 10; offset++) {
      if (pageNumber + offset <= numPages) queue.push(pageNumber + offset);
    }
    if (pageNumber - 1 >= 1) queue.push(pageNumber - 1);

    const processNextInQueue = async (index: number) => {
      if (cancelled || index >= queue.length) return;
      const targetPage = queue[index];

      const existing = preRenderedRef.current.get(targetPage);
      if (existing && existing.zoom === bgZoom && existing.dpr >= bgDpr) {
        timerId = window.setTimeout(() => void processNextInQueue(index + 1), 30);
        return;
      }

      try {
        const page = await doc.getPage(targetPage);
        if (cancelled) return;

        const baseViewport = page.getViewport({ scale: 1 });
        const containerWidth = containerRef.current?.clientWidth
          ? Math.max(260, containerRef.current.clientWidth - 24)
          : 640;
        const maxInitialFit = bgZoom === 1 ? 1.1 : 1.45;
        const fitScale = Math.min(maxInitialFit, containerWidth / baseViewport.width);
        const effectiveScale = Math.max(0.45, fitScale * bgZoom);
        const viewport = page.getViewport({ scale: effectiveScale });

        const offscreen = document.createElement('canvas');
        offscreen.width = Math.floor(viewport.width * bgDpr);
        offscreen.height = Math.floor(viewport.height * bgDpr);
        offscreen.style.width = `${Math.floor(viewport.width)}px`;
        offscreen.style.height = `${Math.floor(viewport.height)}px`;

        const bgTask = page.render({
          canvas: offscreen,
          viewport,
          transform: bgDpr !== 1 ? [bgDpr, 0, 0, bgDpr, 0, 0] : undefined,
        });
        await bgTask.promise;

        if (!cancelled) {
          // Keep pre-rendered cache tidy
          if (preRenderedRef.current.size >= 12) {
            const firstKey = preRenderedRef.current.keys().next().value;
            if (firstKey !== undefined) preRenderedRef.current.delete(firstKey);
          }
          preRenderedRef.current.set(targetPage, {
            canvas: offscreen,
            zoom: bgZoom,
            dpr: bgDpr,
          });
        }
      } catch {
        // Non-fatal background cache skip
      }

      if (!cancelled) {
        timerId = window.setTimeout(() => void processNextInQueue(index + 1), 80);
      }
    };

    timerId = window.setTimeout(() => void processNextInQueue(0), 100);

    return () => {
      cancelled = true;
      if (timerId !== null) window.clearTimeout(timerId);
    };
  }, [docLoading, firstPageReady, loadError, numPages, pageNumber, zoom]);

  if (loadError) {
    return (
      <div className="w-full max-w-md mx-auto bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-center space-y-4 shadow-xs">
        <div className="w-12 h-12 mx-auto rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
          <AlertCircle className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <p className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
            مش قادرين نعرض الملف هنا
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{fileName}</p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
          <TactileButton
            type="button"
            flashSuccess
            onClick={onDownload}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs sm:text-sm min-h-[40px]"
          >
            <Download className="w-4 h-4" />
            <span>تحميل الملف</span>
          </TactileButton>

          {fileUrl && (
            <a
              href={fileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900 text-blue-700 dark:text-blue-300 font-bold text-xs sm:text-sm min-h-[40px] transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>فتح في تبويب جديد</span>
            </a>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col gap-3">
      {/* Toolbar: Page Navigation + Zoom Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl px-3 py-2 shadow-xs">
        {/* Page Navigation */}
        <div className="flex items-center gap-1.5">
          <TactileButton
            type="button"
            disabled={docLoading || pageNumber <= 1}
            onClick={() => setPageNumber((p) => Math.max(1, p - 1))}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-violet-50 dark:hover:bg-violet-950/60 disabled:opacity-45 text-slate-800 dark:text-slate-100 text-xs font-bold min-h-[36px]"
          >
            <ChevronRight className="w-4 h-4" />
            <span>السابق</span>
          </TactileButton>

          <span className="px-2.5 text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 font-mono-num whitespace-nowrap">
            {docLoading ? '...' : `صفحة ${pageNumber} من ${numPages}`}
          </span>

          <TactileButton
            type="button"
            disabled={docLoading || pageNumber >= numPages}
            onClick={() => setPageNumber((p) => Math.min(numPages, p + 1))}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-violet-50 dark:hover:bg-violet-950/60 disabled:opacity-45 text-slate-800 dark:text-slate-100 text-xs font-bold min-h-[36px]"
          >
            <span>التالي</span>
            <ChevronLeft className="w-4 h-4" />
          </TactileButton>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1.5">
          <TactileButton
            type="button"
            disabled={docLoading || zoom <= 0.6}
            onClick={() => setZoom((z) => Math.max(0.5, Number((z - 0.2).toFixed(2))))}
            aria-label="تصغير"
            title="تصغير"
            className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-45 text-slate-700 dark:text-slate-200 flex items-center justify-center"
          >
            <ZoomOut className="w-4 h-4" />
          </TactileButton>

          <span className="min-w-[46px] text-center font-mono-num text-xs font-bold text-slate-700 dark:text-slate-200">
            {Math.round(zoom * 100)}%
          </span>

          <TactileButton
            type="button"
            disabled={docLoading || zoom >= 2.4}
            onClick={() => setZoom((z) => Math.min(2.5, Number((z + 0.2).toFixed(2))))}
            aria-label="تكبير"
            title="تكبير"
            className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-45 text-slate-700 dark:text-slate-200 flex items-center justify-center"
          >
            <ZoomIn className="w-4 h-4" />
          </TactileButton>

          {zoom !== 1 && (
            <TactileButton
              type="button"
              onClick={() => setZoom(1)}
              aria-label="إعادة ضبط التكبير"
              title="الحجم الافتراضي"
              className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </TactileButton>
          )}
        </div>
      </div>

      {/* Skeleton Document Placeholder + Compact Progress Bar while Page 1 prepares */}
      {(docLoading || !firstPageReady) && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 space-y-4">
          <div className="flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-300">
            <span>جاري تحضير الصفحة الأولى...</span>
            <span className="font-mono-num text-violet-600 dark:text-violet-400">
              {loadProgress}%
            </span>
          </div>
          <div className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-violet-600 to-blue-500 transition-all duration-150 rounded-full"
              style={{ width: `${loadProgress}%` }}
            />
          </div>

          {/* Animated Skeleton Document Sheet */}
          <div className="w-full max-w-lg mx-auto rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-800/50 p-5 space-y-3 animate-pulse">
            <div className="h-5 w-2/3 rounded-lg bg-slate-200 dark:bg-slate-700" />
            <div className="h-3.5 w-full rounded bg-slate-200 dark:bg-slate-700" />
            <div className="h-3.5 w-11/12 rounded bg-slate-200 dark:bg-slate-700" />
            <div className="h-3.5 w-4/5 rounded bg-slate-200 dark:bg-slate-700" />
            <div className="h-28 w-full rounded-xl bg-slate-200/80 dark:bg-slate-700/70 mt-2" />
            <div className="h-3.5 w-full rounded bg-slate-200 dark:bg-slate-700" />
            <div className="h-3.5 w-3/4 rounded bg-slate-200 dark:bg-slate-700" />
          </div>
        </div>
      )}

      {/* PDF Canvas Viewport */}
      <div
        ref={containerRef}
        className={`relative flex-1 min-h-[52vh] max-h-[65vh] overflow-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-200/70 dark:bg-slate-900 p-3 flex justify-center items-start ${
          docLoading || !firstPageReady ? 'hidden' : ''
        }`}
      >
        <div className="relative shadow-lg rounded-lg overflow-hidden bg-white">
          <canvas ref={canvasRef} className="block max-w-none" />
          {pageRendering && (
            <div className="absolute inset-0 bg-white/40 dark:bg-slate-900/40 pointer-events-none" />
          )}
        </div>
      </div>
    </div>
  );
}
