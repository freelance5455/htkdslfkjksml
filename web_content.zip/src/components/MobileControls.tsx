import React, { useRef, useState } from 'react';
import { GameEngine } from '../game/engine';
import { Backpack, Hammer, Tent, Sparkles, Sword, Shield, Zap, Hand, Utensils } from 'lucide-react';

interface MobileControlsProps {
  engine: GameEngine;
  onOpenInventory: () => void;
  onOpenCrafting: () => void;
  onOpenBuilding: () => void;
  onOpenSkillTree: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  engine,
  onOpenInventory,
  onOpenCrafting,
  onOpenBuilding,
  onOpenSkillTree,
}) => {
  const joystickBaseRef = useRef<HTMLDivElement | null>(null);
  const [touching, setTouching] = useState(false);
  const [knobPos, setKnobPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const touchIdRef = useRef<number | null>(null);

  // Joystick touch handlers
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    touchIdRef.current = touch.identifier;
    setTouching(true);
    updateJoystick(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === touchIdRef.current) {
        updateJoystick(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchIdRef.current) {
        touchIdRef.current = null;
        setTouching(false);
        setKnobPos({ x: 0, y: 0 });
        engine.setPlayerVelocity(0, 0);
        break;
      }
    }
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    const base = joystickBaseRef.current;
    if (!base) return;

    const rect = base.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const dist = Math.hypot(dx, dy);
    const maxRadius = rect.width / 2;

    const clampedDist = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);

    const kx = Math.cos(angle) * clampedDist;
    const ky = Math.sin(angle) * clampedDist;

    setKnobPos({ x: kx, y: ky });

    // Normalized velocity
    const normDist = clampedDist / maxRadius;
    if (normDist > 0.15) {
      engine.setPlayerVelocity(Math.cos(angle) * normDist, Math.sin(angle) * normDist);
    } else {
      engine.setPlayerVelocity(0, 0);
    }
  };

  const p = engine.player;

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex justify-between items-end p-3 pb-5 sm:p-5 font-['Tajawal',sans-serif]">
      {/* Left: Virtual Joystick */}
      <div
        ref={joystickBaseRef}
        id="virtual-joystick"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-neutral-950/75 border-2 border-neutral-700/80 relative flex items-center justify-center pointer-events-auto touch-none shadow-2xl backdrop-blur-xs"
      >
        {/* Center Guide Ring */}
        <div className="w-9 h-9 rounded-full border border-neutral-600/50" />

        {/* Dynamic Knob */}
        <div
          className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 absolute transition-transform duration-75 shadow-lg flex items-center justify-center ${
            touching
              ? 'bg-amber-500/80 border-amber-300 scale-105'
              : 'bg-neutral-800/80 border-neutral-500'
          }`}
          style={{
            transform: `translate(${knobPos.x}px, ${knobPos.y}px)`,
          }}
        >
          <div className="w-4 h-4 rounded-full bg-neutral-300/40" />
        </div>
      </div>

      {/* Right: Mobile Action Buttons */}
      <div className="flex flex-col items-end gap-2 pointer-events-auto">
        {/* Top small menu triggers for mobile */}
        <div className="flex items-center gap-1.5 sm:hidden mb-1">
          <button
            id="mobile-btn-bag"
            onClick={onOpenInventory}
            className="w-9 h-9 rounded-full bg-neutral-900/90 border border-neutral-700 flex items-center justify-center text-amber-400 active:scale-90 transition shadow"
            title="الحقيبة"
          >
            <Backpack className="w-4 h-4" />
          </button>
          <button
            id="mobile-btn-craft"
            onClick={onOpenCrafting}
            className="w-9 h-9 rounded-full bg-neutral-900/90 border border-neutral-700 flex items-center justify-center text-cyan-400 active:scale-90 transition shadow"
            title="الصناعة"
          >
            <Hammer className="w-4 h-4" />
          </button>
          <button
            id="mobile-btn-build"
            onClick={onOpenBuilding}
            className="w-9 h-9 rounded-full bg-neutral-900/90 border border-neutral-700 flex items-center justify-center text-emerald-400 active:scale-90 transition shadow"
            title="البناء"
          >
            <Tent className="w-4 h-4" />
          </button>
          <button
            id="mobile-btn-skills"
            onClick={onOpenSkillTree}
            className={`w-9 h-9 rounded-full border flex items-center justify-center active:scale-90 transition shadow ${
              p.skillPoints > 0
                ? 'bg-amber-950 border-amber-400 text-amber-300 animate-pulse'
                : 'bg-neutral-900/90 border-neutral-700 text-purple-400'
            }`}
            title="شجرة المهارات"
          >
            <Sparkles className="w-4 h-4" />
          </button>
        </div>

        {/* Primary Gameplay Action Buttons */}
        <div className="flex flex-col gap-1.5 items-end">
          {/* Action cluster (Sprint, Dodge, Use, Interact) */}
          <div className="flex items-center gap-1.5">
            {/* Sprint / Run Button */}
            <button
              id="mobile-btn-sprint"
              onTouchStart={(e) => {
                e.preventDefault();
                engine.setSprinting(true);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                engine.setSprinting(false);
              }}
              onMouseDown={() => engine.setSprinting(true)}
              onMouseUp={() => engine.setSprinting(false)}
              className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full border-2 flex flex-col items-center justify-center transition shadow-lg select-none ${
                p.isRunning
                  ? 'bg-amber-500 border-amber-200 scale-105 text-neutral-950 font-black ring-2 ring-amber-400/50'
                  : 'bg-amber-950/80 border-amber-500 text-amber-200'
              }`}
              title="ركض سريع (SHIFT)"
            >
              <Zap className="w-3.5 h-3.5" />
              <span className="text-[8px] font-bold">ركض</span>
            </button>

            {/* Dodge / Roll Button */}
            <button
              id="mobile-btn-dodge"
              onClick={() => engine.dodge()}
              disabled={p.energy < 12 || p.dodgeCooldown > 0}
              className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full border-2 flex flex-col items-center justify-center transition shadow-lg select-none ${
                p.dodgeCooldown > 0
                  ? 'bg-neutral-900 border-neutral-700 text-neutral-600 opacity-60'
                  : 'bg-purple-950/85 active:scale-90 border-purple-400 text-purple-200'
              }`}
              title="مراوغة وتدحرج (SPACE)"
            >
              <Shield className="w-3.5 h-3.5" />
              <span className="text-[8px] font-bold">مراوغة</span>
            </button>

            {/* Use / Eat Food */}
            <button
              id="mobile-btn-use"
              onClick={() => engine.useCurrentItem()}
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-cyan-950/85 hover:bg-cyan-800 active:scale-90 border-2 border-cyan-400 text-cyan-200 font-bold flex flex-col items-center justify-center transition shadow-lg select-none"
              title="أكل أو استخدام العنصر"
            >
              <Utensils className="w-3.5 h-3.5" />
              <span className="text-[8px]">استخدام</span>
            </button>

            {/* Interact / Pickup / Door / Chest */}
            <button
              id="mobile-btn-interact"
              onClick={() => engine.interact()}
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-emerald-950/85 hover:bg-emerald-800 active:scale-90 border-2 border-emerald-400 text-emerald-200 font-bold flex flex-col items-center justify-center transition shadow-lg select-none"
              title="تفاعل أو جمع أو فتح (E)"
            >
              <Hand className="w-3.5 h-3.5" />
              <span className="text-[8px]">تفاعل</span>
            </button>
          </div>

          {/* Cancel Building Ghost if active */}
          {engine.activeBuildingGhost && (
            <button
              id="mobile-btn-cancel-build"
              onClick={() => {
                engine.activeBuildingGhost = null;
              }}
              className="w-full py-1.5 px-3 rounded-lg bg-red-950/80 border border-red-500 text-red-300 text-xs font-bold active:scale-95 transition text-center"
            >
              إلغاء وضع البناء ✕
            </button>
          )}

          {/* Primary Attack / Harvest Button */}
          <button
            id="mobile-btn-attack"
            onClick={() => engine.attack()}
            className="w-full h-12 sm:h-13 px-4 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 active:scale-95 border-2 border-amber-300 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-2xl select-none cursor-pointer"
          >
            <Sword className="w-4 h-4" />
            <span className="tracking-wide">هجوم / ضرب</span>
          </button>
        </div>
      </div>
    </div>
  );
};

