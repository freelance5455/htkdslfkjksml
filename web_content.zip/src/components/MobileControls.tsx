import { Direction } from '../game/types';

interface MobileControlsProps {
  onMove: (dir: Direction) => void;
}

interface PadButtonProps {
  dir: Direction;
  label: string;
  symbol: string;
  onMove: (dir: Direction) => void;
}

function PadButton({ dir, label, symbol, onMove }: PadButtonProps) {
  return (
    <button
      type="button"
      aria-label={`Move ${label}`}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onMove(dir);
      }}
      className="pixel-btn flex h-13 w-14 sm:h-14 sm:w-16 items-center justify-center bg-[#172b1e]/92 text-[#f4f7ec] cursor-pointer touch-manipulation select-none active:bg-[#2d6a4f] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
    >
      <span className="font-pixel-display text-xl sm:text-2xl leading-none text-[#fef08a] drop-shadow-[0_2px_0_#09130c]">
        {symbol}
      </span>
    </button>
  );
}

export function MobileControls({ onMove }: MobileControlsProps) {
  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-3 sm:bottom-5 z-10 flex justify-center px-4"
      aria-label="Directional controls"
    >
      <div className="pointer-events-auto grid grid-cols-3 gap-2">
        <div />
        <PadButton dir="UP" label="up" symbol="↑" onMove={onMove} />
        <div />
        <PadButton dir="LEFT" label="left" symbol="←" onMove={onMove} />
        <PadButton dir="DOWN" label="down" symbol="↓" onMove={onMove} />
        <PadButton dir="RIGHT" label="right" symbol="→" onMove={onMove} />
      </div>
    </div>
  );
}
