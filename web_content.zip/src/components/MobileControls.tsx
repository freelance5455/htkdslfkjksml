import React, { useRef, useState } from 'react';
import {
  Crosshair,
  Flashlight,
  Hand,
  RotateCw,
  Shield,
  Target,
} from 'lucide-react';
import { GameHudState } from '../game/types';

interface MobileControlsProps {
  hud: GameHudState;
  onMove: (x: number, y: number, sprint: boolean) => void;
  onLook: (dx: number, dy: number) => void;
  onFire: () => void;
  onToggleAim: () => void;
  onReload: () => void;
  onInteract: () => void;
  onToggleFlashlight: () => void;
  onToggleCrouch: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  hud,
  onMove,
  onLook,
  onFire,
  onToggleAim,
  onReload,
  onInteract,
  onToggleFlashlight,
  onToggleCrouch,
}) => {
  // Left joystick tracking
  const stickRef = useRef<HTMLDivElement | null>(null);
  const stickPointerId = useRef<number | null>(null);
  const [puckOffset, setPuckOffset] = useState({ x: 0, y: 0 });
  const [isSprintDrag, setIsSprintDrag] = useState(false);

  // Right-half touch look tracking
  const lookPointerId = useRef<number | null>(null);
  const lastLookPos = useRef({ x: 0, y: 0 });

  if (hud.phase !== 'playing') return null;

  const maxRadius = 42;

  const updateStickFromPointer = (clientX: number, clientY: number) => {
    const el = stickRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setPuckOffset({ x: dx, y: dy });

    const normX = dx / maxRadius;
    const normY = -dy / maxRadius; // Up on screen = +forward
    const sprinting = dist > maxRadius * 0.82 && normY > 0.45;
    setIsSprintDrag(sprinting);
    onMove(normX, normY, sprinting);
  };

  const resetStick = () => {
    stickPointerId.current = null;
    setPuckOffset({ x: 0, y: 0 });
    setIsSprintDrag(false);
    onMove(0, 0, false);
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-15 touch-none select-none">
      {/* Right-Side Open Viewport Touch-Look Pad */}
      <div
        className="pointer-events-auto absolute top-14 right-0 bottom-44 left-1/3 touch-none"
        onPointerDown={(e) => {
          if (lookPointerId.current !== null) return;
          lookPointerId.current = e.pointerId;
          lastLookPos.current = { x: e.clientX, y: e.clientY };
          e.currentTarget.setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (lookPointerId.current !== e.pointerId) return;
          const dx = e.clientX - lastLookPos.current.x;
          const dy = e.clientY - lastLookPos.current.y;
          lastLookPos.current = { x: e.clientX, y: e.clientY };
          onLook(dx, dy);
        }}
        onPointerUp={(e) => {
          if (lookPointerId.current === e.pointerId) {
            lookPointerId.current = null;
          }
        }}
        onPointerCancel={(e) => {
          if (lookPointerId.current === e.pointerId) {
            lookPointerId.current = null;
          }
        }}
      />

      {/* Left Thumb Analog Movement Stick */}
      <div
        ref={stickRef}
        onPointerDown={(e) => {
          e.stopPropagation();
          stickPointerId.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          updateStickFromPointer(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (stickPointerId.current !== e.pointerId) return;
          updateStickFromPointer(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (stickPointerId.current === e.pointerId) {
            resetStick();
          }
        }}
        onPointerCancel={(e) => {
          if (stickPointerId.current === e.pointerId) {
            resetStick();
          }
        }}
        className={`pointer-events-auto absolute bottom-8 left-5 flex h-28 w-28 items-center justify-center rounded-full border-2 transition-colors ${
          isSprintDrag
            ? 'border-amber-400/80 bg-zinc-950/65'
            : 'border-zinc-400/35 bg-zinc-950/55'
        }`}
      >
        <div
          style={{
            transform: `translate3d(${puckOffset.x}px, ${puckOffset.y}px, 0)`,
          }}
          className={`flex h-12 w-12 items-center justify-center rounded-full border shadow-lg ${
            isSprintDrag
              ? 'border-amber-300 bg-amber-500/80 text-zinc-950'
              : 'border-zinc-300/60 bg-zinc-800/85 text-zinc-100'
          }`}
        >
          <span className="font-mono-tech text-[10px] font-bold tracking-wider">
            {isSprintDrag ? 'RUN' : 'MOVE'}
          </span>
        </div>
      </div>

      {/* Right Thumb Action Cluster (>= 48x48px touch targets) */}
      <div className="pointer-events-auto absolute right-4 bottom-8 flex flex-col items-end gap-2.5">
        {/* Contextual Interact Trigger when near field terminal or extraction LZ */}
        {hud.nearbyPrompt && (
          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onInteract();
            }}
            className="flex min-h-[48px] items-center gap-2 rounded border border-cyan-400 bg-cyan-950/90 px-4 py-2 text-xs font-semibold text-cyan-200 shadow-lg active:scale-95"
          >
            <Hand className="h-4 w-4" />
            <span>Interact</span>
          </button>
        )}

        {/* Secondary Utility Row: Light, Crouch, Reload, Aim */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onToggleFlashlight();
            }}
            aria-label="Toggle Flashlight"
            className={`flex h-12 w-12 items-center justify-center rounded-full border transition-transform active:scale-95 ${
              hud.flashlightOn
                ? 'border-amber-400 bg-amber-500/25 text-amber-300'
                : 'border-zinc-600 bg-zinc-900/85 text-zinc-300'
            }`}
          >
            <Flashlight className="h-5 w-5" />
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onToggleCrouch();
            }}
            aria-label="Toggle Crouch"
            className={`flex h-12 w-12 items-center justify-center rounded-full border transition-transform active:scale-95 ${
              hud.isCrouching
                ? 'border-amber-400 bg-amber-500/25 text-amber-300'
                : 'border-zinc-600 bg-zinc-900/85 text-zinc-300'
            }`}
          >
            <Shield className="h-5 w-5" />
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onReload();
            }}
            aria-label="Reload Weapon"
            className="flex h-12 w-12 items-center justify-center rounded-full border border-zinc-600 bg-zinc-900/85 text-zinc-100 transition-transform active:scale-95"
          >
            <RotateCw className="h-5 w-5" />
          </button>
        </div>

        {/* Primary Combat Row: ADS Aim + Fire */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onToggleAim();
            }}
            aria-label="Aim Down Sights"
            className={`flex h-14 w-14 flex-col items-center justify-center rounded-full border transition-transform active:scale-95 ${
              hud.isAiming
                ? 'border-amber-400 bg-amber-500 text-zinc-950'
                : 'border-zinc-500 bg-zinc-900/85 text-zinc-100'
            }`}
          >
            <Target className="h-5 w-5" />
            <span className="font-mono-tech text-[9px] font-bold">AIM</span>
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onFire();
            }}
            aria-label="Fire Weapon"
            className="flex h-16 w-16 flex-col items-center justify-center rounded-full border-2 border-amber-400 bg-red-600/85 text-white shadow-xl transition-transform active:scale-90"
          >
            <Crosshair className="h-6 w-6" />
            <span className="font-mono-tech text-[10px] font-bold">FIRE</span>
          </button>
        </div>
      </div>
    </div>
  );
};
