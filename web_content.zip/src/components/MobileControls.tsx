import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  CarFront,
  Crosshair,
  Flame,
  Hand,
  Megaphone,
  Zap,
} from 'lucide-react';
import { CarControlMode, HudSnapshot } from '../types/game';

interface MobileControlsProps {
  hud: HudSnapshot;
  carControlMode: CarControlMode;
  onChangeCarControlMode: (mode: CarControlMode) => void;
  onJoystick: (x: number, y: number) => void;
  onSteer: (steer: number) => void;
  onPedals: (gas: number, brake: number) => void;
  onHandbrake: (active: boolean) => void;
  onBoost: (active: boolean) => void;
  onSprint: (active: boolean) => void;
  onJump: () => void;
  onEnterExit: () => void;
  onInteract: () => void;
  onHorn: () => void;
  onRecenterCamera: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  hud,
  carControlMode,
  onChangeCarControlMode,
  onJoystick,
  onSteer,
  onPedals,
  onHandbrake,
  onBoost,
  onSprint,
  onJump,
  onEnterExit,
  onInteract,
  onHorn,
  onRecenterCamera,
}) => {
  const padRef = useRef<HTMLDivElement | null>(null);
  const wheelRef = useRef<HTMLDivElement | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [wheelAngle, setWheelAngle] = useState(0);
  const [steerBtn, setSteerBtn] = useState<-1 | 0 | 1>(0);
  const [gasHeld, setGasHeld] = useState(false);
  const [brakeHeld, setBrakeHeld] = useState(false);
  const [driftHeld, setDriftHeld] = useState(false);
  const [boostHeld, setBoostHeld] = useState(false);
  const [sprintHeld, setSprintHeld] = useState(false);

  const activePointer = useRef<number | null>(null);
  const wheelPointer = useRef<number | null>(null);

  const updateStick = (clientX: number, clientY: number) => {
    const el = padRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.44;

    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    setKnob({ x: dx, y: dy });
    // Small deadzone for clean neutral stop
    const nx = Math.abs(dx / maxR) < 0.08 ? 0 : dx / maxR;
    const ny = Math.abs(-dy / maxR) < 0.08 ? 0 : -dy / maxR;
    onJoystick(nx, ny);
  };

  const resetStick = () => {
    activePointer.current = null;
    setKnob({ x: 0, y: 0 });
    onJoystick(0, 0);
  };

  const updateWheel = (clientX: number) => {
    const el = wheelRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const norm = Math.max(-1, Math.min(1, (clientX - cx) / (rect.width * 0.52)));
    setWheelAngle(norm * 75);
    onSteer(norm);
  };

  const resetWheel = () => {
    wheelPointer.current = null;
    setWheelAngle(0);
    onSteer(0);
  };

  const inCar = Boolean(hud.inVehicle);
  const modes: CarControlMode[] = ['buttons', 'wheel', 'joystick'];
  const nextControlMode = modes[(modes.indexOf(carControlMode) + 1) % modes.length];

  return (
    <div className="fixed inset-x-0 bottom-0 z-20 pointer-events-none flex items-end justify-between p-4 md:p-6">
      {/* LEFT THUMB AREA */}
      <div className="pointer-events-auto flex flex-col items-start gap-2 touch-none select-none">
        {inCar && (
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                onSteer(0);
                setSteerBtn(0);
                onJoystick(0, 0);
                onChangeCarControlMode(nextControlMode);
              }}
              className="px-2.5 py-1 rounded-md bg-slate-950/90 border border-slate-700 text-[10px] font-black uppercase tracking-wider text-amber-400 cursor-pointer"
            >
              Steer: {carControlMode === 'buttons' ? 'Arrows' : carControlMode === 'wheel' ? 'Wheel' : 'Stick'} ↻
            </button>
            <button
              type="button"
              onClick={onRecenterCamera}
              className="p-1.5 rounded-md bg-slate-950/90 border border-slate-700 text-sky-400 cursor-pointer"
              title="Center Camera Behind Car"
            >
              <Crosshair className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {inCar && carControlMode === 'buttons' ? (
          <div className="flex items-center gap-3">
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                e.currentTarget.setPointerCapture(e.pointerId);
                setSteerBtn(-1);
                onSteer(-1);
              }}
              onPointerUp={() => {
                setSteerBtn(0);
                onSteer(0);
              }}
              onPointerCancel={() => {
                setSteerBtn(0);
                onSteer(0);
              }}
              className={`w-18 h-18 md:w-20 md:h-20 rounded-2xl border-2 flex items-center justify-center shadow-lg cursor-pointer transition-colors ${
                steerBtn === -1
                  ? 'bg-amber-400 text-slate-950 border-white scale-95'
                  : 'bg-slate-900/90 border-slate-500 text-white'
              }`}
              aria-label="Steer Left"
            >
              <ArrowLeft className="w-8 h-8" />
            </button>
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                e.currentTarget.setPointerCapture(e.pointerId);
                setSteerBtn(1);
                onSteer(1);
              }}
              onPointerUp={() => {
                setSteerBtn(0);
                onSteer(0);
              }}
              onPointerCancel={() => {
                setSteerBtn(0);
                onSteer(0);
              }}
              className={`w-18 h-18 md:w-20 md:h-20 rounded-2xl border-2 flex items-center justify-center shadow-lg cursor-pointer transition-colors ${
                steerBtn === 1
                  ? 'bg-amber-400 text-slate-950 border-white scale-95'
                  : 'bg-slate-900/90 border-slate-500 text-white'
              }`}
              aria-label="Steer Right"
            >
              <ArrowRight className="w-8 h-8" />
            </button>
          </div>
        ) : inCar && carControlMode === 'wheel' ? (
          <div
            ref={wheelRef}
            onPointerDown={(e) => {
              e.stopPropagation();
              e.currentTarget.setPointerCapture(e.pointerId);
              wheelPointer.current = e.pointerId;
              updateWheel(e.clientX);
            }}
            onPointerMove={(e) => {
              if (wheelPointer.current === e.pointerId) {
                updateWheel(e.clientX);
              }
            }}
            onPointerUp={(e) => {
              if (wheelPointer.current === e.pointerId) resetWheel();
            }}
            onPointerCancel={resetWheel}
            style={{ transform: `rotate(${wheelAngle}deg)` }}
            className="w-30 h-30 md:w-34 md:h-34 rounded-full bg-slate-950/90 border-[7px] border-slate-400 flex items-center justify-center shadow-xl cursor-grab relative"
          >
            <div className="absolute top-0.5 w-3 h-2.5 bg-amber-400 rounded-sm" />
            <div className="w-full h-3 bg-slate-400 rounded-full relative flex items-center justify-center">
              <div className="w-9 h-9 rounded-full bg-amber-400 border-2 border-slate-950" />
            </div>
          </div>
        ) : (
          <div
            ref={padRef}
            onPointerDown={(e) => {
              e.stopPropagation();
              e.currentTarget.setPointerCapture(e.pointerId);
              activePointer.current = e.pointerId;
              updateStick(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => {
              if (activePointer.current === e.pointerId) {
                updateStick(e.clientX, e.clientY);
              }
            }}
            onPointerUp={(e) => {
              if (activePointer.current === e.pointerId) {
                resetStick();
              }
            }}
            onPointerCancel={resetStick}
            className="relative w-30 h-30 md:w-34 md:h-34 rounded-full bg-slate-950/80 border-2 border-slate-500/80 flex items-center justify-center shadow-lg"
          >
            <div className="w-12 h-12 rounded-full border border-slate-700/70" />
            <div
              className="absolute w-13 h-13 rounded-full bg-amber-400/95 border-2 border-white shadow-xl"
              style={{ transform: `translate(${knob.x}px, ${knob.y}px)` }}
            />
          </div>
        )}
      </div>

      {/* RIGHT THUMB AREA */}
      <div className="pointer-events-auto flex items-end gap-2 touch-none select-none mb-12 md:mb-14">
        {inCar ? (
          <div className="flex flex-col items-end gap-2">
            {/* Upper quick driving actions: Horn, Drift, Boost, Exit */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onHorn();
                }}
                className="w-11 h-11 rounded-full bg-slate-900/90 border border-slate-600 text-amber-400 flex items-center justify-center active:scale-90 cursor-pointer"
                title="Horn"
              >
                <Megaphone className="w-4 h-4" />
              </button>

              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setDriftHeld(true);
                  onHandbrake(true);
                }}
                onPointerUp={() => {
                  setDriftHeld(false);
                  onHandbrake(false);
                }}
                onPointerCancel={() => {
                  setDriftHeld(false);
                  onHandbrake(false);
                }}
                className={`px-3.5 h-11 rounded-full border font-black text-[11px] flex items-center justify-center cursor-pointer ${
                  driftHeld
                    ? 'bg-amber-300 border-white text-slate-950 scale-95'
                    : 'bg-amber-500/90 border-amber-200 text-slate-950'
                }`}
              >
                DRIFT
              </button>

              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setBoostHeld(true);
                  onBoost(true);
                }}
                onPointerUp={() => {
                  setBoostHeld(false);
                  onBoost(false);
                }}
                onPointerCancel={() => {
                  setBoostHeld(false);
                  onBoost(false);
                }}
                className={`px-3 h-11 rounded-full border font-black text-[11px] flex items-center gap-1 justify-center cursor-pointer ${
                  boostHeld
                    ? 'bg-sky-400 border-white text-slate-950 scale-95'
                    : 'bg-sky-600/90 border-sky-300 text-white'
                }`}
                title="Nitro Turbo Boost"
              >
                <Zap className="w-4 h-4" />
                <span>NITRO</span>
              </button>

              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onEnterExit();
                }}
                className="w-11 h-11 rounded-full bg-slate-900/90 border border-rose-500 text-rose-400 flex items-center justify-center active:scale-90 cursor-pointer"
                title="Exit Vehicle"
              >
                <CarFront className="w-4 h-4" />
              </button>
            </div>

            {/* Main Reverse/Brake & Gas Pedals */}
            <div className="flex items-end gap-2.5">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setBrakeHeld(true);
                  onPedals(0, 1);
                }}
                onPointerUp={() => {
                  setBrakeHeld(false);
                  onPedals(0, 0);
                }}
                onPointerCancel={() => {
                  setBrakeHeld(false);
                  onPedals(0, 0);
                }}
                className={`w-16 h-18 rounded-xl border-2 text-white font-black text-[11px] flex flex-col items-center justify-center cursor-pointer ${
                  brakeHeld
                    ? 'bg-rose-500 border-white scale-95'
                    : 'bg-rose-600/90 border-rose-300'
                }`}
              >
                <span>BRAKE</span>
                <span className="text-[9px] opacity-80">REV</span>
              </button>

              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setGasHeld(true);
                  onPedals(1, 0);
                }}
                onPointerUp={() => {
                  setGasHeld(false);
                  onPedals(0, 0);
                }}
                onPointerCancel={() => {
                  setGasHeld(false);
                  onPedals(0, 0);
                }}
                className={`w-18 h-22 rounded-xl border-2 text-white font-black text-xs flex flex-col items-center justify-center cursor-pointer ${
                  gasHeld
                    ? 'bg-emerald-500 border-white scale-95'
                    : 'bg-emerald-600/90 border-emerald-300'
                }`}
              >
                GAS
              </button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-end gap-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onRecenterCamera}
                className="w-10 h-10 rounded-full bg-slate-950/90 border border-slate-600 text-sky-400 flex items-center justify-center active:scale-90 cursor-pointer"
                title="Align Camera Behind Player"
              >
                <Crosshair className="w-4 h-4" />
              </button>

              {hud.nearbyPrompt?.kind === 'place' && (
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    onInteract();
                  }}
                  className="w-14 h-14 rounded-full bg-amber-400 border-2 border-white text-slate-950 font-black text-xs flex flex-col items-center justify-center active:scale-90 cursor-pointer"
                >
                  <Hand className="w-5 h-5" />
                  <span>USE</span>
                </button>
              )}

              {hud.nearbyPrompt?.kind === 'vehicle' && (
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    onEnterExit();
                  }}
                  className="w-14 h-14 rounded-full bg-sky-500 border-2 border-white text-white font-black text-xs flex flex-col items-center justify-center active:scale-90 cursor-pointer"
                >
                  <CarFront className="w-5 h-5" />
                  <span>RIDE</span>
                </button>
              )}
            </div>

            <div className="flex items-end gap-2.5">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  setSprintHeld(true);
                  onSprint(true);
                }}
                onPointerUp={() => {
                  setSprintHeld(false);
                  onSprint(false);
                }}
                onPointerCancel={() => {
                  setSprintHeld(false);
                  onSprint(false);
                }}
                className={`w-14 h-14 rounded-full border-2 font-bold text-[10px] flex flex-col items-center justify-center cursor-pointer ${
                  sprintHeld
                    ? 'bg-sky-400 text-slate-950 border-white scale-95'
                    : 'bg-slate-900/90 border-sky-400 text-sky-300'
                }`}
              >
                <Flame className="w-4 h-4" />
                <span>RUN</span>
              </button>

              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onJump();
                }}
                className="w-16 h-16 rounded-full bg-amber-400/95 border-2 border-white text-slate-950 font-black text-xs flex flex-col items-center justify-center active:scale-90 cursor-pointer"
              >
                <ArrowUp className="w-5 h-5" />
                <span>JUMP</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
