/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { Crosshair, RotateCcw, Shield, Target, Zap } from 'lucide-react';

interface MobileControlsProps {
  onMove: (x: number, y: number) => void;
  onLookDelta: (dx: number, dy: number) => void;
  onFire: () => void;
  onAimToggle: () => void;
  onReload: () => void;
  onRoll: () => void;
  onSwitchWeapon: () => void;
  isAutomatic: boolean;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onMove,
  onLookDelta,
  onFire,
  onAimToggle,
  onReload,
  onRoll,
  onSwitchWeapon,
  isAutomatic,
}) => {
  // Virtual Joystick state
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [stickPos, setStickPos] = useState({ x: 0, y: 0 });
  const [isStickActive, setIsStickActive] = useState(false);
  const stickTouchIdRef = useRef<number | null>(null);

  // Look zone state
  const lookTouchIdRef = useRef<number | null>(null);
  const lastLookPosRef = useRef<{ x: number; y: number } | null>(null);

  // Auto fire interval for automatic weapons
  const fireIntervalRef = useRef<number | null>(null);

  // Handle Joystick Touch
  const handleJoystickTouchStart = (e: React.TouchEvent) => {
    if (stickTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    stickTouchIdRef.current = touch.identifier;
    setIsStickActive(true);
    updateStickPos(touch.clientX, touch.clientY);
  };

  const handleJoystickTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === stickTouchIdRef.current) {
        updateStickPos(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleJoystickTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === stickTouchIdRef.current) {
        stickTouchIdRef.current = null;
        setIsStickActive(false);
        setStickPos({ x: 0, y: 0 });
        onMove(0, 0);
        break;
      }
    }
  };

  const updateStickPos = (clientX: number, clientY: number) => {
    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const distance = Math.hypot(dx, dy);
    const maxRadius = rect.width / 2;

    const clampedDist = Math.min(distance, maxRadius);
    const angle = Math.atan2(dy, dx);

    const stickX = Math.cos(angle) * clampedDist;
    const stickY = Math.sin(angle) * clampedDist;

    setStickPos({ x: stickX, y: stickY });

    // Normalized input (-1 to 1)
    const normX = stickX / maxRadius;
    const normY = stickY / maxRadius;
    onMove(normX, normY);
  };

  // Handle Right-Half Look Drag
  const handleLookTouchStart = (e: React.TouchEvent) => {
    if (lookTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    lookTouchIdRef.current = touch.identifier;
    lastLookPosRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleLookTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchIdRef.current && lastLookPosRef.current) {
        const dx = touch.clientX - lastLookPosRef.current.x;
        const dy = touch.clientY - lastLookPosRef.current.y;
        onLookDelta(dx, dy);
        lastLookPosRef.current = { x: touch.clientX, y: touch.clientY };
        break;
      }
    }
  };

  const handleLookTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchIdRef.current) {
        lookTouchIdRef.current = null;
        lastLookPosRef.current = null;
        break;
      }
    }
  };

  // Continuous fire on button hold
  const startFiring = () => {
    onFire();
    if (isAutomatic && !fireIntervalRef.current) {
      fireIntervalRef.current = window.setInterval(() => {
        onFire();
      }, 105);
    }
  };

  const stopFiring = () => {
    if (fireIntervalRef.current) {
      clearInterval(fireIntervalRef.current);
      fireIntervalRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      if (fireIntervalRef.current) {
        clearInterval(fireIntervalRef.current);
      }
    };
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden select-none">
      {/* Right-Screen Touch Look Zone (Full right-hand swipe area for aiming) */}
      <div
        className="absolute top-0 right-0 w-2/3 h-3/4 pointer-events-auto"
        onTouchStart={handleLookTouchStart}
        onTouchMove={handleLookTouchMove}
        onTouchEnd={handleLookTouchEnd}
        onTouchCancel={handleLookTouchEnd}
      />

      {/* Left Virtual Joystick Area */}
      <div className="absolute bottom-6 left-6 pointer-events-auto">
        <div
          ref={joystickBaseRef}
          className="relative w-32 h-32 rounded-full bg-slate-900/60 border-2 border-slate-700/80 shadow-2xl flex items-center justify-center touch-none"
          onTouchStart={handleJoystickTouchStart}
          onTouchMove={handleJoystickTouchMove}
          onTouchEnd={handleJoystickTouchEnd}
          onTouchCancel={handleJoystickTouchEnd}
        >
          {/* Inner Joystick Knob */}
          <div
            className={`w-14 h-14 rounded-full bg-gradient-to-tr from-slate-700 to-slate-500 border border-slate-400 shadow-md transition-transform duration-75 flex items-center justify-center ${
              isStickActive ? 'scale-105 brightness-125' : ''
            }`}
            style={{
              transform: `translate(${stickPos.x}px, ${stickPos.y}px)`,
            }}
          >
            <div className="w-4 h-4 rounded-full bg-cyan-400/80 shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
          </div>
        </div>
      </div>

      {/* Right Action Buttons Cluster */}
      <div className="absolute bottom-6 right-6 flex flex-col items-end gap-3 pointer-events-auto">
        {/* Secondary Actions Row: Reload, Roll, Aim */}
        <div className="flex items-center gap-3">
          {/* Weapon Swap */}
          <button
            onClick={onSwitchWeapon}
            className="w-12 h-12 rounded-full bg-slate-900/80 border border-slate-700 flex items-center justify-center text-cyan-400 active:scale-90 transition-transform shadow-lg"
            title="Switch Weapon"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          {/* Aim Down Sights (ADS) */}
          <button
            onClick={onAimToggle}
            className="w-12 h-12 rounded-full bg-slate-900/80 border border-slate-700 flex items-center justify-center text-amber-400 active:scale-90 transition-transform shadow-lg"
            title="Aim Zoom"
          >
            <Target className="w-5 h-5" />
          </button>

          {/* Tactical Roll / Dodge */}
          <button
            onClick={onRoll}
            className="w-12 h-12 rounded-full bg-slate-900/80 border border-slate-700 flex items-center justify-center text-emerald-400 active:scale-90 transition-transform shadow-lg"
            title="Dodge Roll"
          >
            <Zap className="w-5 h-5" />
          </button>

          {/* Reload Button */}
          <button
            onClick={onReload}
            className="w-12 h-12 rounded-full bg-slate-900/80 border border-slate-700 flex items-center justify-center text-white active:scale-90 transition-transform shadow-lg"
            title="Reload"
          >
            <span className="text-xs font-bold font-mono">RELOAD</span>
          </button>
        </div>

        {/* Primary Fire Button (Large thumb trigger) */}
        <button
          onTouchStart={startFiring}
          onTouchEnd={stopFiring}
          onTouchCancel={stopFiring}
          onMouseDown={startFiring}
          onMouseUp={stopFiring}
          className="w-20 h-20 rounded-full bg-gradient-to-tr from-red-700 via-red-600 to-rose-500 border-2 border-red-400 shadow-[0_0_25px_rgba(239,68,68,0.7)] flex items-center justify-center text-white active:scale-90 active:brightness-125 transition-all select-none cursor-pointer"
          title="Fire Weapon"
        >
          <Crosshair className="w-9 h-9 drop-shadow" />
        </button>
      </div>
    </div>
  );
};
