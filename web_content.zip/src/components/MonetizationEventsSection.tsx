import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import type { ApkBuildConfig, BillingProduct } from '../types/apk';

interface MonetizationEventsSectionProps {
  config: ApkBuildConfig;
  onChange: (patch: Partial<ApkBuildConfig>) => void;
}

export function MonetizationEventsSection({
  config,
  onChange,
}: MonetizationEventsSectionProps) {
  const [newSku, setNewSku] = useState('');
  const [newSkuLabel, setNewSkuLabel] = useState('');
  const [newSkuPrice, setNewSkuPrice] = useState('$1.99');
  const [newSkuType, setNewSkuType] =
    useState<BillingProduct['type']>('consumable');
  const [newCurrencyAmount, setNewCurrencyAmount] = useState(500);
  const [newEventName, setNewEventName] = useState('');

  const handleAddProduct = () => {
    const cleanSku = newSku.trim().toLowerCase().replace(/[^a-z0-9_.]/g, '_');
    if (!cleanSku) return;
    if (config.billingProducts.some((p) => p.sku === cleanSku)) return;
    const item: BillingProduct = {
      sku: cleanSku,
      type: newSkuType,
      label: newSkuLabel.trim() || cleanSku,
      priceDisplay: newSkuPrice.trim() || '$0.99',
      currencyAmount:
        newSkuType === 'consumable' ? Math.max(1, newCurrencyAmount) : undefined,
    };
    onChange({ billingProducts: [...config.billingProducts, item] });
    setNewSku('');
    setNewSkuLabel('');
  };

  const handlePresetPack = (preset: BillingProduct) => {
    if (config.billingProducts.some((p) => p.sku === preset.sku)) return;
    onChange({
      enablePlayBilling: true,
      billingProducts: [...config.billingProducts, preset],
    });
  };

  const handleRemoveProduct = (sku: string) => {
    onChange({
      billingProducts: config.billingProducts.filter((p) => p.sku !== sku),
    });
  };

  const handleAddLaunchEvent = () => {
    const clean = newEventName.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_');
    if (!clean || config.customLaunchEvents.includes(clean)) return;
    onChange({ customLaunchEvents: [...config.customLaunchEvents, clean] });
    setNewEventName('');
  };

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 text-xs text-slate-600 space-y-1.5 leading-relaxed">
        <div className="font-semibold text-slate-900">
          Storefront, Remove Ads & Native Bridge
        </div>
        <p>
          Configure non-consumable unlocks (like <strong>Remove Ads</strong>), repeatable <strong>Game Currency / Credit Packs</strong> (auto-consumed via <code className="font-mono">consumeAsync</code>), subscriptions, AdMob ads, and cold-start launch events.
        </p>
      </div>

      {/* 1. Pay to Remove Ads */}
      <div className="border border-slate-200 rounded-xl divide-y divide-slate-200">
        <label className="p-4 flex items-start justify-between gap-4 cursor-pointer">
          <div>
            <div className="text-sm font-display font-semibold text-slate-900">
              Pay to Remove Ads Entitlement
            </div>
            <div className="text-xs text-slate-500 mt-0.5">
              Persists <code className="font-mono">ads_removed</code> in Android <code className="font-mono">SharedPreferences</code>, hides AdMob banners/interstitials upon purchase, and exposes <code className="font-mono">window.AndroidNative.removeAds()</code>.
            </div>
          </div>
          <input
            type="checkbox"
            checked={config.enableRemoveAds}
            onChange={(e) =>
              onChange({
                enableRemoveAds: e.target.checked,
                enablePlayBilling: e.target.checked ? true : config.enablePlayBilling,
              })
            }
            className="mt-1 h-4 w-4 accent-emerald-600 rounded border-slate-300 shrink-0"
          />
        </label>

        {config.enableRemoveAds && (
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Remove Ads Product SKU
              </label>
              <input
                type="text"
                value={config.removeAdsSku}
                onChange={(e) => onChange({ removeAdsSku: e.target.value })}
                placeholder="remove_ads_lifetime"
                className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Display Price Label
              </label>
              <input
                type="text"
                value={config.removeAdsPrice}
                onChange={(e) => onChange({ removeAdsPrice: e.target.value })}
                placeholder="$2.99"
                className="w-full px-3 py-1.5 text-xs font-mono tabular-nums bg-white border border-slate-200 rounded-lg text-slate-900"
              />
            </div>
          </div>
        )}
      </div>

      {/* 2. Products & Game Currency Catalog */}
      <div className="border border-slate-200 rounded-xl divide-y divide-slate-200">
        <label className="p-4 flex items-start justify-between gap-4 cursor-pointer">
          <div>
            <div className="text-sm font-display font-semibold text-slate-900">
              In-App Storefront, Products & Game Currency (Play Billing)
            </div>
            <div className="text-xs text-slate-500 mt-0.5">
              Adds <code className="font-mono">com.android.vending.BILLING</code> and handles both one-time unlocks and repeatable currency packs via <code className="font-mono">window.AndroidNative.purchase(sku, type)</code>.
            </div>
          </div>
          <input
            type="checkbox"
            checked={config.enablePlayBilling}
            onChange={(e) => onChange({ enablePlayBilling: e.target.checked })}
            className="mt-1 h-4 w-4 accent-emerald-600 rounded border-slate-300 shrink-0"
          />
        </label>

        {config.enablePlayBilling && (
          <div className="p-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <label className="text-xs font-medium text-slate-700">
                  Currency Name:
                </label>
                <input
                  type="text"
                  value={config.currencyName}
                  onChange={(e) => onChange({ currencyName: e.target.value })}
                  placeholder="Coins"
                  className="w-28 px-2.5 py-1 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    handlePresetPack({
                      sku: 'coins_500',
                      type: 'consumable',
                      label: `500 ${config.currencyName || 'Coins'}`,
                      priceDisplay: '$0.99',
                      currencyAmount: 500,
                    })
                  }
                  className="px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200/70 transition-colors"
                >
                  + 500 {config.currencyName || 'Coins'}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    handlePresetPack({
                      sku: 'coins_2500',
                      type: 'consumable',
                      label: `2,500 ${config.currencyName || 'Coins'}`,
                      priceDisplay: '$3.99',
                      currencyAmount: 2500,
                    })
                  }
                  className="px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200/70 transition-colors"
                >
                  + 2,500 {config.currencyName || 'Coins'}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    handlePresetPack({
                      sku: 'vip_monthly',
                      type: 'subs',
                      label: 'VIP Monthly Pass',
                      priceDisplay: '$4.99/mo',
                    })
                  }
                  className="px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200/70 transition-colors"
                >
                  + VIP Sub
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
              <input
                type="text"
                value={newSku}
                onChange={(e) => setNewSku(e.target.value)}
                placeholder="SKU (e.g. gems_1000)"
                className="px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
              />
              <input
                type="text"
                value={newSkuLabel}
                onChange={(e) => setNewSkuLabel(e.target.value)}
                placeholder="Product title"
                className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900"
              />
              <input
                type="text"
                value={newSkuPrice}
                onChange={(e) => setNewSkuPrice(e.target.value)}
                placeholder="$1.99"
                className="px-2.5 py-1.5 text-xs font-mono tabular-nums bg-white border border-slate-200 rounded-lg text-slate-900"
              />
              <select
                value={newSkuType}
                onChange={(e) =>
                  setNewSkuType(e.target.value as BillingProduct['type'])
                }
                className="px-2 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900"
              >
                <option value="consumable">Game Currency</option>
                <option value="inapp">One-time Product</option>
                <option value="subs">Subscription</option>
              </select>
              <button
                type="button"
                onClick={handleAddProduct}
                className="inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Item
              </button>
            </div>

            {newSkuType === 'consumable' && (
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <label htmlFor="currency-amount-input">
                  Currency quantity granted on purchase:
                </label>
                <input
                  id="currency-amount-input"
                  type="number"
                  min={1}
                  value={newCurrencyAmount}
                  onChange={(e) =>
                    setNewCurrencyAmount(
                      Math.max(1, parseInt(e.target.value || '100', 10))
                    )
                  }
                  className="w-24 px-2 py-1 text-xs font-mono tabular-nums bg-white border border-slate-200 rounded-md"
                />
              </div>
            )}

            {config.billingProducts.length > 0 && (
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                {config.billingProducts.map((prod) => (
                  <div
                    key={prod.sku}
                    className="px-3 py-2 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="min-w-0 truncate">
                      <span className="font-mono font-medium text-slate-900">
                        {prod.sku}
                      </span>
                      <span className="text-slate-500 ml-2">
                        · {prod.label} · {prod.priceDisplay} ·{' '}
                        {prod.type === 'consumable'
                          ? `Currency (${prod.currencyAmount ?? 0})`
                          : prod.type === 'subs'
                            ? 'Subscription'
                            : 'One-time'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveProduct(prod.sku)}
                      className="text-slate-400 hover:text-red-600 transition-colors shrink-0"
                      title={`Remove ${prod.sku}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. Paid Ads (Google AdMob) */}
      <div className="border border-slate-200 rounded-xl divide-y divide-slate-200">
        <label className="p-4 flex items-start justify-between gap-4 cursor-pointer">
          <div>
            <div className="text-sm font-display font-semibold text-slate-900">
              Paid Ads (Google AdMob Native SDK)
            </div>
            <div className="text-xs text-slate-500 mt-0.5">
              Adds AdMob App ID metadata, <code className="font-mono">AD_ID</code> permission, anchored banner layout, and interstitial/rewarded triggers.
            </div>
          </div>
          <input
            type="checkbox"
            checked={config.enableAdMob}
            onChange={(e) => onChange({ enableAdMob: e.target.checked })}
            className="mt-1 h-4 w-4 accent-emerald-600 rounded border-slate-300 shrink-0"
          />
        </label>

        {config.enableAdMob && (
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  AdMob Application ID
                </label>
                <input
                  type="text"
                  value={config.adMobAppId}
                  onChange={(e) => onChange({ adMobAppId: e.target.value })}
                  placeholder="ca-app-pub-3940256099942544~3347511713"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Banner Ad Unit ID
                </label>
                <input
                  type="text"
                  value={config.adMobBannerUnitId}
                  onChange={(e) =>
                    onChange({ adMobBannerUnitId: e.target.value })
                  }
                  placeholder="ca-app-pub-3940256099942544/6300978111"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Interstitial Ad Unit ID
                </label>
                <input
                  type="text"
                  value={config.adMobInterstitialUnitId}
                  onChange={(e) =>
                    onChange({ adMobInterstitialUnitId: e.target.value })
                  }
                  placeholder="ca-app-pub-3940256099942544/1033173712"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Rewarded Ad Unit ID
                </label>
                <input
                  type="text"
                  value={config.adMobRewardedUnitId}
                  onChange={(e) =>
                    onChange({ adMobRewardedUnitId: e.target.value })
                  }
                  placeholder="ca-app-pub-3940256099942544/5224354917"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
                />
              </div>
            </div>

            <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={config.showBottomBanner}
                onChange={(e) =>
                  onChange({ showBottomBanner: e.target.checked })
                }
                className="h-4 w-4 accent-emerald-600 rounded border-slate-300"
              />
              Display persistent anchored banner ad below WebView (reflected in Device Preview)
            </label>
          </div>
        )}
      </div>

      {/* 4. Launch Events & Telemetry */}
      <div className="border border-slate-200 rounded-xl divide-y divide-slate-200">
        <label className="p-4 flex items-start justify-between gap-4 cursor-pointer">
          <div>
            <div className="text-sm font-display font-semibold text-slate-900">
              App Launch Events & Analytics Dispatch
            </div>
            <div className="text-xs text-slate-500 mt-0.5">
              Fires cold-start <code className="font-mono">android:launch</code> events into your web app, optional webhook endpoint, and Firebase Analytics.
            </div>
          </div>
          <input
            type="checkbox"
            checked={config.enableLaunchEvents}
            onChange={(e) =>
              onChange({ enableLaunchEvents: e.target.checked })
            }
            className="mt-1 h-4 w-4 accent-emerald-600 rounded border-slate-300 shrink-0"
          />
        </label>

        {config.enableLaunchEvents && (
          <div className="p-4 space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Launch Telemetry Webhook URL (Optional)
              </label>
              <input
                type="url"
                value={config.launchWebhookUrl}
                onChange={(e) =>
                  onChange({ launchWebhookUrl: e.target.value })
                }
                placeholder="https://api.yourdomain.com/events/android-launch"
                className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
              />
            </div>

            <label className="flex items-center gap-2.5 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={config.enableFirebaseAnalytics}
                onChange={(e) =>
                  onChange({ enableFirebaseAnalytics: e.target.checked })
                }
                className="h-4 w-4 accent-emerald-600 rounded border-slate-300"
              />
              Include Firebase Analytics SDK in Gradle export
            </label>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Dispatched Launch Event Names
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={newEventName}
                  onChange={(e) => setNewEventName(e.target.value)}
                  placeholder="e.g. onboarding_ready"
                  className="flex-1 px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg text-slate-900"
                />
                <button
                  type="button"
                  onClick={handleAddLaunchEvent}
                  className="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap"
                >
                  Add Event
                </button>
              </div>
              <div className="text-xs font-mono text-slate-600 flex flex-wrap items-center gap-x-3 gap-y-1">
                {config.customLaunchEvents.map((ev) => (
                  <span key={ev} className="inline-flex items-center gap-1">
                    {ev}
                    {config.customLaunchEvents.length > 1 && (
                      <button
                        type="button"
                        onClick={() =>
                          onChange({
                            customLaunchEvents:
                              config.customLaunchEvents.filter((x) => x !== ev),
                          })
                        }
                        className="text-slate-400 hover:text-red-600"
                        title={`Remove ${ev}`}
                      >
                        ×
                      </button>
                    )}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
