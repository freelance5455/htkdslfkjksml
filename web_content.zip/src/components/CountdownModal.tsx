import React, { useEffect, useState } from 'react';
import { ShieldCheck, Zap, Server, Activity, Lock, Sparkles, Check } from 'lucide-react';

interface CountdownModalProps {
  username: string;
  followersCount: number;
  onComplete: () => void;
}

const STATUS_STEPS: { [key: number]: string } = {
  10: 'Connecting to Instagram secure API gateway...',
  9: 'Validating target profile @{user}...',
  8: 'Verifying profile eligibility & status...',
  7: 'Allocating high-retention follower node pool...',
  6: 'Encrypting data payload with 256-bit SSL...',
  5: 'Preparing follower delivery batch queue...',
  4: 'Calibrating safe-velocity anti-ban protocol...',
  3: 'Establishing live Instagram delivery tunnel...',
  2: 'Synchronizing record with cloud database...',
  1: 'Finalizing order verification...',
  0: 'Dispatching growth request!',
};

export const CountdownModal: React.FC<CountdownModalProps> = ({
  username,
  followersCount,
  onComplete,
}) => {
  const [secondsLeft, setSecondsLeft] = useState<number>(10);

  useEffect(() => {
    if (secondsLeft <= 0) {
      const timer = setTimeout(() => {
        onComplete();
      }, 500);
      return () => clearTimeout(timer);
    }

    const interval = setInterval(() => {
      setSecondsLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [secondsLeft, onComplete]);

  // Circle stroke offset calculation
  const totalSeconds = 10;
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - ((10 - secondsLeft) / totalSeconds) * circumference;

  const currentStatus = (STATUS_STEPS[secondsLeft] || STATUS_STEPS[1]).replace('{user}', username);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="relative w-full max-w-md rounded-3xl bg-slate-900/95 border border-purple-500/40 p-8 shadow-2xl shadow-purple-950/90 text-center overflow-hidden">
        {/* Ambient background glows */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-pink-500/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />

        {/* Top badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-200 text-xs font-semibold mb-6">
          <Activity className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
          <span>Processing Follower Transmission</span>
        </div>

        {/* Circular Countdown Progress */}
        <div className="relative w-44 h-44 mx-auto mb-6 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
            {/* Background circle */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              stroke="rgba(147, 51, 234, 0.2)"
              strokeWidth="10"
              fill="transparent"
            />
            {/* Animated progress circle */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              stroke="url(#gradient)"
              strokeWidth="10"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-all duration-1000 ease-linear"
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ec4899" />
                <stop offset="50%" stopColor="#a855f7" />
                <stop offset="100%" stopColor="#6366f1" />
              </linearGradient>
            </defs>
          </svg>

          {/* Number Display inside circle */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span
              key={secondsLeft}
              className="text-6xl font-black tracking-tight bg-gradient-to-br from-white via-purple-100 to-pink-300 bg-clip-text text-transparent animate-in zoom-in-75 duration-300 font-mono"
            >
              {secondsLeft}
            </span>
            <span className="text-[11px] font-semibold text-purple-300/80 uppercase tracking-wider mt-0.5">
              Seconds
            </span>
          </div>
        </div>

        {/* Target Details */}
        <div className="mb-4">
          <h4 className="text-base font-bold text-white flex items-center justify-center gap-1.5">
            <span>Allocating</span>
            <span className="text-pink-400 font-extrabold font-mono">
              +{followersCount.toLocaleString()}
            </span>
            <span>Followers</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5 font-mono">
            Target: <span className="text-slate-200 font-medium">@{username}</span>
          </p>
        </div>

        {/* Real-time status ticker box */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-purple-500/25 flex items-center gap-3 text-left">
          <div className="w-8 h-8 rounded-xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center shrink-0">
            <Server className="w-4 h-4 text-purple-400 animate-pulse" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
              <span className="font-mono text-purple-300">SYSTEM STATUS</span>
              <span className="font-mono text-emerald-400 font-bold">{100 - secondsLeft * 10}%</span>
            </div>
            <p className="text-xs font-medium text-slate-200 truncate">
              {currentStatus}
            </p>
          </div>
        </div>

        {/* Security assurance */}
        <div className="mt-4 flex items-center justify-center gap-4 text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <Lock className="w-3 h-3 text-emerald-400" />
            256-Bit SSL
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-purple-400" />
            Zero Risk
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Zap className="w-3 h-3 text-amber-400" />
            Direct Node
          </span>
        </div>
      </div>
    </div>
  );
};
