import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  HelpCircle,
  LogOut,
  MessageSquare,
  RotateCcw,
  RotateCw,
  Send,
  Trophy,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { canPlayCard, getCardFace } from '../shared/unoEngine';
import {
  COLOR_LABELS_ID,
  DARK_COLORS,
  LIGHT_COLORS,
  type ActiveColor,
  type PublicPlayer,
  type PublicRoomState,
  type Side,
  type UnoCardData,
} from '../shared/unoTypes';
import { PlayerAvatar } from './PlayerAvatar';
import { UnoCard, UnoCardBack } from './UnoCard';

interface GameTableProps {
  room: PublicRoomState;
  muted: boolean;
  onToggleMute: () => void;
  onOpenRules: () => void;
  onPlayCard: (cardId: string, chosenColor?: ActiveColor) => void;
  onChooseFlipColor: (color: ActiveColor) => void;
  onDrawCard: () => void;
  onPlayDrawnCard: (chosenColor?: ActiveColor) => void;
  onPassAfterDraw: () => void;
  onCallUno: () => void;
  onCatchUno: (targetId: string) => void;
  onSendEmote: (text: string) => void;
  onNextRound: () => void;
  onPlayAgain: () => void;
  onLeaveRoom: () => void;
}

const COLOR_HEX: Record<ActiveColor, string> = {
  red: '#DC2626',
  blue: '#2563EB',
  green: '#16A34A',
  yellow: '#EAB308',
  pink: '#DB2777',
  teal: '#0D9488',
  orange: '#EA580C',
  purple: '#7C3AED',
};

const QUICK_EMOTES = ['Mantap!', 'Awas +5!', 'FLIP!!', 'Ampun!', 'UNO nih!'];

export const GameTable: React.FC<GameTableProps> = ({
  room,
  muted,
  onToggleMute,
  onOpenRules,
  onPlayCard,
  onChooseFlipColor,
  onDrawCard,
  onPlayDrawnCard,
  onPassAfterDraw,
  onCallUno,
  onCatchUno,
  onSendEmote,
  onNextRound,
  onPlayAgain,
  onLeaveRoom,
}) => {
  const [wildTarget, setWildTarget] = useState<{
    mode: 'hand' | 'drawn' | 'flip';
    cardId?: string;
  } | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [chatText, setChatText] = useState('');
  const [flipBanner, setFlipBanner] = useState<Side | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const [handoffAckPlayerId, setHandoffAckPlayerId] = useState<string | null>(null);

  const prevSideRef = useRef<Side>(room.activeSide);
  const prevTurnPlayerIdRef = useRef<string | null>(null);

  const offlineHumanCount = useMemo(
    () => (room.code === 'OFFLINE' ? room.players.filter((p) => !p.isBot).length : 0),
    [room.code, room.players]
  );
  const isOfflinePassAndPlay = room.code === 'OFFLINE' && offlineHumanCount >= 2;

  useEffect(() => {
    if (prevSideRef.current !== room.activeSide) {
      prevSideRef.current = room.activeSide;
      setFlipBanner(room.activeSide);
      const t = setTimeout(() => setFlipBanner(null), 1300);
      return () => clearTimeout(t);
    }
  }, [room.activeSide]);

  // Trigger Pass & Play privacy handoff whenever turn moves to a human in offline multi-human mode
  useEffect(() => {
    if (!isOfflinePassAndPlay || room.phase !== 'PLAYING') {
      prevTurnPlayerIdRef.current = null;
      return;
    }
    const turnPlayer = room.players[room.currentTurnIndex];
    if (!turnPlayer) return;
    if (!turnPlayer.isBot && prevTurnPlayerIdRef.current !== turnPlayer.id) {
      setHandoffAckPlayerId(null);
    }
    prevTurnPlayerIdRef.current = turnPlayer.id;
  }, [isOfflinePassAndPlay, room.phase, room.currentTurnIndex, room.players]);

  // Countdown readout
  useEffect(() => {
    if (!room.turnDeadline || room.phase !== 'PLAYING') {
      setSecondsLeft(null);
      return;
    }
    const update = () => {
      const rem = Math.max(0, Math.ceil((room.turnDeadline! - Date.now()) / 1000));
      setSecondsLeft(rem);
    };
    update();
    const iv = setInterval(update, 250);
    return () => clearInterval(iv);
  }, [room.turnDeadline, room.phase]);

  // Open Wild picker if server asks this player to pick color after FLIP revealed a Wild
  useEffect(() => {
    if (room.pendingFlipColorPickerPlayerId === room.myId && room.phase === 'PLAYING') {
      setWildTarget({ mode: 'flip' });
    } else if (wildTarget?.mode === 'flip') {
      setWildTarget(null);
    }
  }, [room.pendingFlipColorPickerPlayerId, room.myId, room.phase]);

  const myIndex = room.players.findIndex((p) => p.id === room.myId);
  const me = myIndex >= 0 ? room.players[myIndex] : null;
  const currentTurnPlayer = room.players[room.currentTurnIndex] ?? null;
  const isMyTurn =
    room.phase === 'PLAYING' &&
    currentTurnPlayer?.id === room.myId &&
    !room.pendingFlipColorPickerPlayerId;
  const needsHandoffReveal =
    isOfflinePassAndPlay &&
    room.phase === 'PLAYING' &&
    currentTurnPlayer &&
    !currentTurnPlayer.isBot &&
    !room.pendingFlipColorPickerPlayerId &&
    !room.pendingDrawnCardId &&
    handoffAckPlayerId !== currentTurnPlayer.id;

  // Arrange opponents clockwise starting after me
  const opponents = useMemo(() => {
    if (myIndex < 0) return room.players;
    const list: PublicPlayer[] = [];
    for (let offset = 1; offset < room.players.length; offset++) {
      list.push(room.players[(myIndex + offset) % room.players.length]);
    }
    return list;
  }, [room.players, myIndex]);

  const pendingDrawnCard = useMemo(
    () => room.myHand.find((c) => c.id === room.pendingDrawnCardId) ?? null,
    [room.myHand, room.pendingDrawnCardId]
  );

  // Keyboard shortcuts: Space to draw, U to shout UNO
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        room.phase !== 'PLAYING' ||
        needsHandoffReveal
      ) {
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        if (isMyTurn && !room.pendingDrawnCardId && !wildTarget) {
          onDrawCard();
        }
      } else if (e.key.toLowerCase() === 'u') {
        if (room.myHand.length <= 2 && me && !me.calledUno) {
          onCallUno();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    room.phase,
    room.pendingDrawnCardId,
    room.myHand.length,
    isMyTurn,
    wildTarget,
    needsHandoffReveal,
    me,
    onDrawCard,
    onCallUno,
  ]);

  const handleCardClick = (card: UnoCardData) => {
    if (!isMyTurn) return;
    if (room.pendingDrawnCardId && room.pendingDrawnCardId !== card.id) return;
    if (!canPlayCard(card, room.topCard, room.activeColor, room.activeSide)) return;

    const face = getCardFace(card, room.activeSide);
    if (face.color === 'wild') {
      setWildTarget({
        mode: room.pendingDrawnCardId === card.id ? 'drawn' : 'hand',
        cardId: card.id,
      });
    } else {
      if (room.pendingDrawnCardId === card.id) {
        onPlayDrawnCard();
      } else {
        onPlayCard(card.id);
      }
    }
  };

  const handleWildSelect = (color: ActiveColor) => {
    if (!wildTarget) return;
    if (wildTarget.mode === 'flip') {
      onChooseFlipColor(color);
    } else if (wildTarget.mode === 'drawn') {
      onPlayDrawnCard(color);
    } else if (wildTarget.cardId) {
      onPlayCard(wildTarget.cardId, color);
    }
    setWildTarget(null);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = chatText.trim();
    if (!trimmed) return;
    onSendEmote(trimmed);
    setChatText('');
  };

  const isDarkSide = room.activeSide === 'dark';
  const sideColors = isDarkSide ? DARK_COLORS : LIGHT_COLORS;
  const activeHex = COLOR_HEX[room.activeColor];
  const myEmote = room.emotes.filter((e) => e.playerId === room.myId).slice(-1)[0];
  const showUnoButton = room.phase === 'PLAYING' && room.myHand.length <= 2 && me && !me.calledUno;

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-stone-950 flex flex-col justify-between select-none">
      {/* Dual-layer crossfading table felt background */}
      <div className="absolute inset-0 pointer-events-none">
        <img
          src="/src/assets/images/table_felt_light_1795173543278.jpg"
          alt="Meja Sisi Terang"
          referrerPolicy="no-referrer"
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
            isDarkSide ? 'opacity-0' : 'opacity-100'
          }`}
        />
        <img
          src="/src/assets/images/table_felt_dark_1795173543302.jpg"
          alt="Meja Sisi Gelap"
          referrerPolicy="no-referrer"
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
            isDarkSide ? 'opacity-100' : 'opacity-0'
          }`}
        />
        <div
          className={`absolute inset-0 transition-colors duration-500 ${
            isDarkSide ? 'bg-stone-950/35' : 'bg-stone-950/25'
          }`}
        />
      </div>

      {/* Non-blocking FLIP Transition Banner */}
      {flipBanner && (
        <div className="fixed inset-0 z-40 pointer-events-none flex items-center justify-center">
          <div
            className={`px-8 py-4 rounded-2xl border shadow-2xl transform transition-all duration-200 ${
              flipBanner === 'dark'
                ? 'bg-stone-950/95 border-pink-400/60 text-pink-200'
                : 'bg-emerald-950/95 border-amber-300/60 text-amber-200'
            }`}
          >
            <p className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-center">
              FLIP! {flipBanner === 'dark' ? 'Sisi Gelap Aktif' : 'Sisi Terang Aktif'}
            </p>
          </div>
        </div>
      )}

      {/* Perimeter Top HUD (low-occlusion, pointer-events-none wrapper) */}
      <header className="relative z-20 pointer-events-none flex items-start justify-between gap-3 px-4 sm:px-6 pt-3.5">
        <div className="pointer-events-auto rounded-xl bg-stone-950/75 border border-white/15 px-3.5 py-2 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs sm:text-sm text-stone-200 shadow-lg">
          <span className="font-display font-bold text-white">Ari Uno</span>
          <span className="text-stone-500" aria-hidden="true">·</span>
          <span className="font-mono-tabular text-amber-300 font-semibold">{room.code}</span>
          <span className="text-stone-500" aria-hidden="true">·</span>
          <span className={isDarkSide ? 'text-pink-300 font-semibold' : 'text-emerald-300 font-semibold'}>
            {isDarkSide ? 'Sisi Gelap' : 'Sisi Terang'}
          </span>
          <span className="text-stone-500 hidden sm:inline" aria-hidden="true">·</span>
          <span className="text-stone-300 hidden sm:inline font-mono-tabular">
            Ronde {room.roundNumber}
            {room.settings.targetScore > 0 ? ` / ${room.settings.targetScore} pt` : ''}
          </span>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={() => setDrawerOpen((v) => !v)}
            className="h-10 px-3 rounded-xl bg-stone-950/75 hover:bg-stone-900 border border-white/15 text-stone-200 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
            aria-label="Buka Log dan Obrolan"
          >
            <MessageSquare className="w-4 h-4 text-sky-300" />
            <span className="hidden sm:inline">Obrolan</span>
          </button>
          <button
            type="button"
            onClick={onOpenRules}
            className="w-10 h-10 rounded-xl bg-stone-950/75 hover:bg-stone-900 border border-white/15 text-stone-200 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Cara Main"
            title="Cara Main"
          >
            <HelpCircle className="w-4 h-4 text-amber-300" />
          </button>
          <button
            type="button"
            onClick={onToggleMute}
            className="w-10 h-10 rounded-xl bg-stone-950/75 hover:bg-stone-900 border border-white/15 text-stone-200 flex items-center justify-center transition-colors cursor-pointer"
            aria-label={muted ? 'Nyalakan suara' : 'Bisukan suara'}
            title={muted ? 'Nyalakan suara' : 'Bisukan suara'}
          >
            {muted ? <VolumeX className="w-4 h-4 text-stone-400" /> : <Volume2 className="w-4 h-4 text-emerald-300" />}
          </button>
          <button
            type="button"
            onClick={onLeaveRoom}
            className="h-10 px-3 rounded-xl bg-stone-950/75 hover:bg-rose-950/90 border border-white/15 text-stone-200 hover:text-rose-200 text-xs sm:text-sm font-medium flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
            aria-label="Keluar dari meja"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Keluar</span>
          </button>
        </div>
      </header>

      {/* Opponent Seats Row */}
      <section
        aria-label="Pemain Lawan"
        className="relative z-10 px-3 sm:px-6 pt-2 flex flex-wrap items-start justify-center gap-2.5 sm:gap-4"
      >
        {opponents.map((opp) => {
          const isTurn = currentTurnPlayer?.id === opp.id && room.phase === 'PLAYING';
          const oppEmote = room.emotes.filter((e) => e.playerId === opp.id).slice(-1)[0];
          const miniCards = Math.min(opp.cardCount, 5);

          return (
            <div
              key={opp.id}
              className={`relative rounded-xl px-3 py-2 border transition-all duration-200 min-w-[136px] sm:min-w-[164px] ${
                isTurn
                  ? 'bg-stone-900/95 border-amber-400 shadow-[0_0_20px_rgba(251,191,36,0.22)]'
                  : 'bg-stone-950/75 border-white/12'
              }`}
            >
              {/* Emote Bubble */}
              {oppEmote && (
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 z-30 whitespace-nowrap rounded-lg bg-amber-300 text-stone-950 px-2.5 py-1 text-xs font-bold shadow-lg pointer-events-none">
                  {oppEmote.text}
                </div>
              )}

              <div className="flex items-center gap-2.5">
                <PlayerAvatar avatar={opp.avatar} isBot={opp.isBot} size="sm" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1.5">
                    <p className="text-xs sm:text-sm font-semibold text-white truncate">
                      {opp.name}
                    </p>
                    {opp.calledUno && opp.cardCount === 1 && (
                      <span className="text-[10px] font-display font-extrabold text-amber-300 tracking-wide">
                        UNO!
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-stone-300 font-mono-tabular">
                    <span>{opp.cardCount} kartu</span>
                    <span className="text-stone-600" aria-hidden="true">·</span>
                    <span>{opp.score} pt</span>
                  </div>
                </div>
              </div>

              {/* Tiny opposite-side card fan */}
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <div className="flex items-center -space-x-3 h-7 pl-0.5">
                  {Array.from({ length: miniCards }).map((_, idx) => (
                    <UnoCardBack key={idx} side={room.activeSide} size="xs" />
                  ))}
                  {opp.cardCount > 5 && (
                    <span className="pl-4 text-[10px] font-mono-tabular text-stone-400">
                      +{opp.cardCount - 5}
                    </span>
                  )}
                </div>

                {opp.unoVulnerable && opp.cardCount === 1 && (
                  <button
                    type="button"
                    onClick={() => onCatchUno(opp.id)}
                    className="px-2 py-1 rounded-md bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold flex items-center gap-1 shadow cursor-pointer whitespace-nowrap"
                  >
                    <AlertTriangle className="w-3 h-3" />
                    <span>Tangkap!</span>
                  </button>
                )}
              </div>

              {/* Active turn timer indicator */}
              {isTurn && secondsLeft !== null && (
                <div className="mt-1.5 h-1 w-full rounded-full bg-stone-800 overflow-hidden">
                  <div
                    className="h-full bg-amber-400 transition-all duration-200"
                    style={{
                      width: `${Math.min(100, (secondsLeft / Math.max(1, room.settings.turnSeconds)) * 100)}%`,
                    }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </section>

      {/* Center Battle Zone (Draw Pile, Discard Pile, Active Color & Direction) */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4">
        {/* Last Event Headline */}
        <p className="mb-3 text-xs sm:text-sm font-medium text-stone-200 bg-stone-950/65 px-3.5 py-1.5 rounded-lg border border-white/10 text-center max-w-md truncate">
          {room.lastEventText}
        </p>

        <div className="relative flex items-center justify-center gap-6 sm:gap-12 py-4 px-6 sm:px-10 rounded-3xl border border-white/10 bg-stone-950/35">
          {/* Draw Pile */}
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              disabled={!isMyTurn || Boolean(room.pendingDrawnCardId)}
              onClick={onDrawCard}
              className={`relative group transition-transform duration-150 ${
                isMyTurn && !room.pendingDrawnCardId
                  ? 'cursor-pointer hover:-translate-y-1.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-xl'
                  : 'cursor-default opacity-85'
              }`}
              aria-label="Ambil 1 kartu dari tumpukan"
            >
              {/* Stacked deck shadow layers */}
              <div className="absolute top-1.5 left-1.5 w-full h-full rounded-xl bg-stone-900 border border-white/10" />
              <UnoCardBack side={room.activeSide} size="lg" className="relative" />
              {isMyTurn && !room.pendingDrawnCardId && (
                <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-md bg-amber-400 text-stone-950 text-[11px] font-bold shadow whitespace-nowrap">
                  Ambil Kartu
                </span>
              )}
            </button>
            <span className="text-xs font-mono-tabular text-stone-300 mt-1">
              Sisa {room.drawPileCount}
            </span>
          </div>

          {/* Center Color + Direction Readout */}
          <div className="flex flex-col items-center gap-2.5 min-w-[84px]">
            <div
              className="w-11 h-11 rounded-full border-2 border-white/80 shadow-lg flex items-center justify-center transition-colors duration-200"
              style={{ backgroundColor: activeHex }}
              title={`Warna aktif: ${COLOR_LABELS_ID[room.activeColor]}`}
            >
              {room.direction === 1 ? (
                <RotateCw className="w-5 h-5 text-white drop-shadow" />
              ) : (
                <RotateCcw className="w-5 h-5 text-white drop-shadow" />
              )}
            </div>
            <div className="text-center">
              <p className="text-xs font-bold text-white">
                {COLOR_LABELS_ID[room.activeColor]}
              </p>
              <p className="text-[11px] text-stone-300">
                {room.direction === 1 ? 'Searah' : 'Berbalik'}
              </p>
            </div>
          </div>

          {/* Discard Pile */}
          <div className="flex flex-col items-center gap-2">
            <div className="relative">
              {room.previousCard && (
                <div className="absolute inset-0 -rotate-6 opacity-65 pointer-events-none">
                  <UnoCard card={room.previousCard} activeSide={room.activeSide} size="lg" />
                </div>
              )}
              {room.topCard && (
                <div className="relative rotate-2 transition-transform duration-200">
                  <UnoCard card={room.topCard} activeSide={room.activeSide} size="lg" />
                </div>
              )}
            </div>
            <span className="text-xs text-stone-300 mt-1">Kartu Meja</span>
          </div>
        </div>

        {/* Turn Status & Draw-and-Play Prompt */}
        <div className="mt-3 min-h-[44px] flex items-center justify-center">
          {pendingDrawnCard ? (
            <div className="flex items-center gap-2.5 rounded-xl bg-stone-900/95 border border-amber-400/50 px-4 py-2 shadow-xl">
              <span className="text-xs sm:text-sm text-stone-200 font-medium">
                Kartu baru cocok!
              </span>
              <button
                type="button"
                onClick={() => handleCardClick(pendingDrawnCard)}
                className="h-9 px-3.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 text-xs sm:text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
              >
                Mainkan
              </button>
              <button
                type="button"
                onClick={onPassAfterDraw}
                className="h-9 px-3.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs sm:text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
              >
                Simpan &amp; Lewati
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs sm:text-sm font-medium">
              {isMyTurn ? (
                <span className="px-3.5 py-1.5 rounded-lg bg-amber-400 text-stone-950 font-bold shadow">
                  Giliran Kamu!{secondsLeft !== null ? ` (${secondsLeft}d)` : ''}
                </span>
              ) : (
                <span className="px-3.5 py-1.5 rounded-lg bg-stone-950/75 text-stone-300 border border-white/10">
                  Giliran {currentTurnPlayer?.name ?? '...'}
                  {secondsLeft !== null ? ` · ${secondsLeft}d` : ''}
                </span>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Player Hand & Bottom Controls */}
      <section className="relative z-20 px-3 sm:px-6 pb-3.5 pt-1 flex flex-col gap-2">
        {/* Action Bar: My Stats + Quick Emotes + UNO Button */}
        <div className="flex items-center justify-between gap-2 max-w-5xl w-full mx-auto">
          <div className="relative flex items-center gap-2.5 bg-stone-950/75 border border-white/12 rounded-xl px-3 py-1.5">
            {myEmote && (
              <div className="absolute -top-9 left-2 z-30 whitespace-nowrap rounded-lg bg-amber-300 text-stone-950 px-2.5 py-1 text-xs font-bold shadow-lg pointer-events-none">
                {myEmote.text}
              </div>
            )}
            {me && <PlayerAvatar avatar={me.avatar} size="sm" />}
            <div className="leading-tight">
              <p className="text-xs sm:text-sm font-semibold text-white">
                {me?.name ?? 'Kamu'}
              </p>
              <p className="text-[11px] text-stone-300 font-mono-tabular">
                {room.myHand.length} kartu · {me?.score ?? 0} pt
                {me?.calledUno && room.myHand.length === 1 ? ' · UNO!' : ''}
              </p>
            </div>
          </div>

          {/* Quick Emotes (desktop) */}
          <div className="hidden md:flex items-center gap-1.5">
            {QUICK_EMOTES.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => onSendEmote(q)}
                className="h-8 px-2.5 rounded-lg bg-stone-950/65 hover:bg-stone-800 border border-white/10 text-xs text-stone-200 transition-colors cursor-pointer whitespace-nowrap"
              >
                {q}
              </button>
            ))}
          </div>

          {/* UNO Shout Button */}
          <div className="flex items-center gap-2">
            {me?.unoVulnerable && room.myHand.length === 1 && (
              <button
                type="button"
                onClick={onCallUno}
                className="h-10 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-display font-extrabold text-sm shadow-lg cursor-pointer whitespace-nowrap animate-bounce"
              >
                TERIAK UNO!
              </button>
            )}
            {showUnoButton && !(me?.unoVulnerable && room.myHand.length === 1) && (
              <button
                type="button"
                onClick={onCallUno}
                className="h-10 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-display font-extrabold text-sm shadow-lg cursor-pointer whitespace-nowrap"
              >
                UNO! (U)
              </button>
            )}
          </div>
        </div>

        {/* Scrollable / Fanned Player Hand */}
        <div className="w-full max-w-6xl mx-auto">
          <div className="hand-scroll overflow-x-auto pt-4 pb-1 px-2 flex items-end justify-start sm:justify-center">
            <div className="flex items-end -space-x-3 sm:-space-x-2">
              {room.myHand.map((card) => {
                const legal =
                  isMyTurn &&
                  (!room.pendingDrawnCardId || room.pendingDrawnCardId === card.id) &&
                  canPlayCard(card, room.topCard, room.activeColor, room.activeSide);
                const dimmed = isMyTurn && !legal;

                return (
                  <UnoCard
                    key={card.id}
                    card={card}
                    activeSide={room.activeSide}
                    size="md"
                    playable={legal}
                    dimmed={dimmed}
                    selected={room.pendingDrawnCardId === card.id}
                    onClick={() => handleCardClick(card)}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Slide-Over Log & Chat Drawer */}
      {drawerOpen && (
        <aside className="fixed top-0 right-0 bottom-0 z-40 w-full max-w-xs bg-stone-950/95 border-l border-white/15 flex flex-col shadow-2xl">
          <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/10">
            <h2 className="font-display font-bold text-base text-white">Obrolan &amp; Riwayat</h2>
            <button
              type="button"
              onClick={() => setDrawerOpen(false)}
              className="w-9 h-9 rounded-lg flex items-center justify-center text-stone-400 hover:text-white hover:bg-white/10 cursor-pointer"
              aria-label="Tutup panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Emotes inside drawer for mobile */}
          <div className="p-3 border-b border-white/10 flex flex-wrap gap-1.5">
            {QUICK_EMOTES.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => onSendEmote(q)}
                className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-xs text-stone-200 cursor-pointer"
              >
                {q}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-2 text-xs">
            {room.actionLog.map((entry) => (
              <div
                key={entry.id}
                className={`rounded-lg px-3 py-2 border ${
                  entry.tone === 'flip'
                    ? 'bg-pink-950/50 border-pink-500/30 text-pink-200'
                    : entry.tone === 'uno'
                      ? 'bg-amber-950/50 border-amber-500/30 text-amber-200'
                      : entry.tone === 'penalty'
                        ? 'bg-rose-950/50 border-rose-500/30 text-rose-200'
                        : entry.tone === 'win'
                          ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-200'
                          : 'bg-stone-900 border-white/10 text-stone-300'
                }`}
              >
                {entry.text}
              </div>
            ))}
          </div>

          <form onSubmit={handleSendChat} className="p-3 border-t border-white/10 flex items-center gap-2">
            <input
              type="text"
              maxLength={60}
              value={chatText}
              onChange={(e) => setChatText(e.target.value)}
              placeholder="Kirim pesan singkat..."
              className="flex-1 h-10 px-3 rounded-lg bg-stone-900 border border-white/15 text-xs text-white placeholder:text-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <button
              type="submit"
              className="w-10 h-10 rounded-lg bg-amber-400 hover:bg-amber-300 text-stone-950 flex items-center justify-center cursor-pointer"
              aria-label="Kirim"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </aside>
      )}

      {/* Wild Color Picker Modal */}
      {wildTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Pilih warna aktif"
        >
          <div className="w-full max-w-sm rounded-2xl bg-stone-900 border border-white/15 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-white">
                Pilih Warna {isDarkSide ? 'Sisi Gelap' : 'Sisi Terang'}
              </h2>
              {wildTarget.mode !== 'flip' && (
                <button
                  type="button"
                  onClick={() => setWildTarget(null)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
                  aria-label="Batal"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              {sideColors.map((col) => (
                <button
                  key={col}
                  type="button"
                  onClick={() => handleWildSelect(col)}
                  className="h-16 rounded-xl font-display font-bold text-base text-white shadow-lg border-2 border-white/25 hover:scale-[1.03] transition-transform cursor-pointer flex items-center justify-center"
                  style={{ backgroundColor: COLOR_HEX[col] }}
                >
                  <span className={col === 'yellow' ? 'text-stone-950' : 'text-white'}>
                    {COLOR_LABELS_ID[col]}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Pass & Play Privacy Handoff Curtain (Offline Mabar 1 Perangkat) */}
      {needsHandoffReveal && currentTurnPlayer && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/95 p-6"
          role="dialog"
          aria-modal="true"
          aria-label={`Giliran ${currentTurnPlayer.name}`}
        >
          <div className="w-full max-w-sm rounded-2xl bg-stone-900 border border-white/15 p-6 sm:p-7 text-center shadow-2xl space-y-5">
            <div className="flex justify-center">
              <PlayerAvatar avatar={currentTurnPlayer.avatar} size="lg" />
            </div>
            <div className="space-y-1.5">
              <p className="text-xs font-medium text-amber-300">Mabar Offline · Giliran Berikutnya</p>
              <h2 className="font-display text-2xl font-extrabold text-white">
                Serahkan ke {currentTurnPlayer.name}
              </h2>
              <p className="text-xs sm:text-sm text-stone-300">
                Pastikan pemain lain tidak melihat layar sebelum kamu membuka kartumu.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setHandoffAckPlayerId(currentTurnPlayer.id)}
              className="w-full h-12 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-display font-bold text-base transition-colors cursor-pointer"
            >
              Buka Kartu {currentTurnPlayer.name}
            </button>
          </div>
        </div>
      )}

      {/* Round Over / Game Over Modal */}
      {(room.phase === 'ROUND_OVER' || room.phase === 'GAME_OVER') && room.roundSummary && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="summary-heading"
        >
          <div className="w-full max-w-lg rounded-2xl bg-stone-900 border border-white/15 p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-400/15 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <Trophy className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-medium text-amber-300">
                  {room.phase === 'GAME_OVER'
                    ? 'Pertandingan Selesai'
                    : `Ronde ${room.roundSummary.roundNumber} Selesai`}
                </p>
                <h2 id="summary-heading" className="font-display text-2xl font-extrabold text-white">
                  {room.roundSummary.winnerName} Menang!
                </h2>
              </div>
            </div>

            <p className="text-sm text-stone-300">
              Mendapat{' '}
              <span className="font-mono-tabular font-bold text-emerald-300">
                +{room.roundSummary.pointsEarned} poin
              </span>{' '}
              dari sisa kartu lawan di meja.
            </p>

            <div className="rounded-xl bg-stone-950/70 border border-white/10 divide-y divide-white/10">
              {room.roundSummary.playerBreakdowns.map((row, idx) => (
                <div
                  key={row.playerId}
                  className="flex items-center justify-between px-4 py-2.5 text-sm"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="font-mono-tabular text-xs text-stone-500 w-4">
                      {idx + 1}.
                    </span>
                    <span className="font-medium text-white truncate">{row.playerName}</span>
                    {row.remainingCards > 0 && (
                      <span className="text-xs text-stone-400 font-mono-tabular">
                        ({row.remainingCards} kartu)
                      </span>
                    )}
                  </div>
                  <span className="font-mono-tabular font-bold text-amber-300">
                    {row.totalScore} pt
                  </span>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3 pt-1">
              <button
                type="button"
                onClick={onLeaveRoom}
                className="h-11 px-4 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
              >
                Keluar ke Menu
              </button>
              {me?.isHost || room.code === 'OFFLINE' ? (
                room.phase === 'ROUND_OVER' ? (
                  <button
                    type="button"
                    onClick={onNextRound}
                    className="h-11 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-display font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Ronde Berikutnya
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onPlayAgain}
                    className="h-11 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-display font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Main Lagi
                  </button>
                )
              ) : (
                <p className="text-xs text-stone-400">
                  Menunggu Tuan Rumah melanjutkan...
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
