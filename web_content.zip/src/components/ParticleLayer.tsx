import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import confetti from 'canvas-confetti';
import { CellColor } from '../types/game';
import { COLOR_MAP } from '../constants/shapes';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
  rotation: number;
  rotationSpeed: number;
  shapeType: 'square' | 'circle' | 'spark';
}

export interface ParticleLayerHandle {
  burstCells: (cells: { x: number; y: number; color: CellColor }[]) => void;
  triggerConfetti: () => void;
  burstShockwave: (centerX: number, centerY: number, color?: string) => void;
}

export const ParticleLayer = forwardRef<ParticleLayerHandle, object>((_, ref) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const shockwavesRef = useRef<{ x: number; y: number; radius: number; maxRadius: number; color: string; alpha: number }[]>([]);

  useImperativeHandle(ref, () => ({
    burstCells: (cells) => {
      const newParticles: Particle[] = [];
      cells.forEach(({ x, y, color }) => {
        const hex = COLOR_MAP[color]?.primary || '#38bdf8';
        const count = 10;
        for (let i = 0; i < count; i++) {
          const angle = Math.random() * Math.PI * 2;
          const speed = Math.random() * 6 + 2;
          newParticles.push({
            x,
            y,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed - 1.5, // slight upward kick
            size: Math.random() * 6 + 3,
            color: hex,
            alpha: 1.0,
            decay: Math.random() * 0.025 + 0.02,
            rotation: Math.random() * Math.PI * 2,
            rotationSpeed: (Math.random() - 0.5) * 0.25,
            shapeType: Math.random() > 0.4 ? 'square' : 'circle',
          });
        }
      });
      particlesRef.current.push(...newParticles);
    },

    burstShockwave: (centerX, centerY, color = '#38bdf8') => {
      shockwavesRef.current.push({
        x: centerX,
        y: centerY,
        radius: 10,
        maxRadius: 180,
        color,
        alpha: 0.9,
      });
    },

    triggerConfetti: () => {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#06b6d4', '#3b82f6', '#a855f7', '#10b981', '#f59e0b', '#f43f5e'],
      });
    },
  }));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const resize = () => {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    const loop = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Render shockwaves
      const activeShockwaves = [];
      for (const sw of shockwavesRef.current) {
        sw.radius += 7;
        sw.alpha -= 0.035;
        if (sw.alpha > 0 && sw.radius < sw.maxRadius) {
          ctx.beginPath();
          ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
          ctx.strokeStyle = sw.color;
          ctx.lineWidth = 4 * sw.alpha;
          ctx.globalAlpha = sw.alpha;
          ctx.shadowColor = sw.color;
          ctx.shadowBlur = 15;
          ctx.stroke();
          activeShockwaves.push(sw);
        }
      }
      shockwavesRef.current = activeShockwaves;

      // Render particles
      const activeParticles: Particle[] = [];
      for (const p of particlesRef.current) {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.18; // gravity
        p.vx *= 0.98; // air drag
        p.alpha -= p.decay;
        p.rotation += p.rotationSpeed;

        if (p.alpha > 0) {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.fillStyle = p.color;
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 8;

          if (p.shapeType === 'square') {
            ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
          } else {
            ctx.beginPath();
            ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
            ctx.fill();
          }

          ctx.restore();
          activeParticles.push(p);
        }
      }
      particlesRef.current = activeParticles;

      ctx.globalAlpha = 1.0;
      ctx.shadowBlur = 0;

      animId = requestAnimationFrame(loop);
    };

    loop();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-30 w-full h-full"
    />
  );
});

ParticleLayer.displayName = 'ParticleLayer';
