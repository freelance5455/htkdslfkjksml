import { useCallback, useRef, useState } from "react";

interface JoystickProps {
  side: "left" | "right";
  color: string;
  label: string;
  onChange: (x: number, y: number) => void;
  disabled?: boolean;
}

export function Joystick({ side, color, label, onChange, disabled }: JoystickProps) {
  const baseRef = useRef<HTMLDivElement>(null);
  const pointerId = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [active, setActive] = useState(false);

  const update = useCallback(
    (clientX: number, clientY: number) => {
      const el = baseRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      let dx = clientX - cx;
      let dy = clientY - cy;
      const max = rect.width / 2 - rect.width * 0.24;
      const len = Math.hypot(dx, dy);
      if (len > max) {
        dx = (dx / len) * max;
        dy = (dy / len) * max;
      }
      setKnob({ x: dx, y: dy });
      onChange(dx / max, -dy / max);
    },
    [onChange]
  );

  const end = useCallback(() => {
    const el = baseRef.current;
    if (el && pointerId.current !== null && el.hasPointerCapture(pointerId.current)) {
      el.releasePointerCapture(pointerId.current);
    }
    pointerId.current = null;
    setActive(false);
    setKnob({ x: 0, y: 0 });
    onChange(0, 0);
  }, [onChange]);

  return (
    <div className={`flex flex-col items-center gap-1 ${side === "left" ? "items-start" : "items-end"}`}>
      <div
        className="flex items-center gap-1.5 text-[9px] font-bold tracking-[0.22em]"
        style={{ color }}
      >
        <span className="inline-block h-1 w-1 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
        {label}
      </div>
      <div
        ref={baseRef}
        role="application"
        aria-label={`${label} joystick`}
        className="no-touch touch-joystick pointer-events-auto relative grid place-items-center rounded-full"
        style={{
          width: "clamp(78px, 21vw, 124px)",
          height: "clamp(78px, 21vw, 124px)",
          background:
            "radial-gradient(circle at 50% 45%, rgba(255,255,255,0.07), rgba(6,9,14,0.72) 62%, rgba(3,5,8,0.9))",
          border: `1px solid ${color}55`,
          boxShadow: active
            ? `0 0 0 2px ${color}44, 0 0 26px ${color}55, inset 0 0 24px ${color}22`
            : `0 0 18px ${color}22, inset 0 0 18px rgba(0,0,0,0.7)`,
          opacity: disabled ? 0.4 : 1,
          touchAction: "none",
        }}
        onPointerDown={(e) => {
          if (disabled) return;
          e.preventDefault();
          e.currentTarget.setPointerCapture(e.pointerId);
          pointerId.current = e.pointerId;
          setActive(true);
          update(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (pointerId.current !== e.pointerId) return;
          e.preventDefault();
          update(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (pointerId.current !== e.pointerId) return;
          end();
        }}
        onPointerCancel={end}
        onLostPointerCapture={end}
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* cardinal ticks */}
        <span className="pointer-events-none absolute left-1/2 top-[5px] h-[6px] w-[2px] -translate-x-1/2 rounded" style={{ background: `${color}99` }} />
        <span className="pointer-events-none absolute bottom-[5px] left-1/2 h-[6px] w-[2px] -translate-x-1/2 rounded" style={{ background: `${color}99` }} />
        <span className="pointer-events-none absolute left-[5px] top-1/2 h-[2px] w-[6px] -translate-y-1/2 rounded" style={{ background: `${color}99` }} />
        <span className="pointer-events-none absolute right-[5px] top-1/2 h-[2px] w-[6px] -translate-y-1/2 rounded" style={{ background: `${color}99` }} />
        <div
          className="pointer-events-none absolute inset-[14%] rounded-full border"
          style={{ borderColor: `${color}22` }}
        />
        <div
          className="pointer-events-none absolute rounded-full"
          style={{
            width: "42%",
            height: "42%",
            transform: `translate(${knob.x}px, ${knob.y}px)`,
            transition: active ? "none" : "transform 0.16s cubic-bezier(0.2,0.9,0.3,1.2)",
            background: `radial-gradient(circle at 36% 30%, #ffffff, ${color} 42%, rgba(8,12,18,0.95) 100%)`,
            border: `1px solid ${color}`,
            boxShadow: `0 0 18px ${color}99, inset 0 -3px 8px rgba(0,0,0,0.5)`,
          }}
        >
          <div
            className="absolute inset-[26%] rounded-full"
            style={{ background: "rgba(4,8,12,0.55)", border: `1px solid ${color}66` }}
          />
        </div>
      </div>
    </div>
  );
}
