import { useRef } from 'react';

interface Props {
  onChange: (x: number, y: number) => void;
}

const R = 44;

export function Joystick({ onChange }: Props) {
  const base = useRef<HTMLDivElement>(null);
  const knob = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);

  const update = (e: React.PointerEvent) => {
    const el = base.current;
    if (!el || !knob.current) return;
    const r = el.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > R) {
      dx = (dx / len) * R;
      dy = (dy / len) * R;
    }
    knob.current.style.transform = `translate(${dx}px, ${dy}px)`;
    let nx = dx / R;
    let ny = -dy / R;
    if (Math.hypot(nx, ny) < 0.14) {
      nx = 0;
      ny = 0;
    }
    onChange(nx, ny);
  };

  const end = (e: React.PointerEvent) => {
    if (e.pointerId !== pid.current) return;
    pid.current = null;
    if (knob.current) knob.current.style.transform = 'translate(0px, 0px)';
    onChange(0, 0);
  };

  return (
    <div
      ref={base}
      className="relative h-[132px] w-[132px] touch-none select-none rounded-full border-2 border-white/40 bg-black/25 backdrop-blur-[2px]"
      onPointerDown={(e) => {
        if (pid.current !== null) return;
        e.preventDefault();
        pid.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        update(e);
      }}
      onPointerMove={(e) => {
        if (e.pointerId === pid.current) update(e);
      }}
      onPointerUp={end}
      onPointerCancel={end}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        ref={knob}
        className="pointer-events-none absolute left-1/2 top-1/2 -ml-7 -mt-7 h-14 w-14 rounded-full border-2 border-white/70 bg-white/35 shadow-lg"
      />
    </div>
  );
}
