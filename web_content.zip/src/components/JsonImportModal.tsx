import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  FileJson,
  Loader2,
  Upload,
  X,
} from 'lucide-react';
import {
  ActiveUpgradeEntry,
  ClanDashboardState,
  VillageCategory,
  VillageId,
} from '../shared/cocData';
import { formatDateTimeRu } from '../utils/formatters';
import { apiFetchJson } from '../utils/apiClient';
import { getVillageShortTitle } from './CocUnitBadge';

interface JsonImportModalProps {
  isOpen: boolean;
  state: ClanDashboardState;
  initialTargetTag?: string;
  onClose: () => void;
  onImported: (nextState: ClanDashboardState, message: string) => void;
}

interface PreviewActiveTimer {
  village: 'home' | 'builderBase';
  dataId: number;
  objectName: string;
  objectNameRu: string;
  detailType: string;
  fromLevel: number;
  toLevel: number;
  timerSeconds: number;
}

interface PreviewResponse {
  parsed: {
    tag: string;
    townHallLevel: number;
    builderHallLevel: number;
    hasBuilderBase: boolean;
    exportTimestampIso?: string;
    recognizedCount: number;
    homeBuildingsCount: number;
    homeTrapsCount: number;
    homeWallsTotal: number;
    builderBuildingsCount: number;
    builderTrapsCount: number;
    builderWallsTotal: number;
  };
  activeTimers: PreviewActiveTimer[];
  missingFields: string[];
  matchedPlayer: {
    tag: string;
    name: string;
    oldPct: number;
    lastJsonImportAt?: string;
  } | null;
  diffs: Array<{
    village: VillageId;
    itemId: string;
    apiName: string;
    itemNameRu: string;
    category: VillageCategory | 'townhall';
    instanceNumber?: number;
    fromLevel: number;
    toLevel: number;
  }>;
}

function formatSecondsDuration(totalSec: number): string {
  const d = Math.floor(totalSec / 86400);
  const h = Math.floor((totalSec % 86400) / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  if (d > 0) return `${d} д ${h} ч ${m} м`;
  if (h > 0) return `${h} ч ${m} м`;
  return `${m} м`;
}

export const JsonImportModal: React.FC<JsonImportModalProps> = ({
  isOpen,
  state,
  initialTargetTag = '',
  onClose,
  onImported,
}) => {
  const [jsonText, setJsonText] = useState('');
  const [targetTag, setTargetTag] = useState(initialTargetTag);
  const [playerName, setPlayerName] = useState('');
  const [preview, setPreview] = useState<PreviewResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setTargetTag(initialTargetTag);
      setErr(null);
      setPreview(null);
    }
  }, [isOpen, initialTargetTag]);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setJsonText(reader.result);
        setPreview(null);
        setErr(null);
      }
    };
    reader.onerror = () => {
      setErr('Не удалось прочитать выбранный файл.');
    };
    reader.readAsText(file, 'utf-8');
  };

  const handlePreview = async () => {
    setErr(null);
    if (!jsonText.trim()) {
      setErr('Вставьте текст JSON или загрузите .json-файл экспорта из Clash of Clans.');
      return;
    }
    setLoading(true);
    try {
      const data = await apiFetchJson<PreviewResponse>('/api/import/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonText,
          targetTag: targetTag || undefined,
        }),
      });
      setPreview(data);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Ошибка разбора JSON');
      setPreview(null);
    } finally {
      setLoading(false);
    }
  };

  const handleCommit = async () => {
    setErr(null);
    if (!jsonText.trim()) {
      setErr('Сначала вставьте JSON экспорта деревни.');
      return;
    }
    setLoading(true);
    try {
      const data = await apiFetchJson<{
        player: { name: string; tag: string };
        eventsCreated: number;
        activeTimersCount: number;
        activeTimers: ActiveUpgradeEntry[];
        missingFields: string[];
        state: ClanDashboardState;
      }>('/api/import/village', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonText,
          targetTag: targetTag || undefined,
          playerName: playerName || undefined,
        }),
      });
      const msg = `JSON Export для ${data.player.name} (${data.player.tag}) сохранён. Текущих улучшений с таймером: ${data.activeTimersCount}. Новых завершений vs прошлый экспорт: ${data.eventsCreated}.`;
      onImported(data.state, msg);
      setJsonText('');
      setPreview(null);
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Ошибка сохранения импорта');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
      <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-xl border border-slate-700 bg-[#121824] shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between gap-4 border-b border-slate-800 bg-[#121824] px-5 py-4">
          <div className="flex items-center gap-2.5">
            <FileJson className="h-5 w-5 text-amber-400 shrink-0" />
            <div>
              <h2 className="font-display text-lg font-bold text-slate-100">
                Импортировать данные деревни (JSON Export)
              </h2>
              <p className="text-xs text-slate-400">
                Home Village + Builder Base + активные таймеры строительства/лаборатории
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-100"
            aria-label="Закрыть"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4 p-5 text-xs">
          <div className="rounded-md border border-slate-800 bg-[#0B0F17] p-3.5 text-slate-300 leading-relaxed space-y-1">
            <div>
              <strong className="text-amber-400">Откуда взять официальный JSON Export в игре:</strong>{' '}
              Откройте в Clash of Clans <span className="font-mono text-slate-100">Настройки → Ещё настройки → Экспорт данных → Скопировать</span>.
            </div>
            <div className="text-slate-400">
              Импортированные объекты помечаются источником <strong className="text-sky-300">Игровой JSON Export</strong> и никогда не выдаются за данные Supercell API.
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-slate-400 mb-1">
                Привязать к участнику клана (необязательно)
              </label>
              <select
                value={targetTag}
                onChange={(e) => {
                  setTargetTag(e.target.value);
                  setPreview(null);
                }}
                className="w-full rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-2 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
              >
                <option value="">Определить по полю tag внутри JSON</option>
                {state.players.map((pl) => (
                  <option key={pl.tag} value={pl.tag}>
                    {pl.name} ({pl.tag} · TH{pl.townHallLevel} / BH{pl.builderHallLevel || '—'})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">
                Имя игрока (если участника ещё нет в клане)
              </label>
              <input
                type="text"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                placeholder="Например: PLAYER ONE"
                className="w-full rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2">
            <label className="text-slate-300 font-medium">
              Вставьте JSON-текст или выберите файл (.json):
            </label>
            <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-slate-700 bg-[#0B0F17] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-amber-500/60 hover:text-amber-400 transition-colors">
              <Upload className="h-3.5 w-3.5" />
              <span>Выбрать JSON-файл</span>
              <input
                type="file"
                accept=".json,application/json,.txt"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
          </div>

          <textarea
            rows={7}
            value={jsonText}
            onChange={(e) => {
              setJsonText(e.target.value);
              setPreview(null);
            }}
            placeholder='{"tag":"#2PP","timestamp":1763200000,"buildings":[...],"buildings2":[...],"heroes2":[...]}'
            className="w-full rounded-md border border-slate-800 bg-[#0B0F17] p-3 font-mono text-[11px] text-slate-200 placeholder:text-slate-600 focus:border-amber-500 focus:outline-none"
          />

          {err && (
            <div className="rounded-md border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-xs text-rose-300">
              {err}
            </div>
          )}

          {preview && (
            <div className="space-y-3 rounded-lg border border-slate-700 bg-[#0B0F17] p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                <div className="flex items-center gap-2 font-semibold text-slate-100">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <span>
                    Распознано: {preview.matchedPlayer ? `${preview.matchedPlayer.name} (${preview.parsed.tag})` : preview.parsed.tag}
                  </span>
                </div>
                {preview.parsed.exportTimestampIso && (
                  <span className="font-mono text-[11px] text-slate-400">
                    Время экспорта: {formatDateTimeRu(preview.parsed.exportTimestampIso)}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="rounded border border-slate-800 bg-[#121824] p-2.5">
                  <div className="text-slate-400">HOME VILLAGE</div>
                  <div className="mt-1 font-mono font-bold text-amber-400">
                    TH{preview.parsed.townHallLevel} · {preview.parsed.homeBuildingsCount} зд.
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Лов.: {preview.parsed.homeTrapsCount} · Стен: {preview.parsed.homeWallsTotal}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#121824] p-2.5">
                  <div className="text-slate-400">BUILDER BASE</div>
                  <div className="mt-1 font-mono font-bold text-sky-400">
                    {preview.parsed.hasBuilderBase
                      ? `BH${preview.parsed.builderHallLevel} · ${preview.parsed.builderBuildingsCount} зд.`
                      : 'Нет данных (buildings2)'}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Лов.: {preview.parsed.builderTrapsCount} · Стен: {preview.parsed.builderWallsTotal}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#121824] p-2.5">
                  <div className="text-slate-400">Текущие таймеры</div>
                  <div className="mt-1 font-mono font-bold text-emerald-400">
                    {preview.activeTimers.length} в процессе
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#121824] p-2.5">
                  <div className="text-slate-400">Завершено vs прошлый</div>
                  <div className="mt-1 font-mono font-bold text-slate-100">
                    +{preview.diffs.length} улучш.
                  </div>
                </div>
              </div>

              {preview.activeTimers.length > 0 && (
                <div className="space-y-1.5">
                  <div className="font-semibold text-amber-300">
                    Обнаружены активные улучшения (по полю timer):
                  </div>
                  <div className="divide-y divide-slate-800 rounded border border-slate-800 bg-[#121824]">
                    {preview.activeTimers.map((t, idx) => (
                      <div key={idx} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[10px] font-semibold text-sky-300">
                            {getVillageShortTitle(t.village)}
                          </span>
                          <span className="font-medium text-slate-100">{t.objectName}</span>
                          <span className="text-slate-500">({t.objectNameRu})</span>
                        </div>
                        <div className="flex items-center gap-3 font-mono">
                          <span className="inline-flex items-center gap-1 font-bold text-amber-400">
                            {t.fromLevel} <ArrowRight className="h-3 w-3" /> {t.toLevel}
                          </span>
                          <span className="inline-flex items-center gap-1 text-emerald-400">
                            <Clock className="h-3 w-3" />
                            {formatSecondsDuration(t.timerSeconds)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {preview.diffs.length > 0 && (
                <div className="space-y-1.5">
                  <div className="font-semibold text-emerald-300">
                    Завершённые улучшения по сравнению с предыдущим импортом:
                  </div>
                  <div className="max-h-36 overflow-y-auto divide-y divide-slate-800 rounded border border-slate-800 bg-[#121824]">
                    {preview.diffs.map((d, idx) => (
                      <div key={idx} className="flex items-center justify-between gap-2 px-3 py-1.5">
                        <span>
                          <span className="font-mono text-[10px] text-slate-400 mr-2">
                            {getVillageShortTitle(d.village)}
                          </span>
                          <span className="text-slate-100 font-medium">{d.apiName}</span>
                          {d.instanceNumber ? ` #${d.instanceNumber}` : ''}
                        </span>
                        <span className="font-mono font-bold text-emerald-400">
                          {d.fromLevel} → {d.toLevel}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {preview.missingFields.length > 0 && (
                <div className="rounded border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-200 space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-amber-300">
                    <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                    <span>Поля, отсутствующие в этом JSON-экспорте:</span>
                  </div>
                  <ul className="list-disc pl-5 text-amber-200/90">
                    {preview.missingFields.map((mf, i) => (
                      <li key={i}>{mf}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-end gap-2.5 border-t border-slate-800 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-slate-700 bg-[#0B0F17] px-4 py-2 text-xs font-medium text-slate-300 hover:text-slate-100"
            >
              Отмена
            </button>
            <button
              type="button"
              disabled={loading || !jsonText.trim()}
              onClick={handlePreview}
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-[#0B0F17] px-4 py-2 text-xs font-semibold text-slate-100 hover:border-amber-500/60 disabled:opacity-50"
            >
              {loading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              <span>Проверить и сравнить</span>
            </button>
            <button
              type="button"
              disabled={loading || !jsonText.trim()}
              onClick={handleCommit}
              className="inline-flex items-center gap-1.5 rounded-md bg-amber-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-50"
            >
              {loading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              <span>Сохранить импорт деревни</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
