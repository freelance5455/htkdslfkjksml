import { useCallback, useRef } from "react";
import { LETTERS } from "@/data/catalog";
import { cn } from "@/lib/utils";

export function AzJumper({
  present,
  active,
  onJump,
}: {
  present: Set<string>;
  active?: string;
  onJump: (letter: string) => void;
}) {
  const railRef = useRef<HTMLDivElement>(null);

  const letterFromPoint = useCallback((clientY: number) => {
    const rail = railRef.current;
    if (!rail) return;
    const buttons = [...rail.querySelectorAll<HTMLButtonElement>("[data-letter]")];
    if (buttons.length === 0) return;
    let closest = buttons[0];
    let best = Infinity;
    for (const btn of buttons) {
      const r = btn.getBoundingClientRect();
      const mid = r.top + r.height / 2;
      const d = Math.abs(mid - clientY);
      if (d < best) {
        best = d;
        closest = btn;
      }
    }
    const letter = closest.dataset.letter;
    if (letter) onJump(letter);
  }, [onJump]);

  return (
    <div
      ref={railRef}
      className="az-rail pointer-events-auto sticky top-28 z-20 flex h-[min(72vh,36rem)] w-6 shrink-0 flex-col justify-between py-1 select-none"
      onPointerDown={(e) => {
        (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
        letterFromPoint(e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) letterFromPoint(e.clientY);
      }}
      role="navigation"
      aria-label="Jump to letter"
    >
      {LETTERS.map((letter) => {
        const enabled = present.has(letter);
        return (
          <button
            key={letter}
            type="button"
            data-letter={letter}
            disabled={!enabled}
            onClick={() => enabled && onJump(letter)}
            className={cn(
              "flex h-full min-h-0 items-center justify-center text-[10px] font-medium leading-none",
              enabled ? "text-foreground" : "text-subtle/50",
              active === letter && enabled && "text-ivory",
            )}
            aria-label={`Jump to ${letter}`}
          >
            {letter}
          </button>
        );
      })}
    </div>
  );
}
