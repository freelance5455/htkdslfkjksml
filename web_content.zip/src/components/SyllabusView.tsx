import React, { useState } from 'react';
import { ClassLevelId, ClassSyllabus, Language } from '../types';
import { translations } from '../utils/translations';
import {
  BookOpen,
  Mic,
  Headphones,
  CheckCircle,
  FileText,
  Printer,
  Sparkles,
  Layers
} from 'lucide-react';

interface SyllabusViewProps {
  syllabusList: ClassSyllabus[];
  lang: Language;
  defaultLevelId?: string;
}

export const SyllabusView: React.FC<SyllabusViewProps> = ({
  syllabusList,
  lang,
  defaultLevelId,
}) => {
  const t = translations[lang];
  const [selectedLevelId, setSelectedLevelId] = useState<ClassLevelId>(
    (defaultLevelId as ClassLevelId) || 'elementary_a'
  );

  const currentSyllabus =
    syllabusList.find((s) => s.classLevelId === selectedLevelId) || syllabusList[0];

  const levels: { id: ClassLevelId; labelEn: string; labelPs: string; labelUr: string }[] = [
    { id: 'elementary_a', labelEn: 'Elementary A', labelPs: 'لومړنی الف (Elem A)', labelUr: 'ابتدائی اے (Elem A)' },
    { id: 'elementary_b', labelEn: 'Elementary B', labelPs: 'لومړنی ب (Elem B)', labelUr: 'ابتدائی بی (Elem B)' },
    { id: 'pre_intermediate', labelEn: 'Pre-Intermediate', labelPs: 'تر منځنۍ مخکې (Pre-Inter)', labelUr: 'پری انٹرمیڈیٹ' },
    { id: 'intermediate', labelEn: 'Intermediate', labelPs: 'منځنی ټولګی (Inter)', labelUr: 'انٹرمیڈیٹ' },
    { id: 'junior_advanced', labelEn: 'Junior Advanced', labelPs: 'جونیئر اډوانس (Part 1)', labelUr: 'جونیئر ایڈوانسڈ (حصہ اول)' },
    { id: 'senior_advanced', labelEn: 'Senior Advanced', labelPs: 'سینئر اډوانس (Part 2)', labelUr: 'سینئر ایڈوانسڈ (حصہ دوم)' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-800/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-300 bg-emerald-500/20 px-3 py-1 rounded-full mb-2 border border-emerald-500/30">
            <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
            <span>Comprehensive Spoken & Grammar Curriculum</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            {t.navSyllabus} - Rahbar English Center
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            {lang === 'ps'
              ? 'د ټولګیو بشپړ درسي نصاب: د ګرامر ساعتونه، د خبرو اترو (Speaking) تګلاره او د لغاتونو لیست.'
              : lang === 'ur'
              ? 'کلاسز کا جامع نصاب: گرامر کے اوقات، روزمرہ بول چال اور ذخیرہ الفاظ کی تفصیلی منصوبہ بندی۔'
              : 'Detailed curriculum from Elementary A to Senior Advanced, highlighting Weekly Grammar, Speaking labs, and Vocabulary.'}
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 bg-white text-slate-900 hover:bg-slate-100 font-bold px-4 py-2 rounded-2xl text-xs shadow-md transition shrink-0"
        >
          <Printer className="w-4 h-4 text-emerald-700" />
          <span>Print Syllabus</span>
        </button>
      </div>

      {/* Level Selection Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {levels.map((lvl) => {
          const isActive = selectedLevelId === lvl.id;
          const label = lang === 'ps' ? lvl.labelPs : lang === 'ur' ? lvl.labelUr : lvl.labelEn;
          return (
            <button
              key={lvl.id}
              onClick={() => setSelectedLevelId(lvl.id)}
              className={`px-4 py-2 rounded-2xl text-xs font-extrabold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-700/20'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Syllabus Content Card */}
      {currentSyllabus && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-100 pb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="text-xs uppercase font-extrabold text-emerald-700 tracking-wider block">
                Rahbar English Center Curriculum
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">
                {lang === 'ps'
                  ? currentSyllabus.titlePs
                  : lang === 'ur'
                  ? currentSyllabus.titleUr
                  : currentSyllabus.titleEn}
              </h3>
            </div>

            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700">
              <Layers className="w-4 h-4 text-emerald-600" />
              <span>{currentSyllabus.units.length} Core Curriculum Modules</span>
            </div>
          </div>

          {/* Units / Weeks List */}
          <div className="space-y-4">
            {currentSyllabus.units.map((unit, index) => (
              <div
                key={index}
                className="bg-slate-50 rounded-2xl border border-slate-200/80 p-5 hover:border-emerald-300 transition space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="bg-emerald-600 text-white font-black text-xs px-2.5 py-1 rounded-xl shadow-sm">
                      Week {unit.week}
                    </span>
                    <h4 className="text-sm font-extrabold text-slate-900">
                      {unit.topicTitle}
                    </h4>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
                  {/* Grammar */}
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200/70">
                    <div className="flex items-center gap-1.5 font-bold text-blue-700 mb-1">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Grammar Structure</span>
                    </div>
                    <p className="text-slate-600 leading-relaxed">{unit.grammarFocus}</p>
                  </div>

                  {/* Speaking */}
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200/70">
                    <div className="flex items-center gap-1.5 font-bold text-emerald-700 mb-1">
                      <Mic className="w-3.5 h-3.5" />
                      <span>Speaking & Conversation</span>
                    </div>
                    <p className="text-slate-600 leading-relaxed">{unit.speakingFocus}</p>
                  </div>

                  {/* Vocab & Activity */}
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200/70">
                    <div className="flex items-center gap-1.5 font-bold text-purple-700 mb-1">
                      <Headphones className="w-3.5 h-3.5" />
                      <span>Vocabulary & Drill</span>
                    </div>
                    <p className="text-slate-600 leading-relaxed mb-2">{unit.vocabularyFocus}</p>
                    <div className="text-[11px] font-semibold text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100 flex items-start gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                      <span>{unit.practiceActivity}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
