import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Coins, 
  ShieldCheck, 
  Sparkles, 
  UserX, 
  UserCheck, 
  PlusCircle, 
  MinusCircle, 
  X,
  Edit
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { User, MembershipTier } from '../../types';

export const AdminUsersTab: React.FC = () => {
  const { allUsers, toggleUserStatus, adjustUserCoins, updateUserTierAdmin, membershipPlans, t } = useApp();

  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<number>(50);
  const [adjustReason, setAdjustReason] = useState('Loyalty Bonus');
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(false);

  const filteredUsers = allUsers.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    u.referralCode.toLowerCase().includes(search.toLowerCase())
  );

  const handleOpenAdjust = (user: User) => {
    setSelectedUser(user);
    setAdjustAmount(50);
    setAdjustReason('Administrative adjustment');
    setIsAdjustModalOpen(true);
  };

  const handleApplyAdjustment = (isCredit: boolean) => {
    if (!selectedUser) return;
    const finalAmount = isCredit ? Math.abs(adjustAmount) : -Math.abs(adjustAmount);
    adjustUserCoins(selectedUser.id, finalAmount, adjustReason);
    setIsAdjustModalOpen(false);
    setSelectedUser(null);
  };

  return (
    <div className="space-y-4">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            {t('userManagement')} ({allUsers.length})
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Activate/deactivate users, manage VIP tiers, and adjust coin balances.
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, email..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs focus:outline-purple-500"
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-3.5">User Details</th>
                <th className="p-3.5">Balance</th>
                <th className="p-3.5">Lifetime</th>
                <th className="p-3.5">VIP Tier</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-200">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                  <td className="p-3.5">
                    <p className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                      <span>{user.name}</span>
                      {user.username && <span className="text-[11px] text-amber-500 font-semibold">{user.username}</span>}
                    </p>
                    <p className="text-[11px] text-slate-400">{user.email}</p>
                    <p className="text-[10px] text-slate-400 font-mono">Ref: {user.referralCode}</p>
                  </td>
                  <td className="p-3.5 font-bold text-emerald-600 dark:text-emerald-400">
                    🪙 {user.coins.toLocaleString()}
                  </td>
                  <td className="p-3.5 text-slate-500">
                    🪙 {user.lifetimeCoins.toLocaleString()}
                  </td>
                  <td className="p-3.5">
                    <select
                      value={user.membershipTier}
                      onChange={(e) => updateUserTierAdmin(user.id, e.target.value as MembershipTier)}
                      className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-[11px] font-bold capitalize"
                    >
                      <option value="basic">Basic</option>
                      <option value="premium">Premium</option>
                      <option value="pro">Pro VIP</option>
                    </select>
                  </td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      user.isActive
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                        : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                    }`}>
                      {user.isActive ? 'Active' : 'Deactivated'}
                    </span>
                  </td>
                  <td className="p-3.5 text-right space-x-1">
                    <button
                      onClick={() => handleOpenAdjust(user)}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold text-[11px] cursor-pointer"
                      title="Adjust coins"
                    >
                      ± Coins
                    </button>
                    <button
                      onClick={() => toggleUserStatus(user.id)}
                      className={`p-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                        user.isActive
                          ? 'text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                          : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                      }`}
                      title={user.isActive ? 'Deactivate' : 'Activate'}
                    >
                      {user.isActive ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Adjust Coins Modal */}
      {isAdjustModalOpen && selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl relative">
            <button
              onClick={() => setIsAdjustModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
              Adjust Coins for {selectedUser.name}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Current balance: {selectedUser.coins} Coins
            </p>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Amount
                </label>
                <input
                  type="number"
                  min={1}
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-sm font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Reason for Adjustment
                </label>
                <input
                  type="text"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  placeholder="e.g. Loyalty bonus, Correction, Event reward"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => handleApplyAdjustment(true)}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Credit (+{adjustAmount})</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyAdjustment(false)}
                  className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <MinusCircle className="w-4 h-4" />
                  <span>Debit (-{adjustAmount})</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
