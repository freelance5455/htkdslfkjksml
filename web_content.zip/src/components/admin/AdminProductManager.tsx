import React, { useState } from 'react';
import {
  Plus,
  Search,
  Upload,
  Pencil,
  Trash2,
  Loader2,
  X,
  Check,
  AlertCircle,
  Image as ImageIcon,
} from 'lucide-react';
import {
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import { db, storage, handleFirestoreError, OperationType } from '../../lib/firebase';
import { CATEGORY_IMAGES, HERO_CAMPAIGN_IMAGE } from '../../lib/catalogDefaults';
import { useStoreData } from '../../context/StoreDataContext';
import { Category, Product, ProductGender } from '../../types/store';
import { formatCurrency, getDiscountPercent, isValidImageUrl, slugify } from '../../lib/formatters';

const AVAILABLE_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '28', '30', '32', '34', '36'];

const STUDIO_GALLERY = [
  { label: 'Mens Jacket', url: CATEGORY_IMAGES.jacket },
  { label: 'Silk Dress', url: CATEGORY_IMAGES.dress },
  { label: 'Minimal Hoodie', url: CATEGORY_IMAGES.hoodie },
  { label: 'Denim & Shirt', url: CATEGORY_IMAGES.denim },
  { label: 'Traditional Wear', url: CATEGORY_IMAGES.traditional },
  { label: 'Editorial Coat', url: HERO_CAMPAIGN_IMAGE },
];

interface AdminProductManagerProps {
  mode: 'add' | 'list';
  onSwitchToList: () => void;
  onSwitchToAdd?: () => void;
}

export function AdminProductManager({
  mode,
  onSwitchToList,
  onSwitchToAdd,
}: AdminProductManagerProps) {
  const { products, categories, notify } = useStoreData();

  // Add / Edit form states
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [discountPrice, setDiscountPrice] = useState('0');
  const [category, setCategory] = useState(categories[0]?.name || "Men's Fashion");
  const [gender, setGender] = useState<ProductGender>('Unisex');
  const [sizes, setSizes] = useState<string[]>(['S', 'M', 'L', 'XL']);
  const [colorsText, setColorsText] = useState('Onyx Black, Ivory');
  const [stock, setStock] = useState('25');
  const [imageUrl, setImageUrl] = useState(CATEGORY_IMAGES.jacket);
  const [isNewArrival, setIsNewArrival] = useState(true);
  const [isBestSeller, setIsBestSeller] = useState(false);
  const [isActive, setIsActive] = useState(true);

  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // List filter & quick actions
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const resetForm = () => {
    setEditingProduct(null);
    setName('');
    setDescription('');
    setPrice('');
    setDiscountPrice('0');
    setCategory(categories[0]?.name || "Men's Fashion");
    setGender('Unisex');
    setSizes(['S', 'M', 'L', 'XL']);
    setColorsText('Onyx Black, Ivory');
    setStock('25');
    setImageUrl(CATEGORY_IMAGES.jacket);
    setIsNewArrival(true);
    setIsBestSeller(false);
    setIsActive(true);
    setFormError('');
    setUploadError('');
  };

  const openEditModal = (prod: Product) => {
    setEditingProduct(prod);
    setName(prod.name);
    setDescription(prod.description);
    setPrice(String(prod.price));
    setDiscountPrice(String(prod.discountPrice || 0));
    setCategory(prod.category);
    setGender(prod.gender);
    setSizes(prod.sizes);
    setColorsText(prod.colors.join(', '));
    setStock(String(prod.stock));
    setImageUrl(prod.imageUrl);
    setIsNewArrival(prod.isNewArrival);
    setIsBestSeller(prod.isBestSeller);
    setIsActive(prod.isActive);
    setFormError('');
    setUploadError('');
  };

  const toggleSize = (s: string) => {
    setSizes((prev) =>
      prev.includes(s) ? prev.filter((item) => item !== s) : [...prev, s]
    );
  };

  const handleImageFileUpload = async (file: File) => {
    setUploadError('');
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (JPG, PNG, WEBP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Image must be smaller than 5 MB.');
      return;
    }

    setUploadingImage(true);
    setUploadProgress(0);

    try {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const storageRef = ref(storage, `products/${Date.now()}_${safeName}`);
      const uploadTask = uploadBytesResumable(storageRef, file);

      await new Promise<void>((resolve, reject) => {
        uploadTask.on(
          'state_changed',
          (snapshot) => {
            const pct = Math.round(
              (snapshot.bytesTransferred / snapshot.totalBytes) * 100
            );
            setUploadProgress(pct);
          },
          (err) => reject(err),
          async () => {
            const url = await getDownloadURL(uploadTask.snapshot.ref);
            setImageUrl(url);
            resolve();
          }
        );
      });
      notify('Product image uploaded to Firebase Storage.', 'success');
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Storage upload failed. Ensure Firebase Storage & storage.rules are enabled in Firebase Console, or choose a studio image / paste an image URL below.';
      setUploadError(
        `${msg} (Tip: Enable Storage in Firebase Console with storage.rules, or select a studio image below.)`
      );
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const cleanName = name.trim();
    const cleanDesc = description.trim();
    const parsedPrice = Number(price);
    const parsedDiscount = Number(discountPrice || 0);
    const parsedStock = parseInt(stock, 10);
    const parsedColors = colorsText
      .split(',')
      .map((c) => c.trim())
      .filter(Boolean)
      .slice(0, 10);

    if (cleanName.length < 2) return setFormError('Product name must be at least 2 characters.');
    if (cleanDesc.length < 5) return setFormError('Description must be at least 5 characters.');
    if (isNaN(parsedPrice) || parsedPrice <= 0) return setFormError('Price must be greater than 0.');
    if (isNaN(parsedDiscount) || parsedDiscount < 0 || parsedDiscount >= parsedPrice) {
      return setFormError('Discount price must be 0 or less than regular price.');
    }
    if (sizes.length === 0) return setFormError('Select at least one product size.');
    if (parsedColors.length === 0) return setFormError('Enter at least one color.');
    if (isNaN(parsedStock) || parsedStock < 0) return setFormError('Stock must be 0 or higher.');
    if (!isValidImageUrl(imageUrl.trim())) {
      return setFormError('Upload a product image or provide a valid image URL.');
    }

    setSaving(true);
    try {
      if (editingProduct) {
        const prodRef = doc(db, 'products', editingProduct.id);
        await updateDoc(prodRef, {
          name: cleanName.slice(0, 120),
          description: cleanDesc.slice(0, 2000),
          price: parsedPrice,
          discountPrice: parsedDiscount,
          category: category.trim().slice(0, 60),
          gender,
          sizes: sizes.slice(0, 10),
          colors: parsedColors,
          stock: parsedStock,
          imageUrl: imageUrl.trim().slice(0, 1000),
          isNewArrival,
          isBestSeller,
          isActive,
          updatedAt: serverTimestamp(),
        });
        notify('Product updated on storefront.', 'success');
        resetForm();
      } else {
        const productId = `prod-${slugify(cleanName).slice(0, 40)}-${Date.now().toString(36)}`;
        const prodRef = doc(db, 'products', productId);
        await setDoc(prodRef, {
          id: productId,
          name: cleanName.slice(0, 120),
          description: cleanDesc.slice(0, 2000),
          price: parsedPrice,
          discountPrice: parsedDiscount,
          category: category.trim().slice(0, 60),
          gender,
          sizes: sizes.slice(0, 10),
          colors: parsedColors,
          stock: parsedStock,
          imageUrl: imageUrl.trim().slice(0, 1000),
          isNewArrival,
          isBestSeller,
          isActive,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        notify('Item published to Fashion Hub storefront.', 'success');
        resetForm();
        onSwitchToList();
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'products');
    } finally {
      setSaving(false);
    }
  };

  const handleQuickStockChange = async (prod: Product, delta: number) => {
    const nextStock = Math.max(0, prod.stock + delta);
    try {
      await updateDoc(doc(db, 'products', prod.id), {
        stock: nextStock,
        updatedAt: serverTimestamp(),
      });
      notify(`Updated stock for "${prod.name}" to ${nextStock}.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `products/${prod.id}`);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    try {
      await deleteDoc(doc(db, 'products', productId));
      setConfirmDeleteId(null);
      notify('Product removed from catalog.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `products/${productId}`);
    }
  };

  const categoryOptions: Category[] =
    categories.length > 0
      ? categories
      : [
          { id: '1', name: "Men's Fashion", slug: 'mens-fashion', displayOrder: 1, isActive: true },
          { id: '2', name: "Women's Fashion", slug: 'womens-fashion', displayOrder: 2, isActive: true },
          { id: '3', name: 'T-Shirts', slug: 't-shirts', displayOrder: 3, isActive: true },
          { id: '4', name: 'Shirts', slug: 'shirts', displayOrder: 4, isActive: true },
          { id: '5', name: 'Jeans', slug: 'jeans', displayOrder: 5, isActive: true },
          { id: '6', name: 'Hoodies', slug: 'hoodies', displayOrder: 6, isActive: true },
          { id: '7', name: 'Jackets', slug: 'jackets', displayOrder: 7, isActive: true },
          { id: '8', name: 'Dresses', slug: 'dresses', displayOrder: 8, isActive: true },
          { id: '9', name: 'Traditional Wear', slug: 'traditional-wear', displayOrder: 9, isActive: true },
        ];

  const previewPrice = Number(price) || 0;
  const previewDiscount = Number(discountPrice) || 0;
  const previewDiscountPct = getDiscountPercent(previewPrice, previewDiscount);

  const renderProductForm = () => (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 items-start">
      <form
        onSubmit={handleSaveProduct}
        className="xl:col-span-2 bg-white border border-neutral-200 p-6 sm:p-8 space-y-6"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Item / Product Name *
            </label>
            <input
              type="text"
              required
              maxLength={120}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Atelier Double-Faced Wool Trench Coat"
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Item Description *
            </label>
            <textarea
              required
              rows={3}
              maxLength={2000}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Fabric composition, fit, tailoring details, and care notes..."
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Regular Price (INR ₹ / Rs) *
            </label>
            <input
              type="number"
              required
              min="1"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="1499"
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none tabular-nums"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Discount Price (0 for no discount)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={discountPrice}
              onChange={(e) => setDiscountPrice(e.target.value)}
              placeholder="1199"
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none tabular-nums"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Category *
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
            >
              {categoryOptions.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Collection Gender *
            </label>
            <select
              value={gender}
              onChange={(e) => setGender(e.target.value as ProductGender)}
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
            >
              <option value="Men">Men</option>
              <option value="Women">Women</option>
              <option value="Unisex">Unisex</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Stock Quantity *
            </label>
            <input
              type="number"
              required
              min="0"
              step="1"
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none tabular-nums"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1.5">
              Available Colors (comma-separated) *
            </label>
            <input
              type="text"
              required
              value={colorsText}
              onChange={(e) => setColorsText(e.target.value)}
              placeholder="Onyx Black, Charcoal, Ivory"
              className="w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-neutral-700 mb-2">
              Available Sizes *
            </label>
            <div className="flex flex-wrap gap-2">
              {AVAILABLE_SIZES.map((s) => {
                const selected = sizes.includes(s);
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => toggleSize(s)}
                    className={`min-w-[42px] h-9 px-3 text-xs font-semibold border rounded-md transition-colors cursor-pointer ${
                      selected
                        ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-500'
                    }`}
                  >
                    {s}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Product Image Upload + Studio Gallery Picker */}
          <div className="md:col-span-2 space-y-3">
            <label className="block text-xs font-medium text-neutral-700">
              Item Image (Firebase Storage Upload, Studio Picker, or Direct URL) *
            </label>

            <div className="flex flex-col sm:flex-row gap-4 items-start">
              <label className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#0A0A0A] text-xs font-semibold hover:bg-neutral-100 transition-colors cursor-pointer shrink-0">
                {uploadingImage ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Upload className="w-4 h-4" />
                )}
                <span>
                  {uploadingImage
                    ? `Uploading ${uploadProgress}%`
                    : 'Upload to Firebase Storage'}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleImageFileUpload(file);
                  }}
                />
              </label>

              <input
                type="text"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="Or paste HTTPS / asset image URL..."
                className="flex-1 w-full px-3.5 py-2.5 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
              />
            </div>

            <div>
              <p className="text-[11px] text-neutral-500 mb-2 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Quick Studio Lookbook Presets:</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {STUDIO_GALLERY.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => setImageUrl(preset.url)}
                    className={`flex items-center gap-2 p-1.5 pr-3 border text-xs transition-colors cursor-pointer ${
                      imageUrl === preset.url
                        ? 'border-[#0A0A0A] bg-neutral-100 font-semibold'
                        : 'border-neutral-200 hover:border-neutral-400'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.label}
                      className="w-7 h-9 object-cover bg-neutral-100"
                    />
                    <span>{preset.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {uploadError && (
              <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 p-2.5">
                {uploadError}
              </p>
            )}
          </div>

          {/* Merchandising Flags */}
          <div className="md:col-span-2 flex flex-wrap gap-6 pt-2">
            <label className="inline-flex items-center gap-2 text-xs font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={isNewArrival}
                onChange={(e) => setIsNewArrival(e.target.checked)}
                className="accent-[#0A0A0A] w-4 h-4"
              />
              <span>Mark as New Arrival</span>
            </label>
            <label className="inline-flex items-center gap-2 text-xs font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={isBestSeller}
                onChange={(e) => setIsBestSeller(e.target.checked)}
                className="accent-[#0A0A0A] w-4 h-4"
              />
              <span>Mark as Best Seller</span>
            </label>
            <label className="inline-flex items-center gap-2 text-xs font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="accent-[#0A0A0A] w-4 h-4"
              />
              <span>Visible on Storefront</span>
            </label>
          </div>
        </div>

        {formError && (
          <div className="p-3 border border-red-200 bg-red-50 text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <div className="flex items-center gap-3 pt-2">
          <button
            type="submit"
            disabled={saving || uploadingImage}
            className="inline-flex items-center gap-2 px-7 py-3 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 disabled:opacity-50 transition-colors cursor-pointer"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            <span>{editingProduct ? 'Save Changes' : 'Publish Item to Store'}</span>
          </button>
          {editingProduct && (
            <button
              type="button"
              onClick={resetForm}
              className="px-6 py-3 rounded-full border border-neutral-300 text-xs font-semibold hover:bg-neutral-100 cursor-pointer"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      {/* Live Storefront Card Preview */}
      <div className="bg-white border border-neutral-200 p-5 space-y-3">
        <p className="text-[11px] uppercase tracking-wider text-neutral-500 font-semibold">
          Live Storefront Preview
        </p>
        <div className="border border-neutral-200/80">
          <div className="aspect-[3/4] bg-neutral-100 overflow-hidden">
            {imageUrl ? (
              <img
                src={imageUrl}
                alt={name || 'Preview'}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : null}
          </div>
          <div className="p-4 space-y-2">
            <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-neutral-500">
              <span>
                {category} · {gender}
              </span>
              {previewDiscountPct > 0 && (
                <span className="font-semibold text-[#0A0A0A]">{previewDiscountPct}% Off</span>
              )}
            </div>
            <p className="text-sm font-semibold text-[#0A0A0A] truncate">
              {name || 'New Fashion Item'}
            </p>
            <div className="flex items-baseline gap-2 tabular-nums">
              <span className="text-sm font-semibold">
                {previewPrice > 0
                  ? formatCurrency(
                      previewDiscount > 0 && previewDiscount < previewPrice
                        ? previewDiscount
                        : previewPrice
                    )
                  : '₹0'}
              </span>
              {previewDiscountPct > 0 && (
                <span className="text-xs text-neutral-400 line-through">
                  {formatCurrency(previewPrice)}
                </span>
              )}
            </div>
            <p className="text-[11px] text-neutral-500">
              Sizes: {sizes.join(' · ') || 'None'} · Stock: {stock || 0}
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  if (mode === 'add') {
    return (
      <div className="space-y-6 w-full">
        <div>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0A0A0A]">
            Add New Item
          </h2>
          <p className="text-xs text-neutral-500 mt-1">
            Publish a new clothing item directly to Firestore & Firebase Storage.
          </p>
        </div>
        {renderProductForm()}
      </div>
    );
  }

  const filteredProducts = products.filter((p) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.gender.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 w-full">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0A0A0A]">
            All Products ({products.length})
          </h2>
          <p className="text-xs text-neutral-500 mt-1">
            Manage pricing, inventory stock, images, and visibility across your storefront.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products or category..."
              className="w-full pl-10 pr-4 py-2 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>

          {onSwitchToAdd && (
            <button
              type="button"
              onClick={onSwitchToAdd}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Item</span>
            </button>
          )}
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white border border-neutral-200 overflow-x-auto w-full">
        <table className="w-full text-left border-collapse min-w-[780px]">
          <thead>
            <tr className="border-b border-neutral-200 bg-neutral-50 text-[11px] uppercase tracking-wider text-neutral-500">
              <th className="py-3.5 px-4 font-semibold">Product</th>
              <th className="py-3.5 px-4 font-semibold">Category</th>
              <th className="py-3.5 px-4 font-semibold">Price</th>
              <th className="py-3.5 px-4 font-semibold">Stock</th>
              <th className="py-3.5 px-4 font-semibold">Status</th>
              <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 text-xs">
            {filteredProducts.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-neutral-500">
                  No matching products found.
                </td>
              </tr>
            ) : (
              filteredProducts.map((prod) => (
                <tr key={prod.id} className="hover:bg-neutral-50/70">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={prod.imageUrl}
                        alt={prod.name}
                        referrerPolicy="no-referrer"
                        className="w-11 h-14 object-cover bg-neutral-100 shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="font-semibold text-[#0A0A0A] truncate max-w-[260px]">
                          {prod.name}
                        </p>
                        <p className="text-neutral-500 mt-0.5">
                          Sizes: {prod.sizes.join(', ')}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-neutral-700">
                    {prod.category} · {prod.gender}
                  </td>
                  <td className="py-3.5 px-4 tabular-nums">
                    {prod.discountPrice > 0 && prod.discountPrice < prod.price ? (
                      <div>
                        <span className="font-semibold text-[#0A0A0A]">
                          {formatCurrency(prod.discountPrice)}
                        </span>
                        <span className="ml-1.5 text-neutral-400 line-through">
                          {formatCurrency(prod.price)}
                        </span>
                      </div>
                    ) : (
                      <span className="font-semibold text-[#0A0A0A]">
                        {formatCurrency(prod.price)}
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 tabular-nums">
                    <div className="inline-flex items-center gap-2 border border-neutral-200 px-2 py-1 rounded">
                      <button
                        type="button"
                        onClick={() => handleQuickStockChange(prod, -1)}
                        className="px-1 text-neutral-500 hover:text-[#0A0A0A] cursor-pointer"
                        aria-label="Decrease stock"
                      >
                        -
                      </button>
                      <span className="font-semibold min-w-[24px] text-center">
                        {prod.stock}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleQuickStockChange(prod, 1)}
                        className="px-1 text-neutral-500 hover:text-[#0A0A0A] cursor-pointer"
                        aria-label="Increase stock"
                      >
                        +
                      </button>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`font-medium ${
                        prod.isActive ? 'text-emerald-800' : 'text-neutral-400'
                      }`}
                    >
                      {prod.isActive ? 'Active' : 'Hidden'}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    {confirmDeleteId === prod.id ? (
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleDeleteProduct(prod.id)}
                          className="px-2.5 py-1 bg-red-600 text-white rounded text-[11px] font-semibold cursor-pointer"
                        >
                          Confirm
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="px-2.5 py-1 border border-neutral-300 rounded text-[11px] cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEditModal(prod)}
                          aria-label={`Edit ${prod.name}`}
                          className="p-2 text-neutral-600 hover:text-[#0A0A0A] hover:bg-neutral-100 rounded cursor-pointer"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(prod.id)}
                          aria-label={`Delete ${prod.name}`}
                          className="p-2 text-neutral-500 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Edit Modal */}
      {editingProduct && (
        <div
          className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white w-full max-w-5xl border border-neutral-200 shadow-2xl my-auto max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between sticky top-0 bg-white z-10">
              <h3 className="text-sm font-semibold uppercase tracking-wide">
                Edit Product — {editingProduct.name}
              </h3>
              <button
                type="button"
                onClick={resetForm}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 sm:p-6">{renderProductForm()}</div>
          </div>
        </div>
      )}
    </div>
  );
}
