import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Copy, 
  ArrowUp, 
  ArrowDown, 
  Edit3, 
  Check, 
  X, 
  Sparkles, 
  Search, 
  Upload, 
  FileSpreadsheet, 
  HelpCircle,
  BookOpen
} from 'lucide-react';
import { MCQQuestion } from '../../types';
import AdminBulkUploadModal from './AdminBulkUploadModal';

interface AdminQuestionManagerProps {
  language: string;
  questions: MCQQuestion[];
  subjects: string[];
  targetLevel: string;
  adminToken: string;
  onChangeQuestions: (questions: MCQQuestion[]) => void;
}

export default function AdminQuestionManager({
  language,
  questions,
  subjects,
  targetLevel,
  adminToken,
  onChangeQuestions
}: AdminQuestionManagerProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [showBulkModal, setShowBulkModal] = useState<boolean>(false);
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);

  // AI Generator state
  const [aiGenerating, setAiGenerating] = useState<boolean>(false);
  const [aiCount, setAiCount] = useState<number>(5);

  // Single Question Form State
  const [editingForm, setEditingForm] = useState<MCQQuestion | null>(null);

  const filteredQuestions = questions.filter(q => {
    if (selectedSubjectFilter !== 'all' && q.subject !== selectedSubjectFilter) return false;
    if (searchQuery.trim()) {
      const qLow = searchQuery.toLowerCase();
      return (
        q.question.toLowerCase().includes(qLow) ||
        q.explanation.toLowerCase().includes(qLow) ||
        q.options.some(o => o.toLowerCase().includes(qLow))
      );
    }
    return true;
  });

  const handleStartEdit = (q: MCQQuestion) => {
    setEditingQuestionId(q.id);
    setEditingForm({ ...q, options: [...q.options] });
  };

  const handleSaveEdit = () => {
    if (!editingForm) return;
    const updated = questions.map(q => q.id === editingForm.id ? editingForm : q);
    onChangeQuestions(updated);
    setEditingQuestionId(null);
    setEditingForm(null);
  };

  const handleCancelEdit = () => {
    setEditingQuestionId(null);
    setEditingForm(null);
  };

  const handleAddNewQuestion = () => {
    const newQ: MCQQuestion = {
      id: `wq-q-${Date.now()}`,
      question: 'নতুন প্রশ্ন এখানে লিখুন?',
      options: ['অপশন A', 'অপশন B', 'অপশন C', 'অপশন D'],
      correctOptionIndex: 0,
      explanation: 'বিশদ ও শিক্ষামূলক ব্যাখ্যা এখানে লিখুন...',
      subject: subjects[0] || 'General Knowledge',
      topic: '',
      difficulty: 'Medium'
    };
    const updated = [newQ, ...questions];
    onChangeQuestions(updated);
    handleStartEdit(newQ);
  };

  const handleDeleteQuestion = (id: string) => {
    onChangeQuestions(questions.filter(q => q.id !== id));
    if (editingQuestionId === id) {
      setEditingQuestionId(null);
      setEditingForm(null);
    }
  };

  const handleDuplicateQuestion = (q: MCQQuestion) => {
    const duplicated: MCQQuestion = {
      ...q,
      id: `wq-q-${Date.now()}`,
      question: `${q.question} (Copy)`
    };
    const idx = questions.findIndex(item => item.id === q.id);
    const newArr = [...questions];
    newArr.splice(idx + 1, 0, duplicated);
    onChangeQuestions(newArr);
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === questions.length - 1) return;
    
    const newArr = [...questions];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const temp = newArr[index];
    newArr[index] = newArr[targetIdx];
    newArr[targetIdx] = temp;
    onChangeQuestions(newArr);
  };

  // AI Question Generation Tool
  const handleGenerateAI = async () => {
    try {
      setAiGenerating(true);
      const res = await fetch('/api/admin/generate-questions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({
          subjects: subjects.length > 0 ? subjects : ['General Knowledge', 'History', 'Science'],
          count: aiCount,
          targetLevel,
          difficulty: 'Medium',
          language: language || 'bn'
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const data = await res.json();
      if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
        onChangeQuestions([...questions, ...data.questions]);
      } else {
        alert(language === 'bn' ? 'কোনো নতুন প্রশ্ন তৈরি করা যায়নি।' : 'No questions were returned.');
      }
    } catch (e: any) {
      console.error('AI Question Generator error:', e);
      alert(language === 'bn' ? 'প্রশ্ন তৈরিতে ত্রুটি দেখা দিয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।' : 'Failed to generate questions. Please try again.');
    } finally {
      setAiGenerating(false);
    }
  };

  return (
    <div className="space-y-4">
      
      {/* Question Header Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-800/80 p-4 rounded-2xl border border-slate-700">
        <div>
          <h4 className="text-sm font-black text-white flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-indigo-400" />
            {language === 'bn' ? 'প্রশ্নের তালিকা ও কাস্টম এডিটর' : 'Questions List & Editor'}
            <span className="px-2 py-0.5 bg-indigo-950 text-indigo-300 text-xs font-bold rounded-md">
              {questions.length} {language === 'bn' ? 'টি প্রশ্ন' : 'Questions'}
            </span>
          </h4>
          <p className="text-[11px] text-slate-400">
            {language === 'bn' ? 'প্রশ্ন তৈরি, অপশন নির্ধারণ, সঠিক উত্তর চিহ্নিতকরণ ও ক্রমবিন্যাস' : 'Add, edit, bulk upload, reorder and configure MCQs'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowBulkModal(true)}
            className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'বাল্ক আপলোড (CSV)' : 'Bulk CSV'}</span>
          </button>

          <button
            type="button"
            onClick={handleAddNewQuestion}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? '+ নতুন প্রশ্ন' : '+ Add Question'}</span>
          </button>
        </div>
      </div>

      {/* AI Generator Box */}
      <div className="bg-gradient-to-r from-purple-950/40 via-slate-900 to-indigo-950/40 border border-purple-500/30 p-3.5 rounded-2xl flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span className="text-xs font-black text-white">
            {language === 'bn' ? 'AI দিয়ে স্বয়ংক্রিয় প্রশ্ন জেনারেট করুন:' : 'AI Question Setter Tool:'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={aiCount}
            onChange={(e) => setAiCount(Number(e.target.value))}
            className="bg-slate-950 border border-purple-500/40 rounded-lg px-2.5 py-1 text-xs text-white"
          >
            <option value={5}>5 Questions</option>
            <option value={10}>10 Questions</option>
            <option value={15}>15 Questions</option>
            <option value={20}>20 Questions</option>
          </select>

          <button
            type="button"
            onClick={handleGenerateAI}
            disabled={aiGenerating}
            className="px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-black text-xs rounded-lg shadow-md cursor-pointer transition-all flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{aiGenerating ? (language === 'bn' ? 'জেনারেট হচ্ছে...' : 'Generating...') : (language === 'bn' ? 'জেনারেট' : 'Generate')}</span>
          </button>
        </div>
      </div>

      {/* Search & Subject Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setSelectedSubjectFilter('all')}
            className={`px-2.5 py-1 text-[11px] font-bold rounded-lg cursor-pointer transition-all ${
              selectedSubjectFilter === 'all' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            All Subjects
          </button>
          {subjects.map((sub, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setSelectedSubjectFilter(sub)}
              className={`px-2.5 py-1 text-[11px] font-bold rounded-lg cursor-pointer transition-all ${
                selectedSubjectFilter === sub ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-60">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search questions..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Questions List */}
      <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
        {filteredQuestions.length === 0 ? (
          <div className="p-8 text-center bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 text-slate-500 text-xs">
            {language === 'bn' ? 'কোনো প্রশ্ন পাওয়া যায়নি। উপরে + বাটনে ক্লিক করে প্রশ্ন যোগ করুন।' : 'No questions yet. Click + Add Question above.'}
          </div>
        ) : (
          filteredQuestions.map((q, idx) => {
            const isEditing = editingQuestionId === q.id;

            if (isEditing && editingForm) {
              return (
                <div key={q.id} className="bg-slate-900 border-2 border-indigo-500 rounded-2xl p-4 space-y-3 shadow-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-indigo-400">
                      Editing Question #{idx + 1}
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleSaveEdit}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-lg cursor-pointer flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Save</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleCancelEdit}
                        className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>

                  {/* Question Text */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-300">Question Text:</label>
                    <textarea
                      rows={2}
                      value={editingForm.question}
                      onChange={(e) => setEditingForm({ ...editingForm, question: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Options & Correct Answer Radio */}
                  <div className="space-y-2">
                    <label className="text-[11px] font-bold text-slate-300 block">
                      Options (Select the correct radio button):
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {editingForm.options.map((opt, oIdx) => (
                        <div 
                          key={oIdx}
                          className={`flex items-center gap-2 p-2 rounded-xl border ${
                            editingForm.correctOptionIndex === oIdx 
                              ? 'bg-emerald-950/40 border-emerald-500' 
                              : 'bg-slate-950 border-slate-800'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`correct-opt-${q.id}`}
                            checked={editingForm.correctOptionIndex === oIdx}
                            onChange={() => setEditingForm({ ...editingForm, correctOptionIndex: oIdx })}
                            className="text-emerald-500 focus:ring-emerald-500 cursor-pointer"
                          />
                          <span className="text-xs font-bold text-slate-400">Option {String.fromCharCode(65 + oIdx)}:</span>
                          <input
                            type="text"
                            value={opt}
                            onChange={(e) => {
                              const newOpts = [...editingForm.options];
                              newOpts[oIdx] = e.target.value;
                              setEditingForm({ ...editingForm, options: newOpts });
                            }}
                            className="w-full bg-transparent text-xs text-white focus:outline-none"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Explanation & Subject */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-300">Subject / Category:</label>
                      <select
                        value={editingForm.subject}
                        onChange={(e) => setEditingForm({ ...editingForm, subject: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                      >
                        {subjects.map((s, i) => (
                          <option key={i} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-300">Difficulty:</label>
                      <select
                        value={editingForm.difficulty || 'Medium'}
                        onChange={(e) => setEditingForm({ ...editingForm, difficulty: e.target.value as any })}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                      >
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-300">Detailed Explanation:</label>
                    <textarea
                      rows={2}
                      value={editingForm.explanation}
                      onChange={(e) => setEditingForm({ ...editingForm, explanation: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              );
            }

            return (
              <div 
                key={q.id}
                className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-2.5 transition-all text-xs"
              >
                {/* Header row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2">
                    <span className="p-1 bg-slate-800 text-slate-400 font-bold rounded text-[11px] shrink-0 mt-0.5">
                      #{idx + 1}
                    </span>
                    <div>
                      <p className="font-black text-white">{q.question}</p>
                      <span className="text-[10px] text-indigo-400 font-bold">{q.subject}</span>
                    </div>
                  </div>

                  {/* Reorder and action buttons */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleMove(idx, 'up')}
                      disabled={idx === 0}
                      className="p-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300 rounded cursor-pointer"
                      title="Move Up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleMove(idx, 'down')}
                      disabled={idx === questions.length - 1}
                      className="p-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300 rounded cursor-pointer"
                      title="Move Down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleStartEdit(q)}
                      className="p-1 bg-slate-800 hover:bg-slate-700 text-indigo-300 rounded cursor-pointer"
                      title="Edit Question"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDuplicateQuestion(q)}
                      className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded cursor-pointer"
                      title="Duplicate"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteQuestion(q.id)}
                      className="p-1 bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Options preview */}
                <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                  {q.options.map((opt, oIdx) => (
                    <div 
                      key={oIdx}
                      className={`px-2 py-1 rounded-lg border ${
                        oIdx === q.correctOptionIndex 
                          ? 'bg-emerald-950/40 border-emerald-500/80 text-emerald-300 font-bold' 
                          : 'bg-slate-950/60 border-slate-800/80 text-slate-400'
                      }`}
                    >
                      <span className="opacity-60">{String.fromCharCode(65 + oIdx)}.</span> {opt}
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bulk Upload Modal */}
      {showBulkModal && (
        <AdminBulkUploadModal
          language={language}
          onClose={() => setShowBulkModal(false)}
          onImport={(newQs) => {
            onChangeQuestions([...questions, ...newQs]);
          }}
        />
      )}

    </div>
  );
}
