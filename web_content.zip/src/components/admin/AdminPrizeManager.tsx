import React, { useState } from 'react';
import { 
  Gift, 
  Upload, 
  Image as ImageIcon, 
  Check, 
  Trash2, 
  Plus, 
  Sparkles,
  Trophy,
  DollarSign,
  Tag,
  FileText
} from 'lucide-react';
import { WeeklyQuiz, WeeklyPrizeItem } from '../../types';

export const PRIZE_PRESETS = [
  {
    name: 'Premium Notebook & Hardbound Planner Set',
    description: 'One luxury hardbound study planner, high-gsm notebook set with executive metallic pen for the Rank 1 winner.',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
    value: '₹750',
    position: '1st Prize'
  },
  {
    name: 'Executive Pen & Leather Journal Set',
    description: 'Engraved executive fountain pen with leatherette ruled journal for competitive exam preparation.',
    image: 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=600&q=80',
    value: '₹600',
    position: '1st Prize'
  },
  {
    name: 'Educational Reference Book Bundle',
    description: 'Comprehensive general knowledge & previous years solved guide book bundle for rank 1 student.',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=600&q=80',
    value: '₹1,200',
    position: '1st Prize'
  },
  {
    name: 'Scientific Smart Study Kit',
    description: 'Digital scientific timer, mathematical geometry instrument box and smart study highlighter set.',
    image: 'https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=600&q=80',
    value: '₹850',
    position: '1st Prize'
  }
];

interface AdminPrizeManagerProps {
  language: string;
  prizeName: string;
  prizeDescription: string;
  prizeImage?: string;
  prizeValue?: string;
  prizeQuantity?: number;
  prizePosition?: string;
  prizeTerms?: string;
  prizes?: WeeklyPrizeItem[];
  onChange: (fields: Partial<WeeklyQuiz>) => void;
}

export default function AdminPrizeManager({
  language,
  prizeName,
  prizeDescription,
  prizeImage,
  prizeValue,
  prizeQuantity,
  prizePosition,
  prizeTerms,
  prizes,
  onChange
}: AdminPrizeManagerProps) {
  const [imageTab, setImageTab] = useState<'presets' | 'upload' | 'url'>('presets');
  const [customUrl, setCustomUrl] = useState<string>('');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const base64 = evt.target?.result as string;
      if (base64) {
        onChange({ prizeImage: base64 });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = (preset: typeof PRIZE_PRESETS[0]) => {
    onChange({
      prizeName: preset.name,
      prizeDescription: preset.description,
      prizeImage: preset.image,
      prizeValue: preset.value,
      prizePosition: preset.position
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Prize Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border border-amber-500/40 p-4 rounded-2xl flex items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 rounded-xl font-black">
            <Gift className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm sm:text-base font-black text-white">
              {language === 'bn' ? 'পুরস্কার কনফিগারেশন ও ছবি আপলোড' : 'Prize Configuration & Custom Media'}
            </h4>
            <p className="text-[11px] text-slate-300">
              {language === 'bn' 
                ? 'হোম পেজের সাপ্তাহিক কুইজ কার্ডে স্বয়ংক্রিয়ভাবে এই পুরস্কার ও ছবি প্রদর্শিত হবে' 
                : 'Linked directly to the Home Page Weekly Quiz Challenge Card'}
            </p>
          </div>
        </div>
      </div>

      {/* Prize Primary Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Left Column: Form Info */}
        <div className="space-y-4 bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80">
          
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Gift className="w-3.5 h-3.5 text-amber-400" />
              {language === 'bn' ? 'পুরস্কারের নাম (Prize Name):' : 'Prize Name:'}
            </label>
            <input
              type="text"
              value={prizeName || ''}
              onChange={(e) => onChange({ prizeName: e.target.value })}
              placeholder="e.g. Premium Notebook Set"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">
              {language === 'bn' ? 'পুরস্কারের বিবরণ (Description):' : 'Prize Description:'}
            </label>
            <textarea
              rows={3}
              value={prizeDescription || ''}
              onChange={(e) => onChange({ prizeDescription: e.target.value })}
              placeholder="Detailed description of the physical prize..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                <DollarSign className="w-3 h-3 text-emerald-400" />
                {language === 'bn' ? 'আনুমানিক মূল্য:' : 'Prize Value:'}
              </label>
              <input
                type="text"
                value={prizeValue || '₹500'}
                onChange={(e) => onChange({ prizeValue: e.target.value })}
                placeholder="e.g. ₹750"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                <Trophy className="w-3 h-3 text-amber-400" />
                {language === 'bn' ? 'বিজয়ীর পজিশন:' : 'Winner Position:'}
              </label>
              <select
                value={prizePosition || '1st Prize'}
                onChange={(e) => onChange({ prizePosition: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
              >
                <option value="1st Prize">1st Prize (Rank 1)</option>
                <option value="Top 3">Top 3 Students</option>
                <option value="Top 5">Top 5 Students</option>
                <option value="Special">Special Award</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
              <FileText className="w-3 h-3 text-slate-400" />
              {language === 'bn' ? 'পুরস্কার প্রদান ও ডেলিভারির শর্তাবলী:' : 'Delivery Terms & Conditions:'}
            </label>
            <input
              type="text"
              value={prizeTerms || 'ফিজিক্যাল কুরিয়ারের মাধ্যমে বিজয়ীর ঠিকানায় পৌঁছানো হবে।'}
              onChange={(e) => onChange({ prizeTerms: e.target.value })}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-slate-300"
            />
          </div>

        </div>

        {/* Right Column: Image Manager */}
        <div className="space-y-4 bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80 flex flex-col justify-between">
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                {language === 'bn' ? 'পুরস্কারের ছবি (Prize Photo):' : 'Prize Image / Media:'}
              </label>

              {/* Image selector tabs */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-[10px]">
                <button
                  type="button"
                  onClick={() => setImageTab('presets')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${imageTab === 'presets' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400'}`}
                >
                  Presets
                </button>
                <button
                  type="button"
                  onClick={() => setImageTab('upload')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${imageTab === 'upload' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400'}`}
                >
                  Upload File
                </button>
                <button
                  type="button"
                  onClick={() => setImageTab('url')}
                  className={`px-2 py-0.5 rounded cursor-pointer ${imageTab === 'url' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400'}`}
                >
                  URL
                </button>
              </div>
            </div>

            {/* Current Image Preview */}
            <div className="relative rounded-2xl overflow-hidden border-2 border-amber-500/40 bg-slate-950 h-44 flex items-center justify-center group shadow-md">
              {prizeImage ? (
                <img
                  src={prizeImage}
                  alt={prizeName || 'Prize'}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center p-4 space-y-2 text-slate-500">
                  <Gift className="w-10 h-10 mx-auto text-slate-600" />
                  <p className="text-xs">{language === 'bn' ? 'কোনো ছবি সিলেক্ট করা নেই' : 'No prize photo selected'}</p>
                </div>
              )}
            </div>

            {/* Tab: Presets */}
            {imageTab === 'presets' && (
              <div className="grid grid-cols-2 gap-2">
                {PRIZE_PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className="p-2 bg-slate-900 hover:bg-slate-950 border border-slate-700 hover:border-amber-500/60 rounded-xl text-left flex items-center gap-2 cursor-pointer transition-all text-xs"
                  >
                    <img
                      src={preset.image}
                      alt={preset.name}
                      className="w-10 h-10 rounded-lg object-cover border border-slate-700 shrink-0"
                    />
                    <div className="truncate">
                      <span className="font-bold text-white block truncate text-[11px]">{preset.name}</span>
                      <span className="text-[10px] text-amber-300 font-medium">{preset.value}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Tab: Upload File */}
            {imageTab === 'upload' && (
              <div className="border border-dashed border-slate-700 rounded-xl p-4 text-center space-y-2 bg-slate-950/50">
                <Upload className="w-6 h-6 text-indigo-400 mx-auto" />
                <label className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg cursor-pointer inline-block">
                  {language === 'bn' ? 'গ্যালারি বা কম্পিউটার থেকে ফটো দিন' : 'Select Photo from Device'}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
                <p className="text-[10px] text-slate-500">PNG, JPG, WebP supported</p>
              </div>
            )}

            {/* Tab: Custom URL */}
            {imageTab === 'url' && (
              <div className="space-y-2">
                <input
                  type="text"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  placeholder="https://example.com/prize.jpg"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (customUrl.trim()) onChange({ prizeImage: customUrl.trim() });
                  }}
                  className="w-full py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-lg cursor-pointer"
                >
                  Set Image URL
                </button>
              </div>
            )}
          </div>

          <p className="text-[11px] text-slate-400 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
            💡 {language === 'bn' 
              ? 'টিপস: এই পুরস্কারের ছবি সরাসরি ইউজারের হোমপেজের উইকলি কুইজ কার্ডে ফুটে উঠবে।' 
              : 'Tip: This image will immediately reflect on the user home page Weekly Quiz card.'}
          </p>

        </div>

      </div>

    </div>
  );
}
