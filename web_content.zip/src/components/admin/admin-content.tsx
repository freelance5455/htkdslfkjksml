"use client";

import { useEffect, useState, type FormEvent } from "react";
import { CalendarCheck, CheckCircle2, Pencil, Plus, Trash2, UserRound, XCircle } from "lucide-react";
import { useI18n, useSite, useToast } from "@/components/providers";
import { ArticleCard, TipCard } from "@/components/cards";
import { Badge, Button, Card, CardSkeleton, Checkbox, EmptyState, ErrorState, Field, Input, LocalizedFields, Modal, Select, ServiceIcon, StatusBadge, Tabs, Textarea, SERVICE_ICON_OPTIONS } from "@/components/ui";
import { api } from "@/lib/api-client";
import { ARTICLE_KINDS, SERVICE_CATEGORIES, APPOINTMENT_STATUSES } from "@/lib/constants";
import type { AppointmentDTO, ArticleDTO, L10n, ProfessionalDTO, ServiceDTO } from "@/lib/types";
import { cn, formatDateTime, formatPrice, loc, slugify } from "@/lib/utils";

const emptyL10n = (): L10n => ({ fr: "", en: "", ar: "" });

/* ---------------------------- Articles & tips ---------------------------- */

interface ArticleForm {
  kind: "article" | "tip";
  slug: string;
  category: string;
  title: L10n;
  summary: L10n;
  body: L10n;
  emoji: string;
  readMinutes: number;
  reviewedBy: string;
  sources: string[];
  isPublished: boolean;
  isFeatured: boolean;
}

const blankArticle = (kind: "article" | "tip"): ArticleForm => ({
  kind,
  slug: "",
  category: "general-health",
  title: emptyL10n(),
  summary: emptyL10n(),
  body: emptyL10n(),
  emoji: kind === "tip" ? "💡" : "📘",
  readMinutes: 3,
  reviewedBy: "",
  sources: [],
  isPublished: true,
  isFeatured: false,
});

export function ArticlesSection() {
  const { categories, categoryName } = useSite();
  const { t, te } = useI18n();
  const toast = useToast();
  const [kind, setKind] = useState<"article" | "tip">("article");
  const [items, setItems] = useState<ArticleDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [editing, setEditing] = useState<ArticleDTO | null>(null);
  const [form, setForm] = useState<ArticleForm | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let alive = true;
    setError(false);
    setItems(null);
    api<{ articles: ArticleDTO[] }>(`/api/articles?all=1&kind=${kind}`)
      .then((r) => alive && setItems(r.articles))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [kind, reloadKey]);

  const openNew = () => {
    setEditing(null);
    setForm(blankArticle(kind));
  };
  const openEdit = (a: ArticleDTO) => {
    setEditing(a);
    setForm({
      kind: a.kind,
      slug: a.slug,
      category: a.category,
      title: a.title,
      summary: a.summary,
      body: a.body,
      emoji: a.emoji,
      readMinutes: a.readMinutes,
      reviewedBy: a.reviewedBy,
      sources: a.sources,
      isPublished: a.isPublished,
      isFeatured: a.isFeatured,
    });
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!form) return;
    if (form.title.fr.trim().length < 2) {
      toast.error(t("err.invalid_input"));
      return;
    }
    setSaving(true);
    const payload = {
      ...form,
      slug: undefined,
      sources: form.sources.map((s) => s.trim()).filter(Boolean),
      body: form.kind === "tip" ? emptyL10n() : form.body,
    };
    try {
      if (editing) {
        await api(`/api/articles/${editing.id}`, { method: "PATCH", body: payload });
      } else {
        await api("/api/articles", { body: { ...payload, slug: form.slug ? slugify(form.slug) : undefined } });
      }
      toast.success(t("adm.saved"));
      setForm(null);
      setReloadKey((k) => k + 1);
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (a: ArticleDTO) => {
    if (!window.confirm(t("adm.deleteConfirm"))) return;
    try {
      await api(`/api/articles/${a.id}`, { method: "DELETE" });
      setItems((prev) => prev?.filter((x) => x.id !== a.id) ?? null);
      toast.success(t("adm.deleted"));
    } catch (err) {
      toast.error(te(err));
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Tabs
          items={[
            { value: "article", label: t("adm.kindArticle") },
            { value: "tip", label: t("adm.kindTip") },
          ]}
          value={kind}
          onChange={setKind}
        />
        <Button variant="primary" onClick={openNew}>
          <Plus className="h-4 w-4" />
          {t("adm.newArticle")}
        </Button>
      </div>

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !items ? (
        <div className="grid gap-4 md:grid-cols-2">
          <CardSkeleton lines={3} />
          <CardSkeleton lines={3} />
        </div>
      ) : items.length === 0 ? (
        <EmptyState title={t("adm.noItems")} />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {items.map((a) => (
            <div key={a.id} className="relative flex flex-col">
              {a.kind === "tip" ? <TipCard tip={a} /> : <ArticleCard article={a} />}
              <div className="mt-2 flex flex-wrap items-center gap-2 px-1">
                {!a.isPublished && <Badge tone="amber">{t("common.disabled")}</Badge>}
                {a.isFeatured && <Badge tone="teal">{t("adm.featured")}</Badge>}
                {!a.reviewedBy && <Badge tone="slate">{t("art.reviewPending")}</Badge>}
                <div className="ms-auto flex gap-1">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(a)} aria-label={t("common.edit")}>
                    <Pencil className="h-4 w-4" />
                    {t("common.edit")}
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => void remove(a)} aria-label={t("common.delete")}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={editing ? t("adm.editArticle") : t("adm.newArticle")}
        wide
        footer={
          <>
            <Button variant="ghost" onClick={() => setForm(null)}>
              {t("common.cancel")}
            </Button>
            <Button variant="primary" loading={saving} onClick={(e) => void save(e as unknown as FormEvent)}>
              {t("common.save")}
            </Button>
          </>
        }
      >
        {form && (
          <form onSubmit={save} className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label={t("adm.kind")} htmlFor="a-kind">
                <Select id="a-kind" value={form.kind} disabled={!!editing} onChange={(e) => setForm({ ...form, kind: e.target.value as "article" | "tip" })}>
                  <option value="article">{t("adm.kindArticle")}</option>
                  <option value="tip">{t("adm.kindTip")}</option>
                </Select>
              </Field>
              <Field label={t("adm.topic")} htmlFor="a-cat">
                <Select id="a-cat" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  {categories.map((c) => (
                    <option key={c.slug} value={c.slug}>
                      {categoryName(c.slug)}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label={t("adm.emoji")} htmlFor="a-emoji">
                <Input id="a-emoji" value={form.emoji} maxLength={8} onChange={(e) => setForm({ ...form, emoji: e.target.value })} />
              </Field>
            </div>
            {!editing && (
              <Field label={t("adm.slug")} htmlFor="a-slug">
                <Input id="a-slug" dir="ltr" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
              </Field>
            )}
            <LocalizedFields label={t("adm.articleTitle")} value={form.title} onChange={(title) => setForm({ ...form, title })} />
            <LocalizedFields label={t("adm.summary")} value={form.summary} onChange={(summary) => setForm({ ...form, summary })} multiline rows={2} />
            {form.kind === "article" && (
              <LocalizedFields label={t("adm.content")} value={form.body} onChange={(body) => setForm({ ...form, body })} multiline rows={7} hint={t("adm.bodyHelp")} />
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("adm.articleSources")} htmlFor="a-src" className="sm:col-span-2">
                <Textarea
                  id="a-src"
                  rows={3}
                  dir="ltr"
                  value={form.sources.join("\n")}
                  onChange={(e) => setForm({ ...form, sources: e.target.value.split("\n").map((s) => s.trim()) })}
                />
              </Field>
              <Field label={t("adm.reviewer")} htmlFor="a-rev">
                <Input id="a-rev" value={form.reviewedBy} onChange={(e) => setForm({ ...form, reviewedBy: e.target.value })} />
              </Field>
              <Field label={t("adm.readMinutes")} htmlFor="a-read">
                <Input id="a-read" type="number" min={1} max={120} value={form.readMinutes} onChange={(e) => setForm({ ...form, readMinutes: Number(e.target.value) })} />
              </Field>
            </div>
            <div className="flex flex-wrap gap-6">
              <Checkbox id="a-pub" checked={form.isPublished} onChange={(v) => setForm({ ...form, isPublished: v })} label={t("adm.published")} />
              <Checkbox id="a-feat" checked={form.isFeatured} onChange={(v) => setForm({ ...form, isFeatured: v })} label={t("adm.featured")} />
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}

/* ---------------------------- Services ---------------------------- */

interface ServiceForm {
  slug: string;
  category: string;
  name: L10n;
  description: L10n;
  priceMad: number;
  durationMinutes: number;
  requiresVerifiedPro: boolean;
  icon: string;
  isFeatured: boolean;
  isActive: boolean;
}

const blankService = (): ServiceForm => ({
  slug: "",
  category: "nursing",
  name: emptyL10n(),
  description: emptyL10n(),
  priceMad: 200,
  durationMinutes: 60,
  requiresVerifiedPro: true,
  icon: "stethoscope",
  isFeatured: false,
  isActive: true,
});

export function ServicesSection() {
  const { t, te, locale } = useI18n();
  const toast = useToast();
  const [items, setItems] = useState<ServiceDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [editing, setEditing] = useState<ServiceDTO | null>(null);
  const [form, setForm] = useState<ServiceForm | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let alive = true;
    setError(false);
    api<{ services: ServiceDTO[] }>("/api/services?all=1")
      .then((r) => alive && setItems(r.services))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [reloadKey]);

  const openEdit = (s: ServiceDTO) => {
    setEditing(s);
    setForm({
      slug: s.slug,
      category: s.category,
      name: s.name,
      description: s.description,
      priceMad: s.priceMad,
      durationMinutes: s.durationMinutes,
      requiresVerifiedPro: s.requiresVerifiedPro,
      icon: s.icon,
      isFeatured: s.isFeatured,
      isActive: s.isActive,
    });
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!form) return;
    if (form.name.fr.trim().length < 2) {
      toast.error(t("err.invalid_input"));
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        const { slug: _slug, ...rest } = form;
        await api(`/api/services/${editing.id}`, { method: "PATCH", body: rest });
      } else {
        await api("/api/services", { body: { ...form, slug: form.slug ? slugify(form.slug) : undefined } });
      }
      toast.success(t("adm.saved"));
      setForm(null);
      setReloadKey((k) => k + 1);
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (s: ServiceDTO) => {
    if (!window.confirm(t("adm.deleteConfirm"))) return;
    try {
      const res = await api<{ archived: boolean }>(`/api/services/${s.id}`, { method: "DELETE" });
      toast.success(res.archived ? t("adm.archivedNote") : t("adm.deleted"));
      setReloadKey((k) => k + 1);
    } catch (err) {
      toast.error(te(err));
    }
  };

  const toggleActive = async (s: ServiceDTO) => {
    const previous = items;
    setItems((prev) => prev?.map((x) => (x.id === s.id ? { ...x, isActive: !x.isActive } : x)) ?? null);
    try {
      await api(`/api/services/${s.id}`, { method: "PATCH", body: { isActive: !s.isActive } });
    } catch (err) {
      setItems(previous);
      toast.error(te(err));
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <Button variant="primary" onClick={() => { setEditing(null); setForm(blankService()); }}>
          <Plus className="h-4 w-4" />
          {t("adm.newService")}
        </Button>
      </div>

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !items ? (
        <div className="grid gap-4 md:grid-cols-2">
          <CardSkeleton lines={3} />
          <CardSkeleton lines={3} />
        </div>
      ) : items.length === 0 ? (
        <EmptyState title={t("adm.noItems")} />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {items.map((s) => (
            <Card key={s.id} className={cn("flex flex-col gap-3 p-5", !s.isActive && "opacity-60")}>
              <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-sky-500 text-white">
                  <ServiceIcon name={s.icon} className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-slate-900">{loc(s.name, locale)}</p>
                  <p className="text-xs text-slate-500">{t(`scat.${s.category}`)} · <span className="font-mono">{s.slug}</span></p>
                </div>
              </div>
              <p className="line-clamp-2 text-sm text-slate-600">{loc(s.description, locale)}</p>
              <div className="flex flex-wrap gap-2 text-xs">
                <Badge tone="teal">{formatPrice(s.priceMad, locale)}</Badge>
                <Badge tone="sky">
                  {s.durationMinutes} {t("common.minutes")}
                </Badge>
                {s.isFeatured && <Badge tone="amber">{t("adm.featured")}</Badge>}
                {s.requiresVerifiedPro && <Badge tone="green">✓</Badge>}
              </div>
              <div className="mt-auto flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3">
                <Button variant="outline" size="sm" onClick={() => void toggleActive(s)}>
                  {s.isActive ? <XCircle className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
                  {s.isActive ? t("common.disabled") : t("common.active")}
                </Button>
                <Button variant="ghost" size="sm" onClick={() => openEdit(s)}>
                  <Pencil className="h-4 w-4" />
                  {t("common.edit")}
                </Button>
                <Button variant="danger" size="sm" onClick={() => void remove(s)} className="ms-auto">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={editing ? t("adm.editService") : t("adm.newService")}
        wide
        footer={
          <>
            <Button variant="ghost" onClick={() => setForm(null)}>
              {t("common.cancel")}
            </Button>
            <Button variant="primary" loading={saving} onClick={(e) => void save(e as unknown as FormEvent)}>
              {t("common.save")}
            </Button>
          </>
        }
      >
        {form && (
          <form onSubmit={save} className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label={t("adm.icon")} htmlFor="s-icon">
                <Select id="s-icon" value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })}>
                  {SERVICE_ICON_OPTIONS.map((i) => (
                    <option key={i} value={i}>
                      {i}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label={t("adm.serviceCategory")} htmlFor="s-cat">
                <Select id="s-cat" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  {SERVICE_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {t(`scat.${c}`)}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label={t("adm.slug")} htmlFor="s-slug">
                <Input id="s-slug" dir="ltr" value={form.slug} disabled={!!editing} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
              </Field>
            </div>
            <LocalizedFields label={t("common.name")} value={form.name} onChange={(name) => setForm({ ...form, name })} />
            <LocalizedFields label={t("svc.about")} value={form.description} onChange={(description) => setForm({ ...form, description })} multiline rows={3} />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("adm.priceMad")} htmlFor="s-price">
                <Input id="s-price" type="number" min={0} value={form.priceMad} onChange={(e) => setForm({ ...form, priceMad: Number(e.target.value) })} />
              </Field>
              <Field label={t("adm.durationMin")} htmlFor="s-dur">
                <Input id="s-dur" type="number" min={5} value={form.durationMinutes} onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })} />
              </Field>
            </div>
            <div className="flex flex-wrap gap-6">
              <Checkbox id="s-req" checked={form.requiresVerifiedPro} onChange={(v) => setForm({ ...form, requiresVerifiedPro: v })} label={t("adm.requiresVerified")} />
              <Checkbox id="s-feat" checked={form.isFeatured} onChange={(v) => setForm({ ...form, isFeatured: v })} label={t("adm.featured")} />
              <Checkbox id="s-act" checked={form.isActive} onChange={(v) => setForm({ ...form, isActive: v })} label={t("common.active")} />
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}

/* ---------------------------- Bookings ---------------------------- */

type BookingFilter = "all" | "unassigned" | (typeof APPOINTMENT_STATUSES)[number];

export function BookingsSection() {
  const { t, te, locale } = useI18n();
  const toast = useToast();
  const [filter, setFilter] = useState<BookingFilter>("all");
  const [items, setItems] = useState<AppointmentDTO[] | null>(null);
  const [pros, setPros] = useState<ProfessionalDTO[]>([]);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    api<{ professionals: ProfessionalDTO[] }>("/api/professionals")
      .then((r) => setPros(r.professionals))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    let alive = true;
    setError(false);
    const qs = new URLSearchParams();
    if (filter !== "all" && filter !== "unassigned") qs.set("status", filter);
    api<{ appointments: AppointmentDTO[] }>(`/api/appointments?${qs.toString()}`)
      .then((r) => alive && setItems(r.appointments))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [filter, reloadKey]);

  /** Optimistic status/assignment change with rollback. */
  const act = async (appt: AppointmentDTO, body: { action: "confirm" | "complete" | "cancel" | "assign"; professionalId?: string | null }) => {
    const previous = items;
    const optimistic: Partial<AppointmentDTO> = {};
    if (body.action === "confirm") optimistic.status = "confirmed";
    if (body.action === "complete") optimistic.status = "completed";
    if (body.action === "cancel") optimistic.status = "cancelled";
    if (body.action === "assign") {
      const pro = pros.find((p) => p.id === body.professionalId);
      optimistic.professionalId = body.professionalId ?? null;
      optimistic.professionalName = pro?.fullName ?? null;
    }
    setItems((prev) => prev?.map((a) => (a.id === appt.id ? { ...a, ...optimistic } : a)) ?? null);
    setBusyId(appt.id);
    try {
      const updated = await api<AppointmentDTO>(`/api/appointments/${appt.id}`, { method: "PATCH", body });
      setItems((prev) => prev?.map((a) => (a.id === appt.id ? updated : a)) ?? null);
      toast.success(t("appt.updated"));
    } catch (err) {
      setItems(previous);
      toast.error(te(err));
    } finally {
      setBusyId(null);
    }
  };

  const visible = (items ?? []).filter((a) => (filter === "unassigned" ? !a.professionalId && a.status !== "cancelled" : true));

  return (
    <div className="space-y-5">
      <Tabs
        items={[
          { value: "all", label: t("appt.filterAll") },
          { value: "unassigned", label: t("adm.unassigned") },
          { value: "pending", label: t("status.pending") },
          { value: "confirmed", label: t("status.confirmed") },
          { value: "completed", label: t("status.completed") },
          { value: "cancelled", label: t("status.cancelled") },
        ]}
        value={filter}
        onChange={setFilter}
      />
      {filter === "unassigned" && <p className="text-sm text-amber-800">{t("adm.unassignedNote")}</p>}

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !items ? (
        <div className="space-y-4">
          <CardSkeleton lines={3} />
          <CardSkeleton lines={3} />
        </div>
      ) : visible.length === 0 ? (
        <EmptyState icon={CalendarCheck} title={t("adm.noItems")} />
      ) : (
        <div className="space-y-4">
          {visible.map((a) => (
            <Card key={a.id} className={cn("p-5", busyId === a.id && "opacity-70")}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-xs text-slate-500">{a.reference}</p>
                  <p className="font-semibold text-slate-900">{loc(a.serviceName, locale)}</p>
                  <p className="text-sm text-slate-600">{formatDateTime(a.scheduledAt, locale)} · {a.city}</p>
                </div>
                <StatusBadge status={a.status} />
              </div>
              <div className="mt-4 grid gap-4 text-sm md:grid-cols-3">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("common.name")}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-slate-800">
                    <UserRound className="h-3.5 w-3.5 text-slate-400" />
                    {a.patientName}
                  </p>
                  <p className="text-xs text-slate-500" dir="ltr">
                    {a.phone}
                  </p>
                </div>
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("common.price")}</p>
                  <p className="mt-1 text-slate-800">{formatPrice(a.priceMad, locale)}</p>
                </div>
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{t("appt.professional")}</p>
                  {a.status === "cancelled" || a.status === "completed" ? (
                    <p className="mt-1 text-slate-800">{a.professionalName ?? t("adm.unassigned")}</p>
                  ) : (
                    <Select
                      value={a.professionalId ?? ""}
                      onChange={(e) => void act(a, { action: "assign", professionalId: e.target.value || null })}
                      className="mt-1 py-1.5 text-xs"
                      aria-label={t("adm.assign")}
                    >
                      <option value="">{t("adm.unassigned")}</option>
                      {pros.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.fullName} · {p.city}
                        </option>
                      ))}
                    </Select>
                  )}
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4">
                {a.status === "pending" && (
                  <Button variant="primary" size="sm" onClick={() => void act(a, { action: "confirm" })} disabled={busyId === a.id}>
                    <CheckCircle2 className="h-4 w-4" />
                    {t("appt.confirm")}
                  </Button>
                )}
                {a.status === "confirmed" && (
                  <Button variant="primary" size="sm" onClick={() => void act(a, { action: "complete" })} disabled={busyId === a.id}>
                    <CheckCircle2 className="h-4 w-4" />
                    {t("appt.complete")}
                  </Button>
                )}
                {(a.status === "pending" || a.status === "confirmed") && (
                  <Button
                    variant="danger"
                    size="sm"
                    disabled={busyId === a.id}
                    onClick={() => {
                      if (window.confirm(t("appt.cancelConfirm"))) void act(a, { action: "cancel" });
                    }}
                  >
                    {t("appt.cancel")}
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
