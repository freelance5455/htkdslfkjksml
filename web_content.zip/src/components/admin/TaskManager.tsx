import React, { useEffect, useState } from 'react';
import {
  CheckSquare,
  Plus,
  Search,
  Filter,
  Calendar,
  User,
  Clock,
  CheckCircle2,
  AlertTriangle,
  X,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { TaskItem, Employee, PriorityLevel, TaskStatus } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { sendNotification } from '../../utils/notificationHelper.ts';

export const TaskManager: React.FC = () => {
  const { currentOrg } = useAuth();
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assignedEmpId, setAssignedEmpId] = useState('');
  const [dueDate, setDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [priority, setPriority] = useState<PriorityLevel>('medium');

  const fetchTasksAndEmployees = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const tQuery = query(collection(db, 'tasks'), where('orgId', '==', currentOrg.id), limit(100));
      const tSnap = await getDocs(tQuery);
      const tList: TaskItem[] = [];
      tSnap.forEach((d) => tList.push(d.data() as TaskItem));
      tList.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
      setTasks(tList);

      const eQuery = query(collection(db, 'employees'), where('orgId', '==', currentOrg.id), limit(100));
      const eSnap = await getDocs(eQuery);
      const eList: Employee[] = [];
      eSnap.forEach((d) => eList.push(d.data() as Employee));
      setEmployees(eList);
      if (eList.length > 0 && !assignedEmpId) {
        setAssignedEmpId(eList[0].id);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasksAndEmployees();
  }, [currentOrg]);

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || !title || !assignedEmpId) return;

    const assignedEmp = employees.find((emp) => emp.id === assignedEmpId);
    const newTask: TaskItem = {
      id: `tsk_${Date.now()}`,
      orgId: currentOrg.id,
      title,
      description,
      priority,
      dueDate,
      status: 'pending',
      assignedEmployeeId: assignedEmpId,
      assignedEmployeeName: assignedEmp?.name || 'Technician',
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'tasks', newTask.id), removeUndefinedFields(newTask));

      // In-app notification for assigned technician
      if (assignedEmpId) {
        await sendNotification({
          orgId: currentOrg.id,
          userId: assignedEmpId,
          title: 'New Task Assigned',
          message: `You have been assigned task: "${title}". Due date: ${dueDate}.`,
          type: 'task',
        });
      }

      setTasks((prev) => [newTask, ...prev]);
      setIsModalOpen(false);
      setTitle('');
      setDescription('');
    } catch (err) {
      console.error(err);
    }
  };

  const updateStatus = async (task: TaskItem, newStatus: TaskStatus) => {
    const updated: TaskItem = {
      ...task,
      status: newStatus,
      completedAt: newStatus === 'completed' ? new Date().toISOString() : null,
    };
    try {
      await setDoc(doc(db, 'tasks', task.id), removeUndefinedFields(updated));
      setTasks((prev) => prev.map((t) => (t.id === task.id ? updated : t)));
    } catch (e) {
      console.error(e);
    }
  };

  const filteredTasks = tasks.filter((t) => {
    if (statusFilter === 'all') return true;
    return t.status === statusFilter;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-sky-600" />
            <span>Task Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Operational work orders, safety compliance checklists, and equipment maintenance tasks
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create Task</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs flex items-center gap-2 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'all' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          All Tasks ({tasks.length})
        </button>
        <button
          onClick={() => setStatusFilter('pending')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'pending' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          Pending ({tasks.filter((t) => t.status === 'pending').length})
        </button>
        <button
          onClick={() => setStatusFilter('in_progress')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'in_progress' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          In Progress ({tasks.filter((t) => t.status === 'in_progress').length})
        </button>
        <button
          onClick={() => setStatusFilter('completed')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'completed' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          Completed ({tasks.filter((t) => t.status === 'completed').length})
        </button>
      </div>

      {/* Task List Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-500 font-medium">Loading tasks...</div>
        ) : filteredTasks.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            No tasks found matching this status.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Task Title</th>
                  <th className="p-3.5">Assigned Technician</th>
                  <th className="p-3.5">Due Date</th>
                  <th className="p-3.5">Priority</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Quick Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTasks.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5">
                      <div className="font-bold text-slate-900">{t.title}</div>
                      {t.description && <div className="text-[11px] text-slate-500 mt-0.5">{t.description}</div>}
                    </td>
                    <td className="p-3.5 font-semibold text-slate-700">
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-sky-600" />
                        <span>{t.assignedEmployeeName}</span>
                      </div>
                    </td>
                    <td className="p-3.5 text-slate-600 font-medium">{t.dueDate}</td>
                    <td className="p-3.5">
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md uppercase ${
                          t.priority === 'urgent'
                            ? 'bg-red-100 text-red-800'
                            : t.priority === 'high'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                          t.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : t.status === 'in_progress'
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {t.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      {t.status !== 'completed' ? (
                        <button
                          onClick={() => updateStatus(t, 'completed')}
                          className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg font-bold text-[11px] inline-flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Mark Done</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => updateStatus(t, 'pending')}
                          className="text-slate-400 hover:text-slate-600 text-[11px] underline"
                        >
                          Reopen
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-base text-slate-900">Create Work Task</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Task Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Inspect Backup Generator Fuel Valve"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description / Checklist</label>
                <textarea
                  rows={2}
                  placeholder="Instructions for technician..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assign Technician *</label>
                  <select
                    value={assignedEmpId}
                    onChange={(e) => setAssignedEmpId(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  >
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Due Date</label>
                <input
                  type="date"
                  required
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Create Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
