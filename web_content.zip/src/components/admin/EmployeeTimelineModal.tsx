import React, { useState, useEffect } from 'react';
import {
  Clock,
  MapPin,
  CheckSquare,
  Calendar,
  Trophy,
  Activity,
  Filter,
  X,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Plus,
  Send,
  ShieldCheck,
  User,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  Employee,
  AttendanceRecord,
  FieldVisit,
  TaskItem,
  LeaveRequest,
  Award,
} from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export interface TimelineEvent {
  id: string;
  type: 'check_in' | 'check_out' | 'visit' | 'task' | 'leave' | 'award' | 'feedback';
  title: string;
  description: string;
  timestamp: string; // ISO string
  status?: string;
  badge?: string;
  badgeColor?: string;
}

interface EmployeeTimelineModalProps {
  employee: Employee;
  onClose: () => void;
  isTechnicianView?: boolean;
}

export const EmployeeTimelineModal: React.FC<EmployeeTimelineModalProps> = ({
  employee,
  onClose,
  isTechnicianView = false,
}) => {
  const { currentOrg, userProfile } = useAuth();
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'attendance' | 'visits' | 'tasks' | 'leave' | 'awards' | 'feedback'>('all');
  const [startDate, setStartDate] = useState(
    new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString().split('T')[0]
  );
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [page, setPage] = useState(1);
  const pageSize = 15;

  // New feedback note input
  const [newFeedbackText, setNewFeedbackText] = useState('');
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  const fetchTimelineData = async () => {
    if (!currentOrg || !employee.id) return;
    setLoading(true);
    try {
      const allEvents: TimelineEvent[] = [];

      // 1. Attendance Punches
      const attSnap = await getDocs(
        query(
          collection(db, 'attendance'),
          where('orgId', '==', currentOrg.id),
          where('employeeId', '==', employee.id),
          limit(60)
        )
      );
      attSnap.forEach((d) => {
        const att = d.data() as AttendanceRecord;
        if (att.checkInTime) {
          allEvents.push({
            id: `att_in_${att.id}`,
            type: 'check_in',
            title: 'Checked In On Shift',
            description: att.checkInAddress ? `Location: ${att.checkInAddress}` : 'Verified via GPS punch',
            timestamp: att.checkInTime,
            status: att.status || 'present',
            badge: 'PUNCH IN',
            badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          });
        }
        if (att.checkOutTime) {
          allEvents.push({
            id: `att_out_${att.id}`,
            type: 'check_out',
            title: 'Checked Out / Shift Concluded',
            description: `Duration: ${Math.floor((att.durationMinutes || 0) / 60)}h ${(att.durationMinutes || 0) % 60}m. ${att.checkOutAddress ? 'Location: ' + att.checkOutAddress : ''}`,
            timestamp: att.checkOutTime,
            status: 'completed',
            badge: 'PUNCH OUT',
            badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
          });
        }
      });

      // 2. Field Visits
      const visSnap = await getDocs(
        query(
          collection(db, 'visits'),
          where('orgId', '==', currentOrg.id),
          where('assignedEmployeeId', '==', employee.id),
          limit(60)
        )
      );
      visSnap.forEach((d) => {
        const vis = d.data() as FieldVisit;
        allEvents.push({
          id: `vis_${vis.id}`,
          type: 'visit',
          title: `Field Visit: ${vis.title}`,
          description: `Customer: ${vis.customerName}. Address: ${vis.siteAddress || 'Site'}.${vis.outcomeNotes ? ' Outcome: ' + vis.outcomeNotes : ''}`,
          timestamp: vis.completedAt || vis.startedAt || `${vis.scheduledDate}T${vis.scheduledTime || '09:00'}:00.000Z`,
          status: vis.status,
          badge: (vis.status || 'scheduled').replace(/_/g, ' ').toUpperCase(),
          badgeColor:
            vis.status === 'completed'
              ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
              : vis.status === 'in_progress'
              ? 'bg-sky-100 text-sky-800 border-sky-200'
              : 'bg-amber-100 text-amber-800 border-amber-200',
        });
      });

      // 3. Work Tasks
      const tskSnap = await getDocs(
        query(
          collection(db, 'tasks'),
          where('orgId', '==', currentOrg.id),
          where('assignedEmployeeId', '==', employee.id),
          limit(60)
        )
      );
      tskSnap.forEach((d) => {
        const tsk = d.data() as TaskItem;
        allEvents.push({
          id: `tsk_${tsk.id}`,
          type: 'task',
          title: `Task: ${tsk.title}`,
          description: tsk.description ? `${tsk.description} (Due: ${tsk.dueDate})` : `Due: ${tsk.dueDate}`,
          timestamp: tsk.completedAt || tsk.createdAt || new Date().toISOString(),
          status: tsk.status,
          badge: (tsk.status || 'pending').replace(/_/g, ' ').toUpperCase(),
          badgeColor:
            tsk.status === 'completed'
              ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
              : 'bg-slate-100 text-slate-700 border-slate-200',
        });
      });

      // 4. Leave Applications
      const lveSnap = await getDocs(
        query(
          collection(db, 'leave_requests'),
          where('orgId', '==', currentOrg.id),
          where('employeeId', '==', employee.id),
          limit(40)
        )
      );
      lveSnap.forEach((d) => {
        const lve = d.data() as LeaveRequest;
        allEvents.push({
          id: `lve_${lve.id}`,
          type: 'leave',
          title: `${lve.leaveType.toUpperCase()} Leave Request`,
          description: `Dates: ${lve.startDate} to ${lve.endDate}. Reason: ${lve.reason}.${lve.reviewedBy ? ' Reviewed by ' + lve.reviewedBy : ''}`,
          timestamp: lve.createdAt || new Date().toISOString(),
          status: lve.status,
          badge: lve.status.toUpperCase(),
          badgeColor:
            lve.status === 'approved'
              ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
              : lve.status === 'rejected'
              ? 'bg-rose-100 text-rose-800 border-rose-200'
              : 'bg-amber-100 text-amber-800 border-amber-200',
        });
      });

      // 5. Awards & Recognition
      const awdSnap = await getDocs(
        query(
          collection(db, 'awards'),
          where('orgId', '==', currentOrg.id),
          where('employeeId', '==', employee.id),
          limit(30)
        )
      );
      awdSnap.forEach((d) => {
        const awd = d.data() as Award;
        allEvents.push({
          id: `awd_${awd.id}`,
          type: 'award',
          title: `Award: ${awd.title} (${awd.period})`,
          description: `Commendation: ${awd.reason}. Awarded by ${awd.awardedBy}`,
          timestamp: awd.date ? `${awd.date}T12:00:00.000Z` : new Date().toISOString(),
          status: 'awarded',
          badge: 'RECOGNITION',
          badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
        });
      });

      // 6. Manager Feedback Notes (from audit_logs or feedback collection)
      const feedSnap = await getDocs(
        query(
          collection(db, 'audit_logs'),
          where('orgId', '==', currentOrg.id),
          where('targetId', '==', employee.id),
          where('module', '==', 'Manager Feedback'),
          limit(30)
        )
      );
      feedSnap.forEach((d) => {
        const f = d.data();
        allEvents.push({
          id: `feed_${f.id}`,
          type: 'feedback',
          title: `Manager Feedback by ${f.userName || 'Supervisor'}`,
          description: f.details || '',
          timestamp: f.timestamp || new Date().toISOString(),
          status: 'noted',
          badge: 'FEEDBACK',
          badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
        });
      });

      // Sort descending by timestamp
      allEvents.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
      setEvents(allEvents);
    } catch (e) {
      console.error('Error fetching employee timeline:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTimelineData();
  }, [currentOrg, employee.id]);

  // Submit new manager feedback
  const handleAddFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFeedbackText.trim() || !currentOrg) return;
    setSubmittingFeedback(true);

    try {
      const feedId = `aud_feed_${Date.now()}`;
      const newEntry = {
        id: feedId,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Manager',
        userRole: userProfile?.role || 'org_admin',
        action: 'SUPERVISOR_NOTE',
        module: 'Manager Feedback',
        details: newFeedbackText.trim(),
        targetId: employee.id,
        targetName: employee.name,
        timestamp: new Date().toISOString(),
      };

      await setDoc(doc(db, 'audit_logs', feedId), removeUndefinedFields(newEntry));

      setEvents((prev) => [
        {
          id: `feed_${feedId}`,
          type: 'feedback',
          title: `Manager Feedback by ${userProfile?.displayName || 'Manager'}`,
          description: newFeedbackText.trim(),
          timestamp: newEntry.timestamp,
          status: 'noted',
          badge: 'FEEDBACK',
          badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
        },
        ...prev,
      ]);
      setNewFeedbackText('');
    } catch (err) {
      console.error('Error submitting feedback:', err);
    } finally {
      setSubmittingFeedback(false);
    }
  };

  // Filtered events
  const filteredEvents = events.filter((ev) => {
    if (categoryFilter !== 'all') {
      if (categoryFilter === 'attendance' && ev.type !== 'check_in' && ev.type !== 'check_out') return false;
      if (categoryFilter === 'visits' && ev.type !== 'visit') return false;
      if (categoryFilter === 'tasks' && ev.type !== 'task') return false;
      if (categoryFilter === 'leave' && ev.type !== 'leave') return false;
      if (categoryFilter === 'awards' && ev.type !== 'award') return false;
      if (categoryFilter === 'feedback' && ev.type !== 'feedback') return false;
    }
    const evDate = ev.timestamp ? ev.timestamp.split('T')[0] : '';
    if (startDate && evDate && evDate < startDate) return false;
    if (endDate && evDate && evDate > endDate) return false;
    return true;
  });

  const totalPages = Math.ceil(filteredEvents.length / pageSize) || 1;
  const paginatedEvents = filteredEvents.slice((page - 1) * pageSize, page * pageSize);

  const getEventIcon = (type: TimelineEvent['type']) => {
    switch (type) {
      case 'check_in':
      case 'check_out':
        return <Clock className="w-4 h-4 text-emerald-600" />;
      case 'visit':
        return <MapPin className="w-4 h-4 text-sky-600" />;
      case 'task':
        return <CheckSquare className="w-4 h-4 text-amber-600" />;
      case 'leave':
        return <Calendar className="w-4 h-4 text-rose-600" />;
      case 'award':
        return <Trophy className="w-4 h-4 text-purple-600" />;
      case 'feedback':
        return <MessageSquare className="w-4 h-4 text-blue-600" />;
      default:
        return <Activity className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-0">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-sky-600 text-white font-bold text-sm flex items-center justify-center shrink-0 shadow-xs">
              {employee.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2 truncate">
                <span>{employee.name}</span>
                <span className="text-xs px-2 py-0.5 rounded-lg bg-sky-100 text-sky-800 font-mono font-normal">
                  {employee.employeeCode}
                </span>
              </h3>
              <p className="text-xs text-slate-500 truncate">
                {employee.designation || 'Field Technician'} • {employee.department || 'Operations'} • Activity Timeline
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter and Date Bar */}
        <div className="p-3 sm:p-4 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
          {/* Category Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-none p-0.5 bg-slate-100 rounded-xl">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'attendance', label: 'Punches' },
                { id: 'visits', label: 'Visits' },
                { id: 'tasks', label: 'Tasks' },
                { id: 'leave', label: 'Leave' },
                { id: 'awards', label: 'Awards' },
                { id: 'feedback', label: 'Feedback' },
              ] as const
            ).map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setCategoryFilter(cat.id);
                  setPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-bold shrink-0 transition-colors ${
                  categoryFilter === cat.id ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Date range */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setPage(1);
              }}
              className="p-1 border border-slate-200 rounded-lg text-[11px] text-slate-700 bg-slate-50"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setPage(1);
              }}
              className="p-1 border border-slate-200 rounded-lg text-[11px] text-slate-700 bg-slate-50"
            />
          </div>
        </div>

        {/* Timeline Events List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {loading ? (
            <div className="py-16 text-center text-xs text-slate-500 flex flex-col items-center justify-center gap-2">
              <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
              <span>Loading employee operational history...</span>
            </div>
          ) : paginatedEvents.length === 0 ? (
            <div className="py-16 text-center text-xs text-slate-400 space-y-1">
              <Activity className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-semibold text-slate-600">No events found</p>
              <p className="text-[11px]">No activity matches the selected category or date filters.</p>
            </div>
          ) : (
            <div className="relative border-l-2 border-slate-200 ml-4 pl-4 space-y-6">
              {paginatedEvents.map((ev) => (
                <div key={ev.id} className="relative group">
                  {/* Timeline Node Dot */}
                  <div className="absolute -left-[27px] top-0 w-6 h-6 rounded-full bg-white border-2 border-slate-300 flex items-center justify-center shadow-xs">
                    {getEventIcon(ev.type)}
                  </div>

                  {/* Event Content Box */}
                  <div className="bg-slate-50 group-hover:bg-slate-100/70 p-3 sm:p-3.5 rounded-2xl border border-slate-200 transition-colors space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-1.5">
                      <span className="font-bold text-xs text-slate-900">{ev.title}</span>
                      {ev.badge && (
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md border ${ev.badgeColor || 'bg-slate-200 text-slate-700'}`}>
                          {ev.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{ev.description}</p>
                    <div className="text-[10px] text-slate-400 font-mono pt-1">
                      {new Date(ev.timestamp).toLocaleString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Manager Feedback Form (Admin Only) */}
        {!isTechnicianView && (
          <div className="p-3 border-t border-slate-200 bg-slate-50">
            <form onSubmit={handleAddFeedback} className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Log manager feedback or supervisor commendation..."
                value={newFeedbackText}
                onChange={(e) => setNewFeedbackText(e.target.value)}
                className="flex-1 p-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-sky-500"
              />
              <button
                type="submit"
                disabled={submittingFeedback || !newFeedbackText.trim()}
                className="px-3.5 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Log Note</span>
              </button>
            </form>
          </div>
        )}

        {/* Pagination Footer */}
        <div className="p-3 border-t border-slate-200 bg-white flex items-center justify-between text-xs text-slate-500">
          <span>
            Showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, filteredEvents.length)} of {filteredEvents.length} events
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-1 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-bold text-slate-800 px-1">
              {page} / {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-1 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
