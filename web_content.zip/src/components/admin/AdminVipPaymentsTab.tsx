import React, { useState } from 'react';
import { 
  CreditCard, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search, 
  Filter, 
  Copy, 
  Check, 
  Eye, 
  X, 
  ShieldCheck, 
  AlertTriangle,
  ExternalLink,
  Smartphone
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VipPaymentRequest, PaymentStatus } from '../../types';

export const AdminVipPaymentsTab: React.FC = () => {
  const { vipPayments, approveVipPayment, rejectVipPayment, systemSettings } = useApp();

  const [filterStatus, setFilterStatus] = useState<'all' | PaymentStatus>('pending');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedUtr, setCopiedUtr] = useState<string | null>(null);
  
  // Selected screenshot for full-screen modal
  const [viewingScreenshot, setViewingScreenshot] = useState<string | null>(null);

  // Reject modal state
  const [rejectingPayment, setRejectingPayment] = useState<VipPaymentRequest | null>(null);
  const [rejectRemark, setRejectRemark] = useState('');

  // Confirmation modal for approval
  const [confirmApprovePayment, setConfirmApprovePayment] = useState<VipPaymentRequest | null>(null);

  const pendingCount = vipPayments.filter(p => p.status === 'pending').length;
  const approvedCount = vipPayments.filter(p => p.status === 'approved').length;
  const totalCollected = vipPayments
    .filter(p => p.status === 'approved')
    .reduce((sum, p) => sum + p.amountRupees, 0);

  const filteredPayments = vipPayments.filter(p => {
    if (filterStatus !== 'all' && p.status !== filterStatus) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return (
        p.userName.toLowerCase().includes(q) ||
        p.userEmail.toLowerCase().includes(q) ||
        p.utrNumber.toLowerCase().includes(q) ||
        p.planName.toLowerCase().includes(q) ||
        p.userId.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCopyUtr = (utr: string) => {
    navigator.clipboard.writeText(utr);
    setCopiedUtr(utr);
    setTimeout(() => setCopiedUtr(null), 2000);
  };

  const handleApproveConfirm = () => {
    if (!confirmApprovePayment) return;
    approveVipPayment(confirmApprovePayment.id);
    setConfirmApprovePayment(null);
  };

  const handleRejectConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectingPayment) return;
    rejectVipPayment(rejectingPayment.id, rejectRemark || 'Payment could not be verified in bank statement');
    setRejectingPayment(null);
    setRejectRemark('');
  };

  return (
    <div className="space-y-6">
      {/* Information Header Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-md">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/30">
            <CreditCard className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-black text-white">
              Pending VIP Payments & UTR Verification
            </h2>
            <p className="text-xs text-slate-400">
              Review user-submitted 12-digit UTR IDs and payment screenshots. Approving instantly unlocks the corresponding VIP plan for the user.
            </p>
          </div>
        </div>

        <div className="text-left sm:text-right shrink-0">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Merchant UPI ID
          </span>
          <span className="font-mono text-xs font-black text-amber-300">
            {systemSettings.adminUpiId || 'paytm.s19vihm@pty'}
          </span>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Pending Approvals
            </span>
            <span className="text-2xl font-black text-amber-500">
              {pendingCount}
            </span>
          </div>
          <div className="w-11 h-11 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-500 flex items-center justify-center">
            <Clock className="w-5 h-5 animate-pulse" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Approved Plans
            </span>
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              {approvedCount}
            </span>
          </div>
          <div className="w-11 h-11 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Total Verified Revenue
            </span>
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              ₹{totalCollected.toLocaleString()}
            </span>
          </div>
          <div className="w-11 h-11 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center">
            <CreditCard className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Status Filter Tabs */}
        <div className="flex gap-1.5 flex-wrap">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            All Submissions ({vipPayments.length})
          </button>
          <button
            onClick={() => setFilterStatus('pending')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
              filterStatus === 'pending'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            <span>Pending ({pendingCount})</span>
          </button>
          <button
            onClick={() => setFilterStatus('approved')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'approved'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            Approved ({approvedCount})
          </button>
          <button
            onClick={() => setFilterStatus('rejected')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'rejected'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            Rejected
          </button>
        </div>

        {/* Search */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by User, UTR, or Plan..."
            className="w-full pl-9 pr-4 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Payments Table / List */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-black text-slate-900 dark:text-slate-100">
            UPI Verification Requests
          </h3>
          <span className="text-xs text-slate-400">
            Showing {filteredPayments.length} of {vipPayments.length}
          </span>
        </div>

        {filteredPayments.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <p className="text-sm font-semibold text-slate-500">
              No payment records match your filters.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredPayments.map((p) => {
              const dateStr = new Date(p.createdAt).toLocaleString(undefined, {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={p.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                >
                  {/* Left: User & Plan Info */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-black text-slate-900 dark:text-slate-100 text-sm">
                        {p.planName}
                      </span>
                      <span className="text-emerald-600 dark:text-emerald-400 font-extrabold text-sm">
                        ₹{p.amountRupees}
                      </span>
                    </div>

                    <div className="text-xs text-slate-500 dark:text-slate-400 space-y-0.5">
                      <p>
                        User: <strong className="text-slate-800 dark:text-slate-200">{p.userName}</strong> ({p.userEmail})
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        User ID: {p.userId} • Date: {dateStr}
                      </p>
                    </div>
                  </div>

                  {/* Middle: UTR & Screenshot */}
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-0.5 min-w-[200px]">
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">
                        UTR / Transaction ID
                      </span>
                      <div className="flex items-center justify-between gap-2 font-mono text-xs font-bold text-slate-900 dark:text-slate-100">
                        <span>{p.utrNumber}</span>
                        <button
                          type="button"
                          onClick={() => handleCopyUtr(p.utrNumber)}
                          className="text-slate-400 hover:text-purple-600 cursor-pointer"
                          title="Copy UTR"
                        >
                          {copiedUtr === p.utrNumber ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Screenshot thumbnail if available */}
                    {p.screenshotUrl ? (
                      <button
                        type="button"
                        onClick={() => setViewingScreenshot(p.screenshotUrl || null)}
                        className="relative group w-12 h-12 rounded-xl overflow-hidden border border-slate-300 dark:border-slate-700 shrink-0 cursor-pointer"
                        title="Click to view full screenshot"
                      >
                        <img 
                          src={p.screenshotUrl} 
                          alt="Proof" 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                          <Eye className="w-4 h-4" />
                        </div>
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400 italic px-2">
                        No image
                      </span>
                    )}
                  </div>

                  {/* Right: Status & Actions */}
                  <div className="flex items-center gap-2 justify-end">
                    {p.status === 'pending' ? (
                      <>
                        <button
                          type="button"
                          onClick={() => setConfirmApprovePayment(p)}
                          className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Approve & Unlock</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setRejectingPayment(p)}
                          className="px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 font-bold text-xs transition-colors cursor-pointer"
                        >
                          Reject
                        </button>
                      </>
                    ) : p.status === 'approved' ? (
                      <span className="px-3 py-1.5 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Approved</span>
                      </span>
                    ) : (
                      <span className="px-3 py-1.5 rounded-xl bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-800 text-xs font-bold flex items-center gap-1">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Rejected</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Screenshot Zoom Modal */}
      {viewingScreenshot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative max-w-2xl max-h-[90vh] bg-white dark:bg-slate-900 p-3 rounded-3xl shadow-2xl">
            <button
              onClick={() => setViewingScreenshot(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white hover:bg-black cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <img 
              src={viewingScreenshot} 
              alt="Payment receipt proof" 
              className="max-h-[82vh] w-auto mx-auto rounded-2xl object-contain"
            />
          </div>
        </div>
      )}

      {/* Confirm Approve Modal */}
      {confirmApprovePayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                Confirm Approval & Unlock VIP?
              </h3>
              <p className="text-xs text-slate-500">
                Confirming will immediately activate <strong>{confirmApprovePayment.planName}</strong> for <strong>{confirmApprovePayment.userName}</strong> and unlock their daily VIP tasks.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Amount:</span>
                <span className="font-bold text-emerald-600">₹{confirmApprovePayment.amountRupees}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">UTR:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{confirmApprovePayment.utrNumber}</span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmApprovePayment(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-bold text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApproveConfirm}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md cursor-pointer"
              >
                Yes, Approve & Unlock
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {rejectingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
          <form onSubmit={handleRejectConfirm} className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                Reject VIP Payment Submission
              </h3>
              <p className="text-xs text-slate-500">
                Rejecting submission for {rejectingPayment.userName} (UTR: {rejectingPayment.utrNumber}).
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Reason for Rejection:
              </label>
              <input
                type="text"
                required
                value={rejectRemark}
                onChange={(e) => setRejectRemark(e.target.value)}
                placeholder="e.g. UTR not found in bank statement, amount mismatch..."
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => { setRejectingPayment(null); setRejectRemark(''); }}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-bold text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md cursor-pointer"
              >
                Reject Payment
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
