import React, { useEffect, useState, useRef } from 'react';
import { X, Calendar, Clock, MapPin, Navigation, ShieldCheck, ChevronRight, AlertCircle, RefreshCw } from 'lucide-react';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { LocationHistoryPoint } from '../../types/index.ts';
import { GOOGLE_MAPS_TILE_PROVIDERS } from '../../utils/googleMapsLoader.ts';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface LocationHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  employeeId: string;
  employeeName: string;
}

export const LocationHistoryModal: React.FC<LocationHistoryModalProps> = ({
  isOpen,
  onClose,
  employeeId,
  employeeName,
}) => {
  const { currentOrg } = useAuth();
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [historyPoints, setHistoryPoints] = useState<LocationHistoryPoint[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPoint, setSelectedPoint] = useState<LocationHistoryPoint | null>(null);

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const polylineRef = useRef<L.Polyline | null>(null);

  const fetchHistory = async () => {
    if (!currentOrg || !employeeId) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'location_history'),
        where('orgId', '==', currentOrg.id),
        where('employeeId', '==', employeeId),
        limit(150)
      );
      const snap = await getDocs(q);
      const list: LocationHistoryPoint[] = [];
      snap.forEach((d) => {
        const pt = d.data() as LocationHistoryPoint;
        if (pt.timestamp.startsWith(selectedDate)) {
          list.push(pt);
        }
      });

      // Sort chronologically ascending
      list.sort((a, b) => a.timestamp.localeCompare(b.timestamp));
      setHistoryPoints(list);
      setSelectedPoint(list[list.length - 1] || null);
    } catch (err) {
      console.error('Error fetching location history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchHistory();
    }
  }, [isOpen, employeeId, selectedDate, currentOrg]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!isOpen || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [37.7749, -122.4194],
        zoom: 13,
        zoomControl: true,
      });

      const googleRoadmap = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.roadmap.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.subdomains,
      });

      const googleSatellite = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.satellite.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.satellite.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.satellite.subdomains,
      });

      googleRoadmap.addTo(map);

      L.control.layers(
        {
          'Google Maps': googleRoadmap,
          'Satellite': googleSatellite,
        },
        undefined,
        { position: 'topright' }
      ).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    // Invalidate size after modal render animation
    const timer = setTimeout(() => {
      mapInstanceRef.current?.invalidateSize();
    }, 200);

    return () => {
      clearTimeout(timer);
    };
  }, [isOpen]);

  // Update map markers and polyline when history points change
  useEffect(() => {
    if (!mapInstanceRef.current || !markersLayerRef.current) return;

    markersLayerRef.current.clearLayers();
    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }

    if (historyPoints.length === 0) return;

    const latLngs: [number, number][] = historyPoints.map((pt) => [pt.lat, pt.lng]);

    // Draw route polyline
    polylineRef.current = L.polyline(latLngs, {
      color: '#0284c7',
      weight: 4,
      opacity: 0.8,
      dashArray: '6, 6',
    }).addTo(mapInstanceRef.current);

    // Place markers
    historyPoints.forEach((pt, index) => {
      const isStart = index === 0;
      const isEnd = index === historyPoints.length - 1;
      const isVisit = pt.eventType === 'visit_start' || pt.eventType === 'visit_complete';

      const color = isStart ? '#10b981' : isEnd ? '#ef4444' : isVisit ? '#8b5cf6' : '#0284c7';
      const label = isStart ? 'S' : isEnd ? 'E' : isVisit ? 'V' : String(index + 1);

      const customIcon = L.divIcon({
        className: 'custom-history-marker',
        html: `
          <div style="background-color: ${color}; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 11px; border: 2px solid white; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3);">
            ${label}
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const marker = L.marker([pt.lat, pt.lng], { icon: customIcon });
      marker.bindPopup(`
        <div style="font-family: sans-serif; font-size: 12px; line-height: 1.4;">
          <strong>${new Date(pt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong><br/>
          <span style="text-transform: capitalize; color: #475569;">${pt.eventType?.replace('_', ' ') || 'Waypoint'}</span>
          ${pt.notes ? `<br/><em>${pt.notes}</em>` : ''}
          ${pt.accuracy ? `<br/><span style="color: #64748b; font-size: 10px;">Accuracy: ±${pt.accuracy}m</span>` : ''}
        </div>
      `);
      marker.on('click', () => setSelectedPoint(pt));
      markersLayerRef.current?.addLayer(marker);
    });

    // Fit bounds to show entire route
    const bounds = L.latLngBounds(latLngs);
    mapInstanceRef.current.fitBounds(bounds, { padding: [40, 40] });
  }, [historyPoints]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden flex flex-col max-h-[95vh] animate-in fade-in-0 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center">
              <Navigation className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                <span>Location Route History</span>
                <span className="text-slate-400">·</span>
                <span className="text-sky-600 font-extrabold">{employeeName}</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Verified GPS timeline & travel path for workforce accountability
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 font-semibold text-slate-700 bg-white"
            />
            <button
              onClick={fetchHistory}
              disabled={loading}
              className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg border border-slate-200 bg-white"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body: Map on top/left, Waypoint Timeline on side */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-[380px]">
          {/* Map canvas */}
          <div className="relative flex-1 min-h-[260px] md:min-h-[420px] bg-slate-100">
            <div ref={mapContainerRef} className="w-full h-full" />
            {loading && (
              <div className="absolute inset-0 bg-white/70 backdrop-blur-xs flex items-center justify-center z-[1000]">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-white px-4 py-2 rounded-xl shadow-md border border-slate-200">
                  <RefreshCw className="w-4 h-4 animate-spin text-sky-600" />
                  <span>Loading route GPS points...</span>
                </div>
              </div>
            )}
            {!loading && historyPoints.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[1000]">
                <div className="bg-white/90 px-4 py-3 rounded-2xl shadow-md border border-slate-200 text-center space-y-1">
                  <AlertCircle className="w-6 h-6 text-amber-500 mx-auto" />
                  <div className="text-xs font-bold text-slate-800">No Location Points Recorded</div>
                  <div className="text-[11px] text-slate-500">
                    No active GPS trail logged for {employeeName} on {selectedDate}.
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Timeline List */}
          <div className="w-full md:w-80 border-t md:border-t-0 md:border-l border-slate-200 bg-slate-50/50 p-3 overflow-y-auto max-h-60 md:max-h-[450px]">
            <div className="text-xs font-bold text-slate-700 mb-2 flex items-center justify-between">
              <span>Trail Points ({historyPoints.length})</span>
              <span className="text-[10px] text-slate-400">Chronological</span>
            </div>

            {historyPoints.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-400">
                Select another date to view historical travel breadcrumbs.
              </div>
            ) : (
              <div className="space-y-1.5">
                {historyPoints.map((pt, idx) => {
                  const isSelected = selectedPoint?.id === pt.id;
                  const timeStr = new Date(pt.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                  });

                  return (
                    <div
                      key={pt.id}
                      onClick={() => {
                        setSelectedPoint(pt);
                        mapInstanceRef.current?.setView([pt.lat, pt.lng], 16, { animate: true });
                      }}
                      className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-sky-50 border-sky-300 shadow-xs'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800 capitalize flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-sky-500" />
                          <span>{pt.eventType?.replace('_', ' ') || `Point ${idx + 1}`}</span>
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">{timeStr}</span>
                      </div>
                      {pt.notes && (
                        <div className="text-[11px] text-slate-600 mt-1 italic">&ldquo;{pt.notes}&rdquo;</div>
                      )}
                      <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                        <span>
                          {pt.lat.toFixed(4)}, {pt.lng.toFixed(4)}
                        </span>
                        {pt.accuracy && <span>±{pt.accuracy}m</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer info note */}
        <div className="px-4 py-2.5 bg-slate-100 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Factual GPS trail data collected during employee work shift for authorized operations.</span>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-white hover:bg-slate-200 text-slate-700 font-bold rounded-lg border border-slate-300 text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
