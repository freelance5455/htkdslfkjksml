import React, { useEffect, useState } from 'react';
import {
  Users,
  Plus,
  Upload,
  Download,
  Search,
  Filter,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  X,
  Edit,
  Trash2,
  ChevronLeft,
  ChevronRight,
  UserMinus,
  UserCheck,
  ShieldAlert,
  History,
  AlertTriangle,
  Clock,
  Lock,
  Activity,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, deleteDoc, updateDoc, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Employee, EmploymentStatus, AuditLogEntry, CompanyJoinRequest } from '../../types/index.ts';
import { BulkImportModal } from './BulkImportModal.tsx';
import { ImportHistoryModal } from './ImportHistoryModal.tsx';
import { EmployeeTimelineModal } from './EmployeeTimelineModal.tsx';
import { exportToCsv } from '../../utils/csvHelper.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { sendNotification } from '../../utils/notificationHelper.ts';

export const EmployeeManager: React.FC = () => {
  const { currentOrg, userProfile, isPlatformOwner, isAdmin, reauthenticateAdmin } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [statusTab, setStatusTab] = useState<'active' | 'former' | 'inactive' | 'requests' | 'all'>('active');

  // Join Requests State
  const [joinRequests, setJoinRequests] = useState<CompanyJoinRequest[]>([]);
  const [rejectingReq, setRejectingReq] = useState<CompanyJoinRequest | null>(null);
  const [rejectionReasonText, setRejectionReasonText] = useState('');
  const [processingReqId, setProcessingReqId] = useState<string | null>(null);

  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [timelineEmp, setTimelineEmp] = useState<Employee | null>(null);

  // Add / Edit Modal
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formDept, setFormDept] = useState('HVAC Operations');
  const [formDesignation, setFormDesignation] = useState('Field Technician');
  const [formTerritory, setFormTerritory] = useState('Central District');
  const [formManager, setFormManager] = useState(userProfile?.displayName || 'Operations Lead');
  const [formEmergency, setFormEmergency] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formStatus, setFormStatus] = useState<EmploymentStatus>('active');

  // Deactivate / Left Company Modal
  const [leavingEmp, setLeavingEmp] = useState<Employee | null>(null);
  const [leavingDate, setLeavingDate] = useState(new Date().toISOString().split('T')[0]);
  const [leavingReason, setLeavingReason] = useState<'resignation' | 'retirement' | 'termination' | 'contract_ended' | 'other'>('resignation');
  const [leavingNotes, setLeavingNotes] = useState('');
  const [processingStatus, setProcessingStatus] = useState(false);

  // Reactivate confirmation modal
  const [reactivatingEmp, setReactivatingEmp] = useState<Employee | null>(null);

  // Permanent Delete Modal (Safeguarded)
  const [deletingEmp, setDeletingEmp] = useState<Employee | null>(null);
  const [authPin, setAuthPin] = useState('');
  const [authError, setAuthError] = useState('');

  // Pagination
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const fetchEmployees = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'employees'),
        where('orgId', '==', currentOrg.id),
        limit(10000)
      );
      const snap = await getDocs(q);
      const list: Employee[] = [];
      snap.forEach((d) => list.push(d.data() as Employee));
      list.sort((a, b) => a.name.localeCompare(b.name));
      setEmployees(list);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const fetchJoinRequests = async () => {
    if (!currentOrg) return;
    try {
      const q = query(collection(db, 'company_join_requests'), where('orgId', '==', currentOrg.id));
      const snap = await getDocs(q);
      const list: CompanyJoinRequest[] = [];
      snap.forEach((d) => list.push(d.data() as CompanyJoinRequest));
      list.sort((a, b) => b.requestedAt.localeCompare(a.requestedAt));
      setJoinRequests(list);
    } catch (e) {
      console.error('Error fetching join requests:', e);
    }
  };

  useEffect(() => {
    fetchEmployees();
    fetchJoinRequests();
  }, [currentOrg]);

  const handleApproveRequest = async (req: CompanyJoinRequest) => {
    if (!currentOrg) return;
    setProcessingReqId(req.id);
    try {
      const empId = `emp_${Date.now()}`;
      const newEmp: Employee = {
        id: empId,
        orgId: currentOrg.id,
        employeeCode: `EMP-${1000 + employees.length + 1}`,
        name: req.userName,
        email: req.userEmail.toLowerCase(),
        phone: req.userPhone || '+1 555-0100',
        department: 'Field Operations',
        designation: 'Field Technician',
        territory: 'Primary Territory',
        managerName: userProfile?.displayName || 'Operations Manager',
        emergencyContact: 'Main Office Desk',
        status: 'active',
        joiningDate: new Date().toISOString().split('T')[0],
        userId: req.userId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'employees', empId), removeUndefinedFields(newEmp));

      // Update user profile in Firestore
      try {
        await updateDoc(doc(db, 'users', req.userId), {
          organizationId: currentOrg.id,
          employeeId: empId,
          role: 'employee',
        });
      } catch (e) {
        console.warn('Could not update user document directly:', e);
      }

      // Update request status
      await updateDoc(doc(db, 'company_join_requests', req.id), {
        status: 'approved',
        reviewedAt: new Date().toISOString(),
        reviewedBy: userProfile?.id || 'admin',
        reviewedByName: userProfile?.displayName || 'Administrator',
      });

      // Send notification to technician
      await sendNotification({
        orgId: currentOrg.id,
        userId: req.userId,
        title: 'Join Request Approved!',
        message: `Welcome to ${currentOrg.name}! Your field technician workspace access has been approved.`,
        type: 'join_request',
        linkTab: 'home',
      });

      // Audit log
      const auditLog: AuditLogEntry = {
        id: `aud_join_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        userRole: 'org_admin',
        action: 'APPROVE_JOIN_REQUEST',
        module: 'Workforce',
        details: `Approved join request for ${req.userName} (${req.userEmail}). Created employee profile ${empId}.`,
        targetId: empId,
        targetName: req.userName,
        result: 'success',
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setEmployees((prev) => [newEmp, ...prev]);
      setJoinRequests((prev) =>
        prev.map((r) => (r.id === req.id ? { ...r, status: 'approved' } : r))
      );
    } catch (err: any) {
      console.error('Error approving join request:', err);
      alert(err?.message || 'Failed to approve join request.');
    } finally {
      setProcessingReqId(null);
    }
  };

  const handleConfirmRejectRequest = async () => {
    if (!rejectingReq || !currentOrg) return;
    setProcessingReqId(rejectingReq.id);
    try {
      await updateDoc(doc(db, 'company_join_requests', rejectingReq.id), {
        status: 'rejected',
        rejectionReason: rejectionReasonText.trim() || 'Application was not approved at this time.',
        reviewedAt: new Date().toISOString(),
        reviewedBy: userProfile?.id || 'admin',
        reviewedByName: userProfile?.displayName || 'Administrator',
      });

      await sendNotification({
        orgId: currentOrg.id,
        userId: rejectingReq.userId,
        title: 'Join Request Update',
        message: `Your request to join ${currentOrg.name} was not approved.${
          rejectionReasonText ? ` Reason: ${rejectionReasonText}` : ''
        }`,
        type: 'join_request',
        linkTab: 'profile',
      });

      // Audit log
      const auditLog: AuditLogEntry = {
        id: `aud_rej_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        userRole: 'org_admin',
        action: 'REJECT_JOIN_REQUEST',
        module: 'Workforce',
        details: `Rejected join request for ${rejectingReq.userName} (${rejectingReq.userEmail}).`,
        targetId: rejectingReq.id,
        targetName: rejectingReq.userName,
        result: 'warning',
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setJoinRequests((prev) =>
        prev.map((r) =>
          r.id === rejectingReq.id
            ? {
                ...r,
                status: 'rejected',
                rejectionReason: rejectionReasonText.trim() || undefined,
              }
            : r
        )
      );
      setRejectingReq(null);
      setRejectionReasonText('');
    } catch (err: any) {
      console.error('Error rejecting join request:', err);
      alert(err?.message || 'Failed to reject join request.');
    } finally {
      setProcessingReqId(null);
    }
  };

  const handleSaveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || !formName || !formEmail) return;

    const id = editingEmp ? editingEmp.id : `emp_${Date.now()}`;
    const empData: Employee = {
      id,
      orgId: currentOrg.id,
      employeeCode: formCode || `EMP-${1000 + employees.length + 1}`,
      name: formName,
      email: formEmail.toLowerCase(),
      phone: formPhone,
      department: formDept,
      designation: formDesignation,
      territory: formTerritory,
      managerName: formManager,
      emergencyContact: formEmergency,
      notes: formNotes,
      status: formStatus,
      joiningDate: editingEmp ? editingEmp.joiningDate : new Date().toISOString().split('T')[0],
      createdAt: editingEmp ? editingEmp.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ...(editingEmp?.leavingDetails ? { leavingDetails: editingEmp.leavingDetails } : {}),
    };

    try {
      await setDoc(doc(db, 'employees', id), removeUndefinedFields(empData), { merge: true });

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_emp_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: editingEmp ? 'Update Employee Profile' : 'Create Employee Profile',
        module: 'Workforce',
        details: `${editingEmp ? 'Updated' : 'Created'} profile for ${formName} (${formCode}).`,
        targetId: id,
        targetName: formName,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      if (editingEmp) {
        setEmployees((prev) => prev.map((emp) => (emp.id === id ? empData : emp)));
      } else {
        setEmployees((prev) => [empData, ...prev]);
      }
      setIsAddModalOpen(false);
      setEditingEmp(null);
      resetForm();
    } catch (err) {
      console.error('Error saving employee:', err);
    }
  };

  const resetForm = () => {
    setFormName('');
    setFormEmail('');
    setFormCode('');
    setFormPhone('');
    setFormDept('HVAC Operations');
    setFormDesignation('Field Technician');
    setFormTerritory('Central District');
    setFormManager(userProfile?.displayName || 'Operations Lead');
    setFormEmergency('');
    setFormNotes('');
    setFormStatus('active');
  };

  const openEdit = (emp: Employee) => {
    setEditingEmp(emp);
    setFormName(emp.name);
    setFormEmail(emp.email);
    setFormCode(emp.employeeCode);
    setFormPhone(emp.phone);
    setFormDept(emp.department);
    setFormDesignation(emp.designation);
    setFormTerritory(emp.territory);
    setFormManager(emp.managerName);
    setFormEmergency(emp.emergencyContact);
    setFormNotes(emp.notes || '');
    setFormStatus(emp.status);
    setIsAddModalOpen(true);
  };

  // Confirm Mark as Left Company
  const handleConfirmMarkAsLeft = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leavingEmp || !currentOrg) return;
    setProcessingStatus(true);

    try {
      const updatedEmp: Employee = {
        ...leavingEmp,
        status: 'left_company',
        leavingDetails: {
          leavingDate,
          reasonCategory: leavingReason,
          notes: leavingNotes,
          recordedBy: userProfile?.displayName || 'Admin',
          recordedAt: new Date().toISOString(),
        },
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'employees', leavingEmp.id), removeUndefinedFields(updatedEmp), { merge: true });

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_leave_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: 'Mark as Left Company',
        module: 'Workforce',
        details: `${userProfile?.displayName || 'Admin'} changed ${leavingEmp.name}'s status to Left Company (Reason: ${leavingReason}, Date: ${leavingDate}). Historical data preserved.`,
        targetId: leavingEmp.id,
        targetName: leavingEmp.name,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setEmployees((prev) => prev.map((e) => (e.id === leavingEmp.id ? updatedEmp : e)));
      setLeavingEmp(null);
      setLeavingNotes('');
    } catch (err) {
      console.error('Error marking as left:', err);
    } finally {
      setProcessingStatus(false);
    }
  };

  // Reactivate Employee
  const handleConfirmReactivate = async () => {
    if (!reactivatingEmp || !currentOrg) return;
    setProcessingStatus(true);

    try {
      const updatedEmp: Employee = {
        ...reactivatingEmp,
        status: 'active',
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'employees', reactivatingEmp.id), removeUndefinedFields(updatedEmp), { merge: true });

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_react_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: 'Reactivate Employee',
        module: 'Workforce',
        details: `${userProfile?.displayName || 'Admin'} reactivated employee ${reactivatingEmp.name} (${reactivatingEmp.employeeCode}). Active field access restored.`,
        targetId: reactivatingEmp.id,
        targetName: reactivatingEmp.name,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setEmployees((prev) => prev.map((e) => (e.id === reactivatingEmp.id ? updatedEmp : e)));
      setReactivatingEmp(null);
    } catch (err) {
      console.error('Error reactivating employee:', err);
    } finally {
      setProcessingStatus(false);
    }
  };

  // Permanent Delete (Main Admin Only with Re-auth)
  const handleConfirmPermanentDelete = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deletingEmp || !currentOrg) return;
    setAuthError('');

    const verified = await reauthenticateAdmin(authPin);
    if (!verified) {
      setAuthError('Authentication PIN / password incorrect. Verification failed.');
      return;
    }

    setProcessingStatus(true);
    try {
      await deleteDoc(doc(db, 'employees', deletingEmp.id));

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_del_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: 'PERMANENT_DELETE_EMPLOYEE',
        module: 'Workforce Security',
        details: `Main Admin permanently deleted employee profile ${deletingEmp.name} (${deletingEmp.employeeCode}). Associated historical attendance remains immutable in audit logs.`,
        targetId: deletingEmp.id,
        targetName: deletingEmp.name,
        result: 'warning',
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setEmployees((prev) => prev.filter((e) => e.id !== deletingEmp.id));
      setDeletingEmp(null);
      setAuthPin('');
    } catch (err) {
      console.error('Error deleting employee:', err);
    } finally {
      setProcessingStatus(false);
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'EmployeeCode',
      'Name',
      'Email',
      'Phone',
      'Department',
      'Designation',
      'Territory',
      'ManagerName',
      'EmergencyContact',
      'Status',
      'JoiningDate',
      'LeavingDate',
      'LeavingReason',
    ];
    const rows = filteredEmployees.map((e) => [
      e.employeeCode,
      e.name,
      e.email,
      e.phone,
      e.department,
      e.designation,
      e.territory,
      e.managerName,
      e.emergencyContact,
      e.status,
      e.joiningDate,
      e.leavingDetails?.leavingDate || '',
      e.leavingDetails?.reasonCategory || '',
    ]);
    exportToCsv(`${currentOrg?.name || 'fieldflow'}_employees_${statusTab}.csv`, headers, rows);
  };

  // Filter logic
  const filteredEmployees = employees.filter((emp) => {
    const matchesSearch =
      emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.employeeCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.territory?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesDept = departmentFilter === 'all' || emp.department === departmentFilter;

    let matchesTab = true;
    if (statusTab === 'active') {
      matchesTab = emp.status === 'active' || emp.status === 'on_leave';
    } else if (statusTab === 'former') {
      matchesTab = emp.status === 'left_company';
    } else if (statusTab === 'inactive') {
      matchesTab = emp.status === 'inactive' || emp.status === 'suspended';
    }

    return matchesSearch && matchesDept && matchesTab;
  });

  const totalPages = Math.ceil(filteredEmployees.length / pageSize) || 1;
  const paginatedEmployees = filteredEmployees.slice((page - 1) * pageSize, page * pageSize);

  const departments = Array.from(new Set(employees.map((e) => e.department).filter(Boolean)));

  const activeCount = employees.filter((e) => e.status === 'active' || e.status === 'on_leave').length;
  const formerCount = employees.filter((e) => e.status === 'left_company').length;
  const inactiveCount = employees.filter((e) => e.status === 'inactive' || e.status === 'suspended').length;
  const pendingJoinCount = joinRequests.filter((r) => r.status === 'pending').length;

  return (
    <div className="space-y-4">
      {/* Top action header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-sky-600" />
            <span>Workforce Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage active field technicians, former employees with preserved records, and repeatable CSV imports
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsHistoryOpen(true)}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-200"
          >
            <History className="w-4 h-4 text-slate-600" />
            <span>Import History</span>
          </button>

          <button
            onClick={() => setIsBulkImportOpen(true)}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-200"
          >
            <Upload className="w-4 h-4 text-slate-600" />
            <span>Bulk Import</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-200"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Export Roster</span>
          </button>

          <button
            onClick={() => {
              setEditingEmp(null);
              resetForm();
              setIsAddModalOpen(true);
            }}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* Status Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl text-xs font-semibold overflow-x-auto">
        <button
          onClick={() => {
            setStatusTab('active');
            setPage(1);
          }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
            statusTab === 'active' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Active Employees</span>
          <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px]">
            {activeCount}
          </span>
        </button>

        <button
          onClick={() => {
            setStatusTab('former');
            setPage(1);
          }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
            statusTab === 'former' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Former / Left Company</span>
          <span className="px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px]">
            {formerCount}
          </span>
        </button>

        <button
          onClick={() => {
            setStatusTab('inactive');
            setPage(1);
          }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
            statusTab === 'inactive' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Inactive / Suspended</span>
          <span className="px-1.5 py-0.5 rounded-full bg-slate-200 text-slate-700 text-[10px]">
            {inactiveCount}
          </span>
        </button>

        <button
          onClick={() => {
            setStatusTab('all');
            setPage(1);
          }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
            statusTab === 'all' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>All Records ({employees.length})</span>
        </button>

        <button
          onClick={() => {
            setStatusTab('requests');
            setPage(1);
          }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
            statusTab === 'requests' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>Join Requests</span>
          <span
            className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
              pendingJoinCount > 0
                ? 'bg-amber-500 text-white animate-pulse'
                : 'bg-slate-200 text-slate-700'
            }`}
          >
            {pendingJoinCount}
          </span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by name, ID, email, or territory..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setPage(1);
            }}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-hidden focus:border-sky-500 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={departmentFilter}
            onChange={(e) => {
              setDepartmentFilter(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="all">All Departments</option>
            {departments.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>
        </div>
      </div>

      {statusTab === 'requests' ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-sm text-slate-900">Technician Join Requests</h3>
              <p className="text-xs text-slate-500">
                Review and approve applicant requests from technicians seeking company onboarding.
              </p>
            </div>
            <button
              onClick={fetchJoinRequests}
              className="text-xs text-sky-600 hover:text-sky-800 font-bold"
            >
              Refresh Requests
            </button>
          </div>

          {joinRequests.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No join requests received yet. Share your Company Access Code with prospective technicians.
            </div>
          ) : (
            <div className="space-y-3">
              {joinRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-4 bg-slate-50/70 border border-slate-200 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-slate-900">{req.userName}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          req.status === 'pending'
                            ? 'bg-amber-100 text-amber-800'
                            : req.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : req.status === 'rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>

                    <div className="text-slate-500 flex items-center gap-3 flex-wrap text-[11px]">
                      <span>Email: <strong className="text-slate-700">{req.userEmail}</strong></span>
                      {req.userPhone && <span>Phone: <strong className="text-slate-700">{req.userPhone}</strong></span>}
                      <span>Requested: {new Date(req.requestedAt).toLocaleString()}</span>
                    </div>

                    {req.notes && (
                      <div className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-700 italic text-[11px]">
                        &quot;{req.notes}&quot;
                      </div>
                    )}

                    {req.rejectionReason && (
                      <div className="text-[11px] text-rose-600 font-medium">
                        Rejection note: {req.rejectionReason}
                      </div>
                    )}
                  </div>

                  {req.status === 'pending' && (
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          setRejectingReq(req);
                          setRejectionReasonText('');
                        }}
                        disabled={processingReqId === req.id}
                        className="px-3 py-1.5 border border-slate-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 text-slate-600 font-bold rounded-xl transition-colors disabled:opacity-50"
                      >
                        Decline
                      </button>

                      <button
                        onClick={() => handleApproveRequest(req)}
                        disabled={processingReqId === req.id}
                        className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors disabled:opacity-50"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>{processingReqId === req.id ? 'Approving...' : 'Approve Technician'}</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
      /* Employees Table */
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-500 font-medium">Loading workforce records...</div>
        ) : filteredEmployees.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            No employees found in this view.
          </div>
        ) : (
          <>
            {/* Mobile Card View (Optimized for 360px-480px phones) */}
            <div className="sm:hidden divide-y divide-slate-100">
              {paginatedEmployees.map((emp) => (
                <div key={emp.id} className="p-3.5 space-y-2.5 hover:bg-slate-50/60 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-9 h-9 rounded-full font-bold flex items-center justify-center text-xs shrink-0 ${
                          emp.status === 'left_company'
                            ? 'bg-amber-100 text-amber-800'
                            : emp.status === 'suspended'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-sky-100 text-sky-700'
                        }`}
                      >
                        {emp.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-900">{emp.name}</div>
                        <div className="text-[11px] text-slate-500">{emp.designation || 'Technician'}</div>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1">
                      <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                        {emp.employeeCode}
                      </span>
                      <span
                        className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full capitalize ${
                          emp.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : emp.status === 'on_leave'
                            ? 'bg-indigo-100 text-indigo-800'
                            : emp.status === 'left_company'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {emp.status.replace(/_/g, ' ')}
                      </span>
                    </div>
                  </div>

                  {/* Metadata Chips */}
                  <div className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-xl border border-slate-100 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Dept: {emp.department}</span>
                      <span className="flex items-center gap-1 text-slate-700 font-medium">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span>{emp.territory || 'Central'}</span>
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-500">
                      <span>{emp.email}</span>
                      {emp.phone && <span>{emp.phone}</span>}
                    </div>
                    {emp.status === 'left_company' && emp.leavingDetails && (
                      <div className="pt-1 border-t border-slate-200/60 text-amber-900 font-medium text-[10px]">
                        Left: {emp.leavingDetails.leavingDate} ({emp.leavingDetails.reasonCategory.replace('_', ' ')})
                      </div>
                    )}
                  </div>

                  {/* Action Buttons for Mobile */}
                  <div className="flex items-center gap-2 pt-0.5">
                    <button
                      onClick={() => setTimelineEmp(emp)}
                      className="py-1.5 px-2.5 bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold rounded-lg text-xs flex items-center justify-center gap-1 border border-sky-200"
                      title="View Employee Activity Timeline"
                    >
                      <Activity className="w-3.5 h-3.5" />
                      <span>Timeline</span>
                    </button>

                    <button
                      onClick={() => openEdit(emp)}
                      className="flex-1 py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs flex items-center justify-center gap-1"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>

                    {emp.status === 'left_company' || emp.status === 'inactive' || emp.status === 'suspended' ? (
                      <button
                        onClick={() => setReactivatingEmp(emp)}
                        className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1 shadow-xs"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Reactivate</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setLeavingEmp(emp);
                          setLeavingDate(new Date().toISOString().split('T')[0]);
                          setLeavingReason('resignation');
                          setLeavingNotes('');
                        }}
                        className="flex-1 py-1.5 px-2 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 font-bold rounded-lg text-xs flex items-center justify-center gap-1"
                      >
                        <UserMinus className="w-3.5 h-3.5" />
                        <span>Mark Left</span>
                      </button>
                    )}

                    {isAdmin && (
                      <button
                        onClick={() => {
                          setDeletingEmp(emp);
                          setAuthPin('');
                          setAuthError('');
                        }}
                        className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                        title="Delete (Main Admin)"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="p-3.5">Technician</th>
                    <th className="p-3.5">ID / Code</th>
                    <th className="p-3.5">Department</th>
                    <th className="p-3.5">Territory</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Employment Info</th>
                    <th className="p-3.5 text-right">Lifecycle Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {paginatedEmployees.map((emp) => (
                    <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-full font-bold flex items-center justify-center text-xs shrink-0 ${
                              emp.status === 'left_company'
                                ? 'bg-amber-100 text-amber-800'
                                : emp.status === 'suspended'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-sky-100 text-sky-700'
                            }`}
                          >
                            {emp.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900">{emp.name}</div>
                            <div className="text-[11px] text-slate-500">{emp.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 font-mono font-bold text-slate-700">{emp.employeeCode}</td>
                      <td className="p-3.5 text-slate-700">{emp.department}</td>
                      <td className="p-3.5 text-slate-700">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          <span>{emp.territory || 'Unassigned'}</span>
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                            emp.status === 'active'
                              ? 'bg-emerald-100 text-emerald-800'
                              : emp.status === 'on_leave'
                              ? 'bg-indigo-100 text-indigo-800'
                              : emp.status === 'left_company'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {emp.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-600">
                        {emp.status === 'left_company' && emp.leavingDetails ? (
                          <div>
                            <span className="font-semibold text-amber-900">Left: {emp.leavingDetails.leavingDate}</span>
                            <div className="text-[10px] text-slate-400 capitalize">
                              Reason: {emp.leavingDetails.reasonCategory.replace(/_/g, ' ')}
                            </div>
                          </div>
                        ) : (
                          <div>
                            <span className="text-slate-500">Joined: {emp.joiningDate}</span>
                            <div className="text-[10px] text-slate-400">{emp.designation}</div>
                          </div>
                        )}
                      </td>
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {/* Activity Timeline */}
                          <button
                            onClick={() => setTimelineEmp(emp)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-sky-600 hover:bg-sky-50 transition-colors"
                            title="View Employee Activity Timeline"
                          >
                            <Activity className="w-4 h-4" />
                          </button>

                          {/* Edit profile */}
                          <button
                            onClick={() => openEdit(emp)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-sky-600 hover:bg-slate-100 transition-colors"
                            title="Edit Profile"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          {/* Lifecycle: Mark as Left or Reactivate */}
                          {emp.status === 'left_company' || emp.status === 'inactive' || emp.status === 'suspended' ? (
                            <button
                              onClick={() => setReactivatingEmp(emp)}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors"
                              title="Reactivate Employee"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                              <span>Reactivate</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setLeavingEmp(emp);
                                setLeavingDate(new Date().toISOString().split('T')[0]);
                                setLeavingReason('resignation');
                                setLeavingNotes('');
                              }}
                              className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors"
                              title="Mark as Left Company"
                            >
                              <UserMinus className="w-3.5 h-3.5" />
                              <span>Mark as Left</span>
                            </button>
                          )}

                          {/* Permanent Delete: Main Admin only */}
                          {isAdmin && (
                            <button
                              onClick={() => {
                                setDeletingEmp(emp);
                                setAuthPin('');
                                setAuthError('');
                              }}
                              className="p-1.5 rounded-lg text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Permanent Deletion (Main Admin Only)"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* Enhanced Pagination Bar with Page Size Selector */}
        {filteredEmployees.length > 0 && (
          <div className="p-3 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
            <div className="flex items-center gap-3">
              <span>
                Showing <strong>{(page - 1) * pageSize + 1}</strong> to{' '}
                <strong>{Math.min(page * pageSize, filteredEmployees.length)}</strong> of{' '}
                <strong>{filteredEmployees.length.toLocaleString()}</strong> employees
              </span>

              <div className="flex items-center gap-1 text-[11px] text-slate-500">
                <span>Per page:</span>
                <select
                  value={pageSize}
                  onChange={(e) => {
                    setPageSize(Number(e.target.value));
                    setPage(1);
                  }}
                  className="bg-white border border-slate-200 rounded px-1.5 py-0.5 text-xs font-semibold text-slate-700"
                >
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-bold">
                Page {page} of {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-1.5 rounded-lg border border-slate-200 bg-white disabled:opacity-40"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
      )}

      {/* DECLINE JOIN REQUEST MODAL */}
      {rejectingReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900">Decline Join Request</h3>
              <button onClick={() => setRejectingReq(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-600">
              Decline join request from <strong>{rejectingReq.userName}</strong> ({rejectingReq.userEmail}).
            </p>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Feedback / Reason (Optional)</label>
              <textarea
                rows={3}
                placeholder="e.g. No openings available in this territory at this time..."
                value={rejectionReasonText}
                onChange={(e) => setRejectionReasonText(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setRejectingReq(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRejectRequest}
                disabled={processingReqId === rejectingReq.id}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs disabled:opacity-50"
              >
                {processingReqId === rejectingReq.id ? 'Processing...' : 'Confirm Decline'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MARK AS LEFT COMPANY MODAL */}
      {leavingEmp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <UserMinus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Mark Employee as Left Company</h3>
                  <p className="text-[11px] text-slate-500">Historical records remain preserved.</p>
                </div>
              </div>
              <button onClick={() => setLeavingEmp(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
              <div>Employee: <strong className="text-slate-900">{leavingEmp.name}</strong> ({leavingEmp.employeeCode})</div>
              <div>Department: {leavingEmp.department}</div>
              <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                ✓ Attendance history, completed visits, tasks, and awards remain intact and reportable.
                <br />
                ✓ Normal employee login/mobile access will be disabled immediately.
              </div>
            </div>

            <form onSubmit={handleConfirmMarkAsLeft} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Leaving Date *</label>
                <input
                  type="date"
                  required
                  value={leavingDate}
                  onChange={(e) => setLeavingDate(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Reason / Category *</label>
                <select
                  value={leavingReason}
                  onChange={(e) => setLeavingReason(e.target.value as any)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                >
                  <option value="resignation">Resignation / Career Move</option>
                  <option value="contract_ended">Contract Ended / Project Concluded</option>
                  <option value="retirement">Retirement</option>
                  <option value="termination">Termination</option>
                  <option value="other">Other / Personal Reasons</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Exit Notes (Optional)</label>
                <textarea
                  rows={2}
                  placeholder="Exit interview notes, return of company equipment..."
                  value={leavingNotes}
                  onChange={(e) => setLeavingNotes(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setLeavingEmp(null)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={processingStatus}
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-xs"
                >
                  {processingStatus ? 'Updating...' : 'Confirm Mark as Left'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REACTIVATE EMPLOYEE MODAL */}
      {reactivatingEmp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                <UserCheck className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-sm text-slate-900">Reactivate Employee</h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to reactivate <strong className="text-slate-900">{reactivatingEmp.name}</strong> ({reactivatingEmp.employeeCode})? Their status will be restored to <strong>Active</strong> and field operations access will be unlocked.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setReactivatingEmp(null)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 font-semibold text-slate-600 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReactivate}
                disabled={processingStatus}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs"
              >
                {processingStatus ? 'Reactivating...' : 'Confirm Reactivation'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SAFEGUARDED PERMANENT DELETION MODAL */}
      {deletingEmp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-rose-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-rose-900">Permanent Profile Deletion</h3>
                <p className="text-[11px] text-rose-700">Main Admin & Platform Owner Protected</p>
              </div>
            </div>

            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 space-y-1.5">
              <div className="font-bold flex items-center gap-1">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Irreversible Administrative Action</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                You are permanently deleting <strong className="text-slate-950">{deletingEmp.name}</strong> ({deletingEmp.employeeCode}). This removes the employee permanently from rosters.
              </p>
              <p className="text-[10px] text-rose-800">
                Note: Standard procedure is to <strong>Mark as Left Company</strong> instead of permanent deletion. Use permanent deletion only to purge test or duplicate records.
              </p>
            </div>

            <form onSubmit={handleConfirmPermanentDelete} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Admin Verification PIN or Password *</span>
                </label>
                <input
                  type="password"
                  required
                  placeholder="Enter admin PIN (1234 or master password)"
                  value={authPin}
                  onChange={(e) => setAuthPin(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              {authError && <div className="text-[11px] text-rose-600 font-semibold">{authError}</div>}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setDeletingEmp(null)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={processingStatus}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs"
                >
                  {processingStatus ? 'Verifying & Deleting...' : 'Confirm Permanent Deletion'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Profile Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-base text-slate-900">
                {editingEmp ? 'Edit Technician Profile' : 'Add Field Technician'}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEmployee} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex Vance"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="technician@company.com"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Employee ID / Code *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. EMP-1044"
                    value={formCode}
                    onChange={(e) => setFormCode(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+1 555-0199"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department</label>
                  <input
                    type="text"
                    placeholder="e.g. HVAC Operations"
                    value={formDept}
                    onChange={(e) => setFormDept(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Designation</label>
                  <input
                    type="text"
                    placeholder="e.g. Lead Specialist"
                    value={formDesignation}
                    onChange={(e) => setFormDesignation(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Territory / Area</label>
                  <input
                    type="text"
                    placeholder="e.g. Metro North"
                    value={formTerritory}
                    onChange={(e) => setFormTerritory(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Employment Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as EmploymentStatus)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs capitalize"
                  >
                    <option value="active">Active</option>
                    <option value="on_leave">On Leave</option>
                    <option value="inactive">Inactive</option>
                    <option value="left_company">Left Company</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Reporting Manager</label>
                  <input
                    type="text"
                    placeholder="e.g. Operations Manager"
                    value={formManager}
                    onChange={(e) => setFormManager(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Emergency Contact</label>
                  <input
                    type="text"
                    placeholder="e.g. Sarah Miller (+1 555-0100)"
                    value={formEmergency}
                    onChange={(e) => setFormEmergency(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Certification & Notes</label>
                <textarea
                  rows={2}
                  placeholder="Certifications, license numbers, van vehicle tag..."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-xs"
                >
                  {editingEmp ? 'Save Changes' : 'Create Profile'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        onSuccess={() => {
          fetchEmployees();
        }}
        onOpenHistory={() => {
          setIsBulkImportOpen(false);
          setIsHistoryOpen(true);
        }}
      />

      {/* Import History Modal */}
      <ImportHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
      />

      {/* Employee Activity Timeline Modal */}
      {timelineEmp && (
        <EmployeeTimelineModal
          employee={timelineEmp}
          onClose={() => setTimelineEmp(null)}
        />
      )}
    </div>
  );
};
