import React, { useState } from 'react';
import { 
  Building2, 
  Award, 
  ShieldCheck, 
  UserCheck, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Save, 
  Upload, 
  Settings, 
  Coins, 
  CreditCard,
  Lock,
  ExternalLink,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

export const AdminLegalAndVerificationTab: React.FC = () => {
  const {
    companyInfo,
    updateCompanyInfo,
    appLicence,
    updateAppLicence,
    allSbiBankAccounts,
    updateSbiBankStatusAdmin,
    allAdvancedKycRecords,
    updateAdvancedKycStatusAdmin,
    metalProviderConfig,
    updateMetalProviderConfig
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'company' | 'licence' | 'kyc_bank' | 'metal_provider'>('company');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Company Form state
  const [compName, setCompName] = useState(companyInfo.legalName);
  const [cinNum, setCinNum] = useState(companyInfo.cinNumber);
  const [gstNum, setGstNum] = useState(companyInfo.gstinNumber || '');
  const [msmeNum, setMsmeNum] = useState(companyInfo.msmeNumber || '');
  const [address, setAddress] = useState(companyInfo.registeredAddress);
  const [mcaStatus, setMcaStatus] = useState(companyInfo.mcaStatus);

  // Licence Form state
  const [licType, setLicType] = useState(appLicence.licenceType);
  const [licNumber, setLicNumber] = useState(appLicence.licenceNumber);
  const [issuingAuth, setIssuingAuth] = useState(appLicence.issuingAuthority);
  const [licStatus, setLicStatus] = useState(appLicence.status);
  const [licExpiry, setLicExpiry] = useState(appLicence.expiryDate);

  // Metal Provider state
  const [providerName, setProviderName] = useState(metalProviderConfig.providerName);
  const [goldMarkup, setGoldMarkup] = useState(metalProviderConfig.goldMarkupPercent.toString());
  const [silverMarkup, setSilverMarkup] = useState(metalProviderConfig.silverMarkupPercent.toString());
  const [minGold, setMinGold] = useState(metalProviderConfig.minGoldBuyINR.toString());
  const [minSilver, setMinSilver] = useState(metalProviderConfig.minSilverBuyINR.toString());
  const [liveTrading, setLiveTrading] = useState(metalProviderConfig.isLiveTradingEnabled);

  const notify = (msg: string) => {
    setSuccessNotice(msg);
    confetti({ particleCount: 30, spread: 50 });
    setTimeout(() => setSuccessNotice(null), 3000);
  };

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanyInfo({
      legalName: compName,
      cinNumber: cinNum,
      gstinNumber: gstNum,
      msmeNumber: msmeNum,
      registeredAddress: address,
      mcaStatus: mcaStatus as any,
      lastVerifiedRecordTimestamp: new Date().toLocaleString('en-IN')
    });
    notify('Company Registration details successfully updated and verified in records!');
  };

  const handleSaveLicence = (e: React.FormEvent) => {
    e.preventDefault();
    updateAppLicence({
      licenceType: licType,
      licenceNumber: licNumber,
      issuingAuthority: issuingAuth,
      status: licStatus,
      expiryDate: licExpiry
    });
    notify('App Licence and Regulatory compliance status saved!');
  };

  const handleSaveProvider = (e: React.FormEvent) => {
    e.preventDefault();
    updateMetalProviderConfig({
      providerName,
      goldMarkupPercent: parseFloat(goldMarkup) || 0,
      silverMarkupPercent: parseFloat(silverMarkup) || 0,
      minGoldBuyINR: parseInt(minGold) || 300,
      minSilverBuyINR: parseInt(minSilver) || 200,
      isLiveTradingEnabled: liveTrading,
      lastAuditSync: new Date().toLocaleString('en-IN')
    });
    notify('Precious metals provider and trading settings updated!');
  };

  return (
    <div className="space-y-5 animate-in fade-in">
      {/* Sub Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-800 text-xs">
        <button
          onClick={() => setActiveSubTab('company')}
          className={`py-2 px-3.5 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeSubTab === 'company'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Company Registration</span>
        </button>

        <button
          onClick={() => setActiveSubTab('licence')}
          className={`py-2 px-3.5 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeSubTab === 'licence'
              ? 'bg-purple-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>App Licence & Certificates</span>
        </button>

        <button
          onClick={() => setActiveSubTab('kyc_bank')}
          className={`py-2 px-3.5 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeSubTab === 'kyc_bank'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>KYC & SBI Bank Approvals</span>
        </button>

        <button
          onClick={() => setActiveSubTab('metal_provider')}
          className={`py-2 px-3.5 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeSubTab === 'metal_provider'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>Gold/Silver Provider Config</span>
        </button>
      </div>

      {successNotice && (
        <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successNotice}</span>
        </div>
      )}

      {/* 1. Company Registration SubTab */}
      {activeSubTab === 'company' && (
        <form onSubmit={handleSaveCompany} className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-black text-white">Company Registration & Legal Information</h3>
              <p className="text-[11px] text-slate-400">Manage authentic MCA, CIN, GST, and address details</p>
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Company Info</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Company Legal Name</label>
              <input
                type="text"
                value={compName}
                onChange={(e) => setCompName(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">MCA Status</label>
              <select
                value={mcaStatus}
                onChange={(e) => setMcaStatus(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-teal-500"
              >
                <option value="Active & Verified">Active & Verified</option>
                <option value="Verification Pending">Verification Pending</option>
                <option value="Under Scrutiny">Under Scrutiny</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">CIN Number</label>
              <input
                type="text"
                value={cinNum}
                onChange={(e) => setCinNum(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">GSTIN Number</label>
              <input
                type="text"
                value={gstNum}
                onChange={(e) => setGstNum(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">MSME / Udyam Number</label>
              <input
                type="text"
                value={msmeNum}
                onChange={(e) => setMsmeNum(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Registered Address</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>
        </form>
      )}

      {/* 2. App Licence SubTab */}
      {activeSubTab === 'licence' && (
        <form onSubmit={handleSaveLicence} className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-black text-white">App Licence Information</h3>
              <p className="text-[11px] text-slate-400">Configure real, verified licence details or pending state</p>
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Licence</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Licence Type</label>
              <input
                type="text"
                value={licType}
                onChange={(e) => setLicType(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Licence Verification Status</label>
              <select
                value={licStatus}
                onChange={(e) => setLicStatus(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-purple-500"
              >
                <option value="verified">Verified & Active</option>
                <option value="pending">Verification Pending</option>
                <option value="not_registered">Not Registered</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Licence Number</label>
              <input
                type="text"
                value={licNumber}
                onChange={(e) => setLicNumber(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Issuing Authority</label>
              <input
                type="text"
                value={issuingAuth}
                onChange={(e) => setIssuingAuth(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Expiry Date / Compliance Cycle</label>
              <input
                type="text"
                value={licExpiry}
                onChange={(e) => setLicExpiry(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>
        </form>
      )}

      {/* 3. KYC & SBI Bank Verification Approvals */}
      {activeSubTab === 'kyc_bank' && (
        <div className="space-y-5">
          {/* KYC Approvals */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-white">Aadhaar & PAN KYC Submissions</h3>
                <p className="text-[11px] text-slate-400">Admin-only approval interface. Users cannot self-verify.</p>
              </div>
              <span className="text-[10px] text-teal-400 font-bold">{allAdvancedKycRecords.length} Total Records</span>
            </div>

            <div className="space-y-2.5">
              {allAdvancedKycRecords.map((kyc) => (
                <div key={kyc.userId} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-white text-sm">{kyc.fullName}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                        kyc.overallStatus === 'verified'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : kyc.overallStatus === 'pending'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {kyc.overallStatus.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      User ID: <span className="font-mono text-slate-300">{kyc.userId}</span> • Aadhaar: <span className="font-mono text-slate-300">{kyc.aadhaarNumberMasked}</span> • PAN: <span className="font-mono text-slate-300">{kyc.panNumberMasked}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        updateAdvancedKycStatusAdmin(kyc.userId, 'verified');
                        notify(`KYC for ${kyc.fullName} marked as VERIFIED`);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => {
                        updateAdvancedKycStatusAdmin(kyc.userId, 'rejected', 'Document discrepancy');
                        notify(`KYC for ${kyc.fullName} marked as REJECTED`);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-rose-600/30 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 font-bold text-xs cursor-pointer"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SBI Bank Approvals */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-white">SBI Bank Account Linking Approvals</h3>
                <p className="text-[11px] text-slate-400">Verify user bank accounts before payout eligibility</p>
              </div>
              <span className="text-[10px] text-blue-400 font-bold">{allSbiBankAccounts.length} Linked Accounts</span>
            </div>

            <div className="space-y-2.5">
              {allSbiBankAccounts.map((bank) => (
                <div key={bank.userId} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-white text-sm">{bank.accountHolderName}</span>
                      <span className="text-[10px] text-blue-400 font-mono font-bold bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                        {bank.bankName}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Account: <span className="font-mono text-slate-300">{bank.maskedAccountNumber}</span> • IFSC: <span className="font-mono text-slate-300">{bank.ifscCode}</span> • Payout Status: <strong className={bank.isEligibleForWithdrawal ? 'text-emerald-400' : 'text-rose-400'}>{bank.status}</strong>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        updateSbiBankStatusAdmin(bank.userId, 'verified');
                        notify(`SBI Account for ${bank.accountHolderName} approved for withdrawals`);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer"
                    >
                      Verify Bank
                    </button>
                    <button
                      onClick={() => {
                        updateSbiBankStatusAdmin(bank.userId, 'rejected');
                        notify(`SBI Account for ${bank.accountHolderName} rejected`);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-rose-600/30 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 font-bold text-xs cursor-pointer"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. Metal Provider Config SubTab */}
      {activeSubTab === 'metal_provider' && (
        <form onSubmit={handleSaveProvider} className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-black text-white">Precious Metals Provider Settings</h3>
              <p className="text-[11px] text-slate-400">Configure MCX/IBJA pricing rules, minimum order limits & spreads</p>
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Provider Config</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Provider Source Name</label>
              <input
                type="text"
                value={providerName}
                onChange={(e) => setProviderName(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Live Trading Status</label>
              <select
                value={liveTrading ? 'enabled' : 'disabled'}
                onChange={(e) => setLiveTrading(e.target.value === 'enabled')}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-amber-500"
              >
                <option value="enabled">Active / Enabled 24/7</option>
                <option value="disabled">Paused / Maintenance Mode</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Min Gold Purchase (INR)</label>
              <input
                type="number"
                value={minGold}
                onChange={(e) => setMinGold(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">Min Silver Purchase (INR)</label>
              <input
                type="number"
                value={minSilver}
                onChange={(e) => setMinSilver(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>
        </form>
      )}
    </div>
  );
};
