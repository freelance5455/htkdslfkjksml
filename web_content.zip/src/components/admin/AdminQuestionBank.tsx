import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Search, 
  Plus, 
  Filter, 
  Trash2, 
  Edit3, 
  Sparkles, 
  Upload, 
  CheckCircle2, 
  HelpCircle,
  Tag,
  BookOpen,
  ArrowUpDown,
  RefreshCw,
  X,
  Save
} from 'lucide-react';
import { MCQQuestion } from '../../types';
import AdminBulkUploadModal from './AdminBulkUploadModal';

interface AdminQuestionBankProps {
  language: string;
  adminToken: string;
  onAddToQuiz?: (question: MCQQuestion) => void;
}

export default function AdminQuestionBank({
  language,
  adminToken,
  onAddToQuiz
}: AdminQuestionBankProps) {
  const [questions, setQuestions] = useState<MCQQuestion[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');

  // Edit / Add Modal State
  const [editingQuestion, setEditingQuestion] = useState<MCQQuestion | null>(null);
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [showBulkUpload, setShowBulkUpload] = useState<boolean>(false);

  // AI Generator state
  const [aiCount, setAiCount] = useState<number>(5);
  const [aiSubject, setAiSubject] = useState<string>('General Knowledge');
  const [aiDifficulty, setAiDifficulty] = useState<string>('Medium');
  const [aiGenerating, setAiGenerating] = useState<boolean>(false);

  const fetchQuestionBank = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/question-bank', {
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        const data = await res.json();
        setQuestions(data.questions || []);
      }
    } catch (err) {
      console.error('Failed to load question bank:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQuestionBank();
  }, []);

  const handleSaveQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingQuestion) return;

    if (!editingQuestion.question.trim()) {
      alert(language === 'bn' ? 'প্রশ্নের বিষয়বস্তু পূরণ করা আবশ্যক' : 'Question text is required');
      return;
    }

    try {
      if (isAddingNew) {
        const res = await fetch('/api/admin/question-bank', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-token': adminToken
          },
          body: JSON.stringify(editingQuestion)
        });
        if (res.ok) {
          await fetchQuestionBank();
          setEditingQuestion(null);
          setIsAddingNew(false);
        }
      } else {
        const res = await fetch(`/api/admin/question-bank/${editingQuestion.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-token': adminToken
          },
          body: JSON.stringify(editingQuestion)
        });
        if (res.ok) {
          await fetchQuestionBank();
          setEditingQuestion(null);
        }
      }
    } catch (err) {
      console.error('Save question error:', err);
    }
  };

  const handleDeleteQuestion = async (id: string) => {
    if (!window.confirm(language === 'bn' ? 'আপনি কি নিশ্চিতভাবে এই প্রশ্নটি প্রশ্নব্যাংক থেকে মুছে ফেলতে চান?' : 'Delete this question from bank?')) return;
    try {
      const res = await fetch(`/api/admin/question-bank/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        setQuestions(prev => prev.filter(q => q.id !== id));
      }
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  const handleAiGenerate = async () => {
    setAiGenerating(true);
    try {
      const res = await fetch('/api/admin/generate-questions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({
          subjects: [aiSubject],
          count: aiCount,
          targetLevel: 'Competitive Exam',
          difficulty: aiDifficulty,
          language
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
        // Bulk import into bank
        const bulkRes = await fetch('/api/admin/question-bank/bulk', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-token': adminToken
          },
          body: JSON.stringify({ questions: data.questions })
        });
        if (bulkRes.ok) {
          await fetchQuestionBank();
          alert(language === 'bn' ? `সফলভাবে ${data.questions.length}টি প্রশ্ন প্রশ্নব্যাংকে যোগ করা হয়েছে!` : `Added ${data.questions.length} questions to Question Bank!`);
        } else {
          alert(language === 'bn' ? 'প্রশ্ন তৈরি হয়েছে তবে প্রশ্নব্যাংকে যোগ করতে সমস্যা হয়েছে।' : 'Questions generated but failed to bulk save.');
        }
      } else {
        alert(language === 'bn' ? 'কোনো প্রশ্ন তৈরি করা সম্ভব হয়নি।' : 'No questions were returned.');
      }
    } catch (err: any) {
      console.error('AI Generate questions error:', err);
      alert(language === 'bn' ? 'প্রশ্ন তৈরিতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।' : 'Failed to generate questions. Please try again.');
    } finally {
      setAiGenerating(false);
    }
  };

  // Filtered Questions
  const subjectsList = Array.from(new Set(questions.map(q => q.subject || 'General'))).filter(Boolean);
  const filteredQuestions = questions.filter(q => {
    const matchesSearch = 
      q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (q.explanation && q.explanation.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (q.subject && q.subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (q.topic && q.topic.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesSubject = selectedSubject === 'all' || q.subject === selectedSubject;
    const matchesDifficulty = selectedDifficulty === 'all' || q.difficulty === selectedDifficulty;

    return matchesSearch && matchesSubject && matchesDifficulty;
  });

  const openAddNew = () => {
    setEditingQuestion({
      id: `qb-${Date.now()}`,
      question: '',
      options: ['', '', '', ''],
      correctOptionIndex: 0,
      explanation: '',
      shortConcept: '',
      rememberPoint: '',
      subject: 'General Knowledge',
      topic: '',
      difficulty: 'Medium'
    });
    setIsAddingNew(true);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-xl">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <span>{language === 'bn' ? 'কেন্দ্রীয় প্রশ্নব্যাংক' : 'Central Question Bank'}</span>
              <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 text-xs font-bold rounded-md border border-indigo-500/30">
                {questions.length} {language === 'bn' ? 'টি সংরক্ষিত প্রশ্ন' : 'Questions'}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'bn' ? 'সকল বিষয়ের প্রশ্ন তৈরি, এডিট ও সরাসরি কুইজে যুক্ত করার হাব' : 'Create, organize and import questions directly into any quiz'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowBulkUpload(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer border border-slate-700 transition-all"
          >
            <Upload className="w-3.5 h-3.5 text-indigo-400" />
            <span>{language === 'bn' ? 'বাল্ক আপলোড' : 'Bulk Upload'}</span>
          </button>

          <button
            onClick={openAddNew}
            className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-black text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'bn' ? 'নতুন প্রশ্ন যোগ' : 'Add Question'}</span>
          </button>

          <button
            onClick={fetchQuestionBank}
            title="Refresh"
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* AI Instant Question Bank Generator Banner */}
      <div className="bg-gradient-to-r from-purple-950/40 via-indigo-950/30 to-slate-950 p-4 rounded-2xl border border-purple-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/20 text-purple-400 border border-purple-500/30 rounded-xl">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-black text-white">
              {language === 'bn' ? 'AI প্রশ্ন জেনারেটর (ব্যাংকে সরাসরি যুক্ত করুন)' : 'AI Question Generator for Bank'}
            </h4>
            <p className="text-[11px] text-slate-400">
              {language === 'bn' ? 'সিলেবাস অনুযায়ী স্বয়ংক্রিয়ভাবে যাচাইকৃত MCQ তৈরি করে ব্যাংক সমৃদ্ধ করুন' : 'Generate syllabus-accurate MCQs directly into the question bank'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <select
            value={aiSubject}
            onChange={(e) => setAiSubject(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-200 text-xs font-bold rounded-xl px-2.5 py-1.5 focus:border-purple-500"
          >
            <option value="General Knowledge">General Knowledge</option>
            <option value="History">History (ইতিহাস)</option>
            <option value="Indian Polity">Polity (রাষ্ট্রবিজ্ঞান)</option>
            <option value="General Science">General Science (বিজ্ঞান)</option>
            <option value="Geography">Geography (ভূগোল)</option>
            <option value="Quantitative Aptitude">Aptitude (গণিত)</option>
            <option value="Reasoning">Reasoning</option>
          </select>

          <select
            value={aiDifficulty}
            onChange={(e) => setAiDifficulty(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-200 text-xs font-bold rounded-xl px-2.5 py-1.5 focus:border-purple-500"
          >
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>

          <select
            value={aiCount}
            onChange={(e) => setAiCount(Number(e.target.value))}
            className="bg-slate-900 border border-slate-700 text-slate-200 text-xs font-bold rounded-xl px-2.5 py-1.5 focus:border-purple-500"
          >
            <option value={5}>5 Questions</option>
            <option value={10}>10 Questions</option>
            <option value={20}>20 Questions</option>
          </select>

          <button
            onClick={handleAiGenerate}
            disabled={aiGenerating}
            className="px-3.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md"
          >
            <Sparkles className={`w-3.5 h-3.5 ${aiGenerating ? 'animate-spin' : ''}`} />
            <span>{aiGenerating ? (language === 'bn' ? 'জেনারেট হচ্ছে...' : 'Generating...') : (language === 'bn' ? 'জেনারেট করুন' : 'Generate')}</span>
          </button>
        </div>
      </div>

      {/* Filters & Search Row */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900 p-3 rounded-2xl border border-slate-800">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'bn' ? 'প্রশ্ন, বিষয় বা টপিক খুঁজুন...' : 'Search question text, subject, topic...'}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto">
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 text-xs font-bold rounded-xl px-3 py-2 focus:border-indigo-500"
          >
            <option value="all">{language === 'bn' ? 'সকল বিষয় (All Subjects)' : 'All Subjects'}</option>
            {subjectsList.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>

          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 text-xs font-bold rounded-xl px-3 py-2 focus:border-indigo-500"
          >
            <option value="all">{language === 'bn' ? 'সকল কাঠিন্য' : 'All Difficulties'}</option>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>
        </div>
      </div>

      {/* Question Bank List */}
      {loading ? (
        <div className="py-16 text-center text-slate-400">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-indigo-400 mb-3" />
          <p className="text-xs font-bold">{language === 'bn' ? 'প্রশ্নব্যাংক লোড হচ্ছে...' : 'Loading Question Bank...'}</p>
        </div>
      ) : filteredQuestions.length === 0 ? (
        <div className="py-16 text-center bg-slate-950/40 rounded-3xl border border-slate-800/80 p-8 space-y-3">
          <Database className="w-12 h-12 mx-auto text-slate-600" />
          <h4 className="text-sm font-black text-slate-300">
            {language === 'bn' ? 'কোনো প্রশ্ন পাওয়া যায়নি' : 'No Questions Found'}
          </h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {language === 'bn' ? 'অনুগ্রহ করে নতুন প্রশ্ন তৈরি করুন, বাল্ক আপলোড করুন অথবা AI জেনারেটর ব্যবহার করুন।' : 'Add new questions manually, bulk upload from Excel/CSV, or generate with AI.'}
          </p>
          <button
            onClick={openAddNew}
            className="mt-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl cursor-pointer inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'প্রথম প্রশ্ন যোগ করুন' : 'Add First Question'}</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredQuestions.map((q, idx) => (
            <div
              key={q.id || idx}
              className="bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 transition-all space-y-3"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <span className="w-6 h-6 rounded-lg bg-slate-800 text-indigo-300 text-[11px] font-black flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-white leading-relaxed">
                      {q.question}
                    </h4>
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className="px-2 py-0.5 bg-slate-800 text-slate-300 text-[10px] font-extrabold rounded-md">
                        📚 {q.subject || 'General'}
                      </span>
                      {q.topic && (
                        <span className="px-2 py-0.5 bg-slate-800/80 text-slate-400 text-[10px] font-bold rounded-md">
                          🏷️ {q.topic}
                        </span>
                      )}
                      <span className={`px-2 py-0.5 text-[10px] font-extrabold rounded-md ${
                        q.difficulty === 'Easy' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50' :
                        q.difficulty === 'Hard' ? 'bg-rose-950/60 text-rose-300 border border-rose-800/50' :
                        'bg-amber-950/60 text-amber-300 border border-amber-800/50'
                      }`}>
                        {q.difficulty || 'Medium'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {onAddToQuiz && (
                    <button
                      onClick={() => onAddToQuiz(q)}
                      title="Add to Current Quiz"
                      className="px-2.5 py-1.5 bg-indigo-600/30 hover:bg-indigo-600 text-indigo-300 hover:text-white font-bold text-[11px] rounded-lg border border-indigo-500/40 cursor-pointer flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" />
                      <span>{language === 'bn' ? 'কুইজে যোগ' : 'Add to Quiz'}</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setEditingQuestion(q);
                      setIsAddingNew(false);
                    }}
                    title="Edit Question"
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => handleDeleteQuestion(q.id)}
                    title="Delete Question"
                    className="p-1.5 bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Options Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                {q.options.map((opt, oIdx) => {
                  const isCorrect = oIdx === q.correctOptionIndex;
                  return (
                    <div
                      key={oIdx}
                      className={`px-3 py-2 rounded-xl text-xs flex items-center gap-2 ${
                        isCorrect 
                          ? 'bg-emerald-950/40 border border-emerald-500/50 text-emerald-200 font-bold' 
                          : 'bg-slate-900 border border-slate-800/80 text-slate-300'
                      }`}
                    >
                      <span className={`w-4 h-4 rounded-full text-[10px] font-black flex items-center justify-center shrink-0 ${
                        isCorrect ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span className="truncate">{opt}</span>
                      {isCorrect && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-auto shrink-0" />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Explanation & Memory Tip */}
              {q.explanation && (
                <div className="bg-slate-900/60 border border-slate-800/60 rounded-xl p-2.5 text-[11px] text-slate-400 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-300 font-bold">
                    <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{language === 'bn' ? 'ব্যাখ্যা:' : 'Explanation:'}</span>
                  </div>
                  <p className="leading-relaxed pl-5">{q.explanation}</p>
                  {q.rememberPoint && (
                    <p className="pl-5 text-amber-300/90 font-medium">
                      💡 <strong>Tip:</strong> {q.rememberPoint}
                    </p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Edit / Add Modal Form */}
      {editingQuestion && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-2xl p-5 sm:p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-indigo-400" />
                <span>{isAddingNew ? (language === 'bn' ? 'প্রশ্নব্যাংকে নতুন প্রশ্ন যোগ' : 'Add New Question to Bank') : (language === 'bn' ? 'প্রশ্ন এডিট করুন' : 'Edit Question')}</span>
              </h3>
              <button
                onClick={() => setEditingQuestion(null)}
                className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQuestion} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'প্রশ্ন বিবরণ (Question Text):' : 'Question Statement:'}
                </label>
                <textarea
                  required
                  rows={3}
                  value={editingQuestion.question}
                  onChange={(e) => setEditingQuestion({ ...editingQuestion, question: e.target.value })}
                  placeholder={language === 'bn' ? 'স্পষ্টভাবে প্রশ্ন লিখুন...' : 'Write full question text...'}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Subject & Difficulty Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">
                    {language === 'bn' ? 'বিষয় (Subject):' : 'Subject:'}
                  </label>
                  <input
                    type="text"
                    value={editingQuestion.subject}
                    onChange={(e) => setEditingQuestion({ ...editingQuestion, subject: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">
                    {language === 'bn' ? 'টপিক (Topic):' : 'Topic:'}
                  </label>
                  <input
                    type="text"
                    value={editingQuestion.topic || ''}
                    onChange={(e) => setEditingQuestion({ ...editingQuestion, topic: e.target.value })}
                    placeholder="e.g. Mughal Era"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-400 block mb-1">
                    {language === 'bn' ? 'কাঠিন্য (Difficulty):' : 'Difficulty:'}
                  </label>
                  <select
                    value={editingQuestion.difficulty || 'Medium'}
                    onChange={(e) => setEditingQuestion({ ...editingQuestion, difficulty: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500"
                  >
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Hard">Hard</option>
                  </select>
                </div>
              </div>

              {/* 4 Options with Correct Answer Selector */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  {language === 'bn' ? '৪টি অপশন ও সঠিক উত্তর নির্ধারণ:' : 'Options & Correct Answer:'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {editingQuestion.options.map((opt, optIndex) => {
                    const isCorrect = editingQuestion.correctOptionIndex === optIndex;
                    return (
                      <div
                        key={optIndex}
                        className={`flex items-center gap-2 p-2 rounded-xl border ${
                          isCorrect ? 'bg-emerald-950/40 border-emerald-500/60' : 'bg-slate-950 border-slate-800'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => setEditingQuestion({ ...editingQuestion, correctOptionIndex: optIndex })}
                          className={`w-6 h-6 rounded-lg text-xs font-black flex items-center justify-center shrink-0 cursor-pointer ${
                            isCorrect ? 'bg-emerald-500 text-slate-950 shadow-md' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                          }`}
                        >
                          {String.fromCharCode(65 + optIndex)}
                        </button>
                        <input
                          type="text"
                          required
                          value={opt}
                          onChange={(e) => {
                            const newOpts = [...editingQuestion.options];
                            newOpts[optIndex] = e.target.value;
                            setEditingQuestion({ ...editingQuestion, options: newOpts });
                          }}
                          placeholder={`Option ${String.fromCharCode(65 + optIndex)}`}
                          className="w-full bg-transparent text-xs text-white focus:outline-none"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Explanation and Memory Tip */}
              <div className="space-y-2">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-400 block">
                    {language === 'bn' ? 'বিস্তারিত সমাধান ও ব্যাখ্যা:' : 'Detailed Explanation:'}
                  </label>
                  <textarea
                    rows={2}
                    value={editingQuestion.explanation}
                    onChange={(e) => setEditingQuestion({ ...editingQuestion, explanation: e.target.value })}
                    placeholder={language === 'bn' ? 'সঠিক উত্তরের পেছনে যৌক্তিক ব্যাখ্যা...' : 'Pedagogical explanation...'}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-400 block">
                    {language === 'bn' ? 'মনে রাখার শর্ট টিপ (Remember Point):' : 'Exam Memory Tip:'}
                  </label>
                  <input
                    type="text"
                    value={editingQuestion.rememberPoint || ''}
                    onChange={(e) => setEditingQuestion({ ...editingQuestion, rememberPoint: e.target.value })}
                    placeholder="e.g. Shortcut formula or key year"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingQuestion(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'সংরক্ষণ করুন' : 'Save Question'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Upload Modal */}
      {showBulkUpload && (
        <AdminBulkUploadModal
          language={language}
          onClose={() => setShowBulkUpload(false)}
          onImport={async (importedQuestions) => {
            try {
              const res = await fetch('/api/admin/question-bank/bulk', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'x-admin-token': adminToken
                },
                body: JSON.stringify({ questions: importedQuestions })
              });
              if (res.ok) {
                await fetchQuestionBank();
                setShowBulkUpload(false);
                alert(language === 'bn' ? `সফলভাবে ${importedQuestions.length}টি প্রশ্ন প্রশ্নব্যাংকে আপলোড সম্পন্ন হয়েছে!` : `Imported ${importedQuestions.length} questions to Question Bank!`);
              }
            } catch (err) {
              console.error('Bulk upload import error:', err);
            }
          }}
        />
      )}

    </div>
  );
}
