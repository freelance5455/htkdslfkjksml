import React, { useEffect, useState, useCallback } from 'react';
import {
  AlertTriangle,
  Calendar,
  CheckSquare,
  HelpCircle,
  Clock,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Check,
  X,
  MessageSquare,
  RefreshCw,
  BellRing,
} from 'lucide-react';
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  setDoc,
  onSnapshot,
  limit,
} from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { LeaveRequest, TaskItem, SupportTicket, AttendanceRecord, AuditLogEntry } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

interface ActivityCenterProps {
  onNavigate: (module: string) => void;
}

export const ActivityCenter: React.FC<ActivityCenterProps> = ({ onNavigate }) => {
  const { currentOrg, userProfile } = useAuth();

  const [pendingLeaves, setPendingLeaves] = useState<LeaveRequest[]>([]);
  const [overdueTasks, setOverdueTasks] = useState<TaskItem[]>([]);
  const [openTickets, setOpenTickets] = useState<SupportTicket[]>([]);
  const [pendingCorrections, setPendingCorrections] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterType, setFilterType] = useState<'all' | 'leave' | 'tasks' | 'support' | 'attendance'>('all');
  const [processingId, setProcessingId] = useState<string | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];

  // Load Firestore data using Firestore query hooks
  const fetchActivityData = useCallback(async () => {
    if (!currentOrg) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      // 1. Pending Leave Requests
      const leaveQuery = query(
        collection(db, 'leave_requests'),
        where('orgId', '==', currentOrg.id),
        where('status', '==', 'pending'),
        limit(20)
      );
      const leaveSnap = await getDocs(leaveQuery);
      const leaves: LeaveRequest[] = [];
      leaveSnap.forEach((d) => leaves.push(d.data() as LeaveRequest));
      setPendingLeaves(leaves);

      // 2. Tasks (Pending / In Progress to detect Overdue)
      const taskQuery = query(
        collection(db, 'tasks'),
        where('orgId', '==', currentOrg.id),
        where('status', 'in', ['pending', 'in_progress']),
        limit(50)
      );
      const taskSnap = await getDocs(taskQuery);
      const overdue: TaskItem[] = [];
      taskSnap.forEach((d) => {
        const item = d.data() as TaskItem;
        if (item.dueDate && item.dueDate < todayStr) {
          overdue.push(item);
        }
      });
      setOverdueTasks(overdue);

      // 3. Support Tickets (Open, In Progress, Waiting)
      const ticketQuery = query(
        collection(db, 'support_tickets'),
        where('orgId', '==', currentOrg.id),
        where('status', 'in', ['open', 'in_progress', 'waiting_for_customer']),
        limit(20)
      );
      const ticketSnap = await getDocs(ticketQuery);
      const tickets: SupportTicket[] = [];
      ticketSnap.forEach((d) => tickets.push(d.data() as SupportTicket));
      setOpenTickets(tickets);

      // 4. Attendance Corrections
      const attQuery = query(
        collection(db, 'attendance'),
        where('orgId', '==', currentOrg.id),
        limit(50)
      );
      const attSnap = await getDocs(attQuery);
      const corrections: AttendanceRecord[] = [];
      attSnap.forEach((d) => {
        const record = d.data() as AttendanceRecord;
        if (record.correctionRequest?.status === 'pending') {
          corrections.push(record);
        }
      });
      setPendingCorrections(corrections);
    } catch (err) {
      console.error('Error fetching Activity Center data:', err);
    } finally {
      setLoading(false);
    }
  }, [currentOrg, todayStr]);

  useEffect(() => {
    fetchActivityData();
  }, [fetchActivityData]);

  // Quick Action: Approve or Reject Leave Request
  const handleLeaveDecision = async (leave: LeaveRequest, approved: boolean) => {
    if (!currentOrg) return;
    setProcessingId(leave.id);
    const newStatus = approved ? 'approved' : 'rejected';
    const updated: LeaveRequest = {
      ...leave,
      status: newStatus,
      reviewedBy: userProfile?.displayName || 'Admin',
    };

    try {
      await setDoc(doc(db, 'leave_requests', leave.id), removeUndefinedFields(updated));

      // Create Audit Log entry
      const auditLog: AuditLogEntry = {
        id: `aud_leave_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: `Leave ${newStatus.toUpperCase()}`,
        module: 'Leave Management',
        details: `Leave application for ${leave.employeeName} (${leave.startDate} to ${leave.endDate}) was ${newStatus} via Activity Center.`,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setPendingLeaves((prev) => prev.filter((l) => l.id !== leave.id));
    } catch (err) {
      console.error('Error updating leave request:', err);
    } finally {
      setProcessingId(null);
    }
  };

  // Quick Action: Complete Overdue Task
  const handleCompleteTask = async (task: TaskItem) => {
    if (!currentOrg) return;
    setProcessingId(task.id);
    const updated: TaskItem = {
      ...task,
      status: 'completed',
      completedAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'tasks', task.id), removeUndefinedFields(updated));

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_task_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: 'Task Completed',
        module: 'Task Management',
        details: `Overdue task "${task.title}" was resolved via Activity Center.`,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setOverdueTasks((prev) => prev.filter((t) => t.id !== task.id));
    } catch (err) {
      console.error('Error completing task:', err);
    } finally {
      setProcessingId(null);
    }
  };

  // Quick Action: Resolve Support Ticket
  const handleResolveTicket = async (ticket: SupportTicket) => {
    if (!currentOrg) return;
    setProcessingId(ticket.id);
    const updated: SupportTicket = {
      ...ticket,
      status: 'resolved',
      updatedAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'support_tickets', ticket.id), removeUndefinedFields(updated));
      setOpenTickets((prev) => prev.filter((t) => t.id !== ticket.id));
    } catch (err) {
      console.error('Error resolving support ticket:', err);
    } finally {
      setProcessingId(null);
    }
  };

  // Quick Action: Approve Attendance Correction
  const handleAttendanceCorrection = async (record: AttendanceRecord, approved: boolean) => {
    if (!currentOrg || !record.correctionRequest) return;
    setProcessingId(record.id);
    const newStatus = approved ? 'approved' : 'rejected';
    const updatedRecord: AttendanceRecord = {
      ...record,
      correctionRequest: {
        ...record.correctionRequest,
        status: newStatus,
        reviewedAt: new Date().toISOString(),
      },
    };

    if (approved && record.correctionRequest.requestedCheckIn) {
      updatedRecord.checkInTime = `${record.date}T${record.correctionRequest.requestedCheckIn}:00.000Z`;
      if (record.correctionRequest.requestedCheckOut) {
        updatedRecord.checkOutTime = `${record.date}T${record.correctionRequest.requestedCheckOut}:00.000Z`;
      }
    }

    try {
      await setDoc(doc(db, 'attendance', record.id), removeUndefinedFields(updatedRecord));
      setPendingCorrections((prev) => prev.filter((r) => r.id !== record.id));
    } catch (err) {
      console.error('Error updating attendance correction:', err);
    } finally {
      setProcessingId(null);
    }
  };

  const totalHighPriorityItems =
    pendingLeaves.length + overdueTasks.length + openTickets.length + pendingCorrections.length;

  return (
    <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
      {/* Activity Center Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <BellRing className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <span>Activity Center</span>
                {totalHighPriorityItems > 0 && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                )}
              </h3>
              <p className="text-xs text-slate-500">
                High-priority operational items requiring immediate supervisor attention
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchActivityData}
            disabled={loading}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            title="Refresh action items"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-sky-600' : ''}`} />
          </button>
          <span
            className={`text-xs font-bold px-3 py-1 rounded-full ${
              totalHighPriorityItems > 0
                ? 'bg-rose-100 text-rose-800 border border-rose-200'
                : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
            }`}
          >
            {totalHighPriorityItems} Action {totalHighPriorityItems === 1 ? 'Item' : 'Items'}
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-semibold pb-1 scrollbar-none">
        <button
          onClick={() => setFilterType('all')}
          className={`px-3 py-1.5 rounded-xl transition-colors shrink-0 ${
            filterType === 'all'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          All Items ({totalHighPriorityItems})
        </button>
        <button
          onClick={() => setFilterType('leave')}
          className={`px-3 py-1.5 rounded-xl transition-colors shrink-0 flex items-center gap-1 ${
            filterType === 'leave'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Pending Leave ({pendingLeaves.length})</span>
        </button>
        <button
          onClick={() => setFilterType('tasks')}
          className={`px-3 py-1.5 rounded-xl transition-colors shrink-0 flex items-center gap-1 ${
            filterType === 'tasks'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'bg-rose-50 text-rose-800 hover:bg-rose-100'
          }`}
        >
          <CheckSquare className="w-3.5 h-3.5" />
          <span>Overdue Tasks ({overdueTasks.length})</span>
        </button>
        <button
          onClick={() => setFilterType('support')}
          className={`px-3 py-1.5 rounded-xl transition-colors shrink-0 flex items-center gap-1 ${
            filterType === 'support'
              ? 'bg-sky-600 text-white shadow-xs'
              : 'bg-sky-50 text-sky-800 hover:bg-sky-100'
          }`}
        >
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Support Tickets ({openTickets.length})</span>
        </button>
        <button
          onClick={() => setFilterType('attendance')}
          className={`px-3 py-1.5 rounded-xl transition-colors shrink-0 flex items-center gap-1 ${
            filterType === 'attendance'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-purple-50 text-purple-800 hover:bg-purple-100'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Corrections ({pendingCorrections.length})</span>
        </button>
      </div>

      {/* Action Items List */}
      {loading ? (
        <div className="py-12 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
          <RefreshCw className="w-4 h-4 animate-spin text-sky-600" />
          <span>Refreshing operational priority feed...</span>
        </div>
      ) : totalHighPriorityItems === 0 ? (
        <div className="py-8 text-center text-xs text-slate-500 bg-slate-50/70 border border-slate-200 rounded-2xl flex flex-col items-center justify-center gap-1.5">
          <CheckCircle2 className="w-6 h-6 text-emerald-500" />
          <div className="font-bold text-slate-800 text-sm">All Clear! Everything Is on Schedule</div>
          <p className="text-slate-400 max-w-sm text-[11px]">
            No pending leave requests, overdue tasks, unread support tickets, or punch corrections right now.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {/* 1. Pending Leave Requests */}
          {(filterType === 'all' || filterType === 'leave') &&
            pendingLeaves.map((leave) => (
              <div
                key={leave.id}
                className="p-3.5 rounded-2xl bg-amber-50/50 border border-amber-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-amber-50/80 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold text-[10px] uppercase">
                      Leave Approval
                    </span>
                    <strong className="text-slate-900 font-bold">{leave.employeeName}</strong>
                    <span className="text-slate-500 capitalize">({leave.leaveType} leave)</span>
                  </div>
                  <div className="text-slate-600 text-[11px] flex items-center gap-1.5">
                    <Calendar className="w-3 h-3 text-amber-600 shrink-0" />
                    <span>
                      {leave.startDate} → {leave.endDate}
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="italic text-slate-500">"{leave.reason}"</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => handleLeaveDecision(leave, true)}
                    disabled={processingId === leave.id}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Approve</span>
                  </button>
                  <button
                    onClick={() => handleLeaveDecision(leave, false)}
                    disabled={processingId === leave.id}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Reject</span>
                  </button>
                  <button
                    onClick={() => onNavigate('leave')}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                    title="View in Leave Manager"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

          {/* 2. Overdue Tasks */}
          {(filterType === 'all' || filterType === 'tasks') &&
            overdueTasks.map((task) => (
              <div
                key={task.id}
                className="p-3.5 rounded-2xl bg-rose-50/50 border border-rose-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-rose-50/80 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-900 font-bold text-[10px] uppercase">
                      Overdue Task
                    </span>
                    <strong className="text-slate-900 font-bold">{task.title}</strong>
                    <span className="text-[10px] uppercase font-bold text-rose-700">
                      [{task.priority}]
                    </span>
                  </div>
                  <div className="text-slate-600 text-[11px] flex items-center gap-2">
                    <span>
                      Assigned to: <strong>{task.assignedEmployeeName}</strong>
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="text-rose-700 font-bold">Past Due Date: {task.dueDate}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => handleCompleteTask(task)}
                    disabled={processingId === task.id}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Resolve Task</span>
                  </button>
                  <button
                    onClick={() => onNavigate('tasks')}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                    title="View in Tasks Board"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

          {/* 3. Open Support Tickets */}
          {(filterType === 'all' || filterType === 'support') &&
            openTickets.map((ticket) => (
              <div
                key={ticket.id}
                className="p-3.5 rounded-2xl bg-sky-50/50 border border-sky-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-sky-50/80 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-900 font-bold text-[10px] uppercase">
                      Support Ticket ({ticket.category})
                    </span>
                    <strong className="text-slate-900 font-bold">{ticket.subject}</strong>
                  </div>
                  <div className="text-slate-600 text-[11px] flex items-center gap-2">
                    <span>
                      From: <strong>{ticket.submittedBy}</strong> ({ticket.submittedByEmail})
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-500 capitalize">Status: {ticket.status.replace(/_/g, ' ')}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => onNavigate('support')}
                    className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Reply Ticket</span>
                  </button>
                  <button
                    onClick={() => handleResolveTicket(ticket)}
                    disabled={processingId === ticket.id}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center gap-1 border border-slate-200 transition-colors"
                  >
                    <span>Close</span>
                  </button>
                </div>
              </div>
            ))}

          {/* 4. Attendance Corrections */}
          {(filterType === 'all' || filterType === 'attendance') &&
            pendingCorrections.map((record) => (
              <div
                key={record.id}
                className="p-3.5 rounded-2xl bg-purple-50/50 border border-purple-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-purple-50/80 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-900 font-bold text-[10px] uppercase">
                      Punch Correction
                    </span>
                    <strong className="text-slate-900 font-bold">{record.employeeName}</strong>
                    <span className="text-slate-500">for {record.date}</span>
                  </div>
                  <div className="text-slate-600 text-[11px]">
                    Requested In: <strong>{record.correctionRequest?.requestedCheckIn}</strong> · Out: <strong>{record.correctionRequest?.requestedCheckOut}</strong>
                    <span className="ml-2 italic text-slate-500">"{record.correctionRequest?.reason}"</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => handleAttendanceCorrection(record, true)}
                    disabled={processingId === record.id}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Approve</span>
                  </button>
                  <button
                    onClick={() => handleAttendanceCorrection(record, false)}
                    disabled={processingId === record.id}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Reject</span>
                  </button>
                  <button
                    onClick={() => onNavigate('attendance')}
                    className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                    title="View in Attendance Manager"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
};
