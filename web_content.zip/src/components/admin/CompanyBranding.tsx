import React, { useState, useRef, useEffect } from 'react';
import {
  Palette,
  Upload,
  Check,
  Building2,
  Save,
  KeyRound,
  Eye,
  EyeOff,
  Copy,
  RefreshCw,
  CheckCircle2,
  ShieldCheck,
} from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { compressImage } from '../../utils/imageCompressor.ts';
import { AuditLogEntry, Organization } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { hashCompanyPassword } from '../../utils/securityHelper.ts';

export const CompanyBranding: React.FC = () => {
  const { currentOrg, switchOrganization, userProfile, reloadUserData } = useAuth();
  const [companyName, setCompanyName] = useState(currentOrg?.name || '');
  const [accentColor, setAccentColor] = useState(currentOrg?.accentColor || '#0284c7');
  const [logoDataUrl, setLogoDataUrl] = useState<string>(currentOrg?.logoUrl || '');
  const [accessCode, setAccessCode] = useState<string>(currentOrg?.accessCode || '');
  const [showAccessCode, setShowAccessCode] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const predefinedColors = [
    { label: 'Sky Blue', hex: '#0284c7' },
    { label: 'Emerald Green', hex: '#16a34a' },
    { label: 'Indigo', hex: '#4f46e5' },
    { label: 'Amber Orange', hex: '#ea580c' },
    { label: 'Slate Dark', hex: '#334155' },
  ];

  useEffect(() => {
    if (currentOrg) {
      setCompanyName(currentOrg.name);
      setAccentColor(currentOrg.accentColor || '#0284c7');
      setLogoDataUrl(currentOrg.logoUrl || '');
      setAccessCode(currentOrg.accessCode || '');
    }
  }, [currentOrg]);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate type and size (max 2MB)
    if (!file.type.match(/^image\/(png|jpe?g|webp|svg\+xml)$/i)) {
      setErrorMessage('Please upload a valid image file (PNG, JPG, WebP, or SVG).');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setErrorMessage('Logo file size must be less than 2 MB.');
      return;
    }

    try {
      const compressed = await compressImage(file, { maxWidth: 256, maxHeight: 256, quality: 0.85 });
      setLogoDataUrl(compressed.dataUrl);
      setMessage(`Logo processed and compressed (${Math.round(compressed.compressedSize / 1024)} KB)`);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to process logo file');
    }
  };

  const handleRegenerateAccessCode = async () => {
    if (!currentOrg) return;
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let newCode = '';
    for (let i = 0; i < 8; i++) {
      newCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    try {
      // Securely hash the company access code so plaintext is not exposed in database
      const { hash, salt } = await hashCompanyPassword(newCode);

      const updates: Partial<Organization> = {
        accessCode: newCode, // Kept for admin display in session
        accessPasswordHash: hash,
        accessPasswordSalt: salt,
        hasAccessPassword: true,
      };

      await setDoc(doc(db, 'organizations', currentOrg.id), updates, { merge: true });
      setAccessCode(newCode);

      // Audit log
      const auditLog: AuditLogEntry = {
        id: `aud_code_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        userRole: userProfile?.role || 'org_admin',
        action: 'REGENERATE_COMPANY_ACCESS_CODE',
        module: 'Company Security',
        details: `Regenerated organization onboarding access code. Salted hash updated; previous credentials invalidated.`,
        targetId: currentOrg.id,
        targetName: currentOrg.name,
        result: 'warning',
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));
      setMessage('Company access code regenerated successfully and secured with salted hash. Previous code has been invalidated.');
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to regenerate company access code.');
    }
  };

  const handleCopyCode = () => {
    if (!accessCode) return;
    navigator.clipboard.writeText(accessCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleSaveBranding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg) return;
    setSaving(true);
    setMessage('');
    setErrorMessage('');

    try {
      let hash = currentOrg.accessPasswordHash;
      let salt = currentOrg.accessPasswordSalt;

      if (accessCode.trim() && (!hash || !salt || accessCode !== currentOrg.accessCode)) {
        const hashed = await hashCompanyPassword(accessCode.trim());
        hash = hashed.hash;
        salt = hashed.salt;
      }

      const updated: Partial<Organization> = {
        name: companyName.trim(),
        logoUrl: logoDataUrl,
        accentColor,
        accessCode: accessCode.trim() || undefined,
        accessPasswordHash: hash,
        accessPasswordSalt: salt,
        hasAccessPassword: !!accessCode.trim(),
      };

      await setDoc(doc(db, 'organizations', currentOrg.id), removeUndefinedFields(updated), { merge: true });
      await switchOrganization(currentOrg.id);
      await reloadUserData();
      setMessage('Workspace branding and settings successfully saved!');
    } catch (err) {
      console.error(err);
      setErrorMessage('Failed to save workspace settings.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* 1. Workspace Branding Form */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Palette className="w-5 h-5 text-sky-600" />
            <span>Workspace Branding & Identity</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Customize your company logo, display name, and accent color theme across the operations dashboard and technician mobile app.
          </p>
        </div>

        {message && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-2xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{message}</span>
          </div>
        )}

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold rounded-2xl">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSaveBranding} className="space-y-4 text-xs">
          {/* Company Name */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">Company / Organization Name</label>
            <input
              type="text"
              required
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
            />
          </div>

          {/* Logo Upload */}
          <div>
            <label className="block font-bold text-slate-700 mb-1">Company Logo</label>
            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center border border-slate-200 overflow-hidden bg-slate-50 text-white font-black text-xl shadow-xs"
                style={{ backgroundColor: !logoDataUrl ? accentColor : undefined }}
              >
                {logoDataUrl ? (
                  <img src={logoDataUrl} alt="Logo" className="w-full h-full object-contain p-1" />
                ) : (
                  companyName ? companyName.charAt(0).toUpperCase() : <Building2 className="w-6 h-6 text-slate-400" />
                )}
              </div>

              <div className="space-y-1.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-2xs transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5 text-sky-600" />
                    <span>Upload Logo Image</span>
                  </button>
                  {logoDataUrl && (
                    <button
                      type="button"
                      onClick={() => setLogoDataUrl('')}
                      className="px-2.5 py-1.5 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-semibold"
                    >
                      Remove
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-slate-400">
                  Recommended: Square PNG, JPG, or SVG (max 2 MB).
                </p>
              </div>
            </div>
          </div>

          {/* Brand Accent Color */}
          <div>
            <label className="block font-bold text-slate-700 mb-1.5">Brand Accent Color</label>
            <div className="flex items-center gap-2 flex-wrap">
              {predefinedColors.map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => setAccentColor(c.hex)}
                  className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 font-semibold text-xs transition-all ${
                    accentColor.toLowerCase() === c.hex.toLowerCase()
                      ? 'border-slate-800 bg-slate-900 text-white shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: c.hex }} />
                  <span>{c.label}</span>
                </button>
              ))}

              <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200">
                <input
                  type="color"
                  value={accentColor}
                  onChange={(e) => setAccentColor(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border border-slate-200 p-0"
                />
                <span className="font-mono text-slate-500 uppercase">{accentColor}</span>
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-xs transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving Changes...' : 'Save Workspace Branding'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* 2. Company Security & Access Credential */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-purple-600" />
              <span>Company Access Credential</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Secure company credential required for technicians when submitting join requests.
            </p>
          </div>
          <span className="px-2.5 py-1 bg-purple-50 text-purple-700 rounded-full text-[10px] font-bold border border-purple-200 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-purple-600" />
            <span>Salted SHA-256 Hashed</span>
          </span>
        </div>

        <div className="p-4 bg-purple-50/60 rounded-2xl border border-purple-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-[11px] font-bold text-purple-950 uppercase tracking-wider">
                Current Access Code
              </div>
              <div className="font-mono text-base font-black text-purple-900 tracking-widest mt-0.5">
                {accessCode ? (showAccessCode ? accessCode : '••••••••') : 'No Code Configured'}
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => setShowAccessCode(!showAccessCode)}
                className="px-3 py-1.5 bg-white border border-purple-200 hover:bg-purple-100/50 text-purple-900 text-xs font-semibold rounded-xl flex items-center gap-1 transition-colors"
              >
                {showAccessCode ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showAccessCode ? 'Hide' : 'Reveal'}</span>
              </button>

              <button
                type="button"
                onClick={handleCopyCode}
                disabled={!accessCode}
                className="px-3 py-1.5 bg-white border border-purple-200 hover:bg-purple-100/50 text-purple-900 text-xs font-semibold rounded-xl flex items-center gap-1 transition-colors disabled:opacity-50"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
              </button>

              <button
                type="button"
                onClick={handleRegenerateAccessCode}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-xs transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Regenerate Code</span>
              </button>
            </div>
          </div>

          <p className="text-[11px] text-purple-900/80 leading-relaxed">
            Technicians provide this access credential when submitting join requests to verify company affiliation. The credential is mathematically verified using salted cryptographic hashing and never exposed publicly.
          </p>
        </div>
      </div>
    </div>
  );
};
