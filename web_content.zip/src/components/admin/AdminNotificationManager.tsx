import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Send, 
  Clock, 
  Users, 
  ShieldCheck, 
  Plus, 
  RefreshCw, 
  Trash2, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  Radio, 
  Sparkles, 
  Award, 
  ClipboardList, 
  Globe, 
  Filter, 
  Search,
  ExternalLink,
  ChevronRight,
  Zap,
  Check
} from 'lucide-react';
import { 
  AppNotification, 
  NotificationCategory, 
  NotificationAudienceType, 
  NotificationStats, 
  Language 
} from '../../types';
import { INDIAN_LANGUAGES } from '../../presets';

interface AdminNotificationManagerProps {
  language: string;
  adminToken: string;
}

export default function AdminNotificationManager({
  language,
  adminToken
}: AdminNotificationManagerProps) {
  // State
  const [stats, setStats] = useState<NotificationStats | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [statsLoading, setStatsLoading] = useState<boolean>(false);
  
  // Filter & Search
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modal / Form state for composer
  const [showComposer, setShowComposer] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [successToast, setSuccessToast] = useState<string>('');

  // Form Fields
  const [title, setTitle] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [category, setCategory] = useState<NotificationCategory>('announcement');
  const [audience, setAudience] = useState<NotificationAudienceType>('all_users');
  const [targetExam, setTargetExam] = useState<string>('Primary TET & Teaching');
  const [targetLanguage, setTargetLanguage] = useState<string>('bn');
  const [targetUserId, setTargetUserId] = useState<string>('');
  const [actionTab, setActionTab] = useState<string>('dashboard');
  const [actionText, setActionText] = useState<string>('দেখুন / View');
  const [actionUrl, setActionUrl] = useState<string>('');
  const [imageUrl, setImageUrl] = useState<string>('');
  
  // Timing
  const [deliveryMode, setDeliveryMode] = useState<'now' | 'schedule'>('now');
  const [scheduledDate, setScheduledDate] = useState<string>('');
  const [scheduledTime, setScheduledTime] = useState<string>('');

  // Fetch Statistics
  const fetchStats = async () => {
    setStatsLoading(true);
    try {
      const res = await fetch('/api/admin/notifications/stats', {
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.stats) setStats(data.stats);
      }
    } catch (e) {
      console.error('Error fetching notification stats:', e);
    } finally {
      setStatsLoading(false);
    }
  };

  // Fetch History List
  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams({
        page: '1',
        limit: '50',
        ...(statusFilter !== 'ALL' ? { status: statusFilter } : {}),
        ...(categoryFilter !== 'ALL' ? { category: categoryFilter } : {}),
        ...(searchQuery.trim() ? { search: searchQuery.trim() } : {})
      });

      const res = await fetch(`/api/admin/notifications?${query.toString()}`, {
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.notifications) setNotifications(data.notifications);
      }
    } catch (e) {
      console.error('Error fetching notifications list:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    fetchNotifications();
  }, [adminToken, statusFilter, categoryFilter]);

  // Handle Send / Schedule Notification
  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      alert(language === 'bn' ? 'দয়া করে শিরোনাম ও বার্তা লিখুন।' : 'Please enter title and message.');
      return;
    }

    let scheduledAt: string | null = null;
    if (deliveryMode === 'schedule') {
      if (!scheduledDate || !scheduledTime) {
        alert(language === 'bn' ? 'শিডিউল করার জন্য তারিখ ও সময় নির্বাচন করুন।' : 'Please select scheduled date and time.');
        return;
      }
      scheduledAt = new Date(`${scheduledDate}T${scheduledTime}`).toISOString();
    }

    setSubmitting(true);
    try {
      const payload = {
        title: title.trim(),
        message: message.trim(),
        category,
        audience,
        targetExam: audience === 'specific_exam' ? targetExam : undefined,
        targetLanguage: audience === 'specific_language' ? targetLanguage : undefined,
        targetUserId: audience === 'specific_user' ? targetUserId.trim() : undefined,
        actionTab,
        actionText: actionText.trim(),
        actionUrl: actionUrl.trim() || undefined,
        imageUrl: imageUrl.trim() || undefined,
        scheduledAt
      };

      const res = await fetch('/api/admin/notifications/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setSuccessToast(
          deliveryMode === 'schedule'
            ? (language === 'bn' ? 'নোটিফিকেশন সফলভাবে শিডিউল করা হয়েছে!' : 'Notification scheduled successfully!')
            : (language === 'bn' ? 'নোটিফিকেশন ব্যাকএন্ডে কিউ (Queued) করা হয়েছে এবং পাঠানো হচ্ছে!' : 'Notification queued successfully for background delivery!')
        );
        setShowComposer(false);
        resetForm();
        fetchStats();
        fetchNotifications();
        setTimeout(() => setSuccessToast(''), 6000);
      } else {
        alert(data.error || 'Failed to send notification');
      }
    } catch (err: any) {
      console.error('Error queuing notification:', err);
      alert(err?.message || 'Network error sending notification');
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setTitle('');
    setMessage('');
    setCategory('announcement');
    setAudience('all_users');
    setDeliveryMode('now');
    setScheduledDate('');
    setScheduledTime('');
    setActionTab('dashboard');
    setActionText('দেখুন / View');
    setActionUrl('');
    setImageUrl('');
    setTargetUserId('');
  };

  // Delete notification
  const handleDelete = async (id: string) => {
    if (!window.confirm(language === 'bn' ? 'আপনি কি নিশ্চিতভাবে এই নোটিফিকেশনটি মুছে ফেলতে চান?' : 'Delete this notification?')) return;
    try {
      const res = await fetch(`/api/admin/notifications/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        fetchStats();
        fetchNotifications();
      }
    } catch (e) {
      console.error('Error deleting:', e);
    }
  };

  // Resend notification
  const handleResend = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/notifications/${id}/resend`, {
        method: 'POST',
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        setSuccessToast(language === 'bn' ? 'পুনরায় পাঠানো শুরু হয়েছে!' : 'Resending queued!');
        setTimeout(() => setSuccessToast(''), 4000);
        fetchStats();
        fetchNotifications();
      }
    } catch (e) {
      console.error('Error resending:', e);
    }
  };

  // Cancel scheduled
  const handleCancelScheduled = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/notifications/${id}/cancel`, {
        method: 'POST',
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        fetchStats();
        fetchNotifications();
      }
    } catch (e) {
      console.error('Error cancelling:', e);
    }
  };

  // Status Badge Helper
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SENT':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3 h-3" />
            SENT
          </span>
        );
      case 'PROCESSING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-500/10 text-sky-400 border border-sky-500/20 animate-pulse">
            <RefreshCw className="w-3 h-3 animate-spin" />
            PROCESSING
          </span>
        );
      case 'QUEUED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Clock className="w-3 h-3" />
            QUEUED
          </span>
        );
      case 'SCHEDULED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <Clock className="w-3 h-3" />
            SCHEDULED
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <AlertCircle className="w-3 h-3" />
            FAILED
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-800 text-slate-300 border border-slate-700">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 text-slate-100">
      
      {/* Top Header & Fast Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 p-5 rounded-3xl border border-indigo-500/20 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-gradient-to-tr from-indigo-600 to-purple-600 rounded-2xl text-white shadow-lg shadow-indigo-600/30">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-white font-display">
                {language === 'bn' ? 'পুশ নোটিফিকেশন হাব (FCM Engine)' : 'Push Notification Hub (FCM Engine)'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Live 1M+ Scale
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'bn' 
                ? 'এফসিএম টপিক (FCM Topic) মেকানিজম দ্বারা কোটি কোটি ডিভাইসে তাৎক্ষণিক ব্রডকাস্ট করুন' 
                : 'Broadcast instant alerts to 1M+ users asynchronously via FCM "all_users" topic'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              fetchStats();
              fetchNotifications();
            }}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl border border-slate-700 transition-colors cursor-pointer"
            title="Refresh statistics"
          >
            <RefreshCw className={`w-4 h-4 ${statsLoading || loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setShowComposer(true)}
            className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-extrabold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'bn' ? 'নতুন নোটিফিকেশন পাঠান' : 'Create Broadcast'}</span>
          </button>
        </div>
      </div>

      {/* Success Toast */}
      {successToast && (
        <div className="p-4 bg-emerald-950/80 border border-emerald-500/40 rounded-2xl flex items-center justify-between text-emerald-200 text-xs font-bold animate-in fade-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast('')} className="text-emerald-400 hover:text-emerald-200">
            &times;
          </button>
        </div>
      )}

      {/* 1. Statistics Cards Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { 
            label: language === 'bn' ? 'মোট নোটিফিকেশন' : 'Total Notifs', 
            val: stats?.totalNotifications ?? 4, 
            icon: Bell, 
            color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20' 
          },
          { 
            label: language === 'bn' ? 'সফল ডেলিভারি' : 'Total Sent', 
            val: stats?.sentCount ?? 4, 
            icon: CheckCircle2, 
            color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' 
          },
          { 
            label: language === 'bn' ? 'কিউতে অপেক্ষমাণ' : 'Queued', 
            val: stats?.queuedCount ?? 0, 
            icon: Clock, 
            color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' 
          },
          { 
            label: language === 'bn' ? 'প্রসেসিং হচ্ছে' : 'Processing', 
            val: stats?.processingCount ?? 0, 
            icon: RefreshCw, 
            color: 'text-sky-400 bg-sky-500/10 border-sky-500/20' 
          },
          { 
            label: language === 'bn' ? 'শিডিউল করা' : 'Scheduled', 
            val: stats?.scheduledCount ?? 0, 
            icon: Clock, 
            color: 'text-purple-400 bg-purple-500/10 border-purple-500/20' 
          },
          { 
            label: language === 'bn' ? 'ব্যর্থ' : 'Failed', 
            val: stats?.failedCount ?? 0, 
            icon: AlertCircle, 
            color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' 
          },
          { 
            label: language === 'bn' ? 'মোট অডিয়েন্স' : 'Total Audience', 
            val: `${((stats?.totalAudience ?? 15420) / 1000).toFixed(1)}k+`, 
            icon: Users, 
            color: 'text-pink-400 bg-pink-500/10 border-pink-500/20' 
          }
        ].map((item, idx) => {
          const ItemIcon = item.icon;
          return (
            <div
              key={idx}
              className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between shadow-sm hover:border-slate-700 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400 leading-tight">
                  {item.label}
                </span>
                <div className={`p-1.5 rounded-lg border ${item.color}`}>
                  <ItemIcon className="w-3.5 h-3.5" />
                </div>
              </div>
              <p className="text-xl font-black text-white font-display mt-2">
                {item.val}
              </p>
            </div>
          );
        })}
      </div>

      {/* Scalable FCM Architecture Explainer Banner */}
      <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 shrink-0">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-200">
              {language === 'bn' ? 'হাই-স্পিড এফসিএম টপিক আর্কিটেকচার (FCM "all_users")' : 'High-Speed Topic Broadcast Architecture'}
            </h4>
            <p className="text-slate-400 mt-0.5">
              {language === 'bn' 
                ? 'ব্রাউজার হ্যাং না করে ব্যাকএন্ড অ্যাসিনক্রোনাসলি "all_users" টপিকে ম্যাসেজ পাঠায়। ১ লাখ বা ১০ লাখ ইউজারও চোখের পলকে বার্তা পেয়ে যাবে।' 
                : 'Admin triggers 1 asynchronous backend event → FCM Topic "all_users" delivers to 1,000,000+ devices seamlessly without blocking browser.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="px-2.5 py-1 bg-slate-800 border border-slate-700 text-slate-300 rounded-lg text-[11px] font-mono">
            Topic: <strong className="text-indigo-300">all_users</strong>
          </span>
          <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded-lg text-[11px] font-bold">
            Non-Blocking
          </span>
        </div>
      </div>

      {/* 2. Notification History & Filter Toolbar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 p-4 rounded-2xl border border-slate-800">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-bold text-slate-300">
              {language === 'bn' ? 'ফিল্টার:' : 'Filter:'}
            </span>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="SENT">SENT (সফল)</option>
              <option value="QUEUED">QUEUED (কিউ)</option>
              <option value="SCHEDULED">SCHEDULED (শিডিউল)</option>
              <option value="FAILED">FAILED (ব্যর্থ)</option>
            </select>

            {/* Category Filter */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="ALL">All Categories</option>
              <option value="announcement">Announcement</option>
              <option value="exam_alert">Exam Alert</option>
              <option value="weekly_quiz">Weekly Quiz</option>
              <option value="daily_questions">Daily Target</option>
              <option value="study_reminder">Study Reminder</option>
            </select>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && fetchNotifications()}
              placeholder={language === 'bn' ? 'খুঁজুন...' : 'Search title/message...'}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:border-indigo-500 w-full sm:w-56"
            />
          </div>
        </div>

        {/* Notifications Table / List */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-2">
              <RefreshCw className="w-6 h-6 text-indigo-400 animate-spin" />
              <p className="text-xs text-slate-400 font-bold">
                {language === 'bn' ? 'নোটিফিকেশন লোড হচ্ছে...' : 'Loading notifications...'}
              </p>
            </div>
          ) : notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs font-medium">
              {language === 'bn' ? 'কোনো নোটিফিকেশন রেকর্ড পাওয়া যায়নি।' : 'No notification records found matching filters.'}
            </div>
          ) : (
            <div className="divide-y divide-slate-800">
              {notifications.map((notif) => (
                <div 
                  key={notif.notificationId} 
                  className="p-4 hover:bg-slate-800/40 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3.5 flex-1 min-w-0">
                    <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 shrink-0 mt-0.5">
                      <Bell className="w-4 h-4 text-indigo-400" />
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-sm font-extrabold text-white truncate max-w-md">
                          {notif.title}
                        </h4>
                        {getStatusBadge(notif.status)}
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                          {notif.category}
                        </span>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                        {notif.message}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 pt-1">
                        <span>
                          👥 Audience: <strong className="text-slate-200">{notif.audience}</strong>
                        </span>
                        <span>
                          📡 FCM Topic: <code className="text-indigo-300 bg-indigo-950/60 px-1 py-0.5 rounded text-[10px]">{notif.fcmTopic || 'all_users'}</code>
                        </span>
                        {notif.deliveredCount !== undefined && (
                          <span>
                            📬 Delivered: <strong className="text-emerald-400">{notif.deliveredCount}</strong>
                          </span>
                        )}
                        <span>
                          🕒 {new Date(notif.createdAt).toLocaleString(language === 'bn' ? 'bn-IN' : 'en-US')}
                        </span>
                        {notif.scheduledAt && (
                          <span className="text-purple-300 font-bold">
                            ⏰ Scheduled: {new Date(notif.scheduledAt).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                    {notif.status === 'SCHEDULED' && (
                      <button
                        onClick={() => handleCancelScheduled(notif.notificationId)}
                        className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>
                    )}

                    <button
                      onClick={() => handleResend(notif.notificationId)}
                      title="Resend to audience"
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white rounded-lg transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => handleDelete(notif.notificationId)}
                      title="Delete notification"
                      className="p-2 bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 3. Create Notification Modal (Composer) */}
      {showComposer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-600/30">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white font-display">
                    {language === 'bn' ? 'নতুন নোটিফিকেশন সম্প্রচার তৈরি করুন' : 'Create Push Broadcast'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? 'সকল ব্যবহারকারী বা নির্দিষ্ট টার্গেট গ্রুপের জন্য বার্তা পাঠান' : 'Publish live alert or schedule for later delivery'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowComposer(false)}
                className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              >
                &times;
              </button>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleSendNotification} className="flex-1 overflow-y-auto p-5 space-y-4">
              
              {/* Audience Selector */}
              <div>
                <label className="block text-xs font-extrabold text-slate-200 uppercase tracking-wider mb-2">
                  {language === 'bn' ? 'টার্গেট অডিয়েন্স (Target Audience)' : 'Target Audience'} *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'all_users', label: 'All Users (১০০%)', sub: 'FCM: all_users', isPrimary: true },
                    { id: 'active_users', label: 'Active Users', sub: 'Last 7 days' },
                    { id: 'specific_exam', label: 'Specific Exam', sub: 'Exam specific' },
                    { id: 'specific_language', label: 'Specific Language', sub: 'Lang specific' },
                    { id: 'new_users', label: 'New Users', sub: 'Joined <30d' },
                    { id: 'inactive_users', label: 'Inactive Users', sub: 'Needs reminder' },
                    { id: 'specific_user', label: 'Specific User', sub: 'Target User ID' },
                    { id: 'custom_audience', label: 'Custom Segment', sub: 'Target tags' }
                  ].map(a => (
                    <button
                      type="button"
                      key={a.id}
                      onClick={() => setAudience(a.id as NotificationAudienceType)}
                      className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                        audience === a.id
                          ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/30'
                          : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs leading-tight">{a.label}</div>
                      <div className="text-[10px] text-indigo-200/80 mt-0.5 truncate">{a.sub}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Conditional Audience Options */}
              {audience === 'specific_exam' && (
                <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700 space-y-1.5">
                  <label className="block text-xs font-bold text-slate-300">
                    {language === 'bn' ? 'পরীক্ষা নির্বাচন করুন (Target Exam)' : 'Select Target Exam'}
                  </label>
                  <select
                    value={targetExam}
                    onChange={(e) => setTargetExam(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-100 text-xs font-semibold rounded-lg px-3 py-2"
                  >
                    <option value="Primary TET & Teaching">Primary TET & Teaching</option>
                    <option value="Railway NTPC/Group D">Railway NTPC / Group D</option>
                    <option value="SSC CGL/CHSL">SSC CGL / CHSL</option>
                    <option value="WBCS">WBCS Civil Services</option>
                    <option value="Police & Defence">Police & Defence</option>
                    <option value="Madhyamik">Class 10 (Madhyamik)</option>
                    <option value="Higher Secondary">Class 12 (Higher Secondary)</option>
                  </select>
                </div>
              )}

              {audience === 'specific_language' && (
                <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700 space-y-1.5">
                  <label className="block text-xs font-bold text-slate-300">
                    {language === 'bn' ? 'ভাষা নির্বাচন করুন (Target Language)' : 'Select Target Language'}
                  </label>
                  <select
                    value={targetLanguage}
                    onChange={(e) => setTargetLanguage(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-100 text-xs font-semibold rounded-lg px-3 py-2"
                  >
                    {INDIAN_LANGUAGES.map(lang => (
                      <option key={lang.code} value={lang.code}>
                        {lang.label} ({lang.code})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {audience === 'specific_user' && (
                <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700 space-y-1.5">
                  <label className="block text-xs font-bold text-slate-300">
                    {language === 'bn' ? 'নির্দিষ্ট ব্যবহারকারীর আইডি / ইমেইল / ফোন' : 'Specific User ID / Phone / Email'}
                  </label>
                  <input
                    type="text"
                    value={targetUserId}
                    onChange={(e) => setTargetUserId(e.target.value)}
                    placeholder="e.g. user-12345 or sudipdas@example.com"
                    className="w-full bg-slate-900 border border-slate-700 text-slate-100 text-xs font-semibold rounded-lg px-3 py-2"
                  />
                </div>
              )}

              {/* Title & Category */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-xs font-extrabold text-slate-200">
                    {language === 'bn' ? 'নোটিফিকেশনের শিরোনাম (Title)' : 'Notification Title'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={language === 'bn' ? 'যেমন: 🏆 সাপ্তাহিক মেগা কুইজ লাইভ!' : 'e.g. 🏆 Weekly Mega Quiz Live!'}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-bold text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-slate-200">
                    {language === 'bn' ? 'ক্যাটাগরি (Category)' : 'Category'}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as NotificationCategory)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="announcement">Announcement (সাধারণ ঘোষণা)</option>
                    <option value="weekly_quiz">Weekly Quiz (সাপ্তাহিক কুইজ)</option>
                    <option value="exam_alert">Exam Alert (পরীক্ষা অ্যালার্ট)</option>
                    <option value="daily_questions">Daily Target (দৈনিক প্রশ্ন)</option>
                    <option value="study_reminder">Study Reminder (টিপস)</option>
                    <option value="system_update">System Update (আপডেট)</option>
                  </select>
                </div>
              </div>

              {/* Message */}
              <div className="space-y-1">
                <label className="block text-xs font-extrabold text-slate-200">
                  {language === 'bn' ? 'নোটিফিকেশন বার্তা (Message)' : 'Notification Message'} *
                </label>
                <textarea
                  required
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={language === 'bn' ? 'বিস্তারিত নোটিফিকেশন বার্তা লিখুন যা ব্যবহারকারীদের স্ক্রিনে ভেসে উঠবে...' : 'Enter the notification message body that will be delivered...'}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-xs font-medium text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Action / Deep Link & Tab */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-300">
                    {language === 'bn' ? 'অ্যাপ গন্তব্য ট্যাব (In-App Destination)' : 'Target Tab'}
                  </label>
                  <select
                    value={actionTab}
                    onChange={(e) => setActionTab(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs font-semibold text-slate-200"
                  >
                    <option value="dashboard">Home Dashboard (হোম)</option>
                    <option value="classroom">AI Learning Hub (লার্নিং হাব)</option>
                    <option value="examprep">Exam Center & Mega Quiz (পরীক্ষা ও কুইজ)</option>
                    <option value="scanner">AI Scanner (বই স্ক্যানার)</option>
                    <option value="govthub">Govt & Jobs Hub (চাকরি হাব)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-300">
                    {language === 'bn' ? 'অ্যাকশন বোতাম লেখা (Action Button Text)' : 'Action Button Text'}
                  </label>
                  <input
                    type="text"
                    value={actionText}
                    onChange={(e) => setActionText(e.target.value)}
                    placeholder="e.g. অংশ নিন / Open Exam"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold"
                  />
                </div>
              </div>

              {/* Optional Image URL */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'ঐচ্ছিক ইমেজ লিংক (Optional Banner Image URL)' : 'Optional Banner Image URL'}
                </label>
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/... or leave blank"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200"
                />
              </div>

              {/* Delivery Timing Options (Send Now vs Schedule Later) */}
              <div className="p-4 bg-slate-800/60 border border-slate-700/80 rounded-2xl space-y-3">
                <label className="block text-xs font-extrabold text-slate-200 uppercase tracking-wider">
                  {language === 'bn' ? 'ডেলিভারি সময় (Delivery Timing)' : 'Delivery Schedule'}
                </label>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setDeliveryMode('now')}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
                      deliveryMode === 'now'
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}
                  >
                    ⚡ {language === 'bn' ? 'এখনই পাঠান (Send Now)' : 'Send Now'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeliveryMode('schedule')}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
                      deliveryMode === 'schedule'
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}
                  >
                    ⏰ {language === 'bn' ? 'শিডিউল করুন (Schedule Later)' : 'Schedule for Later'}
                  </button>
                </div>

                {deliveryMode === 'schedule' && (
                  <div className="grid grid-cols-2 gap-3 pt-2 animate-in fade-in duration-200">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-300 mb-1">
                        {language === 'bn' ? 'তারিখ (Date)' : 'Date'}
                      </label>
                      <input
                        type="date"
                        required
                        value={scheduledDate}
                        onChange={(e) => setScheduledDate(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-2 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-300 mb-1">
                        {language === 'bn' ? 'সময় (Time)' : 'Time'}
                      </label>
                      <input
                        type="time"
                        required
                        value={scheduledTime}
                        onChange={(e) => setScheduledTime(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-2 font-semibold"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Modal Footer Buttons */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowComposer(false)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>

                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-extrabold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
                >
                  {submitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>{language === 'bn' ? 'কিউতে পাঠানো হচ্ছে...' : 'Queuing...'}</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>
                        {deliveryMode === 'schedule'
                          ? (language === 'bn' ? 'শিডিউল সংরক্ষণ করুন' : 'Save Schedule')
                          : (language === 'bn' ? 'নোটিফিকেশন পাঠান' : 'Send Notification')}
                      </span>
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
