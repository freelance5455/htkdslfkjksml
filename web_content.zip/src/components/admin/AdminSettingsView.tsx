import React, { useState, useEffect } from 'react';
import { 
  Lock, 
  KeyRound, 
  CheckCircle, 
  ShieldCheck, 
  Settings, 
  Save, 
  Clock, 
  Percent, 
  FileText,
  AlertTriangle,
  Mail,
  UserCheck,
  Eye,
  EyeOff,
  RefreshCw
} from 'lucide-react';
import { AdminQuizGlobalSettings } from '../../types';

interface AdminSettingsViewProps {
  language: string;
  adminToken: string;
  onSettingsUpdated: () => void;
}

export default function AdminSettingsView({
  language,
  adminToken,
  onSettingsUpdated
}: AdminSettingsViewProps) {
  const [settings, setSettings] = useState<AdminQuizGlobalSettings>({
    defaultDuration: 20,
    defaultMarksPerQuestion: 1,
    defaultNegativeMarking: true,
    defaultNegativeMarks: 0.25,
    leaderboardVisibility: true,
    resultVisibility: true,
    explanationVisibility: true,
    maxAttempts: 1,
    showPrizeSection: true,
    showCountdownTimer: true,
    adminEmail: 'sudipdas22061999@gmail.com',
    defaultRules: [
      'প্রত্যেক শিক্ষার্থী শুধুমাত্র ১ বার অংশগ্রহণের সুযোগ পাবে।',
      'সময়ের আগে সাবমিট করলে বোনাস টাইমিং স্কোর লিডারবোর্ডে অগ্রাধিকার পাবে।',
      'ভুল উত্তরের ক্ষেত্রে ২৫% (০.২৫) নেগেটিভ মার্কিং কার্যকর হবে।',
      'কোনো ট্যাব পরিবর্তন বা নকল শনাক্ত হলে ফলাফল স্বয়ংক্রিয় বাতিল হবে।'
    ]
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  
  // Password change state
  const [currentPassword, setCurrentPassword] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showCurrentPassword, setShowCurrentPassword] = useState<boolean>(false);
  const [showNewPassword, setShowNewPassword] = useState<boolean>(false);
  const [passwordLoading, setPasswordLoading] = useState<boolean>(false);
  const [passwordSuccess, setPasswordSuccess] = useState<string>('');
  const [passwordError, setPasswordError] = useState<string>('');

  useEffect(() => {
    fetch('/api/admin/settings', {
      headers: { 'x-admin-token': adminToken }
    })
      .then(res => res.json())
      .then(data => {
        if (data.settings) setSettings(data.settings);
      })
      .catch(err => console.error('Settings load error:', err))
      .finally(() => setLoading(false));
  }, [adminToken]);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        onSettingsUpdated();
      }
    } catch (err) {
      console.error('Save settings error:', err);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (!currentPassword.trim()) {
      setPasswordError(language === 'bn' ? 'বর্তমান পাসওয়ার্ড প্রদান করুন।' : 'Current password is required.');
      return;
    }

    if (newPassword.length < 8) {
      setPasswordError(language === 'bn' ? 'নতুন পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।' : 'New password must be at least 8 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError(language === 'bn' ? 'নতুন পাসওয়ার্ড ও কনফার্ম পাসওয়ার্ড মেলেনি।' : 'New passwords do not match.');
      return;
    }

    setPasswordLoading(true);
    try {
      const res = await fetch('/api/admin/update-credentials', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({
          currentPassword: currentPassword.trim(),
          newPassword: newPassword.trim()
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setPasswordSuccess(data.message || (language === 'bn' ? 'পাসওয়ার্ড সফলভাবে আপডেট করা হয়েছে!' : 'Password updated successfully!'));
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        setTimeout(() => setPasswordSuccess(''), 5000);
      } else {
        setPasswordError(data.message || data.error || (language === 'bn' ? 'পাসওয়ার্ড আপডেট ব্যর্থ হয়েছে।' : 'Failed to update password.'));
      }
    } catch (err) {
      setPasswordError('Network error updating password');
    } finally {
      setPasswordLoading(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-400 text-xs animate-pulse">লোড হচ্ছে...</div>;
  }

  return (
    <div className="p-4 sm:p-6 space-y-6">
      
      {/* Header */}
      <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl flex items-center justify-between gap-3 shadow-md">
        <div>
          <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-400" />
            {language === 'bn' ? 'গ্লোবাল সেটিংস ও সিকিউরিটি কনফিগারেশন' : 'Global Settings & Security Configuration'}
          </h3>
          <p className="text-xs text-slate-300">
            {language === 'bn' ? 'ডিফল্ট টাইমার, নেগেটিভ মার্কিং ও সিকিউর অ্যাডমিন অথেন্টিক্যাশন' : 'Default timing, negative marking & secure admin credentials'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Global Quiz Config Form */}
        <form onSubmit={handleSaveSettings} className="bg-slate-800/60 p-5 rounded-2xl border border-slate-700/80 space-y-4">
          <h4 className="text-sm font-black text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            {language === 'bn' ? 'ডিফল্ট কুইজ রুলস ও টাইমিং' : 'Default Parameters'}
          </h4>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Default Duration (Mins):</label>
              <input
                type="number"
                min={1}
                max={120}
                value={settings.defaultDuration || 20}
                onChange={(e) => setSettings({ ...settings, defaultDuration: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Default Marks / Question:</label>
              <input
                type="number"
                min={1}
                max={10}
                value={settings.defaultMarksPerQuestion || 1}
                onChange={(e) => setSettings({ ...settings, defaultMarksPerQuestion: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Default Negative Mark:</label>
              <input
                type="number"
                step="0.05"
                min={0}
                value={settings.defaultNegativeMarks || 0.25}
                onChange={(e) => setSettings({ ...settings, defaultNegativeMarks: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Negative Marking Enabled:</label>
              <select
                value={settings.defaultNegativeMarking ? 'yes' : 'no'}
                onChange={(e) => setSettings({ ...settings, defaultNegativeMarking: e.target.value === 'yes' })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
              >
                <option value="yes">Yes (নেগেটিভ মার্কিং কার্যকর)</option>
                <option value="no">No (কোনো নেগেটিভ মার্কিং নেই)</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">Default Instructions (One per line):</label>
            <textarea
              rows={4}
              value={(settings.defaultRules || []).join('\n')}
              onChange={(e) => setSettings({ ...settings, defaultRules: e.target.value.split('\n').filter(r => r.trim()) })}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200"
            />
          </div>

          {saveSuccess && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs font-bold flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4" />
              <span>সেটিংস সফলভাবে সংরক্ষিত হয়েছে!</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Save Global Rules</span>
          </button>
        </form>

        {/* Secure Admin Password Management Form */}
        <form onSubmit={handleChangePassword} className="bg-slate-800/60 p-5 rounded-2xl border border-slate-700/80 space-y-4 h-fit">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-black text-white flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-amber-400" />
              {language === 'bn' ? 'অ্যাডমিন সিকিউরিটি পাসওয়ার্ড পরিবর্তন' : 'Admin Security & Password'}
            </h4>
            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full text-[10px] font-bold flex items-center gap-1">
              <UserCheck className="w-3 h-3" />
              <span>Role: Admin</span>
            </span>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-700/80 rounded-xl space-y-1">
            <span className="text-[11px] text-slate-400 font-medium">Configured Admin Email:</span>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
              <Mail className="w-3.5 h-3.5" />
              <span>{settings.adminEmail || 'sudipdas22061999@gmail.com'}</span>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">
              {language === 'bn' ? 'বর্তমান পাসওয়ার্ড:' : 'Current Admin Password:'}
            </label>
            <div className="relative">
              <input
                type={showCurrentPassword ? 'text' : 'password'}
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-3 pr-10 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
              />
              <button
                type="button"
                onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                {showCurrentPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">
              {language === 'bn' ? 'নতুন পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর):' : 'New Admin Password (min 8 chars):'}
            </label>
            <div className="relative">
              <input
                type={showNewPassword ? 'text' : 'password'}
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-3 pr-10 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                {showNewPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-300">
              {language === 'bn' ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন:' : 'Confirm New Password:'}
            </label>
            <input
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          {passwordError && (
            <div className="p-3 bg-rose-950/60 border border-rose-500/50 rounded-xl text-rose-300 text-xs font-bold flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{passwordError}</span>
            </div>
          )}

          {passwordSuccess && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs font-bold flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{passwordSuccess}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={passwordLoading || !currentPassword.trim() || !newPassword.trim()}
            className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            {passwordLoading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Lock className="w-4 h-4" />
            )}
            <span>Update Admin Password</span>
          </button>
        </form>

      </div>

    </div>
  );
}
