import React, { useState } from 'react';
import { 
  X, 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertTriangle, 
  HelpCircle, 
  FileSpreadsheet,
  Download,
  Check
} from 'lucide-react';
import { MCQQuestion } from '../../types';

interface AdminBulkUploadModalProps {
  language: string;
  onClose: () => void;
  onImport: (questions: MCQQuestion[]) => void;
}

export default function AdminBulkUploadModal({
  language,
  onClose,
  onImport
}: AdminBulkUploadModalProps) {
  const [pasteText, setPasteText] = useState<string>('');
  const [parsedQuestions, setParsedQuestions] = useState<MCQQuestion[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [step, setStep] = useState<'upload' | 'preview'>('upload');

  // Sample CSV template
  const SAMPLE_CSV = `Question,Option A,Option B,Option C,Option D,Correct Answer (1-4),Explanation,Subject,Difficulty
পশ্চিমবঙ্গের সর্বোচ্চ শৃঙ্গ কোনটি?,টাইগার হিল,সান্দাকফু,ফালুট,সবরগ্রাম,2,সান্দাকফু পশ্চিমবঙ্গ ও পশ্চিমবঙ্গের সর্বোচ্চ শৃঙ্গ।,Geography,Easy
১৯০৫ সালে বঙ্গভঙ্গের সময় ভারতের বড়লাট কে ছিলেন?,লর্ড কার্জন,লর্ড ডালহৌসি,লর্ড ক্যানিং,লর্ড রিপন,1,১৯০৫ সালে লর্ড কার্জন বঙ্গভঙ্গ কার্যকর করেছিলেন।,History,Medium
মানবদেহের বৃহত্তম অন্তঃক্ষরা গ্রন্থি কোনটি?,পিটুইটারি,থাইরয়েড,অগ্ন্যাশয়,অ্যাড্রেনাল,2,থাইরয়েড গ্রন্থি মানবদেহের বৃহত্তম অন্তঃক্ষরা গ্রন্থি।,General Science,Medium`;

  const handleParseData = (text: string) => {
    const lines = text.trim().split('\n').filter(l => l.trim().length > 0);
    if (lines.length === 0) {
      setErrors(['কোনো ডাটা পাওয়া যায়নি']);
      return;
    }

    const newQuestions: MCQQuestion[] = [];
    const parseErrors: string[] = [];

    // Check if JSON format
    if (text.trim().startsWith('[') || text.trim().startsWith('{')) {
      try {
        const jsonData = JSON.parse(text);
        const arrayData = Array.isArray(jsonData) ? jsonData : jsonData.questions || [];
        arrayData.forEach((item: any, idx: number) => {
          if (!item.question || !Array.isArray(item.options) || item.options.length < 2) {
            parseErrors.push(`JSON Row ${idx + 1}: Question text or options missing.`);
          } else {
            newQuestions.push({
              id: item.id || `bulk-q-${Date.now()}-${idx}`,
              question: item.question,
              options: item.options.slice(0, 4),
              correctOptionIndex: typeof item.correctOptionIndex === 'number' ? item.correctOptionIndex : 0,
              explanation: item.explanation || 'সঠিক ব্যাখ্যা',
              subject: item.subject || 'General Knowledge',
              topic: item.topic || '',
              difficulty: item.difficulty || 'Medium'
            });
          }
        });
        setParsedQuestions(newQuestions);
        setErrors(parseErrors);
        setStep('preview');
        return;
      } catch (e) {
        // Not valid JSON, continue with CSV parser
      }
    }

    // CSV / TSV parsing
    const firstLine = lines && lines.length > 0 ? lines[0] : '';
    const startIndex = firstLine && (firstLine.toLowerCase().includes('question') || firstLine.toLowerCase().includes('option')) ? 1 : 0;

    for (let i = startIndex; i < lines.length; i++) {
      const line = lines[i];
      // Support comma or tab separated
      const delimiter = line.includes('\t') ? '\t' : ',';
      
      // Handle quoted commas properly
      const cols: string[] = [];
      let inQuotes = false;
      let currentField = '';
      
      for (let c = 0; c < line.length; c++) {
        const char = line[c];
        if (char === '"' || char === "'") {
          inQuotes = !inQuotes;
        } else if (char === delimiter && !inQuotes) {
          cols.push(currentField.trim());
          currentField = '';
        } else {
          currentField += char;
        }
      }
      cols.push(currentField.trim());

      if (cols.length < 6) {
        parseErrors.push(`Row ${i + 1}: Expected at least 6 columns (Question, Opt A, Opt B, Opt C, Opt D, Correct Index), found ${cols.length}`);
        continue;
      }

      const qText = cols[0];
      const optA = cols[1] || 'Option A';
      const optB = cols[2] || 'Option B';
      const optC = cols[3] || 'Option C';
      const optD = cols[4] || 'Option D';
      
      let correctIdx = 0;
      const rawCorrect = cols[5]?.trim().toUpperCase();
      if (rawCorrect === '1' || rawCorrect === 'A' || rawCorrect === 'OPT A' || rawCorrect === 'OPTION A') correctIdx = 0;
      else if (rawCorrect === '2' || rawCorrect === 'B' || rawCorrect === 'OPT B' || rawCorrect === 'OPTION B') correctIdx = 1;
      else if (rawCorrect === '3' || rawCorrect === 'C' || rawCorrect === 'OPT C' || rawCorrect === 'OPTION C') correctIdx = 2;
      else if (rawCorrect === '4' || rawCorrect === 'D' || rawCorrect === 'OPT D' || rawCorrect === 'OPTION D') correctIdx = 3;
      else if (!isNaN(Number(rawCorrect)) && Number(rawCorrect) >= 0 && Number(rawCorrect) <= 3) {
        correctIdx = Number(rawCorrect);
      }

      const explanation = cols[6] || 'বিশদ ব্যাখ্যা';
      const subject = cols[7] || 'General Knowledge';
      const difficulty = (cols[8] === 'Easy' || cols[8] === 'Hard') ? cols[8] : 'Medium';

      newQuestions.push({
        id: `bulk-csv-${Date.now()}-${i}`,
        question: qText,
        options: [optA, optB, optC, optD],
        correctOptionIndex: correctIdx,
        explanation,
        subject,
        difficulty
      });
    }

    setParsedQuestions(newQuestions);
    setErrors(parseErrors);
    setStep('preview');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      if (content) {
        setPasteText(content);
        handleParseData(content);
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmImport = () => {
    if (parsedQuestions.length === 0) return;
    onImport(parsedQuestions);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="bg-slate-800/90 border-b border-slate-700 px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-600/30 text-indigo-300 rounded-xl">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white">
                {language === 'bn' ? 'বাল্ক প্রশ্ন আপলোড উইজার্ড' : 'Bulk Question Upload Wizard'}
              </h3>
              <p className="text-[11px] text-slate-400">
                CSV, TSV, Excel Text or JSON 4-step validated parser
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          
          {step === 'upload' ? (
            <>
              {/* File drop / select */}
              <div className="border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-2xl p-6 text-center space-y-3 bg-slate-950/40 transition-all">
                <Upload className="w-8 h-8 text-indigo-400 mx-auto" />
                <div>
                  <label className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl cursor-pointer shadow-md inline-block">
                    {language === 'bn' ? 'ফাইল সিলেক্ট করুন (.csv, .txt, .json)' : 'Select File (.csv, .txt, .json)'}
                    <input
                      type="file"
                      accept=".csv,.tsv,.txt,.json"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                  <p className="text-[11px] text-slate-400 mt-2">
                    {language === 'bn' ? 'অথবা নিচের বক্সে সরাসরি কপি-পেস্ট করুন' : 'Or paste your question text below'}
                  </p>
                </div>
              </div>

              {/* Paste area */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300">
                    {language === 'bn' ? 'টেক্সট পেস্ট করুন (CSV/JSON Format):' : 'Paste CSV or JSON Data:'}
                  </label>
                  <button
                    onClick={() => setPasteText(SAMPLE_CSV)}
                    className="text-[11px] text-indigo-400 hover:underline cursor-pointer"
                  >
                    {language === 'bn' ? 'নমুনা ডাটা বসান' : 'Fill Sample Template'}
                  </button>
                </div>
                <textarea
                  rows={6}
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  placeholder="Question,Option A,Option B,Option C,Option D,Correct (1-4),Explanation..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Action */}
              <button
                onClick={() => handleParseData(pasteText)}
                disabled={!pasteText.trim()}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-black text-xs rounded-xl shadow-lg cursor-pointer transition-all"
              >
                {language === 'bn' ? 'পরবর্তী: ডাটা প্রিভিউ ও ভ্যালিডেশন' : 'Next: Preview & Validation'}
              </button>
            </>
          ) : (
            <>
              {/* Preview header */}
              <div className="flex items-center justify-between bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                  <span className="text-xs font-black text-white">
                    {parsedQuestions.length} {language === 'bn' ? 'টি প্রশ্ন সফলভাবে যাচাই করা হয়েছে' : 'Questions parsed successfully'}
                  </span>
                </div>

                <button
                  onClick={() => setStep('upload')}
                  className="text-xs text-indigo-400 hover:underline cursor-pointer"
                >
                  {language === 'bn' ? '← পুনরায় আপলোড' : '← Re-upload'}
                </button>
              </div>

              {/* Error messages if any */}
              {errors.length > 0 && (
                <div className="bg-amber-950/40 border border-amber-500/40 rounded-xl p-3 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
                    <AlertTriangle className="w-4 h-4" />
                    <span>{errors.length} {language === 'bn' ? 'টি লাইনে ত্রুটি পাওয়া গেছে (এগুলো বাদ দেওয়া হয়েছে):' : 'Issues detected:'}</span>
                  </div>
                  <ul className="text-[11px] text-amber-200/80 list-disc pl-4 space-y-0.5 max-h-24 overflow-y-auto">
                    {errors.map((err, idx) => (
                      <li key={idx}>{err}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Questions preview list */}
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {parsedQuestions.map((q, idx) => (
                  <div key={idx} className="bg-slate-950/70 border border-slate-800 p-3 rounded-xl space-y-1 text-xs">
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-bold text-white">
                        {idx + 1}. {q.question}
                      </span>
                      <span className="px-2 py-0.5 bg-indigo-950 text-indigo-300 text-[10px] font-bold rounded-md shrink-0">
                        {q.subject}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-300 pt-1">
                      {q.options.map((opt, oIdx) => (
                        <div 
                          key={oIdx}
                          className={`p-1.5 rounded-lg border ${
                            oIdx === q.correctOptionIndex 
                              ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-bold' 
                              : 'bg-slate-900 border-slate-800 text-slate-400'
                          }`}
                        >
                          {opt} {oIdx === q.correctOptionIndex ? '✓' : ''}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Import button */}
              <button
                onClick={handleConfirmImport}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>{language === 'bn' ? `কুইজে এই ${parsedQuestions.length}টি প্রশ্ন যুক্ত করুন` : `Import ${parsedQuestions.length} Questions to Quiz`}</span>
              </button>
            </>
          )}

        </div>

      </div>
    </div>
  );
}
