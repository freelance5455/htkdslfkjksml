import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext.tsx';
import { VouchItem, VouchStatus } from '../../types/index.ts';
import {
  Star,
  ShieldCheck,
  Check,
  X,
  Edit2,
  Trash2,
  RotateCcw,
  Calendar,
  Package,
  Search
} from 'lucide-react';

interface AdminVouchManagementProps {
  onShowToast?: (text: string, type?: 'success' | 'error') => void;
}

export const AdminVouchManagement: React.FC<AdminVouchManagementProps> = ({ onShowToast }) => {
  const {
    vouches,
    vouchStats,
    vouchProductOptions,
    updateVouchAdmin,
    deleteVouchAdmin
  } = useData();

  const [activeTab, setActiveTab] = useState<VouchStatus>('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Edit modal state
  const [editingVouch, setEditingVouch] = useState<VouchItem | null>(null);
  const [editForm, setEditForm] = useState<{
    name: string;
    discordUsername: string;
    productOrService: string;
    feedback: string;
    rating: number;
    isVerified: boolean;
    status: VouchStatus;
  }>({
    name: '',
    discordUsername: '',
    productOrService: '',
    feedback: '',
    rating: 5,
    isVerified: false,
    status: 'approved'
  });
  const [savingEdit, setSavingEdit] = useState(false);

  // Delete confirmation modal state
  const [deleteTarget, setDeleteTarget] = useState<VouchItem | null>(null);

  const counts = useMemo(() => {
    return {
      pending: vouches.filter((v) => v.status === 'pending').length,
      approved: vouches.filter((v) => v.status === 'approved').length,
      rejected: vouches.filter((v) => v.status === 'rejected').length
    };
  }, [vouches]);

  const filteredList = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return vouches
      .filter((v) => v.status === activeTab)
      .filter((v) => {
        if (!q) return true;
        return (
          v.name.toLowerCase().includes(q) ||
          v.discordUsername.toLowerCase().includes(q) ||
          v.productOrService.toLowerCase().includes(q) ||
          v.feedback.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        if (activeTab === 'approved') {
          return (
            new Date(b.approvedAt || b.createdAt || 0).getTime() -
            new Date(a.approvedAt || a.createdAt || 0).getTime()
          );
        }
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
      });
  }, [vouches, activeTab, searchQuery]);

  const notify = (msg: string, type: 'success' | 'error' = 'success') => {
    if (onShowToast) onShowToast(msg, type);
  };

  const handleStatusChange = async (
    vouch: VouchItem,
    nextStatus: VouchStatus,
    markVerified?: boolean
  ) => {
    setProcessingId(vouch.id);
    try {
      const payload: { status: VouchStatus; isVerified?: boolean } = { status: nextStatus };
      if (typeof markVerified === 'boolean') {
        payload.isVerified = markVerified;
      }
      const res = await updateVouchAdmin(vouch.id, payload);
      if (res.success) {
        if (nextStatus === 'approved') {
          notify(`Approved vouch from ${vouch.name}.`);
        } else if (nextStatus === 'rejected') {
          notify(`Moved vouch from ${vouch.name} to Rejected.`);
        } else {
          notify(`Restored vouch from ${vouch.name} to Pending.`);
        }
      } else {
        notify(res.error || 'Failed to update vouch status.', 'error');
      }
    } finally {
      setProcessingId(null);
    }
  };

  const handleToggleVerified = async (vouch: VouchItem) => {
    setProcessingId(vouch.id);
    try {
      const nextVal = !vouch.isVerified;
      const res = await updateVouchAdmin(vouch.id, { isVerified: nextVal });
      if (res.success) {
        notify(
          nextVal
            ? `Marked ${vouch.name} as Verified Client.`
            : `Removed Verified Client badge from ${vouch.name}.`
        );
      } else {
        notify(res.error || 'Failed to update Verified Client status.', 'error');
      }
    } finally {
      setProcessingId(null);
    }
  };

  const openEditModal = (vouch: VouchItem) => {
    setEditingVouch(vouch);
    setEditForm({
      name: vouch.name,
      discordUsername: vouch.discordUsername,
      productOrService: vouch.productOrService,
      feedback: vouch.feedback,
      rating: vouch.rating,
      isVerified: Boolean(vouch.isVerified),
      status: vouch.status
    });
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVouch || savingEdit) return;
    if (!editForm.name.trim() || !editForm.discordUsername.trim() || !editForm.feedback.trim()) {
      notify('Name, Discord Username, and Feedback are required.', 'error');
      return;
    }

    setSavingEdit(true);
    try {
      const res = await updateVouchAdmin(editingVouch.id, {
        name: editForm.name.trim(),
        discordUsername: editForm.discordUsername.trim(),
        productOrService: editForm.productOrService.trim() || 'Other',
        feedback: editForm.feedback.trim(),
        rating: editForm.rating,
        isVerified: editForm.isVerified,
        status: editForm.status
      });
      if (res.success) {
        notify('Vouch updated and synchronized.');
        setEditingVouch(null);
      } else {
        notify(res.error || 'Failed to save vouch changes.', 'error');
      }
    } finally {
      setSavingEdit(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const id = deleteTarget.id;
    const targetName = deleteTarget.name;
    setProcessingId(id);
    setDeleteTarget(null);
    try {
      const res = await deleteVouchAdmin(id);
      if (res.success) {
        notify(`Permanently deleted vouch from ${targetName}.`);
      } else {
        notify(res.error || 'Failed to delete vouch.', 'error');
      }
    } finally {
      setProcessingId(null);
    }
  };

  const formatDate = (iso?: string | null) => {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return iso;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Vouch Management</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Review incoming client vouches, approve or reject submissions, assign Verified Client badges, and manage published feedback.
          </p>
        </div>
      </div>

      {/* Live Reputation & Status Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#060f1d] border border-slate-800/90">
          <div className="text-[11px] font-mono uppercase text-slate-400">Pending Review</div>
          <div className="text-2xl font-bold text-amber-300 font-mono mt-1">{counts.pending}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Awaiting moderation</div>
        </div>

        <div className="p-4 rounded-xl bg-[#060f1d] border border-slate-800/90">
          <div className="text-[11px] font-mono uppercase text-slate-400">Approved Vouches</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono mt-1">
            {vouchStats.totalVouches}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Live on website</div>
        </div>

        <div className="p-4 rounded-xl bg-[#060f1d] border border-slate-800/90">
          <div className="text-[11px] font-mono uppercase text-slate-400">Client Rating</div>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="text-2xl font-bold text-white font-mono">
              {vouchStats.formattedRating}
            </span>
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Calculated from approved</div>
        </div>

        <div className="p-4 rounded-xl bg-[#060f1d] border border-slate-800/90">
          <div className="text-[11px] font-mono uppercase text-slate-400">Rejected</div>
          <div className="text-2xl font-bold text-slate-300 font-mono mt-1">{counts.rejected}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Hidden from public</div>
        </div>
      </div>

      {/* Category Tabs (Pending, Approved, Rejected) & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#060f1d] border border-slate-800/90">
        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              { id: 'pending' as const, label: 'Pending', count: counts.pending },
              { id: 'approved' as const, label: 'Approved', count: counts.approved },
              { id: 'rejected' as const, label: 'Rejected', count: counts.rejected }
            ]
          ).map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  active
                    ? 'bg-cyan-400 text-slate-950'
                    : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                    active ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search name, Discord, product..."
            className="w-full pl-8 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
          />
        </div>
      </div>

      {/* Vouch List for Selected Status Tab */}
      {filteredList.length === 0 ? (
        <div className="rounded-xl bg-[#060f1d] border border-slate-800/90 p-10 text-center space-y-2">
          <div className="text-sm font-bold text-white">
            No {activeTab} vouches found
          </div>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            {activeTab === 'pending'
              ? 'New customer submissions from the website will appear here for review before going live.'
              : activeTab === 'approved'
              ? 'Approved vouches will be listed here and displayed publicly on the Homepage and /vouches page.'
              : 'Rejected vouch submissions will be stored here.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredList.map((vouch) => {
            const isBusy = processingId === vouch.id;
            return (
              <div
                key={vouch.id}
                className="rounded-xl bg-[#060f1d] border border-slate-800/90 p-5 space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3.5 border-b border-slate-800/80">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-base font-bold text-white">{vouch.name}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-300">
                        Discord: {vouch.discordUsername}
                      </span>
                      {vouch.isVerified && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold">
                          <ShieldCheck className="w-3 h-3 text-emerald-400" />
                          <span>Verified Client</span>
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
                      <span className="inline-flex items-center gap-1.5 text-slate-200 font-medium">
                        <Package className="w-3.5 h-3.5 text-cyan-400" />
                        <span>{vouch.productOrService}</span>
                      </span>
                      <span className="inline-flex items-center gap-1 font-mono text-[11px]">
                        <Calendar className="w-3 h-3 text-slate-500" />
                        <span>Submitted: {formatDate(vouch.createdAt)}</span>
                      </span>
                      {vouch.approvedAt && vouch.status === 'approved' && (
                        <span className="inline-flex items-center gap-1 font-mono text-[11px] text-emerald-400">
                          <span>Approved: {formatDate(vouch.approvedAt)}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Star Rating */}
                  <div className="flex items-center gap-1 shrink-0">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-4 h-4 ${
                          star <= vouch.rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-700'
                        }`}
                      />
                    ))}
                    <span className="text-xs font-mono font-bold text-amber-300 ml-1">
                      {vouch.rating}/5
                    </span>
                  </div>
                </div>

                {/* Complete Feedback */}
                <p className="text-slate-200 text-sm leading-relaxed whitespace-pre-line">
                  {vouch.feedback}
                </p>

                {/* Moderation Actions */}
                <div className="pt-2 border-t border-slate-800/70 flex flex-wrap items-center justify-between gap-3">
                  {/* Left: Verified Client Toggle & Edit */}
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => handleToggleVerified(vouch)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer disabled:opacity-50 ${
                        vouch.isVerified
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-white'
                      }`}
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>
                        {vouch.isVerified ? 'Verified Client (Active)' : 'Mark Verified Client'}
                      </span>
                    </button>

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => openEditModal(vouch)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-200 hover:text-white text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Edit Details</span>
                    </button>
                  </div>

                  {/* Right: Status Transitions & Delete */}
                  <div className="flex flex-wrap items-center gap-2">
                    {activeTab === 'pending' && (
                      <>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleStatusChange(vouch, 'approved')}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold transition-colors cursor-pointer disabled:opacity-50"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Approve</span>
                        </button>

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleStatusChange(vouch, 'approved', true)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-extrabold transition-colors cursor-pointer disabled:opacity-50"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Approve + Verify</span>
                        </button>

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleStatusChange(vouch, 'rejected')}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </>
                    )}

                    {activeTab === 'approved' && (
                      <>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleStatusChange(vouch, 'pending')}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-800 text-amber-300 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Move to Pending</span>
                        </button>

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleStatusChange(vouch, 'rejected')}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </>
                    )}

                    {activeTab === 'rejected' && (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => handleStatusChange(vouch, 'pending')}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/35 text-cyan-300 text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Restore to Pending</span>
                      </button>
                    )}

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => setDeleteTarget(vouch)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit Vouch Modal */}
      {editingVouch && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Edit Vouch Details</h3>
              <button
                type="button"
                onClick={() => setEditingVouch(null)}
                className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Customer Name</label>
                  <input
                    type="text"
                    required
                    value={editForm.name}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Discord Username</label>
                  <input
                    type="text"
                    required
                    value={editForm.discordUsername}
                    onChange={(e) => setEditForm({ ...editForm, discordUsername: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Product / Service Purchased
                  </label>
                  <select
                    value={editForm.productOrService}
                    onChange={(e) => setEditForm({ ...editForm, productOrService: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                  >
                    {!vouchProductOptions.includes(editForm.productOrService) &&
                      editForm.productOrService && (
                        <option value={editForm.productOrService}>{editForm.productOrService}</option>
                      )}
                    {vouchProductOptions.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Publication Status</label>
                  <select
                    value={editForm.status}
                    onChange={(e) =>
                      setEditForm({ ...editForm, status: e.target.value as VouchStatus })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                  >
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Star Rating (1–5)</label>
                <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setEditForm({ ...editForm, rating: star })}
                      className="p-1 cursor-pointer"
                    >
                      <Star
                        className={`w-5 h-5 ${
                          star <= editForm.rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-700'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="font-mono text-amber-300 ml-2">{editForm.rating}/5</span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Written Feedback</label>
                <textarea
                  rows={4}
                  required
                  value={editForm.feedback}
                  onChange={(e) => setEditForm({ ...editForm, feedback: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white leading-relaxed"
                />
              </div>

              <label className="flex items-center gap-2.5 p-3 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={editForm.isVerified}
                  onChange={(e) => setEditForm({ ...editForm, isVerified: e.target.checked })}
                  className="rounded accent-cyan-400 cursor-pointer"
                />
                <span className="font-semibold text-slate-200">
                  Display subtle "Verified Client" badge on this review
                </span>
              </label>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingVouch(null)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="px-4 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold cursor-pointer disabled:opacity-50"
                >
                  {savingEdit ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">Delete Vouch Permanently</h3>
            <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed">
              Are you sure you want to permanently delete the vouch submitted by{' '}
              <strong className="text-white">{deleteTarget.name}</strong> ({deleteTarget.discordUsername})? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
