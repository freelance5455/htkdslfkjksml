import React, { useState } from 'react';
import { 
  Save, 
  ArrowLeft, 
  HelpCircle, 
  Calendar, 
  Clock, 
  Gift, 
  ShieldAlert, 
  FileText, 
  Sparkles,
  BookOpen,
  CheckCircle,
  Percent,
  Tv,
  Bell,
  Sliders,
  Layers,
  Image as ImageIcon
} from 'lucide-react';
import { WeeklyQuiz, MCQQuestion } from '../../types';
import AdminQuestionManager from './AdminQuestionManager';
import AdminPrizeManager from './AdminPrizeManager';

interface AdminQuizEditorProps {
  language: string;
  quiz: Partial<WeeklyQuiz>;
  adminToken: string;
  isNew: boolean;
  onSave: (quizData: Partial<WeeklyQuiz>) => void;
  onCancel: () => void;
}

export default function AdminQuizEditor({
  language,
  quiz,
  adminToken,
  isNew,
  onSave,
  onCancel
}: AdminQuizEditorProps) {
  const [activeSubTab, setActiveSubTab] = useState<'basic' | 'questions' | 'prize' | 'rules' | 'notifications'>('basic');
  const [customTimeLimitSelected, setCustomTimeLimitSelected] = useState<boolean>(
    quiz.timeLimit ? ![5, 10, 15, 20, 25, 30, 45, 60, 90].includes(quiz.timeLimit) : false
  );

  const [formData, setFormData] = useState<Partial<WeeklyQuiz>>({
    id: quiz.id || `weekly-quiz-${Date.now()}`,
    weekNumber: quiz.weekNumber || 1,
    title: quiz.title || 'Weekly Mega Quiz Challenge 2026',
    shortDescription: quiz.shortDescription || 'সর্বোচ্চ নম্বর ও দ্রুততম সময়ে সম্পন্ন করে জিতে নিন আকর্ষণীয় পুরস্কার!',
    fullDescription: quiz.fullDescription || quiz.description || 'এই সাপ্তাহিক কুইজে নির্ধারিত সময়ে অংশগ্রহণ করুন। সকল প্রশ্নের সঠিক উত্তর দিয়ে লিডারবোর্ডের শীর্ষে উঠে জিতে নিন আকর্ষণীয় পুরস্কার।',
    description: quiz.description || 'সর্বোচ্চ নম্বর ও দ্রুততম সময়ে সম্পন্ন করে জিতে নিন আকর্ষণীয় পুরস্কার!',
    targetLevel: quiz.targetLevel || 'SSC CHSL / CGL & All Competitive Exams',
    subjects: quiz.subjects || ['Quantitative Aptitude', 'Reasoning', 'General Knowledge', 'General Science'],
    timeLimit: quiz.timeLimit || 20,
    questionCount: quiz.questionCount || quiz.questions?.length || 20,
    startDate: quiz.startDate || new Date().toISOString().split('T')[0],
    startTime: quiz.startTime || '10:00 AM',
    endDate: quiz.endDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    endTime: quiz.endTime || '11:59 PM',
    status: quiz.status || 'live',
    
    // Ads & Entry
    requireAdsBeforeQuiz: quiz.requireAdsBeforeQuiz !== false,
    numberOfAds: quiz.numberOfAds ?? 2,
    adWatchSeconds: quiz.adWatchSeconds || 5,

    // Notification Reminder
    notificationReminderEnabled: quiz.notificationReminderEnabled !== false,
    notificationReminderMinutes: quiz.notificationReminderMinutes || 10,
    notificationTitle: quiz.notificationTitle || '',
    notificationMessage: quiz.notificationMessage || '',
    enable10MinAlerts: quiz.enable10MinAlerts !== false,

    // Scoring & Marking
    negativeMarking: quiz.negativeMarking ?? true,
    negativeMarksPerWrong: quiz.negativeMarksPerWrong ?? 0.25,
    marksPerQuestion: quiz.marksPerQuestion ?? 1.0,
    maxAttempts: quiz.maxAttempts || 1,

    // Prize
    prizeName: quiz.prizeName || 'Executive Hardbound Notebook & Study Planner Set',
    prizeDescription: quiz.prizeDescription || '১ম স্থানাধিকারী শীর্ষ শিক্ষার্থীকে সম্পূর্ণ বিনামূল্যে কুরিয়ারে পাঠানো হবে।',
    prizeImage: quiz.prizeImage || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
    prizeValue: quiz.prizeValue || '₹750',
    prizePosition: quiz.prizePosition || '1st Prize',
    prizeTerms: quiz.prizeTerms || 'ফিজিক্যাল কুরিয়ারের মাধ্যমে বিজয়ীর ঠিকানায় পৌঁছে দেওয়া হবে।',
    
    questions: quiz.questions || [],
    rules: quiz.rules || [
      'প্রত্যেক শিক্ষার্থী শুধুমাত্র ১ বার অংশগ্রহণের সুযোগ পাবে।',
      'সময়ের আগে সাবমিট করলে বোনাস টাইমিং স্কোর লিডারবোর্ডে অগ্রাধিকার পাবে।',
      'ভুল উত্তরের ক্ষেত্রে ২৫% (০.২৫) নেগেটিভ মার্কিং কার্যকর হবে।',
      'কোনো ট্যাব পরিবর্তন বা নকল শনাক্ত হলে ফলাফল স্বয়ংক্রিয় বাতিল হবে।'
    ]
  });

  const [subjectInput, setSubjectInput] = useState<string>('');

  const handleAddSubject = () => {
    if (subjectInput.trim() && !formData.subjects?.includes(subjectInput.trim())) {
      setFormData({
        ...formData,
        subjects: [...(formData.subjects || []), subjectInput.trim()]
      });
      setSubjectInput('');
    }
  };

  const handleRemoveSubject = (sub: string) => {
    setFormData({
      ...formData,
      subjects: formData.subjects?.filter(s => s !== sub)
    });
  };

  const handleQuestionsChange = (newQuestions: MCQQuestion[]) => {
    setFormData({
      ...formData,
      questions: newQuestions,
      questionCount: newQuestions.length
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      questionCount: formData.questions?.length || formData.questionCount || 0
    });
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-6">
      
      {/* Top Header & Save/Cancel Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="p-2 bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white rounded-xl cursor-pointer transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h3 className="text-base sm:text-lg font-black text-white">
              {isNew ? (language === 'bn' ? 'নতুন কুইজ তৈরি করুন' : 'Create Weekly Quiz') : (language === 'bn' ? 'কুইজ এডিটর' : 'Edit Weekly Quiz')}
            </h3>
            <p className="text-xs text-slate-400">
              {formData.title} • Week #{formData.weekNumber || 1}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer transition-all"
          >
            {language === 'bn' ? 'বাতিল' : 'Cancel'}
          </button>

          <button
            type="submit"
            className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
          >
            <Save className="w-4 h-4" />
            <span>{language === 'bn' ? 'কুইজ সেভ করুন' : 'Save Quiz'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 text-xs">
        <button
          type="button"
          onClick={() => setActiveSubTab('basic')}
          className={`px-3.5 py-2 rounded-xl font-black cursor-pointer transition-all flex items-center gap-1.5 ${
            activeSubTab === 'basic' 
              ? 'bg-indigo-600 text-white shadow-md' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>1. {language === 'bn' ? 'তথ্য ও সময়' : 'Basic & Schedule'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('questions')}
          className={`px-3.5 py-2 rounded-xl font-black cursor-pointer transition-all flex items-center gap-1.5 ${
            activeSubTab === 'questions' 
              ? 'bg-indigo-600 text-white shadow-md' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>2. {language === 'bn' ? 'প্রশ্ন সম্ভার' : 'Questions'} ({formData.questions?.length || 0})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('prize')}
          className={`px-3.5 py-2 rounded-xl font-black cursor-pointer transition-all flex items-center gap-1.5 ${
            activeSubTab === 'prize' 
              ? 'bg-amber-600 text-white shadow-md' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Gift className="w-4 h-4" />
          <span>3. {language === 'bn' ? 'পুরস্কার' : 'Prize'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('rules')}
          className={`px-3.5 py-2 rounded-xl font-black cursor-pointer transition-all flex items-center gap-1.5 ${
            activeSubTab === 'rules' 
              ? 'bg-indigo-600 text-white shadow-md' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>4. {language === 'bn' ? 'মার্কিং ও রুলস' : 'Marking & Rules'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('notifications')}
          className={`px-3.5 py-2 rounded-xl font-black cursor-pointer transition-all flex items-center gap-1.5 ${
            activeSubTab === 'notifications' 
              ? 'bg-purple-600 text-white shadow-md' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bell className="w-4 h-4" />
          <span>5. {language === 'bn' ? 'নোটিফিকেশন ও এড' : 'Alerts & Ads'}</span>
        </button>
      </div>

      {/* Sub-Tab 1: Basic Info & Schedule */}
      {activeSubTab === 'basic' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Title, Week & Description */}
            <div className="space-y-4 bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80">
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2 space-y-1">
                  <label className="text-xs font-bold text-slate-300">Quiz Title:</label>
                  <input
                    type="text"
                    required
                    value={formData.title || ''}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g. Weekly Mega Quiz Challenge 2026"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">Week #:</label>
                  <input
                    type="number"
                    min={1}
                    value={formData.weekNumber || 1}
                    onChange={(e) => setFormData({ ...formData, weekNumber: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Target Exam / Standard:</label>
                <input
                  type="text"
                  value={formData.targetLevel || ''}
                  onChange={(e) => setFormData({ ...formData, targetLevel: e.target.value })}
                  placeholder="e.g. SSC CHSL / CGL & Competitive Exams"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Short Description (for compact card):</label>
                <input
                  type="text"
                  value={formData.shortDescription || ''}
                  onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value, description: e.target.value })}
                  placeholder="1 sentence summary shown on compact quiz card"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Full Description (for details modal):</label>
                <textarea
                  rows={3}
                  value={formData.fullDescription || formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, fullDescription: e.target.value })}
                  placeholder="Detailed guidelines, objectives and motivational overview"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Schedule & Timer */}
            <div className="space-y-4 bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80">
              
              {/* Quick Presets for Multi-Quiz Schedule */}
              <div className="space-y-1.5 pb-2 border-b border-slate-700/60">
                <span className="text-[11px] font-black text-amber-400 uppercase tracking-wider block">
                  ⚡ {language === 'bn' ? 'কুইক শিডিউল প্রিসেট (আজ সন্ধ্যা / কাল সকাল):' : 'Quick Schedule Presets:'}
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      const today = new Date().toISOString().split('T')[0];
                      setFormData({
                        ...formData,
                        startDate: today,
                        endDate: today,
                        startTime: '07:00 PM',
                        endTime: '11:00 PM',
                        status: 'scheduled'
                      });
                    }}
                    className="p-2 bg-slate-900 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-[11px] font-bold text-left cursor-pointer transition-all flex items-center gap-1"
                  >
                    <span>🌆</span>
                    <span>{language === 'bn' ? 'আজ সন্ধ্যা (7:00 PM)' : 'Today Evening 7 PM'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
                      setFormData({
                        ...formData,
                        startDate: tomorrow,
                        endDate: tomorrow,
                        startTime: '09:00 AM',
                        endTime: '01:00 PM',
                        status: 'scheduled'
                      });
                    }}
                    className="p-2 bg-slate-900 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-[11px] font-bold text-left cursor-pointer transition-all flex items-center gap-1"
                  >
                    <span>🌅</span>
                    <span>{language === 'bn' ? 'কাল সকাল (9:00 AM)' : 'Tomorrow 9:00 AM'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const today = new Date().toISOString().split('T')[0];
                      const end = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];
                      setFormData({
                        ...formData,
                        startDate: today,
                        endDate: end,
                        startTime: '10:00 AM',
                        endTime: '11:59 PM',
                        status: 'live'
                      });
                    }}
                    className="p-2 bg-indigo-950 hover:bg-indigo-900 text-indigo-200 border border-indigo-500/40 rounded-xl text-[11px] font-bold text-left cursor-pointer transition-all flex items-center gap-1"
                  >
                    <span>🏆</span>
                    <span>{language === 'bn' ? '৭ দিনের মেগা কুইজ' : '7-Day Mega Weekly'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const today = new Date().toISOString().split('T')[0];
                      setFormData({
                        ...formData,
                        startDate: today,
                        endDate: today,
                        startTime: '08:00 PM',
                        endTime: '09:00 PM',
                        timeLimit: 20,
                        status: 'scheduled'
                      });
                    }}
                    className="p-2 bg-slate-900 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-[11px] font-bold text-left cursor-pointer transition-all flex items-center gap-1"
                  >
                    <span>⚡</span>
                    <span>{language === 'bn' ? 'আজ রাত (8:00 PM)' : 'Tonight 8 PM (Live)'}</span>
                  </button>
                </div>
              </div>

              {/* Start & End Dates */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    Start Date:
                  </label>
                  <input
                    type="date"
                    value={formData.startDate || ''}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-indigo-400" />
                    Start Time:
                  </label>
                  <input
                    type="text"
                    value={formData.startTime || '10:00 AM'}
                    onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                    placeholder="e.g. 07:00 PM or 10:00 AM"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    End Date:
                  </label>
                  <input
                    type="date"
                    value={formData.endDate || ''}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-indigo-400" />
                    End Time:
                  </label>
                  <input
                    type="text"
                    value={formData.endTime || '11:59 PM'}
                    onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                    placeholder="e.g. 11:59 PM"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                  />
                </div>
              </div>

              {/* Time Limit: Dropdown + Custom Input */}
              <div className="space-y-1.5 pt-1">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>Time Limit (Minutes):</span>
                  <span className="text-amber-400 font-bold">{formData.timeLimit || 20} Minutes</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={customTimeLimitSelected ? 'custom' : (formData.timeLimit || 20)}
                    onChange={(e) => {
                      if (e.target.value === 'custom') {
                        setCustomTimeLimitSelected(true);
                      } else {
                        setCustomTimeLimitSelected(false);
                        setFormData({ ...formData, timeLimit: Number(e.target.value) });
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                  >
                    <option value={5}>5 Minutes (Quick Blitz)</option>
                    <option value={10}>10 Minutes</option>
                    <option value={15}>15 Minutes</option>
                    <option value={20}>20 Minutes (Standard)</option>
                    <option value={25}>25 Minutes</option>
                    <option value={30}>30 Minutes</option>
                    <option value={45}>45 Minutes</option>
                    <option value={60}>60 Minutes (Full Mock)</option>
                    <option value={90}>90 Minutes</option>
                    <option value="custom">✏️ Custom Minutes...</option>
                  </select>

                  {customTimeLimitSelected ? (
                    <input
                      type="number"
                      min={1}
                      max={240}
                      value={formData.timeLimit || 20}
                      onChange={(e) => setFormData({ ...formData, timeLimit: Number(e.target.value) })}
                      placeholder="Enter custom minutes"
                      className="w-full bg-slate-950 border border-amber-500/60 rounded-xl p-2 text-xs text-white"
                    />
                  ) : (
                    <select
                      value={formData.status || 'live'}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                    >
                      <option value="live">🟢 Live (Active)</option>
                      <option value="scheduled">📅 Scheduled (আসন্ন)</option>
                      <option value="draft">📝 Draft</option>
                      <option value="paused">⏸️ Paused</option>
                      <option value="ended">🏁 Ended</option>
                    </select>
                  )}
                </div>
              </div>

            </div>

          </div>

          {/* Subjects Tag Management */}
          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80 space-y-3">
            <label className="text-xs font-bold text-slate-300 block">
              {language === 'bn' ? 'অন্তর্ভুক্ত বিষয়সমূহ (Subjects):' : 'Included Subjects / Modules:'}
            </label>
            <div className="flex flex-wrap gap-2">
              {formData.subjects?.map((sub, i) => (
                <span 
                  key={i}
                  className="px-3 py-1 bg-indigo-950 text-indigo-300 border border-indigo-500/40 rounded-xl text-xs font-bold flex items-center gap-1.5"
                >
                  {sub}
                  <button
                    type="button"
                    onClick={() => handleRemoveSubject(sub)}
                    className="text-indigo-400 hover:text-white cursor-pointer ml-1"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2 max-w-sm">
              <input
                type="text"
                value={subjectInput}
                onChange={(e) => setSubjectInput(e.target.value)}
                placeholder="Add new subject..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSubject();
                  }
                }}
              />
              <button
                type="button"
                onClick={handleAddSubject}
                className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Add
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Question Manager */}
      {activeSubTab === 'questions' && (
        <AdminQuestionManager
          language={language}
          questions={formData.questions || []}
          subjects={formData.subjects || ['General Knowledge']}
          targetLevel={formData.targetLevel || 'Competitive Exam'}
          adminToken={adminToken}
          onChangeQuestions={handleQuestionsChange}
        />
      )}

      {/* Sub-Tab 3: Prize & Media */}
      {activeSubTab === 'prize' && (
        <AdminPrizeManager
          language={language}
          prizeName={formData.prizeName || ''}
          prizeDescription={formData.prizeDescription || ''}
          prizeImage={formData.prizeImage}
          prizeValue={formData.prizeValue || ''}
          prizePosition={formData.prizePosition || '1st Prize'}
          prizeTerms={formData.prizeTerms || ''}
          onChange={(prizeFields) => setFormData({ ...formData, ...prizeFields })}
        />
      )}

      {/* Sub-Tab 4: Marking & Rules */}
      {activeSubTab === 'rules' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Scoring & Penalties */}
            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80 space-y-4">
              <div className="flex items-center gap-2 text-amber-400 font-black text-xs uppercase tracking-wider">
                <Percent className="w-4 h-4" />
                <span>{language === 'bn' ? 'নম্বর বণ্টন ও নেগেটিভ মার্কিং' : 'Marks & Penalties'}</span>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Marks Per Correct Answer:</label>
                <input
                  type="number"
                  step="0.25"
                  min={0.5}
                  value={formData.marksPerQuestion ?? 1.0}
                  onChange={(e) => setFormData({ ...formData, marksPerQuestion: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-700/60">
                <label className="flex items-center gap-2 text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.negativeMarking ?? true}
                    onChange={(e) => setFormData({ ...formData, negativeMarking: e.target.checked })}
                    className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 accent-rose-500 cursor-pointer"
                  />
                  <span className="font-bold text-xs">
                    {language === 'bn' ? 'নেগেটিভ মার্কিং চালু রাখুন' : 'Enable Negative Marking'}
                  </span>
                </label>

                {formData.negativeMarking && (
                  <div className="pl-6 space-y-1">
                    <label className="text-xs text-slate-400">Negative Marks Per Wrong Answer:</label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[0.25, 0.33, 0.5, 1.0].map((val) => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => setFormData({ ...formData, negativeMarksPerWrong: val })}
                          className={`p-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            formData.negativeMarksPerWrong === val
                              ? 'bg-rose-600 border-rose-500 text-white shadow'
                              : 'bg-slate-950 border-slate-700 text-slate-300 hover:bg-slate-900'
                          }`}
                        >
                          -{val}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-700/60">
                <label className="text-xs font-bold text-slate-300">Max Attempts Per Student:</label>
                <input
                  type="number"
                  min={1}
                  max={5}
                  value={formData.maxAttempts || 1}
                  onChange={(e) => setFormData({ ...formData, maxAttempts: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                />
              </div>
            </div>

            {/* Custom Rules List */}
            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80 space-y-3">
              <div className="flex items-center gap-2 text-indigo-400 font-black text-xs uppercase tracking-wider">
                <ShieldAlert className="w-4 h-4" />
                <span>{language === 'bn' ? 'কুইজের নিয়মাবলী (Rules)' : 'Quiz Rules'}</span>
              </div>

              <div className="space-y-2">
                {formData.rules?.map((rule, idx) => (
                  <div key={idx} className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-700">
                    <span className="text-xs font-bold text-indigo-400 w-5 text-center">{idx + 1}.</span>
                    <input
                      type="text"
                      value={rule}
                      onChange={(e) => {
                        const newRules = [...(formData.rules || [])];
                        newRules[idx] = e.target.value;
                        setFormData({ ...formData, rules: newRules });
                      }}
                      className="w-full bg-transparent text-xs text-white focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const newRules = formData.rules?.filter((_, i) => i !== idx);
                        setFormData({ ...formData, rules: newRules });
                      }}
                      className="text-slate-500 hover:text-rose-400 text-xs px-1 cursor-pointer"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setFormData({ ...formData, rules: [...(formData.rules || []), 'নতুন নিয়ম লিখুন...'] })}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-bold cursor-pointer"
              >
                + Add Rule Item
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Sub-Tab 5: Notifications & Ads */}
      {activeSubTab === 'notifications' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Ad Requirements */}
            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80 space-y-4">
              <div className="flex items-center gap-2 text-purple-400 font-black text-xs uppercase tracking-wider">
                <Tv className="w-4 h-4" />
                <span>{language === 'bn' ? 'এড এন্ট্রি রিকোয়ারমেন্ট' : 'Ad Gate Settings'}</span>
              </div>

              <label className="flex items-center gap-2 text-slate-200 cursor-pointer bg-slate-950 p-3 rounded-xl border border-slate-700">
                <input
                  type="checkbox"
                  checked={formData.requireAdsBeforeQuiz !== false}
                  onChange={(e) => setFormData({ ...formData, requireAdsBeforeQuiz: e.target.checked })}
                  className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 accent-purple-500 cursor-pointer"
                />
                <span className="font-bold text-xs">
                  {language === 'bn' ? 'কুইজে এন্ট্রি নিতে স্পনসরড এড দেখা আবশ্যক' : 'Require video ads before quiz entry'}
                </span>
              </label>

              {formData.requireAdsBeforeQuiz !== false && (
                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Number of Ads to Watch:</label>
                    <div className="grid grid-cols-3 gap-2">
                      {[1, 2, 3].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setFormData({ ...formData, numberOfAds: num })}
                          className={`p-2 rounded-xl text-xs font-black border transition-all cursor-pointer ${
                            formData.numberOfAds === num
                              ? 'bg-purple-600 border-purple-500 text-white shadow'
                              : 'bg-slate-950 border-slate-700 text-slate-300 hover:bg-slate-900'
                          }`}
                        >
                          {num} {num === 1 ? 'Ad' : 'Ads'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Ad Timer (Seconds per Ad):</label>
                    <input
                      type="number"
                      min={3}
                      max={30}
                      value={formData.adWatchSeconds || 5}
                      onChange={(e) => setFormData({ ...formData, adWatchSeconds: Number(e.target.value) })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Notification Reminder Configuration */}
            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/80 space-y-4">
              <div className="flex items-center gap-2 text-amber-400 font-black text-xs uppercase tracking-wider">
                <Bell className="w-4 h-4" />
                <span>{language === 'bn' ? 'স্বয়ংক্রিয় পুশ নোটিফিকেশন রিমাইন্ডার' : 'Automated Push Notifications'}</span>
              </div>

              <label className="flex items-center gap-2 text-slate-200 cursor-pointer bg-slate-950 p-3 rounded-xl border border-slate-700">
                <input
                  type="checkbox"
                  checked={formData.notificationReminderEnabled !== false}
                  onChange={(e) => setFormData({ ...formData, notificationReminderEnabled: e.target.checked, enable10MinAlerts: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 accent-amber-500 cursor-pointer"
                />
                <span className="font-bold text-xs">
                  {language === 'bn' ? 'যুক্ত ইউজারদের কুইজ শুরুর পূর্বে নোটিফিকেশন পাঠান' : 'Send push notification to joined users prior to start'}
                </span>
              </label>

              {formData.notificationReminderEnabled !== false && (
                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Send Notification (Minutes Before Start):</label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[5, 10, 15, 30].map((mins) => (
                        <button
                          key={mins}
                          type="button"
                          onClick={() => setFormData({ ...formData, notificationReminderMinutes: mins })}
                          className={`p-2 rounded-xl text-xs font-black border transition-all cursor-pointer ${
                            formData.notificationReminderMinutes === mins
                              ? 'bg-amber-600 border-amber-500 text-white shadow'
                              : 'bg-slate-950 border-slate-700 text-slate-300 hover:bg-slate-900'
                          }`}
                        >
                          {mins} Mins
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Custom Notification Title:</label>
                    <input
                      type="text"
                      value={formData.notificationTitle || ''}
                      onChange={(e) => setFormData({ ...formData, notificationTitle: e.target.value })}
                      placeholder={`⏰ কুইজ সতর্কতা: "${formData.title || 'Weekly Quiz'}"`}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-300">Custom Notification Message:</label>
                    <textarea
                      rows={2}
                      value={formData.notificationMessage || ''}
                      onChange={(e) => setFormData({ ...formData, notificationMessage: e.target.value })}
                      placeholder="কুইজ শুরু হতে আর মাত্র ১০ মিনিট বাকি! অ্যাপে উপস্থিত হয়ে পুরস্কার জেতার প্রস্তুতি নিন।"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-xs text-white"
                    />
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

    </form>
  );
}
