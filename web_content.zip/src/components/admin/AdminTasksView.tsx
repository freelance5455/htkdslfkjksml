import React, { useState } from 'react';
import { User, TaskTemplate, TaskRecord, WorkArea } from '../../types';
import { storageService } from '../../services/storage';
import { Modal } from '../common/Modal';
import {
  CheckSquare,
  Plus,
  Edit2,
  Trash2,
  Clock,
  CheckCircle2,
  Filter,
  Search,
  Activity,
  Layers,
  AlertCircle,
} from 'lucide-react';

interface AdminTasksViewProps {
  currentUser: User;
  templates: TaskTemplate[];
  records: TaskRecord[];
  areas: WorkArea[];
  onTasksUpdated: () => void;
  initialCreateModalOpen?: boolean;
  onCloseInitialModal?: () => void;
}

export const AdminTasksView: React.FC<AdminTasksViewProps> = ({
  currentUser,
  templates,
  records,
  areas,
  onTasksUpdated,
  initialCreateModalOpen = false,
  onCloseInitialModal,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'plantillas' | 'monitor'>('plantillas');
  const [selectedAreaId, setSelectedAreaId] = useState<string>('todas');
  const [searchQuery, setSearchQuery] = useState('');

  // Task creation/editing modal state
  const [isModalOpen, setIsModalOpen] = useState(initialCreateModalOpen);
  const [editingTemplate, setEditingTemplate] = useState<TaskTemplate | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [areaId, setAreaId] = useState(areas[0]?.id || 'cocina');
  const [priority, setPriority] = useState<'Normal' | 'Alta' | 'Urgente'>('Normal');
  const [shiftTarget, setShiftTarget] = useState('Todos');
  const [formError, setFormError] = useState('');

  const handleOpenCreateModal = () => {
    setEditingTemplate(null);
    setTitle('');
    setDescription('');
    setAreaId(selectedAreaId !== 'todas' ? selectedAreaId : areas[0]?.id || 'cocina');
    setPriority('Normal');
    setShiftTarget('Todos');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (template: TaskTemplate) => {
    setEditingTemplate(template);
    setTitle(template.title);
    setDescription(template.description || '');
    setAreaId(template.areaId);
    setPriority(template.priority || 'Normal');
    setShiftTarget(template.shiftTarget || 'Todos');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setFormError('El título de la tarea es obligatorio.');
      return;
    }

    if (editingTemplate) {
      storageService.updateTaskTemplate(editingTemplate.id, {
        title: title.trim(),
        description: description.trim(),
        areaId,
        priority,
        shiftTarget,
      });
    } else {
      storageService.addTaskTemplate(
        {
          title: title.trim(),
          description: description.trim(),
          areaId,
          priority,
          shiftTarget,
        },
        currentUser
      );
    }

    setIsModalOpen(false);
    if (onCloseInitialModal) onCloseInitialModal();
    onTasksUpdated();
  };

  const handleDeleteTask = (id: string, taskTitle: string) => {
    if (confirm(`¿Estás seguro de eliminar la tarea "${taskTitle}"? Los empleados ya no la verán.`)) {
      storageService.deleteTaskTemplate(id);
      onTasksUpdated();
    }
  };

  // Filter templates
  const filteredTemplates = templates.filter((t) => {
    if (selectedAreaId !== 'todas' && t.areaId !== selectedAreaId) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matches =
        t.title.toLowerCase().includes(q) ||
        (t.description && t.description.toLowerCase().includes(q));
      if (!matches) return false;
    }
    return true;
  });

  // Filter records for monitor tab
  const filteredRecords = records.filter((r) => {
    if (selectedAreaId !== 'todas' && r.areaId !== selectedAreaId) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matches =
        r.title.toLowerCase().includes(q) ||
        (r.completedByName && r.completedByName.toLowerCase().includes(q)) ||
        (r.pendingReportedByName && r.pendingReportedByName.toLowerCase().includes(q)) ||
        (r.pendingReason && r.pendingReason.toLowerCase().includes(q));
      if (!matches) return false;
    }
    return true;
  });

  const getAreaName = (id: string) => areas.find((a) => a.id === id)?.name || id;

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-0.5 rounded-md border border-orange-200 flex items-center gap-1">
                <CheckSquare className="w-3.5 h-3.5" />
                Control de Operaciones
              </span>
              <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
                Gestión de Tareas
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
              Tareas y Cumplimiento por Área
            </h1>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1">
              Solo tú como administrador puedes crear, editar y eliminar tareas. Monitorea quién realizó cada tarea, fecha, hora y motivos de pendientes.
            </p>
          </div>

          <button
            id="btn-add-task-modal"
            onClick={handleOpenCreateModal}
            className="py-3 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shrink-0 shadow-xs active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Crear Nueva Tarea</span>
          </button>
        </div>
      </div>

      {/* Main SubTabs (Plantillas vs Monitor en Vivo) */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-2">
        <button
          id="subtab-plantillas"
          onClick={() => setActiveSubTab('plantillas')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'plantillas'
              ? 'bg-neutral-900 text-white shadow-xs'
              : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Catálogo de Tareas ({templates.length})</span>
        </button>
        <button
          id="subtab-monitor"
          onClick={() => setActiveSubTab('monitor')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'monitor'
              ? 'bg-orange-600 text-white shadow-xs'
              : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Monitor de Realizadas y Pendientes ({records.length})</span>
        </button>
      </div>

      {/* Filter Bar: Areas & Search */}
      <div className="bg-white rounded-2xl p-3 sm:p-4 border border-neutral-200 shadow-xs space-y-3">
        {/* Area Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <button
            onClick={() => setSelectedAreaId('todas')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedAreaId === 'todas'
                ? 'bg-neutral-900 text-white'
                : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
            }`}
          >
            Todas las Áreas
          </button>
          {areas.map((area) => (
            <button
              key={area.id}
              onClick={() => setSelectedAreaId(area.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedAreaId === area.id
                  ? 'bg-orange-600 text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              {area.name}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-neutral-400" />
          <input
            id="search-admin-tasks-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por título de tarea, empleado, motivo..."
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
          />
        </div>
      </div>

      {/* SubTab 1: Catálogo de Tareas (Templates) */}
      {activeSubTab === 'plantillas' && (
        <div className="space-y-3">
          {filteredTemplates.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-neutral-200 text-neutral-500 text-xs">
              No hay tareas registradas para el filtro seleccionado. Haz clic en "Crear Nueva Tarea".
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredTemplates.map((t) => (
                <div
                  key={t.id}
                  id={`admin-task-template-${t.id}`}
                  className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between space-y-3 hover:border-neutral-300 transition-all"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[11px] font-bold text-orange-700 bg-orange-50 px-2 py-0.5 rounded border border-orange-100">
                          {getAreaName(t.areaId)}
                        </span>
                        <span className="text-[11px] font-medium text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                          Turno: {t.shiftTarget || 'Todos'}
                        </span>
                      </div>
                      {t.priority && t.priority !== 'Normal' && (
                        <span
                          className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                            t.priority === 'Urgente'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {t.priority}
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-neutral-900">{t.title}</h3>
                    {t.description && (
                      <p className="text-xs text-neutral-600 mt-1 leading-relaxed">
                        {t.description}
                      </p>
                    )}
                  </div>

                  <div className="pt-2 border-t border-neutral-100 flex items-center justify-end gap-2">
                    <button
                      id={`btn-edit-task-${t.id}`}
                      onClick={() => handleOpenEditModal(t)}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold text-neutral-700 hover:bg-neutral-100 flex items-center gap-1"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Editar</span>
                    </button>
                    <button
                      id={`btn-del-task-${t.id}`}
                      onClick={() => handleDeleteTask(t.id, t.title)}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold text-red-600 hover:bg-red-50 flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Eliminar</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SubTab 2: Monitor en Vivo (Realizadas & Pendientes) */}
      {activeSubTab === 'monitor' && (
        <div className="space-y-3">
          <div className="p-3 bg-neutral-100 rounded-xl text-xs text-neutral-700 flex items-center gap-2">
            <Activity className="w-4 h-4 text-orange-600 shrink-0" />
            <span>
              Mostrando registros de ejecución en tiempo real con empleado, área, turno, hora y fecha.
            </span>
          </div>

          {filteredRecords.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-neutral-200 text-neutral-500 text-xs">
              No hay ejecuciones de tareas registradas para los filtros seleccionados.
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredRecords.map((r) => {
                const isDone = r.status === 'realizada';

                return (
                  <div
                    key={r.id}
                    id={`monitor-record-${r.id}`}
                    className={`bg-white rounded-2xl p-4 border shadow-xs space-y-2 ${
                      isDone
                        ? 'border-emerald-200 bg-emerald-50/15'
                        : 'border-amber-300 bg-amber-50/20'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs font-black uppercase px-2.5 py-0.5 rounded-full ${
                            isDone
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-900'
                          }`}
                        >
                          {isDone ? '✓ Realizada' : '⏳ Pendiente'}
                        </span>
                        <span className="font-extrabold text-neutral-900 text-sm sm:text-base">
                          {r.title}
                        </span>
                      </div>

                      <div className="text-xs text-neutral-500 font-medium">
                        Área: <strong>{r.areaName}</strong> • {r.shift}
                      </div>
                    </div>

                    {/* Execution Details according to prompt */}
                    {isDone ? (
                      <div className="bg-emerald-100/50 p-2.5 rounded-xl border border-emerald-200 text-xs text-emerald-950 flex flex-wrap items-center gap-x-4 gap-y-1">
                        <div>
                          <strong>Realizada por:</strong> {r.completedByName || 'Empleado'}
                        </div>
                        <div>
                          <strong>Turno:</strong> {r.shift}
                        </div>
                        <div>
                          <strong>Hora:</strong> {r.time}
                        </div>
                        <div>
                          <strong>Fecha:</strong> {r.date}
                        </div>
                        {r.resolvedInNextShift && (
                          <div className="w-full text-emerald-800 font-semibold pt-1 border-t border-emerald-200/60 mt-0.5">
                            ★ Originalmente pendiente; fue retomada y concluida por {r.resolvedByName} ({r.resolvedShift}) a las {r.resolvedTime}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="bg-amber-100/60 p-2.5 rounded-xl border border-amber-200 text-xs text-amber-950 space-y-1">
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                          <div>
                            <strong>Reportó Pendiente:</strong> {r.pendingReportedByName || 'Empleado'}
                          </div>
                          <div>
                            <strong>Turno:</strong> {r.shift}
                          </div>
                          <div>
                            <strong>Hora:</strong> {r.time}
                          </div>
                        </div>
                        <div className="pt-1 border-t border-amber-200/80">
                          <strong>Motivo:</strong> "{r.pendingReason}"
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Modal: Crear o Editar Tarea */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          if (onCloseInitialModal) onCloseInitialModal();
        }}
        title={editingTemplate ? 'Editar Tarea' : 'Crear Nueva Tarea'}
        subtitle="Solamente el Administrador puede definir las tareas que ejecutarán los empleados"
      >
        <form onSubmit={handleSaveTask} className="space-y-4">
          {formError && (
            <div className="p-3 bg-red-50 text-red-800 text-xs font-semibold rounded-xl border border-red-200">
              {formError}
            </div>
          )}

          {/* Area selector */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
              Área de Trabajo <span className="text-red-500">*</span>
            </label>
            <select
              id="task-area-select"
              value={areaId}
              onChange={(e) => setAreaId(e.target.value)}
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
            >
              {areas.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
              Nombre de la Tarea <span className="text-red-500">*</span>
            </label>
            <input
              id="task-title-input"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej. Preparar arroz, Revisar refrigeradores, Limpiar barra..."
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 font-semibold"
              autoFocus
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
              Descripción / Instrucciones detalladas
            </label>
            <textarea
              id="task-desc-input"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ej. Cocinar 2 ollas con medida estándar y rotular fecha..."
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Priority */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Prioridad
              </label>
              <select
                id="task-priority-select"
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full p-2.5 text-xs sm:text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white"
              >
                <option value="Normal">Normal</option>
                <option value="Alta">Alta</option>
                <option value="Urgente">Urgente</option>
              </select>
            </div>

            {/* Target Shift */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Turno Destino
              </label>
              <select
                id="task-shift-select"
                value={shiftTarget}
                onChange={(e) => setShiftTarget(e.target.value)}
                className="w-full p-2.5 text-xs sm:text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white"
              >
                <option value="Todos">Todos los turnos</option>
                <option value="Turno 1">Turno 1</option>
                <option value="Turno 2">Turno 2</option>
                <option value="Turno 3">Turno 3</option>
              </select>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-neutral-100">
            <button
              type="button"
              onClick={() => {
                setIsModalOpen(false);
                if (onCloseInitialModal) onCloseInitialModal();
              }}
              className="px-4 py-2.5 rounded-xl text-neutral-600 hover:bg-neutral-100 font-semibold text-sm"
            >
              Cancelar
            </button>
            <button
              id="btn-save-task"
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm shadow-xs active:scale-95 transition-all"
            >
              {editingTemplate ? 'Guardar Cambios' : 'Crear Tarea'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
