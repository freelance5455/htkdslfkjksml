import React, { useState } from 'react';
import { User, ActivityLogEntry, WorkArea } from '../../types';
import { storageService } from '../../services/storage';
import {
  History,
  Search,
  Filter,
  Download,
  Calendar,
  Clock,
  User as UserIcon,
  CheckCircle2,
  ClockAlert,
  AlertTriangle,
  RotateCcw,
  RefreshCw,
  Layers,
} from 'lucide-react';

interface AdminHistoryViewProps {
  currentUser: User;
  logs: ActivityLogEntry[];
  areas: WorkArea[];
  onDataReset: () => void;
}

export const AdminHistoryView: React.FC<AdminHistoryViewProps> = ({
  currentUser,
  logs,
  areas,
  onDataReset,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('todos');
  const [areaFilter, setAreaFilter] = useState<string>('todas');
  const [shiftFilter, setShiftFilter] = useState<string>('todos');

  // Filter logs
  const filteredLogs = logs.filter((log) => {
    if (typeFilter !== 'todos') {
      if (typeFilter === 'TAREA_REALIZADA' && log.type !== 'TAREA_REALIZADA') return false;
      if (typeFilter === 'TAREA_PENDIENTE' && log.type !== 'TAREA_PENDIENTE') return false;
      if (typeFilter === 'FALTANTE_REPORTADO' && log.type !== 'FALTANTE_REPORTADO') return false;
      if (typeFilter === 'CAMBIO_TURNO' && log.type !== 'CAMBIO_TURNO') return false;
      if (typeFilter === 'COMPRA_REALIZADA' && log.type !== 'COMPRA_REALIZADA') return false;
    }
    if (areaFilter !== 'todas' && log.area.toLowerCase() !== areaFilter.toLowerCase()) {
      return false;
    }
    if (shiftFilter !== 'todos' && !log.shift.toLowerCase().includes(shiftFilter.toLowerCase())) {
      return false;
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matches =
        log.employeeName.toLowerCase().includes(q) ||
        (log.task && log.task.toLowerCase().includes(q)) ||
        log.area.toLowerCase().includes(q) ||
        log.details.toLowerCase().includes(q) ||
        log.status.toLowerCase().includes(q);
      if (!matches) return false;
    }
    return true;
  });

  // Export logs to CSV
  const handleExportCSV = () => {
    if (filteredLogs.length === 0) {
      alert('No hay registros para exportar.');
      return;
    }

    const headers = ['Fecha', 'Hora', 'Empleado', 'Área', 'Turno', 'Tarea/Acción', 'Estado', 'Detalles'];
    const rows = filteredLogs.map((l) => [
      `"${l.date}"`,
      `"${l.time}"`,
      `"${l.employeeName}"`,
      `"${l.area}"`,
      `"${l.shift}"`,
      `"${l.task || ''}"`,
      `"${l.status}"`,
      `"${l.details.replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `historial_restaurante_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportJSON = () => {
    const jsonStr = storageService.exportAllDataAsJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `respaldo_restoturno_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResetData = () => {
    if (
      confirm(
        '¿Deseas restablecer los datos de prueba a los valores iniciales? Esto es útil para volver a probar desde cero el flujo de turnos y faltantes.'
      )
    ) {
      storageService.resetToDemoData();
      onDataReset();
      alert('Datos de prueba restablecidos correctamente.');
    }
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-0.5 rounded-md border border-orange-200 flex items-center gap-1">
                <History className="w-3.5 h-3.5" />
                Auditoría y Trazabilidad
              </span>
              <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
                Historial General
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
              Historial de Actividades del Restaurante
            </h1>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1">
              Consulta en orden cronológico: empleado, área, turno, tarea, estado, fecha, hora, motivos de pendientes y faltantes.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="btn-export-csv"
              onClick={handleExportCSV}
              className="py-2.5 px-3.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold text-xs flex items-center gap-1.5 border border-neutral-300 active:scale-95 transition-all"
            >
              <Download className="w-4 h-4 text-neutral-600" />
              <span>Exportar CSV</span>
            </button>
            <button
              id="btn-export-json"
              onClick={handleExportJSON}
              className="py-2.5 px-3.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <Download className="w-4 h-4 text-orange-400" />
              <span>Respaldo JSON</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {/* Filter by Type */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-500 uppercase mb-1">
              Tipo de Registro
            </label>
            <select
              id="filter-log-type"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full p-2 text-xs font-semibold bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white"
            >
              <option value="todos">Todos los eventos</option>
              <option value="TAREA_REALIZADA">Tareas Realizadas</option>
              <option value="TAREA_PENDIENTE">Tareas Pendientes (con motivo)</option>
              <option value="FALTANTE_REPORTADO">Faltantes Reportados</option>
              <option value="COMPRA_REALIZADA">Compras Realizadas</option>
              <option value="CAMBIO_TURNO">Cambios de Turno</option>
            </select>
          </div>

          {/* Filter by Area */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-500 uppercase mb-1">
              Área de Trabajo
            </label>
            <select
              id="filter-log-area"
              value={areaFilter}
              onChange={(e) => setAreaFilter(e.target.value)}
              className="w-full p-2 text-xs font-semibold bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white"
            >
              <option value="todas">Todas las áreas</option>
              {areas.map((a) => (
                <option key={a.id} value={a.name}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          {/* Filter by Shift */}
          <div>
            <label className="block text-[11px] font-bold text-neutral-500 uppercase mb-1">
              Turno
            </label>
            <select
              id="filter-log-shift"
              value={shiftFilter}
              onChange={(e) => setShiftFilter(e.target.value)}
              className="w-full p-2 text-xs font-semibold bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white"
            >
              <option value="todos">Todos los turnos</option>
              <option value="Turno 1">Turno 1</option>
              <option value="Turno 2">Turno 2</option>
              <option value="Turno 3">Turno 3</option>
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-neutral-400" />
          <input
            id="search-history-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por empleado, tarea, motivo o detalle..."
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
          />
        </div>
      </div>

      {/* Log Entries List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1 text-xs text-neutral-500 font-semibold">
          <span>Mostrando {filteredLogs.length} registros</span>
          <button
            onClick={handleResetData}
            className="text-[11px] text-neutral-400 hover:text-orange-600 flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Restablecer datos de prueba</span>
          </button>
        </div>

        {filteredLogs.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-neutral-200 text-xs text-neutral-500">
            No se encontraron registros de historial que coincidan con los filtros.
          </div>
        ) : (
          filteredLogs.map((log) => {
            const isDone = log.type === 'TAREA_REALIZADA' || log.type === 'PENDIENTE_RESUELTO';
            const isPending = log.type === 'TAREA_PENDIENTE';
            const isShortage = log.type === 'FALTANTE_REPORTADO';
            const isPurchase = log.type === 'COMPRA_REALIZADA';
            const isHandover = log.type === 'CAMBIO_TURNO';

            return (
              <div
                key={log.id}
                id={`log-entry-${log.id}`}
                className="bg-white rounded-2xl p-3.5 sm:p-4 border border-neutral-200 shadow-xs hover:border-neutral-300 transition-all space-y-2"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Status badge */}
                    <span
                      className={`text-[10px] sm:text-xs font-black uppercase px-2.5 py-0.5 rounded-full ${
                        isDone
                          ? 'bg-emerald-100 text-emerald-800'
                          : isPending
                          ? 'bg-amber-100 text-amber-900'
                          : isShortage
                          ? 'bg-red-100 text-red-800'
                          : isPurchase
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-purple-100 text-purple-800'
                      }`}
                    >
                      {log.status}
                    </span>

                    <span className="font-extrabold text-neutral-900 text-sm">
                      {log.task || log.type.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div className="text-[11px] text-neutral-400 font-medium flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{log.date}</span>
                    <span>•</span>
                    <Clock className="w-3.5 h-3.5" />
                    <span>{log.time}</span>
                  </div>
                </div>

                {/* Main Data Strip according to requirement #8: Empleado, Área, Turno, Tarea, Estado, Fecha, Hora, Pendientes, Faltantes */}
                <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-100 text-xs text-neutral-700 flex flex-wrap items-center gap-x-4 gap-y-1">
                  <div>
                    <span className="text-neutral-500 font-medium">Empleado:</span>{' '}
                    <strong className="text-neutral-900">{log.employeeName}</strong>
                  </div>
                  <div>
                    <span className="text-neutral-500 font-medium">Área:</span>{' '}
                    <strong className="text-neutral-900">{log.area}</strong>
                  </div>
                  <div>
                    <span className="text-neutral-500 font-medium">Turno:</span>{' '}
                    <strong className="text-orange-600">{log.shift}</strong>
                  </div>
                </div>

                {/* Details / Motivo */}
                <div className="text-xs text-neutral-600 pl-1 leading-relaxed">
                  {log.details}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
