import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldAlert,
  Users,
  Building2,
  Truck,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  FileSpreadsheet,
  CheckCircle2,
  XCircle,
  BarChart3,
  Sliders,
  Percent,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  Search
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

export const AdminApp: React.FC = () => {
  const {
    t,
    orders,
    products,
    driverTrips,
    complaints,
    updateComplaintStatus,
    commissionConfig,
    updateCommissionConfig,
    setInvoiceModalOrderId
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'users' | 'orders' | 'kilns' | 'fleet' | 'commissions' | 'reports' | 'disputes'
  >('dashboard');

  const [searchFilter, setSearchFilter] = useState('');
  const [baseRateKm, setBaseRateKm] = useState(32);
  const [surgeMultiplier, setSurgeMultiplier] = useState(1.0);

  // Revenue analytics data
  const chartData = [
    { day: 'Mon', gmv: 84000, orders: 12, commission: 2940 },
    { day: 'Tue', gmv: 112000, orders: 15, commission: 3920 },
    { day: 'Wed', gmv: 96000, orders: 14, commission: 3360 },
    { day: 'Thu', gmv: 148000, orders: 21, commission: 5180 },
    { day: 'Fri', gmv: 165000, orders: 24, commission: 5775 },
    { day: 'Sat', gmv: 198000, orders: 28, commission: 6930 },
    { day: 'Sun', gmv: 142000, orders: 19, commission: 4970 }
  ];

  const totalGMV = chartData.reduce((acc, c) => acc + c.gmv, 0);
  const totalCommission = chartData.reduce((acc, c) => acc + c.commission, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Sub Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#131822] border border-[#242f40] p-2 rounded-2xl">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white leading-tight">
              Brick Exchange Command Center • Super Admin
            </h2>
            <span className="text-[10px] text-emerald-400 font-semibold">
              Live Gateway Oversight • All 6 Stakeholder Portals Online
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'dashboard' as const, label: 'Dashboard' },
            { id: 'users' as const, label: 'Users & KYC' },
            { id: 'orders' as const, label: 'Order Pipeline' },
            { id: 'kilns' as const, label: 'Kilns' },
            { id: 'fleet' as const, label: 'Fleet' },
            { id: 'commissions' as const, label: 'Pricing & Commission' },
            { id: 'disputes' as const, label: `Disputes (${complaints.filter((d) => d.status === 'Open').length})` },
            { id: 'reports' as const, label: 'Reports' }
          ].map((tab) => (
            <button
              key={tab.id}
              id={`admin-nav-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-purple-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#1c2432]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* =========================================================================
          SCREEN 36: SUPER ADMIN DASHBOARD
      ========================================================================= */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Top Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Total Users</span>
              <div className="text-xl font-black text-white mt-1">1,482</div>
              <span className="text-[10px] text-emerald-400">+48 this week</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Total Orders</span>
              <div className="text-xl font-black text-white mt-1">324</div>
              <span className="text-[10px] text-emerald-400">98.4% fulfillment</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Gross Volume (GMV)</span>
              <div className="text-xl font-black text-emerald-400 mt-1">
                ₹{(totalGMV / 100000).toFixed(1)}L
              </div>
              <span className="text-[10px] text-emerald-400">7-day gross volume</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Active Deliveries</span>
              <div className="text-xl font-black text-amber-400 mt-1">18</div>
              <span className="text-[10px] text-slate-400">Real-time on road</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Verified Kilns</span>
              <div className="text-xl font-black text-white mt-1">42</div>
              <span className="text-[10px] text-slate-400">Bengal & Bihar belt</span>
            </div>
            <div className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl">
              <span className="text-[11px] text-slate-400">Fleet Trucks</span>
              <div className="text-xl font-black text-blue-400 mt-1">86</div>
              <span className="text-[10px] text-blue-400">GPS live tracking</span>
            </div>
          </div>

          {/* Recharts Analytics: Weekly GMV & Commission Trend */}
          <div className="bg-[#141a24] border border-[#253243] rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
                  Platform Volume Analytics
                </span>
                <h3 className="text-base font-bold text-white">7-Day Gross Marketplace Volume (GMV)</h3>
              </div>
              <div className="text-xs text-slate-400">
                Total Net Cut: <strong className="text-emerald-400 font-mono">₹{totalCommission.toLocaleString()}</strong>
              </div>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="gmvGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#232e40" />
                  <XAxis dataKey="day" stroke="#64748b" textAnchor="middle" fontSize={11} />
                  <YAxis
                    stroke="#64748b"
                    fontSize={11}
                    tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                    formatter={(val: any) => [`₹${Number(val || 0).toLocaleString()}`, 'Value']}
                  />
                  <Area
                    type="monotone"
                    dataKey="gmv"
                    stroke="#8b5cf6"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#gmvGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 37: USER MANAGEMENT & KYC VERIFICATION
      ========================================================================= */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
                Screen 37 • Stakeholder Directory
              </span>
              <h2 className="text-xl font-bold text-white">User Management & KYC Verification</h2>
            </div>
            <div className="relative">
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search user / kiln / GST..."
                className="bg-[#10141e] border border-[#263345] rounded-xl px-3 py-1.5 text-xs text-white outline-none w-48"
              />
            </div>
          </div>

          <div className="bg-[#141a24] border border-[#253243] rounded-2xl overflow-hidden">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#10141d] border-b border-[#212b3a] text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="p-3.5">User / Business</th>
                  <th className="p-3.5">Role</th>
                  <th className="p-3.5">Contact</th>
                  <th className="p-3.5">KYC Documents</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1f2837]">
                <tr className="hover:bg-[#18202d]">
                  <td className="p-3.5 font-bold text-white">Maa Tara Brick Kiln</td>
                  <td className="p-3.5 text-amber-400">Manufacturer</td>
                  <td className="p-3.5 text-slate-400">+91 98310 44521</td>
                  <td className="p-3.5 text-emerald-400">GST + Pollution Clearance Verified</td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                      Active
                    </span>
                  </td>
                  <td className="p-3.5">
                    <button className="px-2.5 py-1 bg-[#1e2736] hover:bg-[#283549] text-white rounded text-xs font-semibold">
                      Audit
                    </button>
                  </td>
                </tr>
                <tr className="hover:bg-[#18202d]">
                  <td className="p-3.5 font-bold text-white">Ghosh Imarati Bhandar</td>
                  <td className="p-3.5 text-blue-400">Wholesaler</td>
                  <td className="p-3.5 text-slate-400">+91 98305 77124</td>
                  <td className="p-3.5 text-emerald-400">Trade License Verified</td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                      Active
                    </span>
                  </td>
                  <td className="p-3.5">
                    <button className="px-2.5 py-1 bg-[#1e2736] hover:bg-[#283549] text-white rounded text-xs font-semibold">
                      Audit
                    </button>
                  </td>
                </tr>
                <tr className="hover:bg-[#18202d]">
                  <td className="p-3.5 font-bold text-white">Ramen Das (Bholanath Roadways)</td>
                  <td className="p-3.5 text-orange-400">Transporter</td>
                  <td className="p-3.5 text-slate-400">+91 94331 88201</td>
                  <td className="p-3.5 text-emerald-400">DL + Commercial Insurance</td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                      Active
                    </span>
                  </td>
                  <td className="p-3.5">
                    <button className="px-2.5 py-1 bg-[#1e2736] hover:bg-[#283549] text-white rounded text-xs font-semibold">
                      Audit
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 38: ORDER MONITORING PIPELINE
      ========================================================================= */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
              Screen 38 • Real-time Order Monitoring
            </span>
            <h2 className="text-xl font-bold text-white">Marketplace Order Pipeline</h2>
          </div>

          <div className="space-y-3 text-xs">
            {orders.map((ord) => (
              <div
                key={ord.id}
                className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white text-sm">{ord.id}</span>
                    <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold text-[10px]">
                      {ord.orderStatus}
                    </span>
                    <span className="text-slate-400 text-[11px] font-mono">OTP: {ord.deliveryOtp}</span>
                  </div>
                  <p className="text-slate-200 mt-1 font-semibold">
                    Customer: {ord.customerName} ({ord.customerMobile}) • {ord.items[0]?.productName}
                  </p>
                  <p className="text-slate-400 text-[11px] truncate max-w-md">
                    Destination: {ord.deliveryAddress}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="font-bold text-white text-sm">
                      ₹{ord.totalAmount.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-emerald-400">Paid via Escrow</span>
                  </div>
                  <button
                    onClick={() => setInvoiceModalOrderId(ord.id)}
                    className="px-3 py-1.5 bg-[#1f2937] hover:bg-[#283547] text-slate-200 rounded-lg text-xs"
                  >
                    View Bill
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 39: KILN MONITORING
      ========================================================================= */}
      {activeTab === 'kilns' && (
        <div className="space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
              Screen 39 • Bhatta Kiln Inspection & Capacity
            </span>
            <h2 className="text-xl font-bold text-white">Registered Brick Bhattas</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-white font-bold text-sm">Maa Tara Brick Kiln (BFB Bhatta)</h3>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                  Verified
                </span>
              </div>
              <p className="text-slate-400">Location: Barasat-Baduria Belt, North 24 Pgs</p>
              <div className="grid grid-cols-3 gap-2 p-2.5 bg-[#10141e] rounded-xl text-center">
                <div>
                  <span className="text-[10px] text-slate-400">Firing Method</span>
                  <div className="font-bold text-white">Zig-Zag Clean Coal</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400">Daily Capacity</span>
                  <div className="font-bold text-amber-400">45,000 Bricks</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400">Quality Rating</span>
                  <div className="font-bold text-emerald-400">4.8 / 5.0</div>
                </div>
              </div>
            </div>

            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-white font-bold text-sm">Sonarpur Green Clay Works</h3>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                  Verified
                </span>
              </div>
              <p className="text-slate-400">Location: Baruipur-Canning Highway, South 24 Pgs</p>
              <div className="grid grid-cols-3 gap-2 p-2.5 bg-[#10141e] rounded-xl text-center">
                <div>
                  <span className="text-[10px] text-slate-400">Firing Method</span>
                  <div className="font-bold text-white">FCBK Induced Draft</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400">Daily Capacity</span>
                  <div className="font-bold text-amber-400">30,000 Bricks</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400">Quality Rating</span>
                  <div className="font-bold text-emerald-400">4.6 / 5.0</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 40: FLEET MANAGEMENT
      ========================================================================= */}
      {activeTab === 'fleet' && (
        <div className="space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
              Screen 40 • Transporter Logistics & GPS Pings
            </span>
            <h2 className="text-xl font-bold text-white">Fleet Telemetry & Status</h2>
          </div>

          <div className="space-y-3 text-xs">
            {driverTrips.map((trip) => (
              <div
                key={trip.id}
                className="p-4 bg-[#141a24] border border-[#253243] rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white">{trip.vehicleNumber}</span>
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold text-[10px]">
                      {trip.vehicleType}
                    </span>
                    <span className="text-slate-400 font-mono text-[11px]">Trip: {trip.id}</span>
                  </div>
                  <p className="text-slate-300 mt-1">
                    Route: {trip.pickupAddress} ➔ {trip.destinationAddress}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-emerald-400 font-bold block text-sm">Active On GPS</span>
                    <span className="text-slate-400 text-[10px]">Speed: 42 km/h • 24m remaining</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 41: COMMISSION & PRICING RULES
      ========================================================================= */}
      {activeTab === 'commissions' && (
        <div className="max-w-2xl mx-auto bg-[#141a24] border border-[#253243] rounded-2xl p-6 space-y-5">
          <div className="pb-3 border-b border-[#212c3e]">
            <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
              Screen 41 • Marketplace Economics Configuration
            </span>
            <h2 className="text-xl font-bold text-white mt-0.5">Platform Commission & Pricing Rules</h2>
            <p className="text-xs text-slate-400">
              Configure platform fee percentages and logistics rate per km
            </p>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 font-semibold mb-1">
                <span>Manufacturer Platform Fee</span>
                <span className="text-purple-400 font-bold">{commissionConfig.manufacturerCommissionPercent}%</span>
              </div>
              <input
                id="admin-commission-slider"
                type="range"
                min={1}
                max={10}
                step={0.5}
                value={commissionConfig.manufacturerCommissionPercent}
                onChange={(e) =>
                  updateCommissionConfig({ manufacturerCommissionPercent: Number(e.target.value) })
                }
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 font-semibold mb-1">
                <span>Base Haulage Delivery Rate</span>
                <span className="text-amber-400 font-bold">₹{baseRateKm} / km</span>
              </div>
              <input
                id="admin-rate-per-km-slider"
                type="range"
                min={15}
                max={60}
                step={1}
                value={baseRateKm}
                onChange={(e) => setBaseRateKm(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="p-3.5 bg-[#10141e] border border-[#222c3d] rounded-xl flex items-center justify-between">
              <div>
                <span className="font-bold text-white block">Rain / Monsoon Road Surcharge</span>
                <span className="text-slate-400 text-[11px]">
                  Adds 15% multiplier on transport rates for unpaved kiln roads
                </span>
              </div>
              <button
                id="toggle-surge-btn"
                onClick={() => setSurgeMultiplier(surgeMultiplier === 1.0 ? 1.15 : 1.0)}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs cursor-pointer ${
                  surgeMultiplier > 1.0
                    ? 'bg-amber-600 text-white'
                    : 'bg-[#1e2736] text-slate-400'
                }`}
              >
                {surgeMultiplier > 1.0 ? 'Active (+15%)' : 'Disabled'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 43: DISPUTE RESOLUTION
      ========================================================================= */}
      {activeTab === 'disputes' && (
        <div className="space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
              Screen 43 • Escrow & Quality Mediation
            </span>
            <h2 className="text-xl font-bold text-white">Dispute Resolution & Quality Appeals</h2>
          </div>

          <div className="space-y-3 text-xs">
            {complaints.map((disp) => (
              <div
                key={disp.id}
                className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white">{disp.id}</span>
                    <span className="text-slate-400">Order: {disp.orderId}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        disp.status === 'Open'
                          ? 'bg-rose-500/20 text-rose-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}
                    >
                      {disp.status}
                    </span>
                  </div>
                  <span className="text-slate-400 font-mono text-[11px]">{disp.createdAt}</span>
                </div>

                <div className="p-3 bg-[#10141e] rounded-xl border border-[#212b3c] space-y-1">
                  <div className="font-semibold text-rose-300 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    <span>{disp.category}</span>
                  </div>
                  <p className="text-slate-300">{disp.description}</p>
                </div>

                {disp.status === 'Open' ? (
                  <div className="flex items-center gap-2 pt-2">
                    <button
                      id={`refund-dispute-${disp.id}`}
                      onClick={() =>
                        updateComplaintStatus(
                          disp.id,
                          'Resolved',
                          'Escrow adjusted: 15% refund released to customer wallet for transit breakage.'
                        )
                      }
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-colors cursor-pointer"
                    >
                      Issue 15% Breakage Refund to Customer
                    </button>
                    <button
                      id={`reject-dispute-${disp.id}`}
                      onClick={() =>
                        updateComplaintStatus(
                          disp.id,
                          'Closed',
                          'Inspection cleared: Load delivered within allowable ISI 2% breakage tolerance.'
                        )
                      }
                      className="px-3.5 py-1.5 bg-[#1f2837] hover:bg-[#283547] text-slate-300 font-semibold rounded-lg"
                    >
                      Dismiss Dispute
                    </button>
                  </div>
                ) : (
                  <div className="text-emerald-400 text-[11px] flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Resolution: {disp.resolutionNotes || 'Case audited and closed by Super Admin.'}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          SCREEN 42: REPORTS & ANALYTICS
      ========================================================================= */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">
              Screen 42 • Financial & Operational Audits
            </span>
            <h2 className="text-xl font-bold text-white">Reports & Export Analytics</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl space-y-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
              <h4 className="font-bold text-white">Monthly GMV & Tax Ledger</h4>
              <p className="text-slate-400 text-[11px]">
                Consolidated GST (5% & 12%) collected, escrow settlements, and transporter deductions.
              </p>
              <button
                onClick={() => alert('Exporting CSV: brick_exchange_monthly_gst_ledger.csv')}
                className="mt-2 text-emerald-400 hover:underline font-semibold cursor-pointer"
              >
                Export CSV →
              </button>
            </div>

            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl space-y-2">
              <BarChart3 className="w-5 h-5 text-purple-400" />
              <h4 className="font-bold text-white">Kiln Breakage & Quality Log</h4>
              <p className="text-slate-400 text-[11px]">
                Compressive strength test audits, class-1 compliance ratings, and on-site dispute frequencies.
              </p>
              <button
                onClick={() => alert('Exporting PDF: kiln_quality_compliance_report.pdf')}
                className="mt-2 text-purple-400 hover:underline font-semibold cursor-pointer"
              >
                Download Audit PDF →
              </button>
            </div>

            <div className="p-5 bg-[#141a24] border border-[#253243] rounded-2xl space-y-2">
              <Truck className="w-5 h-5 text-blue-400" />
              <h4 className="font-bold text-white">Transporter Turnaround Time</h4>
              <p className="text-slate-400 text-[11px]">
                Average loading time at kiln chimney, transit duration, OTP verification speeds.
              </p>
              <button
                onClick={() => alert('Exporting CSV: transporter_fleet_kpi.csv')}
                className="mt-2 text-blue-400 hover:underline font-semibold cursor-pointer"
              >
                Export Telemetry CSV →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
