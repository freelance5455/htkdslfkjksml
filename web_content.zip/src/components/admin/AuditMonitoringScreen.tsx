import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  Search,
  Filter,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Eye,
  RefreshCw,
  Download,
  Lock,
  TrendingDown,
  TrendingUp,
  User,
  Zap,
  Clock,
  ShieldCheck,
  Ban,
  SlidersHorizontal,
  ChevronDown,
  Database,
  Radio,
  FileText,
  Copy,
  Check,
  Sparkles,
  Cpu,
} from 'lucide-react';
import { TransactionRecord, UserProfile } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { saveAuditRecordToFirestore } from '../../utils/firebaseSync';

interface AuditMonitoringScreenProps {
  transactions: TransactionRecord[];
  onUpdateTransactions: (updater: (prev: TransactionRecord[]) => TransactionRecord[]) => void;
  currentUser: UserProfile;
  firebaseConnected: boolean;
  onRefreshFromFirebase: () => void;
  showToast: (msg: string) => void;
}

export const AuditMonitoringScreen: React.FC<AuditMonitoringScreenProps> = ({
  transactions,
  onUpdateTransactions,
  currentUser,
  firebaseConnected,
  onRefreshFromFirebase,
  showToast,
}) => {
  // Smart filters
  const [dateFilterMode, setDateFilterMode] = useState<'ALL' | 'TODAY' | '7_DAYS' | '30_DAYS' | 'CUSTOM'>('ALL');
  const [customDate, setCustomDate] = useState<string>('');
  const [operationTypeFilter, setOperationTypeFilter] = useState<string>('ALL');
  const [playerNameQuery, setPlayerNameQuery] = useState<string>('');
  const [showSuspiciousOnly, setShowSuspiciousOnly] = useState<boolean>(false);
  const [riskSeverityFilter, setRiskSeverityFilter] = useState<'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'risk_desc' | 'amount_desc'>('date_desc');

  // Inspection modal
  const [inspectedTx, setInspectedTx] = useState<TransactionRecord | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Gemini AI Analysis state
  const [isAiAnalyzing, setIsAiAnalyzing] = useState<boolean>(false);
  const [showAiModal, setShowAiModal] = useState<boolean>(false);
  const [aiReport, setAiReport] = useState<{
    threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    threatScore: number;
    executiveSummary: string;
    detectedAnomalies: string[];
    flaggedPlayers: { playerId: string; playerName: string; reason: string; severity: string }[];
    recommendedActions: string[];
    systemIntegrityVerdict: string;
  } | null>(null);

  const runGeminiAnalysis = async () => {
    try {
      setIsAiAnalyzing(true);
      soundFX.playButtonClick();
      showToast('🧠 جارِ تشغيل التحليل الذكي عبر Gemini 3.8 Flash...');

      const response = await fetch('/api/gemini/analyze-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stats: analysisStats,
          logs: filteredRecords.slice(0, 30),
        }),
      });

      const data = await response.json();
      if (data.success && data.analysis) {
        setAiReport(data.analysis);
        setShowAiModal(true);
        soundFX.playVictoryFanfare();
        showToast('✅ اكتمل تحليل سجل الأنشطة بنجاح عبر محرك Gemini AI!');
      } else {
        showToast(`⚠️ تنبيه: ${data.error || 'تعذر استلام تقرير الذكاء الاصطناعي'}`);
      }
    } catch (err: any) {
      showToast(`❌ تعذر الاتصال بالخادم: ${err.message || 'خطأ في الشبكة'}`);
    } finally {
      setIsAiAnalyzing(false);
    }
  };

  // Helper function to detect or mark suspicion if not already explicitly flagged
  const isRecordSuspicious = (tx: TransactionRecord): boolean => {
    if (tx.isSuspicious !== undefined) return tx.isSuspicious;
    if (tx.status === 'REJECTED') return true;
    if (tx.playerName.toLowerCase().includes('suspicious') || tx.playerName.toLowerCase().includes('bot')) return true;
    if (tx.referenceNote.includes('غير نظامية') || tx.referenceNote.includes('عدم تطابق') || tx.referenceNote.includes('احتيال')) return true;
    if (tx.amount > 10000 && tx.sourceMethod === 'CASHIER_TRANSFER') return true;
    return false;
  };

  const getSuspicionReason = (tx: TransactionRecord): string => {
    if (tx.suspicionReason) return tx.suspicionReason;
    if (tx.referenceNote.includes('غير نظامية') || tx.referenceNote.includes('عدم تطابق')) {
      return 'عدم تطابق بصمة التشفير ومحاولة اختراق رصيد غير مصرح بها';
    }
    if (tx.playerName.toLowerCase().includes('bot')) {
      return 'نشاط فائق السرعة مشبوه (Timing Anomaly) واشتباه استخدام روبوت آلي';
    }
    if (tx.playerName.toLowerCase().includes('suspicious')) {
      return 'تكرار عمليات غير متناسقة مع نشاط اللعب المسجل في السيرفر';
    }
    if (tx.status === 'REJECTED') {
      return 'محاولة تحويل مرفوضة من قبل خوارزمية جدار الحماية AI';
    }
    return 'نشاط يحتاج مراجعة إدارية وفحص بصمة الجلسة';
  };

  const getRiskScore = (tx: TransactionRecord): number => {
    if (tx.riskScore !== undefined) return tx.riskScore;
    if (isRecordSuspicious(tx)) {
      if (tx.status === 'REJECTED') return 95;
      if (tx.playerName.toLowerCase().includes('bot')) return 92;
      return 85;
    }
    return 10;
  };

  // Smart filtering logic
  const filteredRecords = useMemo(() => {
    return transactions
      .filter((tx) => {
        const suspicious = isRecordSuspicious(tx);

        // Suspicious only toggle
        if (showSuspiciousOnly && !suspicious) return false;

        // Player Name filter
        if (playerNameQuery.trim()) {
          const q = playerNameQuery.trim().toLowerCase();
          const matchesName = tx.playerName.toLowerCase().includes(q) || tx.playerId.toLowerCase().includes(q);
          if (!matchesName) return false;
        }

        // Operation type filter
        if (operationTypeFilter !== 'ALL' && tx.sourceMethod !== operationTypeFilter) {
          return false;
        }

        // Risk severity filter
        const score = getRiskScore(tx);
        if (riskSeverityFilter === 'HIGH' && score < 75) return false;
        if (riskSeverityFilter === 'MEDIUM' && (score < 40 || score >= 75)) return false;
        if (riskSeverityFilter === 'LOW' && score >= 40) return false;

        // Date filter
        if (dateFilterMode !== 'ALL') {
          const txDate = tx.timestamp.slice(0, 10);
          const today = new Date().toISOString().slice(0, 10);

          if (dateFilterMode === 'TODAY') {
            if (txDate !== today && !tx.timestamp.includes('2026-10-09') && !tx.timestamp.includes('2026-10-10')) {
              return false;
            }
          } else if (dateFilterMode === '7_DAYS') {
            // Include recent days
            const txTime = new Date(tx.timestamp.replace(' ', 'T')).getTime();
            const now = Date.now();
            if (!isNaN(txTime) && now - txTime > 7 * 24 * 60 * 60 * 1000) {
              return false;
            }
          } else if (dateFilterMode === 'CUSTOM' && customDate) {
            if (txDate !== customDate) return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date_desc') return b.timestamp.localeCompare(a.timestamp);
        if (sortBy === 'date_asc') return a.timestamp.localeCompare(b.timestamp);
        if (sortBy === 'risk_desc') return getRiskScore(b) - getRiskScore(a);
        if (sortBy === 'amount_desc') return Math.abs(b.amount) - Math.abs(a.amount);
        return 0;
      });
  }, [
    transactions,
    showSuspiciousOnly,
    playerNameQuery,
    operationTypeFilter,
    riskSeverityFilter,
    dateFilterMode,
    customDate,
    sortBy,
  ]);

  // Analytics Metrics
  const analysisStats = useMemo(() => {
    let suspiciousCount = 0;
    let normalCount = 0;
    let suspiciousVolume = 0;

    transactions.forEach((tx) => {
      if (isRecordSuspicious(tx)) {
        suspiciousCount++;
        suspiciousVolume += Math.abs(tx.amount);
      } else {
        normalCount++;
      }
    });

    const safeRate = transactions.length > 0 ? Math.round((normalCount / transactions.length) * 100) : 100;

    return {
      total: transactions.length,
      suspiciousCount,
      normalCount,
      suspiciousVolume,
      safeRate,
    };
  }, [transactions]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  // Mark transaction as resolved / verified or sanctioned
  const handleResolveSuspicion = (tx: TransactionRecord) => {
    soundFX.playButtonClick();
    onUpdateTransactions((prev) =>
      prev.map((item) => {
        if (item.transactionId === tx.transactionId) {
          const updated = {
            ...item,
            isSuspicious: false,
            status: 'COMPLETED' as const,
            referenceNote: `${item.referenceNote} [تم التدقيق والاعتماد الإداري اليدوي بواسطة ${currentUser.name}]`,
          };
          saveAuditRecordToFirestore(updated);
          return updated;
        }
        return item;
      })
    );
    showToast(`✓ تم تدقيق العملية #${tx.transactionId} وإزالة علامة الاشتباه بنجاح.`);
    setInspectedTx(null);
  };

  const handleBlockAndSanction = (tx: TransactionRecord) => {
    soundFX.playButtonClick();
    onUpdateTransactions((prev) =>
      prev.map((item) => {
        if (item.transactionId === tx.transactionId) {
          const updated = {
            ...item,
            isSuspicious: true,
            status: 'REJECTED' as const,
            referenceNote: `${item.referenceNote} [تم تأكيد الحظر وتجميد العملية بقرار أمني من ${currentUser.name}]`,
          };
          saveAuditRecordToFirestore(updated);
          return updated;
        }
        return item;
      })
    );
    showToast(`⛔ تم تجميد العملية #${tx.transactionId} وتسجيل المخالفة في جدار الحماية.`);
    setInspectedTx(null);
  };

  return (
    <div className="space-y-5 text-right font-sans">
      {/* ========================================================
          FIREBASE DATABASE STATUS & REAL-TIME LINK BADGE
         ======================================================== */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#071c10] via-[#0b2b1a] to-[#071c10] border border-amber-500/50 flex flex-col md:flex-row items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Database className="w-6 h-6 text-amber-400" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black text-amber-300">
                شاشة مراقبة وتحليل سجل الأنشطة (Audit Log AI Monitor)
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/50 text-[10px] font-bold flex items-center gap-1">
                <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
                <span>قاعدة البيانات مربوطة ونشطة (Firebase Firestore)</span>
              </span>
            </div>
            <div className="text-[11px] text-gray-300 mt-0.5 flex items-center gap-2">
              <span className="font-mono text-amber-400/90 text-[10px]">
                DB: ai-studio-tabeona-04aa7140-1504-4f4a-8e3f-50b20ae6b80a
              </span>
              <span>•</span>
              <span className="text-emerald-400">سجل مشفّر وتزامن سحابي فوري</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={runGeminiAnalysis}
            disabled={isAiAnalyzing}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-black font-black text-xs flex items-center gap-1.5 transition-all shadow-lg shadow-amber-500/25 disabled:opacity-50 active:scale-95 cursor-pointer"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isAiAnalyzing ? 'animate-spin' : ''}`} />
            <span>{isAiAnalyzing ? 'تحليل Gemini جارٍ...' : 'تحليل الذكاء الاصطناعي (Gemini AI)'}</span>
          </button>

          <button
            onClick={() => {
              soundFX.playButtonClick();
              onRefreshFromFirebase();
              showToast('🔄 جارِ تحديث البيانات ومزامنة سجل التدقيق من السحابة...');
            }}
            className="px-3.5 py-1.5 rounded-xl bg-[#0a2315] hover:bg-[#0f3520] text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
            <span>مزامنة فورية</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          ANALYTICAL KPIS & SECURITY HEALTH CARDS
         ======================================================== */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Total records */}
        <div className="p-3.5 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
          <div className="text-[11px] text-gray-400 flex items-center justify-between">
            <span>إجمالي الأنشطة المسجلة</span>
            <FileText className="w-4 h-4 text-amber-400/60" />
          </div>
          <div className="text-2xl font-black text-amber-300 font-mono mt-1">
            {analysisStats.total.toLocaleString()}
          </div>
          <div className="text-[10px] text-gray-400 mt-0.5">موثقة في سلسلة الـ Ledger</div>
        </div>

        {/* Normal / Safe operations (Green) */}
        <div className="p-3.5 rounded-2xl bg-[#06170d] border border-emerald-950/80 shadow">
          <div className="text-[11px] text-gray-400 flex items-center justify-between">
            <span>عمليات نظامية آمنة</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
            {analysisStats.normalCount.toLocaleString()}
          </div>
          <div className="text-[10px] text-emerald-300/80 mt-0.5">
            نسبة الأمان: {analysisStats.safeRate}% من المعاملات
          </div>
        </div>

        {/* Suspicious Cases (RED HIGHLIGHT WITH PULSING BADGE) */}
        <div
          onClick={() => {
            soundFX.playButtonClick();
            setShowSuspiciousOnly(!showSuspiciousOnly);
          }}
          className={`p-3.5 rounded-2xl cursor-pointer transition-all border shadow ${
            showSuspiciousOnly
              ? 'bg-red-950/90 border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)]'
              : 'bg-[#180808] border-red-900/80 hover:border-red-500/70'
          }`}
        >
          <div className="text-[11px] text-red-300 flex items-center justify-between font-bold">
            <span className="flex items-center gap-1">
              <AlertTriangle className="w-4 h-4 text-red-400 animate-bounce" />
              <span>حالات مشبوهة مكتشفة</span>
            </span>
            <span className="px-1.5 py-0.5 bg-red-600/30 text-red-300 rounded text-[10px]">
              {showSuspiciousOnly ? 'فلتر مفعل' : 'انقر للفلترة'}
            </span>
          </div>
          <div className="text-2xl font-black text-red-400 font-mono mt-1 flex items-center gap-2">
            <span>{analysisStats.suspiciousCount}</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/20 border border-red-500/50 text-red-300 font-bold">
              تنبيه أحمر ⚠️
            </span>
          </div>
          <div className="text-[10px] text-red-300/80 mt-0.5">
            مظللة باللون الأحمر لسهولة المتابعة الفورية
          </div>
        </div>

        {/* Suspicious Volume */}
        <div className="p-3.5 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
          <div className="text-[11px] text-gray-400 flex items-center justify-between">
            <span>مبالغ قيد المراجعة الأمنية</span>
            <ShieldAlert className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-black text-amber-400 font-mono mt-1">
            {analysisStats.suspiciousVolume.toLocaleString()} 🪙
          </div>
          <div className="text-[10px] text-gray-400 mt-0.5">محمية تلقائيًا بجدار الحماية</div>
        </div>
      </div>

      {/* ========================================================
          SMART FILTERS BAR (التاريخ، نوع العملية، اسم اللاعب)
         ======================================================== */}
      <div className="bg-[#05110a] border border-amber-900/60 p-4 rounded-2xl space-y-3 shadow-xl">
        <div className="flex items-center justify-between border-b border-amber-950/80 pb-2">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
            <SlidersHorizontal className="w-4 h-4 text-amber-400" />
            <span>الفلاتر الذكية لتحليل سجل الأنشطة (Smart Analytical Filters)</span>
          </div>
          <div className="flex items-center gap-2">
            {/* Quick toggle for suspicious items only */}
            <button
              onClick={() => {
                soundFX.playButtonClick();
                setShowSuspiciousOnly(!showSuspiciousOnly);
              }}
              className={`px-3 py-1 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all ${
                showSuspiciousOnly
                  ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)] scale-105'
                  : 'bg-red-950/60 hover:bg-red-900/60 text-red-300 border border-red-700/50'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>عرض الحالات المشبوهة فقط ({analysisStats.suspiciousCount})</span>
            </button>

            {(playerNameQuery || operationTypeFilter !== 'ALL' || dateFilterMode !== 'ALL' || showSuspiciousOnly) && (
              <button
                onClick={() => {
                  soundFX.playButtonClick();
                  setPlayerNameQuery('');
                  setOperationTypeFilter('ALL');
                  setDateFilterMode('ALL');
                  setCustomDate('');
                  setShowSuspiciousOnly(false);
                  setRiskSeverityFilter('ALL');
                }}
                className="text-[11px] text-gray-400 hover:text-amber-300 px-2 py-1 underline"
              >
                إعادة ضبط الفلاتر
              </button>
            )}
          </div>
        </div>

        {/* Filter controls grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          {/* 1. SMART DATE FILTER (فلتر التاريخ) */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-gray-300 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <span>التاريخ (Date Range):</span>
            </label>
            <div className="grid grid-cols-3 gap-1">
              <button
                onClick={() => setDateFilterMode('ALL')}
                className={`py-1.5 px-2 rounded-lg text-[10px] font-bold border transition-colors ${
                  dateFilterMode === 'ALL'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                    : 'bg-[#030905] text-gray-400 border-amber-950 hover:bg-[#07160e]'
                }`}
              >
                كل الأوقات
              </button>
              <button
                onClick={() => setDateFilterMode('TODAY')}
                className={`py-1.5 px-2 rounded-lg text-[10px] font-bold border transition-colors ${
                  dateFilterMode === 'TODAY'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                    : 'bg-[#030905] text-gray-400 border-amber-950 hover:bg-[#07160e]'
                }`}
              >
                اليوم / الأحدث
              </button>
              <button
                onClick={() => setDateFilterMode('7_DAYS')}
                className={`py-1.5 px-2 rounded-lg text-[10px] font-bold border transition-colors ${
                  dateFilterMode === '7_DAYS'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                    : 'bg-[#030905] text-gray-400 border-amber-950 hover:bg-[#07160e]'
                }`}
              >
                آخر 7 أيام
              </button>
            </div>
            {dateFilterMode === 'CUSTOM' ? (
              <input
                type="date"
                value={customDate}
                onChange={(e) => setCustomDate(e.target.value)}
                className="w-full bg-[#030905] border border-amber-900/70 rounded-lg p-1.5 text-white text-[11px] mt-1"
              />
            ) : (
              <button
                onClick={() => setDateFilterMode('CUSTOM')}
                className="text-[10px] text-amber-400/80 hover:text-amber-300 underline block mt-1"
              >
                + اختيار تاريخ مخصص
              </button>
            )}
          </div>

          {/* 2. SMART OPERATION TYPE FILTER (فلتر نوع العملية) */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-gray-300 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>نوع العملية (Operation Type):</span>
            </label>
            <select
              value={operationTypeFilter}
              onChange={(e) => setOperationTypeFilter(e.target.value)}
              className="w-full bg-[#030905] border border-amber-900/70 rounded-xl p-2 text-white text-xs focus:outline-none focus:border-amber-400"
            >
              <option value="ALL">جميع أنواع العمليات (الكل)</option>
              <option value="CASHIER_TRANSFER">تحويل / إيداع / سحب كاشير (CASHIER)</option>
              <option value="ADMIN_OVERRIDE">تعديل إداري مباشر (OVERRIDE)</option>
              <option value="REWARD">مكافآت وإنجازات (REWARD)</option>
              <option value="PURCHASE">مشتريات متجر (PURCHASE)</option>
              <option value="GAME_FEE">رسوم طاولات اللعب (GAME_FEE)</option>
              <option value="GIFT">هدايا بين اللاعبين (GIFT)</option>
              <option value="TOURNAMENT_PRIZE">جوائز البطولات (TOURNAMENT)</option>
              <option value="SUBSCRIPTION">اشتراكات VIP الملكية</option>
            </select>
          </div>

          {/* 3. SMART PLAYER NAME FILTER (فلتر اسم اللاعب) */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-gray-300 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-amber-400" />
              <span>اسم اللاعب أو المعرّف (Player Name):</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={playerNameQuery}
                onChange={(e) => setPlayerNameQuery(e.target.value)}
                placeholder="ابحث باسم اللاعب أو المعرف ID..."
                className="w-full bg-[#030905] border border-amber-900/70 rounded-xl py-2 pr-8 pl-3 text-white text-xs focus:outline-none focus:border-amber-400"
              />
              <Search className="w-3.5 h-3.5 text-amber-400 absolute right-2.5 top-2.5" />
              {playerNameQuery && (
                <button
                  onClick={() => setPlayerNameQuery('')}
                  className="absolute left-2.5 top-2 text-gray-400 hover:text-white text-xs"
                >
                  ✕
                </button>
              )}
            </div>
            {/* Quick player chip suggestions */}
            <div className="flex gap-1 overflow-x-auto text-[10px] text-gray-400 pt-1">
              {['Player 1', 'سامي', 'Suspicious', 'أحمد'].map((chip) => (
                <button
                  key={chip}
                  onClick={() => setPlayerNameQuery(chip)}
                  className="px-2 py-0.5 rounded bg-[#081f12] hover:bg-[#0d2e1b] text-amber-300/80 border border-amber-950 shrink-0"
                >
                  {chip}
                </button>
              ))}
            </div>
          </div>

          {/* 4. SORT & RISK LEVEL */}
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-gray-300 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>مستوى الخطورة والترتيب:</span>
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <select
                value={riskSeverityFilter}
                onChange={(e) => setRiskSeverityFilter(e.target.value as any)}
                className="w-full bg-[#030905] border border-amber-900/70 rounded-xl p-2 text-white text-xs focus:outline-none"
              >
                <option value="ALL">كل المستويات</option>
                <option value="HIGH">خطر حرج / مشبوه</option>
                <option value="MEDIUM">خطر متوسط</option>
                <option value="LOW">خطر منخفض / آمن</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-[#030905] border border-amber-900/70 rounded-xl p-2 text-white text-xs focus:outline-none"
              >
                <option value="date_desc">الأحدث أولاً</option>
                <option value="risk_desc">الأعلى خطورة أولاً</option>
                <option value="amount_desc">الأعلى قيمة</option>
                <option value="date_asc">الأقدم أولاً</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================
          AUDIT MONITORING INTERACTIVE TABLE WITH RED HIGHLIGHTS
         ======================================================== */}
      <div className="border border-amber-900/80 rounded-2xl overflow-hidden shadow-2xl bg-[#040d07]">
        {/* Table summary header */}
        <div className="p-3 bg-[#06170d] border-b border-amber-950 flex flex-wrap items-center justify-between text-xs text-gray-300 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-300">سجل الأنشطة والمراقبة المباشر:</span>
            <span>
              عرض <strong className="text-white">{filteredRecords.length}</strong> من أصل{' '}
              <strong className="text-white">{transactions.length}</strong> عملية
            </span>
            {filteredRecords.filter(isRecordSuspicious).length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-red-950 border border-red-500 text-red-300 text-[10px] font-bold animate-pulse">
                يحتوي العرض على {filteredRecords.filter(isRecordSuspicious).length} حالة مشبوهة باللون الأحمر
              </span>
            )}
          </div>
          <div className="text-[11px] text-gray-400 flex items-center gap-3">
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              عملية عادية
            </span>
            <span className="flex items-center gap-1 text-red-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              حالة مشبوهة (تلوين أحمر)
            </span>
          </div>
        </div>

        {/* Records Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right border-collapse">
            <thead className="bg-[#050e08] text-amber-300 border-b border-amber-950 font-bold">
              <tr>
                <th className="p-3 whitespace-nowrap">التقييم والحالة</th>
                <th className="p-3 whitespace-nowrap">معرف العملية (ID)</th>
                <th className="p-3 whitespace-nowrap">اسم اللاعب (Player)</th>
                <th className="p-3 whitespace-nowrap">نوع العملية والمصدر</th>
                <th className="p-3 whitespace-nowrap">المبلغ المتداول</th>
                <th className="p-3 whitespace-nowrap">التاريخ والوقت</th>
                <th className="p-3 whitespace-nowrap">ملاحظة التدقيق والسبب</th>
                <th className="p-3 whitespace-nowrap text-center">الإجراء الفوري</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-950/60 bg-[#040e08]">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-gray-400">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <Search className="w-8 h-8 text-amber-500/50" />
                      <p className="font-bold text-gray-300">لا توجد عمليات تطابق معايير الفلترة المحددة</p>
                      <p className="text-[11px] text-gray-500">جرب تغيير اسم اللاعب أو نوع العملية أو النطاق الزمني</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((tx) => {
                  const suspicious = isRecordSuspicious(tx);
                  const reason = getSuspicionReason(tx);
                  const risk = getRiskScore(tx);
                  const isPositive = tx.amount > 0;

                  return (
                    <tr
                      key={tx.transactionId}
                      className={`transition-all ${
                        suspicious
                          ? 'bg-red-950/50 border-r-4 border-r-red-500 hover:bg-red-950/70 shadow-[inset_0_0_15px_rgba(239,68,68,0.15)]'
                          : 'hover:bg-[#071c10]'
                      }`}
                    >
                      {/* 1. Evaluation & Status (SUSPICIOUS HIGHLIGHT IN RED) */}
                      <td className="p-3 whitespace-nowrap">
                        {suspicious ? (
                          <div className="flex flex-col gap-1">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-red-600 text-white shadow-[0_0_12px_rgba(239,68,68,0.6)] animate-pulse">
                              <AlertTriangle className="w-3 h-3 shrink-0" />
                              <span>حالة مشبوهة ⚠️</span>
                            </span>
                            <span className="text-[9px] font-mono text-red-300 font-bold">
                              مؤشر الخطر: {risk}%
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-600/50">
                              <CheckCircle className="w-3 h-3 text-emerald-400" />
                              <span>طبيعية ✓</span>
                            </span>
                          </div>
                        )}
                      </td>

                      {/* 2. Transaction ID */}
                      <td className="p-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-mono font-bold ${
                              suspicious ? 'text-red-300' : 'text-amber-400'
                            }`}
                          >
                            {tx.transactionId}
                          </span>
                          <button
                            onClick={() => copyToClipboard(tx.transactionId, tx.transactionId)}
                            className="text-gray-400 hover:text-amber-300 p-0.5"
                            title="نسخ المعرف"
                          >
                            {copiedId === tx.transactionId ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                        <div className="text-[10px] text-gray-500 font-mono">
                          Seq #{tx.ledgerSequence || '1040'}
                        </div>
                      </td>

                      {/* 3. Player Name & ID */}
                      <td className="p-3 whitespace-nowrap">
                        <div
                          className={`font-bold text-sm ${
                            suspicious ? 'text-red-200' : 'text-gray-100'
                          }`}
                        >
                          {tx.playerName}
                        </div>
                        <div
                          className={`text-[10px] font-mono ${
                            suspicious ? 'text-red-400' : 'text-amber-400'
                          }`}
                        >
                          ID: {tx.playerId}
                        </div>
                      </td>

                      {/* 4. Operation Type & Source */}
                      <td className="p-3 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold border ${
                            suspicious
                              ? 'bg-red-900/60 text-red-200 border-red-500/60'
                              : 'bg-emerald-950/80 text-emerald-300 border-emerald-600/50'
                          }`}
                        >
                          <span>{tx.sourceMethod}</span>
                        </span>
                        <div className="text-[10px] text-gray-400 mt-0.5">
                          بواسطة: {tx.cashierOrAdminId}
                        </div>
                      </td>

                      {/* 5. Amount */}
                      <td className="p-3 whitespace-nowrap font-mono font-black text-sm">
                        <span
                          className={
                            suspicious
                              ? 'text-red-400 font-extrabold'
                              : isPositive
                              ? 'text-emerald-400'
                              : 'text-amber-400'
                          }
                        >
                          {isPositive ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()}
                        </span>{' '}
                        <span className="text-xs text-gray-300">
                          {tx.currencyType === 'COINS' ? '🪙' : tx.currencyType === 'GEMS' ? '💎' : '$ USD'}
                        </span>
                      </td>

                      {/* 6. Timestamp */}
                      <td className="p-3 whitespace-nowrap font-mono text-[11px] text-gray-300">
                        {tx.timestamp}
                      </td>

                      {/* 7. Reference Note & Suspicion Explanations */}
                      <td className="p-3 max-w-xs text-xs">
                        {suspicious && (
                          <div className="p-1.5 rounded-lg bg-red-900/40 border border-red-600/40 text-red-200 text-[11px] font-bold mb-1 flex items-start gap-1">
                            <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                            <span>سبب الاشتباه: {reason}</span>
                          </div>
                        )}
                        <p className="text-gray-300 line-clamp-2 text-[11px]">{tx.referenceNote}</p>
                      </td>

                      {/* 8. Actions */}
                      <td className="p-3 whitespace-nowrap text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              soundFX.playButtonClick();
                              setInspectedTx(tx);
                            }}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all ${
                              suspicious
                                ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_10px_rgba(239,68,68,0.5)]'
                                : 'bg-[#092215] hover:bg-[#0e3320] text-emerald-300 border border-emerald-600/40'
                            }`}
                          >
                            <Eye className="w-3 h-3" />
                            <span>فحص</span>
                          </button>

                          {suspicious && (
                            <button
                              onClick={() => handleResolveSuspicion(tx)}
                              className="px-2 py-1 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-emerald-200 text-[10px] font-bold border border-emerald-500/50"
                              title="تبرئة واعتماد إداري يدوي"
                            >
                              ✓ تبرئة
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================
          GEMINI AI SECURITY AUDIT REPORT MODAL
         ======================================================== */}
      {showAiModal && aiReport && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-[#05130b] border-2 border-amber-500/80 rounded-3xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-start justify-between border-b border-amber-950 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center shadow-lg text-black">
                  <Sparkles className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-amber-300">
                      تقرير التدقيق الأمني الذكي — Gemini 3.8 Flash
                    </h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                      ذكاء اصطناعي فعلي مباشر ⚡
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">
                    تحليل الأنماط والعمليات المالية وكشف التواطؤ وتبييض الرصيد في الوقت الحقيقي
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAiModal(false)}
                className="w-8 h-8 rounded-full bg-[#0a2315] hover:bg-[#123924] text-gray-400 hover:text-white flex items-center justify-center border border-amber-950 transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Score & Threat Level Banner */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className={`p-4 rounded-2xl border flex flex-col justify-between ${
                aiReport.threatLevel === 'CRITICAL' || aiReport.threatLevel === 'HIGH'
                  ? 'bg-red-950/60 border-red-500/80 text-red-200'
                  : aiReport.threatLevel === 'MEDIUM'
                  ? 'bg-amber-950/60 border-amber-500/80 text-amber-200'
                  : 'bg-emerald-950/60 border-emerald-500/80 text-emerald-200'
              }`}>
                <div className="text-[11px] font-bold">مستوى الخطر العام:</div>
                <div className="text-2xl font-black mt-1 flex items-center gap-2">
                  <span>{aiReport.threatLevel}</span>
                  {aiReport.threatLevel === 'CRITICAL' && <span>🚨</span>}
                  {aiReport.threatLevel === 'HIGH' && <span>⚠️</span>}
                  {aiReport.threatLevel === 'LOW' && <span>🛡️</span>}
                </div>
                <div className="text-[10px] opacity-80 mt-1">
                  الحالة: {aiReport.systemIntegrityVerdict}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#06180e] border border-amber-950 flex flex-col justify-between">
                <div className="text-[11px] text-gray-400 font-bold">مؤشر التهديد الأمني:</div>
                <div className="text-3xl font-black text-amber-400 font-mono mt-1">
                  {aiReport.threatScore}<span className="text-sm text-gray-400 font-normal">/100</span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2 mt-2 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${
                      aiReport.threatScore > 70 ? 'bg-red-500' : aiReport.threatScore > 40 ? 'bg-amber-400' : 'bg-emerald-400'
                    }`}
                    style={{ width: `${Math.min(100, aiReport.threatScore)}%` }}
                  />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#06180e] border border-amber-950 flex flex-col justify-between">
                <div className="text-[11px] text-gray-400 font-bold">الحسابات تحت المراقبة:</div>
                <div className="text-3xl font-black text-white font-mono mt-1">
                  {aiReport.flaggedPlayers?.length || 0}
                </div>
                <div className="text-[10px] text-gray-400">
                  تم رصدها عبر تتبع الـ IP والوتيرة
                </div>
              </div>
            </div>

            {/* Executive Summary */}
            <div className="p-4 rounded-2xl bg-[#030d06] border border-amber-900/60 space-y-1.5">
              <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>الملخص التنفيذي للمحلل الأمني (Gemini AI Summary):</span>
              </div>
              <p className="text-xs text-gray-300 leading-relaxed">
                {aiReport.executiveSummary}
              </p>
            </div>

            {/* Detected Anomalies */}
            {aiReport.detectedAnomalies?.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>الأنشطة والشبهات المكتشفة:</span>
                </div>
                <div className="space-y-1.5">
                  {aiReport.detectedAnomalies.map((anomaly, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-red-950/30 border border-red-900/50 text-red-200 text-xs flex items-center gap-2"
                    >
                      <span className="w-2 h-2 rounded-full bg-red-500 shrink-0" />
                      <span>{anomaly}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Flagged Players Table */}
            {aiReport.flaggedPlayers?.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                  <User className="w-4 h-4 text-amber-400" />
                  <span>اللاعبون المشتبه بهم بدقة الذكاء الاصطناعي:</span>
                </div>
                <div className="border border-amber-950 rounded-xl overflow-hidden text-xs">
                  <div className="grid grid-cols-4 bg-[#041107] p-2 font-bold text-gray-400 border-b border-amber-950">
                    <span>اللاعب</span>
                    <span>المعرّف</span>
                    <span>السبب</span>
                    <span>الخطورة</span>
                  </div>
                  {aiReport.flaggedPlayers.map((fp, idx) => (
                    <div
                      key={idx}
                      className="grid grid-cols-4 p-2 bg-[#020904] border-b border-amber-950/40 items-center text-[11px]"
                    >
                      <span className="font-bold text-white">{fp.playerName}</span>
                      <span className="font-mono text-gray-400">{fp.playerId}</span>
                      <span className="text-amber-300/90">{fp.reason}</span>
                      <span className={`font-black ${
                        fp.severity === 'HIGH' ? 'text-red-400' : 'text-amber-400'
                      }`}>
                        {fp.severity}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recommended Actions */}
            {aiReport.recommendedActions?.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>الإجراءات الإدارية الموصى بها:</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {aiReport.recommendedActions.map((action, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-900/60 text-emerald-300 text-xs flex items-center gap-2"
                    >
                      <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Actions Bar */}
            <div className="flex items-center justify-between pt-3 border-t border-amber-950">
              <button
                onClick={() => {
                  setShowSuspiciousOnly(true);
                  setShowAiModal(false);
                  showToast('🔍 تم تطبيق فلترة الحالات المشبوهة بناءً على تقرير AI');
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs transition-all shadow cursor-pointer"
              >
                فلترة الجدول بالحالات المشبوهة
              </button>

              <button
                onClick={() => setShowAiModal(false)}
                className="px-5 py-2 rounded-xl bg-[#071c10] hover:bg-[#0c2e1b] text-amber-300 text-xs font-bold border border-amber-500/40 transition-all cursor-pointer"
              >
                إغلاق التقرير
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          FORENSIC INSPECTION MODAL DRAWER
         ======================================================== */}
      {inspectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="relative w-full max-w-2xl bg-[#08150d] border-2 border-amber-500/60 rounded-3xl shadow-[0_0_50px_rgba(245,158,11,0.3)] overflow-hidden text-right p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-amber-950 pb-3">
              <button
                onClick={() => setInspectedTx(null)}
                className="text-gray-400 hover:text-white p-1 rounded-full text-sm font-bold"
              >
                ✕ إغلاق
              </button>
              <div className="flex items-center gap-2">
                {isRecordSuspicious(inspectedTx) && (
                  <span className="px-2.5 py-1 rounded-full bg-red-600 text-white text-xs font-black flex items-center gap-1 shadow-lg">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    حالة مشبوهة حمراء ⚠️
                  </span>
                )}
                <h3 className="text-lg font-black text-amber-300">
                  تقرير التحليل الأمني والتدقيق — {inspectedTx.transactionId}
                </h3>
              </div>
            </div>

            {/* Suspicion Notice if flagged */}
            {isRecordSuspicious(inspectedTx) && (
              <div className="p-3.5 rounded-2xl bg-red-950/80 border-2 border-red-500 text-red-100 space-y-1">
                <div className="font-black text-xs flex items-center gap-1.5 text-red-200">
                  <ShieldAlert className="w-4 h-4 text-red-400" />
                  <span>تحليل نظام كشف الاحتيال (Anti-Fraud AI Evaluation):</span>
                </div>
                <p className="text-xs">{getSuspicionReason(inspectedTx)}</p>
                <div className="text-[11px] text-red-300 font-mono pt-1">
                  مستوى الخطورة المسجل: {getRiskScore(inspectedTx)}% • الحالة الإدارية: {inspectedTx.status}
                </div>
              </div>
            )}

            {/* Details Grid */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-[#040e08] border border-amber-950 space-y-1">
                <span className="text-gray-400 text-[10px]">اللاعب والمعرّف:</span>
                <div className="font-bold text-white text-sm">{inspectedTx.playerName}</div>
                <div className="font-mono text-amber-400 text-xs">ID: {inspectedTx.playerId}</div>
              </div>

              <div className="p-3 rounded-xl bg-[#040e08] border border-amber-950 space-y-1">
                <span className="text-gray-400 text-[10px]">المبلغ والعملة:</span>
                <div className="font-bold text-amber-300 text-sm font-mono">
                  {inspectedTx.amount > 0 ? `+${inspectedTx.amount}` : inspectedTx.amount}{' '}
                  {inspectedTx.currencyType}
                </div>
                <div className="text-[10px] text-gray-400">
                  الرصيد: {inspectedTx.balanceBefore} &larr; {inspectedTx.balanceAfter}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#040e08] border border-amber-950 space-y-1">
                <span className="text-gray-400 text-[10px]">نوع العملية والمنفّذ:</span>
                <div className="font-bold text-emerald-400">{inspectedTx.sourceMethod}</div>
                <div className="text-gray-400 text-[11px]">{inspectedTx.cashierOrAdminId}</div>
              </div>

              <div className="p-3 rounded-xl bg-[#040e08] border border-amber-950 space-y-1">
                <span className="text-gray-400 text-[10px]">التوقيت وعنوان الـ IP:</span>
                <div className="font-mono text-white text-[11px]">{inspectedTx.timestamp}</div>
                <div className="font-mono text-gray-400 text-[10px]">
                  IP: {inspectedTx.ipAddress || '127.0.0.1'} | Session: {inspectedTx.sessionId || 'N/A'}
                </div>
              </div>
            </div>

            {/* Cryptographic hash */}
            <div className="p-3 rounded-xl bg-[#030a05] border border-amber-950 space-y-1">
              <span className="text-[10px] text-gray-400">بصمة التشفير المحصنة (Cryptographic Hash):</span>
              <div className="font-mono text-[10px] text-amber-400/90 break-all select-all">
                {inspectedTx.auditHash || 'sha256:7b91d2c00a94e8f15e8b417c8003f901a18c9497e88b22a101f'}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-amber-950">
              {isRecordSuspicious(inspectedTx) ? (
                <>
                  <button
                    onClick={() => handleResolveSuspicion(inspectedTx)}
                    className="px-4 py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/50 text-xs font-bold transition-all"
                  >
                    ✓ تبرئة وإلغاء علامة الشبهة
                  </button>
                  <button
                    onClick={() => handleBlockAndSanction(inspectedTx)}
                    className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-black shadow-lg transition-all"
                  >
                    ⛔ تأكيد الحظر والمخالفة
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setInspectedTx(null)}
                  className="px-4 py-2 rounded-xl bg-[#071c10] text-amber-300 text-xs font-bold border border-amber-500/40"
                >
                  إغلاق التقرير
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
