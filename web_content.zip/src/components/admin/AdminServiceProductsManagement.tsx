import React, { useState } from 'react';
import { useData } from '../../context/DataContext.tsx';
import {
  Box,
  Plus,
  Edit2,
  Trash2,
  ArrowUp,
  ArrowDown,
  Check,
  AlertCircle,
  Tag,
  ToggleLeft,
  ToggleRight,
  Search,
  Layers,
  X,
  Bot,
  Globe,
  Terminal,
  MessageSquare,
  Palette,
  FileCode
} from 'lucide-react';
import type { ServiceProductItem } from '../../types/index.ts';

export const AdminServiceProductsManagement: React.FC = () => {
  const {
    data,
    addServiceProduct,
    updateServiceProduct,
    deleteServiceProduct,
    reorderServiceProducts
  } = useData();

  const serviceProducts: ServiceProductItem[] = [...(data.serviceProducts || [])].sort(
    (a, b) => (a.displayOrder || 0) - (b.displayOrder || 0)
  );

  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ServiceProductItem | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Discord Bot');
  const [type, setType] = useState<'service' | 'product'>('service');
  const [description, setDescription] = useState('');
  const [badge, setBadge] = useState('');
  const [points, setPoints] = useState<string[]>(['']);
  const [price, setPrice] = useState('');
  const [available, setAvailable] = useState(true);
  const [showInSelectionMenu, setShowInSelectionMenu] = useState(true);
  const [iconName, setIconName] = useState('Bot');
  const [saving, setSaving] = useState(false);

  // Delete Confirm State
  const [deleteTarget, setDeleteTarget] = useState<ServiceProductItem | null>(null);
  const [toastMsg, setToastMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMsg({ text, type });
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleOpenAddModal = () => {
    setEditingItem(null);
    setName('');
    setCategory('Discord Bot');
    setType('service');
    setDescription('');
    setBadge('');
    setPoints(['', '']);
    setPrice('');
    setAvailable(true);
    setShowInSelectionMenu(true);
    setIconName('Bot');
    setModalOpen(true);
  };

  const handleOpenEditModal = (item: ServiceProductItem) => {
    setEditingItem(item);
    setName(item.name);
    setCategory(item.category || 'Discord Bot');
    setType(item.type || 'service');
    setDescription(item.description || '');
    setBadge(item.badge || '');
    setPoints(Array.isArray(item.points) && item.points.length > 0 ? [...item.points] : ['']);
    setPrice(item.price || '');
    setAvailable(item.available !== false);
    setShowInSelectionMenu(item.showInSelectionMenu !== false);
    setIconName(item.iconName || 'Bot');
    setModalOpen(true);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Name is required', 'error');
      return;
    }

    setSaving(true);
    const cleanPoints = points.map((p) => p.trim()).filter(Boolean);

    const payload = {
      name: name.trim(),
      category: category.trim(),
      type,
      description: description.trim(),
      badge: badge.trim() || undefined,
      points: cleanPoints,
      price: price.trim() || undefined,
      available,
      showInSelectionMenu,
      iconName
    };

    if (editingItem) {
      const res = await updateServiceProduct(editingItem.id, payload);
      setSaving(false);
      if (res.success) {
        setModalOpen(false);
        showToast('Item updated successfully');
      } else {
        showToast(res.error || 'Failed to update item', 'error');
      }
    } else {
      const res = await addServiceProduct(payload);
      setSaving(false);
      if (res.success) {
        setModalOpen(false);
        showToast('Item created successfully');
      } else {
        showToast(res.error || 'Failed to create item', 'error');
      }
    }
  };

  const handleDeleteItem = async () => {
    if (!deleteTarget) return;
    const res = await deleteServiceProduct(deleteTarget.id);
    setDeleteTarget(null);
    if (res.success) {
      showToast('Item deleted successfully');
    } else {
      showToast(res.error || 'Failed to delete item', 'error');
    }
  };

  const handleToggleAvailability = async (item: ServiceProductItem) => {
    const res = await updateServiceProduct(item.id, { available: !item.available });
    if (res.success) {
      showToast(`Item is now ${!item.available ? 'Available' : 'Unavailable'}`);
    } else {
      showToast(res.error || 'Failed to toggle availability', 'error');
    }
  };

  const handleToggleSelectionMenu = async (item: ServiceProductItem) => {
    const res = await updateServiceProduct(item.id, { showInSelectionMenu: !item.showInSelectionMenu });
    if (res.success) {
      showToast(`Item ${!item.showInSelectionMenu ? 'added to' : 'hidden from'} selection menu`);
    } else {
      showToast(res.error || 'Failed to update menu visibility', 'error');
    }
  };

  const handleMoveOrder = async (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= serviceProducts.length) return;

    const copy = [...serviceProducts];
    const temp = copy[index];
    copy[index] = copy[targetIndex];
    copy[targetIndex] = temp;

    const orderedIds = copy.map((c) => c.id);
    const res = await reorderServiceProducts(orderedIds);
    if (res.success) {
      showToast('Order updated');
    } else {
      showToast(res.error || 'Failed to reorder', 'error');
    }
  };

  const filteredItems = serviceProducts.filter((item) => {
    const matchesCat = categoryFilter === 'all' || item.category?.toLowerCase() === categoryFilter.toLowerCase();
    const matchesSearch = !searchTerm.trim() ||
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl shadow-2xl border text-xs font-mono font-bold ${
            toastMsg.type === 'success'
              ? 'bg-[#061825] border-cyan-400 text-cyan-300'
              : 'bg-rose-950 border-rose-500 text-rose-200'
          }`}
        >
          {toastMsg.type === 'success' ? <Check className="w-4 h-4 text-cyan-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
          <span>{toastMsg.text}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2">
            <Box className="w-5 h-5 text-cyan-400" />
            <h1 className="text-2xl font-black text-white tracking-tight font-['Plus_Jakarta_Sans']">
              Services &amp; Digital Products Catalog
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Add, edit, reorder, and configure availability for services and products shown on the public &quot;What We Do&quot; page and ticket selection menu.
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-mono font-bold transition-all shadow-sm cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Offering</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-2xl bg-[#061222] border border-white/10 text-xs">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search offerings by name or keyword..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-slate-400 text-[11px] font-mono mr-1">Category:</span>
          {['all', 'Discord Bot', 'Bot Files', 'Web Development', 'Discord Services', 'Coding', 'Graphic Design', 'Digital Products', 'Custom Solutions'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold whitespace-nowrap transition-colors cursor-pointer ${
                categoryFilter === cat
                  ? 'bg-cyan-400 text-slate-950'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300'
              }`}
            >
              {cat === 'all' ? 'All' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Offerings Table */}
      <div className="rounded-2xl bg-[#061222] border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-mono bg-white/[0.01]">
                <th className="py-3 px-4 w-12 text-center">Order</th>
                <th className="py-3 px-4">Offering Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Price</th>
                <th className="py-3 px-4">Available</th>
                <th className="py-3 px-4">In Menu</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 font-mono">
                    No services or products found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item, index) => (
                  <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                    {/* Order Controls */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1 text-slate-500">
                        <button
                          onClick={() => handleMoveOrder(index, 'up')}
                          disabled={index === 0}
                          className="hover:text-cyan-400 disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                          title="Move up"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleMoveOrder(index, 'down')}
                          disabled={index === serviceProducts.length - 1}
                          className="hover:text-cyan-400 disabled:opacity-20 cursor-pointer disabled:cursor-not-allowed"
                          title="Move down"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>

                    {/* Name & Badge */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>{item.name}</span>
                        {item.badge && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate max-w-sm mt-0.5">
                        {item.description}
                      </div>
                    </td>

                    {/* Category */}
                    <td className="py-3.5 px-4 font-mono text-[11px] text-cyan-300">
                      {item.category}
                    </td>

                    {/* Type */}
                    <td className="py-3.5 px-4">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300 uppercase">
                        {item.type}
                      </span>
                    </td>

                    {/* Price */}
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-200">
                      {item.price || 'Custom Quote'}
                    </td>

                    {/* Availability Toggle */}
                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => handleToggleAvailability(item)}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold cursor-pointer transition-all ${
                          item.available
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${item.available ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                        <span>{item.available ? 'Available' : 'Unavailable'}</span>
                      </button>
                    </td>

                    {/* Selection Menu Visibility Toggle */}
                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => handleToggleSelectionMenu(item)}
                        className={`text-xs cursor-pointer ${
                          item.showInSelectionMenu ? 'text-cyan-400' : 'text-slate-600'
                        }`}
                        title="Toggle visibility in ticket menu"
                      >
                        {item.showInSelectionMenu ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                      </button>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEditModal(item)}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
                          title="Edit Offering"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(item)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-colors cursor-pointer"
                          title="Delete Offering"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="w-full max-w-xl bg-[#061222] border border-cyan-500/30 rounded-2xl p-6 sm:p-7 shadow-2xl relative my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1 font-['Plus_Jakarta_Sans']">
              {editingItem ? 'Edit Service / Product' : 'Add New Service or Product'}
            </h2>
            <p className="text-xs text-slate-400 mb-5">
              Changes persist instantly to the database and update on the public website.
            </p>

            <form onSubmit={handleSaveItem} className="space-y-4">
              <div>
                <label className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1">
                  Name / Title <span className="text-cyan-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Custom Discord Bot Development"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#040d1a] border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-[#040d1a] border border-white/15 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="Discord Bot">Discord Bot</option>
                    <option value="Bot Files">Bot Files</option>
                    <option value="Web Development">Web Development</option>
                    <option value="Discord Services">Discord Services</option>
                    <option value="Coding">Coding</option>
                    <option value="Graphic Design">Graphic Design</option>
                    <option value="Digital Products">Digital Products</option>
                    <option value="Custom Solutions">Custom Solutions</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1">
                    Offering Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as 'service' | 'product')}
                    className="w-full bg-[#040d1a] border border-white/15 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="service">Full Service</option>
                    <option value="product">Digital Product (Downloadable/Files)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1">
                    Display Price (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. From ₹2,499 or Custom Quote"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full bg-[#040d1a] border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1">
                    Badge (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Core Service, Popular, Digital Product"
                    value={badge}
                    onChange={(e) => setBadge(e.target.value)}
                    className="w-full bg-[#040d1a] border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  placeholder="Detailed description of deliverables, specifications, and scope..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-[#040d1a] border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 resize-y"
                />
              </div>

              {/* Bullet points */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-mono font-bold uppercase text-slate-300">
                    Feature Bullet Highlights
                  </label>
                  <button
                    type="button"
                    onClick={() => setPoints([...points, ''])}
                    className="text-cyan-400 hover:text-cyan-300 text-xs font-semibold cursor-pointer"
                  >
                    + Add Point
                  </button>
                </div>
                <div className="space-y-2">
                  {points.map((pt, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={pt}
                        onChange={(e) => {
                          const updated = [...points];
                          updated[i] = e.target.value;
                          setPoints(updated);
                        }}
                        placeholder={`Feature highlight #${i + 1}`}
                        className="flex-1 px-3 py-1.5 rounded-lg bg-[#040d1a] border border-white/10 text-white text-xs focus:outline-none focus:border-cyan-400"
                      />
                      {points.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setPoints(points.filter((_, idx) => idx !== i))}
                          className="text-slate-500 hover:text-rose-400 p-1"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Toggles: Available & Show in Selection Menu */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3.5 rounded-xl bg-[#040d1a] border border-white/10">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={available}
                    onChange={(e) => setAvailable(e.target.checked)}
                    className="w-4 h-4 rounded text-cyan-500 bg-[#061222] border-white/20 focus:ring-cyan-400 cursor-pointer"
                  />
                  <div>
                    <span className="text-xs font-bold text-white block">Available for Ordering</span>
                    <span className="text-[10px] text-slate-400 block">Mark unavailable without deleting info</span>
                  </div>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showInSelectionMenu}
                    onChange={(e) => setShowInSelectionMenu(e.target.checked)}
                    className="w-4 h-4 rounded text-cyan-500 bg-[#061222] border-white/20 focus:ring-cyan-400 cursor-pointer"
                  />
                  <div>
                    <span className="text-xs font-bold text-white block">Show in Ticket Menu</span>
                    <span className="text-[10px] text-slate-400 block">Appears in &quot;What do you need?&quot; dropdown</span>
                  </div>
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold font-mono text-xs cursor-pointer shadow-sm disabled:opacity-50"
                >
                  {saving ? 'Saving...' : editingItem ? 'Save Changes' : 'Create Offering'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#061222] border border-rose-500/40 rounded-2xl p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">Delete Offering?</h3>
            <p className="text-xs text-slate-300 mb-5 leading-relaxed">
              Are you sure you want to permanently delete <strong>{deleteTarget.name}</strong>? To pause bookings without deleting, you can mark it as &quot;Unavailable&quot; instead.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteItem}
                className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
