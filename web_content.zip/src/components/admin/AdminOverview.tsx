import React from 'react';
import { 
  Users, 
  HelpCircle, 
  Trophy, 
  Gift, 
  Clock, 
  CheckCircle2, 
  Play, 
  Calendar, 
  Plus, 
  ArrowRight,
  TrendingUp,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { AdminOverviewStats, WeeklyQuiz } from '../../types';

interface AdminOverviewProps {
  language: string;
  stats: AdminOverviewStats | null;
  loading: boolean;
  onNavigate: (tab: 'quizzes' | 'edit_quiz' | 'prize' | 'settings' | 'submissions') => void;
  onOpenCreate: () => void;
  onEditQuiz: (quiz: WeeklyQuiz) => void;
  onVerifyWinnerQuick: (quizId: string) => void;
}

export default function AdminOverview({
  language,
  stats,
  loading,
  onNavigate,
  onOpenCreate,
  onEditQuiz,
  onVerifyWinnerQuick
}: AdminOverviewProps) {
  if (loading || !stats) {
    return (
      <div className="p-6 space-y-6 animate-pulse">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-24 bg-slate-800/60 rounded-2xl"></div>
          ))}
        </div>
        <div className="h-48 bg-slate-800/40 rounded-2xl"></div>
      </div>
    );
  }

  const currentQuiz = stats.currentQuiz;

  return (
    <div className="p-4 sm:p-6 space-y-6">
      
      {/* Top Banner / Welcome */}
      <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/30 p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">
        <div className="space-y-1">
          <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            {language === 'bn' ? 'অ্যাডমিন ড্যাশবোর্ড ওভারভিউ' : 'Admin Control Overview'}
          </h3>
          <p className="text-xs text-slate-300">
            {language === 'bn' 
              ? 'সাপ্তাহিক কুইজ, লাইভ নিয়ন্ত্রণ, প্রশ্ন সম্ভার এবং পুরস্কার ট্র্যাকিং' 
              : 'Complete management of weekly contests, questions, participants & prize fulfillment'}
          </p>
        </div>

        <button
          onClick={onOpenCreate}
          className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center gap-2 cursor-pointer transition-all active:scale-95 whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'bn' ? '+ নতুন কুইজ তৈরি করুন' : '+ Create Weekly Quiz'}</span>
        </button>
      </div>

      {/* 4 Core Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-indigo-400">
            <span className="text-xs font-bold text-slate-400">{language === 'bn' ? 'মোট শিক্ষার্থী' : 'Total Users'}</span>
            <Users className="w-4 h-4" />
          </div>
          <div className="text-2xl font-black text-white">{stats.totalUsers}</div>
          <div className="text-[11px] text-slate-400">
            {stats.totalParticipants} {language === 'bn' ? 'বার অংশগ্রহণ' : 'total submissions'}
          </div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-xs font-bold text-slate-400">{language === 'bn' ? 'সক্রিয় ও মোট কুইজ' : 'Quizzes'}</span>
            <Play className="w-4 h-4" />
          </div>
          <div className="text-2xl font-black text-white">
            <span className="text-emerald-400">{stats.activeQuizzesCount} Live</span>
            <span className="text-slate-500 text-base font-normal"> / {stats.totalQuizzes}</span>
          </div>
          <div className="text-[11px] text-slate-400">
            {stats.upcomingQuizzesCount} Upcoming • {stats.completedQuizzesCount} Ended
          </div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-bold text-slate-400">{language === 'bn' ? 'মোট প্রশ্ন' : 'Total Questions'}</span>
            <HelpCircle className="w-4 h-4" />
          </div>
          <div className="text-2xl font-black text-white">{stats.totalQuestionsCount}</div>
          <div className="text-[11px] text-slate-400">
            {language === 'bn' ? 'সকল কুইজে সংগৃহীত' : 'Across all weekly sets'}
          </div>
        </div>

        <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-purple-400">
            <span className="text-xs font-bold text-slate-400">{language === 'bn' ? 'চলতি পুরস্কার' : 'Current Prize'}</span>
            <Gift className="w-4 h-4" />
          </div>
          <div className="text-sm font-black text-white truncate">
            {stats.currentPrize?.name || (language === 'bn' ? 'নির্ধারিত হয়নি' : 'Not set')}
          </div>
          <div className="text-[11px] text-amber-300 font-bold">
            {stats.currentPrize?.status || 'Pending'}
          </div>
        </div>

      </div>

      {/* Active Week Quiz Detail Card */}
      {currentQuiz ? (
        <div className="bg-slate-800/70 border border-slate-700 rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-400 block">
                {language === 'bn' ? '📌 বর্তমান প্রকাশিত / লাইভ কুইজ' : '📌 Current Active Weekly Quiz'}
              </span>
              <h4 className="text-base font-black text-white">{currentQuiz.title}</h4>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 text-xs font-black rounded-lg border ${
                currentQuiz.status === 'live' 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
                  : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
              }`}>
                ● {currentQuiz.status.toUpperCase()}
              </span>

              <button
                onClick={() => onEditQuiz(currentQuiz)}
                className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-lg cursor-pointer transition-all"
              >
                {language === 'bn' ? 'সম্পাদনা করুন' : 'Edit Quiz'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 text-xs">
            <div className="bg-slate-900/60 p-3 rounded-xl space-y-1">
              <span className="text-slate-400 font-bold block">{language === 'bn' ? 'সময়সূচী ও মেয়াদ:' : 'Schedule & Duration:'}</span>
              <div className="text-white font-medium">
                {currentQuiz.startDate} ({currentQuiz.startTime}) - {currentQuiz.endDate} ({currentQuiz.endTime})
              </div>
              <div className="text-indigo-300 font-bold">
                {currentQuiz.timeLimit} {language === 'bn' ? 'মিনিট' : 'Mins'} • {currentQuiz.questions?.length || currentQuiz.questionCount} {language === 'bn' ? 'টি প্রশ্ন' : 'Questions'}
              </div>
            </div>

            <div className="bg-slate-900/60 p-3 rounded-xl space-y-1">
              <span className="text-slate-400 font-bold block">{language === 'bn' ? 'পুরস্কার তথ্য:' : 'Prize Details:'}</span>
              <div className="text-white font-black">{currentQuiz.prizeName}</div>
              <div className="text-slate-300 text-[11px] line-clamp-1">{currentQuiz.prizeDescription}</div>
            </div>

            <div className="bg-slate-900/60 p-3 rounded-xl space-y-1">
              <span className="text-slate-400 font-bold block">{language === 'bn' ? 'অংশগ্রহণকারী ও বিজয়ী:' : 'Participants & Winner:'}</span>
              <div className="text-white font-bold">
                {currentQuiz.participantsCount} {language === 'bn' ? 'জন শিক্ষার্থী অংশ নিয়েছে' : 'Learners completed'}
              </div>
              {currentQuiz.winner ? (
                <div className="text-amber-300 font-bold text-[11px]">
                  🥇 {currentQuiz.winner.displayName} ({currentQuiz.winner.score} pts)
                </div>
              ) : (
                <div className="text-slate-400 text-[11px]">
                  {language === 'bn' ? 'বিজয়ী এখনো ঘোষণা করা হয়নি' : 'Winner not yet announced'}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-800/40 border border-dashed border-slate-700 p-8 rounded-2xl text-center space-y-3">
          <Calendar className="w-10 h-10 text-slate-500 mx-auto" />
          <p className="text-sm font-bold text-slate-300">
            {language === 'bn' ? 'বর্তমানে কোনো কুইজ প্রকাশিত নেই' : 'No active quiz published'}
          </p>
          <button
            onClick={onOpenCreate}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl shadow-md cursor-pointer"
          >
            {language === 'bn' ? '+ প্রথম কুইজ তৈরি করুন' : '+ Create First Quiz'}
          </button>
        </div>
      )}

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={() => onNavigate('quizzes')}
          className="p-4 bg-slate-800/70 hover:bg-slate-800 border border-slate-700 rounded-xl text-left flex items-center justify-between group cursor-pointer transition-all"
        >
          <div>
            <span className="text-xs font-black text-white block group-hover:text-indigo-400">
              {language === 'bn' ? '📋 কুইজ তালিকা ও আর্কাইভ' : '📋 All Quizzes & Archive'}
            </span>
            <span className="text-[11px] text-slate-400">
              {language === 'bn' ? 'সকল সপ্তাহের কুইজ নিয়ন্ত্রণ ও ডুপ্লিকেট' : 'View, edit, duplicate & schedule'}
            </span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-400" />
        </button>

        <button
          onClick={() => onNavigate('submissions')}
          className="p-4 bg-slate-800/70 hover:bg-slate-800 border border-slate-700 rounded-xl text-left flex items-center justify-between group cursor-pointer transition-all"
        >
          <div>
            <span className="text-xs font-black text-white block group-hover:text-amber-400">
              {language === 'bn' ? '🏆 ফলাফল, লিডারবোর্ড ও বিজয়ী' : '🏆 Results & Winner Verification'}
            </span>
            <span className="text-[11px] text-slate-400">
              {language === 'bn' ? 'নম্বর যাচাই ও কুরিয়ার ট্র্যাকিং' : 'Verify scores & courier tracking'}
            </span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-400" />
        </button>

        <button
          onClick={() => onNavigate('settings')}
          className="p-4 bg-slate-800/70 hover:bg-slate-800 border border-slate-700 rounded-xl text-left flex items-center justify-between group cursor-pointer transition-all"
        >
          <div>
            <span className="text-xs font-black text-white block group-hover:text-purple-400">
              {language === 'bn' ? '⚙️ গ্লোবাল রুলস ও অ্যাডমিন পিন' : '⚙️ Rules & Admin PIN'}
            </span>
            <span className="text-[11px] text-slate-400">
              {language === 'bn' ? 'ডিফল্ট নিয়মাবলী, নেগেটিভ মার্কিং ও পাসওয়ার্ড' : 'Default timer, negative marks & PIN'}
            </span>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-400" />
        </button>
      </div>

    </div>
  );
}
