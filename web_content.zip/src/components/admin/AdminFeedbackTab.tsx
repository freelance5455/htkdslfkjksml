import React, { useState } from 'react';
import { 
  MessageSquareHeart, 
  Star, 
  Search, 
  Sparkles, 
  ThumbsUp, 
  Coins, 
  Users, 
  Calendar,
  CheckCircle2,
  TrendingUp,
  Download
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { INITIAL_FEEDBACK_SUBMISSIONS } from '../../services/appInstallOffers';
import { AppFeedbackSubmission } from '../../types';

export const AdminFeedbackTab: React.FC = () => {
  const { allUsers } = useApp();

  const [feedbacks, setFeedbacks] = useState<AppFeedbackSubmission[]>(() => {
    try {
      const saved = localStorage.getItem('taskearn_admin_feedback_submissions');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    return INITIAL_FEEDBACK_SUBMISSIONS;
  });

  const [search, setSearch] = useState('');

  const totalSubmissions = feedbacks.length;
  const averageRating = totalSubmissions > 0 
    ? (feedbacks.reduce((sum, f) => sum + f.overallRating, 0) / totalSubmissions).toFixed(1)
    : '5.0';
  const totalRewardsDistributed = feedbacks.reduce((sum, f) => sum + f.rewardCoinsEarned, 0);

  const filteredFeedbacks = feedbacks.filter(f => 
    f.userName.toLowerCase().includes(search.toLowerCase()) ||
    f.userEmail.toLowerCase().includes(search.toLowerCase()) ||
    f.comments.toLowerCase().includes(search.toLowerCase()) ||
    f.favoriteFeature.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Top Banner */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-pink-500/20 text-pink-400 border border-pink-500/30 flex items-center justify-center shrink-0">
            <MessageSquareHeart className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white">
                App Feedback & Feature Survey Console
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-pink-500/20 text-pink-300 border border-pink-500/30">
                User Insights
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Review live user ratings, requested feature votes, and detailed improvement suggestions.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-right">
          <div>
            <span className="text-[10px] text-slate-400 block uppercase font-bold">Average Rating</span>
            <span className="text-xl font-black text-amber-400 flex items-center gap-1 justify-end">
              <Star className="w-4 h-4 fill-amber-400" />
              <span>{averageRating} / 5.0</span>
            </span>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Total Surveys Completed</span>
          <p className="text-2xl font-black text-white">{totalSubmissions}</p>
          <span className="text-[10px] text-emerald-400 font-semibold">100% Verified Users</span>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Survey Rewards Paid</span>
          <p className="text-2xl font-black text-amber-400">🪙 {totalRewardsDistributed.toLocaleString()}</p>
          <span className="text-[10px] text-slate-400">+500 Coins per submission</span>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Most Loved Feature</span>
          <p className="text-sm font-black text-purple-300 truncate">10,080+ Install Pool</p>
          <span className="text-[10px] text-purple-400 font-semibold">92% Positive votes</span>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Top Requested Feature</span>
          <p className="text-sm font-black text-emerald-300 truncate">Instant USDT Cashout</p>
          <span className="text-[10px] text-emerald-400 font-semibold">88% of users voted</span>
        </div>
      </div>

      {/* Submissions List */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-pink-400" />
              <span>User Survey Responses ({filteredFeedbacks.length})</span>
            </h3>
            <p className="text-xs text-slate-400">
              Live feedback and user sentiment analysis.
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search user name or feedback..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-700 bg-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
          </div>
        </div>

        <div className="space-y-3">
          {filteredFeedbacks.map((fb) => (
            <div 
              key={fb.id}
              className="p-4 sm:p-5 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-3 hover:border-slate-700 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-300 font-bold flex items-center justify-center text-xs">
                    {fb.userName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-xs sm:text-sm text-white">{fb.userName}</h4>
                    <span className="text-[11px] text-slate-400 font-mono">{fb.userEmail}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center text-amber-400">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-3.5 h-3.5 ${i < fb.overallRating ? 'fill-amber-400 text-amber-400' : 'text-slate-600'}`} 
                      />
                    ))}
                  </div>
                  <span className="text-[10px] text-slate-500">
                    {new Date(fb.submittedAt).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-300 italic">
                "{fb.comments}"
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-[10px] font-semibold text-slate-400">Requested Features:</span>
                {fb.requestedFeatures.map((req, idx) => (
                  <span 
                    key={idx}
                    className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
                  >
                    + {req}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
