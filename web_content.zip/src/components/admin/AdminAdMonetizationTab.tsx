import React, { useState } from 'react';
import { 
  DollarSign, 
  Play, 
  TrendingUp, 
  Eye, 
  Sparkles, 
  Save, 
  Check, 
  Tv, 
  BarChart3, 
  Sliders, 
  ShieldAlert, 
  Activity,
  Layers,
  ArrowUpRight,
  RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

export const AdminAdMonetizationTab: React.FC = () => {
  const { 
    systemSettings, 
    updateSystemSettings, 
    recordPlaySeen,
    allUsers 
  } = useApp();

  const [cpmRate, setCpmRate] = useState<number>(systemSettings.adminCpmRateRupees || 250);
  const [adNetwork, setAdNetwork] = useState<string>(systemSettings.adNetworkProvider || 'Google AdMob + Unity Video Ads');
  const [savedNotice, setSavedNotice] = useState<boolean>(false);
  const [simulatedCount, setSimulatedCount] = useState<number>(0);

  const totalPlays = systemSettings.totalPlaysSeen || 34820;
  const totalRevenueRupees = systemSettings.adminTotalAdRevenueRupees || 8705;
  const currencySymbol = systemSettings.currencySymbol || '₹';

  // Total Coins paid out by platform
  const totalCirculatingCoins = allUsers.reduce((sum, u) => sum + (u.coins || 0), 0);
  const totalUserPayoutLiability = totalCirculatingCoins / (systemSettings.coinsPerCurrencyUnit || 1);
  const netAdminProfit = Math.max(0, totalRevenueRupees - (totalUserPayoutLiability * 0.4));
  const profitMarginPercent = totalRevenueRupees > 0 
    ? Math.min(95, Math.round((netAdminProfit / totalRevenueRupees) * 100))
    : 65;

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSystemSettings({
      adminCpmRateRupees: Number(cpmRate) || 250,
      adNetworkProvider: adNetwork,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const handleSimulatePlaySeen = () => {
    const res = recordPlaySeen(60);
    setSimulatedCount(prev => prev + 1);
    confetti({
      particleCount: 50,
      spread: 50,
      origin: { y: 0.7 }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Top Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-600/30 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/10">
            <DollarSign className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black tracking-tight text-white">
                Play Seen & Admin Ad Revenue Console
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Live Monetization Active
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Users watch YouTube videos and play ads; system tracks "Play Seen" impressions and generates Admin Earning revenue!
            </p>
          </div>
        </div>

        {/* Quick Simulation Trigger */}
        <button
          type="button"
          onClick={handleSimulatePlaySeen}
          className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition-all cursor-pointer active:scale-95 shrink-0"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Simulate Play Seen (+1 View)</span>
        </button>
      </div>

      {/* 4 Core Monetization Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Total Plays Seen */}
        <div className="p-4 rounded-2xl sm:rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Plays Seen</span>
            <Eye className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            {totalPlays.toLocaleString()}
          </div>
          <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold">
            <TrendingUp className="w-3 h-3" />
            <span>+1,420 plays today</span>
          </div>
        </div>

        {/* Total Admin Ad Revenue */}
        <div className="p-4 rounded-2xl sm:rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Admin Ad Revenue</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-400">
            {currencySymbol}{Number(totalRevenueRupees).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 font-bold">
            ≈ ${(totalRevenueRupees / 83).toFixed(2)} USD Net Earned
          </div>
        </div>

        {/* Current eCPM Rate */}
        <div className="p-4 rounded-2xl sm:rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Current eCPM</span>
            <Activity className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-sky-400">
            {currencySymbol}{cpmRate}
          </div>
          <div className="text-[10px] text-slate-400 font-bold">
            Per 1,000 Video & Ad Views
          </div>
        </div>

        {/* Admin Profit Margin */}
        <div className="p-4 rounded-2xl sm:rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Net Profit Margin</span>
            <BarChart3 className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-purple-400">
            {profitMarginPercent}%
          </div>
          <div className="text-[10px] text-emerald-400 font-bold">
            Revenue exceeds user rewards
          </div>
        </div>

      </div>

      {/* eCPM Customizer Form & Ad Provider Config */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Settings Form */}
        <div className="lg:col-span-7">
          <form onSubmit={handleSaveSettings} className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-400" />
                <span>eCPM & Ad Network Configuration</span>
              </h3>
              {savedNotice && (
                <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1 animate-in fade-in">
                  <Check className="w-3.5 h-3.5" />
                  <span>eCPM Updated Live!</span>
                </span>
              )}
            </div>

            {/* eCPM Rate Input */}
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-black text-emerald-300 block">
                    eCPM (Effective Cost Per 1,000 Plays)
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Defines how much money the admin earns for every 1,000 video / ad plays seen in the app.
                  </p>
                </div>
                <span className="text-base font-black text-emerald-400 px-3 py-1 rounded-xl bg-emerald-500/20 border border-emerald-500/30">
                  {currencySymbol}{cpmRate} / 1k Plays
                </span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="range"
                  min={50}
                  max={1000}
                  step={10}
                  value={cpmRate}
                  onChange={(e) => setCpmRate(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <input
                  type="number"
                  min={10}
                  max={5000}
                  value={cpmRate}
                  onChange={(e) => setCpmRate(Number(e.target.value))}
                  className="w-24 px-2.5 py-1.5 rounded-xl border border-emerald-500/40 bg-slate-950 font-black text-white text-center"
                />
              </div>
            </div>

            {/* Ad Network Provider */}
            <div>
              <label className="block font-bold text-slate-300 mb-1">
                Connected Ad Network / Monetization Stack
              </label>
              <input
                type="text"
                value={adNetwork}
                onChange={(e) => setAdNetwork(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-bold"
                placeholder="Google AdMob, Unity Ads, AppLovin MAX"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Official mediation partners streaming video ads and sponsored impressions.
              </span>
            </div>

            {/* Quick eCPM Presets */}
            <div>
              <label className="block font-bold text-slate-300 mb-1.5">
                Quick Industry Benchmarks
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setCpmRate(150)}
                  className={`py-2 rounded-xl border text-center transition-all cursor-pointer font-bold ${
                    cpmRate === 150 
                      ? 'bg-emerald-600 text-white border-emerald-500' 
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  <div className="text-[11px]">Standard Tier</div>
                  <div className="text-[10px] text-slate-400">₹150 / $1.80</div>
                </button>
                <button
                  type="button"
                  onClick={() => setCpmRate(250)}
                  className={`py-2 rounded-xl border text-center transition-all cursor-pointer font-bold ${
                    cpmRate === 250 
                      ? 'bg-emerald-600 text-white border-emerald-500' 
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  <div className="text-[11px]">High Tier (Default)</div>
                  <div className="text-[10px] text-slate-400">₹250 / $3.00</div>
                </button>
                <button
                  type="button"
                  onClick={() => setCpmRate(450)}
                  className={`py-2 rounded-xl border text-center transition-all cursor-pointer font-bold ${
                    cpmRate === 450 
                      ? 'bg-emerald-600 text-white border-emerald-500' 
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  <div className="text-[11px]">VIP Premium</div>
                  <div className="text-[10px] text-slate-400">₹450 / $5.40</div>
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Monetization & eCPM Rates</span>
            </button>
          </form>
        </div>

        {/* Right Column: Monetization Breakdown & Live Stream */}
        <div className="lg:col-span-5 space-y-4">
          
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3.5 text-xs">
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <Tv className="w-4 h-4 text-emerald-400" />
              <span>Monetization Stream Sources</span>
            </h3>

            <div className="space-y-2.5">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">YouTube Watch Sessions</span>
                  <span className="text-[10px] text-slate-400">Marathon 2-Hour & 15s Clips</span>
                </div>
                <div className="text-right">
                  <span className="text-emerald-400 font-black">68% Share</span>
                  <span className="text-[10px] text-slate-400 block">23,677 plays</span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Interstitial Video Ads</span>
                  <span className="text-[10px] text-slate-400">Triggered between task claims</span>
                </div>
                <div className="text-right">
                  <span className="text-teal-400 font-black">22% Share</span>
                  <span className="text-[10px] text-slate-400">7,660 plays</span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Rewarded Video Boosts</span>
                  <span className="text-[10px] text-slate-400">Daily streak double bonus</span>
                </div>
                <div className="text-right">
                  <span className="text-purple-400 font-black">10% Share</span>
                  <span className="text-[10px] text-slate-400">3,483 plays</span>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-slate-300 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-emerald-400 text-xs">
                <Check className="w-3.5 h-3.5" />
                <span>Automated Real-Time Revenue Accrual</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Whenever any user completes a video task or views a sponsored clip in the app, the counter triggers <code>recordPlaySeen()</code> and increments Admin Revenue automatically.
              </p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
