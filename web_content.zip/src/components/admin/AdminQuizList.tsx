import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Copy, 
  Play, 
  Pause, 
  Clock, 
  Archive, 
  CheckCircle, 
  Gift, 
  Users, 
  Calendar,
  ChevronRight,
  Sparkles,
  AlertCircle,
  Bell,
  Send,
  Tv,
  CheckCircle2,
  Layers,
  FileBox,
  History,
  Trophy,
  Flame
} from 'lucide-react';
import { WeeklyQuiz, WeeklyQuizStatus } from '../../types';

interface AdminQuizListProps {
  language: string;
  quizzes: WeeklyQuiz[];
  loading: boolean;
  onOpenCreate: () => void;
  onEditQuiz: (quiz: WeeklyQuiz) => void;
  onDeleteQuiz: (id: string) => void;
  onDuplicateQuiz: (id: string) => void;
  onSetStatus: (id: string, status: WeeklyQuizStatus) => void;
  onExtendTime: (id: string, hours: number) => void;
  onToggleArchive: (id: string, isArchived: boolean) => void;
  onViewSubmissions: (quiz: WeeklyQuiz) => void;
  onBroadcastAlert?: (quizId: string) => void;
}

export default function AdminQuizList({
  language,
  quizzes,
  loading,
  onOpenCreate,
  onEditQuiz,
  onDeleteQuiz,
  onDuplicateQuiz,
  onSetStatus,
  onExtendTime,
  onToggleArchive,
  onViewSubmissions,
  onBroadcastAlert
}: AdminQuizListProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showArchive, setShowArchive] = useState<boolean>(false);

  const isBn = language === 'bn';

  // Apply Search & Basic Filters
  const filteredQuizzes = quizzes.filter(q => {
    const isArchived = Boolean(q.isArchived);
    if (showArchive !== isArchived) return false;

    if (statusFilter !== 'all' && q.status !== statusFilter) return false;

    if (searchQuery.trim()) {
      const qLower = searchQuery.toLowerCase();
      return (
        q.title.toLowerCase().includes(qLower) ||
        q.description?.toLowerCase().includes(qLower) ||
        q.prizeName?.toLowerCase().includes(qLower) ||
        String(q.weekNumber || '').toLowerCase().includes(qLower)
      );
    }
    return true;
  });

  // Separate into:
  // 1. Running / Active Quizzes (live, scheduled, published)
  // 2. Draft & Ended / Completed Quizzes (ended, completed, draft, paused, archived)
  const isRunningStatus = (status: string) => status === 'live' || status === 'scheduled' || status === 'published';

  const runningQuizzes = filteredQuizzes.filter(q => isRunningStatus(q.status));
  
  // Completed / ended / draft quizzes ordered sequentially in the order they were played/finished
  const draftAndEndedQuizzes = filteredQuizzes
    .filter(q => !isRunningStatus(q.status))
    .sort((a, b) => {
      // Sort in sequential play order (e.g. by weekNumber if available, or start/end dates chronologically)
      const weekA = Number(a.weekNumber) || 0;
      const weekB = Number(b.weekNumber) || 0;
      if (weekA !== weekB) {
        return weekA - weekB; // Sequential order: Week 1, Week 2, Week 3...
      }
      const dateA = new Date(`${a.startDate} ${a.startTime || '00:00'}`).getTime();
      const dateB = new Date(`${b.startDate} ${b.startTime || '00:00'}`).getTime();
      return dateA - dateB;
    });

  // Reusable Quiz Card Renderer
  const renderQuizCard = (quiz: WeeklyQuiz, displayIndex: number, isDraftBox: boolean = false) => {
    const isLive = quiz.status === 'live';
    const isPaused = quiz.status === 'paused';
    const isDraft = quiz.status === 'draft';
    const isEnded = quiz.status === 'ended' || quiz.status === 'completed';

    return (
      <div 
        key={quiz.id}
        id={`admin-quiz-card-${quiz.id}`}
        className={`rounded-2xl p-4 sm:p-5 transition-all shadow-md space-y-3.5 ${
          isLive 
            ? 'bg-slate-800/90 border-2 border-emerald-500/60 shadow-emerald-500/10' 
            : isDraftBox 
              ? 'bg-slate-900/90 border border-slate-800 hover:border-slate-700' 
              : 'bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80'
        }`}
      >
        {/* Header Row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              {/* Sequential Play / Match Number Badge */}
              <span className="px-2.5 py-0.5 bg-slate-800 text-slate-300 border border-slate-700 text-[11px] font-mono font-black rounded-md flex items-center gap-1">
                <span>#{displayIndex + 1}</span>
                {quiz.weekNumber ? <span>(Week {quiz.weekNumber})</span> : null}
              </span>

              <span className="px-2 py-0.5 bg-indigo-950 text-indigo-300 border border-indigo-500/40 text-[10px] font-bold rounded-md">
                {quiz.targetLevel}
              </span>
              
              <span className={`px-2.5 py-0.5 text-[11px] font-black rounded-md border ${
                isLive ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 animate-pulse' :
                isPaused ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                isDraft ? 'bg-slate-800 text-slate-400 border-slate-700' :
                isEnded ? 'bg-rose-500/15 text-rose-300 border-rose-500/30' :
                'bg-sky-500/20 text-sky-300 border-sky-500/40'
              }`}>
                ● {quiz.status.toUpperCase()}
              </span>

              {isEnded && (
                <span className="px-2 py-0.5 bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-black rounded-md flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-purple-400" />
                  <span>{isBn ? 'খেলা সম্পন্ন' : 'Play Completed'}</span>
                </span>
              )}

              {quiz.winnerVerified && (
                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black rounded-md flex items-center gap-1">
                  <Trophy className="w-3 h-3 text-amber-400" />
                  <span>{isBn ? '🏆 বিজয়ী ঘোষিত' : '🏆 Winner Verified'}</span>
                </span>
              )}
            </div>

            <h4 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
              <span>{quiz.title}</span>
            </h4>
          </div>

          {/* Right Status Actions */}
          <div className="flex items-center gap-1.5 self-start sm:self-auto">
            {/* Live / Pause / Resume controls */}
            {isLive ? (
              <button
                onClick={() => onSetStatus(quiz.id, 'paused')}
                title="Pause Quiz"
                className="px-2.5 py-1.5 bg-amber-600/30 hover:bg-amber-600 text-amber-200 hover:text-white border border-amber-500/40 text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>{isBn ? 'স্থগিত' : 'Pause'}</span>
              </button>
            ) : (
              <button
                onClick={() => onSetStatus(quiz.id, 'live')}
                title="Publish & Make Live"
                className="px-2.5 py-1.5 bg-emerald-600/30 hover:bg-emerald-600 text-emerald-200 hover:text-white border border-emerald-500/40 text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isBn ? 'লাইভ করুন' : 'Make Live'}</span>
              </button>
            )}

            <button
              onClick={() => onExtendTime(quiz.id, 24)}
              title="Extend 24 Hours"
              className="px-2.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>+24h</span>
            </button>
          </div>
        </div>

        {/* Meta details */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-slate-300 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
          <div>
            <span className="text-[10px] text-slate-400 block">{isBn ? 'প্রশ্ন সংখ্যা ও সময়:' : 'Questions & Time:'}</span>
            <span className="font-bold text-white">{quiz.questions?.length || quiz.questionCount} Qs • {quiz.timeLimit}m</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 block">{isBn ? 'খেলার সময়সূচী:' : 'Schedule:'}</span>
            <span className="font-medium text-slate-200">{quiz.startDate} ({quiz.startTime || '10:00'})</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 block">{isBn ? 'পুরস্কার:' : 'Prize:'}</span>
            <span className="font-bold text-amber-300 truncate block">{quiz.prizeName}</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 block">{isBn ? 'অংশগ্রহণকারী ও এডস:' : 'Users & Ads:'}</span>
            <span className="font-bold text-white">{quiz.participantsCount || 0} Users • {quiz.requireAdsBeforeQuiz !== false ? '২টি এড' : 'নো এড'}</span>
          </div>
        </div>

        {/* Bottom Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onViewSubmissions(quiz)}
              className="px-3 py-1.5 bg-indigo-600/40 hover:bg-indigo-600 text-indigo-200 hover:text-white border border-indigo-500/40 text-xs font-extrabold rounded-lg cursor-pointer transition-all flex items-center gap-1.5"
            >
              <Users className="w-3.5 h-3.5" />
              <span>{isBn ? 'ফলাফল ও বিজয়ী' : 'Submissions & Winner'}</span>
            </button>

            <button
              onClick={() => onEditQuiz(quiz)}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 hover:text-white text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1.5"
            >
              <Edit className="w-3.5 h-3.5" />
              <span>{isBn ? 'সম্পাদনা' : 'Edit'}</span>
            </button>

            {/* Broadcast 10-Minute Alert Button */}
            {isLive && (
              <button
                onClick={() => onBroadcastAlert && onBroadcastAlert(quiz.id)}
                className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 border border-amber-500/40 text-xs font-extrabold rounded-lg cursor-pointer transition-all flex items-center gap-1.5"
                title={isBn ? 'সকল শিক্ষার্থীদের ডিভাইসে ১০ মিনিট আগের সতর্কতা অ্যালার্ট পাঠান' : 'Broadcast 10-minute warning alert to all devices'}
              >
                <Bell className="w-3.5 h-3.5 animate-bounce" />
                <span>{isBn ? '📢 ১০-মি অ্যালার্ট পাঠান' : '📢 Send 10m Alert'}</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onDuplicateQuiz(quiz.id)}
              title={isBn ? 'পরবর্তী সপ্তাহের জন্য ডুপ্লিকেট করুন' : 'Clone for Next Week'}
              className="p-2 bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg cursor-pointer transition-all"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => onToggleArchive(quiz.id, !quiz.isArchived)}
              title={quiz.isArchived ? 'Unarchive' : 'Archive Quiz'}
              className="p-2 bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg cursor-pointer transition-all"
            >
              <Archive className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => onDeleteQuiz(quiz.id)}
              title="Delete Quiz"
              className="p-2 bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded-lg cursor-pointer transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    );
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      
      {/* Top Header & Search/Filter Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
            {isBn ? 'সাপ্তাহিক কুইজ কনটেস্ট ম্যানেজমেন্ট' : 'Weekly Quizzes Management'}
            <span className="px-2.5 py-0.5 bg-indigo-600 text-white text-xs font-bold rounded-full">
              {filteredQuizzes.length}
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {isBn 
              ? 'চলমান কুইজ কনটেস্ট ও অতীতে খেলা শেষ হওয়া সকল কুইজ ক্রমানুসারে ড্রাফ্ট বক্সে সংরক্ষিত' 
              : 'Running active contests & sequentially archived past played contests'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowArchive(!showArchive)}
            className={`px-3 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
              showArchive 
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' 
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
            }`}
          >
            <Archive className="w-3.5 h-3.5" />
            <span>{showArchive ? (isBn ? 'আর্কাইভ দেখছেন' : 'Viewing Archive') : (isBn ? 'আর্কাইভ ফাইল' : 'Archive')}</span>
          </button>

          <button
            onClick={onOpenCreate}
            className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>{isBn ? '+ নতুন কুইজ তৈরি' : '+ New Quiz'}</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-800/60 p-3 rounded-2xl border border-slate-700/60">
        
        {/* Status Filters */}
        <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
          {[
            { id: 'all', label: isBn ? 'সকল কনটেস্ট' : 'All Contests' },
            { id: 'live', label: '🟢 Live Running' },
            { id: 'scheduled', label: '📅 Scheduled' },
            { id: 'draft', label: '📝 Draft' },
            { id: 'paused', label: '⏸️ Paused' },
            { id: 'ended', label: '🏁 Ended' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-2.5 py-1 text-[11px] font-extrabold rounded-lg cursor-pointer transition-all ${
                statusFilter === tab.id
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-900/60 hover:bg-slate-700 text-slate-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isBn ? 'কুইজ নাম বা প্রাইজ দিয়ে খুঁজুন...' : 'Search quiz...'}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* If specific filter is active other than 'all', show direct list */}
      {statusFilter !== 'all' ? (
        filteredQuizzes.length === 0 ? (
          <div className="p-12 text-center bg-slate-800/30 rounded-2xl border border-dashed border-slate-700/80 space-y-3">
            <AlertCircle className="w-8 h-8 text-slate-500 mx-auto" />
            <p className="text-xs text-slate-400">
              {isBn ? 'এই ফিল্টারে কোনো কুইজ পাওয়া যায়নি' : 'No quizzes match this status filter'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredQuizzes.map((quiz, idx) => renderQuizCard(quiz, idx, !isRunningStatus(quiz.status)))}
          </div>
        )
      ) : (
        /* SECTION VIEW: 1. RUNNING/ACTIVE CONTESTS -> 2. DRAFT & COMPLETED CONTESTS BOX (IN SEQUENTIAL PLAY ORDER) */
        <div className="space-y-8">
          
          {/* 1. RUNNING / ACTIVE CONTESTS SECTION */}
          <div className="space-y-3.5">
            <div className="flex items-center justify-between pb-1 border-b border-emerald-500/20">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
                <h4 className="text-sm font-black text-emerald-400 flex items-center gap-2">
                  <span>{isBn ? '🟢 চলমান ও সক্রিয় কুইজ কনটেস্ট' : '🟢 Active & Running Contests'}</span>
                </h4>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[11px] font-black rounded-full border border-emerald-500/30">
                  {runningQuizzes.length}
                </span>
              </div>
              <span className="text-[11px] text-slate-400 hidden sm:inline">
                {isBn ? 'শিক্ষার্থীরা বর্তমানে এই কুইজগুলোতে অংশ নিতে পারবে' : 'Currently active for student participation'}
              </span>
            </div>

            {runningQuizzes.length === 0 ? (
              <div className="p-6 text-center bg-slate-900/50 rounded-2xl border border-slate-800 space-y-2">
                <AlertCircle className="w-6 h-6 text-slate-500 mx-auto" />
                <p className="text-xs text-slate-400 font-medium">
                  {isBn ? 'বর্তমানে কোনো কুইজ লাইভ চলমান নেই। নিচের ড্রাফ্ট বক্স থেকে যেকোনো কুইজ "লাইভ করুন" অথবা নতুন কুইজ তৈরি করুন।' : 'No live running quizzes right now. Make a draft live or create a new one.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {runningQuizzes.map((quiz, idx) => renderQuizCard(quiz, idx, false))}
              </div>
            )}
          </div>

          {/* 2. DRAFT & ENDED / COMPLETED CONTESTS BOX (IN SEQUENTIAL PLAY ORDER) */}
          <div className="space-y-3.5 bg-slate-950/70 p-4 sm:p-5 rounded-3xl border border-slate-800 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
                  <FileBox className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <span>{isBn ? '📦 ড্রাফ্ট বক্স ও খেলা সমাপ্ত কুইজ কনটেস্ট' : '📦 Drafts & Completed Contests Archive'}</span>
                    <span className="px-2 py-0.5 bg-slate-800 text-amber-300 text-[11px] font-black rounded-full border border-slate-700">
                      {draftAndEndedQuizzes.length}
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {isBn 
                      ? 'যেসব কুইজের খেলা শেষ হয়ে গেছে এবং ড্রাফ্ট রয়েছে, সেগুলি খেলার ক্রমানুসারে পর পর সাজানো রয়েছে।' 
                      : 'All completed and draft challenges listed sequentially in the order they were played.'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1 text-[11px] text-slate-400 font-mono self-start sm:self-auto bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                <History className="w-3 h-3 text-slate-400" />
                <span>{isBn ? 'খেলার ক্রমানুসারে সাজানো (#1, #2...)' : 'Played in sequence'}</span>
              </div>
            </div>

            {draftAndEndedQuizzes.length === 0 ? (
              <div className="p-8 text-center bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 space-y-2">
                <CheckCircle className="w-6 h-6 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400">
                  {isBn ? 'ড্রাফ্ট বক্সে কোনো সমাপ্ত বা সংরক্ষিত কুইজ নেই' : 'No draft or completed quizzes in the archive'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {draftAndEndedQuizzes.map((quiz, idx) => renderQuizCard(quiz, idx, true))}
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
