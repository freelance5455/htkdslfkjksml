import React, { useEffect, useState } from 'react';
import {
  MapPin,
  Plus,
  Search,
  Filter,
  Calendar,
  User,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Map as MapIcon,
  List as ListIcon,
  Download,
  X,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { FieldVisit, Employee, PriorityLevel, VisitStatus } from '../../types/index.ts';
import { VisitsMapView } from './VisitsMapView.tsx';
import { exportToCsv } from '../../utils/csvHelper.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { sendNotification } from '../../utils/notificationHelper.ts';

export const VisitsManager: React.FC = () => {
  const { currentOrg } = useAuth();
  const [visits, setVisits] = useState<FieldVisit[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Create Visit Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [siteAddress, setSiteAddress] = useState('');
  const [assignedEmpId, setAssignedEmpId] = useState('');
  const [scheduledDate, setScheduledDate] = useState(new Date().toISOString().split('T')[0]);
  const [scheduledTime, setScheduledTime] = useState('10:00 AM');
  const [priority, setPriority] = useState<PriorityLevel>('medium');

  const fetchVisitsAndEmployees = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      // 1. Visits
      const vQuery = query(collection(db, 'visits'), where('orgId', '==', currentOrg.id), limit(100));
      const vSnap = await getDocs(vQuery);
      const vList: FieldVisit[] = [];
      vSnap.forEach((d) => vList.push(d.data() as FieldVisit));
      vList.sort((a, b) => b.scheduledDate.localeCompare(a.scheduledDate));
      setVisits(vList);

      // 2. Employees for assignment dropdown
      const eQuery = query(collection(db, 'employees'), where('orgId', '==', currentOrg.id), limit(100));
      const eSnap = await getDocs(eQuery);
      const eList: Employee[] = [];
      eSnap.forEach((d) => eList.push(d.data() as Employee));
      setEmployees(eList);
      if (eList.length > 0 && !assignedEmpId) {
        setAssignedEmpId(eList[0].id);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVisitsAndEmployees();
  }, [currentOrg]);

  const handleCreateVisit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || !title || !customerName || !siteAddress || !assignedEmpId) return;

    const assignedEmp = employees.find((emp) => emp.id === assignedEmpId);
    const newVisit: FieldVisit = {
      id: `vis_${Date.now()}`,
      orgId: currentOrg.id,
      title,
      customerName,
      customerPhone,
      siteAddress,
      assignedEmployeeId: assignedEmpId,
      assignedEmployeeName: assignedEmp?.name || 'Technician',
      scheduledDate,
      scheduledTime,
      priority,
      status: 'scheduled',
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'visits', newVisit.id), removeUndefinedFields(newVisit));

      // In-app notification for assigned technician
      if (assignedEmpId) {
        await sendNotification({
          orgId: currentOrg.id,
          userId: assignedEmpId,
          title: 'New Field Visit Assigned',
          message: `Assigned visit: "${title}" at ${customerName} on ${scheduledDate} (${scheduledTime}).`,
          type: 'visit',
        });
      }

      setVisits((prev) => [newVisit, ...prev]);
      setIsModalOpen(false);
      resetForm();
    } catch (err) {
      console.error(err);
    }
  };

  const resetForm = () => {
    setTitle('');
    setCustomerName('');
    setCustomerPhone('');
    setSiteAddress('');
    setPriority('medium');
    setScheduledTime('10:00 AM');
  };

  const handleExportCsv = () => {
    const headers = [
      'Title',
      'Customer',
      'Phone',
      'Address',
      'AssignedTo',
      'Date',
      'Time',
      'Priority',
      'Status',
    ];
    const rows = visits.map((v) => [
      v.title,
      v.customerName,
      v.customerPhone || '',
      v.siteAddress,
      v.assignedEmployeeName,
      v.scheduledDate,
      v.scheduledTime,
      v.priority,
      v.status,
    ]);
    exportToCsv(`${currentOrg?.name || 'fieldflow'}_visits.csv`, headers, rows);
  };

  const filteredVisits = visits.filter((v) => {
    const matchesSearch =
      v.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.siteAddress?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.assignedEmployeeName?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || v.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-4">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-sky-600" />
            <span>Field Visits & Work Orders</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Dispatch, assign, and monitor customer site visits with real-time GPS locations
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Toggle View Mode */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs">
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg flex items-center gap-1 font-bold ${
                viewMode === 'list' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
              }`}
            >
              <ListIcon className="w-4 h-4" />
              <span className="hidden sm:inline">List</span>
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`p-1.5 rounded-lg flex items-center gap-1 font-bold ${
                viewMode === 'map' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
              }`}
            >
              <MapIcon className="w-4 h-4" />
              <span className="hidden sm:inline">Map</span>
            </button>
          </div>

          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-200"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule Visit</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by customer, title, technician, address..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-hidden focus:border-sky-500 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 text-slate-700 font-medium focus:outline-hidden"
          >
            <option value="all">All Statuses</option>
            <option value="scheduled">Scheduled</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>

      {/* Map or List View */}
      {viewMode === 'map' ? (
        <VisitsMapView
          visits={filteredVisits}
          onSelectVisit={(vis) => {
            // Can open detail
          }}
        />
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {loading ? (
            <div className="py-12 text-center text-xs text-slate-500 font-medium">Loading visits...</div>
          ) : filteredVisits.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No field visits match this filter.
            </div>
          ) : (
            <>
              {/* Mobile Cards View (Phones < 640px) */}
              <div className="sm:hidden divide-y divide-slate-100">
                {filteredVisits.map((vis) => (
                  <div key={vis.id} className="p-3.5 space-y-2.5 hover:bg-slate-50/60 transition-colors">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold text-sm text-slate-900">{vis.title}</div>
                        <div className="text-xs text-slate-600 font-medium">{vis.customerName}</div>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md uppercase ${
                            vis.priority === 'urgent'
                              ? 'bg-rose-100 text-rose-800'
                              : vis.priority === 'high'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {vis.priority}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                            vis.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : vis.status === 'in_progress'
                              ? 'bg-sky-100 text-sky-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {vis.status.replace('_', ' ')}
                        </span>
                      </div>
                    </div>

                    <div className="text-xs bg-slate-50 p-2 rounded-xl border border-slate-100 space-y-1">
                      <div className="flex items-center justify-between text-slate-600">
                        <span className="flex items-center gap-1 font-semibold text-slate-800">
                          <User className="w-3.5 h-3.5 text-sky-600" />
                          <span>{vis.assignedEmployeeName}</span>
                        </span>
                        <span className="font-bold text-slate-700">
                          ⏰ {vis.scheduledTime || '09:00 AM'} ({vis.scheduledDate})
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 pt-1 border-t border-slate-200/50">
                        <span className="truncate max-w-[200px]">{vis.siteAddress}</span>
                        <a
                          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(vis.siteAddress)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sky-600 font-bold flex items-center gap-0.5 shrink-0 hover:underline"
                        >
                          <span>Map</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Desktop Table View (Tablet & Desktop >= 640px) */}
              <div className="hidden sm:block overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="p-3.5">Visit / Customer</th>
                      <th className="p-3.5">Assigned Technician</th>
                      <th className="p-3.5">Site Address</th>
                      <th className="p-3.5">Scheduled</th>
                      <th className="p-3.5">Priority</th>
                      <th className="p-3.5">Status</th>
                      <th className="p-3.5 text-right">Navigate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredVisits.map((vis) => (
                      <tr key={vis.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3.5">
                          <div className="font-bold text-slate-900">{vis.title}</div>
                          <div className="text-[11px] text-slate-600">{vis.customerName}</div>
                        </td>
                        <td className="p-3.5">
                          <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                            <User className="w-3.5 h-3.5 text-sky-600" />
                            <span>{vis.assignedEmployeeName}</span>
                          </div>
                        </td>
                        <td className="p-3.5 text-slate-600 max-w-[220px] truncate">{vis.siteAddress}</td>
                        <td className="p-3.5">
                          <div className="font-bold text-slate-800">{vis.scheduledTime || '09:00 AM'}</div>
                          <div className="text-[10px] text-slate-400">{vis.scheduledDate}</div>
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md uppercase ${
                              vis.priority === 'urgent'
                                ? 'bg-red-100 text-red-800'
                                : vis.priority === 'high'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {vis.priority}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                              vis.status === 'completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : vis.status === 'in_progress'
                                ? 'bg-sky-100 text-sky-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {vis.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="p-3.5 text-right">
                          <a
                            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(vis.siteAddress)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-slate-400 hover:text-sky-600 font-bold text-[11px]"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* Schedule Visit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-base text-slate-900">Schedule Field Visit</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateVisit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Visit Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Industrial Chiller Repair & Diagnostics"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Customer / Site Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Metro General Hospital"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Customer Contact Phone</label>
                  <input
                    type="text"
                    placeholder="+1 555-0100"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Site Address *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 450 Mercy Way, Building B, North District"
                  value={siteAddress}
                  onChange={(e) => setSiteAddress(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assign Technician *</label>
                  <select
                    value={assignedEmpId}
                    onChange={(e) => setAssignedEmpId(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  >
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.name} ({emp.department})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Scheduled Date</label>
                  <input
                    type="date"
                    required
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Scheduled Time</label>
                  <input
                    type="text"
                    placeholder="e.g. 10:30 AM"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Schedule Visit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
