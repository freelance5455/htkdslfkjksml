import React, { useEffect, useState, useRef } from 'react';
import {
  MessageSquare,
  Send,
  Search,
  Radio,
  Mic,
  Square,
  Paperclip,
  FileText,
  Film,
  X,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Message, Employee } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import {
  validateAndPrepareAttachment,
  ValidatedAttachmentFile,
  ResumableUploadTask,
  ResumableUploadProgress,
  formatFileSize,
  CHAT_FILE_INPUT_ACCEPT,
} from '../../utils/mediaHelper.ts';
import { sendNotification } from '../../utils/notificationHelper.ts';
import { ChatFileAttachmentCard } from '../common/ChatFileAttachmentCard.tsx';

export const MessagingCenter: React.FC = () => {
  const { currentOrg, userProfile } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedRecipient, setSelectedRecipient] = useState<string>('all'); // 'all' or empId
  const [messages, setMessages] = useState<Message[]>([]);
  const [textInput, setTextInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);

  // Media Attachment State (holds lightweight reference only, never full large file in React state)
  const [pendingMedia, setPendingMedia] = useState<ValidatedAttachmentFile | null>(null);
  const [processingMedia, setProcessingMedia] = useState(false);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [previewModal, setPreviewModal] = useState<{
    url: string;
    type: 'image' | 'video' | 'pdf';
    title?: string;
  } | null>(null);

  // Resumable Upload Progress Map (keyed by message.id)
  const [uploadProgressMap, setUploadProgressMap] = useState<Record<string, ResumableUploadProgress>>({});
  const uploadTasksRef = useRef<Record<string, { task: ResumableUploadTask; message: Message }>>({});

  // Voice Note State
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordedBase64DataUrl, setRecordedBase64DataUrl] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState(0);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const adminUserId = userProfile?.id || 'admin';

  const fetchEmployeesAndMessages = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      // 1. Employees in this Organization
      const eSnap = await getDocs(query(collection(db, 'employees'), where('orgId', '==', currentOrg.id)));
      const empList: Employee[] = [];
      eSnap.forEach((d) => empList.push(d.data() as Employee));
      setEmployees(empList);

      // 2. Messages in this Organization
      const mSnap = await getDocs(query(collection(db, 'messages'), where('orgId', '==', currentOrg.id)));
      const msgList: Message[] = [];
      mSnap.forEach((d) => msgList.push(d.data() as Message));
      msgList.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      setMessages(msgList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployeesAndMessages();
  }, [currentOrg]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedRecipient, pendingMedia, recordedAudioUrl]);

  const handleSelectFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMediaError(null);
    setProcessingMedia(true);
    try {
      const validated = await validateAndPrepareAttachment(file);
      if (pendingMedia?.objectPreviewUrl) {
        URL.revokeObjectURL(pendingMedia.objectPreviewUrl);
      }
      setPendingMedia(validated);
    } catch (err: any) {
      setMediaError(err?.message || 'Failed to validate attachment.');
    } finally {
      setProcessingMedia(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const clearPendingMedia = () => {
    if (pendingMedia?.objectPreviewUrl) {
      URL.revokeObjectURL(pendingMedia.objectPreviewUrl);
    }
    setPendingMedia(null);
  };

  // Voice recording
  const startRecording = async () => {
    setVoiceError(null);
    setRecordedAudioUrl(null);
    setRecordedBase64DataUrl(null);
    setAudioDuration(0);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setVoiceError('Voice recording is not supported in this browser or device.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(url);

        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          setRecordedBase64DataUrl(reader.result as string);
        };

        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start(250);
      setIsRecording(true);

      timerRef.current = setInterval(() => {
        setAudioDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.warn('Microphone permission denied or unavailable:', err);
      setVoiceError('Microphone permission denied. Please allow microphone access to record voice notes.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
  };

  const cancelRecording = () => {
    if (isRecording) {
      stopRecording();
    }
    setRecordedAudioUrl(null);
    setRecordedBase64DataUrl(null);
    setAudioDuration(0);
    setVoiceError(null);
  };

  const handleSendVoiceNote = async () => {
    if (!currentOrg || !recordedBase64DataUrl || isSending) return;
    setIsSending(true);
    setVoiceError(null);

    const newMsg: Message = {
      id: `msg_adm_v_${Date.now()}`,
      orgId: currentOrg.id,
      senderId: 'admin',
      senderName: userProfile?.displayName || 'Operations Dispatch',
      senderRole: 'org_admin',
      recipientId: selectedRecipient,
      content: `Voice note (${audioDuration}s)`,
      messageType: 'voice',
      mediaUrl: recordedBase64DataUrl,
      voiceDuration: audioDuration,
      read: false,
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'messages', newMsg.id), removeUndefinedFields(newMsg));
      setMessages((prev) => [...prev, newMsg]);
      cancelRecording();

      // Send in-app notification
      if (selectedRecipient === 'all') {
        for (const emp of employees) {
          sendNotification({
            orgId: currentOrg.id,
            userId: emp.id,
            title: 'New Operations Voice Broadcast',
            message: `Dispatch sent a voice note (${audioDuration}s).`,
            type: 'message',
            linkTab: 'messages',
          });
        }
      } else {
        await sendNotification({
          orgId: currentOrg.id,
          userId: selectedRecipient,
          title: 'New Voice Message from Dispatch',
          message: `Dispatch sent a voice note (${audioDuration}s).`,
          type: 'message',
          linkTab: 'messages',
        });
      }
    } catch (err: any) {
      console.error('Error sending voice note:', err);
      setVoiceError('Failed to send voice note. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  const runResumableAttachmentUpload = async (msg: Message, task: ResumableUploadTask) => {
    if (!currentOrg) return;
    try {
      const completedMeta = await task.startOrResume(msg.id);

      // Update message only after server confirms upload completion
      const finalizedMsg: Message = {
        ...msg,
        fileId: completedMeta.id,
        storagePath: completedMeta.storagePath,
        uploadStatus: 'completed',
        thumbnailUrl: completedMeta.thumbnailUrl || msg.thumbnailUrl,
      };

      await setDoc(doc(db, 'messages', msg.id), removeUndefinedFields(finalizedMsg));
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? finalizedMsg : m)));

      // Dispatch notification after upload completes
      if (msg.recipientId === 'all') {
        for (const emp of employees) {
          sendNotification({
            orgId: currentOrg.id,
            userId: emp.id,
            title: 'New Operations File Shared',
            message: `${msg.fileName || 'Attachment'} shared by Dispatch`,
            type: 'message',
            linkTab: 'messages',
          });
        }
      } else {
        await sendNotification({
          orgId: currentOrg.id,
          userId: msg.recipientId,
          title: 'New File from Dispatch',
          message: `${msg.fileName || 'Attachment'} (${formatFileSize(msg.fileSizeBytes)})`,
          type: 'message',
          linkTab: 'messages',
        });
      }
    } catch (err: any) {
      console.warn('Resumable upload interrupted or failed:', err);
      const failedMsg: Message = {
        ...msg,
        uploadStatus: 'failed',
      };
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? failedMsg : m)));
    }
  };

  const handleRetryUpload = async (messageId: string) => {
    const entry = uploadTasksRef.current[messageId];
    if (!entry) {
      setMediaError('Please re-select the file to start a new upload.');
      return;
    }
    setMediaError(null);
    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, uploadStatus: 'uploading' } : m))
    );
    await runResumableAttachmentUpload(entry.message, entry.task);
  };

  const handleCancelUpload = async (messageId: string) => {
    const entry = uploadTasksRef.current[messageId];
    if (entry) {
      await entry.task.cancel();
      delete uploadTasksRef.current[messageId];
    }
    setUploadProgressMap((prev) => {
      const next = { ...prev };
      delete next[messageId];
      return next;
    });
    setMessages((prev) => prev.filter((m) => m.id !== messageId));
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || isSending) return;
    if (!textInput.trim() && !pendingMedia) return;

    const captionText = textInput.trim();
    const attachmentToUpload = pendingMedia;

    // If sending a file attachment, use non-blocking chunked resumable upload
    if (attachmentToUpload) {
      const msgId = `msg_adm_${Date.now()}`;
      const content =
        captionText || `Attached ${attachmentToUpload.messageType}: ${attachmentToUpload.fileName}`;

      const optimisticMsg: Message = {
        id: msgId,
        orgId: currentOrg.id,
        senderId: 'admin',
        senderName: userProfile?.displayName || 'Operations Dispatch',
        senderRole: 'org_admin',
        recipientId: selectedRecipient,
        content,
        messageType: attachmentToUpload.messageType,
        fileName: attachmentToUpload.fileName,
        fileSizeBytes: attachmentToUpload.fileSizeBytes,
        mimeType: attachmentToUpload.mimeType,
        thumbnailUrl: attachmentToUpload.thumbnailUrl,
        uploadStatus: 'uploading',
        read: false,
        createdAt: new Date().toISOString(),
      };

      const task = new ResumableUploadTask({
        file: attachmentToUpload.file,
        mimeType: attachmentToUpload.mimeType,
        companyId: currentOrg.id,
        conversationId: selectedRecipient,
        uploaderId: adminUserId,
        uploaderName: userProfile?.displayName || 'Operations Dispatch',
        thumbnailUrl: attachmentToUpload.thumbnailUrl,
        onProgress: (progress) => {
          setUploadProgressMap((prev) => ({
            ...prev,
            [msgId]: progress,
          }));
        },
      });

      uploadTasksRef.current[msgId] = { task, message: optimisticMsg };
      setMessages((prev) => [...prev, optimisticMsg]);
      setTextInput('');
      clearPendingMedia();
      setMediaError(null);

      // Run upload asynchronously so chat screen remains responsive
      runResumableAttachmentUpload(optimisticMsg, task);
      return;
    }

    // Standard text message
    setIsSending(true);
    const newMsg: Message = {
      id: `msg_adm_${Date.now()}`,
      orgId: currentOrg.id,
      senderId: 'admin',
      senderName: userProfile?.displayName || 'Operations Dispatch',
      senderRole: 'org_admin',
      recipientId: selectedRecipient,
      content: captionText,
      messageType: 'text',
      read: false,
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'messages', newMsg.id), removeUndefinedFields(newMsg));
      setMessages((prev) => [...prev, newMsg]);
      setTextInput('');
      setMediaError(null);

      if (selectedRecipient === 'all') {
        for (const emp of employees) {
          sendNotification({
            orgId: currentOrg.id,
            userId: emp.id,
            title: 'New Operations Broadcast',
            message: captionText.substring(0, 90),
            type: 'message',
            linkTab: 'messages',
          });
        }
      } else {
        await sendNotification({
          orgId: currentOrg.id,
          userId: selectedRecipient,
          title: 'New Message from Dispatch',
          message: captionText.substring(0, 90),
          type: 'message',
          linkTab: 'messages',
        });
      }
    } catch (err) {
      console.error('Error sending message:', err);
      setMediaError('Failed to send message. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  // Filter messages for current thread
  const currentThreadMessages = messages.filter((m) => {
    if (selectedRecipient === 'all') {
      return m.recipientId === 'all';
    }
    return (
      (m.senderId === selectedRecipient && m.recipientId === 'admin') ||
      (m.senderId === 'admin' && m.recipientId === selectedRecipient) ||
      m.recipientId === 'all'
    );
  });

  const selectedEmployeeObj = employees.find((e) => e.id === selectedRecipient);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col md:flex-row h-[620px]">
      {/* Left Conversations Sidebar */}
      <div className="w-full md:w-72 border-b md:border-b-0 md:border-r border-slate-200 flex flex-col bg-slate-50 shrink-0">
        <div className="p-3.5 border-b border-slate-200">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-sky-600" />
            <span>Field Communications</span>
          </h3>
          <div className="mt-2 relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search technician..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white rounded-lg border border-slate-200"
            />
          </div>
        </div>

        {/* Recipients list */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {/* Company-wide broadcast channel */}
          <button
            onClick={() => setSelectedRecipient('all')}
            className={`w-full text-left p-2.5 rounded-xl text-xs flex items-center gap-2.5 transition-colors ${
              selectedRecipient === 'all'
                ? 'bg-sky-600 text-white font-bold shadow-xs'
                : 'hover:bg-slate-200/60 text-slate-700'
            }`}
          >
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                selectedRecipient === 'all' ? 'bg-sky-500 text-white' : 'bg-sky-100 text-sky-700'
              }`}
            >
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold">Broadcast All Crew</div>
              <div className={`text-[10px] ${selectedRecipient === 'all' ? 'text-sky-100' : 'text-slate-400'}`}>
                {employees.length} Technicians
              </div>
            </div>
          </button>

          {/* Employee Channels */}
          {employees
            .filter((e) => e.name.toLowerCase().includes(searchTerm.toLowerCase()))
            .map((emp) => (
              <button
                key={emp.id}
                onClick={() => setSelectedRecipient(emp.id)}
                className={`w-full text-left p-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                  selectedRecipient === emp.id
                    ? 'bg-sky-600 text-white font-bold shadow-xs'
                    : 'hover:bg-slate-200/60 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-[11px] ${
                      selectedRecipient === emp.id ? 'bg-sky-500 text-white' : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {emp.name.charAt(0)}
                  </div>
                  <div className="truncate">
                    <div className="font-semibold truncate">{emp.name}</div>
                    <div
                      className={`text-[10px] truncate ${
                        selectedRecipient === emp.id ? 'text-sky-100' : 'text-slate-400'
                      }`}
                    >
                      {emp.department || 'Field Tech'}
                    </div>
                  </div>
                </div>

                <span
                  className={`w-2 h-2 rounded-full shrink-0 ${
                    emp.status === 'active' ? 'bg-emerald-500' : 'bg-slate-300'
                  }`}
                />
              </button>
            ))}
        </div>
      </div>

      {/* Right Chat Thread & Composer */}
      <div className="flex-1 flex flex-col min-w-0 bg-white">
        {/* Active conversation header */}
        <div className="p-3.5 border-b border-slate-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-xs">
              {selectedRecipient === 'all' ? <Radio className="w-4 h-4" /> : selectedEmployeeObj?.name.charAt(0) || 'T'}
            </div>
            <div>
              <div className="font-bold text-sm text-slate-900">
                {selectedRecipient === 'all' ? 'Company Operations Broadcast Channel' : selectedEmployeeObj?.name}
              </div>
              <div className="text-[11px] text-slate-500">
                {selectedRecipient === 'all'
                  ? 'All technicians receive announcements posted here'
                  : `${selectedEmployeeObj?.designation || 'Field Technician'} · ${selectedEmployeeObj?.phone || 'Mobile Desk'}`}
              </div>
            </div>
          </div>
          <span className="text-[11px] font-bold text-slate-500 font-mono">
            {currentThreadMessages.length} Messages
          </span>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50">
          {currentThreadMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-2">
              <MessageSquare className="w-8 h-8 stroke-[1.5]" />
              <p className="text-xs">No messages yet. Send an update, file (up to 500 MB), or voice note below.</p>
            </div>
          ) : (
            currentThreadMessages.map((msg) => {
              const isAdminMsg = msg.senderId === 'admin';
              const isFileMsg =
                msg.messageType === 'image' ||
                msg.messageType === 'document' ||
                msg.messageType === 'video';

              return (
                <div key={msg.id} className={`flex flex-col ${isAdminMsg ? 'items-end' : 'items-start'}`}>
                  <div className="text-[10px] text-slate-400 mb-1 px-1 flex items-center gap-1.5">
                    <span className="font-semibold text-slate-600">{msg.senderName}</span>
                    <span>·</span>
                    <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>

                  <div
                    className={`max-w-[85%] sm:max-w-[70%] p-3 rounded-2xl text-xs leading-relaxed space-y-1.5 shadow-2xs ${
                      isAdminMsg
                        ? 'bg-sky-600 text-white rounded-tr-xs'
                        : 'bg-white text-slate-800 rounded-tl-xs border border-slate-200'
                    }`}
                  >
                    {/* Voice Note Message */}
                    {msg.messageType === 'voice' && (
                      <div className="space-y-1.5 min-w-[200px]">
                        <div className="flex items-center gap-1.5 font-bold text-[11px]">
                          <Mic className={`w-3.5 h-3.5 ${isAdminMsg ? 'text-amber-300' : 'text-sky-600'}`} />
                          <span>Voice Note ({msg.voiceDuration || 5}s)</span>
                        </div>
                        {msg.mediaUrl && (
                          <audio controls src={msg.mediaUrl} className="w-full max-w-[240px] h-8 mt-1 rounded-lg" />
                        )}
                        {msg.voiceTranscript && (
                          <div className={`text-[11px] italic ${isAdminMsg ? 'text-sky-100' : 'text-slate-600'}`}>
                            &quot;{msg.voiceTranscript}&quot;
                          </div>
                        )}
                      </div>
                    )}

                    {/* File Attachment Message (Image, Document, Video up to 500 MB) */}
                    {isFileMsg && currentOrg && (
                      <ChatFileAttachmentCard
                        message={msg}
                        isOwnMessage={isAdminMsg}
                        currentUserId={adminUserId}
                        currentCompanyId={currentOrg.id}
                        uploadProgress={uploadProgressMap[msg.id]}
                        onRetryUpload={handleRetryUpload}
                        onCancelUpload={handleCancelUpload}
                        onPreviewMedia={(url, type, title) => setPreviewModal({ url, type, title })}
                      />
                    )}

                    {/* Regular Text */}
                    {msg.messageType === 'text' && <div>{msg.content}</div>}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Live Voice Recording Status */}
        {isRecording && (
          <div className="p-3 bg-rose-50 border-t border-rose-200 text-xs text-rose-800 flex items-center justify-between animate-pulse">
            <div className="flex items-center gap-2 font-bold">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping"></span>
              <span>Recording Voice Note... ({audioDuration}s)</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={cancelRecording}
                className="px-2 py-1 text-slate-500 hover:text-slate-800 font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={stopRecording}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold flex items-center gap-1 text-xs"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>Stop Recording</span>
              </button>
            </div>
          </div>
        )}

        {/* Voice Note Preview Before Sending */}
        {recordedAudioUrl && !isRecording && (
          <div className="p-3 bg-sky-50 border-t border-sky-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <Mic className="w-4 h-4 text-sky-600 shrink-0" />
              <div>
                <span className="font-bold text-sky-950">Voice Note Preview ({audioDuration}s)</span>
                <div className="mt-1">
                  <audio controls src={recordedAudioUrl} className="h-8 w-56" />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center">
              <button
                type="button"
                onClick={cancelRecording}
                className="px-3 py-1.5 border border-slate-300 bg-white rounded-xl text-slate-600 font-semibold hover:bg-slate-100"
              >
                Discard
              </button>
              <button
                type="button"
                onClick={handleSendVoiceNote}
                disabled={isSending}
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs disabled:opacity-50"
              >
                {isSending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>Send Voice Note</span>
              </button>
            </div>
          </div>
        )}

        {/* Voice Error Alert */}
        {voiceError && (
          <div className="p-2.5 bg-rose-50 border-t border-rose-200 text-rose-700 text-xs flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{voiceError}</span>
            </div>
            <button onClick={() => setVoiceError(null)} className="font-bold text-xs p-1">
              ✕
            </button>
          </div>
        )}

        {/* Pending Media Attachment Preview */}
        {pendingMedia && (
          <div className="p-2.5 bg-sky-50 border-t border-sky-100 flex items-center justify-between text-xs text-sky-950">
            <div className="flex items-center gap-2.5 truncate">
              {pendingMedia.thumbnailUrl || pendingMedia.objectPreviewUrl ? (
                <img
                  src={pendingMedia.thumbnailUrl || pendingMedia.objectPreviewUrl}
                  alt="Preview"
                  className="w-9 h-9 rounded-lg object-cover border border-sky-200 shrink-0"
                />
              ) : pendingMedia.messageType === 'video' ? (
                <Film className="w-5 h-5 text-sky-600 shrink-0" />
              ) : (
                <FileText className="w-5 h-5 text-sky-600 shrink-0" />
              )}
              <div className="truncate">
                <div className="truncate font-bold">{pendingMedia.fileName}</div>
                <div className="text-[10px] text-slate-500">
                  {pendingMedia.extension.toUpperCase()} · {formatFileSize(pendingMedia.fileSizeBytes)} · Ready for resumable upload
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={clearPendingMedia}
              className="p-1 text-slate-400 hover:text-slate-600 shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Media Error Alert */}
        {mediaError && (
          <div className="p-2.5 bg-rose-50 border-t border-rose-200 text-rose-700 text-xs flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{mediaError}</span>
            </div>
            <button onClick={() => setMediaError(null)} className="font-bold text-xs px-1">
              ✕
            </button>
          </div>
        )}

        {/* Hidden File Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept={CHAT_FILE_INPUT_ACCEPT}
          onChange={handleSelectFile}
          className="hidden"
        />

        {/* Chat input form */}
        <div className="p-3 border-t border-slate-200 bg-slate-50">
          <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            {/* Attachment Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={processingMedia}
              className="p-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 transition-colors shrink-0 disabled:opacity-50"
              title="Attach file (PDF, DOCX, XLSX, CSV, PPTX, JPG, PNG, WEBP, MP4, MOV, ZIP up to 500 MB)"
            >
              {processingMedia ? (
                <Loader2 className="w-4 h-4 animate-spin text-slate-600" />
              ) : (
                <Paperclip className="w-4 h-4" />
              )}
            </button>

            {/* Voice Record Button */}
            <button
              type="button"
              onClick={isRecording ? stopRecording : startRecording}
              className={`p-2.5 rounded-xl transition-all shrink-0 ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
              }`}
              title="Record voice note"
            >
              <Mic className="w-4 h-4" />
            </button>

            <input
              type="text"
              placeholder={
                pendingMedia
                  ? 'Add a caption (optional)...'
                  : `Send ${selectedRecipient === 'all' ? 'broadcast announcement' : 'message'}... (Press Enter to send)`
              }
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              className="flex-1 px-3.5 py-2.5 text-xs bg-white rounded-xl border border-slate-200 focus:outline-hidden focus:border-sky-500"
            />

            {/* Clearly visible SEND button */}
            <button
              type="submit"
              disabled={(!textInput.trim() && !pendingMedia) || isSending}
              className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors shrink-0 active:scale-95 cursor-pointer"
            >
              {isSending ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
              <span className="font-bold">Send</span>
            </button>
          </form>
        </div>
      </div>

      {/* Modal for viewing full size image, video, or PDF preview */}
      {previewModal && (
        <div
          onClick={() => setPreviewModal(null)}
          className="fixed inset-0 z-[90] bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl w-full max-h-[88vh] flex flex-col items-center"
          >
            <div className="w-full flex items-center justify-between text-white mb-2 px-1">
              <span className="text-xs font-bold truncate">{previewModal.title || 'File Preview'}</span>
              <button
                onClick={() => setPreviewModal(null)}
                className="text-white hover:text-slate-300 p-1.5 rounded-lg bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {previewModal.type === 'image' && (
              <img
                src={previewModal.url}
                alt={previewModal.title || 'Preview'}
                className="rounded-xl max-h-[80vh] w-auto object-contain bg-black"
              />
            )}
            {previewModal.type === 'video' && (
              <video
                controls
                autoPlay
                src={previewModal.url}
                className="rounded-xl max-h-[80vh] w-full bg-black"
              />
            )}
            {previewModal.type === 'pdf' && (
              <iframe
                src={previewModal.url}
                title={previewModal.title || 'PDF Preview'}
                className="w-full h-[78vh] rounded-xl bg-white border border-slate-300"
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
};
