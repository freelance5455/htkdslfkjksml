import React, { useState } from 'react';
import { 
  Headphones, 
  MessageSquare, 
  CheckCircle2, 
  Clock, 
  Send, 
  ShieldCheck, 
  User, 
  Mail, 
  Search, 
  Image as ImageIcon,
  AlertCircle,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminSupportTab: React.FC = () => {
  const { supportMessages, replySupportMessage } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [replyText, setReplyText] = useState<Record<string, string>>({});
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const filteredTickets = supportMessages.filter((ticket) => {
    const matchesCategory = selectedCategory === 'all' || ticket.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      ticket.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.message.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleReplyChange = (id: string, val: string) => {
    setReplyText(prev => ({ ...prev, [id]: val }));
  };

  const handleSendReply = (ticketId: string) => {
    const reply = replyText[ticketId]?.trim();
    if (!reply) {
      alert('Please enter a reply message.');
      return;
    }
    replySupportMessage(ticketId, reply);
    setReplyText(prev => ({ ...prev, [ticketId]: '' }));
    alert('Support reply sent successfully to user!');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-purple-950 via-slate-900 to-indigo-950 border border-purple-500/30 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center shrink-0">
            <Headphones className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">
              Customer Support & Problem Tickets ({supportMessages.length})
            </h2>
            <p className="text-xs text-slate-300">
              Review user problem reports, questions, withdrawal or task issues and send official replies.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-900/80 px-3 py-2 rounded-xl border border-purple-500/20 text-xs">
          <span className="text-slate-400">Open Tickets:</span>
          <span className="font-black text-amber-400">
            {supportMessages.filter(m => m.status === 'open' || m.status === 'in_progress').length}
          </span>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto no-scrollbar text-xs">
          {[
            { id: 'all', label: 'All Tickets' },
            { id: 'task_proof', label: 'Task Proof' },
            { id: 'withdrawal', label: 'Withdrawal' },
            { id: 'kyc_gold', label: 'KYC & Gold' },
            { id: 'vip_upgrade', label: 'VIP' },
            { id: 'other', label: 'Other' }
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap cursor-pointer transition-all ${
                selectedCategory === cat.id
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tickets..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-purple-500"
          />
        </div>
      </div>

      {/* Tickets List */}
      <div className="space-y-4">
        {filteredTickets.length === 0 ? (
          <div className="text-center py-16 space-y-3 bg-slate-900/40 rounded-3xl border border-slate-800">
            <MessageSquare className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-sm text-slate-400 font-medium">No support tickets match your filter.</p>
          </div>
        ) : (
          filteredTickets.map(ticket => (
            <div 
              key={ticket.id}
              className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl relative overflow-hidden"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center text-purple-400 font-bold text-xs uppercase">
                    {ticket.userName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm flex items-center gap-2">
                      <span>{ticket.userName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({ticket.userEmail})</span>
                    </h4>
                    <span className="text-[10px] text-purple-400 font-medium uppercase tracking-wider">
                      Category: {ticket.category}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-slate-950 text-slate-400 border border-slate-800">
                    ID: {ticket.id}
                  </span>
                  <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${
                    ticket.status === 'resolved'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {ticket.status === 'resolved' ? 'Resolved' : 'Open / In Progress'}
                  </span>
                </div>
              </div>

              {/* Subject & Message */}
              <div className="space-y-1.5">
                <h3 className="font-black text-white text-base">
                  {ticket.subject}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800/80">
                  {ticket.message}
                </p>
              </div>

              {/* Screenshot if available */}
              {ticket.screenshotUrl && (
                <div className="flex items-center gap-3 pt-1">
                  <span className="text-xs text-slate-400 font-bold">Attached Proof:</span>
                  <button
                    onClick={() => setPreviewImage(ticket.screenshotUrl || null)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-emerald-400 hover:text-white hover:border-emerald-500 transition-all cursor-pointer"
                  >
                    <ImageIcon className="w-4 h-4" />
                    <span>View Screenshot</span>
                  </button>
                </div>
              )}

              {/* Admin Reply Section */}
              <div className="space-y-2 pt-2 border-t border-slate-800/80">
                {ticket.adminReply && (
                  <div className="p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-1">
                    <div className="flex items-center gap-1.5 text-purple-300 font-bold text-xs">
                      <ShieldCheck className="w-4 h-4 text-purple-400" />
                      <span>Existing Support Reply:</span>
                    </div>
                    <p className="text-xs text-slate-200">
                      {ticket.adminReply}
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    value={replyText[ticket.id] || ''}
                    onChange={(e) => handleReplyChange(ticket.id, e.target.value)}
                    placeholder="Type official support reply message..."
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                  <button
                    onClick={() => handleSendReply(ticket.id)}
                    className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-purple-600/30 cursor-pointer shrink-0 transition-all"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Reply</span>
                  </button>
                </div>
              </div>

              <div className="text-[10px] text-slate-500 text-right">
                Submitted at: {new Date(ticket.createdAt).toLocaleString()}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Image Preview Modal */}
      {previewImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-2xl">
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white cursor-pointer z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="max-h-[80vh] overflow-auto rounded-2xl flex items-center justify-center bg-slate-950 p-2">
              <img src={previewImage} alt="Support Screenshot" className="max-w-full max-h-[75vh] object-contain rounded-xl" />
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
