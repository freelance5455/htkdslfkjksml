import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  CheckCircle, 
  Truck, 
  Search, 
  Download, 
  User, 
  Clock, 
  Award, 
  Phone, 
  MapPin, 
  Check, 
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { WeeklyQuiz, WeeklyQuizSubmission, WeeklyQuizLeaderboardEntry } from '../../types';

interface AdminSubmissionsViewProps {
  language: string;
  quiz: WeeklyQuiz | null;
  adminToken: string;
  onVerifyWinner: (quizId: string, winnerUserId: string) => void;
  onUpdatePrizeStatus: (quizId: string, status: string, notes: string) => void;
}

export default function AdminSubmissionsView({
  language,
  quiz,
  adminToken,
  onVerifyWinner,
  onUpdatePrizeStatus
}: AdminSubmissionsViewProps) {
  const [submissions, setSubmissions] = useState<WeeklyQuizSubmission[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchUser, setSearchUser] = useState<string>('');
  const [selectedSubmission, setSelectedSubmission] = useState<WeeklyQuizSubmission | null>(null);

  // Delivery status form
  const [prizeStatus, setPrizeStatus] = useState<string>(quiz?.prizeStatus || 'Announced');
  const [deliveryNotes, setDeliveryNotes] = useState<string>(quiz?.prizeDeliveryNotes || '');

  useEffect(() => {
    if (!quiz) return;
    setLoading(true);
    fetch(`/api/admin/quiz/${quiz.id}/submissions`, {
      headers: { 'x-admin-token': adminToken }
    })
      .then(res => res.json())
      .then(data => {
        if (data.submissions) {
          // Sort by score desc, timeTakenSeconds asc
          const sorted = [...data.submissions].sort((a, b) => {
            if (b.score !== a.score) return b.score - a.score;
            return a.timeTakenSeconds - b.timeTakenSeconds;
          });
          setSubmissions(sorted);
        }
      })
      .catch(err => console.error('Submissions error:', err))
      .finally(() => setLoading(false));
  }, [quiz, adminToken]);

  if (!quiz) {
    return (
      <div className="p-8 text-center text-slate-400 text-xs">
        {language === 'bn' ? 'কোনো কুইজ সিলেক্ট করা হয়নি' : 'No quiz selected'}
      </div>
    );
  }

  const filteredSubs = submissions.filter(s => 
    s.displayName.toLowerCase().includes(searchUser.toLowerCase()) ||
    s.userId.toLowerCase().includes(searchUser.toLowerCase())
  );

  const topParticipant = submissions && submissions.length > 0 ? submissions[0] : null;

  const handleSaveDelivery = () => {
    onUpdatePrizeStatus(quiz.id, prizeStatus, deliveryNotes);
  };

  const handleExportCSV = () => {
    if (submissions.length === 0) return;
    const header = 'Rank,User Name,User ID,Score,Correct,Wrong,Time (sec),Submitted At\n';
    const rows = submissions.map((s, idx) => 
      `${idx + 1},"${s.displayName}","${s.userId}",${s.score},${s.correctCount},${s.wrongCount},${s.timeTakenSeconds},"${s.submittedAt}"`
    ).join('\n');

    const blob = new Blob([header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${quiz.title.replace(/\s+/g, '_')}_Results.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      
      {/* Top Banner */}
      <div className="bg-slate-800/80 border border-slate-700 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 block">
            {language === 'bn' ? 'কুইজ ফলাফল ও অংশগ্রহণকারী তালিকা' : 'Quiz Submissions & Winner Verification'}
          </span>
          <h3 className="text-base sm:text-lg font-black text-white">{quiz.title}</h3>
          <p className="text-xs text-slate-300">
            {submissions.length} {language === 'bn' ? 'জন শিক্ষার্থী অংশগ্রহণ সম্পন্ন করেছে' : 'Learners completed this challenge'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <Download className="w-4 h-4" />
            <span>{language === 'bn' ? 'CSV এক্সপোর্ট' : 'Export CSV'}</span>
          </button>
        </div>
      </div>

      {/* Winner Verification & Fulfillment Card */}
      <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border border-amber-500/40 p-5 rounded-2xl space-y-4 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500 text-slate-950 rounded-xl font-black">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm sm:text-base font-black text-white">
                {language === 'bn' ? 'বিজয়ী নির্ধারণ ও কুরিয়ার ট্র্যাকিং' : 'Winner Announcement & Prize Tracking'}
              </h4>
              <p className="text-[11px] text-slate-300">
                {quiz.winner 
                  ? `ঘোষিত বিজয়ী: ${quiz.winner.displayName} (${quiz.winner.score} pts)`
                  : topParticipant 
                    ? `স্বাভাবিক Rank 1 প্রতিযোগী: ${topParticipant.displayName}`
                    : 'এখনো কোনো সাবমিশন জমা পড়েনি'}
              </p>
            </div>
          </div>

          {/* Quick verify button */}
          {topParticipant && !quiz.winnerVerified && (
            <button
              onClick={() => onVerifyWinner(quiz.id, topParticipant.userId)}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{language === 'bn' ? 'Rank 1 কে অফিশিয়াল বিজয়ী ঘোষণা করুন' : 'Verify Rank 1 as Winner'}</span>
            </button>
          )}

          {quiz.winnerVerified && (
            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-black rounded-xl flex items-center gap-1">
              <ShieldCheck className="w-4 h-4" />
              <span>Winner Officially Announced</span>
            </span>
          )}
        </div>

        {/* Prize status & dispatch notes */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-300">Prize Delivery Status:</label>
            <select
              value={prizeStatus}
              onChange={(e) => setPrizeStatus(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white"
            >
              <option value="Announced">🏆 Announced</option>
              <option value="Contacted">📞 Contacted Winner</option>
              <option value="Dispatched">📦 Dispatched / Courier Shipped</option>
              <option value="Delivered">✅ Delivered to Winner</option>
            </select>
          </div>

          <div className="space-y-1 sm:col-span-2 flex items-end gap-2">
            <div className="flex-1 space-y-1">
              <label className="text-[11px] font-bold text-slate-300">Courier Tracking / Dispatch Notes:</label>
              <input
                type="text"
                value={deliveryNotes}
                onChange={(e) => setDeliveryNotes(e.target.value)}
                placeholder="e.g. DTDC AWB #1294820 - Expected in 3 days"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white"
              />
            </div>
            <button
              onClick={handleSaveDelivery}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg cursor-pointer transition-all shrink-0"
            >
              Save Notes
            </button>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchUser}
            onChange={(e) => setSearchUser(e.target.value)}
            placeholder="Search candidate name..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
          />
        </div>

        <span className="text-xs text-slate-400 font-bold">
          Showing {filteredSubs.length} of {submissions.length}
        </span>
      </div>

      {/* Submissions Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-black border-b border-slate-800">
              <tr>
                <th className="px-4 py-3">Rank</th>
                <th className="px-4 py-3">Candidate</th>
                <th className="px-4 py-3">Score</th>
                <th className="px-4 py-3">Accuracy</th>
                <th className="px-4 py-3">Time Taken</th>
                <th className="px-4 py-3">Submitted At</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredSubs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500 text-xs">
                    {loading ? 'লোড হচ্ছে...' : 'কোনো ফলাফল পাওয়া যায়নি'}
                  </td>
                </tr>
              ) : (
                filteredSubs.map((sub, idx) => {
                  const isWinner = quiz.winner?.userId === sub.userId;
                  return (
                    <tr 
                      key={sub.id}
                      className={`hover:bg-slate-800/50 transition-colors ${
                        isWinner ? 'bg-amber-950/30 font-bold' : ''
                      }`}
                    >
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-black ${
                          idx === 0 ? 'bg-amber-500 text-slate-950' :
                          idx === 1 ? 'bg-slate-300 text-slate-900' :
                          idx === 2 ? 'bg-amber-700 text-white' :
                          'bg-slate-800 text-slate-400'
                        }`}>
                          {idx + 1}
                        </span>
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{sub.displayName}</span>
                          {isWinner && (
                            <span className="px-1.5 py-0.5 bg-amber-500 text-slate-950 text-[9px] font-black rounded">
                              WINNER
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 block truncate max-w-[120px]">{sub.userId}</span>
                      </td>

                      <td className="px-4 py-3 font-black text-amber-300 text-sm">
                        {sub.score} <span className="text-[10px] text-slate-500 font-normal">pts</span>
                      </td>

                      <td className="px-4 py-3">
                        <span className="text-emerald-400 font-bold">{sub.correctCount}✓</span>{' '}
                        <span className="text-rose-400 font-bold">{sub.wrongCount}✗</span>
                      </td>

                      <td className="px-4 py-3 text-slate-300">
                        {Math.floor(sub.timeTakenSeconds / 60)}m {sub.timeTakenSeconds % 60}s
                      </td>

                      <td className="px-4 py-3 text-slate-400 text-[11px]">
                        {new Date(sub.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>

                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => onVerifyWinner(quiz.id, sub.userId)}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-amber-600 hover:text-slate-950 text-slate-300 text-[11px] font-bold rounded-lg cursor-pointer transition-all"
                        >
                          Make Winner
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
