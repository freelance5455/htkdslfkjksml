import React, { useEffect, useState } from 'react';
import { Calendar, CheckCircle2, XCircle, Clock, Check, X, Filter } from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { LeaveRequest, LeaveStatus, AuditLogEntry } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { sendNotification } from '../../utils/notificationHelper.ts';

export const LeaveManager: React.FC = () => {
  const { currentOrg, userProfile } = useAuth();
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const fetchLeaves = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const q = query(collection(db, 'leave_requests'), where('orgId', '==', currentOrg.id));
      const snap = await getDocs(q);
      const list: LeaveRequest[] = [];
      snap.forEach((d) => list.push(d.data() as LeaveRequest));
      list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setLeaves(list);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaves();
  }, [currentOrg]);

  const handleDecision = async (leave: LeaveRequest, newStatus: LeaveStatus) => {
    if (!currentOrg) return;
    const updated: LeaveRequest = {
      ...leave,
      status: newStatus,
      reviewedBy: userProfile?.displayName || 'Admin',
    };

    try {
      await setDoc(doc(db, 'leave_requests', leave.id), removeUndefinedFields(updated));

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_leave_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: `Leave ${newStatus.toUpperCase()}`,
        module: 'Leave',
        details: `Leave application for ${leave.employeeName} (${leave.startDate} to ${leave.endDate}) was ${newStatus}.`,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      // Dispatch real in-app notification to employee
      if (leave.employeeId) {
        await sendNotification({
          orgId: currentOrg.id,
          userId: leave.employeeId,
          title: `Leave ${newStatus === 'approved' ? 'Approved' : 'Rejected'}`,
          message: `Your ${leave.leaveType} leave request from ${leave.startDate} to ${leave.endDate} has been ${newStatus} by ${userProfile?.displayName || 'Admin'}.`,
          type: 'leave',
        });
      }

      setLeaves((prev) => prev.map((l) => (l.id === leave.id ? updated : l)));
    } catch (err) {
      console.error(err);
    }
  };

  const filteredLeaves = leaves.filter((l) => {
    if (statusFilter === 'all') return true;
    return l.status === statusFilter;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-sky-600" />
            <span>Time Off & Leave Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Review and approve field technician annual, sick, and emergency time-off requests
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            All ({leaves.length})
          </button>
          <button
            onClick={() => setStatusFilter('pending')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              statusFilter === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Pending ({leaves.filter((l) => l.status === 'pending').length})
          </button>
          <button
            onClick={() => setStatusFilter('approved')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              statusFilter === 'approved' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Approved ({leaves.filter((l) => l.status === 'approved').length})
          </button>
        </div>
      </div>

      {/* Requests Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-500 font-medium">Loading leave requests...</div>
        ) : filteredLeaves.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            No leave requests matching this view.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Employee</th>
                  <th className="p-3.5">Leave Type</th>
                  <th className="p-3.5">Date Range</th>
                  <th className="p-3.5">Reason</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLeaves.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5">
                      <div className="font-bold text-slate-900">{l.employeeName}</div>
                      <div className="text-[10px] text-slate-400">
                        Submitted {new Date(l.createdAt).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="p-3.5 font-bold text-slate-700 capitalize">{l.leaveType}</td>
                    <td className="p-3.5 text-slate-700 font-medium">
                      {l.startDate} → {l.endDate}
                    </td>
                    <td className="p-3.5 text-slate-600 max-w-[250px] italic leading-relaxed">
                      "{l.reason}"
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                          l.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : l.status === 'rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {l.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      {l.status === 'pending' ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleDecision(l, 'approved')}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] inline-flex items-center gap-1 shadow-xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => handleDecision(l, 'rejected')}
                            className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-[11px] inline-flex items-center gap-1 shadow-xs"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-medium">
                          Reviewed by {l.reviewedBy || 'Admin'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
