import React, { useState } from 'react';
import { 
  Sparkles, 
  Bot, 
  Send, 
  Check, 
  Plus, 
  Zap, 
  ShieldAlert, 
  TrendingUp, 
  Coins, 
  Layers, 
  CheckCircle2, 
  Play, 
  Sliders, 
  RefreshCw,
  FileText,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { Task } from '../../types';

export const AdminAiStudioTab: React.FC = () => {
  const { 
    tasks, 
    addNewTask, 
    systemSettings, 
    updateSystemSettings, 
    allUsers 
  } = useApp();

  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [executionLog, setExecutionLog] = useState<{ id: string; text: string; type: 'success' | 'info' }[]>([]);
  
  // AI Task Generator State
  const [genCategory, setGenCategory] = useState<'facebook' | 'youtube' | 'app' | 'quiz'>('facebook');
  const [genCoins, setGenCoins] = useState<number>(10);
  const [genCount, setGenCount] = useState<number>(3);
  const [genSuccess, setGenSuccess] = useState<string | null>(null);

  // Quick preset prompt applicator
  const handleRunAiPrompt = (promptText: string) => {
    setIsProcessing(true);
    setAiPrompt(promptText);

    setTimeout(() => {
      setIsProcessing(false);
      const textLower = promptText.toLowerCase();

      if (textLower.includes('facebook') || textLower.includes('fb')) {
        // Generate and add Facebook tasks with 10 coins
        const newFbTasks: Omit<Task, 'id' | 'createdAt'>[] = [
          {
            title: 'Facebook: Like & React to Viral Reel',
            titleBn: 'ফেসবুক: ভাইরাল রিলে লাইক ও লাভ রিয়েক্ট দিন',
            description: 'Open the pinned Facebook community reel, tap Like/Love and receive 10 Coins.',
            descriptionBn: 'পিন করা ফেসবুক রিল ভিডিওতে লাইক দিয়ে ১০ কয়েন পুরস্কার নিন।',
            category: 'social_facebook',
            rewardCoins: 10,
            rewardRupees: 10,
            estimatedMinutes: 1,
            dailyLimit: 5,
            isExternal: true,
            externalUrl: 'https://facebook.com',
            externalPlatform: 'Facebook',
            isActive: true,
            requiresProof: true,
            proofType: 'url',
            proofInstructions: 'Submit Facebook profile link or screenshot proof',
          },
          {
            title: 'Facebook: Share Community Post to Story',
            titleBn: 'ফেসবুক: স্টোরিতে পোস্ট শেয়ার করুন',
            description: 'Share our daily payout proof to your Facebook Story to claim 10 Coins.',
            descriptionBn: 'আমাদের পেমেন্ট প্রুফ পোস্টটি আপনার ফেসবুক স্টোরিতে শেয়ার করে ১০ কয়েন আয় করুন।',
            category: 'social_facebook',
            rewardCoins: 10,
            rewardRupees: 10,
            estimatedMinutes: 1,
            dailyLimit: 3,
            isExternal: true,
            externalUrl: 'https://facebook.com',
            externalPlatform: 'Facebook',
            isActive: true,
            requiresProof: true,
            proofType: 'text',
            proofInstructions: 'Enter your Facebook handle',
          }
        ];

        newFbTasks.forEach(t => addNewTask(t));
        updateSystemSettings({ facebookTaskRewardCoins: 10 });

        setExecutionLog(prev => [
          { id: String(Date.now()), text: '🤖 AI applied configuration: Created 2 high-converting Facebook tasks (10 Coins each) and set system default to 10 Coins.', type: 'success' },
          ...prev
        ]);
        confetti({ particleCount: 70, spread: 60 });
      } else if (textLower.includes('daily') || textLower.includes('12')) {
        // Optimize daily check-in coins to 12
        updateSystemSettings({ dailyCheckinBaseCoins: 12 });
        setExecutionLog(prev => [
          { id: String(Date.now()), text: '🤖 AI optimized system settings: Daily earning base coins set to 12 Coins across all user accounts.', type: 'success' },
          ...prev
        ]);
        confetti({ particleCount: 70, spread: 60 });
      } else if (textLower.includes('cpm') || textLower.includes('ad') || textLower.includes('play seen')) {
        // Optimize CPM and ad earnings
        updateSystemSettings({ adminCpmRateRupees: 300 });
        setExecutionLog(prev => [
          { id: String(Date.now()), text: '🤖 AI optimized ad monetization: eCPM rate boosted to ₹300 per 1,000 plays (+20% profit margin).', type: 'success' },
          ...prev
        ]);
        confetti({ particleCount: 70, spread: 60 });
      } else {
        // General optimization
        updateSystemSettings({
          dailyCheckinBaseCoins: 12,
          facebookTaskRewardCoins: 10,
          enableAiTaskOptimization: true,
        });
        setExecutionLog(prev => [
          { id: String(Date.now()), text: `🤖 AI executed command: "${promptText}". System economy rebalanced (Daily 12 Coins, Facebook 10 Coins).`, type: 'success' },
          ...prev
        ]);
        confetti({ particleCount: 60, spread: 50 });
      }
    }, 900);
  };

  const handleGenerateTasks = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      let created = 0;

      if (genCategory === 'facebook') {
        const fbTitles = [
          { en: 'Facebook: Like & Save Community Post', bn: 'ফেসবুক: পোস্ট লাইক ও সেভ করুন' },
          { en: 'Facebook: Comment Feedback on Review', bn: 'ফেসবুক: রিভিউ পোস্টে কমেন্ট দিন' },
          { en: 'Facebook: Share Post to Public Group', bn: 'ফেসবুক: গ্রুপে পোস্ট শেয়ার করুন' },
        ];

        for (let i = 0; i < Math.min(genCount, fbTitles.length); i++) {
          addNewTask({
            title: fbTitles[i].en,
            titleBn: fbTitles[i].bn,
            description: `Complete this verified Facebook task to earn ${genCoins} Coins instantly.`,
            descriptionBn: `ফেসবুক কাজটি সম্পন্ন করে সাথে সাথে ${genCoins} কয়েন অর্জন করুন।`,
            category: 'social_facebook',
            rewardCoins: genCoins,
            rewardRupees: genCoins,
            estimatedMinutes: 1,
            dailyLimit: 5,
            isExternal: true,
            externalUrl: 'https://facebook.com',
            externalPlatform: 'Facebook',
            isActive: true,
            requiresProof: true,
            proofType: 'text',
            proofInstructions: 'Enter your Facebook profile name',
          });
          created++;
        }
      } else {
        for (let i = 1; i <= genCount; i++) {
          addNewTask({
            title: `AI Curated ${genCategory.toUpperCase()} Task #${i}`,
            titleBn: `এআই কিউরেটেড ${genCategory.toUpperCase()} কাজ #${i}`,
            description: `Engage with partner verified offer to claim ${genCoins} Coins.`,
            descriptionBn: `অংশীদার অফারে অংশগ্রহণ করে ${genCoins} কয়েন বোনাস নিন।`,
            category: genCategory === 'youtube' ? 'youtube_watch' : 'quiz',
            rewardCoins: genCoins,
            rewardRupees: genCoins,
            estimatedMinutes: 2,
            dailyLimit: 2,
            isExternal: false,
            isActive: true,
          });
          created++;
        }
      }

      setGenSuccess(`AI successfully generated & published ${created} new tasks!`);
      setTimeout(() => setGenSuccess(null), 3000);
      confetti({ particleCount: 80, spread: 70 });
    }, 800);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border border-purple-600/30 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center shrink-0 shadow-lg shadow-purple-500/10">
            <Bot className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black tracking-tight text-white">
                AI Customized Admin Studio
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Autonomous Intelligence
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Prompt AI to generate tasks, rebalance coin economy, detect fraud clicks, and customize dashboard parameters.
            </p>
          </div>
        </div>

        {/* AI Health Score */}
        <div className="p-3 rounded-2xl bg-black/40 border border-purple-500/20 flex items-center gap-3 shrink-0">
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">AI Economy Score</span>
            <span className="text-sm font-black text-purple-400">98 / 100 Optimal</span>
          </div>
          <div className="w-px h-7 bg-slate-800" />
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Fraud Shield</span>
            <span className="text-sm font-black text-emerald-400">100% Protected</span>
          </div>
        </div>
      </div>

      {/* AI Natural Language Prompt Controller */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-black text-white">
              AI Command & Prompt Customizer
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            Type any instruction or click a quick action preset below:
          </span>
        </div>

        {/* Input & Execute Button */}
        <div className="flex flex-col sm:flex-row items-center gap-2">
          <div className="relative w-full">
            <input
              type="text"
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              placeholder="e.g., Create 3 viral Facebook like and share tasks with 10 coins reward..."
              className="w-full px-4 py-3 rounded-2xl border border-slate-800 bg-slate-950 text-white font-medium text-xs focus:border-purple-500 focus:outline-hidden pr-10"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && aiPrompt.trim()) {
                  handleRunAiPrompt(aiPrompt);
                }
              }}
            />
            {isProcessing && (
              <RefreshCw className="w-4 h-4 text-purple-400 animate-spin absolute right-3 top-3.5" />
            )}
          </div>

          <button
            type="button"
            disabled={isProcessing || !aiPrompt.trim()}
            onClick={() => handleRunAiPrompt(aiPrompt)}
            className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/25 transition-all cursor-pointer whitespace-nowrap"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{isProcessing ? 'Executing...' : 'Apply via AI'}</span>
          </button>
        </div>

        {/* 4 One-Click Prompt Presets */}
        <div className="flex items-center gap-2 flex-wrap pt-1 text-xs">
          <span className="text-[11px] font-bold text-slate-400">Suggested Prompts:</span>
          <button
            type="button"
            onClick={() => handleRunAiPrompt('Create 3 Facebook Like, Comment and Share tasks with 10 coins reward')}
            className="px-3 py-1.5 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 text-[11px] font-bold transition-all cursor-pointer"
          >
            📘 Add Facebook Tasks (10 Coins)
          </button>
          <button
            type="button"
            onClick={() => handleRunAiPrompt('Set daily earning coins to 12 coins and rebalance streak roadmap')}
            className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[11px] font-bold transition-all cursor-pointer"
          >
            🔥 Set Daily Earning to 12 Coins
          </button>
          <button
            type="button"
            onClick={() => handleRunAiPrompt('Boost Play Seen ad monetization eCPM to ₹300 per 1k views')}
            className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold transition-all cursor-pointer"
          >
            💰 Boost Ad eCPM to ₹300
          </button>
        </div>

        {/* Live Execution Logs */}
        {executionLog.length > 0 && (
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs animate-in fade-in">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Recent AI Actions
            </span>
            {executionLog.slice(0, 3).map((log) => (
              <div key={log.id} className="text-emerald-300 font-mono text-[11px] flex items-start gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>{log.text}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Grid: AI Task Generator & AI Balancer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: AI Task Generator Form */}
        <div className="lg:col-span-7">
          <form onSubmit={handleGenerateTasks} className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Bot className="w-4 h-4 text-purple-400" />
                <span>Autonomous Task Generator</span>
              </h3>
              {genSuccess && (
                <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>{genSuccess}</span>
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Task Category
                </label>
                <select
                  value={genCategory}
                  onChange={(e) => setGenCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-bold"
                >
                  <option value="facebook">📘 Facebook Social (10 Coins)</option>
                  <option value="youtube">▶️ YouTube Watch</option>
                  <option value="app">📱 App Install Offer</option>
                  <option value="quiz">🧠 Knowledge Quiz</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Reward Coins
                </label>
                <input
                  type="number"
                  min={1}
                  value={genCoins}
                  onChange={(e) => setGenCoins(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-black"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Quantity
                </label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={genCount}
                  onChange={(e) => setGenCount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-black"
                />
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-slate-300">
              <p className="text-[11px]">
                AI will formulate multilingual titles (Bengali & English), professional instructions, verification rules, and publish directly to the live task list.
              </p>
            </div>

            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-600/25 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generate & Publish Tasks Now</span>
            </button>
          </form>
        </div>

        {/* Right Column: AI Economy Balancer & Fraud Sentinel */}
        <div className="lg:col-span-5 space-y-4">
          
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3.5 text-xs">
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              <span>AI Economy Recommendations</span>
            </h3>

            <div className="space-y-2.5">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-white font-bold">
                  <span>Daily Earning (12 Coins)</span>
                  <span className="text-emerald-400 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                    High Retention
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  12 coins baseline maintains steady 84% 7-day retention without causing treasury depletion.
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-white font-bold">
                  <span>Facebook Tasks (10 Coins)</span>
                  <span className="text-blue-400 text-[10px] px-1.5 py-0.5 rounded-full bg-blue-500/20 border border-blue-500/30">
                    Viral Conversion
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Like, Comment and Share tasks generate 4.8x more social referral loops than static banners.
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-white font-bold">
                  <span>Play Seen Ad Monetization</span>
                  <span className="text-amber-400 text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/30">
                    +62% Admin Margin
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Ad impressions generated from YouTube watch sessions fully subsidize coin minting liabilities.
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
