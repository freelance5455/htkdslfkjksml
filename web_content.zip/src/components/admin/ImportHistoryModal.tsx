import React, { useEffect, useState } from 'react';
import { History, X, Download, FileText, CheckCircle2, AlertTriangle, XCircle, Clock } from 'lucide-react';
import { collection, query, where, getDocs, limit, orderBy } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { ImportHistoryRecord } from '../../types/index.ts';
import { exportToCsv } from '../../utils/csvHelper.ts';

interface ImportHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ImportHistoryModal: React.FC<ImportHistoryModalProps> = ({ isOpen, onClose }) => {
  const { currentOrg } = useAuth();
  const [history, setHistory] = useState<ImportHistoryRecord[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isOpen || !currentOrg) return;

    const fetchHistory = async () => {
      setLoading(true);
      try {
        const q = query(
          collection(db, 'import_history'),
          where('orgId', '==', currentOrg.id),
          limit(50)
        );
        const snap = await getDocs(q);
        const list: ImportHistoryRecord[] = [];
        snap.forEach((d) => list.push(d.data() as ImportHistoryRecord));
        list.sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt));
        setHistory(list);
      } catch (err) {
        console.error('Error fetching import history:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, [isOpen, currentOrg]);

  if (!isOpen) return null;

  const downloadHistorySummary = () => {
    const headers = ['Date', 'FileName', 'Mode', 'TotalRows', 'Created', 'Updated', 'Skipped', 'Errors', 'Status', 'UploadedBy'];
    const rows = history.map((h) => [
      new Date(h.uploadedAt).toLocaleString(),
      h.fileName,
      h.mode,
      String(h.totalRows),
      String(h.createdCount),
      String(h.updatedCount),
      String(h.skippedCount),
      String(h.errorCount),
      h.status,
      h.uploadedBy,
    ]);
    exportToCsv(`${currentOrg?.name || 'fieldflow'}_import_history.csv`, headers, rows);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden animate-in fade-in-0 duration-150 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-sky-600" />
            <div>
              <h3 className="font-bold text-sm text-slate-900">Bulk Import Audit History</h3>
              <p className="text-[11px] text-slate-500">
                Immutable record of all Excel & CSV roster imports for {currentOrg?.name}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={downloadHistorySummary}
                className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 flex items-center gap-1 shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Log</span>
              </button>
            )}
            <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto flex-1">
          {loading ? (
            <div className="py-12 text-center text-xs text-slate-500">Loading import audit history...</div>
          ) : history.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No previous import runs recorded. Imports can be run repeatedly without limits.
            </div>
          ) : (
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="p-3">Import Date</th>
                    <th className="p-3">File Name</th>
                    <th className="p-3">Mode</th>
                    <th className="p-3">Rows</th>
                    <th className="p-3">Created</th>
                    <th className="p-3">Updated</th>
                    <th className="p-3">Errors</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Uploaded By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {history.map((record) => (
                    <tr key={record.id} className="hover:bg-slate-50/80">
                      <td className="p-3 font-mono text-[11px] text-slate-600">
                        {new Date(record.uploadedAt).toLocaleString()}
                      </td>
                      <td className="p-3 font-semibold text-slate-800">{record.fileName}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 uppercase">
                          {record.mode.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="p-3 font-bold text-slate-700">{record.totalRows}</td>
                      <td className="p-3 text-emerald-700 font-semibold">+{record.createdCount}</td>
                      <td className="p-3 text-sky-700 font-semibold">{record.updatedCount}</td>
                      <td className="p-3 font-semibold">
                        {record.errorCount > 0 ? (
                          <span className="text-rose-600 font-bold">{record.errorCount}</span>
                        ) : (
                          <span className="text-slate-400">0</span>
                        )}
                      </td>
                      <td className="p-3">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                            record.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : record.status === 'completed_with_errors'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {record.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="p-3 text-slate-500 text-[11px]">{record.uploadedBy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
