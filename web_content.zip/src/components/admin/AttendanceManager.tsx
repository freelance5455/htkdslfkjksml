import React, { useEffect, useState } from 'react';
import {
  Clock,
  Calendar,
  CheckCircle2,
  XCircle,
  Download,
  AlertCircle,
  MapPin,
  Check,
  X,
  Filter,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { AttendanceRecord, AuditLogEntry } from '../../types/index.ts';
import { exportToCsv } from '../../utils/csvHelper.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export const AttendanceManager: React.FC = () => {
  const { currentOrg, userProfile } = useAuth();
  const [attendanceList, setAttendanceList] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const fetchAttendance = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'attendance'),
        where('orgId', '==', currentOrg.id),
        where('date', '==', selectedDate)
      );
      const snap = await getDocs(q);
      const list: AttendanceRecord[] = [];
      snap.forEach((d) => list.push(d.data() as AttendanceRecord));
      setAttendanceList(list);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAttendance();
  }, [currentOrg, selectedDate]);

  const handleReviewCorrection = async (record: AttendanceRecord, approved: boolean) => {
    if (!currentOrg || !record.correctionRequest) return;
    const newStatus = approved ? 'approved' : 'rejected';
    const updatedRecord: AttendanceRecord = {
      ...record,
      correctionRequest: {
        ...record.correctionRequest,
        status: newStatus,
        reviewedAt: new Date().toISOString(),
      },
    };

    // If approved, update punch in/out
    if (approved && record.correctionRequest.requestedCheckIn) {
      updatedRecord.checkInTime = `${record.date}T${record.correctionRequest.requestedCheckIn}:00.000Z`;
      if (record.correctionRequest.requestedCheckOut) {
        updatedRecord.checkOutTime = `${record.date}T${record.correctionRequest.requestedCheckOut}:00.000Z`;
      }
    }

    try {
      await setDoc(doc(db, 'attendance', record.id), removeUndefinedFields(updatedRecord));

      // Audit Log
      const auditLog: AuditLogEntry = {
        id: `aud_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: `Correction ${newStatus.toUpperCase()}`,
        module: 'Attendance',
        details: `${record.employeeName} attendance correction for ${record.date} was ${newStatus}.`,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setAttendanceList((prev) => prev.map((r) => (r.id === record.id ? updatedRecord : r)));
    } catch (err) {
      console.error('Correction review error:', err);
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'EmployeeName',
      'Date',
      'CheckInTime',
      'CheckOutTime',
      'DurationMinutes',
      'GPSAddress',
      'Status',
    ];
    const rows = attendanceList.map((r) => [
      r.employeeName,
      r.date,
      r.checkInTime ? new Date(r.checkInTime).toLocaleTimeString() : '',
      r.checkOutTime ? new Date(r.checkOutTime).toLocaleTimeString() : '',
      String(r.durationMinutes || 0),
      r.checkInAddress || '',
      r.status,
    ]);
    exportToCsv(`${currentOrg?.name || 'fieldflow'}_attendance_${selectedDate}.csv`, headers, rows);
  };

  const filtered = attendanceList.filter((r) => {
    if (statusFilter === 'all') return true;
    if (statusFilter === 'present') return !r.checkOutTime;
    if (statusFilter === 'completed') return !!r.checkOutTime;
    if (statusFilter === 'corrections') return !!r.correctionRequest;
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Clock className="w-5 h-5 text-sky-600" />
            <span>Attendance & Punch Verification</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time GPS timestamps, working durations, and auditable correction approvals
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-700"
          />
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-200"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs flex items-center gap-2 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'all' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          All ({attendanceList.length})
        </button>
        <button
          onClick={() => setStatusFilter('present')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'present' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          Active in Field ({attendanceList.filter((r) => !r.checkOutTime).length})
        </button>
        <button
          onClick={() => setStatusFilter('completed')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'completed' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          Completed Shifts ({attendanceList.filter((r) => !!r.checkOutTime).length})
        </button>
        <button
          onClick={() => setStatusFilter('corrections')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            statusFilter === 'corrections' ? 'bg-amber-50 text-amber-800 font-bold' : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          Correction Requests ({attendanceList.filter((r) => !!r.correctionRequest).length})
        </button>
      </div>

      {/* Attendance Records Table / Mobile Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-500 font-medium">Loading attendance records...</div>
        ) : filtered.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            No attendance punches recorded for {selectedDate}.
          </div>
        ) : (
          <>
            {/* Mobile Cards (Phones < 640px) */}
            <div className="sm:hidden divide-y divide-slate-100">
              {filtered.map((r) => (
                <div key={r.id} className="p-3.5 space-y-2.5 hover:bg-slate-50/60 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-bold text-sm text-slate-900">{r.employeeName}</div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <Calendar className="w-3 h-3" />
                        <span>{r.date}</span>
                      </div>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                        r.checkOutTime
                          ? 'bg-slate-100 text-slate-700'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {r.checkOutTime ? 'Completed Shift' : 'Active in Field'}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2 rounded-xl text-center text-[11px]">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">In</div>
                      <div className="font-bold text-slate-800 mt-0.5">
                        {r.checkInTime ? new Date(r.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--'}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">Out</div>
                      <div className="font-bold text-slate-800 mt-0.5">
                        {r.checkOutTime ? new Date(r.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (
                          <span className="text-emerald-600 font-bold">In Field</span>
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">Hours</div>
                      <div className="font-bold text-slate-800 mt-0.5">
                        {r.durationMinutes ? `${Math.floor(r.durationMinutes / 60)}h ${r.durationMinutes % 60}m` : '--'}
                      </div>
                    </div>
                  </div>

                  {r.checkInAddress && (
                    <div className="text-[11px] text-slate-500 flex items-center gap-1.5 truncate">
                      <MapPin className="w-3.5 h-3.5 text-sky-500 shrink-0" />
                      <span className="truncate">{r.checkInAddress}</span>
                    </div>
                  )}

                  {r.correctionRequest && (
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-1.5">
                      <div className="flex items-center justify-between font-bold">
                        <span>Correction Request</span>
                        <span className="capitalize text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-900">
                          {r.correctionRequest.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-amber-800">{r.correctionRequest.reason}</p>
                      {r.correctionRequest.status === 'pending' && (
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => handleReviewCorrection(r, true)}
                            className="flex-1 py-1.5 bg-emerald-600 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => handleReviewCorrection(r, false)}
                            className="flex-1 py-1.5 bg-rose-600 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Desktop Table (Tablet / Desktop >= 640px) */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="p-3.5">Technician</th>
                    <th className="p-3.5">Check In Time</th>
                    <th className="p-3.5">Check Out Time</th>
                    <th className="p-3.5">Hours Worked</th>
                    <th className="p-3.5">GPS Verification</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Correction</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900">{r.employeeName}</div>
                        <div className="text-[11px] text-slate-400">{r.date}</div>
                      </td>
                      <td className="p-3.5 font-bold text-slate-800">
                        {r.checkInTime ? new Date(r.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--'}
                      </td>
                      <td className="p-3.5 font-bold text-slate-800">
                        {r.checkOutTime ? new Date(r.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (
                          <span className="text-emerald-600 font-bold animate-pulse">In Field</span>
                        )}
                      </td>
                      <td className="p-3.5 font-semibold text-slate-700">
                        {r.durationMinutes ? `${Math.floor(r.durationMinutes / 60)}h ${r.durationMinutes % 60}m` : '--'}
                      </td>
                      <td className="p-3.5 text-slate-600">
                        <div className="flex items-center gap-1 text-[11px]">
                          <MapPin className="w-3 h-3 text-sky-500 shrink-0" />
                          <span className="truncate max-w-[200px]">{r.checkInAddress || 'Coordinates logged'}</span>
                        </div>
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                            r.status === 'completed'
                              ? 'bg-slate-100 text-slate-700'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {r.checkOutTime ? 'Completed' : 'Working'}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        {r.correctionRequest && r.correctionRequest.status === 'pending' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleReviewCorrection(r, true)}
                              className="p-1 rounded bg-emerald-600 text-white hover:bg-emerald-700"
                              title="Approve Correction"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleReviewCorrection(r, false)}
                              className="p-1 rounded bg-rose-600 text-white hover:bg-rose-700"
                              title="Reject Correction"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : r.correctionRequest ? (
                          <span className="text-[10px] text-slate-500 capitalize font-medium">
                            {r.correctionRequest.status}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-300">--</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
