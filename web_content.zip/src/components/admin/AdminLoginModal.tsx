import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  Key, 
  Eye, 
  EyeOff, 
  X, 
  ArrowLeft, 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle, 
  ExternalLink,
  RefreshCw,
  Sparkles,
  Server
} from 'lucide-react';

interface AdminLoginModalProps {
  language: string;
  onClose: () => void;
  onSuccess: (token: string, user: { id: string; email: string; name: string; role: 'admin' }) => void;
}

type LoginStep = 'login' | 'forgot' | 'reset' | 'firebase_guide';

export default function AdminLoginModal({
  language,
  onClose,
  onSuccess
}: AdminLoginModalProps) {
  const [step, setStep] = useState<LoginStep>('login');
  
  // Login Form
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  // Forgot Password Form
  const [forgotEmail, setForgotEmail] = useState<string>('');
  const [forgotLoading, setForgotLoading] = useState<boolean>(false);
  const [forgotMessage, setForgotMessage] = useState<string>('');
  const [generatedResetToken, setGeneratedResetToken] = useState<string>('');

  // Reset Password Form
  const [resetToken, setResetToken] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showNewPassword, setShowNewPassword] = useState<boolean>(false);
  const [resetLoading, setResetLoading] = useState<boolean>(false);
  const [resetSuccess, setResetSuccess] = useState<string>('');

  // Fetch configured admin email placeholder on load
  useEffect(() => {
    fetch('/api/admin/config-info')
      .then(res => res.json())
      .then(data => {
        if (data.config?.email && !email) {
          setEmail(data.config.email);
          setForgotEmail(data.config.email);
        }
      })
      .catch(() => {});
  }, []);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const cleanEmail = email.trim();
    const cleanPassword = password.trim();

    if (!cleanEmail || !cleanPassword) {
      setError(language === 'bn' ? 'অ্যাডমিন ইমেইল ও পাসওয়ার্ড উভয়ই প্রদান করুন।' : 'Please enter both Admin Email and Password.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, password: cleanPassword })
      });

      const data = await res.json();
      if (res.ok && data.success && data.token && data.user?.role === 'admin') {
        onSuccess(data.token, data.user);
      } else {
        setError(data.error || (language === 'bn' ? 'অ্যাক্সেস ডিনায়েড: ভুল ইমেইল বা পাসওয়ার্ড।' : 'Access Denied: Invalid administrator credentials.'));
      }
    } catch (err) {
      setError(language === 'bn' ? 'সার্ভার সংযোগে ত্রুটি। পুনরায় চেষ্টা করুন।' : 'Network connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setForgotMessage('');
    
    if (!forgotEmail.trim()) {
      setError(language === 'bn' ? 'অনুগ্রহ করে নিবন্ধিত অ্যাডমিন ইমেইলটি দিন।' : 'Please provide your registered Admin email.');
      return;
    }

    setForgotLoading(true);
    try {
      const res = await fetch('/api/admin/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail.trim() })
      });

      const data = await res.json();
      if (data.success) {
        setForgotMessage(data.message);
        if (data.resetToken) {
          setGeneratedResetToken(data.resetToken);
          setResetToken(data.resetToken);
        }
      } else {
        setError(data.message || 'Failed to process password reset.');
      }
    } catch (err) {
      setError('Connection error. Please try again.');
    } finally {
      setForgotLoading(false);
    }
  };

  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResetSuccess('');

    if (!resetToken.trim()) {
      setError('Security Reset Token is required.');
      return;
    }

    if (newPassword.length < 8) {
      setError(language === 'bn' ? 'নতুন পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।' : 'New password must be at least 8 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError(language === 'bn' ? 'পাসওয়ার্ড দুটি মেলেনি!' : 'Passwords do not match.');
      return;
    }

    setResetLoading(true);
    try {
      const res = await fetch('/api/admin/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: resetToken.trim(), newPassword })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setResetSuccess(data.message);
        setPassword('');
        setTimeout(() => {
          setStep('login');
          setResetSuccess('');
        }, 2000);
      } else {
        setError(data.message || 'Failed to reset password.');
      }
    } catch (err) {
      setError('Connection error. Please try again.');
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-md p-6 sm:p-8 space-y-6 shadow-2xl animate-in fade-in zoom-in-95 relative overflow-hidden">
        
        {/* Top Decorative Glow */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-indigo-500 to-purple-500" />

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-2xl shadow-sm">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-black text-white tracking-tight">
                {step === 'login' && (language === 'bn' ? 'অ্যাডমিন লগইন' : 'Admin Login')}
                {step === 'forgot' && (language === 'bn' ? 'পাসওয়ার্ড রিসেট' : 'Forgot Password')}
                {step === 'reset' && (language === 'bn' ? 'নতুন পাসওয়ার্ড সেট' : 'Set New Password')}
                {step === 'firebase_guide' && (language === 'bn' ? 'ফায়ারবেস অথ গাইড' : 'Firebase Auth Setup')}
              </h3>
              <p className="text-xs text-slate-400 font-medium">
                {step === 'login' && (language === 'bn' ? 'অনুমোদিত সিকিউর কনসোল' : 'Authorized Administrator Access')}
                {step === 'forgot' && (language === 'bn' ? 'নিবন্ধিত অ্যাডমিন ইমেইল যাচাই' : 'Secure Email Verification')}
                {step === 'reset' && (language === 'bn' ? 'নতুন সিকিউর পাসওয়ার্ড তৈরি' : 'Create Strong Password')}
                {step === 'firebase_guide' && (language === 'bn' ? 'ক্লাউড ও আরবিক রোল আর্কিটেকচার' : 'Authentication & Role Claims')}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Global Error Banner */}
        {error && (
          <div className="p-3.5 bg-rose-950/70 border border-rose-600/60 rounded-2xl text-rose-300 text-xs font-semibold flex items-start gap-2.5 shadow-sm">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 1: DEDICATED ADMIN LOGIN FORM */}
        {/* ------------------------------------------------------------- */}
        {step === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            
            {/* Field 1: Admin Email */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>{language === 'bn' ? 'অ্যাডমিন ইমেইল (Admin Email)' : 'Admin Email'}</span>
                <span className="text-[10px] text-slate-500 font-normal">Registered Account</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. admin@studyskill.ai"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>
            </div>

            {/* Field 2: Admin Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'অ্যাডমিন পাসওয়ার্ড (Admin Password)' : 'Admin Password'}
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setError('');
                    setStep('forgot');
                  }}
                  className="text-[11px] text-amber-400 hover:text-amber-300 font-semibold cursor-pointer transition-colors"
                >
                  {language === 'bn' ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}
                </button>
              </div>
              <div className="relative">
                <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-10 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Login Button */}
            <button
              type="submit"
              disabled={loading || !email.trim() || !password.trim()}
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center justify-center gap-2 mt-2"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{language === 'bn' ? 'যাচাই করা হচ্ছে...' : 'Verifying Role & Credentials...'}</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>{language === 'bn' ? 'লগইন ও অ্যাডমিন প্যানেল খুলুন' : 'Login to Admin Panel'}</span>
                </>
              )}
            </button>

            {/* Firebase Auth & Owner Setup Helper Link */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-800/80 text-[11px] text-slate-400">
              <span>{language === 'bn' ? 'প্রজেক্ট ওনার সেটআপ নির্দেশিকা:' : 'Project Owner Setup:'}</span>
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setStep('firebase_guide');
                }}
                className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer flex items-center gap-1 transition-colors"
              >
                <Server className="w-3 h-3" />
                <span>{language === 'bn' ? 'ফায়ারবেস কনফিগারেশন' : 'Firebase Setup Guide'}</span>
              </button>
            </div>

          </form>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 2: FORGOT PASSWORD FORM */}
        {/* ------------------------------------------------------------- */}
        {step === 'forgot' && (
          <form onSubmit={handleForgotSubmit} className="space-y-4">
            <p className="text-xs text-slate-400 leading-relaxed">
              {language === 'bn'
                ? 'আপনার অনুমোদিত অ্যাডমিন ইমেইলটি প্রদান করুন। সার্ভার একটি ওয়ান-টাইম সিকিউরিটি রিসেট কোড তৈরি করবে।'
                : 'Enter your registered Admin email. A secure one-time password reset token will be generated.'}
            </p>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">
                {language === 'bn' ? 'অ্যাডমিন ইমেইল' : 'Admin Email'}
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  autoFocus
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="admin@studyskill.ai"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {forgotMessage && (
              <div className="p-3.5 bg-emerald-950/60 border border-emerald-500/50 rounded-2xl text-emerald-300 text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{forgotMessage}</span>
                </div>
                {generatedResetToken && (
                  <div className="pt-2 border-t border-emerald-800/40 text-[11px] space-y-1">
                    <p className="text-slate-300 font-medium">Security Reset Token (1-hour validity):</p>
                    <div className="p-2 bg-slate-950 rounded-lg text-amber-300 font-mono text-[10px] break-all border border-slate-800">
                      {generatedResetToken}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setStep('login');
                }}
                className="w-1/2 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer transition-colors flex items-center justify-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'ফিরে যান' : 'Back to Login'}</span>
              </button>

              {generatedResetToken ? (
                <button
                  type="button"
                  onClick={() => {
                    setError('');
                    setStep('reset');
                  }}
                  className="w-1/2 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center justify-center gap-1.5"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'পাসওয়ার্ড রিসেট করুন' : 'Reset Password'}</span>
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={forgotLoading || !forgotEmail.trim()}
                  className="w-1/2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center justify-center gap-1.5"
                >
                  {forgotLoading ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <span>{language === 'bn' ? 'যাচাই কোড পাঠান' : 'Send Reset Code'}</span>
                  )}
                </button>
              )}
            </div>

          </form>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 3: SET NEW PASSWORD FORM */}
        {/* ------------------------------------------------------------- */}
        {step === 'reset' && (
          <form onSubmit={handleResetSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">
                Security Reset Token
              </label>
              <input
                type="text"
                required
                value={resetToken}
                onChange={(e) => setResetToken(e.target.value)}
                placeholder="Paste your 32-byte reset token"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">
                {language === 'bn' ? 'নতুন পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর)' : 'New Password (min 8 chars)'}
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-4 pr-10 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">
                {language === 'bn' ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm New Password'}
              </label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            {resetSuccess && (
              <div className="p-3.5 bg-emerald-950/70 border border-emerald-500/50 rounded-2xl text-emerald-300 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{resetSuccess}</span>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep('forgot')}
                className="w-1/2 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
              >
                Back
              </button>

              <button
                type="submit"
                disabled={resetLoading || !newPassword.trim() || !confirmPassword.trim()}
                className="w-1/2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-lg cursor-pointer transition-all flex items-center justify-center gap-1.5"
              >
                {resetLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <span>Update Password</span>}
              </button>
            </div>
          </form>
        )}

        {/* ------------------------------------------------------------- */}
        {/* VIEW 4: FIREBASE AUTH & SECURITY GUIDE FOR PROJECT OWNER */}
        {/* ------------------------------------------------------------- */}
        {step === 'firebase_guide' && (
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-slate-950/80 border border-indigo-900/60 rounded-2xl space-y-3">
              <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                <Sparkles className="w-4 h-4" />
                <span>Firebase Authentication & Admin Setup</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                To manage authentication via <strong>Firebase Authentication</strong> or your configured backend:
              </p>

              <ol className="list-decimal pl-4 space-y-1.5 text-slate-400 text-[11px]">
                <li>
                  <strong className="text-slate-200">Firebase Console:</strong> Open <em>Build &gt; Authentication &gt; Sign-in method</em> and enable <strong>Email/Password</strong>.
                </li>
                <li>
                  <strong className="text-slate-200">Create Admin Account:</strong> In the <em>Users</em> tab, register your Admin email (e.g. <code className="text-amber-300">sudipdas22061999@gmail.com</code>).
                </li>
                <li>
                  <strong className="text-slate-200">Admin Role Claim:</strong> Set custom claim <code className="text-amber-300">{`{ "role": "admin" }`}</code> or maintain in the server database.
                </li>
                <li>
                  <strong className="text-slate-200">Zero Hard-coding:</strong> Passwords are never hard-coded in frontend source or plain-text DB. Cryptographic salted scrypt hashing is enforced server-side.
                </li>
              </ol>
            </div>

            <button
              type="button"
              onClick={() => setStep('login')}
              className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl cursor-pointer transition-colors flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Admin Login</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
