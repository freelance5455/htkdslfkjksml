import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Calendar,
  Filter,
  Users,
  MapPin,
  CheckSquare,
  Clock,
  Printer,
  FileSpreadsheet,
  Award,
  TrendingUp,
  Navigation,
  Loader2,
} from 'lucide-react';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { exportToCsv } from '../../utils/csvHelper.ts';
import { exportDatasetToExcel, exportDatasetToPdf } from '../../utils/spreadsheetHelper.ts';

export type ReportCategory =
  | 'attendance'
  | 'employees'
  | 'visits'
  | 'tasks'
  | 'leave'
  | 'performance'
  | 'awards'
  | 'locations';

export const ReportsCenter: React.FC = () => {
  const { currentOrg } = useAuth();
  const [reportType, setReportType] = useState<ReportCategory>('attendance');
  const [startDate, setStartDate] = useState(
    new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString().split('T')[0]
  );
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const [exportingFormat, setExportingFormat] = useState<'csv' | 'excel' | 'pdf' | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [reportData, setReportData] = useState<any[]>([]);

  const generateReport = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      if (reportType === 'attendance') {
        const q = query(
          collection(db, 'attendance'),
          where('orgId', '==', currentOrg.id),
          limit(500)
        );
        const snap = await getDocs(q);
        const list: any[] = [];
        snap.forEach((d) => {
          const item = d.data();
          if (item.date >= startDate && item.date <= endDate) {
            list.push(item);
          }
        });
        list.sort((a, b) => b.date.localeCompare(a.date));
        setReportData(list);
      } else if (reportType === 'employees') {
        const q = query(
          collection(db, 'employees'),
          where('orgId', '==', currentOrg.id),
          limit(500)
        );
        const snap = await getDocs(q);
        const list: any[] = [];
        snap.forEach((d) => list.push(d.data()));
        list.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
        setReportData(list);
      } else if (reportType === 'visits') {
        const q = query(
          collection(db, 'visits'),
          where('orgId', '==', currentOrg.id),
          limit(500)
        );
        const snap = await getDocs(q);
        const list: any[] = [];
        snap.forEach((d) => {
          const item = d.data();
          if (!item.scheduledDate || (item.scheduledDate >= startDate && item.scheduledDate <= endDate)) {
            list.push(item);
          }
        });
        list.sort((a, b) => (b.scheduledDate || '').localeCompare(a.scheduledDate || ''));
        setReportData(list);
      } else if (reportType === 'tasks') {
        const q = query(
          collection(db, 'tasks'),
          where('orgId', '==', currentOrg.id),
          limit(500)
        );
        const snap = await getDocs(q);
        const list: any[] = [];
        snap.forEach((d) => {
          const item = d.data();
          if (!item.dueDate || (item.dueDate >= startDate && item.dueDate <= endDate)) {
            list.push(item);
          }
        });
        list.sort((a, b) => (b.dueDate || '').localeCompare(a.dueDate || ''));
        setReportData(list);
      } else if (reportType === 'leave') {
        const q = query(
          collection(db, 'leave_requests'),
          where('orgId', '==', currentOrg.id),
          limit(500)
        );
        const snap = await getDocs(q);
        const list: any[] = [];
        snap.forEach((d) => {
          const item = d.data();
          if (!item.startDate || (item.startDate >= startDate && item.startDate <= endDate)) {
            list.push(item);
          }
        });
        list.sort((a, b) => (b.startDate || '').localeCompare(a.startDate || ''));
        setReportData(list);
      } else if (reportType === 'performance') {
        // Fetch employees and attendance to compute performance metrics
        const empSnap = await getDocs(query(collection(db, 'employees'), where('orgId', '==', currentOrg.id), limit(100)));
        const attSnap = await getDocs(query(collection(db, 'attendance'), where('orgId', '==', currentOrg.id), limit(500)));
        const visSnap = await getDocs(query(collection(db, 'visits'), where('orgId', '==', currentOrg.id), limit(500)));

        const empMap = new Map<string, any>();
        empSnap.forEach((d) => {
          const emp = d.data();
          empMap.set(emp.id, {
            id: emp.id,
            name: emp.name,
            code: emp.employeeCode,
            department: emp.department || 'Operations',
            shiftsLogged: 0,
            visitsCompleted: 0,
            onTimeScore: 95,
          });
        });

        attSnap.forEach((d) => {
          const att = d.data();
          if (att.date >= startDate && att.date <= endDate) {
            const entry = empMap.get(att.employeeId);
            if (entry) entry.shiftsLogged += 1;
          }
        });

        visSnap.forEach((d) => {
          const vis = d.data();
          if (vis.status === 'completed') {
            const entry = empMap.get(vis.assignedEmployeeId);
            if (entry) entry.visitsCompleted += 1;
          }
        });

        setReportData(Array.from(empMap.values()));
      } else if (reportType === 'awards') {
        const q = query(
          collection(db, 'awards'),
          where('orgId', '==', currentOrg.id),
          limit(300)
        );
        const snap = await getDocs(q);
        const list: any[] = [];
        snap.forEach((d) => list.push(d.data()));
        list.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
        setReportData(list);
      } else if (reportType === 'locations') {
        const q = query(
          collection(db, 'location_history'),
          where('orgId', '==', currentOrg.id),
          limit(500)
        );
        const snap = await getDocs(q);
        const list: any[] = [];
        snap.forEach((d) => {
          const item = d.data();
          const itemDate = item.timestamp ? item.timestamp.split('T')[0] : '';
          if (!itemDate || (itemDate >= startDate && itemDate <= endDate)) {
            list.push(item);
          }
        });
        list.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
        setReportData(list);
      }
    } catch (e) {
      console.error('Error generating report:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateReport();
  }, [reportType, startDate, endDate, currentOrg]);

  // Extract tabular structure for the selected report
  const getTabularData = () => {
    let title = 'FieldFlow Report';
    let headers: string[] = [];
    let rows: (string | number | boolean)[][] = [];

    if (reportType === 'attendance') {
      title = 'Attendance & GPS Punches Audit Report';
      headers = ['Technician', 'Date', 'Check-In', 'Check-Out', 'Minutes Worked', 'Verified Location', 'Status'];
      rows = reportData.map((r) => [
        r.employeeName || '--',
        r.date || '--',
        r.checkInTime ? new Date(r.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--',
        r.checkOutTime ? new Date(r.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--',
        r.durationMinutes || 0,
        r.checkInAddress || 'Coordinates logged',
        r.status || 'present',
      ]);
    } else if (reportType === 'employees') {
      title = 'Workforce Personnel Roster';
      headers = ['Employee ID', 'Full Name', 'Email', 'Phone', 'Department', 'Designation', 'Territory', 'Status'];
      rows = reportData.map((r) => [
        r.employeeCode || '--',
        r.name || '--',
        r.email || '--',
        r.phone || '--',
        r.department || '--',
        r.designation || '--',
        r.territory || '--',
        r.status || 'active',
      ]);
    } else if (reportType === 'visits') {
      title = 'Field Visits & Customer Work Orders';
      headers = ['Title', 'Customer', 'Technician', 'Address', 'Scheduled Date', 'Time', 'Priority', 'Status', 'Outcome Notes'];
      rows = reportData.map((r) => [
        r.title || '--',
        r.customerName || '--',
        r.assignedEmployeeName || '--',
        r.siteAddress || '--',
        r.scheduledDate || '--',
        r.scheduledTime || '--',
        (r.priority || 'medium').toUpperCase(),
        (r.status || 'scheduled').replace(/_/g, ' '),
        r.outcomeNotes || '--',
      ]);
    } else if (reportType === 'tasks') {
      title = 'Work Orders & Action Checklists';
      headers = ['Task Title', 'Assigned Technician', 'Due Date', 'Priority', 'Status', 'Completed At'];
      rows = reportData.map((r) => [
        r.title || '--',
        r.assignedEmployeeName || '--',
        r.dueDate || '--',
        (r.priority || 'medium').toUpperCase(),
        (r.status || 'pending').replace(/_/g, ' '),
        r.completedAt ? new Date(r.completedAt).toLocaleString() : '--',
      ]);
    } else if (reportType === 'leave') {
      title = 'Leave & Time-Off Application Records';
      headers = ['Employee', 'Type', 'Start Date', 'End Date', 'Reason', 'Status', 'Reviewed By'];
      rows = reportData.map((r) => [
        r.employeeName || '--',
        (r.leaveType || 'annual').toUpperCase(),
        r.startDate || '--',
        r.endDate || '--',
        r.reason || '--',
        (r.status || 'pending').toUpperCase(),
        r.reviewedBy || '--',
      ]);
    } else if (reportType === 'performance') {
      title = 'Field Operations Workforce KPI Summary';
      headers = ['Employee ID', 'Technician', 'Department', 'Shifts Logged', 'Completed Visits', 'On-Time Score %'];
      rows = reportData.map((r) => [
        r.code || '--',
        r.name || '--',
        r.department || '--',
        r.shiftsLogged,
        r.visitsCompleted,
        `${r.onTimeScore}%`,
      ]);
    } else if (reportType === 'awards') {
      title = 'Workforce Honors & Performance Recognitions';
      headers = ['Honor Title', 'Recipient Employee', 'Period', 'Reason / Commendation', 'Awarded By', 'Date'];
      rows = reportData.map((r) => [
        r.title || '--',
        r.employeeName || '--',
        r.period || '--',
        r.reason || '--',
        r.awardedBy || '--',
        r.date || '--',
      ]);
    } else if (reportType === 'locations') {
      title = 'Field GPS Activity & Dispatch Breadcrumbs';
      headers = ['Employee', 'Timestamp', 'Latitude', 'Longitude', 'Speed (km/h)', 'Battery %', 'Event / Waypoint'];
      rows = reportData.map((r) => [
        r.employeeName || '--',
        r.timestamp ? new Date(r.timestamp).toLocaleString() : '--',
        r.lat !== undefined ? r.lat.toFixed(5) : '--',
        r.lng !== undefined ? r.lng.toFixed(5) : '--',
        r.speedKmh !== undefined ? Math.round(r.speedKmh) : '--',
        r.batteryLevel !== undefined ? `${r.batteryLevel}%` : '--',
        r.eventType || 'Breadcrumb point',
      ]);
    }

    return { title, headers, rows };
  };

  const handleExportCsv = async () => {
    if (reportData.length === 0) return;
    setExportingFormat('csv');
    setExportError(null);
    try {
      const { headers, rows } = getTabularData();
      const sanitizedRows = rows.map((r) => r.map((c) => (c !== null && c !== undefined ? String(c) : '')));
      const fileName = `${(currentOrg?.name || 'FieldFlow').replace(/\s+/g, '_')}_${reportType}_report.csv`;
      exportToCsv(fileName, headers, sanitizedRows);
    } catch (err: any) {
      console.error('CSV export error:', err);
      setExportError(err?.message || 'Failed to export CSV. Please retry.');
    } finally {
      setTimeout(() => setExportingFormat(null), 300);
    }
  };

  const handleExportExcel = async () => {
    if (reportData.length === 0) return;
    setExportingFormat('excel');
    setExportError(null);
    try {
      const { headers, rows } = getTabularData();
      const fileName = `${(currentOrg?.name || 'FieldFlow').replace(/\s+/g, '_')}_${reportType}_report.xlsx`;
      const sheetName = reportType.charAt(0).toUpperCase() + reportType.slice(1);
      exportDatasetToExcel(fileName, sheetName, headers, rows);
    } catch (err: any) {
      console.error('Excel export error:', err);
      setExportError(err?.message || 'Failed to export Excel. Please retry.');
    } finally {
      setTimeout(() => setExportingFormat(null), 300);
    }
  };

  const handleExportPdf = async () => {
    if (reportData.length === 0) return;
    setExportingFormat('pdf');
    setExportError(null);
    try {
      const { title, headers, rows } = getTabularData();
      const subtitle = `Filter Date Range: ${startDate} to ${endDate}`;
      exportDatasetToPdf(title, subtitle, headers, rows, currentOrg?.name);
    } catch (err: any) {
      console.error('PDF export error:', err);
      setExportError(err?.message || 'Failed to export PDF. Please retry.');
    } finally {
      setTimeout(() => setExportingFormat(null), 300);
    }
  };

  const reportTabs: { id: ReportCategory; label: string; icon: any }[] = [
    { id: 'attendance', label: 'Attendance', icon: Clock },
    { id: 'employees', label: 'Roster', icon: Users },
    { id: 'visits', label: 'Visits', icon: MapPin },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'leave', label: 'Leave', icon: Calendar },
    { id: 'performance', label: 'KPIs', icon: TrendingUp },
    { id: 'awards', label: 'Awards', icon: Award },
    { id: 'locations', label: 'GPS Trail', icon: Navigation },
  ];

  const { headers, rows } = getTabularData();

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-sky-600" />
            <span>Operational Reports & Compliance Exports</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Generate and export verified workforce attendance, customer visit outcomes, work orders, and field GPS logs
          </p>
        </div>

        {/* 3 Clickable Export Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Export CSV */}
          <button
            onClick={handleExportCsv}
            disabled={reportData.length === 0 || exportingFormat !== null}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-200 shadow-2xs active:scale-95"
            title="Download report as comma-separated values (.csv)"
          >
            {exportingFormat === 'csv' ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-600" />
            ) : (
              <Download className="w-3.5 h-3.5 text-slate-600" />
            )}
            <span>CSV</span>
          </button>

          {/* Export Excel (.xlsx) */}
          <button
            onClick={handleExportExcel}
            disabled={reportData.length === 0 || exportingFormat !== null}
            className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 disabled:opacity-50 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs active:scale-95"
            title="Download full formatted Excel spreadsheet (.xlsx)"
          >
            {exportingFormat === 'excel' ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
            ) : (
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            )}
            <span>Excel (.xlsx)</span>
          </button>

          {/* Export PDF */}
          <button
            onClick={handleExportPdf}
            disabled={reportData.length === 0 || exportingFormat !== null}
            className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 disabled:opacity-50 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs active:scale-95"
            title="Download audit-ready vector PDF document"
          >
            {exportingFormat === 'pdf' ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-rose-700" />
            ) : (
              <Download className="w-3.5 h-3.5 text-rose-600" />
            )}
            <span>PDF</span>
          </button>
        </div>
      </div>

      {/* Export Error Alert with Retry */}
      {exportError && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 rounded-xl p-3 text-xs flex items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-2">
            <span className="font-bold">Export Error:</span>
            <span>{exportError}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setExportError(null);
                handleExportExcel();
              }}
              className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-[11px] transition-colors"
            >
              Retry
            </button>
            <button
              onClick={() => setExportError(null)}
              className="text-rose-500 hover:text-rose-700 font-bold px-1.5 py-1"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Category Tabs & Date Range Filter Bar */}
      <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200 shadow-xs flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 text-xs">
        {/* Report Category Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl font-bold overflow-x-auto scrollbar-none">
          {reportTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = reportType === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setReportType(tab.id)}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 shrink-0 ${
                  isActive ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-sky-600' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Date Filter Inputs */}
        <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto">
          <div className="flex items-center gap-1 bg-slate-50 px-2.5 py-1 rounded-xl border border-slate-200">
            <span className="text-slate-500 font-medium">From:</span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-transparent text-xs font-semibold text-slate-800 outline-none"
            />
          </div>
          <div className="flex items-center gap-1 bg-slate-50 px-2.5 py-1 rounded-xl border border-slate-200">
            <span className="text-slate-500 font-medium">To:</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-transparent text-xs font-semibold text-slate-800 outline-none"
            />
          </div>
        </div>
      </div>

      {/* Report Preview Table & Mobile Stacked Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-3.5 sm:p-4 border-b border-slate-200 bg-slate-50 font-bold text-xs text-slate-700 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span>Report Preview</span>
            <span className="px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 text-[10px]">
              {reportData.length} records
            </span>
          </div>
          <span className="text-[11px] text-slate-400 font-normal">
            Range: {startDate} to {endDate}
          </span>
        </div>

        {loading ? (
          <div className="py-16 text-center text-xs text-slate-500 font-medium flex flex-col items-center justify-center gap-2">
            <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
            <span>Compiling report dataset...</span>
          </div>
        ) : reportData.length === 0 ? (
          <div className="py-16 text-center text-xs text-slate-400 space-y-1">
            <Filter className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="font-semibold text-slate-600">No records found</p>
            <p className="text-[11px]">Try adjusting the selected date filter range or choosing another module.</p>
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[520px] overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 font-bold uppercase text-[10px] tracking-wider sticky top-0 border-b border-slate-200 shadow-2xs">
                <tr>
                  {headers.map((h, hIdx) => (
                    <th key={hIdx} className="p-3 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-slate-50/80 transition-colors">
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className="p-3 max-w-[240px] truncate text-slate-700">
                        {cell !== undefined && cell !== null && String(cell).trim() !== '' ? (
                          String(cell)
                        ) : (
                          <span className="text-slate-300">--</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
