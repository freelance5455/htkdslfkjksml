import React, { useState } from 'react';
import {
  Search,
  UserPlus,
  Pencil,
  Trash2,
  X,
  Check,
  Loader2,
  MapPin,
  Phone,
  Mail,
  ShoppingBag,
  AlertCircle,
} from 'lucide-react';
import {
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useStoreData } from '../../context/StoreDataContext';
import { Order, OrderStatus, UserProfile } from '../../types/store';
import { formatCurrency, formatDate, formatDateTime, slugify } from '../../lib/formatters';

interface AdminCustomerManagerProps {
  customers: UserProfile[];
  orders: Order[];
}

const ORDER_STATUSES: OrderStatus[] = [
  'Pending',
  'Confirmed',
  'Processing',
  'Shipped',
  'Delivered',
  'Cancelled',
];

export function AdminCustomerManager({ customers, orders }: AdminCustomerManagerProps) {
  const { notify } = useStoreData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<UserProfile | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Form states for Add / Edit Customer
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const openAddCustomer = () => {
    setSelectedCustomer(null);
    setDisplayName('');
    setEmail('');
    setPhone('');
    setLocation('');
    setAddress('');
    setCity('');
    setPinCode('');
    setFormError('');
    setIsAddOpen(true);
  };

  const openManageCustomer = (customer: UserProfile) => {
    setIsAddOpen(false);
    setSelectedCustomer(customer);
    setDisplayName(customer.displayName || '');
    setEmail(customer.email || '');
    setPhone(customer.phone || '');
    setLocation(customer.location || '');
    setAddress(customer.address || '');
    setCity(customer.city || '');
    setPinCode(customer.pinCode || '');
    setFormError('');
  };

  const closeModals = () => {
    setIsAddOpen(false);
    setSelectedCustomer(null);
    setFormError('');
  };

  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const cleanName = displayName.trim();
    const cleanEmail = email.trim();
    if (cleanName.length < 1) return setFormError('Customer name is required.');
    if (!cleanEmail.includes('@') || cleanEmail.length < 3) {
      return setFormError('Please enter a valid email address.');
    }

    setSaving(true);
    try {
      if (selectedCustomer) {
        await updateDoc(doc(db, 'users', selectedCustomer.uid), {
          displayName: cleanName.slice(0, 100),
          phone: phone.trim().slice(0, 20),
          location: location.trim().slice(0, 160),
          address: address.trim().slice(0, 300),
          city: city.trim().slice(0, 80),
          pinCode: pinCode.trim().slice(0, 12),
          updatedAt: serverTimestamp(),
        });
        notify(`Customer "${cleanName}" updated.`, 'success');
        setSelectedCustomer({
          ...selectedCustomer,
          displayName: cleanName,
          phone: phone.trim(),
          location: location.trim(),
          address: address.trim(),
          city: city.trim(),
          pinCode: pinCode.trim(),
        });
      } else {
        const uid = `cust-${slugify(cleanName).slice(0, 24)}-${Date.now().toString(36)}`;
        await setDoc(doc(db, 'users', uid), {
          uid,
          displayName: cleanName.slice(0, 100),
          email: cleanEmail.slice(0, 150),
          phone: phone.trim().slice(0, 20),
          location: location.trim().slice(0, 160),
          address: address.trim().slice(0, 300),
          city: city.trim().slice(0, 80),
          pinCode: pinCode.trim().slice(0, 12),
          role: 'customer',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        notify(`Customer "${cleanName}" added to directory.`, 'success');
        closeModals();
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'users');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteCustomer = async (uid: string) => {
    try {
      await deleteDoc(doc(db, 'users', uid));
      setConfirmDeleteId(null);
      if (selectedCustomer?.uid === uid) {
        setSelectedCustomer(null);
      }
      notify('Customer record deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${uid}`);
    }
  };

  const handleOrderStatusUpdate = async (order: Order, nextStatus: OrderStatus) => {
    try {
      await updateDoc(doc(db, 'orders', order.id), {
        status: nextStatus,
        paymentStatus: nextStatus === 'Delivered' ? 'Paid' : order.paymentStatus,
        updatedAt: serverTimestamp(),
      });
      notify(`Order ${order.orderNumber} updated to ${nextStatus}.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${order.id}`);
    }
  };

  const filteredCustomers = customers.filter((c) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      (c.displayName || '').toLowerCase().includes(q) ||
      (c.email || '').toLowerCase().includes(q) ||
      (c.phone || '').toLowerCase().includes(q) ||
      (c.location || '').toLowerCase().includes(q) ||
      (c.city || '').toLowerCase().includes(q) ||
      (c.address || '').toLowerCase().includes(q)
    );
  });

  const selectedCustomerOrders = selectedCustomer
    ? orders.filter((o) => o.userId === selectedCustomer.uid)
    : [];

  return (
    <div className="space-y-6 w-full">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0A0A0A]">
            Manage All Customers ({customers.length})
          </h2>
          <p className="text-xs text-neutral-500 mt-1">
            View, search, add, edit customer profiles, addresses, and manage their complete order history.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search name, email, phone, city..."
              className="w-full pl-10 pr-4 py-2 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
            />
          </div>

          <button
            type="button"
            onClick={openAddCustomer}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer whitespace-nowrap"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add Customer</span>
          </button>
        </div>
      </div>

      {/* Customer Directory Table */}
      <div className="bg-white border border-neutral-200 overflow-x-auto w-full">
        <table className="w-full text-left border-collapse min-w-[880px]">
          <thead>
            <tr className="border-b border-neutral-200 bg-neutral-50 text-[11px] uppercase tracking-wider text-neutral-500">
              <th className="py-3.5 px-4 font-semibold">Customer</th>
              <th className="py-3.5 px-4 font-semibold">Contact</th>
              <th className="py-3.5 px-4 font-semibold">Delivery Address</th>
              <th className="py-3.5 px-4 font-semibold">Orders</th>
              <th className="py-3.5 px-4 font-semibold">Total Spend</th>
              <th className="py-3.5 px-4 font-semibold">Joined</th>
              <th className="py-3.5 px-4 font-semibold text-right">Manage</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 text-xs">
            {filteredCustomers.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-neutral-500">
                  No customers match your search.
                </td>
              </tr>
            ) : (
              filteredCustomers.map((c) => {
                const custOrders = orders.filter((o) => o.userId === c.uid);
                const validOrders = custOrders.filter((o) => o.status !== 'Cancelled');
                const spend = validOrders.reduce((s, o) => s + o.totalAmount, 0);

                return (
                  <tr key={c.uid} className="hover:bg-neutral-50/80">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-[#0A0A0A]">{c.displayName}</div>
                      <div className="text-[11px] text-neutral-500 font-mono truncate max-w-[160px]">
                        {c.uid}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="text-neutral-800">{c.email}</div>
                      <div className="text-neutral-500 mt-0.5">{c.phone || 'No phone'}</div>
                    </td>
                    <td className="py-3.5 px-4 max-w-[260px]">
                      {c.location && (
                        <div className="text-[#0A0A0A] font-medium flex items-center gap-1 mb-0.5">
                          <MapPin className="w-3 h-3 shrink-0" />
                          <span className="truncate">{c.location}</span>
                        </div>
                      )}
                      {c.address || c.city ? (
                        <div className="text-neutral-700 line-clamp-2">
                          {[c.address, c.city, c.pinCode].filter(Boolean).join(', ')}
                        </div>
                      ) : !c.location ? (
                        <span className="text-neutral-400">No address saved</span>
                      ) : null}
                    </td>
                    <td className="py-3.5 px-4 tabular-nums font-medium">
                      {custOrders.length}
                    </td>
                    <td className="py-3.5 px-4 tabular-nums font-semibold">
                      {formatCurrency(spend)}
                    </td>
                    <td className="py-3.5 px-4 text-neutral-500">
                      {formatDate(c.createdAt)}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      {confirmDeleteId === c.uid ? (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleDeleteCustomer(c.uid)}
                            className="px-2.5 py-1 bg-red-600 text-white rounded text-[11px] font-semibold cursor-pointer"
                          >
                            Confirm
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2.5 py-1 border border-neutral-300 rounded text-[11px] cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => openManageCustomer(c)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full border border-neutral-300 text-[11px] font-semibold hover:bg-[#0A0A0A] hover:text-white hover:border-[#0A0A0A] transition-colors cursor-pointer"
                          >
                            <Pencil className="w-3 h-3" />
                            <span>Manage</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(c.uid)}
                            aria-label={`Delete ${c.displayName}`}
                            className="p-1.5 text-neutral-400 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Add / Manage Customer Modal */}
      {(isAddOpen || selectedCustomer) && (
        <div
          className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white w-full max-w-4xl border border-neutral-200 shadow-2xl my-auto max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between sticky top-0 bg-white z-10">
              <div>
                <p className="text-[11px] uppercase tracking-wider text-neutral-500">
                  Customer Management
                </p>
                <h3 className="text-base font-semibold text-[#0A0A0A]">
                  {selectedCustomer ? selectedCustomer.displayName : 'Add New Customer'}
                </h3>
              </div>
              <button
                type="button"
                onClick={closeModals}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2">
              {/* Left: Customer Profile Editor */}
              <form
                onSubmit={handleSaveCustomer}
                className="p-6 space-y-4 border-b lg:border-b-0 lg:border-r border-neutral-200"
              >
                <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-500">
                  Profile & Delivery Details
                </h4>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={100}
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full px-3.5 py-2 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Email Address *
                  </label>
                  <div className="relative">
                    <Mail className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      disabled={Boolean(selectedCustomer)}
                      maxLength={150}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2 text-sm border border-neutral-300 disabled:bg-neutral-100 disabled:text-neutral-500 focus:border-[#0A0A0A] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Mobile Number
                  </label>
                  <div className="relative">
                    <Phone className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      maxLength={20}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Location / Area
                  </label>
                  <div className="relative">
                    <MapPin className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      maxLength={160}
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Assam Badarpur"
                      className="w-full pl-9 pr-3.5 py-2 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-700 mb-1">
                    Full Delivery Address
                  </label>
                  <div className="relative">
                    <MapPin className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
                    <textarea
                      rows={2}
                      maxLength={300}
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none resize-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-neutral-700 mb-1">
                      City
                    </label>
                    <input
                      type="text"
                      maxLength={80}
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-700 mb-1">
                      PIN / Postal Code
                    </label>
                    <input
                      type="text"
                      maxLength={12}
                      value={pinCode}
                      onChange={(e) => setPinCode(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm border border-neutral-300 focus:border-[#0A0A0A] focus:outline-none"
                    />
                  </div>
                </div>

                {formError && (
                  <div className="p-3 border border-red-200 bg-red-50 text-xs text-red-700 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="submit"
                    disabled={saving}
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 disabled:opacity-50 cursor-pointer"
                  >
                    {saving ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Check className="w-3.5 h-3.5" />
                    )}
                    <span>{selectedCustomer ? 'Update Customer' : 'Create Customer'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={closeModals}
                    className="px-5 py-2.5 rounded-full border border-neutral-300 text-xs font-medium hover:bg-neutral-100 cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </form>

              {/* Right: Customer Orders & Activity */}
              <div className="p-6 bg-neutral-50/70 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-500 flex items-center gap-1.5">
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>
                      Customer Orders ({selectedCustomerOrders.length})
                    </span>
                  </h4>
                  {selectedCustomer && (
                    <span className="text-xs font-semibold tabular-nums">
                      Spend:{' '}
                      {formatCurrency(
                        selectedCustomerOrders
                          .filter((o) => o.status !== 'Cancelled')
                          .reduce((s, o) => s + o.totalAmount, 0)
                      )}
                    </span>
                  )}
                </div>

                {!selectedCustomer ? (
                  <div className="p-8 border border-neutral-200 bg-white text-center text-xs text-neutral-500">
                    Orders placed by this customer will appear here automatically.
                  </div>
                ) : selectedCustomerOrders.length === 0 ? (
                  <div className="p-8 border border-neutral-200 bg-white text-center text-xs text-neutral-500">
                    This customer has not placed any orders yet.
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                    {selectedCustomerOrders.map((order) => (
                      <div
                        key={order.id}
                        className="bg-white border border-neutral-200 p-3.5 text-xs space-y-2"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono font-semibold text-[#0A0A0A]">
                            {order.orderNumber}
                          </span>
                          <span className="text-neutral-500">
                            {formatDateTime(order.createdAt)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-3">
                          <span className="truncate font-medium">
                            {order.primaryProductName} ({order.totalQuantity})
                          </span>
                          <span className="font-semibold tabular-nums">
                            {formatCurrency(order.totalAmount)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-2 pt-1 border-t border-neutral-100">
                          <span className="text-neutral-500">{order.paymentMethod}</span>
                          <select
                            aria-label={`Order status for ${order.orderNumber}`}
                            value={order.status}
                            onChange={(e) =>
                              handleOrderStatusUpdate(order, e.target.value as OrderStatus)
                            }
                            className="px-2 py-1 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none cursor-pointer"
                          >
                            {ORDER_STATUSES.map((st) => (
                              <option key={st} value={st}>
                                {st}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
