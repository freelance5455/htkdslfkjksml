import React, { useEffect, useState, useRef, useMemo } from 'react';
import {
  MapPin,
  Navigation,
  Search,
  Filter,
  Users,
  Phone,
  Clock,
  Compass,
  Battery,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Maximize2,
  Calendar,
  Layers,
  Activity,
  X,
} from 'lucide-react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { TechnicianLocation, LocationStatusCategory } from '../../types/index.ts';
import {
  formatRelativeTime,
  getLocationStatusCategory,
} from '../../utils/locationTracker.ts';
import { LocationHistoryModal } from './LocationHistoryModal.tsx';
import { GOOGLE_MAPS_TILE_PROVIDERS, loadGoogleMapsScript } from '../../utils/googleMapsLoader.ts';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export const LiveTechnicianMap: React.FC = () => {
  const { currentOrg } = useAuth();
  const [locations, setLocations] = useState<TechnicianLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'live' | 'recent' | 'offline'>('all');
  const [selectedTech, setSelectedTech] = useState<TechnicianLocation | null>(null);

  // Mobile view mode: 'map' vs 'list'
  const [mobileViewMode, setMobileViewMode] = useState<'map' | 'list'>('map');

  // History Modal
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [historyEmp, setHistoryEmp] = useState<{ id: string; name: string } | null>(null);

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  // 1. Real-time Firestore subscription to technician_locations
  useEffect(() => {
    if (!currentOrg) {
      setLoading(false);
      return;
    }
    setLoading(true);

    const q = query(
      collection(db, 'technician_locations'),
      where('orgId', '==', currentOrg.id)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: TechnicianLocation[] = [];
        snapshot.forEach((doc) => {
          list.push(doc.data() as TechnicianLocation);
        });
        // Sort: Live first, then newest update
        list.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
        setLocations(list);
        setLoading(false);
      },
      (err) => {
        console.error('Error listening to live technician locations:', err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [currentOrg]);

  // Filtered locations
  const filteredLocations = useMemo(() => {
    return locations.filter((loc) => {
      const category = getLocationStatusCategory(loc.updatedAt);
      const matchesStatus = statusFilter === 'all' || category === statusFilter;
      const matchesDept = departmentFilter === 'all' || loc.department === departmentFilter;
      const queryLower = searchTerm.toLowerCase();
      const matchesSearch =
        loc.employeeName.toLowerCase().includes(queryLower) ||
        (loc.employeeCode && loc.employeeCode.toLowerCase().includes(queryLower)) ||
        (loc.currentCustomerName && loc.currentCustomerName.toLowerCase().includes(queryLower));

      return matchesStatus && matchesDept && matchesSearch;
    });
  }, [locations, statusFilter, departmentFilter, searchTerm]);

  const departments = useMemo(() => {
    return Array.from(new Set(locations.map((l) => l.department).filter(Boolean))) as string[];
  }, [locations]);

  // Counts
  const liveCount = locations.filter((l) => getLocationStatusCategory(l.updatedAt) === 'live').length;
  const recentCount = locations.filter((l) => getLocationStatusCategory(l.updatedAt) === 'recent').length;
  const offlineCount = locations.filter((l) => getLocationStatusCategory(l.updatedAt) === 'offline').length;

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [37.7749, -122.4194],
        zoom: 12,
        zoomControl: true,
      });

      // Google Maps Base Tile Layers
      const googleRoadmap = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.roadmap.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.subdomains,
      });

      const googleSatellite = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.satellite.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.satellite.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.satellite.subdomains,
      });

      const googleTerrain = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.terrain.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.terrain.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.terrain.subdomains,
      });

      const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      });

      // Add default Google Maps Roadmap layer
      googleRoadmap.addTo(map);

      // Layer control switcher
      L.control.layers(
        {
          'Google Roadmap': googleRoadmap,
          'Google Satellite': googleSatellite,
          'Google Terrain': googleTerrain,
          'OpenStreetMap': osm,
        },
        undefined,
        { position: 'topright' }
      ).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;

      // Also ensure Google Maps JS SDK is loaded for place queries
      loadGoogleMapsScript().catch(() => {});
    }

    const timer = setTimeout(() => {
      mapInstanceRef.current?.invalidateSize();
    }, 200);

    return () => clearTimeout(timer);
  }, []);

  // Update map markers when filtered locations change
  useEffect(() => {
    if (!mapInstanceRef.current || !markersLayerRef.current) return;

    markersLayerRef.current.clearLayers();
    if (filteredLocations.length === 0) return;

    const latLngs: [number, number][] = [];

    filteredLocations.forEach((loc) => {
      latLngs.push([loc.lat, loc.lng]);
      const category = getLocationStatusCategory(loc.updatedAt);
      const isSelected = selectedTech?.id === loc.id;

      const bgColor =
        category === 'live' ? '#10b981' : category === 'recent' ? '#f59e0b' : '#64748b';
      const pulseClass = category === 'live' ? 'animate-ping opacity-75' : '';

      const initials = loc.employeeName
        .split(' ')
        .map((p) => p[0])
        .join('')
        .slice(0, 2)
        .toUpperCase();

      const customIcon = L.divIcon({
        className: 'custom-live-marker',
        html: `
          <div style="position: relative; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center;">
            ${
              category === 'live'
                ? `<div style="position: absolute; inset: -4px; border-radius: 50%; background-color: #10b981; opacity: 0.35;" class="${pulseClass}"></div>`
                : ''
            }
            <div style="
              width: 32px;
              height: 32px;
              border-radius: 50%;
              background-color: ${bgColor};
              color: white;
              font-weight: 800;
              font-size: 11px;
              display: flex;
              align-items: center;
              justify-content: center;
              border: 2px solid white;
              box-shadow: 0 4px 10px rgba(0,0,0,0.35);
              transform: ${isSelected ? 'scale(1.2)' : 'scale(1)'};
              transition: transform 0.15s ease;
            ">
              ${initials}
            </div>
          </div>
        `,
        iconSize: [34, 34],
        iconAnchor: [17, 17],
      });

      const marker = L.marker([loc.lat, loc.lng], { icon: customIcon });

      const relativeTime = formatRelativeTime(loc.updatedAt);
      marker.bindTooltip(
        `<strong>${loc.employeeName}</strong> (${category.toUpperCase()})<br/>${relativeTime}`,
        { direction: 'top', offset: [0, -12] }
      );

      marker.on('click', () => {
        setSelectedTech(loc);
        mapInstanceRef.current?.setView([loc.lat, loc.lng], 15, { animate: true });
      });

      markersLayerRef.current?.addLayer(marker);
    });

    // Fit bounds on first load or when filters change if markers exist
    if (latLngs.length > 0) {
      const bounds = L.latLngBounds(latLngs);
      mapInstanceRef.current.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
    }
  }, [filteredLocations, selectedTech?.id]);

  // Center on all
  const fitAllBounds = () => {
    if (!mapInstanceRef.current || filteredLocations.length === 0) return;
    const latLngs: [number, number][] = filteredLocations.map((l) => [l.lat, l.lng]);
    const bounds = L.latLngBounds(latLngs);
    mapInstanceRef.current.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
  };

  const handleOpenHistory = (loc: TechnicianLocation) => {
    setHistoryEmp({ id: loc.employeeId, name: loc.employeeName });
    setIsHistoryModalOpen(true);
  };

  return (
    <div className="space-y-3">
      {/* Top Banner & Control Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center">
              <Compass className="w-5 h-5 stroke-[2.2]" />
            </div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2 flex-wrap">
              <span>Live Technician Dispatch Map</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-extrabold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>{liveCount} Live</span>
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-sky-50 text-sky-700 border border-sky-200 font-bold flex items-center gap-1">
                <MapPin className="w-3 h-3 text-sky-600" />
                <span>Google Maps Connected</span>
              </span>
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time GPS coordinates directly reported from authorized technician mobile devices
          </p>
        </div>

        {/* Status Count Badges & Fit Button */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              statusFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All ({locations.length})
          </button>
          <button
            onClick={() => setStatusFilter('live')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 ${
              statusFilter === 'live'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Live ({liveCount})</span>
          </button>
          <button
            onClick={() => setStatusFilter('recent')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 ${
              statusFilter === 'recent'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span>Recent ({recentCount})</span>
          </button>
          <button
            onClick={() => setStatusFilter('offline')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 ${
              statusFilter === 'offline'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>Offline ({offlineCount})</span>
          </button>

          <button
            onClick={fitAllBounds}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-200"
            title="Fit All on Map"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filters & Mobile View Toggle */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search technician, code, or customer..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {departments.length > 0 && (
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 font-medium text-slate-700 focus:outline-none"
            >
              <option value="all">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Mobile View Toggle */}
        <div className="flex sm:hidden p-1 bg-slate-100 rounded-xl text-xs font-bold">
          <button
            onClick={() => setMobileViewMode('map')}
            className={`flex-1 py-1.5 rounded-lg text-center ${
              mobileViewMode === 'map' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Live Map
          </button>
          <button
            onClick={() => setMobileViewMode('list')}
            className={`flex-1 py-1.5 rounded-lg text-center ${
              mobileViewMode === 'list' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            List ({filteredLocations.length})
          </button>
        </div>
      </div>

      {/* Main Map + Technician Sidebar Area */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs flex flex-col md:flex-row h-[580px] relative">
        {/* Real Leaflet Map */}
        <div
          className={`relative flex-1 h-full bg-slate-100 ${
            mobileViewMode === 'list' ? 'hidden sm:block' : 'block'
          }`}
        >
          <div ref={mapContainerRef} className="w-full h-full" />

          {/* Quick overlay disclaimer pill */}
          <div className="absolute bottom-3 left-3 z-[1000] bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-slate-200 text-[10px] font-medium text-slate-600 shadow-sm flex items-center gap-1.5 pointer-events-none">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Factual Device GPS · Updated periodically while technician is on shift</span>
          </div>

          {loading && (
            <div className="absolute inset-0 bg-white/70 backdrop-blur-xs flex items-center justify-center z-[1000]">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-white px-4 py-2 rounded-xl shadow-md border border-slate-200">
                <RefreshCw className="w-4 h-4 animate-spin text-sky-600" />
                <span>Loading active technician coordinates...</span>
              </div>
            </div>
          )}

          {!loading && filteredLocations.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[1000]">
              <div className="bg-white/95 px-5 py-4 rounded-2xl shadow-lg border border-slate-200 text-center space-y-1 max-w-xs">
                <MapPin className="w-6 h-6 text-slate-400 mx-auto" />
                <div className="text-xs font-bold text-slate-800">No matching technicians</div>
                <div className="text-[11px] text-slate-500">
                  Try adjusting your search terms or status filter.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Technician Roster / Selected Detail Sidebar */}
        <div
          className={`w-full md:w-88 border-t md:border-t-0 md:border-l border-slate-200 bg-slate-50 flex flex-col h-full overflow-hidden ${
            mobileViewMode === 'map' ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Header of Sidebar */}
          <div className="p-3 bg-white border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-sky-600" />
              <span>Active Field Crew ({filteredLocations.length})</span>
            </span>
            <span className="text-[10px] text-slate-400">Click to locate</span>
          </div>

          {/* List of Technicians */}
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {filteredLocations.map((loc) => {
              const category = getLocationStatusCategory(loc.updatedAt);
              const isSelected = selectedTech?.id === loc.id;
              const relativeTime = formatRelativeTime(loc.updatedAt);

              return (
                <div
                  key={loc.id}
                  onClick={() => {
                    setSelectedTech(loc);
                    setMobileViewMode('map');
                    mapInstanceRef.current?.setView([loc.lat, loc.lng], 15, { animate: true });
                  }}
                  className={`p-3 rounded-2xl border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-sky-50 border-sky-400 shadow-sm ring-2 ring-sky-200'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-1.5">
                        <span>{loc.employeeName}</span>
                        {loc.employeeCode && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-mono">
                            {loc.employeeCode}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{loc.department || 'Operations'}</div>
                    </div>

                    {/* Status Pill */}
                    <span
                      className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1 uppercase ${
                        category === 'live'
                          ? 'bg-emerald-100 text-emerald-800'
                          : category === 'recent'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          category === 'live'
                            ? 'bg-emerald-500 animate-pulse'
                            : category === 'recent'
                            ? 'bg-amber-500'
                            : 'bg-slate-400'
                        }`}
                      />
                      <span>{category}</span>
                    </span>
                  </div>

                  {/* Current Activity / Visit */}
                  {loc.currentCustomerName && (
                    <div className="mt-2 p-2 rounded-xl bg-slate-50 border border-slate-100 text-[11px] text-slate-700">
                      <span className="font-bold text-slate-900">At Customer: </span>
                      <span>{loc.currentCustomerName}</span>
                    </div>
                  )}

                  {/* Metadata Row */}
                  <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{relativeTime}</span>
                    </span>

                    {loc.batteryLevel !== undefined && (
                      <span className="flex items-center gap-1 font-mono">
                        <Battery className="w-3 h-3 text-slate-400" />
                        <span>{loc.batteryLevel}%</span>
                      </span>
                    )}

                    {loc.accuracy && <span>±{loc.accuracy}m</span>}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Technician Action Drawer in Sidebar */}
          {selectedTech && (
            <div className="p-3 bg-white border-t border-slate-200 space-y-2">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
                Selected Technician
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm text-slate-900">{selectedTech.employeeName}</div>
                  <div className="text-[11px] text-slate-500">
                    {selectedTech.lat.toFixed(5)}, {selectedTech.lng.toFixed(5)}
                  </div>
                </div>
                {selectedTech.phone && (
                  <a
                    href={`tel:${selectedTech.phone}`}
                    className="p-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl border border-emerald-200"
                    title="Call Technician"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                )}
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => handleOpenHistory(selectedTech)}
                  className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>View Route History</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Route History Modal */}
      {isHistoryModalOpen && historyEmp && (
        <LocationHistoryModal
          isOpen={isHistoryModalOpen}
          onClose={() => setIsHistoryModalOpen(false)}
          employeeId={historyEmp.id}
          employeeName={historyEmp.name}
        />
      )}
    </div>
  );
};
