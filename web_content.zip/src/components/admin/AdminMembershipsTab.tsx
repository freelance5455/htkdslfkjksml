import React from 'react';
import { Sparkles, Users, Award, Zap, ShieldCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminMembershipsTab: React.FC = () => {
  const { membershipPlans, allUsers, updateUserTierAdmin, t } = useApp();

  const basicUsers = allUsers.filter(u => u.membershipTier === 'basic');
  const premiumUsers = allUsers.filter(u => u.membershipTier === 'premium');
  const proUsers = allUsers.filter(u => u.membershipTier === 'pro');

  return (
    <div className="space-y-6">
      
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('membershipManagement')}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Monitor membership tiers, benefits, and subscriber distributions.
        </p>
      </div>

      {/* Plans summary stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {membershipPlans.map((plan) => {
          const subscribers = allUsers.filter(u => u.membershipTier === plan.id);
          return (
            <div
              key={plan.id}
              className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${plan.badgeColor}`}>
                  {plan.name}
                </span>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  {plan.rewardMultiplier}x Multiplier
                </span>
              </div>

              <div>
                <p className="text-2xl font-black text-slate-900 dark:text-slate-100">
                  {subscribers.length} <span className="text-xs font-normal text-slate-400">active members</span>
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Daily Limit: {plan.dailyTaskLimit} tasks • ${plan.price} / {plan.durationDays}d
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
                {plan.features.slice(0, 2).join(' • ')}
              </div>
            </div>
          );
        })}
      </div>

      {/* VIP Subscribers list */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
          Active Paid Subscribers ({premiumUsers.length + proUsers.length})
        </h3>

        {premiumUsers.length + proUsers.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 text-center">No paid subscribers yet.</p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {[...premiumUsers, ...proUsers].map((u) => (
              <div key={u.id} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">{u.name}</p>
                  <p className="text-[11px] text-slate-400">{u.email}</p>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    u.membershipTier === 'pro'
                      ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                      : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                  }`}>
                    {u.membershipTier}
                  </span>

                  <button
                    onClick={() => updateUserTierAdmin(u.id, 'basic')}
                    className="text-[11px] text-rose-500 hover:underline cursor-pointer"
                  >
                    Revoke to Basic
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
