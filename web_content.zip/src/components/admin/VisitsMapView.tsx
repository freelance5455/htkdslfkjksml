import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Navigation, User, ExternalLink, Compass } from 'lucide-react';
import { FieldVisit } from '../../types/index.ts';
import { GOOGLE_MAPS_TILE_PROVIDERS } from '../../utils/googleMapsLoader.ts';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface VisitsMapViewProps {
  visits: FieldVisit[];
  onSelectVisit: (visit: FieldVisit) => void;
}

export const VisitsMapView: React.FC<VisitsMapViewProps> = ({ visits, onSelectVisit }) => {
  const [selectedPin, setSelectedPin] = useState<FieldVisit | null>(visits[0] || null);
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  const getPinColor = (status: FieldVisit['status']) => {
    switch (status) {
      case 'completed':
        return '#10b981'; // emerald
      case 'in_progress':
        return '#0284c7'; // sky
      case 'en_route':
        return '#8b5cf6'; // purple
      default:
        return '#f59e0b'; // amber
    }
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [37.7749, -122.4194],
        zoom: 12,
        zoomControl: true,
      });

      const googleRoadmap = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.roadmap.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.roadmap.subdomains,
      });

      const googleSatellite = L.tileLayer(GOOGLE_MAPS_TILE_PROVIDERS.satellite.url, {
        attribution: GOOGLE_MAPS_TILE_PROVIDERS.satellite.attribution,
        maxZoom: 20,
        subdomains: GOOGLE_MAPS_TILE_PROVIDERS.satellite.subdomains,
      });

      googleRoadmap.addTo(map);

      L.control.layers(
        {
          'Google Maps': googleRoadmap,
          'Satellite': googleSatellite,
        },
        undefined,
        { position: 'topright' }
      ).addTo(map);

      markersLayerRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    const timer = setTimeout(() => {
      mapInstanceRef.current?.invalidateSize();
    }, 200);

    return () => clearTimeout(timer);
  }, []);

  // Update Markers
  useEffect(() => {
    if (!mapInstanceRef.current || !markersLayerRef.current) return;

    markersLayerRef.current.clearLayers();
    if (visits.length === 0) return;

    const latLngs: [number, number][] = [];

    visits.forEach((vis, index) => {
      // Use lat/lng or derive spread from San Francisco center
      const lat = (vis as any).lat || (37.755 + ((index * 0.018 + 0.005) % 0.06));
      const lng = (vis as any).lng || (-122.435 + ((index * 0.015 + 0.008) % 0.06));
      latLngs.push([lat, lng]);

      const isSelected = selectedPin?.id === vis.id;
      const color = getPinColor(vis.status);

      const customIcon = L.divIcon({
        className: 'custom-visit-pin',
        html: `
          <div style="background-color: ${color}; width: ${isSelected ? '36px' : '30px'}; height: ${isSelected ? '36px' : '30px'}; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 800; font-size: ${isSelected ? '13px' : '11px'}; border: 3px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.35); transition: all 0.2s ease;">
            ${index + 1}
          </div>
        `,
        iconSize: [isSelected ? 36 : 30, isSelected ? 36 : 30],
        iconAnchor: [isSelected ? 18 : 15, isSelected ? 18 : 15],
      });

      const marker = L.marker([lat, lng], { icon: customIcon });

      marker.bindPopup(`
        <div style="font-family: inherit; font-size: 12px; padding: 2px;">
          <strong style="color: #0f172a; font-size: 13px;">${vis.title}</strong>
          <div style="color: #475569; margin-top: 2px;">${vis.customerName}</div>
          <div style="color: #64748b; font-size: 11px; margin-top: 4px;">Assigned: <strong>${vis.assignedEmployeeName}</strong></div>
          <div style="color: ${color}; font-weight: bold; font-size: 11px; margin-top: 4px; text-transform: capitalize;">${vis.status.replace(/_/g, ' ')}</div>
        </div>
      `);

      marker.on('click', () => {
        setSelectedPin(vis);
        onSelectVisit(vis);
      });

      markersLayerRef.current?.addLayer(marker);
    });

    if (latLngs.length > 0) {
      mapInstanceRef.current.fitBounds(L.latLngBounds(latLngs), { padding: [40, 40] });
    }
  }, [visits, selectedPin]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs flex flex-col md:flex-row h-[520px]">
      {/* Interactive Google Map */}
      <div className="relative flex-1 bg-slate-100 overflow-hidden">
        <div ref={mapContainerRef} className="w-full h-full" />

        {/* Territory Label & Google Maps Badge */}
        <div className="absolute top-3 left-3 z-[1000] bg-white/95 backdrop-blur-xs px-3 py-1.5 rounded-xl border border-slate-200 shadow-sm text-xs font-bold text-slate-800 flex items-center gap-2">
          <Compass className="w-4 h-4 text-sky-600 animate-spin-slow" />
          <span>Google Maps Dispatch View</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-extrabold">Active</span>
        </div>
      </div>

      {/* Side Selected Visit Details Panel */}
      <div className="w-full md:w-80 bg-white border-t md:border-t-0 md:border-l border-slate-200 p-4 flex flex-col justify-between">
        {selectedPin ? (
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Site Inspection Detail
                </span>
                <h3 className="font-bold text-sm text-slate-900 mt-0.5">{selectedPin.title}</h3>
                <div className="text-xs font-semibold text-slate-700">{selectedPin.customerName}</div>
              </div>
              <span
                className="text-[10px] font-bold px-2 py-0.5 rounded-full capitalize"
                style={{
                  backgroundColor: `${getPinColor(selectedPin.status)}20`,
                  color: getPinColor(selectedPin.status),
                }}
              >
                {selectedPin.status.replace('_', ' ')}
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5 text-slate-600">
              <div className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                <span className="leading-snug">{selectedPin.siteAddress}</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-700 pt-1 border-t border-slate-200/60">
                <User className="w-3.5 h-3.5 text-sky-600" />
                <span>Assigned: <strong>{selectedPin.assignedEmployeeName}</strong></span>
              </div>
              <div className="text-[11px] text-slate-500">
                Scheduled: <strong>{selectedPin.scheduledTime || '09:00 AM'}</strong> ({selectedPin.scheduledDate})
              </div>
            </div>

            {selectedPin.outcomeNotes && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900">
                <div className="font-bold text-[10px] text-emerald-800 uppercase">Field Outcome:</div>
                <div className="mt-0.5">{selectedPin.outcomeNotes}</div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-12 text-xs text-slate-400">
            Select a map pin to inspect field site details
          </div>
        )}

        {selectedPin && (
          <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(selectedPin.siteAddress)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open in Google Maps</span>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
