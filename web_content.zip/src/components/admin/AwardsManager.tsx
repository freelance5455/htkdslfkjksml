import React, { useEffect, useState } from 'react';
import { Award as AwardIcon, Plus, Trophy, Sparkles, User, Calendar, X } from 'lucide-react';
import confetti from 'canvas-confetti';
import { collection, query, where, getDocs, doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Award, Employee, NotificationItem } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export const AwardsManager: React.FC = () => {
  const { currentOrg, userProfile } = useAuth();
  const [awards, setAwards] = useState<Award[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form
  const [title, setTitle] = useState('Employee of the Month');
  const [employeeId, setEmployeeId] = useState('');
  const [period, setPeriod] = useState('September 2026');
  const [reason, setReason] = useState('');

  const fetchAwardsAndEmployees = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const aQuery = query(collection(db, 'awards'), where('orgId', '==', currentOrg.id));
      const aSnap = await getDocs(aQuery);
      const aList: Award[] = [];
      aSnap.forEach((d) => aList.push(d.data() as Award));
      aList.sort((a, b) => b.date.localeCompare(a.date));
      setAwards(aList);

      const eQuery = query(collection(db, 'employees'), where('orgId', '==', currentOrg.id));
      const eSnap = await getDocs(eQuery);
      const eList: Employee[] = [];
      eSnap.forEach((d) => eList.push(d.data() as Employee));
      setEmployees(eList);
      if (eList.length > 0 && !employeeId) {
        setEmployeeId(eList[0].id);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAwardsAndEmployees();
  }, [currentOrg]);

  const handleCreateAward = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || !employeeId || !reason) return;

    const selectedEmp = employees.find((emp) => emp.id === employeeId);
    const newAward: Award = {
      id: `awd_${Date.now()}`,
      orgId: currentOrg.id,
      employeeId,
      employeeName: selectedEmp?.name || 'Technician',
      title,
      period,
      reason,
      awardedBy: userProfile?.displayName || 'Operations Management',
      date: new Date().toISOString().split('T')[0],
      badgeIcon: 'trophy',
    };

    try {
      await setDoc(doc(db, 'awards', newAward.id), removeUndefinedFields(newAward));

      // Create notification for employee
      if (selectedEmp?.userId) {
        const notif: NotificationItem = {
          id: `notif_${Date.now()}`,
          orgId: currentOrg.id,
          userId: selectedEmp.userId,
          title: `🏆 Recognition: ${title}`,
          message: `Congratulations! You have received the ${title} award for ${period}.`,
          type: 'award',
          read: false,
          createdAt: new Date().toISOString(),
        };
        await setDoc(doc(db, 'notifications', notif.id), removeUndefinedFields(notif));
      }

      setAwards((prev) => [newAward, ...prev]);
      setIsModalOpen(false);
      setReason('');

      // Celebration confetti
      confetti({
        particleCount: 80,
        spread: 80,
        origin: { y: 0.6 },
      });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Awards & Recognition Center</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Boost technician morale, celebrate on-time records, and recognize outstanding field work
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Grant Recognition</span>
        </button>
      </div>

      {/* Awards Grid */}
      {loading ? (
        <div className="py-12 text-center text-xs text-slate-500 font-medium">Loading awards...</div>
      ) : awards.length === 0 ? (
        <div className="py-12 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-200 p-8">
          No awards granted yet. Click "Grant Recognition" to celebrate technician achievements!
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {awards.map((award) => (
            <div
              key={award.id}
              className="bg-white rounded-2xl p-5 border border-amber-200/80 shadow-xs space-y-3 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-amber-200/40 to-transparent rounded-bl-full pointer-events-none" />

              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
                  <Trophy className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                  {award.period}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-base text-slate-900">{award.title}</h3>
                <div className="text-xs font-semibold text-sky-700 mt-0.5 flex items-center gap-1">
                  <User className="w-3.5 h-3.5" />
                  <span>{award.employeeName}</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                "{award.reason}"
              </p>

              <div className="text-[10px] text-slate-400 pt-1 flex items-center justify-between border-t border-slate-100">
                <span>Awarded by: {award.awardedBy}</span>
                <span>{award.date}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Grant Award Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-base text-slate-900">Grant Recognition Award</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAward} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Award Title *</label>
                <select
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                >
                  <option value="Employee of the Month">Employee of the Month</option>
                  <option value="Outstanding Attendance">Outstanding Attendance</option>
                  <option value="Best Visit Completion">Best Visit Completion</option>
                  <option value="Best Task Performance">Best Task Performance</option>
                  <option value="Customer Appreciation Honor">Customer Appreciation Honor</option>
                  <option value="Safety & Compliance Star">Safety & Compliance Star</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Technician *</label>
                <select
                  value={employeeId}
                  onChange={(e) => setEmployeeId(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.department})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Recognition Period</label>
                <input
                  type="text"
                  placeholder="e.g. September 2026 or Q3 2026"
                  value={period}
                  onChange={(e) => setPeriod(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Reason & Supporting Achievements *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Describe measurable achievements (e.g. 100% on-time attendance, zero repeat callouts)..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs leading-relaxed"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl shadow-xs"
                >
                  Grant & Celebrate 🎉
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
