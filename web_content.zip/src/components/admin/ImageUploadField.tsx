import React, { useRef, useState, useEffect } from 'react';
import { Upload, X, Image as ImageIcon, Check, RefreshCw } from 'lucide-react';
import { useData } from '../../context/DataContext.tsx';

interface ImageUploadFieldProps {
  label: string;
  value: string;
  onChange: (newUrl: string) => void | Promise<void>;
  helperText?: string;
  placeholder?: string;
  allowEmpty?: boolean;
  aspectRatio?: 'square' | 'video' | 'wide' | 'auto';
  className?: string;
}

export const ImageUploadField: React.FC<ImageUploadFieldProps> = ({
  label,
  value,
  onChange,
  helperText,
  placeholder = 'https://... or upload custom image',
  allowEmpty = true,
  aspectRatio = 'auto',
  className = ''
}) => {
  const { uploadAdminFile } = useData();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState(false);
  const [previewError, setPreviewError] = useState(false);

  useEffect(() => {
    setPreviewError(false);
  }, [value]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage(null);
    setPreviewError(false);

    // File type validation (allow all standard image MIME types or image extensions)
    const isImageMime = file.type.startsWith('image/');
    const isImageExt = /\.(jpe?g|png|webp|gif|svg|avif|bmp|ico)$/i.test(file.name);
    if (!isImageMime && !isImageExt) {
      setErrorMessage('Please choose a valid image file (JPG, PNG, WEBP, GIF, or SVG).');
      return;
    }

    // File size validation (max 25MB raw file before automatic optimization)
    const maxSize = 25 * 1024 * 1024;
    if (file.size > maxSize) {
      setErrorMessage('File size exceeds the 25MB limit. Please choose a smaller image.');
      return;
    }

    setUploading(true);

    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = () => reject(new Error('Failed to read the selected file.'));
        reader.readAsDataURL(file);
      });

      const res = await uploadAdminFile(file.name, base64);

      if (res.success && res.fileUrl) {
        await onChange(res.fileUrl);
        setSuccessNotice(true);
        setTimeout(() => setSuccessNotice(false), 3500);
      } else {
        setErrorMessage(res.error || 'Failed to upload image.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error uploading file.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleTriggerPicker = () => {
    setErrorMessage(null);
    fileInputRef.current?.click();
  };

  const handleClear = () => {
    onChange('');
    setErrorMessage(null);
    setPreviewError(false);
  };

  // Aspect ratio helper class
  const aspectClass =
    aspectRatio === 'square'
      ? 'w-24 h-24'
      : aspectRatio === 'video'
      ? 'w-36 h-20'
      : aspectRatio === 'wide'
      ? 'w-44 h-16'
      : 'w-24 h-24';

  const displayUrlLabel =
    value && value.startsWith('data:image/')
      ? 'Uploaded Custom Photo (Saved in Cloud Database)'
      : value;

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex items-center justify-between">
        <label className="block text-xs font-mono font-bold uppercase text-slate-300">
          {label}
        </label>
        {successNotice && (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 animate-fadeIn">
            <Check className="w-3.5 h-3.5" />
            <span>Photo uploaded & ready</span>
          </span>
        )}
      </div>

      {helperText && <p className="text-[11px] text-slate-400">{helperText}</p>}

      {/* Main Control: Input + Upload Button */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
        <div className="relative flex-1">
          <input
            type="text"
            value={value && value.startsWith('data:image/') ? 'Uploaded Custom Photo' : (value || '')}
            onChange={(e) => {
              if (e.target.value !== 'Uploaded Custom Photo') {
                onChange(e.target.value);
              }
            }}
            placeholder={placeholder}
            className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-cyan-400 transition-colors"
          />
        </div>

        {/* Upload Button directly beside field */}
        <div className="flex items-center gap-2 shrink-0">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          <button
            type="button"
            onClick={handleTriggerPicker}
            disabled={uploading}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 hover:border-cyan-400/60 text-cyan-300 font-bold text-xs transition-colors cursor-pointer disabled:opacity-60"
          >
            {uploading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Uploading...</span>
              </>
            ) : (
              <>
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Image</span>
              </>
            )}
          </button>

          {allowEmpty && value && (
            <button
              type="button"
              onClick={handleClear}
              title="Remove image"
              className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/10 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Error message */}
      {errorMessage && (
        <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-[11px] leading-tight">
          {errorMessage}
        </div>
      )}

      {/* Image Preview Box */}
      {value && (
        <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 flex items-center gap-3">
          <div
            className={`${aspectClass} rounded-lg bg-black/60 border border-white/10 overflow-hidden flex items-center justify-center shrink-0 relative`}
          >
            {!previewError ? (
              <img
                key={value.slice(0, 64)}
                src={value}
                alt="Preview"
                className="w-full h-full object-cover"
                onError={() => setPreviewError(true)}
              />
            ) : (
              <ImageIcon className="w-6 h-6 text-slate-600" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
              <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
              <span>Current Image Preview</span>
            </div>
            <p className="text-[11px] font-mono text-slate-400 truncate mt-0.5" title={displayUrlLabel}>
              {displayUrlLabel}
            </p>
            <p className="text-[10px] text-slate-500 mt-1">
              Click &quot;Upload Image&quot; to replace with a new photo from your device.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
