import React, { useState } from 'react';
import { User, WorkArea } from '../../types';
import { storageService } from '../../services/storage';
import { Modal } from '../common/Modal';
import {
  Users,
  Plus,
  Edit2,
  Trash2,
  Layers,
  KeyRound,
  Shield,
  Search,
  Check,
  UserCheck,
} from 'lucide-react';

interface AdminEmployeesViewProps {
  currentUser: User;
  users: User[];
  areas: WorkArea[];
  onUsersUpdated: () => void;
  initialCreateModalOpen?: boolean;
  onCloseInitialModal?: () => void;
}

export const AdminEmployeesView: React.FC<AdminEmployeesViewProps> = ({
  currentUser,
  users,
  areas,
  onUsersUpdated,
  initialCreateModalOpen = false,
  onCloseInitialModal,
}) => {
  const [activeTab, setActiveTab] = useState<'empleados' | 'areas'>('empleados');
  const [searchQuery, setSearchQuery] = useState('');

  // Employee Modal state
  const [isEmpModalOpen, setIsEmpModalOpen] = useState(initialCreateModalOpen);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [areaId, setAreaId] = useState(areas[0]?.id || 'cocina');
  const [shift, setShift] = useState('Turno 1');
  const [empError, setEmpError] = useState('');

  // Area Modal state
  const [isAreaModalOpen, setIsAreaModalOpen] = useState(false);
  const [newAreaName, setNewAreaName] = useState('');
  const [areaError, setAreaError] = useState('');

  const handleOpenCreateEmp = () => {
    setEditingUser(null);
    setName('');
    setUsername('');
    setPassword('');
    setAreaId(areas[0]?.id || 'cocina');
    setShift('Turno 1');
    setEmpError('');
    setIsEmpModalOpen(true);
  };

  const handleOpenEditEmp = (user: User) => {
    setEditingUser(user);
    setName(user.name);
    setUsername(user.username);
    setPassword(user.password || '');
    setAreaId(user.areaId);
    setShift(user.shift);
    setEmpError('');
    setIsEmpModalOpen(true);
  };

  const handleSaveEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !username.trim() || !password.trim()) {
      setEmpError('Nombre, usuario y contraseña son obligatorios.');
      return;
    }

    // Check duplicate username if adding new
    const cleanUsername = username.trim().toLowerCase();
    const existing = users.find(
      (u) => u.username.toLowerCase() === cleanUsername && u.id !== editingUser?.id
    );
    if (existing) {
      setEmpError(`El nombre de usuario "${username}" ya está en uso.`);
      return;
    }

    const selectedArea = areas.find((a) => a.id === areaId);

    if (editingUser) {
      storageService.updateUser(editingUser.id, {
        name: name.trim(),
        username: cleanUsername,
        password: password.trim(),
        areaId,
        areaName: selectedArea?.name || areaId,
        shift,
      });
    } else {
      storageService.addUser({
        name: name.trim(),
        username: cleanUsername,
        password: password.trim(),
        role: 'EMPLEADO',
        areaId,
        areaName: selectedArea?.name || areaId,
        shift,
        active: true,
      });
    }

    setIsEmpModalOpen(false);
    if (onCloseInitialModal) onCloseInitialModal();
    onUsersUpdated();
  };

  const handleDeleteEmployee = (user: User) => {
    if (user.role === 'ADMIN') {
      alert('No puedes eliminar la cuenta del administrador.');
      return;
    }
    if (confirm(`¿Deseas eliminar al empleado "${user.name}"?`)) {
      storageService.deleteUser(user.id);
      onUsersUpdated();
    }
  };

  const handleCreateArea = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAreaName.trim()) {
      setAreaError('Ingresa el nombre del área.');
      return;
    }

    const exists = areas.find(
      (a) => a.name.toLowerCase() === newAreaName.trim().toLowerCase()
    );
    if (exists) {
      setAreaError('Esta área ya existe.');
      return;
    }

    storageService.addArea(newAreaName.trim());
    setNewAreaName('');
    setIsAreaModalOpen(false);
    onUsersUpdated();
  };

  const filteredUsers = users.filter((u) => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        u.name.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q) ||
        (u.areaName && u.areaName.toLowerCase().includes(q)) ||
        u.shift.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2.5 py-0.5 rounded-md border border-orange-200 flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                Recursos Humanos
              </span>
              <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
                Gestión de Personal y Áreas
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
              Personal y Áreas de Trabajo
            </h1>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1">
              Crea empleados asignando nombre, usuario, contraseña, área y turno. Agrega más áreas de trabajo según las necesidades del restaurante.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-add-area-modal"
              onClick={() => {
                setNewAreaName('');
                setAreaError('');
                setIsAreaModalOpen(true);
              }}
              className="py-2.5 px-3 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold text-xs flex items-center gap-1.5 border border-neutral-300 active:scale-95 transition-all"
            >
              <Layers className="w-4 h-4 text-neutral-600" />
              <span>+ Área</span>
            </button>
            <button
              id="btn-add-emp-modal"
              onClick={handleOpenCreateEmp}
              className="py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-xs active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Nuevo Empleado</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-2">
        <button
          onClick={() => setActiveTab('empleados')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
            activeTab === 'empleados'
              ? 'bg-neutral-900 text-white shadow-xs'
              : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Empleados ({users.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('areas')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
            activeTab === 'areas'
              ? 'bg-orange-600 text-white shadow-xs'
              : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Áreas de Trabajo ({areas.length})</span>
        </button>
      </div>

      {/* View 1: Empleados */}
      {activeTab === 'empleados' && (
        <div className="space-y-3">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-3 text-neutral-400" />
            <input
              id="search-employee-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar empleado por nombre, usuario, área o turno..."
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-white border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/20"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredUsers.map((u) => {
              const isAdminAccount = u.role === 'ADMIN';

              return (
                <div
                  key={u.id}
                  id={`emp-card-${u.id}`}
                  className={`bg-white rounded-2xl p-4 border shadow-xs flex flex-col justify-between space-y-3 ${
                    isAdminAccount ? 'border-amber-300 bg-amber-50/20' : 'border-neutral-200'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-extrabold text-sm ${
                            isAdminAccount
                              ? 'bg-amber-500 text-white'
                              : 'bg-orange-100 text-orange-700'
                          }`}
                        >
                          {u.name.charAt(0)}
                        </div>
                        <div>
                          <h3 className="text-sm sm:text-base font-extrabold text-neutral-900">
                            {u.name}
                          </h3>
                          <div className="text-[11px] text-neutral-500">
                            @{u.username}
                          </div>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                          isAdminAccount
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {u.role}
                      </span>
                    </div>

                    <div className="mt-3 p-2.5 bg-neutral-50 rounded-xl border border-neutral-100 text-xs space-y-1">
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Área:</span>
                        <span className="font-bold text-neutral-800">
                          {u.areaName || 'No asignada'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Turno:</span>
                        <span className="font-bold text-orange-600">{u.shift}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Contraseña:</span>
                        <span className="font-mono text-neutral-600">
                          {u.password ? '••••••' : 'Sin clave'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-neutral-100 flex items-center justify-end gap-2">
                    <button
                      id={`btn-edit-emp-${u.id}`}
                      onClick={() => handleOpenEditEmp(u)}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-neutral-700 hover:bg-neutral-100 flex items-center gap-1"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Editar</span>
                    </button>
                    {!isAdminAccount && (
                      <button
                        id={`btn-del-emp-${u.id}`}
                        onClick={() => handleDeleteEmployee(u)}
                        className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-red-600 hover:bg-red-50 flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Eliminar</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* View 2: Áreas de Trabajo */}
      {activeTab === 'areas' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {areas.map((a) => {
              const countInArea = users.filter((u) => u.areaId === a.id).length;

              return (
                <div
                  key={a.id}
                  className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between space-y-2"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-xs">
                      <Layers className="w-4 h-4" />
                    </div>
                    <h3 className="font-bold text-sm text-neutral-900">{a.name}</h3>
                  </div>
                  <div className="text-xs text-neutral-500 font-medium">
                    {countInArea} {countInArea === 1 ? 'empleado' : 'empleados'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modal: Crear / Editar Empleado */}
      <Modal
        isOpen={isEmpModalOpen}
        onClose={() => {
          setIsEmpModalOpen(false);
          if (onCloseInitialModal) onCloseInitialModal();
        }}
        title={editingUser ? 'Editar Empleado' : 'Registrar Nuevo Empleado'}
        subtitle="Asigna credenciales, área de trabajo y turno asignado"
      >
        <form onSubmit={handleSaveEmployee} className="space-y-4">
          {empError && (
            <div className="p-3 bg-red-50 text-red-800 text-xs font-semibold rounded-xl border border-red-200">
              {empError}
            </div>
          )}

          {/* Nombre */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
              Nombre Completo <span className="text-red-500">*</span>
            </label>
            <input
              id="emp-name-input"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej. Carlos Méndez"
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 font-semibold"
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Usuario */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Usuario para Acceso <span className="text-red-500">*</span>
              </label>
              <input
                id="emp-username-input"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Ej. carlos"
                className="w-full p-2.5 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Contraseña <span className="text-red-500">*</span>
              </label>
              <input
                id="emp-password-input"
                type="text"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Ej. 1234"
                className="w-full p-2.5 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Area */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Área de Trabajo <span className="text-red-500">*</span>
              </label>
              <select
                id="emp-area-select"
                value={areaId}
                onChange={(e) => setAreaId(e.target.value)}
                className="w-full p-2.5 text-xs sm:text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white"
              >
                {areas.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Turno */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                Turno Asignado <span className="text-red-500">*</span>
              </label>
              <select
                id="emp-shift-select"
                value={shift}
                onChange={(e) => setShift(e.target.value)}
                className="w-full p-2.5 text-xs sm:text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white font-bold text-orange-600"
              >
                <option value="Turno 1">Turno 1 (Matutino)</option>
                <option value="Turno 2">Turno 2 (Vespertino)</option>
                <option value="Turno 3">Turno 3 (Nocturno)</option>
                <option value="Turno Mixto">Turno Mixto</option>
              </select>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-neutral-100">
            <button
              type="button"
              onClick={() => {
                setIsEmpModalOpen(false);
                if (onCloseInitialModal) onCloseInitialModal();
              }}
              className="px-4 py-2.5 rounded-xl text-neutral-600 hover:bg-neutral-100 font-semibold text-sm"
            >
              Cancelar
            </button>
            <button
              id="btn-save-emp"
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm shadow-xs active:scale-95 transition-all"
            >
              {editingUser ? 'Guardar Cambios' : 'Registrar Empleado'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal: Crear Nueva Área */}
      <Modal
        isOpen={isAreaModalOpen}
        onClose={() => setIsAreaModalOpen(false)}
        title="Agregar Nueva Área de Trabajo"
        subtitle="Por ejemplo: Parrilla, Hostess, Terraza, Repartidores"
      >
        <form onSubmit={handleCreateArea} className="space-y-4">
          {areaError && (
            <div className="p-3 bg-red-50 text-red-800 text-xs font-semibold rounded-xl border border-red-200">
              {areaError}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
              Nombre del Área <span className="text-red-500">*</span>
            </label>
            <input
              id="new-area-name-input"
              type="text"
              value={newAreaName}
              onChange={(e) => setNewAreaName(e.target.value)}
              placeholder="Ej. Parrilla, Hostess, Terraza..."
              className="w-full p-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 font-semibold"
              autoFocus
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAreaModalOpen(false)}
              className="px-4 py-2.5 rounded-xl text-neutral-600 hover:bg-neutral-100 font-semibold text-sm"
            >
              Cancelar
            </button>
            <button
              id="btn-save-area"
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm shadow-xs active:scale-95 transition-all"
            >
              Guardar Área
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
