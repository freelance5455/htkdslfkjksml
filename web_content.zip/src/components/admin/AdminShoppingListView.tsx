import React, { useState } from 'react';
import { User, ShortageItem, WorkArea } from '../../types';
import { storageService } from '../../services/storage';
import {
  ShoppingCart,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  Share2,
  Copy,
  Check,
  RotateCcw,
  PackageCheck,
  AlertTriangle,
} from 'lucide-react';

interface AdminShoppingListViewProps {
  currentUser: User;
  shortages: ShortageItem[];
  areas: WorkArea[];
  onShortagesUpdated: () => void;
}

export const AdminShoppingListView: React.FC<AdminShoppingListViewProps> = ({
  currentUser,
  shortages,
  areas,
  onShortagesUpdated,
}) => {
  const [statusFilter, setStatusFilter] = useState<'Pendiente' | 'Comprado' | 'Todos'>('Pendiente');
  const [areaFilter, setAreaFilter] = useState<string>('todas');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Toggle status between Pendiente and Comprado
  const handleToggleStatus = (item: ShortageItem) => {
    const nextStatus = item.status === 'Pendiente' ? 'Comprado' : 'Pendiente';
    storageService.updateShortageStatus(item.id, nextStatus, currentUser);
    onShortagesUpdated();
  };

  // Filter shortages
  const filteredShortages = shortages.filter((item) => {
    if (statusFilter !== 'Todos' && item.status !== statusFilter) return false;
    if (areaFilter !== 'todas' && item.areaId !== areaFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matches =
        item.product.toLowerCase().includes(q) ||
        item.reportedByName.toLowerCase().includes(q) ||
        item.areaName.toLowerCase().includes(q) ||
        (item.comment && item.comment.toLowerCase().includes(q));
      if (!matches) return false;
    }
    return true;
  });

  const pendingCount = shortages.filter((s) => s.status === 'Pendiente').length;
  const purchasedCount = shortages.filter((s) => s.status === 'Comprado').length;

  // Copy shopping list to clipboard formatted for WhatsApp or printing
  const handleCopyList = () => {
    const itemsToBuy = shortages.filter((s) => s.status === 'Pendiente');
    if (itemsToBuy.length === 0) {
      alert('No hay productos pendientes en la lista de compras.');
      return;
    }

    let text = `🛒 *LISTA DE COMPRAS PENDIENTES - RESTAURANTE*\n`;
    text += `📅 Fecha: ${new Date().toLocaleDateString('es-MX')}\n\n`;

    itemsToBuy.forEach((item, index) => {
      text += `${index + 1}. *${item.product.toUpperCase()}* — ${item.quantity}\n`;
      text += `   • Área: ${item.areaName} (${item.shift})\n`;
      text += `   • Reportó: ${item.reportedByName}\n`;
      if (item.comment) text += `   • Nota: ${item.comment}\n`;
      text += `\n`;
    });

    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 3000);
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-xs border border-neutral-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-red-600 bg-red-50 px-2.5 py-0.5 rounded-md border border-red-200 flex items-center gap-1">
                <ShoppingCart className="w-3.5 h-3.5" />
                Exclusivo Gerencia
              </span>
              <span className="text-xs font-semibold text-neutral-600 bg-neutral-100 px-2.5 py-0.5 rounded-md">
                Control de Abasto
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
              Compras Pendientes
            </h1>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1">
              Faltantes reportados automáticamente por el personal. Marca los productos como comprados una vez surtidos.
            </p>
          </div>

          {/* Quick Copy / Export List Button */}
          <button
            id="btn-copy-shopping-list"
            onClick={handleCopyList}
            className="px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shrink-0 shadow-xs active:scale-95 transition-all"
          >
            {copiedNotification ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>¡Lista Copiada!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-orange-400" />
                <span>Copiar para WhatsApp</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Filter Tabs & Area Selector */}
      <div className="bg-white rounded-2xl p-3 sm:p-4 border border-neutral-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button
              id="filter-status-pendientes"
              onClick={() => setStatusFilter('Pendiente')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
                statusFilter === 'Pendiente'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              Pendientes de Compra ({pendingCount})
            </button>
            <button
              id="filter-status-comprados"
              onClick={() => setStatusFilter('Comprado')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
                statusFilter === 'Comprado'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              Comprados ({purchasedCount})
            </button>
            <button
              id="filter-status-todos"
              onClick={() => setStatusFilter('Todos')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
                statusFilter === 'Todos'
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              Todos ({shortages.length})
            </button>
          </div>

          {/* Area Selector */}
          <div className="flex items-center gap-2 shrink-0">
            <Filter className="w-4 h-4 text-neutral-400 shrink-0" />
            <select
              id="select-filter-area"
              value={areaFilter}
              onChange={(e) => setAreaFilter(e.target.value)}
              className="p-2 text-xs font-semibold bg-neutral-50 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/20"
            >
              <option value="todas">Todas las áreas</option>
              {areas.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-neutral-400" />
          <input
            id="search-shopping-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar producto, área, empleado que reportó..."
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20"
          />
        </div>
      </div>

      {/* Shortages List / Cards */}
      {filteredShortages.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 text-center border border-neutral-200">
          <PackageCheck className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
          <h3 className="text-base font-bold text-neutral-800">
            {statusFilter === 'Pendiente'
              ? 'No hay compras pendientes en este momento'
              : 'No se encontraron registros'}
          </h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
            Cuando un empleado registre un faltante en cualquier área, aparecerá automáticamente aquí.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredShortages.map((item) => {
            const isPurchased = item.status === 'Comprado';

            return (
              <div
                key={item.id}
                id={`admin-shortage-card-${item.id}`}
                className={`bg-white rounded-2xl p-4 sm:p-5 border transition-all shadow-xs flex flex-col justify-between ${
                  isPurchased
                    ? 'border-emerald-200 bg-emerald-50/15'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <div>
                  {/* Top Header: Area, Shift & Status Badge */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[11px] font-bold text-neutral-700 bg-neutral-100 px-2 py-0.5 rounded">
                        {item.areaName}
                      </span>
                      <span className="text-[11px] font-medium text-orange-700 bg-orange-50 px-2 py-0.5 rounded border border-orange-100">
                        {item.shift}
                      </span>
                    </div>

                    <span
                      className={`text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full ${
                        isPurchased
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-red-100 text-red-800 border border-red-300'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  {/* Product & Quantity display strictly matching prompt example */}
                  <div className="mt-1">
                    <h3 className="text-lg font-black text-neutral-900 uppercase tracking-tight">
                      {item.product} — <span className="text-orange-600 font-bold">{item.quantity}</span>
                    </h3>
                  </div>

                  {/* Reporter details */}
                  <div className="mt-2 text-xs text-neutral-600 space-y-1 bg-neutral-50 p-2.5 rounded-xl border border-neutral-100">
                    <div>
                      <strong>Reportado por:</strong> {item.reportedByName}
                    </div>
                    <div>
                      <strong>Fecha:</strong> {item.date} a las {item.time}
                    </div>
                    {item.comment && (
                      <div className="text-neutral-700 italic">
                        <strong>Comentario:</strong> "{item.comment}"
                      </div>
                    )}
                    {isPurchased && item.purchasedByName && (
                      <div className="text-emerald-800 font-semibold pt-1 border-t border-neutral-200/60">
                        ✓ Comprado por: {item.purchasedByName}
                      </div>
                    )}
                  </div>
                </div>

                {/* Big Action Button to mark as purchased */}
                <div className="mt-4 pt-3 border-t border-neutral-100">
                  <button
                    id={`btn-toggle-buy-${item.id}`}
                    onClick={() => handleToggleStatus(item)}
                    className={`w-full py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-xs active:scale-[0.98] transition-all ${
                      isPurchased
                        ? 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700 border border-neutral-300'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    {isPurchased ? (
                      <>
                        <RotateCcw className="w-4 h-4 text-neutral-500" />
                        <span>Desmarcar a Pendiente</span>
                      </>
                    ) : (
                      <>
                        <PackageCheck className="w-5 h-5 stroke-[2.5]" />
                        <span>Marcar como COMPRADO</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
