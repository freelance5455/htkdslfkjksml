import React, { useState, useRef, useMemo } from 'react';
import {
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Download,
  X,
  ArrowRight,
  RefreshCw,
  Sliders,
  History,
  Info,
  Layers,
  FileText,
  AlertCircle,
  HelpCircle,
  Database,
} from 'lucide-react';
import { collection, query, where, getDocs, doc, writeBatch, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  parseSpreadsheetFile,
  extractWorksheetData,
  normalizeExcelDate,
  downloadExcelTemplate,
  downloadErrorReport,
  ParsedSpreadsheetResult,
  SpreadsheetRowError,
} from '../../utils/spreadsheetHelper.ts';
import { Employee, ImportMode, ImportHistoryRecord, AuditLogEntry, EmploymentStatus } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { exportToCsv, generateEmployeeCsvTemplate } from '../../utils/csvHelper.ts';

interface BulkImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  onOpenHistory?: () => void;
}

interface ColumnMapping {
  employeeCode: string;
  name: string;
  phone: string;
  email: string;
  department: string;
  designation: string;
  territory: string;
  managerName: string;
  emergencyContact: string;
  joiningDate: string;
  status: string;
}

export const BulkImportModal: React.FC<BulkImportModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  onOpenHistory,
}) => {
  const { currentOrg, userProfile } = useAuth();
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1); // 1: Upload & Sheet & Mode, 2: Mapping, 3: Preview & Validate, 4: Results
  const [importMode, setImportMode] = useState<ImportMode>('add_and_update');

  // File & Sheet State
  const [parsedFile, setParsedFile] = useState<ParsedSpreadsheetResult | null>(null);
  const [selectedSheetName, setSelectedSheetName] = useState<string>('');
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [parsedRows, setParsedRows] = useState<Record<string, string>[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [fileError, setFileError] = useState<string | null>(null);
  const [isParsingFile, setIsParsingFile] = useState(false);

  // Column Mapping
  const [mapping, setMapping] = useState<ColumnMapping>({
    employeeCode: '',
    name: '',
    phone: '',
    email: '',
    department: '',
    designation: '',
    territory: '',
    managerName: '',
    emergencyContact: '',
    joiningDate: '',
    status: '',
  });

  // Validation & Processing results
  const [newEmployeesToCreate, setNewEmployeesToCreate] = useState<Employee[]>([]);
  const [existingEmployeesToUpdate, setExistingEmployeesToUpdate] = useState<Employee[]>([]);
  const [skippedCount, setSkippedCount] = useState<number>(0);
  const [duplicateInFileCount, setDuplicateInFileCount] = useState<number>(0);
  const [rowErrors, setRowErrors] = useState<SpreadsheetRowError[]>([]);
  const [previewRows, setPreviewRows] = useState<{
    rowNum: number;
    action: 'CREATE' | 'UPDATE' | 'SKIP' | 'ERROR';
    code: string;
    name: string;
    phone: string;
    email: string;
    department: string;
    designation: string;
    errorReason?: string;
  }[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  // Final summary stats
  const [summaryStats, setSummaryStats] = useState<{
    created: number;
    updated: number;
    skipped: number;
    errors: number;
    total: number;
  }>({ created: 0, updated: 0, skipped: 0, errors: 0, total: 0 });

  // Progress Tracker for Large Files (1,000 to 10,000+ records)
  const [importProgress, setImportProgress] = useState<{
    processed: number;
    total: number;
    created: number;
    updated: number;
    skipped: number;
    percentage: number;
  }>({
    processed: 0,
    total: 0,
    created: 0,
    updated: 0,
    skipped: 0,
    percentage: 0,
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  // Auto-detect column mappings based on flexible header variations
  const suggestMappings = (headers: string[]): ColumnMapping => {
    const suggested: ColumnMapping = {
      employeeCode: '',
      name: '',
      phone: '',
      email: '',
      department: '',
      designation: '',
      territory: '',
      managerName: '',
      emergencyContact: '',
      joiningDate: '',
      status: '',
    };

    headers.forEach((h) => {
      const clean = h.trim();
      const lower = clean.toLowerCase().replace(/[^a-z0-9]/g, '');

      // 1. Employee ID / Code
      if (
        /^(emp(loyee)?[\s_-]?(id|no|num|number|code)|id|code|empcode|staffid|badgeno)$/i.test(clean) ||
        (lower.includes('code') && !lower.includes('zip') && !lower.includes('postal')) ||
        (lower.includes('empid') || lower.includes('employeeno'))
      ) {
        if (!suggested.employeeCode) suggested.employeeCode = clean;
      }
      // 2. Full Name
      else if (
        /^(full[\s_-]?name|name|employee[\s_-]?name|staff[\s_-]?name|worker[\s_-]?name)$/i.test(clean) ||
        (lower.includes('fullname') || lower === 'name' || lower.includes('employeename'))
      ) {
        if (!suggested.name) suggested.name = clean;
      }
      // 3. Phone / Mobile
      else if (
        /^(phone|mobile|cell|contact|tel|telephone|phone[\s_-]?num(ber)?|mobile[\s_-]?num(ber)?)$/i.test(clean) ||
        lower.includes('phone') || lower.includes('mobile') || lower.includes('contactno')
      ) {
        if (!suggested.phone) suggested.phone = clean;
      }
      // 4. Email
      else if (
        /^(email|e[\s_-]?mail|email[\s_-]?address|mail)$/i.test(clean) ||
        lower.includes('email') || lower.includes('mailaddress')
      ) {
        if (!suggested.email) suggested.email = clean;
      }
      // 5. Department
      else if (
        /^(dept|department|division|team|unit|branch)$/i.test(clean) ||
        lower.includes('dept') || lower.includes('department') || lower.includes('division')
      ) {
        if (!suggested.department) suggested.department = clean;
      }
      // 6. Designation / Job Title / Role
      else if (
        /^(designation|job[\s_-]?title|position|role|title)$/i.test(clean) ||
        lower.includes('title') || lower.includes('designation') || lower.includes('role') || lower.includes('position')
      ) {
        if (!suggested.designation) suggested.designation = clean;
      }
      // 7. Territory / Region / Area
      else if (
        /^(territory|region|location|area|zone|branch|city)$/i.test(clean) ||
        lower.includes('territory') || lower.includes('region') || lower.includes('zone')
      ) {
        if (!suggested.territory) suggested.territory = clean;
      }
      // 8. Manager Name / Supervisor
      else if (
        /^(manager[\s_-]?name|manager|supervisor|reports[\s_-]?to)$/i.test(clean) ||
        lower.includes('manager') || lower.includes('supervisor')
      ) {
        if (!suggested.managerName) suggested.managerName = clean;
      }
      // 9. Emergency Contact
      else if (
        /^(emergency[\s_-]?contact|emergency[\s_-]?phone|emergency)$/i.test(clean) ||
        lower.includes('emergency')
      ) {
        if (!suggested.emergencyContact) suggested.emergencyContact = clean;
      }
      // 10. Joining Date / Hire Date
      else if (
        /^(joining[\s_-]?date|date[\s_-]?joined|hire[\s_-]?date|start[\s_-]?date|doj)$/i.test(clean) ||
        lower.includes('joining') || lower.includes('hiredate') || lower.includes('startdate') || lower.includes('datejoined')
      ) {
        if (!suggested.joiningDate) suggested.joiningDate = clean;
      }
      // 11. Status
      else if (
        /^(status|employment[\s_-]?status|active|state)$/i.test(clean) ||
        lower.includes('status')
      ) {
        if (!suggested.status) suggested.status = clean;
      }
    });

    // Fallbacks if not detected by keywords
    if (!suggested.employeeCode && headers[0]) suggested.employeeCode = headers[0];
    if (!suggested.name && headers[1]) suggested.name = headers[1];

    return suggested;
  };

  // Process incoming file (either from click or drag-and-drop)
  const processSelectedFile = async (file: File) => {
    setFileError(null);
    setIsParsingFile(true);

    try {
      const result = await parseSpreadsheetFile(file);
      setParsedFile(result);
      setSelectedSheetName(result.selectedSheet);
      setRawHeaders(result.headers);
      setParsedRows(result.rows);

      // Auto-suggest mappings for this sheet
      const suggested = suggestMappings(result.headers);
      setMapping(suggested);
    } catch (err: any) {
      console.error('File parsing error:', err);
      setFileError(err?.message || 'Failed to read file. Please ensure it is a valid Excel or CSV document.');
      setParsedFile(null);
    } finally {
      setIsParsingFile(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  // Switch sheet inside a multi-sheet Excel workbook
  const handleSheetChange = (sheetName: string) => {
    if (!parsedFile?.workbook) return;
    setSelectedSheetName(sheetName);

    const { headers, rows } = extractWorksheetData(parsedFile.workbook, sheetName);
    setRawHeaders(headers);
    setParsedRows(rows);

    const suggested = suggestMappings(headers);
    setMapping(suggested);
  };

  // Step 2 -> Step 3: Validate & Preview Rows
  const handleValidateRows = async () => {
    if (!currentOrg || !mapping.employeeCode || !mapping.name) return;
    setIsValidating(true);

    try {
      // 1. Fetch all existing employees in the current organization for duplicate check & updates
      const existingSnap = await getDocs(
        query(collection(db, 'employees'), where('orgId', '==', currentOrg.id))
      );
      const existingByCode = new Map<string, Employee>();
      const existingByEmail = new Map<string, Employee>();

      existingSnap.forEach((d) => {
        const emp = d.data() as Employee;
        if (emp.employeeCode) {
          existingByCode.set(emp.employeeCode.trim().toLowerCase(), emp);
        }
        if (emp.email) {
          existingByEmail.set(emp.email.trim().toLowerCase(), emp);
        }
      });

      const validationErrors: SpreadsheetRowError[] = [];
      const toCreate: Employee[] = [];
      const toUpdate: Employee[] = [];
      const previewList: typeof previewRows = [];
      let skipped = 0;
      let fileDupes = 0;

      // Intra-file deduplication tracker
      const seenFileCodes = new Set<string>();

      parsedRows.forEach((row, idx) => {
        const rowNum = idx + 2; // Row 1 is header
        const rawCode = (row[mapping.employeeCode] || '').trim();
        const rawName = (row[mapping.name] || '').trim();
        const rawPhone = mapping.phone ? (row[mapping.phone] || '').trim() : '';
        const rawEmail = mapping.email ? (row[mapping.email] || '').trim().toLowerCase() : '';
        const rawDept = mapping.department ? (row[mapping.department] || '').trim() : '';
        const rawDesig = mapping.designation ? (row[mapping.designation] || '').trim() : '';
        const rawTerritory = mapping.territory ? (row[mapping.territory] || '').trim() : '';
        const rawManager = mapping.managerName ? (row[mapping.managerName] || '').trim() : '';
        const rawEmergency = mapping.emergencyContact ? (row[mapping.emergencyContact] || '').trim() : '';
        const rawJoiningDate = mapping.joiningDate ? (row[mapping.joiningDate] || '') : '';
        const rawStatus = mapping.status ? (row[mapping.status] || 'active').trim().toLowerCase() : 'active';

        // 1. Check Required Field: Employee ID
        if (!rawCode) {
          validationErrors.push({
            rowNumber: rowNum,
            field: 'Employee ID',
            value: '',
            reason: 'Missing required Employee ID / Code.',
            suggestedAction: 'Provide a unique Employee ID for this record.',
          });
          if (previewList.length < 20) {
            previewList.push({
              rowNum,
              action: 'ERROR',
              code: '--',
              name: rawName || '--',
              phone: rawPhone,
              email: rawEmail,
              department: rawDept,
              designation: rawDesig,
              errorReason: 'Missing Employee ID',
            });
          }
          return;
        }

        const normalizedCode = rawCode.toLowerCase();

        // 2. Check Intra-File Duplicate Employee ID
        if (seenFileCodes.has(normalizedCode)) {
          fileDupes++;
          validationErrors.push({
            rowNumber: rowNum,
            employeeCode: rawCode,
            name: rawName,
            field: 'Employee ID',
            value: rawCode,
            reason: `Duplicate Employee ID '${rawCode}' within uploaded file.`,
            suggestedAction: 'Ensure each employee has a distinct Employee ID.',
          });
          if (previewList.length < 20) {
            previewList.push({
              rowNum,
              action: 'ERROR',
              code: rawCode,
              name: rawName || '--',
              phone: rawPhone,
              email: rawEmail,
              department: rawDept,
              designation: rawDesig,
              errorReason: 'Duplicate ID in file',
            });
          }
          return;
        }
        seenFileCodes.add(normalizedCode);

        // 3. Check Required Field: Full Name
        if (!rawName) {
          validationErrors.push({
            rowNumber: rowNum,
            employeeCode: rawCode,
            field: 'Full Name',
            value: '',
            reason: 'Missing required Full Name.',
            suggestedAction: 'Provide the employee full name.',
          });
          if (previewList.length < 20) {
            previewList.push({
              rowNum,
              action: 'ERROR',
              code: rawCode,
              name: '--',
              phone: rawPhone,
              email: rawEmail,
              department: rawDept,
              designation: rawDesig,
              errorReason: 'Missing Full Name',
            });
          }
          return;
        }

        // 4. Normalize Date (Excel serial date conversion e.g. 45291 -> 2024-01-01)
        const normalizedJoiningDate = normalizeExcelDate(rawJoiningDate) || new Date().toISOString().split('T')[0];

        // 5. Normalize Status
        let status: EmploymentStatus = 'active';
        if (['active', 'on_leave', 'inactive', 'left_company', 'suspended'].includes(rawStatus)) {
          status = rawStatus as EmploymentStatus;
        } else if (rawStatus.includes('leave')) {
          status = 'on_leave';
        } else if (rawStatus.includes('inact') || rawStatus.includes('no') || rawStatus.includes('false')) {
          status = 'inactive';
        }

        // 6. Check against existing employees in organization
        const existingEmp = existingByCode.get(normalizedCode) || (rawEmail ? existingByEmail.get(rawEmail) : undefined);

        if (existingEmp) {
          // Record already exists in Organization
          if (importMode === 'add_only' || importMode === 'skip_existing') {
            skipped++;
            if (previewList.length < 20) {
              previewList.push({
                rowNum,
                action: 'SKIP',
                code: rawCode,
                name: rawName,
                phone: rawPhone || existingEmp.phone || '',
                email: rawEmail || existingEmp.email || '',
                department: rawDept || existingEmp.department || '',
                designation: rawDesig || existingEmp.designation || '',
              });
            }
            return;
          }

          // In 'update_only' or 'add_and_update': Update existing profile
          const updatedEmp: Employee = {
            ...existingEmp,
            name: rawName,
            email: rawEmail || existingEmp.email || `${normalizedCode}@company.internal`,
            phone: rawPhone || existingEmp.phone || '',
            department: rawDept || existingEmp.department || 'Operations',
            designation: rawDesig || existingEmp.designation || 'Technician',
            territory: rawTerritory || existingEmp.territory || 'General',
            managerName: rawManager || existingEmp.managerName || 'Operations Lead',
            emergencyContact: rawEmergency || existingEmp.emergencyContact || '',
            joiningDate: normalizedJoiningDate || existingEmp.joiningDate || new Date().toISOString().split('T')[0],
            status: status || existingEmp.status || 'active',
            updatedAt: new Date().toISOString(),
          };
          toUpdate.push(updatedEmp);

          if (previewList.length < 20) {
            previewList.push({
              rowNum,
              action: 'UPDATE',
              code: rawCode,
              name: rawName,
              phone: updatedEmp.phone || '',
              email: updatedEmp.email || '',
              department: updatedEmp.department || '',
              designation: updatedEmp.designation || '',
            });
          }
        } else {
          // Record is brand new
          if (importMode === 'update_only') {
            skipped++;
            if (previewList.length < 20) {
              previewList.push({
                rowNum,
                action: 'SKIP',
                code: rawCode,
                name: rawName,
                phone: rawPhone,
                email: rawEmail,
                department: rawDept,
                designation: rawDesig,
              });
            }
            return;
          }

          // In 'add_only', 'skip_existing', or 'add_and_update': Create new profile
          const cleanIdCode = rawCode.toLowerCase().replace(/[^a-z0-9]/g, '-');
          const newEmp: Employee = {
            id: `emp_${currentOrg.id}_${cleanIdCode || Date.now() + '_' + idx}`,
            orgId: currentOrg.id,
            employeeCode: rawCode,
            name: rawName,
            email: rawEmail || `${cleanIdCode || 'emp'}@company.internal`,
            phone: rawPhone || '',
            department: rawDept || 'Operations',
            designation: rawDesig || 'Technician',
            territory: rawTerritory || 'General',
            managerName: rawManager || 'Operations Lead',
            emergencyContact: rawEmergency || '',
            joiningDate: normalizedJoiningDate,
            status,
            createdAt: new Date().toISOString(),
          };
          toCreate.push(newEmp);

          if (previewList.length < 20) {
            previewList.push({
              rowNum,
              action: 'CREATE',
              code: rawCode,
              name: rawName,
              phone: newEmp.phone || '',
              email: newEmp.email || '',
              department: newEmp.department || '',
              designation: newEmp.designation || '',
            });
          }
        }
      });

      setNewEmployeesToCreate(toCreate);
      setExistingEmployeesToUpdate(toUpdate);
      setSkippedCount(skipped);
      setDuplicateInFileCount(fileDupes);
      setRowErrors(validationErrors);
      setPreviewRows(previewList);
      setStep(3);
    } catch (err) {
      console.error('Validation error:', err);
      alert('Error validating employee records against existing database.');
    } finally {
      setIsValidating(false);
    }
  };

  // Step 3 -> Step 4: Execute Batch Write to Firestore
  const handleExecuteImport = async () => {
    if (!currentOrg) return;
    setIsImporting(true);

    const allToCommit = [...newEmployeesToCreate, ...existingEmployeesToUpdate];
    const totalToCommit = allToCommit.length;
    const chunkSize = 400; // Safe batch size (Firestore max is 500)

    setImportProgress({
      processed: 0,
      total: totalToCommit,
      created: 0,
      updated: 0,
      skipped: skippedCount,
      percentage: 0,
    });

    try {
      let createdCounter = 0;
      let updatedCounter = 0;

      for (let i = 0; i < totalToCommit; i += chunkSize) {
        const chunk = allToCommit.slice(i, i + chunkSize);
        const batch = writeBatch(db);

        chunk.forEach((emp) => {
          const docRef = doc(db, 'employees', emp.id);
          batch.set(docRef, removeUndefinedFields(emp), { merge: true });
        });

        await batch.commit();

        const currentProcessed = Math.min(totalToCommit, i + chunk.length);
        const pct = Math.round((currentProcessed / totalToCommit) * 100);

        createdCounter = Math.min(newEmployeesToCreate.length, currentProcessed);
        updatedCounter = Math.max(0, currentProcessed - newEmployeesToCreate.length);

        setImportProgress({
          processed: currentProcessed,
          total: totalToCommit,
          created: createdCounter,
          updated: updatedCounter,
          skipped: skippedCount,
          percentage: pct,
        });

        // Yield to browser execution thread so UI doesn't freeze on 10,000+ rows
        await new Promise((res) => setTimeout(res, 15));
      }

      // Record Import in import_history collection
      const importId = `imp_${Date.now()}`;
      const historyRecord: ImportHistoryRecord = {
        id: importId,
        orgId: currentOrg.id,
        uploadedBy: userProfile?.displayName || userProfile?.email || 'Admin',
        uploadedByEmail: userProfile?.email || 'admin@company.com',
        uploadedAt: new Date().toISOString(),
        fileName: parsedFile?.fileName || 'employee_roster.xlsx',
        mode: importMode,
        totalRows: parsedRows.length,
        createdCount: newEmployeesToCreate.length,
        updatedCount: existingEmployeesToUpdate.length,
        skippedCount,
        errorCount: rowErrors.length,
        status:
          rowErrors.length === 0
            ? 'completed'
            : newEmployeesToCreate.length > 0 || existingEmployeesToUpdate.length > 0
            ? 'completed_with_errors'
            : 'failed',
        errorSummary: rowErrors.slice(0, 10).map((e) => `Row ${e.rowNumber} (${e.field}): ${e.reason}`),
      };
      await setDoc(doc(db, 'import_history', importId), removeUndefinedFields(historyRecord));

      // Audit Log Entry
      const auditLog: AuditLogEntry = {
        id: `aud_imp_${Date.now()}`,
        orgId: currentOrg.id,
        userId: userProfile?.id || 'admin',
        userName: userProfile?.displayName || 'Admin',
        action: 'Bulk Employee Import',
        module: 'Workforce',
        details: `Imported employee roster from "${parsedFile?.fileName || 'file'}" via ${importMode}. Created: ${newEmployeesToCreate.length}, Updated: ${existingEmployeesToUpdate.length}, Skipped: ${skippedCount}, Errors: ${rowErrors.length}.`,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

      setSummaryStats({
        created: newEmployeesToCreate.length,
        updated: existingEmployeesToUpdate.length,
        skipped: skippedCount,
        errors: rowErrors.length,
        total: parsedRows.length,
      });

      setStep(4);
      onSuccess();
    } catch (err) {
      console.error('Error committing bulk import:', err);
      alert('Error writing import batches to database.');
    } finally {
      setIsImporting(false);
    }
  };

  const handleDownloadErrors = () => {
    if (rowErrors.length === 0) return;
    downloadErrorReport(parsedFile?.fileName || 'employees_import', rowErrors);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in-0 duration-150 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-5 h-5 text-sky-600" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">Bulk Employee Import (Excel & CSV)</h3>
              <p className="text-[11px] text-slate-500">
                Supports real .xlsx, .xls, .csv files from MS Excel, Google Sheets, LibreOffice & custom formats
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {onOpenHistory && (
              <button
                type="button"
                onClick={onOpenHistory}
                className="text-xs font-semibold px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 flex items-center gap-1.5 transition-colors"
                title="View past import audit logs"
              >
                <History className="w-3.5 h-3.5 text-slate-500" />
                <span>History</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              disabled={isImporting}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 transition-colors disabled:opacity-50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Step Indicator Header */}
        <div className="bg-white border-b border-slate-200 px-6 py-2.5 flex items-center justify-between text-xs shrink-0">
          <div className={`flex items-center gap-1.5 ${step >= 1 ? 'font-bold text-sky-700' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${step >= 1 ? 'bg-sky-600 text-white' : 'bg-slate-200'}`}>1</span>
            <span>Upload File</span>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-300" />
          <div className={`flex items-center gap-1.5 ${step >= 2 ? 'font-bold text-sky-700' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${step >= 2 ? 'bg-sky-600 text-white' : 'bg-slate-200'}`}>2</span>
            <span>Map Columns</span>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-300" />
          <div className={`flex items-center gap-1.5 ${step >= 3 ? 'font-bold text-sky-700' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${step >= 3 ? 'bg-sky-600 text-white' : 'bg-slate-200'}`}>3</span>
            <span>Preview & Validate</span>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-300" />
          <div className={`flex items-center gap-1.5 ${step === 4 ? 'font-bold text-emerald-700' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${step === 4 ? 'bg-emerald-600 text-white' : 'bg-slate-200'}`}>4</span>
            <span>Completed</span>
          </div>
        </div>

        {/* Body Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* ============================================================ */}
          {/* STEP 1: UPLOAD FILE & WORKSHEET & IMPORT MODE               */}
          {/* ============================================================ */}
          {step === 1 && (
            <div className="space-y-4">
              {/* Native File Input */}
              <input
                type="file"
                accept=".xlsx, .xls, .csv"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
              />

              {/* Drag-and-drop Upload Box */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragOver(true);
                }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed p-8 rounded-2xl cursor-pointer transition-all text-center select-none ${
                  isDragOver
                    ? 'border-sky-500 bg-sky-50/80 scale-[1.01]'
                    : parsedFile
                    ? 'border-emerald-400 bg-emerald-50/30'
                    : 'border-slate-300 hover:border-sky-500 bg-slate-50 hover:bg-sky-50/20'
                }`}
              >
                <div className="w-12 h-12 rounded-2xl bg-sky-100 text-sky-600 flex items-center justify-center mx-auto mb-3">
                  {isParsingFile ? (
                    <RefreshCw className="w-6 h-6 animate-spin text-sky-600" />
                  ) : parsedFile ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                  ) : (
                    <Upload className="w-6 h-6 text-sky-600" />
                  )}
                </div>

                {isParsingFile ? (
                  <div className="font-bold text-sm text-slate-800">Reading Excel / CSV data...</div>
                ) : parsedFile ? (
                  <div>
                    <div className="font-bold text-sm text-slate-900 flex items-center justify-center gap-2">
                      <span className="truncate max-w-sm">{parsedFile.fileName}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-emerald-100 text-emerald-800">
                        {parsedFile.fileType}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-1">
                      {parsedFile.fileSizeStr} • {parsedRows.length.toLocaleString()} rows detected • Click to choose another file
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="font-bold text-sm text-slate-800">
                      Drag & Drop Excel or CSV file here, or <span className="text-sky-600 underline">Browse File</span>
                    </div>
                    <div className="text-xs text-slate-500 mt-1">
                      Accepts genuine .xlsx, .xls, and .csv files from any software
                    </div>
                  </div>
                )}
              </div>

              {/* File Error Notification */}
              {fileError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2 animate-in fade-in-0">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{fileError}</span>
                </div>
              )}

              {/* Multi-Worksheet Selector (If Excel has multiple sheets) */}
              {parsedFile && parsedFile.sheetNames.length > 1 && (
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 animate-in fade-in-0">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-sky-600" />
                      <span>Select Worksheet</span>
                    </span>
                    <span className="text-[11px] text-slate-500">
                      This workbook has {parsedFile.sheetNames.length} sheets
                    </span>
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    {parsedFile.sheetNames.map((sName) => (
                      <button
                        key={sName}
                        type="button"
                        onClick={() => handleSheetChange(sName)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                          selectedSheetName === sName
                            ? 'bg-sky-600 text-white shadow-xs'
                            : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        {sName}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Import Mode Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Import Action Mode
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div
                    onClick={() => setImportMode('add_and_update')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      importMode === 'add_and_update'
                        ? 'border-sky-500 bg-sky-50/70 text-sky-950 font-bold shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold">Add + Update</span>
                      {importMode === 'add_and_update' && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                    </div>
                    <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                      Create new employees and update matching IDs. Recommended.
                    </div>
                  </div>

                  <div
                    onClick={() => setImportMode('add_only')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      importMode === 'add_only'
                        ? 'border-sky-500 bg-sky-50/70 text-sky-950 font-bold shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold">Add New Only</span>
                      {importMode === 'add_only' && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                    </div>
                    <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                      Only create new profiles. Skip matching existing IDs.
                    </div>
                  </div>

                  <div
                    onClick={() => setImportMode('update_only')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      importMode === 'update_only'
                        ? 'border-sky-500 bg-sky-50/70 text-sky-950 font-bold shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold">Update Existing</span>
                      {importMode === 'update_only' && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                    </div>
                    <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                      Only update matching IDs. Do not add new employees.
                    </div>
                  </div>

                  <div
                    onClick={() => setImportMode('skip_existing')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      importMode === 'skip_existing'
                        ? 'border-sky-500 bg-sky-50/70 text-sky-950 font-bold shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold">Skip Existing</span>
                      {importMode === 'skip_existing' && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                    </div>
                    <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                      Create new employees but leave existing employees unchanged.
                    </div>
                  </div>
                </div>
              </div>

              {/* Sample Templates & Action Bar */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={downloadExcelTemplate}
                    className="text-xs font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Sample Excel (.xlsx)</span>
                  </button>
                  <span className="text-slate-300">•</span>
                  <button
                    type="button"
                    onClick={() => {
                      const csv = generateEmployeeCsvTemplate();
                      exportToCsv('FieldFlow_Employee_Template.csv', csv.split('\n')[0].split(','), [
                        csv.split('\n')[1].split(','),
                        csv.split('\n')[2].split(','),
                      ]);
                    }}
                    className="text-xs font-semibold text-slate-500 hover:text-slate-700 transition-colors"
                  >
                    Sample CSV
                  </button>
                </div>

                <button
                  type="button"
                  disabled={!parsedFile || parsedRows.length === 0}
                  onClick={() => setStep(2)}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-40 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <span>Continue to Mapping</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* STEP 2: FLEXIBLE COLUMN MAPPING (Required & Optional)        */}
          {/* ============================================================ */}
          {step === 2 && (
            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <div className="font-bold text-slate-900 text-sm">{parsedFile?.fileName}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Sheet: <span className="font-semibold text-slate-700">{selectedSheetName}</span> • {parsedRows.length.toLocaleString()} rows detected
                  </div>
                </div>
                <div className="text-sky-700 font-bold uppercase text-[10px] bg-sky-100 px-2 py-1 rounded-md">
                  Mode: {importMode.replace(/_/g, ' ')}
                </div>
              </div>

              <p className="text-slate-500 text-[11px]">
                Map columns from your spreadsheet to FieldFlow fields. Only <strong>Employee ID</strong> and <strong>Full Name</strong> are required.
              </p>

              {/* Column Mapping Fields Form */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-72 overflow-y-auto pr-1">
                {[
                  {
                    key: 'employeeCode',
                    label: 'Employee ID',
                    hint: 'Unique employee ID or code',
                    required: true,
                  },
                  {
                    key: 'name',
                    label: 'Full Name',
                    hint: 'Employee first and last name',
                    required: true,
                  },
                  {
                    key: 'phone',
                    label: 'Phone / Mobile',
                    hint: 'Contact mobile number',
                    required: false,
                  },
                  {
                    key: 'email',
                    label: 'Email Address',
                    hint: 'Company email address',
                    required: false,
                  },
                  {
                    key: 'department',
                    label: 'Department',
                    hint: 'Division or operational unit',
                    required: false,
                  },
                  {
                    key: 'designation',
                    label: 'Designation / Role',
                    hint: 'Job title or position',
                    required: false,
                  },
                  {
                    key: 'territory',
                    label: 'Territory / Region',
                    hint: 'Assigned service zone or city',
                    required: false,
                  },
                  {
                    key: 'managerName',
                    label: 'Manager Name',
                    hint: 'Reporting supervisor',
                    required: false,
                  },
                  {
                    key: 'emergencyContact',
                    label: 'Emergency Contact',
                    hint: 'Emergency phone / person',
                    required: false,
                  },
                  {
                    key: 'joiningDate',
                    label: 'Joining Date',
                    hint: 'Hire date (auto converts Excel serial)',
                    required: false,
                  },
                  {
                    key: 'status',
                    label: 'Employment Status',
                    hint: 'Active, On Leave, Inactive',
                    required: false,
                  },
                ].map((field) => (
                  <div key={field.key} className="p-2.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-800 text-xs flex items-center gap-1">
                        <span>{field.label}</span>
                        {field.required ? (
                          <span className="text-[9px] font-black uppercase px-1.5 py-0.2 bg-rose-100 text-rose-700 rounded-md">
                            Required
                          </span>
                        ) : (
                          <span className="text-[9px] font-bold uppercase px-1.5 py-0.2 bg-slate-200 text-slate-600 rounded-md">
                            Optional
                          </span>
                        )}
                      </span>
                    </div>

                    <select
                      value={(mapping as any)[field.key]}
                      onChange={(e) => setMapping({ ...mapping, [field.key]: e.target.value })}
                      className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                    >
                      <option value="">-- Do not map --</option>
                      {rawHeaders.map((h) => (
                        <option key={h} value={h}>
                          {h}
                        </option>
                      ))}
                    </select>

                    <div className="text-[10px] text-slate-400">{field.hint}</div>
                  </div>
                ))}
              </div>

              {/* Bottom Nav */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  &larr; Back
                </button>
                <button
                  type="button"
                  disabled={!mapping.employeeCode || !mapping.name || isValidating}
                  onClick={handleValidateRows}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 disabled:opacity-40 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isValidating ? 'animate-spin' : ''}`} />
                  <span>{isValidating ? 'Validating against DB...' : `Validate & Preview ${parsedRows.length.toLocaleString()} Rows`}</span>
                </button>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* STEP 3: PREVIEW & VALIDATION SUMMARY                        */}
          {/* ============================================================ */}
          {step === 3 && (
            <div className="space-y-4 text-xs">
              {/* KPIs Breakdown */}
              <div className="grid grid-cols-5 gap-2 text-center">
                <div className="p-2.5 bg-slate-100 border border-slate-200 rounded-xl">
                  <div className="text-base font-black text-slate-800">{parsedRows.length.toLocaleString()}</div>
                  <div className="text-[9px] font-bold text-slate-500 uppercase mt-0.5">Total Rows</div>
                </div>
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl">
                  <div className="text-base font-black text-emerald-700">+{newEmployeesToCreate.length.toLocaleString()}</div>
                  <div className="text-[9px] font-bold text-emerald-800 uppercase mt-0.5">New to Add</div>
                </div>
                <div className="p-2.5 bg-sky-50 border border-sky-200 rounded-xl">
                  <div className="text-base font-black text-sky-700">{existingEmployeesToUpdate.length.toLocaleString()}</div>
                  <div className="text-[9px] font-bold text-sky-800 uppercase mt-0.5">To Update</div>
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
                  <div className="text-base font-black text-slate-700">{skippedCount.toLocaleString()}</div>
                  <div className="text-[9px] font-bold text-slate-800 uppercase mt-0.5">Skipped</div>
                </div>
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl">
                  <div className="text-base font-black text-rose-700">{rowErrors.length.toLocaleString()}</div>
                  <div className="text-[9px] font-bold text-rose-800 uppercase mt-0.5">Invalid Rows</div>
                </div>
              </div>

              {/* Validation Errors Box if errors exist */}
              {rowErrors.length > 0 && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between font-bold text-rose-900">
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      <span>{rowErrors.length} invalid rows found (will be skipped)</span>
                    </span>
                    <button
                      type="button"
                      onClick={handleDownloadErrors}
                      className="text-xs font-bold text-rose-800 underline flex items-center gap-1 hover:text-rose-900"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Error Report (.xlsx)</span>
                    </button>
                  </div>
                  <div className="max-h-24 overflow-y-auto space-y-1 text-[11px] text-rose-900 pr-1">
                    {rowErrors.slice(0, 5).map((err, i) => (
                      <div key={i} className="bg-white/80 p-1.5 rounded-lg border border-rose-200 flex items-center justify-between">
                        <span>Row #{err.rowNumber} [{err.field}]: {err.reason}</span>
                        {err.suggestedAction && <span className="text-[10px] text-rose-700 italic">{err.suggestedAction}</span>}
                      </div>
                    ))}
                    {rowErrors.length > 5 && (
                      <div className="text-slate-500 italic text-[10px] text-center pt-0.5">
                        + {rowErrors.length - 5} more errors in downloaded report
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Interactive Preview Table (Showing first 20 rows) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-slate-800 text-xs">
                    Roster Preview (Showing first {Math.min(20, previewRows.length)} rows):
                  </div>
                  <span className="text-[10px] text-slate-500">
                    Mode: <strong className="uppercase">{importMode.replace(/_/g, ' ')}</strong>
                  </span>
                </div>

                <div className="border border-slate-200 rounded-xl overflow-hidden max-h-52 overflow-y-auto">
                  <table className="w-full text-left text-[11px]">
                    <thead className="bg-slate-100 text-slate-700 font-bold sticky top-0">
                      <tr>
                        <th className="p-2">#</th>
                        <th className="p-2">Action</th>
                        <th className="p-2">Employee ID</th>
                        <th className="p-2">Full Name</th>
                        <th className="p-2">Phone</th>
                        <th className="p-2">Department</th>
                        <th className="p-2">Designation</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {previewRows.map((r, i) => (
                        <tr key={i} className={r.action === 'ERROR' ? 'bg-rose-50/50' : 'hover:bg-slate-50'}>
                          <td className="p-2 font-mono text-slate-400">{r.rowNum}</td>
                          <td className="p-2">
                            <span
                              className={`text-[9px] font-black px-1.5 py-0.5 rounded-md uppercase ${
                                r.action === 'CREATE'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : r.action === 'UPDATE'
                                  ? 'bg-sky-100 text-sky-800'
                                  : r.action === 'SKIP'
                                  ? 'bg-slate-200 text-slate-700'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {r.action}
                            </span>
                          </td>
                          <td className="p-2 font-mono font-bold text-slate-900">{r.code}</td>
                          <td className="p-2 font-semibold text-slate-800">{r.name}</td>
                          <td className="p-2 text-slate-600">{r.phone || '--'}</td>
                          <td className="p-2 text-slate-600">{r.department || '--'}</td>
                          <td className="p-2 text-slate-600">{r.designation || '--'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Navigation Action Buttons */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  &larr; Back to Mapping
                </button>
                <button
                  type="button"
                  disabled={newEmployeesToCreate.length === 0 && existingEmployeesToUpdate.length === 0}
                  onClick={handleExecuteImport}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>
                    Confirm & Import {(newEmployeesToCreate.length + existingEmployeesToUpdate.length).toLocaleString()} Employees
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* STEP 4: IMPORT PROGRESS & SUCCESS COMPLETION                 */}
          {/* ============================================================ */}
          {step === 4 && (
            <div className="space-y-5 text-center py-4">
              {isImporting ? (
                <div className="space-y-4 max-w-md mx-auto">
                  <div className="w-12 h-12 rounded-2xl bg-sky-100 text-sky-600 flex items-center justify-center mx-auto">
                    <RefreshCw className="w-6 h-6 animate-spin" />
                  </div>
                  <div>
                    <h4 className="font-bold text-base text-slate-900">Importing Employees...</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Writing batches to Firestore ({importProgress.processed.toLocaleString()} / {importProgress.total.toLocaleString()})
                    </p>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden shadow-inner">
                    <div
                      className="bg-sky-600 h-full rounded-full transition-all duration-150"
                      style={{ width: `${importProgress.percentage}%` }}
                    />
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-xs">
                    <div className="p-2 bg-slate-50 rounded-xl border border-slate-200">
                      <div className="font-mono font-black text-slate-800">{importProgress.processed}</div>
                      <div className="text-[10px] text-slate-400">Processed</div>
                    </div>
                    <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-200">
                      <div className="font-mono font-black text-emerald-700">+{importProgress.created}</div>
                      <div className="text-[10px] text-emerald-800">Created</div>
                    </div>
                    <div className="p-2 bg-sky-50 rounded-xl border border-sky-200">
                      <div className="font-mono font-black text-sky-700">{importProgress.updated}</div>
                      <div className="text-[10px] text-sky-800">Updated</div>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-xl border border-slate-200">
                      <div className="font-mono font-black text-slate-700">{importProgress.skipped}</div>
                      <div className="text-[10px] text-slate-400">Skipped</div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 max-w-md mx-auto animate-in zoom-in-95">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>

                  <div>
                    <h4 className="font-bold text-lg text-slate-900">Import Complete!</h4>
                    <p className="text-xs text-slate-500 mt-1">
                      {summaryStats.created + summaryStats.updated} employees committed to your organization.
                    </p>
                  </div>

                  {/* Summary Breakdown Card */}
                  <div className="grid grid-cols-4 gap-2 text-center text-xs">
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
                      <div className="text-lg font-black text-emerald-700">+{summaryStats.created}</div>
                      <div className="text-[10px] font-bold text-emerald-800 uppercase mt-0.5">Created</div>
                    </div>
                    <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl">
                      <div className="text-lg font-black text-sky-700">{summaryStats.updated}</div>
                      <div className="text-[10px] font-bold text-sky-800 uppercase mt-0.5">Updated</div>
                    </div>
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                      <div className="text-lg font-black text-slate-700">{summaryStats.skipped}</div>
                      <div className="text-[10px] font-bold text-slate-800 uppercase mt-0.5">Skipped</div>
                    </div>
                    <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl">
                      <div className="text-lg font-black text-rose-700">{summaryStats.errors}</div>
                      <div className="text-[10px] font-bold text-rose-800 uppercase mt-0.5">Errors</div>
                    </div>
                  </div>

                  {summaryStats.errors > 0 && (
                    <button
                      type="button"
                      onClick={handleDownloadErrors}
                      className="w-full py-2 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Error Report ({summaryStats.errors} rows)</span>
                    </button>
                  )}

                  <div className="pt-3 flex gap-2 justify-center">
                    {onOpenHistory && (
                      <button
                        type="button"
                        onClick={onOpenHistory}
                        className="px-4 py-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                      >
                        <History className="w-3.5 h-3.5" />
                        <span>View Import Log</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-6 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                    >
                      Done
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
