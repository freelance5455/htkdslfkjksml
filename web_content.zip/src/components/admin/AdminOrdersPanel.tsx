import React, { useState } from 'react';
import {
  Search,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  XCircle,
  Clock,
  Truck,
  MapPin,
} from 'lucide-react';
import { collection, doc, getDocs, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useStoreData } from '../../context/StoreDataContext';
import { Order, OrderItem, OrderStatus, PaymentStatus } from '../../types/store';
import { formatCurrency, formatDateTime } from '../../lib/formatters';

interface AdminOrdersPanelProps {
  orders: Order[];
  mode: 'manage' | 'history';
}

const ORDER_STATUSES: OrderStatus[] = [
  'Pending',
  'Confirmed',
  'Processing',
  'Shipped',
  'Delivered',
  'Cancelled',
];

export function AdminOrdersPanel({ orders, mode }: AdminOrdersPanelProps) {
  const { notify } = useStoreData();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [historyTab, setHistoryTab] = useState<'all' | 'completed' | 'cancelled'>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [orderItemsMap, setOrderItemsMap] = useState<Record<string, OrderItem[]>>({});

  const handleStatusChange = async (order: Order, nextStatus: OrderStatus) => {
    try {
      const nextPayment: PaymentStatus =
        nextStatus === 'Delivered'
          ? 'Paid'
          : nextStatus === 'Cancelled' && order.paymentStatus === 'Paid'
          ? 'Refunded'
          : order.paymentStatus;

      await updateDoc(doc(db, 'orders', order.id), {
        status: nextStatus,
        paymentStatus: nextPayment,
        updatedAt: serverTimestamp(),
      });
      notify(`Order ${order.orderNumber} updated to ${nextStatus}.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${order.id}`);
    }
  };

  const toggleOrderItems = async (orderId: string) => {
    if (expandedOrderId === orderId) {
      setExpandedOrderId(null);
      return;
    }
    setExpandedOrderId(orderId);
    if (!orderItemsMap[orderId]) {
      try {
        const snap = await getDocs(collection(db, 'orders', orderId, 'items'));
        const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as OrderItem));
        setOrderItemsMap((prev) => ({ ...prev, [orderId]: list }));
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, `orders/${orderId}/items`);
      }
    }
  };

  const filteredOrders = orders.filter((order) => {
    if (mode === 'history') {
      if (historyTab === 'completed' && order.status !== 'Delivered') return false;
      if (historyTab === 'cancelled' && order.status !== 'Cancelled') return false;
    }

    if (statusFilter !== 'ALL' && order.status !== statusFilter) return false;

    const q = searchQuery.trim().toLowerCase();
    if (q) {
      const hay = `${order.orderNumber} ${order.customerName} ${order.customerEmail} ${order.phone} ${order.location || ''} ${order.address} ${order.city} ${order.primaryProductName}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }

    if (dateFrom || dateTo) {
      const d = order.createdAt?.toDate();
      if (!d) return false;
      if (dateFrom) {
        const from = new Date(`${dateFrom}T00:00:00`);
        if (d < from) return false;
      }
      if (dateTo) {
        const to = new Date(`${dateTo}T23:59:59`);
        if (d > to) return false;
      }
    }

    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-[#0A0A0A]">
            {mode === 'history' ? 'Order History Archive' : 'Manage Live Orders'}
          </h2>
          <p className="text-xs text-neutral-500 mt-1">
            {mode === 'history'
              ? 'Audit all completed, cancelled, and historical customer orders with date and status filters.'
              : 'Real-time order stream synced with Firestore. Update order statuses to notify customers instantly.'}
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search order ID, customer, product..."
            className="w-full pl-10 pr-4 py-2 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
          />
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-neutral-200 p-4 flex flex-wrap items-center justify-between gap-4">
        {mode === 'history' ? (
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setHistoryTab('all')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-full cursor-pointer ${
                historyTab === 'all' ? 'bg-[#0A0A0A] text-white' : 'bg-neutral-100 text-neutral-700'
              }`}
            >
              All Orders
            </button>
            <button
              type="button"
              onClick={() => setHistoryTab('completed')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-full cursor-pointer ${
                historyTab === 'completed'
                  ? 'bg-[#0A0A0A] text-white'
                  : 'bg-neutral-100 text-neutral-700'
              }`}
            >
              Completed
            </button>
            <button
              type="button"
              onClick={() => setHistoryTab('cancelled')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-full cursor-pointer ${
                historyTab === 'cancelled'
                  ? 'bg-[#0A0A0A] text-white'
                  : 'bg-neutral-100 text-neutral-700'
              }`}
            >
              Cancelled
            </button>
          </div>
        ) : (
          <div className="text-xs font-medium text-neutral-600">
            Showing <span className="font-semibold text-[#0A0A0A] tabular-nums">{filteredOrders.length}</span> orders
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
          >
            <option value="ALL">All Statuses</option>
            {ORDER_STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {mode === 'history' && (
            <>
              <input
                type="date"
                aria-label="Filter from date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="px-2.5 py-1.5 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
              />
              <input
                type="date"
                aria-label="Filter to date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="px-2.5 py-1.5 text-xs border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none"
              />
            </>
          )}
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white border border-neutral-200 overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[960px]">
          <thead>
            <tr className="border-b border-neutral-200 bg-neutral-50 text-[11px] uppercase tracking-wider text-neutral-500">
              <th className="py-3.5 px-4 font-semibold">Order ID & Date</th>
              <th className="py-3.5 px-4 font-semibold">Customer & Address</th>
              <th className="py-3.5 px-4 font-semibold">Product</th>
              <th className="py-3.5 px-4 font-semibold">Qty</th>
              <th className="py-3.5 px-4 font-semibold">Total & Payment</th>
              <th className="py-3.5 px-4 font-semibold">Order Status</th>
              <th className="py-3.5 px-4 font-semibold text-right">Items</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 text-xs">
            {filteredOrders.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-neutral-500">
                  No orders match the current filters.
                </td>
              </tr>
            ) : (
              filteredOrders.map((order) => {
                const isExpanded = expandedOrderId === order.id;
                const items = orderItemsMap[order.id] || [];

                return (
                  <React.Fragment key={order.id}>
                    <tr className="hover:bg-neutral-50/70 align-top">
                      <td className="py-4 px-4">
                        <div className="font-mono font-semibold text-[#0A0A0A]">
                          {order.orderNumber}
                        </div>
                        <div className="text-[11px] text-neutral-500 mt-1">
                          {formatDateTime(order.createdAt)}
                        </div>
                      </td>
                      <td className="py-4 px-4 max-w-[260px]">
                        <div className="font-semibold text-[#0A0A0A]">
                          {order.customerName}
                        </div>
                        <div className="text-neutral-700 mt-0.5 font-medium">{order.phone}</div>
                        {order.location && (
                          <div className="text-[#0A0A0A] mt-0.5 flex items-center gap-1 text-[11px] font-medium">
                            <MapPin className="w-3 h-3 shrink-0" />
                            <span className="truncate">{order.location}</span>
                          </div>
                        )}
                        <div className="text-neutral-500 mt-0.5 line-clamp-2">
                          {order.address}, {order.city} {order.pinCode}
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={order.primaryProductImage}
                            alt={order.primaryProductName}
                            referrerPolicy="no-referrer"
                            className="w-10 h-13 object-cover bg-neutral-100 shrink-0"
                          />
                          <div className="min-w-0">
                            <p className="font-medium text-[#0A0A0A] max-w-[180px] truncate">
                              {order.primaryProductName}
                            </p>
                            {order.itemCount > 1 && (
                              <p className="text-[11px] text-neutral-500">
                                +{order.itemCount - 1} additional item(s)
                              </p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-4 tabular-nums font-semibold">
                        {order.totalQuantity}
                      </td>
                      <td className="py-4 px-4">
                        <div className="font-semibold text-[#0A0A0A] tabular-nums">
                          {formatCurrency(order.totalAmount)}
                        </div>
                        <div className="text-[11px] text-neutral-500 mt-0.5">
                          {order.paymentMethod} · {order.paymentStatus}
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          {order.status === 'Delivered' ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                          ) : order.status === 'Cancelled' ? (
                            <XCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                          ) : order.status === 'Shipped' ? (
                            <Truck className="w-3.5 h-3.5 text-[#0A0A0A] shrink-0" />
                          ) : (
                            <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                          )}
                          <select
                            aria-label={`Update status for ${order.orderNumber}`}
                            value={order.status}
                            onChange={(e) =>
                              handleStatusChange(order, e.target.value as OrderStatus)
                            }
                            className="px-2.5 py-1.5 text-xs font-medium border border-neutral-300 bg-white focus:border-[#0A0A0A] focus:outline-none cursor-pointer"
                          >
                            {ORDER_STATUSES.map((st) => (
                              <option key={st} value={st}>
                                {st}
                              </option>
                            ))}
                          </select>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => toggleOrderItems(order.id)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 border border-neutral-300 rounded-full text-[11px] font-medium hover:bg-neutral-100 cursor-pointer"
                        >
                          <span>{isExpanded ? 'Hide' : 'View'}</span>
                          {isExpanded ? (
                            <ChevronUp className="w-3 h-3" />
                          ) : (
                            <ChevronDown className="w-3 h-3" />
                          )}
                        </button>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="bg-neutral-50/80">
                        <td colSpan={7} className="px-6 py-4 space-y-3">
                          <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs bg-white border border-neutral-200 px-3.5 py-2.5">
                            <span><strong>Name:</strong> {order.customerName}</span>
                            <span><strong>Phone:</strong> {order.phone}</span>
                            {order.location && <span><strong>Location:</strong> {order.location}</span>}
                            <span><strong>Address:</strong> {order.address}, {order.city} {order.pinCode}</span>
                          </div>
                          <div className="text-xs font-semibold text-[#0A0A0A]">
                            Line Items for {order.orderNumber}
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                            {items.length === 0 ? (
                              <span className="text-neutral-400">Loading items...</span>
                            ) : (
                              items.map((item) => (
                                <div
                                  key={item.id}
                                  className="flex items-center justify-between gap-3 bg-white border border-neutral-200 p-2.5"
                                >
                                  <div className="flex items-center gap-2.5 min-w-0">
                                    <img
                                      src={item.productImage}
                                      alt={item.productName}
                                      referrerPolicy="no-referrer"
                                      className="w-9 h-12 object-cover bg-neutral-100 shrink-0"
                                    />
                                    <div className="min-w-0">
                                      <p className="font-medium truncate">{item.productName}</p>
                                      <p className="text-neutral-500">
                                        {item.selectedSize} · {item.selectedColor} · x
                                        {item.quantity}
                                      </p>
                                    </div>
                                  </div>
                                  <span className="font-semibold tabular-nums shrink-0">
                                    {formatCurrency(item.lineTotal)}
                                  </span>
                                </div>
                              ))
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
