import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext.tsx';
import {
  Ticket,
  Search,
  RefreshCw,
  Send,
  MessageSquare,
  Clock,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Shield,
  Trash2,
  Paperclip,
  X,
  User,
  History
} from 'lucide-react';
import type { SupportTicket, TicketStatus, TicketMessage } from '../../types/index.ts';

export const AdminTicketManagement: React.FC = () => {
  const {
    adminTickets,
    fetchAdminTickets,
    updateAdminTicket,
    sendAdminTicketReply,
    deleteAdminTicket
  } = useData();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Pending' | 'In Progress' | 'Resolved'>('all');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

  const [activeTicket, setActiveTicket] = useState<SupportTicket | null>(null);
  const [replyMessage, setReplyMessage] = useState('');
  const [replyStatus, setReplyStatus] = useState<TicketStatus | ''>('');
  const [sendingReply, setSendingReply] = useState(false);
  const [internalNotesText, setInternalNotesText] = useState('');
  const [savingNotes, setSavingNotes] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMsg({ text, type });
    setTimeout(() => setToastMsg(null), 3000);
  };

  useEffect(() => {
    fetchAdminTickets();
  }, [fetchAdminTickets]);

  useEffect(() => {
    if (selectedTicketId) {
      const match = adminTickets.find((t) => t.id === selectedTicketId || t.ticketNumber === selectedTicketId);
      if (match) {
        setActiveTicket(match);
        setInternalNotesText(match.internalNotes || '');
      }
    } else if (adminTickets.length > 0 && !activeTicket) {
      setSelectedTicketId(adminTickets[0].id);
      setActiveTicket(adminTickets[0]);
      setInternalNotesText(adminTickets[0].internalNotes || '');
    }
  }, [adminTickets, selectedTicketId]);

  const normalizeTicketStatus = (status: string): 'Pending' | 'In Progress' | 'Resolved' => {
    if (status === 'In Progress' || status === 'Waiting for Client') return 'In Progress';
    if (status === 'Resolved' || status === 'Completed' || status === 'Closed') return 'Resolved';
    return 'Pending';
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
    showToast(`Copied ${fieldName} to clipboard`);
  };

  const filteredTickets = adminTickets.filter((t) => {
    const normalized = normalizeTicketStatus(t.status);
    if (statusFilter !== 'all' && normalized !== statusFilter) return false;
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchesNum = (t.ticketNumber || '').toLowerCase().includes(term);
      const matchesCubes = (t.cubesId || t.username || '').toLowerCase().includes(term);
      const matchesDetails = (t.requestDetails || '').toLowerCase().includes(term);
      const matchesService = (t.serviceProductName || '').toLowerCase().includes(term);
      return matchesNum || matchesCubes || matchesDetails || matchesService;
    }
    return true;
  });

  const pendingCount = adminTickets.filter((t) => normalizeTicketStatus(t.status) === 'Pending').length;
  const inProgressCount = adminTickets.filter((t) => normalizeTicketStatus(t.status) === 'In Progress').length;
  const resolvedCount = adminTickets.filter((t) => normalizeTicketStatus(t.status) === 'Resolved').length;

  const handleStatusChange = async (newStatus: TicketStatus) => {
    if (!activeTicket) return;
    const res = await updateAdminTicket(activeTicket.id, { status: newStatus });
    if (res.success) {
      showToast(`Ticket status changed to ${newStatus}`);
    } else {
      showToast(res.error || 'Failed to update status', 'error');
    }
  };

  const handleSaveInternalNotes = async () => {
    if (!activeTicket) return;
    setSavingNotes(true);
    const res = await updateAdminTicket(activeTicket.id, { internalNotes: internalNotesText });
    setSavingNotes(false);
    if (res.success) {
      showToast('Internal notes saved');
    } else {
      showToast(res.error || 'Failed to save notes', 'error');
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTicket || !replyMessage.trim()) return;

    setSendingReply(true);
    const res = await sendAdminTicketReply(
      activeTicket.id,
      replyMessage.trim(),
      [],
      replyStatus ? (replyStatus as TicketStatus) : undefined
    );
    setSendingReply(false);

    if (res.success) {
      setReplyMessage('');
      setReplyStatus('');
      showToast(`Reply sent to ${activeTicket.cubesId || activeTicket.username}`);
    } else {
      showToast(res.error || 'Failed to post reply', 'error');
    }
  };

  const handleDelete = async () => {
    if (!activeTicket) return;
    const res = await deleteAdminTicket(activeTicket.id);
    setDeleteConfirmOpen(false);
    if (res.success) {
      setSelectedTicketId(null);
      setActiveTicket(null);
      showToast('Ticket deleted');
    } else {
      showToast(res.error || 'Failed to delete ticket', 'error');
    }
  };

  const getStatusBadge = (status: string) => {
    const normalized = normalizeTicketStatus(status);
    if (normalized === 'Resolved') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-mono font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
          <CheckCircle2 className="w-3 h-3" />
          Resolved
        </span>
      );
    }
    if (normalized === 'In Progress') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-mono font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          In Progress
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-mono font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
        Pending
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {toastMsg && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl shadow-2xl border text-xs font-mono font-bold ${
            toastMsg.type === 'success'
              ? 'bg-[#061825] border-cyan-400 text-cyan-300'
              : 'bg-rose-950 border-rose-500 text-rose-200'
          }`}
        >
          {toastMsg.type === 'success' ? <Check className="w-4 h-4 text-cyan-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
          <span>{toastMsg.text}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Support Tickets & Talk With Founders</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            View incoming client requests identified by their unique Cubes IDs (Cubes-1, Cubes-2, etc.), reply in real time, and manage statuses.
          </p>
        </div>

        <button
          onClick={fetchAdminTickets}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-200 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
          <span>Sync Tickets</span>
        </button>
      </div>

      {/* Summary Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <button
          type="button"
          onClick={() => setStatusFilter('all')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-slate-900 border-cyan-500/50'
              : 'bg-[#060f1d] border-slate-800/90 hover:border-slate-700'
          }`}
        >
          <div className="text-[11px] font-mono uppercase text-slate-400">All Tickets</div>
          <div className="text-2xl font-bold text-white mt-1">{adminTickets.length}</div>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('Pending')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Pending'
              ? 'bg-amber-950/30 border-amber-500/50'
              : 'bg-[#060f1d] border-slate-800/90 hover:border-slate-700'
          }`}
        >
          <div className="text-[11px] font-mono uppercase text-amber-400">Pending</div>
          <div className="text-2xl font-bold text-amber-300 mt-1">{pendingCount}</div>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('In Progress')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            statusFilter === 'In Progress'
              ? 'bg-cyan-950/30 border-cyan-500/50'
              : 'bg-[#060f1d] border-slate-800/90 hover:border-slate-700'
          }`}
        >
          <div className="text-[11px] font-mono uppercase text-cyan-400">In Progress</div>
          <div className="text-2xl font-bold text-cyan-300 mt-1">{inProgressCount}</div>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('Resolved')}
          className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
            statusFilter === 'Resolved'
              ? 'bg-emerald-950/30 border-emerald-500/50'
              : 'bg-[#060f1d] border-slate-800/90 hover:border-slate-700'
          }`}
        >
          <div className="text-[11px] font-mono uppercase text-emerald-400">Resolved</div>
          <div className="text-2xl font-bold text-emerald-300 mt-1">{resolvedCount}</div>
        </button>
      </div>

      {/* Search & Status Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-[#060f1d] border border-slate-800/90">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by Client ID (e.g. Cubes-1), Ticket # (CUBIX-0001), or request details..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
          />
        </div>

        <div className="flex items-center gap-1.5">
          {(['all', 'Pending', 'In Progress', 'Resolved'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                statusFilter === st
                  ? 'bg-cyan-400 text-slate-950 font-bold'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-300'
              }`}
            >
              {st === 'all' ? 'All' : st}
            </button>
          ))}
        </div>
      </div>

      {/* Master-Detail Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left List */}
        <div className={`space-y-2.5 ${activeTicket ? 'lg:col-span-5' : 'lg:col-span-12'}`}>
          {filteredTickets.length === 0 ? (
            <div className="text-center py-12 rounded-xl border border-slate-800/90 bg-[#060f1d] p-8">
              <Ticket className="w-8 h-8 text-slate-600 mx-auto mb-2.5" />
              <div className="text-sm font-bold text-white mb-1">No Support Tickets Found</div>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                When clients click "Talk With Founders" inside the AI Assistant page, their tickets and Cubes IDs appear here automatically.
              </p>
            </div>
          ) : (
            filteredTickets.map((t) => {
              const isSelected = activeTicket?.id === t.id;
              const clientCubesId = t.cubesId || t.username || 'Cubes-1';
              return (
                <div
                  key={t.id}
                  onClick={() => {
                    setSelectedTicketId(t.id);
                    setActiveTicket(t);
                    setInternalNotesText(t.internalNotes || '');
                  }}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-400/60 shadow-md'
                      : 'bg-[#060f1d] border-slate-800/90 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-bold">
                        {clientCubesId}
                      </span>
                      <span className="font-mono text-xs text-slate-400">{t.ticketNumber}</span>
                    </div>
                    {getStatusBadge(t.status)}
                  </div>

                  <p className="text-xs text-slate-200 line-clamp-2 mb-3 leading-relaxed">
                    {t.requestDetails}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
                    <span>{t.serviceProductName || 'Talk With Founders'}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(t.createdAt).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Detail Panel */}
        {activeTicket && (
          <div className="lg:col-span-7 rounded-xl border border-slate-800/90 bg-[#060f1d] p-5 sm:p-6 space-y-5">
            {/* Ticket Top Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-1 rounded-md bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-mono text-sm font-bold">
                    {activeTicket.cubesId || activeTicket.username || 'Cubes-1'}
                  </span>
                  <span className="text-sm font-mono font-bold text-white">{activeTicket.ticketNumber}</span>
                  {getStatusBadge(activeTicket.status)}
                </div>
                <div className="text-xs text-slate-400 mt-1.5 font-mono">
                  Submitted: {new Date(activeTicket.createdAt).toLocaleString()}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={normalizeTicketStatus(activeTicket.status)}
                  onChange={(e) => handleStatusChange(e.target.value as TicketStatus)}
                  className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs font-semibold text-white focus:outline-none focus:border-cyan-400 cursor-pointer"
                >
                  <option value="Pending">Status: Pending</option>
                  <option value="In Progress">Status: In Progress</option>
                  <option value="Resolved">Status: Resolved</option>
                </select>

                <button
                  type="button"
                  onClick={() => setDeleteConfirmOpen(true)}
                  className="p-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-colors cursor-pointer"
                  title="Delete Ticket"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Client Identity & Submission Info */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/90 text-xs">
              <div>
                <span className="text-slate-500 text-[10px] font-mono uppercase block">Client Identity</span>
                <div className="flex items-center gap-1.5 text-cyan-300 font-mono font-bold mt-0.5">
                  <User className="w-3.5 h-3.5" />
                  <span>{activeTicket.cubesId || activeTicket.username}</span>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(activeTicket.cubesId || activeTicket.username, 'Client ID')}
                    className="text-slate-400 hover:text-white cursor-pointer"
                  >
                    {copiedField === 'Client ID' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              </div>

              <div>
                <span className="text-slate-500 text-[10px] font-mono uppercase block">Request Type</span>
                <div className="text-white font-semibold mt-0.5">
                  {activeTicket.serviceProductName || 'Talk With Founders'}
                </div>
              </div>

              <div>
                <span className="text-slate-500 text-[10px] font-mono uppercase block">Last Updated</span>
                <div className="text-slate-300 font-mono mt-0.5">
                  {new Date(activeTicket.updatedAt || activeTicket.createdAt).toLocaleString()}
                </div>
              </div>
            </div>

            {/* Request Details */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
              <div className="text-[11px] font-mono uppercase text-cyan-400 font-semibold">
                Initial Request Details
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                {activeTicket.requestDetails}
              </p>
              {Array.isArray(activeTicket.attachments) && activeTicket.attachments.length > 0 && (
                <div className="pt-2 flex flex-wrap gap-2">
                  {activeTicket.attachments.map((att) => (
                    <a
                      key={att.id}
                      href={att.url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-xs text-cyan-300 hover:text-white"
                    >
                      <Paperclip className="w-3 h-3" />
                      <span>{att.name}</span>
                    </a>
                  ))}
                </div>
              )}
            </div>

            {/* Conversation Thread */}
            <div className="space-y-2.5">
              <div className="text-xs font-mono uppercase text-slate-400 font-semibold flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
                <span>Conversation with {activeTicket.cubesId || activeTicket.username}</span>
              </div>

              <div className="space-y-3 max-h-[260px] overflow-y-auto p-3.5 rounded-xl bg-slate-950 border border-slate-800/90">
                {(activeTicket.conversation || []).map((msg: TicketMessage) => {
                  const isAdmin = msg.sender === 'admin';
                  return (
                    <div key={msg.id} className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'}`}>
                      <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 mb-1">
                        <span className={isAdmin ? 'text-cyan-300 font-bold' : 'text-emerald-300 font-bold'}>
                          {isAdmin ? `${msg.senderName} (Founder)` : msg.senderName}
                        </span>
                        <span>•</span>
                        <span>{new Date(msg.createdAt).toLocaleString()}</span>
                      </div>
                      <div
                        className={`max-w-[85%] p-3 rounded-xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                          isAdmin
                            ? 'bg-cyan-500/15 border border-cyan-500/30 text-white'
                            : 'bg-slate-900 border border-slate-800 text-slate-200'
                        }`}
                      >
                        {msg.message}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Reply Form */}
            <form onSubmit={handleSendReply} className="space-y-3 pt-2 border-t border-slate-800">
              <textarea
                rows={3}
                value={replyMessage}
                onChange={(e) => setReplyMessage(e.target.value)}
                placeholder={`Write a reply to ${activeTicket.cubesId || activeTicket.username}...`}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Update status on reply:</span>
                  <select
                    value={replyStatus}
                    onChange={(e) => setReplyStatus(e.target.value as TicketStatus | '')}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200"
                  >
                    <option value="">Keep Current Status</option>
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={sendingReply || !replyMessage.trim()}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-bold text-xs sm:text-sm cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{sendingReply ? 'Sending...' : 'Send Reply'}</span>
                </button>
              </div>
            </form>

            {/* Internal Admin Notes & Ticket Status History */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono uppercase text-amber-400 flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5" />
                    <span>Internal Notes</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleSaveInternalNotes}
                    disabled={savingNotes}
                    className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 font-medium cursor-pointer"
                  >
                    {savingNotes ? 'Saving...' : 'Save Note'}
                  </button>
                </div>
                <textarea
                  rows={2}
                  value={internalNotesText}
                  onChange={(e) => setInternalNotesText(e.target.value)}
                  placeholder="Private admin notes..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2">
                <div className="text-[11px] font-mono uppercase text-slate-400 flex items-center gap-1">
                  <History className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Ticket History</span>
                </div>
                <div className="space-y-1.5 max-h-24 overflow-y-auto text-[11px] text-slate-400 font-mono">
                  {(activeTicket.statusHistory || []).map((h, i) => (
                    <div key={i} className="flex items-center justify-between gap-2">
                      <span className="text-slate-300">{h.status}</span>
                      <span>{new Date(h.changedAt).toLocaleDateString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#061222] border border-rose-500/40 rounded-2xl p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">Delete Support Ticket?</h3>
            <p className="text-xs text-slate-300 mb-5">
              Permanently delete ticket <strong>{activeTicket?.ticketNumber}</strong> ({activeTicket?.cubesId || activeTicket?.username})?
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeleteConfirmOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white cursor-pointer"
              >
                Delete Ticket
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
