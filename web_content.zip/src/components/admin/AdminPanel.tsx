import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  LayoutDashboard,
  Users,
  Gamepad2,
  Palette,
  DollarSign,
  ShieldAlert,
  UserCheck,
  FileText,
  Bell,
  Settings,
  Plus,
  Search,
  CheckCircle,
  AlertTriangle,
  Lock,
  RefreshCw,
  Eye,
  Sliders,
  Filter,
  Download,
  ArrowUpDown,
  Hash,
  ShieldCheck,
  Calendar,
  Check,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Info,
  Copy,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  Clock,
  Activity,
  Database,
  Radio,
  ArrowRightLeft,
  MessageSquare,
  Headphones,
} from 'lucide-react';
import { UserProfile, SkinItem, TransactionRecord, AiCheatIncident, CashierRequest, SupportTicket } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { AuditMonitoringScreen } from './AuditMonitoringScreen';
import { CurrencyTransferSystem } from './CurrencyTransferSystem';
import { CustomerSupportChat } from './CustomerSupportChat';
import { INITIAL_SUPPORT_TICKETS } from '../../utils/defaultSupportTickets';
import {
  subscribeToAuditLogs,
  seedAuditRecordsIfEmpty,
  saveAuditRecordToFirestore,
  checkFirebaseStatus,
  subscribeToSupportTickets,
  seedSupportTicketsIfEmpty,
} from '../../utils/firebaseSync';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateUser: (u: UserProfile) => void;
  cashierRequests?: CashierRequest[];
  onApproveCashierRequest?: (reqId: string) => void;
  onRejectCashierRequest?: (reqId: string) => void;
  supportTickets?: SupportTicket[];
  onUpdateSupportTickets?: (tickets: SupportTicket[]) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  cashierRequests = [],
  onApproveCashierRequest,
  onRejectCashierRequest,
  supportTickets: externalSupportTickets,
  onUpdateSupportTickets: externalOnUpdateSupportTickets,
}) => {
  const [activeTab, setActiveTab] = useState<
    'support' | 'transfers' | 'monitoring' | 'economy' | 'cashier' | 'dashboard' | 'players' | 'rooms' | 'skins' | 'moderation' | 'staff'
  >('support'); // Default to customer support chat to satisfy user request!

  // Customer Support Tickets state
  const [supportTicketsState, setSupportTicketsState] = useState<SupportTicket[]>(
    externalSupportTickets || INITIAL_SUPPORT_TICKETS
  );

  const supportTickets = externalSupportTickets || supportTicketsState;
  const handleUpdateTickets = (updated: SupportTicket[]) => {
    setSupportTicketsState(updated);
    if (externalOnUpdateSupportTickets) {
      externalOnUpdateSupportTickets(updated);
    }
  };

  // Firebase connection state
  const [firebaseConnected, setFirebaseConnected] = useState(true);

  // Search & filter states
  const [playerSearchQuery, setPlayerSearchQuery] = useState('');

  // ==========================================
  // AUDIT LOG & TRANSACTION LEDGER STATES
  // ==========================================
  const [auditSearchQuery, setAuditSearchQuery] = useState('');
  const [currencyFilter, setCurrencyFilter] = useState<'ALL' | 'COINS' | 'GEMS' | 'REAL_USD'>('ALL');
  const [sourceFilter, setSourceFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'>('date_desc');
  const [selectedTxForInspect, setSelectedTxForInspect] = useState<TransactionRecord | null>(null);
  const [isVerifyingHashes, setIsVerifyingHashes] = useState(false);
  const [hashVerificationStatus, setHashVerificationStatus] = useState<string | null>(null);
  const [showNewManualRecordModal, setShowNewManualRecordModal] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [panelToast, setPanelToast] = useState<string | null>(null);

  // Cashier verification state & feedback notice
  const isAuthorizedCashier = ['OWNER', 'ADMIN', 'MANAGER', 'CASHIER'].includes(currentUser.role);
  const [cashierAuditNotice, setCashierAuditNotice] = useState<{
    type: 'success' | 'reject';
    message: string;
    txId: string;
    details: string;
  } | null>(null);

  const showToast = (msg: string) => {
    setPanelToast(msg);
    setTimeout(() => setPanelToast(null), 3000);
  };

  // New manual audit transaction form
  const [manualRecordForm, setManualRecordForm] = useState({
    playerName: currentUser.name,
    playerId: currentUser.id,
    currencyType: 'COINS' as 'COINS' | 'GEMS' | 'REAL_USD',
    amount: 1000,
    sourceMethod: 'ADMIN_OVERRIDE' as TransactionRecord['sourceMethod'],
    referenceNote: 'تعديل تدقيق يدوي من إدارة TABEONA',
  });

  // Comprehensive, detailed initial transactions ledger matching spec
  const [transactions, setTransactions] = useState<TransactionRecord[]>([
    {
      transactionId: 'TX-904815',
      ledgerSequence: 1048,
      playerId: '78453',
      playerName: 'Player 1',
      cashierOrAdminId: 'SYSTEM_AUTOPILOT',
      amount: 500,
      currencyType: 'COINS',
      balanceBefore: 4900,
      balanceAfter: 5400,
      timestamp: '2026-10-09 18:24:10',
      status: 'COMPLETED',
      sourceMethod: 'REWARD',
      referenceNote: 'مكافأة إكمال دورة تدريبية ملكية في طرنيب سوق 41',
      auditHash: 'sha256:7b91d2c00a94e8f15e8b417c8003f901a18c9497e88b22a101f',
      ipAddress: '192.168.1.104',
      sessionId: 'sess_99182ab',
    },
    {
      transactionId: 'TX-904814',
      ledgerSequence: 1047,
      playerId: '78453',
      playerName: 'Player 1',
      cashierOrAdminId: 'STORE_GATEWAY',
      amount: 125,
      currencyType: 'GEMS',
      balanceBefore: 0,
      balanceAfter: 125,
      timestamp: '2026-10-09 17:50:02',
      status: 'COMPLETED',
      sourceMethod: 'PURCHASE',
      referenceNote: 'شراء حزمة الجواهر الزمردية الملكية من متجر المنصة',
      auditHash: 'sha256:4f82a17cb09d318490a12e87c0018b14e91823908f9024c8891',
      ipAddress: '192.168.1.104',
      sessionId: 'sess_99182ab',
    },
    {
      transactionId: 'TX-904813',
      ledgerSequence: 1046,
      playerId: '62194',
      playerName: 'سامي (Sami)',
      cashierOrAdminId: 'MATCH_ENGINE_#24451',
      amount: -500,
      currencyType: 'COINS',
      balanceBefore: 22650,
      balanceAfter: 22150,
      timestamp: '2026-10-09 16:12:44',
      status: 'COMPLETED',
      sourceMethod: 'GAME_FEE',
      referenceNote: 'رسوم حجز مقعد في طاولة طرنيب سوق 41 (الغرفة #24451)',
      auditHash: 'sha256:91d8481ab0c8192736184910283c7198e091283748291084920',
      ipAddress: '185.220.101.5',
      sessionId: 'sess_339108e',
    },
    {
      transactionId: 'TX-904812',
      ledgerSequence: 1045,
      playerId: '49201',
      playerName: 'أحمد (Ahmed)',
      cashierOrAdminId: 'MATCH_ENGINE_#24451',
      amount: -500,
      currencyType: 'COINS',
      balanceBefore: 21600,
      balanceAfter: 21100,
      timestamp: '2026-10-09 16:12:44',
      status: 'COMPLETED',
      sourceMethod: 'GAME_FEE',
      referenceNote: 'رسوم حجز مقعد في طاولة طرنيب سوق 41 (الغرفة #24451)',
      auditHash: 'sha256:1a84920b7c91827491029384756102938475610293847561029',
      ipAddress: '82.102.18.24',
      sessionId: 'sess_882910c',
    },
    {
      transactionId: 'TX-904811',
      ledgerSequence: 1044,
      playerId: '78453',
      playerName: 'Player 1',
      cashierOrAdminId: 'CASHIER_04',
      amount: -250,
      currencyType: 'COINS',
      balanceBefore: 5150,
      balanceAfter: 4900,
      timestamp: '2026-10-09 14:30:15',
      status: 'COMPLETED',
      sourceMethod: 'GIFT',
      referenceNote: 'إرسال هدية كوينز تشجيعية إلى الصديق Queen (Lv 18)',
      auditHash: 'sha256:558291029384756102938475610293847561029384756102938',
      ipAddress: '192.168.1.104',
      sessionId: 'sess_99182ab',
    },
    {
      transactionId: 'TX-904810',
      ledgerSequence: 1043,
      playerId: '38192',
      playerName: 'ليلى (Laila)',
      cashierOrAdminId: 'SYSTEM_AUTOPILOT',
      amount: 2500,
      currencyType: 'COINS',
      balanceBefore: 15400,
      balanceAfter: 17900,
      timestamp: '2026-10-09 13:10:00',
      status: 'COMPLETED',
      sourceMethod: 'TOURNAMENT_PRIZE',
      referenceNote: 'جائزة المركز الثاني في بطولة كأس تركس الأسبوعي الكبرى',
      auditHash: 'sha256:881920394857610293847561029384756102938475610293847',
      ipAddress: '178.62.204.12',
      sessionId: 'sess_551928a',
    },
    {
      transactionId: 'TX-904809',
      ledgerSequence: 1042,
      playerId: '99214',
      playerName: 'Suspicious_Player_99',
      cashierOrAdminId: 'SECURITY_AI_FILTER',
      amount: 15000,
      currencyType: 'COINS',
      balanceBefore: 200,
      balanceAfter: 200,
      timestamp: '2026-10-09 11:05:22',
      status: 'REJECTED',
      sourceMethod: 'CASHIER_TRANSFER',
      referenceNote: 'محاولة إيداع غير نظامية تم إحباطها تلقائيًا لعدم تطابق بصمة التشفير',
      auditHash: 'sha256:338192039485761029384756102938475610293847561029384',
      ipAddress: '45.142.122.9',
      sessionId: 'sess_001928f',
      isSuspicious: true,
      suspicionReason: 'محاولة إيداع غير مصرح بها وتزوير تجزئة المعاملة (Hash Mismatch)',
      riskScore: 96,
    },
    {
      transactionId: 'TX-904806',
      ledgerSequence: 1039,
      playerId: '33108',
      playerName: 'Speed_Bot_Tester',
      cashierOrAdminId: 'MATCH_ENGINE_#24100',
      amount: 4500,
      currencyType: 'COINS',
      balanceBefore: 500,
      balanceAfter: 5000,
      timestamp: '2026-10-09 08:40:11',
      status: 'PENDING',
      sourceMethod: 'GAME_FEE',
      referenceNote: 'اشتباه وجود سكريبت خارجي (Bot Anomaly) ونقلات بفاصل 8 ميلي ثانية',
      auditHash: 'sha256:cc99887766554433221100ffeeddccbbaa11223344556677889',
      ipAddress: '198.51.100.42',
      sessionId: 'sess_bot_script_99',
      isSuspicious: true,
      suspicionReason: 'استجابة برمجية فائقة السرعة وشبهة بوت آلي (Timing Anomaly 8ms)',
      riskScore: 92,
    },
    {
      transactionId: 'TX-904805',
      ledgerSequence: 1038,
      playerId: '88201',
      playerName: 'Collusion_Suspect_88',
      cashierOrAdminId: 'SECURITY_AI_FILTER',
      amount: 8000,
      currencyType: 'COINS',
      balanceBefore: 12000,
      balanceAfter: 4000,
      timestamp: '2026-10-09 07:15:50',
      status: 'REJECTED',
      sourceMethod: 'GIFT',
      referenceNote: 'تحويل سريع متكرر لكامل الرصيد إلى حساب في نفس الشبكة الفرعية',
      auditHash: 'sha256:aa11223344556677889900ffeeddccbbaa11223344556677889',
      ipAddress: '192.168.1.105',
      sessionId: 'sess_collusion_net',
      isSuspicious: true,
      suspicionReason: 'اشتباه تفريغ رصيد وتواطؤ حسابات متعددة (Multi-Account Collusion)',
      riskScore: 88,
    },
    {
      transactionId: 'TX-904808',
      ledgerSequence: 1041,
      playerId: '78453',
      playerName: 'Player 1',
      cashierOrAdminId: 'ADMIN_OVERRIDE_PANEL',
      amount: 1000,
      currencyType: 'COINS',
      balanceBefore: 4150,
      balanceAfter: 5150,
      timestamp: '2026-10-09 10:00:19',
      status: 'COMPLETED',
      sourceMethod: 'ADMIN_OVERRIDE',
      referenceNote: 'تعديل إداري معتمد لتعويض انقطاع اتصال طارئ بالسيرفر',
      auditHash: 'sha256:11223344556677889900aabbccddeeff1122334455667788990',
      ipAddress: '127.0.0.1',
      sessionId: 'sess_admin_root',
    },
    {
      transactionId: 'TX-904807',
      ledgerSequence: 1040,
      playerId: '12093',
      playerName: 'صقر العرب',
      cashierOrAdminId: 'CASHIER_02',
      amount: 50,
      currencyType: 'GEMS',
      balanceBefore: 120,
      balanceAfter: 170,
      timestamp: '2026-10-09 09:15:33',
      status: 'PENDING',
      sourceMethod: 'SUBSCRIPTION',
      referenceNote: 'تجديد باقة VIP الملكية الشهرية قيد التدقيق البنكي',
      auditHash: 'sha256:99887766554433221100ffeeddccbbaa9988776655443322110',
      ipAddress: '194.135.21.90',
      sessionId: 'sess_pending_77',
    },
  ]);

  // Synchronize with Firebase Firestore
  useEffect(() => {
    checkFirebaseStatus().then((res) => {
      setFirebaseConnected(res.connected);
    });

    seedAuditRecordsIfEmpty(transactions);
    seedSupportTicketsIfEmpty(supportTickets);

    const unsubscribeAudit = subscribeToAuditLogs((remoteRecords) => {
      if (remoteRecords && remoteRecords.length > 0) {
        setTransactions(remoteRecords);
      }
    });

    const unsubscribeSupport = subscribeToSupportTickets((remoteTickets) => {
      if (remoteTickets && remoteTickets.length > 0) {
        handleUpdateTickets(remoteTickets);
      }
    });

    return () => {
      if (unsubscribeAudit) unsubscribeAudit();
      if (unsubscribeSupport) unsubscribeSupport();
    };
  }, []);

  const refreshFromFirebase = () => {
    checkFirebaseStatus().then((res) => {
      setFirebaseConnected(res.connected);
      if (res.connected) {
        showToast('✓ تم الاتصال بقاعدة بيانات Firebase وتحديث السجلات لحظياً');
      }
    });
  };

  // Skins Engine State
  const [skinsList, setSkinsList] = useState<SkinItem[]>([
    {
      id: 'skin-1',
      name: 'Royal Emerald v1',
      game: 'طرنيب',
      category: 'card_back',
      rarity: 'Royal',
      priceCoins: 25000,
      previewUrl: '👑 زمرد ملكي مطرز بذهب خالص',
      status: 'PUBLISHED',
      version: 'v1.0',
    },
    {
      id: 'skin-2',
      name: 'Obsidian Velvet v1.2',
      game: 'طرنيب',
      category: 'table_felt',
      rarity: 'Legendary',
      priceCoins: 35000,
      previewUrl: '🖤 فحم مخملي مع خطوط ذهبية',
      status: 'PUBLISHED',
      version: 'v1.2',
    },
    {
      id: 'skin-3',
      name: 'Golden Dynasty Draft',
      game: 'تركس',
      category: 'card_back',
      rarity: 'Epic',
      priceCoins: 18000,
      previewUrl: '✨ مسودة قيد المراجعة',
      status: 'DRAFT',
      version: 'v0.9',
    },
  ]);

  const [newSkinForm, setNewSkinForm] = useState({
    name: '',
    game: 'طرنيب',
    category: 'card_back' as const,
    rarity: 'Royal' as const,
    priceCoins: 20000,
    version: 'v1.0',
  });
  const [showCreateSkinModal, setShowCreateSkinModal] = useState(false);

  // AI & Rule-based Anti-Cheat Cases
  const [cheatCases, setCheatCases] = useState<AiCheatIncident[]>([
    {
      caseId: 'CASE-771',
      playerId: '99214',
      playerName: 'Suspicious_Player_99',
      riskScore: 84,
      flagReason: 'COLLUSION_SUSPICION',
      severity: 'HIGH',
      status: 'INVESTIGATING',
      detectedAt: 'قبل 15 دقيقة',
      matchId: '#24451',
      notes: 'تواطؤ مشبوه في التخلص من أوراق الطرنيب بدون مبرر لصالح الشريك في 3 جولات متتالية.',
    },
    {
      caseId: 'CASE-770',
      playerId: '33108',
      playerName: 'Speed_Bot_Tester',
      riskScore: 92,
      flagReason: 'TIMING_ANOMALY',
      severity: 'CRITICAL',
      status: 'FLAGGED',
      detectedAt: 'قبل 45 دقيقة',
      matchId: '#24100',
      notes: 'استجابة برمجية فائقة السرعة بفاصل 8 ميلي ثانية لكل نقلة (احتمال وجود سكريبت خارجي).',
    },
    {
      caseId: 'CASE-768',
      playerId: '55190',
      playerName: 'Multi_Acc_Abuser',
      riskScore: 78,
      flagReason: 'MULTI_ACCOUNT_LINK',
      severity: 'HIGH',
      status: 'SANCTIONED',
      detectedAt: 'قبل ساعتين',
      matchId: 'N/A',
      notes: 'محاولة تسجيل حساب خامس لنفس الجهاز ومحاولة التحايل على حد مجموعة الحسابات.',
    },
  ]);

  // Staff & Roles (Default Deny Principle)
  const [staffList, setStaffList] = useState([
    { id: 'st1', name: 'Al-Ali (المالك)', role: 'OWNER', permissions: ['ALL_PERMISSIONS'], email: 'owner@tabeona.vip' },
    { id: 'st2', name: 'أحمد الإداري', role: 'ADMIN', permissions: ['MANAGE_PLAYERS', 'VIEW_REPORTS', 'MANAGE_SKINS'], email: 'ahmed.admin@tabeona.vip' },
    { id: 'st3', name: 'سارة الرقابة', role: 'MODERATOR', permissions: ['VIEW_REPORTS', 'MUTE_PLAYERS', 'INSPECT_MATCHES'], email: 'sara.mod@tabeona.vip' },
    { id: 'st4', name: 'كاشير المحفظة 1', role: 'CASHIER', permissions: ['EXECUTE_LEDGER_TRANSFERS'], email: 'cashier1@tabeona.vip' },
  ]);

  if (!isOpen) return null;

  // ==========================================
  // FILTERING & SEARCHING PIPELINE
  // ==========================================
  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((tx) => {
        // Search query: ID, Player name, Player ID, Cashier ID, or notes
        if (auditSearchQuery.trim()) {
          const q = auditSearchQuery.toLowerCase().trim();
          const matches =
            tx.transactionId.toLowerCase().includes(q) ||
            tx.playerName.toLowerCase().includes(q) ||
            tx.playerId.toLowerCase().includes(q) ||
            tx.cashierOrAdminId.toLowerCase().includes(q) ||
            tx.referenceNote.toLowerCase().includes(q);
          if (!matches) return false;
        }

        // Currency filter
        if (currencyFilter !== 'ALL' && tx.currencyType !== currencyFilter) {
          return false;
        }

        // Source method filter
        if (sourceFilter !== 'ALL' && tx.sourceMethod !== sourceFilter) {
          return false;
        }

        // Status filter
        if (statusFilter !== 'ALL' && tx.status !== statusFilter) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date_desc') return b.timestamp.localeCompare(a.timestamp);
        if (sortBy === 'date_asc') return a.timestamp.localeCompare(b.timestamp);
        if (sortBy === 'amount_desc') return Math.abs(b.amount) - Math.abs(a.amount);
        if (sortBy === 'amount_asc') return Math.abs(a.amount) - Math.abs(b.amount);
        return 0;
      });
  }, [transactions, auditSearchQuery, currencyFilter, sourceFilter, statusFilter, sortBy]);

  // Ledger Aggregates
  const stats = useMemo(() => {
    let totalCoinsIn = 0;
    let totalCoinsOut = 0;
    let totalGemsIn = 0;
    let totalUsdIn = 0;
    let totalUsdOut = 0;

    transactions.forEach((tx) => {
      if (tx.status === 'COMPLETED') {
        if (tx.currencyType === 'COINS') {
          if (tx.amount > 0) totalCoinsIn += tx.amount;
          else totalCoinsOut += Math.abs(tx.amount);
        } else if (tx.currencyType === 'GEMS') {
          if (tx.amount > 0) totalGemsIn += tx.amount;
        } else if (tx.currencyType === 'REAL_USD') {
          if (tx.amount > 0) totalUsdIn += tx.amount;
          else totalUsdOut += Math.abs(tx.amount);
        }
      }
    });

    return {
      totalRecords: transactions.length,
      filteredCount: filteredTransactions.length,
      totalCoinsIn,
      totalCoinsOut,
      totalGemsIn,
      totalUsdIn,
      totalUsdOut,
    };
  }, [transactions, filteredTransactions]);

  const suspiciousCount = useMemo(() => {
    return transactions.filter((tx) => {
      if (tx.isSuspicious) return true;
      if (tx.status === 'REJECTED') return true;
      if (tx.playerName.toLowerCase().includes('suspicious') || tx.playerName.toLowerCase().includes('bot')) return true;
      if (tx.referenceNote.includes('غير نظامية') || tx.referenceNote.includes('عدم تطابق')) return true;
      return false;
    }).length;
  }, [transactions]);

  // Cashier Approval with Mandatory Audit Logging
  const handleApproveCashierWithAudit = (req: CashierRequest) => {
    if (!isAuthorizedCashier) {
      showToast('❌ تم حظر الإجراء: يقتصر اعتماد الطلبات على موظفي الكاشير والإدارة المخولين.');
      return;
    }

    soundFX.playVictoryFanfare();

    const txId = `TX-CASHIER-APP-${Math.floor(100000 + Math.random() * 900000)}`;
    const balBefore = req.playerId === currentUser.id ? currentUser.realCashBalance : 2500;
    const balAfter =
      req.type === 'DEPOSIT'
        ? balBefore + req.amount
        : Math.max(0, balBefore - req.amount);

    const auditEntry: TransactionRecord = {
      transactionId: txId,
      ledgerSequence: transactions.length + 1040,
      playerId: req.playerId,
      playerName: req.playerName,
      cashierOrAdminId: `[${currentUser.role}] ${currentUser.name} (ID: ${currentUser.id})`,
      amount: req.type === 'DEPOSIT' ? req.amount : -req.amount,
      currencyType: 'REAL_USD',
      balanceBefore: balBefore,
      balanceAfter: balAfter,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'COMPLETED',
      sourceMethod: 'CASHIER_TRANSFER',
      referenceNote: `[اعتماد كاشير رسمي] تم اعتماد طلب ${
        req.type === 'DEPOSIT' ? 'إيداع نقدي' : 'سحب أرباح'
      } بمبلغ $${req.amount} USD عبر ${req.method} للاعب ${req.playerName} (ID: ${
        req.playerId
      }) بواسطة الموظف المخول: ${currentUser.name} [${currentUser.role}]`,
      auditHash: `sha256:${Array.from({ length: 50 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join('')}`,
      ipAddress: '127.0.0.1 (Verified Cashier Terminal)',
      sessionId: `sess_cashier_auth_${Date.now()}`,
    };

    setTransactions((prev) => [auditEntry, ...prev]);
    saveAuditRecordToFirestore(auditEntry);

    if (onApproveCashierRequest) {
      onApproveCashierRequest(req.id);
    }

    setCashierAuditNotice({
      type: 'success',
      message: `تم اعتماد طلب ${
        req.type === 'DEPOSIT' ? 'الإيداع' : 'السحب'
      } بمبلغ $${req.amount} USD بنجاح وتحويل الرصيد للاعب ${req.playerName}`,
      txId,
      details: `تم توثيق هذه الحركة الإدارية تلقائياً في سجل التدقيق (Audit Log) بالرقم المرجعي ${txId}`,
    });
    showToast(`✓ تم اعتماد الطلب وتوثيق العملية في الـ Audit Log (#${txId})`);
  };

  // Cashier Rejection with Mandatory Audit Logging
  const handleRejectCashierWithAudit = (req: CashierRequest) => {
    if (!isAuthorizedCashier) {
      showToast('❌ تم حظر الإجراء: يقتصر رفض الطلبات على موظفي الكاشير والإدارة المخولين.');
      return;
    }

    soundFX.playButtonClick();

    const txId = `TX-CASHIER-REJ-${Math.floor(100000 + Math.random() * 900000)}`;
    const balCurrent = req.playerId === currentUser.id ? currentUser.realCashBalance : 2500;

    const auditEntry: TransactionRecord = {
      transactionId: txId,
      ledgerSequence: transactions.length + 1040,
      playerId: req.playerId,
      playerName: req.playerName,
      cashierOrAdminId: `[${currentUser.role}] ${currentUser.name} (ID: ${currentUser.id})`,
      amount: req.amount,
      currencyType: 'REAL_USD',
      balanceBefore: balCurrent,
      balanceAfter: balCurrent,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'REJECTED',
      sourceMethod: 'CASHIER_TRANSFER',
      referenceNote: `[رفض كاشير رسمي] تم رفض طلب ${
        req.type === 'DEPOSIT' ? 'إيداع نقدي' : 'سحب أرباح'
      } بمبلغ $${req.amount} USD للاعب ${req.playerName} (ID: ${
        req.playerId
      }) بواسطة الموظف المخول: ${currentUser.name} [${currentUser.role}]. تم إغلاق الطلب دون تحويل.`,
      auditHash: `sha256:${Array.from({ length: 50 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join('')}`,
      ipAddress: '127.0.0.1 (Verified Cashier Terminal)',
      sessionId: `sess_cashier_audit_${Date.now()}`,
    };

    setTransactions((prev) => [auditEntry, ...prev]);
    saveAuditRecordToFirestore(auditEntry);

    if (onRejectCashierRequest) {
      onRejectCashierRequest(req.id);
    }

    setCashierAuditNotice({
      type: 'reject',
      message: `تم رفض الطلب رسميًا للاعب ${req.playerName} ($${req.amount} USD)`,
      txId,
      details: `تم توثيق الرفض وأسبابه إدارياً في سجل التدقيق والمراقبة (Audit Log).`,
    });
    showToast(`✗ تم رفض الطلب وتوثيق الرفض في سجل التدقيق (#${txId})`);
  };

  // Method to add new manual audit record
  const handleCreateManualRecord = (e: React.FormEvent) => {
    e.preventDefault();
    soundFX.playCoin();

    const amt = Number(manualRecordForm.amount);
    const isPlayer = manualRecordForm.playerId === currentUser.id;
    const currentBal =
      manualRecordForm.currencyType === 'COINS' ? currentUser.coins : currentUser.gems;
    const newBal = currentBal + amt;

    const newTx: TransactionRecord = {
      transactionId: `TX-${Math.floor(100000 + Math.random() * 900000)}`,
      ledgerSequence: transactions.length + 1040,
      playerId: manualRecordForm.playerId,
      playerName: manualRecordForm.playerName,
      cashierOrAdminId: `ADMIN_${currentUser.name.toUpperCase()}`,
      amount: amt,
      currencyType: manualRecordForm.currencyType,
      balanceBefore: currentBal,
      balanceAfter: Math.max(0, newBal),
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'COMPLETED',
      sourceMethod: manualRecordForm.sourceMethod,
      referenceNote: manualRecordForm.referenceNote,
      auditHash: `sha256:${Array.from({ length: 50 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      ipAddress: '127.0.0.1 (Admin Session)',
      sessionId: `sess_adm_${Date.now()}`,
    };

    setTransactions([newTx, ...transactions]);
    saveAuditRecordToFirestore(newTx);

    if (isPlayer) {
      if (manualRecordForm.currencyType === 'COINS') {
        onUpdateUser({ ...currentUser, coins: Math.max(0, newBal) });
      } else {
        onUpdateUser({ ...currentUser, gems: Math.max(0, newBal) });
      }
    }

    setShowNewManualRecordModal(false);
  };

  const handleVerifyLedgerIntegrity = () => {
    soundFX.playButtonClick();
    setIsVerifyingHashes(true);
    setHashVerificationStatus(null);

    setTimeout(() => {
      setIsVerifyingHashes(false);
      soundFX.playVictoryFanfare();
      setHashVerificationStatus('✓ تم التحقق بنجاح: جميع البلوكات التشفيرية متطابقة ولا توجد أي تعديلات غير مصرح بها!');
      setTimeout(() => setHashVerificationStatus(null), 4000);
    }, 900);
  };

  const handleExportCSV = () => {
    soundFX.playButtonClick();
    const headers = [
      'Transaction ID',
      'Ledger Sequence',
      'Player ID',
      'Player Name',
      'Amount',
      'Currency',
      'Balance Before',
      'Balance After',
      'Source Method',
      'Issuer / Cashier',
      'Timestamp',
      'Status',
      'Reference Note',
      'Audit Hash',
    ];

    const rows = filteredTransactions.map((tx) => [
      tx.transactionId,
      tx.ledgerSequence || '',
      tx.playerId,
      `"${tx.playerName}"`,
      tx.amount,
      tx.currencyType,
      tx.balanceBefore,
      tx.balanceAfter,
      tx.sourceMethod,
      tx.cashierOrAdminId,
      tx.timestamp,
      tx.status,
      `"${tx.referenceNote.replace(/"/g, '""')}"`,
      tx.auditHash || '',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `TABEONA_AUDIT_LEDGER_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  // Human-friendly labels for Source Methods
  const getSourceBadge = (method: TransactionRecord['sourceMethod']) => {
    switch (method) {
      case 'REWARD':
        return { label: 'مكافأة إنجاز', bg: 'bg-emerald-950 text-emerald-300 border-emerald-600/50', icon: '🎁' };
      case 'PURCHASE':
        return { label: 'شراء من المتجر', bg: 'bg-blue-950 text-blue-300 border-blue-600/50', icon: '💳' };
      case 'GAME_FEE':
        return { label: 'رسوم طاولة', bg: 'bg-amber-950 text-amber-300 border-amber-600/50', icon: '🃏' };
      case 'GIFT':
        return { label: 'هدية لاعب', bg: 'bg-purple-950 text-purple-300 border-purple-600/50', icon: '🤝' };
      case 'CASHIER_TRANSFER':
        return { label: 'تحويل كاشير', bg: 'bg-cyan-950 text-cyan-300 border-cyan-600/50', icon: '💼' };
      case 'ADMIN_OVERRIDE':
        return { label: 'تعديل إداري', bg: 'bg-red-950 text-red-300 border-red-600/50', icon: '⚙️' };
      case 'TOURNAMENT_PRIZE':
        return { label: 'جائزة بطولة', bg: 'bg-amber-900 text-amber-200 border-amber-400/60', icon: '🏆' };
      case 'SUBSCRIPTION':
        return { label: 'اشتراك VIP', bg: 'bg-yellow-950 text-yellow-300 border-yellow-500/50', icon: '👑' };
      default:
        return { label: method, bg: 'bg-gray-900 text-gray-300 border-gray-700', icon: '📜' };
    }
  };

  // Helper for adjusting player coins directly from players tab
  const handleAdjustPlayerCoins = (amt: number) => {
    soundFX.playCoin();
    const newBal = currentUser.coins + amt;
    const tx: TransactionRecord = {
      transactionId: `TX-${Math.floor(100000 + Math.random() * 900000)}`,
      ledgerSequence: transactions.length + 1040,
      playerId: currentUser.id,
      playerName: currentUser.name,
      cashierOrAdminId: 'ADMIN_PANEL_OVERRIDE',
      amount: amt,
      currencyType: 'COINS',
      balanceBefore: currentUser.coins,
      balanceAfter: Math.max(0, newBal),
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'COMPLETED',
      sourceMethod: 'ADMIN_OVERRIDE',
      referenceNote: `تعديل إداري مباشر من لوحة التحكم (${amt > 0 ? '+' : ''}${amt})`,
      auditHash: `sha256:${Array.from({ length: 50 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      ipAddress: '127.0.0.1 (Root Session)',
      sessionId: `sess_root_${Date.now()}`,
    };
    setTransactions([tx, ...transactions]);
    onUpdateUser({
      ...currentUser,
      coins: Math.max(0, newBal),
    });
  };

  const handleCreateSkinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundFX.playButtonClick();
    const created: SkinItem = {
      id: `skin-${Date.now()}`,
      name: `${newSkinForm.name} ${newSkinForm.version}`,
      game: newSkinForm.game,
      category: newSkinForm.category,
      rarity: newSkinForm.rarity,
      priceCoins: Number(newSkinForm.priceCoins),
      previewUrl: `تصميم حصري v${newSkinForm.version}`,
      status: 'PUBLISHED',
      version: newSkinForm.version,
    };
    setSkinsList([created, ...skinsList]);
    setShowCreateSkinModal(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-3 md:p-5">
      <div className="relative w-full max-w-7xl h-[92vh] bg-[#07130c] border-2 border-amber-500/60 rounded-3xl shadow-[0_0_60px_rgba(245,158,11,0.4)] overflow-hidden text-right flex flex-col">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-[#0c2617] via-[#14422b] to-[#0c2617] border-b border-amber-500/40 p-4 flex items-center justify-between shrink-0">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              onClose();
            }}
            className="text-gray-400 hover:text-amber-400 p-1.5 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-black">
              صلاحية: {currentUser.role}
            </span>
            <h2 className="text-xl font-black text-amber-300 flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-amber-400" />
              لوحة التحكم والإدارة المركزية — TABEONA
            </h2>
          </div>
        </div>

        {/* Floating panel toast */}
        {panelToast && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 px-5 py-2 bg-emerald-950/95 border border-emerald-400 text-emerald-200 text-xs font-bold rounded-full shadow-2xl flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>{panelToast}</span>
          </div>
        )}

        {/* Sub-header tabs with Audit Log prominently placed */}
        <div className="flex bg-[#040e08] border-b border-amber-950 overflow-x-auto text-xs font-bold p-1 gap-1 shrink-0">
          {[
            {
              id: 'support',
              label: 'دردشة دعم العملاء (Support Chat) 💬',
              icon: MessageSquare,
              badge: supportTickets.reduce((acc, t) => acc + t.unreadAdminCount, 0) || undefined,
            },
            { id: 'transfers', label: 'تحويل العملات (Transfers Hub) ⚡', icon: ArrowRightLeft, badge: 'جديد' },
            { id: 'monitoring', label: 'شاشة مراقبة الأنشطة الذكية (Audit Monitor)', icon: Activity, badge: suspiciousCount },
            { id: 'economy', label: 'سجل العمليات والتدقيق (Audit Log)', icon: DollarSign, badge: transactions.length },
            { id: 'cashier', label: 'مكتب الكاشير والنقود الحقيقية (Cashier)', icon: Wallet, badge: cashierRequests.filter((r) => r.status === 'PENDING').length },
            { id: 'dashboard', label: 'الرئيسية (Dashboard)', icon: LayoutDashboard },
            { id: 'players', label: 'اللاعبون والحسابات', icon: Users },
            { id: 'rooms', label: 'مراقبة الغرف', icon: Gamepad2 },
            { id: 'skins', label: 'نظام السكنات (Skins)', icon: Palette },
            { id: 'moderation', label: 'كشف الغش والـ AI', icon: ShieldAlert },
            { id: 'staff', label: 'الصلاحيات والـ Staff', icon: UserCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  soundFX.playButtonClick();
                  setActiveTab(tab.id as any);
                }}
                className={`px-3.5 py-2.5 rounded-xl flex items-center gap-2 whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-emerald-950 to-emerald-900 text-amber-300 border border-amber-500/50 shadow-md'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-[#07160e]'
                }`}
              >
                <Icon className="w-4 h-4 text-amber-400" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] border ${
                    tab.id === 'support' && (supportTickets.reduce((acc, t) => acc + t.unreadAdminCount, 0) > 0)
                      ? 'bg-red-500/20 text-red-300 border-red-500/50 font-black animate-pulse'
                      : tab.id === 'monitoring' && suspiciousCount > 0
                      ? 'bg-red-500/20 text-red-300 border-red-500/50 font-black animate-pulse'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Body */}
        <div className="flex-1 p-5 overflow-y-auto bg-gradient-to-b from-[#06120a] to-[#030905]">
          {/* ========================================================
              TAB: CUSTOMER SUPPORT CHAT (دردشة دعم العملاء المباشرة)
             ======================================================== */}
          {activeTab === 'support' && (
            <CustomerSupportChat
              currentUser={currentUser}
              tickets={supportTickets}
              onUpdateTickets={handleUpdateTickets}
              onUpdateCurrentUser={onUpdateUser}
              onAddAuditTransaction={(tx) => setTransactions((prev) => [tx, ...prev])}
              showToast={showToast}
            />
          )}

          {/* ========================================================
              TAB: CURRENCY TRANSFERS SYSTEM (نظام تحويل العملات المركزي)
             ======================================================== */}
          {activeTab === 'transfers' && (
            <CurrencyTransferSystem
              currentUser={currentUser}
              onUpdateUser={onUpdateUser}
              transactions={transactions}
              onUpdateTransactions={setTransactions}
              showToast={showToast}
              onNavigateToAuditLog={(txId) => {
                setActiveTab('economy');
                if (txId) setAuditSearchQuery(txId);
              }}
            />
          )}

          {/* ========================================================
              TAB: AUDIT MONITORING SCREEN (شاشة مراقبة الأنشطة الذكية)
             ======================================================== */}
          {activeTab === 'monitoring' && (
            <AuditMonitoringScreen
              transactions={transactions}
              onUpdateTransactions={setTransactions}
              currentUser={currentUser}
              firebaseConnected={firebaseConnected}
              onRefreshFromFirebase={refreshFromFirebase}
              showToast={showToast}
            />
          )}

          {/* ========================================================
              TAB: AUDIT LOG & TRANSACTION LEDGER (سجل العمليات والتدقيق)
             ======================================================== */}
          {activeTab === 'economy' && (
            <div className="space-y-5">
              {/* Top Banner & KPI Stat Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
                  <div className="text-[11px] text-gray-400">إجمالي الحركات الموثقة</div>
                  <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                    {stats.totalRecords.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-emerald-400 mt-0.5">
                    سجل محصّن غير قابل للتعديل (Immutable)
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
                  <div className="text-[11px] text-gray-400">تدفق الكوينز المكتسب (Inflow)</div>
                  <div className="text-xl font-black text-emerald-400 font-mono mt-1 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    +{stats.totalCoinsIn.toLocaleString()} 🪙
                  </div>
                  <div className="text-[10px] text-gray-400 mt-0.5">مكافآت وجوائز وبطولات</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
                  <div className="text-[11px] text-gray-400">تدفق الكوينز المستهلك (Outflow)</div>
                  <div className="text-xl font-black text-amber-300 font-mono mt-1 flex items-center gap-1">
                    <TrendingDown className="w-4 h-4" />
                    -{stats.totalCoinsOut.toLocaleString()} 🪙
                  </div>
                  <div className="text-[10px] text-gray-400 mt-0.5">رسوم طاولات وسكنات وهدايا</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
                  <div className="text-[11px] text-gray-400">الجواهر المشحونة (Gems Inflow)</div>
                  <div className="text-xl font-black text-blue-400 font-mono mt-1">
                    +{stats.totalGemsIn.toLocaleString()} 💎
                  </div>
                  <div className="text-[10px] text-emerald-400 mt-0.5">مشتريات آمنة معتمدة</div>
                </div>
              </div>

              {/* Action Toolbar & Verification Notification */}
              {hashVerificationStatus && (
                <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-xs flex items-center gap-2 shadow-lg animate-in fade-in">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{hashVerificationStatus}</span>
                </div>
              )}

              {/* Advanced Filter & Search Interactive Bar */}
              <div className="bg-[#05110a] border border-amber-900/60 p-4 rounded-2xl space-y-3 shadow-lg">
                <div className="flex flex-col md:flex-row items-center justify-between gap-3">
                  {/* Search input with live trigger */}
                  <div className="relative w-full md:w-96">
                    <input
                      type="text"
                      value={auditSearchQuery}
                      onChange={(e) => setAuditSearchQuery(e.target.value)}
                      placeholder="ابحث برمز TX، اسم اللاعب، معرّف ID، المنفّذ، أو الملاحظة..."
                      className="w-full bg-[#030a05] border border-amber-900/70 focus:border-amber-400 rounded-xl px-4 py-2.5 text-white pr-10 text-xs focus:outline-none placeholder-gray-500 shadow-inner"
                    />
                    <Search className="w-4 h-4 text-amber-400 absolute right-3.5 top-3" />
                    {auditSearchQuery && (
                      <button
                        onClick={() => setAuditSearchQuery('')}
                        className="absolute left-3 top-2.5 text-gray-400 hover:text-white text-xs"
                      >
                        ✕
                      </button>
                    )}
                  </div>

                  {/* Actions: Export CSV, Verify Hashes, Add Manual Record */}
                  <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-wrap">
                    <button
                      onClick={handleVerifyLedgerIntegrity}
                      disabled={isVerifyingHashes}
                      className="px-3 py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-600/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow"
                      title="فحص تسلسل التشفير لجميع المعاملات"
                    >
                      <ShieldCheck className={`w-3.5 h-3.5 ${isVerifyingHashes ? 'animate-spin' : ''}`} />
                      <span>{isVerifyingHashes ? 'جارِ فحص الـ Hash...' : 'التحقق من التشفير'}</span>
                    </button>

                    <button
                      onClick={handleExportCSV}
                      className="px-3 py-2 rounded-xl bg-[#092215] hover:bg-[#0e3320] text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow"
                      title="تصدير السجل بتنسيق CSV"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>تصدير CSV</span>
                    </button>

                    <button
                      onClick={() => setShowNewManualRecordModal(true)}
                      className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 text-black text-xs font-black flex items-center gap-1.5 shadow active:scale-95 transition-transform"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>إضافة قيد تدقيق (+ID)</span>
                    </button>
                  </div>
                </div>

                {/* Filters Pills Row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-2 border-t border-amber-950/80 text-xs">
                  {/* Currency filter */}
                  <div>
                    <label className="block text-gray-400 text-[10px] mb-1">العملة:</label>
                    <select
                      value={currencyFilter}
                      onChange={(e) => setCurrencyFilter(e.target.value as any)}
                      className="w-full bg-[#030905] border border-amber-900/60 rounded-lg p-2 text-white text-xs focus:outline-none"
                    >
                      <option value="ALL">جميع العملات (الكل)</option>
                      <option value="COINS">كوينز فقط 🪙</option>
                      <option value="GEMS">جواهر فقط 💎</option>
                    </select>
                  </div>

                  {/* Operation Type filter */}
                  <div>
                    <label className="block text-gray-400 text-[10px] mb-1">نوع العملية (Type):</label>
                    <select
                      value={sourceFilter}
                      onChange={(e) => setSourceFilter(e.target.value)}
                      className="w-full bg-[#030905] border border-amber-900/60 rounded-lg p-2 text-white text-xs focus:outline-none"
                    >
                      <option value="ALL">جميع الأنواع</option>
                      <option value="REWARD">مكافآت (REWARD)</option>
                      <option value="PURCHASE">مشتريات متجر (PURCHASE)</option>
                      <option value="GAME_FEE">رسوم طاولات (GAME_FEE)</option>
                      <option value="GIFT">هدايا (GIFT)</option>
                      <option value="CASHIER_TRANSFER">تحويل كاشير (CASHIER)</option>
                      <option value="ADMIN_OVERRIDE">تعديل إداري (OVERRIDE)</option>
                      <option value="TOURNAMENT_PRIZE">جوائز بطولات (TOURNAMENT)</option>
                      <option value="SUBSCRIPTION">اشتراكات VIP</option>
                    </select>
                  </div>

                  {/* Status filter */}
                  <div>
                    <label className="block text-gray-400 text-[10px] mb-1">حالة العملية:</label>
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="w-full bg-[#030905] border border-amber-900/60 rounded-lg p-2 text-white text-xs focus:outline-none"
                    >
                      <option value="ALL">جميع الحالات</option>
                      <option value="COMPLETED">مكتملة (COMPLETED)</option>
                      <option value="PENDING">معلقة (PENDING)</option>
                      <option value="REJECTED">مرفوضة / محظورة (REJECTED)</option>
                    </select>
                  </div>

                  {/* Sort By */}
                  <div>
                    <label className="block text-gray-400 text-[10px] mb-1">الترتيب:</label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="w-full bg-[#030905] border border-amber-900/60 rounded-lg p-2 text-white text-xs focus:outline-none"
                    >
                      <option value="date_desc">التاريخ (الأحدث أولاً)</option>
                      <option value="date_asc">التاريخ (الأقدم أولاً)</option>
                      <option value="amount_desc">المبلغ (الأعلى قيمة)</option>
                      <option value="amount_asc">المبلغ (الأقل قيمة)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* ========================================================
                  AUDIT LOG INTERACTIVE TABLE WITH COMPLETE DETAILS
                 ======================================================== */}
              <div className="border border-amber-900/70 rounded-2xl overflow-hidden shadow-2xl bg-[#040d07]">
                <div className="p-3 bg-[#06170d] border-b border-amber-950 flex items-center justify-between text-xs text-gray-400">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-amber-300">سجل التدقيق المركزي:</span>
                    <span>عرض {filteredTransactions.length} من أصل {transactions.length} عملية</span>
                  </div>
                  <div className="text-[11px] text-emerald-400 flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    <span>سجل محصّن مشفّر (Append-Only)</span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead className="bg-[#050e08] text-amber-300 border-b border-amber-950 font-bold">
                      <tr>
                        <th className="p-3 whitespace-nowrap">معرف العملية (ID)</th>
                        <th className="p-3 whitespace-nowrap">اللاعب (Player)</th>
                        <th className="p-3 whitespace-nowrap">النوع والمصدر</th>
                        <th className="p-3 whitespace-nowrap">المبلغ</th>
                        <th className="p-3 whitespace-nowrap text-center">الرصيد: قبل &larr; بعد</th>
                        <th className="p-3 whitespace-nowrap">المسؤول / الكاشير</th>
                        <th className="p-3 whitespace-nowrap">التاريخ والوقت</th>
                        <th className="p-3 whitespace-nowrap text-center">الحالة</th>
                        <th className="p-3 whitespace-nowrap text-center">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-950/60 bg-[#040e08]">
                      {filteredTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="p-8 text-center text-gray-400 text-xs">
                            لا توجد عمليات مطابقة لشروط البحث والفلترة المحددة.
                          </td>
                        </tr>
                      ) : (
                        filteredTransactions.map((tx) => {
                          const badge = getSourceBadge(tx.sourceMethod);
                          const isPositive = tx.amount > 0;
                          return (
                            <tr
                              key={tx.transactionId}
                              className="hover:bg-[#071c10] transition-colors group"
                            >
                              {/* 1. Transaction ID */}
                              <td className="p-3 whitespace-nowrap">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-mono text-amber-400 font-bold">
                                    {tx.transactionId}
                                  </span>
                                  <button
                                    onClick={() => copyToClipboard(tx.transactionId, tx.transactionId)}
                                    className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-amber-300 transition-opacity p-0.5"
                                    title="نسخ المعرف"
                                  >
                                    {copiedId === tx.transactionId ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                </div>
                                <div className="text-[10px] text-gray-500 font-mono">
                                  Seq #{tx.ledgerSequence || '1040'}
                                </div>
                              </td>

                              {/* 2. Player */}
                              <td className="p-3 whitespace-nowrap">
                                <div className="font-bold text-gray-100 flex items-center gap-1.5">
                                  <span>{tx.playerName}</span>
                                </div>
                                <div className="text-[10px] text-amber-400 font-mono">
                                  ID: {tx.playerId}
                                </div>
                              </td>

                              {/* 3. Type & Source */}
                              <td className="p-3 whitespace-nowrap">
                                <span
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold border ${badge.bg}`}
                                >
                                  <span>{badge.icon}</span>
                                  <span>{badge.label}</span>
                                </span>
                              </td>

                              {/* 4. Amount */}
                              <td className="p-3 whitespace-nowrap font-mono font-bold text-sm">
                                <span
                                  className={
                                    isPositive
                                      ? 'text-emerald-400'
                                      : 'text-red-400'
                                  }
                                >
                                  {isPositive ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()}
                                </span>{' '}
                                <span className="text-xs text-gray-300">
                                  {tx.currencyType === 'COINS' ? '🪙' : '💎'}
                                </span>
                              </td>

                              {/* 5. Balance Before & After (الرصيد قبل وبعد بدقة بالغة) */}
                              <td className="p-3 whitespace-nowrap text-center">
                                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-xl bg-[#020704] border border-amber-950 font-mono text-xs shadow-inner">
                                  <span className="text-gray-400">
                                    {tx.balanceBefore.toLocaleString()}
                                  </span>
                                  <span className="text-amber-500 font-black">&rarr;</span>
                                  <span className="text-amber-300 font-black">
                                    {tx.balanceAfter.toLocaleString()}
                                  </span>
                                </div>
                              </td>

                              {/* 6. Issuer / Cashier */}
                              <td className="p-3 whitespace-nowrap">
                                <div className="text-xs font-semibold text-gray-200">
                                  {tx.cashierOrAdminId}
                                </div>
                                <div className="text-[10px] text-gray-500 font-mono">
                                  {tx.ipAddress || '127.0.0.1'}
                                </div>
                              </td>

                              {/* 7. Timestamp */}
                              <td className="p-3 whitespace-nowrap font-mono text-gray-300 text-[11px]">
                                {tx.timestamp}
                              </td>

                              {/* 8. Status */}
                              <td className="p-3 whitespace-nowrap text-center">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                    tx.status === 'COMPLETED'
                                      ? 'bg-emerald-950 text-emerald-300 border-emerald-600/60'
                                      : tx.status === 'PENDING'
                                      ? 'bg-amber-950 text-amber-300 border-amber-600/60'
                                      : 'bg-red-950 text-red-300 border-red-600/60'
                                  }`}
                                >
                                  {tx.status === 'COMPLETED'
                                    ? 'مكتملة ✓'
                                    : tx.status === 'PENDING'
                                    ? 'معلقة ⏳'
                                    : 'مرفوضة ✗'}
                                </span>
                              </td>

                              {/* 9. Actions: Inspect Modal */}
                              <td className="p-3 whitespace-nowrap text-center">
                                <button
                                  onClick={() => setSelectedTxForInspect(tx)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border border-emerald-600/40 text-[11px] font-bold flex items-center gap-1 mx-auto transition-colors"
                                >
                                  <Eye className="w-3 h-3" />
                                  <span>فحص</span>
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB: DASHBOARD (لوحة الإحصائيات)
             ======================================================== */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-xl bg-[#06150c] border border-amber-950">
                  <div className="text-xs text-gray-400">اللاعبون المتصلون الآن</div>
                  <div className="text-2xl font-black text-amber-400 mt-1">1,482</div>
                  <div className="text-[10px] text-emerald-400 mt-1">+12% مقارنة بأمس</div>
                </div>
                <div className="p-4 rounded-xl bg-[#06150c] border border-amber-950">
                  <div className="text-xs text-gray-400">المباريات النشطة (طرنيب/تركس)</div>
                  <div className="text-2xl font-black text-emerald-400 mt-1">294</div>
                  <div className="text-[10px] text-gray-400 mt-1">1,176 لاعب في الطاولات</div>
                </div>
                <div className="p-4 rounded-xl bg-[#06150c] border border-amber-950">
                  <div className="text-xs text-gray-400">حالات الغش المشتبه بها (AI)</div>
                  <div className="text-2xl font-black text-red-400 mt-1">3</div>
                  <div className="text-[10px] text-red-300 mt-1">تتطلب مراجعة إدارية</div>
                </div>
                <div className="p-4 rounded-xl bg-[#06150c] border border-amber-950">
                  <div className="text-xs text-gray-400">حالة السيرفر وقاعدة البيانات</div>
                  <div className="text-2xl font-black text-emerald-300 mt-1">100% مستقر</div>
                  <div className="text-[10px] text-emerald-400 mt-1">Supabase PostgreSQL • Realtime OK</div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/30 text-xs text-amber-200 space-y-1">
                <div className="font-bold text-amber-300 flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-amber-400" />
                  قاعدة الصلاحيات الدستورية (Default Deny):
                </div>
                <p className="leading-relaxed">
                  أي صلاحية غير ممنوحة صراحةً تعتبر مرفوضة فورًا. لا توجد صلاحيات admin=true في الواجهة الأمامية بدون تحقق خادمي موثوق، وسجل العمليات المالية غير قابل للحذف (Immutable Ledger).
                </p>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB: PLAYERS (إدارة اللاعبين)
             ======================================================== */}
          {activeTab === 'players' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={playerSearchQuery}
                    onChange={(e) => setPlayerSearchQuery(e.target.value)}
                    placeholder="ابحث عن لاعب باسمه أو معرّفه (ID)..."
                    className="w-full bg-[#050f0a] border border-amber-900/70 focus:border-amber-400 rounded-xl px-4 py-2.5 text-white pr-10 text-xs focus:outline-none"
                  />
                  <Search className="w-4 h-4 text-amber-400 absolute right-3.5 top-3" />
                </div>
              </div>

              <div className="p-5 rounded-xl bg-[#05110a] border border-amber-950 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <img src={currentUser.avatar} alt={currentUser.name} className="w-16 h-16 rounded-full border-2 border-amber-400 object-cover" />
                  <div>
                    <h3 className="font-bold text-base text-white flex items-center gap-2">
                      <span>{currentUser.name}</span>
                      <span className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        {currentUser.title}
                      </span>
                    </h3>
                    <div className="text-xs text-gray-400 mt-1">
                      ID: {currentUser.id} • المستوى: {currentUser.level} • XP: {currentUser.xp}/{currentUser.nextLevelXp}
                    </div>
                    <div className="text-xs text-emerald-400 mt-1">
                      مجموعة الحسابات: {currentUser.accountGroup.accountsCount} من أصل {currentUser.accountGroup.maxAllowed} مسموح
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <div className="text-sm font-bold text-amber-400 font-mono">
                    الرصيد: {currentUser.coins.toLocaleString()} كوينز | {currentUser.gems.toLocaleString()} جوهرة
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleAdjustPlayerCoins(1000)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold"
                    >
                      + 1,000 كوينز
                    </button>
                    <button
                      onClick={() => handleAdjustPlayerCoins(-500)}
                      className="px-3 py-1.5 rounded-lg bg-red-950 hover:bg-red-900 text-red-300 text-xs font-bold"
                    >
                      - 500 كوينز
                    </button>
                    <button
                      onClick={() => showToast('تم تطبيق كتم مؤقت للدردشة لمدة 30 دقيقة بحسب اللائحة')}
                      className="px-3 py-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs"
                    >
                      كتم الدردشة
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB: ROOMS MONITOR (مراقبة الغرف)
             ======================================================== */}
          {activeTab === 'rooms' && (
            <div className="space-y-4">
              <h3 className="font-bold text-sm text-gray-200">الغرف النشطة لحظيًا في الخادم:</h3>
              <div className="space-y-3">
                {[
                  { id: '#24451', game: 'طرنيب سوق 41', host: 'Player 1', stake: 500, state: 'مرحلة المزايدة', players: '4/4' },
                  { id: '#19208', game: 'تركس فردي', host: 'Queen_18', stake: 1000, state: 'المملكة 2: ديناري', players: '4/4' },
                  { id: '#88291', game: 'شطرنج 1v1', host: 'Grandmaster_X', stake: 250, state: 'نقلة 24', players: '2/2' },
                ].map((room) => (
                  <div
                    key={room.id}
                    className="p-4 rounded-xl bg-[#05110a] border border-amber-950 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold text-sm text-gray-100 flex items-center gap-2">
                        <span>{room.game}</span>
                        <span className="font-mono text-amber-400 text-xs">{room.id}</span>
                      </div>
                      <div className="text-xs text-gray-400 mt-1">
                        المنشئ: {room.host} • الرهان: {room.stake} كوينز • الحالة: {room.state}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => showToast(`بدء فحص ومراقبة سرية للغرفة ${room.id} (أوراق مكشوفة للإدارة)`)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-emerald-300 text-xs flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>فحص الغرفة</span>
                      </button>
                      <button
                        onClick={() => showToast(`تم إيقاف الغرفة ${room.id} جبرياً وإعادة الرهانات للاعبين`)}
                        className="px-3 py-1.5 rounded-lg bg-red-950 hover:bg-red-900 text-red-300 text-xs"
                      >
                        إيقاف جبري
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              TAB: SKINS ENGINE (محرك السكنات)
             ======================================================== */}
          {activeTab === 'skins' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-gray-200">نظام السكنات الديناميكي (Skins Engine):</h3>
                  <div className="text-xs text-gray-400">
                    مسار الإنشاء: Skins &rarr; Create &rarr; Upload &rarr; Game &rarr; Name &rarr; Rarity &rarr; Price &rarr; Preview &rarr; Save &rarr; Publish
                  </div>
                </div>
                <button
                  onClick={() => setShowCreateSkinModal(true)}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4" />
                  <span>إنشاء سكن جديد</span>
                </button>
              </div>

              {showCreateSkinModal && (
                <form
                  onSubmit={handleCreateSkinSubmit}
                  className="p-5 rounded-xl bg-[#06180d] border border-emerald-500/50 space-y-3"
                >
                  <h4 className="font-bold text-xs text-amber-300">إضافة سكن جديد للمنصة دون إعادة بناء التطبيق:</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block text-gray-300 mb-1">اسم السكن:</label>
                      <input
                        type="text"
                        value={newSkinForm.name}
                        onChange={(e) => setNewSkinForm({ ...newSkinForm, name: e.target.value })}
                        placeholder="مثل: الذهب الملكي"
                        className="w-full bg-[#030a05] border border-amber-950 p-2 rounded text-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-300 mb-1">اللعبة المستهدفة:</label>
                      <select
                        value={newSkinForm.game}
                        onChange={(e) => setNewSkinForm({ ...newSkinForm, game: e.target.value })}
                        className="w-full bg-[#030a05] border border-amber-950 p-2 rounded text-white"
                      >
                        <option value="طرنيب">طرنيب</option>
                        <option value="تركس">تركس</option>
                        <option value="شطرنج">شطرنج</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-300 mb-1">الندرة (Rarity):</label>
                      <select
                        value={newSkinForm.rarity}
                        onChange={(e) => setNewSkinForm({ ...newSkinForm, rarity: e.target.value as any })}
                        className="w-full bg-[#030a05] border border-amber-950 p-2 rounded text-white"
                      >
                        <option value="Royal">Royal (ملكي)</option>
                        <option value="Legendary">Legendary (أسطوري)</option>
                        <option value="Epic">Epic (ملحمي)</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowCreateSkinModal(false)}
                      className="px-3 py-1.5 rounded bg-gray-800 text-xs text-gray-300"
                    >
                      إلغاء
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded bg-amber-500 text-black text-xs font-bold"
                    >
                      حفظ ونشر (Publish)
                    </button>
                  </div>
                </form>
              )}

              <div className="border border-amber-950 rounded-xl overflow-hidden">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#050e08] text-amber-300 border-b border-amber-950">
                    <tr>
                      <th className="p-3">اسم السكن</th>
                      <th className="p-3">اللعبة</th>
                      <th className="p-3">الندرة</th>
                      <th className="p-3">السعر</th>
                      <th className="p-3">الإصدار (Version)</th>
                      <th className="p-3">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-950/50 bg-[#05110a]">
                    {skinsList.map((s) => (
                      <tr key={s.id} className="hover:bg-[#07170f]">
                        <td className="p-3 font-bold text-gray-100">{s.name}</td>
                        <td className="p-3 text-gray-400">{s.game}</td>
                        <td className="p-3 text-amber-400">{s.rarity}</td>
                        <td className="p-3 font-mono">{s.priceCoins?.toLocaleString()} كوينز</td>
                        <td className="p-3 font-mono text-gray-400">{s.version}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              s.status === 'PUBLISHED'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/50'
                                : 'bg-amber-950 text-amber-300 border border-amber-600/50'
                            }`}
                          >
                            {s.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB: MODERATION & AI CHEAT DETECTION
             ======================================================== */}
          {activeTab === 'moderation' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/30 text-xs text-amber-200">
                <div className="font-bold text-amber-300 mb-1 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-amber-400" />
                  فلسفة نظام الذكاء الاصطناعي والمراقبة:
                </div>
                <p className="leading-relaxed">
                  لا يوجد شات AI للاعبين. الـ AI يعمل خلف الكواليس كمساعد لكشف التواطؤ، النقلات المستحيلة، التوقيت المشبوه، وتعدد الحسابات المفرط. القرار النهائي يظل دائمًا بيد الإدارة مع سياسة Default Deny.
                </p>
              </div>

              <div className="space-y-3">
                {cheatCases.map((c) => (
                  <div
                    key={c.caseId}
                    className="p-4 rounded-xl bg-[#05110a] border border-red-950/70 hover:border-red-600/60 flex flex-col md:flex-row items-start md:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-amber-400 text-xs font-bold">{c.caseId}</span>
                        <span className="font-bold text-sm text-gray-100">{c.playerName}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-600 font-bold">
                          خطر: {c.riskScore}% ({c.severity})
                        </span>
                      </div>
                      <div className="text-xs text-amber-300 mt-1 font-semibold">
                        السبب: {c.flagReason} • الغرفة: {c.matchId}
                      </div>
                      <p className="text-xs text-gray-400 mt-1">{c.notes}</p>
                    </div>

                    <div className="flex items-center gap-2 w-full md:w-auto">
                      <button
                        onClick={() => showToast(`تم حظر اللاعب ${c.playerName} بناء على كشف التواطؤ وتوثيق الحالة`)}
                        className="px-3 py-1.5 rounded-lg bg-red-900 hover:bg-red-800 text-white text-xs font-bold"
                      >
                        تطبيق عقوبة
                      </button>
                      <button
                        onClick={() => showToast(`تم حفظ الحالة ${c.caseId} في الأرشيف وتجاهل التنبيه`)}
                        className="px-3 py-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs"
                      >
                        تجاهل
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              TAB: STAFF & ROLES (الصلاحيات)
             ======================================================== */}
          {activeTab === 'staff' && (
            <div className="space-y-4">
              <div className="border border-amber-950 rounded-xl overflow-hidden">
                <table className="w-full text-xs text-right">
                  <thead className="bg-[#050e08] text-amber-300 border-b border-amber-950">
                    <tr>
                      <th className="p-3">الاسم</th>
                      <th className="p-3">الرتبة</th>
                      <th className="p-3">البريد المعتمد</th>
                      <th className="p-3">الصلاحيات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-950/50 bg-[#05110a]">
                    {staffList.map((st) => (
                      <tr key={st.id} className="hover:bg-[#07170f]">
                        <td className="p-3 font-bold text-gray-100">{st.name}</td>
                        <td className="p-3 font-mono text-amber-400 font-bold">{st.role}</td>
                        <td className="p-3 text-gray-400 font-mono">{st.email}</td>
                        <td className="p-3 text-emerald-400">{st.permissions.join(' • ')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB: CASHIER DESK & REAL MONEY (مكتب الكاشير والنقود الحقيقية)
             ======================================================== */}
          {activeTab === 'cashier' && (
            <div className="space-y-5">
              {/* Cashier Treasury Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0c311c] to-[#04110a] border-2 border-emerald-500/60 shadow">
                  <div className="text-[11px] text-emerald-300 font-bold">خزينة الكاشير المركزية (Treasury)</div>
                  <div className="text-2xl font-black text-amber-300 font-mono mt-1">$54,200 USD</div>
                  <div className="text-[10px] text-emerald-400 mt-0.5">محفظة USDT TRC-20 متصلة</div>
                </div>

                <div className="p-4 rounded-2xl bg-[#06150c] border border-amber-950 shadow">
                  <div className="text-[11px] text-gray-400">طلبات الإيداع المعلقة</div>
                  <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                    {cashierRequests.filter((r) => r.type === 'DEPOSIT' && r.status === 'PENDING').length} طلب
                  </div>
                  <div className="text-[10px] text-gray-400 mt-0.5">تتطلب تدقيق الهاش أو الإيصال</div>
                </div>

                <div className="p-4 rounded-2xl bg-[#06150c] border border-amber-950 shadow">
                  <div className="text-[11px] text-gray-400">طلبات السحب المعلقة</div>
                  <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                    {cashierRequests.filter((r) => r.type === 'WITHDRAWAL' && r.status === 'PENDING').length} طلب
                  </div>
                  <div className="text-[10px] text-amber-300 mt-0.5">تحويل أرباح للاعبين</div>
                </div>

                <div className="p-4 rounded-2xl bg-[#06150c] border border-amber-950 shadow">
                  <div className="text-[11px] text-gray-400">الموزعون الإقليميون المعتمدون</div>
                  <div className="text-2xl font-black text-white font-mono mt-1">6 موزعين</div>
                  <div className="text-[10px] text-emerald-400 mt-0.5">تغطية نشطة</div>
                </div>
              </div>

              {/* Fast Shortcut to Currency Transfer Hub */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950 via-[#072414] to-emerald-950 border border-amber-500/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
                    <ArrowRightLeft className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <h4 className="font-black text-sm text-white">
                      نظام تحويل العملات المركزي (لوحة التحكم &larr; الكاشير &larr; الحسابات)
                    </h4>
                    <p className="text-xs text-gray-300 mt-0.5">
                      قم بضخ وتغذية أرصدة خزائن الكاشير، أو تحويل الكوينز والنقود من الكاشير إلى حسابات اللاعبين وسحبها فوراً.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    soundFX.playButtonClick();
                    setActiveTab('transfers');
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-black text-xs flex items-center gap-1.5 shadow-md hover:brightness-110 shrink-0"
                >
                  <ArrowRightLeft className="w-3.5 h-3.5" />
                  <span>فتح نافذة تحويل العملات ⚡</span>
                </button>
              </div>

              {/* Cashier Permissions Verification Banner & Active Role Tester */}
              <div className="p-4 rounded-2xl bg-[#05110a] border border-amber-900/70 shadow-lg space-y-3">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-black ${
                        isAuthorizedCashier
                          ? 'bg-emerald-950 border border-emerald-500 text-emerald-300'
                          : 'bg-red-950 border border-red-500 text-red-300'
                      }`}
                    >
                      {isAuthorizedCashier ? <ShieldCheck className="w-5 h-5 text-emerald-400" /> : <Lock className="w-5 h-5 text-red-400" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-sm text-white">نظام التحقق من صلاحيات الكاشير:</span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black border ${
                            isAuthorizedCashier
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-500'
                              : 'bg-red-950 text-red-300 border-red-500 animate-pulse'
                          }`}
                        >
                          {isAuthorizedCashier ? 'موظف مخول بالاعتماد والرفض ✓' : 'غير مخول بالعمليات المالية 🔒'}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5">
                        المستخدم الحالي:{' '}
                        <strong className="text-amber-300">{currentUser.name}</strong> • الدور المسجل:{' '}
                        <strong className="text-amber-400 font-mono">{currentUser.role}</strong>{' '}
                        {isAuthorizedCashier ? (
                          <span className="text-emerald-400">
                            (مسموح له باعتماد/رفض طلبات الإيداع والسحب وتوثيق الحركات في الـ Audit Log)
                          </span>
                        ) : (
                          <span className="text-red-400 font-bold">
                            (محجوب عنه أزرار الاعتماد والرفض لمنع التلاعب المالي)
                          </span>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Interactive Role Switcher to immediately test authorization rules */}
                  <div className="bg-[#020704] p-1.5 rounded-xl border border-amber-950 flex items-center gap-1">
                    <span className="text-[10px] text-gray-400 px-1 font-bold">تبديل الدور للتجربة:</span>
                    {(['OWNER', 'ADMIN', 'CASHIER', 'MODERATOR', 'PLAYER'] as const).map((r) => {
                      const isActive = currentUser.role === r;
                      const isAuth = ['OWNER', 'ADMIN', 'MANAGER', 'CASHIER'].includes(r);
                      return (
                        <button
                          key={r}
                          onClick={() => {
                            soundFX.playButtonClick();
                            onUpdateUser({ ...currentUser, role: r });
                            showToast(`تم تبديل الدور إلى ${r} (${isAuth ? 'مخول كاشير ✓' : 'غير مخول 🔒'})`);
                          }}
                          className={`px-2 py-1 rounded-lg text-[10px] font-black transition-all ${
                            isActive
                              ? isAuth
                                ? 'bg-emerald-500 text-black shadow'
                                : 'bg-red-500 text-white shadow'
                              : 'text-gray-400 hover:text-white hover:bg-white/5'
                          }`}
                          title={isAuth ? `دور مخول (${r})` : `دور غير مخول (${r})`}
                        >
                          {r === 'OWNER' && '👑 '}
                          {r === 'ADMIN' && '🛡️ '}
                          {r === 'CASHIER' && '💼 '}
                          {r === 'MODERATOR' && '👮 '}
                          {r === 'PLAYER' && '🎮 '}
                          {r}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Audit notification banner upon execution */}
                {cashierAuditNotice && (
                  <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950 to-[#071d11] border border-emerald-500 text-emerald-200 text-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-2 shadow-xl animate-in fade-in">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="font-bold text-white">{cashierAuditNotice.message}</div>
                        <div className="text-[11px] text-emerald-300">
                          {cashierAuditNotice.details} • رقم المعاملة الموثقة:{' '}
                          <span className="font-mono text-amber-300 font-bold">
                            #{cashierAuditNotice.txId}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        soundFX.playButtonClick();
                        setActiveTab('economy');
                        setAuditSearchQuery(cashierAuditNotice.txId);
                      }}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-black rounded-lg text-xs flex items-center gap-1 shadow shrink-0"
                    >
                      <span>عرض في سجل التدقيق (Audit Log) 📜</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Pending Cashier Requests Queue */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-gray-100 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>قائمة طلبات الإيداع والسحب المعلقة للمراجعة والاعتماد:</span>
                  </h3>
                  <span className="text-xs text-gray-400 font-mono">
                    طلبات معلقة: {cashierRequests.filter((r) => r.status === 'PENDING').length}
                  </span>
                </div>

                {cashierRequests.filter((r) => r.status === 'PENDING').length === 0 ? (
                  <div className="p-6 rounded-2xl bg-[#05110a] border border-amber-950 text-center text-xs text-gray-400">
                    لا توجد طلبات كاشير معلقة حالياً. جميع الطلبات تم تدقيقها واعتمادها بنجاح في الـ Audit Log ✓.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {cashierRequests
                      .filter((r) => r.status === 'PENDING')
                      .map((req) => (
                        <div
                          key={req.id}
                          className="p-4 rounded-2xl bg-[#05110a] border border-amber-900/60 hover:border-amber-600/70 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  req.type === 'DEPOSIT'
                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                                    : 'bg-amber-950 text-amber-300 border border-amber-600'
                                }`}
                              >
                                {req.type === 'DEPOSIT' ? 'طلب إيداع نقدي 📥' : 'طلب سحب أرباح 📤'}
                              </span>
                              <span className="font-bold text-sm text-white">{req.playerName}</span>
                              <span className="text-[10px] text-amber-400 font-mono">ID: {req.playerId}</span>
                              <span className="font-mono text-base font-black text-amber-300">
                                ${req.amount.toLocaleString()} USD
                              </span>
                            </div>

                            <div className="text-xs text-gray-400 mt-1">
                              الوسيلة: {req.method} • الحساب/المحفظة: <span className="font-mono text-gray-200">{req.walletAddressOrAccount}</span>
                            </div>
                            {req.txHashOrReceipt && (
                              <div className="text-[10px] text-gray-500 font-mono mt-0.5 truncate max-w-lg">
                                هاش المعاملة: {req.txHashOrReceipt}
                              </div>
                            )}
                          </div>

                          {/* ACTION BUTTONS: Rendered ONLY for Authorized Staff (CASHIER/ADMIN/OWNER) */}
                          <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                            {isAuthorizedCashier ? (
                              <>
                                <button
                                  onClick={() => handleApproveCashierWithAudit(req)}
                                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 text-white font-black text-xs shadow-lg transition-transform active:scale-95 flex items-center gap-1.5"
                                  title="اعتماد وتحويل الرصيد مع تسجيل القيد في الـ Audit Log"
                                >
                                  <Check className="w-4 h-4" />
                                  <span>اعتماد وتحويل الرصيد ✓</span>
                                </button>
                                <button
                                  onClick={() => handleRejectCashierWithAudit(req)}
                                  className="px-3.5 py-2.5 rounded-xl bg-red-950 hover:bg-red-900 text-red-300 text-xs font-bold border border-red-700/50 shadow flex items-center gap-1.5 active:scale-95 transition-transform"
                                  title="رفض الطلب مع توثيق سبب الرفض في سجل التدقيق"
                                >
                                  <X className="w-4 h-4" />
                                  <span>رفض الطلب ✗</span>
                                </button>
                              </>
                            ) : (
                              <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-red-950/70 border border-red-800 text-red-300 text-xs font-bold shadow">
                                <Lock className="w-4 h-4 text-red-400 shrink-0" />
                                <span>🔒 غير مصرح: يتطلب دور كاشير معتمد (CASHIER / ADMIN / OWNER)</span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>

              {/* Dedicated Live Audit Log of Cashier Movements */}
              <div className="p-4 rounded-2xl bg-[#05110a] border border-amber-950 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-amber-400" />
                    <h4 className="font-bold text-sm text-white">سجل حركات الكاشير الموثقة مؤخراً (Audit Trail):</h4>
                  </div>
                  <button
                    onClick={() => {
                      soundFX.playButtonClick();
                      setActiveTab('economy');
                      setSourceFilter('CASHIER_TRANSFER');
                    }}
                    className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                  >
                    <span>فتح الفلترة الكاملة في سجل التدقيق 📜</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="border border-amber-950/80 rounded-xl overflow-hidden text-xs">
                  <table className="w-full text-right border-collapse">
                    <thead>
                      <tr className="bg-[#030a05] text-gray-400 text-[11px] border-b border-amber-950">
                        <th className="p-2.5">رقم الحركة (ID)</th>
                        <th className="p-2.5">اللاعب المستفيد</th>
                        <th className="p-2.5">المبلغ ($ USD)</th>
                        <th className="p-2.5">المسؤول المنفّذ</th>
                        <th className="p-2.5">التاريخ والوقت</th>
                        <th className="p-2.5">الحالة</th>
                        <th className="p-2.5">فحص البصمة</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-950/50">
                      {transactions
                        .filter((tx) => tx.sourceMethod === 'CASHIER_TRANSFER')
                        .slice(0, 5)
                        .map((tx) => (
                          <tr key={tx.transactionId} className="hover:bg-emerald-950/20">
                            <td className="p-2.5 font-mono text-amber-400 font-bold">
                              {tx.transactionId}
                            </td>
                            <td className="p-2.5 text-gray-200">
                              {tx.playerName} <span className="text-gray-500 font-mono">({tx.playerId})</span>
                            </td>
                            <td className="p-2.5 font-mono font-bold">
                              <span className={tx.status === 'COMPLETED' ? 'text-emerald-400' : 'text-red-400'}>
                                {tx.amount > 0 ? `+$${tx.amount.toLocaleString()}` : `$${tx.amount.toLocaleString()}`} USD
                              </span>
                            </td>
                            <td className="p-2.5 text-gray-300 font-mono text-[11px]">
                              {tx.cashierOrAdminId}
                            </td>
                            <td className="p-2.5 font-mono text-gray-400 text-[11px]">
                              {tx.timestamp}
                            </td>
                            <td className="p-2.5">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  tx.status === 'COMPLETED'
                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                                    : 'bg-red-950 text-red-300 border border-red-600'
                                }`}
                              >
                                {tx.status === 'COMPLETED' ? 'معتمد ✓' : 'مرفوض ✗'}
                              </span>
                            </td>
                            <td className="p-2.5">
                              <button
                                onClick={() => setSelectedTxForInspect(tx)}
                                className="px-2 py-1 rounded bg-[#092215] text-amber-300 border border-amber-900/60 hover:bg-[#0e3520] text-[10px] font-bold flex items-center gap-1"
                              >
                                <Eye className="w-3 h-3" />
                                <span>معاينة</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Direct Player Cash Credit / Debit */}
              <div className="p-4 rounded-2xl bg-[#05110a] border border-amber-950 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-sm text-white">إيداع / خصم نقدي مباشر لحساب اللاعب الحالي:</h4>
                  <p className="text-xs text-gray-400 mt-0.5">
                    اللاعب: {currentUser.name} • الرصيد النقدي الحالي: ${currentUser.realCashBalance.toLocaleString()} USD
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      soundFX.playCoin();
                      const newBal = currentUser.realCashBalance + 100;
                      onUpdateUser({ ...currentUser, realCashBalance: newBal });
                      const newTx: TransactionRecord = {
                        transactionId: `TX-${Math.floor(100000 + Math.random() * 900000)}`,
                        ledgerSequence: transactions.length + 1040,
                        playerId: currentUser.id,
                        playerName: currentUser.name,
                        cashierOrAdminId: 'CASHIER_DIRECT_OVERRIDE',
                        amount: 100,
                        currencyType: 'REAL_USD',
                        balanceBefore: currentUser.realCashBalance,
                        balanceAfter: newBal,
                        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
                        status: 'COMPLETED',
                        sourceMethod: 'CASHIER_TRANSFER',
                        referenceNote: 'إيداع نقدي حقيقي مباشر من مكتب الكاشير (+$100 USD)',
                        auditHash: `sha256:${Array.from({ length: 50 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
                        ipAddress: '127.0.0.1 (Cashier Session)',
                        sessionId: 'sess_cashier_direct',
                      };
                      setTransactions([newTx, ...transactions]);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs"
                  >
                    + $100 USD كاشير
                  </button>
                  <button
                    onClick={() => {
                      soundFX.playCoin();
                      const newBal = Math.max(0, currentUser.realCashBalance - 50);
                      onUpdateUser({ ...currentUser, realCashBalance: newBal });
                    }}
                    className="px-3.5 py-2 rounded-xl bg-red-950 hover:bg-red-900 text-red-300 font-bold text-xs border border-red-800"
                  >
                    - $50 USD كاشير
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================
          MODAL: AUDIT RECORD DETAIL INSPECTOR (معاينة تفاصيل التدقيق الكاملة)
         ======================================================== */}
      {selectedTxForInspect && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="relative w-full max-w-xl bg-[#07160e] border-2 border-amber-500/70 rounded-3xl p-6 shadow-[0_0_50px_rgba(245,158,11,0.5)] text-right space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-amber-950">
              <button
                onClick={() => setSelectedTxForInspect(null)}
                className="text-gray-400 hover:text-amber-400 p-1 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="font-black text-amber-300 text-base">
                  تفاصيل قيد التدقيق المالي #{selectedTxForInspect.transactionId}
                </h3>
              </div>
            </div>

            {/* Cryptographic Hash Badge */}
            <div className="p-3 rounded-2xl bg-[#030905] border border-amber-900/60 space-y-1">
              <div className="text-[10px] text-gray-400 flex items-center justify-between">
                <span>بصمة التشفير المقفلة (SHA-256 Checksum):</span>
                <span className="text-emerald-400 font-bold">100% موثقة</span>
              </div>
              <div className="font-mono text-xs text-amber-300/90 break-all bg-black/60 p-2 rounded-lg border border-amber-950">
                {selectedTxForInspect.auditHash || 'sha256:verified_block_signature_immutable'}
              </div>
            </div>

            {/* Balances & Flow Comparison Card */}
            <div className="grid grid-cols-3 gap-2 text-center p-3 rounded-2xl bg-[#05110a] border border-amber-950">
              <div>
                <div className="text-[10px] text-gray-400">الرصيد السابق</div>
                <div className="font-mono font-bold text-gray-200 text-sm mt-0.5">
                  {selectedTxForInspect.balanceBefore.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-[10px] text-gray-400">قيمة التغيير</div>
                <div
                  className={`font-mono font-black text-sm mt-0.5 ${
                    selectedTxForInspect.amount > 0 ? 'text-emerald-400' : 'text-red-400'
                  }`}
                >
                  {selectedTxForInspect.amount > 0
                    ? `+${selectedTxForInspect.amount.toLocaleString()}`
                    : selectedTxForInspect.amount.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-[10px] text-gray-400">الرصيد النهائي</div>
                <div className="font-mono font-black text-amber-300 text-sm mt-0.5">
                  {selectedTxForInspect.balanceAfter.toLocaleString()}
                </div>
              </div>
            </div>

            {/* Key Information Fields */}
            <div className="space-y-2 text-xs bg-[#040e08] p-3.5 rounded-2xl border border-amber-950/80">
              <div className="flex justify-between py-1 border-b border-amber-950/40">
                <span className="text-gray-400">اسم ومعرّف اللاعب:</span>
                <span className="font-bold text-white">
                  {selectedTxForInspect.playerName} (ID: {selectedTxForInspect.playerId})
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-amber-950/40">
                <span className="text-gray-400">نوع العملية (Source Method):</span>
                <span className="font-bold text-amber-400">
                  {selectedTxForInspect.sourceMethod}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-amber-950/40">
                <span className="text-gray-400">العملة المعتمدة:</span>
                <span className="font-bold text-gray-200">
                  {selectedTxForInspect.currencyType === 'COINS' ? 'كوينز (Coins 🪙)' : 'جواهر (Gems 💎)'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-amber-950/40">
                <span className="text-gray-400">المشرف أو النظام المصدر:</span>
                <span className="font-mono text-emerald-300 font-bold">
                  {selectedTxForInspect.cashierOrAdminId}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-amber-950/40">
                <span className="text-gray-400">عنوان IP والجلسة:</span>
                <span className="font-mono text-gray-400">
                  {selectedTxForInspect.ipAddress || '192.168.1.104'} • {selectedTxForInspect.sessionId || 'sess_active'}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-amber-950/40">
                <span className="text-gray-400">التاريخ والوقت المسجل:</span>
                <span className="font-mono text-gray-300">
                  {selectedTxForInspect.timestamp}
                </span>
              </div>
              <div className="pt-1">
                <span className="text-gray-400 block mb-1">الملاحظة المرجعية والبيان:</span>
                <p className="text-gray-200 bg-[#020704] p-2.5 rounded-xl border border-amber-950 text-[11px] leading-relaxed">
                  {selectedTxForInspect.referenceNote}
                </p>
              </div>
            </div>

            <button
              onClick={() => setSelectedTxForInspect(null)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 text-black font-black text-xs shadow-md active:scale-95 transition-transform"
            >
              إغلاق نافذة المعاينة
            </button>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: ADD MANUAL AUDIT RECORD (إضافة قيد تدقيق جديد)
         ======================================================== */}
      {showNewManualRecordModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="relative w-full max-w-lg bg-[#07160e] border-2 border-emerald-500/60 rounded-3xl p-6 shadow-[0_0_50px_rgba(16,185,129,0.4)] text-right space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-amber-950">
              <button
                onClick={() => setShowNewManualRecordModal(false)}
                className="text-gray-400 hover:text-amber-400 p-1 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
              <h3 className="font-black text-amber-300 text-base flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                تسجيل حركة تدقيق يدوي في الـ Ledger
              </h3>
            </div>

            <form onSubmit={handleCreateManualRecord} className="space-y-3 text-xs">
              <div>
                <label className="block text-gray-300 font-bold mb-1">اسم اللاعب المستهدف:</label>
                <input
                  type="text"
                  value={manualRecordForm.playerName}
                  onChange={(e) =>
                    setManualRecordForm({ ...manualRecordForm, playerName: e.target.value })
                  }
                  className="w-full bg-[#030905] border border-amber-900 rounded-xl p-2.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">معرف اللاعب (Player ID):</label>
                <input
                  type="text"
                  value={manualRecordForm.playerId}
                  onChange={(e) =>
                    setManualRecordForm({ ...manualRecordForm, playerId: e.target.value })
                  }
                  className="w-full bg-[#030905] border border-amber-900 rounded-xl p-2.5 text-white font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-bold mb-1">نوع العملة:</label>
                  <select
                    value={manualRecordForm.currencyType}
                    onChange={(e) =>
                      setManualRecordForm({
                        ...manualRecordForm,
                        currencyType: e.target.value as any,
                      })
                    }
                    className="w-full bg-[#030905] border border-amber-900 rounded-xl p-2.5 text-white"
                  >
                    <option value="COINS">كوينز (Coins 🪙)</option>
                    <option value="GEMS">جواهر (Gems 💎)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1">المبلغ (+ إضافة أو - خصم):</label>
                  <input
                    type="number"
                    value={manualRecordForm.amount}
                    onChange={(e) =>
                      setManualRecordForm({
                        ...manualRecordForm,
                        amount: Number(e.target.value),
                      })
                    }
                    className="w-full bg-[#030905] border border-amber-900 rounded-xl p-2.5 text-white font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">تصنيف العملية (Method):</label>
                <select
                  value={manualRecordForm.sourceMethod}
                  onChange={(e) =>
                    setManualRecordForm({
                      ...manualRecordForm,
                      sourceMethod: e.target.value as any,
                    })
                  }
                  className="w-full bg-[#030905] border border-amber-900 rounded-xl p-2.5 text-white"
                >
                  <option value="ADMIN_OVERRIDE">تعديل إداري (ADMIN_OVERRIDE)</option>
                  <option value="REWARD">مكافأة مباشرة (REWARD)</option>
                  <option value="CASHIER_TRANSFER">تحويل كاشير (CASHIER_TRANSFER)</option>
                  <option value="TOURNAMENT_PRIZE">جائزة بطولة (TOURNAMENT_PRIZE)</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">البيان والملاحظة التوثيقية:</label>
                <textarea
                  value={manualRecordForm.referenceNote}
                  onChange={(e) =>
                    setManualRecordForm({
                      ...manualRecordForm,
                      referenceNote: e.target.value,
                    })
                  }
                  rows={2}
                  className="w-full bg-[#030905] border border-amber-900 rounded-xl p-2.5 text-white text-xs"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewManualRecordModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-gray-800 text-gray-300 font-bold text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg"
                >
                  تأكيد وقيد في السجل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
