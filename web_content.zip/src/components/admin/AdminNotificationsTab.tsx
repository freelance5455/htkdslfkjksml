import React, { useState } from 'react';
import { Send, Bell, CheckCircle2, AlertTriangle, Gift, Info } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { NotificationItem } from '../../types';

export const AdminNotificationsTab: React.FC = () => {
  const { notifications, sendAdminBroadcast, t } = useApp();

  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [message, setMessage] = useState('');
  const [messageBn, setMessageBn] = useState('');
  const [type, setType] = useState<NotificationItem['type']>('info');
  const [successNotice, setSuccessNotice] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;

    sendAdminBroadcast(title, message, titleBn, messageBn, type);
    confetti({ particleCount: 50, spread: 50 });
    setTitle('');
    setTitleBn('');
    setMessage('');
    setMessageBn('');
    setSuccessNotice(true);
    setTimeout(() => setSuccessNotice(false), 3000);
  };

  return (
    <div className="space-y-6">
      
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('notificationsManagement')}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Broadcast real-time messages, maintenance updates, or reward promotions to all users.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Send Broadcast Form */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Send className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span>Create New Announcement</span>
          </h3>

          {successNotice && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 text-xs font-semibold">
              Broadcast dispatched to all users successfully!
            </div>
          )}

          <form onSubmit={handleSend} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Announcement Title (English)
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Weekend 2x Bonus Coin Surge!"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Title (বাংলা Bengali - Optional)
              </label>
              <input
                type="text"
                value={titleBn}
                onChange={(e) => setTitleBn(e.target.value)}
                placeholder="e.g. উইকএন্ড ডাবল কয়েন বোনাস অফার!"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Message Body
              </label>
              <textarea
                rows={3}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter details for the notification..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Notification Type
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as NotificationItem['type'])}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
              >
                <option value="info">Info (Blue)</option>
                <option value="success">Success (Green)</option>
                <option value="reward">Reward (Purple/Gold)</option>
                <option value="warning">Warning (Amber)</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md shadow-purple-600/20 active:scale-95 transition-all cursor-pointer"
            >
              Send Broadcast to All Users
            </button>
          </form>
        </div>

        {/* Recent Notifications List */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Bell className="w-4 h-4 text-slate-400" />
            <span>Recent Notifications ({notifications.length})</span>
          </h3>

          <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-1 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {notif.title}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-purple-600 dark:text-purple-400">
                    {notif.type}
                  </span>
                </div>
                <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">
                  {notif.message}
                </p>
                <p className="text-[10px] text-slate-400">
                  Target: {notif.userId === 'all' ? 'All Users' : notif.userId} • {new Date(notif.createdAt).toLocaleDateString()}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
