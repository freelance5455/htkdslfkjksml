import React, { useState, useMemo } from 'react';
import {
  ArrowRightLeft,
  DollarSign,
  Wallet,
  Building,
  User,
  Users,
  ShieldCheck,
  CheckCircle,
  AlertTriangle,
  FileText,
  Copy,
  Check,
  Clock,
  Printer,
  Search,
  Plus,
  RefreshCw,
  Coins,
  Gem,
  Landmark,
  ArrowDownRight,
  ArrowUpRight,
  ExternalLink,
  ChevronDown,
  Info,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import {
  UserProfile,
  TransactionRecord,
  CashierAgent,
  TransferVoucher,
  CurrencyTransferChannel,
} from '../../types';
import { soundFX } from '../../utils/soundEffects';
import {
  saveAuditRecordToFirestore,
  saveTransferVoucherToFirestore,
  saveCashierAgentToFirestore,
} from '../../utils/firebaseSync';

interface CurrencyTransferSystemProps {
  currentUser: UserProfile;
  onUpdateUser: (u: UserProfile) => void;
  transactions: TransactionRecord[];
  onUpdateTransactions: (updater: (prev: TransactionRecord[]) => TransactionRecord[]) => void;
  showToast: (msg: string) => void;
  onNavigateToAuditLog?: (txId?: string) => void;
}

export const CurrencyTransferSystem: React.FC<CurrencyTransferSystemProps> = ({
  currentUser,
  onUpdateUser,
  transactions,
  onUpdateTransactions,
  showToast,
  onNavigateToAuditLog,
}) => {
  // Main Navigation within Transfer System
  const [activeChannelTab, setActiveChannelTab] = useState<
    'admin_to_account' | 'admin_to_cashier' | 'cashier_to_account' | 'vouchers' | 'cashier_wallets'
  >('admin_to_account');

  // List of known Cashier Agents
  const [cashierAgents, setCashierAgents] = useState<CashierAgent[]>([
    {
      id: 'csh_01',
      name: 'سليم النجار (Saleem)',
      code: 'DXB_DESK_01',
      branchName: 'كاشير دبي الرقمي 🇦🇪',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      status: 'ACTIVE',
      balanceUsd: 18500,
      balanceCoins: 350000,
      balanceGems: 1200,
      totalTransferredToPlayers: 42300,
      totalReceivedFromAdmin: 60000,
      commissionRate: 1.0,
      phone: '+971 50 123 4567',
    },
    {
      id: 'csh_02',
      name: 'فهد المطيري (Fahad)',
      code: 'RYD_DESK_02',
      branchName: 'كاشير الرياض المركزي 🇸🇦',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      status: 'ACTIVE',
      balanceUsd: 24000,
      balanceCoins: 580000,
      balanceGems: 2500,
      totalTransferredToPlayers: 68100,
      totalReceivedFromAdmin: 90000,
      commissionRate: 1.2,
      phone: '+966 55 987 6543',
    },
    {
      id: 'csh_03',
      name: 'محفظة USDT TRC-20 الآلية',
      code: 'CRYPTO_BOT_03',
      branchName: 'بوابة الكاشير الرقمي المشفر 💎',
      avatar: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?w=100&h=100&fit=crop',
      status: 'ACTIVE',
      balanceUsd: 31200,
      balanceCoins: 120000,
      balanceGems: 800,
      totalTransferredToPlayers: 89400,
      totalReceivedFromAdmin: 120000,
      commissionRate: 0.5,
      phone: 'TRC20: TTabeonaAutomatedVault99xQ',
    },
    {
      id: 'csh_04',
      name: 'مراد أوغلو (Murad)',
      code: 'IST_DESK_04',
      branchName: 'مكتب اسطنبول والشرق الأوسط 🇹🇷',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      status: 'ACTIVE',
      balanceUsd: 11400,
      balanceCoins: 210000,
      balanceGems: 950,
      totalTransferredToPlayers: 31000,
      totalReceivedFromAdmin: 42000,
      commissionRate: 1.5,
      phone: '+90 532 111 2233',
    },
  ]);

  // Registered players for transfers
  const [playersList, setPlayersList] = useState([
    {
      id: currentUser.id,
      name: currentUser.name,
      avatar: currentUser.avatar,
      title: currentUser.title,
      coins: currentUser.coins,
      gems: currentUser.gems,
      realCashBalance: currentUser.realCashBalance,
      isCurrentUser: true,
    },
    {
      id: '62194',
      name: 'سامي (Sami)',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop',
      title: 'بطل الطرنيب',
      coins: 22150,
      gems: 45,
      realCashBalance: 480,
      isCurrentUser: false,
    },
    {
      id: '49201',
      name: 'أحمد (Ahmed)',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&h=100&fit=crop',
      title: 'محترف تركس',
      coins: 21100,
      gems: 30,
      realCashBalance: 250,
      isCurrentUser: false,
    },
    {
      id: '38192',
      name: 'ليلى (Laila)',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      title: 'أميرة اللعبة',
      coins: 17900,
      gems: 80,
      realCashBalance: 1100,
      isCurrentUser: false,
    },
    {
      id: '12093',
      name: 'صقر العرب',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=100&h=100&fit=crop',
      title: 'فارس الطاولة',
      coins: 8400,
      gems: 170,
      realCashBalance: 320,
      isCurrentUser: false,
    },
  ]);

  // Transfer Vouchers List
  const [vouchers, setVouchers] = useState<TransferVoucher[]>([
    {
      voucherId: 'VCHR-2026-0881',
      channel: 'ADMIN_TO_ACCOUNT',
      senderRole: 'OWNER (لوحة التحكم المركزية)',
      senderName: 'Al-Ali (المالك)',
      senderId: 'ROOT_ADMIN',
      receiverType: 'ACCOUNT',
      receiverName: 'Player 1',
      receiverId: '78453',
      currencyType: 'COINS',
      amount: 5000,
      fee: 0,
      finalAmount: 5000,
      timestamp: '2026-10-10 09:15:22',
      reasonCategory: 'مكافأة إدارية تشجيعية',
      notes: 'إيداع إداري مباشر لتعزيز رصيد الحساب الملكي',
      auditHash: 'sha256:7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f',
      status: 'COMPLETED',
      sourceLedgerTxId: 'TX-904815',
    },
    {
      voucherId: 'VCHR-2026-0880',
      channel: 'ADMIN_TO_CASHIER',
      senderRole: 'ADMIN (إدارة الخزينة)',
      senderName: 'أحمد الإداري',
      senderId: 'ADM_02',
      receiverType: 'CASHIER',
      receiverName: 'كاشير دبي الرقمي 🇦🇪 (DXB_DESK_01)',
      receiverId: 'csh_01',
      currencyType: 'REAL_USD',
      amount: 15000,
      fee: 0,
      finalAmount: 15000,
      timestamp: '2026-10-10 08:30:00',
      reasonCategory: 'تغذية سيولة الخزينة التشغيلية',
      notes: 'تحويل سيولة بنكية معتمدة لتغطية سحوبات نهاية الأسبوع',
      auditHash: 'sha256:11223344556677889900aabbccddeeff1122334455667788',
      status: 'COMPLETED',
    },
    {
      voucherId: 'VCHR-2026-0879',
      channel: 'CASHIER_TO_ACCOUNT',
      senderRole: 'CASHIER (مكتب الكاشير)',
      senderName: 'فهد المطيري (كاشير الرياض)',
      senderId: 'csh_02',
      receiverType: 'ACCOUNT',
      receiverName: 'سامي (Sami)',
      receiverId: '62194',
      currencyType: 'REAL_USD',
      amount: 500,
      fee: 0,
      finalAmount: 500,
      timestamp: '2026-10-10 07:45:10',
      reasonCategory: 'شحن رصيد نقدي مباشر',
      notes: 'إيداع نقدي تم استلامه يداً بيد في الفرع وتغذية حساب اللاعب فوراً',
      auditHash: 'sha256:99887766554433221100ffeeddccbbaa9988776655443322',
      status: 'COMPLETED',
      sourceLedgerTxId: 'TX-CASHIER-APP-9941',
    },
  ]);

  // Form 1 State: Admin -> Account
  const [adminToAccountForm, setAdminToAccountForm] = useState({
    targetPlayerId: currentUser.id,
    currencyType: 'COINS' as 'COINS' | 'GEMS' | 'REAL_USD',
    amount: 1000,
    reasonCategory: 'مكافأة إدارية تشجيعية',
    notes: 'تحويل مباشر من لوحة التحكم الإدارية',
  });

  // Form 2 State: Admin -> Cashier
  const [adminToCashierForm, setAdminToCashierForm] = useState({
    targetCashierId: 'csh_01',
    currencyType: 'REAL_USD' as 'REAL_USD' | 'COINS' | 'GEMS',
    amount: 10000,
    reasonCategory: 'تغذية سيولة الخزينة التشغيلية',
    notes: 'تحويل سيولة معتمدة من الإدارة العامة إلى حساب الكاشير',
  });

  // Form 3 State: Cashier -> Account
  const [cashierToAccountForm, setCashierToAccountForm] = useState({
    sourceCashierId: 'csh_01',
    targetPlayerId: currentUser.id,
    currencyType: 'COINS' as 'COINS' | 'REAL_USD' | 'GEMS',
    amount: 500,
    reasonCategory: 'شحن حساب لاعب عبر الكاشير',
    notes: 'إيداع وتغذية حساب لاعب عبر مكتب الكاشير المعتمد',
  });

  // Modals / Receipts
  const [activeVoucherModal, setActiveVoucherModal] = useState<TransferVoucher | null>(null);
  const [copiedVoucherId, setCopiedVoucherId] = useState<string | null>(null);

  // Sync current user with playersList
  const activeCurrentPlayerInList = useMemo(() => {
    return {
      id: currentUser.id,
      name: currentUser.name,
      avatar: currentUser.avatar,
      title: currentUser.title,
      coins: currentUser.coins,
      gems: currentUser.gems,
      realCashBalance: currentUser.realCashBalance,
      isCurrentUser: true,
    };
  }, [currentUser]);

  // Aggregated Stats
  const systemTotals = useMemo(() => {
    const totalCashierUsd = cashierAgents.reduce((sum, c) => sum + c.balanceUsd, 0);
    const totalCashierCoins = cashierAgents.reduce((sum, c) => sum + c.balanceCoins, 0);
    const totalVouchersCount = vouchers.length;
    const adminToAccCount = vouchers.filter((v) => v.channel === 'ADMIN_TO_ACCOUNT').length;
    const adminToCashierCount = vouchers.filter((v) => v.channel === 'ADMIN_TO_CASHIER').length;
    const cashierToAccCount = vouchers.filter((v) => v.channel === 'CASHIER_TO_ACCOUNT').length;

    return {
      totalCashierUsd,
      totalCashierCoins,
      totalVouchersCount,
      adminToAccCount,
      adminToCashierCount,
      cashierToAccCount,
    };
  }, [cashierAgents, vouchers]);

  // Helper to copy text
  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedVoucherId(id);
    showToast('✓ تم نسخ رقم السند إلى الحافظة');
    setTimeout(() => setCopiedVoucherId(null), 2500);
  };

  // =========================================================================
  // EXECUTION 1: ADMIN -> PLAYER ACCOUNT
  // =========================================================================
  const handleExecuteAdminToAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(adminToAccountForm.amount);
    if (amt <= 0 || isNaN(amt)) {
      showToast('⚠️ الرجاء إدخال مبلغ صحيح أكبر من الصفر');
      return;
    }

    soundFX.playCoin();

    const targetPlayer =
      adminToAccountForm.targetPlayerId === currentUser.id
        ? activeCurrentPlayerInList
        : playersList.find((p) => p.id === adminToAccountForm.targetPlayerId) || {
            id: adminToAccountForm.targetPlayerId,
            name: 'حساب مخصص',
            avatar: '',
            title: 'لاعب',
            coins: 10000,
            gems: 50,
            realCashBalance: 100,
            isCurrentUser: false,
          };

    // Calculate before/after
    const beforeBalance =
      adminToAccountForm.currencyType === 'COINS'
        ? targetPlayer.coins
        : adminToAccountForm.currencyType === 'GEMS'
        ? targetPlayer.gems
        : targetPlayer.realCashBalance;

    const afterBalance = beforeBalance + amt;

    const voucherId = `VCHR-${Date.now().toString().slice(-6)}`;
    const txId = `TX-ADM-ACC-${Math.floor(100000 + Math.random() * 900000)}`;
    const auditHash = `sha256:${Array.from({ length: 48 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('')}`;

    // 1. Create Transfer Voucher
    const newVoucher: TransferVoucher = {
      voucherId,
      channel: 'ADMIN_TO_ACCOUNT',
      senderRole: `ADMIN [${currentUser.role}]`,
      senderName: currentUser.name,
      senderId: currentUser.id,
      receiverType: 'ACCOUNT',
      receiverName: targetPlayer.name,
      receiverId: targetPlayer.id,
      currencyType: adminToAccountForm.currencyType,
      amount: amt,
      fee: 0,
      finalAmount: amt,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      reasonCategory: adminToAccountForm.reasonCategory,
      notes: adminToAccountForm.notes,
      auditHash,
      status: 'COMPLETED',
      sourceLedgerTxId: txId,
    };

    // 2. Create Audit Ledger Record
    const auditRecord: TransactionRecord = {
      transactionId: txId,
      ledgerSequence: transactions.length + 1045,
      playerId: targetPlayer.id,
      playerName: targetPlayer.name,
      cashierOrAdminId: `[${currentUser.role}] ${currentUser.name}`,
      amount: amt,
      currencyType: adminToAccountForm.currencyType,
      balanceBefore: beforeBalance,
      balanceAfter: afterBalance,
      timestamp: newVoucher.timestamp,
      status: 'COMPLETED',
      sourceMethod: 'ADMIN_OVERRIDE',
      referenceNote: `[تحويل إداري لحساب لاعب] ${adminToAccountForm.reasonCategory} - سند: #${voucherId} (${adminToAccountForm.notes})`,
      auditHash,
      ipAddress: '127.0.0.1 (Root Admin Session)',
      sessionId: `sess_adm_transfer_${Date.now()}`,
    };

    // 3. Update States
    setVouchers([newVoucher, ...vouchers]);
    onUpdateTransactions((prev) => [auditRecord, ...prev]);

    // Save to Firestore
    saveAuditRecordToFirestore(auditRecord);
    saveTransferVoucherToFirestore(newVoucher);

    // Update Player Balance
    if (targetPlayer.id === currentUser.id) {
      if (adminToAccountForm.currencyType === 'COINS') {
        onUpdateUser({ ...currentUser, coins: afterBalance });
      } else if (adminToAccountForm.currencyType === 'GEMS') {
        onUpdateUser({ ...currentUser, gems: afterBalance });
      } else {
        onUpdateUser({ ...currentUser, realCashBalance: afterBalance });
      }
    } else {
      setPlayersList((prev) =>
        prev.map((p) => {
          if (p.id === targetPlayer.id) {
            return {
              ...p,
              coins: adminToAccountForm.currencyType === 'COINS' ? p.coins + amt : p.coins,
              gems: adminToAccountForm.currencyType === 'GEMS' ? p.gems + amt : p.gems,
              realCashBalance:
                adminToAccountForm.currencyType === 'REAL_USD'
                  ? p.realCashBalance + amt
                  : p.realCashBalance,
            };
          }
          return p;
        })
      );
    }

    setActiveVoucherModal(newVoucher);
    showToast(`✓ تم التحويل بنجاح لحساب ${targetPlayer.name} وتم إصدار السند #${voucherId}`);
  };

  // =========================================================================
  // EXECUTION 2: ADMIN -> CASHIER
  // =========================================================================
  const handleExecuteAdminToCashier = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(adminToCashierForm.amount);
    if (amt <= 0 || isNaN(amt)) {
      showToast('⚠️ الرجاء إدخال مبلغ صحيح أكبر من الصفر');
      return;
    }

    const targetCashier = cashierAgents.find((c) => c.id === adminToCashierForm.targetCashierId);
    if (!targetCashier) {
      showToast('❌ لم يتم العثور على الكاشير المحدد');
      return;
    }

    soundFX.playVictoryFanfare();

    const voucherId = `VCHR-${Date.now().toString().slice(-6)}`;
    const txId = `TX-ADM-CSH-${Math.floor(100000 + Math.random() * 900000)}`;
    const auditHash = `sha256:${Array.from({ length: 48 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('')}`;

    const beforeBal =
      adminToCashierForm.currencyType === 'REAL_USD'
        ? targetCashier.balanceUsd
        : adminToCashierForm.currencyType === 'COINS'
        ? targetCashier.balanceCoins
        : targetCashier.balanceGems;

    const afterBal = beforeBal + amt;

    const newVoucher: TransferVoucher = {
      voucherId,
      channel: 'ADMIN_TO_CASHIER',
      senderRole: `ADMIN_TREASURY [${currentUser.role}]`,
      senderName: currentUser.name,
      senderId: currentUser.id,
      receiverType: 'CASHIER',
      receiverName: `${targetCashier.branchName} (${targetCashier.code})`,
      receiverId: targetCashier.id,
      currencyType: adminToCashierForm.currencyType,
      amount: amt,
      fee: 0,
      finalAmount: amt,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      reasonCategory: adminToCashierForm.reasonCategory,
      notes: adminToCashierForm.notes,
      auditHash,
      status: 'COMPLETED',
      sourceLedgerTxId: txId,
    };

    const auditRecord: TransactionRecord = {
      transactionId: txId,
      ledgerSequence: transactions.length + 1045,
      playerId: `CSH_${targetCashier.code}`,
      playerName: `[كاشير] ${targetCashier.name} - ${targetCashier.branchName}`,
      cashierOrAdminId: `[${currentUser.role}] ${currentUser.name}`,
      amount: amt,
      currencyType: adminToCashierForm.currencyType,
      balanceBefore: beforeBal,
      balanceAfter: afterBal,
      timestamp: newVoucher.timestamp,
      status: 'COMPLETED',
      sourceMethod: 'ADMIN_OVERRIDE',
      referenceNote: `[تغذية خزينة كاشير] ${adminToCashierForm.reasonCategory} لكاشير ${targetCashier.branchName} - سند: #${voucherId}`,
      auditHash,
      ipAddress: '127.0.0.1 (Treasury Terminal)',
      sessionId: `sess_treasury_${Date.now()}`,
    };

    // Update Cashier State
    const updatedAgent: CashierAgent = {
      ...targetCashier,
      balanceUsd:
        adminToCashierForm.currencyType === 'REAL_USD'
          ? targetCashier.balanceUsd + amt
          : targetCashier.balanceUsd,
      balanceCoins:
        adminToCashierForm.currencyType === 'COINS'
          ? targetCashier.balanceCoins + amt
          : targetCashier.balanceCoins,
      balanceGems:
        adminToCashierForm.currencyType === 'GEMS'
          ? targetCashier.balanceGems + amt
          : targetCashier.balanceGems,
      totalReceivedFromAdmin: targetCashier.totalReceivedFromAdmin + amt,
    };

    setCashierAgents((prev) => prev.map((c) => (c.id === targetCashier.id ? updatedAgent : c)));
    setVouchers([newVoucher, ...vouchers]);
    onUpdateTransactions((prev) => [auditRecord, ...prev]);

    saveAuditRecordToFirestore(auditRecord);
    saveTransferVoucherToFirestore(newVoucher);
    saveCashierAgentToFirestore(updatedAgent);

    setActiveVoucherModal(newVoucher);
    showToast(`✓ تم تغذية خزينة كاشير ${targetCashier.branchName} بمبلغ ${amt.toLocaleString()} بنجاح`);
  };

  // =========================================================================
  // EXECUTION 3: CASHIER -> PLAYER ACCOUNT
  // =========================================================================
  const handleExecuteCashierToAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(cashierToAccountForm.amount);
    if (amt <= 0 || isNaN(amt)) {
      showToast('⚠️ الرجاء إدخال مبلغ صحيح أكبر من الصفر');
      return;
    }

    const sourceCashier = cashierAgents.find((c) => c.id === cashierToAccountForm.sourceCashierId);
    if (!sourceCashier) {
      showToast('❌ لم يتم العثور على الكاشير المصدر');
      return;
    }

    // Check Cashier Balance (Ensure sufficient funds)
    const cashierAvail =
      cashierToAccountForm.currencyType === 'REAL_USD'
        ? sourceCashier.balanceUsd
        : cashierToAccountForm.currencyType === 'COINS'
        ? sourceCashier.balanceCoins
        : sourceCashier.balanceGems;

    if (cashierAvail < amt) {
      showToast(
        `⚠️ رصيد خزينة الكاشير غير كافٍ! المتوفر: ${cashierAvail.toLocaleString()} والمطلوب تحويله: ${amt.toLocaleString()}`
      );
      return;
    }

    const targetPlayer =
      cashierToAccountForm.targetPlayerId === currentUser.id
        ? activeCurrentPlayerInList
        : playersList.find((p) => p.id === cashierToAccountForm.targetPlayerId) || {
            id: cashierToAccountForm.targetPlayerId,
            name: 'حساب مخصص',
            avatar: '',
            title: 'لاعب',
            coins: 10000,
            gems: 50,
            realCashBalance: 100,
            isCurrentUser: false,
          };

    soundFX.playCoin();

    const voucherId = `VCHR-${Date.now().toString().slice(-6)}`;
    const txId = `TX-CSH-ACC-${Math.floor(100000 + Math.random() * 900000)}`;
    const auditHash = `sha256:${Array.from({ length: 48 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('')}`;

    const playerBeforeBal =
      cashierToAccountForm.currencyType === 'COINS'
        ? targetPlayer.coins
        : cashierToAccountForm.currencyType === 'GEMS'
        ? targetPlayer.gems
        : targetPlayer.realCashBalance;

    const playerAfterBal = playerBeforeBal + amt;

    const newVoucher: TransferVoucher = {
      voucherId,
      channel: 'CASHIER_TO_ACCOUNT',
      senderRole: `CASHIER_DESK [${sourceCashier.code}]`,
      senderName: `${sourceCashier.name} (${sourceCashier.branchName})`,
      senderId: sourceCashier.id,
      receiverType: 'ACCOUNT',
      receiverName: targetPlayer.name,
      receiverId: targetPlayer.id,
      currencyType: cashierToAccountForm.currencyType,
      amount: amt,
      fee: 0,
      finalAmount: amt,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      reasonCategory: cashierToAccountForm.reasonCategory,
      notes: cashierToAccountForm.notes,
      auditHash,
      status: 'COMPLETED',
      sourceLedgerTxId: txId,
    };

    // Double-entry record for audit
    const auditRecord: TransactionRecord = {
      transactionId: txId,
      ledgerSequence: transactions.length + 1045,
      playerId: targetPlayer.id,
      playerName: targetPlayer.name,
      cashierOrAdminId: `[كاشير] ${sourceCashier.name} (${sourceCashier.code})`,
      amount: amt,
      currencyType: cashierToAccountForm.currencyType,
      balanceBefore: playerBeforeBal,
      balanceAfter: playerAfterBal,
      timestamp: newVoucher.timestamp,
      status: 'COMPLETED',
      sourceMethod: 'CASHIER_TRANSFER',
      referenceNote: `[تحويل من الكاشير للاعب] من خزينة ${sourceCashier.branchName} إلى اللاعب ${targetPlayer.name} - سند: #${voucherId}`,
      auditHash,
      ipAddress: '192.168.1.108 (Cashier Verified Desk)',
      sessionId: `sess_cashier_point_${Date.now()}`,
    };

    // Deduct from Cashier
    const updatedAgent: CashierAgent = {
      ...sourceCashier,
      balanceUsd:
        cashierToAccountForm.currencyType === 'REAL_USD'
          ? sourceCashier.balanceUsd - amt
          : sourceCashier.balanceUsd,
      balanceCoins:
        cashierToAccountForm.currencyType === 'COINS'
          ? sourceCashier.balanceCoins - amt
          : sourceCashier.balanceCoins,
      balanceGems:
        cashierToAccountForm.currencyType === 'GEMS'
          ? sourceCashier.balanceGems - amt
          : sourceCashier.balanceGems,
      totalTransferredToPlayers: sourceCashier.totalTransferredToPlayers + amt,
    };

    setCashierAgents((prev) => prev.map((c) => (c.id === sourceCashier.id ? updatedAgent : c)));
    setVouchers([newVoucher, ...vouchers]);
    onUpdateTransactions((prev) => [auditRecord, ...prev]);

    saveAuditRecordToFirestore(auditRecord);
    saveTransferVoucherToFirestore(newVoucher);
    saveCashierAgentToFirestore(updatedAgent);

    // Update Player
    if (targetPlayer.id === currentUser.id) {
      if (cashierToAccountForm.currencyType === 'COINS') {
        onUpdateUser({ ...currentUser, coins: playerAfterBal });
      } else if (cashierToAccountForm.currencyType === 'GEMS') {
        onUpdateUser({ ...currentUser, gems: playerAfterBal });
      } else {
        onUpdateUser({ ...currentUser, realCashBalance: playerAfterBal });
      }
    } else {
      setPlayersList((prev) =>
        prev.map((p) => {
          if (p.id === targetPlayer.id) {
            return {
              ...p,
              coins: cashierToAccountForm.currencyType === 'COINS' ? p.coins + amt : p.coins,
              gems: cashierToAccountForm.currencyType === 'GEMS' ? p.gems + amt : p.gems,
              realCashBalance:
                cashierToAccountForm.currencyType === 'REAL_USD'
                  ? p.realCashBalance + amt
                  : p.realCashBalance,
            };
          }
          return p;
        })
      );
    }

    setActiveVoucherModal(newVoucher);
    showToast(
      `✓ تم تحويل ${amt.toLocaleString()} من ${sourceCashier.branchName} إلى ${targetPlayer.name} بنجاح`
    );
  };

  return (
    <div className="space-y-5 text-right font-sans">
      {/* =========================================================================
          TOP STATS & OVERVIEW BAR
         ========================================================================= */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
          <div className="text-[11px] text-gray-400 font-bold flex items-center justify-between">
            <span>إجمالي خزائن الكاشير</span>
            <Landmark className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-amber-300 font-mono mt-1">
            ${systemTotals.totalCashierUsd.toLocaleString()}
          </div>
          <div className="text-[10px] text-emerald-400 mt-0.5">
            + {systemTotals.totalCashierCoins.toLocaleString()} كوينز سيولة
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
          <div className="text-[11px] text-gray-400 font-bold flex items-center justify-between">
            <span>عدد سندات التحويل الصادرة</span>
            <FileText className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono mt-1">
            {systemTotals.totalVouchersCount} سند
          </div>
          <div className="text-[10px] text-amber-300 mt-0.5">
            موثقة ومختومة بتجزئة SHA-256
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
          <div className="text-[11px] text-gray-400 font-bold flex items-center justify-between">
            <span>تحويلات الكاشير للاعبين</span>
            <ArrowDownRight className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
            {systemTotals.cashierToAccCount} عملية
          </div>
          <div className="text-[10px] text-gray-400 mt-0.5">
            شحن مباشر عبر الموزعين
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#06170d] border border-amber-950/80 shadow">
          <div className="text-[11px] text-gray-400 font-bold flex items-center justify-between">
            <span>تحويلات الإدارة المركزية</span>
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 font-mono mt-1">
            {systemTotals.adminToAccCount + systemTotals.adminToCashierCount} عملية
          </div>
          <div className="text-[10px] text-emerald-400 mt-0.5">
            تغذية خزائن ومكافآت
          </div>
        </div>
      </div>

      {/* =========================================================================
          CHANNEL NAVIGATION TABS
         ========================================================================= */}
      <div className="bg-[#05110a] p-1.5 rounded-2xl border border-amber-900/60 flex flex-wrap gap-1.5">
        <button
          onClick={() => {
            soundFX.playButtonClick();
            setActiveChannelTab('admin_to_account');
          }}
          className={`flex-1 min-w-[200px] py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all ${
            activeChannelTab === 'admin_to_account'
              ? 'bg-gradient-to-r from-emerald-950 via-emerald-800 to-emerald-950 text-amber-300 border border-amber-500/60 shadow-lg'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Building className="w-4 h-4 text-amber-400" />
          <span>1. من لوحة التحكم &larr; إلى الحسابات</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-mono">
            Direct
          </span>
        </button>

        <button
          onClick={() => {
            soundFX.playButtonClick();
            setActiveChannelTab('admin_to_cashier');
          }}
          className={`flex-1 min-w-[200px] py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all ${
            activeChannelTab === 'admin_to_cashier'
              ? 'bg-gradient-to-r from-emerald-950 via-emerald-800 to-emerald-950 text-amber-300 border border-amber-500/60 shadow-lg'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Landmark className="w-4 h-4 text-emerald-400" />
          <span>2. من لوحة التحكم &larr; إلى الكاشير</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">
            Treasury
          </span>
        </button>

        <button
          onClick={() => {
            soundFX.playButtonClick();
            setActiveChannelTab('cashier_to_account');
          }}
          className={`flex-1 min-w-[200px] py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all ${
            activeChannelTab === 'cashier_to_account'
              ? 'bg-gradient-to-r from-emerald-950 via-emerald-800 to-emerald-950 text-amber-300 border border-amber-500/60 shadow-lg'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Wallet className="w-4 h-4 text-amber-400" />
          <span>3. من الكاشير &larr; إلى الحسابات</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-mono">
            Player Desk
          </span>
        </button>

        <button
          onClick={() => {
            soundFX.playButtonClick();
            setActiveChannelTab('vouchers');
          }}
          className={`py-2.5 px-3.5 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all ${
            activeChannelTab === 'vouchers'
              ? 'bg-gradient-to-r from-emerald-950 via-emerald-800 to-emerald-950 text-amber-300 border border-amber-500/60 shadow-lg'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileText className="w-4 h-4 text-amber-400" />
          <span>أرشيف السندات ({vouchers.length})</span>
        </button>

        <button
          onClick={() => {
            soundFX.playButtonClick();
            setActiveChannelTab('cashier_wallets');
          }}
          className={`py-2.5 px-3.5 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all ${
            activeChannelTab === 'cashier_wallets'
              ? 'bg-gradient-to-r from-emerald-950 via-emerald-800 to-emerald-950 text-amber-300 border border-amber-500/60 shadow-lg'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4 text-emerald-400" />
          <span>خزائن الكاشير ({cashierAgents.length})</span>
        </button>
      </div>

      {/* =========================================================================
          TAB 1: ADMIN -> PLAYER ACCOUNT
         ========================================================================= */}
      {activeChannelTab === 'admin_to_account' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Main Form */}
          <div className="lg:col-span-2 p-5 rounded-2xl bg-[#06180d] border border-amber-900/60 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-950/80 pb-3">
              <div className="flex items-center gap-2">
                <Building className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-black text-sm text-white">
                    تحويل مباشر: من لوحة التحكم &larr; إلى حساب لاعب
                  </h3>
                  <p className="text-[11px] text-gray-400">
                    صرف وشحن مباشر للرصيد بصفة إدارية معتمدة وموثقة في سجل التدقيق
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold">
                Admin Direct Credit
              </span>
            </div>

            <form onSubmit={handleExecuteAdminToAccount} className="space-y-4 text-xs">
              {/* Recipient Account Selector */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">
                  اختر الحساب المستفيد (اللاعب):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {playersList.map((player) => {
                    const isSelected = adminToAccountForm.targetPlayerId === player.id;
                    return (
                      <div
                        key={player.id}
                        onClick={() => {
                          soundFX.playButtonClick();
                          setAdminToAccountForm({ ...adminToAccountForm, targetPlayerId: player.id });
                        }}
                        className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center gap-2.5 ${
                          isSelected
                            ? 'bg-[#0d311c] border-amber-400 text-white shadow-md'
                            : 'bg-[#040e08] border-amber-950 hover:border-amber-900/60 text-gray-300'
                        }`}
                      >
                        <img
                          src={player.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&h=50&fit=crop'}
                          alt={player.name}
                          className="w-8 h-8 rounded-full border border-amber-500/50 object-cover shrink-0"
                        />
                        <div className="overflow-hidden">
                          <div className="font-bold truncate text-[11px] flex items-center gap-1">
                            <span>{player.name}</span>
                            {player.isCurrentUser && (
                              <span className="text-[9px] px-1 bg-emerald-500/20 text-emerald-300 rounded">
                                أنت
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-gray-400 font-mono">
                            🪙 {player.coins.toLocaleString()} • 💵 ${player.realCashBalance.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Currency Selection */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">نوع العملة المراد تحويلها:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { type: 'COINS' as const, label: 'الكوينز الذهبية (Coins)', icon: Coins, color: 'text-amber-400' },
                    { type: 'GEMS' as const, label: 'الجواهر الزمردية (Gems)', icon: Gem, color: 'text-emerald-400' },
                    { type: 'REAL_USD' as const, label: 'النقود الحقيقية (USD $)', icon: DollarSign, color: 'text-green-400' },
                  ].map((curr) => {
                    const Icon = curr.icon;
                    const isSelected = adminToAccountForm.currencyType === curr.type;
                    return (
                      <button
                        key={curr.type}
                        type="button"
                        onClick={() => {
                          soundFX.playButtonClick();
                          setAdminToAccountForm({ ...adminToAccountForm, currencyType: curr.type });
                        }}
                        className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-[#0f3820] border-amber-400 text-amber-300 shadow-md'
                            : 'bg-[#040e08] border-amber-950 text-gray-400 hover:text-gray-200'
                        }`}
                      >
                        <Icon className={`w-5 h-5 ${curr.color}`} />
                        <span className="font-bold text-[11px]">{curr.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Amount & Quick Chips */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">المبلغ المراد تحويله:</label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    value={adminToAccountForm.amount}
                    onChange={(e) =>
                      setAdminToAccountForm({ ...adminToAccountForm, amount: Number(e.target.value) })
                    }
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-amber-400 rounded-xl p-3 text-white font-mono font-black text-base pr-4 focus:outline-none"
                    placeholder="أدخل المبلغ..."
                    required
                  />
                  <span className="absolute left-4 top-3.5 text-xs text-amber-400 font-bold">
                    {adminToAccountForm.currencyType === 'COINS'
                      ? '🪙 كوينز'
                      : adminToAccountForm.currencyType === 'GEMS'
                      ? '💎 جواهر'
                      : '💵 دولار USD'}
                  </span>
                </div>

                {/* Quick amount chips */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {(adminToAccountForm.currencyType === 'REAL_USD'
                    ? [50, 100, 250, 500, 1000, 5000]
                    : [500, 1000, 5000, 10000, 25000, 50000]
                  ).map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => {
                        soundFX.playButtonClick();
                        setAdminToAccountForm({ ...adminToAccountForm, amount: val });
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#040e08] hover:bg-[#081f12] border border-amber-950 text-amber-300 text-[10px] font-mono font-bold"
                    >
                      +{val.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reason Category */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">تصنيف سبب التحويل:</label>
                  <select
                    value={adminToAccountForm.reasonCategory}
                    onChange={(e) =>
                      setAdminToAccountForm({ ...adminToAccountForm, reasonCategory: e.target.value })
                    }
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-amber-400 rounded-xl p-2.5 text-white focus:outline-none"
                  >
                    <option value="مكافأة إدارية تشجيعية">مكافأة إدارية تشجيعية</option>
                    <option value="شحن مباشر من الإدارة">شحن مباشر من الإدارة</option>
                    <option value="تعويض خلل فني أو انقطاع">تعويض خلل فني أو انقطاع</option>
                    <option value="مكافأة ترقية VIP ورتبة">مكافأة ترقية VIP ورتبة</option>
                    <option value="جائزة بطولة استثنائية">جائزة بطولة استثنائية</option>
                    <option value="تسوية حساب مصرفي">تسوية حساب مصرفي</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">ملاحظات مرجعية:</label>
                  <input
                    type="text"
                    value={adminToAccountForm.notes}
                    onChange={(e) =>
                      setAdminToAccountForm({ ...adminToAccountForm, notes: e.target.value })
                    }
                    placeholder="ملاحظات تظهر في السند..."
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-amber-400 rounded-xl p-2.5 text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-black font-black text-sm shadow-[0_0_20px_rgba(245,158,11,0.4)] hover:brightness-110 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <ShieldCheck className="w-5 h-5 text-black" />
                  <span>
                    اعتماد التحويل لحساب اللاعب فوراً وإصدار السند المالي ⚡
                  </span>
                </button>
              </div>
            </form>
          </div>

          {/* Side Info & Selected Target Preview */}
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-[#05110a] border border-amber-950 space-y-3">
              <h4 className="font-black text-xs text-amber-300 flex items-center gap-2">
                <Info className="w-4 h-4 text-amber-400" />
                <span>معاينة المستفيد قبل الاعتماد:</span>
              </h4>

              {(() => {
                const target =
                  adminToAccountForm.targetPlayerId === currentUser.id
                    ? activeCurrentPlayerInList
                    : playersList.find((p) => p.id === adminToAccountForm.targetPlayerId);
                if (!target) return null;
                const curVal =
                  adminToAccountForm.currencyType === 'COINS'
                    ? target.coins
                    : adminToAccountForm.currencyType === 'GEMS'
                    ? target.gems
                    : target.realCashBalance;
                const newVal = curVal + Number(adminToAccountForm.amount || 0);

                return (
                  <div className="p-3.5 rounded-xl bg-[#030804] border border-amber-950/60 space-y-2.5">
                    <div className="flex items-center gap-3">
                      <img
                        src={target.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&h=50&fit=crop'}
                        alt={target.name}
                        className="w-10 h-10 rounded-full border border-amber-500/50 object-cover"
                      />
                      <div>
                        <div className="font-bold text-white text-xs">{target.name}</div>
                        <div className="text-[10px] text-amber-400 font-mono">ID: #{target.id}</div>
                      </div>
                    </div>

                    <div className="border-t border-amber-950/80 pt-2 space-y-1.5 text-[11px]">
                      <div className="flex justify-between text-gray-400">
                        <span>الرصيد الحالي:</span>
                        <span className="font-mono text-gray-200">{curVal.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-emerald-400 font-bold">
                        <span>المبلغ المضاف (+):</span>
                        <span className="font-mono">
                          +{Number(adminToAccountForm.amount || 0).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between text-amber-300 font-black border-t border-amber-950/40 pt-1">
                        <span>الرصيد بعد التحويل:</span>
                        <span className="font-mono text-xs">{newVal.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30 text-[10px] text-amber-200/90 leading-relaxed">
                <span className="font-bold text-amber-300">ملاحظة أمنية:</span> عمليات التحويل الإداري
                المباشرة تظهر فوراً في حساب اللاعب دون الحاجة لتحديث الصفحة، وتُقفل برقم تجزئة
                Cryptographic Hash غير قابل للحذف أو التعديل.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: ADMIN -> CASHIER
         ========================================================================= */}
      {activeChannelTab === 'admin_to_cashier' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 p-5 rounded-2xl bg-[#06180d] border border-emerald-900/60 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-950/80 pb-3">
              <div className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-black text-sm text-white">
                    تغذية الخزائن: من لوحة التحكم &larr; إلى الكاشير والموزعين
                  </h3>
                  <p className="text-[11px] text-gray-400">
                    ضخ سيولة نقدية أو كوينز إلى خزائن الكاشير المعتمدين لتمكينهم من خدمة اللاعبين
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold">
                Treasury Allocation
              </span>
            </div>

            <form onSubmit={handleExecuteAdminToCashier} className="space-y-4 text-xs">
              {/* Target Cashier Agent Selection */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">
                  اختر مكتب الكاشير أو الموزع المعتمد:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {cashierAgents.map((agent) => {
                    const isSelected = adminToCashierForm.targetCashierId === agent.id;
                    return (
                      <div
                        key={agent.id}
                        onClick={() => {
                          soundFX.playButtonClick();
                          setAdminToCashierForm({ ...adminToCashierForm, targetCashierId: agent.id });
                        }}
                        className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                          isSelected
                            ? 'bg-[#0a2917] border-emerald-400 text-white shadow-md'
                            : 'bg-[#040e08] border-amber-950 hover:border-emerald-900/60 text-gray-300'
                        }`}
                      >
                        <img
                          src={agent.avatar}
                          alt={agent.name}
                          className="w-9 h-9 rounded-full border border-emerald-500/50 object-cover shrink-0"
                        />
                        <div className="flex-1 overflow-hidden">
                          <div className="font-black text-xs text-white truncate">{agent.branchName}</div>
                          <div className="text-[10px] text-gray-400">{agent.name} ({agent.code})</div>
                          <div className="mt-1 text-[10px] font-mono font-bold text-amber-300">
                            خزينة: ${agent.balanceUsd.toLocaleString()} USD • {agent.balanceCoins.toLocaleString()} كوينز
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Currency */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">نوع السيولة المراد ضخها:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { type: 'REAL_USD' as const, label: 'خزينة نقدية (USD $)', icon: DollarSign, color: 'text-emerald-400' },
                    { type: 'COINS' as const, label: 'رصيد كوينز (Coins)', icon: Coins, color: 'text-amber-400' },
                    { type: 'GEMS' as const, label: 'احتياطي جواهر (Gems)', icon: Gem, color: 'text-blue-400' },
                  ].map((curr) => {
                    const Icon = curr.icon;
                    const isSelected = adminToCashierForm.currencyType === curr.type;
                    return (
                      <button
                        key={curr.type}
                        type="button"
                        onClick={() => {
                          soundFX.playButtonClick();
                          setAdminToCashierForm({ ...adminToCashierForm, currencyType: curr.type });
                        }}
                        className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-[#0f3820] border-emerald-400 text-emerald-300 shadow-md'
                            : 'bg-[#040e08] border-amber-950 text-gray-400 hover:text-gray-200'
                        }`}
                      >
                        <Icon className={`w-5 h-5 ${curr.color}`} />
                        <span className="font-bold text-[11px]">{curr.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Amount */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">مبلغ تغذية الخزينة:</label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    value={adminToCashierForm.amount}
                    onChange={(e) =>
                      setAdminToCashierForm({ ...adminToCashierForm, amount: Number(e.target.value) })
                    }
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-emerald-400 rounded-xl p-3 text-white font-mono font-black text-base pr-4 focus:outline-none"
                    placeholder="أدخل مبلغ الخزينة..."
                    required
                  />
                  <span className="absolute left-4 top-3.5 text-xs text-emerald-400 font-bold">
                    {adminToCashierForm.currencyType === 'REAL_USD'
                      ? '💵 دولار USD'
                      : adminToCashierForm.currencyType === 'COINS'
                      ? '🪙 كوينز'
                      : '💎 جواهر'}
                  </span>
                </div>

                <div className="flex flex-wrap gap-1.5 mt-2">
                  {[2500, 5000, 10000, 25000, 50000, 100000].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => {
                        soundFX.playButtonClick();
                        setAdminToCashierForm({ ...adminToCashierForm, amount: val });
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#040e08] hover:bg-[#081f12] border border-emerald-950 text-emerald-300 text-[10px] font-mono font-bold"
                    >
                      +{val.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reason & Notes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">سبب التغذية:</label>
                  <select
                    value={adminToCashierForm.reasonCategory}
                    onChange={(e) =>
                      setAdminToCashierForm({ ...adminToCashierForm, reasonCategory: e.target.value })
                    }
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-emerald-400 rounded-xl p-2.5 text-white focus:outline-none"
                  >
                    <option value="تغذية سيولة الخزينة التشغيلية">تغذية سيولة الخزينة التشغيلية</option>
                    <option value="توسيع سقف السحب اليومي للمكتب">توسيع سقف السحب اليومي للمكتب</option>
                    <option value="تمويل إيداعات عطلة نهاية الأسبوع">تمويل إيداعات عطلة نهاية الأسبوع</option>
                    <option value="تزويد سيولة كوينز للمسابقات">تزويد سيولة كوينز للمسابقات</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">ملاحظات التحويل:</label>
                  <input
                    type="text"
                    value={adminToCashierForm.notes}
                    onChange={(e) =>
                      setAdminToCashierForm({ ...adminToCashierForm, notes: e.target.value })
                    }
                    placeholder="رقم الحوالة البنكية أو الباتش..."
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-emerald-400 rounded-xl p-2.5 text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 text-white font-black text-sm shadow-[0_0_20px_rgba(16,185,129,0.4)] hover:brightness-110 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Landmark className="w-5 h-5" />
                  <span>تأكيد ضخ السيولة إلى خزينة الكاشير وإصدار سند الإيداع 🏛️</span>
                </button>
              </div>
            </form>
          </div>

          {/* Side Info */}
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-[#05110a] border border-amber-950 space-y-3">
              <h4 className="font-black text-xs text-emerald-300 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>حالة خزينة الكاشير المستهدف:</span>
              </h4>

              {(() => {
                const target = cashierAgents.find((c) => c.id === adminToCashierForm.targetCashierId);
                if (!target) return null;
                const before =
                  adminToCashierForm.currencyType === 'REAL_USD'
                    ? target.balanceUsd
                    : adminToCashierForm.currencyType === 'COINS'
                    ? target.balanceCoins
                    : target.balanceGems;
                const after = before + Number(adminToCashierForm.amount || 0);

                return (
                  <div className="p-3.5 rounded-xl bg-[#030804] border border-emerald-950/60 space-y-2.5 text-[11px]">
                    <div className="font-bold text-white text-xs">{target.branchName}</div>
                    <div className="text-[10px] text-gray-400">{target.phone || target.code}</div>

                    <div className="border-t border-amber-950/80 pt-2 space-y-1.5">
                      <div className="flex justify-between text-gray-400">
                        <span>الرصيد الحالي بالخزينة:</span>
                        <span className="font-mono text-gray-200">{before.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-emerald-400 font-bold">
                        <span>السيولة المضافة (+):</span>
                        <span className="font-mono">
                          +{Number(adminToCashierForm.amount || 0).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between text-amber-300 font-black border-t border-amber-950/40 pt-1">
                        <span>رصيد الخزينة الجديد:</span>
                        <span className="font-mono text-xs">{after.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-[10px] text-emerald-200/90 leading-relaxed">
                <span className="font-bold text-emerald-300">نظام الخزينة المزدوج:</span> تُسجل كل
                تغذية خزينة كحركة خروج من الاحتياطي المركزي وحركة دخول في خزينة الكاشير (Double-Entry)،
                مما يضمن تطابق الموازنة المالية بنسبة 100%.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: CASHIER -> PLAYER ACCOUNT
         ========================================================================= */}
      {activeChannelTab === 'cashier_to_account' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 p-5 rounded-2xl bg-[#06180d] border border-amber-900/60 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-950/80 pb-3">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-black text-sm text-white">
                    نقطة بيع الكاشير: من الكاشير &larr; إلى حسابات اللاعبين
                  </h3>
                  <p className="text-[11px] text-gray-400">
                    يقوم الكاشير بشحن رصيد اللاعب من رصيد خزينته المخصصة بعد استلام المقابل من اللاعب
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold">
                Cashier Desk Point
              </span>
            </div>

            <form onSubmit={handleExecuteCashierToAccount} className="space-y-4 text-xs">
              {/* Source Cashier Selector */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">
                  من كاشير (الخزينة المصدرة):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {cashierAgents.map((agent) => {
                    const isSelected = cashierToAccountForm.sourceCashierId === agent.id;
                    return (
                      <div
                        key={agent.id}
                        onClick={() => {
                          soundFX.playButtonClick();
                          setCashierToAccountForm({ ...cashierToAccountForm, sourceCashierId: agent.id });
                        }}
                        className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center gap-2.5 ${
                          isSelected
                            ? 'bg-[#0e331f] border-amber-400 text-white shadow-md'
                            : 'bg-[#040e08] border-amber-950 hover:border-amber-900/60 text-gray-300'
                        }`}
                      >
                        <img
                          src={agent.avatar}
                          alt={agent.name}
                          className="w-8 h-8 rounded-full border border-amber-500/50 object-cover shrink-0"
                        />
                        <div className="overflow-hidden">
                          <div className="font-bold text-[11px] text-white truncate">{agent.branchName}</div>
                          <div className="text-[10px] text-emerald-400 font-mono">
                            المتوفر: ${agent.balanceUsd.toLocaleString()} USD • {agent.balanceCoins.toLocaleString()} كوينز
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Target Player Selector */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">
                  إلى اللاعب (الحساب المستلم):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {playersList.map((player) => {
                    const isSelected = cashierToAccountForm.targetPlayerId === player.id;
                    return (
                      <div
                        key={player.id}
                        onClick={() => {
                          soundFX.playButtonClick();
                          setCashierToAccountForm({ ...cashierToAccountForm, targetPlayerId: player.id });
                        }}
                        className={`p-2 rounded-xl border cursor-pointer transition-all flex items-center gap-2 ${
                          isSelected
                            ? 'bg-[#0e331f] border-amber-400 text-white shadow-md'
                            : 'bg-[#040e08] border-amber-950 text-gray-300'
                        }`}
                      >
                        <img
                          src={player.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&h=50&fit=crop'}
                          alt={player.name}
                          className="w-7 h-7 rounded-full border border-amber-500/50 object-cover shrink-0"
                        />
                        <div className="overflow-hidden">
                          <div className="font-bold text-[11px] truncate flex items-center gap-1">
                            <span>{player.name}</span>
                            {player.isCurrentUser && <span className="text-[8px] bg-emerald-500/20 px-1 rounded">أنت</span>}
                          </div>
                          <div className="text-[9px] text-gray-400 font-mono">
                            ID: {player.id}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Currency & Amount */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">نوع العملة:</label>
                  <select
                    value={cashierToAccountForm.currencyType}
                    onChange={(e) =>
                      setCashierToAccountForm({ ...cashierToAccountForm, currencyType: e.target.value as any })
                    }
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-amber-400 rounded-xl p-2.5 text-white focus:outline-none"
                  >
                    <option value="COINS">🪙 كوينز الألعاب (Coins)</option>
                    <option value="REAL_USD">💵 رصيد نقدي حقيقي ($ USD)</option>
                    <option value="GEMS">💎 جواهر ملكية (Gems)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1.5">المبلغ المراد شحنه للاعب:</label>
                  <input
                    type="number"
                    min="1"
                    value={cashierToAccountForm.amount}
                    onChange={(e) =>
                      setCashierToAccountForm({ ...cashierToAccountForm, amount: Number(e.target.value) })
                    }
                    className="w-full bg-[#030905] border border-amber-950/80 focus:border-amber-400 rounded-xl p-2.5 text-white font-mono font-bold focus:outline-none"
                    placeholder="أدخل المبلغ..."
                    required
                  />
                </div>
              </div>

              {/* Quick Preset Chips */}
              <div className="flex flex-wrap gap-1.5">
                {(cashierToAccountForm.currencyType === 'REAL_USD'
                  ? [20, 50, 100, 250, 500, 1000]
                  : [250, 500, 1000, 2500, 5000, 10000]
                ).map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => {
                      soundFX.playButtonClick();
                      setCashierToAccountForm({ ...cashierToAccountForm, amount: val });
                    }}
                    className="px-2 py-0.5 rounded-lg bg-[#040e08] hover:bg-[#081f12] border border-amber-950 text-amber-300 text-[10px] font-mono"
                  >
                    +{val.toLocaleString()}
                  </button>
                ))}
              </div>

              {/* Notes */}
              <div>
                <label className="block text-gray-300 font-bold mb-1.5">ملاحظات وإيصال الاستلام النقدي:</label>
                <input
                  type="text"
                  value={cashierToAccountForm.notes}
                  onChange={(e) =>
                    setCashierToAccountForm({ ...cashierToAccountForm, notes: e.target.value })
                  }
                  placeholder="مثال: تم استلام المبلغ نقداً في الفرع وتم شحن الحساب"
                  className="w-full bg-[#030905] border border-amber-950/80 focus:border-amber-400 rounded-xl p-2.5 text-white focus:outline-none"
                />
              </div>

              {/* Submit */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-black font-black text-sm shadow-[0_0_20px_rgba(245,158,11,0.4)] hover:brightness-110 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <ArrowRightLeft className="w-5 h-5 text-black" />
                  <span>
                    خصم من خزينة الكاشير وشحن حساب اللاعب فوراً وإصدار السند 🧾
                  </span>
                </button>
              </div>
            </form>
          </div>

          {/* Side Info */}
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-[#05110a] border border-amber-950 space-y-3">
              <h4 className="font-black text-xs text-amber-300 flex items-center gap-2">
                <Wallet className="w-4 h-4 text-amber-400" />
                <span>التحقق من كفاية رصيد الكاشير:</span>
              </h4>

              {(() => {
                const srcCashier = cashierAgents.find((c) => c.id === cashierToAccountForm.sourceCashierId);
                const reqAmt = Number(cashierToAccountForm.amount || 0);
                if (!srcCashier) return null;

                const curCashierBal =
                  cashierToAccountForm.currencyType === 'REAL_USD'
                    ? srcCashier.balanceUsd
                    : cashierToAccountForm.currencyType === 'COINS'
                    ? srcCashier.balanceCoins
                    : srcCashier.balanceGems;

                const hasEnough = curCashierBal >= reqAmt;

                return (
                  <div className="p-3.5 rounded-xl bg-[#030804] border border-amber-950/60 space-y-2.5 text-[11px]">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">رصيد الكاشير المتوفر:</span>
                      <span className="font-mono text-emerald-400 font-bold">
                        {curCashierBal.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">المبلغ المطلوب شحنه:</span>
                      <span className="font-mono text-amber-300 font-bold">
                        {reqAmt.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex justify-between items-center border-t border-amber-950/60 pt-2">
                      <span className="text-gray-400">رصيد الكاشير المتبقي بعد الخصم:</span>
                      <span
                        className={`font-mono font-bold ${
                          hasEnough ? 'text-gray-200' : 'text-red-400'
                        }`}
                      >
                        {Math.max(0, curCashierBal - reqAmt).toLocaleString()}
                      </span>
                    </div>

                    <div
                      className={`p-2 rounded-lg text-[10px] font-bold text-center border ${
                        hasEnough
                          ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/40'
                          : 'bg-red-950/40 text-red-300 border-red-500/40'
                      }`}
                    >
                      {hasEnough
                        ? '✓ رصيد الكاشير كافٍ للعملية ويمكن التنفيذ فوراً'
                        : '⚠️ رصيد الكاشير غير كافٍ! يجب تغذية خزينته من الإدارة أولاً'}
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 4: VOUCHERS LEDGER & RECEIPTS ARCHIVE
         ========================================================================= */}
      {activeChannelTab === 'vouchers' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>أرشيف سندات وإيصالات تحويل العملات الرقمية</span>
              </h3>
              <p className="text-[11px] text-gray-400">
                توثيق رسمي غير قابل للحذف أو التعديل لجميع التحويلات المالية
              </p>
            </div>

            <button
              onClick={() => {
                soundFX.playButtonClick();
                if (onNavigateToAuditLog) onNavigateToAuditLog();
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5"
            >
              <span>فتح في سجل التدقيق والمراقبة الكامل (Audit Log) &larr;</span>
            </button>
          </div>

          <div className="border border-amber-950 rounded-2xl overflow-hidden shadow-xl bg-[#040e08]">
            <table className="w-full text-xs text-right border-collapse">
              <thead className="bg-[#05110a] text-amber-300 border-b border-amber-950 font-bold">
                <tr>
                  <th className="p-3">رقم السند (Voucher)</th>
                  <th className="p-3">مسار التحويل</th>
                  <th className="p-3">المرسل (المصدر)</th>
                  <th className="p-3">المستلم (المستفيد)</th>
                  <th className="p-3">المبلغ والعملة</th>
                  <th className="p-3">التاريخ والوقت</th>
                  <th className="p-3 text-center">الحالة</th>
                  <th className="p-3 text-center">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-950/60">
                {vouchers.map((v) => {
                  return (
                    <tr key={v.voucherId} className="hover:bg-[#071c10] transition-colors">
                      {/* 1. Voucher ID */}
                      <td className="p-3 font-mono text-amber-400 font-bold whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{v.voucherId}</span>
                          <button
                            onClick={() => copyToClipboard(v.voucherId, v.voucherId)}
                            className="text-gray-500 hover:text-amber-300"
                            title="نسخ رقم السند"
                          >
                            {copiedVoucherId === v.voucherId ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* 2. Channel */}
                      <td className="p-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            v.channel === 'ADMIN_TO_ACCOUNT'
                              ? 'bg-amber-950 text-amber-300 border-amber-600/50'
                              : v.channel === 'ADMIN_TO_CASHIER'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-600/50'
                              : 'bg-blue-950 text-blue-300 border-blue-600/50'
                          }`}
                        >
                          {v.channel === 'ADMIN_TO_ACCOUNT'
                            ? 'إدارة &larr; حساب'
                            : v.channel === 'ADMIN_TO_CASHIER'
                            ? 'إدارة &larr; كاشير'
                            : 'كاشير &larr; حساب'}
                        </span>
                      </td>

                      {/* 3. Sender */}
                      <td className="p-3 whitespace-nowrap">
                        <div className="font-bold text-gray-200">{v.senderName}</div>
                        <div className="text-[10px] text-gray-500">{v.senderRole}</div>
                      </td>

                      {/* 4. Receiver */}
                      <td className="p-3 whitespace-nowrap">
                        <div className="font-bold text-gray-100">{v.receiverName}</div>
                        <div className="text-[10px] text-amber-400 font-mono">ID: {v.receiverId}</div>
                      </td>

                      {/* 5. Amount */}
                      <td className="p-3 font-mono font-bold text-sm whitespace-nowrap">
                        <span className="text-emerald-400">+{v.amount.toLocaleString()}</span>{' '}
                        <span className="text-xs text-gray-300">
                          {v.currencyType === 'COINS' ? '🪙 كوينز' : v.currencyType === 'GEMS' ? '💎 جواهر' : '💵 USD'}
                        </span>
                      </td>

                      {/* 6. Timestamp */}
                      <td className="p-3 font-mono text-gray-400 text-[11px] whitespace-nowrap">
                        {v.timestamp}
                      </td>

                      {/* 7. Status */}
                      <td className="p-3 text-center whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-600/50">
                          معتمد ✓
                        </span>
                      </td>

                      {/* 8. Inspect / Print Receipt */}
                      <td className="p-3 text-center whitespace-nowrap">
                        <button
                          onClick={() => {
                            soundFX.playButtonClick();
                            setActiveVoucherModal(v);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border border-emerald-600/40 text-[11px] font-bold flex items-center gap-1 mx-auto"
                        >
                          <Printer className="w-3 h-3" />
                          <span>عرض السند</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 5: CASHIER WALLETS & TREASURY OVERVIEW
         ========================================================================= */}
      {activeChannelTab === 'cashier_wallets' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-black text-sm text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>أرصدة وخزائن مكاتب الكاشير والموزعين المعتمدين</span>
              </h3>
              <p className="text-[11px] text-gray-400">
                مراقبة فورية لرصيد كل كاشير، وحجم العمليات المحولة للاعبين والسيولة المستلمة
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {cashierAgents.map((agent) => (
              <div
                key={agent.id}
                className="p-5 rounded-2xl bg-[#06180d] border border-amber-950/80 shadow-xl space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={agent.avatar}
                      alt={agent.name}
                      className="w-12 h-12 rounded-full border-2 border-emerald-500/60 object-cover"
                    />
                    <div>
                      <div className="font-black text-base text-white">{agent.branchName}</div>
                      <div className="text-xs text-gray-400">
                        المسؤول: {agent.name} • الكود: <span className="font-mono text-amber-400">{agent.code}</span>
                      </div>
                      <div className="text-[10px] text-emerald-400 mt-0.5">{agent.phone}</div>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-950 text-emerald-300 border border-emerald-500/50">
                    نشط ومرخص ✓
                  </span>
                </div>

                {/* Balances */}
                <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-[#030905] border border-amber-950/60 text-center font-mono">
                  <div>
                    <div className="text-[10px] text-gray-400">رصيد الدولار ($)</div>
                    <div className="text-base font-black text-amber-300 mt-0.5">
                      ${agent.balanceUsd.toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-400">سيولة الكوينز</div>
                    <div className="text-base font-black text-emerald-400 mt-0.5">
                      {agent.balanceCoins.toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-400">احتياطي الجواهر</div>
                    <div className="text-base font-black text-blue-400 mt-0.5">
                      {agent.balanceGems.toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Quick transfer button */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => {
                      soundFX.playButtonClick();
                      setActiveChannelTab('admin_to_cashier');
                      setAdminToCashierForm({ ...adminToCashierForm, targetCashierId: agent.id });
                    }}
                    className="flex-1 py-2 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>تغذية خزينة هذا الكاشير</span>
                  </button>
                  <button
                    onClick={() => {
                      soundFX.playButtonClick();
                      setActiveChannelTab('cashier_to_account');
                      setCashierToAccountForm({ ...cashierToAccountForm, sourceCashierId: agent.id });
                    }}
                    className="flex-1 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-1.5"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                    <span>تحويل للاعب من هذا الكاشير</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          DIGITAL VOUCHER / RECEIPT POPUP MODAL
         ========================================================================= */}
      {activeVoucherModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in">
          <div className="relative w-full max-w-lg bg-[#07170e] border-2 border-amber-500/70 rounded-3xl p-6 shadow-[0_0_60px_rgba(245,158,11,0.5)] text-right space-y-4">
            {/* Header with Royal Emblem */}
            <div className="text-center border-b border-amber-950/80 pb-3">
              <div className="inline-block px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-black mb-1">
                👑 سند تحويل مالي رسمي — منصة TABEONA
              </div>
              <h3 className="text-xl font-black text-amber-400">إيصال تحويل عملات معتمد</h3>
              <p className="text-xs text-gray-400 font-mono mt-0.5">
                رقم السند: <span className="text-white font-bold">{activeVoucherModal.voucherId}</span>
              </p>
            </div>

            {/* Voucher Details Table */}
            <div className="space-y-2.5 text-xs bg-[#030905] p-4 rounded-2xl border border-amber-950">
              <div className="flex justify-between items-center py-1 border-b border-amber-950/60">
                <span className="text-gray-400">مسار التحويل:</span>
                <span className="font-bold text-amber-300">
                  {activeVoucherModal.channel === 'ADMIN_TO_ACCOUNT'
                    ? 'من لوحة التحكم &larr; إلى حساب لاعب'
                    : activeVoucherModal.channel === 'ADMIN_TO_CASHIER'
                    ? 'من لوحة التحكم &larr; إلى خزينة كاشير'
                    : 'من الكاشير &larr; إلى حساب لاعب'}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-amber-950/60">
                <span className="text-gray-400">الطرف المحوِّل (المصدر):</span>
                <span className="font-bold text-white">{activeVoucherModal.senderName} ({activeVoucherModal.senderRole})</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-amber-950/60">
                <span className="text-gray-400">الطرف المستلم (المستفيد):</span>
                <span className="font-bold text-emerald-400">{activeVoucherModal.receiverName} (ID: #{activeVoucherModal.receiverId})</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-amber-950/60">
                <span className="text-gray-400">المبلغ المحول:</span>
                <span className="font-mono font-black text-base text-amber-300">
                  +{activeVoucherModal.amount.toLocaleString()}{' '}
                  <span className="text-xs font-normal">
                    {activeVoucherModal.currencyType === 'COINS'
                      ? '🪙 كوينز'
                      : activeVoucherModal.currencyType === 'GEMS'
                      ? '💎 جواهر'
                      : '💵 دولار USD'}
                  </span>
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-amber-950/60">
                <span className="text-gray-400">تصنيف السبب:</span>
                <span className="text-gray-200">{activeVoucherModal.reasonCategory}</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-amber-950/60">
                <span className="text-gray-400">وقت التوثيق:</span>
                <span className="font-mono text-gray-300">{activeVoucherModal.timestamp}</span>
              </div>

              <div>
                <span className="text-gray-400 block mb-1">بصمة التشفير الرقمية (Digital Hash):</span>
                <div className="p-2 rounded bg-black/60 font-mono text-[10px] text-amber-400/90 break-all select-all">
                  {activeVoucherModal.auditHash}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => {
                  copyToClipboard(activeVoucherModal.voucherId, activeVoucherModal.voucherId);
                }}
                className="flex-1 py-2.5 rounded-xl bg-[#0a2716] hover:bg-[#0f3d23] text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center justify-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>نسخ رقم السند</span>
              </button>

              <button
                onClick={() => {
                  soundFX.playButtonClick();
                  window.print();
                }}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs flex items-center justify-center gap-1.5 shadow"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة الإيصال 🖨️</span>
              </button>

              <button
                onClick={() => {
                  soundFX.playButtonClick();
                  setActiveVoucherModal(null);
                }}
                className="px-4 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs font-bold"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
