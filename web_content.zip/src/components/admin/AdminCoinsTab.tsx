import React, { useState } from 'react';
import { 
  Coins, 
  Save, 
  Check, 
  Sparkles, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  UserCheck, 
  DollarSign, 
  ArrowUpRight, 
  Layers, 
  RefreshCw, 
  Sliders, 
  AlertCircle 
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminCoinsTab: React.FC = () => {
  const { 
    systemSettings, 
    updateSystemSettings, 
    allUsers, 
    adjustUserCoins, 
    t 
  } = useApp();

  const [form, setForm] = useState({
    currencySymbol: systemSettings.currencySymbol || '₹',
    currencyCode: systemSettings.currencyCode || 'INR',
    coinsPerCurrencyUnit: systemSettings.coinsPerCurrencyUnit || 1,
    dailyCheckinBaseCoins: systemSettings.dailyCheckinBaseCoins || 12,
    facebookTaskRewardCoins: systemSettings.facebookTaskRewardCoins || 10,
    minWithdrawalCoins: systemSettings.minWithdrawalCoins || 100,
    referralBonusCoins: systemSettings.referralBonusCoins || 50,
    referredUserBonusCoins: systemSettings.referredUserBonusCoins || 25,
    adminUpiId: systemSettings.adminUpiId || 'paytm.s19vihm@pty',
  });

  const [savedNotice, setSavedNotice] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string>(allUsers[0]?.id || '');
  const [adjustAmount, setAdjustAmount] = useState<number>(50);
  const [adjustReason, setAdjustReason] = useState<string>('Admin Manual Bonus Injection');
  const [adjustSuccess, setAdjustSuccess] = useState<string | null>(null);

  // Calculations
  const totalCirculatingCoins = allUsers.reduce((sum, u) => sum + (u.coins || 0), 0);
  const totalLifetimeMinted = allUsers.reduce((sum, u) => sum + (u.lifetimeCoins || 0), 0);
  const totalWithdrawnCoins = allUsers.reduce((sum, u) => sum + (u.withdrawnCoins || 0), 0);
  const currencySymbol = form.currencySymbol;
  const circulatingFiatValue = (totalCirculatingCoins / (form.coinsPerCurrencyUnit || 1)).toFixed(2);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSystemSettings({
      currencySymbol: form.currencySymbol,
      currencyCode: form.currencyCode,
      coinsPerCurrencyUnit: Number(form.coinsPerCurrencyUnit) || 1,
      dailyCheckinBaseCoins: Number(form.dailyCheckinBaseCoins) || 12,
      facebookTaskRewardCoins: Number(form.facebookTaskRewardCoins) || 10,
      minWithdrawalCoins: Number(form.minWithdrawalCoins) || 100,
      referralBonusCoins: Number(form.referralBonusCoins) || 50,
      referredUserBonusCoins: Number(form.referredUserBonusCoins) || 25,
      adminUpiId: form.adminUpiId,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const handleApplyPreset = (preset: 'standard' | 'promo' | 'conservative') => {
    let presetValues = { ...form };
    if (preset === 'standard') {
      presetValues = {
        ...presetValues,
        dailyCheckinBaseCoins: 12,
        facebookTaskRewardCoins: 10,
        coinsPerCurrencyUnit: 1,
        minWithdrawalCoins: 100,
        referralBonusCoins: 50,
        referredUserBonusCoins: 25,
      };
    } else if (preset === 'promo') {
      presetValues = {
        ...presetValues,
        dailyCheckinBaseCoins: 25,
        facebookTaskRewardCoins: 20,
        coinsPerCurrencyUnit: 1,
        minWithdrawalCoins: 80,
        referralBonusCoins: 100,
        referredUserBonusCoins: 50,
      };
    } else if (preset === 'conservative') {
      presetValues = {
        ...presetValues,
        dailyCheckinBaseCoins: 10,
        facebookTaskRewardCoins: 8,
        coinsPerCurrencyUnit: 2,
        minWithdrawalCoins: 200,
        referralBonusCoins: 30,
        referredUserBonusCoins: 15,
      };
    }
    setForm(presetValues);
    updateSystemSettings(presetValues);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const handleDirectAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId || !adjustAmount) return;
    
    adjustUserCoins(selectedUserId, Number(adjustAmount), adjustReason);
    const target = allUsers.find(u => u.id === selectedUserId);
    setAdjustSuccess(`Successfully injected ${adjustAmount > 0 ? '+' : ''}${adjustAmount} Coins to ${target?.name || 'user'}`);
    setTimeout(() => setAdjustSuccess(null), 3500);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-900/40 border border-amber-600/30 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0 shadow-lg shadow-amber-500/10">
            <Coins className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black tracking-tight text-white">
                Coins & Economy Customizer
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Live Admin Control
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Customize Coin valuation, Daily earning rate (12 Coins), Facebook task payout (10 Coins), and platform treasury.
            </p>
          </div>
        </div>

        {/* Live Treasury Stat */}
        <div className="p-3 rounded-2xl bg-black/40 border border-amber-500/20 flex items-center gap-3 shrink-0">
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Circulation Value</span>
            <span className="text-sm font-black text-amber-400">
              {currencySymbol}{Number(circulatingFiatValue).toLocaleString()}
            </span>
          </div>
          <div className="w-px h-7 bg-slate-800" />
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Total Minted</span>
            <span className="text-sm font-black text-emerald-400">
              {totalLifetimeMinted.toLocaleString()} Coins
            </span>
          </div>
        </div>
      </div>

      {/* Quick Presets Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-purple-400" />
          <span className="text-xs font-bold text-white">Quick Economy Presets:</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => handleApplyPreset('standard')}
            className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Standard (12 Daily • 10 FB)</span>
          </button>
          <button
            type="button"
            onClick={() => handleApplyPreset('promo')}
            className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>High Reward Promo (25 Daily • 20 FB)</span>
          </button>
          <button
            type="button"
            onClick={() => handleApplyPreset('conservative')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
            <span>Anti-Inflation (10 Daily • 8 FB)</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Settings Form & Direct Coin Injection */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Core Coin Settings Form */}
        <div className="lg:col-span-7">
          <form onSubmit={handleSaveSettings} className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4 text-xs">
            
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400" />
                <span>Coin Payout & Conversion Rules</span>
              </h3>
              {savedNotice && (
                <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1 animate-in fade-in">
                  <Check className="w-3.5 h-3.5" />
                  <span>Changes Saved Live!</span>
                </span>
              )}
            </div>

            {/* Daily Earning Coins (User Highlighted: 12 Coins) */}
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-black text-amber-300 block">
                    Daily Earning Coins (Base Streak Bonus)
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Baseline coins received every day by all users when logging in or claiming daily reward.
                  </p>
                </div>
                <span className="text-lg font-black text-amber-400 px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-500/30">
                  {form.dailyCheckinBaseCoins} Coins
                </span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="range"
                  min={1}
                  max={100}
                  step={1}
                  value={form.dailyCheckinBaseCoins}
                  onChange={(e) => setForm({ ...form, dailyCheckinBaseCoins: Number(e.target.value) })}
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <input
                  type="number"
                  min={1}
                  max={500}
                  value={form.dailyCheckinBaseCoins}
                  onChange={(e) => setForm({ ...form, dailyCheckinBaseCoins: Number(e.target.value) })}
                  className="w-20 px-2.5 py-1.5 rounded-xl border border-amber-500/40 bg-slate-950 font-black text-white text-center"
                />
              </div>
            </div>

            {/* Facebook Social Task Coins (User Highlighted: 10 Coins) */}
            <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-black text-blue-300 block">
                    Facebook Social Tasks Reward (Like / Comment / Share)
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Coins rewarded when a user completes a Facebook Like, Post comment, or Share task.
                  </p>
                </div>
                <span className="text-lg font-black text-blue-400 px-3 py-1 rounded-xl bg-blue-500/20 border border-blue-500/30">
                  {form.facebookTaskRewardCoins} Coins
                </span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="range"
                  min={1}
                  max={50}
                  step={1}
                  value={form.facebookTaskRewardCoins}
                  onChange={(e) => setForm({ ...form, facebookTaskRewardCoins: Number(e.target.value) })}
                  className="w-full accent-blue-500 cursor-pointer"
                />
                <input
                  type="number"
                  min={1}
                  max={200}
                  value={form.facebookTaskRewardCoins}
                  onChange={(e) => setForm({ ...form, facebookTaskRewardCoins: Number(e.target.value) })}
                  className="w-20 px-2.5 py-1.5 rounded-xl border border-blue-500/40 bg-slate-950 font-black text-white text-center"
                />
              </div>
            </div>

            {/* Currency & Exchange Rate Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Currency Symbol & Code
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={form.currencySymbol}
                    onChange={(e) => setForm({ ...form, currencySymbol: e.target.value })}
                    className="w-16 px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-black text-center"
                    placeholder="₹"
                  />
                  <input
                    type="text"
                    value={form.currencyCode}
                    onChange={(e) => setForm({ ...form, currencyCode: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-bold"
                    placeholder="INR"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Coins per 1.00 Currency Unit ({form.currencySymbol}1)
                </label>
                <input
                  type="number"
                  min={1}
                  value={form.coinsPerCurrencyUnit}
                  onChange={(e) => setForm({ ...form, coinsPerCurrencyUnit: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-black"
                />
                <span className="text-[10px] text-slate-400">
                  {form.coinsPerCurrencyUnit} Coins = {form.currencySymbol}1.00
                </span>
              </div>
            </div>

            {/* Withdrawal & Referral Thresholds */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Min Withdrawal (Coins)
                </label>
                <input
                  type="number"
                  min={10}
                  value={form.minWithdrawalCoins}
                  onChange={(e) => setForm({ ...form, minWithdrawalCoins: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-black"
                />
                <span className="text-[10px] text-slate-400">
                  ≈ {form.currencySymbol}{(form.minWithdrawalCoins / (form.coinsPerCurrencyUnit || 1)).toFixed(2)}
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Referrer Bonus (Coins)
                </label>
                <input
                  type="number"
                  min={0}
                  value={form.referralBonusCoins}
                  onChange={(e) => setForm({ ...form, referralBonusCoins: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Referred User Bonus
                </label>
                <input
                  type="number"
                  min={0}
                  value={form.referredUserBonusCoins}
                  onChange={(e) => setForm({ ...form, referredUserBonusCoins: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-bold"
                />
              </div>
            </div>

            {/* VIP Payment UPI ID Changer */}
            <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 space-y-1.5">
              <label className="block font-black text-indigo-300">
                Merchant Payment Receiving UPI ID
              </label>
              <input
                type="text"
                value={form.adminUpiId}
                onChange={(e) => setForm({ ...form, adminUpiId: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-indigo-500/30 bg-slate-950 text-white font-mono text-xs font-bold"
                placeholder="e.g. paytm.s19vihm@pty"
              />
              <p className="text-[10px] text-slate-400">
                This UPI ID is displayed dynamically in QR codes and payment copy targets when users buy VIP membership plans.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all cursor-pointer active:scale-98"
            >
              <Save className="w-4 h-4" />
              <span>Save & Apply Coin Customizations</span>
            </button>
          </form>
        </div>

        {/* Right Column: Direct Coin Injector & Treasury Breakdown */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Direct Wallet Injection Box */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3.5 text-xs">
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span>Direct Coin Credit / Debit Tool</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Instantly inject coins into any user's balance or adjust discrepancies.
            </p>

            {adjustSuccess && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{adjustSuccess}</span>
              </div>
            )}

            <form onSubmit={handleDirectAdjust} className="space-y-3">
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Target User
                </label>
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-bold text-xs"
                >
                  {allUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.email}) — Balance: {u.coins} Coins
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Coins Amount (+ or -)
                  </label>
                  <input
                    type="number"
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white font-black"
                    placeholder="e.g. 50"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Quick Preset
                  </label>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setAdjustAmount(10)}
                      className="flex-1 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-[11px]"
                    >
                      +10
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdjustAmount(50)}
                      className="flex-1 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-[11px]"
                    >
                      +50
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdjustAmount(500)}
                      className="flex-1 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-[11px]"
                    >
                      +500
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Transaction Audit Reason
                </label>
                <input
                  type="text"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-white text-xs"
                  placeholder="e.g. Compensation for social task verification"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>Execute Coin Adjustment</span>
              </button>
            </form>
          </div>

          {/* Treasury Snapshot Card */}
          <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3 text-xs">
            <h4 className="text-xs font-black text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Platform Treasury Health</span>
            </h4>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-slate-400">Circulating Supply</span>
                <span className="font-black text-white">{totalCirculatingCoins.toLocaleString()} Coins</span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-slate-400">Total Processed Withdrawals</span>
                <span className="font-black text-rose-400">{totalWithdrawnCoins.toLocaleString()} Coins</span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-slate-400">Platform Reserve Health</span>
                <span className="font-black text-emerald-400 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>100% Fully Backed</span>
                </span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
