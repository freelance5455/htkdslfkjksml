"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Pencil, Plus, Save, Trash2 } from "lucide-react";
import { useI18n, useSite, useToast } from "@/components/providers";
import { Button, buttonClass, Card, Checkbox, CardSkeleton, ErrorState, Field, Input, LocalizedFields, Modal, Select } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { CategoryDTO, L10n, SiteData, SiteSettings } from "@/lib/types";
import { loc } from "@/lib/utils";

// `loc` is used to show category names in the list.

const emptyL10n = (): L10n => ({ fr: "", en: "", ar: "" });

/** Editable website content: contact & WhatsApp, home text, nurse profile, testimonials. */
export function SiteSection() {
  const { t, te } = useI18n();
  const toast = useToast();
  const { refreshSite } = useSite();
  const [draft, setDraft] = useState<SiteSettings | null>(null);
  const [error, setError] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let alive = true;
    api<SiteData>("/api/site")
      .then((r) => alive && setDraft(r.settings))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, []);

  if (error) return <ErrorState message={t("common.error")} />;
  if (!draft) return <CardSkeleton lines={8} />;

  const patch = (p: Partial<SiteSettings>) => setDraft((d) => (d ? { ...d, ...p } : d));
  const setContact = (p: Partial<SiteSettings["contact"]>) => patch({ contact: { ...draft.contact, ...p } });
  const setProfile = (p: Partial<SiteSettings["profile"]>) => patch({ profile: { ...draft.profile, ...p } });

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api("/api/site", { method: "PATCH", body: draft });
      await refreshSite();
      toast.success(t("adm.site.saved"));
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  const { contact, profile } = draft;

  return (
    <form onSubmit={save} className="space-y-6">
      <p className="rounded-2xl bg-amber-50 p-4 text-sm leading-relaxed text-amber-900 ring-1 ring-amber-100">{t("adm.site.hint")}</p>

      <Card className="space-y-5">
        <h2 className="font-bold text-slate-900">{t("adm.site.contact")}</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t("adm.site.phoneDisplay")} htmlFor="s-pd">
            <Input id="s-pd" dir="ltr" value={contact.phoneDisplay} onChange={(e) => setContact({ phoneDisplay: e.target.value })} />
          </Field>
          <Field label={t("adm.site.phoneIntl")} htmlFor="s-pi">
            <Input id="s-pi" dir="ltr" value={contact.phoneIntl} onChange={(e) => setContact({ phoneIntl: e.target.value })} />
          </Field>
          <Field label={t("adm.site.whatsapp")} htmlFor="s-wa">
            <Input id="s-wa" dir="ltr" value={contact.whatsappNumber} onChange={(e) => setContact({ whatsappNumber: e.target.value })} />
          </Field>
          <Field label={t("adm.site.email")} htmlFor="s-em">
            <Input id="s-em" dir="ltr" type="email" value={contact.email} onChange={(e) => setContact({ email: e.target.value })} />
          </Field>
          <Field label={t("common.city")} htmlFor="s-city">
            <Input id="s-city" value={contact.city} onChange={(e) => setContact({ city: e.target.value })} />
          </Field>
          <Field label={t("adm.site.address")} htmlFor="s-addr">
            <Input id="s-addr" value={contact.address} onChange={(e) => setContact({ address: e.target.value })} />
          </Field>
        </div>
        <LocalizedFields label={t("adm.site.hours")} value={contact.hours} onChange={(hours) => setContact({ hours })} />
        <LocalizedFields
          label={t("adm.site.waMessage")}
          value={draft.defaultWhatsappMessage}
          onChange={(defaultWhatsappMessage) => patch({ defaultWhatsappMessage })}
          multiline
          rows={3}
        />
      </Card>

      <Card className="space-y-5">
        <h2 className="font-bold text-slate-900">{t("adm.site.hero")}</h2>
        <LocalizedFields label={t("adm.site.heroHeadline")} value={draft.hero.headline} onChange={(headline) => patch({ hero: { ...draft.hero, headline } })} />
        <LocalizedFields
          label={t("adm.site.heroSubtitle")}
          value={draft.hero.subtitle}
          onChange={(subtitle) => patch({ hero: { ...draft.hero, subtitle } })}
          multiline
          rows={2}
        />
      </Card>

      <Card className="space-y-5">
        <h2 className="font-bold text-slate-900">{t("adm.site.profile")}</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t("adm.site.name")} htmlFor="p-name">
            <Input id="p-name" value={profile.name} onChange={(e) => setProfile({ name: e.target.value })} />
          </Field>
          <Field label={t("adm.site.photo")} htmlFor="p-photo">
            <Input id="p-photo" dir="ltr" value={profile.photoUrl} onChange={(e) => setProfile({ photoUrl: e.target.value })} placeholder="https://…" />
          </Field>
          <Field label={t("adm.site.experience")} htmlFor="p-exp">
            <Input
              id="p-exp"
              type="number"
              min={0}
              max={60}
              value={profile.experienceYears ?? ""}
              onChange={(e) => setProfile({ experienceYears: e.target.value === "" ? null : Number(e.target.value) })}
            />
          </Field>
        </div>
        <LocalizedFields label={t("adm.site.title")} value={profile.title} onChange={(title) => setProfile({ title })} />
        <LocalizedFields label={t("adm.site.intro")} value={profile.intro} onChange={(intro) => setProfile({ intro })} multiline rows={4} />
        <LocalizedFields label={t("about.qualifications")} value={profile.qualifications} onChange={(qualifications) => setProfile({ qualifications })} multiline rows={3} />
        <LocalizedFields label={t("adm.site.location")} value={profile.location} onChange={(location) => setProfile({ location })} />

        <div className="space-y-4">
          <p className="text-sm font-semibold text-slate-800">{t("adm.site.values")}</p>
          {profile.values.map((v, i) => (
            <div key={i} className="rounded-xl bg-slate-50 p-4 ring-1 ring-slate-100">
              <LocalizedFields
                label={`${t("adm.site.values")} ${i + 1}`}
                value={v}
                onChange={(nv) => setProfile({ values: profile.values.map((x, j) => (j === i ? nv : x)) })}
              />
              <Button variant="danger" size="sm" className="mt-3" onClick={() => setProfile({ values: profile.values.filter((_, j) => j !== i) })}>
                <Trash2 className="h-4 w-4" />
                {t("adm.site.remove")}
              </Button>
            </div>
          ))}
          <Button variant="outline" onClick={() => setProfile({ values: [...profile.values, emptyL10n()] })}>
            <Plus className="h-4 w-4" />
            {t("adm.site.addItem")}
          </Button>
        </div>
      </Card>

      <Card className="space-y-5">
        <h2 className="font-bold text-slate-900">{t("adm.site.testimonials")}</h2>
        {draft.testimonials.map((tm, i) => (
          <div key={tm.id} className="space-y-4 rounded-xl bg-slate-50 p-4 ring-1 ring-slate-100">
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label={t("common.name")} htmlFor={`tm-n-${i}`}>
                <Input id={`tm-n-${i}`} value={tm.name} onChange={(e) => patch({ testimonials: draft.testimonials.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)) })} />
              </Field>
              <Field label={t("common.city")} htmlFor={`tm-c-${i}`}>
                <Input id={`tm-c-${i}`} value={tm.city} onChange={(e) => patch({ testimonials: draft.testimonials.map((x, j) => (j === i ? { ...x, city: e.target.value } : x)) })} />
              </Field>
              <Field label={t("common.rating")} htmlFor={`tm-r-${i}`}>
                <Select id={`tm-r-${i}`} value={tm.rating} onChange={(e) => patch({ testimonials: draft.testimonials.map((x, j) => (j === i ? { ...x, rating: Number(e.target.value) } : x)) })}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <option key={n} value={n}>
                      {n}/5
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <LocalizedFields
              label={`${t("home.testimonials")} ${i + 1}`}
              value={tm.text}
              onChange={(text) => patch({ testimonials: draft.testimonials.map((x, j) => (j === i ? { ...x, text } : x)) })}
              multiline
              rows={2}
            />
            <div className="flex flex-wrap items-center justify-between gap-3">
              <Checkbox
                id={`tm-f-${i}`}
                checked={tm.fictional}
                onChange={(v) => patch({ testimonials: draft.testimonials.map((x, j) => (j === i ? { ...x, fictional: v } : x)) })}
                label={t("adm.site.fictional")}
              />
              <Button variant="danger" size="sm" onClick={() => patch({ testimonials: draft.testimonials.filter((_, j) => j !== i) })}>
                <Trash2 className="h-4 w-4" />
                {t("adm.site.remove")}
              </Button>
            </div>
          </div>
        ))}
        <Button
          variant="outline"
          onClick={() =>
            patch({
              testimonials: [
                ...draft.testimonials,
                { id: `t-${Date.now().toString(36)}`, name: "", city: "", rating: 5, text: emptyL10n(), fictional: true },
              ],
            })
          }
        >
          <Plus className="h-4 w-4" />
          {t("adm.site.addItem")}
        </Button>
      </Card>

      <div className="sticky bottom-24 z-10 flex justify-end lg:bottom-6">
        <button type="submit" disabled={saving} className={buttonClass("primary", "lg", "shadow-xl")}>
          <Save className="h-5 w-5" />
          {saving ? t("common.loading") : t("adm.site.save")}
        </button>
      </div>
    </form>
  );
}

interface CatForm {
  name: L10n;
  sortOrder: number;
}

/** Health categories used by articles. Deleting a category is blocked while articles use it. */
export function CategoriesSection() {
  const { t, te, locale } = useI18n();
  const toast = useToast();
  const { refreshSite } = useSite();
  const [items, setItems] = useState<CategoryDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [modal, setModal] = useState<{ editing: CategoryDTO | null } | null>(null);
  const [form, setForm] = useState<CatForm>({ name: emptyL10n(), sortOrder: 1 });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let alive = true;
    setError(false);
    api<{ categories: CategoryDTO[] }>("/api/categories")
      .then((r) => alive && setItems(r.categories))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [reloadKey]);

  const openNew = () => {
    setForm({ name: emptyL10n(), sortOrder: (items?.length ?? 0) + 1 });
    setModal({ editing: null });
  };
  const openEdit = (c: CategoryDTO) => {
    setForm({ name: c.name, sortOrder: c.sortOrder });
    setModal({ editing: c });
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!modal) return;
    if (form.name.fr.trim().length < 2) {
      toast.error(t("err.invalid_input"));
      return;
    }
    setSaving(true);
    try {
      if (modal.editing) await api(`/api/categories?id=${modal.editing.id}`, { method: "PATCH", body: form });
      else await api("/api/categories", { body: form });
      toast.success(t("adm.saved"));
      setModal(null);
      setReloadKey((k) => k + 1);
      await refreshSite();
    } catch (err) {
      toast.error(te(err));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (c: CategoryDTO) => {
    if (!window.confirm(t("adm.deleteConfirm"))) return;
    try {
      await api(`/api/categories?id=${c.id}`, { method: "DELETE" });
      toast.success(t("adm.deleted"));
      setReloadKey((k) => k + 1);
      await refreshSite();
    } catch (err) {
      toast.error(te(err));
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <Button variant="primary" onClick={openNew}>
          <Plus className="h-4 w-4" />
          {t("adm.cat.new")}
        </Button>
      </div>

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !items ? (
        <CardSkeleton lines={6} />
      ) : (
        <Card className="p-0">
          <ul className="divide-y divide-slate-100">
            {items.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                <div className="min-w-0">
                  <p className="font-semibold text-slate-900">{loc(c.name, locale)}</p>
                  <p className="font-mono text-xs text-slate-500" dir="ltr">
                    {c.slug} · #{c.sortOrder}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(c)}>
                    <Pencil className="h-4 w-4" />
                    {t("common.edit")}
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => void remove(c)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Modal
        open={!!modal}
        onClose={() => setModal(null)}
        title={modal?.editing ? t("common.edit") : t("adm.cat.new")}
        footer={
          <>
            <Button variant="ghost" onClick={() => setModal(null)}>
              {t("common.cancel")}
            </Button>
            <Button variant="primary" loading={saving} onClick={(e) => void save(e as unknown as FormEvent)}>
              {t("common.save")}
            </Button>
          </>
        }
      >
        <form onSubmit={save} className="space-y-5">
          <LocalizedFields label={t("adm.cat.name")} value={form.name} onChange={(name) => setForm({ ...form, name })} />
          <Field label={t("adm.cat.order")} htmlFor="cat-order">
            <Input id="cat-order" type="number" min={0} value={form.sortOrder} onChange={(e) => setForm({ ...form, sortOrder: Number(e.target.value) })} />
          </Field>
        </form>
      </Modal>
    </div>
  );
}
