import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Clock, 
  Coins, 
  ExternalLink, 
  CheckCircle2, 
  X, 
  Save,
  Search,
  Filter,
  Copy,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  Sparkles,
  Layers,
  Shield,
  FileText,
  DollarSign,
  ChevronDown,
  ChevronUp,
  Check,
  Award
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Task, TaskCategory, MembershipTier } from '../../types';
import { TaskCompletionTrendsChart } from './TaskCompletionTrendsChart';

export const AdminTasksTab: React.FC = () => {
  const { 
    tasks, 
    addNewTask, 
    updateTask, 
    deleteTask, 
    taskSubmissions,
    approveTaskSubmission,
    rejectTaskSubmission,
    systemSettings, 
    t 
  } = useApp();

  const [viewMode, setViewMode] = useState<'tasks' | 'submissions'>('tasks');
  const [submissionFilter, setSubmissionFilter] = useState<'all' | 'pending' | 'completed' | 'rejected'>('all');
  const [submissionSearch, setSubmissionSearch] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTierFilter, setSelectedTierFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'disabled'>('all');
  const [sortBy, setSortBy] = useState<'reward_desc' | 'reward_asc' | 'limit' | 'newest'>('reward_desc');

  const [editingTask, setEditingTask] = useState<Partial<Task> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showTrendsVisualization, setShowTrendsVisualization] = useState(true);
  const [copiedTaskId, setCopiedTaskId] = useState<string | null>(null);

  // Stats calculation
  const totalTasks = tasks.length;
  const activeTasks = tasks.filter(t => t.isActive).length;
  const proofRequiredTasks = tasks.filter(t => t.requiresProof).length;
  const vipRestrictedTasks = tasks.filter(t => t.vipTierRequired && t.vipTierRequired !== 'basic').length;
  const totalPossibleDailyCoins = tasks.filter(t => t.isActive).reduce((sum, t) => sum + (t.rewardCoins * t.dailyLimit), 0);

  // Submissions stats
  const totalSubmissionsCount = taskSubmissions.length;
  const pendingSubmissionsCount = taskSubmissions.filter(s => s.status === 'pending_verification').length;
  const completedSubmissionsCount = taskSubmissions.filter(s => s.status === 'completed').length;
  const totalCoinsAwarded = taskSubmissions
    .filter(s => s.status === 'completed')
    .reduce((sum, s) => sum + s.rewardCoins, 0);

  const currencySymbol = systemSettings?.currencySymbol || '₹';
  const coinsPerCurrency = systemSettings?.coinsPerCurrencyUnit || 1;

  // Filtered & Sorted Tasks
  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => {
        // Search
        const matchesSearch = 
          task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          task.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (task.externalPlatform && task.externalPlatform.toLowerCase().includes(searchQuery.toLowerCase()));

        // Category
        const matchesCategory = selectedCategory === 'all' || task.category === selectedCategory;

        // Tier Filter
        const matchesTier = selectedTierFilter === 'all' || (task.vipTierRequired || 'basic') === selectedTierFilter;

        // Status
        const matchesStatus = 
          statusFilter === 'all' ||
          (statusFilter === 'active' && task.isActive) ||
          (statusFilter === 'disabled' && !task.isActive);

        return matchesSearch && matchesCategory && matchesTier && matchesStatus;
      })
      .sort((a, b) => {
        if (sortBy === 'reward_desc') return b.rewardCoins - a.rewardCoins;
        if (sortBy === 'reward_asc') return a.rewardCoins - b.rewardCoins;
        if (sortBy === 'limit') return b.dailyLimit - a.dailyLimit;
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        return 0;
      });
  }, [tasks, searchQuery, selectedCategory, selectedTierFilter, statusFilter, sortBy]);

  // Filtered Submissions
  const filteredSubmissions = useMemo(() => {
    return taskSubmissions.filter((sub) => {
      const matchesStatus = 
        submissionFilter === 'all' ||
        (submissionFilter === 'pending' && sub.status === 'pending_verification') ||
        (submissionFilter === 'completed' && sub.status === 'completed') ||
        (submissionFilter === 'rejected' && sub.status === 'rejected');

      const matchesSearch = 
        !submissionSearch ||
        sub.taskTitle.toLowerCase().includes(submissionSearch.toLowerCase()) ||
        (sub.userName && sub.userName.toLowerCase().includes(submissionSearch.toLowerCase())) ||
        (sub.userEmail && sub.userEmail.toLowerCase().includes(submissionSearch.toLowerCase())) ||
        (sub.proofText && sub.proofText.toLowerCase().includes(submissionSearch.toLowerCase()));

      return matchesStatus && matchesSearch;
    });
  }, [taskSubmissions, submissionFilter, submissionSearch]);

  const handleOpenAdd = () => {
    setEditingTask({
      title: '',
      titleBn: '',
      description: '',
      descriptionBn: '',
      category: 'daily_checkin',
      rewardCoins: 35,
      rewardRupees: 35,
      estimatedMinutes: 2,
      dailyLimit: 1,
      isExternal: false,
      externalUrl: '',
      externalPlatform: '',
      isActive: true,
      requiresProof: false,
      proofType: 'text',
      proofInstructions: 'Submit verification code or completion proof',
      vipTierRequired: 'basic',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (task: Task) => {
    setEditingTask({ ...task });
    setIsModalOpen(true);
  };

  const handleDuplicateTask = (task: Task) => {
    const clonedData: Omit<Task, 'id' | 'createdAt'> = {
      ...task,
      title: `${task.title} (Copy)`,
      titleBn: task.titleBn ? `${task.titleBn} (কপি)` : '',
    };
    addNewTask(clonedData);
    setCopiedTaskId(task.id);
    setTimeout(() => setCopiedTaskId(null), 2000);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTask || !editingTask.title || !editingTask.description) return;

    const rewardCoins = Number(editingTask.rewardCoins) || 10;
    const taskPayload = {
      ...editingTask,
      rewardCoins,
      rewardRupees: editingTask.rewardRupees ? Number(editingTask.rewardRupees) : Number((rewardCoins / coinsPerCurrency).toFixed(2)),
      estimatedMinutes: Number(editingTask.estimatedMinutes) || 1,
      dailyLimit: Number(editingTask.dailyLimit) || 1,
    };

    if (editingTask.id) {
      updateTask(editingTask.id, taskPayload);
    } else {
      addNewTask(taskPayload as Omit<Task, 'id' | 'createdAt'>);
    }
    setIsModalOpen(false);
    setEditingTask(null);
  };

  const handleDelete = (id: string, title: string) => {
    if (window.confirm(`Are you sure you want to permanently delete task "${title}"? This cannot be undone.`)) {
      deleteTask(id);
    }
  };

  const categoriesList: { id: string; label: string }[] = [
    { id: 'all', label: 'All Categories' },
    { id: 'social_facebook', label: '📘 Facebook Social (10 Coins)' },
    { id: 'app_download', label: '📱 App Download Offer' },
    { id: 'youtube_watch', label: '▶️ YouTube Video Task' },
    { id: 'game', label: '🎮 Play Game Task' },
    { id: 'daily_checkin', label: 'Daily Check-in' },
    { id: 'google_tasks', label: 'Google Tasks' },
    { id: 'quiz', label: 'Knowledge Quiz' },
    { id: 'survey', label: 'User Survey' },
    { id: 'vip_task', label: 'VIP Exclusive' },
    { id: 'external_partner', label: 'External Partner' },
    { id: 'video_demo', label: 'Video Watch' },
    { id: 'review', label: 'App Reviews' },
  ];

  const tiersList: { id: string; label: string }[] = [
    { id: 'all', label: 'All Tiers' },
    { id: 'basic', label: 'Basic (Free)' },
    { id: 'silver', label: 'Silver' },
    { id: 'gold', label: 'Gold' },
    { id: 'platinum', label: 'Platinum' },
    { id: 'diamond', label: 'Diamond' },
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* 30-Day Completion Trends & Payout Optimization Toggle Header */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-purple-600/30 text-purple-400 border border-purple-500/40 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white">
              30-Day Task Completion Trends & Payout Optimization
            </h2>
            <p className="text-[11px] text-slate-400">
              Interactive Recharts analytics showing user completion velocity, reward outflow, and recommendations.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowTrendsVisualization(!showTrendsVisualization)}
          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
        >
          {showTrendsVisualization ? (
            <>
              <ChevronUp className="w-4 h-4 text-purple-400" />
              <span>Hide Visualization</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-4 h-4 text-purple-400" />
              <span>Show 30-Day Chart</span>
            </>
          )}
        </button>
      </div>

      {/* Embedded Recharts Visualization */}
      {showTrendsVisualization && (
        <div className="animate-in fade-in duration-300">
          <TaskCompletionTrendsChart 
            onSelectCategoryFilter={(cat) => setSelectedCategory(cat)} 
          />
        </div>
      )}

      {/* Switcher: Tasks Management vs User Submissions & Approvals */}
      <div className="flex gap-2 p-1.5 bg-slate-900 border border-slate-800 rounded-2xl w-fit">
        <button
          type="button"
          onClick={() => setViewMode('tasks')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            viewMode === 'tasks'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Task Management ({tasks.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setViewMode('submissions')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            viewMode === 'submissions'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Submissions & Verifications ({taskSubmissions.length})</span>
          {pendingSubmissionsCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[10px]">
              {pendingSubmissionsCount}
            </span>
          )}
        </button>
      </div>

      {viewMode === 'tasks' ? (
        <>
          {/* Main Task Management Section */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  {t('taskManagement')} ({filteredTasks.length} / {tasks.length})
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Live Dynamic CRUD
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Create, update, and delete tasks dynamically with custom rewards, VIP tier requirements, and verification rules.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  addNewTask({
                    title: 'Facebook: Like Official Announcement Post',
                    titleBn: 'ফেসবুক: অফিশিয়াল পোস্টে লাইক দিন',
                    description: 'Open our official Facebook page post and hit Like for 10 Coins.',
                    descriptionBn: 'আমাদের ফেসবুক পোস্টে লাইক দিয়ে ১০ কয়েন পুরস্কার গ্রহণ করুন।',
                    category: 'social_facebook',
                    rewardCoins: 10,
                    rewardRupees: 10,
                    estimatedMinutes: 1,
                    dailyLimit: 5,
                    isExternal: true,
                    externalUrl: 'https://facebook.com',
                    externalPlatform: 'Facebook',
                    isActive: true,
                    requiresProof: true,
                    proofType: 'text',
                    proofInstructions: 'Enter your Facebook profile handle',
                  });
                }}
                className="px-3 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <span>+ FB Like (10 Coins)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  addNewTask({
                    title: 'Facebook: Comment on Community Update',
                    titleBn: 'ফেসবুক: কমিউনিটি পোস্টে একটি কমেন্ট করুন',
                    description: 'Leave an honest positive comment on our Facebook post to claim 10 Coins.',
                    descriptionBn: 'আমাদের ফেসবুক পোস্টে পজিটিভ মন্তব্য করে ১০ কয়েন আয় করুন।',
                    category: 'social_facebook',
                    rewardCoins: 10,
                    rewardRupees: 10,
                    estimatedMinutes: 1,
                    dailyLimit: 5,
                    isExternal: true,
                    externalUrl: 'https://facebook.com',
                    externalPlatform: 'Facebook',
                    isActive: true,
                    requiresProof: true,
                    proofType: 'text',
                    proofInstructions: 'Paste the comment text or username',
                  });
                }}
                className="px-3 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <span>+ FB Comment (10 Coins)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  addNewTask({
                    title: 'Facebook: Share Post to Feed / Groups',
                    titleBn: 'ফেসবুক: টাইমলাইন বা গ্রুপে পোস্ট শেয়ার করুন',
                    description: 'Share our daily payout milestone to your feed or earning group for 10 Coins.',
                    descriptionBn: 'পোস্টটি আপনার ফেসবুক ওয়ালে বা গ্রুপে শেয়ার করে ১০ কয়েন নিন।',
                    category: 'social_facebook',
                    rewardCoins: 10,
                    rewardRupees: 10,
                    estimatedMinutes: 1,
                    dailyLimit: 5,
                    isExternal: true,
                    externalUrl: 'https://facebook.com',
                    externalPlatform: 'Facebook',
                    isActive: true,
                    requiresProof: true,
                    proofType: 'url',
                    proofInstructions: 'Paste the shared post URL',
                  });
                }}
                className="px-3 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <span>+ FB Share (10 Coins)</span>
              </button>

              <button
                onClick={handleOpenAdd}
                className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/20 active:scale-95 transition-all cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>{t('addNewTask')}</span>
              </button>
            </div>
          </div>

      {/* Task Summary Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">Active / Total</span>
            <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
              {activeTasks} / {totalTasks}
            </span>
          </div>
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
        </div>

        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">Max Daily Coins</span>
            <span className="font-bold text-amber-500 text-sm">
              🪙 {totalPossibleDailyCoins.toLocaleString()}
            </span>
          </div>
          <Coins className="w-4 h-4 text-amber-500" />
        </div>

        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">VIP Exclusive</span>
            <span className="font-bold text-purple-400 text-sm">
              {vipRestrictedTasks} Tasks
            </span>
          </div>
          <Sparkles className="w-4 h-4 text-purple-500" />
        </div>

        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">Proof Required</span>
            <span className="font-bold text-sky-400 text-sm">
              {proofRequiredTasks} Tasks
            </span>
          </div>
          <Shield className="w-4 h-4 text-sky-500" />
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search tasks by title, description, or platform..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Sort */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-xs whitespace-nowrap">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300"
            >
              <option value="reward_desc">Highest Reward</option>
              <option value="reward_asc">Lowest Reward</option>
              <option value="limit">Daily Limit</option>
              <option value="newest">Newest First</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300"
            >
              <option value="all">All Status</option>
              <option value="active">Active Only</option>
              <option value="disabled">Paused Only</option>
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categoriesList.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tasks Table */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-3.5">Task Info & Requirements</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Reward Config</th>
                <th className="p-3.5">Requirements & Limits</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-200">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No tasks match your current filter. Click "Add New Task" to create one.
                  </td>
                </tr>
              ) : (
                filteredTasks.map((task) => (
                  <tr key={task.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    
                    {/* Task Title & Details */}
                    <td className="p-3.5 max-w-xs">
                      <div className="flex items-start gap-2">
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <p className="font-bold text-slate-900 dark:text-slate-100">
                              {task.title}
                            </p>
                            {task.isExternal && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center gap-0.5">
                                <ExternalLink className="w-2.5 h-2.5" />
                                {task.externalPlatform || 'External'}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                            {task.description}
                          </p>
                          {task.titleBn && (
                            <p className="text-[10px] text-slate-500 line-clamp-1 font-bangla">
                              {task.titleBn}
                            </p>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 font-semibold uppercase text-[10px] text-slate-700 dark:text-slate-300">
                        {task.category.replace('_', ' ')}
                      </span>
                    </td>

                    {/* Reward Config */}
                    <td className="p-3.5">
                      <div className="space-y-0.5">
                        <span className="font-bold text-amber-500 text-sm flex items-center gap-1">
                          <Coins className="w-3.5 h-3.5" />
                          <span>{task.rewardCoins}</span>
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono">
                          {currencySymbol}{task.rewardRupees || (task.rewardCoins / coinsPerCurrency).toFixed(2)}
                        </span>
                      </div>
                    </td>

                    {/* Requirements & Limits */}
                    <td className="p-3.5">
                      <div className="space-y-1 text-[11px]">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{task.dailyLimit}x daily • ~{task.estimatedMinutes}m</span>
                        </div>

                        {task.vipTierRequired && task.vipTierRequired !== 'basic' && (
                          <div className="flex items-center gap-1 text-purple-400 font-bold text-[10px]">
                            <Sparkles className="w-3 h-3" />
                            <span>Requires {task.vipTierRequired.toUpperCase()}</span>
                          </div>
                        )}

                        {task.requiresProof && (
                          <div className="flex items-center gap-1 text-sky-400 text-[10px] font-semibold">
                            <Shield className="w-3 h-3" />
                            <span>Proof: {task.proofType || 'text'}</span>
                          </div>
                        )}
                      </div>
                    </td>

                    {/* Status */}
                    <td className="p-3.5">
                      <button
                        onClick={() => updateTask(task.id, { isActive: !task.isActive })}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
                          task.isActive
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700'
                        }`}
                      >
                        {task.isActive ? 'Active' : 'Paused'}
                      </button>
                    </td>

                    {/* Actions */}
                    <td className="p-3.5 text-right space-x-1 whitespace-nowrap">
                      <button
                        onClick={() => handleDuplicateTask(task)}
                        className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-purple-400 cursor-pointer transition-colors"
                        title="Duplicate / Clone Task"
                      >
                        {copiedTaskId === task.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => handleOpenEdit(task)}
                        className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-white cursor-pointer transition-colors"
                        title="Edit Task"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDelete(task.id, task.title)}
                        className="p-1.5 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-500 dark:text-slate-400 hover:text-rose-400 cursor-pointer transition-colors"
                        title="Delete Task"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  ) : (
    /* Submissions & Verifications Management View */
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Submissions Header & Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">Total Submissions</span>
            <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
              {totalSubmissionsCount}
            </span>
          </div>
          <FileText className="w-4 h-4 text-purple-400" />
        </div>

        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">Pending Verification</span>
            <span className="font-bold text-amber-500 text-sm">
              {pendingSubmissionsCount}
            </span>
          </div>
          <Clock className="w-4 h-4 text-amber-500" />
        </div>

        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">Verified & Approved</span>
            <span className="font-bold text-emerald-400 text-sm">
              {completedSubmissionsCount}
            </span>
          </div>
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        </div>

        <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-400 text-[11px] block">Total Coins Awarded</span>
            <span className="font-bold text-amber-400 text-sm">
              🪙 {totalCoinsAwarded.toLocaleString()}
            </span>
          </div>
          <Coins className="w-4 h-4 text-amber-400" />
        </div>
      </div>

      {/* Submissions Filter & Search Bar */}
      <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search submissions by user, task title, or proof notes..."
            value={submissionSearch}
            onChange={(e) => setSubmissionSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-500 focus:outline-none"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto">
          {(['all', 'pending', 'completed', 'rejected'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setSubmissionFilter(st)}
              className={`px-3 py-1.5 rounded-xl font-bold capitalize text-xs transition-all cursor-pointer ${
                submissionFilter === st
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {st === 'pending' ? 'Pending' : st}
            </button>
          ))}
        </div>
      </div>

      {/* Submissions Table / Cards */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Task Details</th>
                <th className="py-3 px-4">Reward</th>
                <th className="py-3 px-4">Proof / Attribution</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filteredSubmissions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No submissions found matching this filter.
                  </td>
                </tr>
              ) : (
                filteredSubmissions.map((sub) => (
                  <tr key={sub.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-slate-100">
                        {sub.userName || 'Member User'}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {sub.userEmail || sub.userId}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800 dark:text-slate-200 max-w-[200px] truncate" title={sub.taskTitle}>
                        {sub.taskTitle}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(sub.completedAt).toLocaleString()}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-black text-amber-500 flex items-center gap-1">
                        <Coins className="w-3.5 h-3.5" /> +{sub.rewardCoins}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="max-w-[220px] text-[11px] text-slate-400 line-clamp-2" title={sub.proofText}>
                        {sub.proofText || 'Automated Telemetry / In-App Check'}
                      </div>
                      {sub.adminRemark && (
                        <div className="text-[10px] text-purple-400 mt-0.5 italic">
                          Admin Remark: {sub.adminRemark}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {sub.status === 'completed' ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          Approved
                        </span>
                      ) : sub.status === 'pending_verification' ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                          Pending
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                          Rejected
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      {sub.status === 'pending_verification' ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => approveTaskSubmission(sub.id)}
                            className="py-1 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer shadow-xs"
                          >
                            <Check className="w-3 h-3" />
                            <span>Approve</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const reason = prompt('Enter rejection reason:') || 'Proof requirements not satisfied.';
                              rejectTaskSubmission(sub.id, reason);
                            }}
                            className="py-1 px-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer shadow-xs"
                          >
                            <X className="w-3 h-3" />
                            <span>Reject</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-500 italic">No actions</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )}

      {/* Dynamic Add / Edit Task Modal with Granular Rewards & Requirements */}
      {isModalOpen && editingTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
          <div 
            className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-4"
            role="dialog"
          >
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="pr-8">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-400 border border-purple-500/30">
                Dynamic Task Engine
              </span>
              <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100 mt-1">
                {editingTask.id ? 'Edit Dynamic Task' : 'Create New Dynamic Task'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Configure task rewards, verification requirements, VIP gating, and limits.
              </p>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              
              {/* Section 1: Basic Information */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-purple-400" />
                  <span>1. Task Details & Content</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Task Title (English) *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Subscribe to Partner YouTube Channel"
                      value={editingTask.title || ''}
                      onChange={(e) => setEditingTask({ ...editingTask, title: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Task Title (বাংলা Bengali Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="বাংলায় শিরোনাম (ঐচ্ছিক)"
                      value={editingTask.titleBn || ''}
                      onChange={(e) => setEditingTask({ ...editingTask, titleBn: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Task Description & Instructions *
                  </label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Describe step-by-step what the user needs to do..."
                    value={editingTask.description || ''}
                    onChange={(e) => setEditingTask({ ...editingTask, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Category
                    </label>
                    <select
                      value={editingTask.category || 'daily_checkin'}
                      onChange={(e) => {
                        const newCat = e.target.value as TaskCategory;
                        let defaultReward = editingTask.rewardCoins || 35;
                        if (newCat === 'social_facebook') defaultReward = 10;
                        else if (newCat === 'app_download') defaultReward = 200;
                        else if (newCat === 'youtube_watch') defaultReward = 25;
                        else if (newCat === 'game') defaultReward = 18;

                        setEditingTask({ 
                          ...editingTask, 
                          category: newCat,
                          rewardCoins: defaultReward,
                          rewardRupees: Number((defaultReward / coinsPerCurrency).toFixed(2))
                        });
                      }}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                    >
                      <option value="social_facebook">📘 Facebook Social Task (10 Coins)</option>
                      <option value="app_download">📱 App Download Offer (200 Coins)</option>
                      <option value="youtube_watch">▶️ YouTube Video Watch (25 Coins)</option>
                      <option value="game">🎮 Play Game Task (18 Coins)</option>
                      <option value="daily_checkin">Daily Check-in</option>
                      <option value="google_tasks">Google Tasks Sync</option>
                      <option value="quiz">Knowledge Quiz</option>
                      <option value="survey">User Survey</option>
                      <option value="vip_task">VIP Exclusive</option>
                      <option value="external_partner">External Partner</option>
                      <option value="video_demo">Video Watch</option>
                      <option value="review">App Reviews</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Estimated Duration (Minutes)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={120}
                      value={editingTask.estimatedMinutes || 2}
                      onChange={(e) => setEditingTask({ ...editingTask, estimatedMinutes: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Reward Settings */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400" />
                  <span>2. Task Rewards Configuration</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Reward Coins *
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={10000}
                      value={editingTask.rewardCoins ?? 35}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setEditingTask({ 
                          ...editingTask, 
                          rewardCoins: val,
                          rewardRupees: Number((val / coinsPerCurrency).toFixed(2))
                        });
                      }}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Equivalent Value ({currencySymbol})
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={editingTask.rewardRupees ?? 35}
                      onChange={(e) => setEditingTask({ ...editingTask, rewardRupees: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Daily Completion Limit
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      value={editingTask.dailyLimit || 1}
                      onChange={(e) => setEditingTask({ ...editingTask, dailyLimit: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                    />
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      Max completions per user per day
                    </span>
                  </div>
                </div>
              </div>

              {/* Section 3: Requirements & Eligibility */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-sky-400" />
                  <span>3. Task Requirements & Gating</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Minimum VIP Tier Requirement
                    </label>
                    <select
                      value={editingTask.vipTierRequired || 'basic'}
                      onChange={(e) => setEditingTask({ ...editingTask, vipTierRequired: e.target.value as MembershipTier })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                    >
                      <option value="basic">Basic (Free - All Users)</option>
                      <option value="silver">Silver Tier & Above</option>
                      <option value="gold">Gold Tier & Above</option>
                      <option value="platinum">Platinum Tier & Above</option>
                      <option value="diamond">Diamond Tier Only</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Proof Submission Rule
                    </label>
                    <div className="pt-2">
                      <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700 dark:text-slate-300">
                        <input
                          type="checkbox"
                          checked={editingTask.requiresProof || false}
                          onChange={(e) => setEditingTask({ ...editingTask, requiresProof: e.target.checked })}
                          className="rounded text-purple-600 focus:ring-purple-500"
                        />
                        <span>Require User to Submit Proof / Screenshot</span>
                      </label>
                    </div>
                  </div>
                </div>

                {editingTask.requiresProof && (
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Proof Format
                      </label>
                      <select
                        value={editingTask.proofType || 'text'}
                        onChange={(e) => setEditingTask({ ...editingTask, proofType: e.target.value as any })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                      >
                        <option value="text">Written Answer / Text</option>
                        <option value="screenshot">Screenshot Upload URL</option>
                        <option value="code">Verification Secret Keyword</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Verification Keyword (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. EARN2026 or secret password"
                        value={editingTask.verificationKeyword || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, verificationKeyword: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Section 4: External Link Settings */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <ExternalLink className="w-4 h-4 text-blue-400" />
                    <span>4. External Partner / URL Setup</span>
                  </h4>
                  <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={editingTask.isExternal || false}
                      onChange={(e) => setEditingTask({ ...editingTask, isExternal: e.target.checked })}
                      className="rounded text-purple-600 focus:ring-purple-500"
                    />
                    <span>External Task</span>
                  </label>
                </div>

                {editingTask.isExternal && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        External Destination URL
                      </label>
                      <input
                        type="url"
                        placeholder="https://youtube.com/watch?v=... or partner survey link"
                        value={editingTask.externalUrl || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, externalUrl: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Platform / Source Label
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. YouTube, Telegram, Survey Portal"
                        value={editingTask.externalPlatform || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, externalPlatform: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Section 5: Specific Task Category Settings */}
              {editingTask.category === 'app_download' && (
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/60 space-y-3">
                  <h4 className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5 text-xs">
                    <span>📱 App Download & Attribution Setup (200 Coins)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Android Package Name (Application ID) *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. com.binance.dev or com.whatsapp"
                        value={editingTask.appPackageName || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, appPackageName: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        App Icon Image URL
                      </label>
                      <input
                        type="url"
                        placeholder="https://..."
                        value={editingTask.appIconUrl || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, appIconUrl: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Attribution Postback Token
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. ATTRIB_TEP_BINANCE_2026"
                        value={editingTask.appPostbackToken || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, appPostbackToken: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Store Install URL (Play Store / Direct)
                      </label>
                      <input
                        type="url"
                        placeholder="https://play.google.com/store/apps/details?id=..."
                        value={editingTask.externalUrl || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, externalUrl: e.target.value, isExternal: true })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {editingTask.category === 'youtube_watch' && (
                <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800/60 space-y-3">
                  <h4 className="font-bold text-red-800 dark:text-red-300 flex items-center gap-1.5 text-xs">
                    <span>▶️ YouTube Video Task Configuration (25 Coins)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        YouTube Video URL or Video ID *
                      </label>
                      <input
                        type="text"
                        placeholder="https://youtube.com/watch?v=kJQP7kiw5Fk or kJQP7kiw5Fk"
                        value={editingTask.youtubeUrl || editingTask.youtubeVideoId || ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          let vid = val;
                          if (val.includes('v=')) vid = val.split('v=')[1]?.split('&')[0] || val;
                          else if (val.includes('youtu.be/')) vid = val.split('youtu.be/')[1]?.split('?')[0] || val;
                          setEditingTask({ 
                            ...editingTask, 
                            youtubeUrl: val, 
                            youtubeVideoId: vid,
                            youtubeThumbnailUrl: `https://img.youtube.com/vi/${vid}/mqdefault.jpg`
                          });
                        }}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Required Watch Duration (Seconds)
                      </label>
                      <input
                        type="number"
                        min={15}
                        max={3600}
                        value={editingTask.requiredWatchSeconds || 60}
                        onChange={(e) => setEditingTask({ ...editingTask, requiredWatchSeconds: Number(e.target.value) })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        e.g. 60s (1 min) or 3600s (1 hour)
                      </span>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Channel / Creator Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Task Earn Pro Official"
                        value={editingTask.channelTitle || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, channelTitle: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Custom Thumbnail URL (Optional)
                      </label>
                      <input
                        type="url"
                        placeholder="https://..."
                        value={editingTask.youtubeThumbnailUrl || ''}
                        onChange={(e) => setEditingTask({ ...editingTask, youtubeThumbnailUrl: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {editingTask.category === 'game' && (
                <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800/60 space-y-3">
                  <h4 className="font-bold text-indigo-800 dark:text-indigo-300 flex items-center gap-1.5 text-xs">
                    <span>🎮 Play Game Task Setup (18 Coins)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Game Engine Type
                      </label>
                      <select
                        value={editingTask.gameType || 'coin_collector'}
                        onChange={(e) => setEditingTask({ ...editingTask, gameType: e.target.value as any })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                      >
                        <option value="coin_collector">Coin Collector (Falling Items & Spikes)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                        Target Score to Win & Claim Reward
                      </label>
                      <input
                        type="number"
                        min={5}
                        max={200}
                        value={editingTask.gameTargetScore || 30}
                        onChange={(e) => setEditingTask({ ...editingTask, gameTargetScore: Number(e.target.value) })}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Status active switch */}
              <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800/60 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200 block">
                    Task Status
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Active tasks appear immediately in user dashboards.
                  </span>
                </div>
                <label className="flex items-center gap-2 cursor-pointer font-bold text-xs text-slate-800 dark:text-slate-200">
                  <input
                    type="checkbox"
                    checked={editingTask.isActive !== false}
                    onChange={(e) => setEditingTask({ ...editingTask, isActive: e.target.checked })}
                    className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
                  />
                  <span>{editingTask.isActive !== false ? 'Active (Live)' : 'Paused'}</span>
                </label>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black flex items-center gap-2 shadow-lg shadow-purple-600/20 active:scale-95 transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingTask.id ? 'Save & Update Task' : 'Create Task'}</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
