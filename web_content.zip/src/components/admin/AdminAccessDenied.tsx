import React from 'react';
import { ShieldAlert, ArrowLeft, Lock, LogIn } from 'lucide-react';

interface AdminAccessDeniedProps {
  language: string;
  onRetryLogin: () => void;
  onClose: () => void;
  reason?: string;
}

export default function AdminAccessDenied({
  language,
  onRetryLogin,
  onClose,
  reason
}: AdminAccessDeniedProps) {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-rose-600/50 rounded-3xl w-full max-w-md p-6 sm:p-8 text-center space-y-6 shadow-2xl animate-in fade-in zoom-in-95">
        
        <div className="w-16 h-16 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-3xl mx-auto flex items-center justify-center shadow-inner">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <h2 className="text-xl font-black text-white tracking-tight">
            {language === 'bn' ? 'অ্যাক্সেস ডিনায়েড (Access Denied)' : 'Access Denied'}
          </h2>
          <p className="text-xs text-rose-300 font-semibold bg-rose-950/60 border border-rose-900/60 rounded-xl p-3">
            {reason || (language === 'bn' 
              ? 'এই অংশে প্রবেশের জন্য অনুমোদিত অ্যাডমিনিস্ট্রেটর অ্যাকাউন্ট (Role: Admin) আবশ্যক।' 
              : 'Administrator credentials and verified Admin role claim are required to access this console.')}
          </p>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          {language === 'bn'
            ? 'সার্ভার-সাইড ভেরিফিকেশন ব্যর্থ হয়েছে। অনুগ্রহ করে আপনার অনুমোদিত অ্যাডমিন ইমেইল ও পাসওয়ার্ড দিয়ে পুনরায় লগইন করুন।'
            : 'Server-side authorization rejected the request. Please authenticate with your authorized Admin credentials.'}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-1/2 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{language === 'bn' ? 'অ্যাপে ফিরুন' : 'Return to App'}</span>
          </button>

          <button
            type="button"
            onClick={onRetryLogin}
            className="w-full sm:w-1/2 py-2.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <LogIn className="w-4 h-4" />
            <span>{language === 'bn' ? 'অ্যাডমিন লগইন' : 'Admin Login'}</span>
          </button>
        </div>

      </div>
    </div>
  );
}
