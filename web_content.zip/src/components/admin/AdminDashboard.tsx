import React, { useState } from 'react';
import {
  ShieldAlert,
  Users,
  CheckCircle2,
  XCircle,
  Tag,
  DollarSign,
  FileText,
  Settings,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  RotateCcw,
  Sliders,
  ChevronRight,
  Eye,
  Store,
  Trash2,
} from 'lucide-react';
import { Seller, Product, Order, Dispute, AuditLog, Coupon, Banner, SettlementLedgerEntry } from '../../types';

interface AdminDashboardProps {
  sellers: Seller[];
  products: Product[];
  orders: Order[];
  disputes: Dispute[];
  auditLogs: AuditLog[];
  coupons: Coupon[];
  banners: Banner[];
  settlements: SettlementLedgerEntry[];
  onApproveSeller: (sellerId: string) => void;
  onRejectSeller: (sellerId: string) => void;
  onDeleteSeller?: (sellerId: string) => void;
  onClearAllSellers?: () => void;
  onOpenRegistration?: () => void;
  onApproveProduct: (productId: string) => void;
  onRejectProduct: (productId: string) => void;
  onDeleteProduct?: (productId: string) => void;
  onClearAllProducts?: () => void;
  onLoadSampleProducts?: () => void;
  onResolveDispute: (disputeId: string, decision: 'REFUND' | 'REJECT') => void;
  onAddCoupon: (coupon: Coupon) => void;
  onGenerateSettlementBatch: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  sellers,
  products,
  orders,
  disputes,
  auditLogs,
  coupons,
  banners,
  settlements,
  onApproveSeller,
  onRejectSeller,
  onDeleteSeller,
  onClearAllSellers,
  onOpenRegistration,
  onApproveProduct,
  onRejectProduct,
  onDeleteProduct,
  onClearAllProducts,
  onLoadSampleProducts,
  onResolveDispute,
  onAddCoupon,
  onGenerateSettlementBatch,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'approvals' | 'disputes' | 'coupons' | 'settlements' | 'audit' | 'aiConfig'>('overview');

  // Coupon Creation State
  const [showCouponModal, setShowCouponModal] = useState<boolean>(false);
  const [couponCode, setCouponCode] = useState<string>('');
  const [couponDesc, setCouponDesc] = useState<string>('');
  const [couponVal, setCouponVal] = useState<number>(250);
  const [couponMin, setCouponMin] = useState<number>(1000);

  // AI Configuration State
  const [aiAutoModerate, setAiAutoModerate] = useState<boolean>(true);
  const [aiReviewThreshold, setAiReviewThreshold] = useState<number>(85);
  const [voiceSearchLang, setVoiceSearchLang] = useState<string>('Hinglish & English');

  // Compute platform metrics
  const totalGmv = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const platformEarnings = Math.round(totalGmv * 0.12);
  const pendingApprovalsCount = products.filter((p) => p.approvalStatus === 'PENDING').length;
  const openDisputesCount = disputes.filter((d) => d.status === 'OPEN').length;

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode) return;
    onAddCoupon({
      code: couponCode.toUpperCase(),
      description: couponDesc || `Flat ₹${couponVal} OFF on orders above ₹${couponMin}`,
      discountType: 'FLAT',
      value: Number(couponVal),
      minOrderValue: Number(couponMin),
      expiryDate: '2026-12-31',
    });
    setShowCouponModal(false);
    setCouponCode('');
    setCouponDesc('');
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 overflow-y-auto">
      {/* Top Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#1746A2] flex items-center justify-center text-[#FFD447] font-black shadow-md">
            🛡️
          </div>
          <div>
            <h1 className="text-xl font-black text-white">PCMART Central Admin Tower</h1>
            <p className="text-xs text-slate-400">
              Role: Super Administrator • Multi-Vendor Governance & Dispute Resolution
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-emerald-950 text-emerald-400 px-3 py-1.5 rounded-xl border border-emerald-500/30 text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Payment Gateway Online (HMAC Active)
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-6 flex gap-6 text-xs font-bold text-slate-400 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'overview' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Executive Overview
        </button>
        <button
          onClick={() => setActiveTab('approvals')}
          className={`py-3 border-b-2 transition-colors relative ${
            activeTab === 'approvals' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Catalog Approvals
          {pendingApprovalsCount > 0 && (
            <span className="ml-1.5 bg-[#FFD447] text-slate-950 px-1.5 py-0.2 rounded-full text-[10px] font-black">
              {pendingApprovalsCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('disputes')}
          className={`py-3 border-b-2 transition-colors relative ${
            activeTab === 'disputes' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Disputes & Returns
          {openDisputesCount > 0 && (
            <span className="ml-1.5 bg-red-500 text-white px-1.5 py-0.2 rounded-full text-[10px] font-black">
              {openDisputesCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('settlements')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'settlements' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Settlements & Commissions
        </button>
        <button
          onClick={() => setActiveTab('coupons')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'coupons' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Marketing & Coupons ({coupons.length})
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'audit' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          Immutable Audit Logs
        </button>
        <button
          onClick={() => setActiveTab('aiConfig')}
          className={`py-3 border-b-2 transition-colors ${
            activeTab === 'aiConfig' ? 'border-[#FFD447] text-[#FFD447]' : 'border-transparent hover:text-white'
          }`}
        >
          AI Automation Engine
        </button>
      </div>

      {/* Main Content */}
      <div className="p-6 space-y-6 flex-1">
        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Metric Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Total Gross Merchandise Value (GMV)</span>
                <div className="text-2xl font-black text-white">₹{totalGmv.toLocaleString()}</div>
                <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> Across {orders.length} Marketplace Orders
                </span>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Platform Net Commission (12%)</span>
                <div className="text-2xl font-black text-[#FFD447]">₹{platformEarnings.toLocaleString()}</div>
                <span className="text-[11px] text-slate-400">After payment gateway deductions</span>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Verified Active Merchants</span>
                <div className="text-2xl font-black text-white">{sellers.length} Sellers</div>
                <span className="text-[11px] text-emerald-400">100% GSTIN & Bank Audited</span>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
                <span className="text-xs text-slate-400 font-medium">Open Return Disputes</span>
                <div className="text-2xl font-black text-amber-400">{openDisputesCount} Pending</div>
                <span className="text-[11px] text-slate-400">Target SLA: 24 Hours</span>
              </div>
            </div>

            {/* Merchant Roster & Performance */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    Marketplace Seller Governance Roster
                    <span className="bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded-full font-bold">
                      {sellers.length} Active
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Live merchant accounts, GSTIN verification, and vendor governance.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {onOpenRegistration && (
                    <button
                      onClick={onOpenRegistration}
                      className="px-3 py-1.5 bg-[#FFD447] text-slate-950 font-bold text-xs rounded-xl hover:bg-amber-300 flex items-center gap-1.5 shadow"
                    >
                      <Store className="w-3.5 h-3.5" /> + Register Seller
                    </button>
                  )}
                  {sellers.length > 0 && onClearAllSellers && (
                    <button
                      onClick={onClearAllSellers}
                      className="px-3 py-1.5 bg-red-950/70 hover:bg-red-900 text-red-300 border border-red-500/40 font-bold text-xs rounded-xl flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Remove All Sellers
                    </button>
                  )}
                </div>
              </div>

              {sellers.length === 0 ? (
                <div className="p-8 text-center bg-slate-950 rounded-2xl border border-slate-800/80 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 text-2xl flex items-center justify-center mx-auto">
                    🏪
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Sabhi Seller Accounts Remove Kar Diye Gaye Hain</h4>
                    <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
                      Currently 0 active seller accounts in the app. Naye sellers registration flow ke dwara apni dukan create kar sakte hain.
                    </p>
                  </div>
                  {onOpenRegistration && (
                    <button
                      onClick={onOpenRegistration}
                      className="px-4 py-2 bg-[#FFD447] text-slate-950 font-black text-xs rounded-xl hover:bg-amber-300 inline-flex items-center gap-1.5"
                    >
                      <Store className="w-3.5 h-3.5" /> + Register Test Merchant
                    </button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] font-bold">
                      <tr>
                        <th className="p-3">Store Name</th>
                        <th className="p-3">Proprietor</th>
                        <th className="p-3">GSTIN & Location</th>
                        <th className="p-3">Fulfilled Orders</th>
                        <th className="p-3">Merchant Rating</th>
                        <th className="p-3">Commission Rate</th>
                        <th className="p-3">KYC Status</th>
                        <th className="p-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {sellers.map((s) => (
                        <tr key={s.id} className="hover:bg-slate-800/40">
                          <td className="p-3 font-bold text-white">{s.storeName}</td>
                          <td className="p-3">{s.ownerName}</td>
                          <td className="p-3">
                            <span className="font-mono text-slate-300 block">{s.gstin}</span>
                            <span className="text-[10px] text-slate-400">
                              {s.city}, {s.state}
                            </span>
                          </td>
                          <td className="p-3 font-semibold">{s.totalOrders} items</td>
                          <td className="p-3 text-amber-400 font-bold">★ {s.rating}</td>
                          <td className="p-3 font-semibold text-white">{(s.commissionRate * 100).toFixed(0)}%</td>
                          <td className="p-3">
                            <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded text-[10px] font-bold">
                              {s.status}
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            {onDeleteSeller && (
                              <button
                                onClick={() => onDeleteSeller(s.id)}
                                className="px-2.5 py-1 bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-500/30 rounded-lg text-[11px] font-bold inline-flex items-center gap-1"
                              >
                                <Trash2 className="w-3 h-3" /> Remove
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: APPROVALS */}
        {activeTab === 'approvals' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                  <span>Product Listing & Content Moderation Queue</span>
                  <span className="text-[10px] bg-[#1746A2] text-white px-2 py-0.5 rounded-full font-bold">
                    {products.length} Products
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Multi-vendor catalog governance, automated AI inspection, and compliance moderation.
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {onLoadSampleProducts && (
                  <button
                    onClick={onLoadSampleProducts}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-950/70 hover:bg-blue-900 border border-blue-500/40 text-blue-200 text-xs font-bold rounded-xl transition-all shadow-sm"
                  >
                    + Load Demo Products (Sample)
                  </button>
                )}
                {products.length > 0 && onClearAllProducts && (
                  <button
                    onClick={() => {
                      if (window.confirm('Kya aap sabhi products ko marketplace se remove karna chahte hain?')) {
                        onClearAllProducts();
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-950/70 hover:bg-red-900 border border-red-500/40 text-red-300 text-xs font-bold rounded-xl transition-all shadow-sm"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Remove All Products
                  </button>
                )}
              </div>
            </div>

            {products.length === 0 ? (
              <div className="py-10 px-4 text-center bg-slate-950/60 border border-slate-800/80 rounded-2xl space-y-3">
                <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#FFD447]">
                  <Store className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-white">Sabhi Products Successfully Remove Kar Diye Gaye Hain</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Currently catalog me 0 active products hain. Jab bhi koi verified seller naya product register karega ya publish karega, wo yahan queue me dikhai dega.
                  </p>
                </div>
                {onLoadSampleProducts && (
                  <button
                    onClick={onLoadSampleProducts}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1746A2] hover:bg-blue-600 text-white font-bold text-xs rounded-xl shadow transition-transform active:scale-95"
                  >
                    + Demo Testing Ke Liye 8 Sample Products Load Karein
                  </button>
                )}
              </div>
            ) : (
              <div className="divide-y divide-slate-800">
                {products.map((p) => (
                  <div key={p.id} className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
                    <div className="flex items-center gap-3">
                      <img src={p.images[0]} alt="" className="w-14 h-14 rounded-xl object-cover border border-slate-800" />
                      <div>
                        <span className="font-bold text-white text-sm block">{p.title}</span>
                        <span className="text-slate-400 text-[11px]">
                          Seller: {p.sellerName} • Category: {p.category} • Price: ₹{p.price} (MRP: ₹{p.mrp})
                        </span>
                        <p className="text-slate-300 text-[11px] mt-0.5 max-w-lg line-clamp-1">{p.shortHook}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/40 px-2 py-1 rounded text-xs font-bold">
                        {p.approvalStatus}
                      </span>
                      <button
                        onClick={() => onApproveProduct(p.id)}
                        className="px-3 py-1.5 bg-[#1746A2] hover:bg-blue-600 text-white font-bold rounded-xl shadow"
                      >
                        Re-verify
                      </button>
                      {onDeleteProduct && (
                        <button
                          onClick={() => {
                            if (window.confirm(`Product "${p.title}" ko delete karna chahte hain?`)) {
                              onDeleteProduct(p.id);
                            }
                          }}
                          title="Delete Product"
                          className="p-1.5 bg-red-950/60 hover:bg-red-900 border border-red-500/30 text-red-400 hover:text-red-200 rounded-xl transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: DISPUTES & RETURNS */}
        {activeTab === 'disputes' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Customer Return & Refund Disputes ({disputes.length})
            </h3>
            <p className="text-xs text-slate-400">
              Admin tribunal for arbitrating customer claims against sellers within the 7-day guarantee window.
            </p>

            <div className="space-y-3">
              {disputes.map((d) => (
                <div key={d.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <div>
                      <span className="font-bold text-white text-sm block">{d.productTitle}</span>
                      <span className="text-[10px] text-slate-400">
                        Order Ref: {d.orderId} • Claim Amount: ₹{d.amount} • Customer: {d.customerName}
                      </span>
                    </div>
                    <span
                      className={`px-2.5 py-1 rounded text-xs font-bold ${
                        d.status === 'OPEN'
                          ? 'bg-amber-950 text-amber-400 border border-amber-500/40'
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                      }`}
                    >
                      {d.status}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl text-slate-300">
                    <span className="font-extrabold text-[#FFD447] block mb-1">Customer Dispute Statement:</span>
                    <p>{d.reason}</p>
                    <span className="text-[10px] text-slate-400 block mt-1">Merchant: {d.sellerName}</span>
                  </div>

                  {d.status === 'OPEN' && (
                    <div className="flex gap-2 justify-end pt-1">
                      <button
                        onClick={() => onResolveDispute(d.id, 'REJECT')}
                        className="px-4 py-2 border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold rounded-xl"
                      >
                        Reject Claim
                      </button>
                      <button
                        onClick={() => onResolveDispute(d.id, 'REFUND')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow"
                      >
                        Approve Immediate Refund (₹{d.amount})
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: SETTLEMENTS */}
        {activeTab === 'settlements' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Marketplace Settlement Reconciliation Engine
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Batch-processes vendor payouts with automatic 12% marketplace fee, 2% PG fee, and 18% GST retention.
                  </p>
                </div>
                <button
                  onClick={onGenerateSettlementBatch}
                  className="px-4 py-2 bg-[#FFD447] hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow flex items-center gap-1.5"
                >
                  <DollarSign className="w-4 h-4" /> Run Settlement Batch
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] font-bold">
                    <tr>
                      <th className="p-3">Batch ID</th>
                      <th className="p-3">Seller Store</th>
                      <th className="p-3">Order Number</th>
                      <th className="p-3">Gross Sale</th>
                      <th className="p-3">PCMART 12%</th>
                      <th className="p-3">Net Payout</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Bank UTR Reference</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {settlements.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-800/40">
                        <td className="p-3 font-mono font-bold text-white">{s.id}</td>
                        <td className="p-3 font-semibold text-white">{s.sellerName}</td>
                        <td className="p-3">{s.orderId}</td>
                        <td className="p-3">₹{s.grossAmount}</td>
                        <td className="p-3 text-emerald-400 font-bold">₹{s.commissionDeduction}</td>
                        <td className="p-3 font-black text-[#FFD447]">₹{s.netPayout}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              s.status === 'SETTLED'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                                : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                            }`}
                          >
                            {s.status}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">
                          {s.utrNumber || 'Batch Queued for Bank Payout'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: COUPONS */}
        {activeTab === 'coupons' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Promotions & Platform Discount Coupons
                </h3>
                <p className="text-xs text-slate-400">Manage campaign vouchers available at customer checkout.</p>
              </div>
              <button
                onClick={() => setShowCouponModal(true)}
                className="px-3 py-1.5 bg-[#FFD447] text-slate-950 font-bold text-xs rounded-xl shadow"
              >
                + Create Coupon
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              {coupons.map((c) => (
                <div key={c.code} className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-sm font-black text-[#FFD447] bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                      {c.code}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-bold">ACTIVE</span>
                  </div>
                  <p className="text-xs text-white font-semibold">{c.description}</p>
                  <div className="flex justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-900">
                    <span>Min Order: ₹{c.minOrderValue}</span>
                    <span>Expires: {c.expiryDate}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: AUDIT LOGS */}
        {activeTab === 'audit' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Immutable Governance Audit Trail
            </h3>
            <p className="text-xs text-slate-400">
              Cryptographically timestamped action logs for regulatory compliance and dispute accountability.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/70 text-slate-400 uppercase text-[10px] font-bold">
                  <tr>
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">Actor</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Event Action</th>
                    <th className="p-3">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/40">
                      <td className="p-3 font-mono text-[11px] text-slate-400">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="p-3 font-semibold text-white">{log.actor}</td>
                      <td className="p-3">
                        <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-bold">
                          {log.role}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-[#FFD447]">{log.action}</td>
                      <td className="p-3 text-slate-300">{log.details}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 7: AI CONFIGURATION */}
        {activeTab === 'aiConfig' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 max-w-2xl text-xs">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Gemini AI Marketplace Settings
              </h3>
              <p className="text-slate-400 mt-0.5">
                Configure server-side Gemini 3.8 Flash models for voice search, catalog description drafting, and review intelligence.
              </p>
            </div>

            <div className="space-y-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Automated Catalog Moderation</span>
                  <span className="text-[10px] text-slate-400">
                    Flag medical, unauthorized counterfeit claims before listing.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={aiAutoModerate}
                  onChange={(e) => setAiAutoModerate(e.target.checked)}
                  className="w-4 h-4 accent-[#FFD447]"
                />
              </div>

              <div className="border-t border-slate-900 pt-3">
                <div className="flex justify-between mb-1">
                  <span className="font-bold text-white">Review Authenticity Confidence Threshold</span>
                  <span className="font-bold text-[#FFD447]">{aiReviewThreshold}%</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="99"
                  value={aiReviewThreshold}
                  onChange={(e) => setAiReviewThreshold(Number(e.target.value))}
                  className="w-full accent-[#FFD447]"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Reviews scoring below {aiReviewThreshold}% confidence are flagged for human audit.
                </span>
              </div>

              <div className="border-t border-slate-900 pt-3">
                <label className="font-bold text-white block mb-1">Primary Voice Recognition Dialects</label>
                <select
                  value={voiceSearchLang}
                  onChange={(e) => setVoiceSearchLang(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white"
                >
                  <option value="Hinglish & English">Hindi, Hinglish & English (Multi-lingual Hybrid)</option>
                  <option value="English Only">English (Standard)</option>
                  <option value="Pure Hindi">Pure Devanagari Hindi</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* CREATE COUPON MODAL */}
      {showCouponModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 space-y-4">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Issue Promotional Campaign Coupon
            </h3>
            <form onSubmit={handleCreateCoupon} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1 font-semibold">Coupon Code</label>
                <input
                  type="text"
                  required
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  placeholder="e.g. FESTIVE250"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white uppercase"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Flat Discount (₹)</label>
                  <input
                    type="number"
                    required
                    value={couponVal}
                    onChange={(e) => setCouponVal(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Min Order Value (₹)</label>
                  <input
                    type="number"
                    required
                    value={couponMin}
                    onChange={(e) => setCouponMin(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCouponModal(false)}
                  className="flex-1 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#FFD447] text-slate-950 font-black rounded-xl shadow"
                >
                  Publish Coupon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
