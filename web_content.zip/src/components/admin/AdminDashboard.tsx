import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  Users,
  Settings,
  ShieldAlert,
  Percent,
  MessageSquare,
  DollarSign,
  CheckCircle2,
  XCircle,
  Clock,
  Briefcase,
  Layers,
  ChevronRight,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { ServiceCategoryType } from '../../types';

export const AdminDashboard: React.FC = () => {
  const {
    adminConfig,
    updateAdminConfig,
    withdrawalRequests,
    processWithdrawal,
    sosAlerts,
    orders,
    providers,
    deliveryPartners,
    categories
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'commissions' | 'chat_rules' | 'withdrawals' | 'safety'
  >('overview');

  // Local state for chat rules
  const [freeLimit, setFreeLimit] = useState(adminConfig.chatRules.freeMessageLimit);
  const [unlockFee, setUnlockFee] = useState(adminConfig.chatRules.unlockFee);
  const [rulesSaved, setRulesSaved] = useState(false);

  // Financial calculations
  const totalGmv = orders.reduce((acc, o) => acc + o.grandTotal, 0);
  const totalPlatformCommissions = orders.reduce((acc, o) => {
    const rate = adminConfig.commissions[o.category] || 15;
    return acc + Math.round((o.grandTotal * rate) / 100);
  }, 0);

  const pendingWithdrawals = withdrawalRequests.filter(w => w.status === 'pending');

  const handleSaveChatRules = (e: React.FormEvent) => {
    e.preventDefault();
    updateAdminConfig({
      chatRules: {
        freeMessageLimit: freeLimit,
        unlockFee: unlockFee,
        enableMonetization: true
      }
    });
    setRulesSaved(true);
    setTimeout(() => setRulesSaved(false), 2000);
  };

  const handleUpdateCommission = (cat: ServiceCategoryType, newRate: number) => {
    updateAdminConfig({
      commissions: {
        ...adminConfig.commissions,
        [cat]: newRate
      }
    });
  };

  return (
    <div className="pb-24">
      {/* Admin Header */}
      <div className="p-4 bg-slate-950 text-white space-y-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center font-black text-sm">
              👑
            </div>
            <div>
              <h2 className="text-sm font-black text-white">AllJi Super Admin</h2>
              <p className="text-[10px] text-slate-400">Platform Control & Business Analytics</p>
            </div>
          </div>

          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
            System Live
          </span>
        </div>
      </div>

      {/* Sub Navigation Bar */}
      <div className="px-4 py-2.5 bg-white border-b border-slate-200 flex gap-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'commissions', label: 'Commissions' },
          { id: 'chat_rules', label: 'Chat Rules' },
          { id: 'withdrawals', label: `Withdrawals (${pendingWithdrawals.length})` },
          { id: 'safety', label: `Safety (${sosAlerts.length})` }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              activeTab === t.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB CONTENT */}
      <div className="p-4 space-y-4">
        {/* 1. OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-3">
            {/* Top Stat Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Gross Merchandise (GMV)
                </span>
                <p className="text-xl font-black text-slate-900 mt-0.5">₹{totalGmv}</p>
                <p className="text-[10px] text-emerald-600 font-bold mt-1">Across all categories</p>
              </div>

              <div className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Platform Commission
                </span>
                <p className="text-xl font-black text-amber-600 mt-0.5">
                  ₹{totalPlatformCommissions}
                </p>
                <p className="text-[10px] text-slate-500 font-semibold mt-1">Direct Platform Revenue</p>
              </div>
            </div>

            {/* Entity Counts */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2.5 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                <p className="text-xs font-black text-slate-900">{orders.length}</p>
                <p className="text-[9px] text-slate-500 font-semibold">Total Orders</p>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                <p className="text-xs font-black text-slate-900">{providers.length}</p>
                <p className="text-[9px] text-slate-500 font-semibold">Providers</p>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                <p className="text-xs font-black text-slate-900">{deliveryPartners.length}</p>
                <p className="text-[9px] text-slate-500 font-semibold">Riders</p>
              </div>
            </div>

            {/* Recent Orders Stream */}
            <div className="space-y-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
                Recent Customer Orders
              </h3>
              <div className="space-y-2">
                {orders.slice(0, 4).map(o => (
                  <div
                    key={o.id}
                    className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block">
                        #{o.orderNumber} • {o.category}
                      </span>
                      <p className="font-bold text-slate-900">{o.items[0]?.title}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-black text-slate-900 block">₹{o.grandTotal}</span>
                      <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded-md bg-amber-100 text-amber-800">
                        {o.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 2. COMMISSIONS CONFIG TAB */}
        {activeTab === 'commissions' && (
          <div className="space-y-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
                Category Commission Rates (%)
              </h3>
              <p className="text-xs text-slate-500">
                Configure the percentage platform fee retained from each service category.
              </p>
            </div>

            <div className="space-y-2">
              {categories.map(cat => {
                const currentPct = adminConfig.commissions[cat.id] ?? 15;
                return (
                  <div
                    key={cat.id}
                    className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{cat.title}</h4>
                      <p className="text-[10px] text-slate-400">Category ID: {cat.id}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={0}
                        max={50}
                        value={currentPct}
                        onChange={e =>
                          handleUpdateCommission(cat.id, parseInt(e.target.value) || 0)
                        }
                        className="w-16 p-1.5 text-xs text-center font-black rounded-xl border border-slate-300"
                      />
                      <span className="text-xs font-bold text-slate-500">%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. CHAT RULES & MONETIZATION CONFIG TAB */}
        {activeTab === 'chat_rules' && (
          <form
            onSubmit={handleSaveChatRules}
            className="p-4 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4"
          >
            <div>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-amber-600" />
                <h3 className="text-sm font-black text-slate-900">In-App Chat Monetization Rules</h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Configure customer free message threshold and unlock pricing for direct partner chats.
              </p>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Free Messages Allowed Per Booking:
              </label>
              <input
                type="number"
                min={1}
                max={20}
                value={freeLimit}
                onChange={e => setFreeLimit(parseInt(e.target.value))}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-300 font-bold"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Typically 4 or 5 free messages for directions, gate code, or quick confirmation.
              </p>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Unlimited Chat Unlock Price (₹):
              </label>
              <input
                type="number"
                min={5}
                max={500}
                value={unlockFee}
                onChange={e => setUnlockFee(parseInt(e.target.value))}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-300 font-bold"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Charged to customer or auto-deducted from AllJi Wallet to unlock unlimited conversation.
              </p>
            </div>

            {rulesSaved && (
              <div className="p-2 bg-emerald-50 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Chat monetization rules saved and applied live across all orders!</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all"
            >
              Save Chat Rules
            </button>
          </form>
        )}

        {/* 4. WITHDRAWALS TAB */}
        {activeTab === 'withdrawals' && (
          <div className="space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
              Provider & Rider Withdrawal Requests ({withdrawalRequests.length})
            </h3>

            <div className="space-y-2">
              {withdrawalRequests.map(req => (
                <div
                  key={req.id}
                  className="p-3 bg-white rounded-2xl border border-slate-200 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-black text-slate-900">{req.providerName}</h4>
                      <p className="text-[10px] text-slate-400">
                        {req.payoutMethod.toUpperCase()}: {req.accountDetails}
                      </p>
                    </div>
                    <span className="text-sm font-black text-emerald-700">₹{req.amount}</span>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                    <span
                      className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md ${
                        req.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : req.status === 'rejected'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {req.status}
                    </span>

                    {req.status === 'pending' && (
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => processWithdrawal(req.id, 'rejected')}
                          className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 font-bold text-xs hover:bg-rose-100"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => processWithdrawal(req.id, 'approved')}
                          className="px-3 py-1 rounded-lg bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700 shadow-xs"
                        >
                          Approve Payout
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. SAFETY & SOS INCIDENTS TAB */}
        {activeTab === 'safety' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
                Emergency SOS Incident Reports
              </h3>
              <span className="text-xs font-bold text-red-600 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>24x7 Safety Response</span>
              </span>
            </div>

            {sosAlerts.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-3xl border border-slate-200">
                <ShieldCheck className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
                <h4 className="text-xs font-bold text-slate-800">All Safe</h4>
                <p className="text-[10px] text-slate-400 mt-0.5">No active SOS alerts triggered.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {sosAlerts.map(alert => (
                  <div
                    key={alert.id}
                    className="p-3 bg-red-50/80 border border-red-200 rounded-2xl space-y-1.5 text-xs text-red-950"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-black text-red-900 flex items-center gap-1">
                        <ShieldAlert className="w-3.5 h-3.5 text-red-600" />
                        <span>EMERGENCY ALERT</span>
                      </span>
                      <span className="text-[10px] text-red-700">
                        {new Date(alert.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="font-semibold">{alert.message}</p>
                    <p className="text-[10px] text-red-800">
                      Location: {alert.location.locality}, {alert.location.city}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
