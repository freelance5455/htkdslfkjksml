import React from 'react';
import { User, TaskTemplate, TaskRecord, ShortageItem, ShiftHandover } from '../../types';
import { AdminTab } from '../common/BottomNav';
import {
  CheckCircle2,
  ClockAlert,
  ShoppingCart,
  Users,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  ChefHat,
  Repeat,
  Plus,
  ShieldCheck,
  PackageCheck,
} from 'lucide-react';

interface AdminDashboardProps {
  currentUser: User;
  templates: TaskTemplate[];
  records: TaskRecord[];
  shortages: ShortageItem[];
  handovers: ShiftHandover[];
  users: User[];
  onNavigateTab: (tab: AdminTab) => void;
  onMarkShortagePurchased: (id: string) => void;
  onOpenNewTaskModal: () => void;
  onOpenNewEmployeeModal: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  templates,
  records,
  shortages,
  handovers,
  users,
  onNavigateTab,
  onMarkShortagePurchased,
  onOpenNewTaskModal,
  onOpenNewEmployeeModal,
}) => {
  // Stats
  const completedTasksCount = records.filter((r) => r.status === 'realizada').length;
  const pendingTasksCount = records.filter((r) => r.status === 'pendiente').length;
  const pendingPurchases = shortages.filter((s) => s.status === 'Pendiente');
  const activeEmployees = users.filter((u) => u.role === 'EMPLEADO' && u.active).length;

  return (
    <div className="space-y-5 max-w-5xl mx-auto">
      {/* Welcome Banner */}
      <div className="bg-neutral-900 text-white rounded-2xl p-5 sm:p-6 shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-orange-400 bg-orange-950/80 px-2.5 py-0.5 rounded border border-orange-800/60">
                Panel de Administración
              </span>
              <span className="text-xs text-neutral-400">Control Central</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              ¡Bienvenido, {currentUser.name}!
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-xl">
              Monitorea el cumplimiento de tareas por área, resuelve pendientes dejados por turnos anteriores y surte los insumos faltantes reportados por tu equipo.
            </p>
          </div>

          {/* Action Quick Buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              id="dash-btn-new-task"
              onClick={onOpenNewTaskModal}
              className="py-2.5 px-3.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Crear Tarea</span>
            </button>
            <button
              id="dash-btn-new-emp"
              onClick={onOpenNewEmployeeModal}
              className="py-2.5 px-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-bold text-xs flex items-center gap-1.5 border border-neutral-700 active:scale-95 transition-all"
            >
              <Users className="w-4 h-4 text-orange-400" />
              <span>Nuevo Empleado</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Tareas Realizadas */}
        <div
          onClick={() => onNavigateTab('tareas_admin')}
          className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs cursor-pointer hover:border-emerald-300 transition-all"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">
              Realizadas
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-neutral-900">{completedTasksCount}</div>
          <div className="text-[11px] text-emerald-700 font-semibold mt-1 flex items-center gap-1">
            <span>Registradas con hora y empleado</span>
          </div>
        </div>

        {/* Tareas Pendientes */}
        <div
          onClick={() => onNavigateTab('tareas_admin')}
          className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs cursor-pointer hover:border-amber-300 transition-all"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">
              Pendientes
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <ClockAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-neutral-900">{pendingTasksCount}</div>
          <div className="text-[11px] text-amber-700 font-semibold mt-1">
            Con motivo especificado
          </div>
        </div>

        {/* Compras Pendientes */}
        <div
          onClick={() => onNavigateTab('compras')}
          className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs cursor-pointer hover:border-red-300 transition-all"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">
              Por Comprar
            </span>
            <div className="w-8 h-8 rounded-xl bg-red-100 text-red-700 flex items-center justify-center">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-neutral-900">
            {pendingPurchases.length}
          </div>
          <div className="text-[11px] text-red-700 font-semibold mt-1">
            Faltantes por surtir
          </div>
        </div>

        {/* Empleados Activos */}
        <div
          onClick={() => onNavigateTab('empleados')}
          className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs cursor-pointer hover:border-blue-300 transition-all"
        >
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">
              Empleados
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-neutral-900">{activeEmployees}</div>
          <div className="text-[11px] text-blue-700 font-semibold mt-1">
            En cocina, barra, piso y caja
          </div>
        </div>
      </div>

      {/* Critical Section: Compras Pendientes Urgent Preview */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-neutral-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center font-bold">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-neutral-900 tracking-tight">
                Compras Pendientes (Faltantes Reportados)
              </h2>
              <p className="text-xs text-neutral-500">
                Productos reportados por empleados que requieren ser surtidos
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('compras')}
            className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 shrink-0"
          >
            <span>Ver todas</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {pendingPurchases.length === 0 ? (
          <div className="p-6 text-center bg-neutral-50 rounded-xl border border-neutral-200 text-xs text-neutral-500">
            ¡No hay compras pendientes! Todos los insumos están abastecidos.
          </div>
        ) : (
          <div className="divide-y divide-neutral-100">
            {pendingPurchases.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-neutral-900 text-sm">{item.product}</span>
                    <span className="text-xs font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded border border-orange-200">
                      {item.quantity}
                    </span>
                    <span className="text-[11px] text-neutral-400">({item.areaName})</span>
                  </div>
                  <div className="text-xs text-neutral-600 mt-0.5">
                    Reportó: <strong>{item.reportedByName}</strong> ({item.shift}) • {item.date} {item.time}
                  </div>
                  {item.comment && (
                    <div className="text-xs text-neutral-500 italic mt-0.5">
                      "{item.comment}"
                    </div>
                  )}
                </div>

                <button
                  id={`btn-dash-buy-${item.id}`}
                  onClick={() => onMarkShortagePurchased(item.id)}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shrink-0 shadow-xs active:scale-95 transition-all"
                >
                  <PackageCheck className="w-4 h-4" />
                  <span>Marcar Comprado</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Latest Shift Handovers Preview */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-neutral-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <Repeat className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-neutral-900 tracking-tight">
                Últimas Entregas de Turno
              </h2>
              <p className="text-xs text-neutral-500">
                Observaciones y traspasos dejados por los empleados al terminar su turno
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('historial')}
            className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 shrink-0"
          >
            <span>Ver historial</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {handovers.length === 0 ? (
          <div className="p-6 text-center bg-neutral-50 rounded-xl border border-neutral-200 text-xs text-neutral-500">
            Aún no hay entregas de turno registradas hoy.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {handovers.slice(0, 4).map((h) => (
              <div
                key={h.id}
                className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-neutral-900 text-sm">
                    {h.areaName} — {h.fromShift}
                  </div>
                  <span className="text-[11px] text-neutral-500">{h.time}</span>
                </div>
                <div className="text-neutral-600 font-medium">
                  Entregado por: <strong>{h.employeeName}</strong>
                </div>
                <p className="italic text-neutral-700 bg-white p-2 rounded-lg border border-neutral-200">
                  "{h.observations}"
                </p>
                <div className="flex items-center gap-2 text-[11px] text-neutral-500 pt-1">
                  <span>✓ {h.completedTasksSummary?.length || 0} realizadas</span>
                  <span>•</span>
                  <span>⏳ {h.pendingTasksSummary?.length || 0} pendientes</span>
                  <span>•</span>
                  <span>⚠️ {h.shortagesSummary?.length || 0} faltantes</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
