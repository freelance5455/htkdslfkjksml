import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { Song } from '../../types/music';
import { CoverArt } from '../common/CoverArt';
import {
  ShieldCheck,
  X,
  Users,
  Music,
  Disc3,
  TrendingUp,
  Plus,
  Trash2,
  Edit2,
  Search,
  CheckCircle,
  AlertTriangle,
  Play,
  BarChart3,
  FileText
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    isAdminOpen,
    setIsAdminOpen,
    songs,
    artists,
    albums,
    playlists,
    addSongAdmin,
    editSongAdmin,
    deleteSongAdmin
  } = useMusic();

  const [activeTab, setActiveTab] = useState<'overview' | 'songs' | 'users' | 'analytics'>('overview');
  const [songSearch, setSongSearch] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [isAddSongOpen, setIsAddSongOpen] = useState(false);

  // New Song Form State
  const [newTitle, setNewTitle] = useState('');
  const [newArtist, setNewArtist] = useState('');
  const [newAlbum, setNewAlbum] = useState('Express Master');
  const [newGenre, setNewGenre] = useState<any>('English');
  const [newDuration, setNewDuration] = useState('3:30');
  const [newDurationSec, setNewDurationSec] = useState(210);
  const [newPreset, setNewPreset] = useState<any>('synthwave');

  // Simulated Users Table
  const [mockUsers, setMockUsers] = useState([
    { id: '1', name: 'Sahanur Alam', email: 'sahanuralam781108@gmail.com', status: 'Active', plan: 'Hi-Fi Master', streams: 1420 },
    { id: '2', name: 'Priya Mukherjee', email: 'priya.m@example.com', status: 'Active', plan: 'Premium', streams: 840 },
    { id: '3', name: 'Rahul Sharma', email: 'rahul.s@example.com', status: 'Active', plan: 'Free', streams: 310 },
    { id: '4', name: 'David Miller', email: 'david.m@example.com', status: 'Suspended', plan: 'Free', streams: 15 },
    { id: '5', name: 'Ananya Bose', email: 'ananya.b@example.com', status: 'Active', plan: 'Premium', streams: 690 }
  ]);

  if (!isAdminOpen) return null;

  const handleAddSongSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newArtist.trim()) return;

    addSongAdmin({
      title: newTitle.trim(),
      artist: newArtist.trim(),
      artistId: 'artist-custom',
      album: newAlbum.trim(),
      albumId: 'album-custom',
      albumArt: 'custom_song',
      duration: newDuration,
      durationSec: newDurationSec,
      genre: newGenre,
      releaseDate: new Date().toISOString().split('T')[0],
      bpm: 110,
      synthPreset: newPreset,
      colorTheme: { from: '#9333ea', to: '#3b82f6', accent: '#c084fc' },
      lyrics: [
        { time: 0, text: `♪ Intro to ${newTitle} ♪` },
        { time: 10, text: 'Melodic verse lines flowing smoothly...' },
        { time: 25, text: 'Harmonic chorus taking over the soundscape' },
        { time: 45, text: `♪ Outro - ${newTitle} ♪` }
      ]
    });

    setNewTitle('');
    setNewArtist('');
    setIsAddSongOpen(false);
  };

  const toggleUserStatus = (id: string) => {
    setMockUsers((prev) =>
      prev.map((u) =>
        u.id === id ? { ...u, status: u.status === 'Active' ? 'Suspended' : 'Active' } : u
      )
    );
  };

  const deleteUser = (id: string) => {
    setMockUsers((prev) => prev.filter((u) => u.id !== id));
  };

  const filteredSongs = songs.filter(
    (s) =>
      s.title.toLowerCase().includes(songSearch.toLowerCase()) ||
      s.artist.toLowerCase().includes(songSearch.toLowerCase()) ||
      s.genre.toLowerCase().includes(songSearch.toLowerCase())
  );

  const filteredUsers = mockUsers.filter(
    (u) =>
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b0c10] text-slate-100 overflow-y-auto animate-in fade-in">
      {/* Top Navbar */}
      <div className="sticky top-0 z-20 backdrop-blur-xl bg-[#0e1017]/90 border-b border-white/[0.08] px-5 py-3">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-600/30 text-purple-400 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-base text-white">Music Express Admin Console</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-semibold">
                  LIVE
                </span>
              </div>
              <p className="text-xs text-slate-400">Streaming system status & music catalog management</p>
            </div>
          </div>

          <button
            onClick={() => setIsAdminOpen(false)}
            className="p-2 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto w-full px-5 py-6 space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-white/[0.08] pb-3 overflow-x-auto no-scrollbar">
          {[
            { id: 'overview', label: 'Overview & Metrics', icon: BarChart3 },
            { id: 'songs', label: `Music Catalog (${songs.length})`, icon: Music },
            { id: 'users', label: 'User Accounts', icon: Users },
            { id: 'analytics', label: 'Streaming Analytics', icon: TrendingUp }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold shrink-0 transition-all ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-white/[0.03] text-slate-400 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* KPI Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
                <span className="text-xs text-slate-400 font-medium">Total Users</span>
                <p className="text-xl font-display font-extrabold text-white mt-1">14,280</p>
                <span className="text-[10px] text-emerald-400 font-semibold">+12% this month</span>
              </div>
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
                <span className="text-xs text-slate-400 font-medium">Active Listeners</span>
                <p className="text-xl font-display font-extrabold text-purple-400 mt-1">8,940</p>
                <span className="text-[10px] text-slate-400 font-medium">62.6% retention</span>
              </div>
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
                <span className="text-xs text-slate-400 font-medium">Total Songs</span>
                <p className="text-xl font-display font-extrabold text-white mt-1">{songs.length}</p>
                <span className="text-[10px] text-purple-300 font-medium">Across 10 genres</span>
              </div>
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
                <span className="text-xs text-slate-400 font-medium">Total Artists</span>
                <p className="text-xl font-display font-extrabold text-pink-400 mt-1">{artists.length}</p>
                <span className="text-[10px] text-slate-400 font-medium">Verified roster</span>
              </div>
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
                <span className="text-xs text-slate-400 font-medium">Playlists</span>
                <p className="text-xl font-display font-extrabold text-blue-400 mt-1">{playlists.length}</p>
                <span className="text-[10px] text-slate-400 font-medium">Curated & User</span>
              </div>
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
                <span className="text-xs text-slate-400 font-medium">Daily Streams</span>
                <p className="text-xl font-display font-extrabold text-emerald-400 mt-1">42,910</p>
                <span className="text-[10px] text-emerald-400 font-medium">+18.4% today</span>
              </div>
            </div>

            {/* Quick Summary Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/[0.06] space-y-3">
                <h3 className="font-display font-bold text-sm text-white">Top 3 Streamed Tracks</h3>
                <div className="space-y-2">
                  {songs.slice(0, 3).map((s, idx) => (
                    <div key={s.id} className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02]">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-5 text-center font-mono font-bold text-xs text-amber-400">0{idx + 1}</span>
                        <div className="min-w-0">
                          <p className="font-semibold text-xs text-white truncate">{s.title}</p>
                          <p className="text-[10px] text-slate-400 truncate">{s.artist}</p>
                        </div>
                      </div>
                      <span className="text-xs font-mono text-purple-300 font-medium">
                        {(s.playCount / 1000).toFixed(0)}k plays
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/[0.06] space-y-3">
                <h3 className="font-display font-bold text-sm text-white">Streaming Health & Systems</h3>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between p-2 rounded-xl bg-white/[0.02]">
                    <span className="text-slate-300">Web Audio Synthesis Engine</span>
                    <span className="text-emerald-400 font-semibold">Healthy (100%)</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-xl bg-white/[0.02]">
                    <span className="text-slate-300">Lyrics Sync Latency</span>
                    <span className="text-emerald-400 font-semibold">&lt; 15ms</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-xl bg-white/[0.02]">
                    <span className="text-slate-300">Offline Cache Availability</span>
                    <span className="text-purple-300 font-semibold">Ready</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Songs Management */}
        {activeTab === 'songs' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={songSearch}
                  onChange={(e) => setSongSearch(e.target.value)}
                  placeholder="Filter songs by title, artist, genre..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              <button
                onClick={() => setIsAddSongOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-md transition-all self-end sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Track</span>
              </button>
            </div>

            {/* Song Table */}
            <div className="overflow-x-auto rounded-2xl border border-white/[0.06] bg-white/[0.02]">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/[0.04] text-slate-400 font-semibold border-b border-white/[0.06]">
                  <tr>
                    <th className="p-3">Track & Title</th>
                    <th className="p-3">Artist</th>
                    <th className="p-3">Genre</th>
                    <th className="p-3">Duration</th>
                    <th className="p-3">Plays</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04] text-slate-300">
                  {filteredSongs.map((song) => (
                    <tr key={song.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="p-3 font-semibold text-white flex items-center gap-2.5">
                        <CoverArt
                          artKey={song.albumArt}
                          colorTheme={song.colorTheme}
                          size="sm"
                          className="w-8 h-8 rounded-lg"
                        />
                        <span className="truncate max-w-[180px]">{song.title}</span>
                      </td>
                      <td className="p-3 text-slate-300">{song.artist}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-300 font-medium text-[10px]">
                          {song.genre}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-slate-400">{song.duration}</td>
                      <td className="p-3 font-mono text-purple-300">
                        {song.playCount.toLocaleString()}
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => {
                            if (confirm(`Delete "${song.title}" from catalog?`)) {
                              deleteSongAdmin(song.id);
                            }
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-white/10 transition-colors"
                          title="Delete song"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: User Accounts */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Search registered users..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="overflow-x-auto rounded-2xl border border-white/[0.06] bg-white/[0.02]">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/[0.04] text-slate-400 font-semibold border-b border-white/[0.06]">
                  <tr>
                    <th className="p-3">User</th>
                    <th className="p-3">Email</th>
                    <th className="p-3">Membership Tier</th>
                    <th className="p-3">Total Streams</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04] text-slate-300">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="p-3 font-semibold text-white">{u.name}</td>
                      <td className="p-3 text-slate-400 font-mono text-[11px]">{u.email}</td>
                      <td className="p-3 font-medium text-purple-300">{u.plan}</td>
                      <td className="p-3 font-mono">{u.streams}</td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            u.status === 'Active'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-red-500/20 text-red-400'
                          }`}
                        >
                          {u.status}
                        </span>
                      </td>
                      <td className="p-3 text-right space-x-1">
                        <button
                          onClick={() => toggleUserStatus(u.id)}
                          className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] font-medium text-slate-300 transition-colors"
                        >
                          {u.status === 'Active' ? 'Suspend' : 'Activate'}
                        </button>
                        <button
                          onClick={() => deleteUser(u.id)}
                          className="p-1 rounded-lg text-slate-500 hover:text-red-400 transition-colors"
                          title="Delete user"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 4: Analytics */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/[0.06] space-y-3">
              <h3 className="font-display font-bold text-sm text-white">Daily Streams (Past 7 Days)</h3>
              <div className="h-40 flex items-end gap-3 pt-6 pb-2 px-2">
                {[
                  { day: 'Mon', val: 32000 },
                  { day: 'Tue', val: 34500 },
                  { day: 'Wed', val: 38200 },
                  { day: 'Thu', val: 36000 },
                  { day: 'Fri', val: 44800 },
                  { day: 'Sat', val: 48900 },
                  { day: 'Sun', val: 42910 }
                ].map((item, idx) => {
                  const pct = Math.round((item.val / 50000) * 100);
                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                      <div
                        className="w-full rounded-xl bg-gradient-to-t from-purple-600 to-pink-500 transition-all hover:brightness-110"
                        style={{ height: `${pct}%` }}
                      />
                      <span className="text-[10px] font-mono text-slate-400">{item.day}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/[0.06] space-y-3">
                <h3 className="font-display font-bold text-sm text-white">Top Genres by Listening Time</h3>
                <div className="space-y-2">
                  {[
                    { genre: 'Bengali Acoustic & Folk', pct: 28 },
                    { genre: 'Bollywood Romantic', pct: 26 },
                    { genre: 'Synthwave & Electronic', pct: 20 },
                    { genre: 'Workout & EDM', pct: 14 },
                    { genre: 'Lo-Fi Chill & Focus', pct: 12 }
                  ].map((g, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-300">
                        <span>{g.genre}</span>
                        <span className="font-mono text-purple-300">{g.pct}%</span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full bg-purple-500 rounded-full"
                          style={{ width: `${g.pct}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-5 rounded-3xl bg-white/[0.02] border border-white/[0.06] space-y-3">
                <h3 className="font-display font-bold text-sm text-white">Monthly Revenue Projections</h3>
                <p className="text-2xl font-display font-black text-white">$18,420</p>
                <p className="text-xs text-slate-400">
                  Calculated from active premium subscriptions and streaming licenses.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Song Modal */}
      {isAddSongOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="w-full max-w-md rounded-3xl bg-[#141622] border border-white/10 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <h3 className="font-display font-bold text-base text-white">Add New Song to Express Catalog</h3>
              <button onClick={() => setIsAddSongOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddSongSubmit} className="mt-4 space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Song Title *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Moonlight Reverie"
                  className="w-full px-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Artist *</label>
                <input
                  type="text"
                  required
                  value={newArtist}
                  onChange={(e) => setNewArtist(e.target.value)}
                  placeholder="e.g. Arijit Singh"
                  className="w-full px-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">Genre</label>
                  <select
                    value={newGenre}
                    onChange={(e) => setNewGenre(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-[#1c1e2b] border border-white/10 text-white text-xs focus:outline-none"
                  >
                    {['Chill', 'Romantic', 'Workout', 'Party', 'Sad', 'Focus', 'Lo-Fi', 'Bollywood', 'Bengali', 'English'].map(
                      (g) => (
                        <option key={g} value={g}>{g}</option>
                      )
                    )}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">Synthesizer Sound</label>
                  <select
                    value={newPreset}
                    onChange={(e) => setNewPreset(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-[#1c1e2b] border border-white/10 text-white text-xs focus:outline-none"
                  >
                    <option value="synthwave">Synthwave (Electronic)</option>
                    <option value="bengali">Bengali (Acoustic Folk)</option>
                    <option value="acoustic">Acoustic (Piano/Guitar)</option>
                    <option value="lofi">Lo-Fi (Chill Rhodes)</option>
                    <option value="dance">Dance (High BPM)</option>
                    <option value="ambient">Ambient (Deep Focus)</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-colors shadow-md"
                >
                  Publish Track
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddSongOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
