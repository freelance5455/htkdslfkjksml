import React, { useEffect, useState } from 'react';
import {
  Users,
  Clock,
  MapPin,
  CheckSquare,
  TrendingUp,
  AlertTriangle,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Compass,
} from 'lucide-react';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  Employee,
  AttendanceRecord,
  FieldVisit,
  TaskItem,
  LeaveRequest,
} from '../../types/index.ts';
import { ActivityCenter } from './ActivityCenter.tsx';

interface AdminDashboardProps {
  onNavigate: (module: string) => void;
  onOpenAiAssistant: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate, onOpenAiAssistant }) => {
  const { currentOrg } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord[]>([]);
  const [todayVisits, setTodayVisits] = useState<FieldVisit[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([]);
  const [loading, setLoading] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  const fetchDashboardStats = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const [empSnap, attSnap, visSnap, tskSnap, lveSnap] = await Promise.all([
        getDocs(query(collection(db, 'employees'), where('orgId', '==', currentOrg.id), limit(200))),
        getDocs(query(collection(db, 'attendance'), where('orgId', '==', currentOrg.id), where('date', '==', todayStr))),
        getDocs(query(collection(db, 'visits'), where('orgId', '==', currentOrg.id), where('scheduledDate', '==', todayStr))),
        getDocs(query(collection(db, 'tasks'), where('orgId', '==', currentOrg.id), limit(200))),
        getDocs(query(collection(db, 'leave_requests'), where('orgId', '==', currentOrg.id))),
      ]);

      const empList: Employee[] = [];
      empSnap.forEach((d) => empList.push(d.data() as Employee));
      setEmployees(empList);

      const attList: AttendanceRecord[] = [];
      attSnap.forEach((d) => attList.push(d.data() as AttendanceRecord));
      setTodayAttendance(attList);

      const visList: FieldVisit[] = [];
      visSnap.forEach((d) => visList.push(d.data() as FieldVisit));
      setTodayVisits(visList);

      const tskList: TaskItem[] = [];
      tskSnap.forEach((d) => tskList.push(d.data() as TaskItem));
      setTasks(tskList);

      const lveList: LeaveRequest[] = [];
      lveSnap.forEach((d) => lveList.push(d.data() as LeaveRequest));
      setLeaveRequests(lveList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardStats();
  }, [currentOrg, todayStr]);

  // Derived real metric values
  const totalEmployees = employees.length;
  const presentCount = todayAttendance.length;
  const activeInField = todayAttendance.filter((a) => !a.checkOutTime).length;
  const activeLeaves = leaveRequests.filter(
    (l) => l.status === 'approved' && l.startDate <= todayStr && l.endDate >= todayStr
  ).length;
  const absentCount = Math.max(0, totalEmployees - presentCount - activeLeaves);

  const completedVisits = todayVisits.filter((v) => v.status === 'completed').length;
  const pendingVisits = todayVisits.filter((v) => v.status !== 'completed' && v.status !== 'cancelled').length;

  const pendingTasks = tasks.filter((t) => t.status === 'pending' || t.status === 'in_progress').length;
  const overdueTasks = tasks.filter((t) => t.status !== 'completed' && t.dueDate < todayStr);

  const pendingLeaves = leaveRequests.filter((l) => l.status === 'pending');
  const pendingCorrections = todayAttendance.filter((a) => a.correctionRequest?.status === 'pending');

  return (
    <div className="space-y-5">
      {/* 1. Activity Center: "What needs my attention today?" */}
      <ActivityCenter onNavigate={onNavigate} />

      {/* 2. Top Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Total Workforce */}
        <div
          onClick={() => onNavigate('employees')}
          className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs cursor-pointer hover:border-sky-300 transition-all"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Workforce</span>
            <div className="w-8 h-8 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{totalEmployees}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5">
            <span className="text-emerald-700 font-bold">{presentCount} Present</span>
            <span>·</span>
            <span className="text-slate-500">{absentCount} Absent</span>
            <span>·</span>
            <span className="text-amber-700 font-bold">{activeLeaves} On Leave</span>
          </div>
        </div>

        {/* Active Field Technicians */}
        <div
          onClick={() => onNavigate('live_map')}
          className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs cursor-pointer hover:border-emerald-300 hover:ring-2 hover:ring-emerald-100 transition-all group"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Active in Field</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <Compass className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{activeInField}</div>
          <div className="text-[11px] text-emerald-600 mt-1 font-semibold flex items-center justify-between">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Currently on shift</span>
            </span>
            <span className="text-[10px] text-sky-600 font-bold underline flex items-center gap-0.5">
              <span>View Live Map</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </span>
          </div>
        </div>

        {/* Today's Visits */}
        <div
          onClick={() => onNavigate('visits')}
          className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs cursor-pointer hover:border-sky-300 transition-all"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Today's Field Visits</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{todayVisits.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            <strong className="text-emerald-600">{completedVisits} Completed</strong> · {pendingVisits} In Progress
          </div>
        </div>

        {/* Pending Tasks */}
        <div
          onClick={() => onNavigate('tasks')}
          className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs cursor-pointer hover:border-sky-300 transition-all"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Open Tasks</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <CheckSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{pendingTasks}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            {overdueTasks.length > 0 ? (
              <span className="text-rose-600 font-bold">{overdueTasks.length} Overdue</span>
            ) : (
              <span className="text-emerald-600 font-medium">All tasks within deadline</span>
            )}
          </div>
        </div>
      </div>

      {/* 3. Operational Grid (Today's Visits Schedule & Field Workforce Status) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Today's Visits Dispatch Schedule */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-sky-600" />
              <span>Today's Dispatched Visits</span>
            </h3>
            <button
              onClick={() => onNavigate('visits')}
              className="text-xs text-sky-600 hover:text-sky-800 font-bold flex items-center gap-1"
            >
              <span>Manage All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {todayVisits.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No field visits scheduled for today yet.
            </div>
          ) : (
            <div className="space-y-2.5">
              {todayVisits.slice(0, 4).map((vis) => (
                <div
                  key={vis.id}
                  className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-slate-900">{vis.title}</div>
                    <div className="text-[11px] text-slate-500">
                      {vis.customerName} · Assigned to <strong>{vis.assignedEmployeeName}</strong>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                      vis.status === 'completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : vis.status === 'in_progress'
                        ? 'bg-sky-100 text-sky-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {vis.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* AI Operations Banner & Quick Assistant */}
        <div className="bg-gradient-to-br from-slate-900 to-indigo-950 rounded-2xl p-5 text-white shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs">
              <Sparkles className="w-4 h-4" />
              <span>FieldFlow AI Operations Intelligence</span>
            </div>
            <h4 className="text-base font-black text-white">Instant Natural Language Insights</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Ask about technician attendance anomalies, repeat customer site visits, or workload trends. All answers are grounded strictly in your real {currentOrg?.name} database records.
            </p>
          </div>

          <div className="space-y-2">
            <button
              onClick={onOpenAiAssistant}
              className="w-full py-2.5 px-4 bg-sky-500 hover:bg-sky-400 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch FieldFlow AI Assistant</span>
            </button>
            <div className="text-[10px] text-slate-400 text-center">
              Zero hallucinated metrics · Strict organization boundary protection
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
