import React, { useState, useEffect } from 'react';
import { AdminStats, User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import {
  ShieldAlert, Users, FileText, ShoppingBag,
  Clapperboard, CheckCircle2, Ban, ShieldCheck,
  AlertTriangle, RefreshCw, Trash2
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'reports'>('overview');
  const [isLoading, setIsLoading] = useState(true);

  if (!currentUser?.isAdmin) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-slate-900 border border-slate-800 rounded-3xl text-center">
        <ShieldAlert className="w-12 h-12 text-red-500 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-white font-display">Acesso Restrito</h2>
        <p className="text-xs text-slate-400 mt-1">
          Apenas administradores autorizados do Angola Connect podem aceder a este painel.
        </p>
      </div>
    );
  }

  const loadAdminData = async () => {
    try {
      setIsLoading(true);
      const [statsRes, usersRes, reportsRes] = await Promise.all([
        api.getAdminStats(currentUser.id),
        api.getAdminUsers(currentUser.id),
        api.getAdminReports(currentUser.id)
      ]);
      setStats(statsRes.stats);
      setUsers(usersRes.users || []);
      setReports(reportsRes.reports || []);
    } catch (err) {
      console.error('Erro ao carregar dados do admin:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, [currentUser.id]);

  const handleUserAction = async (userId: string, action: 'toggle_verified' | 'toggle_suspend') => {
    try {
      await api.adminUserAction(userId, action, currentUser.id);
      loadAdminData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleResolveReport = async (reportId: string, action: 'dismiss' | 'remove_content') => {
    try {
      await api.resolveReport(reportId, action, currentUser.id);
      loadAdminData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              🛡️
            </span>
            <h1 className="text-2xl font-bold text-white font-display">
              Painel de Administração Angola Connect
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Gestão global de segurança, moderação de conteúdos, suspensões e estatísticas da plataforma.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${activeTab === 'overview' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
          >
            Visão Geral
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${activeTab === 'users' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
          >
            Utilizadores ({users.length})
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${activeTab === 'reports' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
          >
            Denúncias ({reports.filter(r => r.status === 'pending').length})
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="p-12 text-center text-slate-500 text-xs">
          <RefreshCw className="w-6 h-6 animate-spin text-amber-400 mx-auto mb-2" />
          <span>A carregar painel de moderação...</span>
        </div>
      ) : (
        <>
          {/* TAB 1: OVERVIEW STATS */}
          {activeTab === 'overview' && stats && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
                    <span>Total Utilizadores</span>
                    <Users className="w-4 h-4 text-blue-400" />
                  </div>
                  <p className="text-2xl font-black text-white font-display tabular-nums">{stats.totalUsers}</p>
                  <p className="text-[10px] text-amber-400 mt-1">{stats.verifiedUsers} com selo verificado</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
                    <span>Publicações no Feed</span>
                    <FileText className="w-4 h-4 text-emerald-400" />
                  </div>
                  <p className="text-2xl font-black text-white font-display tabular-nums">{stats.totalPosts}</p>
                  <p className="text-[10px] text-slate-400 mt-1">Fotos, vídeos e artigos</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
                    <span>Mercado Angola</span>
                    <ShoppingBag className="w-4 h-4 text-amber-400" />
                  </div>
                  <p className="text-2xl font-black text-white font-display tabular-nums">{stats.totalMarketplace}</p>
                  <p className="text-[10px] text-slate-400 mt-1">Anúncios em Kwanzas</p>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
                    <span>Stories Activos</span>
                    <Clapperboard className="w-4 h-4 text-purple-400" />
                  </div>
                  <p className="text-2xl font-black text-white font-display tabular-nums">{stats.activeStories}</p>
                  <p className="text-[10px] text-slate-400 mt-1">Desaparecem em 24h</p>
                </div>
              </div>

              {/* Status Banner */}
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
                    ✓
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white">Servidor e Base de Dados Seguros</h4>
                    <p className="text-xs text-slate-400">
                      Sessões ativas e WebSockets a operar com persistência ACID em disco.
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 font-bold rounded-lg text-xs">
                  Online 🇦🇴
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: USERS MODERATION */}
          {activeTab === 'users' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
              <div className="p-4 border-b border-slate-800">
                <h3 className="font-bold text-sm text-white font-display">Gestão de Utilizadores</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                    <tr>
                      <th className="p-3.5">Utilizador</th>
                      <th className="p-3.5">Contacto</th>
                      <th className="p-3.5">Província</th>
                      <th className="p-3.5">Estado</th>
                      <th className="p-3.5 text-right">Ações de Moderação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {users.map(u => (
                      <tr key={u.id} className="hover:bg-slate-950/40">
                        <td className="p-3.5 flex items-center gap-2.5">
                          <img src={u.avatar} className="w-8 h-8 rounded-full object-cover" />
                          <div>
                            <p className="font-bold text-white flex items-center gap-1">
                              <span>{u.name}</span>
                              {u.verified && <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />}
                            </p>
                            <p className="text-[10px] text-slate-400 font-mono">@{u.username}</p>
                          </div>
                        </td>
                        <td className="p-3.5 font-mono text-[11px] text-slate-400">
                          {u.phone || u.email || 'N/A'}
                        </td>
                        <td className="p-3.5 text-amber-400 font-medium">
                          🇦🇴 {u.province}
                        </td>
                        <td className="p-3.5">
                          {u.isSuspended ? (
                            <span className="px-2 py-0.5 bg-red-950 text-red-400 border border-red-800 rounded text-[10px] font-bold">
                              Suspenso
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                              Activo
                            </span>
                          )}
                        </td>
                        <td className="p-3.5 text-right space-x-2">
                          <button
                            onClick={() => handleUserAction(u.id, 'toggle_verified')}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-lg font-semibold text-[11px]"
                          >
                            {u.verified ? 'Remover Selo' : 'Dar Selo 🇦🇴'}
                          </button>
                          <button
                            onClick={() => handleUserAction(u.id, 'toggle_suspend')}
                            className={`px-2.5 py-1 rounded-lg font-semibold text-[11px] ${u.isSuspended ? 'bg-emerald-900/60 text-emerald-300' : 'bg-red-950/60 text-red-400 hover:bg-red-900'}`}
                          >
                            {u.isSuspended ? 'Reactivar' : 'Suspender'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: REPORTS MODERATION */}
          {activeTab === 'reports' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
              <div className="p-4 border-b border-slate-800">
                <h3 className="font-bold text-sm text-white font-display">Fila de Denúncias</h3>
              </div>
              <div className="p-4 space-y-3">
                {reports.length === 0 ? (
                  <p className="text-center text-xs text-slate-500 py-8">Nenhuma denúncia registada.</p>
                ) : (
                  reports.map(rep => (
                    <div
                      key={rep.id}
                      className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between gap-4"
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="px-2 py-0.5 bg-red-950 text-red-400 border border-red-800/80 rounded text-[10px] font-bold uppercase">
                            {rep.targetType}
                          </span>
                          <span className="text-xs text-slate-400">
                            Denunciado por <strong>{rep.reporter?.name || 'Utilizador'}</strong>
                          </span>
                        </div>
                        <p className="text-xs text-white">Motivo: <span className="font-semibold">{rep.reason}</span></p>
                        <p className="text-[10px] text-slate-500 font-mono mt-1">ID do Conteúdo: {rep.targetId}</p>
                      </div>

                      <div className="flex items-center gap-2">
                        {rep.status === 'pending' ? (
                          <>
                            <button
                              onClick={() => handleResolveReport(rep.id, 'dismiss')}
                              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg"
                            >
                              Ignorar
                            </button>
                            <button
                              onClick={() => handleResolveReport(rep.id, 'remove_content')}
                              className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg flex items-center gap-1 shadow-sm"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Remover Conteúdo</span>
                            </button>
                          </>
                        ) : (
                          <span className="text-xs font-semibold text-slate-500">
                            Resolvido ({rep.status})
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </>
      )}

    </div>
  );
};
