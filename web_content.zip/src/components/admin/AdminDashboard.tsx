import React, { useState, useEffect } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import { adminService, AdminUserRecord, AdminOverview } from '../../services/adminService';
import {
  Users,
  Wrench,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  FileCheck,
  Check,
  X,
  Settings,
  Plus,
  Layers,
  Search,
  Sliders,
  ShieldAlert,
  Lock,
  LogOut,
  RefreshCw,
  UserX,
  UserCheck,
} from 'lucide-react';
import { formatCurrencyPKR } from '../../utils/geo';
import { ServiceCategory } from '../../types';

export const AdminDashboard: React.FC = () => {
  const {
    providers,
    bookings,
    reports,
    categories,
    settings,
    approveProviderVerification,
    rejectProviderVerification,
    updateSettings,
    addCategory,
    currentUser,
    logoutUser,
  } = useMohalla();

  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'verifications' | 'categories' | 'settings' | 'reports'>('overview');
  const [rejectModalProviderId, setRejectModalProviderId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('CNIC image unclear or illegible');
  
  // Real Database Users
  const [serverUsers, setServerUsers] = useState<AdminUserRecord[]>([]);
  const [serverOverview, setServerOverview] = useState<AdminOverview | null>(null);
  const [isLoadingServerData, setIsLoadingServerData] = useState(false);
  const [searchUserQuery, setSearchUserQuery] = useState('');

  // New Category Form State
  const [showAddCatModal, setShowAddCatModal] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatUrdu, setNewCatUrdu] = useState('');
  const [newCatCharge, setNewCatCharge] = useState(600);

  // Settings State
  const [commissionRate, setCommissionRate] = useState(settings.commissionPercentage);
  const [emergencySurcharge, setEmergencySurcharge] = useState(settings.emergencySurcharge);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Load real server data
  const loadAdminServerData = async () => {
    setIsLoadingServerData(true);
    try {
      const [overviewData, usersData] = await Promise.all([
        adminService.getOverview().catch(() => null),
        adminService.getUsers().catch(() => []),
      ]);
      if (overviewData) setServerOverview(overviewData);
      if (usersData) setServerUsers(usersData);
    } catch (err) {
      console.error('Failed to fetch server admin data:', err);
    } finally {
      setIsLoadingServerData(false);
    }
  };

  useEffect(() => {
    loadAdminServerData();
  }, [activeTab]);

  const handleToggleUserActive = async (userId: string, currentActive: number) => {
    try {
      await adminService.toggleUserStatus(userId, currentActive === 0);
      setServerUsers((prev) =>
        prev.map((u) => (u.id === userId ? { ...u, is_active: currentActive === 0 ? 1 : 0 } : u))
      );
    } catch (err: any) {
      alert(err.message || 'Failed to update user status.');
    }
  };

  // Stats calculation
  const totalProviders = providers.length;
  const verifiedProviders = providers.filter((p) => p.verificationStatus === 'verified').length;
  const pendingVerifications = providers.filter((p) => p.verificationStatus === 'pending');
  const totalCompletedBookings = bookings.filter((b) => b.status === 'COMPLETED').length;
  const totalPlatformRevenue = bookings
    .filter((b) => b.status === 'COMPLETED')
    .reduce((sum, b) => sum + (b.platformCommissionAmount || Math.round((b.finalBill || b.visitFee) * 0.1)), 0);

  const handleSaveCommission = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await adminService.updateSettings(
        Number(commissionRate),
        Number(emergencySurcharge),
        settings.minVisitCharge
      );
      updateSettings({
        commissionPercentage: Number(commissionRate),
        emergencySurcharge: Number(emergencySurcharge),
      });
      setSaveSuccessMsg('Platform commission and financial rules updated in server database!');
      setTimeout(() => setSaveSuccessMsg(null), 3500);
    } catch (err: any) {
      alert(err.message || 'Failed to update platform settings on server.');
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const id = newCatName.toLowerCase().replace(/\s+/g, '_');
    const newCat: ServiceCategory = {
      id,
      name: newCatName.trim(),
      nameUrdu: newCatUrdu.trim() || newCatName.trim(),
      icon: 'Wrench',
      description: `Professional ${newCatName.trim()} services across Karachi`,
      popular: false,
      emergencyEligible: false,
      typicalVisitCharge: Number(newCatCharge) || 500,
    };

    try {
      await adminService.addCategory(newCat);
      addCategory(newCat);
      setShowAddCatModal(false);
      setNewCatName('');
      setNewCatUrdu('');
    } catch (err: any) {
      alert(err.message || 'Failed to save category on server.');
    }
  };

  const handleConfirmReject = async () => {
    if (!rejectModalProviderId) return;
    try {
      await adminService.verifyProvider(rejectModalProviderId, 'rejected', rejectReason);
      rejectProviderVerification(rejectModalProviderId, rejectReason);
      setRejectModalProviderId(null);
    } catch (err: any) {
      alert(err.message || 'Failed to update provider status.');
    }
  };

  const handleConfirmApprove = async (providerId: string) => {
    try {
      await adminService.verifyProvider(providerId, 'verified');
      approveProviderVerification(providerId);
    } catch (err: any) {
      alert(err.message || 'Failed to approve provider on server.');
    }
  };

  // Filter server users by search
  const filteredUsers = serverUsers.filter((u) => {
    if (!searchUserQuery.trim()) return true;
    const q = searchUserQuery.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.phone.includes(q) ||
      u.role.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Top Banner with Server Security Status */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-purple-950 rounded-3xl p-6 text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-300">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold">Mohalla Central Operations HQ</h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500 text-slate-950 uppercase tracking-wider">
              Server Authenticated
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Logged in as <span className="font-bold text-white">{currentUser.email || currentUser.name}</span> • SQLite Database Active
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadAdminServerData}
            disabled={isLoadingServerData}
            className="p-2 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer transition-colors"
            title="Refresh database records"
          >
            <RefreshCw className={`w-4 h-4 ${isLoadingServerData ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => logoutUser()}
            className="px-3.5 py-2 rounded-xl bg-rose-600/80 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>End Admin Session</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex border-b border-slate-200 overflow-x-auto gap-2 text-xs font-bold text-slate-500 pb-1">
        <button
          onClick={() => setActiveTab('overview')}
          className={`py-2 px-4 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'overview'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'hover:bg-slate-100 text-slate-600'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          Analytics & Overview
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`py-2 px-4 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'users'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'hover:bg-slate-100 text-slate-600'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Manage Users ({serverUsers.length || '...'})
        </button>

        <button
          onClick={() => setActiveTab('verifications')}
          className={`py-2 px-4 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'verifications'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'hover:bg-slate-100 text-slate-600'
          }`}
        >
          <FileCheck className="w-3.5 h-3.5" />
          Verifications
          {pendingVerifications.length > 0 && (
            <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-bold">
              {pendingVerifications.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('categories')}
          className={`py-2 px-4 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'categories'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'hover:bg-slate-100 text-slate-600'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Categories ({categories.length})
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`py-2 px-4 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'reports'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'hover:bg-slate-100 text-slate-600'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          Disputes & Reports ({reports.length})
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`py-2 px-4 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'settings'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'hover:bg-slate-100 text-slate-600'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          Commission & Rules
        </button>
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Key KPI Metric Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-semibold text-slate-500 block">Total Providers</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">
                {serverOverview?.totalProviders ?? totalProviders}
              </span>
              <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">
                {serverOverview?.verifiedProviders ?? verifiedProviders} verified with CNIC
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-semibold text-slate-500 block">Registered Customers</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">
                {serverOverview?.totalUsers ?? serverUsers.filter((u) => u.role === 'customer').length}
              </span>
              <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">
                Across Karachi East, South & Central
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-semibold text-slate-500 block">Platform Net Commission</span>
              <span className="text-2xl font-black text-emerald-800 mt-1 block">
                {formatCurrencyPKR(serverOverview?.totalPlatformCommissionRevenue ?? totalPlatformRevenue)}
              </span>
              <span className="text-[11px] text-emerald-600 font-medium mt-0.5 block">
                {settings.commissionPercentage}% fee on completed jobs
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-semibold text-slate-500 block">Database Status</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">SQLite Active</span>
              <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">
                ✓ Persistent Disk Storage
              </span>
            </div>
          </div>

          {/* Recent Platform Bookings Feed */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900">Live Booking Activity</h3>
              <span className="text-xs text-slate-400">{bookings.length} total platform bookings</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 uppercase font-bold text-[10px]">
                    <th className="py-2.5">ID</th>
                    <th>Customer</th>
                    <th>Provider</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Total Bill</th>
                    <th>Commission</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {bookings.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50/60">
                      <td className="py-2.5 font-mono font-medium text-slate-500">#{b.id.slice(-5)}</td>
                      <td className="font-semibold text-slate-900">{b.customerName}</td>
                      <td>{b.providerName}</td>
                      <td>
                        <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                          {b.categoryName}
                        </span>
                      </td>
                      <td>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            b.status === 'COMPLETED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : b.status === 'CANCELLED'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="font-bold">{formatCurrencyPKR(b.finalBill || b.visitFee)}</td>
                      <td className="font-semibold text-emerald-700">
                        {formatCurrencyPKR(b.platformCommissionAmount || Math.round((b.finalBill || b.visitFee) * 0.1))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MANAGE REGISTERED USERS TAB */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">Registered Customers & Technicians</h2>
              <p className="text-xs text-slate-500">Directly fetched from the persistent SQLite database</p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchUserQuery}
                onChange={(e) => setSearchUserQuery(e.target.value)}
                placeholder="Search by name, phone, or email..."
                className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 outline-hidden"
              />
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-400 uppercase font-bold text-[10px]">
                    <th className="p-3">User</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Phone</th>
                    <th className="p-3">Location</th>
                    <th className="p-3">Account Status</th>
                    <th className="p-3 text-right">Moderation Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        No registered users found matching query.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/60">
                        <td className="p-3">
                          <div className="font-bold text-slate-900">{u.name}</div>
                          <div className="text-[11px] text-slate-400">{u.email}</div>
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              u.role === 'admin'
                                ? 'bg-purple-100 text-purple-800'
                                : u.role === 'provider'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {u.role}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-[11px]">{u.phone}</td>
                        <td className="p-3">
                          {u.area}, {u.city}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              u.is_active === 1
                                ? 'bg-emerald-50 text-emerald-800'
                                : 'bg-rose-50 text-rose-800'
                            }`}
                          >
                            {u.is_active === 1 ? 'Active' : 'Suspended'}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          {u.role !== 'admin' && (
                            <button
                              onClick={() => handleToggleUserActive(u.id, u.is_active)}
                              className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                                u.is_active === 1
                                  ? 'text-rose-600 hover:bg-rose-50 border border-rose-200'
                                  : 'text-emerald-700 hover:bg-emerald-50 border border-emerald-300 font-bold'
                              }`}
                            >
                              {u.is_active === 1 ? 'Suspend Account' : 'Reactivate'}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VERIFICATIONS MODERATION TAB */}
      {activeTab === 'verifications' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Provider Verification Queue</h2>
              <p className="text-xs text-slate-500">
                Inspect Pakistani CNIC documents and trade licenses before awarding the green badge
              </p>
            </div>
            <span className="text-xs font-bold bg-amber-100 text-amber-900 px-2.5 py-1 rounded-full">
              {pendingVerifications.length} Pending
            </span>
          </div>

          {pendingVerifications.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <p className="font-bold text-slate-700">All provider verifications processed!</p>
              <p className="mt-1">No pending documents waiting for admin review.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingVerifications.map((prov) => (
                <div
                  key={prov.id}
                  className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-4"
                >
                  <div className="flex items-start justify-between gap-2 pb-2 border-b border-slate-100">
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{prov.businessName}</h3>
                      <p className="text-xs text-slate-500">{prov.city} • {prov.location.areaName}</p>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                      Pending Review
                    </span>
                  </div>

                  {/* CNIC preview simulation */}
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Masked CNIC:</span>
                      <span className="font-mono font-bold text-slate-900">{prov.cnicMasked}</span>
                    </div>

                    <div>
                      <span className="text-slate-500 block mb-1 font-semibold">
                        Uploaded Document Proof:
                      </span>
                      {prov.cnicDocumentUrl ? (
                        <div className="h-36 rounded-xl overflow-hidden border border-slate-200 relative group">
                          <img
                            src={prov.cnicDocumentUrl}
                            alt="CNIC Document"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ) : (
                        <div className="p-4 bg-slate-100 rounded-xl text-center text-slate-400 text-xs">
                          No document image uploaded
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Approval Actions */}
                  <div className="pt-2 flex gap-2">
                    <button
                      onClick={() => setRejectModalProviderId(prov.id)}
                      className="flex-1 py-2 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-bold cursor-pointer"
                    >
                      Reject Application
                    </button>
                    <button
                      onClick={() => handleConfirmApprove(prov.id)}
                      className="flex-1 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold cursor-pointer shadow-xs"
                    >
                      Approve & Verify Badge
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* CATEGORIES MANAGEMENT TAB */}
      {activeTab === 'categories' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Service Categories</h2>
              <p className="text-xs text-slate-500">Configure marketplace categories, icons, and baseline visit rates</p>
            </div>
            <button
              onClick={() => setShowAddCatModal(true)}
              className="px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Category
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {categories.map((c) => (
              <div
                key={c.id}
                className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-900">{c.name}</span>
                  <span className="font-urdu text-xs text-slate-500">{c.nameUrdu}</span>
                </div>
                <p className="text-[11px] text-slate-500 line-clamp-1">{c.description}</p>
                <div className="pt-1 flex items-center justify-between text-[11px] font-semibold text-slate-700">
                  <span>Visit: Rs. {c.typicalVisitCharge}</span>
                  {c.emergencyEligible && (
                    <span className="text-[9px] bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded font-bold">
                      SOS Eligible
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* DISPUTES & USER REPORTS TAB */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <h2 className="text-base font-bold text-slate-900">Safety & Trust Moderation Reports</h2>

          {reports.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
              No reported disputes or incidents.
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((rep) => (
                <div
                  key={rep.id}
                  className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-rose-700 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      {rep.category} Violation
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                      {rep.status}
                    </span>
                  </div>
                  <p className="text-slate-800">
                    <span className="font-bold text-slate-900">{rep.reporterName}</span> reported{' '}
                    <span className="font-bold text-slate-900">{rep.targetName}</span>:
                  </p>
                  <p className="p-2.5 rounded-xl bg-slate-50 text-slate-700 italic border border-slate-100">
                    "{rep.description}"
                  </p>
                  {rep.adminNotes && (
                    <p className="text-[11px] text-emerald-800 font-medium">
                      Admin note: {rep.adminNotes}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SETTINGS TAB */}
      {activeTab === 'settings' && (
        <div className="max-w-xl bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div>
            <h2 className="text-base font-bold text-slate-900">Platform Financial Rules</h2>
            <p className="text-xs text-slate-500">Persisted in SQLite database</p>
          </div>

          {saveSuccessMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
              ✓ {saveSuccessMsg}
            </div>
          )}

          <form onSubmit={handleSaveCommission} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Platform Commission Rate (%)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="0"
                  max="30"
                  value={commissionRate}
                  onChange={(e) => setCommissionRate(Number(e.target.value))}
                  className="w-32 p-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-sm"
                />
                <span className="text-slate-500 font-medium">% per completed booking</span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Emergency Surcharge (PKR)
              </label>
              <input
                type="number"
                min="0"
                value={emergencySurcharge}
                onChange={(e) => setEmergencySurcharge(Number(e.target.value))}
                className="w-32 p-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 text-sm"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold cursor-pointer shadow-xs"
              >
                Save Settings to Database
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Category Modal */}
      {showAddCatModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="font-bold text-slate-900 text-base">Add New Category</h3>
            <form onSubmit={handleCreateCategory} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Category Name (English)</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Solar Panel Cleaning"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Category Name (Urdu)</label>
                <input
                  type="text"
                  placeholder="مثلاً سولر پینل کی صفائی"
                  value={newCatUrdu}
                  onChange={(e) => setNewCatUrdu(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 font-urdu"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Typical Visit Charge (PKR)</label>
                <input
                  type="number"
                  required
                  value={newCatCharge}
                  onChange={(e) => setNewCatCharge(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-800 font-bold"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddCatModal(false)}
                  className="flex-1 py-2 rounded-xl border border-slate-300 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold"
                >
                  Save to Database
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reject Verification Modal */}
      {rejectModalProviderId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="font-bold text-slate-900 text-base">Reject Verification</h3>
            <p className="text-xs text-slate-500 mt-1">Specify reason sent to provider</p>

            <div className="mt-4">
              <label className="text-xs font-bold text-slate-700 block mb-1">Reason:</label>
              <select
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-300 text-xs text-slate-800"
              >
                <option value="CNIC image unclear or illegible">CNIC image unclear or illegible</option>
                <option value="Name on CNIC does not match profile">Name on CNIC does not match profile</option>
                <option value="Trade license expired">Trade license expired</option>
                <option value="Requires police verification clearance">Requires police verification clearance</option>
              </select>
            </div>

            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setRejectModalProviderId(null)}
                className="flex-1 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReject}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
