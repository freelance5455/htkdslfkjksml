import React, { useState, useEffect, useRef } from 'react';
import { useData, syncHeroBackgroundToDomAndCache } from '../../context/DataContext.tsx';
import {
  Founder,
  Project,
  FinancialRecord,
  FaqItem,
  ServiceItem,
  GalleryItem,
  SiteSettings,
  AiAssistantSettings
} from '../../types/index.ts';
import { ImageUploadField } from './ImageUploadField.tsx';
import {
  ShieldCheck,
  Users,
  Briefcase,
  Settings,
  Lock,
  Plus,
  Trash2,
  Edit2,
  Check,
  AlertCircle,
  RefreshCw,
  LogOut,
  Eye,
  Download,
  IndianRupee,
  Save,
  HelpCircle,
  Layers,
  Search,
  MoveUp,
  MoveDown,
  FileText,
  Upload,
  Sparkles,
  X,
  ExternalLink,
  MessageSquare,
  LayoutDashboard,
  CheckCircle2,
  Sliders,
  Image as ImageIcon,
  Ticket,
  Database,
  Star,
  Clock
} from 'lucide-react';
import { AdminTicketManagement } from './AdminTicketManagement.tsx';
import { AdminServiceProductsManagement } from './AdminServiceProductsManagement.tsx';
import { AdminVouchManagement } from './AdminVouchManagement.tsx';
import { defaultStore } from '../../data/defaults.ts';

interface AdminDashboardProps {
  onBackToSite: () => void;
  initialTab?: string;
}

type AdminCategory =
  | 'dashboard'
  | 'website'
  | 'appearance'
  | 'media'
  | 'projects'
  | 'vouches'
  | 'tickets'
  | 'database'
  | 'settings';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToSite, initialTab }) => {
  const {
    data,
    updateAppData,
    currentUser,
    loginAdmin,
    logoutAdmin,
    adminTickets,
    addGalleryItem,
    deleteGalleryItem,
    uploadAdminFile,
    resetToDefaults,
    adminToken,
    syncing,
    lastUpdated,
    refreshData,
    saveTicketDiscordUrl,
    databaseStatus,
    vouches,
    vouchStats
  } = useData();

  // Map any incoming initialTab to one of the organized categories
  const resolveInitialCategory = (tab?: string): AdminCategory => {
    if (!tab) return 'dashboard';
    if (tab === 'appearance' || tab === 'homepage-appearance' || tab === 'background') {
      return 'appearance';
    }
    if (tab === 'website' || tab === 'homepage' || tab === 'about' || tab === 'founders' || tab === 'services' || tab === 'faqs') {
      return 'website';
    }
    if (tab === 'media' || tab === 'gallery') return 'media';
    if (tab === 'projects' || tab === 'serviceProducts') return 'projects';
    if (tab === 'vouches' || tab === 'vouch-management' || tab === 'ai-assistant') return 'vouches';
    if (tab === 'tickets' || tab === 'ticketSettings') return 'tickets';
    if (tab === 'database') return 'database';
    if (tab === 'settings' || tab === 'security' || tab === 'financial' || tab === 'accounts') return 'settings';
    return 'dashboard';
  };

  const [activeCategory, setActiveCategory] = useState<AdminCategory>(() => resolveInitialCategory(initialTab));
  const [websiteSubTab, setWebsiteSubTab] = useState<'homepage' | 'about' | 'founders' | 'services' | 'faqs'>(() =>
    initialTab === 'founders' ? 'founders' : 'homepage'
  );
  const [projectsSubTab, setProjectsSubTab] = useState<'portfolio' | 'catalog'>('portfolio');
  const [settingsSubTab, setSettingsSubTab] = useState<'general' | 'financial' | 'security'>('general');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Login Form State (Google Login completely removed per user instructions)
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3200);
  };

  // Confirmation Modal
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    open: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  // Settings & Homepage Form
  const [settingsForm, _setSettingsFormRaw] = useState<SiteSettings>(data.settings);
  const [savingSettings, setSavingSettings] = useState(false);
  const settingsFormDirtyRef = useRef(false);

  const setSettingsForm: React.Dispatch<React.SetStateAction<SiteSettings>> = (valueOrUpdater) => {
    settingsFormDirtyRef.current = true;
    _setSettingsFormRaw(valueOrUpdater);
  };

  useEffect(() => {
    if (data.settings && !settingsFormDirtyRef.current) {
      _setSettingsFormRaw(data.settings);
    }
  }, [data.settings]);

  const handleSaveSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (savingSettings) return;
    setSavingSettings(true);
    try {
      const res = await updateAppData({ settings: settingsForm });
      if (res.success) {
        settingsFormDirtyRef.current = false;
        if (res.data?.settings) _setSettingsFormRaw(res.data.settings);
        showToast('Settings saved and synced with database.');
      } else {
        showToast(res.error || 'Failed to save settings', 'error');
      }
    } finally {
      setSavingSettings(false);
    }
  };

  // =========================================================================
  // HOMEPAGE APPEARANCE STATE & HANDLERS (Live Preview, Blur, Overlay, Position)
  // =========================================================================
  const DEFAULT_HERO_BG_IMAGE = '/b90c9408e77c5a808a0f1adfab828f1b.jpg';

  const normalizeBgPositionKey = (pos?: string): 'center' | 'top' | 'bottom' => {
    const p = (pos || '').toLowerCase().trim();
    if (p.startsWith('top')) return 'top';
    if (p.startsWith('bottom')) return 'bottom';
    return 'center';
  };

  const buildAppearanceState = (srcHeroBg?: SiteSettings['heroBackground']) => ({
    imageUrl:
      srcHeroBg?.imageUrl && srcHeroBg.imageUrl !== 'none' && String(srcHeroBg.imageUrl).trim() !== ''
        ? String(srcHeroBg.imageUrl).trim()
        : DEFAULT_HERO_BG_IMAGE,
    position: normalizeBgPositionKey(srcHeroBg?.position || 'top'),
    blur: typeof srcHeroBg?.blur === 'number' ? Math.min(Math.max(Math.round(srcHeroBg.blur), 0), 40) : 0,
    overlayOpacity:
      typeof srcHeroBg?.overlayOpacity === 'number'
        ? Math.min(Math.max(Math.round(srcHeroBg.overlayOpacity), 0), 100)
        : 80,
    size: srcHeroBg?.size || 'cover',
    repeat: srcHeroBg?.repeat || 'no-repeat',
    solidColor: srcHeroBg?.solidColor || '#06101e'
  });

  const [appearanceDraft, setAppearanceDraftState] = useState(() =>
    buildAppearanceState(data.settings?.heroBackground)
  );
  const [appearanceDirty, setAppearanceDirty] = useState(false);
  const appearanceDirtyRef = useRef(false);
  const [savingAppearance, setSavingAppearance] = useState(false);
  const [uploadingAppearanceBg, setUploadingAppearanceBg] = useState(false);
  const appearanceFileInputRef = useRef<HTMLInputElement>(null);

  const updateAppearanceDraft = (
    updater:
      | Partial<ReturnType<typeof buildAppearanceState>>
      | ((prev: ReturnType<typeof buildAppearanceState>) => ReturnType<typeof buildAppearanceState>)
  ) => {
    appearanceDirtyRef.current = true;
    setAppearanceDirty(true);
    setAppearanceDraftState((prev) => (typeof updater === 'function' ? updater(prev) : { ...prev, ...updater }));
  };

  useEffect(() => {
    if (data.settings?.heroBackground && !appearanceDirtyRef.current) {
      setAppearanceDraftState(buildAppearanceState(data.settings.heroBackground));
    }
  }, [data.settings?.heroBackground]);

  const handleAppearanceFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (PNG, JPG, WEBP, SVG).', 'error');
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      showToast('Image file size must be under 15MB.', 'error');
      return;
    }

    setUploadingAppearanceBg(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        const result = await uploadAdminFile(file.name, base64Data);
        setUploadingAppearanceBg(false);
        if (result.success && result.fileUrl) {
          updateAppearanceDraft({ imageUrl: result.fileUrl });
          showToast('Background image loaded into Live Preview. Click "Save Changes" to publish.');
        } else {
          showToast(result.error || 'Failed to process background image.', 'error');
        }
      };
      reader.onerror = () => {
        setUploadingAppearanceBg(false);
        showToast('Failed to read image file.', 'error');
      };
      reader.readAsDataURL(file);
    } catch {
      setUploadingAppearanceBg(false);
      showToast('Error uploading image.', 'error');
    } finally {
      if (appearanceFileInputRef.current) {
        appearanceFileInputRef.current.value = '';
      }
    }
  };

  const handleRemoveCustomAppearanceBg = () => {
    updateAppearanceDraft({ imageUrl: DEFAULT_HERO_BG_IMAGE });
    showToast('Default background image restored in Live Preview. Click "Save Changes" to apply.');
  };

  const handleSaveAppearance = async () => {
    if (savingAppearance) return;
    setSavingAppearance(true);
    try {
      const nextHeroBg = {
        ...(data.settings?.heroBackground || {}),
        imageUrl: appearanceDraft.imageUrl || DEFAULT_HERO_BG_IMAGE,
        position: appearanceDraft.position,
        blur: Math.min(Math.max(Number(appearanceDraft.blur) || 0, 0), 40),
        overlayOpacity: Math.min(Math.max(Number(appearanceDraft.overlayOpacity), 0), 100),
        size: appearanceDraft.size || 'cover',
        repeat: appearanceDraft.repeat || 'no-repeat',
        solidColor: appearanceDraft.solidColor || '#06101e'
      };

      const nextSettings: SiteSettings = {
        ...data.settings,
        ...settingsForm,
        heroBackground: nextHeroBg
      };

      syncHeroBackgroundToDomAndCache(nextHeroBg);
      const res = await updateAppData({ settings: nextSettings });
      if (res.success) {
        appearanceDirtyRef.current = false;
        setAppearanceDirty(false);
        settingsFormDirtyRef.current = false;
        _setSettingsFormRaw(nextSettings);
        showToast('Homepage Appearance saved and synced to Firebase.');
      } else {
        showToast(res.error || 'Failed to save Homepage Appearance.', 'error');
      }
    } finally {
      setSavingAppearance(false);
    }
  };

  const handleResetAppearanceToDefault = async () => {
    if (savingAppearance) return;
    setSavingAppearance(true);
    try {
      const defaultHeroBg = {
        imageUrl: DEFAULT_HERO_BG_IMAGE,
        position: 'top' as const,
        blur: 0,
        overlayOpacity: 80,
        size: 'cover',
        repeat: 'no-repeat',
        solidColor: '#06101e'
      };

      const nextSettings: SiteSettings = {
        ...data.settings,
        ...settingsForm,
        heroBackground: defaultHeroBg
      };

      setAppearanceDraftState(defaultHeroBg);
      syncHeroBackgroundToDomAndCache(defaultHeroBg);
      const res = await updateAppData({ settings: nextSettings });
      if (res.success) {
        appearanceDirtyRef.current = false;
        setAppearanceDirty(false);
        settingsFormDirtyRef.current = false;
        _setSettingsFormRaw(nextSettings);
        showToast('Homepage Appearance reset to default and saved.');
      } else {
        showToast(res.error || 'Failed to reset Homepage Appearance.', 'error');
      }
    } finally {
      setSavingAppearance(false);
    }
  };

  // AI Assistant Settings State
  const [aiForm, _setAiFormRaw] = useState<AiAssistantSettings>(
    data.aiAssistant ||
      defaultStore.aiAssistant || {
        enabled: true,
        sectionTitle: 'Cubix AI Assistant',
        sectionSubtitle: '24/7 Intelligent Studio Concierge & Direct Founder Support',
        sectionDescription:
          'Get instant answers about Cubix Studio services, project timelines, and technical capabilities—or connect directly with our Founders using your unique Cubes client identity.',
        buttonText: 'Open AI Assistant',
        welcomeMessage:
          'Hello! Welcome to Cubix Studio AI Assistant. How can I help you with your project or questions today?',
        systemPrompt:
          'You are the official AI Assistant for Cubix Studio, a premier digital development and creative studio.'
      }
  );
  const [savingAiSettings, setSavingAiSettings] = useState(false);
  const aiFormDirtyRef = useRef(false);
  const [selectedAiSessionId, setSelectedAiSessionId] = useState<string | null>(null);

  const setAiForm: React.Dispatch<React.SetStateAction<AiAssistantSettings>> = (val) => {
    aiFormDirtyRef.current = true;
    _setAiFormRaw(val);
  };

  useEffect(() => {
    if (data.aiAssistant && !aiFormDirtyRef.current) {
      _setAiFormRaw(data.aiAssistant);
    }
  }, [data.aiAssistant]);

  const handleSaveAiSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingAiSettings(true);
    try {
      const res = await updateAppData({ aiAssistant: aiForm });
      if (res.success) {
        aiFormDirtyRef.current = false;
        showToast('AI Assistant configuration saved.');
      } else {
        showToast(res.error || 'Failed to save AI settings', 'error');
      }
    } finally {
      setSavingAiSettings(false);
    }
  };

  // Ticket Discord URL State
  const [ticketUrlInput, setTicketUrlInput] = useState(
    data.settings?.ticketDiscordUrl || data.settings?.discordUrl || ''
  );
  const [savingTicketUrl, setSavingTicketUrl] = useState(false);

  useEffect(() => {
    if (data.settings?.ticketDiscordUrl || data.settings?.discordUrl) {
      setTicketUrlInput(data.settings.ticketDiscordUrl || data.settings.discordUrl || '');
    }
  }, [data.settings?.ticketDiscordUrl, data.settings?.discordUrl]);

  const handleSaveTicketUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = ticketUrlInput.trim();
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      showToast('URL must start with https:// or http://', 'error');
      return;
    }
    setSavingTicketUrl(true);
    const res = await saveTicketDiscordUrl(trimmed);
    setSavingTicketUrl(false);
    if (res.success) showToast('Ticket Discord URL saved.');
    else showToast(res.error || 'Failed to save URL', 'error');
  };

  // Services CRUD
  const currentServices: ServiceItem[] = data.services || [];
  const [serviceModalOpen, setServiceModalOpen] = useState(false);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [serviceForm, setServiceForm] = useState<ServiceItem>({
    id: '',
    name: '',
    category: 'web',
    iconName: 'Code2',
    description: '',
    points: [''],
    displayOrder: 1,
    published: true
  });

  const handleOpenAddService = () => {
    setEditingServiceId(null);
    setServiceForm({
      id: 'srv_' + Date.now(),
      name: '',
      category: 'web',
      iconName: 'Code2',
      description: '',
      points: ['', ''],
      displayOrder: currentServices.length + 1,
      published: true
    });
    setServiceModalOpen(true);
  };

  const handleEditService = (service: ServiceItem) => {
    setEditingServiceId(service.id);
    setServiceForm({
      ...service,
      points: service.points && service.points.length > 0 ? [...service.points] : ['']
    });
    setServiceModalOpen(true);
  };

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceForm.name.trim()) {
      showToast('Service name is required', 'error');
      return;
    }
    const cleanedPoints = serviceForm.points.filter((p) => p.trim() !== '');
    const itemToSave: ServiceItem = {
      ...serviceForm,
      id: serviceForm.id || 'srv_' + Date.now(),
      points: cleanedPoints.length > 0 ? cleanedPoints : ['Comprehensive solution delivery']
    };
    const updated = editingServiceId
      ? currentServices.map((s) => (s.id === editingServiceId ? itemToSave : s))
      : [...currentServices, itemToSave];
    const res = await updateAppData({ services: updated });
    if (res.success) {
      showToast('Service saved.');
      setServiceModalOpen(false);
    } else {
      showToast(res.error || 'Failed to save service', 'error');
    }
  };

  const handleDeleteService = (id: string) => {
    setConfirmDialog({
      open: true,
      title: 'Delete Service',
      message: 'Are you sure you want to remove this service from the website?',
      onConfirm: async () => {
        const updated = currentServices.filter((s) => s.id !== id);
        const res = await updateAppData({ services: updated });
        if (res.success) showToast('Service removed.');
        setConfirmDialog((prev) => ({ ...prev, open: false }));
      }
    });
  };

  const handleMoveService = async (idx: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= currentServices.length) return;
    const list = [...currentServices];
    const temp = list[idx];
    list[idx] = list[targetIdx];
    list[targetIdx] = temp;
    const reordered = list.map((item, i) => ({ ...item, displayOrder: i + 1 }));
    await updateAppData({ services: reordered });
  };

  // Projects CRUD
  const [projectModalOpen, setProjectModalOpen] = useState(false);
  const [editingProjectId, setEditingProjectId] = useState<string | number | null>(null);
  const [projectForm, setProjectForm] = useState<Project>({
    id: '',
    name: '',
    category: 'web',
    description: '',
    thumbnail: '',
    tags: [],
    fileName: '',
    fileUrl: '',
    externalUrl: '',
    date: new Date().toISOString().split('T')[0],
    published: true,
    order: 1
  });
  const [tagsInput, setTagsInput] = useState('');
  const [projectFilterCategory, setProjectFilterCategory] = useState<string>('all');
  const [projectSearchTerm, setProjectSearchTerm] = useState('');
  const [uploadingProjectFile, setUploadingProjectFile] = useState(false);

  const handleOpenAddProject = () => {
    setEditingProjectId(null);
    setProjectForm({
      id: Date.now(),
      name: '',
      category: 'web',
      description: '',
      thumbnail: '',
      tags: [],
      fileName: '',
      fileUrl: '',
      externalUrl: '',
      date: new Date().toISOString().split('T')[0],
      published: true,
      order: (data.projects || []).length + 1
    });
    setTagsInput('');
    setProjectModalOpen(true);
  };

  const handleEditProject = (proj: Project) => {
    setEditingProjectId(proj.id);
    setProjectForm({ ...proj });
    setTagsInput((proj.tags || []).join(', '));
    setProjectModalOpen(true);
  };

  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectForm.name.trim()) {
      showToast('Project title is required', 'error');
      return;
    }
    const tagsArray = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const itemToSave: Project = {
      ...projectForm,
      id: projectForm.id || Date.now(),
      tags: tagsArray
    };
    let updated = [...(data.projects || [])];
    if (editingProjectId !== null) {
      updated = updated.map((p) => (p.id === editingProjectId ? itemToSave : p));
    } else {
      updated = [itemToSave, ...updated];
    }
    const res = await updateAppData({ projects: updated });
    if (res.success) {
      showToast('Project saved.');
      setProjectModalOpen(false);
    } else {
      showToast(res.error || 'Failed to save project', 'error');
    }
  };

  const handleDeleteProject = (id: string | number) => {
    setConfirmDialog({
      open: true,
      title: 'Delete Project',
      message: 'Are you sure you want to permanently delete this project?',
      onConfirm: async () => {
        const updated = (data.projects || []).filter((p) => p.id !== id);
        const res = await updateAppData({ projects: updated });
        if (res.success) showToast('Project deleted.');
        setConfirmDialog((prev) => ({ ...prev, open: false }));
      }
    });
  };

  const handleToggleProjectPublish = async (id: string | number, currentVal: boolean) => {
    const updated = (data.projects || []).map((p) => (p.id === id ? { ...p, published: !currentVal } : p));
    const res = await updateAppData({ projects: updated });
    if (res.success) showToast(!currentVal ? 'Project published.' : 'Project hidden.');
  };

  const handleProjectFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingProjectFile(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      const uploaded = await uploadAdminFile(file.name, base64);
      setUploadingProjectFile(false);
      if (uploaded.success && uploaded.fileUrl) {
        setProjectForm((prev) => ({
          ...prev,
          fileName: file.name,
          fileUrl: uploaded.fileUrl!
        }));
        showToast(`File "${file.name}" uploaded.`);
      } else {
        showToast(uploaded.error || 'Upload failed', 'error');
      }
    };
    reader.readAsDataURL(file);
  };

  // Founders CRUD
  const [founderModalOpen, setFounderModalOpen] = useState(false);
  const [editingFounderId, setEditingFounderId] = useState<string | null>(null);
  const [founderForm, setFounderForm] = useState<Founder>({
    name: '',
    role: '',
    bio: '',
    skills: '',
    avatar: '/cubix-logo.jpg',
    displayOrder: 1,
    published: true,
    socialLinks: { github: '', discord: '', email: '', twitter: '', linkedin: '' }
  });

  const handleOpenAddFounder = () => {
    setEditingFounderId(null);
    setFounderForm({
      id: 'f_' + Date.now(),
      name: '',
      role: '',
      bio: '',
      skills: '',
      avatar: '/cubix-logo.jpg',
      displayOrder: (data.founders || []).length + 1,
      published: true,
      socialLinks: { github: '', discord: '', email: '', twitter: '', linkedin: '' }
    });
    setFounderModalOpen(true);
  };

  const handleEditFounder = (founder: Founder) => {
    setEditingFounderId(founder.id || founder.name);
    setFounderForm({
      ...founder,
      socialLinks: {
        github: '',
        discord: '',
        email: '',
        twitter: '',
        linkedin: '',
        ...(founder.socialLinks || {})
      }
    });
    setFounderModalOpen(true);
  };

  const handleSaveFounder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!founderForm.name.trim()) {
      showToast('Founder name is required', 'error');
      return;
    }
    const itemToSave: Founder = {
      ...founderForm,
      id: founderForm.id || 'f_' + Date.now()
    };
    let updated = [...(data.founders || [])];
    if (editingFounderId) {
      updated = updated.map((f) => (f.id === editingFounderId || f.name === editingFounderId ? itemToSave : f));
    } else {
      updated = [...updated, itemToSave];
    }
    const res = await updateAppData({ founders: updated });
    if (res.success) {
      showToast('Founder profile saved.');
      setFounderModalOpen(false);
    } else {
      showToast(res.error || 'Failed to save founder', 'error');
    }
  };

  const handleDeleteFounder = (id: string) => {
    setConfirmDialog({
      open: true,
      title: 'Delete Founder',
      message: 'Are you sure you want to remove this founder profile?',
      onConfirm: async () => {
        const updated = (data.founders || []).filter((f) => f.id !== id && f.name !== id);
        const res = await updateAppData({ founders: updated });
        if (res.success) showToast('Founder removed.');
        setConfirmDialog((prev) => ({ ...prev, open: false }));
      }
    });
  };

  const handleToggleFounderPublish = async (id: string, currentVal: boolean) => {
    const updated = (data.founders || []).map((f) =>
      f.id === id || f.name === id ? { ...f, published: !currentVal } : f
    );
    const res = await updateAppData({ founders: updated });
    if (res.success) showToast(!currentVal ? 'Founder published.' : 'Founder hidden.');
  };

  // Gallery / Media Management CRUD
  const [galleryModalOpen, setGalleryModalOpen] = useState(false);
  const [editingGalleryId, setEditingGalleryId] = useState<string | null>(null);
  const [galleryForm, setGalleryForm] = useState<GalleryItem>({
    id: '',
    title: '',
    category: 'web',
    imageUrl: '',
    caption: '',
    projectId: '',
    externalUrl: '',
    displayOrder: 1,
    published: true
  });

  const handleOpenAddGallery = () => {
    setEditingGalleryId(null);
    setGalleryForm({
      id: '',
      title: '',
      category: 'web',
      imageUrl: '',
      caption: '',
      projectId: '',
      externalUrl: '',
      displayOrder: (data.gallery || []).length + 1,
      published: true
    });
    setGalleryModalOpen(true);
  };

  const handleEditGallery = (g: GalleryItem) => {
    setEditingGalleryId(g.id);
    setGalleryForm({ ...g });
    setGalleryModalOpen(true);
  };

  const handleSaveGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!galleryForm.title.trim() || !galleryForm.imageUrl.trim()) {
      showToast('Title and uploaded image are required', 'error');
      return;
    }
    if (editingGalleryId) {
      const updated = (data.gallery || []).map((g) => (g.id === editingGalleryId ? galleryForm : g));
      const res = await updateAppData({ gallery: updated });
      if (res.success) {
        showToast('Media item updated.');
        setGalleryModalOpen(false);
      }
    } else {
      const res = await addGalleryItem(galleryForm);
      if (res.success) {
        showToast('Media item added.');
        setGalleryModalOpen(false);
      }
    }
  };

  const handleDeleteGallery = (id: string) => {
    setConfirmDialog({
      open: true,
      title: 'Delete Media Item',
      message: 'Remove this image from Media Management?',
      onConfirm: async () => {
        const res = await deleteGalleryItem(id);
        if (res.success) showToast('Media item deleted.');
        setConfirmDialog((prev) => ({ ...prev, open: false }));
      }
    });
  };

  // FAQ CRUD
  const [faqModalOpen, setFaqModalOpen] = useState(false);
  const [editingFaqId, setEditingFaqId] = useState<string | null>(null);
  const [faqForm, setFaqForm] = useState<FaqItem>({ id: '', question: '', answer: '' });

  const handleOpenAddFaq = () => {
    setEditingFaqId(null);
    setFaqForm({ id: 'faq_' + Date.now(), question: '', answer: '' });
    setFaqModalOpen(true);
  };

  const handleEditFaq = (faq: FaqItem) => {
    setEditingFaqId(faq.id);
    setFaqForm({ ...faq });
    setFaqModalOpen(true);
  };

  const handleSaveFaq = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!faqForm.question.trim() || !faqForm.answer.trim()) return;
    const updated = editingFaqId
      ? (data.faqs || []).map((f) => (f.id === editingFaqId ? faqForm : f))
      : [...(data.faqs || []), faqForm];
    const res = await updateAppData({ faqs: updated });
    if (res.success) {
      showToast('FAQ saved.');
      setFaqModalOpen(false);
    }
  };

  const handleDeleteFaq = (id: string) => {
    setConfirmDialog({
      open: true,
      title: 'Delete FAQ',
      message: 'Delete this FAQ item?',
      onConfirm: async () => {
        const updated = (data.faqs || []).filter((f) => f.id !== id);
        await updateAppData({ faqs: updated });
        setConfirmDialog((prev) => ({ ...prev, open: false }));
      }
    });
  };

  // Financial CRUD
  const finRecords = data.financialRecords || [];
  const totalGains = finRecords.filter((r) => r.type === 'gain').reduce((s, r) => s + (Number(r.amount) || 0), 0);
  const totalLosses = finRecords.filter((r) => r.type === 'loss').reduce((s, r) => s + (Number(r.amount) || 0), 0);
  const netBalance = totalGains - totalLosses;

  const [finModalOpen, setFinModalOpen] = useState(false);
  const [editingFinId, setEditingFinId] = useState<string | null>(null);
  const [finForm, setFinForm] = useState<FinancialRecord>({
    id: '',
    date: new Date().toISOString().split('T')[0],
    description: '',
    category: 'Web Development',
    amount: 0,
    type: 'gain'
  });

  const handleOpenAddFin = () => {
    setEditingFinId(null);
    setFinForm({
      id: 'fin_' + Date.now(),
      date: new Date().toISOString().split('T')[0],
      description: '',
      category: 'Web Development',
      amount: 0,
      type: 'gain'
    });
    setFinModalOpen(true);
  };

  const handleSaveFin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!finForm.description.trim() || Number(finForm.amount) <= 0) return;
    const recordToSave: FinancialRecord = {
      ...finForm,
      id: finForm.id || 'fin_' + Date.now(),
      amount: Math.abs(Number(finForm.amount))
    };
    const updated = editingFinId
      ? finRecords.map((r) => (r.id === editingFinId ? recordToSave : r))
      : [recordToSave, ...finRecords];
    const res = await updateAppData({ financialRecords: updated });
    if (res.success) {
      showToast('Financial record saved.');
      setFinModalOpen(false);
    }
  };

  const handleDeleteFin = (id: string) => {
    setConfirmDialog({
      open: true,
      title: 'Delete Financial Record',
      message: 'Remove this transaction from the ledger?',
      onConfirm: async () => {
        const updated = finRecords.filter((r) => r.id !== id);
        await updateAppData({ financialRecords: updated });
        setConfirmDialog((prev) => ({ ...prev, open: false }));
      }
    });
  };

  // Security / Password Change
  const [currentPass, setCurrentPass] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPass, setNewAdminPass] = useState('');
  const [updatingPass, setUpdatingPass] = useState(false);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPass || !newAdminPass) return;
    setUpdatingPass(true);
    try {
      const res = await fetch('/api/admin/auth/change', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          currentPass,
          newEmail: newAdminEmail.trim() || undefined,
          newPass: newAdminPass
        })
      });
      const json = await res.json();
      if (res.ok && json.success) {
        showToast('Admin credentials updated.');
        setCurrentPass('');
        setNewAdminEmail('');
        setNewAdminPass('');
      } else {
        showToast(json.error || 'Failed to update credentials', 'error');
      }
    } finally {
      setUpdatingPass(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    if (!loginIdentifier.trim() || !loginPass.trim()) {
      setLoginError('Please enter both Username/Email and Password.');
      return;
    }
    setLoggingIn(true);
    const res = await loginAdmin(loginIdentifier.trim(), loginPass.trim());
    setLoggingIn(false);
    if (!res.success) {
      setLoginError(res.error || 'Invalid credentials.');
    } else {
      showToast('Signed in to Admin Panel.');
    }
  };

  // =========================================================================
  // LOGIN SCREEN (Simple, Classic, Professional — No Google Login)
  // =========================================================================
  if (!adminToken) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-md p-8 rounded-2xl bg-[#060f1e] border border-slate-800 shadow-2xl">
          <div className="text-center mb-7">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center mx-auto mb-3.5">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">Cubix Studio Admin Panel</h1>
            <p className="text-slate-400 text-xs mt-1">Sign in with your administrator credentials</p>
          </div>

          {loginError && (
            <div className="mb-5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Username or Email</label>
              <input
                type="text"
                required
                value={loginIdentifier}
                onChange={(e) => setLoginIdentifier(e.target.value)}
                placeholder="Enter username or email"
                autoComplete="username"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Password</label>
              <input
                type="password"
                required
                value={loginPass}
                onChange={(e) => setLoginPass(e.target.value)}
                placeholder="••••••••••••"
                autoComplete="current-password"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400"
              />
            </div>

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full py-3 px-4 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Lock className="w-4 h-4" />
              <span>{loggingIn ? 'Signing In...' : 'Sign In'}</span>
            </button>

            <div className="text-center pt-3 border-t border-slate-800/80">
              <button
                type="button"
                onClick={onBackToSite}
                className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ← Back to Website
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 8 WELL-ORGANIZED ADMIN CATEGORIES
  // =========================================================================
  const pendingTicketsCount = adminTickets.filter(
    (t) => t.status === 'Pending' || t.status === 'Open'
  ).length;
  const pendingVouchesCount = vouches.filter((v) => v.status === 'pending').length;

  const sidebarCategories: {
    id: AdminCategory;
    label: string;
    description: string;
    icon: React.ElementType;
    badge?: number;
  }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      description: 'Overview & statistics',
      icon: LayoutDashboard
    },
    {
      id: 'website',
      label: 'Website Management',
      description: 'Homepage, sections & text',
      icon: FileText
    },
    {
      id: 'appearance',
      label: 'Homepage Appearance',
      description: 'Background, blur & overlay',
      icon: Sliders
    },
    {
      id: 'media',
      label: 'Media Management',
      description: 'Logos, founder photos & images',
      icon: ImageIcon,
      badge: (data.gallery || []).length
    },
    {
      id: 'projects',
      label: 'Projects',
      description: 'Manage portfolio & catalog',
      icon: Briefcase,
      badge: (data.projects || []).length
    },
    {
      id: 'vouches',
      label: 'Vouch Management',
      description: 'Pending, approved & rejected',
      icon: Star,
      badge: pendingVouchesCount > 0 ? pendingVouchesCount : vouches.length
    },
    {
      id: 'tickets',
      label: 'Support Tickets',
      description: 'Talk With Founders requests',
      icon: Ticket,
      badge: pendingTicketsCount > 0 ? pendingTicketsCount : adminTickets.length
    },
    {
      id: 'database',
      label: 'Database & Sync',
      description: 'Connection & sync status',
      icon: Database
    },
    {
      id: 'settings',
      label: 'Site Settings',
      description: 'Global configuration',
      icon: Settings
    }
  ];

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 flex flex-col">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-2xl border text-xs sm:text-sm font-semibold ${
            toastMessage.type === 'success'
              ? 'bg-[#061825] border-cyan-400 text-cyan-300'
              : 'bg-rose-950 border-rose-500 text-rose-200'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <Check className="w-4 h-4 text-cyan-400" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Confirmation Dialog */}
      {confirmDialog.open && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">{confirmDialog.title}</h3>
            <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed">{confirmDialog.message}</p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setConfirmDialog((prev) => ({ ...prev, open: false }))}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmDialog.onConfirm}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Admin Header */}
      <header className="sticky top-0 z-30 h-16 bg-[#050c18]/95 backdrop-blur-md border-b border-slate-800/90 px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            className="md:hidden p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200"
            aria-label="Toggle menu"
          >
            <Sliders className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold text-sm">
              C
            </div>
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>Cubix Studio</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-800">
                  Admin Panel
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
            {syncing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                <span className="text-cyan-300">Syncing...</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-slate-300">Database Synced</span>
              </>
            )}
          </div>

          <button
            onClick={onBackToSite}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold transition-colors cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">View Website</span>
          </button>

          <button
            onClick={logoutAdmin}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* Main Layout: Sidebar + Content */}
      <div className="flex-1 flex overflow-hidden">
        {mobileSidebarOpen && (
          <div
            className="fixed inset-0 bg-black/60 z-30 md:hidden"
            onClick={() => setMobileSidebarOpen(false)}
          />
        )}

        {/* Classic Organized Sidebar */}
        <aside
          className={`fixed md:static inset-y-0 left-0 z-40 w-64 bg-[#050c18] border-r border-slate-800/90 flex flex-col justify-between transition-transform duration-200 md:translate-x-0 ${
            mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="p-3.5 space-y-1 overflow-y-auto">
            <div className="px-3 py-2 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
              Admin Categories
            </div>

            {sidebarCategories.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setActiveCategory(cat.id);
                    setMobileSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-all cursor-pointer ${
                    isActive
                      ? 'bg-cyan-500/15 text-white border border-cyan-500/35'
                      : 'text-slate-300 hover:text-white hover:bg-slate-900/70 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <div className="truncate">
                      <div className="text-xs font-bold leading-tight">{cat.label}</div>
                      <div className="text-[10px] text-slate-500 truncate">{cat.description}</div>
                    </div>
                  </div>
                  {cat.badge !== undefined && cat.badge > 0 && (
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold ${
                        isActive ? 'bg-cyan-400 text-slate-950' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {cat.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-4 border-t border-slate-800/90 bg-[#040914] text-xs">
            <div className="font-semibold text-white truncate">{currentUser?.name || 'Administrator'}</div>
            <div className="text-[11px] font-mono text-slate-400 truncate">
              {currentUser?.email || 'admin@cubix.std'}
            </div>
          </div>
        </aside>

        {/* Main Workspace Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-8 bg-[#030712]">
          <div className="max-w-6xl mx-auto">
            {/* ========================================================= */}
            {/* 1. DASHBOARD – OVERVIEW & IMPORTANT STATISTICS */}
            {/* ========================================================= */}
            {activeCategory === 'dashboard' && (
              <div className="space-y-6">
                <div className="pb-4 border-b border-slate-800">
                  <h1 className="text-2xl font-bold text-white tracking-tight">Dashboard Overview</h1>
                  <p className="text-xs sm:text-sm text-slate-400 mt-1">
                    Key studio metrics, active client requests, AI Assistant sessions, and quick management tools.
                  </p>
                </div>

                {/* Top Statistics Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div
                    onClick={() => setActiveCategory('tickets')}
                    className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 hover:border-cyan-500/40 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-xs font-mono uppercase text-slate-400">
                      <span>Support Tickets</span>
                      <Ticket className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div className="text-2xl font-bold text-white mt-2">{adminTickets.length}</div>
                    <div className="text-xs text-amber-300 mt-1 font-mono">
                      {pendingTicketsCount} Pending Founder Action
                    </div>
                  </div>

                  <div
                    onClick={() => setActiveCategory('vouches')}
                    className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 hover:border-cyan-500/40 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-xs font-mono uppercase text-slate-400">
                      <span>Cubix Vouches</span>
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                    </div>
                    <div className="text-2xl font-bold text-white mt-2">
                      {vouchStats.totalVouches} • {vouchStats.formattedRating}
                    </div>
                    <div className="text-xs text-cyan-300 mt-1 font-mono">
                      {pendingVouchesCount} Pending Review
                    </div>
                  </div>

                  <div
                    onClick={() => setActiveCategory('projects')}
                    className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 hover:border-cyan-500/40 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-xs font-mono uppercase text-slate-400">
                      <span>Published Projects</span>
                      <Briefcase className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div className="text-2xl font-bold text-white mt-2">
                      {(data.projects || []).filter((p) => p.published !== false).length}
                    </div>
                    <div className="text-xs text-slate-400 mt-1 font-mono">
                      {(data.serviceProducts || []).length} Catalog Offerings
                    </div>
                  </div>

                  <div
                    onClick={() => setActiveCategory('media')}
                    className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 hover:border-cyan-500/40 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-xs font-mono uppercase text-slate-400">
                      <span>Founders & Media</span>
                      <Users className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div className="text-2xl font-bold text-white mt-2">{(data.founders || []).length} Founders</div>
                    <div className="text-xs text-emerald-400 mt-1 font-mono">
                      {(data.gallery || []).length} Uploaded Media Assets
                    </div>
                  </div>
                </div>

                {/* Recent Support Tickets & Recent AI Client Sessions */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Recent Talk With Founders Requests */}
                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-sm font-bold text-white flex items-center gap-2">
                        <Ticket className="w-4 h-4 text-cyan-400" />
                        <span>Recent Talk With Founders Tickets</span>
                      </h2>
                      <button
                        onClick={() => setActiveCategory('tickets')}
                        className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                      >
                        Manage All →
                      </button>
                    </div>

                    {adminTickets.length === 0 ? (
                      <p className="text-xs text-slate-400 py-6 text-center">
                        No support tickets submitted yet.
                      </p>
                    ) : (
                      <div className="space-y-2.5">
                        {adminTickets.slice(0, 4).map((t) => (
                          <div
                            key={t.id}
                            onClick={() => setActiveCategory('tickets')}
                            className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 hover:border-slate-700 flex items-center justify-between gap-3 cursor-pointer"
                          >
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-300 font-mono text-[11px] font-bold">
                                  {t.cubesId || t.username}
                                </span>
                                <span className="text-xs font-mono text-slate-400">{t.ticketNumber}</span>
                              </div>
                              <p className="text-xs text-slate-300 truncate mt-1">{t.requestDetails}</p>
                            </div>
                            <span className="text-[11px] font-mono text-amber-300 shrink-0">
                              {t.status === 'Open' ? 'Pending' : t.status}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Quick Category Directory */}
                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                    <h2 className="text-sm font-bold text-white">Quick Administration Directory</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {sidebarCategories.slice(1).map((c) => {
                        const Icon = c.icon;
                        return (
                          <button
                            key={c.id}
                            onClick={() => setActiveCategory(c.id)}
                            className="p-3 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-800/80 text-left flex items-center gap-3 transition-colors cursor-pointer"
                          >
                            <Icon className="w-4 h-4 text-cyan-400 shrink-0" />
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-white truncate">{c.label}</div>
                              <div className="text-[11px] text-slate-400 truncate">{c.description}</div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* 2. WEBSITE MANAGEMENT – HOMEPAGE, SECTIONS, FOUNDERS & TEXT */}
            {/* ========================================================= */}
            {activeCategory === 'website' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight">Website Management</h1>
                    <p className="text-xs sm:text-sm text-slate-400 mt-1">
                      Edit homepage hero text, section visibility, About section, Founders, Services, and FAQs.
                    </p>
                  </div>

                  {(websiteSubTab === 'homepage' || websiteSubTab === 'about') && (
                    <button
                      onClick={() => handleSaveSettings()}
                      disabled={savingSettings}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs sm:text-sm cursor-pointer disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      <span>{savingSettings ? 'Saving...' : 'Save Changes'}</span>
                    </button>
                  )}
                </div>

                {/* Sub-navigation bar */}
                <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-xl bg-[#060f1d] border border-slate-800/90">
                  {[
                    { id: 'homepage' as const, label: 'Homepage & Hero' },
                    { id: 'about' as const, label: 'About Section' },
                    { id: 'founders' as const, label: `Founders (${(data.founders || []).length})` },
                    { id: 'services' as const, label: `Services (${currentServices.length})` },
                    { id: 'faqs' as const, label: `FAQs (${(data.faqs || []).length})` }
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setWebsiteSubTab(tab.id)}
                      className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        websiteSubTab === tab.id
                          ? 'bg-cyan-400 text-slate-950'
                          : 'text-slate-300 hover:text-white hover:bg-slate-900'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                  <button
                    onClick={() => setActiveCategory('appearance')}
                    className="px-3.5 py-2 rounded-lg text-xs font-bold text-cyan-300 hover:text-white bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/25 transition-colors cursor-pointer ml-auto flex items-center gap-1.5"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Homepage Appearance</span>
                  </button>
                </div>

                {/* SUB-TAB: HOMEPAGE & HERO */}
                {websiteSubTab === 'homepage' && (
                  <div className="space-y-6">
                    <div className="p-6 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                      <h3 className="text-sm font-bold text-white">Homepage Section Visibility</h3>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        {[
                          { key: 'hero', label: 'Hero Section' },
                          { key: 'reputation', label: 'Cubix Vouches Section' },
                          { key: 'about', label: 'About Cubix Studio' },
                          { key: 'services', label: 'Our Projects / Services' },
                          { key: 'faq', label: 'FAQ Section' },
                          { key: 'contact', label: 'Contact Section' }
                        ].map((sec) => {
                          const isVisible =
                            settingsForm.sectionVisibility?.[
                              sec.key as keyof typeof settingsForm.sectionVisibility
                            ] !== false;
                          return (
                            <label
                              key={sec.key}
                              className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-200 cursor-pointer"
                            >
                              <span>{sec.label}</span>
                              <input
                                type="checkbox"
                                checked={isVisible}
                                onChange={(e) =>
                                  setSettingsForm((prev) => ({
                                    ...prev,
                                    sectionVisibility: {
                                      ...(prev.sectionVisibility || {}),
                                      [sec.key]: e.target.checked
                                    }
                                  }))
                                }
                                className="rounded accent-cyan-400 cursor-pointer"
                              />
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    <div className="p-6 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                      <h3 className="text-sm font-bold text-white">Hero Text & Action Buttons</h3>
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">Hero Badge</label>
                        <input
                          type="text"
                          value={settingsForm.heroBadge || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, heroBadge: e.target.value })}
                          className="w-full px-3.5 py-2.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">Main Headline</label>
                        <input
                          type="text"
                          value={settingsForm.heroHeadline || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, heroHeadline: e.target.value })}
                          className="w-full px-3.5 py-2.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-sm font-bold"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">Hero Subtitle</label>
                        <textarea
                          rows={3}
                          value={settingsForm.heroSubtitle || settingsForm.heroDescription || ''}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              heroSubtitle: e.target.value,
                              heroDescription: e.target.value
                            })
                          }
                          className="w-full px-3.5 py-2.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs leading-relaxed"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                            Primary Button Label
                          </label>
                          <input
                            type="text"
                            value={settingsForm.heroPrimaryBtnText || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, heroPrimaryBtnText: e.target.value })}
                            className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                            Secondary Button Label
                          </label>
                          <input
                            type="text"
                            value={settingsForm.heroSecondaryBtnText || ''}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, heroSecondaryBtnText: e.target.value })
                            }
                            className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* SUB-TAB: ABOUT SECTION */}
                {websiteSubTab === 'about' && (
                  <div className="p-6 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                    <h3 className="text-sm font-bold text-white">About Cubix Studio</h3>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">Section Heading</label>
                      <input
                        type="text"
                        value={settingsForm.aboutHeading || 'About Cubix Studio'}
                        onChange={(e) => setSettingsForm({ ...settingsForm, aboutHeading: e.target.value })}
                        className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">Main Statement</label>
                      <input
                        type="text"
                        value={settingsForm.aboutStatement || ''}
                        onChange={(e) => setSettingsForm({ ...settingsForm, aboutStatement: e.target.value })}
                        className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-sm font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">Description</label>
                      <textarea
                        rows={3}
                        value={settingsForm.aboutDescription || ''}
                        onChange={(e) => setSettingsForm({ ...settingsForm, aboutDescription: e.target.value })}
                        className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                      <div>
                        <label className="block text-xs font-mono text-cyan-400 mb-1">Mission Card</label>
                        <textarea
                          rows={4}
                          value={settingsForm.aboutCards?.mission || ''}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              aboutCards: { ...settingsForm.aboutCards, mission: e.target.value }
                            })
                          }
                          className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono text-cyan-400 mb-1">Approach Card</label>
                        <textarea
                          rows={4}
                          value={settingsForm.aboutCards?.approach || ''}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              aboutCards: { ...settingsForm.aboutCards, approach: e.target.value }
                            })
                          }
                          className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono text-cyan-400 mb-1">What We Build Card</label>
                        <textarea
                          rows={4}
                          value={settingsForm.aboutCards?.whatWeBuild || ''}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              aboutCards: { ...settingsForm.aboutCards, whatWeBuild: e.target.value }
                            })
                          }
                          className="w-full p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* SUB-TAB: FOUNDERS */}
                {websiteSubTab === 'founders' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white">Studio Founders</h3>
                      <button
                        onClick={handleOpenAddFounder}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Founder</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {(data.founders || []).map((founder) => (
                        <div
                          key={founder.id || founder.name}
                          className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-3"
                        >
                          <div className="flex items-start gap-3.5">
                            <img
                              src={founder.avatar || '/cubix-logo.jpg'}
                              alt={founder.name}
                              className="w-12 h-12 rounded-full object-cover border border-slate-700 shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-bold text-white">{founder.name}</div>
                              <div className="text-xs font-mono text-cyan-400">{founder.role}</div>
                              <p className="text-xs text-slate-300 mt-1 line-clamp-2">{founder.bio}</p>
                            </div>
                          </div>
                          <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
                            <button
                              onClick={() =>
                                handleToggleFounderPublish(
                                  founder.id || founder.name,
                                  founder.published !== false
                                )
                              }
                              className={`px-2.5 py-1 rounded font-mono text-[11px] cursor-pointer ${
                                founder.published !== false
                                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {founder.published !== false ? 'Published' : 'Hidden'}
                            </button>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleEditFounder(founder)}
                                className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 cursor-pointer"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => handleDeleteFounder(founder.id || founder.name)}
                                className="px-2.5 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 cursor-pointer"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* SUB-TAB: SERVICES */}
                {websiteSubTab === 'services' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white">Homepage Services</h3>
                      <button
                        onClick={handleOpenAddService}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Service</span>
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {currentServices.map((srv, idx) => (
                        <div key={srv.id} className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="text-sm font-bold text-white">{srv.name}</h4>
                              <span className="text-[11px] font-mono text-cyan-400 uppercase">{srv.category}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleMoveService(idx, 'up')}
                                disabled={idx === 0}
                                className="p-1 rounded bg-slate-900 text-slate-300 disabled:opacity-30 cursor-pointer"
                              >
                                <MoveUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleMoveService(idx, 'down')}
                                disabled={idx === currentServices.length - 1}
                                className="p-1 rounded bg-slate-900 text-slate-300 disabled:opacity-30 cursor-pointer"
                              >
                                <MoveDown className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                          <ul className="space-y-1 text-xs text-slate-300">
                            {(srv.points || []).map((pt, i) => (
                              <li key={i}>• {pt}</li>
                            ))}
                          </ul>
                          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                            <button
                              onClick={() => handleEditService(srv)}
                              className="px-2.5 py-1 rounded bg-slate-900 text-xs text-slate-200 border border-slate-700 cursor-pointer"
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => handleDeleteService(srv.id)}
                              className="px-2.5 py-1 rounded bg-rose-500/10 text-xs text-rose-300 border border-rose-500/30 cursor-pointer"
                            >
                              Delete
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* SUB-TAB: FAQS */}
                {websiteSubTab === 'faqs' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white">Frequently Asked Questions</h3>
                      <button
                        onClick={handleOpenAddFaq}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add FAQ</span>
                      </button>
                    </div>
                    <div className="space-y-3">
                      {(data.faqs || []).map((faq) => (
                        <div
                          key={faq.id}
                          className="p-4 rounded-xl bg-[#060f1d] border border-slate-800/90 flex items-start justify-between gap-4"
                        >
                          <div>
                            <div className="text-sm font-bold text-white">{faq.question}</div>
                            <p className="text-xs text-slate-300 mt-1">{faq.answer}</p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => handleEditFaq(faq)}
                              className="p-1.5 rounded bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteFaq(faq.id)}
                              className="p-1.5 rounded bg-rose-500/10 text-rose-300 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ========================================================= */}
            {/* 2B. HOMEPAGE APPEARANCE – BACKGROUND, BLUR, OVERLAY & PREVIEW */}
            {/* ========================================================= */}
            {activeCategory === 'appearance' && (
              <div className="space-y-6">
                {/* Header & Primary Actions */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <h1 className="text-2xl font-bold text-white tracking-tight">Homepage Appearance</h1>
                      {appearanceDirty ? (
                        <span className="px-2.5 py-0.5 rounded-md bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-mono">
                          Unsaved Preview
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-mono">
                          Saved &amp; Live
                        </span>
                      )}
                    </div>
                    <p className="text-xs sm:text-sm text-slate-400 mt-1">
                      Customize the homepage background image, positioning, background blur intensity, and overlay darkness with live preview.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      type="button"
                      onClick={handleResetAppearanceToDefault}
                      disabled={savingAppearance}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 font-semibold text-xs transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                      <span>Reset to Default</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleSaveAppearance}
                      disabled={savingAppearance}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs sm:text-sm transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      <span>{savingAppearance ? 'Saving...' : 'Save Changes'}</span>
                    </button>
                  </div>
                </div>

                {/* Live Homepage Preview Card */}
                <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-3.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h2 className="text-sm font-bold text-white flex items-center gap-2">
                        <Eye className="w-4 h-4 text-cyan-400" />
                        <span>Live Homepage Preview</span>
                      </h2>
                      <p className="text-xs text-slate-400">
                        Preview how your background image, position, blur, and darkness overlay appear behind sharp homepage content before saving.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono">
                      <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300">
                        Position: <strong className="text-cyan-300 capitalize">{appearanceDraft.position}</strong>
                      </span>
                      <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300">
                        Blur: <strong className="text-cyan-300">{appearanceDraft.blur}px</strong>
                      </span>
                      <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300">
                        Overlay: <strong className="text-cyan-300">{appearanceDraft.overlayOpacity}%</strong>
                      </span>
                    </div>
                  </div>

                  {/* Interactive Homepage Hero Simulation */}
                  <div
                    className="relative rounded-xl border border-slate-800 overflow-hidden min-h-[280px] sm:min-h-[320px] flex flex-col justify-between p-4 sm:p-6"
                    style={{ backgroundColor: appearanceDraft.solidColor || '#06101e' }}
                  >
                    {/* Layer 1: Background Image ONLY (Blur affects only this layer) */}
                    <div
                      className="absolute inset-0 z-0 pointer-events-none select-none"
                      style={{
                        backgroundColor: appearanceDraft.solidColor || '#06101e',
                        backgroundImage: `url("${appearanceDraft.imageUrl || DEFAULT_HERO_BG_IMAGE}")`,
                        backgroundPosition:
                          appearanceDraft.position === 'top'
                            ? 'top center'
                            : appearanceDraft.position === 'bottom'
                            ? 'bottom center'
                            : 'center center',
                        backgroundSize: 'cover',
                        backgroundRepeat: 'no-repeat',
                        filter: appearanceDraft.blur > 0 ? `blur(${appearanceDraft.blur}px)` : 'none',
                        transform: appearanceDraft.blur > 0 ? 'scale(1.08)' : 'scale(1)'
                      }}
                    />

                    {/* Layer 2: Darkness / Overlay Intensity Layer (0% to 100%) */}
                    <div
                      className="absolute inset-0 z-0 pointer-events-none"
                      style={{
                        backgroundColor: appearanceDraft.solidColor || '#06101e',
                        opacity: Math.min(Math.max(appearanceDraft.overlayOpacity, 0), 100) / 100
                      }}
                    />

                    {/* Subtle bottom transition blend */}
                    <div className="absolute inset-x-0 bottom-0 h-16 z-0 pointer-events-none bg-gradient-to-b from-transparent to-[#030712]/90" />

                    {/* Layer 3: Sharp Foreground Content (Navigation, Headline, Subtitle, Buttons) */}
                    <div className="relative z-10 flex items-center justify-between px-3.5 py-2 rounded-2xl border border-white/15 bg-white/[0.05] backdrop-blur-md">
                      <div className="flex items-center gap-2">
                        <img
                          src={data.settings?.logoUrl || '/cubix-logo.jpg'}
                          alt="Cubix Studio"
                          className="w-6 h-6 rounded-full object-cover border border-white/20"
                        />
                        <span className="text-xs font-extrabold text-white">
                          Cubix <span className="text-cyan-400 font-semibold">Studio</span>
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-300 px-2 py-0.5 rounded bg-white/10">
                        Foreground Sharp
                      </span>
                    </div>

                    <div className="relative z-10 my-auto py-6 max-w-xl">
                      <div className="inline-block px-2.5 py-1 rounded-md bg-white/[0.06] border border-white/15 text-[10px] font-mono uppercase tracking-wider text-cyan-300 mb-2.5">
                        {data.settings?.heroBadge || 'DIGITAL DEVELOPMENT & CREATIVE STUDIO'}
                      </div>
                      <h3 className="text-lg sm:text-2xl font-extrabold text-white tracking-tight leading-snug">
                        {data.settings?.heroHeadline || 'Building Modern Websites, Custom Systems & Creative Digital Experiences'}
                      </h3>
                      <p className="text-xs text-slate-300 mt-2 line-clamp-2">
                        {data.settings?.heroSubtitle ||
                          data.settings?.heroDescription ||
                          'Full-stack web platforms, custom software, Minecraft systems, and Discord infrastructure.'}
                      </p>
                      <div className="flex flex-wrap items-center gap-2.5 mt-4">
                        <span className="px-3.5 py-1.5 rounded-lg bg-cyan-400 text-slate-950 font-bold text-xs">
                          {data.settings?.heroPrimaryBtnText || 'What We Do'}
                        </span>
                        <span className="px-3.5 py-1.5 rounded-lg bg-white/10 border border-white/15 text-white font-semibold text-xs">
                          {data.settings?.heroSecondaryBtnText || 'Meet the Founders'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Controls Grid: Background Image & Position + Blur & Overlay Sliders */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Left Column: Background Image Controls & Positioning */}
                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-5">
                    <div>
                      <h3 className="text-sm font-bold text-white">Background Image Controls</h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Upload a custom homepage background, replace the existing image, or restore the default studio background.
                      </p>
                    </div>

                    {/* Selected Image Thumbnail Preview */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-300">Selected Background Image</span>
                        <span
                          className={`font-mono text-[11px] px-2 py-0.5 rounded ${
                            appearanceDraft.imageUrl === DEFAULT_HERO_BG_IMAGE
                              ? 'bg-slate-800 text-slate-300'
                              : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                          }`}
                        >
                          {appearanceDraft.imageUrl === DEFAULT_HERO_BG_IMAGE ? 'Default Background' : 'Custom Image'}
                        </span>
                      </div>

                      <div className="relative h-36 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center">
                        <img
                          src={appearanceDraft.imageUrl || DEFAULT_HERO_BG_IMAGE}
                          alt="Selected Homepage Background"
                          className="w-full h-full object-cover"
                          style={{
                            objectPosition:
                              appearanceDraft.position === 'top'
                                ? 'top'
                                : appearanceDraft.position === 'bottom'
                                ? 'bottom'
                                : 'center'
                          }}
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = DEFAULT_HERO_BG_IMAGE;
                          }}
                        />
                      </div>
                    </div>

                    {/* Upload / Replace / Remove Buttons */}
                    <input
                      ref={appearanceFileInputRef}
                      type="file"
                      accept="image/png,image/jpeg,image/jpg,image/webp,image/svg+xml,image/gif"
                      onChange={handleAppearanceFileSelect}
                      className="hidden"
                    />

                    <div className="flex flex-wrap items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => appearanceFileInputRef.current?.click()}
                        disabled={uploadingAppearanceBg}
                        className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs transition-colors cursor-pointer disabled:opacity-50"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>
                          {uploadingAppearanceBg
                            ? 'Uploading...'
                            : appearanceDraft.imageUrl === DEFAULT_HERO_BG_IMAGE
                            ? 'Upload Custom Image'
                            : 'Replace Background Image'}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={handleRemoveCustomAppearanceBg}
                        disabled={appearanceDraft.imageUrl === DEFAULT_HERO_BG_IMAGE}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 font-semibold text-xs transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                        <span>Remove Custom Image</span>
                      </button>
                    </div>

                    {/* Direct Image URL Input */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Background Image URL (Optional)
                      </label>
                      <input
                        type="text"
                        value={
                          appearanceDraft.imageUrl.startsWith('data:')
                            ? ''
                            : appearanceDraft.imageUrl
                        }
                        onChange={(e) =>
                          updateAppearanceDraft({
                            imageUrl: e.target.value.trim() || DEFAULT_HERO_BG_IMAGE
                          })
                        }
                        placeholder={
                          appearanceDraft.imageUrl.startsWith('data:')
                            ? 'Uploaded custom image active (paste URL to override)'
                            : '/b90c9408e77c5a808a0f1adfab828f1b.jpg'
                        }
                        className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs font-mono focus:outline-none focus:border-cyan-400"
                      />
                    </div>

                    {/* Background Positioning Controls: Center, Top, Bottom */}
                    <div className="pt-2 border-t border-slate-800/80">
                      <label className="block text-xs font-semibold text-slate-300 mb-2">
                        Background Positioning
                      </label>
                      <div className="grid grid-cols-3 gap-2.5">
                        {(
                          [
                            { id: 'center', label: 'Center' },
                            { id: 'top', label: 'Top' },
                            { id: 'bottom', label: 'Bottom' }
                          ] as const
                        ).map((posOption) => {
                          const isSelected = appearanceDraft.position === posOption.id;
                          return (
                            <button
                              key={posOption.id}
                              type="button"
                              onClick={() => updateAppearanceDraft({ position: posOption.id })}
                              className={`py-2.5 px-3 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                                isSelected
                                  ? 'bg-cyan-400 text-slate-950 border-cyan-400'
                                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                              }`}
                            >
                              {posOption.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Background Blur & Overlay Intensity Sliders */}
                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-6">
                    {/* Background Blur Slider (0px to 40px) */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-bold text-white">Background Blur Controls</h3>
                          <p className="text-xs text-slate-400 mt-0.5">
                            Blurs only the background image. Foreground text, navigation, and buttons remain sharp.
                          </p>
                        </div>
                        <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300 font-mono text-xs font-bold">
                          {appearanceDraft.blur}px
                        </span>
                      </div>

                      <div className="pt-1">
                        <input
                          type="range"
                          min={0}
                          max={40}
                          step={1}
                          value={appearanceDraft.blur}
                          onChange={(e) =>
                            updateAppearanceDraft({
                              blur: Math.min(Math.max(Number(e.target.value) || 0, 0), 40)
                            })
                          }
                          aria-label="Background Blur Intensity (0px to 40px)"
                          className="w-full h-2 rounded-lg bg-slate-950 accent-cyan-400 cursor-pointer"
                        />
                        <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-1">
                          <span>0px (No Blur)</span>
                          <span>20px</span>
                          <span>40px (Max Blur)</span>
                        </div>
                      </div>

                      {/* Quick Blur Presets */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        {[0, 4, 8, 12, 20, 30, 40].map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => updateAppearanceDraft({ blur: val })}
                            className={`px-2.5 py-1 rounded-md text-[11px] font-mono transition-colors cursor-pointer ${
                              appearanceDraft.blur === val
                                ? 'bg-cyan-400 text-slate-950 font-bold'
                                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                            }`}
                          >
                            {val}px
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Background Overlay / Darkness Slider (0% to 100%) */}
                    <div className="pt-5 border-t border-slate-800/80 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-bold text-white">Background Overlay Controls</h3>
                          <p className="text-xs text-slate-400 mt-0.5">
                            Adjust darkness overlay intensity from 0% to 100% for optimal foreground readability.
                          </p>
                        </div>
                        <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300 font-mono text-xs font-bold">
                          {appearanceDraft.overlayOpacity}%
                        </span>
                      </div>

                      <div className="pt-1">
                        <input
                          type="range"
                          min={0}
                          max={100}
                          step={1}
                          value={appearanceDraft.overlayOpacity}
                          onChange={(e) =>
                            updateAppearanceDraft({
                              overlayOpacity: Math.min(Math.max(Number(e.target.value), 0), 100)
                            })
                          }
                          aria-label="Background Overlay Darkness Intensity (0% to 100%)"
                          className="w-full h-2 rounded-lg bg-slate-950 accent-cyan-400 cursor-pointer"
                        />
                        <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-1">
                          <span>0% (Clear)</span>
                          <span>50%</span>
                          <span>100% (Solid Dark)</span>
                        </div>
                      </div>

                      {/* Quick Overlay Presets */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        {[0, 30, 50, 70, 80, 90, 100].map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => updateAppearanceDraft({ overlayOpacity: val })}
                            className={`px-2.5 py-1 rounded-md text-[11px] font-mono transition-colors cursor-pointer ${
                              appearanceDraft.overlayOpacity === val
                                ? 'bg-cyan-400 text-slate-950 font-bold'
                                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                            }`}
                          >
                            {val}%
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Save & Reset Footer inside controls card */}
                    <div className="pt-5 border-t border-slate-800/80 flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={handleResetAppearanceToDefault}
                        disabled={savingAppearance}
                        className="px-3.5 py-2 rounded-lg bg-slate-950 hover:bg-slate-900 text-slate-300 border border-slate-800 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
                      >
                        Reset to Default
                      </button>

                      <button
                        type="button"
                        onClick={handleSaveAppearance}
                        disabled={savingAppearance}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs transition-colors cursor-pointer disabled:opacity-50"
                      >
                        <Save className="w-4 h-4" />
                        <span>{savingAppearance ? 'Saving...' : 'Save Changes'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* 3. MEDIA MANAGEMENT – LOGOS, FOUNDER PHOTOS & IMAGES */}
            {/* ========================================================= */}
            {activeCategory === 'media' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight">Media Management</h1>
                    <p className="text-xs sm:text-sm text-slate-400 mt-1">
                      Upload and manage website logos, homepage hero background, founder profile photos, and showcase gallery images.
                    </p>
                  </div>
                  <button
                    onClick={handleOpenAddGallery}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs sm:text-sm cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload Gallery Image</span>
                  </button>
                </div>

                {/* Brand Logo & Homepage Hero Background */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                    <h3 className="text-sm font-bold text-white">Website Brand Logo</h3>
                    <ImageUploadField
                      label="Studio Logo Image"
                      value={settingsForm.logoUrl}
                      onChange={async (url) => {
                        const nextSettings = { ...settingsForm, logoUrl: url };
                        setSettingsForm(nextSettings);
                        const res = await updateAppData({ settings: nextSettings });
                        if (res.success) {
                          settingsFormDirtyRef.current = false;
                          showToast('Website logo saved.');
                        }
                      }}
                      helperText="Displayed in navigation bar and footer"
                      placeholder="/cubix-logo.jpg"
                      aspectRatio="square"
                    />
                  </div>

                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4 flex flex-col justify-between">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white">Homepage Hero Background</h3>
                        <button
                          type="button"
                          onClick={() => setActiveCategory('appearance')}
                          className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                        >
                          Blur, Overlay &amp; Position →
                        </button>
                      </div>
                      <ImageUploadField
                        label="Hero Background Banner"
                        value={settingsForm.heroBackground?.imageUrl || ''}
                        onChange={async (url) => {
                          const nextHeroBg = {
                            ...(settingsForm.heroBackground || {}),
                            imageUrl: url || DEFAULT_HERO_BG_IMAGE
                          };
                          const nextSettings = {
                            ...settingsForm,
                            heroBackground: nextHeroBg
                          };
                          setSettingsForm(nextSettings);
                          setAppearanceDraftState(buildAppearanceState(nextHeroBg));
                          syncHeroBackgroundToDomAndCache(nextHeroBg);
                          const res = await updateAppData({ settings: nextSettings });
                          if (res.success) {
                            settingsFormDirtyRef.current = false;
                            showToast('Homepage background image saved.');
                          }
                        }}
                        helperText="Top homepage background image"
                        placeholder="/b90c9408e77c5a808a0f1adfab828f1b.jpg"
                        aspectRatio="wide"
                      />
                    </div>
                  </div>
                </div>

                {/* Founder Profile Photos Quick Manager */}
                <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white">Founder Profile Photos</h3>
                      <p className="text-xs text-slate-400">
                        Upload or replace portrait photos for each Founder. Changes save automatically.
                      </p>
                    </div>
                    <button
                      onClick={handleOpenAddFounder}
                      className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                    >
                      + Add Founder
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {(data.founders || []).map((founder) => (
                      <div
                        key={founder.id || founder.name}
                        className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-xs font-bold text-white">{founder.name}</div>
                            <div className="text-[10px] font-mono text-cyan-400">{founder.role}</div>
                          </div>
                          <button
                            onClick={() => handleEditFounder(founder)}
                            className="text-xs text-slate-400 hover:text-white cursor-pointer"
                          >
                            Edit Info
                          </button>
                        </div>

                        <ImageUploadField
                          label="Founder Photo"
                          value={founder.avatar}
                          onChange={async (url) => {
                            const updated = (data.founders || []).map((f) =>
                              f.id === founder.id && f.name === founder.name ? { ...f, avatar: url } : f
                            );
                            const res = await updateAppData({ founders: updated });
                            if (res.success) {
                              showToast(`Photo updated for ${founder.name}.`);
                            }
                          }}
                          aspectRatio="square"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Uploaded Showcase Gallery Images */}
                <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white">
                        Uploaded Gallery Images ({(data.gallery || []).length})
                      </h3>
                      <p className="text-xs text-slate-400">Images displayed in the public Projects & Gallery showcase.</p>
                    </div>
                  </div>

                  {(data.gallery || []).length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-400">
                      No gallery images uploaded yet. Click "Upload Gallery Image" above to add one.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      {(data.gallery || []).map((item) => (
                        <div
                          key={item.id}
                          className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col justify-between"
                        >
                          <div className="h-40 bg-slate-900 overflow-hidden">
                            <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                          </div>
                          <div className="p-3.5 flex items-center justify-between gap-2">
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-white truncate">{item.title}</div>
                              <div className="text-[10px] font-mono text-cyan-400 uppercase">{item.category}</div>
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                onClick={() => handleEditGallery(item)}
                                className="p-1.5 rounded bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteGallery(item.id)}
                                className="p-1.5 rounded bg-rose-500/10 text-rose-300 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* 4. PROJECTS – ADD, EDIT, DELETE & MANAGE PROJECTS */}
            {/* ========================================================= */}
            {activeCategory === 'projects' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight">Projects Management</h1>
                    <p className="text-xs sm:text-sm text-slate-400 mt-1">
                      Add, edit, delete, and organize portfolio projects and catalog offerings.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setProjectsSubTab('portfolio')}
                      className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer ${
                        projectsSubTab === 'portfolio'
                          ? 'bg-cyan-400 text-slate-950'
                          : 'bg-slate-900 text-slate-300'
                      }`}
                    >
                      Portfolio Projects ({(data.projects || []).length})
                    </button>
                    <button
                      onClick={() => setProjectsSubTab('catalog')}
                      className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer ${
                        projectsSubTab === 'catalog'
                          ? 'bg-cyan-400 text-slate-950'
                          : 'bg-slate-900 text-slate-300'
                      }`}
                    >
                      Catalog Services & Products ({(data.serviceProducts || []).length})
                    </button>
                  </div>
                </div>

                {projectsSubTab === 'catalog' ? (
                  <AdminServiceProductsManagement />
                ) : (
                  <div className="space-y-5">
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-xl bg-[#060f1d] border border-slate-800/90">
                      <div className="relative flex-1 max-w-sm">
                        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={projectSearchTerm}
                          onChange={(e) => setProjectSearchTerm(e.target.value)}
                          placeholder="Search projects..."
                          className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        {['all', 'web', 'design', 'minecraft', 'discord'].map((cat) => (
                          <button
                            key={cat}
                            onClick={() => setProjectFilterCategory(cat)}
                            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono uppercase cursor-pointer ${
                              projectFilterCategory === cat
                                ? 'bg-cyan-400 text-slate-950 font-bold'
                                : 'bg-slate-900 text-slate-300'
                            }`}
                          >
                            {cat}
                          </button>
                        ))}
                        <button
                          onClick={handleOpenAddProject}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs cursor-pointer ml-2"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Add Project</span>
                        </button>
                      </div>
                    </div>

                    <div className="rounded-xl bg-[#060f1d] border border-slate-800/90 overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="border-b border-slate-800 text-slate-400 font-mono">
                              <th className="py-3 px-4">Project</th>
                              <th className="py-3 px-4">Category</th>
                              <th className="py-3 px-4">File</th>
                              <th className="py-3 px-4">Status</th>
                              <th className="py-3 px-4 text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/70">
                            {(data.projects || [])
                              .filter((p) => {
                                if (projectFilterCategory !== 'all' && p.category !== projectFilterCategory)
                                  return false;
                                if (projectSearchTerm) {
                                  const term = projectSearchTerm.toLowerCase();
                                  return (
                                    p.name.toLowerCase().includes(term) ||
                                    (p.tags || []).some((t) => t.toLowerCase().includes(term))
                                  );
                                }
                                return true;
                              })
                              .map((proj) => (
                                <tr key={proj.id} className="hover:bg-slate-900/50">
                                  <td className="py-3.5 px-4">
                                    <div className="font-bold text-white">{proj.name}</div>
                                    <div className="text-[11px] text-slate-400 line-clamp-1 max-w-md">
                                      {proj.description}
                                    </div>
                                  </td>
                                  <td className="py-3.5 px-4 font-mono uppercase text-cyan-400">{proj.category}</td>
                                  <td className="py-3.5 px-4">
                                    {proj.fileName ? (
                                      <a
                                        href={`/api/download/${proj.fileName}`}
                                        target="_blank"
                                        rel="noreferrer"
                                        className="inline-flex items-center gap-1 text-cyan-300 hover:underline"
                                      >
                                        <Download className="w-3 h-3" />
                                        <span>{proj.fileName}</span>
                                      </a>
                                    ) : (
                                      <span className="text-slate-500">—</span>
                                    )}
                                  </td>
                                  <td className="py-3.5 px-4">
                                    <button
                                      onClick={() =>
                                        handleToggleProjectPublish(proj.id, proj.published !== false)
                                      }
                                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold cursor-pointer ${
                                        proj.published !== false
                                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                          : 'bg-slate-800 text-slate-400'
                                      }`}
                                    >
                                      {proj.published !== false ? 'Published' : 'Draft'}
                                    </button>
                                  </td>
                                  <td className="py-3.5 px-4 text-right">
                                    <div className="flex items-center justify-end gap-2">
                                      <button
                                        onClick={() => handleEditProject(proj)}
                                        className="p-1.5 rounded bg-slate-900 text-slate-200 hover:text-white cursor-pointer"
                                      >
                                        <Edit2 className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleDeleteProject(proj.id)}
                                        className="p-1.5 rounded bg-rose-500/10 text-rose-300 cursor-pointer"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ========================================================= */}
            {/* 5. VOUCH MANAGEMENT – PENDING, APPROVED & REJECTED */}
            {/* ========================================================= */}
            {activeCategory === 'vouches' && (
              <AdminVouchManagement onShowToast={showToast} />
            )}

            {/* ========================================================= */}
            {/* 6. SUPPORT TICKETS – MANAGE ALL TALK WITH FOUNDERS REQUESTS */}
            {/* ========================================================= */}
            {activeCategory === 'tickets' && (
              <div className="space-y-6">
                <AdminTicketManagement />

                {/* Discord Ticket Button Link Setting */}
                <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-3">
                  <h3 className="text-sm font-bold text-white">External Discord Ticket Button URL</h3>
                  <form onSubmit={handleSaveTicketUrl} className="flex flex-col sm:flex-row gap-3">
                    <input
                      type="url"
                      value={ticketUrlInput}
                      onChange={(e) => setTicketUrlInput(e.target.value)}
                      placeholder="https://discord.gg/..."
                      className="flex-1 px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-white"
                    />
                    <button
                      type="submit"
                      disabled={savingTicketUrl}
                      className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-cyan-300 cursor-pointer"
                    >
                      {savingTicketUrl ? 'Saving...' : 'Save Discord URL'}
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* 7. DATABASE & SYNC – CONNECTION & SYNCHRONIZATION STATUS */}
            {/* ========================================================= */}
            {activeCategory === 'database' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight">Database & Real-Time Sync</h1>
                    <p className="text-xs sm:text-sm text-slate-400 mt-1">
                      Monitor your Firebase Cloud Firestore connection, named database configuration, and instant synchronization status.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      refreshData(true);
                      showToast('Database synchronized.');
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
                    <span>Force Sync Now</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-1.5">
                    <span className="text-[11px] font-mono uppercase text-slate-400">Connection Status</span>
                    <div className="flex items-center gap-2 text-lg font-bold text-emerald-400">
                      <CheckCircle2 className="w-5 h-5" />
                      <span>Connected & Active</span>
                    </div>
                    <p className="text-xs text-slate-400">Real-time onSnapshot listeners active</p>
                  </div>

                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-1.5">
                    <span className="text-[11px] font-mono uppercase text-slate-400">Google Cloud Project</span>
                    <div className="text-sm font-mono font-bold text-white">gen-lang-client-0642412032</div>
                    <p className="text-xs text-slate-400">Region: asia-southeast1</p>
                  </div>

                  <div className="p-5 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-1.5">
                    <span className="text-[11px] font-mono uppercase text-slate-400">Last Synchronized</span>
                    <div className="text-sm font-mono font-bold text-cyan-300">
                      {lastUpdated ? new Date(lastUpdated).toLocaleString() : 'Live'}
                    </div>
                    <p className="text-xs text-slate-400">0ms local snapshot cache enabled</p>
                  </div>
                </div>

                <div className="p-6 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4">
                  <h3 className="text-sm font-bold text-white">Firestore Database Details</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-slate-500 block mb-1">NAMED DATABASE ID</span>
                      <span className="text-cyan-300 break-all">
                        ai-studio-cubixstudiogloba-56ae10ae-a948-4558-ab74-2c1a5de01e30
                      </span>
                    </div>
                    <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-slate-500 block mb-1">ACTIVE COLLECTIONS</span>
                      <span className="text-slate-200">
                        cubix_store • vouches ({vouches.length}) • support_tickets ({adminTickets.length}) • cubix_meta
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* 8. SITE SETTINGS – GLOBAL CONFIGURATION, FINANCIAL & SECURITY */}
            {/* ========================================================= */}
            {activeCategory === 'settings' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight">Site Settings</h1>
                    <p className="text-xs sm:text-sm text-slate-400 mt-1">
                      Global website metadata, contact details, financial ledger, and administrator security.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {[
                      { id: 'general' as const, label: 'General Config' },
                      { id: 'financial' as const, label: 'INR Financial Ledger' },
                      { id: 'security' as const, label: 'Admin Security' }
                    ].map((t) => (
                      <button
                        key={t.id}
                        onClick={() => setSettingsSubTab(t.id)}
                        className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer ${
                          settingsSubTab === t.id
                            ? 'bg-cyan-400 text-slate-950'
                            : 'bg-slate-900 text-slate-300'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                {settingsSubTab === 'general' && (
                  <form
                    onSubmit={handleSaveSettings}
                    className="p-6 rounded-xl bg-[#060f1d] border border-slate-800/90 space-y-4"
                  >
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <h3 className="text-sm font-bold text-white">Global Website Settings</h3>
                      <button
                        type="submit"
                        disabled={savingSettings}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs cursor-pointer"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>{savingSettings ? 'Saving...' : 'Save Settings'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">Website Title</label>
                        <input
                          type="text"
                          value={settingsForm.siteTitle || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, siteTitle: e.target.value })}
                          className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">Contact Email</label>
                        <input
                          type="email"
                          value={settingsForm.contactEmail || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                          className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">Discord Server URL</label>
                        <input
                          type="text"
                          value={settingsForm.discordUrl || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, discordUrl: e.target.value })}
                          className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">Studio Location</label>
                        <input
                          type="text"
                          value={settingsForm.location || ''}
                          onChange={(e) => setSettingsForm({ ...settingsForm, location: e.target.value })}
                          className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Contact Section Text</label>
                      <textarea
                        rows={2}
                        value={settingsForm.contactDescription || ''}
                        onChange={(e) => setSettingsForm({ ...settingsForm, contactDescription: e.target.value })}
                        className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                      />
                    </div>
                  </form>
                )}

                {settingsSubTab === 'financial' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="px-4 py-2 rounded-lg bg-[#060f1d] border border-slate-800 text-xs">
                          <span className="text-slate-400 mr-2">Net Balance:</span>
                          <strong className="text-white font-mono">₹{netBalance.toLocaleString('en-IN')}</strong>
                        </div>
                      </div>
                      <button
                        onClick={handleOpenAddFin}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-cyan-400 text-slate-950 font-bold text-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Transaction</span>
                      </button>
                    </div>

                    <div className="rounded-xl bg-[#060f1d] border border-slate-800/90 overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-800 text-slate-400 font-mono">
                            <th className="py-3 px-4">Date</th>
                            <th className="py-3 px-4">Description</th>
                            <th className="py-3 px-4">Type</th>
                            <th className="py-3 px-4 text-right">Amount (₹)</th>
                            <th className="py-3 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/70">
                          {finRecords.map((rec) => (
                            <tr key={rec.id}>
                              <td className="py-3 px-4 font-mono text-slate-400">{rec.date}</td>
                              <td className="py-3 px-4 text-white font-medium">{rec.description}</td>
                              <td className="py-3 px-4 uppercase font-mono text-[11px]">
                                <span className={rec.type === 'gain' ? 'text-emerald-400' : 'text-rose-400'}>
                                  {rec.type}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-right font-mono font-bold text-white">
                                ₹{rec.amount.toLocaleString('en-IN')}
                              </td>
                              <td className="py-3 px-4 text-right">
                                <button
                                  onClick={() => handleDeleteFin(rec.id)}
                                  className="p-1.5 rounded bg-rose-500/10 text-rose-300 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {settingsSubTab === 'security' && (
                  <div className="p-6 rounded-xl bg-[#060f1d] border border-slate-800/90 max-w-lg space-y-4">
                    <h3 className="text-sm font-bold text-white">Update Administrator Credentials</h3>
                    <form onSubmit={handleChangePassword} className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">Current Password</label>
                        <input
                          type="password"
                          required
                          value={currentPass}
                          onChange={(e) => setCurrentPass(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">
                          New Admin Email (optional)
                        </label>
                        <input
                          type="email"
                          value={newAdminEmail}
                          onChange={(e) => setNewAdminEmail(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-semibold mb-1">New Password</label>
                        <input
                          type="password"
                          required
                          value={newAdminPass}
                          onChange={(e) => setNewAdminPass(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={updatingPass}
                        className="px-4 py-2.5 rounded-lg bg-cyan-400 text-slate-950 font-bold cursor-pointer"
                      >
                        {updatingPass ? 'Updating...' : 'Update Credentials'}
                      </button>
                    </form>
                  </div>
                )}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* ========================================================================= */}
      {/* MODALS FOR FOUNDERS, PROJECTS, SERVICES, GALLERY, FAQ, FINANCIAL */}
      {/* ========================================================================= */}

      {/* Founder Modal */}
      {founderModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">
                {editingFounderId ? 'Edit Founder' : 'Add Founder'}
              </h3>
              <button onClick={() => setFounderModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveFounder} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Name</label>
                <input
                  type="text"
                  required
                  value={founderForm.name}
                  onChange={(e) => setFounderForm({ ...founderForm, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Role</label>
                <input
                  type="text"
                  required
                  value={founderForm.role}
                  onChange={(e) => setFounderForm({ ...founderForm, role: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Bio</label>
                <textarea
                  rows={3}
                  required
                  value={founderForm.bio}
                  onChange={(e) => setFounderForm({ ...founderForm, bio: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Skills (comma separated)</label>
                <input
                  type="text"
                  value={founderForm.skills}
                  onChange={(e) => setFounderForm({ ...founderForm, skills: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <ImageUploadField
                label="Founder Photo"
                value={founderForm.avatar}
                onChange={(url) => setFounderForm((prev) => ({ ...prev, avatar: url }))}
                aspectRatio="square"
              />
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setFounderModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-bold cursor-pointer"
                >
                  Save Founder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Project Modal */}
      {projectModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-xl rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">
                {editingProjectId !== null ? 'Edit Project' : 'Add Project'}
              </h3>
              <button onClick={() => setProjectModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveProject} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  value={projectForm.name}
                  onChange={(e) => setProjectForm({ ...projectForm, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Category</label>
                  <select
                    value={projectForm.category}
                    onChange={(e) => setProjectForm({ ...projectForm, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                  >
                    <option value="web">Website Development (web)</option>
                    <option value="design">Graphic Design (design)</option>
                    <option value="minecraft">Minecraft Development (minecraft)</option>
                    <option value="discord">Discord Solutions (discord)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Date</label>
                  <input
                    type="date"
                    value={projectForm.date || ''}
                    onChange={(e) => setProjectForm({ ...projectForm, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Description</label>
                <textarea
                  rows={3}
                  required
                  value={projectForm.description}
                  onChange={(e) => setProjectForm({ ...projectForm, description: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <ImageUploadField
                label="Project Cover Thumbnail"
                value={projectForm.thumbnail || ''}
                onChange={(url) => setProjectForm((prev) => ({ ...prev, thumbnail: url }))}
                aspectRatio="video"
              />
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                <label className="inline-flex items-center gap-2 px-3 py-1.5 rounded bg-slate-900 border border-slate-700 text-cyan-300 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{uploadingProjectFile ? 'Uploading...' : 'Attach Downloadable File'}</span>
                  <input type="file" onChange={handleProjectFileUpload} className="hidden" />
                </label>
                {projectForm.fileName && <span className="font-mono text-cyan-400">{projectForm.fileName}</span>}
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setProjectModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-bold cursor-pointer"
                >
                  Save Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Gallery Upload Modal */}
      {galleryModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">
                {editingGalleryId ? 'Edit Media Item' : 'Upload Gallery Image'}
              </h3>
              <button onClick={() => setGalleryModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveGallery} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Image Title</label>
                <input
                  type="text"
                  required
                  value={galleryForm.title}
                  onChange={(e) => setGalleryForm({ ...galleryForm, title: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Category</label>
                <select
                  value={galleryForm.category}
                  onChange={(e) => setGalleryForm({ ...galleryForm, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                >
                  <option value="web">Website (web)</option>
                  <option value="design">Design (design)</option>
                  <option value="minecraft">Minecraft (minecraft)</option>
                  <option value="discord">Discord (discord)</option>
                </select>
              </div>
              <ImageUploadField
                label="Upload Image"
                value={galleryForm.imageUrl}
                onChange={(url) => setGalleryForm((prev) => ({ ...prev, imageUrl: url }))}
                aspectRatio="video"
              />
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setGalleryModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-bold cursor-pointer"
                >
                  Save Image
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Service Modal */}
      {serviceModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">
                {editingServiceId ? 'Edit Service' : 'Add Service'}
              </h3>
              <button onClick={() => setServiceModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveService} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Service Name</label>
                <input
                  type="text"
                  required
                  value={serviceForm.name}
                  onChange={(e) => setServiceForm({ ...serviceForm, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Bullet Points (one per line)</label>
                <textarea
                  rows={3}
                  value={(serviceForm.points || []).join('\n')}
                  onChange={(e) => setServiceForm({ ...serviceForm, points: e.target.value.split('\n') })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setServiceModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-bold cursor-pointer"
                >
                  Save Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FAQ Modal */}
      {faqModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">{editingFaqId ? 'Edit FAQ' : 'Add FAQ'}</h3>
              <button onClick={() => setFaqModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveFaq} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Question</label>
                <input
                  type="text"
                  required
                  value={faqForm.question}
                  onChange={(e) => setFaqForm({ ...faqForm, question: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Answer</label>
                <textarea
                  rows={4}
                  required
                  value={faqForm.answer}
                  onChange={(e) => setFaqForm({ ...faqForm, answer: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setFaqModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-bold cursor-pointer"
                >
                  Save FAQ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Financial Modal */}
      {finModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#071222] border border-slate-800 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white">Record Financial Transaction</h3>
              <button onClick={() => setFinModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveFin} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setFinForm({ ...finForm, type: 'gain' })}
                  className={`py-2 rounded-lg font-bold cursor-pointer ${
                    finForm.type === 'gain' ? 'bg-cyan-400 text-slate-950' : 'bg-slate-900 text-slate-300'
                  }`}
                >
                  + Gain (INR)
                </button>
                <button
                  type="button"
                  onClick={() => setFinForm({ ...finForm, type: 'loss' })}
                  className={`py-2 rounded-lg font-bold cursor-pointer ${
                    finForm.type === 'loss' ? 'bg-rose-500 text-white' : 'bg-slate-900 text-slate-300'
                  }`}
                >
                  - Expense (INR)
                </button>
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Amount (₹)</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={finForm.amount || ''}
                  onChange={(e) => setFinForm({ ...finForm, amount: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Description</label>
                <input
                  type="text"
                  required
                  value={finForm.description}
                  onChange={(e) => setFinForm({ ...finForm, description: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setFinModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-400 text-slate-950 font-bold cursor-pointer"
                >
                  Save Transaction
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
