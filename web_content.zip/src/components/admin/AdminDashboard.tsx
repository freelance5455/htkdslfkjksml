import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  CheckSquare, 
  Wallet, 
  Sparkles, 
  Bell, 
  Settings, 
  LogOut, 
  ArrowLeft,
  Coins,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  FileCheck,
  MessageSquareHeart,
  Smartphone,
  DollarSign,
  Bot,
  Award
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AdminTasksTab } from './AdminTasksTab';
import { AdminUsersTab } from './AdminUsersTab';
import { AdminWithdrawalsTab } from './AdminWithdrawalsTab';
import { AdminMembershipsTab } from './AdminMembershipsTab';
import { AdminNotificationsTab } from './AdminNotificationsTab';
import { AdminSettingsTab } from './AdminSettingsTab';
import { AdminVipPaymentsTab } from './AdminVipPaymentsTab';
import { AdminWalletTab } from './AdminWalletTab';
import { AdminFeedbackTab } from './AdminFeedbackTab';
import { AdminApkTab } from './AdminApkTab';
import { AdminCoinsTab } from './AdminCoinsTab';
import { AdminAiStudioTab } from './AdminAiStudioTab';
import { AdminAdMonetizationTab } from './AdminAdMonetizationTab';
import { AdminInvestmentTab } from './AdminInvestmentTab';
import { AdminSupportTab } from './AdminSupportTab';
import { TaskCompletionTrendsChart } from './TaskCompletionTrendsChart';
import { AdminLegalAndVerificationTab } from './AdminLegalAndVerificationTab';
import { Headphones } from 'lucide-react';

interface AdminDashboardProps {
  onBackToApp: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToApp }) => {
  const { 
    allUsers, 
    tasks, 
    withdrawals, 
    taskSubmissions, 
    vipPayments,
    supportMessages,
    adminLogout, 
    systemSettings,
    t 
  } = useApp();

  const [activeAdminTab, setActiveAdminTab] = useState<
    'overview' | 'legal_verification' | 'coins_customizer' | 'ai_customizer' | 'ad_monetization' | 'investment_management' | 'users' | 'memberships' | 'pending_payments' | 'tasks' | 'wallet' | 'withdrawals' | 'notifications' | 'feedback' | 'settings' | 'task_analytics' | 'apk_management' | 'support'
  >('overview');

  const supportOpenCount = supportMessages.filter(m => m.status === 'open' || m.status === 'in_progress').length;

  // The 9 required core statistics
  const totalUsersCount = allUsers.length;
  const activeUsersCount = allUsers.filter(u => u.isActive).length;
  const premiumUsersCount = allUsers.filter(u => u.membershipTier !== 'basic').length;
  const totalCoinsInCirculation = allUsers.reduce((sum, u) => sum + u.coins, 0);
  const totalVipPurchasesCount = vipPayments.filter(p => p.status === 'approved').length;
  const pendingVipCount = vipPayments.filter(p => p.status === 'pending').length;
  const totalTasksCount = tasks.length;
  const completedTasksCount = taskSubmissions.filter(s => s.status === 'completed').length;
  const totalWithdrawalsCount = withdrawals.length;
  const pendingWdCount = withdrawals.filter(w => w.status === 'pending').length;
  
  const pendingWdAmount = withdrawals
    .filter(w => w.status === 'pending')
    .reduce((sum, w) => sum + w.amountCoins, 0);

  const currencySymbol = systemSettings?.currencySymbol || '₹';
  const coinsPerCurrency = systemSettings?.coinsPerCurrencyUnit || 1;

  // SLA and Withdrawal Analytics calculations
  const pendingWithdrawalsList = withdrawals.filter(w => w.status === 'pending');
  const pendingWdPayoutTotalCoins = pendingWithdrawalsList.reduce((sum, w) => sum + w.amountCoins, 0);
  const pendingWdPayoutTotalCurrency = pendingWithdrawalsList.reduce((sum, w) => sum + w.amountCurrency, 0);

  const approvedWds = withdrawals.filter(w => w.status === 'approved' && w.processedAt);
  let averageApprovalTimeText = '1.5 hours';
  if (approvedWds.length > 0) {
    const totalMs = approvedWds.reduce((sum, w) => {
      const req = new Date(w.requestedAt).getTime();
      const proc = new Date(w.processedAt!).getTime();
      return sum + Math.max(0, proc - req);
    }, 0);
    const avgMs = totalMs / approvedWds.length;
    const avgMinutes = avgMs / (1000 * 60);
    if (avgMinutes < 60) {
      averageApprovalTimeText = `${Math.round(avgMinutes)} minutes`;
    } else {
      const avgHours = avgMinutes / 60;
      if (avgHours < 24) {
        averageApprovalTimeText = `${avgHours.toFixed(1)} hours`;
      } else {
        const avgDays = avgHours / 24;
        averageApprovalTimeText = `${avgDays.toFixed(1)} days`;
      }
    }
  }

  const handleAdminSignOut = () => {
    adminLogout();
    onBackToApp();
  };

  // Admin Management Sections including Coins Customizer, AI Studio & Play Seen Ad Revenue
  const tabs = [
    { id: 'overview', label: 'Stats Overview', icon: TrendingUp },
    { id: 'legal_verification', label: '⚖️ Legal, Licences & KYC', icon: ShieldCheck, highlight: true },
    { id: 'coins_customizer', label: '🪙 Coins Customizer', icon: Coins, highlight: true },
    { id: 'ai_customizer', label: '🤖 AI Studio & Customizer', icon: Sparkles, highlight: true },
    { id: 'ad_monetization', label: '📺 Play Seen & Ad Money', icon: DollarSign, highlight: true },
    { id: 'investment_management', label: '🏆 Gold & Silver & Coupons', icon: Award, highlight: true },
    { id: 'tasks', label: 'Task Management', icon: CheckSquare },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'memberships', label: 'VIP Purchase Management', icon: Sparkles },
    { id: 'pending_payments', label: `Payment Verification (${pendingVipCount})`, icon: CreditCard, highlight: pendingVipCount > 0 },
    { id: 'wallet', label: 'Wallet Management', icon: Wallet },
    { id: 'withdrawals', label: `Withdrawal Management (${pendingWdCount})`, icon: Clock, highlight: pendingWdCount > 0 },
    { id: 'apk_management', label: 'APK Management', icon: Smartphone },
    { id: 'feedback', label: 'App Feedback & Surveys', icon: MessageSquareHeart },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'settings', label: 'App Settings', icon: Settings },
    { id: 'support', label: `🎧 Support Tickets (${supportOpenCount})`, icon: Headphones, highlight: supportOpenCount > 0 },
    { id: 'task_analytics', label: '30D Trends & Payouts', icon: TrendingUp },
  ];

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-300">
      
      {/* Top Admin Header with Logout Button */}
      <div className="p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-purple-600/30 text-purple-400 border border-purple-500/40 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tight text-white">
                {t('adminDashboard')}
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Authorized Session
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Task Earn Pro • Management & Operations Console
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onBackToApp}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Public App View</span>
          </button>
          
          {/* Admin Logout Button */}
          <button
            onClick={handleAdminSignOut}
            className="px-3.5 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout Admin</span>
          </button>
        </div>
      </div>

      {/* Tab Navigation pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeAdminTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveAdminTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20 scale-[1.02]'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${tab.highlight && !isActive ? 'text-amber-500 animate-bounce' : ''}`} />
              <span>{tab.label}</span>
              {tab.highlight && (
                <span className="w-2 h-2 rounded-full bg-amber-400" />
              )}
            </button>
          );
        })}
      </div>

      {/* Overview Stats Tab */}
      {activeAdminTab === 'overview' && (
        <div className="space-y-6">
          
          {/* 9 Required Core Stat Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-3.5">
            
            {/* 1. Total Users */}
            <div 
              onClick={() => setActiveAdminTab('users')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-purple-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Total Users</span>
                <Users className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-slate-900 dark:text-slate-100">{totalUsersCount}</p>
              <span className="text-[10px] text-purple-400 font-bold block">Registered Accounts</span>
            </div>

            {/* 2. Active Users */}
            <div 
              onClick={() => setActiveAdminTab('users')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-emerald-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Active Users</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-emerald-500">{activeUsersCount}</p>
              <span className="text-[10px] text-emerald-400 font-bold block">Active Status</span>
            </div>

            {/* 3. VIP Users */}
            <div 
              onClick={() => setActiveAdminTab('memberships')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-amber-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">VIP Users</span>
                <Sparkles className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-amber-500">{premiumUsersCount}</p>
              <span className="text-[10px] text-amber-400 font-bold block">Silver / Gold / Diamond</span>
            </div>

            {/* 4. Total Wallet Balance */}
            <div 
              onClick={() => setActiveAdminTab('wallet')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-amber-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Total Wallet Balance</span>
                <Coins className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-xl font-black text-amber-400">🪙 {totalCoinsInCirculation.toLocaleString()}</p>
              <span className="text-[10px] text-emerald-400 font-semibold block">
                ≈ {currencySymbol}{(totalCoinsInCirculation / coinsPerCurrency).toFixed(2)} in circulation
              </span>
            </div>

            {/* 5. Total VIP Purchases */}
            <div 
              onClick={() => setActiveAdminTab('memberships')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-pink-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Total VIP Purchases</span>
                <CreditCard className="w-4 h-4 text-pink-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-pink-400">{totalVipPurchasesCount}</p>
              <span className="text-[10px] text-slate-400 font-bold block">Approved Plan Purchases</span>
            </div>

            {/* 6. Pending Payment Verifications */}
            <div 
              onClick={() => setActiveAdminTab('pending_payments')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-amber-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Pending Payment Verifications</span>
                <Clock className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-amber-400">{pendingVipCount}</p>
              <span className="text-[10px] text-amber-400 font-bold block">
                {pendingVipCount > 0 ? 'Requires Admin Approval' : 'All Verified'}
              </span>
            </div>

            {/* 7. Total Tasks */}
            <div 
              onClick={() => setActiveAdminTab('tasks')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-blue-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Total Tasks</span>
                <CheckSquare className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-blue-500">{totalTasksCount}</p>
              <span className="text-[10px] text-slate-400 font-bold block">Available Tasks in System</span>
            </div>

            {/* 8. Completed Tasks */}
            <div 
              onClick={() => setActiveAdminTab('task_analytics')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-emerald-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Completed Tasks</span>
                <FileCheck className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-emerald-500">{completedTasksCount}</p>
              <span className="text-[10px] text-slate-400 font-bold block">Verified User Submissions</span>
            </div>

            {/* 9. Withdraw Requests */}
            <div 
              onClick={() => setActiveAdminTab('withdrawals')}
              className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-1 hover:border-rose-500/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[10px]">Withdraw Requests</span>
                <Clock className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
              </div>
              <p className="text-2xl font-black text-rose-500">{totalWithdrawalsCount}</p>
              <span className="text-[10px] text-rose-400 font-bold block">
                {pendingWdCount} Pending Requests ({pendingWdAmount} Coins)
              </span>
            </div>

          </div>

          {/* Quick Action Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            
            {/* Pending Payments Quick Alert */}
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-emerald-500" />
                  <span>Pending VIP Payments</span>
                </h3>
                <button
                  onClick={() => setActiveAdminTab('pending_payments')}
                  className="text-xs font-semibold text-purple-600 dark:text-purple-400 hover:underline cursor-pointer"
                >
                  Review All ({pendingVipCount})
                </button>
              </div>

              {pendingVipCount === 0 ? (
                <p className="text-xs text-slate-400 py-4 text-center">No pending VIP payment verification requests.</p>
              ) : (
                <div className="space-y-2">
                  {vipPayments.filter(p => p.status === 'pending').slice(0, 3).map((p) => (
                    <div key={p.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-slate-800 dark:text-slate-200">{p.userName}</p>
                        <p className="text-[11px] text-slate-400 font-mono">{p.planName} • UTR: {p.utrNumber}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">
                          ₹{p.amountRupees}
                        </span>
                        <button
                          type="button"
                          onClick={() => setActiveAdminTab('pending_payments')}
                          className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] cursor-pointer"
                        >
                          Review
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Pending Withdrawals Quick Alert */}
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-500" />
                  <span>Pending Withdrawal Queue</span>
                </h3>
                <button
                  onClick={() => setActiveAdminTab('withdrawals')}
                  className="text-xs font-semibold text-purple-600 dark:text-purple-400 hover:underline cursor-pointer"
                >
                  View All ({pendingWdCount})
                </button>
              </div>

              {pendingWdCount === 0 ? (
                <p className="text-xs text-slate-400 py-4 text-center">No pending withdrawal requests.</p>
              ) : (
                <div className="space-y-2">
                  {withdrawals.filter(w => w.status === 'pending').slice(0, 3).map((w) => (
                    <div key={w.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-slate-800 dark:text-slate-200">{w.userName}</p>
                        <p className="text-[11px] text-slate-400">{w.method.toUpperCase()} • {w.accountDetails}</p>
                      </div>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {w.amountCoins} Coins (${w.amountCurrency})
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Platform Health and Policy Card */}
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Legitimate System Compliance Status</span>
              </h3>
              <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                <p className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                  <span>Google Tasks sync active with official Google Workspace OAuth scopes.</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                  <span>External partner tasks correctly tagged with "External Task" indicators.</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                  <span>VIP manual UPI verification workflow with UTR check active.</span>
                </p>
              </div>
            </div>

          </div>

          {/* New Analytical Card: Payout Liability & SLA Turnaround Metrics */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/20 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-white">Withdrawal Payout & SLA Turnaround</h3>
                  <p className="text-[10px] text-slate-400">Live analytical metrics of withdrawal processing speed and pending liquidity payout.</p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1 animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                SLA Status: Healthy
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Analytic Card 1: Pending Withdrawal Payout Total */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700/60 transition-all flex items-center justify-between gap-3 group">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                    Pending Withdrawal Payout Total
                  </span>
                  <div className="text-xl sm:text-2xl font-black text-white group-hover:text-amber-300 transition-colors">
                    🪙 {pendingWdPayoutTotalCoins.toLocaleString()} <span className="text-xs font-normal text-slate-400">Coins</span>
                  </div>
                  <p className="text-[10px] text-emerald-400 font-semibold block">
                    ≈ {currencySymbol}{pendingWdPayoutTotalCurrency.toFixed(2)} {systemSettings.currencyCode} Liability
                  </p>
                </div>
                <div className="px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 text-xs font-black shrink-0">
                  {pendingWithdrawalsList.length} Requests
                </div>
              </div>

              {/* Analytic Card 2: Average Withdrawal Approval Time */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700/60 transition-all flex items-center justify-between gap-3 group">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                    Average Withdrawal Approval Time
                  </span>
                  <div className="text-xl sm:text-2xl font-black text-emerald-400 group-hover:text-emerald-300 transition-colors">
                    ⏱️ {averageApprovalTimeText}
                  </div>
                  <p className="text-[10px] text-slate-400 font-semibold block">
                    SLA Window: 2.0 hours maximum
                  </p>
                </div>
                <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-black shrink-0">
                  99.4% On-Time
                </div>
              </div>
            </div>
          </div>

          {/* 30-Day Task Completion & Payout Optimization Visualization on Overview */}
          <div className="pt-2">
            <TaskCompletionTrendsChart />
          </div>

        </div>
      )}

      {/* Admin Management Sub-Tabs */}
      {activeAdminTab === 'legal_verification' && <AdminLegalAndVerificationTab />}
      {activeAdminTab === 'coins_customizer' && <AdminCoinsTab />}
      {activeAdminTab === 'ai_customizer' && <AdminAiStudioTab />}
      {activeAdminTab === 'ad_monetization' && <AdminAdMonetizationTab />}
      {activeAdminTab === 'investment_management' && <AdminInvestmentTab />}
      {activeAdminTab === 'tasks' && <AdminTasksTab />}
      {activeAdminTab === 'users' && <AdminUsersTab />}
      {activeAdminTab === 'memberships' && <AdminMembershipsTab />}
      {activeAdminTab === 'pending_payments' && <AdminVipPaymentsTab />}
      {activeAdminTab === 'wallet' && <AdminWalletTab />}
      {activeAdminTab === 'withdrawals' && <AdminWithdrawalsTab />}
      {activeAdminTab === 'apk_management' && <AdminApkTab />}
      {activeAdminTab === 'feedback' && <AdminFeedbackTab />}
      {activeAdminTab === 'notifications' && <AdminNotificationsTab />}
      {activeAdminTab === 'settings' && <AdminSettingsTab />}
      {activeAdminTab === 'support' && <AdminSupportTab />}
      {activeAdminTab === 'task_analytics' && <TaskCompletionTrendsChart />}

    </div>
  );
};
