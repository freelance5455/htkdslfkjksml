import React, { useState } from 'react';
import { 
  Award, 
  Sparkles, 
  Plus, 
  Check, 
  ShieldCheck, 
  Trash2, 
  RefreshCw, 
  TrendingUp, 
  Users, 
  Tag,
  DollarSign,
  Eye,
  X,
  CheckCircle2,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

export const AdminInvestmentTab: React.FC = () => {
  const { 
    goldPricePerGram, 
    silverPricePerGram, 
    investmentOrders, 
    kycRecords, 
    investmentCoupons, 
    createCoupon, 
    toggleCouponActive,
    updateSystemSettings 
  } = useApp();

  const [newCode, setNewCode] = useState('GOLD50');
  const [newDiscount, setNewDiscount] = useState(50);
  const [minInvest, setMinInvest] = useState(100);
  const [usageLimit, setUsageLimit] = useState(500);

  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [viewingScreenshot, setViewingScreenshot] = useState<string | null>(null);

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    createCoupon({
      code: newCode.trim().toUpperCase(),
      flatDiscountINR: newDiscount,
      minInvestmentINR: minInvest,
      usageLimit: usageLimit,
      isActive: true,
      expiresAt: '2026-12-31T23:59:59Z',
    });
    setSuccessMsg(`Promotional coupon ${newCode.toUpperCase()} created successfully!`);
    confetti({ particleCount: 40, spread: 50 });
    setTimeout(() => setSuccessMsg(null), 3000);
    setNewCode('');
  };

  const totalVolumeINR = investmentOrders.reduce((sum, o) => sum + o.amountINR, 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-300 text-xs">
      
      {/* Header Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-yellow-950/80 border border-amber-500/30 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0 shadow-lg text-xl">
            🏆
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight text-white">
              Gold & Silver Investment & Aadhaar KYC Admin
            </h2>
            <p className="text-xs text-slate-300">
              Review user gold/silver buy orders, Aadhaar card KYC verification status, payment screenshot proofs (Payment Seen), and short approve transactions.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="p-3 rounded-2xl bg-black/40 border border-amber-500/20 text-right">
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Total Volume</span>
            <span className="text-sm font-black text-amber-400">₹{totalVolumeINR.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Live Market Pricing Control */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-white flex items-center gap-2">
              <span>🏆</span>
              <span>Gold Live Price (24K / gram)</span>
            </h3>
            <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-mono text-[10px] font-bold">
              ₹{goldPricePerGram}/g
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Gold pricing is synced with international bullion markets with zero markup.
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-white flex items-center gap-2">
              <span>🥈</span>
              <span>Silver Live Price (99.9% / gram)</span>
            </h3>
            <span className="px-2 py-0.5 rounded-md bg-slate-300/20 text-slate-200 font-mono text-[10px] font-bold">
              ₹{silverPricePerGram}/g
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Silver pricing reflects industrial demand and bullion index rates.
          </p>
        </div>

      </div>

      {/* Investment Orders & Aadhaar KYC Verification Feed */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="text-sm font-black text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <span>Gold Buy & Silver Investment Orders with Aadhaar KYC & Payment Seen ({investmentOrders.length})</span>
          </h3>
          {successMsg && (
            <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>{successMsg}</span>
            </span>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase font-bold">
                <th className="py-2.5 px-3">Order & Date</th>
                <th className="py-2.5 px-3">User Name & ID</th>
                <th className="py-2.5 px-3">Aadhaar KYC Status</th>
                <th className="py-2.5 px-3">Metal / Amount</th>
                <th className="py-2.5 px-3">Payment Seen (Screenshot)</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Short Approved</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium text-slate-300">
              {investmentOrders.map((ord) => {
                const userKyc = kycRecords.find(k => k.userId === ord.userId);
                const isKycVerified = userKyc && userKyc.status === 'verified';

                return (
                  <tr key={ord.id} className="hover:bg-slate-950/40">
                    <td className="py-3 px-3">
                      <span className="font-mono font-bold text-amber-400 block">{ord.id}</span>
                      <span className="text-[10px] text-slate-400">{new Date(ord.createdAt).toLocaleDateString()} {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-bold text-white block">{ord.userName}</span>
                      <span className="font-mono text-[10px] text-slate-400">ID: {ord.userId}</span>
                    </td>
                    <td className="py-3 px-3">
                      {isKycVerified ? (
                        <div className="space-y-0.5">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                            <ShieldCheck className="w-3 h-3 text-emerald-400" />
                            Aadhaar Verified
                          </span>
                          <span className="font-mono text-[10px] text-slate-400 block">{userKyc?.aadhaarMasked || 'XXXX-XXXX-1234'}</span>
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                          KYC Pending
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <span className="uppercase font-black text-amber-400 block">{ord.metalType} ({ord.grams}g)</span>
                      <span className="font-bold text-white">₹{ord.amountINR.toLocaleString()}</span>
                    </td>
                    <td className="py-3 px-3">
                      {ord.screenshotUrl ? (
                        <button
                          type="button"
                          onClick={() => setViewingScreenshot(ord.screenshotUrl || null)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-[10px] cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5 text-amber-400" />
                          <span>Payment Seen</span>
                        </button>
                      ) : (
                        <span className="text-[10px] text-slate-500 italic">No attachment</span>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {ord.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-600 text-white font-bold text-[10px] shadow-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                        Short Approved
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Coupon Creation & Management */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="text-sm font-black text-white flex items-center gap-2">
            <Tag className="w-4 h-4 text-amber-400" />
            <span>Investment Promotional Coupons (e.g. TODAY60)</span>
          </h3>
        </div>

        <form onSubmit={handleCreateCoupon} className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-2">
          <div>
            <label className="block font-bold text-slate-300 mb-1">Coupon Code</label>
            <input
              type="text"
              required
              value={newCode}
              onChange={(e) => setNewCode(e.target.value)}
              placeholder="TODAY60"
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono uppercase font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-300 mb-1">Flat Discount (₹)</label>
            <input
              type="number"
              required
              min={1}
              value={newDiscount}
              onChange={(e) => setNewDiscount(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-300 mb-1">Min Invest (₹)</label>
            <input
              type="number"
              required
              min={10}
              value={minInvest}
              onChange={(e) => setMinInvest(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-300 mb-1">Usage Limit</label>
            <input
              type="number"
              required
              min={1}
              value={usageLimit}
              onChange={(e) => setUsageLimit(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black flex items-center justify-center gap-1 cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Create Coupon</span>
            </button>
          </div>
        </form>

        <div className="overflow-x-auto pt-2">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase font-bold">
                <th className="py-2 px-3">Code</th>
                <th className="py-2 px-3">Discount</th>
                <th className="py-2 px-3">Min Invest</th>
                <th className="py-2 px-3">Usage Stats</th>
                <th className="py-2 px-3">Status</th>
                <th className="py-2 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium text-slate-300">
              {investmentCoupons.map((c) => (
                <tr key={c.id} className="hover:bg-slate-950/40">
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-400">{c.code}</td>
                  <td className="py-2.5 px-3">₹{c.flatDiscountINR || c.discountPercent}</td>
                  <td className="py-2.5 px-3">₹{c.minInvestmentINR}</td>
                  <td className="py-2.5 px-3 font-mono">{c.timesUsed} / {c.usageLimit} used</td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                      c.isActive ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}>
                      {c.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      type="button"
                      onClick={() => toggleCouponActive(c.id)}
                      className={`px-3 py-1 rounded-lg font-bold text-[11px] cursor-pointer ${
                        c.isActive ? 'bg-rose-500/20 text-rose-300 hover:bg-rose-500/30' : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                      }`}
                    >
                      {c.isActive ? 'Disable' : 'Enable'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Screenshot / Payment Seen Modal Viewer */}
      {viewingScreenshot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl relative space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>Payment Seen — Attachment Proof</span>
              </h3>
              <button
                onClick={() => setViewingScreenshot(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="w-full max-h-[65vh] overflow-auto bg-black rounded-2xl border border-slate-800 p-2 flex items-center justify-center">
              <img src={viewingScreenshot} alt="Payment Proof" className="max-w-full h-auto rounded-xl object-contain" />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setViewingScreenshot(null)}
                className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black cursor-pointer text-xs"
              >
                Close Viewer
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
