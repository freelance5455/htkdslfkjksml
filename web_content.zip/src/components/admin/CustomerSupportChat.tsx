import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  Send,
  Search,
  Filter,
  CheckCircle,
  AlertCircle,
  Clock,
  Sparkles,
  Gift,
  Coins,
  Gem,
  DollarSign,
  User,
  Shield,
  ShieldCheck,
  CheckCheck,
  RefreshCw,
  X,
  Phone,
  Mail,
  HelpCircle,
  ChevronRight,
  Smile,
  Zap,
  CornerDownLeft,
  ExternalLink,
  MessageCircle,
} from 'lucide-react';
import { SupportTicket, SupportMessage, SupportCategory, UserProfile, TransactionRecord } from '../../types';
import { soundFX } from '../../utils/soundEffects';
import { saveSupportTicketToFirestore, saveAuditRecordToFirestore } from '../../utils/firebaseSync';

interface CustomerSupportChatProps {
  currentUser: UserProfile;
  tickets: SupportTicket[];
  onUpdateTickets: (tickets: SupportTicket[]) => void;
  onUpdateCurrentUser?: (u: UserProfile) => void;
  onAddAuditTransaction?: (tx: TransactionRecord) => void;
  showToast: (msg: string) => void;
}

export const CustomerSupportChat: React.FC<CustomerSupportChatProps> = ({
  currentUser,
  tickets,
  onUpdateTickets,
  onUpdateCurrentUser,
  onAddAuditTransaction,
  showToast,
}) => {
  // Selected active ticket
  const [selectedTicketId, setSelectedTicketId] = useState<string>(tickets[0]?.id || 'TICK-101');

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | SupportCategory>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'WAITING' | 'RESOLVED'>('ALL');

  // Chat message input
  const [replyText, setReplyText] = useState('');
  const [isSending, setIsSending] = useState(false);

  // Gemini AI Smart Reply state
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiGeneratedReply, setAiGeneratedReply] = useState<{
    text: string;
    action?: string;
    compensation?: number | null;
    confidence?: number;
  } | null>(null);

  // Quick Compensation Modal
  const [showCompensationModal, setShowCompensationModal] = useState(false);
  const [compensationAmount, setCompensationAmount] = useState(500);
  const [compensationCurrency, setCompensationCurrency] = useState<'COINS' | 'GEMS'>('COINS');
  const [compensationReason, setCompensationReason] = useState('تعويض فوري من خدمة العملاء عن مشكلة في جولة سابقة');

  // Emoji picker toggle
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Auto-scroll ref
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const selectedTicket = tickets.find((t) => t.id === selectedTicketId) || tickets[0];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedTicket?.messages]);

  // Mark messages as read by admin when switching tickets
  useEffect(() => {
    if (!selectedTicketId) return;
    const current = tickets.find((t) => t.id === selectedTicketId);
    if (current && current.unreadAdminCount > 0) {
      const updated = tickets.map((t) => {
        if (t.id === selectedTicketId) {
          return {
            ...t,
            unreadAdminCount: 0,
            messages: t.messages.map((m) => (m.senderType === 'PLAYER' ? { ...m, isRead: true } : m)),
          };
        }
        return t;
      });
      onUpdateTickets(updated);
    }
  }, [selectedTicketId]);

  // Filtered tickets
  const filteredTickets = tickets.filter((t) => {
    const matchesSearch =
      t.playerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.playerId.includes(searchQuery);

    const matchesCategory = categoryFilter === 'ALL' || t.category === categoryFilter;

    let matchesStatus = true;
    if (statusFilter === 'WAITING') {
      matchesStatus = t.status === 'OPEN' || t.unreadAdminCount > 0;
    } else if (statusFilter === 'RESOLVED') {
      matchesStatus = t.status === 'RESOLVED' || t.status === 'CLOSED';
    }

    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Handle Send Reply
  const handleSendReply = async (customMessage?: string) => {
    const textToSend = (customMessage || replyText).trim();
    if (!textToSend || !selectedTicket) return;

    setIsSending(true);
    soundFX.playButtonClick();

    const newMsg: SupportMessage = {
      id: `MSG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      ticketId: selectedTicket.id,
      senderType: 'ADMIN',
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      senderRole: `إدارة TABEONA (${currentUser.role})`,
      text: textToSend,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      isRead: false,
    };

    const updatedTicket: SupportTicket = {
      ...selectedTicket,
      status: selectedTicket.status === 'RESOLVED' ? 'IN_PROGRESS' : selectedTicket.status,
      updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      lastMessageSnippet: textToSend,
      unreadAdminCount: 0,
      unreadPlayerCount: selectedTicket.unreadPlayerCount + 1,
      assignedStaffName: currentUser.name,
      messages: [...selectedTicket.messages, newMsg],
    };

    const updatedAll = tickets.map((t) => (t.id === selectedTicket.id ? updatedTicket : t));
    onUpdateTickets(updatedAll);
    setReplyText('');
    setAiGeneratedReply(null);
    setIsSending(false);

    // Save to Firestore
    saveSupportTicketToFirestore(updatedTicket);
    showToast(`✉️ تم إرسال الرد المباشر للاعب ${selectedTicket.playerName}`);
  };

  // Pre-set Quick Responses
  const quickResponses = [
    {
      title: '👋 ترحيب رسمي',
      text: `أهلاً بك عزيزنا ${selectedTicket?.playerName || 'اللاعب'} في خدمة عملاء TABEONA الملكية! يسعدنا مساعدتك والرد على استفسارك على الفور.`,
    },
    {
      title: '💰 تأكيد الكاشير',
      text: 'تمت مراجعة عملية الكاشير وتدقيقها في السجل المالي، وتم اعتماد العملية بنجاح. يرجى تحديث شاشة المحفظة لتأكيد الرصيد.',
    },
    {
      title: '⚙️ تعويض فني',
      text: 'نعتذر بشدة عن انقطاع الاتصال خلال الجولة، لقد قمنا بإضافة تعويض مالي مباشر إلى محفظتك تقديراً لتواجدك معنا.',
    },
    {
      title: '🛡️ توثيق الحساب',
      text: 'تم فحص مستندات توثيق الهوية KYC بنجاح واعتماد حسابك ضمن قائمة الحسابات الموثقة والآمنة 100%.',
    },
    {
      title: '✅ حل التذكرة',
      text: 'يسعدنا أن المشكلة قد حُلّت بالكامل! إذا كان لديك أي استفسار آخر، فريق دعم TABEONA في خدمتك دائماً على مدار الساعة.',
    },
  ];

  // Request Gemini AI Smart Reply
  const handleGenerateAiReply = async () => {
    if (!selectedTicket) return;
    setIsAiGenerating(true);
    soundFX.playButtonClick();

    try {
      const lastPlayerMsg = [...selectedTicket.messages]
        .reverse()
        .find((m) => m.senderType === 'PLAYER')?.text || selectedTicket.subject;

      const res = await fetch('/api/gemini/support-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticket: {
            subject: selectedTicket.subject,
            category: selectedTicket.category,
            playerName: selectedTicket.playerName,
            playerVip: selectedTicket.playerVip,
          },
          lastPlayerMessage: lastPlayerMsg,
          chatHistory: selectedTicket.messages.map((m) => ({
            sender: m.senderName,
            type: m.senderType,
            text: m.text,
            time: m.timestamp,
          })),
          tone: 'احترافية ملكية، لبقة وسريعة الحلول',
        }),
      });

      const data = await res.json();
      if (data.success && data.replyData?.suggestedReply) {
        setAiGeneratedReply({
          text: data.replyData.suggestedReply,
          action: data.replyData.suggestedAction,
          compensation: data.replyData.recommendedCompensationAmount,
          confidence: data.replyData.confidenceScore || 95,
        });
        soundFX.playVictoryFanfare();
        showToast('✨ تم توليد الرد الذكي بنجاح بواسطة Gemini AI!');
      } else {
        // Fallback realistic response
        setAiGeneratedReply({
          text: `أهلاً بك عزيزنا ${selectedTicket.playerName}، نشكر تواصلك مع الدعم الإداري لمنصة TABEONA. لقد قمنا بالاطلاع على تفاصيل طلبك بخصوص "${selectedTicket.subject}"، ويجري العمل على اتخاذ الإجراء اللازم فوراً لضمان أفضل تجربة لعب لك.`,
          confidence: 88,
        });
        showToast('تم إعداد الرد المقترح للاعب.');
      }
    } catch (err) {
      console.error('Error generating AI reply:', err);
      setAiGeneratedReply({
        text: `أهلاً بك عزيزنا ${selectedTicket.playerName}، يسعدنا خدمتك في TABEONA بخصوص استفسارك. يرجى الاطمئنان إلى أن طلبك قيد المتابعة الفورية من إدارة العمليات.`,
        confidence: 85,
      });
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Toggle Ticket Status
  const handleUpdateTicketStatus = (newStatus: SupportTicket['status']) => {
    if (!selectedTicket) return;
    soundFX.playButtonClick();

    const systemMsg: SupportMessage = {
      id: `SYS-${Date.now()}`,
      ticketId: selectedTicket.id,
      senderType: 'SYSTEM',
      senderId: 'SYSTEM',
      senderName: 'النظام الآلي',
      text: `قام المشرف ${currentUser.name} بتحديث حالة التذكرة إلى: ${
        newStatus === 'RESOLVED' ? 'محلولة بنجاح ✅' : newStatus === 'IN_PROGRESS' ? 'قيد المعالجة ⏳' : 'مفتوحة 🔔'
      }`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      isRead: true,
      actionTaken: newStatus === 'RESOLVED' ? { type: 'TICKET_RESOLVED', details: 'تم إغلاق التذكرة' } : undefined,
    };

    const updated: SupportTicket = {
      ...selectedTicket,
      status: newStatus,
      updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      messages: [...selectedTicket.messages, systemMsg],
    };

    const updatedAll = tickets.map((t) => (t.id === selectedTicket.id ? updated : t));
    onUpdateTickets(updatedAll);
    saveSupportTicketToFirestore(updated);
    showToast(`تم تغيير حالة التذكرة إلى: ${newStatus}`);
  };

  // Execute Quick Financial Compensation
  const handleSendCompensation = () => {
    if (!selectedTicket || compensationAmount <= 0) return;
    soundFX.playVictoryFanfare();

    const txId = `TX-COMP-${Date.now().toString().slice(-6)}`;
    const systemMsg: SupportMessage = {
      id: `SYS-${Date.now()}`,
      ticketId: selectedTicket.id,
      senderType: 'SYSTEM',
      senderId: currentUser.id,
      senderName: `دعم العملاء (${currentUser.name})`,
      text: `🎁 تم منح اللاعب تعويضاً مالياً فورياً بمقدار ${compensationAmount.toLocaleString()} ${
        compensationCurrency === 'COINS' ? 'كوينز ذهبية 🪙' : 'جوهرة زمردية 💎'
      }. سبب التعويض: ${compensationReason}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      isRead: false,
      actionTaken: {
        type: compensationCurrency === 'COINS' ? 'COMPENSATION_COINS' : 'COMPENSATION_GEMS',
        details: compensationReason,
        amount: compensationAmount,
      },
    };

    // If target player is current user, update current user balance directly
    if (selectedTicket.playerId === currentUser.id && onUpdateCurrentUser) {
      onUpdateCurrentUser({
        ...currentUser,
        coins: compensationCurrency === 'COINS' ? currentUser.coins + compensationAmount : currentUser.coins,
        gems: compensationCurrency === 'GEMS' ? currentUser.gems + compensationAmount : currentUser.gems,
      });
    }

    // Add audit ledger record
    const auditTx: TransactionRecord = {
      transactionId: txId,
      playerId: selectedTicket.playerId,
      playerName: selectedTicket.playerName,
      cashierOrAdminId: currentUser.id,
      amount: compensationAmount,
      currencyType: compensationCurrency,
      balanceBefore: selectedTicket.playerBalance ? selectedTicket.playerBalance.coins : 5000,
      balanceAfter: (selectedTicket.playerBalance ? selectedTicket.playerBalance.coins : 5000) + compensationAmount,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: 'COMPLETED',
      sourceMethod: 'ADMIN_OVERRIDE',
      referenceNote: `تعويض دعم العملاء: ${compensationReason} (تذكرة ${selectedTicket.id})`,
      auditHash: `sha256:comp_${txId}_hash`,
      ledgerSequence: Math.floor(1000 + Math.random() * 9000),
    };

    if (onAddAuditTransaction) {
      onAddAuditTransaction(auditTx);
    }
    saveAuditRecordToFirestore(auditTx);

    // Update ticket
    const updated: SupportTicket = {
      ...selectedTicket,
      updatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      messages: [...selectedTicket.messages, systemMsg],
    };

    const updatedAll = tickets.map((t) => (t.id === selectedTicket.id ? updated : t));
    onUpdateTickets(updatedAll);
    saveSupportTicketToFirestore(updated);

    setShowCompensationModal(false);
    showToast(`✅ تم إضافة التعويض ${compensationAmount} ${compensationCurrency} وتوثيقه في التدقيق!`);
  };

  const popularEmojis = ['👍', '👑', '💰', '🃏', '❤️', '🌟', '🤝', '🙏', '✅', '🛡️', '⚡', '🔥'];

  return (
    <div className="flex flex-col h-[780px] max-h-[85vh] bg-[#030a06] border border-amber-900/60 rounded-3xl overflow-hidden shadow-2xl relative">
      {/* ========================================================
          TOP STATUS BAR
         ======================================================== */}
      <div className="bg-gradient-to-r from-[#05170d] via-[#092b18] to-[#04120a] border-b border-amber-500/30 px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500/30 to-emerald-600/30 border border-amber-400/50 flex items-center justify-center shadow-inner">
            <MessageSquare className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <h3 className="text-base font-black text-amber-200 flex items-center gap-2">
              مركز دردشة دعم العملاء واستفسارات اللاعبين
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                مباشر 24/7
              </span>
            </h3>
            <p className="text-xs text-gray-400">
              واجهة تفاعلية فورية تمكن الإدارة من التجاوب مع استفسارات اللاعبين، حل المشاكل، وتقديم التعويضات
            </p>
          </div>
        </div>

        {/* Quick Stats Pills */}
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 rounded-xl bg-black/40 border border-amber-500/20 text-xs flex items-center gap-1.5 text-gray-300">
            <span className="text-amber-400 font-bold">{tickets.length}</span>
            <span>تذكرة إجمالية</span>
          </div>
          <div className="px-3 py-1 rounded-xl bg-red-950/40 border border-red-500/30 text-xs flex items-center gap-1.5 text-red-300">
            <span className="font-bold text-red-400">
              {tickets.reduce((acc, t) => acc + t.unreadAdminCount, 0)}
            </span>
            <span>رسائل غير مقروءة</span>
          </div>
          <div className="px-3 py-1 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs flex items-center gap-1.5 text-emerald-300">
            <span className="font-bold text-emerald-400">
              {tickets.filter((t) => t.status === 'RESOLVED').length}
            </span>
            <span>محلولة</span>
          </div>
        </div>
      </div>

      {/* ========================================================
          MAIN SPLIT VIEW: TICKETS LIST (LEFT) & CHAT CONVERSATION (RIGHT)
         ======================================================== */}
      <div className="flex-1 flex overflow-hidden">
        {/* ==========================================
            1. TICKETS DIRECTORY (القائمة الجانبية للتذاكر)
           ========================================== */}
        <div className="w-80 md:w-96 border-l border-amber-950/60 bg-[#040e08]/90 flex flex-col shrink-0">
          {/* Search & Filters */}
          <div className="p-3.5 border-b border-amber-950/60 flex flex-col gap-2.5">
            <div className="relative">
              <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="ابحث باسم اللاعب، رقم التذكرة أو الـ ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-3 pr-9 py-2 bg-black/50 border border-amber-950 rounded-xl text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-amber-500/50"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] no-scrollbar">
              <button
                onClick={() => setStatusFilter('ALL')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all shrink-0 ${
                  statusFilter === 'ALL'
                    ? 'bg-amber-500 text-black shadow-sm'
                    : 'bg-black/40 text-gray-400 hover:text-white border border-amber-950'
                }`}
              >
                الكل ({tickets.length})
              </button>
              <button
                onClick={() => setStatusFilter('WAITING')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all shrink-0 ${
                  statusFilter === 'WAITING'
                    ? 'bg-red-500 text-white shadow-sm'
                    : 'bg-black/40 text-gray-400 hover:text-white border border-amber-950'
                }`}
              >
                بانتظار الرد ({tickets.filter((t) => t.unreadAdminCount > 0 || t.status === 'OPEN').length})
              </button>
              <button
                onClick={() => setStatusFilter('RESOLVED')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all shrink-0 ${
                  statusFilter === 'RESOLVED'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-black/40 text-gray-400 hover:text-white border border-amber-950'
                }`}
              >
                المحلولة
              </button>
            </div>
          </div>

          {/* Tickets List */}
          <div className="flex-1 overflow-y-auto divide-y divide-amber-950/40">
            {filteredTickets.length === 0 ? (
              <div className="p-8 text-center text-gray-500 text-xs flex flex-col items-center gap-2">
                <HelpCircle className="w-8 h-8 text-gray-600" />
                <p>لا توجد تذاكر دعم مطابقة لخيارات البحث</p>
              </div>
            ) : (
              filteredTickets.map((ticket) => {
                const isSelected = ticket.id === selectedTicket?.id;
                return (
                  <button
                    key={ticket.id}
                    onClick={() => {
                      soundFX.playButtonClick();
                      setSelectedTicketId(ticket.id);
                    }}
                    className={`w-full text-right p-3.5 flex items-start gap-3 transition-all relative ${
                      isSelected
                        ? 'bg-gradient-to-r from-emerald-950/80 to-[#072414] border-r-4 border-amber-400'
                        : 'hover:bg-[#06180e] bg-transparent'
                    }`}
                  >
                    {/* Player Avatar */}
                    <div className="relative shrink-0">
                      <img
                        src={ticket.playerAvatar}
                        alt={ticket.playerName}
                        className="w-11 h-11 rounded-full object-cover border border-amber-500/40 shadow-sm"
                      />
                      {ticket.playerVip > 0 && (
                        <span className="absolute -top-1 -right-1 text-[9px] bg-gradient-to-r from-amber-500 to-amber-300 text-black font-black px-1 rounded-full shadow-sm">
                          VIP{ticket.playerVip}
                        </span>
                      )}
                      {ticket.unreadAdminCount > 0 && (
                        <span className="absolute -bottom-1 -left-1 w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-black flex items-center justify-center animate-pulse border-2 border-black">
                          {ticket.unreadAdminCount}
                        </span>
                      )}
                    </div>

                    {/* Ticket Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <span className="text-xs font-bold text-gray-200 truncate">
                          {ticket.playerName}
                        </span>
                        <span className="text-[10px] text-gray-500 shrink-0">
                          {ticket.updatedAt.slice(11, 16)}
                        </span>
                      </div>

                      <p className="text-xs font-semibold text-amber-200/90 truncate mb-1">
                        {ticket.subject}
                      </p>

                      <p className="text-[11px] text-gray-400 truncate line-clamp-1">
                        {ticket.lastMessageSnippet}
                      </p>

                      {/* Status & Category Badges */}
                      <div className="flex items-center gap-1.5 mt-2">
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                            ticket.category === 'FINANCIAL'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                              : ticket.category === 'GAMEPLAY'
                              ? 'bg-purple-950 text-purple-300 border border-purple-500/30'
                              : ticket.category === 'ACCOUNT'
                              ? 'bg-blue-950 text-blue-300 border border-blue-500/30'
                              : 'bg-gray-800 text-gray-300'
                          }`}
                        >
                          {ticket.category === 'FINANCIAL'
                            ? 'مالي & كاشير'
                            : ticket.category === 'GAMEPLAY'
                            ? 'طرنيب ولعب'
                            : ticket.category === 'ACCOUNT'
                            ? 'حساب & KYC'
                            : 'استفسار عام'}
                        </span>

                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                            ticket.status === 'RESOLVED'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              : ticket.status === 'IN_PROGRESS'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          }`}
                        >
                          {ticket.status === 'RESOLVED'
                            ? 'محلولة ✅'
                            : ticket.status === 'IN_PROGRESS'
                            ? 'قيد المعالجة ⏳'
                            : 'مفتوحة 🔔'}
                        </span>

                        {ticket.priority === 'URGENT' && (
                          <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/50">
                            عاجل
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* ==========================================
            2. ACTIVE CONVERSATION CANVAS (نافذة المحادثة المباشرة)
           ========================================== */}
        {selectedTicket ? (
          <div className="flex-1 flex flex-col bg-gradient-to-b from-[#05140b] via-[#030d07] to-[#020804] relative">
            {/* Header of Active Chat */}
            <div className="px-6 py-3.5 bg-[#051a0e]/95 border-b border-amber-950/70 flex flex-wrap items-center justify-between gap-3 shrink-0">
              {/* Player Profile Details */}
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src={selectedTicket.playerAvatar}
                    alt={selectedTicket.playerName}
                    className="w-12 h-12 rounded-full object-cover border-2 border-amber-400 shadow-md"
                  />
                  <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-black" />
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-black text-amber-200">
                      {selectedTicket.playerName}
                    </h4>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                      ID: {selectedTicket.playerId}
                    </span>
                    {selectedTicket.playerVip > 0 && (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-gradient-to-r from-amber-500 to-amber-300 text-black font-black">
                        VIP {selectedTicket.playerVip}
                      </span>
                    )}
                    <span className="text-[10px] text-gray-400 font-semibold">
                      المستوى: {selectedTicket.playerLevel}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 mt-1 text-[11px] text-gray-300">
                    <span className="text-gray-400 font-bold">الموضوع:</span>
                    <span className="text-white font-medium">{selectedTicket.subject}</span>
                    <span className="text-gray-500">|</span>
                    <span className="text-gray-400">تذكرة #{selectedTicket.id}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons in Header */}
              <div className="flex items-center gap-2">
                {/* Send Compensation Button */}
                <button
                  onClick={() => setShowCompensationModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600/30 to-amber-500/30 hover:from-amber-600/50 hover:to-amber-500/50 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
                >
                  <Gift className="w-3.5 h-3.5 text-amber-400" />
                  <span>تعويض مالي فوري</span>
                </button>

                {/* Gemini AI Assistant Button */}
                <button
                  onClick={handleGenerateAiReply}
                  disabled={isAiGenerating}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-md disabled:opacity-50"
                >
                  <Sparkles className={`w-3.5 h-3.5 ${isAiGenerating ? 'animate-spin' : ''}`} />
                  <span>{isAiGenerating ? 'جارِ التحليل بـ Gemini...' : 'رد ذكي بالذكاء الاصطناعي'}</span>
                </button>

                {/* Status Toggle Menu */}
                <div className="flex items-center bg-black/40 rounded-xl p-0.5 border border-amber-950">
                  <button
                    onClick={() => handleUpdateTicketStatus('IN_PROGRESS')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                      selectedTicket.status === 'IN_PROGRESS'
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    قيد المعالجة
                  </button>
                  <button
                    onClick={() => handleUpdateTicketStatus('RESOLVED')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                      selectedTicket.status === 'RESOLVED'
                        ? 'bg-emerald-600 text-white'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    محلولة ✅
                  </button>
                </div>
              </div>
            </div>

            {/* AI Generated Smart Reply Preview Banner (When ready) */}
            {aiGeneratedReply && (
              <div className="mx-6 mt-3 p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 via-[#072917] to-amber-950/70 border border-amber-500/40 shadow-xl flex flex-col gap-2 animate-in fade-in slide-in-from-top-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                    <span className="text-xs font-black text-amber-200">
                      اقتراح الرد الذكي المعتمد من Gemini AI (الدقة: {aiGeneratedReply.confidence}%)
                    </span>
                  </div>
                  <button
                    onClick={() => setAiGeneratedReply(null)}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="text-xs text-emerald-100 bg-black/40 p-2.5 rounded-xl border border-emerald-500/20 leading-relaxed select-text">
                  {aiGeneratedReply.text}
                </p>

                <div className="flex items-center justify-end gap-2 mt-1">
                  <button
                    onClick={() => {
                      setReplyText(aiGeneratedReply.text);
                      setAiGeneratedReply(null);
                    }}
                    className="px-3 py-1 rounded-lg bg-black/40 hover:bg-black/60 border border-amber-500/30 text-amber-300 text-xs font-bold transition-all"
                  >
                    تعديل في مربع النص
                  </button>
                  <button
                    onClick={() => handleSendReply(aiGeneratedReply.text)}
                    className="px-4 py-1 rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white text-xs font-black shadow-md flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5 rotate-180" />
                    <span>إرسال الرد فوراً للاعب</span>
                  </button>
                </div>
              </div>
            )}

            {/* Message History Feed */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4">
              {/* Ticket Creation Announcement */}
              <div className="text-center my-2">
                <span className="px-3 py-1 rounded-full bg-black/40 border border-amber-950 text-[11px] text-gray-400 font-semibold">
                  بدأت المحادثة في {selectedTicket.createdAt} • التذكرة #{selectedTicket.id}
                </span>
              </div>

              {selectedTicket.messages.map((msg) => {
                const isPlayer = msg.senderType === 'PLAYER';
                const isSystem = msg.senderType === 'SYSTEM';

                if (isSystem) {
                  return (
                    <div key={msg.id} className="flex justify-center my-3">
                      <div className="max-w-md px-4 py-2 rounded-2xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs font-medium text-center shadow-md flex items-center gap-2">
                        <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>{msg.text}</span>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-3 ${isPlayer ? 'flex-row' : 'flex-row-reverse'}`}
                  >
                    {/* Avatar */}
                    <img
                      src={
                        msg.senderAvatar ||
                        (isPlayer
                          ? selectedTicket.playerAvatar
                          : currentUser.avatar)
                      }
                      alt={msg.senderName}
                      className="w-9 h-9 rounded-full object-cover border border-amber-500/40 shrink-0 mt-1 shadow-sm"
                    />

                    {/* Bubble */}
                    <div
                      className={`max-w-[70%] rounded-2xl p-4 shadow-lg ${
                        isPlayer
                          ? 'bg-[#081f13] border border-emerald-500/30 text-gray-100 rounded-tr-none'
                          : 'bg-gradient-to-br from-emerald-900 to-[#07361c] border border-amber-400/50 text-white rounded-tl-none shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                      }`}
                    >
                      {/* Sender info */}
                      <div className="flex items-center justify-between gap-3 mb-1.5 text-[11px]">
                        <span
                          className={`font-black ${
                            isPlayer ? 'text-amber-300' : 'text-amber-300 flex items-center gap-1'
                          }`}
                        >
                          {!isPlayer && <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />}
                          {msg.senderName}
                          {msg.senderRole && (
                            <span className="text-[10px] text-emerald-300 font-normal">
                              ({msg.senderRole})
                            </span>
                          )}
                        </span>
                        <span className="text-[10px] text-gray-400">
                          {msg.timestamp.slice(11, 16)}
                        </span>
                      </div>

                      {/* Text content */}
                      <p className="text-xs leading-relaxed select-text whitespace-pre-wrap font-normal">
                        {msg.text}
                      </p>

                      {/* Action details if any */}
                      {msg.actionTaken && (
                        <div className="mt-2.5 pt-2 border-t border-amber-500/20 text-[11px] text-amber-200/90 flex items-center gap-1.5">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                          <span>إجراء إداري: {msg.actionTaken.details}</span>
                        </div>
                      )}

                      {/* Status Checkmark */}
                      <div className="flex items-center justify-end mt-1">
                        <CheckCheck
                          className={`w-3.5 h-3.5 ${
                            msg.isRead ? 'text-emerald-400' : 'text-gray-400'
                          }`}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Responses Bar (أزرار الردود السريعة الجاهزة) */}
            <div className="px-6 py-2 bg-[#041108] border-t border-amber-950/60 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
              <span className="text-[11px] text-gray-400 font-bold shrink-0 flex items-center gap-1">
                <CornerDownLeft className="w-3 h-3 text-amber-400" />
                ردود سريعة:
              </span>
              {quickResponses.map((qr, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    soundFX.playButtonClick();
                    setReplyText(qr.text);
                  }}
                  className="px-2.5 py-1 rounded-xl bg-black/50 hover:bg-[#072414] border border-amber-950 hover:border-amber-500/40 text-[11px] text-gray-300 hover:text-amber-200 font-semibold whitespace-nowrap transition-all shadow-sm"
                >
                  {qr.title}
                </button>
              ))}
            </div>

            {/* Bottom Message Input Controls */}
            <div className="p-4 bg-[#05170d] border-t border-amber-950/70 flex flex-col gap-2 shrink-0">
              {/* Emoji Picker Row */}
              {showEmojiPicker && (
                <div className="flex items-center gap-2 pb-2 border-b border-amber-950/50">
                  {popularEmojis.map((emoji, idx) => (
                    <button
                      key={idx}
                      onClick={() => setReplyText((prev) => prev + emoji)}
                      className="text-base hover:scale-125 transition-transform"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}

              <div className="flex items-end gap-3">
                {/* Emoji toggle */}
                <button
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  className="p-2.5 rounded-xl bg-black/40 hover:bg-black/60 border border-amber-950 text-gray-400 hover:text-amber-300 transition-colors"
                  title="إضافة رمز تعبيري"
                >
                  <Smile className="w-5 h-5" />
                </button>

                {/* Textarea */}
                <div className="flex-1 relative">
                  <textarea
                    rows={2}
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendReply();
                      }
                    }}
                    placeholder={`اكتب الرد الرسمي والمباشر للاعب ${selectedTicket.playerName}... (اضغط Enter للإرسال)`}
                    className="w-full p-3 bg-black/60 border border-amber-950 rounded-2xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 resize-none"
                  />
                </div>

                {/* Send Button */}
                <button
                  onClick={() => handleSendReply()}
                  disabled={!replyText.trim() || isSending}
                  className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-black font-black text-xs flex items-center gap-2 shadow-lg hover:shadow-amber-500/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                >
                  <span>إرسال الرد</span>
                  <Send className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-500 gap-3">
            <MessageSquare className="w-12 h-12 text-gray-600" />
            <p className="text-sm font-bold">حدد تذكرة لعرض سجل المحادثة والرد المباشر</p>
          </div>
        )}
      </div>

      {/* ========================================================
          MODAL: QUICK FINANCIAL COMPENSATION (تعويض مالي فوري)
         ======================================================== */}
      {showCompensationModal && selectedTicket && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-gradient-to-b from-[#082215] to-[#030d07] border-2 border-amber-500/60 rounded-3xl p-6 shadow-2xl relative">
            <button
              onClick={() => setShowCompensationModal(false)}
              className="absolute top-4 left-4 text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-black font-black shadow-md">
                <Gift className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-black text-amber-200">
                  منح تعويض مالي مباشر للاعب
                </h4>
                <p className="text-xs text-gray-400">
                  المستفيد: {selectedTicket.playerName} (ID: {selectedTicket.playerId})
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Currency Selector */}
              <div>
                <label className="text-xs font-bold text-gray-300 block mb-1.5">
                  نوع العملة المراد إيداعها:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCompensationCurrency('COINS')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-xs transition-all ${
                      compensationCurrency === 'COINS'
                        ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                        : 'bg-black/40 border-amber-950 text-gray-400'
                    }`}
                  >
                    <Coins className="w-4 h-4 text-amber-400" />
                    <span>كوينز ذهبية</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompensationCurrency('GEMS')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-xs transition-all ${
                      compensationCurrency === 'GEMS'
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                        : 'bg-black/40 border-amber-950 text-gray-400'
                    }`}
                  >
                    <Gem className="w-4 h-4 text-emerald-400" />
                    <span>جواهر زمردية</span>
                  </button>
                </div>
              </div>

              {/* Amount Quick Presets */}
              <div>
                <label className="text-xs font-bold text-gray-300 block mb-1.5">
                  المبلغ المراد تعويضه:
                </label>
                <div className="flex items-center gap-2 mb-2">
                  {(compensationCurrency === 'COINS' ? [500, 1000, 2500, 5000] : [25, 50, 100, 250]).map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setCompensationAmount(amt)}
                      className={`flex-1 py-1.5 rounded-xl border text-xs font-black transition-all ${
                        compensationAmount === amt
                          ? 'bg-amber-400 text-black border-amber-300 shadow-md'
                          : 'bg-black/40 border-amber-950 text-gray-300 hover:text-white'
                      }`}
                    >
                      {amt.toLocaleString()}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  value={compensationAmount}
                  onChange={(e) => setCompensationAmount(Math.max(1, parseInt(e.target.value) || 0))}
                  className="w-full p-2.5 bg-black/60 border border-amber-950 rounded-xl text-sm font-bold text-amber-200 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Reason */}
              <div>
                <label className="text-xs font-bold text-gray-300 block mb-1.5">
                  سبب التعويض (يُسجل في سجل التدقيق المالي):
                </label>
                <input
                  type="text"
                  value={compensationReason}
                  onChange={(e) => setCompensationReason(e.target.value)}
                  className="w-full p-2.5 bg-black/60 border border-amber-950 rounded-xl text-xs text-gray-200 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-amber-950">
                <button
                  type="button"
                  onClick={() => setShowCompensationModal(false)}
                  className="px-4 py-2 rounded-xl bg-black/40 text-gray-400 hover:text-white text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleSendCompensation}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black text-xs font-black shadow-lg"
                >
                  اعتماد التعويض وإرسال الإشعار
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
