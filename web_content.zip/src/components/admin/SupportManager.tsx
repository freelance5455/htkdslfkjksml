import React, { useEffect, useState } from 'react';
import { HelpCircle, Plus, Send, Clock, CheckCircle2, MessageSquare, X } from 'lucide-react';
import { collection, query, where, getDocs, doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { SupportTicket } from '../../types/index.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';

export const SupportManager: React.FC = () => {
  const { currentOrg, userProfile } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<'bug' | 'question' | 'feature' | 'urgent'>('question');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Reply state
  const [replyText, setReplyText] = useState<{ [ticketId: string]: string }>({});

  const fetchTickets = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const q = query(collection(db, 'support_tickets'), where('orgId', '==', currentOrg.id));
      const snap = await getDocs(q);
      const list: SupportTicket[] = [];
      snap.forEach((d) => list.push(d.data() as SupportTicket));
      list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setTickets(list);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [currentOrg]);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOrg || !subject || !description) return;
    setSubmitting(true);
    try {
      const newTicket: SupportTicket = {
        id: `spt_${Date.now()}`,
        orgId: currentOrg.id,
        orgName: currentOrg.name,
        submittedBy: userProfile?.displayName || 'Admin',
        submittedByEmail: userProfile?.email || 'admin@company.com',
        subject,
        category,
        description,
        status: 'open',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'support_tickets', newTicket.id), removeUndefinedFields(newTicket));
      setTickets((prev) => [newTicket, ...prev]);
      setIsModalOpen(false);
      setSubject('');
      setDescription('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddReply = async (ticket: SupportTicket) => {
    const text = replyText[ticket.id]?.trim();
    if (!text || !currentOrg) return;

    const replies = ticket.replies || [];
    const newReply = {
      id: `rep_${Date.now()}`,
      sender: userProfile?.displayName || 'Admin',
      isPlatformStaff: false,
      text,
      createdAt: new Date().toISOString(),
    };

    const updated: SupportTicket = {
      ...ticket,
      replies: [...replies, newReply],
      updatedAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'support_tickets', ticket.id), removeUndefinedFields(updated));
      setTickets((prev) => prev.map((t) => (t.id === ticket.id ? updated : t)));
      setReplyText((prev) => ({ ...prev, [ticket.id]: '' }));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-sky-600" />
            <span>FieldFlow Platform Support</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Submit operational questions, bug reports, and platform requests directly to FieldFlow engineers
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Support Ticket</span>
        </button>
      </div>

      {/* Tickets List */}
      {loading ? (
        <div className="py-12 text-center text-xs text-slate-500 font-medium">Loading support tickets...</div>
      ) : tickets.length === 0 ? (
        <div className="py-12 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-200 p-8">
          No support tickets open. Click "New Support Ticket" if you need technical assistance.
        </div>
      ) : (
        <div className="space-y-3">
          {tickets.map((t) => (
            <div
              key={t.id}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md uppercase ${
                        t.category === 'urgent'
                          ? 'bg-red-100 text-red-800'
                          : t.category === 'bug'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-sky-100 text-sky-800'
                      }`}
                    >
                      {t.category}
                    </span>
                    <h3 className="font-bold text-sm text-slate-900">{t.subject}</h3>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    Submitted by {t.submittedBy} ({t.submittedByEmail}) on {new Date(t.createdAt).toLocaleDateString()}
                  </div>
                </div>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize shrink-0 ${
                    t.status === 'resolved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : t.status === 'in_progress'
                      ? 'bg-sky-100 text-sky-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {t.status.replace(/_/g, ' ')}
                </span>
              </div>

              <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-100 leading-relaxed">
                {t.description}
              </p>

              {/* Thread Replies */}
              {t.replies && t.replies.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Responses</div>
                  {t.replies.map((r) => (
                    <div
                      key={r.id}
                      className={`p-2.5 rounded-xl text-xs ${
                        r.isPlatformStaff
                          ? 'bg-purple-50 border border-purple-200 text-purple-900'
                          : 'bg-slate-100 text-slate-800'
                      }`}
                    >
                      <div className="font-bold text-[11px] flex items-center justify-between">
                        <span>{r.isPlatformStaff ? `👑 FieldFlow Staff (${r.sender})` : r.sender}</span>
                        <span className="text-[10px] opacity-75">
                          {new Date(r.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div className="mt-1">{r.text}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Quick Reply Form */}
              <div className="pt-2 flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Add clarification or update..."
                  value={replyText[t.id] || ''}
                  onChange={(e) => setReplyText({ ...replyText, [t.id]: e.target.value })}
                  className="flex-1 px-3 py-1.5 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-hidden"
                />
                <button
                  onClick={() => handleAddReply(t)}
                  disabled={!replyText[t.id]?.trim()}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white rounded-xl font-bold text-xs flex items-center gap-1"
                >
                  <Send className="w-3 h-3" />
                  <span>Reply</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Ticket Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full border border-slate-200 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-base text-slate-900">Open FieldFlow Support Ticket</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Issue Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                >
                  <option value="question">General Operational Question</option>
                  <option value="bug">Technical Bug / Sync Error</option>
                  <option value="feature">Feature Request</option>
                  <option value="urgent">Urgent Field Operation Blocker</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Need assistance configuring API bulk employee sync"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Describe your question or issue in detail..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs leading-relaxed"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl shadow-xs"
                >
                  {submitting ? 'Submitting...' : 'Submit to Platform Support'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
