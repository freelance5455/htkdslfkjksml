"use client";

import { useEffect, useState } from "react";
import { Activity, BadgeCheck, Ban, CalendarCheck, CheckCircle2, ShieldCheck, Star, Trash2, Users } from "lucide-react";
import { useAuth, useI18n, useToast } from "@/components/providers";
import { Avatar, Badge, Button, Card, CardSkeleton, EmptyState, ErrorState, Input, Select, Stars, Tabs, VerificationBadge } from "@/components/ui";
import { api } from "@/lib/api-client";
import { ROLES, VERIFICATION_STATUSES } from "@/lib/constants";
import type { ProfessionalDTO, ReviewDTO } from "@/lib/types";
import { cn, formatDateTime, formatDay } from "@/lib/utils";

/* ---------------------------- Overview ---------------------------- */

interface StatsPayload {
  users: { total: number; byRole: Record<string, number> };
  professionals: Record<string, number>;
  appointments: { total: number; byStatus: Record<string, number> };
  reviews: { count: number; average: number };
  articles: number;
  services: number;
  daily: Array<{ day: string; count: number }>;
  activity: Array<{ id: string; action: string; entity: string; details: string; createdAt: string; actorName: string | null }>;
}

export function OverviewSection() {
  const { t, locale } = useI18n();
  const [stats, setStats] = useState<StatsPayload | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let alive = true;
    setError(false);
    api<StatsPayload>("/api/stats")
      .then((r) => alive && setStats(r))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [reloadKey]);

  if (error) return <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />;
  if (!stats)
    return (
      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} lines={1} />
          ))}
        </div>
        <CardSkeleton lines={6} />
      </div>
    );

  const byStatus = stats.appointments.byStatus;
  const maxDaily = Math.max(1, ...stats.daily.map((d) => d.count));
  const kpis = [
    {
      label: t("adm.totalUsers"),
      value: stats.users.total,
      sub: `${t("adm.patients")} ${stats.users.byRole.patient ?? 0} · ${t("adm.pros")} ${stats.users.byRole.professional ?? 0}`,
      icon: Users,
      tone: "from-sky-500 to-cyan-400",
    },
    {
      label: t("adm.pendingPros"),
      value: stats.professionals.pending ?? 0,
      sub: `${t("adm.verifiedPros")} ${stats.professionals.verified ?? 0}`,
      icon: BadgeCheck,
      tone: "from-amber-500 to-orange-400",
    },
    {
      label: t("adm.appointments"),
      value: stats.appointments.total,
      sub: `${t("status.pending")} ${byStatus.pending ?? 0} · ${t("status.confirmed")} ${byStatus.confirmed ?? 0}`,
      icon: CalendarCheck,
      tone: "from-teal-500 to-emerald-400",
    },
    {
      label: t("adm.reviewsCount"),
      value: stats.reviews.count,
      sub: `${t("adm.avgRating")} ${stats.reviews.average.toFixed(1)}/5`,
      icon: Star,
      tone: "from-emerald-500 to-lime-400",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k) => (
          <Card key={k.label} className="relative overflow-hidden p-5">
            <span className={cn("mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br text-white shadow", k.tone)}>
              <k.icon className="h-5 w-5" />
            </span>
            <p className="text-3xl font-extrabold text-slate-900">{k.value}</p>
            <p className="mt-1 text-sm font-semibold text-slate-700">{k.label}</p>
            <p className="mt-1 text-xs text-slate-500">{k.sub}</p>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <p className="text-xs font-medium text-slate-500">{t("adm.articles")}</p>
          <p className="mt-1 text-2xl font-bold text-slate-900">{stats.articles}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs font-medium text-slate-500">{t("adm.services")}</p>
          <p className="mt-1 text-2xl font-bold text-slate-900">{stats.services}</p>
        </Card>
        <Card className="p-5">
          <p className="text-xs font-medium text-slate-500">{t("adm.byStatus")}</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {(["pending", "confirmed", "completed", "cancelled"] as const).map((s) => (
              <Badge key={s} tone={s === "pending" ? "amber" : s === "confirmed" ? "sky" : s === "completed" ? "green" : "red"}>
                {t(`status.${s}`)} {byStatus[s] ?? 0}
              </Badge>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <h2 className="mb-5 font-semibold text-slate-900">{t("adm.bookingsLast14")}</h2>
          {stats.daily.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-500">{t("common.noData")}</p>
          ) : (
            <div className="flex h-44 items-end gap-2">
              {stats.daily.map((d) => (
                <div key={d.day} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
                  <span className="text-[10px] font-semibold text-slate-600">{d.count}</span>
                  <div
                    className="w-full rounded-t-lg bg-gradient-to-t from-teal-500 to-sky-400 transition-all"
                    style={{ height: `${Math.max(6, (d.count / maxDaily) * 100)}%` }}
                    title={`${d.day}: ${d.count}`}
                  />
                  <span className="text-[10px] text-slate-500">{d.day.slice(5)}</span>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="lg:col-span-2">
          <h2 className="mb-4 flex items-center gap-2 font-semibold text-slate-900">
            <Activity className="h-4 w-4 text-teal-600" />
            {t("adm.activity")}
          </h2>
          {stats.activity.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">{t("adm.noActivity")}</p>
          ) : (
            <ul className="max-h-80 space-y-3 overflow-y-auto pe-1">
              {stats.activity.map((a) => (
                <li key={a.id} className="border-s-2 border-teal-200 ps-3 text-sm">
                  <p className="font-medium text-slate-800">{a.action}</p>
                  <p className="truncate text-xs text-slate-500">
                    {a.actorName ?? "system"} · {a.entity}
                    {a.details ? ` · ${a.details}` : ""}
                  </p>
                  <p className="text-[11px] text-slate-400">{formatDateTime(a.createdAt, locale)}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------- Users ---------------------------- */

interface AdminUser {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  city: string;
  role: string;
  isActive: boolean;
  createdAt: string;
}

export function UsersSection() {
  const { t, te, locale } = useI18n();
  const toast = useToast();
  const { user: me } = useAuth();
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [role, setRole] = useState("");
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    const id = window.setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => window.clearTimeout(id);
  }, [q]);

  useEffect(() => {
    let alive = true;
    setError(false);
    const qs = new URLSearchParams();
    if (debouncedQ) qs.set("q", debouncedQ);
    if (role) qs.set("role", role);
    api<{ users: AdminUser[] }>(`/api/users?${qs.toString()}`)
      .then((r) => alive && setUsers(r.users))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [debouncedQ, role, reloadKey]);

  /** Optimistic update with rollback. */
  const update = async (target: AdminUser, body: { role?: string; isActive?: boolean }) => {
    const previous = users;
    setUsers((prev) => prev?.map((u) => (u.id === target.id ? { ...u, ...body } : u)) ?? null);
    try {
      await api("/api/users", { method: "PATCH", body: { id: target.id, ...body } });
      toast.success(t("adm.updated"));
    } catch (err) {
      setUsers(previous);
      toast.error(te(err));
    }
  };

  return (
    <Card className="space-y-5">
      <div className="grid gap-3 md:grid-cols-[1fr_200px]">
        <Input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("adm.searchUsers")} aria-label={t("common.search")} />
        <Select value={role} onChange={(e) => setRole(e.target.value)} aria-label={t("common.role")}>
          <option value="">{t("adm.allRoles")}</option>
          {ROLES.map((r) => (
            <option key={r} value={r}>
              {t(`role.${r}`)}
            </option>
          ))}
        </Select>
      </div>

      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !users ? (
        <CardSkeleton lines={5} />
      ) : users.length === 0 ? (
        <EmptyState icon={Users} title={t("adm.noItems")} />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-start text-xs uppercase tracking-wide text-slate-500">
                <th className="py-3 text-start font-semibold">{t("common.name")}</th>
                <th className="py-3 text-start font-semibold">{t("common.city")}</th>
                <th className="py-3 text-start font-semibold">{t("common.role")}</th>
                <th className="py-3 text-start font-semibold">{t("common.status")}</th>
                <th className="py-3 text-start font-semibold">{t("common.date")}</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const isMe = me?.id === u.id;
                return (
                  <tr key={u.id} className="border-b border-slate-50 align-middle">
                    <td className="py-3 pe-3">
                      <p className="font-semibold text-slate-900">{u.fullName}</p>
                      <p className="text-xs text-slate-500" dir="ltr">
                        {u.email}
                      </p>
                      <p className="text-xs text-slate-500" dir="ltr">
                        {u.phone}
                      </p>
                    </td>
                    <td className="py-3 pe-3 text-slate-700">{u.city}</td>
                    <td className="py-3 pe-3">
                      <Select
                        value={u.role}
                        disabled={isMe}
                        onChange={(e) => void update(u, { role: e.target.value })}
                        className="py-1.5 text-xs"
                        aria-label={t("adm.changeRole")}
                      >
                        {ROLES.map((r) => (
                          <option key={r} value={r}>
                            {t(`role.${r}`)}
                          </option>
                        ))}
                      </Select>
                    </td>
                    <td className="py-3 pe-3">
                      <button
                        type="button"
                        disabled={isMe}
                        onClick={() => void update(u, { isActive: !u.isActive })}
                        className={cn(
                          "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ring-1 transition disabled:opacity-50",
                          u.isActive ? "bg-emerald-50 text-emerald-700 ring-emerald-200 hover:bg-emerald-100" : "bg-rose-50 text-rose-700 ring-rose-200 hover:bg-rose-100",
                        )}
                        title={t("adm.toggleActive")}
                      >
                        {u.isActive ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Ban className="h-3.5 w-3.5" />}
                        {u.isActive ? t("common.active") : t("common.disabled")}
                      </button>
                    </td>
                    <td className="py-3 text-xs text-slate-500">{formatDay(u.createdAt, locale)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

/* ---------------------------- Professionals ---------------------------- */

type ProFilter = "pending" | "verified" | "rejected" | "all";

export function ProfessionalsSection() {
  const { t, te, locale } = useI18n();
  const toast = useToast();
  const [filter, setFilter] = useState<ProFilter>("pending");
  const [pros, setPros] = useState<ProfessionalDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [counts, setCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    let alive = true;
    setError(false);
    const qs = new URLSearchParams({ all: "1" });
    if (filter !== "all") qs.set("status", filter);
    api<{ professionals: ProfessionalDTO[] }>(`/api/professionals?${qs.toString()}`)
      .then((r) => {
        if (!alive) return;
        setPros(r.professionals);
      })
      .catch(() => alive && setError(true));
    api<{ professionals: ProfessionalDTO[] }>("/api/professionals?all=1")
      .then((r) => {
        if (!alive) return;
        const c: Record<string, number> = { all: r.professionals.length };
        for (const s of VERIFICATION_STATUSES) c[s] = r.professionals.filter((p) => p.verificationStatus === s).length;
        setCounts(c);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [filter, reloadKey]);

  /** Optimistic verification decision with rollback. */
  const setStatus = async (pro: ProfessionalDTO, status: string) => {
    const previous = pros;
    setPros((prev) => (prev ? (filter === "all" ? prev.map((p) => (p.id === pro.id ? { ...p, verificationStatus: status as ProfessionalDTO["verificationStatus"] } : p)) : prev.filter((p) => p.id !== pro.id)) : prev));
    try {
      await api(`/api/professionals/${pro.id}`, { method: "PATCH", body: { verificationStatus: status } });
      toast.success(status === "verified" ? t("pro.verified") : status === "rejected" ? t("pro.rejected") : t("adm.updated"));
      setCounts({});
      setReloadKey((k) => k + 1);
    } catch (err) {
      setPros(previous);
      toast.error(te(err));
    }
  };

  const tabs: Array<{ value: ProFilter; label: string; count?: number }> = [
    { value: "pending", label: t("pro.pending"), count: counts.pending },
    { value: "verified", label: t("pro.verified"), count: counts.verified },
    { value: "rejected", label: t("pro.rejected"), count: counts.rejected },
    { value: "all", label: t("common.all"), count: counts.all },
  ];

  return (
    <div className="space-y-5">
      <Tabs items={tabs} value={filter} onChange={setFilter} />
      {error ? (
        <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />
      ) : !pros ? (
        <div className="grid gap-4 md:grid-cols-2">
          <CardSkeleton lines={4} />
          <CardSkeleton lines={4} />
        </div>
      ) : pros.length === 0 ? (
        <EmptyState icon={BadgeCheck} title={t("adm.noItems")} />
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {pros.map((p) => (
            <Card key={p.id} className="flex flex-col gap-4 p-5">
              <div className="flex items-start gap-4">
                <Avatar src={p.photoUrl} name={p.fullName} className="h-14 w-14" />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-semibold text-slate-900">{p.fullName}</p>
                    <VerificationBadge status={p.verificationStatus} />
                  </div>
                  <p className="text-sm text-slate-600">
                    {t(`pro.profession.${p.profession}`)} · {p.city} · {t("pro.experience", { n: p.experienceYears })}
                  </p>
                  <p className="mt-1 text-xs text-slate-500" dir="ltr">
                    {p.email} · {p.phone}
                  </p>
                  <p className="text-xs text-slate-500">
                    {t("adm.licence")}: <span className="font-mono">{p.licenseNumber}</span>
                  </p>
                </div>
              </div>
              {p.qualifications && <p className="text-sm leading-relaxed text-slate-700">{p.qualifications}</p>}
              <div className="flex flex-wrap gap-1.5">
                {p.serviceCodes.map((s) => (
                  <Badge key={s} tone="teal">
                    {s}
                  </Badge>
                ))}
                {p.serviceCities.map((c) => (
                  <Badge key={c} tone="sky">
                    {c}
                  </Badge>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-2 border-t border-slate-100 pt-4">
                {p.verificationStatus !== "verified" && (
                  <Button variant="primary" size="sm" onClick={() => void setStatus(p, "verified")}>
                    <ShieldCheck className="h-4 w-4" />
                    {t("adm.verify")}
                  </Button>
                )}
                {p.verificationStatus !== "rejected" && (
                  <Button variant="danger" size="sm" onClick={() => void setStatus(p, "rejected")}>
                    {t("adm.reject")}
                  </Button>
                )}
                {p.verificationStatus !== "pending" && (
                  <Button variant="outline" size="sm" onClick={() => void setStatus(p, "pending")}>
                    {t("adm.setPending")}
                  </Button>
                )}
                <span className="ms-auto text-xs text-slate-400">{formatDay(p.createdAt, locale)}</span>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------------------- Reviews ---------------------------- */

export function ReviewsSection() {
  const { t, te, locale } = useI18n();
  const toast = useToast();
  const [reviews, setReviews] = useState<ReviewDTO[] | null>(null);
  const [error, setError] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let alive = true;
    setError(false);
    api<{ reviews: ReviewDTO[] }>("/api/reviews")
      .then((r) => alive && setReviews(r.reviews))
      .catch(() => alive && setError(true));
    return () => {
      alive = false;
    };
  }, [reloadKey]);

  const remove = async (review: ReviewDTO) => {
    if (!window.confirm(t("adm.deleteConfirm"))) return;
    const previous = reviews;
    setReviews((prev) => prev?.filter((r) => r.id !== review.id) ?? null);
    try {
      await api(`/api/reviews?id=${review.id}`, { method: "DELETE" });
      toast.success(t("adm.deleted"));
    } catch (err) {
      setReviews(previous);
      toast.error(te(err));
    }
  };

  if (error) return <ErrorState message={t("common.error")} onRetry={() => setReloadKey((k) => k + 1)} />;
  if (!reviews) return <CardSkeleton lines={5} />;
  if (reviews.length === 0) return <EmptyState icon={Star} title={t("adm.noItems")} />;

  return (
    <div className="space-y-3">
      {reviews.map((r) => (
        <Card key={r.id} className="flex flex-col gap-3 p-5 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0 space-y-1.5">
            <div className="flex flex-wrap items-center gap-3">
              <Stars value={r.rating} size={14} />
              <span className="text-xs text-slate-500">{formatDateTime(r.createdAt, locale)}</span>
              <span className="font-mono text-xs text-slate-400">{r.reference}</span>
            </div>
            {r.comment && <p className="text-sm leading-relaxed text-slate-800">“{r.comment}”</p>}
            <p className="text-xs text-slate-500">
              {r.patientName} → {r.professionalName}
            </p>
          </div>
          <Button variant="danger" size="sm" onClick={() => void remove(r)} className="shrink-0">
            <Trash2 className="h-4 w-4" />
            {t("adm.reviewDelete")}
          </Button>
        </Card>
      ))}
    </div>
  );
}
