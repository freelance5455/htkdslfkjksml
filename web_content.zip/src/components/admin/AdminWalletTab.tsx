import React, { useState } from 'react';
import { 
  Wallet, 
  Coins, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Search, 
  PlusCircle, 
  MinusCircle, 
  ShieldCheck, 
  Users, 
  X, 
  CheckCircle2,
  DollarSign,
  TrendingDown,
  RefreshCw
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { User } from '../../types';

export const AdminWalletTab: React.FC = () => {
  const { allUsers, transactions, adjustUserCoins, systemSettings, t } = useApp();

  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<number>(100);
  const [adjustReason, setAdjustReason] = useState('Administrative wallet adjustment');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [adjustType, setAdjustType] = useState<'credit' | 'debit'>('credit');

  const totalWalletCoins = allUsers.reduce((sum, u) => sum + u.coins, 0);
  const totalLifetimeCoins = allUsers.reduce((sum, u) => sum + (u.lifetimeCoins || u.coins), 0);
  const totalWithdrawnCoins = allUsers.reduce((sum, u) => sum + (u.withdrawnCoins || 0), 0);
  const currencySymbol = systemSettings?.currencySymbol || '₹';
  const coinsPerCurrency = systemSettings?.coinsPerCurrencyUnit || 1;
  const currencyValue = (totalWalletCoins / coinsPerCurrency).toFixed(2);

  const filteredUsers = allUsers.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    u.referralCode.toLowerCase().includes(search.toLowerCase())
  ).sort((a, b) => b.coins - a.coins);

  const handleOpenAdjust = (user: User, type: 'credit' | 'debit') => {
    setSelectedUser(user);
    setAdjustType(type);
    setAdjustAmount(100);
    setAdjustReason(type === 'credit' ? 'Reward / Promotion Bonus' : 'Deduction / Correction');
    setIsModalOpen(true);
  };

  const handleApplyAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !adjustAmount) return;

    const amount = adjustType === 'credit' ? Math.abs(adjustAmount) : -Math.abs(adjustAmount);
    adjustUserCoins(selectedUser.id, amount, adjustReason);
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white">
                Wallet Management & Coin Reserves
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Live Reserves
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Manage user balances, track circulating coin float, and execute direct administrative credits or debits.
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className="text-[11px] text-slate-400 block font-medium">Platform Total Float</span>
          <span className="text-xl font-black text-amber-400">
            🪙 {totalWalletCoins.toLocaleString()}
          </span>
          <span className="text-xs text-emerald-400 block font-semibold">
            ≈ {currencySymbol}{currencyValue}
          </span>
        </div>
      </div>

      {/* Wallet Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Active Float Balance</span>
          <p className="text-xl font-black text-amber-400">
            🪙 {totalWalletCoins.toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-400">Across {allUsers.length} user accounts</span>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Estimated Cash Liability</span>
          <p className="text-xl font-black text-emerald-400">
            {currencySymbol}{currencyValue}
          </p>
          <span className="text-[10px] text-slate-400">At 1 coin = {currencySymbol}{coinsPerCurrency}</span>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Lifetime Coins Minted</span>
          <p className="text-xl font-black text-purple-400">
            🪙 {totalLifetimeCoins.toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-400">All-time earned coins</span>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <span className="text-slate-400 text-xs block">Total Withdrawn</span>
          <p className="text-xl font-black text-rose-400">
            🪙 {totalWithdrawnCoins.toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-400">Successfully cashed out</span>
        </div>
      </div>

      {/* User Wallets & Quick Adjust Table */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-400" />
              <span>User Wallet Balances & Direct Adjustments</span>
            </h3>
            <p className="text-xs text-slate-400">
              Credit bonus rewards or deduct coins from user accounts.
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search user name or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-700 bg-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-800">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/70 text-slate-400 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-800">
              <tr>
                <th className="p-3.5">User Details</th>
                <th className="p-3.5">VIP Tier</th>
                <th className="p-3.5">Wallet Balance</th>
                <th className="p-3.5">Cash Equivalent</th>
                <th className="p-3.5">Lifetime Minted</th>
                <th className="p-3.5 text-right">Quick Wallet Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3.5">
                    <p className="font-bold text-white">{user.name}</p>
                    <p className="text-[11px] text-slate-400">{user.email}</p>
                    <span className="text-[10px] text-slate-500 font-mono">Ref: {user.referralCode}</span>
                  </td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      {user.membershipTier}
                    </span>
                  </td>
                  <td className="p-3.5">
                    <span className="font-black text-amber-400 text-sm flex items-center gap-1">
                      <Coins className="w-3.5 h-3.5" />
                      <span>{user.coins.toLocaleString()}</span>
                    </span>
                  </td>
                  <td className="p-3.5 font-bold text-emerald-400">
                    {currencySymbol}{(user.coins / coinsPerCurrency).toFixed(2)}
                  </td>
                  <td className="p-3.5 text-slate-400">
                    🪙 {(user.lifetimeCoins || user.coins).toLocaleString()}
                  </td>
                  <td className="p-3.5 text-right space-x-1.5 whitespace-nowrap">
                    <button
                      onClick={() => handleOpenAdjust(user, 'credit')}
                      className="px-2.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 font-bold text-[11px] inline-flex items-center gap-1 transition-all cursor-pointer"
                      title="Credit Coins"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>Credit</span>
                    </button>
                    <button
                      onClick={() => handleOpenAdjust(user, 'debit')}
                      className="px-2.5 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 font-bold text-[11px] inline-flex items-center gap-1 transition-all cursor-pointer"
                      title="Debit Coins"
                    >
                      <MinusCircle className="w-3.5 h-3.5" />
                      <span>Debit</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Adjust Modal */}
      {isModalOpen && selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative space-y-4">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                adjustType === 'credit' 
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              }`}>
                {adjustType === 'credit' ? 'Wallet Credit' : 'Wallet Debit'}
              </span>
              <h3 className="text-lg font-black text-white mt-1">
                {adjustType === 'credit' ? 'Add Coins to User' : 'Deduct Coins from User'}
              </h3>
              <p className="text-xs text-slate-400">
                User: <strong className="text-slate-200">{selectedUser.name}</strong> ({selectedUser.email})
              </p>
              <p className="text-xs text-amber-400 mt-1">
                Current Balance: 🪙 {selectedUser.coins.toLocaleString()}
              </p>
            </div>

            <form onSubmit={handleApplyAdjustment} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Amount of Coins to {adjustType === 'credit' ? 'Credit' : 'Debit'} *
                </label>
                <div className="relative">
                  <Coins className="w-4 h-4 text-amber-400 absolute left-3 top-2.5" />
                  <input
                    type="number"
                    required
                    min={1}
                    max={100000}
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(Math.max(1, Number(e.target.value)))}
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-700 bg-slate-800 text-sm font-mono text-white focus:outline-purple-500"
                  />
                </div>
                <span className="text-[11px] text-slate-400 block mt-1">
                  Equivalent to {currencySymbol}{(adjustAmount / coinsPerCurrency).toFixed(2)}
                </span>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Reason / Administrative Note *
                </label>
                <input
                  type="text"
                  required
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  placeholder="e.g. Promotional Bonus, Contest Winner, Correction"
                  className="w-full px-3 py-2 rounded-xl border border-slate-700 bg-slate-800 text-xs text-white focus:outline-purple-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 font-bold hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-white font-black flex items-center gap-1.5 cursor-pointer ${
                    adjustType === 'credit'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirm {adjustType === 'credit' ? 'Credit' : 'Debit'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
