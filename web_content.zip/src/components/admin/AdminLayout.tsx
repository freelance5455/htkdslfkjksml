import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  Clock,
  MapPin,
  CheckSquare,
  Calendar,
  TrendingUp,
  Trophy,
  MessageSquare,
  FileText,
  Palette,
  ShieldCheck,
  HelpCircle,
  Menu,
  X,
  Sparkles,
  Lock,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { AdminDashboard } from './AdminDashboard.tsx';
import { EmployeeManager } from './EmployeeManager.tsx';
import { AttendanceManager } from './AttendanceManager.tsx';
import { VisitsManager } from './VisitsManager.tsx';
import { TaskManager } from './TaskManager.tsx';
import { LeaveManager } from './LeaveManager.tsx';
import { PerformanceManager } from './PerformanceManager.tsx';
import { AwardsManager } from './AwardsManager.tsx';
import { MessagingCenter } from './MessagingCenter.tsx';
import { ReportsCenter } from './ReportsCenter.tsx';
import { CompanyBranding } from './CompanyBranding.tsx';
import { AuditLogViewer } from './AuditLogViewer.tsx';
import { SupportManager } from './SupportManager.tsx';
import { SecurityCenter } from './SecurityCenter.tsx';
import { LiveTechnicianMap } from './LiveTechnicianMap.tsx';
import { SubAdminPermissions } from '../../types/index.ts';
import { Compass } from 'lucide-react';

interface AdminLayoutProps {
  onOpenAiAssistant: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  onOpenAiAssistant,
  activeTab,
  setActiveTab,
}) => {
  const { currentOrg, hasPermission, userProfile } = useAuth();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const navigationSections: {
    title: string;
    items: {
      id: string;
      label: string;
      icon: any;
      permission?: keyof SubAdminPermissions;
    }[];
  }[] = [
    {
      title: 'Operations',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'live_map', label: 'Live Technician Map', icon: Compass, permission: 'manageVisits' },
        { id: 'attendance', label: 'Attendance & GPS', icon: Clock, permission: 'manageAttendance' },
        { id: 'visits', label: 'Visits & Dispatch', icon: MapPin, permission: 'manageVisits' },
        { id: 'tasks', label: 'Tasks & Orders', icon: CheckSquare, permission: 'manageTasks' },
      ],
    },
    {
      title: 'Workforce',
      items: [
        { id: 'employees', label: 'Employees', icon: Users, permission: 'manageEmployees' },
        { id: 'leave', label: 'Leave Requests', icon: Calendar, permission: 'manageLeave' },
        { id: 'performance', label: 'Performance & KPIs', icon: TrendingUp, permission: 'managePerformance' },
        { id: 'awards', label: 'Awards & Recognition', icon: Trophy, permission: 'manageAwards' },
        { id: 'messaging', label: 'Field Messaging', icon: MessageSquare, permission: 'manageMessaging' },
      ],
    },
    {
      title: 'Administration',
      items: [
        { id: 'reports', label: 'Reports & Exports', icon: FileText, permission: 'manageReports' },
        { id: 'branding', label: 'Workspace Branding', icon: Palette, permission: 'manageBranding' },
        { id: 'security', label: 'Security & Access', icon: Lock, permission: 'manageSecurity' },
        { id: 'audit', label: 'Audit Logs', icon: ShieldCheck },
        { id: 'support', label: 'Platform Support', icon: HelpCircle },
      ],
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-4 flex gap-6">
      {/* Mobile Toggle Button */}
      <button
        type="button"
        onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        className="md:hidden fixed bottom-5 right-5 z-40 p-3.5 bg-sky-600 hover:bg-sky-700 text-white rounded-full shadow-xl active:scale-95 transition-all cursor-pointer"
        aria-label="Toggle navigation menu"
      >
        {isMobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Mobile Backdrop */}
      {isMobileSidebarOpen && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-30 md:hidden animate-in fade-in-0 duration-150"
          onClick={() => setIsMobileSidebarOpen(false)}
        />
      )}

      {/* Left Sidebar Navigation */}
      <aside
        className={`fixed md:static top-14 md:top-auto bottom-0 md:bottom-auto left-0 z-35 md:z-10 w-64 bg-white md:bg-transparent border-r md:border-r-0 border-slate-200 p-4 md:p-0 transition-transform md:translate-x-0 overflow-y-auto md:overflow-visible ${
          isMobileSidebarOpen
            ? 'translate-x-0 shadow-2xl pointer-events-auto'
            : '-translate-x-full pointer-events-none md:pointer-events-auto'
        } shrink-0`}
      >
        <div className="sticky top-20 bg-white rounded-2xl border border-slate-200 shadow-xs p-3 space-y-4">
          {navigationSections.map((sec, sIdx) => {
            const allowedItems = sec.items.filter(
              (item) => !item.permission || hasPermission(item.permission)
            );
            if (allowedItems.length === 0) return null;

            return (
              <div key={sIdx} className="space-y-1">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 py-1">
                  {sec.title}
                </div>
                {allowedItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setIsMobileSidebarOpen(false);
                      }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-sky-50 text-sky-700 font-bold shadow-xs'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isActive ? 'text-sky-600 stroke-[2.2]' : 'text-slate-400'}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            );
          })}

          {/* AI Shortcut Card */}
          <div className="pt-2 border-t border-slate-100">
            <button
              onClick={onOpenAiAssistant}
              className="w-full p-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs hover:opacity-95 transition-opacity"
            >
              <Sparkles className="w-4 h-4" />
              <span>Ask FieldFlow AI</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Admin Content Body */}
      <main className="flex-1 min-w-0 pb-16">
        {activeTab === 'dashboard' && (
          <AdminDashboard
            onNavigate={(mod) => setActiveTab(mod)}
            onOpenAiAssistant={onOpenAiAssistant}
          />
        )}
        {activeTab === 'live_map' && <LiveTechnicianMap />}
        {activeTab === 'employees' && <EmployeeManager />}
        {activeTab === 'attendance' && <AttendanceManager />}
        {activeTab === 'visits' && <VisitsManager />}
        {activeTab === 'tasks' && <TaskManager />}
        {activeTab === 'leave' && <LeaveManager />}
        {activeTab === 'performance' && <PerformanceManager />}
        {activeTab === 'awards' && <AwardsManager />}
        {activeTab === 'messaging' && <MessagingCenter />}
        {activeTab === 'reports' && <ReportsCenter />}
        {activeTab === 'branding' && <CompanyBranding />}
        {activeTab === 'security' && <SecurityCenter />}
        {activeTab === 'audit' && <AuditLogViewer />}
        {activeTab === 'support' && <SupportManager />}
      </main>
    </div>
  );
};
