import React, { useState } from 'react';
import { 
  Settings, 
  Save, 
  ShieldAlert, 
  Key, 
  Coins, 
  Check, 
  HelpCircle,
  FileCode
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AdminSettingsTab: React.FC = () => {
  const { systemSettings, updateSystemSettings, t } = useApp();

  const [form, setForm] = useState({ ...systemSettings });
  const [savedNotice, setSavedNotice] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSystemSettings(form);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <div className="space-y-6">
      
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          {t('settingsManagement')}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Configure financial conversion rates, referral rules, and system behavior.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* System & Payout Settings Form */}
        <form onSubmit={handleSubmit} className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 shadow-xs text-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Coins className="w-4 h-4 text-emerald-500" />
            <span>Coin Economics & Thresholds</span>
          </h3>

          {savedNotice && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 font-semibold flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>Settings saved successfully!</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Currency Symbol
              </label>
              <input
                type="text"
                value={form.currencySymbol}
                onChange={(e) => setForm({ ...form, currencySymbol: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-bold"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Currency Code
              </label>
              <input
                type="text"
                value={form.currencyCode}
                onChange={(e) => setForm({ ...form, currencyCode: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Coins per 1.00 Currency Unit
              </label>
              <input
                type="number"
                min={1}
                value={form.coinsPerCurrencyUnit}
                onChange={(e) => setForm({ ...form, coinsPerCurrencyUnit: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-bold"
              />
              <span className="text-[10px] text-slate-400">e.g. 100 coins = $1.00</span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Minimum Withdrawal (Coins)
              </label>
              <input
                type="number"
                min={10}
                value={form.minWithdrawalCoins}
                onChange={(e) => setForm({ ...form, minWithdrawalCoins: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-bold"
              />
              <span className="text-[10px] text-slate-400">≈ ${(form.minWithdrawalCoins / form.coinsPerCurrencyUnit).toFixed(2)}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Referrer Reward (Coins)
              </label>
              <input
                type="number"
                min={0}
                value={form.referralBonusCoins}
                onChange={(e) => setForm({ ...form, referralBonusCoins: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Referred User Bonus (Coins)
              </label>
              <input
                type="number"
                min={0}
                value={form.referredUserBonusCoins}
                onChange={(e) => setForm({ ...form, referredUserBonusCoins: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-emerald-500" />
                <span>Official Direct Android APK Configuration</span>
              </h4>
              <label className="flex items-center gap-2 cursor-pointer font-bold text-[11px] text-emerald-600 dark:text-emerald-400">
                <input
                  type="checkbox"
                  checked={form.enableApkDownload !== false}
                  onChange={(e) => setForm({ ...form, enableApkDownload: e.target.checked })}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>Enable Direct APK Download</span>
              </label>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-semibold text-slate-700 dark:text-slate-300">
                  Production APK Download URL (HTTPS Link) *
                </label>
              </div>
              <input
                type="text"
                placeholder="https://your-hosting.com/task-earn-pro-release.apk"
                value={form.apkDownloadUrl || ''}
                onChange={(e) => setForm({ ...form, apkDownloadUrl: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-mono text-xs placeholder:text-slate-500"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                Enter your hosted release APK HTTPS URL only after compiling in Android Studio or GitHub Actions. Leave empty if unbuilt.
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  APK Version Label
                </label>
                <input
                  type="text"
                  placeholder="v2.4.0"
                  value={form.apkVersion || 'v2.4.0'}
                  onChange={(e) => setForm({ ...form, apkVersion: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-mono text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  APK File Size
                </label>
                <input
                  type="text"
                  placeholder="8.28 MB"
                  value={form.apkFileSizeMb || '8.28 MB'}
                  onChange={(e) => setForm({ ...form, apkFileSizeMb: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-mono text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Release Notes / Changelog
              </label>
              <textarea
                rows={2}
                placeholder="Describe new features, task improvements, and payout guarantees..."
                value={form.apkReleaseNotes || ''}
                onChange={(e) => setForm({ ...form, apkReleaseNotes: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs placeholder:text-slate-500 resize-none"
              />
            </div>

            {/* Quick Link Test in Admin */}
            {form.apkDownloadUrl && (
              <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 truncate max-w-[240px]">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <span className="truncate">{form.apkDownloadUrl}</span>
                </div>
                <a
                  href={form.apkDownloadUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  download
                  className="text-purple-600 dark:text-purple-400 font-bold hover:underline shrink-0"
                >
                  Test Download ↗
                </a>
              </div>
            )}
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800 dark:text-slate-200">
              <input
                type="checkbox"
                checked={form.demoModeNotice}
                onChange={(e) => setForm({ ...form, demoModeNotice: e.target.checked })}
                className="text-purple-600 focus:ring-purple-500 rounded"
              />
              <span>Display DEMO / TEST MODE Disclaimer Banner to Users</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800 dark:text-slate-200">
              <input
                type="checkbox"
                checked={form.enableGoogleTasksSync}
                onChange={(e) => setForm({ ...form, enableGoogleTasksSync: e.target.checked })}
                className="text-purple-600 focus:ring-purple-500 rounded"
              />
              <span>Enable Google Tasks Productivity Rewards Integration</span>
            </label>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md shadow-purple-600/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </form>

        {/* Production Security & How to Change Credentials Documentation */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4 shadow-xs text-xs">
          <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold text-sm">
            <ShieldAlert className="w-5 h-5 shrink-0" />
            <span>Production Deployment & Security Guide</span>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 text-amber-800 dark:text-amber-300 leading-relaxed text-[11px] space-y-1.5">
            <p className="font-bold">How to change the demo admin credentials before production:</p>
            <p>1. Open <code className="bg-amber-200/50 dark:bg-amber-900/60 px-1 py-0.5 rounded font-mono">src/context/AppContext.tsx</code></p>
            <p>2. Locate the <code className="bg-amber-200/50 dark:bg-amber-900/60 px-1 py-0.5 rounded font-mono">adminLogin(user, pass)</code> function.</p>
            <p>3. Replace the development constants:</p>
            <pre className="p-2 rounded-lg bg-black/70 text-amber-200 font-mono text-[10px] overflow-x-auto">
{`// Production Pattern:
if (user === process.env.ADMIN_USER && 
    await bcrypt.compare(pass, process.env.ADMIN_HASH)) {
  setIsAdminAuthenticated(true);
}`}
            </pre>
            <p>4. In a production Node.js/Cloud Run deployment, store credentials as encrypted hashes in environment variables or Google Cloud Secret Manager.</p>
          </div>

          <div className="space-y-2 text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
            <p className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <FileCode className="w-4 h-4 text-purple-500" />
              <span>How to Run & Deploy the Project:</span>
            </p>
            <ul className="list-disc pl-4 space-y-1">
              <li><strong>Local Dev:</strong> <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">npm run dev</code> (runs on port 3000)</li>
              <li><strong>Production Build:</strong> <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">npm run build</code></li>
              <li><strong>Google Workspace OAuth:</strong> Powered by Firebase Client-Side Auth with Google Tasks scope (<code className="font-mono text-[10px]">https://www.googleapis.com/auth/tasks</code>).</li>
              <li><strong>Data Persistence:</strong> Synchronized with browser LocalStorage and state layer.</li>
            </ul>
          </div>
        </div>

      </div>

    </div>
  );
};
