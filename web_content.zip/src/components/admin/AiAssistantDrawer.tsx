import React, { useState, useRef } from 'react';
import { Sparkles, X, Send, Bot, User, Clock, AlertCircle, Loader2 } from 'lucide-react';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';

interface AiAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiAssistantDrawer: React.FC<AiAssistantDrawerProps> = ({ isOpen, onClose }) => {
  const { currentOrg } = useAuth();
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; time: string; error?: boolean }>>([
    {
      sender: 'ai',
      text: `Hello! I am your FieldFlow AI Operations Assistant for ${currentOrg?.name || 'your company'}. How can I assist you with today's attendance, pending visits, or technician performance?`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState<string>('Analyzing query...');

  // 60-second context cache to prevent redundant Firestore queries
  const contextCacheRef = useRef<{ data: any; timestamp: number } | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    'What Needs Attention Today?',
    'How many employees are present today?',
    'Who has not checked out yet?',
    'Show pending visits for today',
    'Which tasks are overdue or urgent?',
  ];

  const getOrFetchContextData = async () => {
    if (!currentOrg) return null;
    const now = Date.now();

    // Cache hit within 60 seconds
    if (contextCacheRef.current && now - contextCacheRef.current.timestamp < 60000) {
      return contextCacheRef.current.data;
    }

    setLoadingStatus('Retrieving workforce records...');
    const todayStr = new Date().toISOString().split('T')[0];

    // Efficient parallel queries with low limit (25) to avoid excessive data transfer
    const [empSnap, attSnap, visSnap, tskSnap] = await Promise.all([
      getDocs(query(collection(db, 'employees'), where('orgId', '==', currentOrg.id), limit(25))),
      getDocs(query(collection(db, 'attendance'), where('orgId', '==', currentOrg.id), where('date', '==', todayStr), limit(25))),
      getDocs(query(collection(db, 'visits'), where('orgId', '==', currentOrg.id), limit(25))),
      getDocs(query(collection(db, 'tasks'), where('orgId', '==', currentOrg.id), limit(25))),
    ]);

    const contextData = {
      organizationName: currentOrg.name,
      currentDate: todayStr,
      employeesSummary: empSnap.docs.map((d) => {
        const e = d.data();
        return { id: e.id, name: e.name, designation: e.designation, territory: e.territory, status: e.status };
      }),
      todayAttendance: attSnap.docs.map((d) => {
        const a = d.data();
        return { employeeName: a.employeeName, checkInTime: a.checkInTime, checkOutTime: a.checkOutTime, status: a.status };
      }),
      visitsSummary: visSnap.docs.map((d) => {
        const v = d.data();
        return { title: v.title, customer: v.customerName, assignedTo: v.assignedEmployeeName, status: v.status, priority: v.priority };
      }),
      tasksSummary: tskSnap.docs.map((d) => {
        const t = d.data();
        return { title: t.title, assignedTo: t.assignedEmployeeName, status: t.status, priority: t.priority, dueDate: t.dueDate };
      }),
    };

    contextCacheRef.current = { data: contextData, timestamp: now };
    return contextData;
  };

  const handleSend = async (queryText?: string) => {
    const q = (queryText || inputQuery).trim();
    if (!q || !currentOrg) return;

    const userMsgTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages((prev) => [...prev, { sender: 'user', text: q, time: userMsgTime }]);
    setInputQuery('');
    setLoading(true);
    setLoadingStatus('Consulting Gemini AI...');

    try {
      const contextData = await getOrFetchContextData();
      if (!contextData) {
        throw new Error('Unable to retrieve workforce context');
      }

      setLoadingStatus('Processing with Gemini 2.5...');

      // AbortController with 10-second timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, contextData }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      let answerText = '';
      if (res.ok) {
        const data = await res.json();
        answerText = data.answer;
      } else {
        const errJson = await res.json().catch(() => ({}));
        if (res.status === 429) {
          answerText = '⚠️ AI rate limit reached. Please wait a moment and try your query again.';
        } else if (res.status === 403 || res.status === 401) {
          answerText = '⚠️ AI configuration error: permission denied or invalid API credentials.';
        } else {
          answerText = errJson.error || '⚠️ AI service temporarily unavailable. Please retry.';
        }
      }

      const aiMsgTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setMessages((prev) => [...prev, { sender: 'ai', text: answerText, time: aiMsgTime }]);
    } catch (err: any) {
      console.error('AI Chat Error:', err);
      const isTimeout = err?.name === 'AbortError';
      const aiMsgTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const errorMessage = isTimeout
        ? '⚠️ AI request timed out. Please check your network connection and retry.'
        : `⚠️ Unable to process query: ${err?.message || 'Database or AI service error'}. Please retry.`;

      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: errorMessage,
          time: aiMsgTime,
          error: true,
        },
      ]);
    } finally {
      setLoading(false);
      setLoadingStatus('');
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white border-l border-slate-200 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="p-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-sky-400 to-indigo-500 flex items-center justify-center text-white shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-sm">FieldFlow AI Assistant</h3>
            <p className="text-[11px] text-sky-200">Grounded in real {currentOrg?.name} data</p>
          </div>
        </div>
        <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-white transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed space-y-1.5 ${
                m.sender === 'user'
                  ? 'bg-sky-600 text-white rounded-tr-xs shadow-xs'
                  : m.error
                  ? 'bg-rose-50 text-rose-900 border border-rose-200 rounded-tl-xs'
                  : 'bg-white text-slate-800 border border-slate-200/80 rounded-tl-xs shadow-2xs'
              }`}
            >
              <div className="whitespace-pre-wrap">{m.text}</div>
            </div>
            <span className="text-[10px] text-slate-400 mt-1 px-1">{m.time}</span>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 p-3 bg-white rounded-2xl border border-slate-200 shadow-2xs text-xs text-sky-700 max-w-[85%] animate-pulse">
            <Loader2 className="w-4 h-4 animate-spin text-sky-600 shrink-0" />
            <span className="font-medium">{loadingStatus}</span>
          </div>
        )}
      </div>

      {/* Quick Prompts */}
      <div className="p-2.5 bg-white border-t border-slate-200 overflow-x-auto scrollbar-none flex items-center gap-1.5">
        {quickPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(p)}
            disabled={loading}
            className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-sky-50 hover:text-sky-700 text-slate-700 rounded-lg whitespace-nowrap transition-colors border border-slate-200/60 disabled:opacity-50"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="p-3 bg-white border-t border-slate-200">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            placeholder="Ask about attendance, visits, technicians..."
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            disabled={loading}
            className="flex-1 px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-sky-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!inputQuery.trim() || loading}
            className="p-2.5 bg-sky-600 hover:bg-sky-700 disabled:opacity-40 text-white rounded-xl shadow-xs transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
