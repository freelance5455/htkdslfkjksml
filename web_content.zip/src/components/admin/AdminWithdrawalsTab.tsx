import React, { useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Coins, 
  Search, 
  FileCheck, 
  AlertTriangle,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { WithdrawalRequest } from '../../types';

export const AdminWithdrawalsTab: React.FC = () => {
  const { withdrawals, approveWithdrawal, rejectWithdrawal, t } = useApp();

  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedReq, setSelectedReq] = useState<WithdrawalRequest | null>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject'>('approve');
  const [refId, setRefId] = useState('');
  const [remark, setRemark] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filtered = withdrawals.filter((w) => {
    if (filter === 'all') return true;
    return w.status === filter;
  });

  const handleOpenApprove = (req: WithdrawalRequest) => {
    setSelectedReq(req);
    setActionType('approve');
    setRefId(`${req.method.toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`);
    setRemark('Verified & processed successfully via payout gateway simulator.');
    setIsModalOpen(true);
  };

  const handleOpenReject = (req: WithdrawalRequest) => {
    setSelectedReq(req);
    setActionType('reject');
    setRemark('Account details could not be verified. Please check and re-apply.');
    setIsModalOpen(true);
  };

  const handleConfirmAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReq) return;

    if (actionType === 'approve') {
      approveWithdrawal(selectedReq.id, refId, remark);
    } else {
      rejectWithdrawal(selectedReq.id, remark);
    }
    setIsModalOpen(false);
    setSelectedReq(null);
  };

  return (
    <div className="space-y-4">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            {t('withdrawalManagement')} ({withdrawals.length})
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Review user redemption requests, approve with simulated transaction receipts, or reject with refund.
          </p>
        </div>

        {/* Filter pills */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setFilter(st)}
              className={`px-3 py-1 rounded-lg capitalize transition-all cursor-pointer ${
                filter === st
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Withdrawals Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-3.5">User</th>
                <th className="p-3.5">Method & Account</th>
                <th className="p-3.5">Amount</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No withdrawal requests matching filter.
                  </td>
                </tr>
              ) : (
                filtered.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="p-3.5">
                      <p className="font-bold text-slate-900 dark:text-slate-100">{req.userName}</p>
                      <p className="text-[11px] text-slate-400">{req.userEmail}</p>
                    </td>
                    <td className="p-3.5">
                      <span className="font-semibold uppercase text-slate-800 dark:text-slate-200">
                        {req.method.replace('_', ' ')}
                      </span>
                      <p className="text-[11px] text-slate-400 font-mono">{req.accountDetails}</p>
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {req.amountCoins} Coins
                      </span>
                      <p className="text-[11px] text-slate-400">(${req.amountCurrency})</p>
                    </td>
                    <td className="p-3.5 text-slate-500">
                      {new Date(req.requestedAt).toLocaleDateString()}
                    </td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        req.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                          : req.status === 'pending'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
                          : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                      }`}>
                        {req.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right space-x-1">
                      {req.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => handleOpenApprove(req)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] cursor-pointer shadow-xs"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => handleOpenReject(req)}
                            className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold text-[11px] cursor-pointer shadow-xs"
                          >
                            Reject
                          </button>
                        </>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">
                          {req.transactionRef || req.adminRemark || 'Processed'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Action Dialog */}
      {isModalOpen && selectedReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl relative">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
              {actionType === 'approve' ? 'Approve Withdrawal Request' : 'Reject Withdrawal Request'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              User: {selectedReq.userName} • {selectedReq.amountCoins} Coins (${selectedReq.amountCurrency})
            </p>

            <form onSubmit={handleConfirmAction} className="space-y-3.5 text-xs">
              {actionType === 'approve' && (
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Transaction / Receipt Reference ID
                  </label>
                  <input
                    type="text"
                    required
                    value={refId}
                    onChange={(e) => setRefId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 font-mono text-xs"
                  />
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {actionType === 'approve' ? 'Administrative Note (Optional)' : 'Rejection Reason (Refunds Coins)'}
                </label>
                <textarea
                  rows={2}
                  required={actionType === 'reject'}
                  value={remark}
                  onChange={(e) => setRemark(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl font-bold text-white shadow-xs cursor-pointer ${
                    actionType === 'approve'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  {actionType === 'approve' ? 'Confirm Approval' : 'Confirm Rejection'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
