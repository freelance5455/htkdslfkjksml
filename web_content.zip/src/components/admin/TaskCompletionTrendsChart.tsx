import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  TrendingUp, 
  Coins, 
  CheckCircle2, 
  Users, 
  Lightbulb, 
  Sliders, 
  Calendar, 
  BarChart3, 
  PieChart as PieIcon,
  ShieldAlert,
  ArrowUpRight,
  Filter,
  DollarSign
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { 
  get30DayCompletionTrendData, 
  getPayoutOptimizationMetrics, 
  getCategoryBreakdownData 
} from '../../utils/taskAnalytics';

interface TaskCompletionTrendsChartProps {
  onSelectCategoryFilter?: (category: string) => void;
}

export const TaskCompletionTrendsChart: React.FC<TaskCompletionTrendsChartProps> = ({
  onSelectCategoryFilter
}) => {
  const { taskSubmissions, tasks, systemSettings, t } = useApp();

  const [timeRange, setTimeRange] = useState<7 | 14 | 30>(30);
  const [chartType, setChartType] = useState<'area' | 'bar' | 'line'>('area');
  const [metricFocus, setMetricFocus] = useState<'all' | 'completions' | 'payout'>('all');
  const [showCategoryPie, setShowCategoryPie] = useState(false);

  // Compute trend data based on selected range
  const trendData = useMemo(() => {
    return get30DayCompletionTrendData(taskSubmissions, systemSettings, timeRange);
  }, [taskSubmissions, systemSettings, timeRange]);

  // Compute optimization metrics
  const metrics = useMemo(() => {
    return getPayoutOptimizationMetrics(trendData, taskSubmissions, tasks, systemSettings);
  }, [trendData, taskSubmissions, tasks, systemSettings]);

  // Category breakdown for distribution
  const categoryData = useMemo(() => {
    return getCategoryBreakdownData(taskSubmissions, tasks);
  }, [taskSubmissions, tasks]);

  const currencySymbol = systemSettings?.currencySymbol || '₹';

  // Custom Chart Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="p-3 bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-md text-xs space-y-1.5 min-w-[180px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-1 font-bold text-slate-200">
            <span>{data.date} ({data.dayLabel})</span>
            <span className="text-[10px] text-slate-400 font-mono">{data.isoDate}</span>
          </div>
          <div className="space-y-1 pt-0.5">
            <div className="flex items-center justify-between text-sky-400 font-semibold">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Tasks Completed:
              </span>
              <span className="font-bold">{data.completions}</span>
            </div>
            <div className="flex items-center justify-between text-amber-400 font-semibold">
              <span className="flex items-center gap-1">
                <Coins className="w-3.5 h-3.5" /> Payout:
              </span>
              <span className="font-bold">🪙 {data.payoutCoins}</span>
            </div>
            <div className="flex items-center justify-between text-emerald-400 font-medium text-[11px]">
              <span>Real Value:</span>
              <span>{currencySymbol}{data.payoutCurrency}</span>
            </div>
            <div className="flex items-center justify-between text-purple-400 font-medium text-[11px]">
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3" /> Unique Completers:
              </span>
              <span>{data.uniqueUsers} users</span>
            </div>
            <div className="flex items-center justify-between text-slate-400 text-[10px] pt-1 border-t border-slate-800/80">
              <span>Avg Reward/Task:</span>
              <span className="font-mono text-slate-300">🪙 {data.avgReward}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      
      {/* Top Banner & Control Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl text-white">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>Recharts 30-Day Intelligence</span>
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${metrics.payoutHealthColor}`}>
              {metrics.payoutHealthStatus} ({metrics.payoutHealthScore}/100)
            </span>
          </div>
          <h2 className="text-lg font-black text-white mt-1">
            Task Completion Trends & Payout Optimization
          </h2>
          <p className="text-xs text-slate-400">
            Real-time visual analysis of user engagement, coin outflow velocity, and reward sustainability.
          </p>
        </div>

        {/* View Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Time range buttons */}
          <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 text-xs">
            <button
              onClick={() => setTimeRange(7)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                timeRange === 7 ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              7D
            </button>
            <button
              onClick={() => setTimeRange(14)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                timeRange === 14 ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              14D
            </button>
            <button
              onClick={() => setTimeRange(30)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                timeRange === 30 ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              30D
            </button>
          </div>

          {/* Metric focus */}
          <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 text-xs">
            <button
              onClick={() => setMetricFocus('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                metricFocus === 'all' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Both
            </button>
            <button
              onClick={() => setMetricFocus('completions')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                metricFocus === 'completions' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Completions
            </button>
            <button
              onClick={() => setMetricFocus('payout')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                metricFocus === 'payout' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Payout 🪙
            </button>
          </div>

          {/* Chart Type */}
          <div className="flex items-center bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 text-xs">
            <button
              onClick={() => setChartType('area')}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                chartType === 'area' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Area Chart"
            >
              <TrendingUp className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setChartType('bar')}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                chartType === 'bar' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Bar Chart"
            >
              <BarChart3 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setChartType('line')}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                chartType === 'line' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Line Chart"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Toggle Category Breakdown */}
          <button
            onClick={() => setShowCategoryPie(!showCategoryPie)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all cursor-pointer ${
              showCategoryPie 
                ? 'bg-purple-600/30 border-purple-500/50 text-purple-300' 
                : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <PieIcon className="w-3.5 h-3.5 text-purple-400" />
            <span>Category Share</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>{timeRange}D Completions</span>
            <CheckCircle2 className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl font-black text-white">
            {metrics.total30DayCompletions.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400">
            Avg <strong className="text-sky-300">{metrics.avgDailyCompletions}</strong> tasks/day
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>{timeRange}D Coin Outflow</span>
            <Coins className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-black text-amber-400">
            🪙 {metrics.total30DayPayoutCoins.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400">
            Approx <strong className="text-emerald-400">{currencySymbol}{metrics.total30DayPayoutCurrency.toLocaleString()}</strong>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Avg Cost / Task</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-black text-emerald-400">
            🪙 {metrics.avgPayoutPerTask}
          </div>
          <div className="text-[11px] text-slate-400">
            Target: <span className="text-slate-300">25 - 60 coins</span>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Active Completers</span>
            <Users className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl font-black text-purple-300">
            {metrics.activeCompletersCount} Users
          </div>
          <div className="text-[11px] text-slate-400">
            {metrics.total30DayCompletions > 0 
              ? (metrics.total30DayCompletions / Math.max(1, metrics.activeCompletersCount)).toFixed(1)
              : 0} tasks/user
          </div>
        </div>
      </div>

      {/* Main Interactive Recharts Container */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              <span>Completion Velocity & Coin Payout (Last {timeRange} Days)</span>
            </h3>
          </div>
          <div className="flex items-center gap-4 text-xs font-semibold">
            {(metricFocus === 'all' || metricFocus === 'completions') && (
              <span className="flex items-center gap-1.5 text-sky-400">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
                Tasks Completed
              </span>
            )}
            {(metricFocus === 'all' || metricFocus === 'payout') && (
              <span className="flex items-center gap-1.5 text-amber-400">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                Coins Paid Out
              </span>
            )}
          </div>
        </div>

        {/* The Recharts Graphic */}
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'area' ? (
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorCompletions" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.05}/>
                  </linearGradient>
                  <linearGradient id="colorPayout" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.7}/>
                    <stop offset="95%" stopColor="#fbbf24" stopOpacity={0.02}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#64748b" 
                  fontSize={10} 
                  tickLine={false}
                  interval={timeRange === 30 ? 3 : 1}
                />
                <YAxis 
                  yAxisId="left" 
                  stroke="#64748b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                {metricFocus === 'all' && (
                  <YAxis 
                    yAxisId="right" 
                    orientation="right" 
                    stroke="#64748b" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                )}
                <Tooltip content={<CustomTooltip />} />
                {(metricFocus === 'all' || metricFocus === 'completions') && (
                  <Area
                    yAxisId="left"
                    type="monotone"
                    dataKey="completions"
                    stroke="#38bdf8"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#colorCompletions)"
                    name="Completed Tasks"
                  />
                )}
                {(metricFocus === 'all' || metricFocus === 'payout') && (
                  <Area
                    yAxisId={metricFocus === 'all' ? "right" : "left"}
                    type="monotone"
                    dataKey="payoutCoins"
                    stroke="#fbbf24"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorPayout)"
                    name="Coins Paid"
                  />
                )}
              </AreaChart>
            ) : chartType === 'bar' ? (
              <BarChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#64748b" 
                  fontSize={10} 
                  tickLine={false}
                  interval={timeRange === 30 ? 3 : 1}
                />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                {(metricFocus === 'all' || metricFocus === 'completions') && (
                  <Bar dataKey="completions" fill="#38bdf8" radius={[4, 4, 0, 0]} name="Completed Tasks" />
                )}
                {(metricFocus === 'all' || metricFocus === 'payout') && (
                  <Bar dataKey="payoutCoins" fill="#fbbf24" radius={[4, 4, 0, 0]} name="Coins Paid" />
                )}
              </BarChart>
            ) : (
              <LineChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#64748b" 
                  fontSize={10} 
                  tickLine={false}
                  interval={timeRange === 30 ? 3 : 1}
                />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                {(metricFocus === 'all' || metricFocus === 'completions') && (
                  <Line 
                    type="monotone" 
                    dataKey="completions" 
                    stroke="#38bdf8" 
                    strokeWidth={3} 
                    dot={{ r: 2 }} 
                    name="Completed Tasks" 
                  />
                )}
                {(metricFocus === 'all' || metricFocus === 'payout') && (
                  <Line 
                    type="monotone" 
                    dataKey="payoutCoins" 
                    stroke="#fbbf24" 
                    strokeWidth={2} 
                    dot={{ r: 2 }} 
                    name="Coins Paid" 
                  />
                )}
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800">
          <span>Tip: Hover over data points to inspect daily currency equivalents and active users.</span>
          <span className="font-mono text-slate-300">
            {timeRange} Days Aggregated • Projected Run Rate: 🪙 {metrics.projectedMonthlyCoins.toLocaleString()} / mo
          </span>
        </div>
      </div>

      {/* Category Breakdown & Optimization Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Category Breakdown Card */}
        <div className="lg:col-span-1 p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-purple-400" />
              <span>Category Payout Share</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">
              {categoryData.length} Categories
            </span>
          </div>

          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={3}
                  dataKey="completions"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: any, name: any, item: any) => [
                    `${value} completions (${item.payload.percentage}%) • 🪙${item.payload.totalCoins} paid`,
                    item.payload.categoryLabel
                  ]}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '11px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Category List */}
          <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
            {categoryData.map((cat) => (
              <div 
                key={cat.category}
                onClick={() => onSelectCategoryFilter && onSelectCategoryFilter(cat.category)}
                className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 text-xs transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: cat.color }} />
                  <span className="font-medium text-slate-300 group-hover:text-white transition-colors truncate max-w-[110px]">
                    {cat.categoryLabel}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-bold text-white">{cat.completions}</span>
                  <span className="text-[10px] text-slate-400 ml-1">({cat.percentage}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Payout Optimization Insights Panel */}
        <div className="lg:col-span-2 p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <span>Admin Payout Optimization Recommendations</span>
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
              Active Simulator
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Based on the past {timeRange} days of user completions and coin withdrawal velocity, here is how you can tune task rewards for higher retention and lower platform liability:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {metrics.recommendations.map((rec) => (
              <div 
                key={rec.id} 
                className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-1.5"
              >
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full shrink-0 ${
                    rec.type === 'positive' 
                      ? 'bg-emerald-400' 
                      : rec.type === 'warning' 
                        ? 'bg-amber-400' 
                        : 'bg-sky-400'
                  }`} />
                  <h4 className="text-xs font-bold text-slate-200">
                    {rec.title}
                  </h4>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {rec.description}
                </p>
                {rec.suggestedAction && (
                  <div className="pt-1">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded-md border border-purple-500/20">
                      <ArrowUpRight className="w-3 h-3" />
                      {rec.suggestedAction}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Quick Action Guide */}
          <div className="p-3 rounded-2xl bg-purple-950/30 border border-purple-800/40 flex items-center justify-between text-xs">
            <span className="text-purple-300 text-[11px]">
              Ready to adjust reward amounts or requirements? Go to the <strong>Tasks</strong> tab to edit tasks dynamically.
            </span>
            <span className="text-[10px] font-black text-purple-400 bg-purple-900/60 px-2.5 py-1 rounded-xl">
              1 Coin = {currencySymbol}{systemSettings?.coinsPerCurrencyUnit || 1}
            </span>
          </div>
        </div>

      </div>

    </div>
  );
};
