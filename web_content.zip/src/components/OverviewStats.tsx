import type { GlobalOverview } from '../types/attendance';

interface OverviewStatsProps {
  overview: GlobalOverview;
}

export function OverviewStats({ overview }: OverviewStatsProps) {
  const items = [
    {
      label: 'Total Departments',
      value: overview.totalDepartments,
      valueClass: 'text-slate-900',
    },
    {
      label: 'Total Workers',
      value: overview.totalWorkers,
      valueClass: 'text-slate-900',
    },
    {
      label: 'Present Today',
      value: overview.presentToday,
      valueClass: 'text-emerald-600',
    },
    {
      label: 'Absent Today',
      value: overview.absentToday,
      valueClass: 'text-rose-600',
    },
  ];

  return (
    <section aria-label="Today's Attendance Overview" className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      {items.map((item) => (
        <div
          key={item.label}
          className="bg-white rounded-2xl border border-slate-200/80 shadow-sm px-4 py-4 sm:px-5 sm:py-5"
        >
          <p className="text-xs sm:text-sm font-medium text-slate-500 truncate">{item.label}</p>
          <p className={`mt-1.5 text-2xl sm:text-3xl font-bold tracking-tight tabular-nums ${item.valueClass}`}>
            {item.value}
          </p>
        </div>
      ))}
    </section>
  );
}
