import Link from "next/link";
import { DEVELOPER } from "@/lib/developer";
import { BatBallLogo } from "./cricket";

export function SiteFooter() {
  const year = new Date().getFullYear();
  return (
    <footer className="mt-12 border-t border-slate-800/80 bg-[#060910]">
      <div className="mx-auto max-w-7xl px-4 py-10">
        <div className="grid gap-8 md:grid-cols-[1.6fr_1fr]">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-900 ring-1 ring-slate-800">
                <BatBallLogo className="h-6 w-6" />
              </span>
              <span className="text-lg font-black tracking-tight">
                MATCH <span className="text-emerald-400">CRICKET</span>
              </span>
            </div>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-slate-400">
              A professional live cricket scoring platform — ball-by-ball engine, real-time
              scorecards, player statistics and automatic Urdu commentary with voice.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {["Scoring", "Leagues", "Urdu Commentary", "Offline Mode"].map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-slate-800 bg-slate-900/60 px-2.5 py-1 text-[11px] font-semibold text-slate-400"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-widest text-slate-300">
              Platform
            </h3>
            <ul className="mt-3 space-y-2 text-sm">
              {[
                { href: "/", label: "Live Matches" },
                { href: "/leagues", label: "Leagues & Tournaments" },
                { href: "/new", label: "Create New Match" },
                { href: "/history", label: "Match History" },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-slate-400 transition hover:text-emerald-400">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-slate-800/80 pt-5 text-center sm:flex-row sm:text-left">
          <p className="text-xs text-slate-500">
            © {year} MATCH CRICKET · Real-time cricket scoring engine
          </p>
          {/* Developer credit — attribution only */}
          <span className="inline-flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-1.5">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
              {DEVELOPER.tagline}
            </span>
            <span className="text-xs font-black text-slate-200">{DEVELOPER.name}</span>
          </span>
        </div>
      </div>
    </footer>
  );
}
