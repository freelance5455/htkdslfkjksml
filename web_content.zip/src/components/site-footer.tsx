import Link from "next/link";
import { LogoMark } from "@/components/logo-mark";
import { FOOTER_SECTIONS, SITE } from "@/lib/site";

export function SiteFooter() {
  return (
    <footer className="relative overflow-hidden bg-navy-deep text-ivory">
      <div className="pattern-lattice absolute inset-0 opacity-[0.06]" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-gold">
            <LogoMark className="size-8" />
            <span className="font-serif text-3xl font-bold text-ivory">لأنه الله</span>
          </div>
          <p className="max-w-sm leading-8 text-ivory/65">{SITE.tagline}</p>
          <p className="text-sm text-ivory/50">
            إعداد الطالب <span className="text-gold-light">{SITE.author}</span> — {SITE.school}
          </p>
        </div>

        <nav aria-label="أقسام المنصة">
          <h2 className="mb-4 font-serif text-lg text-gold-light">الأقسام</h2>
          <ul className="flex flex-wrap gap-2.5 text-sm">
            {FOOTER_SECTIONS.map((item) => (
              <li key={item.href}>
                <Link
                  className="inline-flex items-center rounded-full border border-gold/30 bg-white/[0.03] px-4 py-2 text-ivory/80 transition-all hover:-translate-y-0.5 hover:border-gold hover:bg-gold hover:text-navy"
                  href={item.href}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className="mb-4 font-serif text-lg text-gold-light">المشروع</h2>
          <ul className="space-y-2.5 text-sm text-ivory/70">
            <li>
              <Link className="transition-colors hover:text-gold-light" href="/about">
                عن مشروع لأنه الله
              </Link>
            </li>
            <li>
              <Link className="transition-colors hover:text-gold-light" href="/about#sources">
                المصادر والمراجع
              </Link>
            </li>
            <li>
              <Link className="transition-colors hover:text-gold-light" href="/form-a">
                نموذج أ — استمارة التقديم
              </Link>
            </li>
            <li>نصوص القرآن والتلاوة: alquran.cloud</li>
          </ul>
        </div>
      </div>
      <div className="relative border-t border-white/10 py-5 text-center text-xs text-ivory/45">
        {SITE.copyright}
      </div>
    </footer>
  );
}
