import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Cpu, 
  Smartphone, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  RefreshCw, 
  Battery, 
  Sun, 
  Volume2, 
  HardDrive,
  Info
} from 'lucide-react';
import { isWakeLockSupported, isWakeLockActive } from '../utils/wakeLock';
import { getAudioContext } from '../utils/audioEngine';

export const SensorsDiagnostic: React.FC = () => {
  const [wakeLockOk, setWakeLockOk] = useState<boolean>(false);
  const [activeWake, setActiveWake] = useState<boolean>(false);
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState<boolean | null>(null);
  const [localStorageOk, setLocalStorageOk] = useState<boolean>(true);
  const [browserInfo, setBrowserInfo] = useState<string>('');

  useEffect(() => {
    checkDiagnostics();
  }, []);

  const checkDiagnostics = () => {
    setWakeLockOk(isWakeLockSupported());
    setActiveWake(isWakeLockActive());
    setBrowserInfo(navigator.userAgent);

    // Test localStorage
    try {
      localStorage.setItem('screensound_test', '1');
      localStorage.removeItem('screensound_test');
      setLocalStorageOk(true);
    } catch {
      setLocalStorageOk(false);
    }

    // Battery API if available
    if ('getBattery' in navigator) {
      (navigator as unknown as { getBattery: () => Promise<{ level: number; charging: boolean }> })
        .getBattery()
        .then((battery) => {
          setBatteryLevel(Math.round(battery.level * 100));
          setIsCharging(battery.charging);
        })
        .catch(() => {});
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white font-heading">
              فحص الحساسات والعتاد البرمجي
            </h2>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              تقرير فني فوري حول قدرات جهازك ومدى توافقه مع معايير أندرويد 8.1 والأحدث لتشغيل خدمات ScreenSound Fixer دون إنترنت.
            </p>
          </div>

          <button
            onClick={checkDiagnostics}
            className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-xs font-bold text-slate-200 px-4 py-2.5 rounded-xl border border-slate-700 transition-all cursor-pointer self-start sm:self-auto"
          >
            <RefreshCw className="w-4 h-4 text-red-500" />
            <span>إعادة فحص المستشعرات</span>
          </button>
        </div>
      </div>

      {/* Grid of Diagnostic Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Wake Lock Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-400">حساس قفل الشاشة (Wake Lock)</span>
              {wakeLockOk ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-amber-400" />
              )}
            </div>
            <h4 className="text-base font-bold text-white">
              {wakeLockOk ? 'مدعوم رسمياً من النظام' : 'يعمل بالوضع الاحتياطي'}
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              يسمح للتطبيق بإبقاء الهاتف مضاءً لمنع حجب المكالمات عند تعطل حساس القرب.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-800 text-xs">
            <span className="text-slate-400">الحالة الراهنة: </span>
            <span className={activeWake ? 'text-emerald-400 font-bold' : 'text-slate-300'}>
              {activeWake ? 'مفعل وشغال حالياً' : 'جاهز للتفعيل'}
            </span>
          </div>
        </div>

        {/* Audio Engine Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-400">محرك الصوت الرقمي (WebAudio)</span>
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <h4 className="text-base font-bold text-white">
              جاهز لتوليد نبضات التفريغ
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              تردد أخذ العينات: {getAudioContext().sampleRate} هرتز، بحالة تشغيلية ممتازة.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-800 text-xs">
            <span className="text-slate-400">قنوات الإخراج: </span>
            <span className="text-white font-mono font-bold">مكبر ستيريو مدمج</span>
          </div>
        </div>

        {/* Offline Storage Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-400">التخزين المحلي دون إنترنت</span>
              {localStorageOk ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-red-500" />
              )}
            </div>
            <h4 className="text-base font-bold text-white">
              {localStorageOk ? 'الذاكرة المحلية جاهزة' : 'التخزين المحلي مقيد'}
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              يتم حفظ تفضيلات التشغيل وإعدادات الشاشة تلقائياً على جهازك دون الحاجة لسيرفر أو حساب.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-800 text-xs">
            <span className="text-slate-400">التزامن: </span>
            <span className="text-emerald-400 font-bold">100% بدون إنترنت (Offline)</span>
          </div>
        </div>

        {/* Battery Status if supported */}
        {batteryLevel !== null && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-400">مستوى البطارية</span>
                <Battery className="w-5 h-5 text-emerald-400" />
              </div>
              <h4 className="text-base font-bold text-white font-mono">
                {batteryLevel}% {isCharging ? '(قيد الشحن)' : ''}
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                استهلاك وضع إبقاء الشاشة أثناء المكالمات متوافق مع معايير الحفاظ على الطاقة.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-800 text-xs">
              <span className="text-slate-400">كفاءة الاستهلاك: </span>
              <span className="text-emerald-400 font-bold">ممتازة</span>
            </div>
          </div>
        )}
      </div>

      {/* Android 8.1+ Compatibility Sheet */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-md space-y-3">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-red-500" />
          <span>التوافقية مع إصدارات أندرويد 8.1 (Oreo) فما فوق</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          تمت برمجة هذا التطبيق ليتوافق بسلاسة مع أجهزة أندرويد القديمة والحديثة بدءاً من أندرويد 8.1 وحتى أحدث الإصدارات، مع احترام معايير نظام أمان Google Sandbox وحماية خصوصية المستخدم الكاملة.
        </p>

        <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-[11px] font-mono text-slate-400 break-all">
          <span className="text-red-400 font-bold">بصمة النظام المشغّل: </span>
          {browserInfo}
        </div>
      </div>
    </div>
  );
};
