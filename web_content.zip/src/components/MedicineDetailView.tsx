import React, { useState } from 'react';
import {
  X,
  Bookmark,
  Share2,
  Check,
  Globe,
  Pill,
  ShieldAlert,
  Info,
  Clock,
  AlertTriangle,
  Utensils,
  HelpCircle,
  Stethoscope,
  Baby,
  Car,
  Wine,
  FileText,
  HeartPulse,
  Flame,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MedicineItem, MedicineLanguage } from '../types/medicine';

interface MedicineDetailViewProps {
  medicine: MedicineItem;
  currentLanguage: MedicineLanguage;
  onLanguageChange: (lang: MedicineLanguage) => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onClose: () => void;
}

export const MedicineDetailView: React.FC<MedicineDetailViewProps> = ({
  medicine,
  currentLanguage,
  onLanguageChange,
  isBookmarked,
  onToggleBookmark,
  onClose
}) => {
  const [copiedShare, setCopiedShare] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const content = medicine.content[currentLanguage] || medicine.content.English;

  // Handle share
  const handleShare = async () => {
    const text = `💊 ${content.name}\nGeneric: ${content.genericName}\nBrands: ${content.brandNames.join(', ')}\n\n${content.description}\n\nLearn more on Mediguide AI.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: content.name,
          text,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    } catch (err) {
      console.warn('Failed to copy:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-center items-end sm:items-center p-0 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 60, opacity: 0 }}
        className="bg-white w-full sm:max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92vh] overflow-hidden my-auto"
      >
        {/* Sticky Header with Title & Controls */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 shrink-0 flex flex-col space-y-3 relative">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/15 text-white">
                <Pill className="w-6 h-6 text-sky-300" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-sky-300">
                  {content.categoryName}
                </span>
                <h2 className="text-lg sm:text-xl font-black leading-snug">{content.name}</h2>
                <p className="text-xs text-slate-300 font-medium pt-0.5">
                  Generic: <span className="text-white font-semibold">{content.genericName}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => onToggleBookmark(medicine.id)}
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  isBookmarked
                    ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
                title="Bookmark Medicine"
              >
                <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-slate-950' : ''}`} />
              </button>

              <button
                onClick={handleShare}
                className="p-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all cursor-pointer"
                title="Share Medicine"
              >
                {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              </button>

              <button
                onClick={onClose}
                className="p-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Trilingual Language Selector Bar */}
          <div className="pt-2 border-t border-white/15 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-slate-300 font-bold text-[11px]">
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              <span>Language:</span>
            </div>

            <div className="flex bg-black/40 p-1 rounded-xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as MedicineLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => onLanguageChange(lang)}
                  className={`px-3 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    currentLanguage === lang
                      ? 'bg-sky-500 text-white shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-5 overflow-y-auto space-y-6 text-slate-800 text-xs sm:text-sm">
          {/* Common Brand Names Banner */}
          <div className="bg-sky-50 p-4 rounded-2xl border border-sky-200/80 space-y-1.5">
            <div className="flex items-center gap-2 font-black text-sky-900 text-xs uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-sky-600" />
              <span>
                {currentLanguage === 'Hindi'
                  ? 'प्रसिद्ध ब्रांड नाम (Common Brands)'
                  : currentLanguage === 'Marathi'
                  ? 'प्रसिद्ध ब्रँड नावे (Common Brands)'
                  : 'Common Brand Names'}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {content.brandNames.map((brand, i) => (
                <span key={i} className="bg-white px-3 py-1 rounded-xl text-xs font-bold text-sky-950 border border-sky-200 shadow-2xs">
                  {brand}
                </span>
              ))}
            </div>
          </div>

          {/* Medicine Description */}
          <div className="space-y-2">
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <Info className="w-4 h-4 text-sky-600" />
              <span>
                {currentLanguage === 'Hindi'
                  ? 'दवा का परिचय (Description)'
                  : currentLanguage === 'Marathi'
                  ? 'औषधाची माहिती (Description)'
                  : 'Medicine Description'}
              </span>
            </h3>
            <p className="text-slate-700 leading-relaxed font-medium bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
              {content.description}
            </p>
          </div>

          {/* Key Uses */}
          <div className="space-y-2">
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-emerald-600" />
              <span>
                {currentLanguage === 'Hindi'
                  ? 'मुख्य उपयोग (Uses & Indications)'
                  : currentLanguage === 'Marathi'
                  ? 'मुख्य उपयोग (Uses)'
                  : 'Uses & Benefits'}
              </span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {content.uses.map((use, idx) => (
                <div key={idx} className="bg-emerald-50/60 p-3 rounded-2xl border border-emerald-200/70 flex items-start gap-2 text-emerald-950 font-medium">
                  <span className="text-emerald-600 font-bold mt-0.5">•</span>
                  <span>{use}</span>
                </div>
              ))}
            </div>
          </div>

          {/* How It Works */}
          <div className="space-y-2">
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <HeartPulse className="w-4 h-4 text-indigo-600" />
              <span>
                {currentLanguage === 'Hindi'
                  ? 'यह दवा कैसे काम करती है (Mechanism of Action)'
                  : currentLanguage === 'Marathi'
                  ? 'हे औषध कसे कार्य करते (How It Works)'
                  : 'How It Works'}
              </span>
            </h3>
            <div className="bg-indigo-50/60 p-3.5 rounded-2xl border border-indigo-200/80 text-indigo-950 leading-relaxed font-medium">
              {content.howItWorks}
            </div>
          </div>

          {/* Dosage & Administration Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Recommended Dosage */}
            <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200/80 space-y-1.5">
              <div className="flex items-center gap-2 font-extrabold text-amber-900 text-xs">
                <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  {currentLanguage === 'Hindi'
                    ? 'सामान्य खुराक (Recommended Dosage)'
                    : currentLanguage === 'Marathi'
                    ? 'सामान्य डोस (Dosage)'
                    : 'Recommended Dosage'}
                </span>
              </div>
              <p className="text-amber-950 text-xs font-medium leading-relaxed">
                {content.recommendedDosage}
              </p>
            </div>

            {/* How to Take & Food Relation */}
            <div className="bg-teal-50/60 p-4 rounded-2xl border border-teal-200/80 space-y-1.5">
              <div className="flex items-center gap-2 font-extrabold text-teal-900 text-xs">
                <Utensils className="w-4 h-4 text-teal-600 shrink-0" />
                <span>
                  {currentLanguage === 'Hindi'
                    ? 'लेने का तरीका और भोजन (Food Relation)'
                    : currentLanguage === 'Marathi'
                    ? 'घेण्याची पद्धत आणि जेवण (Food Relation)'
                    : 'How to Take & Food Relation'}
                </span>
              </div>
              <div className="space-y-1 text-teal-950 text-xs font-medium">
                <p><strong>Food relation:</strong> <span className="underline decoration-teal-400 font-bold">{content.foodRelation}</span></p>
                <p>{content.howToTake}</p>
              </div>
            </div>
          </div>

          {/* Missed Dose & Overdose Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-slate-100 p-3.5 rounded-2xl border border-slate-200 space-y-1">
              <span className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                {currentLanguage === 'Hindi' ? 'खुराक छूट जाने पर (Missed Dose)' : currentLanguage === 'Marathi' ? 'डोस चुकल्यास (Missed Dose)' : 'Missed Dose Advice'}
              </span>
              <p className="text-slate-600 text-xs leading-relaxed">{content.missedDoseAdvice}</p>
            </div>

            <div className="bg-rose-50 p-3.5 rounded-2xl border border-rose-200 space-y-1">
              <span className="font-extrabold text-rose-900 text-xs flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                {currentLanguage === 'Hindi' ? 'ओवरडोज की जानकारी (Overdose)' : currentLanguage === 'Marathi' ? 'अतिप्रमाणात डोस घेतल्यास (Overdose)' : 'Overdose Information'}
              </span>
              <p className="text-rose-950 text-xs leading-relaxed font-medium">{content.overdoseInformation}</p>
            </div>
          </div>

          {/* Side Effects */}
          <div className="space-y-2">
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600" />
              <span>
                {currentLanguage === 'Hindi'
                  ? 'दुष्प्रभाव (Side Effects)'
                  : currentLanguage === 'Marathi'
                  ? 'दुष्परिणाम (Side Effects)'
                  : 'Side Effects'}
              </span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Common Side Effects */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1.5">
                <span className="font-extrabold text-slate-700 text-xs">Common Side Effects</span>
                <ul className="space-y-1 text-slate-600 text-xs">
                  {content.commonSideEffects.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Serious Side Effects */}
              <div className="bg-rose-50/70 p-3.5 rounded-2xl border border-rose-200/80 space-y-1.5">
                <span className="font-extrabold text-rose-900 text-xs">Serious Side Effects (Seek Help)</span>
                <ul className="space-y-1 text-rose-900 text-xs font-medium">
                  {content.seriousSideEffects.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1 shrink-0"></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Warnings & Precautions */}
          <div className="space-y-2">
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>
                {currentLanguage === 'Hindi'
                  ? 'चेतावनी और सावधानियां (Warnings & Precautions)'
                  : currentLanguage === 'Marathi'
                  ? 'सावधगिरी आणि इशारे (Warnings)'
                  : 'Warnings & Precautions'}
              </span>
            </h3>
            <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200/80 space-y-2">
              {content.warningsPrecautions.map((warn, i) => (
                <div key={i} className="flex items-start gap-2 text-amber-950 font-medium text-xs">
                  <span className="text-amber-600 font-bold">•</span>
                  <span>{warn}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Lifestyle & Safety Warnings Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Pregnancy & Breastfeeding */}
            <div className="bg-purple-50/60 p-3.5 rounded-2xl border border-purple-200/80 space-y-2">
              <div className="flex items-center gap-1.5 font-extrabold text-purple-900 text-xs">
                <Baby className="w-4 h-4 text-purple-600" />
                <span>Pregnancy & Lactation</span>
              </div>
              <p className="text-purple-950 text-xs"><strong>Pregnancy:</strong> {content.pregnancyInfo}</p>
              <p className="text-purple-950 text-xs"><strong>Breastfeeding:</strong> {content.breastfeedingInfo}</p>
            </div>

            {/* Driving & Alcohol */}
            <div className="bg-blue-50/60 p-3.5 rounded-2xl border border-blue-200/80 space-y-2">
              <div className="flex items-center gap-1.5 font-extrabold text-blue-900 text-xs">
                <Car className="w-4 h-4 text-blue-600" />
                <span>Driving & Alcohol</span>
              </div>
              <p className="text-blue-950 text-xs flex items-start gap-1">
                <Car className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                <span><strong>Driving:</strong> {content.drivingWarning}</span>
              </p>
              <p className="text-blue-950 text-xs flex items-start gap-1">
                <Wine className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                <span><strong>Alcohol:</strong> {content.alcoholInteraction}</span>
              </p>
            </div>
          </div>

          {/* Drug Interactions & Storage */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
              <span className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                <Pill className="w-3.5 h-3.5 text-slate-500" />
                Drug Interactions
              </span>
              <p className="text-slate-600 text-xs">{content.drugInteractions.join(', ')}</p>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
              <span className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                Storage Instructions
              </span>
              <p className="text-slate-600 text-xs">{content.storageInstructions}</p>
            </div>
          </div>

          {/* Frequently Asked Questions */}
          {content.faqs && content.faqs.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-sky-600" />
                <span>Frequently Asked Questions</span>
              </h3>
              <div className="space-y-2">
                {content.faqs.map((faq, idx) => {
                  const isOpen = openFaqIndex === idx;
                  return (
                    <div key={idx} className="bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden">
                      <button
                        onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                        className="w-full p-3.5 text-left font-bold text-slate-800 text-xs flex items-center justify-between gap-2 cursor-pointer"
                      >
                        <span>{faq.question}</span>
                        {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />}
                      </button>
                      {isOpen && (
                        <div className="px-3.5 pb-3.5 pt-0 text-slate-600 text-xs leading-relaxed font-medium border-t border-slate-200/60 pt-2">
                          {faq.answer}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Required Educational Disclaimer */}
          <div className="bg-amber-50 p-4 rounded-2xl border border-amber-300 text-amber-950 space-y-1.5 mt-4">
            <div className="flex items-center gap-2 font-black text-xs text-amber-900 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Educational Disclaimer</span>
            </div>
            <p className="text-[11px] leading-relaxed font-medium text-amber-900">
              "This information is provided for educational purposes only and should not replace professional medical advice. Always consult a qualified healthcare professional before taking or stopping any medicine."
            </p>
          </div>
        </div>

        {/* Footer Close Button */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 shrink-0">
          <button
            onClick={onClose}
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-2xl transition-colors cursor-pointer shadow-md"
          >
            Close Medicine Guide
          </button>
        </div>
      </motion.div>
    </div>
  );
};
