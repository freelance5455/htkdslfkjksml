import React, { useState } from 'react';
import { useKingdom } from '../context/KingdomContext';
import { CIVILIZATIONS, BUILDINGS_CONFIG } from '../game/gameConfig';
import { BuildingType, ResourceType } from '../types/kingdom';
import {
  Wheat,
  Trees,
  Mountain,
  Coins,
  Warehouse,
  TrendingUp,
  TrendingDown,
  X,
  Clock,
  Crown,
  ArrowRight,
} from 'lucide-react';

interface ResourceDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialResource?: ResourceType;
  onNavigateTab?: (tab: 'village' | 'construction' | 'university' | 'army' | 'map' | 'parliament') => void;
}

interface ResourceItemConfig {
  name: string;
  shortName: string;
  icon: React.ReactNode;
  color: string;
  amount: number;
  max: number;
  rate: number;
  building: BuildingType;
  storageBuilding: BuildingType;
  description: string;
  consumptionInfo: string;
}

export const ResourceDetailModal: React.FC<ResourceDetailModalProps> = ({
  isOpen,
  onClose,
  initialResource = 'food',
  onNavigateTab,
}) => {
  const { kingdom, rates, storageMax, playSound } = useKingdom();
  const [selectedRes, setSelectedRes] = useState<ResourceType>(initialResource);

  if (!isOpen || !kingdom) return null;

  const civ = CIVILIZATIONS[kingdom.civilization];

  const resourceConfigs: Record<ResourceType, ResourceItemConfig> = {
    food: {
      name: 'Comida (Cereales y Provisiones)',
      shortName: 'Comida',
      icon: <Wheat className="w-5 h-5 text-amber-500" />,
      color: 'amber',
      amount: kingdom.resources.food,
      max: storageMax.foodMax,
      rate: rates.foodPerHour,
      building: 'farm',
      storageBuilding: 'granary',
      description: 'Alimenta a los aldeanos del feudo y sustenta los regimientos de tu ejército.',
      consumptionInfo: 'Las tropas consumen raciones continuamente. Si la tasa es negativa, las reservas descenderán.',
    },
    wood: {
      name: 'Madera (Robles y Vigas)',
      shortName: 'Madera',
      icon: <Trees className="w-5 h-5 text-emerald-500" />,
      color: 'emerald',
      amount: kingdom.resources.wood,
      max: storageMax.resourcesMax,
      rate: rates.woodPerHour,
      building: 'lumberMill',
      storageBuilding: 'warehouse',
      description: 'Material indispensable para levantar empalizadas, casernas, arcos y catapultas.',
      consumptionInfo: 'No se consume con el tiempo, se emplea directamente en obras y reclutamiento.',
    },
    stone: {
      name: 'Piedra (Sillares de Cantera)',
      shortName: 'Piedra',
      icon: <Mountain className="w-5 h-5 text-slate-400" />,
      color: 'slate',
      amount: kingdom.resources.stone,
      max: storageMax.resourcesMax,
      rate: rates.stonePerHour,
      building: 'quarry',
      storageBuilding: 'warehouse',
      description: 'Bloques pétreos para erigir murallas, castillos, universidades y fortificaciones.',
      consumptionInfo: 'Esencial para las edificaciones de mayor rango defensivo y civil.',
    },
    gold: {
      name: 'Oro (Arcas Reales y Tributos)',
      shortName: 'Oro',
      icon: <Coins className="w-5 h-5 text-yellow-500" />,
      color: 'yellow',
      amount: kingdom.resources.gold,
      max: storageMax.resourcesMax,
      rate: rates.goldPerHour,
      building: 'goldMine',
      storageBuilding: 'warehouse',
      description: 'Divisa del reino para financiar avances científicos en la universidad y equipamiento bélico.',
      consumptionInfo: 'Generado principalmente por la mina de oro y recaudado por el tributo fiscal del parlamento.',
    },
  };

  const current = resourceConfigs[selectedRes];
  const percentFull = Math.min(100, Math.round((current.amount / current.max) * 100));

  let timeEstimateText = '';
  if (current.rate > 0) {
    const remainingToFull = Math.max(0, current.max - current.amount);
    const hoursToFull = remainingToFull / current.rate;
    if (hoursToFull <= 0) {
      timeEstimateText = 'Almacén al 100% de capacidad. Se pierde el excedente.';
    } else if (hoursToFull < 1) {
      timeEstimateText = `Lleno en aprox. ${Math.round(hoursToFull * 60)} minutos`;
    } else {
      const h = Math.floor(hoursToFull);
      const m = Math.round((hoursToFull - h) * 60);
      timeEstimateText = `Lleno en aprox. ${h}h ${m}m`;
    }
  } else if (current.rate < 0) {
    const hoursToDepletion = current.amount / Math.abs(current.rate);
    if (hoursToDepletion < 1) {
      timeEstimateText = `¡Agotamiento inminente en ${Math.round(hoursToDepletion * 60)} minutos!`;
    } else {
      const h = Math.floor(hoursToDepletion);
      timeEstimateText = `¡Agotamiento de provisiones en ${h} horas!`;
    }
  } else {
    timeEstimateText = 'Producción en equilibrio nulo (+0/h).';
  }

  const prodBuildingInfo = BUILDINGS_CONFIG[current.building];
  const storageBuildingInfo = BUILDINGS_CONFIG[current.storageBuilding];
  const prodBuildingLevel = kingdom.buildings[current.building] || 0;
  const storageBuildingLevel = kingdom.buildings[current.storageBuilding] || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col no-scrollbar">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-stone-800 flex items-center justify-between sticky top-0 bg-stone-900/95 backdrop-blur z-10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-950/40 border border-amber-800/60 text-amber-400">
              <Warehouse className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-100 font-serif">
                Tesorería y Graneros Reales
              </h3>
              <p className="text-xs text-stone-400">
                Estado y balance detallado de las reservas de {kingdom.kingdomName}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playSound('click');
              onClose();
            }}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition cursor-pointer"
            title="Cerrar panel de tesorería"
            aria-label="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Resource Selector Tabs */}
        <div className="px-4 sm:px-6 pt-4">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            {(Object.keys(resourceConfigs) as ResourceType[]).map((resKey) => {
              const cfg = resourceConfigs[resKey];
              const isSelected = selectedRes === resKey;
              return (
                <button
                  key={resKey}
                  onClick={() => {
                    setSelectedRes(resKey);
                    playSound('click');
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 cursor-pointer ${
                    isSelected
                      ? 'bg-amber-600 text-stone-950 shadow-md scale-102'
                      : 'bg-stone-800/80 hover:bg-stone-800 text-stone-300 border border-stone-700/60'
                  }`}
                  title={`Seleccionar ${cfg.shortName}: ${Math.floor(cfg.amount).toLocaleString()} / ${cfg.max.toLocaleString()}`}
                  aria-label={`Seleccionar ${cfg.shortName}`}
                >
                  {cfg.icon}
                  <span>{cfg.shortName}</span>
                  <span className="text-[10px] opacity-80 font-mono">
                    {Math.floor(cfg.amount).toLocaleString()}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Content Details */}
        <div className="p-4 sm:p-6 space-y-5">
          <div className="p-4 rounded-2xl bg-stone-950/70 border border-stone-800/80">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-stone-900 border border-stone-800">
                  {current.icon}
                </div>
                <div>
                  <h4 className="font-bold text-stone-100 text-sm">{current.name}</h4>
                  <p className="text-xs text-stone-400">{current.description}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold text-stone-400">Tasa neta por hora</div>
                <div
                  className={`text-base font-bold font-mono flex items-center justify-end gap-1 ${
                    current.rate >= 0 ? 'text-emerald-400' : 'text-red-400'
                  }`}
                >
                  {current.rate >= 0 ? (
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-400" />
                  )}
                  <span>{current.rate >= 0 ? `+${current.rate}` : current.rate}/h</span>
                </div>
              </div>
            </div>

            {/* Capacity Bar */}
            <div className="space-y-1.5 pt-2 border-t border-stone-800/60">
              <div className="flex items-center justify-between text-xs">
                <span className="text-stone-300 font-medium">Capacidad de Reserva:</span>
                <span className="font-mono text-stone-100 font-bold">
                  {Math.floor(current.amount).toLocaleString()} / {current.max.toLocaleString()} ({percentFull}%)
                </span>
              </div>
              <div className="w-full bg-stone-800/90 h-3 rounded-full overflow-hidden p-0.5 border border-stone-700/50">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    percentFull >= 95
                      ? 'bg-red-500'
                      : percentFull >= 80
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{ width: `${percentFull}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-stone-400 pt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{timeEstimateText}</span>
                </span>
                {percentFull >= 95 && (
                  <span className="text-red-400 font-bold">¡Ampliar almacenes recomendado!</span>
                )}
              </div>
            </div>
          </div>

          {/* Breakdown Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 rounded-xl bg-stone-900/90 border border-stone-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs text-stone-400 font-medium">Edificio Productor</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-800 text-stone-300">
                    Nivel {prodBuildingLevel}
                  </span>
                </div>
                <div className="font-bold text-sm text-stone-200 mb-1">{prodBuildingInfo.name}</div>
                <p className="text-xs text-stone-400 leading-relaxed">
                  {prodBuildingLevel > 0
                    ? prodBuildingInfo.effectDescription(prodBuildingLevel)
                    : 'Sin construir. Levántalo para comenzar a recolectar.'}
                </p>
              </div>
              {onNavigateTab && (
                <button
                  onClick={() => {
                    onClose();
                    onNavigateTab('construction');
                    playSound('click');
                  }}
                  className="mt-3 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-750 text-amber-400 hover:text-amber-300 text-xs font-semibold flex items-center justify-between transition cursor-pointer border border-stone-700/60"
                  title={`Ir a construcción para mejorar ${prodBuildingInfo.name}`}
                  aria-label={`Ir a construcción para mejorar ${prodBuildingInfo.name}`}
                >
                  <span>Mejorar Edificio</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="p-3.5 rounded-xl bg-stone-900/90 border border-stone-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs text-stone-400 font-medium">Contenedor de Reserva</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-800 text-stone-300">
                    Nivel {storageBuildingLevel}
                  </span>
                </div>
                <div className="font-bold text-sm text-stone-200 mb-1">{storageBuildingInfo.name}</div>
                <p className="text-xs text-stone-400 leading-relaxed">
                  {storageBuildingLevel > 0
                    ? storageBuildingInfo.effectDescription(storageBuildingLevel)
                    : 'Sin construir. Levántalo para incrementar el tope.'}
                </p>
              </div>
              {onNavigateTab && (
                <button
                  onClick={() => {
                    onClose();
                    onNavigateTab('construction');
                    playSound('click');
                  }}
                  className="mt-3 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-750 text-amber-400 hover:text-amber-300 text-xs font-semibold flex items-center justify-between transition cursor-pointer border border-stone-700/60"
                  title={`Ir a construcción para mejorar ${storageBuildingInfo.name}`}
                  aria-label={`Ir a construcción para mejorar ${storageBuildingInfo.name}`}
                >
                  <span>Ampliar Almacén</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Active Kingdom Modifiers */}
          <div className="p-3.5 rounded-xl bg-stone-950/50 border border-stone-800/60 space-y-2">
            <h5 className="text-xs font-bold text-stone-300 uppercase tracking-wider flex items-center gap-1.5">
              <Crown className="w-4 h-4 text-amber-400" />
              <span>Modificadores Activos de la Corona</span>
            </h5>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-400">
              <div className="p-2 rounded-lg bg-stone-900 border border-stone-800">
                <span className="text-stone-300 font-medium">Bono Civilización ({civ.name}):</span>
                <div className="text-amber-400 text-[11px] mt-0.5">{civ.description}</div>
              </div>
              <div className="p-2 rounded-lg bg-stone-900 border border-stone-800">
                <span className="text-stone-300 font-medium">Consumo Militar de Tropas:</span>
                <div className="text-stone-400 text-[11px] mt-0.5">
                  {selectedRes === 'food'
                    ? 'Regimientos en guarnición descuentan raciones por hora.'
                    : 'Sin consumo continuo de tropas.'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-6 border-t border-stone-800 bg-stone-900 flex items-center justify-between">
          <div className="text-xs text-stone-400">
            {civ.badge} {kingdom.kingdomName} • {kingdom.castleName}
          </div>
          <button
            onClick={() => {
              playSound('click');
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs transition cursor-pointer shadow"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
