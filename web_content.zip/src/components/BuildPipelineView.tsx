import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  Hammer,
  Loader2,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import { formatBytes, formatDateTr } from '../lib/api';
import type {
  BuildJob,
  MembershipInfo,
  ProjectSummary,
  SystemCapabilities,
} from '../types/studio';

interface BuildPipelineViewProps {
  projects: ProjectSummary[];
  builds: BuildJob[];
  activeBuild: BuildJob | null;
  selectedProjectId: string | null;
  membership: MembershipInfo;
  capabilities: SystemCapabilities | null;
  onSelectProject: (id: string) => void;
  onStartBuild: (projectId: string) => void;
  onCancelBuild: (buildId: string) => void;
  onDownloadBuild: (buildId: string) => void;
  onSelectBuild: (build: BuildJob) => void;
}

const STAGE_LABELS = [
  '1. Proje ve giriş HTML doğrulama',
  '2. Güvenlik ve yol taraması',
  '3. İzole çalışma alanı oluşturma',
  '4. Android WebView iskeleti',
  '5. HTML/CSS/JS assets kopyalama',
  '6. Kotlin WebView yapılandırması',
  '7. AndroidManifest.xml & tema',
  '8. Gradle KTS & Dockerfile',
  '9. Android SDK / Gradle derleme yürütme',
  '10. Çıktı paketleme',
  '11. Bütünlük & SHA-256 doğrulama',
  '12. İndirmeye hazır',
];

export const BuildPipelineView: React.FC<BuildPipelineViewProps> = ({
  projects,
  builds,
  activeBuild,
  selectedProjectId,
  membership,
  capabilities,
  onSelectProject,
  onStartBuild,
  onCancelBuild,
  onDownloadBuild,
  onSelectBuild,
}) => {
  const targetProjectId = selectedProjectId || projects[0]?.id || null;
  const currentBuild = activeBuild || builds[0] || null;
  const isRunning =
    currentBuild && (currentBuild.status === 'queued' || currentBuild.status === 'running');
  const isCompletedApk = currentBuild?.status === 'completed_apk';
  const isCompletedBundle = currentBuild?.status === 'completed_bundle';

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            APK Derleme Hattı
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            Gerçek zamanlı Kotlin WebView + Android SDK derleme aşamalarını ve çıktıları takip edin.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {projects.length > 0 && (
            <select
              value={targetProjectId || ''}
              onChange={(e) => onSelectProject(e.target.value)}
              className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            disabled={!targetProjectId || Boolean(isRunning)}
            onClick={() => targetProjectId && onStartBuild(targetProjectId)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white transition-colors whitespace-nowrap shrink-0"
          >
            {isRunning ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Hammer className="w-3.5 h-3.5" />
            )}
            <span>
              {isRunning
                ? 'Derleme Sürüyor...'
                : membership.limits.priorityQueue
                ? 'Öncelikli Derleme Başlat'
                : 'Derlemeyi Başlat'}
            </span>
          </button>
        </div>
      </div>

      {/* Real Environment Notice */}
      {capabilities && (
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl px-5 py-3.5 text-xs text-slate-600 dark:text-[#94A3B8] flex items-start gap-3">
          <ShieldCheck className="w-4 h-4 text-[#3B82F6] shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-900 dark:text-[#F8FAFC]">Altyapı Modu: </span>
            {capabilities.summary}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Active Build Stages & Logs */}
        <div className="xl:col-span-8 space-y-6">
          {!currentBuild ? (
            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-10 text-center text-sm text-slate-600 dark:text-[#94A3B8]">
              Derleme başlatmak için yukarıdan bir proje seçip &ldquo;Derlemeyi Başlat&rdquo;
              butonuna tıklayın.
            </div>
          ) : (
            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2.5">
                    {isRunning && <Loader2 className="w-4 h-4 text-amber-500 animate-spin" />}
                    {(isCompletedApk || isCompletedBundle) && (
                      <CheckCircle2 className="w-4 h-4 text-[#22C55E]" />
                    )}
                    {currentBuild.status === 'failed' && (
                      <AlertTriangle className="w-4 h-4 text-[#EF4444]" />
                    )}
                    {currentBuild.status === 'cancelled' && (
                      <XCircle className="w-4 h-4 text-slate-500 dark:text-[#94A3B8]" />
                    )}
                    <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                      {currentBuild.stage}
                    </h2>
                  </div>
                  <p className="mt-1 text-xs text-slate-500 dark:text-[#94A3B8] tabular-nums">
                    Aşama {currentBuild.stage_index} / {currentBuild.total_stages}
                    <span className="mx-2" aria-hidden="true">
                      ·
                    </span>
                    <span>
                      {currentBuild.is_priority ? 'Öncelikli Premium Kuyruk' : 'Standart Kuyruk'}
                    </span>
                    <span className="mx-2" aria-hidden="true">
                      ·
                    </span>
                    <span>{formatDateTr(currentBuild.created_at)}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2.5">
                  {isRunning && (
                    <button
                      type="button"
                      onClick={() => onCancelBuild(currentBuild.id)}
                      className="px-3.5 py-2 text-xs font-medium rounded-xl border border-red-500/30 text-[#EF4444] hover:bg-red-500/10 transition-colors"
                    >
                      İptal Et
                    </button>
                  )}

                  {(isCompletedApk || isCompletedBundle) && (
                    <button
                      type="button"
                      onClick={() => onDownloadBuild(currentBuild.id)}
                      className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-[#22C55E] hover:bg-[#16A34A] text-[#0B1020] transition-colors whitespace-nowrap"
                    >
                      <Download className="w-4 h-4" />
                      <span>
                        {isCompletedApk
                          ? 'APK Dosyasını İndir (.apk)'
                          : 'Android Gradle + Docker Paketini İndir (.zip)'}
                      </span>
                    </button>
                  )}
                </div>
              </div>

              {/* 12 Real Stages Matrix */}
              <div className="p-6 border-b border-slate-200 dark:border-white/[0.08] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {STAGE_LABELS.map((label, idx) => {
                  const stageNum = idx + 1;
                  const done =
                    currentBuild.stage_index > stageNum ||
                    ((isCompletedApk || isCompletedBundle) &&
                      currentBuild.stage_index >= stageNum);
                  const active = isRunning && currentBuild.stage_index === stageNum;

                  return (
                    <div
                      key={label}
                      className={`px-3 py-2 rounded-lg border text-xs flex items-center gap-2 ${
                        done
                          ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-700 dark:text-[#22C55E]'
                          : active
                          ? 'bg-[#6366F1]/15 border-[#6366F1]/40 text-slate-900 dark:text-[#F8FAFC]'
                          : 'bg-slate-50 dark:bg-[#0B1020] border-slate-200 dark:border-white/[0.06] text-slate-500 dark:text-[#94A3B8]'
                      }`}
                    >
                      <span className="font-mono tabular-nums text-[11px] shrink-0">
                        {String(stageNum).padStart(2, '0')}
                      </span>
                      <span className="truncate">{label.replace(/^\d+\.\s*/, '')}</span>
                    </div>
                  );
                })}
              </div>

              {/* Artifact Verification Metadata */}
              {(isCompletedApk || isCompletedBundle) && (
                <div className="px-6 py-3.5 bg-slate-50 dark:bg-[#111827] border-b border-slate-200 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 dark:text-[#94A3B8]">Çıktı: </span>
                    <span className="font-mono text-slate-900 dark:text-[#F8FAFC]">
                      {currentBuild.artifact_filename}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 tabular-nums font-mono text-[11px] text-slate-500 dark:text-[#94A3B8]">
                    <span>Boyut: {formatBytes(currentBuild.artifact_size_bytes)}</span>
                    {currentBuild.sha256 && (
                      <span>SHA-256: {currentBuild.sha256.slice(0, 20)}…</span>
                    )}
                  </div>
                </div>
              )}

              {currentBuild.error_message && (
                <div className="px-6 py-3 bg-red-500/10 border-b border-red-500/20 text-xs text-[#EF4444]">
                  Hata: {currentBuild.error_message}
                </div>
              )}

              {/* Real Timestamped Build Logs */}
              <div className="bg-slate-900 dark:bg-[#0B1020] p-5 max-h-[340px] overflow-y-auto space-y-2 font-mono text-xs">
                {currentBuild.logs.map((log, i) => (
                  <div key={i} className="flex items-start gap-3 leading-relaxed">
                    <span className="text-slate-500 tabular-nums shrink-0">
                      {new Date(log.timestamp).toLocaleTimeString('tr-TR')}
                    </span>
                    <span
                      className={
                        log.level === 'error'
                          ? 'text-red-400'
                          : log.level === 'warn'
                          ? 'text-amber-300'
                          : log.level === 'success'
                          ? 'text-emerald-400'
                          : 'text-slate-200'
                      }
                    >
                      {log.message}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Build History */}
        <div className="xl:col-span-4 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08]">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Derleme Geçmişi
            </h2>
          </div>

          {builds.length === 0 ? (
            <div className="p-6 text-xs text-slate-500 dark:text-[#94A3B8]">
              Kayıtlı derleme geçmişi yok.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-white/[0.06] max-h-[540px] overflow-y-auto">
              {builds.map((b) => {
                const selected = currentBuild?.id === b.id;
                return (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => onSelectBuild(b)}
                    className={`w-full text-left px-5 py-3.5 transition-colors ${
                      selected
                        ? 'bg-[#6366F1]/10'
                        : 'hover:bg-slate-50 dark:hover:bg-white/[0.02]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                        {b.app_name || b.project_name}
                      </span>
                      <span
                        className={`text-[11px] font-medium shrink-0 ${
                          b.status === 'completed_apk'
                            ? 'text-[#22C55E]'
                            : b.status === 'completed_bundle'
                            ? 'text-[#3B82F6]'
                            : b.status === 'failed'
                            ? 'text-[#EF4444]'
                            : 'text-amber-500'
                        }`}
                      >
                        {b.status === 'completed_apk'
                          ? 'APK'
                          : b.status === 'completed_bundle'
                          ? 'Gradle ZIP'
                          : b.status === 'failed'
                          ? 'Hata'
                          : b.status === 'cancelled'
                          ? 'İptal'
                          : 'Sürüyor'}
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] font-mono text-slate-500 dark:text-[#94A3B8] truncate">
                      {b.package_name}
                    </p>
                    <p className="mt-1 text-[11px] text-slate-400 dark:text-[#94A3B8] tabular-nums">
                      {formatDateTr(b.created_at)}
                    </p>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
