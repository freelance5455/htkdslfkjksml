import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { useActiveStory, useDesk, useUi } from "@/lib/desk-store";
import { wordCount, type MuseHint } from "@/lib/story";

const ACTIONS: { hint: MuseHint; label: string; instruction: string }[] = [
  { hint: "continue", label: "Continue", instruction: "Continue the scene." },
  { hint: "dialogue", label: "Dialogue", instruction: "Write the next dialogue." },
  { hint: "interior", label: "Interior", instruction: "Step inside their thoughts." },
  { hint: "sensory", label: "Detail", instruction: "Slow down and describe." },
  { hint: "trouble", label: "Trouble", instruction: "Make trouble." },
];

export function MusePanel() {
  const story = useActiveStory();
  const focus = useUi((state) => state.focus);
  const pane = useUi((state) => state.pane);
  const selection = useUi((state) => state.selection.text);
  const askMuse = useDesk((state) => state.askMuse);
  const insertProse = useDesk((state) => state.insertProse);
  const undoInsert = useDesk((state) => state.undoInsert);
  const [draft, setDraft] = useState("");
  const [copiedId, setCopiedId] = useState("");
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const node = scroller.current;
    if (!node) return;
    node.scrollTop = node.scrollHeight;
  }, [story?.messages.length]);

  if (!story) return null;

  const lastMuse = [...story.messages].reverse().find((message) => message.role === "muse");

  function send(instruction: string, hint: MuseHint) {
    askMuse(instruction, hint, true);
    if (hint === "auto") setDraft("");
  }

  return (
    <aside
      className={cn(
        "min-h-0 w-full flex-col overflow-hidden border-line lg:w-96 lg:shrink-0 lg:border-l",
        focus ? "hidden" : pane === "muse" ? "flex" : "hidden lg:flex",
      )}
    >
      <div className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
        <div>
          <h2 className="font-serif text-xl italic">Ink</h2>
          <p className="text-sm text-muted">On this device</p>
        </div>
        <Button tone="ghost" disabled={!story.snapshots.length} onClick={undoInsert}>
          Undo insert
        </Button>
      </div>
      <div className="flex shrink-0 flex-wrap gap-2 px-4 py-3">
        {ACTIONS.map((action) => (
          <Button key={action.hint} tone="quiet" onClick={() => send(action.instruction, action.hint)}>
            {action.label}
          </Button>
        ))}
        <Button tone="ghost" onClick={() => send("Sharpen the passage.", "sharpen")}>
          Sharpen
        </Button>
        <Button tone="ghost" onClick={() => send("Expand the passage.", "expand")}>
          Expand
        </Button>
      </div>
      <div ref={scroller} className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 pb-4">
        {selection ? (
          <p className="text-sm text-muted">Sharpen and Expand use the highlighted passage.</p>
        ) : null}
        {story.messages.length === 0 ? (
          <div className="pt-2">
            <p className="font-serif text-xl leading-relaxed">The page is listening.</p>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted">
              Ink stays in this browser. Nothing is sent away. Tell it what happens next — a lie, a
              kiss, a door, a worse turn — and it will stay in the scene instead of stopping to
              lecture the draft.
            </p>
          </div>
        ) : null}
        {story.messages.map((message) =>
          message.role === "user" ? (
            <p key={message.id} className="ml-8 text-right text-sm leading-relaxed text-muted">
              {message.text}
            </p>
          ) : (
            <article key={message.id} className="rounded-lg border border-line bg-sheet px-4 py-3">
              <p
                className={cn(
                  "whitespace-pre-wrap leading-relaxed",
                  message.insertable ? "manuscript text-lg" : "text-sm",
                )}
              >
                {message.text}
              </p>
              <p className="mt-2 text-sm tabular-nums text-muted">
                {wordCount(message.text).toLocaleString()} words
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {message.insertable ? (
                  <Button tone="wax" onClick={() => insertProse(message.text)}>
                    Insert
                  </Button>
                ) : null}
                <Button
                  tone="ghost"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(message.text);
                      setCopiedId(message.id);
                    } catch {
                      setCopiedId("");
                    }
                  }}
                >
                  {copiedId === message.id ? "Copied" : "Copy"}
                </Button>
                {message.id === lastMuse?.id ? (
                  <Button
                    tone="ghost"
                    onClick={() => askMuse(message.instruction, message.hint, false)}
                  >
                    Another
                  </Button>
                ) : null}
              </div>
            </article>
          ),
        )}
      </div>
      <form
        className="shrink-0 border-t border-line p-3"
        onSubmit={(event) => {
          event.preventDefault();
          send(draft, "auto");
        }}
      >
        <label className="block">
          <span className="sr-only">Note to Ink</span>
          <textarea
            className="field font-serif"
            rows={2}
            placeholder="What happens next"
            value={draft}
            aria-label="Note to Ink"
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                send(draft, "auto");
              }
            }}
          />
        </label>
        <div className="mt-2 flex items-center justify-between gap-3">
          <p className="text-sm text-muted">Enter to write. Nothing leaves this desk.</p>
          <Button tone="wax" type="submit">
            Write
          </Button>
        </div>
      </form>
    </aside>
  );
}
