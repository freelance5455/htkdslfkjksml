import React, { useState, useRef } from 'react';
import {
  Code,
  Play,
  Download,
  Copy,
  Check,
  Sparkles,
  Maximize2,
  RefreshCw,
  FolderCode,
  Gamepad2,
  Calculator,
  Clock,
  FileCode2,
  Send,
  Zap,
  Terminal
} from 'lucide-react';
import { GeneratedApp, SupportedLanguage } from '../types';
import { sendMessageToDost } from '../services/api';

interface AppStudioTabProps {
  language: SupportedLanguage;
  activeApp?: GeneratedApp | null;
  onSelectApp?: (app: GeneratedApp) => void;
}

const DEFAULT_APPS: GeneratedApp[] = [
  {
    id: 'app-snake',
    title: 'Neon Cyber Snake Game',
    description: 'Interactive retro arcade game with touch controls & score tracking',
    type: 'html',
    createdAt: Date.now() - 3600000,
    code: `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Neon Snake</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 12px;
      background: #060913;
      color: #e2e8f0;
      font-family: system-ui, -apple-system, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      user-select: none;
    }
    .hud {
      display: flex;
      justify-content: space-between;
      width: 100%;
      max-width: 320px;
      margin-bottom: 8px;
      font-family: monospace;
      font-size: 14px;
      font-weight: bold;
    }
    .score { color: #06b6d4; }
    .best { color: #10b981; }
    canvas {
      background: #0c1427;
      border: 2px solid #06b6d4;
      border-radius: 16px;
      box-shadow: 0 0 25px rgba(6, 182, 212, 0.25);
      max-width: 100%;
      height: auto;
    }
    .controls {
      display: grid;
      grid-template-columns: repeat(3, 55px);
      gap: 6px;
      margin-top: 14px;
    }
    button.pad {
      background: #1e293b;
      border: 1px solid #334155;
      color: #38bdf8;
      height: 48px;
      border-radius: 12px;
      font-size: 18px;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      active:scale-95;
    }
    button.pad:active { background: #0284c7; color: #fff; }
    .status { margin-top: 8px; font-size: 11px; color: #64748b; }
  </style>
</head>
<body>
  <div class="hud">
    <span class="score">SCORE: <span id="sc">0</span></span>
    <span class="best">BEST: <span id="hi">0</span></span>
  </div>
  <canvas id="c" width="300" height="300"></canvas>
  <div class="controls">
    <div></div>
    <button class="pad" onclick="setDir(0,-1)">▲</button>
    <div></div>
    <button class="pad" onclick="setDir(-1,0)">◀</button>
    <button class="pad" onclick="setDir(0,1)">▼</button>
    <button class="pad" onclick="setDir(1,0)">▶</button>
  </div>
  <div class="status">DOST AI Powered Mini Arcade</div>

  <script>
    const cv = document.getElementById('c'), cx = cv.getContext('2d');
    let sn = [{x: 7, y: 7}], fd = {x: 11, y: 11}, dx = 1, dy = 0, sc = 0, hi = 0, over = false;

    function setDir(x, y) {
      if ((x && dx === -x) || (y && dy === -y)) return;
      dx = x; dy = y;
    }

    function spawnFood() {
      fd = { x: Math.floor(Math.random() * 15), y: Math.floor(Math.random() * 15) };
    }

    window.addEventListener('keydown', e => {
      if (e.key === 'ArrowUp') setDir(0, -1);
      if (e.key === 'ArrowDown') setDir(0, 1);
      if (e.key === 'ArrowLeft') setDir(-1, 0);
      if (e.key === 'ArrowRight') setDir(1, 0);
    });

    setInterval(() => {
      if (over) return;
      let h = { x: (sn[0].x + dx + 15) % 15, y: (sn[0].y + dy + 15) % 15 };
      if (sn.some(p => p.x === h.x && p.y === h.y)) {
        over = true;
        alert('Game Over! Final Score: ' + sc);
        sn = [{x: 7, y: 7}]; dx = 1; dy = 0; sc = 0; over = false;
        document.getElementById('sc').innerText = sc;
        return;
      }
      if (h.x === fd.x && h.y === fd.y) {
        sc += 10;
        if (sc > hi) { hi = sc; document.getElementById('hi').innerText = hi; }
        document.getElementById('sc').innerText = sc;
        spawnFood();
      } else {
        sn.pop();
      }
      sn.unshift(h);

      cx.fillStyle = '#0c1427';
      cx.fillRect(0, 0, 300, 300);

      // Draw grid lines
      cx.strokeStyle = '#1e293b';
      cx.lineWidth = 0.5;
      for (let i = 0; i <= 300; i += 20) {
        cx.beginPath(); cx.moveTo(i, 0); cx.lineTo(i, 300); cx.stroke();
        cx.beginPath(); cx.moveTo(0, i); cx.lineTo(300, i); cx.stroke();
      }

      // Food
      cx.fillStyle = '#10b981';
      cx.shadowColor = '#10b981';
      cx.shadowBlur = 10;
      cx.beginPath();
      cx.arc(fd.x * 20 + 10, fd.y * 20 + 10, 7, 0, Math.PI * 2);
      cx.fill();

      // Snake
      sn.forEach((p, i) => {
        cx.fillStyle = i === 0 ? '#38bdf8' : '#0284c7';
        cx.shadowColor = '#38bdf8';
        cx.shadowBlur = i === 0 ? 8 : 2;
        cx.fillRect(p.x * 20 + 2, p.y * 20 + 2, 16, 16);
      });
    }, 130);
  </script>
</body>
</html>`
  },
  {
    id: 'app-crypto-calc',
    title: 'Crypto Leverage & Profit Calculator',
    description: 'Calculate net liquidation, leverage profit, and ROE in real-time',
    type: 'html',
    createdAt: Date.now() - 7200000,
    code: `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DOST Crypto PnL</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 16px;
      background: #090e1a;
      color: #f1f5f9;
      font-family: system-ui, sans-serif;
    }
    h2 { color: #06b6d4; font-size: 16px; margin-top: 0; }
    .card {
      background: #111a2e;
      border: 1px solid #1e293b;
      border-radius: 14px;
      padding: 14px;
      margin-bottom: 12px;
    }
    label { font-size: 11px; color: #94a3b8; display: block; margin-top: 8px; }
    input, select {
      width: 100%;
      padding: 8px 10px;
      background: #080d19;
      border: 1px solid #334155;
      color: #38bdf8;
      border-radius: 8px;
      font-size: 13px;
      font-family: monospace;
      margin-top: 4px;
    }
    button {
      width: 100%;
      background: #06b6d4;
      color: #04121d;
      font-weight: bold;
      padding: 10px;
      border-radius: 10px;
      border: none;
      margin-top: 12px;
      cursor: pointer;
    }
    .res {
      margin-top: 12px;
      padding: 12px;
      border-radius: 10px;
      background: #062820;
      border: 1px solid #10b981;
      color: #34d399;
      font-family: monospace;
      font-size: 13px;
    }
  </style>
</head>
<body>
  <h2>DOST Futures Profit Calculator</h2>
  <div class="card">
    <label>Position Type:</label>
    <select id="type">
      <option value="LONG">LONG (Buy)</option>
      <option value="SHORT">SHORT (Sell)</option>
    </select>
    <label>Entry Price ($):</label>
    <input id="entry" type="number" value="82000">
    <label>Exit Target Price ($):</label>
    <input id="exit" type="number" value="86000">
    <label>Margin Capital ($):</label>
    <input id="margin" type="number" value="250">
    <label>Leverage (x):</label>
    <input id="lev" type="number" value="10">
    <button onclick="calculate()">Calculate Return</button>
    <div id="out" class="res">
      Net Profit: +$121.95<br>
      ROE: +48.78%<br>
      Total Position: $2,500.00
    </div>
  </div>
  <script>
    function calculate() {
      const type = document.getElementById('type').value;
      const entry = +document.getElementById('entry').value;
      const exit = +document.getElementById('exit').value;
      const margin = +document.getElementById('margin').value;
      const lev = +document.getElementById('lev').value;
      const pos = margin * lev;
      let pnl = 0;
      if (type === 'LONG') {
        pnl = ((exit - entry) / entry) * pos;
      } else {
        pnl = ((entry - exit) / entry) * pos;
      }
      const roe = (pnl / margin) * 100;
      const el = document.getElementById('out');
      el.innerHTML = 'Net Profit: ' + (pnl >= 0 ? '+$' : '-$') + Math.abs(pnl).toFixed(2) + '<br>ROE: ' + (roe >= 0 ? '+' : '') + roe.toFixed(2) + '%<br>Position Value: $' + pos.toFixed(2);
      el.style.background = pnl >= 0 ? '#062820' : '#330e12';
      el.style.borderColor = pnl >= 0 ? '#10b981' : '#f43f5e';
      el.style.color = pnl >= 0 ? '#34d399' : '#fb7185';
    }
  </script>
</body>
</html>`
  }
];

export const AppStudioTab: React.FC<AppStudioTabProps> = ({
  language,
  activeApp: propActiveApp,
}) => {
  const [appsList, setAppsList] = useState<GeneratedApp[]>(() => {
    const saved = localStorage.getItem('dost_generated_apps');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return DEFAULT_APPS;
      }
    }
    return DEFAULT_APPS;
  });

  const [currentApp, setCurrentApp] = useState<GeneratedApp>(
    propActiveApp || appsList[0] || DEFAULT_APPS[0]
  );
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [codeDraft, setCodeDraft] = useState<string>(currentApp.code);
  const [copied, setCopied] = useState(false);
  const [promptInput, setPromptInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const iframeRef = useRef<HTMLIFrameElement>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleSelectApp = (app: GeneratedApp) => {
    setCurrentApp(app);
    setCodeDraft(app.code);
    setViewMode('preview');
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(codeDraft);
    setCopied(true);
    showToast('Code copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadHtml = () => {
    const blob = new Blob([codeDraft], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentApp.title.toLowerCase().replace(/[^a-z0-9]/g, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Downloaded ${currentApp.title}.html!`);
  };

  const handleRunCustomCode = () => {
    setCurrentApp((prev) => ({
      ...prev,
      code: codeDraft,
    }));
    setViewMode('preview');
    showToast('Re-running custom code in sandbox!');
  };

  const handleGenerateAppWithAI = async () => {
    if (!promptInput.trim() || isGenerating) return;
    setIsGenerating(true);
    showToast('DOST AI app code likh raha hai...');

    try {
      const prompt = `Please build and code a complete, self-contained single-file working HTML/CSS/JS application for: "${promptInput.trim()}". Include modern dark styling and interactive buttons.`;
      const res = await sendMessageToDost([{ role: 'user', content: prompt }], language);

      if (res.appCode && res.appCode.code) {
        const newApp: GeneratedApp = {
          id: `app-${Date.now()}`,
          title: res.appCode.title || promptInput.trim().slice(0, 24),
          description: `Custom generated by DOST AI from "${promptInput.trim()}"`,
          type: 'html',
          createdAt: Date.now(),
          code: res.appCode.code,
        };

        const updated = [newApp, ...appsList];
        setAppsList(updated);
        localStorage.setItem('dost_generated_apps', JSON.stringify(updated));
        setCurrentApp(newApp);
        setCodeDraft(newApp.code);
        setViewMode('preview');
        setPromptInput('');
        showToast(`App "${newApp.title}" created & launched!`);
      } else {
        // Fallback: create a custom tool wrapper
        const generatedHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${promptInput}</title><style>body{margin:0;padding:20px;background:#090d16;color:#f8fafc;font-family:sans-serif}h1{color:#38bdf8;font-size:20px}.box{background:#111927;border:1px solid #1e293b;padding:16px;border-radius:12px;margin-top:12px}button{background:#0ea5e9;color:#04131f;font-weight:bold;padding:10px 16px;border-radius:8px;border:none;cursor:pointer}</style></head><body><h1>${promptInput}</h1><div class="box"><p>${res.reply}</p><button onclick="alert('DOST AI app action active!')">Click Action</button></div></body></html>`;

        const newApp: GeneratedApp = {
          id: `app-${Date.now()}`,
          title: promptInput.trim().slice(0, 24),
          description: `Generated for: ${promptInput.trim()}`,
          type: 'html',
          createdAt: Date.now(),
          code: generatedHtml,
        };

        const updated = [newApp, ...appsList];
        setAppsList(updated);
        localStorage.setItem('dost_generated_apps', JSON.stringify(updated));
        setCurrentApp(newApp);
        setCodeDraft(newApp.code);
        setViewMode('preview');
        setPromptInput('');
        showToast('App generated and launched!');
      }
    } catch (err: any) {
      showToast('App creation failed: ' + (err.message || 'Error'));
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto p-3 sm:p-4 space-y-4">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="p-3 bg-cyan-950/90 border border-cyan-500/50 text-cyan-200 rounded-xl text-xs flex items-center gap-2 animate-in fade-in shadow-xl">
          <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="font-semibold">{toastMsg}</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-4 rounded-2xl border border-slate-800 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 text-slate-950 flex items-center justify-center font-black">
              <Zap className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>DOST App Studio &amp; Code Lab</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 uppercase font-mono">
                  Live Runner
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Generate, code, and execute custom interactive apps inside DOST
              </p>
            </div>
          </div>
        </div>

        {/* AI App Generator Input */}
        <div className="mt-3 flex gap-2">
          <input
            type="text"
            placeholder="DOST ko bolo: 'Flappy bird banao', 'Expense tracker banao'..."
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleGenerateAppWithAI()}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
          <button
            onClick={handleGenerateAppWithAI}
            disabled={isGenerating || !promptInput.trim()}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 shrink-0 transition-all"
          >
            {isGenerating ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            <span>{isGenerating ? 'Coding...' : 'Build App'}</span>
          </button>
        </div>
      </div>

      {/* Available Apps Horizontal Reel */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block px-1">
          Installed &amp; Generated Apps:
        </span>
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {appsList.map((app) => {
            const isSelected = app.id === currentApp.id;
            return (
              <button
                key={app.id}
                onClick={() => handleSelectApp(app)}
                className={`px-3 py-2 rounded-xl border text-left shrink-0 transition-all flex items-center gap-2 ${
                  isSelected
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 font-bold shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                {app.id.includes('snake') || app.title.toLowerCase().includes('game') ? (
                  <Gamepad2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : app.title.toLowerCase().includes('calc') ? (
                  <Calculator className="w-4 h-4 text-cyan-400 shrink-0" />
                ) : (
                  <FileCode2 className="w-4 h-4 text-purple-400 shrink-0" />
                )}
                <div className="text-left">
                  <span className="text-xs block truncate max-w-[140px]">{app.title}</span>
                  <span className="text-[9px] text-slate-500 font-normal">HTML5 Sandbox</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active App Controller Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between gap-2 shadow-sm">
        <div>
          <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
            <span>{currentApp.title}</span>
          </h3>
          <p className="text-[10px] text-slate-400">{currentApp.description}</p>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setViewMode('preview')}
              className={`px-2.5 py-1 rounded transition-colors text-[11px] font-semibold flex items-center gap-1 ${
                viewMode === 'preview'
                  ? 'bg-cyan-500 text-slate-950'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Play className="w-3 h-3" /> Run
            </button>
            <button
              onClick={() => setViewMode('code')}
              className={`px-2.5 py-1 rounded transition-colors text-[11px] font-semibold flex items-center gap-1 ${
                viewMode === 'code'
                  ? 'bg-cyan-500 text-slate-950'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code className="w-3 h-3" /> Code
            </button>
          </div>

          <button
            onClick={handleCopyCode}
            title="Copy Code"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={handleDownloadHtml}
            title="Download .html file"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Display: Sandbox iFrame Runner OR Code Editor */}
      <div className="flex-1 min-h-[460px] bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl relative">
        {viewMode === 'preview' ? (
          <iframe
            ref={iframeRef}
            srcDoc={currentApp.code}
            sandbox="allow-scripts allow-modals allow-forms"
            title={currentApp.title}
            className="w-full h-full min-h-[460px] border-none bg-slate-950"
          />
        ) : (
          <div className="flex flex-col h-full min-h-[460px] p-2 space-y-2">
            <div className="flex items-center justify-between px-2 text-[11px] text-slate-400">
              <span className="font-mono">Single-file HTML/CSS/JS Source</span>
              <button
                onClick={handleRunCustomCode}
                className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg flex items-center gap-1 text-xs"
              >
                <Play className="w-3 h-3" /> Re-Run Changes
              </button>
            </div>
            <textarea
              value={codeDraft}
              onChange={(e) => setCodeDraft(e.target.value)}
              className="flex-1 w-full bg-slate-900 border border-slate-800 rounded-xl p-3 font-mono text-xs text-cyan-300 focus:outline-none focus:border-cyan-500 resize-none min-h-[400px]"
              spellCheck={false}
            />
          </div>
        )}
      </div>
    </div>
  );
};
