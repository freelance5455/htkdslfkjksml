import { useCallback, useEffect, useState } from "react";
import type { SubtitleSet, VideoMeta } from "../types";
import { idbAll, idbDel } from "../lib/db";
import { downloadText, fmtClock } from "../lib/subtitles";
import { fmtBytes } from "../lib/modelManager";
import { Btn, Card, Chip, Empty, Icon, SectionTitle, useToast } from "./ui";

interface Props {
  onChange: () => void;
  onOpen: (meta: VideoMeta) => void;
  onGoToPlayer: () => void;
}

export default function LibraryTab({ onChange, onOpen, onGoToPlayer }: Props) {
  const toast = useToast();
  const [videos, setVideos] = useState<VideoMeta[]>([]);
  const [sets, setSets] = useState<SubtitleSet[]>([]);
  const [confirm, setConfirm] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [v, s] = await Promise.all([
      idbAll<VideoMeta>("videos"),
      idbAll<SubtitleSet>("subtitles"),
    ]);
    setVideos(v.sort((a, b) => b.lastUsed - a.lastUsed));
    setSets(s.sort((a, b) => b.createdAt - a.createdAt));
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const setsFor = (key: string) => sets.filter((s) => s.videoKey === key);

  const deleteVideo = async (meta: VideoMeta) => {
    for (const s of setsFor(meta.key)) await idbDel("subtitles", s.id);
    await idbDel("videos", meta.key);
    await idbDel("files", meta.key);
    toast("Video entry removed (subtitle sets included)", "ok");
    await load();
    onChange();
  };

  const deleteSet = async (s: SubtitleSet) => {
    await idbDel("subtitles", s.id);
    toast("Subtitle set removed", "ok");
    await load();
    onChange();
  };

  const totalBytes = videos.reduce((a, v) => a + v.size, 0);

  return (
    <div className="space-y-5">
      <Card className="flex items-center justify-between p-3.5">
        <div className="text-xs text-mist-400">
          <p>
            <b className="text-mist-100">{videos.length}</b> video entr{videos.length === 1 ? "y" : "ies"} ·{" "}
            <b className="text-mist-100">{sets.length}</b> subtitle set{sets.length === 1 ? "" : "s"}
          </p>
          <p className="mt-0.5 text-[11px] text-mist-600">
            {totalBytes > 0 ? `${fmtBytes(totalBytes)} of media referenced` : "no media referenced yet"}
            {" · "}stored video files & subtitle text persist in IndexedDB on this device
          </p>
        </div>
        <Btn size="sm" variant="ghost" onClick={() => void load()}>
          <Icon name="refresh" className="h-4 w-4" />
        </Btn>
      </Card>

      <div>
        <SectionTitle>Videos</SectionTitle>
        {videos.length === 0 ? (
          <Empty
            icon="folder"
            title="Library is empty"
            sub="Play a video and press “Store file” to keep it here — it then opens offline after you close and reopen the app."
          >
            <Btn size="sm" variant="outline" onClick={onGoToPlayer}>
              <Icon name="film" className="h-4 w-4" /> Choose a video
            </Btn>
          </Empty>
        ) : (
          <div className="space-y-2.5">
            {videos.map((v) => {
              const vsets = setsFor(v.key);
              return (
                <Card key={v.key} className="space-y-2 p-3.5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate font-display text-sm font-semibold text-mist-100">
                        {v.name}
                      </p>
                      <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-mist-500">
                        {fmtBytes(v.size)}
                        {v.duration ? ` · ${fmtClock(v.duration)}` : ""} · opened{" "}
                        {new Date(v.lastUsed).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-2">
                      <Btn size="sm" variant="outline" onClick={() => onOpen(v)}>
                        <Icon name="play" className="h-4 w-4" /> Open
                      </Btn>
                      <Btn
                        size="sm"
                        variant={confirm === v.key ? "danger" : "ghost"}
                        onClick={() => {
                          if (confirm === v.key) void deleteVideo(v);
                          else setConfirm(v.key);
                        }}
                      >
                        <Icon name="trash" className="h-4 w-4" />
                        {confirm === v.key ? "Sure?" : ""}
                      </Btn>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {v.hasBlob ? (
                      <Chip tone="moss">
                        <Icon name="save" className="h-3 w-3" /> file stored — opens offline
                      </Chip>
                    ) : (
                      <Chip tone="mist">re-select file to play (subs auto-load)</Chip>
                    )}
                    {vsets.length > 0 && (
                      <Chip tone="brass">
                        {vsets.length} subtitle set{vsets.length === 1 ? "" : "s"}
                      </Chip>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <div>
        <SectionTitle>All subtitle sets</SectionTitle>
        {sets.length === 0 ? (
          <p className="rounded-xl border border-dashed border-ink-600 px-4 py-6 text-center text-xs text-mist-500">
            Generated and imported subtitle sets appear here with SRT / VTT export.
          </p>
        ) : (
          <div className="space-y-2.5">
            {sets.map((s) => (
              <Card key={s.id} className="space-y-2 p-3.5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate font-display text-sm font-semibold text-mist-100" dir="auto">
                      {s.title}
                    </p>
                    <p className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-mist-500">
                      <Chip tone={s.kind === "generated" ? "brass" : s.kind === "translated" ? "jade" : "mist"}>
                        {s.kind}
                      </Chip>
                      {s.cues.length} cues · {new Date(s.createdAt).toLocaleString()}
                    </p>
                    <p className="mt-1 truncate text-[11px] text-mist-600">{s.videoName}</p>
                  </div>
                  <Btn size="sm" variant="ghost" className="text-rust-400" onClick={() => void deleteSet(s)}>
                    <Icon name="trash" className="h-4 w-4" />
                  </Btn>
                </div>
                <div className="flex gap-2">
                  <Btn
                    size="sm"
                    variant="ghost"
                    onClick={() => downloadText(`${s.title.replace(/\s+/g, "_")}.srt`, s.srt)}
                  >
                    <Icon name="download" className="h-4 w-4" /> SRT
                  </Btn>
                  <Btn
                    size="sm"
                    variant="ghost"
                    onClick={() => downloadText(`${s.title.replace(/\s+/g, "_")}.vtt`, s.vtt)}
                  >
                    <Icon name="download" className="h-4 w-4" /> VTT
                  </Btn>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Card className="p-4">
        <p className="flex items-start gap-2 text-[11px] leading-relaxed text-mist-400">
          <Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0 text-jade-400" />
          Browser storage rules: IndexedDB data persists until you clear site data or the browser
          evicts under pressure (not guaranteed). Export SRT/VTT as a backup; models can always be
          re-downloaded in the Models tab.
        </p>
      </Card>
    </div>
  );
}
