import React, { useEffect, useState } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import {
  BookOpen,
  Building2,
  CheckCircle2,
  Download,
  FileText,
  GraduationCap,
  Search,
  Sparkles,
  Wrench,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import {
  BUILTIN_COURSES,
  BUILTIN_MATERIALS,
  COMMON_SUBJECT_NAMES,
  TEVETA_COLLEGES,
} from '../lib/tevetaCatalog';
import type { LanguageCode, LibraryCourse, LibraryMaterial, LibrarySection } from '../types';

interface LibraryTabProps {
  language: LanguageCode;
  isAdmin: boolean;
  selectedCollegeFilter?: string;
  onCollegeFilterChange?: (college: string) => void;
  onOpenCollegeNotice?: () => void;
  onAskAiAboutMaterial: (material: LibraryMaterial, selectedExcerpt?: string) => void;
  onOpenAdminUpload: () => void;
}

const OFFLINE_CACHE_KEY = 'tevet_power_offline_materials_v1';

export const LibraryTab: React.FC<LibraryTabProps> = ({
  language,
  isAdmin,
  selectedCollegeFilter,
  onCollegeFilterChange,
  onOpenCollegeNotice,
  onAskAiAboutMaterial,
  onOpenAdminUpload,
}) => {
  const t = TRANSLATIONS[language];
  const [activeSection, setActiveSection] = useState<'common' | 'course' | 'practical' | 'fundamentals' | 'past_paper' | 'offline'>('common');
  const [cloudCourses, setCloudCourses] = useState<LibraryCourse[]>([]);
  const [cloudMaterials, setCloudMaterials] = useState<LibraryMaterial[]>([]);
  const [offlineMaterials, setOfflineMaterials] = useState<LibraryMaterial[]>(() => {
    try {
      const raw = localStorage.getItem(OFFLINE_CACHE_KEY);
      return raw ? (JSON.parse(raw) as LibraryMaterial[]) : [];
    } catch {
      return [];
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCollege, setSelectedCollege] = useState(selectedCollegeFilter || 'All');
  const [selectedLevel, setSelectedLevel] = useState('All');
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [readingMaterial, setReadingMaterial] = useState<LibraryMaterial | null>(null);
  const [selectedTextForAi, setSelectedTextForAi] = useState('');

  useEffect(() => {
    if (selectedCollegeFilter) {
      setSelectedCollege(selectedCollegeFilter);
    }
  }, [selectedCollegeFilter]);

  useEffect(() => {
    const unsubCourses = onSnapshot(
      collection(db, 'libraryCourses'),
      (snap) => {
        setCloudCourses(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<LibraryCourse, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'libraryCourses')
    );

    const unsubMats = onSnapshot(
      collection(db, 'libraryMaterials'),
      (snap) => {
        setCloudMaterials(
          snap.docs
            .map((d) => ({ id: d.id, ...(d.data() as Omit<LibraryMaterial, 'id'>) }))
            .filter((m) => m.isAuthorized)
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'libraryMaterials')
    );

    return () => {
      unsubCourses();
      unsubMats();
    };
  }, []);

  const allCourses = [...BUILTIN_COURSES, ...cloudCourses];
  const allMaterials = [...cloudMaterials, ...BUILTIN_MATERIALS];

  const toggleOfflineSave = (mat: LibraryMaterial) => {
    const exists = offlineMaterials.some((m) => m.id === mat.id);
    const updated = exists
      ? offlineMaterials.filter((m) => m.id !== mat.id)
      : [mat, ...offlineMaterials];
    setOfflineMaterials(updated);
    try {
      localStorage.setItem(OFFLINE_CACHE_KEY, JSON.stringify(updated));
    } catch {
      // Storage quota full
    }
  };

  const handleDownloadStudyFile = (mat: LibraryMaterial) => {
    const body = `${mat.title}\nSubject: ${mat.subject}\nCourse: ${mat.courseName || 'General'}\nCollege: ${mat.college || 'TEVETA Malawi'}\nLevel: ${mat.level || 'All'}\n\n${mat.summary}\n\n${mat.contentMarkdown}`;
    const blob = new Blob([body], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${mat.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    if (!offlineMaterials.some((m) => m.id === mat.id)) {
      toggleOfflineSave(mat);
    }
  };

  const filteredMaterials = (activeSection === 'offline' ? offlineMaterials : allMaterials).filter(
    (m) => {
      if (activeSection !== 'offline' && m.section !== (activeSection as LibrarySection)) {
        return false;
      }
      if (selectedCollege !== 'All' && m.college && !m.college.includes(selectedCollege) && m.college !== 'All TEVETA Colleges') {
        return false;
      }
      if (selectedLevel !== 'All' && m.level && !m.level.includes(selectedLevel)) {
        return false;
      }
      if (selectedSubject !== 'All' && m.subject !== selectedSubject) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          m.title.toLowerCase().includes(q) ||
          m.subject.toLowerCase().includes(q) ||
          (m.courseName || '').toLowerCase().includes(q) ||
          m.summary.toLowerCase().includes(q)
        );
      }
      return true;
    }
  );

  const filteredCourses = allCourses.filter((c) => {
    if (selectedCollege !== 'All' && c.college !== selectedCollege) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        c.name.toLowerCase().includes(q) ||
        c.trade.toLowerCase().includes(q) ||
        c.college.toLowerCase().includes(q) ||
        c.department.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCaptureSelection = () => {
    const sel = window.getSelection()?.toString().trim() || '';
    if (sel) {
      setSelectedTextForAi(sel);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {t.library.title}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Common subjects, verified Malawian technical college programmes, workshop practicals, fundamentals, and offline study packs across all TEVETA colleges.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {onOpenCollegeNotice && (
            <button
              type="button"
              onClick={onOpenCollegeNotice}
              className="min-h-[40px] px-3.5 py-2 rounded-xl border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>{t.studentNotice.viewCollegesBtn}</span>
            </button>
          )}
          {isAdmin && (
            <button
              type="button"
              onClick={onOpenAdminUpload}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold cursor-pointer"
            >
              + Upload Resource / Course
            </button>
          )}
        </div>
      </section>

      {/* Section Segmented Navigation */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl overflow-x-auto no-scrollbar">
        {[
          { id: 'common', label: t.library.commonSubjects },
          { id: 'course', label: t.library.courseDirectory },
          { id: 'practical', label: t.library.practicalTraining },
          { id: 'fundamentals', label: t.library.fundamentals },
          { id: 'past_paper', label: t.library.examPrep },
          { id: 'offline', label: `${t.library.offlineLibrary} (${offlineMaterials.length})` },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveSection(item.id as typeof activeSection)}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              activeSection === item.id
                ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search notes, formulas, trades..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
          />
        </div>
        <select
          value={selectedCollege}
          onChange={(e) => {
            setSelectedCollege(e.target.value);
            onCollegeFilterChange?.(e.target.value);
          }}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
        >
          <option value="All">{t.library.filterCollege}</option>
          {TEVETA_COLLEGES.map((col) => (
            <option key={col} value={col}>{col}</option>
          ))}
        </select>
        <select
          value={selectedLevel}
          onChange={(e) => setSelectedLevel(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
        >
          <option value="All">{t.library.filterLevel}</option>
          <option value="Level 1">Level 1</option>
          <option value="Level 2">Level 2</option>
          <option value="Level 3">Level 3</option>
        </select>
        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
        >
          <option value="All">{t.library.filterSubject}</option>
          {COMMON_SUBJECT_NAMES.map((sub) => (
            <option key={sub} value={sub}>{sub}</option>
          ))}
        </select>
      </div>

      {/* Course Directory Sub-view when Course Directory is active */}
      {activeSection === 'course' && (
        <section className="space-y-3">
          <h2 className="font-display font-semibold text-base text-slate-900 dark:text-white">
            Verified TEVETA Malawi Programmes & Colleges ({filteredCourses.length})
          </h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {filteredCourses.map((course) => (
              <div
                key={course.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-display font-semibold text-sm text-slate-900 dark:text-white">
                    {course.name}
                  </h3>
                  <GraduationCap className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap gap-1.5">
                  <span>{course.college}</span>
                  <span aria-hidden="true">·</span>
                  <span>{course.department}</span>
                  <span aria-hidden="true">·</span>
                  <span>{course.level}</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {course.description}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Materials Grid */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-semibold text-base text-slate-900 dark:text-white">
            {activeSection === 'common'
              ? '7 Core Common Subjects Across TEVETA Programmes'
              : activeSection === 'practical'
              ? 'Workshop Practical Procedures & Competency Guides'
              : activeSection === 'fundamentals'
              ? 'Trade Fundamentals, Formulas & Core Principles'
              : activeSection === 'past_paper'
              ? 'Revision Guides & Authorized Assessment Prep'
              : activeSection === 'offline'
              ? 'Saved for Offline Reading'
              : 'Course-Specific Study Notes'}
          </h2>
          <span className="text-xs text-slate-500 tabular-nums">{filteredMaterials.length} items</span>
        </div>

        {filteredMaterials.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No resources match these filters yet. Try resetting filters or ask TEVET AI for help.
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {filteredMaterials.map((mat) => {
              const isSavedOffline = offlineMaterials.some((o) => o.id === mat.id);
              return (
                <article
                  key={mat.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-between"
                >
                  {mat.imagePreview && (
                    <div className="h-40 overflow-hidden bg-slate-100 dark:bg-slate-950">
                      <img
                        src={mat.imagePreview}
                        alt={mat.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}
                  <div className="p-4 sm:p-5 space-y-2.5 flex-1">
                    <div className="text-xs text-blue-700 dark:text-blue-400 font-medium flex flex-wrap items-center gap-1.5">
                      <span>{mat.subject}</span>
                      <span aria-hidden="true">·</span>
                      <span>{mat.level || 'All Levels'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="uppercase">{mat.docType}</span>
                    </div>
                    <h3 className="font-display font-semibold text-base text-slate-900 dark:text-white leading-snug">
                      {mat.title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {mat.summary}
                    </p>
                  </div>

                  <div className="px-4 sm:px-5 py-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setReadingMaterial(mat);
                        setSelectedTextForAi('');
                      }}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      {mat.section === 'practical' ? (
                        <Wrench className="w-3.5 h-3.5" />
                      ) : (
                        <BookOpen className="w-3.5 h-3.5" />
                      )}
                      <span>Open Reader</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => toggleOfflineSave(mat)}
                        className={`min-h-[38px] px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1 cursor-pointer ${
                          isSavedOffline
                            ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {isSavedOffline ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
                        <span>{isSavedOffline ? t.actions.savedOffline : t.actions.saveOffline}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onAskAiAboutMaterial(mat)}
                        className="min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-blue-700 dark:text-blue-400 flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>AI Tutor</span>
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* In-App Document & Note Reader Modal */}
      {readingMaterial && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-4">
              <div>
                <p className="text-xs text-blue-700 dark:text-blue-400 font-medium">
                  {readingMaterial.subject} · {readingMaterial.courseName || 'All Programmes'} · {readingMaterial.level || 'TEVETA'}
                </p>
                <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mt-0.5">
                  {readingMaterial.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setReadingMaterial(null)}
                className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div
              onMouseUp={handleCaptureSelection}
              onTouchEnd={handleCaptureSelection}
              className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap"
            >
              {readingMaterial.imagePreview && (
                <img
                  src={readingMaterial.imagePreview}
                  alt={readingMaterial.title}
                  className="w-full max-h-64 object-cover rounded-xl mb-4"
                  referrerPolicy="no-referrer"
                />
              )}
              {readingMaterial.fileUrl && (
                <a
                  href={readingMaterial.fileUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-blue-700 dark:text-blue-400 text-xs font-semibold"
                >
                  <FileText className="w-4 h-4" />
                  <span>Open Attached PDF / External Document</span>
                </a>
              )}
              <div className="font-sans">{readingMaterial.contentMarkdown}</div>
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {selectedTextForAi
                  ? `Selected excerpt (${selectedTextForAi.slice(0, 42)}...)`
                  : 'Tip: Highlight any difficult paragraph or formula, then ask TEVET AI.'}
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleDownloadStudyFile(readingMaterial)}
                  className="min-h-[40px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onAskAiAboutMaterial(
                      readingMaterial,
                      selectedTextForAi || readingMaterial.contentMarkdown
                    )
                  }
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>
                    {selectedTextForAi ? 'Explain Selected Section' : t.actions.explainWithAi}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
