import React, { useState } from 'react';
import { ArrowLeftRight, PiggyBank, Wallet, X, AlertCircle, Sparkles } from 'lucide-react';
import { Transaction, WalletBalance } from '../types';
import { formatNumber, formatRupiah, generateRefCode, getCurrentWibTime } from '../utils/formatters';

interface TransferSavingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  balances: WalletBalance;
  onRequestPin: (amount: number, onAuthorize: () => void) => void;
  onSuccessTransfer: (transaction: Transaction, newBalances: WalletBalance) => void;
}

export const TransferSavingsModal: React.FC<TransferSavingsModalProps> = ({
  isOpen,
  onClose,
  balances,
  onRequestPin,
  onSuccessTransfer,
}) => {
  const [direction, setDirection] = useState<'to_savings' | 'to_wallet'>('to_savings');
  const [amount, setAmount] = useState<number>(25000);
  const [customInput, setCustomInput] = useState<string>('25000');
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const maxAvailable = direction === 'to_savings' ? balances.wallet : balances.savings;

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '');
    setCustomInput(raw);
    setAmount(Number(raw));
    setErrorMsg('');
  };

  const handleSetMax = () => {
    setAmount(maxAvailable);
    setCustomInput(maxAvailable.toString());
    setErrorMsg('');
  };

  const handleExecute = () => {
    if (amount <= 0) {
      setErrorMsg('Masukkan nominal transfer minimal Rp 1.000');
      return;
    }

    if (amount > maxAvailable) {
      setErrorMsg(`Saldo sumber tidak mencukupi (Tersedia: ${formatRupiah(maxAvailable)})`);
      return;
    }

    onRequestPin(amount, () => {
      let newBalances: WalletBalance;
      let newTx: Transaction;

      if (direction === 'to_savings') {
        newBalances = {
          wallet: balances.wallet - amount,
          savings: balances.savings + amount,
        };
        newTx = {
          id: `TXN-${Date.now().toString().slice(-7)}`,
          type: 'to_savings',
          title: 'Simpan ke Tabungan Siswa',
          category: 'savings',
          amount: amount,
          sourceAccount: 'Dompet Saku Harian',
          paymentMethodName: 'Pindah Tabungan',
          timestamp: getCurrentWibTime(),
          status: 'success',
          referenceCode: generateRefCode('SAV-MOVE'),
          destination: 'savings',
          note: 'Menambah tabungan untuk leaderboard sekolah',
        };
      } else {
        newBalances = {
          wallet: balances.wallet + amount,
          savings: balances.savings - amount,
        };
        newTx = {
          id: `TXN-${Date.now().toString().slice(-7)}`,
          type: 'to_wallet',
          title: 'Tarik dari Tabungan Siswa',
          category: 'savings',
          amount: amount,
          sourceAccount: 'Tabungan Siswa',
          paymentMethodName: 'Tarik Tabungan',
          timestamp: getCurrentWibTime(),
          status: 'success',
          referenceCode: generateRefCode('WAL-MOVE'),
          destination: 'wallet',
          note: 'Penarikan tabungan ke uang saku',
        };
      }

      onSuccessTransfer(newTx, newBalances);
      onClose();
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-700 px-6 pt-6 pb-5 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <ArrowLeftRight className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-bold">Kelola Tabungan Siswa</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              aria-label="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-indigo-100 mt-2">
            Pindahkan uang saku ke tabungan berjangka untuk menaikkan peringkatmu di Leaderboard Siswa!
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Direction Toggle */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl">
            <button
              type="button"
              onClick={() => {
                setDirection('to_savings');
                setErrorMsg('');
              }}
              className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                direction === 'to_savings'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <PiggyBank className="w-4 h-4" />
              <span>Masuk Tabungan</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setDirection('to_wallet');
                setErrorMsg('');
              }}
              className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                direction === 'to_wallet'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span>Tarik ke Dompet</span>
            </button>
          </div>

          {/* Source & Destination Visualizer */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">
                {direction === 'to_savings' ? 'Dari Dompet Saku:' : 'Dari Tabungan Siswa:'}
              </span>
              <span className="font-mono font-bold text-slate-800">
                {formatRupiah(direction === 'to_savings' ? balances.wallet : balances.savings)}
              </span>
            </div>

            <div className="flex items-center justify-center text-indigo-600">
              <div className="w-8 h-8 rounded-full bg-indigo-50 border border-indigo-200 flex items-center justify-center">
                <ArrowLeftRight className="w-4 h-4" />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">
                {direction === 'to_savings' ? 'Ke Tabungan Siswa (Leaderboard):' : 'Ke Dompet Saku Harian:'}
              </span>
              <span className="font-mono font-bold text-indigo-700">
                {formatRupiah(direction === 'to_savings' ? balances.savings : balances.wallet)}
              </span>
            </div>
          </div>

          {/* Amount input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800">Nominal Transfer</label>
              <button
                type="button"
                onClick={handleSetMax}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 underline"
              >
                Gunakan Semua ({formatRupiah(maxAvailable)})
              </button>
            </div>

            <div className="relative mb-2">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 font-bold text-sm">
                Rp
              </div>
              <input
                type="text"
                value={formatNumber(amount)}
                onChange={handleAmountChange}
                className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-2xl text-base font-mono font-bold text-slate-900 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex gap-2">
              {[10000, 25000, 50000, 100000].map((val) => (
                <button
                  type="button"
                  key={val}
                  onClick={() => {
                    setAmount(val);
                    setCustomInput(val.toString());
                    setErrorMsg('');
                  }}
                  className={`flex-1 py-1 text-[11px] font-mono font-semibold rounded-lg border transition-colors ${
                    amount === val
                      ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  +{formatNumber(val)}
                </button>
              ))}
            </div>
          </div>

          {direction === 'to_savings' && (
            <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl text-xs text-indigo-800 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>
                Dengan menabung Rp {formatNumber(amount || 0)}, tabunganmu akan bertambah menjadi{' '}
                <strong className="font-mono">{formatRupiah(balances.savings + (amount || 0))}</strong>!
              </span>
            </div>
          )}

          {/* Action button */}
          <div className="pt-2">
            <button
              type="button"
              onClick={handleExecute}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold rounded-2xl shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
            >
              <span>Konfirmasi PIN & Pindahkan Saldo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
