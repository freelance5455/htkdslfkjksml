import { Copy, TriangleAlert, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatRange } from "@/lib/format";
import type { Appraisal, TradeIntent } from "@/lib/types";
import { cn } from "@/lib/utils";

type Props = {
  appraisal: Appraisal;
  intent: TradeIntent;
  timestamp: string;
  onCopy: () => void;
  onClose: () => void;
};

function CardList({
  title,
  items,
  tone,
}: {
  title: string;
  items: { name: string; skill?: string; note: string }[];
  tone: "paid" | "free";
}) {
  if (items.length === 0) return null;
  return (
    <div>
      <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-muted">{title}</h4>
      <ul className="space-y-1.5">
        {items.map((card) => (
          <li
            key={card.name}
            className={cn(
              "rounded-[var(--radius-sm)] bg-surface-2 px-3 py-2",
              tone === "paid" ? "shadow-[inset_3px_0_0_var(--color-accent)]" : "opacity-80",
            )}
          >
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-bold text-fg">{card.name}</span>
              {card.skill ? (
                <span className="font-display text-xs tracking-wide text-accent">{card.skill}</span>
              ) : null}
            </div>
            {card.note ? <p className="mt-0.5 text-xs text-muted">{card.note}</p> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function ResultPanel({ appraisal, intent, timestamp, onCopy, onClose }: Props) {
  return (
    <section className="rounded-[var(--radius-2xl)] bg-surface p-1 shadow-[var(--shadow-border)]">
      <div className="rounded-[calc(var(--radius-2xl)-4px)] bg-bg p-5">
        <div className="mb-4 flex items-start justify-between gap-3 border-b border-border pb-3">
          <div>
            <h3 className="text-base font-bold text-fg">AI တွက်ချက်မှုရလဒ်</h3>
            <p className="text-xs text-muted">{timestamp}</p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="secondary" size="sm" onClick={onCopy}>
              <Copy className="size-3.5" />
              Copy
            </Button>
            <Button variant="ghost" size="icon" className="size-9" onClick={onClose} aria-label="ပိတ်မည်">
              <X className="size-4" />
            </Button>
          </div>
        </div>

        <div className="mb-4">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-display text-xs font-semibold tracking-wide text-accent">
              TIER {appraisal.tier} · {appraisal.tierLabel}
            </span>
            <span className="text-xs text-muted">
              {intent === "buy" ? "ဝယ်ယူသူအတွက်" : "ရောင်းချသူအတွက်"} ·{" "}
              {appraisal.confidence === "high"
                ? "ယုံကြည်မှု မြင့်"
                : appraisal.confidence === "low"
                  ? "ယုံကြည်မှု နိမ့်"
                  : "ယုံကြည်မှု အလယ်အလတ်"}
            </span>
          </div>
          <p className="font-display text-3xl font-semibold tracking-tight text-fg tabular-nums">
            {formatRange(appraisal.finalMin, appraisal.finalMax)}
          </p>
          {appraisal.summary ? (
            <p className="mt-2 text-sm text-muted">{appraisal.summary}</p>
          ) : null}
        </div>

        {appraisal.deadLinkPenaltyPct > 0 ? (
          <div className="mb-4 flex gap-2 rounded-[var(--radius-md)] bg-danger/10 px-3 py-2.5 text-sm text-danger">
            <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
            <p>Google Dead Link ကြောင့် {appraisal.deadLinkPenaltyPct}% လျော့တွက်ထားသည်။</p>
          </div>
        ) : null}

        {appraisal.warnings.map((w) => (
          <div
            key={w}
            className="mb-3 flex gap-2 rounded-[var(--radius-md)] bg-surface-2 px-3 py-2 text-sm text-muted"
          >
            <TriangleAlert className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
            <p>{w}</p>
          </div>
        ))}

        <div className="space-y-4">
          <CardList title="စျေးရရှိမည့် Paid / Special Skill" items={appraisal.paidCards} tone="paid" />
          <CardList title="စျေးမရသော Free Booster / Event" items={appraisal.freeCards} tone="free" />
          <CardList title="Managers" items={appraisal.managers} tone="paid" />
        </div>

        {appraisal.coinAddMmk > 0 ? (
          <p className="mt-3 text-xs text-muted">
            Coins တန်ဖိုး ထည့်တွက်ပြီး:{" "}
            <span className="font-display tabular-nums text-fg">
              +{appraisal.coinAddMmk.toLocaleString("en-US")} MMK
            </span>
          </p>
        ) : null}

        {appraisal.marketAnalysis ? (
          <div className="mt-5">
            <h4 className="mb-1.5 text-xs font-bold uppercase tracking-wider text-muted">
              စျေးကွက်အခြေအနေ
            </h4>
            <p className="text-sm text-fg">{appraisal.marketAnalysis}</p>
          </div>
        ) : null}

        {appraisal.strategyPoints.length > 0 ? (
          <div className="mt-5">
            <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-muted">
              {intent === "buy" ? "ဝယ်ယူသူအတွက် အကြံပြုချက်" : "ရောင်းချသူအတွက် အကြံပြုချက်"}
            </h4>
            <ol className="space-y-1.5">
              {appraisal.strategyPoints.map((point, i) => (
                <li key={point} className="flex items-start gap-2 text-sm text-fg">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-[var(--radius-xs)] bg-surface-2 font-display text-xs text-accent">
                    {i + 1}
                  </span>
                  <span>{point}</span>
                </li>
              ))}
            </ol>
          </div>
        ) : null}

        <div className="mt-5 flex items-center justify-between border-t border-border pt-3 text-xs text-subtle">
          <span>Myanmar Market Engine</span>
          <span className="font-display tracking-wide">Bruno Gaming</span>
        </div>
      </div>
    </section>
  );
}
