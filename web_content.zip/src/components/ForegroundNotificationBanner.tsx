import React, { useState, useEffect } from 'react';
import { Bell, X, ChevronRight, Award, ClipboardList, Sparkles, BookOpen } from 'lucide-react';
import { AppNotification, Language } from '../types';
import { subscribeToForegroundNotifications } from '../services/notificationService';

interface ForegroundNotificationBannerProps {
  language: Language;
  onNavigateTab?: (tab: string) => void;
  onOpenNotificationCenter?: () => void;
}

export default function ForegroundNotificationBanner({
  language,
  onNavigateTab,
  onOpenNotificationCenter
}: ForegroundNotificationBannerProps) {
  const [activeNotification, setActiveNotification] = useState<AppNotification | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToForegroundNotifications((notif) => {
      setActiveNotification(notif);

      // Auto dismiss after 8 seconds
      const timer = setTimeout(() => {
        setActiveNotification((curr) => (curr?.notificationId === notif.notificationId ? null : curr));
      }, 8000);

      return () => clearTimeout(timer);
    });

    return unsubscribe;
  }, []);

  if (!activeNotification) return null;

  const handleClick = () => {
    if (activeNotification.actionTab && onNavigateTab) {
      onNavigateTab(activeNotification.actionTab);
    } else if (onOpenNotificationCenter) {
      onOpenNotificationCenter();
    }
    setActiveNotification(null);
  };

  const getIcon = () => {
    switch (activeNotification.category) {
      case 'weekly_quiz':
        return <Award className="w-5 h-5 text-amber-300" />;
      case 'exam_alert':
        return <ClipboardList className="w-5 h-5 text-purple-300" />;
      case 'study_reminder':
        return <Sparkles className="w-5 h-5 text-indigo-300" />;
      case 'daily_questions':
        return <BookOpen className="w-5 h-5 text-emerald-300" />;
      default:
        return <Bell className="w-5 h-5 text-indigo-300" />;
    }
  };

  return (
    <div className="fixed top-4 left-4 right-4 md:left-auto md:right-6 md:max-w-md z-50 animate-in slide-in-from-top-4 fade-in duration-300 pointer-events-auto">
      <div 
        onClick={handleClick}
        className="group relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/90 to-slate-900 border border-indigo-500/40 p-4 shadow-2xl shadow-indigo-950/80 cursor-pointer flex items-start gap-3.5 hover:border-indigo-400/80 transition-all duration-200"
      >
        {/* Glowing side accent line */}
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-indigo-500 via-purple-500 to-pink-500" />

        {/* Icon */}
        <div className="p-2.5 rounded-xl bg-slate-800/90 border border-slate-700/80 shrink-0 mt-0.5 shadow-sm">
          {getIcon()}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 pr-2">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {language === 'bn' ? 'নতুন নোটিফিকেশন' : 'New Update'}
            </span>
            <span className="text-[10px] text-slate-400">
              {language === 'bn' ? 'এইমাত্র' : 'Just now'}
            </span>
          </div>

          <h4 className="text-sm font-black text-white leading-tight truncate">
            {activeNotification.title}
          </h4>

          <p className="text-xs text-slate-300 leading-snug line-clamp-2 mt-0.5">
            {activeNotification.message}
          </p>

          <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-indigo-400 group-hover:text-indigo-300 transition-colors">
            <span>{activeNotification.actionText || (language === 'bn' ? 'ট্যাপ করে দেখুন' : 'Tap to open')}</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>

        {/* Close button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setActiveNotification(null);
          }}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/80 transition-colors shrink-0"
          aria-label="Dismiss"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
