import React, { useState, useEffect } from 'react';
import { Product, Customer, CartItem, PaymentMethod, SaleInvoice } from '../types/business';
import { StorageService } from '../db/storage';
import {
  ArrowLeft,
  Search,
  ShoppingCart,
  User,
  Plus,
  Trash2,
  CheckCircle2,
  DollarSign,
  AlertCircle,
  Package,
  Layers,
  Phone,
  Tag,
  Calendar,
  X,
} from 'lucide-react';

interface SalesScreenProps {
  lang: 'bn' | 'en';
  onBack: () => void;
  onInvoiceCreated: (invoice: SaleInvoice) => void;
}

export const SalesScreen: React.FC<SalesScreenProps> = ({
  lang,
  onBack,
  onInvoiceCreated,
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);

  // Selected Customer state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('walk-in');
  const [customerSearch, setCustomerSearch] = useState('');
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustWhatsApp, setNewCustWhatsApp] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');

  // Product Search & Selection
  const [productSearch, setProductSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBrand, setSelectedBrand] = useState<string>('All');

  // Cart
  const [cart, setCart] = useState<CartItem[]>([]);
  const [discount, setDiscount] = useState<number | ''>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [paidAmount, setPaidAmount] = useState<number | ''>('');
  const [dueDate, setDueDate] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    setProducts(StorageService.getProducts());
    setCustomers(StorageService.getCustomers());
  }, []);

  // Filter customers for dropdown/search
  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.phone.includes(customerSearch)
  );

  const selectedCustomerObj =
    selectedCustomerId === 'walk-in'
      ? {
          id: 'walk-in',
          name: lang === 'bn' ? 'নগদ ক্রেতা (Walk-in Customer)' : 'Cash / Walk-in Customer',
          phone: '',
          address: '',
          currentDue: 0,
        }
      : customers.find((c) => c.id === selectedCustomerId);

  // Add Item to Cart
  const handleAddToCart = (product: Product, priceType: 'Retail' | 'Wholesale' = 'Retail') => {
    if (product.stockQuantity <= 0) {
      alert(lang === 'bn' ? 'Stock শেষ — এই পণ্য বিক্রি করা যাবে না।' : 'Out of Stock - cannot be sold!');
      return;
    }

    const existingIndex = cart.findIndex((item) => item.productId === product.id);
    const unitPrice = priceType === 'Wholesale' ? product.wholesalePrice : product.retailPrice;

    if (existingIndex !== -1) {
      const existing = cart[existingIndex];
      if (existing.quantity + 1 > product.stockQuantity) {
        alert(
          lang === 'bn'
            ? `দোকানে মাত্র ${product.stockQuantity} পিস মজুদ আছে!`
            : `Only ${product.stockQuantity} pcs available in stock!`
        );
        return;
      }
      const updatedCart = [...cart];
      const newQty = existing.quantity + 1;
      const newTotal = newQty * existing.unitPrice;
      const newProfit = (existing.unitPrice - existing.purchasePrice) * newQty;
      updatedCart[existingIndex] = {
        ...existing,
        quantity: newQty,
        totalPrice: newTotal,
        profit: newProfit,
      };
      setCart(updatedCart);
    } else {
      const newItem: CartItem = {
        productId: product.id,
        productName: product.name,
        category: product.category,
        brand: product.brand,
        modelNumber: product.modelNumber,
        frontPhoto: product.frontPhoto,
        quantity: 1,
        purchasePrice: product.purchasePrice,
        unitPrice: unitPrice,
        priceType: priceType,
        totalPrice: unitPrice,
        profit: unitPrice - product.purchasePrice,
      };
      setCart([...cart, newItem]);
    }
  };

  // Modify Cart Item Quantity
  const handleUpdateQty = (productId: string, newQty: number) => {
    const p = products.find((prod) => prod.id === productId);
    if (!p) return;

    if (newQty <= 0) {
      handleRemoveFromCart(productId);
      return;
    }

    if (newQty > p.stockQuantity) {
      alert(
        lang === 'bn'
          ? `দোকানে মাত্র ${p.stockQuantity} পিস মজুদ আছে!`
          : `Only ${p.stockQuantity} pcs available in stock!`
      );
      return;
    }

    const updated = cart.map((item) => {
      if (item.productId === productId) {
        const totalPrice = newQty * item.unitPrice;
        const profit = (item.unitPrice - item.purchasePrice) * newQty;
        return { ...item, quantity: newQty, totalPrice, profit };
      }
      return item;
    });
    setCart(updated);
  };

  // Modify Cart Item Price & Type
  const handleUpdatePrice = (
    productId: string,
    newPrice: number,
    priceType: 'Retail' | 'Wholesale' | 'Custom'
  ) => {
    const updated = cart.map((item) => {
      if (item.productId === productId) {
        const safePrice = Math.max(0, newPrice);
        const totalPrice = item.quantity * safePrice;
        const profit = (safePrice - item.purchasePrice) * item.quantity;
        return {
          ...item,
          unitPrice: safePrice,
          priceType,
          totalPrice,
          profit,
        };
      }
      return item;
    });
    setCart(updated);
  };

  // Remove from cart
  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.productId !== productId));
  };

  // Quick Customer Creation
  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim() || !newCustPhone.trim()) {
      alert(lang === 'bn' ? 'কাস্টমারের নাম ও মোবাইল নম্বর আবশ্যক' : 'Name and phone required');
      return;
    }

    const created = StorageService.addCustomer({
      name: newCustName.trim(),
      phone: newCustPhone.trim(),
      whatsapp: newCustWhatsApp.trim() || newCustPhone.trim(),
      address: newCustAddress.trim(),
    });

    setCustomers(StorageService.getCustomers());
    setSelectedCustomerId(created.id);
    setShowAddCustomerModal(false);
    setNewCustName('');
    setNewCustPhone('');
    setNewCustWhatsApp('');
    setNewCustAddress('');
  };

  // Calculations
  const totalItems = cart.length;
  const totalQuantity = cart.reduce((sum, i) => sum + i.quantity, 0);
  const totalSalesAmount = cart.reduce((sum, i) => sum + i.totalPrice, 0);
  const totalPurchaseCost = cart.reduce((sum, i) => sum + i.purchasePrice * i.quantity, 0);
  const grossProfit = totalSalesAmount - totalPurchaseCost;
  const discountVal = Number(discount) || 0;
  const finalPayable = Math.max(0, totalSalesAmount - discountVal);
  const netProfit = grossProfit - discountVal;

  // Auto set paid amount when payable changes or payment method toggles
  useEffect(() => {
    if (paymentMethod === 'Due') {
      if (paidAmount === '' || paidAmount === finalPayable) {
        setPaidAmount(0);
      }
    } else {
      setPaidAmount(finalPayable);
    }
  }, [finalPayable, paymentMethod]);

  const currentPaid = paidAmount === '' ? 0 : Number(paidAmount);
  const dueAmount = Math.max(0, finalPayable - currentPaid);

  // Complete Sale
  const handleCompleteSale = () => {
    if (cart.length === 0) {
      setErrorMessage(lang === 'bn' ? 'কার্টে অন্তত একটি পণ্য যোগ করুন' : 'Please add items to cart');
      return;
    }

    if (dueAmount > 0 && selectedCustomerId === 'walk-in') {
      setErrorMessage(
        lang === 'bn'
          ? 'বাকি বিক্রয়ের জন্য কাস্টমার নির্বাচন অথবা নতুন কাস্টমার যোগ করা আবশ্যক।'
          : 'Please select a specific customer for due sales (cannot sell due to walk-in).'
      );
      return;
    }

    try {
      const invoice = StorageService.createSaleInvoice({
        customerId: selectedCustomerId,
        customerName: selectedCustomerObj?.name || 'Walk-in',
        customerPhone: selectedCustomerObj?.phone || '',
        customerAddress: (selectedCustomerObj as any)?.address || '',
        items: cart,
        discount: discountVal,
        paymentMethod: paymentMethod,
        paidAmount: currentPaid,
        dueDate: dueAmount > 0 ? dueDate : undefined,
      });

      // Reset cart
      setCart([]);
      setDiscount(0);
      setPaidAmount('');
      setErrorMessage('');

      // Open Invoice
      onInvoiceCreated(invoice);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error completing sale');
    }
  };

  // Filtered product catalog for selection
  const catalogProducts = products.filter((p) => {
    const q = productSearch.toLowerCase();
    const matchSearch =
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.modelNumber.toLowerCase().includes(q) ||
      p.supportedModels.toLowerCase().includes(q);
    const matchCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchBrand = selectedBrand === 'All' || p.brand === selectedBrand;
    return matchSearch && matchCat && matchBrand;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Top Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-600" />
                <span>{lang === 'bn' ? 'বিক্রয় ও চালান তৈরি (Sales POS)' : 'New Sale / POS'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? 'পণ্য সিলেক্ট করুন ও স্বয়ংক্রিয় ইনভয়েস জেনারেট করুন'
                  : 'Select parts & generate verified invoice'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500 hidden sm:inline">
              কার্ট আইটেম:
            </span>
            <span className="px-3 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-extrabold text-sm">
              {totalQuantity} pcs
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5">
        {errorMessage && (
          <div className="mb-4 p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-2xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* LEFT COLUMN: Customer & Product Catalog (7 Cols) */}
          <div className="lg:col-span-7 space-y-5">
            {/* 1. CUSTOMER SELECTION CARD */}
            <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <User className="w-4 h-4 text-indigo-600" />
                  <span>{lang === 'bn' ? 'ক্রেতা / কাস্টমার নির্বাচন' : 'Customer Selection'}</span>
                </h3>
                <button
                  onClick={() => setShowAddCustomerModal(true)}
                  className="px-3 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'নতুন কাস্টমার' : 'Add Customer'}</span>
                </button>
              </div>

              {/* Select & Search Customer */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="walk-in">
                      {lang === 'bn' ? 'নগদ ক্রেতা (Walk-in Customer)' : 'Cash / Walk-in Customer'}
                    </option>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone}) {c.currentDue > 0 ? `• বাকি: ৳${c.currentDue}` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                    placeholder={lang === 'bn' ? 'কাস্টমার নাম বা ফোন দিয়ে খুঁজুন...' : 'Search by name or phone...'}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* Selected Customer Info Badge */}
              {selectedCustomerObj && selectedCustomerObj.id !== 'walk-in' && (
                <div className="mt-3 p-3 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-indigo-950 block">{selectedCustomerObj.name}</span>
                    <span className="text-slate-600 font-medium">মোবাইল: {selectedCustomerObj.phone}</span>
                  </div>
                  {selectedCustomerObj.currentDue > 0 && (
                    <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 font-extrabold text-xs">
                      পূর্বের বাকি: ৳{selectedCustomerObj.currentDue.toLocaleString()}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* 2. PRODUCT CATALOG SEARCH & SELECTION */}
            <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <Package className="w-4 h-4 text-blue-600" />
                  <span>{lang === 'bn' ? 'পণ্য নির্বাচন (Product Selection)' : 'Select Products'}</span>
                </h3>
                <span className="text-xs text-slate-400 font-medium">
                  {catalogProducts.length} {lang === 'bn' ? 'আইটেম লভ্য' : 'items'}
                </span>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-4">
                <div className="relative sm:col-span-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    placeholder="মডেল বা পার্টস খুঁজুন..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700"
                >
                  <option value="All">{lang === 'bn' ? 'সব ক্যাটাগরি' : 'All Categories'}</option>
                  <option value="LCD/Display">LCD/Display</option>
                  <option value="Touch/Glass">Touch/Glass</option>
                  <option value="Battery">Battery</option>
                  <option value="Charging Ribbon">Charging Ribbon</option>
                  <option value="Housing/Body">Housing/Body</option>
                  <option value="Camera">Camera</option>
                  <option value="IC/Motherboard Parts">IC/Motherboard Parts</option>
                  <option value="Tools">Tools</option>
                </select>
                <select
                  value={selectedBrand}
                  onChange={(e) => setSelectedBrand(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700"
                >
                  <option value="All">{lang === 'bn' ? 'সব ব্র্যান্ড' : 'All Brands'}</option>
                  <option value="Samsung">Samsung</option>
                  <option value="Xiaomi / Redmi">Xiaomi / Redmi</option>
                  <option value="Oppo">Oppo</option>
                  <option value="Vivo">Vivo</option>
                  <option value="Realme">Realme</option>
                  <option value="Apple">Apple</option>
                  <option value="Infinix">Infinix</option>
                  <option value="Tecno">Tecno</option>
                  <option value="OnePlus">OnePlus</option>
                </select>
              </div>

              {/* Product Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[460px] overflow-y-auto pr-1">
                {catalogProducts.map((p) => {
                  const isOutOfStock = p.stockQuantity <= 0;
                  const isLimited = p.stockQuantity > 0 && p.stockQuantity <= p.alertLimit;

                  return (
                    <div
                      key={p.id}
                      className={`p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                        isOutOfStock
                          ? 'bg-slate-50 border-slate-200 opacity-60'
                          : isLimited
                          ? 'bg-amber-50/20 border-amber-200 hover:border-amber-400'
                          : 'bg-white border-slate-200 hover:border-blue-400'
                      }`}
                    >
                      <div className="flex items-start gap-2.5 mb-2">
                        <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                          {p.frontPhoto ? (
                            <img src={p.frontPhoto} alt={p.name} className="w-full h-full object-cover" />
                          ) : (
                            <Package className="w-6 h-6 text-slate-400" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] font-bold text-indigo-600 block">
                            {p.brand} • {p.category}
                          </span>
                          <h4 className="font-bold text-slate-900 text-xs leading-snug truncate">
                            {p.modelNumber}
                          </h4>
                          <div className="flex items-center gap-1.5 mt-1">
                            {isOutOfStock ? (
                              <span className="px-1.5 py-0.2 rounded text-[10px] font-extrabold bg-red-100 text-red-700">
                                Stock শেষ
                              </span>
                            ) : (
                              <span className="text-[11px] text-slate-600 font-semibold">
                                মজুদ: <strong className="text-slate-900">{p.stockQuantity} pcs</strong>
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Pricing and Add Buttons */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-1.5">
                        <div className="text-[11px]">
                          <span className="text-slate-400 block text-[9px]">মূল্য</span>
                          <span className="font-bold text-slate-800">৳{p.retailPrice}</span>
                        </div>

                        {isOutOfStock ? (
                          <span className="text-[11px] text-red-600 font-bold italic py-1">
                            বিক্রি বন্ধ
                          </span>
                        ) : (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleAddToCart(p, 'Retail')}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-2xs cursor-pointer active:scale-95"
                              title="খুচরা মূল্যে যোগ"
                            >
                              + খুচরা (৳{p.retailPrice})
                            </button>
                            <button
                              onClick={() => handleAddToCart(p, 'Wholesale')}
                              className="px-2 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] shadow-2xs cursor-pointer active:scale-95"
                              title="পাইকারি মূল্যে যোগ"
                            >
                              পাইকারি
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Sales Cart & Checkout Invoice Summary (5 Cols) */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-md sticky top-20">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-emerald-600" />
                  <span>{lang === 'bn' ? 'বিক্রয় কার্ট' : 'Sales Cart'}</span>
                </h3>
                <span className="text-xs text-slate-500 font-semibold">
                  {cart.length} {lang === 'bn' ? 'টি পণ্য' : 'products'}
                </span>
              </div>

              {/* Cart Items List */}
              {cart.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  <ShoppingCart className="w-10 h-10 mx-auto mb-2 text-slate-300 stroke-1" />
                  <p>{lang === 'bn' ? 'কার্ট খালি — বাম পাশের তালিকা থেকে পণ্য যোগ করুন' : 'Cart is empty'}</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1 mb-4">
                  {cart.map((item) => (
                    <div
                      key={item.productId}
                      className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-bold text-slate-400 uppercase">
                            {item.brand}
                          </span>
                          <h5 className="font-bold text-slate-900 text-xs leading-tight">
                            {item.modelNumber}
                          </h5>
                        </div>
                        <button
                          onClick={() => handleRemoveFromCart(item.productId)}
                          className="text-red-500 hover:text-red-700 p-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Quantity & Unit Price Controls */}
                      <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200/60 text-xs">
                        {/* Quantity Counter */}
                        <div className="flex items-center gap-1 bg-white rounded-lg border border-slate-200 p-0.5">
                          <button
                            onClick={() => handleUpdateQty(item.productId, item.quantity - 1)}
                            className="w-6 h-6 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100 rounded cursor-pointer"
                          >
                            -
                          </button>
                          <span className="w-7 text-center font-bold text-slate-900">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => handleUpdateQty(item.productId, item.quantity + 1)}
                            className="w-6 h-6 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100 rounded cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        {/* Price Input */}
                        <div className="flex items-center gap-1">
                          <span className="text-[11px] text-slate-400">দর ৳</span>
                          <input
                            type="number"
                            min="0"
                            value={item.unitPrice}
                            onChange={(e) =>
                              handleUpdatePrice(item.productId, Number(e.target.value) || 0, 'Custom')
                            }
                            className="w-16 px-1.5 py-1 rounded border border-slate-200 bg-white text-xs font-bold text-slate-900 text-right"
                          />
                        </div>

                        {/* Item Total */}
                        <span className="font-extrabold text-slate-900 text-sm">
                          ৳{item.totalPrice.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Total Calculation Grid */}
              <div className="space-y-2 pt-3 border-t border-slate-200 text-xs font-medium">
                <div className="flex justify-between text-slate-600">
                  <span>মোট পরিমাণ:</span>
                  <span className="font-bold text-slate-800">{totalQuantity} পিস</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>মোট বিক্রয় মূল্য:</span>
                  <span className="font-bold text-slate-800">৳{totalSalesAmount.toLocaleString()}</span>
                </div>

                {/* Discount */}
                <div className="flex items-center justify-between text-slate-600">
                  <span>ডিসকাউন্ট / ছাড় (৳):</span>
                  <input
                    type="number"
                    min="0"
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-20 px-2 py-0.5 rounded border border-slate-200 text-right font-bold text-slate-900"
                  />
                </div>

                <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-200">
                  <span>সর্বমোট প্রদেয়:</span>
                  <span className="text-emerald-700 text-base">৳{finalPayable.toLocaleString()}</span>
                </div>

                {/* Gross Profit Preview for Merchant */}
                <div className="flex justify-between text-[11px] text-blue-700 bg-blue-50 p-2 rounded-xl border border-blue-100">
                  <span>আনুমানিক নিট লাভ:</span>
                  <span className="font-bold">৳{netProfit.toLocaleString()}</span>
                </div>
              </div>

              {/* Payment Section */}
              <div className="mt-4 pt-3 border-t border-slate-200 space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    পরিশোধের মাধ্যম (Payment Method)
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['Cash', 'bKash', 'Nagad', 'Bank', 'Due'] as PaymentMethod[]).map((method) => (
                      <button
                        key={method}
                        type="button"
                        onClick={() => setPaymentMethod(method)}
                        className={`py-1.5 px-2 rounded-xl text-xs font-bold border cursor-pointer transition-all ${
                          paymentMethod === method
                            ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {method}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Paid Amount & Due Calculation */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      জমা / পেইড (৳)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max={finalPayable}
                      value={paidAmount}
                      onChange={(e) => setPaidAmount(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 font-bold text-emerald-700 focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      বাকি / ডিউ (৳)
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={`৳${dueAmount.toLocaleString()}`}
                      className="w-full px-2.5 py-1.5 rounded-xl border border-amber-200 bg-amber-50 font-bold text-amber-900"
                    />
                  </div>
                </div>

                {dueAmount > 0 && (
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      বাকি পরিশোধের সম্ভাব্য তারিখ (Due Date)
                    </label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800"
                    />
                  </div>
                )}
              </div>

              {/* Complete Sale Button */}
              <button
                onClick={handleCompleteSale}
                disabled={cart.length === 0}
                className="mt-5 w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-extrabold text-sm shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>{lang === 'bn' ? 'বিক্রয় সম্পন্ন করুন (Complete Sale)' : 'Complete Sale'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* QUICK ADD CUSTOMER MODAL */}
      {showAddCustomerModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <User className="w-5 h-5 text-indigo-600" />
                <span>নতুন কাস্টমার নিবন্ধন</span>
              </h3>
              <button
                onClick={() => setShowAddCustomerModal(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  কাস্টমারের নাম *
                </label>
                <input
                  type="text"
                  required
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  placeholder="যেমন: মোঃ কামরুল ইসলাম"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  মোবাইল নম্বর *
                </label>
                <input
                  type="tel"
                  required
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  placeholder="017xxxxxxxx"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  হোয়াটসঅ্যাপ নম্বর (ঐচ্ছিক)
                </label>
                <input
                  type="tel"
                  value={newCustWhatsApp}
                  onChange={(e) => setNewCustWhatsApp(e.target.value)}
                  placeholder="017xxxxxxxx"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ঠিকানা
                </label>
                <input
                  type="text"
                  value={newCustAddress}
                  onChange={(e) => setNewCustAddress(e.target.value)}
                  placeholder="বালাগঞ্জ বাজার, সিলেট"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddCustomerModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-500/20 cursor-pointer"
                >
                  কাস্টমার সংরক্ষণ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
