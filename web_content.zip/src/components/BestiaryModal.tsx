import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  BookOpen,
  Clock,
  Crown,
  Flame,
  Ghost,
  PawPrint,
  Search,
  Shield,
  Skull,
  Sparkles,
  Swords,
  X,
} from 'lucide-react';
import { ELEMENTS } from '../game/data/elements';
import { BOSSES, CREATURES, MONSTERS } from '../game/data/entities';
import { ITEMS } from '../game/data/items';
import {
  ActiveSummonEntry,
  BestiaryRecord,
  EntityArchetype,
  EntityRank,
  EntityTemplateDef,
} from '../game/types';

interface BestiaryModalProps {
  open: boolean;
  bestiary: Record<string, BestiaryRecord>;
  activeSummons: ActiveSummonEntry[];
  soulPowerUsed: number;
  soulControlMax: number;
  summonMasteryLevel: number;
  summonMasteryXp: number;
  summonCooldowns: Record<string, number>;
  playerMana: number;
  onClose: () => void;
  onSummon: (entityId: string) => void;
  onDismissSummon: (uid?: string) => void;
  onReclaimSummon: (uid: string) => void;
}

const RANK_LABELS: Record<EntityRank, { label: string; cls: string }> = {
  common: { label: 'عادي', cls: 'bg-slate-800 text-slate-300 border-slate-700' },
  rare: { label: 'نادر', cls: 'bg-sky-950/90 text-sky-300 border-sky-500/50' },
  elite: { label: 'نخبة', cls: 'bg-purple-950/90 text-purple-300 border-purple-500/50' },
  legendary: { label: 'أسطوري', cls: 'bg-amber-950/90 text-amber-300 border-amber-500/60' },
  boss: { label: 'زعيم', cls: 'bg-rose-950/90 text-rose-300 border-rose-500/60' },
};

const ROLE_LABELS: Record<'tank' | 'dps' | 'ranged' | 'support', string> = {
  tank: 'دبابة',
  dps: 'مهاجم',
  ranged: 'رامي',
  support: 'دعم',
};

function ArchetypeEmblem({
  archetype,
  colorHex,
  discovered,
}: {
  archetype: EntityArchetype;
  colorHex: string;
  discovered: boolean;
}) {
  const stroke = discovered ? colorHex : '#475569';
  return (
    <svg viewBox="0 0 28 28" className="h-7 w-7 shrink-0 rounded-lg border border-slate-700/80 bg-slate-900 p-1">
      {archetype === 'dragon' || archetype === 'winged' ? (
        <path
          d="M4 18 L9 8 L14 13 L19 8 L24 18 L14 22 Z"
          fill={stroke}
          fillOpacity={0.35}
          stroke={stroke}
          strokeWidth={1.6}
        />
      ) : archetype === 'skeleton' ? (
        <>
          <circle cx="14" cy="11" r="6" fill={stroke} fillOpacity={0.28} stroke={stroke} strokeWidth={1.6} />
          <path d="M10 18 v4 M14 18 v4 M18 18 v4" stroke={stroke} strokeWidth={1.8} strokeLinecap="round" />
        </>
      ) : archetype === 'golem' ? (
        <polygon
          points="7,5 21,5 24,14 20,23 8,23 4,14"
          fill={stroke}
          fillOpacity={0.35}
          stroke={stroke}
          strokeWidth={1.6}
        />
      ) : archetype === 'serpent' ? (
        <path
          d="M6 21 Q10 14 16 15 T22 7"
          fill="none"
          stroke={stroke}
          strokeWidth={3}
          strokeLinecap="round"
        />
      ) : archetype === 'wisp' || archetype === 'slime' ? (
        <path
          d="M6 19 C6 10 22 10 22 19 C22 22 6 22 6 19 Z"
          fill={stroke}
          fillOpacity={0.42}
          stroke={stroke}
          strokeWidth={1.6}
        />
      ) : (
        <>
          <circle cx="14" cy="13" r="6.5" fill={stroke} fillOpacity={0.3} stroke={stroke} strokeWidth={1.6} />
          <path d="M8 7 L11 10 M20 7 L17 10" stroke={stroke} strokeWidth={1.8} strokeLinecap="round" />
        </>
      )}
    </svg>
  );
}

export const BestiaryModal: React.FC<BestiaryModalProps> = ({
  open,
  bestiary,
  activeSummons,
  soulPowerUsed,
  soulControlMax,
  summonMasteryLevel,
  summonMasteryXp,
  summonCooldowns,
  playerMana,
  onClose,
  onSummon,
  onDismissSummon,
  onReclaimSummon,
}) => {
  const [tab, setTab] = useState<'creature' | 'monster' | 'boss'>('monster');
  const [query, setQuery] = useState('');
  const [rankFilter, setRankFilter] = useState<'all' | 'unlocked' | EntityRank>('all');

  const rawList: EntityTemplateDef[] =
    tab === 'creature' ? CREATURES : tab === 'monster' ? MONSTERS : BOSSES;

  const filteredList = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rawList.filter((ent) => {
      const rec = bestiary[ent.id];
      if (rankFilter === 'unlocked' && !rec?.summonUnlocked) return false;
      if (rankFilter !== 'all' && rankFilter !== 'unlocked') {
        const r = ent.rank ?? (ent.category === 'boss' ? 'boss' : 'common');
        if (r !== rankFilter) return false;
      }
      if (!q) return true;
      return ent.nameAr.toLowerCase().includes(q) || ent.descriptionAr.toLowerCase().includes(q);
    });
  }, [rawList, bestiary, query, rankFilter]);

  if (!open) return null;

  const countUnlocked = (arr: EntityTemplateDef[]) =>
    arr.filter((e) => bestiary[e.id]?.discovered).length;

  const masteryReq = 45 + (summonMasteryLevel - 1) * 35;
  const controlPct = Math.min(100, Math.round((soulPowerUsed / Math.max(1, soulControlMax)) * 100));

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 p-2.5 sm:p-6"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-purple-500/40 bg-slate-900 shadow-2xl">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-slate-950/90 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <BookOpen className="h-5 w-5 text-purple-400" />
            <div>
              <h2 className="text-base font-extrabold text-purple-100">
                موسوعة العالم ونظام استحضار الأرواح
              </h2>
              <p className="text-[11px] text-slate-400">
                استحضر حتى 3 كائنات معاً • تجاوز طاقة السيطرة يؤدي إلى تمرد المخلوق المستحضر!
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {activeSummons.length > 0 && (
              <button
                type="button"
                onClick={() => onDismissSummon()}
                className="rounded-xl border border-rose-500/40 bg-rose-500/15 px-3 py-1.5 text-xs font-bold text-rose-200 hover:bg-rose-500/30"
              >
                صرف الجميع
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-700 bg-slate-800 p-1.5 text-slate-300 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Soul Control Capacity & Mastery Panel */}
        <div className="grid grid-cols-1 gap-2 border-b border-slate-800 bg-slate-950/75 px-4 py-2.5 sm:grid-cols-2">
          <div className="rounded-xl border border-cyan-500/30 bg-slate-900/90 px-3 py-2">
            <div className="mb-1 flex items-center justify-between text-xs font-bold">
              <span className="flex items-center gap-1.5 text-cyan-200">
                <Ghost className="h-3.5 w-3.5 text-cyan-400" />
                طاقة السيطرة على الأرواح
              </span>
              <span className={soulPowerUsed > soulControlMax ? 'text-rose-400' : 'text-cyan-300'}>
                {soulPowerUsed} / {soulControlMax}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                className={`h-full transition-all ${
                  controlPct >= 90 ? 'bg-amber-400' : 'bg-cyan-500'
                }`}
                style={{ width: `${controlPct}%` }}
              />
            </div>
          </div>

          <div className="rounded-xl border border-purple-500/30 bg-slate-900/90 px-3 py-2">
            <div className="mb-1 flex items-center justify-between text-xs font-bold">
              <span className="flex items-center gap-1.5 text-purple-200">
                <Sparkles className="h-3.5 w-3.5 text-purple-400" />
                إتقان الاستحضار
              </span>
              <span className="text-purple-300">
                Lv.{summonMasteryLevel} ({summonMasteryXp}/{masteryReq} XP)
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full bg-purple-500 transition-all"
                style={{ width: `${Math.min(100, Math.round((summonMasteryXp / Math.max(1, masteryReq)) * 100))}%` }}
              />
            </div>
          </div>
        </div>

        {/* Active Summons Bar */}
        {activeSummons.length > 0 && (
          <div className="flex flex-wrap gap-2 border-b border-slate-800 bg-slate-950/60 px-4 py-2">
            {activeSummons.map((s) => (
              <div
                key={s.uid}
                className={`flex items-center gap-2 rounded-xl border px-2.5 py-1.5 text-xs ${
                  s.isRebel
                    ? 'border-rose-500/60 bg-rose-950/50 text-rose-100'
                    : 'border-cyan-500/40 bg-cyan-950/40 text-cyan-100'
                }`}
              >
                <span className="font-bold">{s.nameAr}</span>
                <span className="rounded bg-slate-900/80 px-1.5 py-0.5 text-[10px]">
                  {ROLE_LABELS[s.role]} • قوة {s.soulPower}
                </span>
                <span className="flex items-center gap-0.5 font-mono text-[10px] text-slate-300">
                  <Clock className="h-3 w-3" />
                  {s.remainingSec}ث
                </span>
                {s.isRebel ? (
                  <button
                    type="button"
                    onClick={() => onReclaimSummon(s.uid)}
                    className="rounded-lg bg-amber-500 px-2 py-0.5 text-[10px] font-extrabold text-slate-950 hover:bg-amber-400"
                  >
                    إخضاع
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => onDismissSummon(s.uid)}
                    className="rounded-lg border border-rose-500/40 bg-rose-500/15 px-2 py-0.5 text-[10px] font-bold text-rose-200 hover:bg-rose-500/30"
                  >
                    صرف
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Category Tabs + Search + Filter */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-slate-950/55 px-4 py-2.5">
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setTab('creature')}
              className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                tab === 'creature'
                  ? 'bg-emerald-600 text-white'
                  : 'border border-slate-700 bg-slate-800 text-slate-300'
              }`}
            >
              <PawPrint className="h-3.5 w-3.5" />
              المخلوقات ({countUnlocked(CREATURES)}/{CREATURES.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('monster')}
              className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                tab === 'monster'
                  ? 'bg-rose-600 text-white'
                  : 'border border-slate-700 bg-slate-800 text-slate-300'
              }`}
            >
              <Skull className="h-3.5 w-3.5" />
              الوحوش ({countUnlocked(MONSTERS)}/{MONSTERS.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('boss')}
              className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                tab === 'boss'
                  ? 'bg-amber-600 text-white'
                  : 'border border-slate-700 bg-slate-800 text-slate-300'
              }`}
            >
              <Crown className="h-3.5 w-3.5" />
              الزعماء ({countUnlocked(BOSSES)}/{BOSSES.length})
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute right-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث بالاسم..."
                className="w-40 rounded-lg border border-slate-700 bg-slate-950 py-1 pr-8 pl-2 text-xs text-slate-100 placeholder:text-slate-500 focus:border-purple-400 focus:outline-none"
              />
            </div>
            <select
              value={rankFilter}
              onChange={(e) => setRankFilter(e.target.value as typeof rankFilter)}
              className="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1 text-xs text-slate-200 focus:border-purple-400 focus:outline-none"
            >
              <option value="all">كل الرتب</option>
              <option value="unlocked">المفتوح للاستحضار</option>
              <option value="common">عادي</option>
              <option value="rare">نادر</option>
              <option value="elite">نخبة</option>
              <option value="legendary">أسطوري</option>
            </select>
          </div>
        </div>

        {/* Entity Grid */}
        <div className="grid flex-1 grid-cols-1 gap-3 overflow-y-auto p-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredList.map((ent) => {
            const rec = bestiary[ent.id];
            const discovered = Boolean(rec?.discovered);
            const summonUnlocked = Boolean(rec?.summonUnlocked);
            const isSummoned = activeSummons.some((s) => s.entityId === ent.id);
            const weakEl = ELEMENTS[ent.weakness];
            const colorHexStr = `#${ent.glowHex.toString(16).padStart(6, '0')}`;
            const rank = ent.rank ?? (ent.category === 'boss' ? 'boss' : 'common');
            const rankInfo = RANK_LABELS[rank];
            const soulPower = ent.soulPower ?? 8;
            const role = ent.summonRole ?? 'dps';
            const cd = summonCooldowns[ent.id] ?? 0;
            const willExceedControl = soulPowerUsed + soulPower > soulControlMax;

            return (
              <div
                key={ent.id}
                className={`flex flex-col justify-between gap-2.5 rounded-xl border p-3 ${
                  isSummoned
                    ? 'border-cyan-400 bg-cyan-950/25'
                    : discovered || ent.category === 'boss'
                      ? 'border-slate-700 bg-slate-950/80'
                      : 'border-slate-800 bg-slate-950/45 opacity-80'
                }`}
              >
                <div className="space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <ArchetypeEmblem
                        archetype={ent.archetype}
                        colorHex={colorHexStr}
                        discovered={discovered || ent.category === 'boss'}
                      />
                      <div>
                        <div className="text-sm font-extrabold text-slate-100">
                          {discovered || ent.category === 'boss' ? ent.nameAr : 'كائن غير مكتشف'}
                        </div>
                        <div className="mt-0.5 flex flex-wrap items-center gap-1">
                          <span className={`rounded border px-1.5 py-0 text-[9px] font-bold ${rankInfo.cls}`}>
                            {rankInfo.label}
                          </span>
                          <span className="rounded border border-slate-700 bg-slate-900 px-1.5 py-0 text-[9px] font-semibold text-slate-300">
                            {ROLE_LABELS[role]}
                          </span>
                        </div>
                      </div>
                    </div>
                    <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">
                      Lv.{ent.level}
                    </span>
                  </div>

                  {discovered ? (
                    <>
                      <p className="text-[11px] leading-relaxed text-slate-400">
                        {ent.descriptionAr}
                      </p>
                      <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-300">
                        <span>HP: {ent.maxHp}</span>
                        <span>•</span>
                        <span>هجوم: {ent.attack}</span>
                        <span>•</span>
                        <span className="flex items-center gap-0.5" style={{ color: weakEl?.colorHex }}>
                          <Flame className="h-3 w-3" />
                          نقطة ضعف: {weakEl?.nameAr}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-[10px] text-cyan-300">
                        <span>قوة الروح: {soulPower}</span>
                        <span>•</span>
                        <span>المدة: {ent.summonDurationSec ?? 45}ث</span>
                        <span>•</span>
                        <span>تهدئة: {ent.summonCooldownSec ?? 16}ث</span>
                      </div>
                      {ent.abilities && ent.abilities.length > 0 && (
                        <div className="text-[10px] text-amber-300/90">
                          القدرات: {ent.abilities.join(' • ')}
                        </div>
                      )}
                      <div className="text-[10px] text-slate-400">
                        الغنائم:{' '}
                        {ent.drops
                          .map((d) => ITEMS[d.itemId]?.nameAr ?? d.itemId)
                          .join('، ')}
                      </div>
                    </>
                  ) : (
                    <p className="text-[11px] text-slate-500">
                      {ent.category === 'boss'
                        ? `زعيم أسطوري: ${ent.descriptionAr}`
                        : 'اقترب من هذا الكائن في العالم المفتوح لتوثيق تفاصيله.'}
                    </p>
                  )}
                </div>

                {/* Summon Action Footer */}
                <div className="flex items-center justify-between gap-2 border-t border-slate-800 pt-2 text-[11px]">
                  <span className="text-slate-400">
                    الهزائم: <strong className="text-slate-200">{rec?.defeatedCount ?? 0}</strong>
                  </span>
                  {isSummoned ? (
                    <span className="flex items-center gap-1 font-bold text-cyan-300">
                      <Sparkles className="h-3.5 w-3.5" />
                      مُستحضر حالياً
                    </span>
                  ) : summonUnlocked ? (
                    <div className="flex items-center gap-1.5">
                      {willExceedControl && (
                        <span
                          className="flex items-center gap-0.5 rounded bg-rose-950/90 px-1.5 py-0.5 text-[9px] font-bold text-rose-300"
                          title="استحضار هذا الكائن سيتجاوز طاقة السيطرة وقد يتمرد عليك!"
                        >
                          <AlertTriangle className="h-2.5 w-2.5" />
                          خطر التمرد
                        </span>
                      )}
                      <button
                        type="button"
                        disabled={playerMana < ent.summonManaCost || cd > 0}
                        onClick={() => onSummon(ent.id)}
                        className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold ${
                          cd > 0 || playerMana < ent.summonManaCost
                            ? 'bg-slate-800 text-slate-500'
                            : willExceedControl
                              ? 'bg-rose-600 text-white hover:bg-rose-500'
                              : 'bg-purple-600 text-white hover:bg-purple-500'
                        }`}
                      >
                        {role === 'tank' ? (
                          <Shield className="h-3 w-3" />
                        ) : role === 'dps' ? (
                          <Swords className="h-3 w-3" />
                        ) : (
                          <Ghost className="h-3 w-3" />
                        )}
                        {cd > 0 ? `${Math.ceil(cd)}ث` : `استحضار (${ent.summonManaCost}MP)`}
                      </button>
                    </div>
                  ) : (
                    <span className="text-[10px] text-slate-500">اهزمه لفتح الاستحضار</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
