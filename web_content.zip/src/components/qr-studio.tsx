import { useEffect, useId, useRef, useState } from "react";
import type { QRCodeErrorCorrectionLevel } from "qrcode";
import { Download } from "lucide-react";

const SIZE_MIN = 128;
const SIZE_MAX = 1024;
const SIZE_STEP = 8;

const LEVELS: { id: QRCodeErrorCorrectionLevel; name: string; detail: string }[] = [
  { id: "L", name: "منخفض", detail: "7%" },
  { id: "M", name: "متوسط", detail: "15%" },
  { id: "Q", name: "عالٍ", detail: "25%" },
  { id: "H", name: "أعلى", detail: "30%" },
];

const PRESETS: { name: string; fg: string; bg: string }[] = [
  { name: "كلاسيكي", fg: "#111111", bg: "#ffffff" },
  { name: "حبر على ورق", fg: "#1c1916", bg: "#f3efe7" },
  { name: "معكوس", fg: "#ffffff", bg: "#1c1916" },
  { name: "طيني", fg: "#8c2f1b", bg: "#fff6ee" },
];

let qrModule: Promise<typeof import("qrcode")> | null = null;

function loadQr() {
  qrModule ??= import("qrcode");
  return qrModule;
}

function parseHex(input: string): string | null {
  const match = /^#?([0-9a-fA-F]{6})$/.exec(input.trim());
  return match ? `#${match[1].toLowerCase()}` : null;
}

function channel(value: number): number {
  const s = value / 255;
  return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
}

function contrastRatio(a: string, b: string): number {
  const lum = (hex: string) => {
    const n = parseInt(hex.slice(1), 16);
    const r = channel((n >> 16) & 255);
    const g = channel((n >> 8) & 255);
    const bl = channel(n & 255);
    return 0.2126 * r + 0.7152 * g + 0.0722 * bl;
  };
  const hi = Math.max(lum(a), lum(b));
  const lo = Math.min(lum(a), lum(b));
  return (hi + 0.05) / (lo + 0.05);
}

function messageFor(err: unknown): string {
  const raw = err instanceof Error ? err.message : "";
  if (/too big|too large|data is too/i.test(raw)) {
    return "النص أطول من سعة رمز QR بهذا المستوى. قصّره أو اختر مستوى تصحيح أقل.";
  }
  return "تعذّر إنشاء الرمز. جرّب نصاً أقصر.";
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (hex: string) => void;
}) {
  const groupId = useId();
  const [draft, setDraft] = useState(value);

  useEffect(() => {
    setDraft(value.toUpperCase());
  }, [value]);

  return (
    <div className="flex flex-col gap-2" role="group" aria-labelledby={groupId}>
      <span id={groupId} className="text-sm font-medium">
        {label}
      </span>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          aria-label={`${label}، منتقي الألوان`}
          onChange={(event) => onChange(event.target.value.toLowerCase())}
          className="size-11 shrink-0 cursor-pointer rounded-lg"
        />
        <input
          type="text"
          dir="ltr"
          inputMode="text"
          spellCheck={false}
          autoComplete="off"
          maxLength={7}
          value={draft}
          aria-label={`${label}، القيمة السداسية`}
          onChange={(event) => {
            const next = event.target.value;
            setDraft(next);
            const parsed = parseHex(next);
            if (parsed) onChange(parsed);
          }}
          onBlur={() => setDraft(value.toUpperCase())}
          className="h-11 min-w-0 flex-1 rounded-lg border border-line bg-surface px-3 font-mono text-sm text-ink"
        />
      </div>
    </div>
  );
}

export function QrStudio() {
  const textId = useId();
  const textHintId = useId();
  const sizeId = useId();
  const sizeHintId = useId();
  const eccHintId = useId();
  const seq = useRef(0);

  const [text, setText] = useState("");
  const [fg, setFg] = useState("#111111");
  const [bg, setBg] = useState("#ffffff");
  const [size, setSize] = useState(320);
  const [ecc, setEcc] = useState<QRCodeErrorCorrectionLevel>("M");
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const trimmed = text.trim();
  const lowContrast = contrastRatio(fg, bg) < 3;
  const showImage = Boolean(dataUrl) && trimmed.length > 0 && !error;
  const canDownload = showImage;

  useEffect(() => {
    const value = text.trim();
    if (!value) {
      setError(null);
      setDataUrl(null);
      return;
    }

    const id = ++seq.current;
    let cancelled = false;

    loadQr()
      .then((qr) => {
        if (cancelled || seq.current !== id) return null;
        const offscreen = document.createElement("canvas");
        return qr
          .toCanvas(offscreen, value, {
            errorCorrectionLevel: ecc,
            margin: 4,
            width: size,
            color: { dark: fg, light: bg },
          })
          .then(() => offscreen);
      })
      .then((offscreen) => {
        if (!offscreen || cancelled || seq.current !== id) return;
        setDataUrl(offscreen.toDataURL("image/png"));
        setError(null);
      })
      .catch((err: unknown) => {
        if (cancelled || seq.current !== id) return;
        setDataUrl(null);
        setError(messageFor(err));
      });

    return () => {
      cancelled = true;
    };
  }, [text, fg, bg, size, ecc]);

  function downloadPng() {
    if (!dataUrl || !canDownload) return;
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = "qr-code.png";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <label htmlFor={textId} className="text-sm font-medium">
          النص أو الرابط
        </label>
        <textarea
          id={textId}
          dir="auto"
          rows={4}
          value={text}
          placeholder="https://example.com أو أي نص"
          aria-describedby={textHintId}
          onChange={(event) => setText(event.target.value)}
          className="min-h-28 w-full resize-y rounded-xl border border-line bg-surface px-3 py-3 text-base text-ink placeholder:text-muted"
        />
        <p id={textHintId} className="text-sm text-muted">
          يتحدث الرمز مع كل حرف.
        </p>
      </div>

      <section aria-labelledby="preview-heading" className="flex flex-col gap-4 rounded-2xl border border-line bg-surface p-4 sm:p-5">
        <h2 id="preview-heading" className="text-sm font-medium">
          المعاينة
        </h2>
        <div
          className={`flex flex-col items-center justify-center overflow-hidden rounded-xl bg-bg p-4 ${
            showImage ? "" : "min-h-48"
          }`}
        >
          {showImage && dataUrl ? (
            <img
              src={dataUrl}
              alt="معاينة رمز QR"
              width={size}
              height={size}
              style={{ width: `min(100%, ${size}px)` }}
              className="h-auto max-w-full"
            />
          ) : !trimmed ? (
            <p className="max-w-xs px-4 text-center text-sm text-muted">
              اكتب نصاً أو رابطاً لتظهر المعاينة هنا فوراً.
            </p>
          ) : error ? (
            <p role="alert" className="max-w-xs px-4 text-center text-sm text-accent">
              {error}
            </p>
          ) : (
            <p className="text-sm text-muted">جارٍ إنشاء الرمز…</p>
          )}
        </div>
        {trimmed && !error && lowContrast && (
          <p className="text-sm text-accent" role="status">
            التباين منخفض وقد يتعذّر مسح الرمز. غمّق أحد اللونين أو افتح الآخر.
          </p>
        )}
        <button
          type="button"
          onClick={downloadPng}
          disabled={!canDownload}
          className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent text-base font-semibold text-on-accent transition-colors duration-150 hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Download className="size-5" aria-hidden="true" />
          تنزيل PNG
        </button>
        <p className="text-sm text-muted">يُحفظ الملف بالمقاس المختار، مع هامش هادئ حول الرمز.</p>
      </section>

      <div className="flex flex-col gap-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <ColorField label="لون الرمز" value={fg} onChange={setFg} />
          <ColorField label="لون الخلفية" value={bg} onChange={setBg} />
        </div>

        <div className="flex flex-col gap-2">
          <span className="text-sm font-medium" id="preset-label">
            ألوان جاهزة
          </span>
          <div className="flex flex-wrap gap-2" role="group" aria-labelledby="preset-label">
            {PRESETS.map((preset) => {
              const active = fg === preset.fg && bg === preset.bg;
              return (
                <button
                  key={preset.name}
                  type="button"
                  aria-pressed={active}
                  aria-label={preset.name}
                  onClick={() => {
                    setFg(preset.fg);
                    setBg(preset.bg);
                  }}
                  className={`size-11 rounded-xl border border-line bg-surface p-1 ${
                    active ? "ring-2 ring-ink ring-offset-2 ring-offset-bg" : ""
                  }`}
                >
                  <span
                    className="block size-full rounded-lg"
                    style={{
                      background: preset.bg,
                      boxShadow: `inset 0 0 0 7px ${preset.fg}`,
                    }}
                  />
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <div className="flex items-baseline justify-between gap-3">
            <label htmlFor={sizeId} className="text-sm font-medium">
              الحجم
            </label>
            <span dir="ltr" className="font-mono text-sm text-muted">
              {size}px
            </span>
          </div>
          <input
            id={sizeId}
            className="qr-range"
            type="range"
            min={SIZE_MIN}
            max={SIZE_MAX}
            step={SIZE_STEP}
            value={size}
            aria-valuemin={SIZE_MIN}
            aria-valuemax={SIZE_MAX}
            aria-valuenow={size}
            aria-valuetext={`${size} بكسل`}
            aria-describedby={sizeHintId}
            onChange={(event) => setSize(Number(event.target.value))}
          />
          <p id={sizeHintId} className="text-sm text-muted">
            مقاس ملف التنزيل من {SIZE_MIN} إلى {SIZE_MAX} بكسل. المعاينة تتقلص لتناسب الشاشة.
          </p>
        </div>

        <fieldset className="flex flex-col gap-2" aria-describedby={eccHintId}>
          <legend className="text-sm font-medium">مستوى تصحيح الأخطاء</legend>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {LEVELS.map((level) => {
              const selected = ecc === level.id;
              return (
                <label
                  key={level.id}
                  className={`flex min-h-11 cursor-pointer flex-col items-center justify-center rounded-xl border px-2 py-2 text-center has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-accent has-[:focus-visible]:ring-offset-2 has-[:focus-visible]:ring-offset-bg ${
                    selected ? "border-ink bg-ink text-surface" : "border-line bg-surface text-ink"
                  }`}
                >
                  <input
                    className="sr-only"
                    type="radio"
                    name="error-correction"
                    value={level.id}
                    checked={selected}
                    onChange={() => setEcc(level.id)}
                  />
                  <span className="text-sm font-semibold">{level.name}</span>
                  <span dir="ltr" className={`font-mono text-xs ${selected ? "text-on-accent" : "text-muted"}`}>
                    {level.id} · {level.detail}
                  </span>
                </label>
              );
            })}
          </div>
          <p id={eccHintId} className="text-sm text-muted">
            مستوى أعلى يقاوم التلف أكثر، والرمز يصبح أكثف.
          </p>
        </fieldset>
      </div>
    </div>
  );
}
