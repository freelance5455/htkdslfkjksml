import { useEffect, useState } from "react";
import { Download, QrCode } from "lucide-react";
import { toDataURL, type QRCodeErrorCorrectionLevel } from "qrcode";

const SIZE_MIN = 128;
const SIZE_MAX = 1024;
const SIZE_STEP = 16;
const EXAMPLE = "https://exemple.fr/atelier";

const PRESETS = [
  { id: "encre", name: "Encre", fg: "#1a1814", bg: "#fffdf8" },
  { id: "nuit", name: "Nuit", fg: "#f4efe6", bg: "#1a1814" },
  { id: "foret", name: "Forêt", fg: "#0f6e56", bg: "#f3f7f4" },
  { id: "corail", name: "Corail", fg: "#9a3412", bg: "#fff6f1" },
] as const;

const LEVELS: { id: QRCodeErrorCorrectionLevel; short: string; detail: string }[] = [
  {
    id: "L",
    short: "7 %",
    detail: "Faible. Environ 7 % du motif peut être masqué. Le code reste le plus compact.",
  },
  {
    id: "M",
    short: "15 %",
    detail: "Moyen. Environ 15 %. Un bon réglage pour un écran ou une page propre.",
  },
  {
    id: "Q",
    short: "25 %",
    detail: "Quartile. Environ 25 %. Utile si le support s’use ou se plie.",
  },
  {
    id: "H",
    short: "30 %",
    detail: "Élevé. Environ 30 %. Le motif est plus dense, le texte possible plus court.",
  },
];

function normalizeHex(raw: string): string | null {
  const trimmed = raw.trim();
  const withHash = trimmed.startsWith("#") ? trimmed : `#${trimmed}`;
  if (!/^#[0-9a-fA-F]{6}$/.test(withHash)) return null;
  return withHash.toLowerCase();
}

function clampSize(value: number): number {
  if (!Number.isFinite(value)) return SIZE_MIN;
  return Math.min(SIZE_MAX, Math.max(SIZE_MIN, Math.round(value)));
}

function channel(hex: string, start: number): number {
  return parseInt(hex.slice(start, start + 2), 16) / 255;
}

function luminance(hex: string): number {
  const lin = [1, 3, 5].map((start) => {
    const s = channel(hex, start);
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2];
}

function contrastRatio(fg: string, bg: string): number {
  const lighter = Math.max(luminance(fg), luminance(bg));
  const darker = Math.min(luminance(fg), luminance(bg));
  return (lighter + 0.05) / (darker + 0.05);
}

function frenchError(err: unknown): string {
  const raw = err instanceof Error ? err.message : "";
  if (/too big|too long|maximum/i.test(raw)) {
    return "Ce texte est trop long pour un QR à ce niveau de correction. Raccourcissez-le, ou choisissez un niveau plus bas.";
  }
  return "Impossible de générer ce code. Vérifiez le texte saisi.";
}

async function downloadPng(dataUrl: string) {
  const response = await fetch(dataUrl);
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "code-qr.png";
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function ColorField({
  id,
  label,
  value,
  draft,
  onDraft,
  onBlur,
  invalid,
}: {
  id: string;
  label: string;
  value: string;
  draft: string;
  onDraft: (next: string) => void;
  onBlur: () => void;
  invalid: boolean;
}) {
  const errorId = `${id}-error`;
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={id} className="text-sm font-medium text-ink">
        {label}
      </label>
      <div className="flex items-center gap-2">
        <input
          id={id}
          className="color-well shrink-0"
          type="color"
          value={value}
          onChange={(event) => onDraft(event.target.value)}
        />
        <input
          id={`${id}-hex`}
          className="h-11 w-full rounded-xl border border-line bg-sheet px-3 text-sm tracking-wide text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent"
          type="text"
          inputMode="text"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
          maxLength={7}
          value={draft}
          aria-label={`${label}, valeur hexadécimale`}
          aria-invalid={invalid || undefined}
          aria-describedby={invalid ? errorId : undefined}
          onChange={(event) => onDraft(event.target.value)}
          onBlur={onBlur}
        />
      </div>
      {invalid ? (
        <p id={errorId} className="text-sm text-warn">
          Indiquez 6 chiffres hexadécimaux, par exemple #1A1814.
        </p>
      ) : null}
    </div>
  );
}

export function QrStudio() {
  const [text, setText] = useState("");
  const [fg, setFg] = useState<string>(PRESETS[0].fg);
  const [bg, setBg] = useState<string>(PRESETS[0].bg);
  const [fgDraft, setFgDraft] = useState<string>(PRESETS[0].fg);
  const [bgDraft, setBgDraft] = useState<string>(PRESETS[0].bg);
  const [fgTouched, setFgTouched] = useState(false);
  const [bgTouched, setBgTouched] = useState(false);
  const [size, setSize] = useState(320);
  const [sizeDraft, setSizeDraft] = useState("320");
  const [ecc, setEcc] = useState<QRCodeErrorCorrectionLevel>("M");
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    const value = text;
    if (!value.trim()) {
      setDataUrl(null);
      setError(null);
      setPending(false);
      return;
    }

    let cancelled = false;
    setPending(true);
    toDataURL(value, {
      errorCorrectionLevel: ecc,
      width: size,
      margin: 2,
      color: { dark: fg, light: bg },
    })
      .then((url) => {
        if (cancelled) return;
        setDataUrl(url);
        setError(null);
        setPending(false);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setDataUrl(null);
        setError(frenchError(err));
        setPending(false);
      });

    return () => {
      cancelled = true;
    };
  }, [text, fg, bg, size, ecc]);

  const ratio = contrastRatio(fg, bg);
  const lowContrast = ratio < 3;
  const level = LEVELS.find((item) => item.id === ecc) ?? LEVELS[1];
  const trimmed = text.trim();

  let status = "En attente d’un texte ou d’une URL.";
  let tone: "muted" | "warn" = "muted";
  if (trimmed && error) {
    status = error;
    tone = "warn";
  } else if (trimmed && !dataUrl) {
    status = "Génération du code…";
  } else if (dataUrl && lowContrast) {
    status = `Aperçu à jour · contraste ${ratio.toFixed(1)}:1 · trop faible, le scan peut échouer.`;
    tone = "warn";
  } else if (dataUrl) {
    status = `Aperçu à jour · contraste ${ratio.toFixed(1)}:1.`;
  }

  function commitFg(raw: string) {
    setFgDraft(raw);
    const next = normalizeHex(raw);
    if (next) {
      setFg(next);
      setFgTouched(false);
    }
  }

  function commitBg(raw: string) {
    setBgDraft(raw);
    const next = normalizeHex(raw);
    if (next) {
      setBg(next);
      setBgTouched(false);
    }
  }

  function blurFg() {
    const next = normalizeHex(fgDraft);
    if (next) {
      setFg(next);
      setFgDraft(next);
      setFgTouched(false);
      return;
    }
    setFgTouched(true);
  }

  function blurBg() {
    const next = normalizeHex(bgDraft);
    if (next) {
      setBg(next);
      setBgDraft(next);
      setBgTouched(false);
      return;
    }
    setBgTouched(true);
  }

  function applyPreset(nextFg: string, nextBg: string) {
    setFg(nextFg);
    setBg(nextBg);
    setFgDraft(nextFg);
    setBgDraft(nextBg);
    setFgTouched(false);
    setBgTouched(false);
  }

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-10">
      <header className="flex flex-col gap-2">
        <div className="flex items-center gap-3">
          <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-ink">
            <QrCode className="size-5" aria-hidden="true" />
          </div>
          <h1 className="font-display text-3xl font-semibold tracking-tight text-ink">Studio QR</h1>
        </div>
        <p className="max-w-xl text-sm leading-normal text-muted">
          Le code se redessine pendant la saisie. Téléchargez-le ensuite en PNG.
        </p>
      </header>

      <form
        className="qr-layout grid items-start gap-6"
        onSubmit={(event) => {
          event.preventDefault();
          if (dataUrl) void downloadPng(dataUrl);
        }}
      >
        <div className="qr-area-payload flex flex-col gap-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <label htmlFor="payload" className="text-sm font-medium text-ink">
              URL ou texte
            </label>
            <button
              type="button"
              className="min-h-11 rounded-xl px-3 text-sm font-medium text-accent outline-none focus-visible:ring-2 focus-visible:ring-accent"
              onClick={() => setText(EXAMPLE)}
            >
              Essayer un exemple
            </button>
          </div>
          <textarea
            id="payload"
            className="min-h-24 w-full resize-y rounded-2xl border border-line bg-sheet px-3 py-3 text-base leading-normal text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent"
            value={text}
            placeholder="https://exemple.fr ou un message"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
            aria-invalid={error ? true : undefined}
            aria-describedby="payload-hint qr-status"
            onChange={(event) => setText(event.target.value)}
          />
          <p id="payload-hint" className="text-sm text-muted">
            <span className="tabular-nums">{text.length}</span> caractères. Liens et texte libre sont
            acceptés.
          </p>
        </div>

        <section
          aria-labelledby="preview-heading"
          className="qr-area-preview flex flex-col gap-4 rounded-3xl border border-line bg-sheet p-4 shadow-card"
        >
          <div className="flex items-baseline justify-between gap-3">
            <h2 id="preview-heading" className="text-sm font-medium text-ink">
              Aperçu
            </h2>
            <p className="text-sm tabular-nums text-muted">{size} × {size} px</p>
          </div>
          <div className="overflow-hidden rounded-2xl border border-line bg-paper p-4">
            {dataUrl ? (
              <img
                src={dataUrl}
                alt={`Code QR pour ${trimmed.slice(0, 120)}`}
                width={size}
                height={size}
                className={`qr-preview mx-auto aspect-square w-full max-w-72 sm:max-w-80 lg:max-w-none ${pending ? "opacity-70" : ""}`}
              />
            ) : (
              <div className="flex h-36 w-full flex-col items-center justify-center gap-2 text-center">
                <QrCode className="size-8 text-muted" aria-hidden="true" />
                <p className="max-w-xs text-sm text-muted">
                  Le code apparaît ici dès le premier caractère.
                </p>
              </div>
            )}
          </div>
          <p
            id="qr-status"
            role="status"
            className={`text-sm leading-normal ${tone === "warn" ? "text-warn" : "text-muted"}`}
          >
            {status}
          </p>
          <button
            type="submit"
            disabled={!dataUrl}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent text-base font-medium text-accent-ink outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-sheet disabled:opacity-40"
          >
            <Download className="size-5" aria-hidden="true" />
            Télécharger le PNG
          </button>
        </section>

        <section aria-labelledby="settings-heading" className="qr-area-settings flex flex-col gap-6">
          <h2 id="settings-heading" className="text-sm font-medium text-ink">
            Réglages
          </h2>

          <div className="flex flex-col gap-2">
            <p id="preset-label" className="text-sm font-medium text-ink">
              Couleurs prédéfinies
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4" role="group" aria-labelledby="preset-label">
              {PRESETS.map((preset) => {
                const active = fg === preset.fg && bg === preset.bg;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    aria-pressed={active}
                    className={`flex min-h-11 items-center justify-center gap-2 rounded-xl border px-2 text-sm font-medium outline-none focus-visible:ring-2 focus-visible:ring-accent ${
                      active
                        ? "border-accent bg-accent text-accent-ink"
                        : "border-line bg-sheet text-ink"
                    }`}
                    onClick={() => applyPreset(preset.fg, preset.bg)}
                  >
                    <span className="flex overflow-hidden rounded-md" aria-hidden="true">
                      <span className="size-4" style={{ backgroundColor: preset.fg }} />
                      <span className="size-4" style={{ backgroundColor: preset.bg }} />
                    </span>
                    {preset.name}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <ColorField
              id="fg"
              label="Couleur du premier plan"
              value={fg}
              draft={fgDraft}
              invalid={fgTouched && normalizeHex(fgDraft) === null}
              onDraft={commitFg}
              onBlur={blurFg}
            />
            <ColorField
              id="bg"
              label="Couleur de l’arrière-plan"
              value={bg}
              draft={bgDraft}
              invalid={bgTouched && normalizeHex(bgDraft) === null}
              onDraft={commitBg}
              onBlur={blurBg}
            />
          </div>
          <p className="text-sm text-muted">
            Premier plan : les modules du code. Arrière-plan : le fond autour.
          </p>

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between gap-3">
              <label htmlFor="size" className="text-sm font-medium text-ink">
                Taille
              </label>
              <output htmlFor="size" className="text-sm tabular-nums text-muted">
                {size} px
              </output>
            </div>
            <div className="flex items-center gap-3">
              <input
                id="size"
                className="size-range"
                type="range"
                min={SIZE_MIN}
                max={SIZE_MAX}
                step={SIZE_STEP}
                value={size}
                aria-valuetext={`${size} pixels`}
                aria-describedby="size-hint"
                onChange={(event) => {
                  const next = clampSize(Number(event.target.value));
                  setSize(next);
                  setSizeDraft(String(next));
                }}
              />
              <input
                id="size-px"
                className="h-11 w-24 shrink-0 rounded-xl border border-line bg-sheet px-3 text-sm tabular-nums text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent"
                type="number"
                inputMode="numeric"
                min={SIZE_MIN}
                max={SIZE_MAX}
                value={sizeDraft}
                aria-label="Taille en pixels"
                onChange={(event) => {
                  const raw = event.target.value;
                  setSizeDraft(raw);
                  if (!/^\d+$/.test(raw)) return;
                  const next = Number(raw);
                  if (next >= SIZE_MIN && next <= SIZE_MAX) setSize(next);
                }}
                onBlur={() => {
                  if (!/^\d+$/.test(sizeDraft)) {
                    setSizeDraft(String(size));
                    return;
                  }
                  const next = clampSize(Number(sizeDraft));
                  setSize(next);
                  setSizeDraft(String(next));
                }}
              />
            </div>
            <p id="size-hint" className="text-sm text-muted">
              Le fichier PNG mesure {size} pixels de côté, entre {SIZE_MIN} et {SIZE_MAX}.
            </p>
          </div>

          <fieldset className="flex flex-col gap-3">
            <legend className="text-sm font-medium text-ink">Niveau de correction d’erreurs</legend>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {LEVELS.map((item) => {
                const selected = ecc === item.id;
                return (
                  <label
                    key={item.id}
                    className={`flex min-h-11 cursor-pointer flex-col items-center justify-center rounded-xl border px-2 py-2 text-center outline-none focus-within:ring-2 focus-within:ring-accent focus-within:ring-offset-2 focus-within:ring-offset-paper ${
                      selected
                        ? "border-accent bg-accent text-accent-ink"
                        : "border-line bg-sheet text-ink"
                    }`}
                  >
                    <input
                      className="sr-only"
                      type="radio"
                      name="ecc"
                      value={item.id}
                      checked={selected}
                      onChange={() => setEcc(item.id)}
                    />
                    <span className="text-sm font-semibold">{item.id}</span>
                    <span className={`text-xs ${selected ? "text-accent-ink" : "text-muted"}`}>
                      {item.short}
                    </span>
                  </label>
                );
              })}
            </div>
            <p className="text-sm text-muted">{level.detail}</p>
          </fieldset>
        </section>
      </form>
    </main>
  );
}
