import React, { useState } from 'react';
import { User, Calendar, Lock, School, GraduationCap, Hash, Check, X, Sparkles } from 'lucide-react';
import { StudentProfile } from '../types';

interface ProfileSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: StudentProfile;
  onSaveProfile: (profile: StudentProfile) => void;
  isFirstSetup?: boolean;
}

const AVATAR_OPTIONS = [
  'https://api.dicebear.com/7.x/bottts/svg?seed=RafiPratama&backgroundColor=b6e3f4',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Annisa&backgroundColor=ffd5dc',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Dimas&backgroundColor=d1d4f9',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Clarissa&backgroundColor=c0aede',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Bima&backgroundColor=ffdfbf',
  'https://api.dicebear.com/7.x/bottts/svg?seed=Fikri&backgroundColor=b6e3f4',
];

export const ProfileSetupModal: React.FC<ProfileSetupModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onSaveProfile,
  isFirstSetup = false,
}) => {
  const [name, setName] = useState(currentProfile.name);
  const [age, setAge] = useState<number | string>(currentProfile.age || 16);
  const [pin, setPin] = useState(currentProfile.pin || '123456');
  const [confirmPin, setConfirmPin] = useState(currentProfile.pin || '123456');
  const [school, setSchool] = useState(currentProfile.school || 'SMA Negeri 1 Nusantara');
  const [grade, setGrade] = useState(currentProfile.grade || 'XI MIPA 2');
  const [nisn, setNisn] = useState(currentProfile.nisn || '0087419283');
  const [avatar, setAvatar] = useState(currentProfile.avatar || AVATAR_OPTIONS[0]);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setErrorMessage('Nama lengkap siswa wajib diisi');
      return;
    }

    const numAge = Number(age);
    if (!numAge || numAge < 6 || numAge > 25) {
      setErrorMessage('Umur harus antara 6 - 25 tahun');
      return;
    }

    if (!/^\d{6}$/.test(pin)) {
      setErrorMessage('PIN keamanan harus terdiri dari tepat 6 angka');
      return;
    }

    if (pin !== confirmPin) {
      setErrorMessage('Konfirmasi PIN tidak cocok dengan PIN baru');
      return;
    }

    onSaveProfile({
      name: name.trim(),
      age: numAge,
      pin,
      school: school.trim() || 'Sekolah Siswa',
      grade: grade.trim() || 'Kelas 11',
      nisn: nisn.trim() || '0087419283',
      avatar,
      isProfileSetup: true,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-emerald-600 to-teal-700 px-6 pt-6 pb-5 text-white">
          {!isFirstSetup && (
            <button
              onClick={onClose}
              className="absolute top-5 right-5 p-1 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              aria-label="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-2 text-emerald-200 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>Identitas Siswa Digital</span>
          </div>
          <h2 className="text-xl font-bold mt-1">
            {isFirstSetup ? 'Lengkapi Data Diri Siswa' : 'Pengaturan Profil & PIN Siswa'}
          </h2>
          <p className="text-xs text-emerald-100 mt-1">
            Masukkan data nama, umur, dan 6-digit PIN untuk keamanan dompet & tabungan sekolah.
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-medium text-rose-700 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Avatar Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">Pilih Avatar Siswa</label>
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {AVATAR_OPTIONS.map((item, index) => (
                <button
                  type="button"
                  key={index}
                  onClick={() => setAvatar(item)}
                  className={`relative p-1 rounded-2xl transition-all shrink-0 ${
                    avatar === item
                      ? 'ring-2 ring-emerald-500 scale-105 bg-emerald-50'
                      : 'hover:scale-102 bg-slate-100 opacity-80 hover:opacity-100'
                  }`}
                >
                  <img src={item} alt={`Avatar ${index + 1}`} className="w-12 h-12 rounded-xl object-cover" />
                  {avatar === item && (
                    <div className="absolute -top-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5 shadow-sm">
                      <Check className="w-3 h-3" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Nama Lengkap Siswa */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nama Lengkap Siswa <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setErrorMessage('');
                }}
                placeholder="Contoh: Rafi Pratama"
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          {/* Umur & Kelas (Grid) */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Umur (Tahun) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Calendar className="w-4 h-4" />
                </div>
                <input
                  type="number"
                  min="6"
                  max="25"
                  required
                  value={age}
                  onChange={(e) => {
                    setAge(e.target.value);
                    setErrorMessage('');
                  }}
                  placeholder="Contoh: 16"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Kelas / Jurusan</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  placeholder="Contoh: XI MIPA 2"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Sekolah & NISN */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Sekolah</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <School className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={school}
                  onChange={(e) => setSchool(e.target.value)}
                  placeholder="Contoh: SMA Negeri 1 Nusantara"
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">NISN (Nomor Induk Siswa)</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Hash className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={nisn}
                  onChange={(e) => setNisn(e.target.value)}
                  placeholder="10 digit NISN"
                  maxLength={10}
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
                />
              </div>
            </div>
          </div>

          {/* PIN Keamanan 6 Digit */}
          <div className="p-4 bg-emerald-50/60 border border-emerald-200/80 rounded-2xl space-y-3">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-700" />
              <span className="text-xs font-bold text-emerald-900">Keamanan PIN Transaksi (6 Angka)</span>
            </div>
            <p className="text-[11px] text-emerald-800 leading-relaxed">
              PIN ini wajib dimasukkan setiap kali melakukan Top Up, bayar QRIS di kantin, atau transfer tabungan.
            </p>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Buat PIN Baru (6 Angka) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="password"
                  maxLength={6}
                  required
                  value={pin}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    setPin(val);
                    setErrorMessage('');
                  }}
                  placeholder="123456"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-center text-sm font-mono tracking-widest font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Ulangi PIN <span className="text-rose-500">*</span>
                </label>
                <input
                  type="password"
                  maxLength={6}
                  required
                  value={confirmPin}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    setConfirmPin(val);
                    setErrorMessage('');
                  }}
                  placeholder="123456"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-center text-sm font-mono tracking-widest font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-3">
            {!isFirstSetup && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Batal
              </button>
            )}
            <button
              type="submit"
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{isFirstSetup ? 'Mulai Gunakan Dompet' : 'Simpan Data Siswa'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
