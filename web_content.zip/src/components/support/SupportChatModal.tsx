import React, { useState } from 'react';
import { 
  X, 
  MessageSquare, 
  Send, 
  HelpCircle, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Upload, 
  Image as ImageIcon,
  Sparkles,
  ChevronRight,
  User,
  Headphones
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SupportMessage } from '../../types';

interface SupportChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupportChatModal: React.FC<SupportChatModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, supportMessages, sendSupportMessage, language } = useApp();

  const [activeTab, setActiveTab] = useState<'create' | 'history'>('create');
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<SupportMessage['category']>('task_proof');
  const [message, setMessage] = useState('');
  const [screenshotUrl, setScreenshotUrl] = useState<string | undefined>(undefined);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const userTickets = currentUser 
    ? supportMessages.filter(m => m.userId === currentUser.id)
    : [];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshotUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      alert('Please sign in to contact support.');
      return;
    }
    if (!subject.trim() || !message.trim()) {
      alert('Please fill in both subject and description.');
      return;
    }

    setIsSubmitting(true);
    const res = sendSupportMessage(subject.trim(), category, message.trim(), screenshotUrl);
    setIsSubmitting(false);

    if (res.success) {
      setSuccessMsg(language === 'bn' ? 'আপনার সহায়তা বার্তা সফলভাবে পাঠানো হয়েছে! সাপোর্ট টিম শীঘ্রই উত্তর দেবে।' : 'Your support ticket was submitted successfully! Support team will reply shortly.');
      setSubject('');
      setMessage('');
      setScreenshotUrl(undefined);
      setTimeout(() => {
        setSuccessMsg(null);
        setActiveTab('history');
      }, 1500);
    } else {
      alert(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-base">
                {language === 'bn' ? '২৪/৭ লাইভ সাপোর্ট ও হেল্পডেস্ক' : '24/7 Support & Helpdesk'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'bn' ? 'যেকোনো সমস্যায় সাপোর্ট টিমের সাথে যোগাযোগ করুন' : 'Contact Support Team for any problem or issue'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 p-1.5 gap-2">
          <button
            onClick={() => setActiveTab('create')}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'create'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>{language === 'bn' ? 'নতুন সমস্যা রিপোর্ট করুন' : 'New Ticket / Problem'}</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'history'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>{language === 'bn' ? `আমার টিকেট (${userTickets.length})` : `My Tickets (${userTickets.length})`}</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {successMsg && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-2 animate-bounce">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {activeTab === 'create' ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Category */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'সমস্যার ধরণ (Category)' : 'Problem Category *'}
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-500 font-medium"
                >
                  <option value="task_proof">Task Proof / Submission Rejected Problem</option>
                  <option value="withdrawal">Withdrawal / UPI Payment Problem</option>
                  <option value="kyc_gold">Aadhaar KYC / Gold Buy Payment Issue</option>
                  <option value="vip_upgrade">VIP Membership & Coin Upgrade Problem</option>
                  <option value="other">Other Issue / General Inquiry</option>
                </select>
              </div>

              {/* Subject */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'বিষয় (Subject)' : 'Subject / Title *'}
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g., Task screenshot verification rejected incorrectly"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-500 font-medium"
                />
              </div>

              {/* Message */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'বিস্তারিত সমস্যা লিখুন (Description)' : 'Describe Your Problem in Detail *'}
                </label>
                <textarea
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please describe what problem you are facing. Support team will review and reply within 2 hours."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-500 font-medium resize-none"
                />
              </div>

              {/* Screenshot Upload */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300">
                  {language === 'bn' ? 'স্ক্রিনশট বা প্রমাণ যুক্ত করুন (Optional)' : 'Attach Screenshot or Proof (Optional)'}
                </label>
                <div className="flex items-center gap-3">
                  <label className="flex-1 flex items-center justify-center gap-2 p-3 rounded-xl bg-slate-950 border border-dashed border-slate-700 hover:border-emerald-500 cursor-pointer text-slate-400 hover:text-white transition-colors text-xs font-bold">
                    <Upload className="w-4 h-4 text-emerald-400" />
                    <span>{screenshotUrl ? 'Change Screenshot' : 'Upload Screenshot'}</span>
                    <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                  </label>
                  {screenshotUrl && (
                    <div className="w-12 h-12 rounded-xl overflow-hidden border border-emerald-500/50 shrink-0 relative">
                      <img src={screenshotUrl} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-500/25 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{isSubmitting ? 'Sending...' : 'Submit Ticket to Support Team'}</span>
              </button>

            </form>
          ) : (
            <div className="space-y-3">
              {userTickets.length === 0 ? (
                <div className="text-center py-12 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto text-slate-500">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <p className="text-xs text-slate-400 font-medium">
                    {language === 'bn' ? 'কোনো সাপোর্ট টিকেট নেই।' : 'No support tickets found.'}
                  </p>
                  <button
                    onClick={() => setActiveTab('create')}
                    className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold cursor-pointer"
                  >
                    Create Ticket
                  </button>
                </div>
              ) : (
                userTickets.map((ticket) => (
                  <div 
                    key={ticket.id} 
                    className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 shadow-md"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-900 text-slate-300 border border-slate-800">
                        ID: {ticket.id}
                      </span>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                        ticket.status === 'resolved'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : ticket.status === 'in_progress'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                      }`}>
                        {ticket.status === 'resolved' ? 'Resolved' : ticket.status === 'in_progress' ? 'In Progress' : 'Open Ticket'}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-white text-sm">
                        {ticket.subject}
                      </h4>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        {ticket.message}
                      </p>
                    </div>

                    {ticket.screenshotUrl && (
                      <div className="w-20 h-20 rounded-xl overflow-hidden border border-slate-800">
                        <img src={ticket.screenshotUrl} alt="Proof" className="w-full h-full object-cover" />
                      </div>
                    )}

                    {/* Admin Reply Box */}
                    {ticket.adminReply ? (
                      <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 space-y-1">
                        <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-[11px]">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Support Team Official Reply:</span>
                        </div>
                        <p className="text-xs text-slate-200">
                          {ticket.adminReply}
                        </p>
                      </div>
                    ) : (
                      <div className="text-[11px] text-amber-400 font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>Awaiting Support Team response (usually within 2 hours)...</span>
                      </div>
                    )}

                    <div className="text-[10px] text-slate-500 text-right">
                      {new Date(ticket.createdAt).toLocaleString()}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
