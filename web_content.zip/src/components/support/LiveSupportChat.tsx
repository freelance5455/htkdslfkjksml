import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  X, 
  Send, 
  Headphones, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  PhoneCall, 
  ExternalLink,
  ChevronDown,
  Minimize2,
  Paperclip,
  Smile
} from 'lucide-react';
import { Language, Store } from '../../types';

interface ChatMessage {
  id: string;
  sender: 'user' | 'support' | 'system';
  text: string;
  time: string;
  agentName?: string;
  agentAvatar?: string;
}

interface LiveSupportChatProps {
  activeStore: Store;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onToggle: () => void;
}

export const LiveSupportChat: React.FC<LiveSupportChatProps> = ({
  activeStore,
  language,
  isOpen,
  onClose,
  onToggle,
}) => {
  const isBn = language === 'bn';

  // Check if current time is within support hours (9:00 AM - 11:00 PM)
  const [isOnline, setIsOnline] = useState<boolean>(true);
  useEffect(() => {
    const checkSupportHours = () => {
      const now = new Date();
      const currentHour = now.getHours();
      // 9 AM (9) to 11 PM (23)
      setIsOnline(currentHour >= 9 && currentHour < 23);
    };
    checkSupportHours();
    const interval = setInterval(checkSupportHours, 60000);
    return () => clearInterval(interval);
  }, []);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'support',
      agentName: 'সুমন আহমেদ (Merchant Success Lead)',
      agentAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
      text: isBn 
        ? `আসসালামু আলাইকুম! Shanju কাস্টমার সাপোর্টে স্বাগতম। সকাল ৯:০০ টা থেকে রাত ১১:০০ টা পর্যন্ত আমরা আপনার সেবায় সরাসরি নিয়োজিত। আপনার ${activeStore.name} স্টোর সেটআপ, প্রোডাক্ট বা প্ল্যান সংক্রান্ত যেকোনো বিষয়ে আমাদের সরাসরি চ্যাটে জানান!`
        : `Hello! Welcome to Shanju Customer Support. Our team is live and available daily from 9:00 AM to 11:00 PM. How can we help you scale your store ${activeStore.name} today?`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      setUnreadCount(0);
      scrollToBottom();
    }
  }, [isOpen, messages]);

  const quickPrompts = isBn ? [
    '💳 প্ল্যান আপগ্রেড করতে চাই',
    '🚚 পাঠাও ও স্টিডফাস্ট কুরিয়ার সেটআপ',
    '💰 বিকাশ ও নগদ পেমেন্ট গেটওয়ে',
    '🌐 কাস্টম ডোমেন কানেক্ট করার উপায়',
    '📦 প্রোডাক্ট ও ভিডিও রিল আপলোড সাপোর্ট',
  ] : [
    '💳 How to upgrade subscription plan',
    '🚚 Courier (Pathao/Steadfast) setup',
    '💰 bKash & Nagad gateway integration',
    '🌐 Connect custom domain',
    '📦 Help with video reel & product upload',
  ];

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');

    // Simulate real intelligent merchant support response
    setIsTyping(true);
    setTimeout(() => {
      let replyText = '';
      const lower = text.toLowerCase();

      if (lower.includes('plan') || lower.includes('আপগ্রেড') || lower.includes('প্ল্যান') || lower.includes('500') || lower.includes('999') || lower.includes('free')) {
        replyText = isBn
          ? `ধন্যবাদ! আমাদের বর্তমানে ৩টি সেরা প্ল্যান রয়েছে:\n1️⃣ **১ মাস ফ্রি ট্রায়াল** (৫০টি পণ্য, ফ্রি সাবডোমেন)\n2️⃣ **গ্রোথ প্ল্যান (৳৫০০/মাস)**: ২০০টি পণ্য, ফ্রি সাবডোমেন এবং সকাল ৯টা থেকে রাত ১১টা ডেডিকেটেড সাপোর্ট\n3️⃣ **প্রো এন্টারপ্রাইজ (৳৯৯৯/মাস)**: আনলিমিটেড পণ্য, কাস্টম ডোমেন ও ২৪/৭ ভিআইপি সাপোর্ট।\n\nআপনি 'Plans & Billing' ট্যাব থেকে সরাসরি ওয়ান-ক্লিকে যেকোনো প্ল্যানে স্যুইচ করতে পারেন!`
          : `Thanks for asking! We have 3 plans:\n1️⃣ **1 Month Free Trial** (50 products)\n2️⃣ **Growth (৳500/mo)**: 200 products, free subdomain, 9AM-11PM live support\n3️⃣ **Pro Enterprise (৳999/mo)**: Unlimited products, custom domain & 24/7 VIP support.\n\nYou can switch tiers anytime in the 'Plans & Billing' tab!`;
      } else if (lower.includes('কুরিয়ার') || lower.includes('courier') || lower.includes('pathao') || lower.includes('steadfast')) {
        replyText = isBn
          ? `পাঠাও ও স্টিডফাস্ট কুরিয়ারের সাথে আমাদের ওয়ান-ক্লিক এপিআই ইন্টিগ্রেশন চালু রয়েছে। প্রো এন্টারপ্রাইজ প্ল্যানে যেকোনো অর্ডারের পাশে 'Book Courier' চাপলেই স্বয়ংক্রিয়ভাবে ট্র্যাকিং কোড ও ডেলিভারি কনফার্মেশন স্লিপ তৈরি হয়ে যাবে।`
          : `We support 1-click Courier API for Steadfast, Pathao & RedX. Instant tracking numbers and air waybills are automatically generated upon order fulfillment.`;
      } else if (lower.includes('বিকাশ') || lower.includes('bkash') || lower.includes('nagad') || lower.includes('পেমেন্ট') || lower.includes('payment')) {
        replyText = isBn
          ? `আপনার স্টোরে বিকাশ ও নগদ পেমেন্ট রিসিভ করতে পারবেন। মার্চেন্ট বিকাশ একাউন্ট বা পার্সোনাল সেন্ড-মানি ট্রানজেকশন আইডি দিয়ে ক্রেতারা সহজেই অর্ডার কনফার্ম করতে পারবেন।`
          : `bKash and Nagad payment options are fully integrated. Customers can pay via automated merchant gateway or manual send-money TrxID verification.`;
      } else if (lower.includes('ডোমেন') || lower.includes('domain')) {
        replyText = isBn
          ? `গ্রোথ প্ল্যানে আপনি ফ্রি সাবডোমেন (yourstore.shanju.cloud) পাবেন। আর প্রো এন্টারপ্রাইজ প্ল্যানে আপনার নিজস্ব কেনা ডোমেন (যেমন yourbrand.com বা .com.bd) খুব সহজেই আমাদের ক্লাউড ডিএনএসে কানেক্ট করতে পারবেন!`
          : `Growth plan includes a free .shanju.cloud subdomain. Pro Enterprise allows mapping your own custom domain (e.g. yourbrand.com) seamlessly.`;
      } else {
        replyText = isBn
          ? `ধন্যবাদ আপনার মেসেজের জন্য! আমাদের কাস্টমার সাকসেস টিম এটি নোট করেছে। আপনি চাইলে সরাসরি জরুরি প্রয়োজনে আমাদের হটলাইনেও (+880 1700-000000) যোগাযোগ করতে পারেন। আমরা সকাল ৯:০০ টা থেকে রাত ১১:০০ টা পর্যন্ত আপনার সার্বক্ষণিক সহযোগিতায় প্রস্তুত আছি।`
          : `Thank you for reaching out! Our merchant support lead is reviewing your message. For immediate assistance during 9:00 AM - 11:00 PM, you can also connect via WhatsApp or Hotline.`;
      }

      const supportMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'support',
        agentName: 'সুমন আহমেদ (Merchant Success Lead)',
        agentAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
        text: replyText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, supportMsg]);
      setIsTyping(false);

      if (!isOpen) {
        setUnreadCount((c) => c + 1);
      }
    }, 900);
  };

  return (
    <>
      {/* Floating Chat Trigger Launcher Button (Bottom-Right) */}
      <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2 print:hidden">
        {!isOpen && (
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 text-white text-xs font-semibold shadow-lg backdrop-blur-xs border border-slate-700/80 animate-fade-in">
            <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span>
              {isOnline 
                ? (isBn ? 'সাপোর্ট চ্যাট: সকাল ৯:০০ - রাত ১১:০০' : 'Support Live: 9AM - 11PM')
                : (isBn ? 'সাপোর্ট সময়: সকাল ৯:০০ - রাত ১১:০০' : 'Support: 9AM - 11PM')}
            </span>
          </div>
        )}

        <button
          type="button"
          id="live-support-chat-launcher"
          onClick={onToggle}
          className="relative group p-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-xl shadow-emerald-700/30 transition-all hover:scale-105 active:scale-95 flex items-center justify-center"
          title={isBn ? 'কাস্টমার সাপোর্ট চ্যাট চালু করুন' : 'Open Customer Support Chat'}
        >
          {isOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <>
              <MessageSquare className="w-6 h-6" />
              {/* Online Dot */}
              <span className={`absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-white ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              {unreadCount > 0 && (
                <span className="absolute -top-2 -left-2 px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black shadow-md">
                  {unreadCount}
                </span>
              )}
            </>
          )}
        </button>
      </div>

      {/* Floating Chat Box Window */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 sm:right-6 z-50 w-[calc(100vw-2rem)] sm:w-[400px] h-[540px] max-h-[82vh] bg-white rounded-3xl shadow-2xl border border-slate-200/90 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 p-4 text-white flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-inner">
                  <Headphones className="w-5 h-5" />
                </div>
                <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-950 ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-white">
                    {isBn ? 'Shanju কাস্টমার সাপোর্ট' : 'Shanju Support'}
                  </h3>
                  <span className="px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold text-[10px] border border-emerald-500/30">
                    Live
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-300 mt-0.5">
                  <Clock className="w-3 h-3 text-emerald-400" />
                  <span>
                    {isBn 
                      ? 'সকাল ৯:০০ টা থেকে রাত ১১:০০ টা পর্যন্ত' 
                      : 'Active Daily 9:00 AM - 11:00 PM'}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
          </div>

          {/* Operational Status Pill */}
          <div className={`px-4 py-2 text-xs flex items-center justify-between border-b ${
            isOnline 
              ? 'bg-emerald-50 text-emerald-900 border-emerald-100' 
              : 'bg-amber-50 text-amber-900 border-amber-100'
          }`}>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-amber-500'}`} />
              <span className="font-semibold text-[11px]">
                {isOnline 
                  ? (isBn ? '🟢 সাপোর্ট টিম অনলাইন আছে' : '🟢 Support Team Online')
                  : (isBn ? '🌙 অফিস সময় ৯:০০ AM - ১১:০০ PM (মেসেজ দিয়ে রাখুন)' : '🌙 Hours: 9 AM - 11 PM (Leave a message)')}
              </span>
            </div>

            <a
              href="https://wa.me/8801700000000"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 hover:text-emerald-800 underline underline-offset-2"
            >
              <span>WhatsApp</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  {!isUser && msg.agentName && (
                    <div className="flex items-center gap-1.5 mb-1 px-1">
                      {msg.agentAvatar ? (
                        <img 
                          src={msg.agentAvatar} 
                          alt="Agent" 
                          className="w-4 h-4 rounded-full object-cover" 
                        />
                      ) : (
                        <Headphones className="w-3.5 h-3.5 text-emerald-600" />
                      )}
                      <span className="text-[11px] font-semibold text-slate-500">
                        {msg.agentName}
                      </span>
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed shadow-xs whitespace-pre-line ${
                      isUser
                        ? 'bg-emerald-600 text-white rounded-br-xs'
                        : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                    }`}
                  >
                    {msg.text}
                  </div>

                  <span className="text-[10px] text-slate-400 mt-1 px-1">
                    {msg.time}
                  </span>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white border border-slate-200/80 w-fit text-xs text-slate-500">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="text-[11px] ml-1">{isBn ? 'সাপোর্ট টিম টাইপ করছে...' : 'Support typing...'}</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick FAQ / Action Prompts */}
          <div className="px-3 py-2 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {quickPrompts.map((prompt, i) => (
              <button
                key={i}
                type="button"
                onClick={() => handleSendMessage(prompt)}
                className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-600 text-[11px] font-medium whitespace-nowrap transition-colors border border-slate-200/70"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Message Input Box */}
          <div className="p-3 bg-white border-t border-slate-200">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={isBn ? 'আপনার প্রশ্ন বা সমস্যার কথা লিখুন...' : 'Type your query here...'}
                className="flex-1 py-2 px-3.5 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs text-slate-900 bg-slate-50 focus:bg-white transition-all outline-hidden"
              />

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed text-white shadow-xs transition-colors flex items-center justify-center shrink-0"
                title={isBn ? 'পাঠান' : 'Send'}
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
              <span>{isBn ? 'সকাল ৯:০০ - রাত ১১:০০ লাইভ রেসপন্স' : 'Live support: 9:00 AM - 11:00 PM'}</span>
              <span className="flex items-center gap-1 text-emerald-600 font-semibold">
                <CheckCircle2 className="w-3 h-3" />
                <span>Shanju Verified Support</span>
              </span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
