import React, { useState } from 'react';
import {
  ArrowLeft,
  Headphones,
  Mail,
  Phone,
  HelpCircle,
  ChevronDown,
  MessageSquare,
  Send,
  CheckCircle2,
} from 'lucide-react';
import { Order } from '../../types';

interface SupportScreenProps {
  onBack: () => void;
  orders?: Order[];
}

const FAQS = [
  {
    q: 'How does Cash on Delivery (COD) work on OMAZIFY?',
    a: 'COD is 100% available across all eligible pin codes in India. You pay cash or UPI directly to the courier delivery executive upon physical receipt of your package. There are no advance charges.',
  },
  {
    q: 'What is the estimated delivery time for my order?',
    a: 'Most orders are processed within 24 hours and delivered within 2 to 5 business days, depending on your delivery address and destination hub.',
  },
  {
    q: 'How do I initiate a return or exchange?',
    a: 'OMAZIFY offers a hassle-free 7-day return and exchange policy from the date of delivery. Items must be unworn with original tags and packaging intact.',
  },
  {
    q: 'Are all products sold on OMAZIFY genuine?',
    a: 'Yes, 100% of products are sourced directly from verified manufacturers, certified brands, and authenticated suppliers with standard warranty protection.',
  },
  {
    q: 'Can I cancel my order after placing it?',
    a: 'You can cancel any order free of charge from your "Orders" tab as long as the status is Confirmed or Processing. Once dispatched, you may refuse delivery with the courier.',
  },
];

export const SupportScreen: React.FC<SupportScreenProps> = ({ onBack, orders = [] }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [category, setCategory] = useState('Delivery & Shipping');
  const [orderId, setOrderId] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [ticketId, setTicketId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    const newTicket = 'OMAZ-' + Math.floor(100000 + Math.random() * 900000);
    setTicketId(newTicket);
    setIsSubmitted(true);
    setMessage('');
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#EAEAEA] px-4 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] flex items-center justify-center text-[#111111] transition-colors cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-base sm:text-lg font-black text-[#111111]">
            Help & Customer Support
          </h1>
        </div>
      </div>

      <div className="max-w-2xl mx-auto w-full px-4 py-4 space-y-4">
        <div className="bg-[#000000] rounded-3xl p-5 text-white shadow-md border border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-900 border border-neutral-700 flex items-center justify-center flex-shrink-0 text-[#FFD400]">
              <Headphones className="w-6 h-6 text-[#FFD400]" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white">We're Here to Help You</h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Reach our customer care team 7 days a week, 9:00 AM - 9:00 PM IST.
              </p>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-neutral-800 grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-[#FFD400]" />
              <span>1800-420-OMAZ (Toll-Free)</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-[#FFD400]" />
              <span>support@omazify.com</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-[#EAEAEA] p-4 sm:p-5 shadow-2xs space-y-3">
          <div className="flex items-center gap-2 pb-1 border-b border-[#EAEAEA]">
            <HelpCircle className="w-4 h-4 text-[#000000]" />
            <h3 className="text-xs sm:text-sm font-extrabold text-[#111111] uppercase tracking-wider">
              Frequently Asked Questions
            </h3>
          </div>
          <div className="divide-y divide-[#EAEAEA]">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div key={idx} className="py-2.5">
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full flex items-center justify-between text-left gap-2 text-xs font-bold text-[#111111] hover:text-[#000000] transition-colors cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-[#666666] transition-transform ${
                        isOpen ? 'rotate-180 text-[#000000]' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <p className="text-xs text-[#666666] mt-2 leading-relaxed bg-[#FAFAFA] p-3 rounded-xl border border-[#EAEAEA]">
                      {faq.a}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-[#EAEAEA] p-4 sm:p-5 shadow-2xs space-y-3">
          <div className="flex items-center gap-2 pb-1 border-b border-[#EAEAEA]">
            <MessageSquare className="w-4 h-4 text-[#000000]" />
            <h3 className="text-xs sm:text-sm font-extrabold text-[#111111] uppercase tracking-wider">
              Submit a Support Request
            </h3>
          </div>

          {isSubmitted ? (
            <div className="py-6 text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-extrabold text-[#111111]">
                Support Ticket Created!
              </h4>
              <p className="text-xs text-[#666666]">
                Ticket Number: <span className="font-extrabold text-[#000000] bg-[#FFF9DB] px-1.5 py-0.5 rounded">{ticketId}</span>
              </p>
              <p className="text-[11px] text-[#666666] max-w-xs mx-auto">
                Our support team will review your query and respond via email within 2-4 business hours.
              </p>
              <button
                onClick={() => setIsSubmitted(false)}
                className="mt-3 px-4 py-2 rounded-xl bg-[#000000] text-white font-bold text-xs shadow-xs cursor-pointer hover:bg-neutral-800"
              >
                Submit Another Request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-[#111111] block mb-1">Issue Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full h-10 px-3 text-xs font-semibold bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#000000]"
                >
                  <option value="Delivery & Shipping">Delivery & Shipping Status</option>
                  <option value="Cash on Delivery">Cash on Delivery Inquiry</option>
                  <option value="Return / Exchange">Return or Exchange Request</option>
                  <option value="Product Damaged">Damaged or Wrong Product Received</option>
                  <option value="Account & Profile">Account / Login Assistance</option>
                  <option value="Other">Other Question</option>
                </select>
              </div>

              {orders.length > 0 && (
                <div>
                  <label className="text-xs font-bold text-[#111111] block mb-1">Related Order (Optional)</label>
                  <select
                    value={orderId}
                    onChange={(e) => setOrderId(e.target.value)}
                    className="w-full h-10 px-3 text-xs font-semibold bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#000000]"
                  >
                    <option value="">Select an order (Optional)</option>
                    {orders.map((ord) => (
                      <option key={ord.id} value={ord.id}>
                        #{ord.id.slice(0, 14)} • ₹{ord.total}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="text-xs font-bold text-[#111111] block mb-1">Describe Your Issue</label>
                <textarea
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please provide details about how we can help you..."
                  className="w-full p-3 text-xs font-medium bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#000000] placeholder:text-[#666666]"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Ticket</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
