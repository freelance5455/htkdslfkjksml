import { useState } from 'react';
import { Phone, Mail, MapPin, MessageSquare, ChevronDown, ChevronUp, Send, CheckCircle2, Headphones, Sparkles } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface SupportScreenProps {
  language: Language;
}

export function SupportScreen({ language }: SupportScreenProps) {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'agent'; text: string; time: string }>>([
    { sender: 'agent', text: 'مرحباً بك في Tourism By Taki! كيف يمكننا مساعدتك في رحلتك القادمة؟', time: '10:00 ص' },
  ]);
  const [chatInput, setChatInput] = useState('');

  const t = translations[language];

  const faqs = [
    {
      q: 'كيف يمكنني استلام تذكرة الطيران وبطاقة الصعود الرسمية؟',
      a: 'بمجرد تأكيد الحجز، تظهر بطاقتك وتذكرتك تلقائياً في قسم "محفظتي" داخل تطبيق TAKI-GO، وتكون متاحة للاستخدام دون اتصال بالإنترنت (Offline).',
    },
    {
      q: 'هل تقدم وكالة Tourism By Taki مساعدة كاملة في ملفات تأشيرة شنغن وتأشيرة تركيا؟',
      a: 'نعم، يتولى فريقنا حجز المواعيد الرسمية، مراجعة وتدقيق الوثائق وترجمتها، إعداد التأمين وحجوزات الطيران والفنادق المؤكدة لضمان أعلى نسب القبول.',
    },
    {
      q: 'ما هي طرق الدفع المتاحة لدى الوكالة؟',
      a: 'ندعم الدفع نقداً أو عبر البطاقة الذهبية / CIB في مقر الوكالة بالجزائر، أو عبر التحويل البنكي المباشر والحساب البريدي الجاري CCP.',
    },
    {
      q: 'ما هو نظام Smart Trip Guardian وكيف يحميني أثناء السفر؟',
      a: 'هو نظام مراقبة حي يرصد مواعيد الرحلات، التغييرات في بوابات الصعود، حالة الطقس بالوجهة، ويقدم تنبيهات استباقية باللغة العربية والفرنسية.',
    },
  ];

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg = { sender: 'user' as const, text: chatInput, time: 'الآن' };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');

    setTimeout(() => {
      const agentReply = {
        sender: 'agent' as const,
        text: 'شكراً لتواصلك! تم استلام رسالتك وسيجيبك مستشار السفر المخصص خلال لحظات.',
        time: 'الآن',
      };
      setChatMessages(prev => [...prev, agentReply]);
    }, 900);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Title */}
      <div>
        <h1 className="text-xl md:text-2xl font-black text-white">
          {t.supportTitle}
        </h1>
        <p className="text-xs text-slate-300 mt-1">
          {t.supportSubtitle}
        </p>
      </div>

      {/* Direct Contact Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <a
          href="https://wa.me/213555123456"
          target="_blank"
          rel="noreferrer"
          className="p-4 rounded-3xl bg-emerald-950/40 border border-emerald-500/30 hover:border-emerald-400 text-white transition-all flex items-center gap-3 group"
        >
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-white">{t.contactWhatsapp}</p>
            <p className="text-[11px] text-emerald-300 font-mono">+213 555 12 34 56</p>
          </div>
        </a>

        <a
          href="tel:+213555123456"
          className="p-4 rounded-3xl bg-blue-950/40 border border-blue-500/30 hover:border-blue-400 text-white transition-all flex items-center gap-3 group"
        >
          <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
            <Phone className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-white">{t.callAgency}</p>
            <p className="text-[11px] text-blue-300 font-mono">+213 555 12 34 56</p>
          </div>
        </a>

        <a
          href="mailto:tourismebytaki@gmail.com"
          className="p-4 rounded-3xl bg-cyan-950/40 border border-cyan-500/30 hover:border-cyan-400 text-white transition-all flex items-center gap-3 group"
        >
          <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-white">البريد الإلكتروني</p>
            <p className="text-[11px] text-cyan-300 font-mono truncate max-w-[130px]">tourismebytaki@gmail.com</p>
          </div>
        </a>
      </div>

      {/* Live Concierge Chat Box */}
      <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-500/30 text-white space-y-3">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Headphones className="w-4 h-4 text-cyan-400" />
            <h2 className="text-xs font-bold text-white">{t.chatWithAgent}</h2>
          </div>
          <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            ONLINE
          </span>
        </div>

        {/* Message Thread */}
        <div className="h-44 overflow-y-auto space-y-2 p-1 no-scrollbar text-xs">
          {chatMessages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[80%] p-3 rounded-2xl ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-br-none rtl:rounded-bl-none rtl:rounded-br-2xl'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-none rtl:rounded-br-none rtl:rounded-bl-2xl'
                }`}
              >
                <p>{msg.text}</p>
              </div>
              <span className="text-[9px] text-slate-500 mt-0.5 font-mono">{msg.time}</span>
            </div>
          ))}
        </div>

        {/* Input */}
        <form onSubmit={handleSendChatMessage} className="flex items-center gap-2 pt-2 border-t border-slate-800">
          <input
            type="text"
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            placeholder="اكتب استفسارك هنا..."
            className="flex-1 h-10 bg-slate-900 border border-slate-800 rounded-xl px-3 text-xs text-white placeholder-slate-500 outline-none"
          />
          <button
            type="submit"
            className="h-10 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-xs font-bold flex items-center gap-1"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>

      {/* FAQs */}
      <div className="space-y-2.5">
        <h2 className="text-xs font-bold text-slate-200">
          {language === 'ar' ? 'الأسئلة الشائعة (FAQ):' : 'Frequently Asked Questions:'}
        </h2>

        {faqs.map((faq, i) => (
          <div
            key={i}
            onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
            className="glass-panel p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all cursor-pointer text-white"
          >
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold text-slate-200">{faq.q}</p>
              {expandedFaq === i ? (
                <ChevronUp className="w-4 h-4 text-cyan-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-slate-500" />
              )}
            </div>
            {expandedFaq === i && (
              <p className="mt-2.5 pt-2.5 border-t border-slate-800/80 text-xs text-slate-300 leading-relaxed">
                {faq.a}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
