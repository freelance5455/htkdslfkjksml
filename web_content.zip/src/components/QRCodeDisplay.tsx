/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';

interface QRCodeDisplayProps {
  url: string;
  size?: number;
}

export const QRCodeDisplay: React.FC<QRCodeDisplayProps> = ({ url, size = 180 }) => {
  const [dataUrl, setDataUrl] = useState<string>('');

  useEffect(() => {
    QRCode.toDataURL(url, {
      width: size,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then(setDataUrl)
      .catch(console.error);
  }, [url, size]);

  if (!dataUrl) {
    return (
      <div 
        style={{ width: size, height: size }} 
        className="rounded-xl bg-slate-800 animate-pulse flex items-center justify-center text-xs text-slate-500"
      >
        Loading QR...
      </div>
    );
  }

  return (
    <div className="p-2.5 rounded-2xl bg-white shadow-md inline-block">
      <img 
        src={dataUrl} 
        alt="Scan with Android Camera" 
        width={size} 
        height={size} 
        className="rounded-lg block" 
      />
    </div>
  );
};
