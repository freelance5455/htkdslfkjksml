import { useEffect, useMemo, useRef, useState } from "react";
import { askAiTutor } from "../ai/tutorClient";
import { AI_PROVIDER, DEFAULT_DAILY_LIMIT } from "../ai/config";
import { connectPuter, disconnectPuter, getPuterUsername, isPuterScriptLoaded, isPuterSignedIn } from "../ai/puterClient";
import { detectKnownFormulas } from "../ai/formulaDetection";
import type { ChatMessage } from "../ai/types";
import { useAiUsage } from "../state/AiUsageState";
import { useFormulaHistory } from "../state/FormulaHistoryState";
import { useAppState } from "../state/AppState";
import { getBoardChapters } from "../data/syllabus";
import type { ClassLevel, Subject } from "../data/types";

const CONVERSATION_KEY = "formulaverse-ai-conversation";
const CLASS_OPTIONS: ClassLevel[] = [8, 9, 10];
const SUBJECT_OPTIONS: Subject[] = ["Mathematics", "Physics", "Chemistry"];

function loadConversation(): ChatMessage[] {
  try {
    const raw = sessionStorage.getItem(CONVERSATION_KEY);
    return raw ? (JSON.parse(raw) as ChatMessage[]) : [];
  } catch {
    return [];
  }
}

function newId(): string {
  return `msg_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export default function AiTutor() {
  const usage = useAiUsage();
  const { board } = useAppState();
  const { recordUsage } = useFormulaHistory();
  const [messages, setMessages] = useState<ChatMessage[]>(() => loadConversation());
  const [input, setInput] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastFailedQuestion, setLastFailedQuestion] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // --- Study context (optional) — tailors the AI Tutor's answers and is
  // shown to the student so they always know what context is active. ---
  const [ctxClass, setCtxClass] = useState<ClassLevel | "">("");
  const [ctxSubject, setCtxSubject] = useState<Subject | "">("");
  const [ctxChapter, setCtxChapter] = useState<string>("");
  const chapterOptions = useMemo(() => (ctxClass && ctxSubject ? getBoardChapters(board, ctxClass, ctxSubject).map((c) => c.chapter) : []), [board, ctxClass, ctxSubject]);

  // --- Puter.js engine / connection state (only relevant when AI_PROVIDER === "puter") ---
  const [engineState, setEngineState] = useState<"loading" | "ready" | "failed">(isPuterScriptLoaded() ? "ready" : "loading");
  const [connected, setConnected] = useState(isPuterSignedIn());
  const [username, setUsername] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);

  useEffect(() => {
    if (AI_PROVIDER !== "puter" || engineState !== "loading") return;
    let tries = 0;
    const id = setInterval(() => {
      tries++;
      if (isPuterScriptLoaded()) {
        setEngineState("ready");
        clearInterval(id);
      } else if (tries > 25) {
        setEngineState("failed");
        clearInterval(id);
      }
    }, 300);
    return () => clearInterval(id);
  }, [engineState]);

  useEffect(() => {
    if (AI_PROVIDER !== "puter" || engineState !== "ready") return;
    if (isPuterSignedIn()) {
      getPuterUsername().then((name) => {
        setConnected(true);
        setUsername(name);
      });
    }
  }, [engineState]);

  useEffect(() => {
    sessionStorage.setItem(CONVERSATION_KEY, JSON.stringify(messages));
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function handleConnect() {
    setConnecting(true);
    setConnectError(null);
    const result = await connectPuter();
    setConnecting(false);
    if (result.ok) {
      setConnected(true);
      setUsername(result.username);
    } else {
      setConnectError(result.message);
    }
  }

  function handleDisconnect() {
    disconnectPuter();
    setConnected(false);
    setUsername(null);
  }

  async function sendMessage(question: string) {
    const trimmed = question.trim();
    if (!trimmed) return;
    if (!usage.canSend) return;

    // For the Puter.js path, make sure the user is connected first — this is
    // the one required one-time step, triggered here by their own click so
    // the sign-in popup is allowed to open.
    if (AI_PROVIDER === "puter" && !connected) {
      const result = await connectPuter();
      if (!result.ok) {
        setConnectError(result.message);
        return;
      }
      setConnected(true);
      setUsername(result.username);
    }

    setErrorMessage(null);
    setLastFailedQuestion(null);
    const userMsg: ChatMessage = { id: newId(), role: "user", content: trimmed, createdAt: new Date().toISOString() };
    const historyForRequest = [...messages, userMsg];
    setMessages(historyForRequest);
    setInput("");
    setStatus("loading");

    usage.recordMessageSent();

    const outcome = await askAiTutor(usage.deviceId, messages, trimmed, {
      board,
      classLevel: ctxClass || undefined,
      subject: ctxSubject || undefined,
      chapter: ctxChapter || undefined,
    });

    if (outcome.ok) {
      const assistantMsg: ChatMessage = { id: newId(), role: "assistant", content: outcome.reply, createdAt: new Date().toISOString() };
      setMessages((prev) => [...prev, assistantMsg]);
      setStatus("idle");
      if (outcome.remainingToday !== undefined) usage.syncFromServer(outcome.remainingToday);

      const detected = detectKnownFormulas(outcome.reply);
      for (const d of detected) {
        recordUsage({ ...d, board: d.board ?? board, chapter: d.chapter ?? (ctxChapter || undefined) }, trimmed, "Mentioned by the AI Tutor while answering this question");
      }
    } else {
      setStatus("error");
      setErrorMessage(outcome.message);
      setLastFailedQuestion(trimmed);
      const errMsg: ChatMessage = { id: newId(), role: "assistant", content: outcome.message, createdAt: new Date().toISOString(), error: true };
      setMessages((prev) => [...prev, errMsg]);
    }
  }

  function retry() {
    if (!lastFailedQuestion) return;
    setMessages((prev) => prev.filter((m) => !m.error));
    sendMessage(lastFailedQuestion);
  }

  function startNewConversation() {
    setMessages([]);
    setErrorMessage(null);
    setLastFailedQuestion(null);
    setStatus("idle");
    sessionStorage.removeItem(CONVERSATION_KEY);
  }

  const resetTimeLabel = new Date(usage.resetAt).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
  const needsConnect = AI_PROVIDER === "puter" && engineState === "ready" && !connected;

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-3xl flex-col px-4 py-6 sm:px-6">
      <div className="mb-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md">
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2a7 7 0 0 0-7 7c0 2.5 1.3 4.3 3 5.5V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.5c1.7-1.2 3-3 3-5.5a7 7 0 0 0-7-7Z" />
              <path d="M9 21h6" />
            </svg>
          </span>
          <div>
            <h1 className="text-xl font-bold leading-tight text-slate-800 dark:text-slate-100">AI Tutor</h1>
            <p className="text-[11px] text-slate-400 dark:text-slate-500">
              Mathematics, Physics & Chemistry · Classes 8–10
              {AI_PROVIDER === "puter" && connected && username && <span className="ml-1 text-emerald-500">· Connected as {username}</span>}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {AI_PROVIDER === "puter" && connected && (
            <button
              onClick={handleDisconnect}
              className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-500 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
            >
              Disconnect
            </button>
          )}
          <button
            onClick={startNewConversation}
            className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-500 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            New conversation
          </button>
        </div>
      </div>

      <UsageBar usage={usage} resetTimeLabel={resetTimeLabel} />

      <div className="mt-2 flex flex-wrap gap-2">
        <span className="flex items-center rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400">
          {board}
        </span>
        <select
          value={ctxClass}
          onChange={(e) => {
            setCtxClass(e.target.value ? (Number(e.target.value) as ClassLevel) : "");
            setCtxChapter("");
          }}
          className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-600 outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
        >
          <option value="">Any class</option>
          {CLASS_OPTIONS.map((c) => (
            <option key={c} value={c}>
              Class {c}
            </option>
          ))}
        </select>
        <select
          value={ctxSubject}
          onChange={(e) => {
            setCtxSubject(e.target.value as Subject | "");
            setCtxChapter("");
          }}
          className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-600 outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
        >
          <option value="">Any subject</option>
          {SUBJECT_OPTIONS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        {chapterOptions.length > 0 && (
          <select
            value={ctxChapter}
            onChange={(e) => setCtxChapter(e.target.value)}
            className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-600 outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
          >
            <option value="">Any chapter</option>
            {chapterOptions.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        )}
      </div>

      {AI_PROVIDER === "puter" && engineState === "failed" && (
        <div className="mt-2 rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
          <span className="font-semibold">⚠ AI engine failed to load. </span>
          Check your internet connection or disable any ad-blocker/script-blocker for this site, then reload the page.
        </div>
      )}

      {needsConnect && (
        <ConnectCard connecting={connecting} error={connectError} onConnect={handleConnect} />
      )}

      <div ref={scrollRef} className="mt-3 flex-1 space-y-3 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        {messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center text-center text-sm text-slate-400 dark:text-slate-500">
            <p>Ask anything from your Class 8–10 Math, Physics or Chemistry syllabus.</p>
            <p className="mt-1 text-xs">e.g. "Explain Newton's second law with an example" or "Why is √2 irrational?"</p>
          </div>
        )}
        {messages.map((m) => (
          <MessageBubble key={m.id} message={m} />
        ))}
        {status === "loading" && (
          <div className="flex items-center gap-2 text-sm text-slate-400">
            <span className="h-2 w-2 animate-pulse rounded-full bg-indigo-400" />
            <span className="h-2 w-2 animate-pulse rounded-full bg-indigo-400 [animation-delay:150ms]" />
            <span className="h-2 w-2 animate-pulse rounded-full bg-indigo-400 [animation-delay:300ms]" />
            <span>AI Tutor is thinking…</span>
          </div>
        )}
      </div>

      {errorMessage && status === "error" && (
        <div className="mt-2 flex items-center justify-between gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
          <span>{errorMessage}</span>
          {lastFailedQuestion && (
            <button onClick={retry} className="shrink-0 rounded-md bg-rose-100 px-2 py-1 font-semibold hover:bg-rose-200 dark:bg-rose-500/20 dark:hover:bg-rose-500/30">
              Retry
            </button>
          )}
        </div>
      )}

      {messages.length > 0 && status === "idle" && messages[messages.length - 1]?.role === "assistant" && !messages[messages.length - 1]?.error && (
        <div className="mt-2 flex flex-wrap gap-2">
          <button
            onClick={() => sendMessage("Can you explain that more simply, with an easier example?")}
            className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-medium text-slate-500 transition hover:border-indigo-300 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400"
          >
            Explain more simply
          </button>
          <button
            onClick={() => sendMessage("Can you give me a practice question on this topic?")}
            className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-medium text-slate-500 transition hover:border-indigo-300 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400"
          >
            Give me a practice question
          </button>
        </div>
      )}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          sendMessage(input);
        }}
        className="mt-3 flex gap-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={!usage.canSend ? "Daily limit reached" : needsConnect ? "Type a question, then Send to connect..." : "Ask a question..."}
          disabled={!usage.canSend || status === "loading"}
          className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm shadow-sm outline-none ring-indigo-200 transition focus:ring-4 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:ring-indigo-500/20"
        />
        <button
          type="submit"
          disabled={!usage.canSend || status === "loading" || !input.trim()}
          className="shrink-0 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90 disabled:opacity-40"
        >
          Send
        </button>
      </form>
    </div>
  );
}

function ConnectCard({ connecting, error, onConnect }: { connecting: boolean; error: string | null; onConnect: () => void }) {
  return (
    <div className="mt-3 rounded-2xl border border-indigo-200 bg-indigo-50 p-4 text-sm dark:border-indigo-500/30 dark:bg-indigo-500/10">
      <p className="font-semibold text-indigo-700 dark:text-indigo-300">One step to activate the AI Tutor</p>
      <p className="mt-1 text-xs text-indigo-600/90 dark:text-indigo-300/80">
        FormulaVerse's AI Tutor runs on a real AI model with no backend server and no fees for this app — each user signs in with a
        free account to use it. Click the button below, then sign in or create a free account in the popup that opens.
      </p>
      <button
        onClick={onConnect}
        disabled={connecting}
        className="mt-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90 disabled:opacity-60"
      >
        {connecting ? "Opening sign-in…" : "Connect AI Tutor →"}
      </button>
      {error && <p className="mt-2 text-xs font-medium text-rose-600 dark:text-rose-400">{error}</p>}
    </div>
  );
}

function UsageBar({ usage, resetTimeLabel }: { usage: ReturnType<typeof useAiUsage>; resetTimeLabel: string }) {
  const pct = Math.min(100, (usage.used / usage.limit) * 100);
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3 text-xs dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-center justify-between">
        <span className="font-medium text-slate-600 dark:text-slate-300">
          {usage.remaining} of {DEFAULT_DAILY_LIMIT} messages left today
        </span>
        <span className="text-slate-400">resets {resetTimeLabel}</span>
      </div>
      <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
        <div className="h-full bg-gradient-to-r from-indigo-500 to-purple-500" style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-1.5 text-[10px] text-slate-400 dark:text-slate-500">
        This is a device-based limit stored on this browser (not a secure per-account quota) — it's separate from any usage allowance
        on your own AI account.
      </p>
      {!usage.canSend && (
        <p className="mt-1 text-[11px] font-medium text-amber-600 dark:text-amber-400">
          Daily limit reached. You can ask again after {resetTimeLabel}.
        </p>
      )}
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm ${
          isUser
            ? "bg-gradient-to-br from-indigo-600 to-purple-600 text-white"
            : message.error
            ? "border border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300"
            : "border border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
        }`}
      >
        {message.content}
      </div>
    </div>
  );
}
