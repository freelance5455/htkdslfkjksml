import React, { useState, useEffect } from 'react';
import {
  X,
  BookMarked,
  TrendingDown,
  Calendar,
  Clock,
  Download,
  FileSpreadsheet,
  FileText,
  FileJson,
  Heart,
  Sparkles,
  ChevronDown,
  Activity,
  UserCheck,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { jsPDF } from 'jspdf';
import { SessionRecord, EmotionalLog, UserProfile } from '../types/index.ts';
import { storageService } from '../lib/supabase.ts';

interface JournalHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectToolById: (toolId: string) => void;
}

export const JournalHistoryModal: React.FC<JournalHistoryModalProps> = ({
  isOpen,
  onClose,
  onSelectToolById,
}) => {
  const { t } = useTranslation();
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [emotionalLogs, setEmotionalLogs] = useState<EmotionalLog[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [showExportMenu, setShowExportMenu] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'sessions' | 'logs'>('sessions');

  useEffect(() => {
    if (isOpen) {
      setSessions(storageService.getSessions());
      setEmotionalLogs(storageService.getEmotionalLogs());
      setUserProfile(storageService.getUserProfile());
      setShowExportMenu(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Compute average relief points
  const totalRelief = sessions.reduce((acc, s) => acc + (s.ratingBefore - s.ratingAfter), 0);
  const avgRelief = sessions.length > 0 ? (totalRelief / sessions.length).toFixed(1) : '0';

  const avgBefore = sessions.length > 0
    ? (sessions.reduce((acc, s) => acc + s.ratingBefore, 0) / sessions.length).toFixed(1)
    : '0';

  const avgAfter = sessions.length > 0
    ? (sessions.reduce((acc, s) => acc + s.ratingAfter, 0) / sessions.length).toFixed(1)
    : '0';

  // 1. Export CSV formatted for spreadsheet / clinical consultation
  const exportToCSV = () => {
    const today = new Date().toISOString().split('T')[0];
    const patientName = userProfile?.fullName || 'Patient_Anonyme';

    // UTF-8 BOM so Excel opens accents properly without garbled characters
    let csvContent = '\uFEFF';
    csvContent += 'Date;Heure;Type d’Entrée;Exercice ou Émotion;Espace;Version;Durée (min);Détresse Initiale (0-10);Détresse Après (0-10);Différentiel de Soulagement;Notes & Observations Cliniques\n';

    // Append sessions
    sessions.forEach((s) => {
      const dt = new Date(s.createdAt);
      const dateStr = dt.toLocaleDateString('fr-FR');
      const timeStr = dt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      const durationMin = Math.max(1, Math.round(s.durationSeconds / 60));
      const diff = s.ratingBefore - s.ratingAfter;
      const cleanNote = (s.notes || '').replace(/[\n\r;]/g, ' ');
      const spaceLabel = s.spaceType === 'parents' ? 'Espace Parents' : 'Espace Adulte';
      const versionLabel = s.version === 'short' ? 'Express (Court)' : 'Approfondi (Complet)';

      csvContent += `"${dateStr}";"${timeStr}";"Exercice de régulation";"${s.toolTitle}";"${spaceLabel}";"${versionLabel}";"${durationMin}";"${s.ratingBefore}";"${s.ratingAfter}";"-${diff} pts";"${cleanNote}"\n`;
    });

    // Append emotional logs
    emotionalLogs.forEach((log) => {
      const dt = new Date(log.createdAt);
      const dateStr = dt.toLocaleDateString('fr-FR');
      const timeStr = dt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      const diff = log.intensityBefore - log.intensityAfter;
      const cleanNote = (log.notes || '').replace(/[\n\r;]/g, ' ');
      const spaceLabel = log.context === 'parents' ? 'Espace Parents' : 'Espace Adulte';

      csvContent += `"${dateStr}";"${timeStr}";"Journal émotionnel";"${log.primaryEmotion}";"${spaceLabel}";"-";"-";"${log.intensityBefore}";"${log.intensityAfter}";"-${diff} pts";"${cleanNote}"\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', url);
    downloadAnchor.setAttribute('download', `coeur_regule_suivi_clinique_${patientName}_${today}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    document.body.removeChild(downloadAnchor);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  // 2. Export PDF formatted for Health Professionals (Thérapeute / Psychiatre / Psychologue)
  const exportToPDF = () => {
    const today = new Date().toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    const patientName = userProfile?.fullName || 'Utilisateur (Mode Invité / Anonyme)';

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    let currentY = 18;

    // Header Title
    doc.setFillColor(244, 63, 94); // Rose-500
    doc.rect(14, currentY, 4, 16, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(30, 41, 59);
    doc.text('CŒUR RÉGULÉ', 22, currentY + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text('Dossier de Suivi Émotionnel & Somatique pour Professionnel de Santé', 22, currentY + 12);

    currentY += 24;

    // Patient & Consultation Meta Box
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(14, currentY, pageWidth - 28, 20, 2, 2, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text(`Patient / Accompagné(e) : ${patientName}`, 18, currentY + 7);
    doc.text(`Date d'exportation : ${today}`, 18, currentY + 14);

    doc.text(`Nombre total d'exercices : ${sessions.length}`, pageWidth / 2 + 10, currentY + 7);
    doc.text(`Baisse moyenne de tension : -${avgRelief} points (sur 10)`, pageWidth / 2 + 10, currentY + 14);

    currentY += 26;

    // Clinical Summary Metrics
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('1. Synthèse de la Régulation du Système Nerveux', 14, currentY);
    currentY += 6;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(51, 65, 85);
    const summaryText = `Ce document récapitule les protocoles somatiques (Grounding, Cohérence Cardiaque, EFT, IFS, Théorie Polyvagale) réalisés de manière autonome. La détresse moyenne initiale évaluée avant exercice est de ${avgBefore}/10, et redescend en moyenne à ${avgAfter}/10 après séance.`;
    const splitSummary = doc.splitTextToSize(summaryText, pageWidth - 28);
    doc.text(splitSummary, 14, currentY);
    currentY += splitSummary.length * 4.5 + 4;

    // Table Header
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('2. Historique Chronologique Détaillé des Séances', 14, currentY);
    currentY += 7;

    doc.setFillColor(241, 245, 249);
    doc.rect(14, currentY, pageWidth - 28, 7, 'F');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    doc.text('Date & Heure', 16, currentY + 5);
    doc.text('Protocole / Outil', 48, currentY + 5);
    doc.text('Espace', 105, currentY + 5);
    doc.text('Avant / Après', 135, currentY + 5);
    doc.text('Gain', 165, currentY + 5);
    doc.text('Durée', 180, currentY + 5);

    currentY += 8;

    // Iterate Sessions
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);

    if (sessions.length === 0) {
      doc.text('Aucune séance enregistrée pour le moment.', 16, currentY + 5);
      currentY += 10;
    } else {
      sessions.forEach((sess) => {
        // Page break if needed
        if (currentY > 260) {
          doc.addPage();
          currentY = 18;
          // Subheader on new page
          doc.setFont('helvetica', 'bold');
          doc.text('Historique des Séances (suite)', 14, currentY);
          currentY += 8;
        }

        const dt = new Date(sess.createdAt);
        const dateFormatted = `${dt.toLocaleDateString('fr-FR')} ${dt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`;
        const diff = sess.ratingBefore - sess.ratingAfter;
        const durationMin = `${Math.max(1, Math.round(sess.durationSeconds / 60))}m`;
        const spaceShort = sess.spaceType === 'parents' ? 'Parents' : 'Adulte';

        doc.setTextColor(30, 41, 59);
        doc.text(dateFormatted, 16, currentY + 4);
        doc.text(sess.toolTitle.substring(0, 32), 48, currentY + 4);
        doc.text(spaceShort, 105, currentY + 4);

        doc.text(`${sess.ratingBefore}/10 -> ${sess.ratingAfter}/10`, 135, currentY + 4);

        if (diff > 0) {
          doc.setTextColor(16, 185, 129); // Emerald
          doc.text(`-${diff} pts`, 165, currentY + 4);
        } else {
          doc.setTextColor(100, 116, 139);
          doc.text('0 pt', 165, currentY + 4);
        }

        doc.setTextColor(100, 116, 139);
        doc.text(durationMin, 180, currentY + 4);

        currentY += 6;

        // If patient wrote notes, print on indented row
        if (sess.notes && sess.notes.trim()) {
          doc.setFont('helvetica', 'italic');
          doc.setTextColor(100, 116, 139);
          const noteText = `Note : "${sess.notes.trim()}"`;
          const splitNotes = doc.splitTextToSize(noteText, pageWidth - 40);
          doc.text(splitNotes, 24, currentY + 3);
          currentY += splitNotes.length * 4 + 2;
          doc.setFont('helvetica', 'normal');
        }

        // Row subtle separator
        doc.setDrawColor(241, 245, 249);
        doc.line(14, currentY, pageWidth - 14, currentY);
        currentY += 2;
      });
    }

    // Footer Disclaimer on PDF
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    const footerText = 'Document généré par l\'application Cœur Régulé. Outil d\'accompagnement psycho-somatique non diagnostique. En cas de détresse sévère, joindre le 3114 (France) ou le 112 (Europe).';
    doc.text(footerText, 14, 287);

    doc.save(`coeur_regule_rapport_sante_${today.replace(/\s+/g, '_')}.pdf`);
    setShowExportMenu(false);
  };

  // 3. Export JSON (raw backup)
  const exportToJSON = () => {
    const backupData = {
      user: userProfile,
      exportedAt: new Date().toISOString(),
      sessions,
      emotionalLogs,
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `coeur_regule_sauvegarde_complete_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    document.body.removeChild(downloadAnchor);
    setShowExportMenu(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-100 dark:border-slate-800 flex flex-col my-auto max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 bg-gradient-to-r from-rose-50/70 via-white to-teal-50/70 dark:from-slate-900 dark:to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500 text-white flex items-center justify-center shadow-md">
              <BookMarked className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-base sm:text-lg">
                {t('history.title')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Suivi somatique & export pour professionnel de santé
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Export Dropdown Menu Button */}
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all shadow-xs"
                title="Exporter pour un professionnel de santé"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Exporter (PDF / CSV)</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {/* Dropdown Options */}
              {showExportMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 p-2 z-20 space-y-1 animate-fade-in">
                  <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-700">
                    Partage Médical & Thérapeutique
                  </div>

                  <button
                    onClick={exportToPDF}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-rose-50 dark:hover:bg-slate-700 transition-colors text-left"
                  >
                    <FileText className="w-4 h-4 text-rose-500 shrink-0" />
                    <div>
                      <div className="font-bold text-slate-800 dark:text-slate-100">
                        Rapport PDF Clinique
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Mise en page médicale pour consultation
                      </div>
                    </div>
                  </button>

                  <button
                    onClick={exportToCSV}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-slate-700 transition-colors text-left"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-teal-600 shrink-0" />
                    <div>
                      <div className="font-bold text-slate-800 dark:text-slate-100">
                        Tableur CSV (Excel / Sheets)
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Données brutes avec dates & notes
                      </div>
                    </div>
                  </button>

                  <button
                    onClick={exportToJSON}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-left"
                  >
                    <FileJson className="w-4 h-4 text-slate-400 shrink-0" />
                    <div>
                      <div className="font-bold text-slate-800 dark:text-slate-100">
                        Sauvegarde JSON
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Archive complète des données
                      </div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Doctor Sharing Advice Banner */}
        <div className="px-4 sm:px-6 py-2.5 bg-rose-50/60 dark:bg-rose-950/20 border-b border-rose-100/60 dark:border-rose-900/40 flex items-center gap-2 text-xs text-rose-900 dark:text-rose-200">
          <UserCheck className="w-4 h-4 text-rose-500 shrink-0" />
          <span>
            <strong>Partage avec votre praticien :</strong> Exportez vos données en PDF ou CSV pour analyser vos déclencheurs et vos progrès lors de vos rendez-vous thérapeutiques.
          </span>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 sm:p-6 bg-slate-50/50 dark:bg-slate-800/30 border-b border-slate-100 dark:border-slate-800">
          <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700">
            <span className="text-[11px] font-bold text-slate-400 block mb-0.5">
              {t('history.sessionCount')}
            </span>
            <span className="text-xl sm:text-2xl font-extrabold text-teal-600 dark:text-teal-400">
              {sessions.length}
            </span>
          </div>

          <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700">
            <span className="text-[11px] font-bold text-slate-400 block mb-0.5">
              {t('history.avgRelief')}
            </span>
            <div className="flex items-center gap-1 text-xl sm:text-2xl font-extrabold text-rose-500">
              <TrendingDown className="w-5 h-5" />
              <span>-{avgRelief} pts</span>
            </div>
          </div>

          <div className="hidden sm:block p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700">
            <span className="text-[11px] font-bold text-slate-400 block mb-0.5">
              Confidentialité
            </span>
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              100% sur votre appareil
            </span>
          </div>
        </div>

        {/* Tab switcher: Sessions vs Emotional Logs */}
        <div className="flex items-center px-4 sm:px-6 pt-3 border-b border-slate-100 dark:border-slate-800 gap-4 text-xs font-bold">
          <button
            onClick={() => setActiveTab('sessions')}
            className={`pb-2 transition-colors border-b-2 ${
              activeTab === 'sessions'
                ? 'border-teal-600 text-teal-700 dark:text-teal-300'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            Exercices Réalisés ({sessions.length})
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`pb-2 transition-colors border-b-2 ${
              activeTab === 'logs'
                ? 'border-teal-600 text-teal-700 dark:text-teal-300'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            Logs Émotionnels ({emotionalLogs.length})
          </button>
        </div>

        {/* Sessions & Logs List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {activeTab === 'sessions' ? (
            sessions.length === 0 ? (
              <div className="text-center py-12 space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
                  <BookMarked className="w-6 h-6" />
                </div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                  {t('history.noSessions')}
                </p>
              </div>
            ) : (
              sessions.map((sess) => {
                const diff = sess.ratingBefore - sess.ratingAfter;
                const dateFormatted = new Date(sess.createdAt).toLocaleDateString(undefined, {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={sess.id}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 hover:border-teal-200 dark:hover:border-slate-700 shadow-2xs transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-slate-100">
                          {sess.toolTitle}
                        </span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {sess.version === 'short' ? 'Express' : 'Complet'}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          • {sess.spaceType === 'parents' ? 'Parents' : 'Adulte'}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-[11px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {dateFormatted}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {Math.round(sess.durationSeconds / 60)} min
                        </span>
                      </div>

                      {sess.notes && (
                        <p className="text-xs text-slate-600 dark:text-slate-300 italic pt-1">
                          "{sess.notes}"
                        </p>
                      )}
                    </div>

                    {/* Rating Evolution Badge */}
                    <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                      <div className="flex items-center gap-1.5 text-xs font-bold bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-100 dark:border-slate-700">
                        <span className="text-slate-500">{sess.ratingBefore}/10</span>
                        <span className="text-slate-300">→</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                          {sess.ratingAfter}/10
                        </span>
                      </div>

                      {diff > 0 && (
                        <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-1 rounded-lg">
                          -{diff}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )
          ) : (
            emotionalLogs.length === 0 ? (
              <div className="text-center py-12 space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
                  <Activity className="w-6 h-6" />
                </div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                  Aucun log émotionnel pour le moment.
                </p>
              </div>
            ) : (
              emotionalLogs.map((log) => {
                const diff = log.intensityBefore - log.intensityAfter;
                const dateFormatted = new Date(log.createdAt).toLocaleDateString(undefined, {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={log.id}
                    className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-slate-100">
                          {log.primaryEmotion}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          ({log.context === 'parents' ? 'Parents' : 'Adulte'})
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{dateFormatted}</span>
                      </div>
                      {log.notes && (
                        <p className="text-xs text-slate-600 dark:text-slate-300 italic pt-1">
                          "{log.notes}"
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                      <div className="flex items-center gap-1.5 text-xs font-bold bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-100 dark:border-slate-700">
                        <span className="text-slate-500">{log.intensityBefore}/10</span>
                        <span className="text-slate-300">→</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                          {log.intensityAfter}/10
                        </span>
                      </div>
                      {diff > 0 && (
                        <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-1 rounded-lg">
                          -{diff}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )
          )}
        </div>
      </div>
    </div>
  );
};
