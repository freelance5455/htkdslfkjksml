import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Account, Transaction, AppSettings, AccountType } from '../types';
import { formatCurrency } from '../utils/formatters';
import { getDualAccentInfo } from '../utils/theme';
import { storage } from '../utils/storage';
import {
  X,
  Wallet,
  Landmark,
  Smartphone,
  CreditCard,
  Banknote,
  ArrowDownLeft,
  ArrowUpRight,
  Scale,
  TrendingUp,
  TrendingDown,
  ArrowLeft,
} from 'lucide-react';

export interface AccountsBalanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts?: Account[];
  transactions?: Transaction[];
  useBanglaDigits: boolean;
  appSettings: AppSettings;
  onNavigateToLoan?: () => void;
}

interface WalletSummaryItem {
  type: AccountType;
  label: string;
  labelBangla: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}

const WALLET_SUMMARY_ITEMS: WalletSummaryItem[] = [
  { type: 'cash', label: 'Cash', labelBangla: 'নগদ ক্যাশ', icon: Banknote, color: '#10B981' },
  { type: 'mobile_banking', label: 'Mobile wallet', labelBangla: 'মোবাইল ওয়ালেট', icon: Smartphone, color: '#6366F1' },
  { type: 'card', label: 'Card wallet', labelBangla: 'কার্ড ওয়ালেট', icon: CreditCard, color: '#F59E0B' },
  { type: 'bank', label: 'Bank wallet', labelBangla: 'ব্যাংক ওয়ালেট', icon: Landmark, color: '#3B82F6' },
];

export const AccountsBalanceModal: React.FC<AccountsBalanceModalProps> = ({
  isOpen,
  onClose,
  accounts = [],
  transactions = [],
  useBanglaDigits,
  appSettings,
  onNavigateToLoan,
}) => {
  const isLight = appSettings?.themeMode === 'light';
  const isEn = appSettings?.language === 'en';

  const dualAccent = getDualAccentInfo(
    appSettings?.themeAccent,
    appSettings?.secondaryAccent,
    appSettings?.accentPercentage
  );

  type DetailCategory = 'wallets' | 'receivables' | 'payables';
  const [activeDetail, setActiveDetail] = useState<DetailCategory | null>(null);

  // Recalculate up-to-date balances for all accounts using double-entry transactions
  const balancedAccounts = useMemo(() => {
    const safeAccounts = Array.isArray(accounts) && accounts.length > 0
      ? accounts
      : storage.getAccounts();
    const safeTx = Array.isArray(transactions) ? transactions : [];
    return storage.calculateAccountBalances(safeAccounts, safeTx);
  }, [accounts, transactions]);

  // Aggregate totals
  const summary = useMemo(() => {
    let walletTotal = 0;
    let receivableTotal = 0;
    let payableTotal = 0;

    balancedAccounts.forEach((acc) => {
      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
      if (acc.type === 'receivable') {
        receivableTotal += bal;
      } else if (acc.type === 'payable') {
        payableTotal += bal;
      } else {
        walletTotal += bal;
      }
    });

    const netBalance = walletTotal + receivableTotal - payableTotal;
    const totalAssets = walletTotal + receivableTotal;

    return {
      walletTotal,
      receivableTotal,
      payableTotal,
      netBalance,
      totalAssets,
    };
  }, [balancedAccounts]);

  // Separate account lists by category
  const walletAccounts = useMemo(() => {
    return balancedAccounts.filter((acc) => acc.type !== 'receivable' && acc.type !== 'payable');
  }, [balancedAccounts]);

  const receivableAccounts = useMemo(() => {
    return balancedAccounts.filter((acc) => acc.type === 'receivable');
  }, [balancedAccounts]);

  const payableAccounts = useMemo(() => {
    return balancedAccounts.filter((acc) => acc.type === 'payable');
  }, [balancedAccounts]);

  // Accounts to show in the active detail panel
  const detailedAccounts = useMemo(() => {
    if (!activeDetail) return [];

    if (activeDetail === 'wallets') {
      return [...walletAccounts].sort(
        (a, b) => (b.currentBalance ?? b.openingBalance ?? 0) - (a.currentBalance ?? a.openingBalance ?? 0)
      );
    }

    if (activeDetail === 'receivables') {
      return [...receivableAccounts].sort(
        (a, b) => (b.currentBalance ?? b.openingBalance ?? 0) - (a.currentBalance ?? a.openingBalance ?? 0)
      );
    }

    if (activeDetail === 'payables') {
      return [...payableAccounts].sort(
        (a, b) => (b.currentBalance ?? b.openingBalance ?? 0) - (a.currentBalance ?? a.openingBalance ?? 0)
      );
    }

    return [];
  }, [activeDetail, walletAccounts, receivableAccounts, payableAccounts]);

  // Balance by specific account type
  const getWalletBalance = (type: AccountType): number => {
    return balancedAccounts
      .filter((acc) => acc.type === type)
      .reduce((sum, acc) => sum + (acc.currentBalance ?? acc.openingBalance ?? 0), 0);
  };

  const handleCategoryToggle = (category: DetailCategory) => {
    if (activeDetail === category) {
      setActiveDetail(null);
    } else {
      setActiveDetail(category);
    }
  };

  const handleSubtypeToggle = (type: AccountType) => {
    if (type === 'receivable') {
      handleCategoryToggle('receivables');
    } else if (type === 'payable') {
      handleCategoryToggle('payables');
    } else {
      setActiveDetail('wallets');
    }
  };

  const getAccountIconComponent = (type: AccountType) => {
    switch (type) {
      case 'cash':
        return Banknote;
      case 'mobile_banking':
        return Smartphone;
      case 'card':
        return CreditCard;
      case 'bank':
        return Landmark;
      case 'receivable':
        return ArrowDownLeft;
      case 'payable':
        return ArrowUpRight;
      default:
        return Wallet;
    }
  };

  const getAccountTypeLabel = (type: AccountType) => {
    switch (type) {
      case 'cash':
        return isEn ? 'Cash' : 'নগদ ক্যাশ';
      case 'mobile_banking':
        return isEn ? 'Mobile Wallet' : 'মোবাইল ওয়ালেট';
      case 'card':
        return isEn ? 'Card' : 'কার্ড ওয়ালেট';
      case 'bank':
        return isEn ? 'Bank Account' : 'ব্যাংক হিসাব';
      case 'receivable':
        return isEn ? 'Receivables (Loan)' : 'পাওনা টাকা';
      case 'payable':
        return isEn ? 'Payables (Debt)' : 'দেনা টাকা';
      default:
        return isEn ? 'Account' : 'হিসাব';
    }
  };

  const getAccountTypeColor = (type: AccountType) => {
    switch (type) {
      case 'cash':
        return '#10B981';
      case 'mobile_banking':
        return '#6366F1';
      case 'card':
        return '#F59E0B';
      case 'bank':
        return '#3B82F6';
      case 'receivable':
        return '#06B6D4';
      case 'payable':
        return '#EF4444';
      default:
        return '#8B5CF6';
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="accounts-balance-modal-backdrop"
      className={`fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 transition-all duration-200 ${
        isLight ? 'bg-slate-900/50 backdrop-blur-xs' : 'bg-slate-950/80 backdrop-blur-xs'
      } animate-in fade-in duration-200`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="accounts-balance-modal-content"
        className={`relative w-full max-w-lg max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-all duration-200 ${
          isLight
            ? 'bg-white border-sky-100 text-slate-900'
            : 'bg-slate-900 border-slate-700/80 text-slate-100'
        }`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="accounts-balance-modal-title"
      >
        {/* Modal Header */}
        <div
          id="accounts-balance-modal-header"
          className={`flex items-center justify-between px-5 sm:px-6 py-4 border-b shrink-0 ${
            isLight
              ? 'border-sky-100 bg-sky-50/70'
              : 'border-slate-800 bg-slate-800/60'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className="p-2.5 rounded-2xl shadow-xs"
              style={dualAccent.iconBoxPrimaryStyle}
            >
              <Wallet className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div>
              <h2
                id="accounts-balance-modal-title"
                className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2"
              >
                <span>{isEn ? 'Accounts Balance' : 'একাউন্টস ব্যালেন্স'}</span>
                <span
                  className="text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full"
                  style={{
                    backgroundColor: `${dualAccent.primary.hex}20`,
                    color: dualAccent.primary.hex,
                  }}
                >
                  {isEn ? 'Summary' : 'সারসংক্ষেপ'}
                </span>
              </h2>
              <p
                className={`text-xs font-medium ${
                  isLight ? 'text-slate-500' : 'text-slate-400'
                }`}
              >
                {isEn
                  ? 'Overview of wallets, accounts & ledger balances'
                  : 'সকল ওয়ালেট, ব্যাংক হিসাব এবং দেনা-পাওনা লেজারের ব্যালেন্স'}
              </p>
            </div>
          </div>

          <button
            id="accounts-balance-modal-close-btn"
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className={`p-2 rounded-full transition-colors cursor-pointer ${
              isLight
                ? 'text-slate-400 hover:text-slate-700 hover:bg-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {/* Top Summary Metrics Cards - Clean original interface appearance, touchable */}
          <div
            id="accounts-summary-cards-grid"
            className="grid grid-cols-2 sm:grid-cols-4 gap-2.5"
          >
            {/* Net Balance */}
            <div
              className={`p-3 rounded-2xl border ${
                isLight
                  ? 'bg-sky-50/50 border-sky-100'
                  : 'bg-slate-800/50 border-slate-800'
              }`}
            >
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500 mb-1">
                <Scale className="w-3.5 h-3.5 text-sky-500 shrink-0" />
                <span className="truncate">{isEn ? 'Net Balance' : 'নিট স্থিতি'}</span>
              </div>
              <div
                className="text-sm sm:text-base font-black truncate"
                style={{ color: dualAccent.primary.hex }}
              >
                {formatCurrency(summary.netBalance, useBanglaDigits, appSettings.currencySymbol)}
              </div>
            </div>

            {/* Wallets & Bank */}
            <div
              id="accounts-card-wallets"
              onClick={() => setActiveDetail('wallets')}
              className={`p-3 rounded-2xl border cursor-pointer active:scale-95 transition-all duration-150 hover:shadow-xs select-none ${
                isLight
                  ? 'bg-emerald-50/50 border-emerald-100 hover:bg-emerald-100/60'
                  : 'bg-emerald-950/20 border-emerald-900/50 hover:bg-emerald-950/40'
              }`}
              title={isEn ? 'Touch to view Wallets & Bank details' : 'ওয়ালেট ও ব্যাংক বিস্তারিত দেখতে টাচ করুন'}
            >
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 mb-1">
                <Wallet className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{isEn ? 'Wallets / Bank' : 'ওয়ালেট/ব্যাংক'}</span>
              </div>
              <div className="text-sm sm:text-base font-black text-emerald-600 dark:text-emerald-400 truncate">
                {formatCurrency(summary.walletTotal, useBanglaDigits, appSettings.currencySymbol)}
              </div>
            </div>

            {/* Receivable (Loans Given) */}
            <div
              id="accounts-card-receivables"
              onClick={() => setActiveDetail('receivables')}
              className={`p-3 rounded-2xl border cursor-pointer active:scale-95 transition-all duration-150 hover:shadow-xs select-none ${
                isLight
                  ? 'bg-cyan-50/50 border-cyan-100 hover:bg-cyan-100/60'
                  : 'bg-cyan-950/20 border-cyan-900/50 hover:bg-cyan-950/40'
              }`}
              title={isEn ? 'Touch to view Receivables details' : 'ধার দেওয়া (পাওনা) বিস্তারিত দেখতে টাচ করুন'}
            >
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-600 dark:text-cyan-400 mb-1">
                <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{isEn ? 'Receivables' : 'ধার দেওয়া (পাওনা)'}</span>
              </div>
              <div className="text-sm sm:text-base font-black text-cyan-600 dark:text-cyan-400 truncate">
                {formatCurrency(summary.receivableTotal, useBanglaDigits, appSettings.currencySymbol)}
              </div>
            </div>

            {/* Payable */}
            <div
              id="accounts-card-payables"
              onClick={() => setActiveDetail('payables')}
              className={`p-3 rounded-2xl border cursor-pointer active:scale-95 transition-all duration-150 hover:shadow-xs select-none ${
                isLight
                  ? 'bg-rose-50/50 border-rose-100 hover:bg-rose-100/60'
                  : 'bg-rose-950/20 border-rose-900/50 hover:bg-rose-950/40'
              }`}
              title={isEn ? 'Touch to view Payables details' : 'ধার নেওয়া (দেনা) বিস্তারিত দেখতে টাচ করুন'}
            >
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-rose-600 dark:text-rose-400 mb-1">
                <TrendingDown className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{isEn ? 'Payables' : 'ধার নেওয়া (দেনা)'}</span>
              </div>
              <div className="text-sm sm:text-base font-black text-rose-600 dark:text-rose-400 truncate">
                {formatCurrency(summary.payableTotal, useBanglaDigits, appSettings.currencySymbol)}
              </div>
            </div>
          </div>

          {/* Section: Wallets Summary Card (Single Column format) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between px-1">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Wallet className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                <span>{isEn ? 'Wallets Summary' : 'ওয়ালেট সারসংক্ষেপ'}</span>
              </span>
              <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                {formatCurrency(summary.walletTotal, useBanglaDigits, appSettings.currencySymbol)}
              </span>
            </div>

            <div
              id="modal-wallets-summary-box"
              className={`rounded-2xl border p-2.5 sm:p-3 transition-colors ${
                isLight
                  ? 'bg-white border-sky-100 shadow-2xs'
                  : 'bg-slate-800/80 border-slate-700/80 shadow-2xs'
              }`}
            >
              <div className="space-y-1.5">
                {WALLET_SUMMARY_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const balance = getWalletBalance(item.type);
                  return (
                    <div
                      key={item.type}
                      onClick={() => handleSubtypeToggle(item.type)}
                      className={`flex items-center justify-between gap-2 px-2.5 py-2 rounded-xl transition-colors cursor-pointer select-none ${
                        isLight ? 'hover:bg-sky-50/70 active:bg-sky-100/70' : 'hover:bg-slate-700/50 active:bg-slate-700'
                      }`}
                      title={`${isEn ? item.label : item.labelBangla}: ${formatCurrency(balance, useBanglaDigits, appSettings.currencySymbol)} (${isEn ? 'Touch to view details' : 'বিস্তারিত দেখতে টাচ করুন'})`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className="p-1.5 rounded-lg shrink-0 flex items-center justify-center"
                          style={{
                            backgroundColor: `${item.color}18`,
                            color: item.color,
                          }}
                        >
                          <Icon className="w-4 h-4" />
                        </div>
                        <span className={`text-xs sm:text-sm font-bold truncate ${isLight ? 'text-slate-700' : 'text-slate-200'}`}>
                          {isEn ? item.label : item.labelBangla}
                        </span>
                      </div>
                      <span
                        className={`text-xs sm:text-sm font-black shrink-0 ${
                          isLight ? 'text-slate-900' : 'text-white'
                        }`}
                      >
                        {formatCurrency(balance, useBanglaDigits, appSettings.currencySymbol)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Action: Open Loans & Debts (দেনা/পাওনা) Page button */}
          {onNavigateToLoan && (
            <button
              id="modal-open-loans-debts-btn"
              type="button"
              onClick={() => {
                onClose();
                onNavigateToLoan();
              }}
              className="w-full py-2.5 px-3 rounded-2xl border border-sky-300 dark:border-slate-700 bg-sky-50 dark:bg-slate-800 hover:bg-sky-100 dark:hover:bg-slate-750 text-sky-800 dark:text-sky-300 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-98 cursor-pointer shadow-2xs"
            >
              <span>{isEn ? 'Open Loans & Debts (দেনা/পাওনা) Page' : 'Open Loans & Debts (দেনা/পাওনা) Page'}</span>
              <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
            </button>
          )}
        </div>

        {/* Modal Footer */}
        <div
          id="accounts-balance-modal-footer"
          className={`px-5 sm:px-6 py-3.5 border-t shrink-0 flex items-center justify-between ${
            isLight
              ? 'border-sky-100 bg-sky-50/50'
              : 'border-slate-800 bg-slate-800/40'
          }`}
        >
          <div className="text-[11px] font-semibold text-slate-500 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>
              {isEn
                ? 'All accounts are balanced with transactions'
                : 'সব হিসাব লেনদেনের সাথে সমন্বয়কৃত'}
            </span>
          </div>
          <button
            id="accounts-balance-modal-ok-btn"
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold text-white shadow-xs hover:opacity-90 active:scale-95 transition cursor-pointer"
            style={{ backgroundColor: dualAccent.primary.hex }}
          >
            {isEn ? 'Close' : 'ঠিক আছে'}
          </button>
        </div>

        {/* Dedicated Animated Slide-Up Detail View (শুধুমাত্র টাচ করার পর নতুন একটি প্রভাব এর মাধ্যমে ভিউ হবে) */}
        <AnimatePresence>
          {activeDetail && (
            <motion.div
              id="accounts-detail-animated-sheet"
              initial={{ y: '100%', opacity: 0.3 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 28, stiffness: 320 }}
              className={`absolute inset-0 z-30 flex flex-col rounded-3xl overflow-hidden shadow-2xl ${
                isLight ? 'bg-white text-slate-900' : 'bg-slate-900 text-slate-100'
              }`}
            >
              {/* Top Grab / Handle Bar */}
              <div className="pt-2.5 pb-1 flex justify-center shrink-0">
                <div className={`w-12 h-1.5 rounded-full ${isLight ? 'bg-slate-300' : 'bg-slate-700'}`} />
              </div>

              {/* Detail View Header */}
              <div
                className={`flex items-center justify-between px-4 sm:px-6 py-3 border-b shrink-0 ${
                  activeDetail === 'wallets'
                    ? isLight ? 'bg-emerald-50/80 border-emerald-100' : 'bg-emerald-950/40 border-emerald-900/50'
                    : activeDetail === 'receivables'
                    ? isLight ? 'bg-cyan-50/80 border-cyan-100' : 'bg-cyan-950/40 border-cyan-900/50'
                    : isLight ? 'bg-rose-50/80 border-rose-100' : 'bg-rose-950/40 border-rose-900/50'
                }`}
              >
                <button
                  id="accounts-detail-back-btn"
                  type="button"
                  onClick={() => setActiveDetail(null)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isLight
                      ? 'bg-white/90 hover:bg-white text-slate-700 shadow-2xs active:scale-95'
                      : 'bg-slate-800/90 hover:bg-slate-800 text-slate-200 shadow-2xs active:scale-95'
                  }`}
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{isEn ? 'Back' : 'ফিরে যান'}</span>
                </button>

                <div className="text-center min-w-0 px-2">
                  <h3 className="text-sm sm:text-base font-black truncate">
                    {activeDetail === 'wallets'
                      ? isEn ? 'Wallets & Bank Details' : 'ওয়ালেট ও ব্যাংক বিস্তারিত'
                      : activeDetail === 'receivables'
                      ? isEn ? 'Receivables' : 'ধার দেওয়া (পাওনা) বিস্তারিত'
                      : isEn ? 'Payables' : 'ধার নেওয়া (দেনা) বিস্তারিত'}
                  </h3>
                  <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
                    {detailedAccounts.length} {isEn ? 'accounts' : 'টি হিসাব'}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveDetail(null)}
                  className={`p-2 rounded-full transition-colors cursor-pointer ${
                    isLight
                      ? 'text-slate-400 hover:text-slate-700 hover:bg-white'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                  aria-label="Close detail view"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Detail Content Body */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
                {/* Hero Total Card inside Detail */}
                <div
                  className={`p-4 rounded-2xl border ${
                    activeDetail === 'wallets'
                      ? isLight ? 'bg-emerald-50/50 border-emerald-200' : 'bg-emerald-950/20 border-emerald-900/50'
                      : activeDetail === 'receivables'
                      ? isLight ? 'bg-cyan-50/50 border-cyan-200' : 'bg-cyan-950/20 border-cyan-900/50'
                      : isLight ? 'bg-rose-50/50 border-rose-200' : 'bg-rose-950/20 border-rose-900/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-slate-500 dark:text-slate-400">
                        {activeDetail === 'wallets'
                          ? isEn
                            ? 'Total Wallets & Bank Balance'
                            : 'মোট ওয়ালেট ও ব্যাংক ব্যালেন্স'
                          : activeDetail === 'receivables'
                          ? isEn
                            ? 'Total Receivables'
                            : 'মোট ধার দেওয়া (পাওনা)'
                          : isEn
                          ? 'Total Payables'
                          : 'মোট ধার নেওয়া (দেনা)'}
                      </div>
                      <div
                        className={`text-xl sm:text-2xl font-black mt-0.5 ${
                          activeDetail === 'wallets'
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : activeDetail === 'receivables'
                            ? 'text-cyan-600 dark:text-cyan-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {formatCurrency(
                          activeDetail === 'wallets'
                            ? summary.walletTotal
                            : activeDetail === 'receivables'
                            ? summary.receivableTotal
                            : summary.payableTotal,
                          useBanglaDigits,
                          appSettings.currencySymbol
                        )}
                      </div>
                    </div>
                    <div
                      className="p-3 rounded-2xl shadow-xs"
                      style={{
                        backgroundColor:
                          activeDetail === 'wallets' ? '#10B98120' : activeDetail === 'receivables' ? '#06B6D420' : '#EF444420',
                        color:
                          activeDetail === 'wallets' ? '#10B981' : activeDetail === 'receivables' ? '#06B6D4' : '#EF4444',
                      }}
                    >
                      {activeDetail === 'wallets' && <Wallet className="w-6 h-6" />}
                      {activeDetail === 'receivables' && <TrendingUp className="w-6 h-6" />}
                      {activeDetail === 'payables' && <TrendingDown className="w-6 h-6" />}
                    </div>
                  </div>
                </div>

                {/* Accounts List Cards */}
                <div className="space-y-2">
                  {detailedAccounts.length === 0 ? (
                    <div className="text-center py-12 text-sm text-slate-400 font-medium">
                      {isEn ? 'No accounts found in this section.' : 'এই সেকশনে এখনো কোনো হিসাব যুক্ত করা হয়নি।'}
                    </div>
                  ) : (
                    detailedAccounts.map((acc) => {
                      const IconComponent = getAccountIconComponent(acc.type);
                      const typeColor = getAccountTypeColor(acc.type);
                      const balance = acc.currentBalance ?? acc.openingBalance ?? 0;
                      const totalForCat =
                        activeDetail === 'wallets'
                          ? summary.walletTotal
                          : activeDetail === 'receivables'
                          ? summary.receivableTotal
                          : summary.payableTotal;
                      const pct = totalForCat > 0 ? Math.min(100, Math.max(0, Math.round((balance / totalForCat) * 100))) : 0;

                      return (
                        <div
                          key={acc.id}
                          className={`p-3 rounded-2xl border transition-all ${
                            isLight
                              ? 'bg-white border-slate-200/80 shadow-2xs hover:shadow-xs'
                              : 'bg-slate-800/80 border-slate-700/80 shadow-2xs hover:shadow-xs'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              <div
                                className="p-2.5 rounded-xl shrink-0 flex items-center justify-center shadow-2xs"
                                style={{
                                  backgroundColor: `${typeColor}18`,
                                  color: typeColor,
                                }}
                              >
                                <IconComponent className="w-4 h-4 sm:w-5 sm:h-5" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className={`text-sm font-bold truncate ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
                                    {isEn ? (acc.nameEnglish || acc.nameBangla) : (acc.nameBangla || acc.nameEnglish)}
                                  </span>
                                  {acc.isDefault && (
                                    <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-sky-500/15 text-sky-500">
                                      {isEn ? 'Default' : 'ডিফল্ট'}
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex-wrap">
                                  <span>{getAccountTypeLabel(acc.type)}</span>
                                  {(acc.institutionName || acc.accountNumber) && (
                                    <>
                                      <span>•</span>
                                      <span className="truncate max-w-[160px]">
                                        {acc.institutionName || ''} {acc.accountNumber ? `(${acc.accountNumber})` : ''}
                                      </span>
                                    </>
                                  )}
                                  {acc.notes && !acc.institutionName && !acc.accountNumber && (
                                    <>
                                      <span>•</span>
                                      <span className="truncate max-w-[160px]">{acc.notes}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="text-right shrink-0 flex flex-col items-end">
                              <div
                                className={`text-sm sm:text-base font-black ${
                                  acc.type === 'receivable'
                                    ? 'text-cyan-600 dark:text-cyan-400'
                                    : acc.type === 'payable'
                                    ? 'text-rose-600 dark:text-rose-400'
                                    : isLight
                                    ? 'text-slate-900'
                                    : 'text-white'
                                }`}
                              >
                                {formatCurrency(balance, useBanglaDigits, appSettings.currencySymbol)}
                              </div>
                              {totalForCat > 0 && (
                                <div className="flex items-center gap-1.5 mt-1">
                                  {/* Compact bar in front of % */}
                                  <div className="w-12 sm:w-14 h-1.5 bg-slate-200/70 dark:bg-slate-700/60 rounded-full overflow-hidden">
                                    <div
                                      className="h-full rounded-full transition-all duration-300"
                                      style={{
                                        width: `${pct}%`,
                                        backgroundColor: typeColor,
                                      }}
                                    />
                                  </div>
                                  <span className="text-[10px] font-semibold text-slate-400">
                                    {useBanglaDigits ? pct.toLocaleString('bn-BD') : pct}%
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Detail Footer */}
              <div
                className={`px-5 py-3 border-t shrink-0 flex items-center justify-between ${
                  isLight ? 'border-slate-100 bg-slate-50/80' : 'border-slate-800 bg-slate-800/60'
                }`}
              >
                <div className="text-xs text-slate-500 font-semibold">
                  {detailedAccounts.length} {isEn ? 'accounts listed' : 'টি হিসাব প্রদর্শিত'}
                </div>
                <button
                  type="button"
                  onClick={() => setActiveDetail(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white shadow-xs hover:opacity-90 active:scale-95 transition cursor-pointer"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {isEn ? 'Back to Overview' : 'ফিরে যান'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
