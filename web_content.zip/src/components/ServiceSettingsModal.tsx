import React, { useState } from 'react';
import { X, Church, Sparkles, User, Calendar, AlertTriangle } from 'lucide-react';
import { useChurch } from '../context/ChurchContext';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ServiceSettingsModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { service, updateService, visitors } = useChurch();

  const [churchName, setChurchName] = useState(service.churchName || 'Nossa Igreja');
  const [title, setTitle] = useState(service.title || 'Culto de Celebração');
  const [leaderName, setLeaderName] = useState(service.leaderName || 'Pastor Dirigente');
  const [notes, setNotes] = useState(service.notes || '');

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateService({
      churchName: churchName.trim(),
      title: title.trim(),
      leaderName: leaderName.trim(),
      notes: notes.trim(),
    });
    onClose();
  };

  const presetTitles = [
    'Culto da Família',
    'Culto de Doutrina e Ensino',
    'Culto de Libertação & Milagres',
    'Culto de Jovens (Geração Eleita)',
    'Culto de Oração & Círculo de Oração',
    'Culto de Santa Ceia do Senhor',
    'Culto de Domingo Matutino',
    'Culto de Domingo Noturno',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-neutral-900 border border-neutral-800 p-6 text-white shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-2 text-neutral-400 hover:bg-neutral-800 hover:text-white transition"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Church className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Configuração do Culto</h3>
            <p className="text-xs text-neutral-400">Dados exibidos no cabeçalho dos dois tablets</p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5 flex items-center gap-1.5">
              <Church className="h-4 w-4 text-amber-400" /> Nome da Igreja / Ministério
            </label>
            <input
              type="text"
              value={churchName}
              onChange={(e) => setChurchName(e.target.value)}
              placeholder="Ex: Igreja Evangélica Assembleia de Deus"
              className="w-full rounded-xl bg-neutral-800 border border-neutral-700 px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5 flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-amber-400" /> Tipo / Nome do Culto
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Culto de Domingo Noite"
              className="w-full rounded-xl bg-neutral-800 border border-neutral-700 px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 mb-2"
              required
            />
            {/* Quick presets */}
            <div className="flex flex-wrap gap-1.5">
              {presetTitles.slice(0, 4).map((p) => (
                <button
                  type="button"
                  key={p}
                  onClick={() => setTitle(p)}
                  className="rounded-lg bg-neutral-800/80 hover:bg-neutral-700 px-2.5 py-1 text-[11px] text-neutral-300 border border-neutral-700/60 transition"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5 flex items-center gap-1.5">
              <User className="h-4 w-4 text-amber-400" /> Pastor Dirigente / Líder
            </label>
            <input
              type="text"
              value={leaderName}
              onChange={(e) => setLeaderName(e.target.value)}
              placeholder="Ex: Pastor Carlos Andrade"
              className="w-full rounded-xl bg-neutral-800 border border-neutral-700 px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5">
              Tema da Mensagem / Observações Gerais
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: 'A Fé que Move Montanhas' - Hebreus 11"
              className="w-full rounded-xl bg-neutral-800 border border-neutral-700 px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
          </div>

          <div className="rounded-xl bg-neutral-800/60 p-3 text-xs text-neutral-400 border border-neutral-700/50">
            Total de visitantes registrados hoje: <strong className="text-white">{visitors.length}</strong>
          </div>

          <div className="mt-6 flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl bg-neutral-800 py-3 text-sm font-semibold text-neutral-300 hover:bg-neutral-700 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 rounded-xl bg-amber-500 py-3 text-sm font-bold text-neutral-950 hover:bg-amber-400 transition shadow-lg shadow-amber-500/20"
            >
              Salvar Alterações
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
