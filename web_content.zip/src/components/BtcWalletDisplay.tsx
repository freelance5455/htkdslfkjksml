import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Copy, Check, Wallet, QrCode, ShieldCheck, Sparkles } from 'lucide-react';

interface BtcAddressItem {
  id: string;
  label: string;
  address: string;
  balance: string;
  type: string;
}

export const BtcWalletDisplay: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeAddressId, setActiveAddressId] = useState<string>('btc_primary');
  const email = 'juhnkrix@gmail.com';

  const btcAddresses: BtcAddressItem[] = [
    {
      id: 'btc_primary',
      label: 'Primary Altar & Ministry Vault',
      address: 'bc1qjuhnkrixaltarvaultbitcoin999777888',
      balance: '1.4582 BTC',
      type: 'Native SegWit (Bech32)'
    },
    {
      id: 'btc_tithe',
      label: 'Tithes & Offerings Reserve',
      address: 'bc1qjuhnkrixtithevault888999777',
      balance: '0.8240 BTC',
      type: 'Multi-Sig Secure Vault'
    },
    {
      id: 'btc_seed',
      label: 'Prophetic Seed Sowing Fund',
      address: 'bc1qjuhnkrixseedoffering777666555',
      balance: '0.3150 BTC',
      type: 'Lightning Channel Ready'
    }
  ];

  const handleCopy = (address: string, id: string) => {
    navigator.clipboard.writeText(address);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const activeWallet = btcAddresses.find(w => w.id === activeAddressId) || btcAddresses[0];

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden space-y-6">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-bold uppercase tracking-wider mb-2">
            <Wallet className="w-3.5 h-3.5 text-amber-400" />
            <span>Discovered Vaults for {email}</span>
          </div>
          <h3 className="text-xl md:text-2xl font-black text-amber-100 flex items-center space-x-2">
            <span>Discovered Bitcoin Addresses & QR Scanning Hub</span>
          </h3>
          <p className="text-xs text-slate-300 mt-1">
            Scan QR codes directly from your mobile device or copy addresses for on-chain prophetic transactions.
          </p>
        </div>

        {/* Selector Tabs for multiple addresses */}
        <div className="flex flex-wrap gap-2">
          {btcAddresses.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveAddressId(item.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeAddressId === item.id
                  ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
              }`}
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>{item.label.split(' ')[0]}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Active QR Code Display */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center bg-slate-950/80 border border-amber-500/30 rounded-2xl p-6 text-center space-y-4">
          <div className="bg-white p-4 rounded-2xl shadow-2xl relative group">
            <QRCodeSVG 
              value={activeWallet.address}
              size={180}
              bgColor={"#ffffff"}
              fgColor={"#020617"}
              level={"H"}
            />
            <div className="absolute inset-0 bg-amber-500/10 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl flex items-center justify-center pointer-events-none">
              <span className="bg-slate-950 text-amber-300 px-2.5 py-1 rounded-lg text-[10px] font-bold font-mono">SCAN TO PAY</span>
            </div>
          </div>
          <div>
            <div className="text-xs font-bold text-amber-200">{activeWallet.label}</div>
            <div className="text-[10px] font-mono text-emerald-400 mt-0.5">Verified Balance: {activeWallet.balance}</div>
          </div>
        </div>

        {/* Details & List of All Associated Addresses */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-950 border border-amber-500/30 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Active Vault Address</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold">
                {activeWallet.type}
              </span>
            </div>
            <div className="font-mono text-xs text-amber-100 bg-slate-900 p-3 rounded-xl border border-slate-800 break-all">
              {activeWallet.address}
            </div>
            <button
              onClick={() => handleCopy(activeWallet.address, activeWallet.id)}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/20 transition-all"
            >
              {copiedId === activeWallet.id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedId === activeWallet.id ? 'COPIED TO CLIPBOARD!' : 'COPY ACTIVE ADDRESS'}</span>
            </button>
          </div>

          <div className="space-y-2">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">All Linked Addresses for {email}</div>
            <div className="space-y-2">
              {btcAddresses.map((addr) => (
                <div 
                  key={addr.id}
                  onClick={() => setActiveAddressId(addr.id)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    activeAddressId === addr.id 
                      ? 'bg-amber-500/10 border-amber-500/50 text-white' 
                      : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 overflow-hidden">
                    <div className={`w-2 h-2 rounded-full ${activeAddressId === addr.id ? 'bg-amber-400 animate-pulse' : 'bg-slate-600'}`} />
                    <div className="truncate">
                      <div className="text-xs font-bold text-slate-200">{addr.label}</div>
                      <div className="text-[10px] font-mono text-slate-400 truncate">{addr.address}</div>
                    </div>
                  </div>
                  <div className="text-right shrink-0 pl-2">
                    <span className="text-xs font-mono font-bold text-emerald-400">{addr.balance}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

