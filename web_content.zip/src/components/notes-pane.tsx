import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";

export function NotesPane() {
  const notes = useAppStore((s) => s.notes);
  const addNote = useAppStore((s) => s.addNote);
  const updateNote = useAppStore((s) => s.updateNote);
  const removeNote = useAppStore((s) => s.removeNote);
  const setTab = useAppStore((s) => s.setTab);
  const setDraft = useAppStore((s) => s.setDraft);
  const [activeId, setActiveId] = useState<string | null>(notes[0]?.id ?? null);
  const active = notes.find((n) => n.id === activeId) ?? notes[0];

  return (
    <div className="mx-auto flex w-full max-w-lg flex-1 flex-col gap-4 overflow-y-auto px-4 pb-8 pt-2">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">Notes</p>
          <h2 className="font-display mt-1 text-3xl tracking-[-0.03em] text-fg">
            Kept on this phone
          </h2>
        </div>
        <Button
          size="icon"
          aria-label="New note"
          onClick={() => {
            addNote("New note", "");
            const latest = useAppStore.getState().notes[0];
            setActiveId(latest?.id ?? null);
          }}
        >
          <Plus className="size-4" />
        </Button>
      </header>
      <p className="text-sm leading-relaxed text-muted">
        Notes live in this browser. They are not uploaded unless you ask Mira
        about one.
      </p>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {notes.map((note) => (
          <button
            key={note.id}
            type="button"
            onClick={() => setActiveId(note.id)}
            className={
              note.id === active?.id
                ? "h-9 shrink-0 rounded-full bg-accent px-3.5 text-sm font-medium text-accent-fg"
                : "h-9 shrink-0 rounded-full bg-raised px-3.5 text-sm text-muted shadow-[var(--shadow-border)]"
            }
          >
            {note.title || "Untitled"}
          </button>
        ))}
      </div>

      {active ? (
        <div className="flex min-h-0 flex-1 flex-col gap-3 rounded-xl bg-raised p-3 shadow-[var(--shadow-border)]">
          <input
            value={active.title}
            onChange={(e) => updateNote(active.id, { title: e.target.value })}
            className="h-11 rounded-lg bg-surface px-3 text-base font-medium text-fg outline-none"
            placeholder="Title"
          />
          <textarea
            value={active.body}
            onChange={(e) => updateNote(active.id, { body: e.target.value })}
            className="min-h-48 flex-1 resize-none rounded-lg bg-surface px-3 py-3 text-sm leading-relaxed text-fg outline-none placeholder:text-faint"
            placeholder="Write something to keep…"
          />
          <div className="flex gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => {
                setDraft(
                  `Use this note titled “${active.title}”:\n\n${active.body}`,
                );
                setTab("ask");
              }}
            >
              Ask Mira
            </Button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Delete note"
              onClick={() => {
                removeNote(active.id);
                setActiveId(useAppStore.getState().notes[0]?.id ?? null);
              }}
            >
              <Trash2 className="size-4" />
            </Button>
          </div>
        </div>
      ) : (
        <p className="text-sm text-muted">No notes yet.</p>
      )}
    </div>
  );
}
