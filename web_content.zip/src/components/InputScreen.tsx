import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Link as LinkIcon,
  Upload,
  Image as ImageIcon,
  Zap,
  ShoppingBag,
  Sliders,
  ScanEye,
  X,
  Flame,
  Check
} from 'lucide-react';
import { ProductInput } from '../types';
import { PRESET_PRODUCTS, HOOK_STYLES, PresetProduct } from '../data/presets';

interface InputScreenProps {
  onSubmit: (input: ProductInput) => void;
  isLoading: boolean;
}

export const InputScreen: React.FC<InputScreenProps> = ({ onSubmit, isLoading }) => {
  const [productName, setProductName] = useState('');
  const [productUrl, setProductUrl] = useState('');
  const [category, setCategory] = useState('Beauty & Skincare');
  const [offer, setOffer] = useState('Use code VIRAL20 for 20% OFF');
  const [hookStyle, setHookStyle] = useState('Stop Scrolling Hook');
  const [persona, setPersona] = useState('Gen-Z Beauty Creator');
  const [tone, setTone] = useState('Enthusiastic, authentic, high-energy');
  const [images, setImages] = useState<string[]>([]);
  const [analyzingImage, setAnalyzingImage] = useState(false);
  const [visionInsight, setVisionInsight] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const categories = [
    'Beauty & Skincare',
    'Tech & Gadgets',
    'Fitness & Wellness',
    'Fashion & Apparel',
    'Home & Kitchen',
    'Pet Care & Lifestyle',
  ];

  const handleApplyPreset = (preset: PresetProduct) => {
    setProductName(preset.name);
    setProductUrl(preset.url);
    setCategory(preset.category);
    setOffer(preset.offer);
    setHookStyle(preset.hookStyle);
    setPersona(preset.persona);
    setTone(preset.tone);
    setImages([preset.imageUrl]);
    setVisionInsight(`Loaded preset: ${preset.name} with ${preset.sampleBenefits.length} key benefits`);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setImages((prev) => [...prev, result]);
          // Auto analyze with Gemini Vision
          analyzeUploadedImage(result, file.type);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const analyzeUploadedImage = async (base64Data: string, mimeType: string) => {
    try {
      setAnalyzingImage(true);
      // Remove data URL prefix if present for server
      const cleanBase64 = base64Data.split(',')[1] || base64Data;
      const res = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: cleanBase64, mimeType }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.productTitle && !productName) {
          setProductName(data.productTitle);
        }
        if (data.category) {
          setCategory(data.category);
        }
        setVisionInsight(
          `AI Detected: ${data.productTitle || 'Product'} · Aesthetic: ${data.aestheticTone || 'Clean'} · ${
            data.suggestedHooks?.[0] || 'Viral Ready'
          }`
        );
      }
    } catch (err) {
      console.warn('Vision analysis skipped or failed:', err);
    } finally {
      setAnalyzingImage(false);
    }
  };

  const handleRemoveImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName && !productUrl && images.length === 0) {
      return;
    }
    onSubmit({
      name: productName,
      url: productUrl,
      category,
      offer,
      persona,
      tone,
      hookStyle,
      images,
    });
  };

  return (
    <div className="w-full glass-panel rounded-3xl p-5 sm:p-7 border border-white/10 shadow-[0_12px_45px_rgba(0,0,0,0.6)] relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-gradient-to-br from-indigo-500/15 via-cyan-500/10 to-transparent blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-gradient-to-tr from-pink-500/10 via-purple-500/10 to-transparent blur-3xl pointer-events-none" />

      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-6 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold tracking-wider uppercase font-mono flex items-center gap-1">
              <Zap className="w-3 h-3 text-cyan-400" />
              E-Commerce Video Engine
            </span>
            <span className="text-xs text-slate-400">Step 1 of 2</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Create Your 16s UGC Ad
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Input product info or drop an image. Gemini search grounding handles trending hooks, benefits, and script.
          </p>
        </div>

        {/* Quick presets label */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-white/[0.04] border border-white/[0.08] text-xs text-slate-300 self-start sm:self-auto">
          <Flame className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
          <span className="font-semibold text-[11px]">Instant Viral Presets</span>
        </div>
      </div>

      {/* Preset quick buttons */}
      <div className="py-4 border-b border-white/[0.06]">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
          Try a trending demo product:
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {PRESET_PRODUCTS.map((preset) => (
            <button
              key={preset.name}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="flex items-center gap-2.5 p-2 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.06] hover:border-cyan-500/40 text-left transition-all group"
            >
              <img
                src={preset.imageUrl}
                alt={preset.name}
                className="w-9 h-9 rounded-lg object-cover border border-white/10 group-hover:scale-105 transition-transform"
              />
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-slate-200 truncate group-hover:text-cyan-300">
                  {preset.name}
                </p>
                <p className="text-[10px] text-slate-400 truncate">{preset.category}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-5 space-y-5">
        {/* Product Name & URL */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Product Name <span className="text-rose-400">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g. PureGlow Lip Glaze, AeroGlide Magnetic Charger"
                className="w-full glass-input rounded-xl px-3.5 py-2.5 text-sm pl-10 placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500"
                required
              />
              <ShoppingBag className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Product URL <span className="text-slate-500 text-[10px] font-normal">(Optional for Search Grounding)</span>
            </label>
            <div className="relative">
              <input
                type="url"
                value={productUrl}
                onChange={(e) => setProductUrl(e.target.value)}
                placeholder="https://yourstore.com/products/viral-item"
                className="w-full glass-input rounded-xl px-3.5 py-2.5 text-sm pl-10 placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500"
              />
              <LinkIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            </div>
          </div>
        </div>

        {/* Category Pill Selector */}
        <div>
          <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
            E-Commerce Category
          </label>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  category === cat
                    ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-[0_0_15px_rgba(6,182,212,0.35)] border border-cyan-400/50'
                    : 'bg-white/[0.04] text-slate-300 hover:bg-white/[0.08] border border-white/[0.08]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Image Assets Upload */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <ImageIcon className="w-4 h-4 text-cyan-400" />
              Product Photo / Asset
              <span className="text-[10px] font-normal text-slate-400">(Auto-animated into 9:16 Video)</span>
            </label>
            {analyzingImage && (
              <span className="text-xs text-cyan-400 animate-pulse flex items-center gap-1">
                <ScanEye className="w-3.5 h-3.5" />
                Gemini Vision analyzing...
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {/* Upload dropzone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="sm:col-span-2 border-2 border-dashed border-white/15 hover:border-cyan-500/50 rounded-2xl p-4 text-center cursor-pointer transition-all bg-white/[0.02] hover:bg-white/[0.05] flex flex-col items-center justify-center min-h-[110px]"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileChange}
                className="hidden"
              />
              <Upload className="w-6 h-6 text-cyan-400 mb-1.5" />
              <p className="text-xs font-semibold text-slate-200">
                Click to upload product image
              </p>
              <p className="text-[10px] text-slate-400 mt-0.5">
                PNG, JPG, WebP supported
              </p>
            </div>

            {/* Uploaded images previews */}
            <div className="sm:col-span-2 flex flex-wrap gap-2.5 items-center">
              {images.map((img, idx) => (
                <div key={idx} className="relative group w-24 h-24 rounded-xl overflow-hidden border border-white/20">
                  <img src={img} alt="Product upload" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => handleRemoveImage(idx)}
                    className="absolute top-1 right-1 p-1 rounded-full bg-black/70 text-white hover:bg-rose-600 transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {images.length === 0 && (
                <div className="text-xs text-slate-500 italic p-3">
                  No custom image uploaded yet. (Preset image or AI visual background will be used)
                </div>
              )}
            </div>
          </div>

          {visionInsight && (
            <div className="mt-2 p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/25 text-xs text-cyan-200 flex items-center gap-2">
              <ScanEye className="w-4 h-4 text-cyan-400 shrink-0" />
              <span className="truncate">{visionInsight}</span>
            </div>
          )}
        </div>

        {/* Viral Hook Angle & Offer Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Opening Hook Style (0-3s)
            </label>
            <select
              value={hookStyle}
              onChange={(e) => setHookStyle(e.target.value)}
              className="w-full glass-input rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-cyan-500 bg-[#0d101c]"
            >
              {HOOK_STYLES.map((h) => (
                <option key={h.id} value={h.name} className="bg-slate-900 text-slate-100">
                  {h.name} — ({h.tag})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Special Offer / Urgency CTA
            </label>
            <input
              type="text"
              value={offer}
              onChange={(e) => setOffer(e.target.value)}
              placeholder="e.g. Code TIKTOK20 for 20% OFF"
              className="w-full glass-input rounded-xl px-3.5 py-2.5 text-xs placeholder:text-slate-500 focus:ring-2 focus:ring-cyan-500"
            />
          </div>
        </div>

        {/* Submit action */}
        <div className="pt-3">
          <button
            type="submit"
            disabled={isLoading || (!productName && images.length === 0)}
            className="w-full relative group overflow-hidden py-3.5 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 via-cyan-500 to-pink-500 text-white font-extrabold text-sm sm:text-base tracking-wide shadow-[0_0_30px_rgba(99,102,241,0.4)] hover:shadow-[0_0_40px_rgba(6,182,212,0.6)] transition-all active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2.5"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 pointer-events-none" />
            <Sparkles className="w-5 h-5 text-yellow-300 animate-spin" />
            <span>{isLoading ? 'Synthesizing 16s Ad...' : 'Generate 16-Second UGC Video Ad'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
