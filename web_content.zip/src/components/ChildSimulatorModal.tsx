import React, { useState } from 'react';
import { useParentControl } from '../context/ParentControlContext';
import { 
  X, Wifi, WifiOff, Battery, Volume2, ShieldAlert, 
  Lock, PhoneCall, Radio, Eye, Mic, Bell,
  Sparkles, CheckCircle2, RotateCcw, QrCode
} from 'lucide-react';
import { QrScannerModal } from './QrScannerModal';

export const ChildSimulatorModal: React.FC = () => {
  const { 
    isSimulatorOpen, 
    setIsSimulatorOpen, 
    activeDevice,
    simulatorScreen, 
    setSimulatorScreen,
    simulatorActiveAppId,
    language,
    isLiveCameraStreaming,
    isMicListening,
    sirenPlaying,
    setDeviceLockdown,
    toggleAppBlock
  } = useParentControl();

  const [sosSent, setSosSent] = useState(false);
  const [phoneModel, setPhoneModel] = useState<'android' | 'ios'>(activeDevice?.platform || 'android');
  const [isQrScannerOpen, setIsQrScannerOpen] = useState(false);
  const [inPhoneNotice, setInPhoneNotice] = useState<string | null>(null);

  const triggerPhoneNotice = (msg: string) => {
    setInPhoneNotice(msg);
    setTimeout(() => setInPhoneNotice(null), 3200);
  };

  if (!isSimulatorOpen || !activeDevice) return null;

  const isAr = language === 'ar';
  const settings = activeDevice.settings;
  const isLocked = settings.screenLocked;

  const handleSosClick = () => {
    setSosSent(true);
    setTimeout(() => setSosSent(false), 4000);
  };

  const currentApp = activeDevice.installedApps.find(a => a.id === simulatorActiveAppId);

  return (
    <div id="child-simulator-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 bg-slate-900/70 backdrop-blur-sm overflow-y-auto">
      <div 
        id="child-simulator-card"
        className="relative flex flex-col items-center w-full max-w-[340px] xs:max-w-sm sm:max-w-md bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-2.5 sm:p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-200 my-auto max-h-[95vh] overflow-y-auto transition-colors"
      >
        {/* Header Bar */}
        <div className="w-full flex items-center justify-between pb-2.5 mb-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 relative shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                {isAr ? 'محاكي جهاز الطفل' : 'Child Device Simulator'}
              </h3>
              <p className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400">
                {activeDevice.childNameAr} ({activeDevice.deviceName})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Toggle iOS vs Android Skin */}
            <button
              id="toggle-simulator-platform-btn"
              onClick={() => setPhoneModel(p => p === 'android' ? 'ios' : 'android')}
              className="text-[10px] sm:text-[11px] px-2 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/70 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 font-medium transition-colors"
            >
              {phoneModel === 'android' ? 'Android' : 'iOS iPhone'}
            </button>
            <button
              id="close-simulator-btn"
              onClick={() => setIsSimulatorOpen(false)}
              className="p-1 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Informative notice banner */}
        <div className="w-full mb-2.5 px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-900/50 rounded-xl text-center">
          <p className="text-[10px] sm:text-[11px] text-indigo-700 dark:text-indigo-300 font-medium">
            {isAr 
              ? '⚡ يتفاعل هذا الهاتف في الوقت الفعلي مع أوامر القفل، حظر التطبيقات، والمايك والكاميرا!'
              : '⚡ This simulated phone reacts in real-time to locks, app blocks, mic, and camera commands!'}
          </p>
        </div>

        {/* Smartphone Hardware Frame */}
        <div 
          id="smartphone-hardware-frame"
          className={`relative w-[260px] xs:w-[280px] sm:w-[300px] h-[480px] xs:h-[510px] sm:h-[580px] bg-slate-950 rounded-[34px] sm:rounded-[44px] p-2 sm:p-3 shadow-2xl border-[4px] sm:border-[6px] ${
            phoneModel === 'ios' ? 'border-slate-600' : 'border-slate-700'
          } overflow-hidden flex flex-col shrink-0`}
          style={{
            filter: `brightness(${Math.max(40, settings.brightness)}%)`
          }}
        >
          {/* Hardware Camera Notch / Dynamic Island */}
          <div className="absolute top-2.5 left-1/2 -translate-x-1/2 z-30 flex items-center justify-center">
            {phoneModel === 'ios' ? (
              <div className="h-6 w-28 bg-black rounded-full flex items-center justify-between px-2 text-[9px] text-white">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
                {isLiveCameraStreaming && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Camera Streaming" />
                )}
                {isMicListening && (
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="Mic Listening" />
                )}
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900" />
              </div>
            ) : (
              <div className="h-4 w-4 bg-black rounded-full border border-slate-800 flex items-center justify-center">
                {isLiveCameraStreaming && (
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                )}
              </div>
            )}
          </div>

          {/* Status Bar */}
          <div className="w-full flex items-center justify-between px-3 pt-1 pb-2 text-[10px] text-slate-300 select-none z-20 font-sans">
            <span className="font-semibold">
              {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
            <div className="flex items-center gap-1.5">
              {isMicListening && (
                <span className="flex items-center gap-0.5 text-amber-400 text-[9px]">
                  <Mic className="w-3 h-3 animate-pulse" />
                </span>
              )}
              {isLiveCameraStreaming && (
                <span className="flex items-center gap-0.5 text-emerald-400 text-[9px]">
                  <Eye className="w-3 h-3" />
                </span>
              )}
              {settings.wifiEnabled ? (
                <Wifi className="w-3 h-3 text-white" />
              ) : (
                <WifiOff className="w-3 h-3 text-rose-400" />
              )}
              {settings.cellularDataEnabled && (
                <span className="text-[9px] font-bold text-sky-400">5G</span>
              )}
              <div className="flex items-center gap-0.5">
                <Battery className={`w-3.5 h-3.5 ${activeDevice.batteryLevel < 20 ? 'text-rose-400' : 'text-emerald-400'}`} />
                <span className="text-[9px]">{activeDevice.batteryLevel}%</span>
              </div>
            </div>
          </div>

          {/* Screen Content Container */}
          <div className="relative flex-1 rounded-[30px] overflow-hidden bg-gradient-to-b from-slate-900 via-slate-950 to-indigo-950 flex flex-col text-white">
            
            {/* Native In-Phone Push Notification */}
            {inPhoneNotice && (
              <div className="absolute top-3 inset-x-3 z-50 p-2.5 rounded-2xl bg-slate-900/95 border border-indigo-500/50 text-white text-[11px] font-semibold text-center shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-top-2 duration-200">
                {inPhoneNotice}
              </div>
            )}

            {/* Siren Alert Flash inside phone if siren active */}
            {sirenPlaying && (
              <div className="absolute inset-0 z-40 bg-rose-600/60 animate-pulse flex flex-col items-center justify-center p-4 text-center">
                <Volume2 className="w-16 h-16 text-white animate-bounce" />
                <h4 className="text-lg font-black text-white mt-2">
                  {isAr ? 'صفارة إنذار الوالدين!' : 'PARENTAL SIREN!'}
                </h4>
                <p className="text-xs text-rose-100 mt-1">
                  {isAr ? 'يرن الهاتف بأعلى صوت لتحديد موقعه' : 'Phone ringing at maximum volume'}
                </p>
              </div>
            )}

            {/* SCREEN CONTENT: LOCK SCREEN OVERLAY */}
            {isLocked ? (
              <div className="flex-1 flex flex-col items-center justify-between p-4 text-center bg-slate-950/95 z-30">
                <div className="w-full flex justify-end">
                  <div className="p-1.5 bg-rose-500/20 text-rose-400 rounded-full">
                    <Lock className="w-4 h-4" />
                  </div>
                </div>

                <div className="flex flex-col items-center my-auto">
                  <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-3 shadow-lg shadow-rose-950/50">
                    <ShieldAlert className="w-8 h-8" />
                  </div>
                  <h4 className="text-base font-bold text-white">
                    {isAr ? 'تم قفل هذا الهاتف' : 'Device Locked'}
                  </h4>
                  <p className="text-xs text-rose-300 mt-2 px-2 leading-relaxed bg-rose-950/40 p-2.5 rounded-xl border border-rose-800/40">
                    {settings.lockMessage || (isAr ? 'تم قفل الجهاز من قِبل الوالدين' : 'Device locked by Parent')}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-3">
                    {isAr ? 'لا يمكن فتح أي تطبيق حتى يزيل ولي الأمر القفل.' : 'Apps restricted until parent unlocks.'}
                  </p>
                </div>

                {/* SOS Child Button */}
                <div className="w-full flex flex-col gap-2">
                  <button
                    onClick={handleSosClick}
                    className="w-full py-2.5 px-3 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-rose-900/40"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    {sosSent ? (isAr ? 'تم إرسال نداء الاستغاثة لولي الأمر!' : 'SOS Alert Sent!') : (isAr ? 'طوارئ: اتصال بولي الأمر (SOS)' : 'Emergency Call Parent')}
                  </button>
                </div>
              </div>
            ) : simulatorScreen === 'app' && currentApp ? (
              /* SPECIFIC APP RUNNING */
              <div className="flex-1 flex flex-col bg-slate-900">
                <div className="h-10 bg-slate-800/80 px-3 flex items-center justify-between border-b border-slate-700 text-xs">
                  <div className="flex items-center gap-2">
                    <img src={currentApp.icon} alt={currentApp.name} className="w-5 h-5 rounded" />
                    <span className="font-medium text-white">{isAr ? currentApp.nameAr : currentApp.name}</span>
                  </div>
                  <button 
                    onClick={() => setSimulatorScreen('home')}
                    className="text-[10px] bg-slate-700 px-2 py-0.5 rounded text-slate-300 hover:text-white"
                  >
                    {isAr ? 'خروج' : 'Home'}
                  </button>
                </div>
                <div className="flex-1 p-3 flex flex-col items-center justify-center text-center">
                  <img src={currentApp.icon} alt={currentApp.name} className="w-16 h-16 rounded-2xl mb-3 shadow-md" />
                  <p className="text-sm font-semibold text-white">{isAr ? currentApp.nameAr : currentApp.name}</p>
                  <span className="text-[11px] text-emerald-400 mt-1">
                    {isAr ? 'التطبيق قيد التشغيل المباشر' : 'App Active & Running'}
                  </span>
                  <div className="mt-4 p-2 bg-slate-800/80 rounded-xl text-[10px] text-slate-400 max-w-[200px]">
                    {isAr 
                      ? `استخدم ${currentApp.usedMinutesToday} دقيقة اليوم (الحد: ${currentApp.dailyLimitMinutes || 'بلا حدود'} د)`
                      : `Used ${currentApp.usedMinutesToday}m today (Limit: ${currentApp.dailyLimitMinutes || 'Unlimited'}m)`}
                  </div>
                  <button
                    onClick={() => toggleAppBlock(currentApp.id)}
                    className="mt-4 px-3 py-1.5 bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 border border-rose-500/30 rounded-lg text-[11px]"
                  >
                    {isAr ? 'جرب حظر التطبيق الآن' : 'Test Blocking App Now'}
                  </button>
                </div>
              </div>
            ) : (
              /* HOME SCREEN WITH APPS */
              <div className="flex-1 p-3 flex flex-col justify-between">
                {/* Search & Widget */}
                <div>
                  <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 mb-3 border border-white/10 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] text-slate-300">
                        {isAr ? 'الخميس، 12 أكتوبر' : 'Thursday, Oct 12'}
                      </p>
                      <p className="text-base font-bold text-white">26°C مشمس</p>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] px-2 py-0.5 bg-indigo-500/30 rounded-full text-indigo-300 border border-indigo-400/20">
                        {isAr ? 'محمي بواسطة ParentGuard' : 'ParentGuard Active'}
                      </span>
                    </div>
                  </div>

                  {/* App Grid */}
                  <div className="grid grid-cols-4 gap-2.5 pt-1">
                    {activeDevice.installedApps.map(app => {
                      return (
                        <button
                          key={app.id}
                          onClick={() => {
                            if (app.isBlocked) {
                              triggerPhoneNotice(isAr 
                                ? `⛔ عذراً! تطبيق ${app.nameAr} محظور حالياً من قبل ولي الأمر.` 
                                : `⛔ Sorry! ${app.name} is currently blocked by parent.`);
                            } else {
                              setSimulatorScreen('app');
                            }
                          }}
                          className="flex flex-col items-center group relative focus:outline-none"
                        >
                          <div className="relative w-11 h-11 rounded-xl bg-slate-800/80 p-1.5 border border-slate-700 flex items-center justify-center transition-transform group-hover:scale-105 shadow-md">
                            <img src={app.icon} alt={app.name} className="w-full h-full object-contain rounded-lg" />
                            {app.isBlocked && (
                              <div className="absolute inset-0 bg-rose-950/80 rounded-xl flex items-center justify-center border border-rose-500/50">
                                <Lock className="w-4 h-4 text-rose-400" />
                              </div>
                            )}
                          </div>
                          <span className="text-[9px] text-slate-200 mt-1 truncate w-full text-center">
                            {isAr ? app.nameAr : app.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Bottom Dock */}
                <div className="w-full bg-white/10 backdrop-blur-md rounded-2xl p-2 flex items-center justify-around border border-white/10">
                  <button 
                    onClick={handleSosClick}
                    className="p-2 bg-rose-600/80 rounded-xl text-white hover:bg-rose-500 transition-colors"
                    title="SOS Call"
                  >
                    <PhoneCall className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setIsQrScannerOpen(true)}
                    className="p-2 bg-indigo-600/80 rounded-xl text-white hover:bg-indigo-500 transition-colors flex items-center justify-center relative group"
                    title={isAr ? 'مسح رمز QR' : 'Scan QR'}
                  >
                    <QrCode className="w-4 h-4" />
                    <span className="absolute -top-7 px-1.5 py-0.5 rounded bg-black/80 text-[9px] text-white whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                      {isAr ? 'مسح QR' : 'QR Scan'}
                    </span>
                  </button>
                  <button 
                    onClick={() => triggerPhoneNotice(isAr ? '🟢 رسالة من الطفل: كل شيء هادئ وعلى ما يرام' : '🟢 Message: All safe and sound')}
                    className="p-2 bg-emerald-600/80 rounded-xl text-white hover:bg-emerald-500 transition-colors"
                  >
                    <Bell className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setSimulatorScreen('home')}
                    className="p-2 bg-slate-700/80 rounded-xl text-white hover:bg-slate-600 transition-colors"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Home Bar Indicator (iOS style bottom line) */}
          <div className="w-full flex justify-center py-1 z-20">
            <button 
              onClick={() => setSimulatorScreen('home')}
              className="w-24 h-1 bg-slate-400/50 hover:bg-slate-300 rounded-full transition-colors"
            />
          </div>
        </div>

        {/* Action helper footer */}
        <div className="w-full flex items-center justify-between mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
          <button
            onClick={() => setIsQrScannerOpen(true)}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition-colors"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>{isAr ? 'مسح QR' : 'Scan QR'}</span>
          </button>

          <div className="flex gap-2">
            <button
              onClick={() => setDeviceLockdown(!isLocked)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shadow-xs transition-colors ${
                isLocked ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              {isLocked ? (isAr ? 'إلغاء القفل' : 'Unlock Phone') : (isAr ? 'قفل الهاتف الآن' : 'Lock Phone Now')}
            </button>
          </div>
        </div>

        {/* QR Scanner Modal for Simulator */}
        <QrScannerModal
          isOpen={isQrScannerOpen}
          onClose={() => setIsQrScannerOpen(false)}
          defaultCode={activeDevice.pairingCode}
        />
      </div>
    </div>
  );
};
