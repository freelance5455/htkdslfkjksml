import { Monitor, Tablet, Tv } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/cn";
import { CONSOLES, firstZone, GAMES, ITEMS, zonesOf } from "@/lib/rastro/catalog";
import { unlockAudio } from "@/lib/rastro/audio";
import { useRastro } from "@/lib/rastro/store";
import { Plate } from "@/components/rastro/plate";
import { Btn } from "@/components/rastro/ui";

const ICONS = { pulse: Tv, nimbus: Tablet, atrio: Monitor } as const;
const STEPS = ["Console respondeu", "Save reconhecido", "Posição no mapa"];

export function LinkScreen() {
  const link = useRastro((state) => state.link);
  const [consoleId, setConsoleId] = useState(CONSOLES[0]?.id ?? "pulse");
  const [gameId, setGameId] = useState(GAMES[0]?.id ?? "vale");
  const [expected, setExpected] = useState<string | null>(null);
  const [typed, setTyped] = useState("");
  const [phase, setPhase] = useState<"edit" | "link">("edit");
  const [step, setStep] = useState(0);
  const [pad, setPad] = useState(false);
  const zone = firstZone(gameId);
  const ready = expected !== null && typed.trim().toUpperCase() === expected;

  useEffect(() => {
    const look = () => {
      const pads = navigator.getGamepads?.();
      setPad(!!pads && Array.from(pads).some(Boolean));
    };
    const id = window.setInterval(look, 700);
    window.addEventListener("gamepadconnected", look);
    return () => {
      window.clearInterval(id);
      window.removeEventListener("gamepadconnected", look);
    };
  }, []);

  useEffect(() => {
    if (phase !== "link") return;
    const timers = [
      window.setTimeout(() => setStep(1), 360),
      window.setTimeout(() => setStep(2), 780),
      window.setTimeout(() => setStep(3), 1180),
      window.setTimeout(() => link(consoleId, gameId), 1500),
    ];
    return () => {
      for (const timer of timers) window.clearTimeout(timer);
    };
  }, [phase, consoleId, gameId, link]);

  function ignite() {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < 4; i += 1) code += alphabet[Math.floor(Math.random() * alphabet.length)] ?? "R";
    setExpected(code);
    setTyped("");
  }

  function start(event?: { preventDefault: () => void }) {
    event?.preventDefault();
    if (!ready || phase === "link") return;
    unlockAudio();
    setStep(0);
    setPhase("link");
  }

  return (
    <main className="mx-auto min-h-dvh w-full max-w-6xl px-4 py-6 sm:px-6 sm:py-10">
      <div className="grid items-start gap-8 lg:grid-cols-2 lg:gap-12">
        <section className="min-w-0">
          <p className="text-xs tracking-widest text-phosphor uppercase">Segunda tela</p>
          <h1 className="mt-2 font-display text-5xl leading-none text-balance text-bone sm:text-6xl">
            Rastro
          </h1>
          <p className="mt-4 max-w-md text-lg text-pretty text-bone">
            O mapa avisa o que está perto. E o que você deixou para trás.
          </p>
          <p className="mt-3 max-w-md text-sm text-pretty text-mist">
            Vincule a sessão do console. O batedor no mapa é a posição que o jogo enviaria. Entrou no raio, soa.
            Afastou sem pegar, o item fica em brasa até a volta.
          </p>
          <div className="mt-6 h-52 overflow-hidden rounded-2xl border border-line sm:h-72">
            <Plate zone={zone} />
          </div>
          <p className="mt-2 text-sm text-mist">
            {zone.name} · {GAMES.find((game) => game.id === gameId)?.title}
          </p>
        </section>

        <section className="min-w-0 rounded-3xl border border-line bg-panel p-4 sm:p-6">
          <h2 className="font-display text-2xl text-balance">Vincular sessão</h2>
          <p className="mt-1 text-sm text-pretty text-mist">
            {pad
              ? "Controle detectado. Na sessão, o analógico esquerdo move o batedor."
              : "Nenhum controle no navegador. WASD, as setas ou o stick também movem."}
          </p>

          <p className="mt-5 text-xs tracking-widest text-mist uppercase">Console</p>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {CONSOLES.map((entry) => {
              const Icon = ICONS[entry.id as keyof typeof ICONS] ?? Tv;
              const on = consoleId === entry.id;
              return (
                <button
                  key={entry.id}
                  type="button"
                  aria-pressed={on}
                  disabled={phase === "link"}
                  onClick={() => setConsoleId(entry.id)}
                  className={cn(
                    "min-h-11 rounded-2xl border px-2 py-3 text-left transition-transform duration-150 active:scale-[0.96]",
                    on ? "border-phosphor bg-ink text-bone" : "border-line bg-ink text-mist",
                  )}
                >
                  <Icon className="size-4" aria-hidden />
                  <span className="mt-2 block text-sm font-medium text-bone">{entry.name}</span>
                  <span className="block text-xs">{entry.where}</span>
                </button>
              );
            })}
          </div>

          <p className="mt-5 text-xs tracking-widest text-mist uppercase">Jogo</p>
          <div className="mt-2 grid gap-2">
            {GAMES.map((game) => {
              const on = gameId === game.id;
              const zones = zonesOf(game.id);
              const count = ITEMS.filter((item) => zones.some((z) => z.id === item.zoneId)).length;
              return (
                <button
                  key={game.id}
                  type="button"
                  aria-pressed={on}
                  disabled={phase === "link"}
                  onClick={() => setGameId(game.id)}
                  className={cn(
                    "min-h-11 rounded-2xl border px-3 py-3 text-left transition-transform duration-150 active:scale-[0.96]",
                    on ? "border-phosphor bg-ink" : "border-line bg-ink",
                  )}
                >
                  <span className="block text-sm font-medium text-bone">{game.title}</span>
                  <span className="mt-1 block text-sm text-pretty text-mist">{game.blurb}</span>
                  <span className="mt-1 block text-xs text-mist">
                    {game.studio} · {zones.length} {zones.length === 1 ? "região" : "regiões"} · {count} itens
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-5 rounded-2xl border border-line bg-ink p-3">
            <div className="flex aspect-video items-center justify-center rounded-xl bg-panel">
              <div className="text-center">
                <p className="text-xs tracking-widest text-mist uppercase">Código na TV</p>
                <p className="mt-2 font-display text-5xl tracking-widest text-phosphor tabular-nums">
                  {expected ?? "----"}
                </p>
              </div>
            </div>
            <div className="mx-auto h-3 w-16 bg-panel-2" />
            <div className="mx-auto h-1.5 w-24 rounded-full bg-line" />
          </div>

          {phase === "link" ? (
            <ol className="mt-4 grid gap-2">
              {STEPS.map((label, index) => {
                const done = step > index;
                const current = step === index;
                return (
                  <li
                    key={label}
                    className={cn(
                      "flex min-h-11 items-center gap-3 rounded-2xl border px-3 text-sm",
                      done ? "border-phosphor text-bone" : "border-line text-mist",
                      current && "text-phosphor",
                    )}
                  >
                    <span
                      className={cn(
                        "size-2 rounded-full",
                        done || current ? "bg-phosphor" : "bg-line",
                        current && "rastro-live",
                      )}
                    />
                    {label}
                  </li>
                );
              })}
            </ol>
          ) : (
            <form className="mt-4 grid gap-3" onSubmit={start}>
              <label className="grid gap-2 text-sm text-mist">
                Digite o código
                <input
                  value={typed}
                  onChange={(event) => setTyped(event.target.value.toUpperCase().slice(0, 4))}
                  maxLength={4}
                  autoCapitalize="characters"
                  autoCorrect="off"
                  spellCheck={false}
                  aria-label="Código da TV"
                  className="h-12 rounded-2xl border border-line bg-ink text-center font-display text-2xl tracking-widest text-bone uppercase outline-none focus-visible:border-phosphor"
                />
              </label>
              <div className="flex flex-wrap gap-2">
                {expected ? (
                  <Btn tone="primary" disabled={!ready} onClick={() => start()}>
                    Vincular
                  </Btn>
                ) : (
                  <Btn tone="primary" onClick={ignite}>
                    Acender código na TV
                  </Btn>
                )}
                {expected ? (
                  <Btn tone="ghost" onClick={() => setTyped(expected)}>
                    Usar o código da TV
                  </Btn>
                ) : null}
              </div>
            </form>
          )}
        </section>
      </div>
    </main>
  );
}
