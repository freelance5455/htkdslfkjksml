import { useRef, useState } from "react";

type Vec = { x: number; y: number };

export function Stick({ onChange }: { onChange: (v: Vec) => void }) {
  const base = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState<Vec>({ x: 0, y: 0 });

  function update(clientX: number, clientY: number) {
    const el = base.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const max = rect.width / 2;
    let dx = clientX - (rect.left + rect.width / 2);
    let dy = clientY - (rect.top + rect.height / 2);
    const mag = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(mag, max);
    dx = (dx / mag) * clamped;
    dy = (dy / mag) * clamped;
    setKnob({ x: dx, y: dy });
    onChange({ x: dx / max, y: dy / max });
  }

  function end() {
    setKnob({ x: 0, y: 0 });
    onChange({ x: 0, y: 0 });
  }

  return (
    <div
      ref={base}
      className="absolute bottom-3 left-3 z-30 size-28 touch-none rounded-full border border-line bg-ink/80 lg:hidden"
      onPointerDown={(event) => {
        event.currentTarget.setPointerCapture(event.pointerId);
        update(event.clientX, event.clientY);
      }}
      onPointerMove={(event) => {
        if (event.currentTarget.hasPointerCapture(event.pointerId)) update(event.clientX, event.clientY);
      }}
      onPointerUp={end}
      onPointerCancel={end}
      role="presentation"
    >
      <span className="absolute top-1/2 left-1/2 size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-line" />
      <span
        className="absolute top-1/2 left-1/2 size-11 -translate-x-1/2 -translate-y-1/2 rounded-full border border-phosphor bg-panel"
        style={{ marginLeft: knob.x, marginTop: knob.y }}
      />
    </div>
  );
}
