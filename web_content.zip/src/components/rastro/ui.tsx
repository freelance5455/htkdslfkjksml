import { Archive, BookOpen, Gem, Hexagon, KeyRound, type LucideIcon } from "lucide-react";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";
import type { Kind } from "@/lib/rastro/catalog";

export const KIND_ICON: Record<Kind, LucideIcon> = {
  reliquia: Gem,
  fragmento: Hexagon,
  diario: BookOpen,
  chave: KeyRound,
  bau: Archive,
};

export function Btn({
  tone = "ghost",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  tone?: "primary" | "ember" | "ghost" | "quiet";
}) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-4 text-sm font-medium transition-transform duration-150 ease-out active:scale-[0.96] disabled:pointer-events-none disabled:opacity-40",
        "focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-phosphor",
        tone === "primary" && "bg-phosphor text-ink",
        tone === "ember" && "bg-ember text-ink",
        tone === "ghost" && "border border-line bg-panel text-bone",
        tone === "quiet" && "bg-transparent text-mist",
        className,
      )}
      {...props}
    />
  );
}
