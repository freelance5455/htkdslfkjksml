import { forwardRef, useImperativeHandle, useLayoutEffect, useRef, useState } from "react";
import { cn } from "@/lib/cn";
import { itemById, type ZoneDef } from "@/lib/rastro/catalog";
import type { Runtime } from "@/lib/rastro/engine";
import { Plate } from "@/components/rastro/plate";
import { KIND_ICON } from "@/components/rastro/ui";

export type Pose = { x: number; y: number; facing: number; speed: number };

export type FieldHandle = {
  apply: (pose: Pose, detect: number) => void;
};

type Props = {
  zone: ZoneDef;
  runtimes: Runtime[];
  selectedId: string | null;
  trail: { x: number; y: number }[];
  onSelect: (id: string) => void;
};

export const FieldMap = forwardRef<FieldHandle, Props>(function FieldMap(
  { zone, runtimes, selectedId, trail, onSelect },
  ref,
) {
  const box = useRef<HTMLDivElement>(null);
  const puck = useRef<HTMLDivElement>(null);
  const notch = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState(240);

  useLayoutEffect(() => {
    const el = box.current;
    if (!el) return;
    const measure = () => {
      const rect = el.getBoundingClientRect();
      setSize(Math.max(160, Math.floor(Math.min(rect.width, rect.height) - 8)));
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useImperativeHandle(ref, () => ({
    apply(pose, detect) {
      if (puck.current) {
        puck.current.style.left = `${pose.x}%`;
        puck.current.style.top = `${pose.y}%`;
      }
      if (notch.current) notch.current.style.rotate = `${pose.facing + Math.PI / 2}rad`;
      if (ring.current) {
        ring.current.style.left = `${pose.x}%`;
        ring.current.style.top = `${pose.y}%`;
        ring.current.style.width = `${detect * 2}%`;
        ring.current.style.height = `${detect * 2}%`;
      }
    },
  }));

  const pins = runtimes.filter(
    (item) => item.zoneId === zone.id && item.status !== "pocket" && item.status !== "held",
  );
  const points = trail.map((point) => `${point.x},${point.y}`).join(" ");

  return (
    <div ref={box} className="grid h-full w-full place-items-center">
      <div className="relative overflow-hidden rounded-2xl border border-line" style={{ width: size, height: size }}>
        <Plate zone={zone} />
        {trail.length > 1 ? (
          <svg viewBox="0 0 100 100" className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden>
            <polyline
              points={points}
              fill="none"
              stroke="var(--color-phosphor)"
              strokeOpacity="0.55"
              strokeWidth="0.7"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          </svg>
        ) : null}
        <div
          ref={ring}
          className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2"
          style={{ left: "50%", top: "50%", width: "28%", height: "28%" }}
        >
          <div className="rastro-sweep absolute inset-0 rounded-full" />
          <div className="absolute inset-0 rounded-full border border-phosphor/50" />
        </div>
        {pins.map((item) => {
          const def = itemById.get(item.id);
          if (!def) return null;
          const Icon = KIND_ICON[def.kind];
          const hot = item.status === "near" || item.status === "behind";
          return (
            <button
              key={item.id}
              type="button"
              className="absolute z-10 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center"
              style={{ left: `${item.x}%`, top: `${item.y}%` }}
              aria-pressed={selectedId === item.id}
              aria-label={`${def.name}, ${item.status === "behind" ? "deixou para trás" : item.status === "near" ? "por perto" : "no mapa"}`}
              onClick={() => onSelect(item.id)}
            >
              <span
                className={cn(
                  "flex size-7 items-center justify-center rounded-full border",
                  item.status === "near" && "border-phosphor bg-phosphor text-ink",
                  item.status === "behind" && "border-ember bg-ember text-ink",
                  item.status === "field" && "border-line bg-panel text-bone",
                  selectedId === item.id && "outline outline-2 outline-offset-2 outline-bone",
                )}
              >
                <Icon className="size-3.5" aria-hidden />
              </span>
              {hot ? (
                <span
                  className={cn(
                    "pointer-events-none absolute top-1/2 -translate-y-1/2 rounded-full px-2 py-0.5 text-xs whitespace-nowrap",
                    item.x > 68 ? "right-full mr-1" : "left-full ml-1",
                    item.status === "behind" ? "bg-ember text-ink" : "bg-phosphor text-ink",
                  )}
                >
                  {def.short}
                </span>
              ) : null}
            </button>
          );
        })}
        <div
          ref={puck}
          className="pointer-events-none absolute z-20 size-5 -translate-x-1/2 -translate-y-1/2"
          style={{ left: "50%", top: "56%" }}
        >
          <div ref={notch} className="absolute inset-0">
            <span className="absolute top-0 left-1/2 h-2 w-0.5 -translate-x-1/2 rounded-full bg-phosphor" />
          </div>
          <span className="absolute inset-1 rounded-full border-2 border-ink bg-bone" />
        </div>
      </div>
    </div>
  );
});
