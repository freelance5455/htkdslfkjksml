import { useId } from "react";
import { cn } from "@/lib/cn";
import type { Fill, Shape, ZoneDef } from "@/lib/rastro/catalog";

const FILL: Record<Fill, string> = {
  moss: "color-mix(in oklab, var(--color-phosphor) 16%, var(--color-panel))",
  water: "color-mix(in oklab, var(--color-ink) 78%, var(--color-panel))",
  stone: "color-mix(in oklab, var(--color-bone) 18%, var(--color-panel))",
  metal: "color-mix(in oklab, var(--color-mist) 14%, var(--color-panel))",
  ground: "color-mix(in oklab, var(--color-bone) 8%, var(--color-panel))",
};

export function Plate({ zone, className }: { zone: ZoneDef; className?: string }) {
  const gid = useId().replace(/:/g, "");
  return (
    <svg viewBox="0 0 100 100" className={cn("h-full w-full", className)} aria-hidden>
      <defs>
        <pattern id={gid} width="5" height="5" patternUnits="userSpaceOnUse">
          <path d="M 5 0 L 0 0 0 5" fill="none" stroke="var(--color-line)" strokeWidth="0.22" />
        </pattern>
      </defs>
      <rect width="100" height="100" fill="var(--color-panel)" />
      <rect width="100" height="100" fill={`url(#${gid})`} />
      {zone.shapes.map((shape, index) => (
        <ShapeView key={index} shape={shape} />
      ))}
      <text
        x="50"
        y="4.2"
        textAnchor="middle"
        fill="var(--color-mist)"
        fontSize="2.5"
        letterSpacing="0.18"
      >
        N
      </text>
      <rect x="0.6" y="0.6" width="98.8" height="98.8" fill="none" stroke="var(--color-line)" strokeWidth="0.45" />
    </svg>
  );
}

function ShapeView({ shape }: { shape: Shape }) {
  if (shape.t === "disc") {
    return <circle cx={shape.x} cy={shape.y} r={shape.r} fill={FILL[shape.fill]} />;
  }
  if (shape.t === "rect") {
    return <rect x={shape.x} y={shape.y} width={shape.w} height={shape.h} fill={FILL[shape.fill]} />;
  }
  if (shape.t === "ring") {
    return (
      <circle
        cx={shape.x}
        cy={shape.y}
        r={shape.r}
        fill="none"
        stroke="var(--color-mist)"
        strokeWidth="0.45"
      />
    );
  }
  if (shape.t === "path") {
    return (
      <path
        d={shape.d}
        fill="none"
        stroke="color-mix(in oklab, var(--color-bone) 55%, transparent)"
        strokeWidth="0.7"
        strokeLinecap="round"
      />
    );
  }
  if (shape.t === "fire") {
    return (
      <g>
        <circle cx={shape.x} cy={shape.y} r="1.5" fill="var(--color-ember)" />
        <circle cx={shape.x} cy={shape.y} r="2.8" fill="none" stroke="var(--color-ember)" strokeWidth="0.3" />
      </g>
    );
  }
  return (
    <text x={shape.x} y={shape.y} textAnchor="middle" fill="var(--color-mist)" fontSize="2.5" letterSpacing="0.12">
      {shape.text}
    </text>
  );
}
