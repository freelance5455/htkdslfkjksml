import React, { useState } from 'react';
import { 
  X, 
  Upload, 
  FileCheck2, 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  School, 
  MapPin, 
  Calendar, 
  FileText 
} from 'lucide-react';
import { Language, User, GradeLevel, Medium, PaperType, Province, TermTest, FileFormat } from '../types';
import { TRANSLATIONS } from '../lib/translations';
import { SRI_LANKAN_SCHOOLS, SUBJECTS_BY_GRADE } from '../data/mockData';

interface PaperUploadModalProps {
  onClose: () => void;
  language: Language;
  currentUser: User;
  onPaperUploaded: (newPaper: any) => void;
}

export const PaperUploadModal: React.FC<PaperUploadModalProps> = ({
  onClose,
  language,
  currentUser,
  onPaperUploaded
}) => {
  const t = TRANSLATIONS[language];

  const [file, setFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [virusScanStatus, setVirusScanStatus] = useState<'IDLE' | 'SCANNING' | 'CLEAN'>('IDLE');
  const [duplicateStatus, setDuplicateStatus] = useState<'IDLE' | 'CHECKING' | 'UNIQUE'>('IDLE');

  // Form Fields
  const [title, setTitle] = useState('');
  const [grade, setGrade] = useState<GradeLevel>('G.C.E. A/L');
  const [subject, setSubject] = useState('Combined Mathematics');
  const [medium, setMedium] = useState<Medium>('Sinhala');
  const [year, setYear] = useState(2024);
  const [province, setProvince] = useState<Province>('Western');
  const [school, setSchool] = useState('Royal College, Colombo 07');
  const [paperType, setPaperType] = useState<PaperType>('Model Paper');
  const [termTest, setTermTest] = useState<TermTest>('3rd Term');
  const [hasAnswers, setHasAnswers] = useState(true);
  const [hasMarkingScheme, setHasMarkingScheme] = useState(true);
  const [tags, setTags] = useState<string[]>(['SriLankaExam', 'ModelPaper']);
  const [description, setDescription] = useState('');
  const [isGeneratingTags, setIsGeneratingTags] = useState(false);

  const availableSubjects = SUBJECTS_BY_GRADE[grade] || ['Mathematics', 'Science'];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelected = (selectedFile: File) => {
    setFile(selectedFile);
    if (!title) {
      setTitle(selectedFile.name.replace(/\.[^/.]+$/, ''));
    }

    // Trigger simulated virus scan & duplicate check
    setVirusScanStatus('SCANNING');
    setDuplicateStatus('CHECKING');
    setTimeout(() => {
      setVirusScanStatus('CLEAN');
      setDuplicateStatus('UNIQUE');
    }, 1200);
  };

  const handleAutoGenerateTags = async () => {
    if (!title) return;
    setIsGeneratingTags(true);
    try {
      const res = await fetch('/api/ai/auto-tags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, description })
      });
      const data = await res.json();
      if (data.tags && data.tags.length > 0) {
        setTags(data.tags);
      }
    } catch (err) {
      setTags(['ExamPrep', 'SriLankaEducation', grade.replace(/\s+/g, '')]);
    } finally {
      setIsGeneratingTags(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsUploading(true);
    
    // Simulate upload progress
    let interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          
          const fileExt = file?.name.split('.').pop()?.toUpperCase() || 'PDF';
          const newPaper = {
            title,
            subject,
            grade,
            medium,
            year,
            province,
            school,
            paperType,
            termTest,
            hasAnswers,
            hasMarkingScheme,
            fileFormat: (['PDF', 'DOCX', 'ZIP', 'RAR'].includes(fileExt) ? fileExt : 'PDF') as FileFormat,
            fileSize: file ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` : '3.5 MB',
            tags,
            description,
            uploaderId: currentUser.id,
            uploaderName: currentUser.name,
            uploaderAvatar: currentUser.avatar,
            uploaderRole: currentUser.role
          };

          fetch('/api/papers', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newPaper)
          })
            .then((res) => res.json())
            .then((data) => {
              setIsUploading(false);
              onPaperUploaded(data.paper);
              onClose();
            });

          return 100;
        }
        return prev + 25;
      });
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden my-6">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">{t.uploadBtn}</h3>
              <p className="text-xs text-slate-400">Upload past papers, term test files, or official marking schemes</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition-all cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Drag & Drop Area */}
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
              dragActive
                ? 'border-amber-400 bg-amber-500/10'
                : file
                ? 'border-emerald-500/50 bg-emerald-500/5'
                : 'border-slate-700 bg-slate-950/50 hover:border-slate-600'
            }`}
          >
            {file ? (
              <div className="space-y-2">
                <FileCheck2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <p className="text-sm font-bold text-white">{file.name}</p>
                <p className="text-xs text-slate-400">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>

                {/* Virus & Duplicate Status */}
                <div className="flex items-center justify-center gap-4 text-xs pt-2">
                  <span className="flex items-center gap-1 text-emerald-400 font-semibold bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Virus Scan: Clean</span>
                  </span>
                  <span className="flex items-center gap-1 text-sky-400 font-semibold bg-sky-500/10 px-2.5 py-1 rounded-full border border-sky-500/20">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Duplicate Check: Unique</span>
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="w-10 h-10 text-amber-400 mx-auto" />
                <p className="text-sm font-bold text-white">Drag & drop your paper file here</p>
                <p className="text-xs text-slate-400">Supports PDF, DOCX, ZIP, or RAR up to 25 MB</p>
                <label className="inline-block mt-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs rounded-xl cursor-pointer transition-all">
                  Browse File
                  <input
                    type="file"
                    accept=".pdf,.docx,.zip,.rar"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleFileSelected(e.target.files[0])}
                  />
                </label>
              </div>
            )}
          </div>

          {/* Form Fields Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Title */}
            <div className="sm:col-span-2 space-y-1">
              <label className="text-xs font-bold text-slate-300">Paper Title *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. 2024 Royal College G.C.E. A/L Combined Mathematics 3rd Term Test Paper I & II"
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Grade */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Grade Level</label>
              <select
                value={grade}
                onChange={(e) => {
                  const newGrade = e.target.value as GradeLevel;
                  setGrade(newGrade);
                  setSubject(SUBJECTS_BY_GRADE[newGrade]?.[0] || 'Mathematics');
                }}
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              >
                {['Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'G.C.E. O/L', 'G.C.E. A/L'].map((g) => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
            </div>

            {/* Subject */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Subject</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              >
                {availableSubjects.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Medium */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Medium</label>
              <select
                value={medium}
                onChange={(e) => setMedium(e.target.value as Medium)}
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              >
                <option value="Sinhala">Sinhala (සිංහල)</option>
                <option value="English">English</option>
                <option value="Tamil">Tamil (தமிழ்)</option>
              </select>
            </div>

            {/* Year */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Year</label>
              <select
                value={year}
                onChange={(e) => setYear(parseInt(e.target.value))}
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              >
                {[2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018].map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>

            {/* Province */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Province</label>
              <select
                value={province}
                onChange={(e) => setProvince(e.target.value as Province)}
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              >
                {['Western', 'Central', 'Southern', 'Northern', 'Eastern', 'North Western', 'North Central', 'Uva', 'Sabaragamuwa', 'National'].map((p) => (
                  <option key={p} value={p}>{p} Province</option>
                ))}
              </select>
            </div>

            {/* School */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">School / Institution</label>
              <input
                type="text"
                value={school}
                onChange={(e) => setSchool(e.target.value)}
                placeholder="e.g. Ananda College, Colombo 10"
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Paper Type */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Paper Type</label>
              <select
                value={paperType}
                onChange={(e) => setPaperType(e.target.value as PaperType)}
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              >
                <option value="Model Paper">Model Paper</option>
                <option value="Term Test">Term Test</option>
                <option value="Past Paper">Past Paper</option>
                <option value="Marking Scheme">Marking Scheme</option>
                <option value="Short Notes">Short Notes</option>
              </select>
            </div>

            {/* Term Test */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Term / Evaluation</label>
              <select
                value={termTest}
                onChange={(e) => setTermTest(e.target.value as TermTest)}
                className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-amber-400"
              >
                <option value="1st Term">1st Term</option>
                <option value="2nd Term">2nd Term</option>
                <option value="3rd Term">3rd Term</option>
                <option value="Final Exam">Final Exam</option>
                <option value="N/A">N/A</option>
              </select>
            </div>

          </div>

          {/* Marking Scheme Checkboxes */}
          <div className="flex items-center gap-6 pt-2">
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={hasAnswers}
                onChange={(e) => setHasAnswers(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded"
              />
              <span>Answers Included</span>
            </label>

            <label className="flex items-center gap-2 text-xs font-semibold text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={hasMarkingScheme}
                onChange={(e) => setHasMarkingScheme(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded"
              />
              <span>Official Marking Scheme Included</span>
            </label>
          </div>

          {/* AI Auto Tag Generator */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300">Paper Tags</label>
              <button
                type="button"
                onClick={handleAutoGenerateTags}
                disabled={isGeneratingTags || !title}
                className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isGeneratingTags ? 'Generating...' : 'Auto-Generate Tags with AI'}</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 p-2 bg-slate-950 rounded-xl border border-slate-800">
              {tags.map((t, i) => (
                <span key={i} className="px-2.5 py-1 text-xs font-semibold bg-amber-500/20 text-amber-300 rounded-lg border border-amber-500/30">
                  #{t}
                </span>
              ))}
            </div>
          </div>

          {/* Progress bar if uploading */}
          {isUploading && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold text-amber-400">
                <span>Uploading to Cloud Storage...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full transition-all duration-200" style={{ width: `${uploadProgress}%` }}></div>
              </div>
            </div>
          )}

          {/* Submit */}
          <div className="pt-4 flex justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-xs font-bold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isUploading}
              className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Submit & Upload Paper (+50 Pts)</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
