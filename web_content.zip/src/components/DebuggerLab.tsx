import React, { useState } from 'react';
import {
  Terminal,
  AlertCircle,
  AlertTriangle,
  Info,
  CheckCircle2,
  Trash2,
  Sparkles,
  Play,
  Bug,
  ChevronDown,
  ChevronUp,
  FlaskConical
} from 'lucide-react';
import { ConsoleEntry, Project, TestResult } from '../types';

interface DebuggerLabProps {
  logs: ConsoleEntry[];
  onClearLogs: () => void;
  onDiagnoseError: (errorMsg: string, stack?: string) => void;
  project: Project;
  isOpen: boolean;
  onToggleOpen: () => void;
}

export const DebuggerLab: React.FC<DebuggerLabProps> = ({
  logs,
  onClearLogs,
  onDiagnoseError,
  project,
  isOpen,
  onToggleOpen,
}) => {
  const [activeTab, setActiveTab] = useState<'console' | 'tests' | 'auditor'>('console');
  const [filter, setFilter] = useState<'all' | 'log' | 'warn' | 'error'>('all');
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState(false);

  const errorCount = logs.filter(l => l.type === 'error').length;
  const warnCount = logs.filter(l => l.type === 'warn').length;

  const filteredLogs = logs.filter(l => {
    if (filter === 'all') return true;
    return l.type === filter;
  });

  // Run automated test suite
  const runTests = () => {
    setIsRunningTests(true);
    setTestResults([]);

    setTimeout(() => {
      const results: TestResult[] = [];
      const startTime = performance.now();

      // Test 1: Entry File Check
      const hasHtml = project.files.some(f => f.name.endsWith('.html') || f.name.endsWith('.py'));
      results.push({
        id: 't-entry',
        name: 'Project Entry Point Verification',
        status: hasHtml ? 'pass' : 'fail',
        message: hasHtml ? 'Valid entry file detected.' : 'Missing index.html or main.py entry.',
        durationMs: Math.round(performance.now() - startTime),
      });

      // Test 2: Syntax and Parenthesis Matching
      const jsFiles = project.files.filter(f => f.name.endsWith('.js') || f.name.endsWith('.ts'));
      let syntaxPass = true;
      let syntaxMsg = 'All JavaScript brackets and braces balance properly.';

      for (const f of jsFiles) {
        let braces = 0;
        let parens = 0;
        for (const char of f.content) {
          if (char === '{') braces++;
          if (char === '}') braces--;
          if (char === '(') parens++;
          if (char === ')') parens--;
        }
        if (braces !== 0 || parens !== 0) {
          syntaxPass = false;
          syntaxMsg = `Unbalanced brackets in ${f.name} (Braces: ${braces}, Parens: ${parens})`;
          break;
        }
      }

      results.push({
        id: 't-syntax',
        name: 'Lexical Grammar & Brace Matching',
        status: syntaxPass ? 'pass' : 'fail',
        message: syntaxMsg,
        durationMs: Math.round(performance.now() - startTime + 2),
      });

      // Test 3: Canvas ID reference check for games
      if (project.category === 'game') {
        const hasCanvasTag = project.files.some(f => f.content.includes('<canvas'));
        const hasGetContext = project.files.some(f => f.content.includes('getContext('));
        const canvasPass = hasCanvasTag && hasGetContext;

        results.push({
          id: 't-canvas',
          name: '2D Canvas Context Binding',
          status: canvasPass ? 'pass' : 'fail',
          message: canvasPass
            ? 'HTML <canvas> and getContext("2d") bound correctly.'
            : 'Warning: Missing <canvas> tag or getContext call.',
          durationMs: Math.round(performance.now() - startTime + 5),
        });
      }

      // Test 4: Web Audio or event cleanup
      const hasAudio = project.files.some(f => f.content.includes('AudioContext'));
      results.push({
        id: 't-audio',
        name: 'Interactive Audio / Event Listeners',
        status: 'pass',
        message: hasAudio ? 'Web Audio synthesizer configured.' : 'Clean event listener configuration.',
        durationMs: Math.round(performance.now() - startTime + 7),
      });

      setTestResults(results);
      setIsRunningTests(false);
    }, 300);
  };

  // Run code auditor heuristics
  const getAuditFindings = () => {
    const findings: Array<{ title: string; desc: string; severity: 'warn' | 'info' | 'good' }> = [];
    const jsContent = project.files
      .filter(f => f.name.endsWith('.js') || f.name.endsWith('.ts'))
      .map(f => f.content)
      .join('\n');

    if (jsContent.includes('alert(')) {
      findings.push({
        title: 'Blocking window.alert() detected',
        desc: 'Modal alerts block the browser execution thread. Prefer custom in-DOM banners.',
        severity: 'warn',
      });
    }

    if (project.category === 'game' && !jsContent.includes('requestAnimationFrame')) {
      findings.push({
        title: 'Missing requestAnimationFrame loop',
        desc: 'Canvas games should use requestAnimationFrame for smooth 60fps rendering.',
        severity: 'warn',
      });
    }

    if (jsContent.includes('var ')) {
      findings.push({
        title: 'Legacy "var" keyword used',
        desc: 'Consider refactoring "var" to block-scoped "let" or "const" for reliability.',
        severity: 'info',
      });
    }

    if (findings.length === 0) {
      findings.push({
        title: 'Optimal Code Health',
        desc: 'No major architectural bottlenecks or anti-patterns detected in project files.',
        severity: 'good',
      });
    }

    return findings;
  };

  return (
    <div
      className={`border-t border-slate-800 bg-[#070a14] flex flex-col transition-all duration-200 select-none ${
        isOpen ? 'h-52 md:h-64' : 'h-8'
      }`}
    >
      {/* Tab bar header */}
      <div className="h-8 bg-[#090d18] px-3 flex items-center justify-between border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setActiveTab('console');
              if (!isOpen) onToggleOpen();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
              activeTab === 'console' && isOpen
                ? 'bg-cyan-500/20 text-cyan-300'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Console</span>
            {errorCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-400 font-mono text-[10px]">
                {errorCount}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              setActiveTab('tests');
              if (!isOpen) onToggleOpen();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
              activeTab === 'tests' && isOpen
                ? 'bg-purple-500/20 text-purple-300'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FlaskConical className="w-3.5 h-3.5" />
            <span>Test Runner</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('auditor');
              if (!isOpen) onToggleOpen();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
              activeTab === 'auditor' && isOpen
                ? 'bg-emerald-500/20 text-emerald-300'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Bug className="w-3.5 h-3.5" />
            <span>Code Health</span>
          </button>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          {activeTab === 'console' && isOpen && (
            <>
              {/* Filter pills */}
              <div className="hidden sm:flex items-center gap-1 text-[11px]">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-1.5 py-0.5 rounded ${
                    filter === 'all' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilter('log')}
                  className={`px-1.5 py-0.5 rounded ${
                    filter === 'log' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Logs
                </button>
                <button
                  onClick={() => setFilter('warn')}
                  className={`px-1.5 py-0.5 rounded ${
                    filter === 'warn' ? 'bg-amber-900/40 text-amber-300' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Warns ({warnCount})
                </button>
                <button
                  onClick={() => setFilter('error')}
                  className={`px-1.5 py-0.5 rounded ${
                    filter === 'error' ? 'bg-rose-900/40 text-rose-300' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Errors ({errorCount})
                </button>
              </div>

              {/* Clear button */}
              <button
                onClick={onClearLogs}
                title="Clear console"
                aria-label="Clear console"
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </>
          )}

          {/* Toggle open/close */}
          <button
            onClick={onToggleOpen}
            aria-label={isOpen ? 'Collapse console' : 'Expand console'}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {isOpen && (
        <div className="flex-1 overflow-auto p-3 font-mono text-xs bg-[#050811]">
          {/* TAB 1: CONSOLE LOGS */}
          {activeTab === 'console' && (
            <div className="space-y-1">
              {filteredLogs.length === 0 ? (
                <div className="text-slate-500 py-4 text-center">Console is clear. No output emitted.</div>
              ) : (
                filteredLogs.map(entry => (
                  <div
                    key={entry.id}
                    className={`flex items-start justify-between p-1.5 rounded hover:bg-slate-800/40 transition-colors ${
                      entry.type === 'error'
                        ? 'bg-rose-950/20 text-rose-300 border-l-2 border-rose-500'
                        : entry.type === 'warn'
                        ? 'bg-amber-950/20 text-amber-300 border-l-2 border-amber-500'
                        : entry.type === 'system'
                        ? 'text-cyan-400/80 font-semibold'
                        : 'text-slate-300'
                    }`}
                  >
                    <div className="flex items-start gap-2 flex-1 mr-2 break-all">
                      {entry.type === 'error' && <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />}
                      {entry.type === 'warn' && <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />}
                      {entry.type === 'info' && <Info className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />}
                      <div>
                        <div>{entry.message}</div>
                        {entry.stack && (
                          <div className="text-[10px] text-slate-500 mt-0.5 whitespace-pre-wrap">{entry.stack}</div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* Diagnose with AI button if error */}
                      {entry.type === 'error' && (
                        <button
                          onClick={() => onDiagnoseError(entry.message, entry.stack)}
                          className="flex items-center gap-1 px-2 py-0.5 rounded bg-cyan-500/15 hover:bg-cyan-500/30 text-cyan-300 text-[10px] font-semibold border border-cyan-500/30 transition-colors"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>Fix with AI</span>
                        </button>
                      )}
                      <span className="text-[10px] text-slate-500">{entry.timestamp}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 2: TEST RUNNER */}
          {activeTab === 'tests' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="text-slate-300 font-semibold flex items-center gap-2">
                  <span>Unit Test Runner & Validation Suite</span>
                  {testResults.length > 0 && (
                    <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                      {testResults.filter(t => t.status === 'pass').length} / {testResults.length} Passed
                    </span>
                  )}
                </div>
                <button
                  onClick={runTests}
                  disabled={isRunningTests}
                  className="px-3 py-1 rounded-md bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-purple-900/30 transition-all active:scale-95"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningTests ? 'Running...' : 'Run Test Suite'}</span>
                </button>
              </div>

              {testResults.length === 0 ? (
                <div className="text-slate-500 text-center py-6">
                  Click "Run Test Suite" to execute deterministic assertions and code health checks.
                </div>
              ) : (
                <div className="space-y-1.5">
                  {testResults.map(test => (
                    <div
                      key={test.id}
                      className={`p-2 rounded-lg border flex items-center justify-between ${
                        test.status === 'pass'
                          ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-300'
                          : 'bg-rose-950/20 border-rose-900/40 text-rose-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {test.status === 'pass' ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        )}
                        <div>
                          <div className="font-bold text-xs text-white">{test.name}</div>
                          <div className="text-[11px] text-slate-400">{test.message}</div>
                        </div>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">{test.durationMs}ms</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: CODE HEALTH AUDITOR */}
          {activeTab === 'auditor' && (
            <div className="space-y-2">
              <div className="text-slate-300 font-semibold mb-2">Static Analysis & Best Practices</div>
              {getAuditFindings().map((finding, idx) => (
                <div
                  key={idx}
                  className={`p-2.5 rounded-lg border ${
                    finding.severity === 'warn'
                      ? 'bg-amber-950/20 border-amber-800/40 text-amber-200'
                      : finding.severity === 'info'
                      ? 'bg-sky-950/20 border-sky-800/40 text-sky-200'
                      : 'bg-emerald-950/20 border-emerald-800/40 text-emerald-200'
                  }`}
                >
                  <div className="font-bold text-xs mb-0.5">{finding.title}</div>
                  <div className="text-[11px] opacity-80">{finding.desc}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
