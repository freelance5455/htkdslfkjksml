import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  Printer,
  Image as ImageIcon,
  ArrowUpDown,
  X,
  FilePlus,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { OperationalReport, Sector, ReportFilterOptions } from '../types/report';
import {
  formatDate,
  formatDateTime,
  getStatusLabel,
  getStatusTextColor,
  getPriorityLabel,
  getPriorityTextColor,
  getShiftLabel
} from '../utils/formatters';
import { SectorIcon } from './SectorIcon';

interface Props {
  reports: OperationalReport[];
  sectors: Sector[];
  selectedSectorId: string;
  onOpenReport: (report: OperationalReport) => void;
  onEditReport: (report: OperationalReport) => void;
  onDeleteReport: (id: string) => void;
  onPrintReport: (report: OperationalReport) => void;
  onOpenNewReportModal: () => void;
}

export const ReportTable: React.FC<Props> = ({
  reports,
  sectors,
  selectedSectorId,
  onOpenReport,
  onEditReport,
  onDeleteReport,
  onPrintReport,
  onOpenNewReportModal
}) => {
  // Search and filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [shiftFilter, setShiftFilter] = useState('all');
  const [onlyWithImages, setOnlyWithImages] = useState(false);
  const [sortBy, setSortBy] = useState<'date' | 'protocol' | 'title' | 'sector' | 'status' | 'priority'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const sectorMap = useMemo(() => new Map(sectors.map((s) => [s.id, s])), [sectors]);

  // Handle sort toggle
  const toggleSort = (column: 'date' | 'protocol' | 'title' | 'sector' | 'status' | 'priority') => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  // Filter and sort reports
  const filteredReports = useMemo(() => {
    return reports
      .filter((report) => {
        // Sector filter
        if (selectedSectorId !== 'all' && report.sectorId !== selectedSectorId) {
          return false;
        }

        // Status filter
        if (statusFilter !== 'all' && report.status !== statusFilter) {
          return false;
        }

        // Priority filter
        if (priorityFilter !== 'all' && report.priority !== priorityFilter) {
          return false;
        }

        // Shift filter
        if (shiftFilter !== 'all' && report.shift !== shiftFilter) {
          return false;
        }

        // Images only
        if (onlyWithImages && report.images.length === 0) {
          return false;
        }

        // Search text
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = report.title.toLowerCase().includes(q);
          const matchProtocol = report.protocolNumber.toLowerCase().includes(q);
          const matchOperator = report.operatorName.toLowerCase().includes(q);
          const matchLocation = report.location.toLowerCase().includes(q);
          const matchDesc = report.description.toLowerCase().includes(q);
          const matchSector = (sectorMap.get(report.sectorId)?.name || '').toLowerCase().includes(q);

          if (!matchTitle && !matchProtocol && !matchOperator && !matchLocation && !matchDesc && !matchSector) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        let diff = 0;
        if (sortBy === 'date') {
          diff = new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
        } else if (sortBy === 'protocol') {
          diff = a.protocolNumber.localeCompare(b.protocolNumber);
        } else if (sortBy === 'title') {
          diff = a.title.localeCompare(b.title);
        } else if (sortBy === 'sector') {
          const nameA = sectorMap.get(a.sectorId)?.name || '';
          const nameB = sectorMap.get(b.sectorId)?.name || '';
          diff = nameA.localeCompare(nameB);
        } else if (sortBy === 'status') {
          diff = a.status.localeCompare(b.status);
        } else if (sortBy === 'priority') {
          const pOrder = { urgente: 4, alta: 3, media: 2, bassa: 1 };
          diff = (pOrder[a.priority] || 0) - (pOrder[b.priority] || 0);
        }

        return sortOrder === 'asc' ? diff : -diff;
      });
  }, [
    reports,
    selectedSectorId,
    statusFilter,
    priorityFilter,
    shiftFilter,
    onlyWithImages,
    searchQuery,
    sortBy,
    sortOrder,
    sectorMap
  ]);

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    statusFilter !== 'all' ||
    priorityFilter !== 'all' ||
    shiftFilter !== 'all' ||
    onlyWithImages;

  const resetFilters = () => {
    setSearchQuery('');
    setStatusFilter('all');
    setPriorityFilter('all');
    setShiftFilter('all');
    setOnlyWithImages(false);
  };

  const currentSectorObj = sectors.find((s) => s.id === selectedSectorId);

  return (
    <div className="space-y-4">
      {/* Top Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-neutral-200">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-neutral-900">
              Database Report Operativi
            </h1>
            {selectedSectorId !== 'all' && currentSectorObj && (
              <span className="text-xs text-neutral-500">
                / {currentSectorObj.name}
              </span>
            )}
          </div>
          <p className="text-xs text-neutral-500 mt-0.5">
            Registro cronologico completo con metriche, allegati fotografici e convalide
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenNewReportModal}
            className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition-colors whitespace-nowrap"
          >
            <FilePlus className="w-3.5 h-3.5" />
            <span>Nuovo Inserimento</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-neutral-200 rounded-lg p-3 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center gap-2.5">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cerca per titolo, protocollo, operatore, impianto o note..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 focus:bg-white text-neutral-900"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Status Dropdown Filter */}
          <div className="flex items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs py-1.5 px-2.5 bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 text-neutral-700"
            >
              <option value="all">Tutti gli stati</option>
              <option value="completato">Completato</option>
              <option value="in_corso">In Lavorazione</option>
              <option value="in_revisione">In Revisione</option>
              <option value="critico">Critico / Bloccante</option>
            </select>

            {/* Priority Dropdown */}
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="text-xs py-1.5 px-2.5 bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 text-neutral-700"
            >
              <option value="all">Tutte le priorità</option>
              <option value="urgente">Urgente</option>
              <option value="alta">Alta</option>
              <option value="media">Media</option>
              <option value="bassa">Bassa</option>
            </select>

            {/* Shift Dropdown */}
            <select
              value={shiftFilter}
              onChange={(e) => setShiftFilter(e.target.value)}
              className="text-xs py-1.5 px-2.5 bg-neutral-50 border border-neutral-200 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 text-neutral-700"
            >
              <option value="all">Tutti i turni</option>
              <option value="mattina">Turno Mattina</option>
              <option value="pomeriggio">Turno Pomeriggio</option>
              <option value="notte">Turno Notte</option>
              <option value="giornaliero">Giornaliero</option>
            </select>

            {/* Only With Images Toggle Button (Interactive Filter Control) */}
            <button
              onClick={() => setOnlyWithImages(!onlyWithImages)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-md transition-colors whitespace-nowrap ${
                onlyWithImages
                  ? 'bg-neutral-900 text-white font-medium'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Con Foto</span>
            </button>

            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="text-xs text-neutral-500 hover:text-neutral-900 px-2 py-1 underline whitespace-nowrap"
              >
                Azzera filtri
              </button>
            )}
          </div>
        </div>

        {/* Counter & Meta */}
        <div className="flex items-center justify-between text-[11px] text-neutral-500 pt-1 border-t border-neutral-100">
          <div>
            Visualizzazione di <span className="font-mono tabular-nums text-neutral-900 font-medium">{filteredReports.length}</span> di <span className="font-mono tabular-nums">{reports.length}</span> report
            {selectedSectorId !== 'all' && currentSectorObj && (
              <> nel settore <span className="font-medium text-neutral-800">{currentSectorObj.name}</span></>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span>Ordina per colonne cliccando sull&apos;intestazione</span>
          </div>
        </div>
      </div>

      {/* High Density Table */}
      <div className="bg-white border border-neutral-200 rounded-lg overflow-hidden shadow-xs">
        {filteredReports.length === 0 ? (
          <div className="py-16 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-neutral-100 mx-auto flex items-center justify-center text-neutral-400">
              <Filter className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-neutral-900">
                Nessun report trovato
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Nessun record corrisponde ai criteri di ricerca selezionati. Prova a modificare i filtri o inserisci un nuovo report.
              </p>
            </div>
            <div>
              {hasActiveFilters ? (
                <button
                  onClick={resetFilters}
                  className="px-3.5 py-1.5 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors"
                >
                  Reimposta Filtri
                </button>
              ) : (
                <button
                  onClick={onOpenNewReportModal}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors"
                >
                  Registra Primo Report
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-neutral-200 bg-neutral-50/80 text-[11px] font-semibold text-neutral-600 select-none">
                  <th
                    onClick={() => toggleSort('protocol')}
                    className="py-2.5 px-3.5 cursor-pointer hover:text-neutral-900 whitespace-nowrap"
                  >
                    <div className="flex items-center gap-1">
                      <span>Protocollo</span>
                      <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('date')}
                    className="py-2.5 px-3.5 cursor-pointer hover:text-neutral-900 whitespace-nowrap"
                  >
                    <div className="flex items-center gap-1">
                      <span>Data & Turno</span>
                      <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('sector')}
                    className="py-2.5 px-3.5 cursor-pointer hover:text-neutral-900 whitespace-nowrap"
                  >
                    <div className="flex items-center gap-1">
                      <span>Settore</span>
                      <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('title')}
                    className="py-2.5 px-3.5 cursor-pointer hover:text-neutral-900"
                  >
                    <div className="flex items-center gap-1">
                      <span>Oggetto / Titolo Intervento</span>
                      <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3.5 whitespace-nowrap">
                    Operatore & Ubicazione
                  </th>
                  <th
                    onClick={() => toggleSort('status')}
                    className="py-2.5 px-3.5 cursor-pointer hover:text-neutral-900 whitespace-nowrap"
                  >
                    <div className="flex items-center gap-1">
                      <span>Stato</span>
                      <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('priority')}
                    className="py-2.5 px-3.5 cursor-pointer hover:text-neutral-900 whitespace-nowrap"
                  >
                    <div className="flex items-center gap-1">
                      <span>Priorità</span>
                      <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                    </div>
                  </th>
                  <th className="py-2.5 px-3.5 text-center whitespace-nowrap">
                    Foto
                  </th>
                  <th className="py-2.5 px-3.5 text-right whitespace-nowrap">
                    Azioni
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {filteredReports.map((report) => {
                  const sector = sectorMap.get(report.sectorId);
                  const hasImages = report.images.length > 0;

                  return (
                    <tr
                      key={report.id}
                      className="hover:bg-neutral-50/70 transition-colors group cursor-pointer"
                      onClick={() => onOpenReport(report)}
                    >
                      {/* Protocollo */}
                      <td className="py-3 px-3.5 font-mono tabular-nums text-neutral-900 font-medium whitespace-nowrap">
                        {report.protocolNumber}
                      </td>

                      {/* Data & Ora */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <div className="text-neutral-900 font-mono tabular-nums">
                          {formatDate(report.timestamp)}
                        </div>
                        <div className="text-[11px] text-neutral-500">
                          {getShiftLabel(report.shift)}
                        </div>
                      </td>

                      {/* Settore */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <SectorIcon
                            name={sector?.iconName || 'Layers'}
                            className="w-3.5 h-3.5 text-neutral-500"
                          />
                          <span className="font-medium text-neutral-800">
                            {sector?.name || report.sectorId}
                          </span>
                        </div>
                      </td>

                      {/* Titolo e breve estratto */}
                      <td className="py-3 px-3.5 max-w-xs">
                        <div className="font-medium text-neutral-900 line-clamp-1 group-hover:text-neutral-700">
                          {report.title}
                        </div>
                        <div className="text-[11px] text-neutral-500 line-clamp-1 mt-0.5">
                          {report.description}
                        </div>
                      </td>

                      {/* Operatore e Ubicazione */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <div className="text-neutral-800 font-medium">
                          {report.operatorName}
                        </div>
                        <div className="text-[11px] text-neutral-500 truncate max-w-[180px]">
                          {report.location}
                        </div>
                      </td>

                      {/* Stato Operativo */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <span className={getStatusTextColor(report.status)}>
                          {getStatusLabel(report.status)}
                        </span>
                      </td>

                      {/* Priorità */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <span className={getPriorityTextColor(report.priority)}>
                          {getPriorityLabel(report.priority)}
                        </span>
                      </td>

                      {/* Foto Allegate */}
                      <td className="py-3 px-3.5 text-center whitespace-nowrap">
                        {hasImages ? (
                          <span className="font-mono tabular-nums text-neutral-900 inline-flex items-center gap-1 text-[11px]">
                            <ImageIcon className="w-3.5 h-3.5 text-neutral-600" />
                            {report.images.length}
                          </span>
                        ) : (
                          <span className="text-neutral-300 text-[11px]">-</span>
                        )}
                      </td>

                      {/* Azioni riga */}
                      <td
                        className="py-3 px-3.5 text-right whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => onOpenReport(report)}
                            title="Visualizza Scheda Dettagliata"
                            className="p-1 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onPrintReport(report)}
                            title="Stampa Scheda PDF"
                            className="p-1 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onEditReport(report)}
                            title="Modifica Report"
                            className="p-1 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm(`Sei sicuro di voler eliminare il report ${report.protocolNumber}?`)) {
                                onDeleteReport(report.id);
                              }
                            }}
                            title="Elimina Report"
                            className="p-1 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
