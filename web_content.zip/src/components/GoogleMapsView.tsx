import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  InfoWindow,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  MapPin,
  Search,
  Navigation,
  Compass,
  Bookmark,
  Trash2,
  Share2,
  ExternalLink,
  Layers,
  Sparkles,
  Plus,
  X,
  Check,
  ChevronRight,
  Route as RouteIcon,
  Loader2,
  LocateFixed,
  Eye,
  Info,
} from 'lucide-react';
import {
  FirestoreSavedPlace,
  savePlaceToFirestore,
  fetchPlacesFromFirestore,
  deletePlaceFromFirestore,
} from '../lib/firebase';
import { User } from '../types/auth';

interface GoogleMapsViewProps {
  user: User | null;
  isLight?: boolean;
}

// Preset popular locations in the Arab world and globally
const INITIAL_CENTER = { lat: 24.7136, lng: 46.6753 }; // Riyadh
const DEFAULT_ZOOM = 13;

const PRESET_PLACES: Array<{ name: string; lat: number; lng: number; category: string }> = [
  { name: 'الرياض - برج المملكة', lat: 24.7114, lng: 46.6744, category: 'معلم سياحي' },
  { name: 'دبي - برج خليفة', lat: 25.1972, lng: 55.2744, category: 'معلم سياحي' },
  { name: 'القاهرة - الأهرامات', lat: 29.9792, lng: 31.1342, category: 'تاريخي' },
  { name: 'مكة المكرمة - المسجد الحرام', lat: 21.4225, lng: 39.8262, category: 'ديني' },
  { name: 'الدوحة - كورنيش الدوحة', lat: 25.305, lng: 51.528, category: 'ترفيهي' },
];

// Inner controller component that utilizes useMap and useMapsLibrary
const MapController: React.FC<{
  selectedPlace: { lat: number; lng: number } | null;
  routeOrigin: { lat: number; lng: number } | null;
  routeDestination: { lat: number; lng: number } | null;
  onRouteCalculated?: (distanceText: string, durationText: string) => void;
}> = ({ selectedPlace, routeOrigin, routeDestination, onRouteCalculated }) => {
  const map = useMap();
  const routesLibrary = useMapsLibrary('routes');
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  // Pan to selected place
  useEffect(() => {
    if (map && selectedPlace) {
      map.panTo(selectedPlace);
      map.setZoom(15);
    }
  }, [map, selectedPlace]);

  // Handle route calculation using modern Routes API
  useEffect(() => {
    if (!map || !routesLibrary || !routeOrigin || !routeDestination) {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
        polylineRef.current = null;
      }
      return;
    }

    const computeAndDrawRoute = async () => {
      try {
        if ((routesLibrary as any).Route?.computeRoutes) {
          const response = await (routesLibrary as any).Route.computeRoutes({
            origin: { location: { latLng: routeOrigin } },
            destination: { location: { latLng: routeDestination } },
            travelMode: 'DRIVE',
            fields: ['routes.distanceMeters', 'routes.duration', 'routes.polyline.encodedPolyline'],
          });

          const route = response.routes?.[0];
          if (route) {
            if (polylineRef.current) {
              polylineRef.current.setMap(null);
            }

            const path = google.maps.geometry.encoding.decodePath(route.polyline.encodedPolyline);
            const polyline = new google.maps.Polyline({
              path,
              strokeColor: '#3B82F6',
              strokeOpacity: 0.9,
              strokeWeight: 6,
              map,
            });
            polylineRef.current = polyline;

            const distKm = ((route.distanceMeters || 0) / 1000).toFixed(1);
            const durMin = Math.round(parseInt(route.duration?.replace('s', '') || '0') / 60);

            if (onRouteCalculated) {
              onRouteCalculated(`${distKm} كم`, `${durMin} دقيقة`);
            }
          }
        }
      } catch (e) {
        console.warn('Routes calculation error:', e);
      }
    };

    computeAndDrawRoute();

    return () => {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
      }
    };
  }, [map, routesLibrary, routeOrigin, routeDestination, onRouteCalculated]);

  return null;
};

export const GoogleMapsView: React.FC<GoogleMapsViewProps> = ({ user, isLight = false }) => {
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyCzOtERrQQ2-tx-1v3ynzuDDuX9VHT3VZg';

  const [savedPlaces, setSavedPlaces] = useState<FirestoreSavedPlace[]>([]);
  const [activeMarker, setActiveMarker] = useState<FirestoreSavedPlace | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [mapType, setMapType] = useState<'roadmap' | 'satellite' | 'hybrid' | 'terrain'>('roadmap');
  const [isAddingPlace, setIsAddingPlace] = useState(false);
  const [newPlaceName, setNewPlaceName] = useState('');
  const [newPlaceCategory, setNewPlaceCategory] = useState('مفضل');
  const [newPlaceNotes, setNewPlaceNotes] = useState('');
  const [tempCoords, setTempCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [selectedTarget, setSelectedTarget] = useState<{ lat: number; lng: number } | null>(null);

  // Directions state
  const [isRoutingActive, setIsRoutingActive] = useState(false);
  const [routeOrigin, setRouteOrigin] = useState<{ lat: number; lng: number } | null>(null);
  const [routeDest, setRouteDest] = useState<{ lat: number; lng: number } | null>(null);
  const [routeSummary, setRouteSummary] = useState<{ distance: string; duration: string } | null>(null);

  // Notification / toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Load saved places from Firestore on user load
  useEffect(() => {
    if (user?.id) {
      fetchPlacesFromFirestore(user.id).then((places) => {
        if (places.length > 0) {
          setSavedPlaces(places);
        } else {
          // Initialize with popular presets for smooth demo experience
          const presets: FirestoreSavedPlace[] = PRESET_PLACES.map((p, idx) => ({
            id: `preset-${idx}`,
            userId: user.id,
            name: p.name,
            address: p.name,
            lat: p.lat,
            lng: p.lng,
            category: p.category,
            notes: 'مكان مقترح تم إضافته تلقائياً',
            createdAt: Date.now() - idx * 10000,
          }));
          setSavedPlaces(presets);
        }
      });
    }
  }, [user]);

  // Current Geolocation handler
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      showToast('المتصفح لا يدعم تحديد الموقع الجغرافي');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setUserLocation(coords);
        setSelectedTarget(coords);
        showToast('تم تحديد موقعك الحالي بدقة!');
      },
      (err) => {
        setIsLocating(false);
        showToast('تعذر الوصول إلى الموقع الجغرافي: ' + err.message);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Handle map click to drop pin
  const handleMapClick = (e: any) => {
    if (!e.detail?.latLng) return;
    const { lat, lng } = e.detail.latLng;
    setTempCoords({ lat, lng });
    setIsAddingPlace(true);
    setNewPlaceName(`موقع (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
  };

  // Save new place to Firestore
  const handleSavePlace = async () => {
    if (!tempCoords || !newPlaceName.trim()) return;
    const userId = user?.id || 'guest-user';
    const placeId = `pl-${Date.now()}`;
    const newPlace: FirestoreSavedPlace = {
      id: placeId,
      userId,
      name: newPlaceName.trim(),
      address: `${tempCoords.lat.toFixed(5)}, ${tempCoords.lng.toFixed(5)}`,
      lat: tempCoords.lat,
      lng: tempCoords.lng,
      category: newPlaceCategory,
      notes: newPlaceNotes.trim(),
      createdAt: Date.now(),
    };

    setSavedPlaces((prev) => [newPlace, ...prev]);
    setIsAddingPlace(false);
    setTempCoords(null);
    setNewPlaceName('');
    setNewPlaceNotes('');

    try {
      if (user?.id) {
        await savePlaceToFirestore(userId, newPlace);
      }
      showToast('تم حفظ المكان بنجاح في Firebase!');
    } catch (e) {
      console.warn('Saved locally:', e);
      showToast('تم حفظ المكان محلياً');
    }
  };

  // Delete place
  const handleDeletePlace = async (placeId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const userId = user?.id || 'guest-user';
    setSavedPlaces((prev) => prev.filter((p) => p.id !== placeId));
    if (activeMarker?.id === placeId) {
      setActiveMarker(null);
    }
    try {
      if (user?.id) {
        await deletePlaceFromFirestore(userId, placeId);
      }
      showToast('تم حذف المكان');
    } catch (e) {
      console.warn('Deleted locally:', e);
    }
  };

  // Quick geocoding search for common cities
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    const query = searchQuery.trim().toLowerCase();
    const matched = savedPlaces.find((p) => p.name.toLowerCase().includes(query));
    if (matched) {
      setSelectedTarget({ lat: matched.lat, lng: matched.lng });
      setActiveMarker(matched);
      showToast(`الانتقال إلى: ${matched.name}`);
      return;
    }

    // Known geocode fallbacks for instant responsiveness
    const cityMap: Record<string, { lat: number; lng: number; name: string }> = {
      الرياض: { lat: 24.7136, lng: 46.6753, name: 'الرياض، المملكة العربية السعودية' },
      جدة: { lat: 21.5433, lng: 39.1728, name: 'جدة، المملكة العربية السعودية' },
      دبي: { lat: 25.2048, lng: 55.2708, name: 'دبي، الإمارات العربية المتحدة' },
      أبوظبي: { lat: 24.4539, lng: 54.3773, name: 'أبوظبي، الإمارات العربية المتحدة' },
      القاهرة: { lat: 30.0444, lng: 31.2357, name: 'القاهرة، مصر' },
      الدوحة: { lat: 25.2854, lng: 51.531, name: 'الدوحة، قطر' },
      الكويت: { lat: 29.3759, lng: 47.9774, name: 'الكويت' },
      المنامة: { lat: 26.2285, lng: 50.586, name: 'المنامة، البحرين' },
      مسقط: { lat: 23.588, lng: 58.3829, name: 'مسقط، عُمان' },
      عمان: { lat: 31.9454, lng: 35.9284, name: 'عمّان، الأردن' },
      بيروت: { lat: 33.8938, lng: 35.5018, name: 'بيروت، لبنان' },
    };

    for (const [key, val] of Object.entries(cityMap)) {
      if (query.includes(key)) {
        setSelectedTarget({ lat: val.lat, lng: val.lng });
        showToast(`تم العثور على: ${val.name}`);
        return;
      }
    }

    showToast('ابحث عن مدينة أو انقر مباشرة على الخريطة لتحديد أي موقع بدقة.');
  };

  return (
    <div className={`flex flex-col h-full w-full relative overflow-hidden ${isLight ? 'bg-slate-50 text-slate-800' : 'bg-slate-950 text-slate-100'}`}>
      {/* Toast Alert */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-blue-600 text-white rounded-full shadow-lg text-sm font-medium flex items-center gap-2 animate-in fade-in slide-in-from-top duration-200">
          <Sparkles className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Action Bar */}
      <div className={`p-4 border-b flex flex-wrap items-center justify-between gap-3 z-10 ${isLight ? 'bg-white/80 border-slate-200' : 'bg-slate-900/80 border-slate-800'} backdrop-blur-md`}>
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-blue-600/10 text-blue-500">
            <Compass className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <h1 className="text-lg font-bold flex items-center gap-2">
              خرائط Google
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-medium">
                Google Maps Platform
              </span>
            </h1>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              استكشف المواقع الجغرافية، واحفظ الأماكن المفضلة مع مزامنة فورية في Firebase
            </p>
          </div>
        </div>

        {/* Search bar */}
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 max-w-md w-full sm:w-auto">
          <div className="relative flex-1">
            <Search className={`w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 ${isLight ? 'text-slate-400' : 'text-slate-500'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن مدينة، معلم، أو موقع..."
              className={`w-full pr-9 pl-3 py-1.5 text-sm rounded-xl border focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                isLight ? 'bg-slate-100 border-slate-300 text-slate-800 placeholder:text-slate-400' : 'bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500'
              }`}
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-medium transition"
          >
            بحث
          </button>
        </form>

        {/* Map Type Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleGetLocation}
            disabled={isLocating}
            title="تحديد موقعي الحالي"
            className={`p-2 rounded-xl border transition flex items-center gap-1 text-xs font-medium ${
              isLight ? 'border-slate-300 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
            }`}
          >
            {isLocating ? <Loader2 className="w-4 h-4 animate-spin text-blue-500" /> : <LocateFixed className="w-4 h-4 text-blue-500" />}
            <span className="hidden md:inline">موقعي</span>
          </button>

          <button
            onClick={() => setMapType((prev) => (prev === 'roadmap' ? 'satellite' : prev === 'satellite' ? 'hybrid' : 'roadmap'))}
            className={`p-2 rounded-xl border transition flex items-center gap-1 text-xs font-medium ${
              isLight ? 'border-slate-300 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4 text-emerald-500" />
            <span className="capitalize">{mapType === 'roadmap' ? 'خريطة' : mapType === 'satellite' ? 'قمر صناعي' : 'هجين'}</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar: Saved Places & Controls */}
        <div className={`w-80 border-l flex flex-col hidden lg:flex z-10 ${isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'}`}>
          <div className="p-3 border-b flex items-center justify-between">
            <h2 className="text-sm font-bold flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-amber-500" />
              الأماكن المحفوظة ({savedPlaces.length})
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 font-semibold">
              Firebase Synced
            </span>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {savedPlaces.length === 0 ? (
              <div className="text-center py-10 px-4">
                <MapPin className="w-8 h-8 text-slate-500 mx-auto mb-2 opacity-50" />
                <p className="text-sm text-slate-400">لا توجد أماكن محفوظة بعد.</p>
                <p className="text-xs text-slate-500 mt-1">انقر على أي نقطة في الخريطة لحفظها فوراً.</p>
              </div>
            ) : (
              savedPlaces.map((place) => (
                <div
                  key={place.id}
                  onClick={() => {
                    setSelectedTarget({ lat: place.lat, lng: place.lng });
                    setActiveMarker(place);
                  }}
                  className={`p-3 rounded-xl border transition cursor-pointer group flex items-start justify-between gap-2 ${
                    activeMarker?.id === place.id
                      ? 'border-blue-500 bg-blue-500/10'
                      : isLight
                      ? 'border-slate-200 hover:bg-slate-50'
                      : 'border-slate-800 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-semibold truncate">{place.name}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">{place.address}</p>
                    {place.notes && (
                      <p className="text-[11px] text-slate-400 mt-1 line-clamp-1 italic">
                        "{place.notes}"
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => handleDeletePlace(place.id, e)}
                      title="حذف المكان"
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-400 transition rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition" />
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Quick Route Planner Footer */}
          <div className={`p-3 border-t text-xs ${isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950 border-slate-800'}`}>
            <p className="font-semibold flex items-center gap-1 text-blue-400 mb-1">
              <RouteIcon className="w-3.5 h-3.5" />
              تخطيط المسارات الذكي
            </p>
            <p className="text-slate-500">
              انقر على أي مكان لعرض تفاصيل المسار والاتجاهات عبر Routes API.
            </p>
          </div>
        </div>

        {/* Map Container */}
        <div className="flex-1 h-full w-full relative">
          <APIProvider apiKey={apiKey} language="ar">
            <Map
              defaultCenter={INITIAL_CENTER}
              defaultZoom={DEFAULT_ZOOM}
              mapId="DEMO_MAP_ID"
              internalUsageAttributionIds={['gmp_git_agentskills_v1']}
              mapTypeId={mapType}
              gestureHandling="greedy"
              disableDefaultUI={false}
              onClick={handleMapClick}
              className="w-full h-full"
            >
              <MapController
                selectedPlace={selectedTarget}
                routeOrigin={routeOrigin}
                routeDestination={routeDest}
                onRouteCalculated={(dist, dur) => setRouteSummary({ distance: dist, duration: dur })}
              />

              {/* User Current Location Marker */}
              {userLocation && (
                <AdvancedMarker position={userLocation} title="موقعك الحالي">
                  <div className="relative flex items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-blue-400 opacity-75"></span>
                    <div className="relative p-2 bg-blue-600 rounded-full text-white shadow-lg border-2 border-white">
                      <LocateFixed className="w-4 h-4" />
                    </div>
                  </div>
                </AdvancedMarker>
              )}

              {/* Saved Places Markers */}
              {savedPlaces.map((place) => (
                <AdvancedMarker
                  key={place.id}
                  position={{ lat: place.lat, lng: place.lng }}
                  onClick={() => setActiveMarker(place)}
                  title={place.name}
                >
                  <Pin
                    background={activeMarker?.id === place.id ? '#3B82F6' : '#10B981'}
                    borderColor="#FFFFFF"
                    glyphColor="#FFFFFF"
                  />
                </AdvancedMarker>
              ))}

              {/* Temporary Click Pin */}
              {tempCoords && (
                <AdvancedMarker position={tempCoords} title="مكان محدد">
                  <Pin background="#F59E0B" borderColor="#FFFFFF" glyphColor="#FFFFFF" />
                </AdvancedMarker>
              )}

              {/* Info Window for Active Marker */}
              {activeMarker && (
                <InfoWindow
                  position={{ lat: activeMarker.lat, lng: activeMarker.lng }}
                  onCloseClick={() => setActiveMarker(null)}
                >
                  <div className="p-2 max-w-xs text-right text-slate-900" dir="rtl">
                    <div className="flex items-center gap-1 text-xs text-blue-600 font-bold mb-1">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{activeMarker.category || 'مكان محفوظ'}</span>
                    </div>
                    <h3 className="font-bold text-sm text-slate-900">{activeMarker.name}</h3>
                    <p className="text-xs text-slate-600 mt-0.5">{activeMarker.address}</p>
                    {activeMarker.notes && (
                      <p className="text-xs bg-slate-100 p-1.5 rounded mt-1.5 text-slate-700 italic">
                        {activeMarker.notes}
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-200">
                      <a
                        href={`https://www.google.com/maps/search/?api=1&query=${activeMarker.lat},${activeMarker.lng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-blue-600 hover:underline flex items-center gap-1 font-medium"
                      >
                        فتح في خرائط Google
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </InfoWindow>
              )}
            </Map>
          </APIProvider>

          {/* Add Place Dialog Overlay */}
          {isAddingPlace && tempCoords && (
            <div className={`absolute bottom-6 right-6 z-20 w-80 p-4 rounded-2xl shadow-2xl border ${
              isLight ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-700'
            } animate-in fade-in zoom-in-95 duration-150`}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-amber-500" />
                  حفظ مكان جديد
                </h3>
                <button
                  onClick={() => setIsAddingPlace(false)}
                  className="text-slate-400 hover:text-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">اسم المكان</label>
                  <input
                    type="text"
                    value={newPlaceName}
                    onChange={(e) => setNewPlaceName(e.target.value)}
                    placeholder="مثال: مكتبي، مطعم مفضل..."
                    className={`w-full px-3 py-1.5 text-xs rounded-xl border focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                      isLight ? 'bg-slate-50 border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">التصنيف</label>
                  <select
                    value={newPlaceCategory}
                    onChange={(e) => setNewPlaceCategory(e.target.value)}
                    className={`w-full px-3 py-1.5 text-xs rounded-xl border focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                      isLight ? 'bg-slate-50 border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  >
                    <option value="مفضل">⭐ مفضل</option>
                    <option value="عمل">💼 عمل</option>
                    <option value="مطعم">🍽️ مطعم / مقهى</option>
                    <option value="معلم سياحي">🏛️ معلم سياحي</option>
                    <option value="تسوق">🛍️ تسوق</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">ملاحظات إضافية (اختياري)</label>
                  <input
                    type="text"
                    value={newPlaceNotes}
                    onChange={(e) => setNewPlaceNotes(e.target.value)}
                    placeholder="ملاحظات تذكرك بهذا المكان..."
                    className={`w-full px-3 py-1.5 text-xs rounded-xl border focus:outline-none focus:ring-1 focus:ring-blue-500 ${
                      isLight ? 'bg-slate-50 border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  />
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    onClick={handleSavePlace}
                    className="flex-1 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    حفظ في Firebase
                  </button>
                  <button
                    onClick={() => setIsAddingPlace(false)}
                    className={`px-3 py-1.5 rounded-xl text-xs border font-medium ${
                      isLight ? 'border-slate-300 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
