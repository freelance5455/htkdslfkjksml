import { ArrowRight, Check, Shield } from "lucide-react";
import { CHECK_LABELS } from "@/lib/security/device-checks";
import { securedLabel } from "@/lib/security/score";
import { cn } from "@/lib/cn";
import { Meter, PercentLockup } from "./percent";

type Props = {
  percent: number | null;
  caption: string;
  running: boolean;
  step: string | null;
  doneIds: string[];
  device: number | null;
  apps: number | null;
  files: number | null;
  onScan: () => void;
};

export function SecuredHero({
  percent,
  caption,
  running,
  step,
  doneIds,
  device,
  apps,
  files,
  onScan,
}: Props) {
  return (
    <section className="rounded-3xl bg-card p-2 shadow-card">
      <div className="rounded-2xl bg-paper px-5 py-6 sm:px-8 sm:py-8">
        {running ? (
          <ScanProgress step={step} doneIds={doneIds} />
        ) : percent == null ? (
          <Intro onScan={onScan} />
        ) : (
          <Result
            percent={percent}
            caption={caption}
            device={device}
            apps={apps}
            files={files}
            onScan={onScan}
          />
        )}
      </div>
    </section>
  );
}

function Intro({ onScan }: { onScan: () => void }) {
  return (
    <div>
      <p className="text-xs font-medium tracking-widest text-pine uppercase">For every device</p>
      <h1 className="mt-3 max-w-xl font-display text-4xl leading-tight text-ink sm:text-5xl">
        Is this device safe to trust?
      </h1>
      <p className="mt-4 max-w-xl text-base leading-relaxed text-muted">
        Aegis checks the browser, the apps you ask about, and the files you choose. When the scan finishes
        you get a percentage — 90% secured, 99% secured, or lower when something needs a decision.
      </p>
      <button
        type="button"
        onClick={onScan}
        className="mt-6 inline-flex h-12 items-center gap-2 rounded-full bg-pine pr-4 pl-5 text-base font-medium text-paper transition-colors duration-200 hover:bg-pine-deep"
      >
        Scan this device
        <ArrowRight className="size-4" aria-hidden="true" />
      </button>
      <p className="mt-4 text-sm text-muted">Works on iPhone, Android, and computers. Files never leave the device.</p>
      <ul className="mt-8 grid gap-4 border-t border-line pt-6 sm:grid-cols-3">
        <Promise title="Device" text="Connection, browser age, and the questions only you can answer." />
        <Promise title="Apps" text="Stalkerware, modded apps, and fake cleaners — by name." />
        <Promise title="Files" text="Disguised names, programs pretending to be photos, risky links." />
      </ul>
    </div>
  );
}

function Promise({ title, text }: { title: string; text: string }) {
  return (
    <li>
      <p className="text-sm font-medium text-ink">{title}</p>
      <p className="mt-1 text-sm leading-relaxed text-muted">{text}</p>
    </li>
  );
}

function ScanProgress({ step, doneIds }: { step: string | null; doneIds: string[] }) {
  return (
    <div>
      <p className="text-xs font-medium tracking-widest text-pine uppercase">Scanning</p>
      <h1 className="mt-3 font-display text-4xl text-ink">Checking this device</h1>
      <p className="mt-3 max-w-lg text-base text-muted">
        These are real checks this browser can run. Aegis will not invent a virus to scare you.
      </p>
      <ul className="mt-6 divide-y divide-line" aria-live="polite">
        {CHECK_LABELS.map((item) => {
          const done = doneIds.includes(item.id);
          const active = step === item.label;
          return (
            <li key={item.id} className="flex items-center gap-3 py-3">
              <span
                className={cn(
                  "grid size-6 place-items-center rounded-full",
                  done ? "bg-mist text-pine" : "bg-paper-deep text-transparent",
                )}
                aria-hidden="true"
              >
                {done ? <Check className="size-3.5" strokeWidth={2.5} /> : <span className="size-1.5 rounded-full bg-line" />}
              </span>
              <span className={cn("text-sm", done || active ? "text-ink" : "text-muted")}>
                {item.label}
                {active && !done ? "…" : ""}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Result({
  percent,
  caption,
  device,
  apps,
  files,
  onScan,
}: {
  percent: number;
  caption: string;
  device: number | null;
  apps: number | null;
  files: number | null;
  onScan: () => void;
}) {
  return (
    <div>
      <div className="flex items-start justify-between gap-4">
        <p className="text-xs font-medium tracking-widest text-pine uppercase">Device result</p>
        <button
          type="button"
          onClick={onScan}
          className="inline-flex h-11 items-center rounded-full px-3 text-sm font-medium text-pine hover:bg-mist"
        >
          Scan again
        </button>
      </div>
      <div className="mt-4 grid items-end gap-8 sm:grid-cols-[minmax(0,1fr)_15rem]">
        <div>
          <PercentLockup value={percent} large />
          <p className="mt-4 text-base text-ink">{securedLabel(percent)}</p>
          <p className="mt-1 max-w-md text-sm leading-relaxed text-muted">{caption}</p>
        </div>
        <div className="grid gap-4">
          <Meter label="Device" score={device} />
          <Meter label="Apps" score={apps} />
          <Meter label="Files" score={files} />
        </div>
      </div>
      <div className="mt-6 h-2 overflow-hidden rounded-full bg-paper-deep">
        <div
          className={cn("h-full rounded-full bg-pine transition-[width] duration-700 ease-out", percent < 70 && "bg-clay", percent >= 70 && percent < 90 && "bg-ink")}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}

export function Wordmark() {
  return (
    <div className="flex items-center gap-3">
      <span className="grid size-11 place-items-center rounded-2xl bg-pine text-paper shadow-card">
        <Shield className="size-5" aria-hidden="true" />
      </span>
      <span>
        <span className="block font-display text-xl leading-none text-ink">Aegis</span>
        <span className="mt-1 block text-sm text-muted">Device security</span>
      </span>
    </div>
  );
}
