import { useState } from "react";
import { ExternalLink, ShieldCheck, TriangleAlert, ShieldAlert } from "lucide-react";
import { eicarFile, formatBytes, scanFile, scanFileName } from "@/lib/security/files";
import { inspectLink } from "@/lib/security/links";
import type { FileReport, LinkReport, Severity } from "@/lib/security/types";
import { cn } from "@/lib/cn";
import { PercentLockup } from "./percent";

type Props = {
  files: FileReport[];
  links: LinkReport[];
  onFiles: (files: FileReport[]) => void;
  onLinks: (links: LinkReport[]) => void;
  filesPercent: number | null;
};

export function FilesPanel({ files, links, onFiles, onLinks, filesPercent }: Props) {
  const [over, setOver] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [link, setLink] = useState("");

  async function take(list: FileList | File[]) {
    const batch = [...list].slice(0, 8);
    if (!batch.length) return;
    setBusy(`Reading ${batch.length === 1 ? batch[0]!.name : `${batch.length} files`}`);
    const next: FileReport[] = [];
    for (const file of batch) {
      setBusy(`Reading ${file.name}`);
      next.push(await scanFile(file));
    }
    onFiles([...next, ...files].slice(0, 12));
    setBusy(null);
  }

  function addName(value: string) {
    const trimmed = value.trim();
    if (!trimmed) return;
    onFiles([scanFileName(trimmed), ...files].slice(0, 12));
    setName("");
  }

  function addLink(value: string) {
    const report = inspectLink(value);
    if (!report) return;
    onLinks([report, ...links].slice(0, 12));
    setLink("");
  }

  return (
    <section className="mt-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl text-ink">Files and links</h2>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
            Drop a download, type a suspicious name, or paste a link. Scanning happens on this device.
            Nothing is uploaded.
          </p>
        </div>
        {filesPercent != null ? <PercentLockup value={filesPercent} /> : null}
      </div>

      <div
        onDragOver={(event) => {
          event.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(event) => {
          event.preventDefault();
          setOver(false);
          if (event.dataTransfer.files.length) void take(event.dataTransfer.files);
        }}
        className={cn(
          "mt-5 rounded-3xl bg-card px-5 py-8 text-center shadow-card",
          over && "bg-mist",
        )}
      >
        <p className="font-display text-2xl text-ink">Drop files here</p>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted">
          On a phone, use the button. Photos, APKs, documents, and installers are all fine.
        </p>
        <label className="mt-5 inline-flex h-12 cursor-pointer items-center rounded-full bg-pine px-5 text-sm font-medium text-paper hover:bg-pine-deep">
          Choose files
          <input
            type="file"
            multiple
            className="sr-only"
            onChange={(event) => {
              if (event.target.files) void take(event.target.files);
              event.target.value = "";
            }}
          />
        </label>
        {busy ? <p className="mt-4 text-sm text-pine">{busy}</p> : null}
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <form
          onSubmit={(event) => {
            event.preventDefault();
            addName(name);
          }}
        >
          <label className="block text-sm font-medium text-ink" htmlFor="file-name">
            File name
          </label>
          <div className="mt-2 flex gap-2">
            <input
              id="file-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="Invoice.pdf.exe"
              className="h-12 min-w-0 flex-1 rounded-2xl bg-card px-4 text-base text-ink shadow-card outline-none placeholder:text-muted"
            />
            <button type="submit" className="h-12 rounded-full bg-ink px-4 text-sm font-medium text-paper">
              Check
            </button>
          </div>
        </form>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            addLink(link);
          }}
        >
          <label className="block text-sm font-medium text-ink" htmlFor="link-name">
            Link
          </label>
          <div className="mt-2 flex gap-2">
            <input
              id="link-name"
              value={link}
              onChange={(event) => setLink(event.target.value)}
              placeholder="https://…"
              inputMode="url"
              className="h-12 min-w-0 flex-1 rounded-2xl bg-card px-4 text-base text-ink shadow-card outline-none placeholder:text-muted"
            />
            <button type="submit" className="h-12 rounded-full bg-ink px-4 text-sm font-medium text-paper">
              Check
            </button>
          </div>
        </form>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => addName("Invoice.pdf.exe")}
          className="h-10 rounded-full bg-paper-deep px-3 text-sm text-ink"
        >
          Invoice.pdf.exe
        </button>
        <button
          type="button"
          onClick={() => addLink("https://paypa1.com/signin")}
          className="h-10 rounded-full bg-paper-deep px-3 text-sm text-ink"
        >
          paypa1.com
        </button>
        <button
          type="button"
          onClick={() => void take([eicarFile()])}
          className="h-10 rounded-full bg-paper-deep px-3 text-sm text-ink"
        >
          Harmless test file
        </button>
      </div>

      {files.length + links.length === 0 ? (
        <p className="mt-6 text-sm text-muted">
          A clear result means no harmful pattern in the name or the bytes we could read. It is not a promise
          about files still sitting in a folder you did not open.
        </p>
      ) : (
        <ul className="mt-6 grid gap-3">
          {files.map((file) => (
            <FileCard key={file.id} file={file} />
          ))}
          {links.map((item) => (
            <li key={item.id} className="rounded-2xl bg-card px-4 py-4 shadow-card">
              <VerdictHead severity={item.severity} title={item.title} eyebrow={item.input} drill={false} />
              <SignalList signals={item.signals} />
            </li>
          ))}
        </ul>
      )}

      {files.length + links.length > 0 ? (
        <button
          type="button"
          onClick={() => {
            onFiles([]);
            onLinks([]);
          }}
          className="mt-4 h-11 text-sm text-muted hover:text-ink"
        >
          Clear results
        </button>
      ) : null}
    </section>
  );
}

function FileCard({ file }: { file: FileReport }) {
  return (
    <li className="rounded-2xl bg-card px-4 py-4 shadow-card">
      <VerdictHead severity={file.severity} title={file.title} eyebrow={file.name} drill={Boolean(file.drill)} />
      <p className="mt-1 text-xs text-muted">
        {file.size == null ? "Name only" : formatBytes(file.size)}
        {file.partial ? " · partial read" : ""}
      </p>
      <SignalList signals={file.signals} />
      {file.sha256 ? (
        <p className="mt-3 text-xs leading-relaxed text-muted">
          <span className="font-mono break-all">{file.sha256}</span>
          <a
            className="mt-1 flex items-center gap-1 text-pine"
            href={`https://www.virustotal.com/gui/file/${file.sha256}`}
            target="_blank"
            rel="noreferrer"
          >
            Look up this fingerprint
            <ExternalLink className="size-3.5" aria-hidden="true" />
          </a>
          Opens VirusTotal with the fingerprint only, not the file.
        </p>
      ) : null}
    </li>
  );
}

function VerdictHead({
  severity,
  title,
  eyebrow,
  drill,
}: {
  severity: Severity;
  title: string;
  eyebrow: string;
  drill: boolean;
}) {
  const Icon = drill ? ShieldCheck : severity === "risk" ? ShieldAlert : severity === "review" ? TriangleAlert : ShieldCheck;
  const color = drill ? "text-pine" : severity === "risk" ? "text-clay" : severity === "review" ? "text-ink" : "text-pine";
  return (
    <div className="grid grid-cols-[auto_minmax(0,1fr)] gap-3">
      <Icon className={cn("mt-0.5 size-5", color)} aria-hidden="true" />
      <div className="min-w-0">
        <p className="truncate text-xs text-muted">{eyebrow}</p>
        <p className="text-sm font-medium text-ink">{title}</p>
      </div>
    </div>
  );
}

function SignalList({ signals }: { signals: { severity: Severity; text: string }[] }) {
  if (!signals.length) {
    return <p className="mt-2 text-sm leading-relaxed text-muted">Nothing in the name matched a harmful pattern.</p>;
  }
  return (
    <ul className="mt-2 grid gap-2">
      {signals.map((signal) => (
        <li key={signal.text} className="text-sm leading-relaxed text-muted">
          {signal.text}
        </li>
      ))}
    </ul>
  );
}
