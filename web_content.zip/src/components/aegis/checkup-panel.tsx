import { formatDistanceToNow } from "date-fns";
import { Info, ShieldAlert, ShieldCheck, TriangleAlert } from "lucide-react";
import { isRiskyAnswer, questionsFor } from "@/lib/security/audit";
import type { Answer, AuditQuestion, DeviceReport, PlatformKind, Severity } from "@/lib/security/types";
import { cn } from "@/lib/cn";

type Props = {
  report: DeviceReport | null;
  os: PlatformKind | null;
  answers: Record<string, Answer | undefined>;
  onAnswer: (id: string, value: Answer) => void;
  devicePercent: number | null;
  framed: boolean;
};

export function CheckupPanel({ report, os, answers, onAnswer, devicePercent, framed }: Props) {
  const questions = questionsFor(os ?? "computer");

  if (!report) {
    return (
      <section className="mt-8">
        <h2 className="font-display text-2xl text-ink">What the scan can see</h2>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
          A website cannot list the other apps on a phone or walk the whole storage. No browser can — that
          wall is what stops a page from being the virus. Aegis checks what is actually visible, then asks
          you the rest.
        </p>
        <ul className="mt-6 divide-y divide-line border-t border-line">
          {[
            ["Connection", "Whether this page is on a protected link."],
            ["Browser", "Whether it is current enough to have recent security fixes."],
            ["Network", "Whether a site can see a private address from this browser."],
            ["Your answers", "Lock screen, updates, unknown apps, and store protections."],
          ].map(([title, detail]) => (
            <li key={title} className="py-4">
              <p className="text-sm font-medium text-ink">{title}</p>
              <p className="mt-1 text-sm text-muted">{detail}</p>
            </li>
          ))}
        </ul>
      </section>
    );
  }

  const issues = report.checks.filter((check) => check.severity === "risk" || check.severity === "review");
  const notes = report.checks.filter((check) => check.severity === "info");
  const passes = report.checks.filter((check) => check.severity === "clear");

  return (
    <section className="mt-8">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="font-display text-2xl text-ink">What turned up</h2>
        <p className="text-sm text-muted">
          {report.environment.detail} · {formatDistanceToNow(report.at, { addSuffix: true })}
        </p>
      </div>
      {framed ? (
        <p className="mt-3 text-sm text-muted">
          Opened inside another page. The checks still describe this browser.
        </p>
      ) : null}

      {issues.length === 0 ? (
        <p className="mt-4 text-sm leading-relaxed text-muted">
          Nothing in the browser checks needs a fix. The percentage can still move when you answer the
          device questions below.
        </p>
      ) : null}

      <ul className="mt-4 divide-y divide-line border-t border-line">
        {issues.map((check) => (
          <Finding key={check.id} severity={check.severity} title={check.title} detail={check.detail} />
        ))}
        {notes.map((check) => (
          <Finding key={check.id} severity={check.severity} title={check.title} detail={check.detail} />
        ))}
      </ul>

      {passes.length > 0 ? (
        <details className="mt-4 border-t border-line" open={issues.length === 0}>
          <summary className="cursor-pointer py-3 text-sm font-medium text-ink">
            {passes.length} check{passes.length === 1 ? "" : "s"} passed
          </summary>
          <ul className="divide-y divide-line">
            {passes.map((check) => (
              <Finding key={check.id} severity={check.severity} title={check.title} detail={check.detail} />
            ))}
          </ul>
        </details>
      ) : null}

      <div className="mt-10">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl text-ink">The part a browser cannot see</h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
              These answers change the device percentage. {questions.length} questions for{" "}
              {report.environment.osLabel}.
            </p>
          </div>
          {devicePercent != null ? (
            <p className="font-display text-xl text-ink">
              <span className="tabular-nums">{devicePercent}%</span>{" "}
              <span className="italic">secured</span>
            </p>
          ) : null}
        </div>
        <ul className="mt-4 divide-y divide-line border-t border-line">
          {questions.map((question) => (
            <QuestionRow
              key={question.id}
              question={question}
              answer={answers[question.id]}
              onAnswer={onAnswer}
            />
          ))}
        </ul>
      </div>
    </section>
  );
}

function Finding({ severity, title, detail }: { severity: Severity; title: string; detail: string }) {
  return (
    <li className="grid grid-cols-[auto_minmax(0,1fr)] gap-3 py-4">
      <Mark severity={severity} />
      <div className="min-w-0">
        <p className="text-sm font-medium text-ink">{title}</p>
        <p className="mt-1 text-sm leading-relaxed text-muted">{detail}</p>
      </div>
    </li>
  );
}

function Mark({ severity }: { severity: Severity }) {
  const className = "mt-0.5 size-5";
  if (severity === "risk") return <ShieldAlert className={cn(className, "text-clay")} aria-hidden="true" />;
  if (severity === "review") return <TriangleAlert className={cn(className, "text-ink")} aria-hidden="true" />;
  if (severity === "info") return <Info className={cn(className, "text-muted")} aria-hidden="true" />;
  return <ShieldCheck className={cn(className, "text-pine")} aria-hidden="true" />;
}

function QuestionRow({
  question,
  answer,
  onAnswer,
}: {
  question: AuditQuestion;
  answer: Answer | undefined;
  onAnswer: (id: string, value: Answer) => void;
}) {
  const risky = answer ? isRiskyAnswer(question, answer) : false;
  return (
    <li className="py-4">
      <p className="text-sm font-medium text-ink">{question.prompt}</p>
      <div className="mt-3 flex gap-2">
        <Choice question={question} choice="yes" answer={answer} onAnswer={onAnswer} />
        <Choice question={question} choice="no" answer={answer} onAnswer={onAnswer} />
      </div>
      {answer && risky ? <p className="mt-3 text-sm leading-relaxed text-clay">{question.detail}</p> : null}
    </li>
  );
}

function Choice({
  question,
  choice,
  answer,
  onAnswer,
}: {
  question: AuditQuestion;
  choice: Answer;
  answer: Answer | undefined;
  onAnswer: (id: string, value: Answer) => void;
}) {
  const selected = answer === choice;
  const risky = isRiskyAnswer(question, choice);
  return (
    <button
      type="button"
      aria-pressed={selected}
      onClick={() => onAnswer(question.id, choice)}
      className={cn(
        "h-11 min-w-16 rounded-full px-4 text-sm font-medium transition-colors duration-200",
        selected && risky && "bg-clay text-paper",
        selected && !risky && "bg-pine text-paper",
        !selected && "bg-paper-deep text-ink",
      )}
    >
      {choice === "yes" ? "Yes" : "No"}
    </button>
  );
}
