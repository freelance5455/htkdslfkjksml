import { Check } from "lucide-react";
import { PERMISSION_FLAGS } from "@/lib/security/apps";
import type { AppAssessment } from "@/lib/security/types";
import { cn } from "@/lib/cn";
import { PercentLockup } from "./percent";

const EXAMPLES = ["mSpy", "GBWhatsApp", "WhatsApp", "Super Cleaner"];

type Props = {
  query: string;
  onQuery: (value: string) => void;
  flagIds: string[];
  onToggleFlag: (id: string) => void;
  assessment: AppAssessment | null;
};

export function AppsPanel({ query, onQuery, flagIds, onToggleFlag, assessment }: Props) {
  return (
    <section className="mt-8">
      <h2 className="font-display text-2xl text-ink">Could this app be harmful?</h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
        Search a name or a package. Aegis compares it with known stalkerware, modded apps, and fake
        cleaners. Then match the permissions against what the phone actually shows.
      </p>

      <label className="mt-5 block">
        <span className="sr-only">App name</span>
        <input
          value={query}
          onChange={(event) => onQuery(event.target.value)}
          placeholder="App name or package"
          className="h-12 w-full rounded-2xl bg-card px-4 text-base text-ink shadow-card outline-none placeholder:text-muted"
        />
      </label>

      <div className="mt-3 flex flex-wrap gap-2">
        {EXAMPLES.map((example) => (
          <button
            key={example}
            type="button"
            onClick={() => onQuery(example)}
            className="h-10 rounded-full bg-paper-deep px-3 text-sm text-ink hover:bg-mist"
          >
            {example}
          </button>
        ))}
      </div>

      {assessment ? (
        <article className={cn("mt-5 rounded-3xl p-2 shadow-card", assessment.severity === "risk" ? "bg-clay-soft" : "bg-card")}>
          <div className="rounded-2xl bg-card px-5 py-5">
            {assessment.percent != null ? (
              <PercentLockup value={assessment.percent} />
            ) : (
              <p className="font-display text-3xl text-ink italic">No score yet</p>
            )}
            <h3 className="mt-4 text-base font-medium text-ink">{assessment.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{assessment.detail}</p>
            {assessment.steps.length > 0 ? (
              <ol className="mt-4 grid gap-2">
                {Array.from(new Set(assessment.steps)).map((step, index) => (
                  <li key={`${index}-${step}`} className="text-sm leading-relaxed text-ink">
                    {step}
                  </li>
                ))}
              </ol>
            ) : null}
          </div>
        </article>
      ) : (
        <p className="mt-5 text-sm text-muted">Try a name, or tick the permissions you see on the phone.</p>
      )}

      <h3 className="mt-10 font-display text-2xl text-ink">Permissions on the phone</h3>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
        Open the app’s settings and tick anything that is turned on. A normal camera or map app will not
        need the ones marked as dangerous.
      </p>
      <ul className="mt-4 grid gap-2">
        {PERMISSION_FLAGS.map((flag) => {
          const on = flagIds.includes(flag.id);
          return (
            <li key={flag.id}>
              <button
                type="button"
                aria-pressed={on}
                onClick={() => onToggleFlag(flag.id)}
                className={cn(
                  "flex min-h-11 w-full items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm shadow-card",
                  on && flag.severity === "risk" && "bg-clay text-paper",
                  on && flag.severity !== "risk" && "bg-ink text-paper",
                  !on && "bg-card text-ink",
                )}
              >
                <span
                  className={cn(
                    "grid size-5 shrink-0 place-items-center rounded-full border",
                    on ? "border-paper" : "border-line",
                  )}
                  aria-hidden="true"
                >
                  {on ? <Check className="size-3" strokeWidth={2.5} /> : null}
                </span>
                <span>{flag.label}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
