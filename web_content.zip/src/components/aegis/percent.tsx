import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/cn";

export function toneText(score: number): string {
  if (score >= 90) return "text-pine";
  if (score >= 70) return "text-ink";
  return "text-clay";
}

export function toneBar(score: number): string {
  if (score >= 90) return "bg-pine";
  if (score >= 70) return "bg-ink";
  return "bg-clay";
}

export function useCountUp(target: number): number {
  const [value, setValue] = useState(target);
  const from = useRef(target);

  useEffect(() => {
    const startValue = from.current;
    from.current = target;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || startValue === target) {
      setValue(target);
      return;
    }
    const begun = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - begun) / 700);
      const eased = 1 - (1 - t) ** 3;
      setValue(Math.round(startValue + (target - startValue) * eased));
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target]);

  return value;
}

export function PercentLockup({ value, large = false }: { value: number; large?: boolean }) {
  const shown = useCountUp(value);
  return (
    <p aria-label={`${value}% secured`}>
      <span
        className={cn(
          "block font-display tabular-nums leading-none",
          large ? "text-7xl sm:text-8xl" : "text-5xl",
          toneText(value),
        )}
      >
        {shown}%
      </span>
      <span
        className={cn(
          "mt-1 block font-display leading-none text-ink italic",
          large ? "text-4xl sm:text-5xl" : "text-3xl",
        )}
      >
        secured
      </span>
    </p>
  );
}

export function Meter({ label, score }: { label: string; score: number | null }) {
  return (
    <div className="min-w-0">
      <div className="flex items-baseline justify-between gap-3">
        <span className="text-sm text-muted">{label}</span>
        <span className={cn("font-display text-lg tabular-nums", score == null ? "text-muted" : "text-ink")}>
          {score == null ? "—" : `${score}%`}
        </span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-paper-deep">
        <div
          className={cn(
            "h-full rounded-full transition-[width] duration-700 ease-out",
            score == null ? "bg-line" : toneBar(score),
          )}
          style={{ width: score == null ? "0%" : `${score}%` }}
        />
      </div>
    </div>
  );
}
