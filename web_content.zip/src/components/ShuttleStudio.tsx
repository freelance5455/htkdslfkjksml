import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import type { Language, ShuttleStatus } from '../types';

export type StudioView = 'iso' | 'side' | 'front' | 'top';
export type OperatingMode = 'OFFLINE' | 'SIMULATION';

export interface StudioPart {
  id: string;
  en: string;
  ar: string;
  detailEn: string;
  detailAr: string;
}

export const STUDIO_PARTS: StudioPart[] = [
  { id: 'chassis', en: 'Main structural chassis', ar: 'الشاسيه الرئيسي', detailEn: 'Conceptual load-bearing frame and deck. Not manufacturer CAD and not to scale.', detailAr: 'هيكل تصوري حامل مع سطح التحميل. ليس ملف الشركة المصنعة ولا بمقياس رسم.' },
  { id: 'platform', en: 'Load-handling platform', ar: 'منصة التحميل', detailEn: 'Conceptual lifting deck shown for layout only. Never commands machine motion.', detailAr: 'منصة رفع تصورية للتوضيح فقط. لا تصدر أي أمر حركة للمعدة.' },
  { id: 'wheels', en: 'Drive wheels', ar: 'عجلات الحركة', detailEn: 'Four conceptual traction wheel assemblies. Rotation shown is illustrative only.', detailAr: 'أربع مجموعات عجلات تصورية. الدوران المعروض توضيحي فقط.' },
  { id: 'motors', en: 'Drive motors & transmission', ar: 'المحركات وناقل الحركة', detailEn: 'Conceptual drive units and gearbox housings. No ratings or register data implied.', detailAr: 'وحدات دفع وعلب تروس تصورية. لا تعني أي قيم أو بيانات.' },
  { id: 'battery', en: 'Battery compartment', ar: 'حجرة البطارية', detailEn: 'Removable energy module bay. Charge values here are never live telemetry.', detailAr: 'موضع وحدة الطاقة القابلة للفك. قيم الشحن هنا ليست قراءات حية.' },
  { id: 'sensors', en: 'Positioning & safety sensors', ar: 'حساسات التموضع والأمان', detailEn: 'Conceptual sensor positions and safety zones. No live detection state.', detailAr: 'مواضع حساسات ومناطق أمان تصورية. لا تعكس حالة كشف حية.' },
  { id: 'electrics', en: 'Electrical connection areas', ar: 'مناطق التوصيل الكهربائي', detailEn: 'Conceptual cabinet and connector positions. No wiring or PLC mapping implied.', detailAr: 'مواضع خزانة ووصلات تصورية. لا تعني أي مخطط أسلاك أو ربط PLC.' },
  { id: 'covers', en: 'Mechanical covers', ar: 'الأغطية الميكانيكية', detailEn: 'Removable guard panels shown lifted in exploded view.', detailAr: 'ألواح حماية قابلة للفك تظهر مرفوعة في العرض التفكيكي.' },
];

interface ManufacturerTheme {
  accent: number;
  accentCss: string;
  body: number;
  deck: number;
  length: number;
  width: number;
  deckHeight: number;
}

const THEMES: Record<string, ManufacturerTheme> = {
  Cassioli: { accent: 0xd28b4b, accentCss: '#d28b4b', body: 0x4a5a68, deck: 0x2a3642, length: 4.6, width: 2.4, deckHeight: 0.5 },
  Craftsman: { accent: 0x45b8d2, accentCss: '#45b8d2', body: 0x46586a, deck: 0x28363f, length: 4.2, width: 2.3, deckHeight: 0.55 },
  ACME: { accent: 0xa58af5, accentCss: '#a58af5', body: 0x4c5462, deck: 0x2b2f3a, length: 4.0, width: 2.2, deckHeight: 0.5 },
};

const VIEW_LABEL: Record<StudioView, string> = {
  iso: 'ISOMETRIC ASSEMBLY',
  side: 'SIDE ELEVATION',
  front: 'FRONT ELEVATION',
  top: 'TOP PLAN',
};

const VIEW_POS: Record<StudioView, [number, number, number]> = {
  iso: [6.4, 4.6, 6.4],
  side: [0, 1.6, 9.2],
  front: [9.2, 1.6, 0],
  top: [0, 11.5, 0.02],
};

function webglAvailable(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('webgl2') || canvas.getContext('webgl');
    return !!ctx;
  } catch {
    return false;
  }
}

const STATUS_BEACON: Record<ShuttleStatus, number> = {
  Ready: 0x64c99b,
  Running: 0x64c99b,
  Idle: 0xe7b66a,
  Charging: 0x68b7e3,
  Maintenance: 0xe7b66a,
  Fault: 0xe67878,
  Disconnected: 0x5e7183,
  Unknown: 0x5e7183,
};

interface ShuttleStudioProps {
  manufacturer: 'Cassioli' | 'Craftsman' | 'ACME';
  unitId: string;
  view: StudioView;
  exploded: boolean;
  animated: boolean;
  mode: OperatingMode;
  status: ShuttleStatus;
  language: Language;
}

export default function ShuttleStudio(props: ShuttleStudioProps) {
  const { manufacturer, unitId, view, exploded, animated, mode, status, language } = props;
  const mountRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [selectedId, setSelectedId] = useState<string>('chassis');
  const stateRef = useRef({ view, exploded, animated, mode, status, selectedId, manufacturer });
  stateRef.current = { view, exploded, animated, mode, status, selectedId, manufacturer };
  const selectRef = useRef<(id: string) => void>(() => undefined);
  selectRef.current = (id: string) => setSelectedId(id);

  const caption = useMemo(
    () => `${manufacturer.toUpperCase()} · ${VIEW_LABEL[view]}`,
    [manufacturer, view],
  );
  const selected = STUDIO_PARTS.find((p) => p.id === selectedId) || STUDIO_PARTS[0];
  const motionOn = animated && mode === 'SIMULATION';

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    if (!webglAvailable()) {
      setFailed(true);
      return;
    }

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      setFailed(true);
      return;
    }

    const theme = THEMES[manufacturer] || THEMES.Cassioli;
    const W = mount.clientWidth || 640;
    const H = 420;
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, W / H, 0.1, 100);
    camera.position.set(...VIEW_POS[stateRef.current.view]);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 4;
    controls.maxDistance = 20;
    controls.maxPolarAngle = Math.PI * 0.52;
    controls.target.set(0, 1, 0);

    scene.add(new THREE.HemisphereLight(0xdfe9f2, 0x1a2430, 1.05));
    const key = new THREE.DirectionalLight(0xffffff, 1.5);
    key.position.set(6, 9, 5);
    scene.add(key);
    const rim = new THREE.DirectionalLight(theme.accent, 0.7);
    rim.position.set(-6, 3, -6);
    scene.add(rim);

    const grid = new THREE.GridHelper(14, 14, 0x3a4a5a, 0x222f3c);
    grid.position.y = -0.02;
    scene.add(grid);

    const metal = (color: number, emissive = 0x000000) =>
      new THREE.MeshStandardMaterial({ color, metalness: 0.55, roughness: 0.42, emissive });
    const accentMat = () => new THREE.MeshStandardMaterial({ color: theme.accent, metalness: 0.35, roughness: 0.4 });

    const pickables: THREE.Object3D[] = [];
    const partMeshes = new Map<string, THREE.MeshStandardMaterial[]>();
    const register = (id: string, mesh: THREE.Mesh) => {
      mesh.userData.partId = id;
      pickables.push(mesh);
      const mats = partMeshes.get(id) || [];
      mats.push(mesh.material as THREE.MeshStandardMaterial);
      partMeshes.set(id, mats);
    };

    const shuttle = new THREE.Group();
    scene.add(shuttle);
    const L = theme.length;
    const Wd = theme.width;

    // Chassis + deck
    const chassis = new THREE.Group();
    const frame = new THREE.Mesh(new THREE.BoxGeometry(L, 0.5, Wd), metal(theme.body));
    frame.position.y = 1.0;
    chassis.add(frame);
    register('chassis', frame);
    const deckPlate = new THREE.Mesh(new THREE.BoxGeometry(L * 0.94, 0.12, Wd * 0.9), metal(theme.deck));
    deckPlate.position.y = 1.31;
    chassis.add(deckPlate);
    register('chassis', deckPlate);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(L * 0.94, 0.06, 0.18), accentMat());
    stripe.position.set(0, 1.32, Wd * 0.32);
    chassis.add(stripe);
    const explodeTargets = new Map<string, THREE.Vector3>();
    explodeTargets.set('chassis', new THREE.Vector3(0, 0, 0));

    // Load-handling platform
    const platform = new THREE.Group();
    const platformSlab = new THREE.Mesh(new THREE.BoxGeometry(L * 0.7, 0.22, Wd * 0.72), metal(0x6b7d8d));
    platform.add(platformSlab);
    register('platform', platformSlab);
    const liftA = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.5, 12), accentMat());
    liftA.position.set(-L * 0.22, -0.34, 0);
    const liftB = liftA.clone();
    liftB.position.set(L * 0.22, -0.34, 0);
    platform.add(liftA, liftB);
    platform.position.y = 1.85;
    shuttle.add(chassis, platform);
    explodeTargets.set('platform', new THREE.Vector3(0, 1.5, 0));

    // Wheels
    const wheels = new THREE.Group();
    const wheelGeo = new THREE.CylinderGeometry(0.46, 0.46, 0.34, 24);
    const hubGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.36, 16);
    const wheelPositions: Array<[number, number]> = [
      [-L * 0.36, Wd / 2], [L * 0.36, Wd / 2], [-L * 0.36, -Wd / 2], [L * 0.36, -Wd / 2],
    ];
    const wheelMeshes: THREE.Mesh[] = [];
    wheelPositions.forEach(([x, z]) => {
      const tire = new THREE.Mesh(wheelGeo, metal(0x141c24));
      tire.rotation.x = Math.PI / 2;
      tire.position.set(x, 0.46, z);
      const hub = new THREE.Mesh(hubGeo, accentMat());
      hub.rotation.x = Math.PI / 2;
      hub.position.set(x, 0.46, z);
      wheels.add(tire, hub);
      register('wheels', tire);
      register('wheels', hub);
      wheelMeshes.push(tire, hub);
    });
    shuttle.add(wheels);
    explodeTargets.set('wheels', new THREE.Vector3(0, -0.1, 0));

    // Drive motors + transmission
    const motors = new THREE.Group();
    [-1, 1].forEach((side) => {
      const housing = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.55, 0.6), metal(0x2c3a48));
      housing.position.set(side * L * 0.36, 1.0, 0);
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.7, 18), accentMat());
      drum.rotation.z = Math.PI / 2;
      drum.position.set(side * L * 0.36, 1.0, 0);
      motors.add(housing, drum);
      register('motors', housing);
      register('motors', drum);
    });
    shuttle.add(motors);
    explodeTargets.set('motors', new THREE.Vector3(0, 0.55, 0));

    // Battery compartment (slides out when exploded)
    const batteryBay = new THREE.Group();
    const tray = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.5, 1.4), metal(0x8b98a4));
    batteryBay.add(tray);
    register('battery', tray);
    for (let i = 0; i < 4; i++) {
      const cell = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.34, 1.1), accentMat());
      cell.position.set(-0.51 + i * 0.34, 0.42, 0);
      batteryBay.add(cell);
      register('battery', cell);
    }
    batteryBay.position.set(0, 1.02, 0);
    shuttle.add(batteryBay);
    explodeTargets.set('battery', new THREE.Vector3(0, 1.0, Wd * 0.9));

    // Sensors
    const sensors = new THREE.Group();
    const mastGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.9, 8);
    const eyeGeo = new THREE.SphereGeometry(0.09, 12, 12);
    [[-L / 2, Wd / 2 - 0.2], [L / 2, -(Wd / 2 - 0.2)]].forEach(([x, z]) => {
      const mast = new THREE.Mesh(mastGeo, metal(0x3a4a5a));
      mast.position.set(x, 1.9, z);
      const eye = new THREE.Mesh(eyeGeo, new THREE.MeshStandardMaterial({ color: 0x76d4ff, emissive: 0x2a7fa8, emissiveIntensity: 0.9 }));
      eye.position.set(x, 2.38, z);
      sensors.add(mast, eye);
      register('sensors', mast);
      register('sensors', eye);
    });
    shuttle.add(sensors);
    explodeTargets.set('sensors', new THREE.Vector3(0, 1.1, 0));

    // Electrical cabinet
    const electrics = new THREE.Group();
    const cabinet = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.9, Wd * 0.5), metal(0x33414f));
    cabinet.position.set(-L * 0.12, 1.15, -Wd * 0.18);
    const connector = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.2, 0.2), accentMat());
    connector.position.set(-L * 0.12, 0.75, -Wd * 0.18);
    electrics.add(cabinet, connector);
    register('electrics', cabinet);
    register('electrics', connector);
    shuttle.add(electrics);
    explodeTargets.set('electrics', new THREE.Vector3(0, 0.7, -Wd * 0.7));

    // Covers
    const covers = new THREE.Group();
    const cover = new THREE.Mesh(new THREE.BoxGeometry(L * 0.5, 0.1, Wd * 0.8), new THREE.MeshStandardMaterial({ color: theme.body, metalness: 0.4, roughness: 0.5, transparent: true, opacity: 0.92 }));
    cover.position.set(L * 0.14, 1.62, 0);
    covers.add(cover);
    register('covers', cover);
    shuttle.add(covers);
    explodeTargets.set('covers', new THREE.Vector3(0, 1.9, 0));

    const groups: Record<string, THREE.Group> = { chassis, platform, wheels, motors, battery: batteryBay, sensors, electrics, covers };

    // Beacon for operating state
    const beacon = new THREE.Mesh(
      new THREE.SphereGeometry(0.11, 12, 12),
      new THREE.MeshStandardMaterial({ color: STATUS_BEACON[stateRef.current.status] ?? 0x5e7183, emissive: STATUS_BEACON[stateRef.current.status] ?? 0x5e7183, emissiveIntensity: 1 }),
    );
    beacon.position.set(L / 2 - 0.2, 2.1, Wd / 2 - 0.2);
    scene.add(beacon);

    // Picking (click without drag)
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let downAt: [number, number] | null = null;
    const onPointerDown = (event: PointerEvent) => {
      downAt = [event.clientX, event.clientY];
    };
    const onPointerUp = (event: PointerEvent) => {
      if (!downAt) return;
      const dx = event.clientX - downAt[0];
      const dy = event.clientY - downAt[1];
      downAt = null;
      if (dx * dx + dy * dy > 36) return;
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hit = raycaster.intersectObjects(pickables, false)[0];
      const partId = hit?.object.userData.partId as string | undefined;
      if (partId) selectRef.current(partId);
    };
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointerup', onPointerUp);

    // Keyboard rotation on the canvas
    const onKeyDown = (event: KeyboardEvent) => {
      const step = 0.18;
      const offset = camera.position.clone().sub(controls.target);
      const spherical = new THREE.Spherical().setFromVector3(offset);
      if (event.key === 'ArrowLeft') spherical.theta -= step;
      else if (event.key === 'ArrowRight') spherical.theta += step;
      else if (event.key === 'ArrowUp') spherical.phi = Math.max(0.15, spherical.phi - step);
      else if (event.key === 'ArrowDown') spherical.phi = Math.min(Math.PI * 0.52, spherical.phi + step);
      else return;
      event.preventDefault();
      camera.position.copy(new THREE.Vector3().setFromSpherical(spherical).add(controls.target));
    };
    renderer.domElement.tabIndex = 0;
    renderer.domElement.addEventListener('keydown', onKeyDown);

    const onResize = () => {
      const w = mount.clientWidth || 640;
      camera.aspect = w / H;
      camera.updateProjectionMatrix();
      renderer.setSize(w, H);
    };
    const resizeObserver = new ResizeObserver(onResize);
    resizeObserver.observe(mount);
    onResize();

    let raf = 0;
    let visible = true;
    const onVisibility = () => {
      visible = !document.hidden;
    };
    document.addEventListener('visibilitychange', onVisibility);
    const clock = new THREE.Clock();
    let explodeT = stateRef.current.exploded ? 1 : 0;

    const highlight = (id: string) => {
      partMeshes.forEach((mats, key) => {
        mats.forEach((mat) => {
          if (key === id) {
            mat.emissive.setHex(theme.accent);
            mat.emissiveIntensity = 0.35;
          } else {
            mat.emissiveIntensity = key === 'sensors' ? 0.9 : 0;
            if (key !== 'sensors') mat.emissive.setHex(0x000000);
          }
        });
      });
    };
    highlight(stateRef.current.selectedId);

    const basePlatformY = 1.85;
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (!visible) return;
      const s = stateRef.current;
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;

      const target = s.exploded ? 1 : 0;
      explodeT += Math.sign(target - explodeT) * Math.min(Math.abs(target - explodeT), dt * 2.2);
      Object.entries(groups).forEach(([id, group]) => {
        const off = explodeTargets.get(id) || new THREE.Vector3();
        group.position.copy(off.clone().multiplyScalar(explodeT));
      });
      platform.position.y = basePlatformY + explodeT * 1.5;

      if (s.animated && s.mode === 'SIMULATION') {
        wheelMeshes.forEach((w) => {
          w.rotation.y += dt * 3.2;
        });
        platform.position.y += Math.sin(t * 1.6) * 0.05;
        const pulse = 0.7 + Math.sin(t * 4) * 0.3;
        (beacon.material as THREE.MeshStandardMaterial).emissiveIntensity = pulse;
      } else {
        (beacon.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.9;
      }
      const beaconColor = STATUS_BEACON[s.status] ?? 0x5e7183;
      (beacon.material as THREE.MeshStandardMaterial).color.setHex(beaconColor);
      (beacon.material as THREE.MeshStandardMaterial).emissive.setHex(beaconColor);

      highlight(s.selectedId);

      const desired = VIEW_POS[s.view];
      const goal = new THREE.Vector3(...desired);
      if (camera.position.distanceTo(goal) > 0.05 && !controlsDragging) {
        camera.position.lerp(goal, 1 - Math.pow(0.002, dt));
      }
      controls.update();
      renderer.render(scene, camera);
    };

    let controlsDragging = false;
    controls.addEventListener('start', () => {
      controlsDragging = true;
    });
    controls.addEventListener('end', () => {
      controlsDragging = false;
    });

    setReady(true);
    animate();

    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVisibility);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointerup', onPointerUp);
      renderer.domElement.removeEventListener('keydown', onKeyDown);
      controls.dispose();
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.isMesh) {
          mesh.geometry.dispose();
          const mat = mesh.material as THREE.Material | THREE.Material[];
          if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
          else mat.dispose();
        }
      });
      renderer.dispose();
      if (renderer.domElement.parentElement === mount) mount.removeChild(renderer.domElement);
    };
    // Rebuild only when the manufacturer changes; view/explode/animate/mode flow through stateRef.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [manufacturer]);

  if (failed) {
    return (
      <div className="studio-fallback" role="img" aria-label={`${caption} — 3D unavailable`}>
        <div className="studio-caption">{caption}</div>
        <p className="muted-text">
          {language === 'ar'
            ? 'العرض ثلاثي الأبعاد غير متاح على هذا الجهاز. هذه قائمة المكونات التصورية.'
            : '3D viewing is not available on this device. These are the conceptual assembly components.'}
        </p>
        <div className="studio-parts">
          {STUDIO_PARTS.map((p) => (
            <button key={p.id} className={'studio-part' + (p.id === selectedId ? ' selected' : '')} onClick={() => setSelectedId(p.id)}>
              <strong>{language === 'ar' ? p.ar : p.en}</strong>
              <small>{language === 'ar' ? p.detailAr : p.detailEn}</small>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="studio">
      <div ref={mountRef} className="studio-canvas" tabIndex={0} role="application" aria-label={`${caption}. Drag to rotate, scroll to zoom, arrow keys rotate.`} />
      <div className="studio-overlay-top">
        <span className="studio-caption">{caption}</span>
        {motionOn ? (
          <span className="studio-badge badge-sim">SIMULATION · {language === 'ar' ? 'حركة توضيحية' : 'illustrative motion'}</span>
        ) : (
          <span className="studio-badge badge-off">{mode === 'SIMULATION' ? (language === 'ar' ? 'ثابت' : 'STATIC') : 'OFFLINE · NO MOTION'}</span>
        )}
      </div>
      <div className="studio-overlay-bottom">
        <span className="studio-selected">
          {language === 'ar' ? selected.ar : selected.en} · {unitId}
        </span>
        <span className="studio-hint">{language === 'ar' ? 'اسحب للتدوير · عجلة الفأرة للتقريب' : 'Drag to rotate · scroll to zoom'}</span>
      </div>
      {!ready && <div className="studio-loading">{language === 'ar' ? 'جارٍ تجهيز النموذج…' : 'Preparing model…'}</div>}
      <div className="studio-inspector">
        <div className="studio-parts">
          {STUDIO_PARTS.map((p) => (
            <button key={p.id} className={'studio-part' + (p.id === selectedId ? ' selected' : '')} onClick={() => setSelectedId(p.id)} aria-pressed={p.id === selectedId}>
              {language === 'ar' ? p.ar : p.en}
            </button>
          ))}
        </div>
        <p className="studio-detail">
          <strong>{language === 'ar' ? selected.ar : selected.en}.</strong> {language === 'ar' ? selected.detailAr : selected.detailEn}
        </p>
      </div>
    </div>
  );
}
