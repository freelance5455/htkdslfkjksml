import { X } from "lucide-react";
import { LANGS, LANG_LABEL, type Copy, type Lang } from "@/engine/i18n";
import { layoutName } from "@/engine/spec";
import { COLORS, LAYOUTS, type Spec } from "@/engine/types";

const BGS = ["", "#000000", "#1b1e24", "#e9edf2", "#0d2b45", "#3a0f12", "#12351f"];

export function MakerPanel({
  tr,
  lang,
  spec,
  volume,
  bg,
  onClose,
  onLang,
  onSpec,
  onVolume,
  onBg,
  pwa,
}: {
  tr: Copy;
  lang: Lang;
  spec: Spec;
  volume: number;
  bg: string;
  onClose: () => void;
  onLang: (l: Lang) => void;
  onSpec: (patch: Partial<Spec>) => void;
  onVolume: (v: number) => void;
  onBg: (c: string) => void;
  pwa: {
    canInstall: boolean;
    installed: boolean;
    ios: boolean;
    shareNote: "" | "shared" | "copied";
    onInstall: () => void;
    onShare: () => void;
  };
}) {
  const opts = [
    ["carb", tr.carb],
    ["turbo", tr.turbo],
    ["sc", tr.sc],
  ] as const;
  return (
    <aside className="z-20 flex w-full flex-col overflow-y-auto border-line bg-panel p-4 md:w-80 md:border-l max-md:fixed max-md:inset-x-0 max-md:bottom-0 max-md:max-h-[68dvh] max-md:rounded-t-2xl max-md:border-t">
      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-display text-xl font-bold tracking-wide">{tr.title}</h2>
        <button type="button" className="grid size-11 place-items-center rounded-lg" onClick={onClose} aria-label={tr.close}>
          <X className="size-5" />
        </button>
      </div>

      <Section title={tr.hLayout} />
      <div className="grid grid-cols-2 gap-1.5">
        {LAYOUTS.map((id) => (
          <button
            key={id}
            type="button"
            aria-pressed={spec.type === id}
            className={chip(spec.type === id)}
            onClick={() => onSpec({ type: id })}
          >
            {layoutName(id, tr)}
          </button>
        ))}
      </div>
      <button type="button" aria-pressed={spec.twin} className={`mt-1.5 ${chip(spec.twin, true)}`} onClick={() => onSpec({ twin: !spec.twin })}>
        {spec.twin ? "✓  " : ""}
        {tr.twin}
      </button>

      <Section title={tr.hDim} />
      <Slider label={tr.bore} value={`${spec.bore} mm`} min={50} max={110} v={spec.bore} onChange={(bore) => onSpec({ bore })} />
      <Slider label={tr.stroke} value={`${spec.stroke} mm`} min={50} max={110} v={spec.stroke} onChange={(stroke) => onSpec({ stroke })} />

      <Section title={tr.hFuel} />
      <div className="grid grid-cols-2 gap-1.5">
        <button type="button" aria-pressed={spec.fuel === "gas"} className={chip(spec.fuel === "gas")} onClick={() => onSpec({ fuel: "gas" })}>
          {tr.fuelGas}
        </button>
        <button
          type="button"
          aria-pressed={spec.fuel === "dsl"}
          className={chip(spec.fuel === "dsl")}
          onClick={() => onSpec({ fuel: "dsl", carb: false })}
        >
          {tr.fuelDsl}
        </button>
      </div>

      <Section title={tr.hInduct} />
      <div className="flex flex-col gap-1.5">
        {opts
          .filter(([k]) => !(k === "carb" && spec.fuel === "dsl"))
          .map(([k, label]) => (
            <button key={k} type="button" aria-pressed={spec[k]} className={chip(spec[k], true)} onClick={() => onSpec({ [k]: !spec[k] } as Partial<Spec>)}>
              {spec[k] ? "✓  " : ""}
              {label}
            </button>
          ))}
      </div>

      <Section title={tr.hExh} />
      <div className="grid grid-cols-2 gap-1.5">
        {(
          [
            ["stock", tr.xStock],
            ["sport", tr.xSport],
            ["straight", tr.xStraight],
            ["open", tr.xOpen],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            type="button"
            aria-pressed={spec.exh === k}
            className={chip(spec.exh === k)}
            onClick={() => onSpec({ exh: k, pop: k === "stock" ? spec.pop : true })}
          >
            {label}
          </button>
        ))}
      </div>
      {spec.fuel !== "dsl" && spec.exh !== "stock" && (
        <button type="button" aria-pressed={spec.pop} className={`mt-1.5 ${chip(spec.pop, true)}`} onClick={() => onSpec({ pop: !spec.pop })}>
          {spec.pop ? "✓  " : ""}
          {tr.pop}
        </button>
      )}

      <Section title={tr.hEcu} />
      <button type="button" aria-pressed={spec.ecu} className={chip(spec.ecu, true)} onClick={() => onSpec({ ecu: !spec.ecu })}>
        {spec.ecu ? "✓  " : ""}
        {tr.ecu}
      </button>
      {spec.ecu && (
        <div className="mt-1">
          <Slider label={tr.map} value={`+${spec.map}%`} min={0} max={30} v={spec.map} onChange={(map) => onSpec({ map })} />
          <Slider
            label={tr.lim}
            value={`${spec.lim > 0 ? "+" : ""}${spec.lim}%`}
            min={-10}
            max={20}
            v={spec.lim}
            onChange={(lim) => onSpec({ lim })}
          />
          {(spec.turbo || spec.sc) && (
            <Slider label={tr.bst} value={`+${spec.bst}%`} min={0} max={50} v={spec.bst} onChange={(bst) => onSpec({ bst })} />
          )}
        </div>
      )}

      <Section title={tr.hLang} />
      <div className="grid grid-cols-2 gap-1.5">
        {LANGS.map((l) => (
          <button key={l} type="button" aria-pressed={lang === l} className={chip(lang === l)} onClick={() => onLang(l)}>
            {LANG_LABEL[l]}
          </button>
        ))}
      </div>

      <Section title={tr.hBg} />
      <div className="flex flex-wrap items-center gap-2">
        {BGS.map((c) => (
          <button
            key={c || "auto"}
            type="button"
            aria-label={c || tr.auto}
            aria-pressed={bg === c}
            className={`size-8 rounded-full border-2 ${c ? "" : "swatch-auto"} ${bg === c ? "border-accent" : "border-line"}`}
            style={c ? { background: c } : undefined}
            onClick={() => onBg(c)}
          />
        ))}
        <input
          type="color"
          aria-label={tr.hBg}
          value={bg || "#101216"}
          className="size-8 cursor-pointer border-0 bg-transparent p-0"
          onChange={(e) => onBg(e.target.value)}
        />
      </div>

      <Section title={tr.hSnd} />
      <Slider label={tr.vol} value={`${Math.round(volume * 100)}%`} min={0} max={100} v={Math.round(volume * 100)} onChange={(v) => onVolume(v / 100)} />

      <Section title={tr.install} />
      {pwa.installed ? (
        <p className="text-sm text-muted">{tr.installReady}</p>
      ) : (
        <div className="grid gap-1.5">
          {pwa.canInstall && (
            <button type="button" className={chip(true, true)} onClick={pwa.onInstall}>
              {tr.installBtn}
            </button>
          )}
          {pwa.ios && <p className="text-sm text-muted">{tr.installIos}</p>}
        </div>
      )}
      <button type="button" className={`mt-1.5 ${chip(false, true)}`} onClick={pwa.onShare}>
        {tr.share}
      </button>
      {pwa.shareNote === "copied" && <p className="mt-1 text-xs text-muted">{tr.copied}</p>}
      {pwa.shareNote === "shared" && <p className="mt-1 text-xs text-muted">{tr.shared}</p>}

      <Section title={tr.hCol} />
      <div className="flex gap-2 pb-2">
        {COLORS.map((c) => (
          <button
            key={c}
            type="button"
            aria-label={c}
            aria-pressed={spec.color === c}
            className={`size-8 rounded-full border-2 ${spec.color === c ? "border-accent" : "border-line"}`}
            style={{ background: c }}
            onClick={() => onSpec({ color: c })}
          />
        ))}
      </div>
    </aside>
  );
}

function Section({ title }: { title: string }) {
  return <h3 className="mt-4 mb-1.5 text-xs font-semibold tracking-widest text-muted uppercase">{title}</h3>;
}

function chip(on: boolean, wide = false) {
  return `${wide ? "w-full text-left" : ""} rounded-lg border px-2 py-2 text-sm ${
    on ? "border-accent bg-accent font-semibold text-accent-fg" : "border-line bg-chip text-fg"
  }`;
}

function Slider({
  label,
  value,
  min,
  max,
  v,
  onChange,
}: {
  label: string;
  value: string;
  min: number;
  max: number;
  v: number;
  onChange: (n: number) => void;
}) {
  const id = `sl-${label.replace(/\s+/g, "-")}`;
  return (
    <label htmlFor={id} className="mt-1.5 block text-sm">
      <span className="mb-0.5 flex justify-between">
        <span>{label}</span>
        <span className="text-muted">{value}</span>
      </span>
      <input id={id} type="range" min={min} max={max} value={v} onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}
