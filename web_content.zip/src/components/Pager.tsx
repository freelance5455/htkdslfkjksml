import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { clamp } from "@/lib/format";
import type { Stage } from "@/lib/reflow";
import { cn } from "@/utils/cn";

const ANIM = 280;

export type GoFn = (dir: 1 | -1) => void;

export function Pager({
  total,
  index,
  onIndex,
  rtl,
  stage,
  tapZones,
  allowScrollY,
  renderPage,
  goRef,
  onFirstGesture,
  onCenterTap,
  onReachEnd,
}: {
  total: number;
  index: number;
  onIndex: (i: number) => void;
  rtl: boolean;
  stage: Stage;
  tapZones: boolean;
  allowScrollY: boolean;
  renderPage: (i: number) => ReactNode;
  goRef?: React.RefObject<GoFn | null>;
  onFirstGesture?: () => void;
  onCenterTap?: () => void;
  onReachEnd?: () => void;
}) {
  const sgn = rtl ? 1 : -1;
  const W = stage.w || 1;
  const rootRef = useRef<HTMLDivElement | null>(null);
  const [offset, setOffset] = useState(0);
  const [anim, setAnim] = useState(false);
  const lock = useRef(false);
  const start = useRef({ x: 0, y: 0, id: -1 });
  const last = useRef({ x: 0, t: 0 });
  const axis = useRef<"x" | "y" | null>(null);
  const velocity = useRef(0);
  const scrollRefs = useRef<Array<HTMLDivElement | null>>([]);
  const myIndex = useRef(index);
  const goTimer = useRef<number | null>(null);
  const wheelDistance = useRef(0);

  useEffect(() => {
    if (myIndex.current !== index) {
      myIndex.current = index;
      lock.current = false;
      setAnim(false);
      setOffset(0);
    }
  }, [index]);

  useEffect(() => {
    scrollRefs.current.forEach((el) => {
      if (el) el.scrollTop = 0;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  useEffect(() => () => {
    if (goTimer.current) window.clearTimeout(goTimer.current);
  }, []);

  useEffect(() => {
    rootRef.current?.focus({ preventScroll: true });
  }, []);

  const go = useCallback<GoFn>(
    (dir) => {
      if (lock.current) return;
      const nextIdx = clamp(index + dir, 0, Math.max(0, total - 1));
      if (nextIdx === index) {
        if (dir === 1) onReachEnd?.();
        setAnim(true);
        setOffset(-dir * sgn * W * 0.1);
        window.setTimeout(() => {
          setOffset(0);
          window.setTimeout(() => setAnim(false), ANIM);
        }, 120);
        return;
      }
      lock.current = true;
      setAnim(true);
      setOffset(-dir * sgn * W);
      goTimer.current = window.setTimeout(() => {
        setAnim(false);
        setOffset(0);
        myIndex.current = nextIdx;
        onIndex(nextIdx);
        window.setTimeout(() => {
          lock.current = false;
        }, 24);
      }, ANIM);
    },
    [index, onIndex, sgn, total, W, onReachEnd],
  );

  useEffect(() => {
    if (goRef) goRef.current = go;
  }, [go, goRef]);

  const onPointerDown = (e: React.PointerEvent) => {
    if (lock.current || e.button === 2) return;
    start.current = { x: e.clientX, y: e.clientY, id: e.pointerId };
    last.current = { x: e.clientX, t: performance.now() };
    velocity.current = 0;
    axis.current = null;
    setAnim(false);
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (start.current.id !== e.pointerId) return;
    const dx = e.clientX - start.current.x;
    const dy = e.clientY - start.current.y;
    if (!axis.current) {
      if (Math.abs(dx) < 9 && Math.abs(dy) < 9) return;
      axis.current = Math.abs(dx) > Math.abs(dy) ? "x" : "y";
      if (axis.current === "x") onFirstGesture?.();
      else if (!allowScrollY) return;
    }
    if (axis.current !== "x") return;
    const now = performance.now();
    const dt = now - last.current.t;
    if (dt > 0) velocity.current = (e.clientX - last.current.x) / dt;
    last.current = { x: e.clientX, t: now };
    const blocked =
      (dx * sgn < 0 && index === 0) || (dx * sgn > 0 && index >= total - 1);
    setOffset(blocked ? dx * 0.2 : dx);
  };

  const endDrag = (e: React.PointerEvent) => {
    if (start.current.id !== e.pointerId) return;
    const pid = start.current.id;
    start.current.id = -1;
    const wasAxis = axis.current;
    axis.current = null;
    velocity.current = 0;
    if (wasAxis !== "x") {
      const dist =
        Math.abs(e.clientX - start.current.x) + Math.abs(e.clientY - start.current.y);
      if (dist < 9 && tapZones && pid >= 0) {
        const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
        const rel = (e.clientX - rect.left) / Math.max(1, rect.width);
        if (onCenterTap && rel > 0.33 && rel < 0.67) onCenterTap();
        else go(rtl ? (rel < 0.34 ? 1 : -1) : rel > 0.66 ? 1 : -1);
      }
      setOffset(0);
      return;
    }
    const threshold = W * 0.22;
    const moved = e.clientX - start.current.x;
    if (moved * sgn > threshold) go(1);
    else if (moved * sgn < -threshold) go(-1);
    else {
      setAnim(true);
      setOffset(0);
      window.setTimeout(() => setAnim(false), ANIM);
    }
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowLeft") go(rtl ? 1 : -1);
    else if (e.key === "ArrowRight") go(rtl ? -1 : 1);
    else if (e.key === " " || e.key === "PageDown") go(1);
    else if (e.key === "PageUp") go(-1);
    else if (e.key === "Home") onIndex(0);
    else if (e.key === "End") onIndex(Math.max(0, total - 1));
    else return;
    e.preventDefault();
  };

  const onWheel = (e: React.WheelEvent) => {
    // Trackpads can send horizontal wheel events instead of pointer gestures.
    if (lock.current || Math.abs(e.deltaX) < Math.abs(e.deltaY) || Math.abs(e.deltaX) < 3) return;
    wheelDistance.current += e.deltaX;
    if (Math.abs(wheelDistance.current) < 35) return;
    const direction = wheelDistance.current * sgn < 0 ? 1 : -1;
    wheelDistance.current = 0;
    go(direction);
  };

  // The current page renders before its neighbours for responsive navigation.
  const panes = [
    { tile: index, pos: 0 },
    { tile: index - 1, pos: sgn * W },
    { tile: index + 1, pos: -sgn * W },
  ];

  return (
    <div
      ref={rootRef}
      className="relative h-full w-full touch-pan-y overflow-hidden outline-none"
      tabIndex={0}
      role="group"
      aria-label="ورق زدن کتاب"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      onKeyDown={onKey}
      onWheel={onWheel}
    >
      <div
        className="absolute inset-0 will-change-transform"
        style={{
          transform: `translate3d(${offset}px,0,0)`,
          transition: anim ? `transform ${ANIM}ms cubic-bezier(.22,1,.36,1)` : "none",
        }}
      >
        {panes.map((p, i) => {
          const valid = p.tile >= 0 && p.tile < total;
          return (
            <div
              key={p.tile}
              className="absolute top-0 bottom-0 left-0 overflow-hidden"
              style={{ width: `${W}px`, transform: `translate3d(${p.pos}px,0,0)` }}
            >
              <div
                ref={(el) => {
                  scrollRefs.current[i] = el;
                }}
                className={cn(
                  "no-scrollbar h-full w-full overflow-x-hidden",
                  allowScrollY ? "overflow-y-auto overscroll-contain" : "overflow-y-hidden",
                )}
              >
                <div className="flex min-h-full w-full flex-col items-center">
                  <div className="my-auto">{valid ? renderPage(p.tile) : null}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
