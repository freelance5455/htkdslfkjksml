import React from 'react';
import { Moon, Sun, Sparkles, X, Check, Flame, Shield, Eye } from 'lucide-react';
import { NightReadingMode, NightWarmthLevel } from '../types';

interface NightModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentMode: NightReadingMode;
  warmthLevel: NightWarmthLevel;
  onSelectMode: (mode: NightReadingMode) => void;
  onSelectWarmth: (level: NightWarmthLevel) => void;
  isNightBySolar?: boolean;
  sunsetFormatted?: string;
}

export const NightModeModal: React.FC<NightModeModalProps> = ({
  isOpen,
  onClose,
  currentMode,
  warmthLevel,
  onSelectMode,
  onSelectWarmth,
  isNightBySolar,
  sunsetFormatted,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-[#120d09] border border-amber-800/60 rounded-3xl p-5 shadow-2xl space-y-4 text-right text-amber-100"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-amber-900/40">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Moon className="w-5 h-5 fill-amber-400/30" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-amber-200 font-cairo">
                وضع القراءة الليلية وراحة العين
              </h3>
              <p className="text-[11px] text-amber-300/70 font-tajawal">
                تصفية الضوء الأزرق لراحة العين والقراءة بتأنٍ في الظلام
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-amber-400/80 hover:text-amber-200 hover:bg-amber-950/60 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-amber-300/90 font-cairo block">
            نمط التفعيل:
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'auto' as NightReadingMode, label: 'تلقائي 🌅', desc: 'مع غروب الشمس' },
              { id: 'on' as NightReadingMode, label: 'مفعّل دائماً 🌙', desc: 'ألوان دافئة مستمرة' },
              { id: 'off' as NightReadingMode, label: 'معطل ☀️', desc: 'الوضع العادي' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => onSelectMode(item.id)}
                className={`p-2.5 rounded-2xl border text-center transition-all cursor-pointer ${
                  currentMode === item.id
                    ? 'bg-amber-500/25 border-amber-400 text-amber-200 shadow-xs font-bold'
                    : 'bg-[#181109] border-amber-900/40 text-amber-300/70 hover:border-amber-700/50'
                }`}
              >
                <div className="text-xs font-bold font-cairo">{item.label}</div>
                <div className="text-[10px] text-amber-300/60 font-tajawal mt-0.5">{item.desc}</div>
              </button>
            ))}
          </div>

          {currentMode === 'auto' && (
            <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/30 flex items-center justify-between text-[11px] text-amber-200/90 font-tajawal">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>حالة الموقع الحالي: {isNightBySolar ? 'حل الليل 🌙 (مفعّل)' : 'نهار ☀️ (سيفعّل مع الغروب)'}</span>
              </span>
              {sunsetFormatted && <span className="font-mono text-amber-300">{sunsetFormatted}</span>}
            </div>
          )}
        </div>

        {/* Warmth Levels */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-amber-300/90 font-cairo block">
            درجة الدفء وتصفية الضوء الأزرق:
          </label>
          <div className="space-y-2">
            {[
              {
                id: 'mild' as NightWarmthLevel,
                title: 'معتدل (خافت مريح)',
                desc: 'تقليل السطوع مع الحفاظ على التباين الطبيعي',
                bgPreview: 'bg-[#100d09]',
              },
              {
                id: 'warm' as NightWarmthLevel,
                title: 'عنبري دافئ (المفضل للسرير)',
                desc: 'تصفية قوية للضوء الأزرق مناسبة لقبل النوم',
                bgPreview: 'bg-[#0c0906]',
              },
              {
                id: 'deep_amber' as NightWarmthLevel,
                title: 'شمعة داكنة (أقصى حماية)',
                desc: 'أغمق درجة لحماية النوم وإنتاج الميلاتونين',
                bgPreview: 'bg-[#070503]',
              },
            ].map((warmth) => (
              <button
                key={warmth.id}
                onClick={() => onSelectWarmth(warmth.id)}
                className={`w-full p-2.5 rounded-2xl border text-right transition-all flex items-center justify-between cursor-pointer ${
                  warmthLevel === warmth.id
                    ? 'bg-amber-500/20 border-amber-400 text-amber-100 shadow-xs'
                    : 'bg-[#181109] border-amber-900/40 text-amber-300/80 hover:border-amber-700/50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-6 h-6 rounded-lg ${warmth.bgPreview} border border-amber-700/50 flex items-center justify-center shrink-0`}>
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-xs font-bold font-cairo">{warmth.title}</p>
                    <p className="text-[10px] text-amber-300/60 font-tajawal">{warmth.desc}</p>
                  </div>
                </div>
                {warmthLevel === warmth.id && (
                  <Check className="w-4 h-4 text-amber-400 stroke-[3]" />
                )}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-black font-extrabold text-xs font-cairo transition-all cursor-pointer shadow-md"
        >
          تم وتطبيق
        </button>
      </div>
    </div>
  );
};
