import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { Download, ImagePlus, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { fitSize, hitAt, renderMeme } from "@/lib/meme/draw";
import { copyLayers, presetById, PRESETS } from "@/lib/meme/presets";
import { starterById, STARTERS, type Starter } from "@/lib/meme/starters";
import type { HitBox, MemeLayer, TextTone } from "@/lib/meme/types";
import { cn } from "@/lib/utils";

const MAX_UPLOAD = 15 * 1024 * 1024;

type Upload = { url: string; name: string };

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function pointFromEvent(canvas: HTMLCanvasElement, clientX: number, clientY: number) {
  const rect = canvas.getBoundingClientRect();
  if (rect.width < 1 || rect.height < 1) return { x: 0, y: 0 };
  return {
    x: ((clientX - rect.left) / rect.width) * canvas.width,
    y: ((clientY - rect.top) / rect.height) * canvas.height,
  };
}

export function MemeStudio() {
  const initial = PRESETS[0]!;
  const [presetId, setPresetId] = useState(initial.id);
  const [layers, setLayers] = useState<MemeLayer[]>(() => copyLayers(initial.layers));
  const [selectedId, setSelectedId] = useState(initial.layers[0]!.id);
  const [starterId, setStarterId] = useState(STARTERS[0]!.id);
  const [upload, setUpload] = useState<Upload | null>(null);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [fill, setFill] = useState("#141416");
  const [size, setSize] = useState({ w: 1080, h: 1080 });
  const [status, setStatus] = useState<"loading" | "ready">("loading");
  const [error, setError] = useState<string | null>(null);
  const [dropping, setDropping] = useState(false);
  const [fontTick, setFontTick] = useState(0);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const hitsRef = useRef<HitBox[]>([]);
  const layersRef = useRef(layers);
  const sizeRef = useRef(size);
  const selectedRef = useRef(selectedId);
  const dragRef = useRef<{
    id: string;
    pointerId: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);
  const frameReq = useRef(0);
  const pendingMove = useRef<{ id: string; x: number; y: number } | null>(null);

  layersRef.current = layers;
  sizeRef.current = size;
  selectedRef.current = selectedId;

  const starter = starterById(starterId);
  const preset = presetById(presetId);
  const selected = layers.find((layer) => layer.id === selectedId) ?? layers[0]!;
  const photoLabel = upload?.name ?? starter.name;
  const srcKey = upload
    ? upload.url
    : starter.kind === "image"
      ? starter.src
      : `fill:${starter.color}`;

  useEffect(() => {
    let alive = true;
    const bump = () => {
      if (alive) setFontTick((n) => n + 1);
    };
    document.fonts.ready.then(bump).catch(() => {});
    document.fonts.addEventListener("loadingdone", bump);
    void document.fonts.load("400 96px Anton");
    void document.fonts.load("600 64px Outfit");
    return () => {
      alive = false;
      document.fonts.removeEventListener("loadingdone", bump);
    };
  }, []);

  useEffect(() => {
    let cancel = false;
    if (!upload && starter.kind === "fill") {
      setImage(null);
      setFill(starter.color);
      setSize({ w: 1080, h: 1080 });
      setStatus("ready");
      return;
    }
    const src = upload?.url ?? (starter.kind === "image" ? starter.src : "");
    if (!src) return;
    setStatus("loading");
    const img = new Image();
    img.onload = () => {
      if (cancel) return;
      setImage(img);
      setFill("#141416");
      setSize(fitSize(img.naturalWidth, img.naturalHeight));
      setStatus("ready");
      setError(null);
    };
    img.onerror = () => {
      if (cancel) return;
      setImage(null);
      setFill("#141416");
      setSize({ w: 1080, h: 1080 });
      setStatus("ready");
      setError("Couldn't load that photo. Try a different one.");
    };
    img.src = src;
    return () => {
      cancel = true;
    };
  }, [srcKey, starter, upload]);

  useEffect(() => {
    if (status !== "ready") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    hitsRef.current = renderMeme(ctx, {
      width: canvas.width,
      height: canvas.height,
      image,
      fill,
      layers,
    });
  }, [status, image, fill, layers, size, fontTick]);

  useEffect(() => {
    const frame = frameRef.current;
    const canvas = canvasRef.current;
    if (!frame || !canvas) return;
    const apply = () => {
      const rect = frame.getBoundingClientRect();
      if (rect.width < 2 || rect.height < 2) return;
      const scale = Math.min(rect.width / size.w, rect.height / size.h);
      canvas.style.width = `${Math.max(1, Math.floor(size.w * scale))}px`;
      canvas.style.height = `${Math.max(1, Math.floor(size.h * scale))}px`;
    };
    apply();
    const observer = new ResizeObserver(apply);
    observer.observe(frame);
    return () => observer.disconnect();
  }, [size.w, size.h]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement | null;
      if (target?.closest("input, textarea, button, a, [role='slider']")) return;
      const key = event.key;
      if (key !== "ArrowLeft" && key !== "ArrowRight" && key !== "ArrowUp" && key !== "ArrowDown") {
        return;
      }
      const id = selectedRef.current;
      const layer = layersRef.current.find((item) => item.id === id);
      if (!layer) return;
      event.preventDefault();
      const step = event.shiftKey ? 0.02 : 0.008;
      const x = layer.banner
        ? layer.x
        : clamp(
            layer.x + (key === "ArrowLeft" ? -step : key === "ArrowRight" ? step : 0),
            0.06,
            0.94,
          );
      const y = clamp(
        layer.y + (key === "ArrowUp" ? -step : key === "ArrowDown" ? step : 0),
        0.05,
        0.95,
      );
      setLayers((current) => current.map((item) => (item.id === id ? { ...item, x, y } : item)));
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    return () => {
      if (frameReq.current) cancelAnimationFrame(frameReq.current);
    };
  }, []);

  function applyPreset(id: string) {
    const next = presetById(id);
    const tone = upload ? null : starter.tone;
    setPresetId(next.id);
    setLayers(copyLayers(next.layers).map((layer) => (tone ? { ...layer, tone } : layer)));
    setSelectedId(next.layers[0]!.id);
  }

  function chooseStarter(next: Starter) {
    if (upload) URL.revokeObjectURL(upload.url);
    setUpload(null);
    setStarterId(next.id);
    setLayers((current) => current.map((layer) => ({ ...layer, tone: next.tone })));
    setError(null);
  }

  function loadFile(file: File) {
    if (file.type && !file.type.startsWith("image/")) {
      setError("Use a JPG, PNG, or WebP.");
      return;
    }
    if (file.size > MAX_UPLOAD) {
      setError("That photo is larger than 15 MB.");
      return;
    }
    if (upload) URL.revokeObjectURL(upload.url);
    setUpload({ url: URL.createObjectURL(file), name: file.name });
    setError(null);
  }

  function updateSelected(patch: Partial<MemeLayer>) {
    const id = selected.id;
    setLayers((current) => current.map((layer) => (layer.id === id ? { ...layer, ...patch } : layer)));
  }

  function onPointerDown(event: ReactPointerEvent<HTMLCanvasElement>) {
    const canvas = event.currentTarget;
    const point = pointFromEvent(canvas, event.clientX, event.clientY);
    const hit = hitAt(hitsRef.current, point.x, point.y);
    if (!hit) return;
    const layer = layersRef.current.find((item) => item.id === hit.id);
    if (!layer) return;
    event.preventDefault();
    setSelectedId(layer.id);
    dragRef.current = {
      id: layer.id,
      pointerId: event.pointerId,
      startX: point.x,
      startY: point.y,
      origX: layer.x,
      origY: layer.y,
    };
    try {
      canvas.setPointerCapture(event.pointerId);
    } catch {
      // The pointer can already be inactive. Drag still tracks move events.
    }
    canvas.style.cursor = "grabbing";
  }

  function onPointerMove(event: ReactPointerEvent<HTMLCanvasElement>) {
    const canvas = event.currentTarget;
    const point = pointFromEvent(canvas, event.clientX, event.clientY);
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) {
      canvas.style.cursor = hitAt(hitsRef.current, point.x, point.y) ? "grab" : "default";
      return;
    }
    const layer = layersRef.current.find((item) => item.id === drag.id);
    const { w, h } = sizeRef.current;
    const x = layer?.banner
      ? drag.origX
      : clamp(drag.origX + (point.x - drag.startX) / w, 0.06, 0.94);
    const y = clamp(drag.origY + (point.y - drag.startY) / h, 0.05, 0.95);
    pendingMove.current = { id: drag.id, x, y };
    if (frameReq.current) return;
    frameReq.current = requestAnimationFrame(() => {
      frameReq.current = 0;
      const next = pendingMove.current;
      if (!next) return;
      setLayers((current) =>
        current.map((item) => (item.id === next.id ? { ...item, x: next.x, y: next.y } : item)),
      );
    });
  }

  function endDrag(event: ReactPointerEvent<HTMLCanvasElement>) {
    if (dragRef.current?.pointerId === event.pointerId) {
      dragRef.current = null;
      event.currentTarget.style.cursor = "grab";
    }
  }

  async function onDownload() {
    const canvas = canvasRef.current;
    if (!canvas || status !== "ready") return;
    setBusy(true);
    try {
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
      if (!blob) {
        setError("Couldn't export that image.");
        return;
      }
      const file = new File([blob], "punchline.png", { type: "image/png" });
      const coarse = window.matchMedia("(pointer: coarse)").matches;
      if (coarse && navigator.canShare?.({ files: [file] })) {
        try {
          await navigator.share({ files: [file], title: "Punchline" });
          return;
        } catch (err) {
          if (err instanceof DOMException && err.name === "AbortError") return;
        }
      }
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "punchline.png";
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setSaved(true);
      window.setTimeout(() => setSaved(false), 1600);
    } finally {
      setBusy(false);
    }
  }

  const fontPx = Math.round(selected.fontSize * size.w);
  const outlinePx = Math.round(selected.fontSize * selected.outline * size.w);

  return (
    <div className="min-h-dvh bg-ink text-paper">
      <header className="sticky top-0 z-20 border-b border-line bg-ink">
        <div className="shell-pad mx-auto flex h-16 max-w-6xl items-center justify-between gap-2">
          <div className="flex min-w-0 items-center gap-2">
            <span className="grid size-9 shrink-0 place-items-center rounded-md bg-paper text-base font-semibold text-ink">
              P
            </span>
            <div className="min-w-0">
              <h1 className="truncate text-lg leading-tight font-semibold tracking-tight">Punchline</h1>
              <p className="hidden text-sm leading-tight text-mute sm:block">Meme studio</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <Button variant="ghost" aria-label="Reset captions" onClick={() => applyPreset(presetId)}>
              <RotateCcw className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">Reset</span>
            </Button>
            <Button onClick={onDownload} disabled={status !== "ready" || busy}>
              <Download className="size-4" aria-hidden="true" />
              {busy ? "Saving…" : saved ? "Saved" : "Download"}
            </Button>
          </div>
        </div>
      </header>

      <main className="shell-pad page-bottom mx-auto grid max-w-6xl gap-4 py-4 lg:grid-cols-[minmax(0,1fr)_22.5rem] lg:items-start lg:py-6">
        <section className="min-w-0 rounded-2xl bg-panel p-4">
          <div
            ref={frameRef}
            className="stage-frame relative overflow-hidden rounded-md bg-ink"
            onDragOver={(event) => {
              event.preventDefault();
              setDropping(true);
            }}
            onDragLeave={(event) => {
              if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setDropping(false);
            }}
            onDrop={(event) => {
              event.preventDefault();
              setDropping(false);
              const file = event.dataTransfer.files?.[0];
              if (file) loadFile(file);
            }}
          >
            <canvas
              ref={canvasRef}
              id="meme-canvas"
              width={size.w}
              height={size.h}
              aria-label="Meme preview"
              className="absolute top-1/2 left-1/2 max-h-full max-w-full -translate-x-1/2 -translate-y-1/2 touch-none select-none"
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={endDrag}
              onPointerCancel={endDrag}
            />
            {dropping ? (
              <div className="pointer-events-none absolute inset-0 grid place-items-center bg-ink/80">
                <p className="text-sm font-medium">Drop photo</p>
              </div>
            ) : null}
            {status === "loading" ? (
              <p className="pointer-events-none absolute inset-x-0 bottom-3 text-center text-sm text-mute">
                Loading photo…
              </p>
            ) : null}
          </div>
          <p className="mt-3 text-center text-sm text-mute">
            Drag a caption to move it. Arrow keys nudge the selected line.
          </p>
        </section>

        <aside className="flex min-w-0 flex-col gap-5 rounded-2xl bg-panel p-4">
          <section>
            <h2 className="text-sm font-semibold">Photo</h2>
            <p className="mt-1 truncate text-sm text-mute">{photoLabel}</p>
            <Button
              variant="quiet"
              className="mt-3 w-full"
              onClick={() => fileRef.current?.click()}
            >
              <ImagePlus className="size-4" aria-hidden="true" />
              Upload photo
            </Button>
            <input
              ref={fileRef}
              className="sr-only"
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (file) loadFile(file);
              }}
            />
            <div className="h-scroll mt-3">
              {STARTERS.map((item) => {
                const active = !upload && item.id === starterId;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-label={item.name}
                    aria-pressed={active}
                    onClick={() => chooseStarter(item)}
                    className={cn(
                      "relative size-16 shrink-0 overflow-hidden rounded-md border",
                      active ? "border-paper" : "border-line",
                    )}
                  >
                    {item.kind === "fill" ? (
                      <span className="block size-full" style={{ background: item.color }} />
                    ) : (
                      <img src={item.src} alt="" className="size-full object-cover" draggable={false} />
                    )}
                  </button>
                );
              })}
            </div>
          </section>

          <section className="border-t border-line pt-5">
            <h2 className="text-sm font-semibold">Layout</h2>
            <p className="mt-1 text-sm text-mute">{preset.detail}</p>
            <div className="h-scroll mt-3" role="group" aria-label="Meme layouts">
              {PRESETS.map((item) => {
                const active = item.id === presetId;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => applyPreset(item.id)}
                    className={cn(
                      "h-11 shrink-0 rounded-full px-4 text-sm font-medium",
                      active ? "bg-paper text-ink" : "bg-field text-paper",
                    )}
                  >
                    {item.name}
                  </button>
                );
              })}
            </div>
          </section>

          <section className="border-t border-line pt-5">
            <h2 className="text-sm font-semibold">Captions</h2>
            <div className="mt-3 flex flex-col gap-3">
              {layers.map((layer) => {
                const active = layer.id === selected.id;
                return (
                  <label key={layer.id} className="block">
                    <span className={cn("text-sm font-medium", active ? "text-paper" : "text-mute")}>
                      {layer.label}
                    </span>
                    <textarea
                      value={layer.text}
                      rows={2}
                      aria-label={`${layer.label} caption`}
                      placeholder="Type a caption"
                      onFocus={() => setSelectedId(layer.id)}
                      onChange={(event) => {
                        const text = event.target.value;
                        setSelectedId(layer.id);
                        setLayers((current) =>
                          current.map((item) => (item.id === layer.id ? { ...item, text } : item)),
                        );
                      }}
                      className={cn(
                        "mt-1 w-full resize-none rounded-md border bg-ink px-3 py-3 text-base text-paper",
                        "placeholder:text-faint focus-visible:ring-2 focus-visible:ring-paper/40 focus-visible:outline-none",
                        active ? "border-paper" : "border-line",
                      )}
                    />
                  </label>
                );
              })}
            </div>
          </section>

          <section className="border-t border-line pt-5">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-sm font-semibold">Style</h2>
              <p className="text-sm text-mute">Editing {selected.label.toLowerCase()}</p>
            </div>
            <div className="mt-3">
              <div className="mb-1 flex items-center justify-between text-sm">
                <span className="text-mute" id="font-size-label">
                  Font size
                </span>
                <span className="tabular-nums">{fontPx}</span>
              </div>
              <Slider
                label="Font size"
                min={0.036}
                max={0.16}
                step={0.001}
                value={selected.fontSize}
                onChange={(fontSize) => updateSelected({ fontSize })}
              />
            </div>
            <div className="mt-3">
              <div className="mb-1 flex items-center justify-between text-sm">
                <span className="text-mute" id="outline-label">
                  Outline
                </span>
                <span className="tabular-nums">{outlinePx}</span>
              </div>
              <Slider
                label="Outline"
                min={0}
                max={0.42}
                step={0.005}
                value={selected.outline}
                onChange={(outline) => updateSelected({ outline })}
              />
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2" role="group" aria-label="Text color">
              {(
                [
                  ["light", "White"],
                  ["dark", "Black"],
                ] as const
              ).map(([tone, name]) => {
                const active = selected.tone === tone;
                return (
                  <button
                    key={tone}
                    type="button"
                    aria-pressed={active}
                    onClick={() => updateSelected({ tone: tone as TextTone })}
                    className={cn(
                      "flex h-11 items-center justify-center gap-2 rounded-md border text-sm font-medium",
                      active ? "border-paper bg-field" : "border-line bg-transparent text-paper",
                    )}
                  >
                    <span
                      className={cn(
                        "size-4 rounded-full border",
                        tone === "light" ? "border-line bg-paper" : "border-line-strong bg-ink",
                      )}
                      aria-hidden="true"
                    />
                    {name}
                  </button>
                );
              })}
            </div>
          </section>

          {error ? (
            <p role="alert" className="text-sm text-paper">
              {error}
            </p>
          ) : null}
        </aside>
      </main>
    </div>
  );
}
