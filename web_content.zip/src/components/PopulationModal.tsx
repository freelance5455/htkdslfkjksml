import React from 'react';
import { useKingdom } from '../context/KingdomContext';
import { CIVILIZATIONS } from '../game/gameConfig';
import { PopulationHistoryChart } from './PopulationHistoryChart';
import {
  Users,
  X,
  Coins,
  Home,
  Smile,
  Frown,
  TrendingUp,
  AlertTriangle,
  Hammer,
  Shield,
  Wheat,
  Trees,
  Mountain,
  Sparkles,
} from 'lucide-react';

interface PopulationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab?: (tab: 'construction' | 'university' | 'army' | 'parliament' | 'map') => void;
}

export const PopulationModal: React.FC<PopulationModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
}) => {
  const { kingdom, rates, maxPopulation, demographicRate, playSound } = useKingdom();
  if (!isOpen || !kingdom) return null;

  const civ = CIVILIZATIONS[kingdom.civilization];
  const { buildings, taxRate, foodLevel, army, trainingQueue, workerAllocation } = kingdom;

  const currentPop = Math.floor(kingdom.population || 0);
  const maxPop = maxPopulation;
  const occupancyPct = Math.min(100, Math.round((currentPop / maxPop) * 100));

  // Military & Civilians breakdown
  const activeArmy = Object.values(army).reduce((acc: number, val: number) => acc + (val || 0), 0);
  const inTraining = trainingQueue.reduce((acc, it) => acc + (it.totalCount - it.trainedCount), 0);
  const totalMilitary = activeArmy + inTraining;
  const freeCitizens = Math.max(0, currentPop - totalMilitary);

  // Housing breakdown
  const housesLvl = buildings.houses || 0;
  const housesCap = housesLvl * 120;
  const townHallLvl = buildings.townHall || 1;
  const townHallCap = 150 + townHallLvl * 50;
  const granaryLvl = buildings.granary || 1;
  const granaryCap = granaryLvl * 30;

  // Happiness label
  const happiness = demographicRate.happiness;
  const getHappinessLabel = (h: number) => {
    if (h >= 80)
      return {
        text: 'Jubiloso y Fiel',
        color: 'text-emerald-400',
        badgeBg: 'bg-emerald-950/60 border-emerald-800/60',
        icon: <Smile className="w-5 h-5 text-emerald-400" />,
      };
    if (h >= 55)
      return {
        text: 'Conforme y Laborioso',
        color: 'text-yellow-400',
        badgeBg: 'bg-yellow-950/60 border-yellow-800/60',
        icon: <Smile className="w-5 h-5 text-yellow-400" />,
      };
    if (h >= 35)
      return {
        text: 'Inquieto y Quejumbroso',
        color: 'text-orange-400',
        badgeBg: 'bg-orange-950/60 border-orange-800/60',
        icon: <Frown className="w-5 h-5 text-orange-400" />,
      };
    return {
      text: 'Al Borde de la Revuelta',
      color: 'text-red-400',
      badgeBg: 'bg-red-950/60 border-red-800/60',
      icon: <Frown className="w-5 h-5 text-red-400" />,
    };
  };

  const status = getHappinessLabel(happiness);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-3xl bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-7 shadow-2xl relative overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-950/50 border border-amber-800/60 text-amber-400">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold font-serif text-stone-100 flex items-center gap-2">
                <span>Censo Feudal y Demografía</span>
              </h3>
              <p className="text-xs text-stone-400">
                {kingdom.kingdomName} • Linaje {civ.name}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-800 text-stone-400 hover:text-stone-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="overflow-y-auto pr-1 space-y-4 text-xs">
          {/* Top 3 KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Population & Housing */}
            <div className="p-3.5 rounded-2xl bg-stone-950/80 border border-stone-800 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] text-stone-400 font-semibold uppercase tracking-wider">
                  Población
                </span>
                <Home className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-2xl font-bold font-mono text-stone-100">
                {currentPop.toLocaleString()}
                <span className="text-xs font-normal text-stone-400 ml-1">/ {maxPop}</span>
              </div>
              {/* Progress bar */}
              <div className="mt-2">
                <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      occupancyPct >= 100
                        ? 'bg-red-500'
                        : occupancyPct >= 80
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${occupancyPct}%` }}
                  />
                </div>
                <div className="flex justify-between items-center text-[10px] text-stone-400 mt-1">
                  <span>{occupancyPct}% ocupación</span>
                  <span>{Math.max(0, maxPop - currentPop)} plazas libres</span>
                </div>
              </div>
            </div>

            {/* Growth rate */}
            <div className="p-3.5 rounded-2xl bg-stone-950/80 border border-stone-800 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] text-stone-400 font-semibold uppercase tracking-wider">
                  Crecimiento
                </span>
                <TrendingUp className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400">
                {demographicRate.growthPerHour > 0 ? `+${demographicRate.growthPerHour}` : '0'}
                <span className="text-xs font-normal text-stone-400 ml-1">hab/hora</span>
              </div>
              <div className="text-[10px] text-stone-400 mt-2 line-clamp-2">
                {demographicRate.statusText}
              </div>
            </div>

            {/* Happiness / Morale */}
            <div className="p-3.5 rounded-2xl bg-stone-950/80 border border-stone-800 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] text-stone-400 font-semibold uppercase tracking-wider">
                  Moral y Fecundidad
                </span>
                {status.icon}
              </div>
              <div className="text-2xl font-bold font-mono text-stone-100 flex items-center gap-1.5">
                <span>{happiness}%</span>
              </div>
              <div className={`text-[11px] font-semibold mt-2 ${status.color}`}>
                {status.text}
              </div>
            </div>
          </div>

          {/* Historical Population Growth Chart (Recharts) */}
          <PopulationHistoryChart kingdom={kingdom} />

          {/* Demographic Growth Explanation */}
          <div className="p-3.5 rounded-2xl bg-stone-950/60 border border-stone-850 space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-[11px] font-bold text-stone-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Dinámica de Población y Casas Residenciales</span>
              </h4>
              {onNavigateTab && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigateTab('construction');
                    playSound('click');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-[11px] transition cursor-pointer flex items-center gap-1"
                >
                  <Hammer className="w-3 h-3" />
                  <span>Mejorar Casas</span>
                </button>
              )}
            </div>
            <p className="text-stone-400 leading-relaxed text-[11px]">
              La población crece continuamente con la llegada de nuevas familias y nacimientos hasta alcanzar el tope que ofrecen las <strong className="text-stone-200">Casas y Chozas</strong>.
              Cuando se instruyen tropas en el cuartel, los soldados son reclutados de los aldeanos libres disponibles. Si caen en batalla, la población disminuye y se regenera con el tiempo.
            </p>
          </div>

          {/* Housing Capacity Breakdown */}
          <div className="space-y-2">
            <h4 className="text-[11px] font-bold text-stone-300 uppercase tracking-wider">
              Capacidad Habitacional ({maxPop} plazas en total)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="p-2.5 rounded-xl bg-stone-950/60 border border-stone-850 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Home className="w-4 h-4 text-amber-400" />
                  <div>
                    <div className="font-semibold text-stone-200">Casas y Chozas</div>
                    <div className="text-[10px] text-stone-500">Nivel {housesLvl}</div>
                  </div>
                </div>
                <span className="font-mono font-bold text-amber-400">+{housesCap}</span>
              </div>

              <div className="p-2.5 rounded-xl bg-stone-950/60 border border-stone-850 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 flex items-center justify-center text-xs">🏰</div>
                  <div>
                    <div className="font-semibold text-stone-200">Castillo Central</div>
                    <div className="text-[10px] text-stone-500">Nivel {townHallLvl}</div>
                  </div>
                </div>
                <span className="font-mono font-bold text-stone-300">+{townHallCap}</span>
              </div>

              <div className="p-2.5 rounded-xl bg-stone-950/60 border border-stone-850 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Wheat className="w-4 h-4 text-amber-500" />
                  <div>
                    <div className="font-semibold text-stone-200">Graneros Reales</div>
                    <div className="text-[10px] text-stone-500">Nivel {granaryLvl}</div>
                  </div>
                </div>
                <span className="font-mono font-bold text-stone-300">+{granaryCap}</span>
              </div>
            </div>
          </div>

          {/* Citizen Distribution */}
          <div className="space-y-2">
            <h4 className="text-[11px] font-bold text-stone-300 uppercase tracking-wider">
              Distribución de Habitantes en el Feudo
            </h4>
            <div className="space-y-1.5">
              {/* Free citizens */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-800/40">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800/60 text-emerald-400">
                    <Users className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <div className="font-semibold text-stone-100">Aldeanos Libres y Trabajadores</div>
                    <div className="text-[10px] text-stone-400">
                      Disponibles para adiestrar como soldados o realizar faenas
                    </div>
                  </div>
                </div>
                <span className="font-mono font-bold text-emerald-400 text-sm">{freeCitizens} almas</span>
              </div>

              {/* Active Military */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-stone-950/50 border border-stone-850">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-red-950/50 border border-red-800/60 text-red-400">
                    <Shield className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <div className="font-semibold text-stone-200">Ejército en Servicio Activo</div>
                    <div className="text-[10px] text-stone-400">
                      Soldados movilizados en la guarnición del feudo
                    </div>
                  </div>
                </div>
                <span className="font-mono font-bold text-red-400 text-sm">{activeArmy} guerreros</span>
              </div>

              {/* Recruits in training */}
              {inTraining > 0 && (
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-stone-950/50 border border-stone-850">
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 rounded-lg bg-amber-950/50 border border-amber-800/60 text-amber-400">
                      <Hammer className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="font-semibold text-stone-200">Reclutas en Adiestramiento</div>
                      <div className="text-[10px] text-stone-400">
                        En maniobras de instrucción en el cuartel
                      </div>
                    </div>
                  </div>
                  <span className="font-mono font-bold text-amber-400">{inTraining} soldados</span>
                </div>
              )}
            </div>
          </div>

          {/* Tax and Grain notice */}
          <div className="p-3 rounded-xl bg-stone-950/80 border border-stone-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-stone-400 text-[11px]">
              <Coins className="w-4 h-4 text-yellow-400 shrink-0" />
              <span>
                Edicto Fiscal: <strong className="text-yellow-400">{taxRate}%</strong> (+{rates.goldPerHour}/h oro) • Raciones: <strong className="text-amber-400">{foodLevel}</strong>
              </span>
            </div>
            {onNavigateTab && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateTab('parliament');
                  playSound('click');
                }}
                className="text-[10px] font-bold text-amber-400 hover:text-amber-300 underline cursor-pointer shrink-0"
              >
                Ajustar Leyes
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-stone-800 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold transition cursor-pointer"
          >
            Cerrar Censo
          </button>
        </div>
      </div>
    </div>
  );
};
