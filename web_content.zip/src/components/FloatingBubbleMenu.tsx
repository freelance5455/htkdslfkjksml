import { useRef, useState } from "react";
import { motion, AnimatePresence, useDragControls } from "framer-motion";
import AnimatedToggle from "./AnimatedToggle";

const FEATURES = [
  { key: "aimbot", icon: "🎯", label: "Aimbot" },
  { key: "esp", icon: "📍", label: "ESP Location" },
  { key: "headshot", icon: "💀", label: "100% Headshot" },
  { key: "bypass", icon: "🛡️", label: "Bypass" },
  { key: "wallhack", icon: "🧱", label: "Wallhack" },
  { key: "speed", icon: "⚡", label: "Speed Hack" },
] as const;

type FeatureKey = (typeof FEATURES)[number]["key"];

interface FloatingBubbleMenuProps {
  onToggleLog?: (label: string, state: boolean) => void;
}

export default function FloatingBubbleMenu({ onToggleLog }: FloatingBubbleMenuProps) {
  const [open, setOpen] = useState(false);
  const [features, setFeatures] = useState<Record<FeatureKey, boolean>>({
    aimbot: false,
    esp: false,
    headshot: false,
    bypass: false,
    wallhack: false,
    speed: false,
  });
  const constraintsRef = useRef(null);
  const dragControls = useDragControls();
  const movedRef = useRef(false);

  const toggleFeature = (key: FeatureKey) => {
    setFeatures((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      const label = FEATURES.find((f) => f.key === key)?.label ?? key;
      onToggleLog?.(label, next[key]);
      return next;
    });
  };

  const activeCount = Object.values(features).filter(Boolean).length;

  return (
    <div ref={constraintsRef} className="pointer-events-none fixed inset-0 z-50">
      <motion.div
        drag
        dragControls={dragControls}
        dragListener={false}
        dragMomentum={false}
        dragConstraints={constraintsRef}
        dragElastic={0.08}
        onDragStart={() => (movedRef.current = true)}
        initial={{ x: window.innerWidth - 88, y: window.innerHeight - 180 }}
        className="pointer-events-auto absolute flex flex-col items-end"
      >
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, scale: 0.7, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.7, y: 20 }}
              transition={{ type: "spring", stiffness: 300, damping: 24 }}
              className="mb-3 w-64 origin-bottom-right rounded-3xl border border-white/10 bg-slate-900/95 p-3 shadow-2xl shadow-black/60 backdrop-blur"
            >
              <div className="mb-2 flex items-center justify-between px-1">
                <p className="text-xs font-bold tracking-wide text-orange-400">
                  OVERLAY MENU • DEMO
                </p>
                <span className="rounded-full bg-orange-500/20 px-2 py-0.5 text-[10px] font-semibold text-orange-300">
                  {activeCount} ON
                </span>
              </div>
              <div className="space-y-1.5">
                {FEATURES.map((f) => (
                  <AnimatedToggle
                    key={f.key}
                    icon={f.icon}
                    label={f.label}
                    checked={features[f.key]}
                    onChange={() => toggleFeature(f.key)}
                  />
                ))}
              </div>
              <p className="mt-2 px-1 text-[9px] leading-snug text-slate-500">
                Sirf UI animation demo — koi real game function nahi hota.
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Draggable + clickable bubble icon */}
        <motion.button
          onPointerDown={(e) => {
            movedRef.current = false;
            dragControls.start(e);
          }}
          onClick={() => {
            if (!movedRef.current) setOpen((v) => !v);
          }}
          whileTap={{ scale: 0.9 }}
          animate={{
            boxShadow: open
              ? "0 0 0 6px rgba(249,115,22,0.25), 0 0 25px rgba(249,115,22,0.6)"
              : "0 0 0 0px rgba(249,115,22,0), 0 6px 18px rgba(0,0,0,0.5)",
          }}
          className="flex h-16 w-16 cursor-grab touch-none items-center justify-center rounded-full border-2 border-orange-400/70 bg-gradient-to-br from-slate-800 to-slate-950 text-2xl text-orange-300 active:cursor-grabbing"
        >
          <motion.span
            animate={{ rotate: open ? 135 : 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="flex items-center justify-center"
          >
            {open ? (
              <span className="text-2xl leading-none">✕</span>
            ) : (
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.8}
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-7 w-7"
              >
                <rect x="2" y="6" width="14" height="12" rx="2.5" />
                <path d="M16 10.5 21.5 7v10L16 13.5" />
              </svg>
            )}
          </motion.span>
        </motion.button>
      </motion.div>
    </div>
  );
}
