import React, { useState, useEffect } from 'react';
import {
  Phone,
  PhoneIncoming,
  PhoneOutgoing,
  PhoneMissed,
  Video,
  Trash2,
  Check,
  Loader2,
  Calendar,
} from 'lucide-react';
import { CallHistoryItem, Profile } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { useCall } from '../../contexts/CallContext';
import {
  getCallHistory,
  deleteCallRecordForMe,
  deleteMultipleCallsForMe,
  clearAllCallHistoryForMe,
} from '../../services/callService';
import { ConfirmationDialog } from '../common/ConfirmationDialog';

export const CallsView: React.FC = () => {
  const { user } = useAuth();
  const { startCall } = useCall();

  const [calls, setCalls] = useState<CallHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'missed'>('all');

  // Multi-select mode
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedCallIds, setSelectedCallIds] = useState<Set<string>>(new Set());

  // Confirmations
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [deleteSingleTarget, setDeleteSingleTarget] = useState<string | null>(null);

  const currentUserId = user?.id || '';

  const loadHistory = async () => {
    if (!currentUserId) return;
    setLoading(true);
    try {
      const data = await getCallHistory(currentUserId);
      setCalls(data);
    } catch (err) {
      console.error('Failed to load call history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, [currentUserId]);

  const filtered = activeTab === 'missed'
    ? calls.filter((c) => c.status === 'missed' || c.status === 'rejected')
    : calls;

  const toggleSelect = (id: string) => {
    setSelectedCallIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleDeleteSelected = async () => {
    if (selectedCallIds.size === 0) return;
    await deleteMultipleCallsForMe(Array.from(selectedCallIds), currentUserId);
    setSelectedCallIds(new Set());
    setIsSelectMode(false);
    loadHistory();
  };

  const formatCallDuration = (seconds: number) => {
    if (seconds <= 0) return '';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getCallDirection = (item: CallHistoryItem) => {
    const isOutgoing = item.caller_id === currentUserId;
    if (item.status === 'missed' || item.status === 'rejected') {
      return {
        label: isOutgoing ? 'Cancelled / Rejected' : 'Missed',
        icon: <PhoneMissed className="w-3.5 h-3.5 text-red-400" />,
        textColor: 'text-red-400',
      };
    }
    if (isOutgoing) {
      return {
        label: 'Outgoing',
        icon: <PhoneOutgoing className="w-3.5 h-3.5 text-cyan-400" />,
        textColor: 'text-cyan-400',
      };
    }
    return {
      label: 'Incoming',
      icon: <PhoneIncoming className="w-3.5 h-3.5 text-emerald-400" />,
      textColor: 'text-emerald-400',
    };
  };

  return (
    <div id="calls-view-container" className="h-full flex flex-col bg-neutral-900 text-white select-none">
      {/* Header */}
      <div className="p-4 border-b border-neutral-800 bg-neutral-950/40 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Call Logs</h2>
          <p className="text-xs text-neutral-400">Encrypted WebRTC Voice & Video calls</p>
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center space-x-2">
          {calls.length > 0 && (
            <>
              <button
                id="btn-toggle-select-calls"
                onClick={() => {
                  setIsSelectMode(!isSelectMode);
                  setSelectedCallIds(new Set());
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors ${
                  isSelectMode ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {isSelectMode ? 'Done' : 'Select'}
              </button>

              <button
                id="btn-clear-call-history"
                onClick={() => setShowClearConfirm(true)}
                className="p-1.5 text-neutral-400 hover:text-red-400 rounded-lg hover:bg-neutral-800 transition-colors"
                title="Clear all call history"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-neutral-800 px-4 pt-2 bg-neutral-900/50">
        <button
          id="tab-calls-all"
          onClick={() => setActiveTab('all')}
          className={`pb-2.5 px-4 text-xs font-semibold border-b-2 transition-colors ${
            activeTab === 'all'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          All Calls ({calls.length})
        </button>
        <button
          id="tab-calls-missed"
          onClick={() => setActiveTab('missed')}
          className={`pb-2.5 px-4 text-xs font-semibold border-b-2 transition-colors ${
            activeTab === 'missed'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Missed
        </button>
      </div>

      {/* Multi-select active toolbar */}
      {isSelectMode && (
        <div className="px-4 py-2 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between text-xs">
          <span className="text-neutral-300 font-semibold">{selectedCallIds.size} selected</span>
          <button
            onClick={handleDeleteSelected}
            disabled={selectedCallIds.size === 0}
            className="px-3 py-1 bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white rounded-lg font-medium"
          >
            Delete Selected
          </button>
        </div>
      )}

      {/* List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center space-y-2 text-neutral-500">
            <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
            <span className="text-xs">Loading call logs...</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-20 text-center flex flex-col items-center justify-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-800 text-neutral-400 flex items-center justify-center">
              <Phone className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-neutral-200">No call records</h4>
              <p className="text-xs text-neutral-500 mt-0.5">
                {activeTab === 'missed' ? 'No missed calls.' : 'Make 1-to-1 voice or video calls with your friends.'}
              </p>
            </div>
          </div>
        ) : (
          filtered.map((item) => {
            const isOutgoing = item.caller_id === currentUserId;
            const peer = isOutgoing ? item.receiver : item.caller;
            const direction = getCallDirection(item);
            const isSelected = selectedCallIds.has(item.id);

            return (
              <div
                key={item.id}
                id={`call-item-${item.id}`}
                className={`p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800/80 hover:border-neutral-700/80 flex items-center justify-between transition-all ${
                  isSelected ? 'border-emerald-500/50 bg-emerald-500/5' : ''
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  {isSelectMode && (
                    <button
                      onClick={() => toggleSelect(item.id)}
                      className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                        isSelected ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-neutral-700'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5" />}
                    </button>
                  )}

                  {/* Avatar */}
                  <div className="w-11 h-11 rounded-full bg-neutral-800 border border-neutral-700 overflow-hidden flex items-center justify-center text-sm font-bold text-neutral-200 shrink-0">
                    {peer?.avatar_url ? (
                      <img src={peer.avatar_url} alt={peer.display_name} className="w-full h-full object-cover" />
                    ) : (
                      peer?.display_name?.charAt(0).toUpperCase() || '?'
                    )}
                  </div>

                  {/* Call details */}
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold text-neutral-100 truncate">
                      {peer?.display_name || 'Contact'}
                    </h4>
                    <div className="flex items-center space-x-1.5 text-[11px] text-neutral-400 mt-0.5">
                      {direction.icon}
                      <span className={direction.textColor}>{direction.label}</span>
                      <span>•</span>
                      <span>{new Date(item.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</span>
                      {item.duration_seconds > 0 && (
                        <>
                          <span>•</span>
                          <span className="font-mono">{formatCallDuration(item.duration_seconds)}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Call back buttons */}
                {peer && !isSelectMode && (
                  <div className="flex items-center space-x-1 shrink-0">
                    <button
                      id={`btn-callback-voice-${item.id}`}
                      onClick={() => startCall(peer, 'voice')}
                      className="p-2 text-neutral-300 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                      title="Voice call back"
                    >
                      <Phone className="w-4 h-4" />
                    </button>

                    <button
                      id={`btn-callback-video-${item.id}`}
                      onClick={() => startCall(peer, 'video')}
                      className="p-2 text-neutral-300 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                      title="Video call back"
                    >
                      <Video className="w-4 h-4" />
                    </button>

                    <button
                      id={`btn-delete-call-${item.id}`}
                      onClick={() => setDeleteSingleTarget(item.id)}
                      className="p-2 text-neutral-500 hover:text-red-400 rounded-xl hover:bg-neutral-800 transition-colors"
                      title="Delete from history"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Confirmation Dialogs */}
      <ConfirmationDialog
        isOpen={showClearConfirm}
        title="Clear All Call History"
        message="Are you sure you want to clear your call history? This removes call records from your view."
        confirmLabel="Clear All"
        onConfirm={async () => {
          await clearAllCallHistoryForMe(currentUserId);
          setShowClearConfirm(false);
          loadHistory();
        }}
        onCancel={() => setShowClearConfirm(false)}
      />

      <ConfirmationDialog
        isOpen={Boolean(deleteSingleTarget)}
        title="Delete Call Log"
        message="Remove this call record from your history?"
        confirmLabel="Delete"
        onConfirm={async () => {
          if (!deleteSingleTarget) return;
          await deleteCallRecordForMe(deleteSingleTarget, currentUserId);
          setDeleteSingleTarget(null);
          loadHistory();
        }}
        onCancel={() => setDeleteSingleTarget(null)}
      />
    </div>
  );
};
