import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import {
  Moon,
  Sun,
  ShieldCheck,
  Sliders,
  Bell,
  HardDrive,
  Globe,
  HelpCircle,
  Info,
  LogOut,
  Edit3,
  Check,
  ChevronRight,
  Sparkles,
  Zap,
  Music2,
  X
} from 'lucide-react';

export const ProfileScreen: React.FC = () => {
  const {
    user,
    updateUserSettings,
    updateUserProfile,
    setIsAdminOpen,
    setIsOnboardingOpen,
    setIsAuthOpen
  } = useMusic();

  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [editName, setEditName] = useState(user.name);
  const [editEmail, setEditEmail] = useState(user.email);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile(editName, editEmail);
    setIsEditProfileOpen(false);
  };

  const audioQualityOptions = [
    { label: 'Auto (Dynamic data saver)', value: 'Auto' as const, rate: '~128 kbps' },
    { label: 'Low (Minimal cellular data)', value: 'Low' as const, rate: '96 kbps' },
    { label: 'Normal (Balanced streaming)', value: 'Normal' as const, rate: '160 kbps' },
    { label: 'High (Studio fidelity)', value: 'High' as const, rate: '256 kbps' },
    { label: 'Very High (Master Lossless)', value: 'Very High' as const, rate: '320 kbps Hi-Fi' }
  ];

  const equalizerPresets = [
    'Bass Boost',
    'Vocal',
    'Electronic',
    'Rock',
    'Acoustic',
    'Flat'
  ] as const;

  return (
    <div className="space-y-6 pb-28 pt-2 max-w-2xl mx-auto px-1">
      {/* Profile Card Header */}
      <div className="relative overflow-hidden p-6 rounded-3xl bg-gradient-to-br from-purple-900/40 via-white/[0.03] to-pink-900/30 border border-white/10 shadow-xl">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
          {/* Avatar with Glow */}
          <div className="relative group">
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-purple-600 via-pink-600 to-indigo-600 p-1 shadow-lg shadow-purple-600/30">
              <div className="w-full h-full rounded-full bg-[#12141f] flex items-center justify-center font-display font-black text-2xl text-white">
                {user.name[0]}
              </div>
            </div>
            <button
              onClick={() => setIsEditProfileOpen(true)}
              className="absolute bottom-0 right-0 p-1.5 rounded-full bg-purple-600 text-white shadow-md hover:bg-purple-500 transition-colors"
              title="Edit Profile"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* User Details */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="font-display font-extrabold text-xl sm:text-2xl text-white tracking-tight">
                  {user.name}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5 truncate">{user.email}</p>
              </div>

              <button
                onClick={() => setIsEditProfileOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white border border-white/10 transition-colors self-center sm:self-auto"
              >
                Edit Profile
              </button>
            </div>

            {/* Quick Badge */}
            <div className="mt-3 flex items-center justify-center sm:justify-start gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-semibold tracking-wider uppercase border border-purple-500/30">
                Premium Hi-Fi Member
              </span>
            </div>
          </div>
        </div>

        {/* User Stats Grid */}
        <div className="grid grid-cols-4 gap-2 mt-6 pt-5 border-t border-white/[0.08] text-center">
          <div>
            <p className="font-display font-bold text-base sm:text-lg text-white">
              {user.stats.playlists}
            </p>
            <span className="text-[11px] text-slate-400">Playlists</span>
          </div>
          <div>
            <p className="font-display font-bold text-base sm:text-lg text-pink-400">
              {user.stats.likedSongs}
            </p>
            <span className="text-[11px] text-slate-400">Liked</span>
          </div>
          <div>
            <p className="font-display font-bold text-base sm:text-lg text-white">
              {user.stats.following}
            </p>
            <span className="text-[11px] text-slate-400">Following</span>
          </div>
          <div>
            <p className="font-display font-bold text-base sm:text-lg text-white">
              {user.stats.followers}
            </p>
            <span className="text-[11px] text-slate-400">Followers</span>
          </div>
        </div>
      </div>

      {/* Admin Panel Quick Trigger Button */}
      <button
        onClick={() => setIsAdminOpen(true)}
        className="w-full flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-purple-900/30 via-pink-900/20 to-blue-900/30 hover:from-purple-900/50 hover:to-blue-900/50 border border-purple-500/30 transition-all text-left shadow-lg group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600/30 text-purple-300 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-display font-bold text-sm text-white group-hover:text-purple-300 transition-colors">
              Music Express Admin Panel
            </h4>
            <p className="text-xs text-slate-400">
              Manage songs, view stream analytics & manage users
            </p>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-white transition-colors" />
      </button>

      {/* App Settings Section */}
      <div className="space-y-3">
        <h3 className="font-display font-bold text-sm text-slate-300 px-1 uppercase tracking-wider text-[11px]">
          Preferences & Audio Settings
        </h3>

        <div className="space-y-1 bg-white/[0.02] rounded-3xl p-2 border border-white/[0.06]">
          {/* Dark / Light Mode Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.03] transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-white/5 text-purple-400 flex items-center justify-center">
                {user.settings.darkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-400" />}
              </div>
              <div>
                <p className="text-xs sm:text-sm font-semibold text-slate-200">Appearance Mode</p>
                <p className="text-[11px] text-slate-400">
                  {user.settings.darkMode ? 'Dark Theme (OLED Black)' : 'Light Theme'}
                </p>
              </div>
            </div>

            <button
              onClick={() => updateUserSettings({ darkMode: !user.settings.darkMode })}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                user.settings.darkMode ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  user.settings.darkMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Audio Quality Selector */}
          <div className="p-3 rounded-2xl hover:bg-white/[0.03] transition-colors">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white/5 text-blue-400 flex items-center justify-center">
                  <Music2 className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-semibold text-slate-200">Streaming Quality</p>
                  <p className="text-[11px] text-slate-400">Currently: {user.settings.audioQuality}</p>
                </div>
              </div>

              <select
                value={user.settings.audioQuality}
                onChange={(e) => updateUserSettings({ audioQuality: e.target.value as any })}
                className="bg-[#1c1e2b] text-purple-300 font-semibold text-xs px-2.5 py-1.5 rounded-xl border border-white/10 cursor-pointer"
              >
                {audioQualityOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.value} ({opt.rate})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Equalizer Presets */}
          <div className="p-3 rounded-2xl hover:bg-white/[0.03] transition-colors">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-white/5 text-pink-400 flex items-center justify-center">
                <Sliders className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs sm:text-sm font-semibold text-slate-200">Hardware Equalizer</p>
                <p className="text-[11px] text-slate-400">Preset: {user.settings.equalizerPreset}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-1.5 mt-2">
              {equalizerPresets.map((eq) => (
                <button
                  key={eq}
                  onClick={() => updateUserSettings({ equalizerPreset: eq })}
                  className={`py-1.5 px-2 rounded-xl text-[11px] font-medium transition-all ${
                    user.settings.equalizerPreset === eq
                      ? 'bg-purple-600 text-white shadow-sm font-semibold'
                      : 'bg-white/[0.04] text-slate-400 hover:text-white'
                  }`}
                >
                  {eq}
                </button>
              ))}
            </div>
          </div>

          {/* Crossfade slider */}
          <div className="p-3 rounded-2xl hover:bg-white/[0.03] transition-colors">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-semibold text-slate-200">Crossfade Between Tracks</span>
              <span className="font-mono text-purple-400">{user.settings.crossfadeSec}s</span>
            </div>
            <input
              type="range"
              min={0}
              max={12}
              value={user.settings.crossfadeSec}
              onChange={(e) => updateUserSettings({ crossfadeSec: parseInt(e.target.value) })}
              className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-purple-500"
            />
          </div>

          {/* Data Saver Mode */}
          <div className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.03] transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-white/5 text-emerald-400 flex items-center justify-center">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs sm:text-sm font-semibold text-slate-200">Data Saver Mode</p>
                <p className="text-[11px] text-slate-400">Compresses audio streaming on cellular data</p>
              </div>
            </div>

            <button
              onClick={() => updateUserSettings({ dataSaver: !user.settings.dataSaver })}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                user.settings.dataSaver ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  user.settings.dataSaver ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Notifications */}
          <div className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.03] transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-white/5 text-amber-400 flex items-center justify-center">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs sm:text-sm font-semibold text-slate-200">New Release Alerts</p>
                <p className="text-[11px] text-slate-400">Receive alerts when your artists drop music</p>
              </div>
            </div>

            <button
              onClick={() => updateUserSettings({ notifications: !user.settings.notifications })}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                user.settings.notifications ? 'bg-purple-600' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  user.settings.notifications ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* General Actions */}
      <div className="space-y-1 bg-white/[0.02] rounded-3xl p-2 border border-white/[0.06]">
        {/* Onboarding tour re-trigger */}
        <button
          onClick={() => setIsOnboardingOpen(true)}
          className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.04] transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-xs sm:text-sm font-medium text-slate-200">
              Restart Welcome Tour
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        {/* Help & Support */}
        <button
          onClick={() => setShowSupportModal(true)}
          className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.04] transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <HelpCircle className="w-4 h-4 text-blue-400" />
            <span className="text-xs sm:text-sm font-medium text-slate-200">
              Help & Support
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        {/* About */}
        <button
          onClick={() => setShowAboutModal(true)}
          className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.04] transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <Info className="w-4 h-4 text-pink-400" />
            <span className="text-xs sm:text-sm font-medium text-slate-200">
              About Music Express
            </span>
          </div>
          <span className="text-xs text-slate-500">v3.4 Android</span>
        </button>

        {/* Switch / Logout */}
        <button
          onClick={() => setIsAuthOpen(true)}
          className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-red-500/10 transition-colors text-left text-red-400"
        >
          <div className="flex items-center gap-3">
            <LogOut className="w-4 h-4" />
            <span className="text-xs sm:text-sm font-semibold">
              Switch Account or Logout
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-red-400/50" />
        </button>
      </div>

      {/* Edit Profile Modal */}
      {isEditProfileOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/10 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <h3 className="font-display font-bold text-base text-white">Edit Profile</h3>
              <button onClick={() => setIsEditProfileOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleProfileSave} className="mt-4 space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Your Name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">Email Address</label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white/[0.06] border border-white/10 text-white text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-purple-600 text-white font-semibold text-xs hover:bg-purple-500 transition-colors"
                >
                  Save Changes
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditProfileOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 text-slate-300 text-xs hover:bg-white/20"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* About Modal */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/10 p-6 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 mx-auto flex items-center justify-center text-white font-display font-black text-xl shadow-lg mb-3">
              ME
            </div>
            <h3 className="font-display font-bold text-lg text-white">Music Express</h3>
            <p className="text-xs text-purple-300 mt-0.5">Version 3.4 · Commercial Edition</p>
            <p className="text-xs text-slate-400 mt-3 leading-relaxed">
              Designed for Android & modern touch viewports with Web Audio synthesizers, real-time waveform visualizers, synchronized lyrics, and offline downloads.
            </p>
            <button
              onClick={() => setShowAboutModal(false)}
              className="mt-5 w-full py-2 rounded-xl bg-purple-600 text-white font-semibold text-xs hover:bg-purple-500"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Support Modal */}
      {showSupportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-[#141622] border border-white/10 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <h3 className="font-display font-bold text-base text-white">Help & Support</h3>
              <button onClick={() => setShowSupportModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="mt-4 space-y-3 text-xs text-slate-300">
              <p>• <strong>Offline Mode:</strong> Toggle Offline Mode in the Downloads tab to test playing only locally cached tracks.</p>
              <p>• <strong>Lyrics:</strong> Tap any lyric line in the full player to scrub playback immediately to that timestamp.</p>
              <p>• <strong>Audio Engine:</strong> Powered by Web Audio API synthesizers to ensure uninterrupted, crystal-clear playback on all platforms.</p>
            </div>
            <button
              onClick={() => setShowSupportModal(false)}
              className="mt-5 w-full py-2 rounded-xl bg-purple-600 text-white font-semibold text-xs hover:bg-purple-500"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
