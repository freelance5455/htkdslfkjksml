import { useState } from 'react';
import { User, Shield, Globe, Coins, Moon, FileText, Bell, Heart, LogOut, ChevronRight, ChevronLeft, Building2, Edit3, Fingerprint, ScanFace, KeyRound } from 'lucide-react';
import { UserProfile, Language, Currency } from '../../types';
import { translations } from '../../i18n/translations';
import { getBiometricSettings, saveBiometricSettings, lockSection, BiometricSettings } from '../../utils/biometrics';

interface ProfileScreenProps {
  user: UserProfile;
  language: Language;
  currency: Currency;
  onUpdateLanguage: (lang: Language) => void;
  onUpdateCurrency: (curr: Currency) => void;
  onOpenAgencyMode: () => void;
  onOpenAuthEdit: () => void;
  onOpenWallet: () => void;
  onOpenTrips: () => void;
  onLogout: () => void;
  onLockAllSections?: () => void;
}

export function ProfileScreen({
  user,
  language,
  currency,
  onUpdateLanguage,
  onUpdateCurrency,
  onOpenAgencyMode,
  onOpenAuthEdit,
  onOpenWallet,
  onOpenTrips,
  onLogout,
  onLockAllSections,
}: ProfileScreenProps) {
  const [biometricConfig, setBiometricConfig] = useState<BiometricSettings>(() => getBiometricSettings());
  const [savedToast, setSavedToast] = useState('');
  const t = translations[language];
  const isRTL = language === 'ar';

  return (
    <div className="space-y-6 pb-24">
      {/* Profile Card Header */}
      <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 text-white relative overflow-hidden">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-cyan-400 p-0.5 shadow-[0_0_20px_rgba(0,240,255,0.4)]">
              <img
                src={user.avatarUrl}
                alt={user.fullName}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
            <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center text-[10px]">
              ✓
            </span>
          </div>

          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white">{user.fullName}</h2>
              <button
                onClick={onOpenAuthEdit}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-cyan-400 hover:text-white"
                title="تعديل البيانات"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">{user.email}</p>
            <p className="text-[11px] text-cyan-300 font-mono mt-0.5">
              {user.passportNumber ? `جواز السفر: ${user.passportNumber}` : user.phone}
            </p>
          </div>
        </div>

        {/* Agency Toggle Shortcut */}
        <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-semibold text-slate-200">
              {language === 'ar' ? 'صلاحيات Tourism By Taki Backoffice' : 'Agency Admin Console'}
            </span>
          </div>
          <button
            onClick={onOpenAgencyMode}
            className="px-3 py-1 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 text-xs font-bold hover:bg-cyan-500/30 transition-colors"
          >
            {language === 'ar' ? 'دخول لوحة الوكالة ←' : 'Open Console →'}
          </button>
        </div>
      </div>

      {/* App Preferences & Settings */}
      <div className="glass-panel rounded-3xl p-5 border border-slate-800 text-white space-y-4">
        <h3 className="text-xs font-bold text-slate-300 flex items-center gap-2">
          <Globe className="w-4 h-4 text-cyan-400" />
          <span>{language === 'ar' ? 'تفضيلات التطبيق والإعدادات الدولية:' : 'App Preferences:'}</span>
        </h3>

        {/* Language Selector */}
        <div className="flex items-center justify-between py-2 border-b border-slate-800/80">
          <div>
            <p className="text-xs font-semibold text-white">{t.languageSetting}</p>
            <p className="text-[10px] text-slate-400">العربية (RTL) / Français / English</p>
          </div>
          <div className="flex items-center gap-1 bg-[#060c20] p-1 rounded-xl border border-slate-800">
            {(['ar', 'fr', 'en'] as const).map(lang => (
              <button
                key={lang}
                onClick={() => onUpdateLanguage(lang)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                  language === lang
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {lang === 'ar' ? 'عربي' : lang === 'fr' ? 'FR' : 'EN'}
              </button>
            ))}
          </div>
        </div>

        {/* Currency Selector */}
        <div className="flex items-center justify-between py-2 border-b border-slate-800/80">
          <div>
            <p className="text-xs font-semibold text-white">{t.currencySetting}</p>
            <p className="text-[10px] text-slate-400">دينار جزائري (DZD) / يورو (EUR) / دولار (USD)</p>
          </div>
          <div className="flex items-center gap-1 bg-[#060c20] p-1 rounded-xl border border-slate-800">
            {(['DZD', 'EUR', 'USD'] as const).map(curr => (
              <button
                key={curr}
                onClick={() => onUpdateCurrency(curr)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold font-mono transition-colors ${
                  currency === curr
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Biometric Security & Vault Controls */}
      <div className="glass-panel-elevated rounded-3xl p-5 border border-cyan-500/30 text-white space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-400 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white">
                {language === 'ar' ? 'أمان البصمة والخزنة المشفرة' : 'Biometric Security & Vault'}
              </h3>
              <p className="text-[10px] text-slate-400">
                {language === 'ar' ? 'تأمين محفظة التذاكر والملف الشخصي محلياً' : 'Local biometric lock for wallet & profile'}
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={biometricConfig.enabled}
              onChange={(e) => {
                const next = saveBiometricSettings({ enabled: e.target.checked });
                setBiometricConfig(next);
                setSavedToast(language === 'ar' ? 'تم تحديث إعدادات الأمان البيومتري' : 'Security settings updated');
                setTimeout(() => setSavedToast(''), 2000);
              }}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
          </label>
        </div>

        {biometricConfig.enabled && (
          <div className="space-y-3 pt-2 border-t border-slate-800/80">
            {/* Preferred Biometric Method */}
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">
                {language === 'ar' ? 'طريقة التحقق المفضلة:' : 'Preferred Method:'}
              </span>
              <div className="flex items-center gap-1 bg-[#060c20] p-1 rounded-xl border border-slate-800">
                {[
                  { id: 'faceid', label: language === 'ar' ? 'بصمة الوجه' : 'Face ID' },
                  { id: 'touchid', label: language === 'ar' ? 'بصمة الإصبع' : 'Touch ID' },
                  { id: 'pin', label: 'PIN' },
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      const next = saveBiometricSettings({ method: m.id as any });
                      setBiometricConfig(next);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer ${
                      biometricConfig.method === m.id
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Section Toggles */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => {
                  const next = saveBiometricSettings({
                    requireForWallet: !biometricConfig.requireForWallet,
                  });
                  setBiometricConfig(next);
                }}
                className={`p-2.5 rounded-2xl border text-start transition-all cursor-pointer ${
                  biometricConfig.requireForWallet
                    ? 'bg-cyan-500/10 border-cyan-400/50 text-cyan-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                <div className="font-bold text-[11px] flex items-center justify-between">
                  <span>{language === 'ar' ? 'محفظة الوثائق' : 'Travel Wallet'}</span>
                  <span className={`w-2 h-2 rounded-full ${biometricConfig.requireForWallet ? 'bg-cyan-400' : 'bg-slate-600'}`} />
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  {biometricConfig.requireForWallet ? (language === 'ar' ? 'مقفلة بالبصمة' : 'Protected') : (language === 'ar' ? 'غير مقفلة' : 'Unprotected')}
                </span>
              </button>

              <button
                onClick={() => {
                  const next = saveBiometricSettings({
                    requireForProfile: !biometricConfig.requireForProfile,
                  });
                  setBiometricConfig(next);
                }}
                className={`p-2.5 rounded-2xl border text-start transition-all cursor-pointer ${
                  biometricConfig.requireForProfile
                    ? 'bg-cyan-500/10 border-cyan-400/50 text-cyan-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                <div className="font-bold text-[11px] flex items-center justify-between">
                  <span>{language === 'ar' ? 'الملف الشخصي' : 'Profile Info'}</span>
                  <span className={`w-2 h-2 rounded-full ${biometricConfig.requireForProfile ? 'bg-cyan-400' : 'bg-slate-600'}`} />
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  {biometricConfig.requireForProfile ? (language === 'ar' ? 'مقفل بالبصمة' : 'Protected') : (language === 'ar' ? 'غير مقفل' : 'Unprotected')}
                </span>
              </button>
            </div>

            {/* Lock All Now Button & PIN reminder */}
            <div className="pt-2 flex items-center justify-between gap-2">
              <span className="text-[10px] text-slate-400 font-mono">
                {language === 'ar' ? `رمز PIN الاحتياطي: ${biometricConfig.pin || '1234'}` : `Backup PIN: ${biometricConfig.pin || '1234'}`}
              </span>

              <button
                onClick={() => {
                  lockSection();
                  if (onLockAllSections) onLockAllSections();
                  setSavedToast(language === 'ar' ? 'تم قفل الخزنة والملف فوراً!' : 'Vault & Profile locked!');
                  setTimeout(() => setSavedToast(''), 2000);
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/40 hover:bg-cyan-500/20 text-cyan-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span>{language === 'ar' ? 'قفل الخزنة الآن' : 'Lock Vault Now'}</span>
              </button>
            </div>
          </div>
        )}

        {savedToast && (
          <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold text-center animate-fade-in">
            {savedToast}
          </div>
        )}
      </div>

      {/* Navigation Shortcuts */}
      <div className="space-y-2">
        {[
          { label: t.upcomingTripTitle, action: onOpenTrips, icon: <FileText className="w-4 h-4 text-cyan-400" /> },
          { label: t.walletTitle, action: onOpenWallet, icon: <Shield className="w-4 h-4 text-emerald-400" /> },
          { label: t.personalInfo, action: onOpenAuthEdit, icon: <User className="w-4 h-4 text-blue-400" /> },
        ].map((item, idx) => (
          <button
            key={idx}
            onClick={item.action}
            className="w-full glass-panel p-3.5 rounded-2xl border border-slate-800 hover:border-cyan-400/30 flex items-center justify-between text-xs text-white transition-all"
          >
            <div className="flex items-center gap-3">
              {item.icon}
              <span className="font-semibold">{item.label}</span>
            </div>
            {isRTL ? <ChevronLeft className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
          </button>
        ))}
      </div>

      {/* Logout Button */}
      <button
        onClick={onLogout}
        className="w-full h-11 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center justify-center gap-2 hover:bg-rose-500/20 transition-colors"
      >
        <LogOut className="w-4 h-4" />
        <span>{t.logout}</span>
      </button>
    </div>
  );
}
