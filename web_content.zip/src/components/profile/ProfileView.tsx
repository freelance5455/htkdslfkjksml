import React, { useState } from 'react';
import { UserProfile, Book, ReadingSession, ReadingGoal, AppSettings } from '../../types';
import { calculateReadingStats } from '../../services/statsCalculator';
import { SharedProfileModal } from './SharedProfileModal';
import { CoverImage } from '../common/CoverImage';
import {
  User,
  BookOpen,
  CheckCircle2,
  Clock,
  Flame,
  Award,
  Settings,
  Target,
  Download,
  Upload,
  Sparkles,
  Edit2,
  Check,
  Cloud,
  Palette,
  Eye,
  Lock,
  Heart,
  Share2,
} from 'lucide-react';

interface ProfileViewProps {
  user: UserProfile;
  books: Book[];
  sessions: ReadingSession[];
  goals: ReadingGoal[];
  settings: AppSettings;
  onUpdateUser: (user: UserProfile) => void;
  onOpenSettings: () => void;
  onOpenBookDetail: (book: Book) => void;
  onOpenBackupModal?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  books,
  sessions,
  goals,
  settings,
  onUpdateUser,
  onOpenSettings,
  onOpenBookDetail,
  onOpenBackupModal,
}) => {
  const stats = calculateReadingStats(books, sessions);
  const [profileMode, setProfileMode] = useState<'private' | 'shared'>('private');
  const [isEditingName, setIsEditingName] = useState(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [nameInput, setNameInput] = useState(user.name);
  const [bioInput, setBioInput] = useState(user.bio || '');

  const shared = user.sharedProfile || {
    favoriteBookTitle: books.find((b) => b.favorite)?.title || 'Dune',
    favoriteBookAuthor: books.find((b) => b.favorite)?.author || 'Frank Herbert',
    favoriteBookCover: books.find((b) => b.favorite)?.coverUrl,
    currentBookTitle: books.find((b) => b.status === 'LEYENDO')?.title,
    currentBookAuthor: books.find((b) => b.status === 'LEYENDO')?.author,
    currentBookCover: books.find((b) => b.status === 'LEYENDO')?.coverUrl,
    favoriteAuthor: 'Frank Herbert',
    favoriteGenre: 'Ciencia Ficción',
    theme: {
      primaryColor: '#8b5cf6',
      accentColor: '#ec4899',
      avatarFrameColor: '#a855f7',
      avatarFrameShape: 'glow',
      bannerType: 'preset',
      bannerValue: 'linear-gradient(135deg, #4c1d95 0%, #1e1b4b 100%)',
      bannerBlur: 16,
    },
    privacy: {
      showBooks: true,
      showFavoriteBook: true,
      showCurrentBook: true,
      showFavoriteAuthor: true,
      showFavoriteGenre: true,
      showStats: true,
      showActivity: true,
      showCollections: true,
      showQuotes: true,
    },
  };

  const theme = shared.theme;
  const privacy = shared.privacy;
  const profileAccent = theme.accentColor || theme.primaryColor || '#ec4899';

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onUpdateUser({
      ...user,
      name: nameInput.trim(),
      bio: bioInput.trim() || undefined,
    });
    setIsEditingName(false);
  };

  // Real milestone badges
  const milestones = [
    {
      title: 'Primer Libro',
      desc: 'Completar tu primer libro',
      achieved: stats.completedBooks >= 1,
      icon: '🌱',
    },
    {
      title: 'Racha de Fuego',
      desc: '3 días continuos de lectura',
      achieved: stats.longestStreakDays >= 3,
      icon: '🔥',
    },
    {
      title: 'Club de las 500',
      desc: 'Leer más de 500 páginas',
      achieved: stats.totalPagesRead >= 500,
      icon: '⚡',
    },
    {
      title: 'Bibliófilo',
      desc: 'Tener más de 5 libros registrados',
      achieved: stats.totalBooks >= 5,
      icon: '📚',
    },
  ];

  return (
    <div className="space-y-6 pb-20 animate-fadeIn">
      {/* Top Switcher: Mi Perfil Privado vs Perfil Compartido (Requisitos 2 & 5) */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 glass-panel rounded-2xl border border-white/10">
        <div className="flex items-center gap-1.5 p-1 bg-white/[0.04] rounded-xl border border-white/[0.06] w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setProfileMode('private')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
              profileMode === 'private'
                ? 'bg-white text-zinc-950 shadow-md font-bold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Mi perfil privado / completo</span>
          </button>

          <button
            type="button"
            onClick={() => setProfileMode('shared')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-2 ${
              profileMode === 'shared'
                ? 'bg-white text-zinc-950 shadow-md font-bold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Perfil que ven mis amigos</span>
          </button>
        </div>

        <button
          type="button"
          onClick={() => setIsCustomizerOpen(true)}
          className="w-full sm:w-auto px-4 py-2 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 text-xs font-semibold flex items-center justify-center gap-2 transition-all shadow-sm active:scale-95"
        >
          <Palette className="w-4 h-4 text-purple-400" />
          <span>Personalizar perfil compartido & Privacidad</span>
        </button>
      </div>

      {/* NOTICE WHEN IN SHARED VIEW */}
      {profileMode === 'shared' && (
        <div className="p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/30 flex items-center justify-between gap-3 text-xs text-purple-200">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
            <span>
              <strong>Vista previa compartida:</strong> Así ven tu perfil tus amigos. Solo se muestran los elementos que mantienes activos en Privacidad.
            </span>
          </div>
          <button
            onClick={() => setIsCustomizerOpen(true)}
            className="text-white underline font-semibold shrink-0"
          >
            Editar ajustes
          </button>
        </div>
      )}

      {/* --- PROFILE HEADER CARD --- */}
      <div
        className="glass-panel rounded-3xl border relative overflow-hidden shadow-2xl transition-all"
        style={
          profileMode === 'shared'
            ? {
                borderColor: `${profileAccent}44`,
                boxShadow: `0 8px 32px 0 ${profileAccent}22`,
              }
            : { borderColor: 'rgba(255,255,255,0.1)' }
        }
      >
        {/* Banner with blur effect (Only in shared view or when banner is configured) */}
        {profileMode === 'shared' && (
          <div className="relative h-44 sm:h-52 w-full overflow-hidden shrink-0">
            <div
              className="absolute inset-0 w-full h-full scale-110"
              style={{
                background:
                  theme.bannerType === 'image' && theme.bannerValue
                    ? `url(${theme.bannerValue}) center/cover no-repeat`
                    : theme.bannerValue,
                filter: `blur(${theme.bannerBlur || 16}px)`,
                opacity: 0.65,
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/40 to-[#07080a]" />
          </div>
        )}

        <div
          className={`p-6 sm:p-8 relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-6 ${
            profileMode === 'shared' ? '-mt-16 sm:-mt-20' : ''
          }`}
        >
          {/* Avatar with customized frame in shared view */}
          <div className="relative group shrink-0">
            {user.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={user.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shadow-2xl border-4"
                style={{
                  borderColor:
                    profileMode === 'shared'
                      ? theme.avatarFrameColor || profileAccent
                      : 'rgba(255,255,255,0.2)',
                  boxShadow:
                    profileMode === 'shared'
                      ? `0 0 24px ${profileAccent}55`
                      : 'none',
                }}
              />
            ) : (
              <div
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-zinc-800 border-4 flex items-center justify-center text-white shadow-xl text-3xl font-bold font-['Syne']"
                style={{
                  borderColor:
                    profileMode === 'shared'
                      ? theme.avatarFrameColor || profileAccent
                      : 'rgba(255,255,255,0.2)',
                  boxShadow:
                    profileMode === 'shared'
                      ? `0 0 24px ${profileAccent}55`
                      : 'none',
                }}
              >
                {user.name.charAt(0).toUpperCase()}
              </div>
            )}
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-white border-2 border-zinc-900 flex items-center justify-center text-zinc-950 text-xs font-bold">
              ✓
            </div>
          </div>

          {/* User Info */}
          <div className="flex-1 text-center sm:text-left space-y-2 min-w-0">
            {profileMode === 'private' && isEditingName ? (
              <form onSubmit={handleSaveProfile} className="space-y-2 max-w-sm">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/40 focus:border-white/80 rounded-xl px-3 py-1.5 text-sm text-white font-semibold outline-none"
                  placeholder="Tu nombre..."
                  autoFocus
                />
                <input
                  type="text"
                  value={bioInput}
                  onChange={(e) => setBioInput(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/20 focus:border-white/50 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                  placeholder="Tu biografía o lema de lectura..."
                />
                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    className="px-3 py-1 bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs rounded-lg transition-colors"
                  >
                    Guardar
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditingName(false)}
                    className="px-3 py-1 text-xs text-zinc-400 hover:text-white"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            ) : (
              <div>
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne']">
                    {user.name}
                  </h2>
                  {profileMode === 'private' && (
                    <button
                      onClick={() => setIsEditingName(true)}
                      className="p-1 rounded-lg text-zinc-400 hover:text-white transition-colors"
                      title="Editar perfil"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-zinc-300">
                  {user.bio || 'Lector en Mi Biblioteca'}
                </p>
                <div className="flex items-center justify-center sm:justify-start gap-2 mt-1">
                  <span className="text-[11px] text-zinc-400">
                    Miembro desde {new Date(user.joinedDate).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
                  </span>
                  {profileMode === 'shared' && (
                    <span
                      className="px-2 py-0.5 rounded-full text-[10px] font-semibold border shadow-sm"
                      style={{
                        backgroundColor: `${profileAccent}22`,
                        color: profileAccent,
                        borderColor: `${profileAccent}55`,
                      }}
                    >
                      Perfil Compartido
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Quick Actions (only in private view) */}
          {profileMode === 'private' && (
            <div className="flex items-center gap-2 shrink-0">
              {onOpenBackupModal && (
                <button
                  onClick={onOpenBackupModal}
                  className="px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
                  title="Sincronización multi-dispositivo y copias de seguridad"
                >
                  <Cloud className="w-3.5 h-3.5 text-zinc-300" />
                  <span>Datos & Sync</span>
                </button>
              )}
              <button
                onClick={onOpenSettings}
                className="px-3.5 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                <Settings className="w-3.5 h-3.5" />
                <span>Configuración</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* --- REQUISITO 4 & 9: INFORMACIÓN DEL PERFIL COMPARTIDO (Libro favorito, Leyendo actualmente, Autor, Género) --- */}
      {/* Visible in shared mode (according to privacy) or in private mode as preview */}
      {(profileMode === 'shared' || profileMode === 'private') && (
        <div
          className="glass-panel rounded-3xl p-5 sm:p-6 border space-y-4 transition-all"
          style={
            profileMode === 'shared'
              ? {
                  borderColor: `${profileAccent}35`,
                  boxShadow: `0 8px 30px 0 ${profileAccent}12`,
                }
              : { borderColor: 'rgba(255,255,255,0.1)' }
          }
        >
          <div className="flex items-center justify-between">
            <h3
              className="text-xs font-bold uppercase tracking-wider flex items-center gap-2"
              style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
            >
              <Sparkles className="w-4 h-4" style={{ color: profileMode === 'shared' ? profileAccent : '#c084fc' }} />
              <span>Gusto Literario & Lecturas</span>
            </h3>
            {profileMode === 'private' && (
              <button
                onClick={() => setIsCustomizerOpen(true)}
                className="text-xs text-purple-400 hover:text-purple-300 font-semibold"
              >
                Editar gustos
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Libro Favorito */}
            {(profileMode === 'private' || privacy.showFavoriteBook) && shared.favoriteBookTitle && (
              <div
                className="glass-panel-subtle rounded-2xl p-3.5 border flex items-center gap-3 transition-all"
                style={
                  profileMode === 'shared'
                    ? {
                        borderColor: `${profileAccent}40`,
                        background: `linear-gradient(135deg, ${profileAccent}15, rgba(255,255,255,0.02))`,
                      }
                    : { borderColor: 'rgba(255,255,255,0.1)' }
                }
              >
                {shared.favoriteBookCover && (
                  <div
                    className="w-10 h-14 rounded-lg overflow-hidden shrink-0 border shadow-sm"
                    style={{
                      borderColor: profileMode === 'shared' ? `${profileAccent}50` : 'rgba(255,255,255,0.15)',
                    }}
                  >
                    <CoverImage
                      url={shared.favoriteBookCover}
                      title={shared.favoriteBookTitle}
                      author={shared.favoriteBookAuthor || ''}
                      showShadow={false}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className="min-w-0">
                  <span
                    className="text-[10px] uppercase font-bold block"
                    style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
                  >
                    Libro Favorito
                  </span>
                  <h4 className="text-xs font-bold text-white truncate mt-0.5">
                    {shared.favoriteBookTitle}
                  </h4>
                  {shared.favoriteBookAuthor && (
                    <p className="text-[11px] text-zinc-300 truncate">{shared.favoriteBookAuthor}</p>
                  )}
                </div>
              </div>
            )}

            {/* Leyendo actualmente */}
            {(profileMode === 'private' || privacy.showCurrentBook) && shared.currentBookTitle && (
              <div
                className="glass-panel-subtle rounded-2xl p-3.5 border flex items-center gap-3 transition-all"
                style={
                  profileMode === 'shared'
                    ? {
                        borderColor: `${profileAccent}40`,
                        background: `linear-gradient(135deg, ${profileAccent}15, rgba(255,255,255,0.02))`,
                      }
                    : { borderColor: 'rgba(255,255,255,0.1)' }
                }
              >
                {shared.currentBookCover && (
                  <div
                    className="w-10 h-14 rounded-lg overflow-hidden shrink-0 border shadow-sm"
                    style={{
                      borderColor: profileMode === 'shared' ? `${profileAccent}50` : 'rgba(255,255,255,0.15)',
                    }}
                  >
                    <CoverImage
                      url={shared.currentBookCover}
                      title={shared.currentBookTitle}
                      author={shared.currentBookAuthor || ''}
                      showShadow={false}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className="min-w-0">
                  <span
                    className="text-[10px] uppercase font-bold block flex items-center gap-1"
                    style={{ color: profileMode === 'shared' ? profileAccent : '#34d399' }}
                  >
                    <span
                      className="w-1.5 h-1.5 rounded-full animate-pulse"
                      style={{ backgroundColor: profileMode === 'shared' ? profileAccent : '#34d399' }}
                    />
                    Leyendo ahora
                  </span>
                  <h4 className="text-xs font-bold text-white truncate mt-0.5">
                    {shared.currentBookTitle}
                  </h4>
                  {shared.currentBookAuthor && (
                    <p className="text-[11px] text-zinc-300 truncate">{shared.currentBookAuthor}</p>
                  )}
                </div>
              </div>
            )}

            {/* Autor Favorito */}
            {(profileMode === 'private' || privacy.showFavoriteAuthor) && shared.favoriteAuthor && (
              <div
                className="glass-panel-subtle rounded-2xl p-3.5 border transition-all"
                style={
                  profileMode === 'shared'
                    ? {
                        borderColor: `${profileAccent}40`,
                        background: `linear-gradient(135deg, ${profileAccent}12, rgba(255,255,255,0.02))`,
                      }
                    : { borderColor: 'rgba(255,255,255,0.1)' }
                }
              >
                <span
                  className="text-[10px] uppercase font-bold block"
                  style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
                >
                  Autor Favorito
                </span>
                <p className="text-xs font-bold text-white truncate mt-1">
                  {shared.favoriteAuthor}
                </p>
              </div>
            )}

            {/* Género Favorito */}
            {(profileMode === 'private' || privacy.showFavoriteGenre) && shared.favoriteGenre && (
              <div
                className="glass-panel-subtle rounded-2xl p-3.5 border transition-all"
                style={
                  profileMode === 'shared'
                    ? {
                        borderColor: `${profileAccent}40`,
                        background: `linear-gradient(135deg, ${profileAccent}12, rgba(255,255,255,0.02))`,
                      }
                    : { borderColor: 'rgba(255,255,255,0.1)' }
                }
              >
                <span
                  className="text-[10px] uppercase font-bold block"
                  style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
                >
                  Género Favorito
                </span>
                <p className="text-xs font-bold text-white truncate mt-1">
                  {shared.favoriteGenre}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- ESTADÍSTICAS DEL PERFIL --- */}
      {/* If shared mode: only render if privacy.showStats is true. In private mode: always render! */}
      {(profileMode === 'private' || privacy.showStats) && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          <div
            className="glass-panel rounded-2xl p-4 border transition-all"
            style={
              profileMode === 'shared'
                ? {
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(180deg, ${profileAccent}14, rgba(255,255,255,0.02))`,
                  }
                : { borderColor: 'rgba(255,255,255,0.1)' }
            }
          >
            <span
              className="text-[11px] uppercase font-semibold block"
              style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
            >
              Total Libros
            </span>
            <span className="text-2xl font-bold text-white tracking-tight tabular-nums block mt-1">
              {stats.totalBooks}
            </span>
            <span className="text-[11px] text-zinc-400">{stats.readingBooks} leyendo ahora</span>
          </div>

          <div
            className="glass-panel rounded-2xl p-4 border transition-all"
            style={
              profileMode === 'shared'
                ? {
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(180deg, ${profileAccent}14, rgba(255,255,255,0.02))`,
                  }
                : { borderColor: 'rgba(255,255,255,0.1)' }
            }
          >
            <span
              className="text-[11px] uppercase font-semibold block"
              style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
            >
              Terminados
            </span>
            <span className="text-2xl font-bold text-white tracking-tight tabular-nums block mt-1">
              {stats.completedBooks}
            </span>
            <span className="text-[11px] text-zinc-400">libros completados</span>
          </div>

          <div
            className="glass-panel rounded-2xl p-4 border transition-all"
            style={
              profileMode === 'shared'
                ? {
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(180deg, ${profileAccent}14, rgba(255,255,255,0.02))`,
                  }
                : { borderColor: 'rgba(255,255,255,0.1)' }
            }
          >
            <span
              className="text-[11px] uppercase font-semibold block"
              style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
            >
              Páginas Leídas
            </span>
            <span className="text-2xl font-bold text-white tracking-tight tabular-nums block mt-1">
              {stats.totalPagesRead}
            </span>
            <span className="text-[11px] text-zinc-400">acumuladas</span>
          </div>

          <div
            className="glass-panel rounded-2xl p-4 border transition-all"
            style={
              profileMode === 'shared'
                ? {
                    borderColor: `${profileAccent}35`,
                    background: `linear-gradient(180deg, ${profileAccent}14, rgba(255,255,255,0.02))`,
                  }
                : { borderColor: 'rgba(255,255,255,0.1)' }
            }
          >
            <span
              className="text-[11px] uppercase font-semibold block"
              style={{ color: profileMode === 'shared' ? profileAccent : '#a1a1aa' }}
            >
              Racha Actual
            </span>
            <span className="text-2xl font-bold text-white tracking-tight tabular-nums block mt-1">
              {stats.currentStreakDays}d
            </span>
            <span className="text-[11px] text-zinc-400">récord: {stats.longestStreakDays}d</span>
          </div>
        </div>
      )}

      {/* --- LOGROS E HITOS PERSONALES --- */}
      {(profileMode === 'private' || privacy.showActivity) && (
        <div
          className="glass-panel rounded-2xl p-5 sm:p-6 border space-y-4 transition-all"
          style={
            profileMode === 'shared'
              ? {
                  borderColor: `${profileAccent}35`,
                  boxShadow: `0 8px 30px 0 ${profileAccent}12`,
                }
              : { borderColor: 'rgba(255,255,255,0.1)' }
          }
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award
                className="w-4 h-4"
                style={{ color: profileMode === 'shared' ? profileAccent : '#d4d4d8' }}
              />
              <h3
                className="text-sm font-bold uppercase tracking-wider text-white"
                style={{ color: profileMode === 'shared' ? profileAccent : undefined }}
              >
                Logros e Hitos Personales
              </h3>
            </div>
            <span className="text-xs text-zinc-400">
              {milestones.filter((m) => m.achieved).length} de {milestones.length} completados
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {milestones.map((m) => (
              <div
                key={m.title}
                className={`p-3.5 rounded-2xl border flex items-center gap-3 transition-all ${
                  m.achieved
                    ? profileMode === 'shared'
                      ? 'text-white'
                      : 'bg-white/[0.08] border-white/20 text-white'
                    : 'bg-white/[0.02] border-white/[0.05] opacity-50 text-zinc-400'
                }`}
                style={
                  m.achieved && profileMode === 'shared'
                    ? {
                        borderColor: `${profileAccent}45`,
                        background: `linear-gradient(135deg, ${profileAccent}18, rgba(255,255,255,0.02))`,
                      }
                    : undefined
                }
              >
                <div className="w-10 h-10 rounded-xl bg-white/[0.05] flex items-center justify-center text-xl shrink-0">
                  {m.icon}
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs font-bold truncate">{m.title}</h4>
                  <p className="text-[10px] text-zinc-400 truncate">{m.desc}</p>
                  {m.achieved && (
                    <span className="text-[9px] text-zinc-300 font-semibold block mt-0.5">
                      ¡Completado!
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- METAS ESTABLECIDAS (En modo privado) --- */}
      {profileMode === 'private' && (
        <div className="glass-panel rounded-2xl p-5 sm:p-6 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-zinc-300" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Metas Establecidas ({goals.length})
              </h3>
            </div>
          </div>

          <div className="space-y-3">
            {goals.map((goal) => {
              let current = 0;
              if (goal.type === 'books_year') current = stats.completedBooks;
              else if (goal.type === 'pages_month') current = stats.totalPagesRead;
              else if (goal.type === 'days_month') current = stats.activeReadingDaysCount;

              const percent = goal.target > 0 ? Math.min(100, Math.round((current / goal.target) * 100)) : 0;

              return (
                <div key={goal.id} className="space-y-1.5 p-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white/95">{goal.title}</span>
                    <span className="font-mono text-zinc-200 font-bold tabular-nums">
                      {current} / {goal.target} ({percent}%)
                    </span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-white/[0.08] overflow-hidden">
                    <div className="h-full bg-white rounded-full" style={{ width: `${percent}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Customizer Modal */}
      <SharedProfileModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        user={user}
        books={books}
        onSaveUserProfile={onUpdateUser}
      />
    </div>
  );
};
