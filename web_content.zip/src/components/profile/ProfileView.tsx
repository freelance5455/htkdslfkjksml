import React, { useState, useEffect } from 'react';
import { User, Post } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import {
  MapPin, ShieldCheck, UserCheck, UserPlus,
  MessageSquare, Edit3, Grid, Image as ImageIcon,
  Video, Bookmark, ShieldAlert
} from 'lucide-react';
import { PostCard } from '../feed/PostCard';
import { EditProfileModal } from './EditProfileModal';

interface ProfileViewProps {
  userId?: string;
  onStartChat: (userId: string) => void;
  onHashtagClick: (tag: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  userId,
  onStartChat,
  onHashtagClick
}) => {
  const { currentUser } = useAuth();
  const targetId = userId || currentUser?.id;

  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [savedPosts, setSavedPosts] = useState<Post[]>([]);
  const [authorsMap, setAuthorsMap] = useState<Map<string, User>>(new Map());
  const [tab, setTab] = useState<'posts' | 'photos' | 'videos' | 'saved'>('posts');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const isMe = currentUser?.id === targetId;

  const loadProfile = async () => {
    if (!targetId) return;
    try {
      setIsLoading(true);
      const res = await api.getUserProfile(targetId);
      setProfileUser(res.user);

      // Load all authors
      const allUsers = await api.searchUsers();
      const map = new Map<string, User>();
      for (const u of allUsers.users || []) map.set(u.id, u);
      setAuthorsMap(map);

      // Load user posts
      const postsRes = await api.getPosts({ authorId: targetId });
      setPosts(postsRes.posts || []);

      // If isMe, load saved posts
      if (isMe) {
        const savedRes = await api.getPosts({ savedByUserId: currentUser?.id });
        setSavedPosts(savedRes.posts || []);
      }
    } catch (err) {
      console.error('Erro ao carregar perfil:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, [targetId]);

  if (isLoading) {
    return <div className="p-12 text-center text-slate-500 text-xs">A carregar perfil...</div>;
  }

  if (!profileUser) {
    return <div className="p-12 text-center text-slate-500 text-xs">Perfil não encontrado.</div>;
  }

  const isFriend = currentUser ? currentUser.friends.includes(profileUser.id) : false;
  const isFollowing = currentUser ? currentUser.following.includes(profileUser.id) : false;

  const photos = posts.filter(p => p.mediaUrl && p.mediaType === 'image');
  const videos = posts.filter(p => p.mediaUrl && p.mediaType === 'video');

  const handleFriendAction = async () => {
    if (!currentUser) return;
    try {
      if (isFriend) {
        await api.removeFriend(currentUser.id, profileUser.id);
      } else {
        await api.sendFriendRequest(currentUser.id, profileUser.id);
        alert('Pedido de amizade enviado!');
      }
      loadProfile();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleFollowAction = async () => {
    if (!currentUser) return;
    try {
      await api.toggleFollow(currentUser.id, profileUser.id);
      loadProfile();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">

      {/* Profile Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-sm">

        {/* Cover */}
        <div className="relative h-48 sm:h-64 w-full bg-slate-950">
          <img
            src={profileUser.coverImage || '/src/assets/images/luanda_skyline_banner_1793388059121.jpg'}
            alt="Capa"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
        </div>

        {/* Info & Avatar */}
        <div className="p-6 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-16 sm:-mt-20 mb-4">
            <div className="flex items-end gap-4">
              <div className="relative">
                <img
                  src={profileUser.avatar}
                  alt={profileUser.name}
                  className="w-28 h-28 sm:w-32 sm:h-32 rounded-full object-cover ring-4 ring-slate-900 bg-slate-800 shadow-2xl"
                />
                {profileUser.verified && (
                  <span title="Conta Verificada 🇦🇴" className="absolute bottom-1 right-1">
                    <ShieldCheck className="w-6 h-6 text-amber-400 fill-amber-400/20" />
                  </span>
                )}
              </div>

              <div className="mb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-bold text-white font-display leading-tight">
                    {profileUser.name}
                  </h1>
                </div>
                <p className="text-xs text-slate-400 font-mono">@{profileUser.username}</p>
                <p className="text-xs text-amber-400 font-medium flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{profileUser.province}, Angola</span>
                </p>
              </div>
            </div>

            {/* Profile Action Buttons */}
            <div className="flex items-center gap-2 self-start sm:self-end">
              {isMe ? (
                <button
                  onClick={() => setIsEditModalOpen(true)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Editar Perfil</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={handleFriendAction}
                    className={`px-4 py-2 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors ${isFriend ? 'bg-slate-800 text-slate-200 hover:bg-red-950/40 hover:text-red-400' : 'bg-amber-500 hover:bg-amber-400 text-slate-950'}`}
                  >
                    {isFriend ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Amigos</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Adicionar Amigo</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => onStartChat(profileUser.id)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Mensagem</span>
                  </button>

                  <button
                    onClick={handleFollowAction}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs"
                  >
                    {isFollowing ? 'A Seguir' : 'Seguir'}
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Bio */}
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl whitespace-pre-line">
            {profileUser.bio}
          </p>

          {/* Stats Bar */}
          <div className="flex items-center gap-6 pt-5 mt-5 border-t border-slate-800 text-xs">
            <div>
              <span className="font-extrabold text-white text-sm font-display tabular-nums">
                {profileUser.friendsCount || profileUser.friends.length}
              </span>
              <span className="text-slate-400 ml-1.5">Amigos</span>
            </div>
            <div>
              <span className="font-extrabold text-white text-sm font-display tabular-nums">
                {profileUser.followersCount || profileUser.followers.length}
              </span>
              <span className="text-slate-400 ml-1.5">Seguidores</span>
            </div>
            <div>
              <span className="font-extrabold text-white text-sm font-display tabular-nums">
                {profileUser.followingCount || profileUser.following.length}
              </span>
              <span className="text-slate-400 ml-1.5">A Seguir</span>
            </div>
            <div>
              <span className="font-extrabold text-white text-sm font-display tabular-nums">
                {posts.length}
              </span>
              <span className="text-slate-400 ml-1.5">Publicações</span>
            </div>
          </div>
        </div>

      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 text-xs font-semibold">
        <button
          onClick={() => setTab('posts')}
          className={`py-3 px-4 flex items-center gap-2 border-b-2 transition-colors ${tab === 'posts' ? 'border-amber-400 text-amber-400' : 'border-transparent text-slate-400 hover:text-white'}`}
        >
          <Grid className="w-4 h-4" />
          <span>Publicações ({posts.length})</span>
        </button>

        <button
          onClick={() => setTab('photos')}
          className={`py-3 px-4 flex items-center gap-2 border-b-2 transition-colors ${tab === 'photos' ? 'border-amber-400 text-amber-400' : 'border-transparent text-slate-400 hover:text-white'}`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>Fotos ({photos.length})</span>
        </button>

        <button
          onClick={() => setTab('videos')}
          className={`py-3 px-4 flex items-center gap-2 border-b-2 transition-colors ${tab === 'videos' ? 'border-amber-400 text-amber-400' : 'border-transparent text-slate-400 hover:text-white'}`}
        >
          <Video className="w-4 h-4" />
          <span>Vídeos ({videos.length})</span>
        </button>

        {isMe && (
          <button
            onClick={() => setTab('saved')}
            className={`py-3 px-4 flex items-center gap-2 border-b-2 transition-colors ${tab === 'saved' ? 'border-amber-400 text-amber-400' : 'border-transparent text-slate-400 hover:text-white'}`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Salvos ({savedPosts.length})</span>
          </button>
        )}
      </div>

      {/* Tab Content */}
      {tab === 'posts' && (
        <div className="space-y-4">
          {posts.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs bg-slate-900 border border-slate-800 rounded-2xl">
              Nenhuma publicação partilhada ainda.
            </div>
          ) : (
            posts.map(p => (
              <PostCard
                key={p.id}
                post={p}
                authorsMap={authorsMap}
                onPostUpdated={loadProfile}
                onHashtagClick={onHashtagClick}
              />
            ))
          )}
        </div>
      )}

      {tab === 'photos' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {photos.length === 0 ? (
            <p className="col-span-full p-8 text-center text-slate-500 text-xs">Sem fotos publicadas.</p>
          ) : (
            photos.map(p => (
              <div key={p.id} className="aspect-square bg-slate-950 rounded-2xl overflow-hidden border border-slate-800">
                <img src={p.mediaUrl} alt="Foto" className="w-full h-full object-cover hover:scale-105 transition-transform" />
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'videos' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {videos.length === 0 ? (
            <p className="col-span-full p-8 text-center text-slate-500 text-xs">Sem vídeos publicados.</p>
          ) : (
            videos.map(p => (
              <div key={p.id} className="aspect-video bg-slate-950 rounded-2xl overflow-hidden border border-slate-800">
                <video src={p.mediaUrl} controls className="w-full h-full object-cover" />
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'saved' && (
        <div className="space-y-4">
          {savedPosts.length === 0 ? (
            <p className="p-8 text-center text-slate-500 text-xs bg-slate-900 border border-slate-800 rounded-2xl">
              Ainda não guardou nenhuma publicação.
            </p>
          ) : (
            savedPosts.map(p => (
              <PostCard
                key={p.id}
                post={p}
                authorsMap={authorsMap}
                onPostUpdated={loadProfile}
                onHashtagClick={onHashtagClick}
              />
            ))
          )}
        </div>
      )}

      {/* Edit Modal */}
      <EditProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onProfileUpdated={loadProfile}
      />

    </div>
  );
};
