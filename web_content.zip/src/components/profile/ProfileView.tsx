import React, { useState } from 'react';
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  Calendar, 
  ShieldCheck, 
  Globe, 
  LogOut, 
  CheckCircle2, 
  Sparkles, 
  Info,
  Edit2,
  Check,
  Receipt,
  Smartphone,
  Download,
  Archive
} from 'lucide-react';
import { useApp, isSubhodipUser } from '../../context/AppContext';
import { Language } from '../../i18n/translations';
import { VipPaymentHistoryModal } from '../vip/VipPaymentHistoryModal';
import { ApkInstallModal } from '../pwa/ApkInstallModal';
import { VipBadge } from '../common/VipBadge';
import { GovtLicenseBadge } from '../common/GovtLicenseBadge';
import { GoldMineInvestorProofModal } from '../investment/GoldMineInvestorProofModal';
import { SbiBankVerificationCard } from '../bank/SbiBankVerificationCard';
import { AppLicenceCard } from '../legal/AppLicenceCard';
import { CompanyLegalInfoModal } from '../legal/CompanyLegalInfoModal';
import { AdvancedKycModal } from '../kyc/AdvancedKycModal';

interface ProfileViewProps {
  onOpenGoogleTasks?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onOpenGoogleTasks }) => {
  const { 
    currentUser, 
    membershipPlans, 
    updateUserProfile, 
    logoutUser, 
    isGoogleConnected, 
    loginWithGoogle,
    connectGoogleTasksAuth,
    connectGoogleTester,
    vipPayments,
    language, 
    setLanguage, 
    t 
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isGoldMineProofOpen, setIsGoldMineProofOpen] = useState(false);
  const [isCompanyLegalModalOpen, setIsCompanyLegalModalOpen] = useState(false);
  const [isAdvancedKycModalOpen, setIsAdvancedKycModalOpen] = useState(false);

  const userPaymentsCount = currentUser 
    ? vipPayments.filter(p => p.userId === currentUser.id || p.userEmail.toLowerCase() === currentUser.email.toLowerCase()).length
    : 0;

  const handleConnectGoogle = async () => {
    setIsConnecting(true);
    setConnectError(null);
    try {
      await connectGoogleTasksAuth();
      if (onOpenGoogleTasks) {
        onOpenGoogleTasks();
      }
    } catch (err: any) {
      console.error(err);
      const errStr = String(err?.message || err);
      if (errStr.includes('access_denied') || errStr.includes('403') || errStr.includes('verification')) {
        setConnectError(
          'Google Cloud project is in Testing Mode (Error 403: access_denied). Make sure subhodipgarai7654@gmail.com is added as a Test User in Google Cloud Console OAuth consent screen, or click "One-Click Test Connect" below.'
        );
      } else if (err.code === 'auth/popup-blocked') {
        setConnectError('Popup blocked by browser. Please allow popups and click Connect.');
      } else if (err.code === 'auth/popup-closed-by-user') {
        setConnectError('Sign-in popup closed before authorization was completed.');
      } else {
        setConnectError(err.message || 'Google Tasks connection failed.');
      }
    } finally {
      setIsConnecting(false);
    }
  };

  const handleInstantConnect = () => {
    connectGoogleTester('subhodipgarai7654@gmail.com');
    setConnectError(null);
    if (onOpenGoogleTasks) {
      onOpenGoogleTasks();
    }
  };

  const currentPlan = currentUser
    ? membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0]
    : membershipPlans[0];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({ name, phone });
    setIsEditing(false);
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 animate-in fade-in duration-300 max-w-2xl mx-auto">
      
      {/* Title */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
          <UserIcon className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
          <span>{t('profileTitle')}</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Manage your account profile, settings, and language preferences.
        </p>
      </div>

      {/* User Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-16 h-16 rounded-2xl object-cover ring-2 ring-emerald-500/40"
              />
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white font-black text-2xl flex items-center justify-center shadow-md">
                {currentUser?.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
              </div>
            )}

            <div className="space-y-1.5">
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                  {currentUser?.name || 'Guest User'}
                </h2>
                <VipBadge tier={currentUser?.membershipTier} size="md" />
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${currentPlan.badgeColor}`}>
                  {language === 'bn' ? currentPlan.nameBn : currentPlan.name}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  Code: {currentUser?.referralCode}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 self-start cursor-pointer"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>{isEditing ? t('cancel') : t('edit')}</span>
          </button>
        </div>

        {/* Profile Info / Edit Form */}
        {isEditing ? (
          <form onSubmit={handleSaveProfile} className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3.5 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-sm"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('phone')}
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 555-0199"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-sm"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Check className="w-4 h-4" />
              <span>{t('save')}</span>
            </button>
          </form>
        ) : (
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
            <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
              <Mail className="w-4 h-4 text-slate-400" />
              <span>{currentUser?.email || 'N/A'}</span>
            </div>
            <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>{currentUser?.phone || 'No phone added'}</span>
            </div>
            <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>{t('memberSince')}: {currentUser ? new Date(currentUser.joinedAt).toLocaleDateString() : 'N/A'}</span>
            </div>
            <div className="flex items-center gap-2.5 text-slate-600 dark:text-slate-300">
              <ShieldCheck className="w-4 h-4 text-slate-400" />
              <span className="capitalize">Role: {currentUser?.role || 'User'}</span>
            </div>
          </div>
        )}

      </div>

      {/* VIP Purchases & Payment History Card */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
              <span>VIP Payment History & Purchases</span>
              {userPaymentsCount > 0 && (
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300">
                  {userPaymentsCount} Records
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Track UPI payment receipts and manual verification status
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsHistoryOpen(true)}
          className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs cursor-pointer shadow-xs transition-colors"
        >
          View Purchases
        </button>
      </div>

      {/* KYC & Identity Verification Action Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-teal-950/60 via-slate-900 to-slate-900 border border-teal-500/40 shadow-sm flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5 text-teal-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Aadhaar & PAN KYC Verification</span>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-teal-500/20 text-teal-300 border border-teal-500/30">
                DigiLocker / NSDL
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Verified identity unlocks bullion vault liquidation and unlimited daily withdrawals
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setIsAdvancedKycModalOpen(true)}
          className="px-3.5 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs cursor-pointer shadow-sm transition-all active:scale-95 shrink-0"
        >
          Manage KYC
        </button>
      </div>

      {/* SBI Bank Verification Section */}
      <SbiBankVerificationCard />

      {/* App Licence & Regulatory Accreditation */}
      <AppLicenceCard onOpenCompanyModal={() => setIsCompanyLegalModalOpen(true)} />

      {/* Google Tasks Connection Status */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
              <svg className="w-5 h-5" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
              </svg>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Google Tasks Integration
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isGoogleConnected ? 'Connected & authorized' : 'Not connected'}
              </p>
            </div>
          </div>

          {isGoogleConnected ? (
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{t('verified')}</span>
              </span>
              {onOpenGoogleTasks && (
                <button
                  type="button"
                  onClick={onOpenGoogleTasks}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer shadow-xs transition-colors"
                >
                  Sync Tasks
                </button>
              )}
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleConnectGoogle}
                disabled={isConnecting}
                className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer shadow-xs disabled:opacity-50 flex items-center gap-1.5 transition-all active:scale-95"
              >
                {isConnecting ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Connecting...</span>
                  </>
                ) : (
                  <span>Connect Google</span>
                )}
              </button>

              <button
                type="button"
                onClick={handleInstantConnect}
                title="Bypass Google 403 test mode and connect subhodipgarai386@gmail.com instantly"
                className="px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs cursor-pointer shadow-xs transition-all active:scale-95 flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>One-Click Connect (Subhodip)</span>
              </button>
            </div>
          )}
        </div>

        {connectError && (
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-200 text-xs space-y-2">
            <p className="font-semibold">{connectError}</p>
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleInstantConnect}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer flex items-center gap-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Bypass & Connect subhodipgarai386@gmail.com</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Language Switcher */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              {t('language')}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Bengali & English Support
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setLanguage('en')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              language === 'en'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            English
          </button>
          <button
            onClick={() => setLanguage('bn')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              language === 'bn'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            বাংলা
          </button>
        </div>
      </div>

      {/* Android APK App Installation Card */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-sm flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>Android App (APK)</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                v2.4.0
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Install lightweight native WebAPK (4.2 MB)
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsApkModalOpen(true)}
          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer active:scale-95 transition-all shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download APK</span>
        </button>
      </div>

      {/* Task Pro App Complete Source Code ZIP File Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/60 border border-blue-500/40 shadow-sm flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
            <Archive className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>Task Pro App Complete ZIP File</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-blue-500/20 text-blue-300 font-bold border border-blue-500/30">
                Full Code
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Download complete application source code (.zip)
            </p>
          </div>
        </div>

        <a
          href="/downloads/TaskEarnPro.zip"
          download="TaskEarnPro-App.zip"
          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/20 cursor-pointer active:scale-95 transition-all shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download ZIP</span>
        </a>
      </div>

      {/* Government License & Registration Certificate Card */}
      <GovtLicenseBadge />

      {/* System Integrity & Policy Card */}
      <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
        <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
          <Info className="w-4 h-4 text-emerald-500" />
          <span>{t('termsAndDisclaimer')}</span>
        </div>
        <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-[11px]">
          {t('termsText')}
        </p>
      </div>

      {/* Logout Button */}
      {currentUser && (
        <button
          onClick={logoutUser}
          className="w-full py-3 rounded-2xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 font-bold text-xs flex items-center justify-center gap-2 hover:bg-rose-100 dark:hover:bg-rose-900/40 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>{t('logout')}</span>
        </button>
      )}

      {/* Payment History Modal */}
      <VipPaymentHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
      />

      {/* Android APK Modal */}
      <ApkInstallModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Gold Mine Investor Proof & Certificate Modal */}
      <GoldMineInvestorProofModal
        isOpen={isGoldMineProofOpen}
        onClose={() => setIsGoldMineProofOpen(false)}
      />

      {/* Company Legal Information Modal */}
      <CompanyLegalInfoModal
        isOpen={isCompanyLegalModalOpen}
        onClose={() => setIsCompanyLegalModalOpen(false)}
      />

      {/* Advanced KYC Modal */}
      <AdvancedKycModal
        isOpen={isAdvancedKycModalOpen}
        onClose={() => setIsAdvancedKycModalOpen(false)}
      />

    </div>
  );
};
