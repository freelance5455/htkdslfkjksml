import React, { useState, useRef } from 'react';
import {
  Camera,
  AtSign,
  User,
  FileText,
  Calendar,
  LogOut,
  Check,
  Loader2,
  Copy,
  ExternalLink,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { uploadAvatar } from '../../services/storageService';
import { ConfirmationDialog } from '../common/ConfirmationDialog';

export const ProfileView: React.FC = () => {
  const { user, profile, updateProfile, logout } = useAuth();

  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copiedUsername, setCopiedUsername] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!profile || !user) return null;

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingAvatar(true);
    try {
      const publicUrl = await uploadAvatar(user.id, file);
      await updateProfile({ avatar_url: publicUrl });
    } catch (err: any) {
      alert(err.message || 'Avatar upload failed.');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateProfile({
        display_name: displayName.trim(),
        bio: bio.trim(),
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  const copyUsername = () => {
    navigator.clipboard.writeText(`@${profile.username}`);
    setCopiedUsername(true);
    setTimeout(() => setCopiedUsername(false), 2000);
  };

  return (
    <div id="profile-view-container" className="h-full flex flex-col bg-neutral-900 text-white select-none overflow-y-auto">
      {/* Top Header */}
      <div className="p-4 border-b border-neutral-800 bg-neutral-950/40 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">My Profile</h2>
          <p className="text-xs text-neutral-400">Manage your identity and bio</p>
        </div>
        <button
          id="btn-profile-logout"
          onClick={() => setShowLogoutConfirm(true)}
          className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-red-500/20 text-neutral-300 hover:text-red-400 text-xs font-semibold flex items-center space-x-1.5 transition-colors"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Sign Out</span>
        </button>
      </div>

      <div className="p-6 max-w-lg mx-auto w-full space-y-6">
        {/* Avatar Section */}
        <div className="flex flex-col items-center space-y-3">
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            className="hidden"
            onChange={handleAvatarChange}
          />

          <div className="relative group">
            <div className="w-24 h-24 rounded-full bg-neutral-800 border-2 border-neutral-700 overflow-hidden flex items-center justify-center text-3xl font-bold text-neutral-200 shadow-xl">
              {uploadingAvatar ? (
                <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
              ) : profile.avatar_url ? (
                <img src={profile.avatar_url} alt={profile.display_name} className="w-full h-full object-cover" />
              ) : (
                profile.display_name.charAt(0).toUpperCase()
              )}
            </div>

            <button
              id="btn-upload-avatar"
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-0 right-0 p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-lg transition-transform active:scale-95"
              title="Upload Avatar"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          <div className="text-center">
            <h3 className="text-base font-bold text-white">{profile.display_name}</h3>
            <button
              id="btn-copy-username-pill"
              onClick={copyUsername}
              className="mt-1 px-3 py-1 rounded-full bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-xs text-neutral-400 hover:text-white flex items-center space-x-1.5 mx-auto transition-colors"
            >
              <AtSign className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-mono">{profile.username}</span>
              {copiedUsername ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            </button>
          </div>
        </div>

        {/* Edit Form */}
        <form onSubmit={handleSaveProfile} className="space-y-4 bg-neutral-950/60 p-5 rounded-2xl border border-neutral-800">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Username
            </label>
            <div className="relative">
              <input
                type="text"
                disabled
                value={`@${profile.username}`}
                className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-neutral-400 font-mono cursor-not-allowed"
              />
            </div>
            <p className="text-[11px] text-neutral-500 mt-1">Username is unique and case-insensitive</p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Display Name
            </label>
            <div className="relative">
              <input
                id="input-edit-display-name"
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Bio / Status
            </label>
            <textarea
              id="input-edit-bio"
              rows={3}
              placeholder="Tell your friends what you're up to..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 resize-none"
            />
          </div>

          {savedSuccess && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-400 flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>Profile changes saved successfully!</span>
            </div>
          )}

          <button
            id="btn-save-profile"
            type="submit"
            disabled={saving}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-2"
          >
            {saving ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Saving...</span>
              </>
            ) : (
              <span>Save Changes</span>
            )}
          </button>
        </form>

        {/* Account Details */}
        <div className="p-4 bg-neutral-950/40 border border-neutral-800/80 rounded-2xl space-y-2 text-xs text-neutral-400">
          <div className="flex items-center justify-between">
            <span className="flex items-center space-x-1.5">
              <Calendar className="w-3.5 h-3.5 text-neutral-500" />
              <span>Member Since</span>
            </span>
            <span>{new Date(profile.created_at).toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' })}</span>
          </div>
        </div>
      </div>

      {/* Logout Confirmation */}
      <ConfirmationDialog
        isOpen={showLogoutConfirm}
        title="Sign Out of Nexa"
        message="Are you sure you want to sign out? You will need your username and password to log back in."
        confirmLabel="Sign Out"
        onConfirm={async () => {
          setShowLogoutConfirm(false);
          await logout();
        }}
        onCancel={() => setShowLogoutConfirm(false)}
      />
    </div>
  );
};
