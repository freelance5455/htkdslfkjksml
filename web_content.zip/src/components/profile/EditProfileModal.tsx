import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api, ANGOLA_PROVINCES } from '../../services/api';
import { X, Image as ImageIcon, Camera, RefreshCw } from 'lucide-react';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProfileUpdated: () => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  onProfileUpdated
}) => {
  const { currentUser, updateCurrentUserProfile } = useAuth();
  const [name, setName] = useState(currentUser?.name || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [province, setProvince] = useState(currentUser?.province || 'Luanda');
  const [avatar, setAvatar] = useState(currentUser?.avatar || '');
  const [coverImage, setCoverImage] = useState(currentUser?.coverImage || '');
  const [isPrivate, setIsPrivate] = useState(currentUser?.isPrivate || false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !currentUser) return null;

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploadRes = await api.uploadFile(base64, file.name);
        setAvatar(uploadRes.url);
      } catch (err: any) {
        setErrorMsg('Erro no envio do avatar: ' + err.message);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const uploadRes = await api.uploadFile(base64, file.name);
        setCoverImage(uploadRes.url);
      } catch (err: any) {
        setErrorMsg('Erro no envio da capa: ' + err.message);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      setIsSubmitting(true);
      setErrorMsg(null);
      await updateCurrentUserProfile({
        name: name.trim(),
        bio: bio.trim(),
        province,
        avatar,
        coverImage,
        isPrivate
      });

      onProfileUpdated();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-slate-100 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">

        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h3 className="font-bold text-base text-white font-display">Editar Perfil</h3>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {errorMsg && (
            <p className="text-xs text-red-400 bg-red-950/40 p-2.5 rounded-xl border border-red-800/60">{errorMsg}</p>
          )}

          {/* Cover & Avatar edit preview */}
          <div className="relative">
            <div className="relative h-28 w-full bg-slate-950 rounded-xl overflow-hidden border border-slate-800">
              <img src={coverImage} alt="Capa" className="w-full h-full object-cover" />
              <label className="absolute bottom-2 right-2 p-1.5 bg-black/70 hover:bg-black rounded-lg text-white text-xs flex items-center gap-1 cursor-pointer">
                <Camera className="w-3.5 h-3.5" />
                <span>Trocar Capa</span>
                <input type="file" accept="image/*" onChange={handleCoverUpload} className="hidden" />
              </label>
            </div>

            <div className="absolute -bottom-6 left-4 flex items-end">
              <div className="relative">
                <img
                  src={avatar}
                  alt={name}
                  className="w-16 h-16 rounded-full object-cover ring-4 ring-slate-900 bg-slate-800"
                />
                <label className="absolute bottom-0 right-0 p-1 bg-amber-500 rounded-full text-slate-950 cursor-pointer shadow-md">
                  <Camera className="w-3.5 h-3.5" />
                  <input type="file" accept="image/*" onChange={handleAvatarUpload} className="hidden" />
                </label>
              </div>
            </div>
          </div>

          <div className="pt-6">
            <label className="block text-xs font-medium text-slate-300 mb-1">Nome Completo</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Província</label>
            <select
              value={province}
              onChange={(e) => setProvince(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            >
              {ANGOLA_PROVINCES.filter(p => p !== 'Todas').map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Biografia</label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500 resize-none"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="isPrivateCheck"
              checked={isPrivate}
              onChange={(e) => setIsPrivate(e.target.checked)}
              className="rounded bg-slate-950 border-slate-800 text-amber-500 focus:ring-0"
            />
            <label htmlFor="isPrivateCheck" className="text-xs text-slate-300 cursor-pointer">
              Conta Privada (apenas amigos podem ver fotos e publicações)
            </label>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full h-11 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all active:scale-[0.98] mt-2"
          >
            {isSubmitting ? (
              <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
            ) : (
              <span>Guardar Alterações</span>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
