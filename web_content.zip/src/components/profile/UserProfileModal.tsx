import React from 'react';
import { X, Phone, Video, MessageSquare, Ban, AtSign, Calendar } from 'lucide-react';
import { Profile } from '../../types';
import { usePresence } from '../../contexts/PresenceContext';
import { useCall } from '../../contexts/CallContext';

type UserProfileModalProps = {
  user: Profile | null;
  onClose: () => void;
  onStartChat?: () => void;
  onBlockUser?: () => void;
};

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  user,
  onClose,
  onStartChat,
  onBlockUser,
}) => {
  const { isUserOnline } = usePresence();
  const { startCall } = useCall();

  if (!user) return null;
  const online = isUserOnline(user.id);

  return (
    <div
      id="user-profile-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in"
      onClick={onClose}
    >
      <div
        id="user-profile-dialog"
        className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-5 text-white animate-in zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">Contact Info</span>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Avatar & Names */}
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-neutral-800 border-2 border-neutral-700 overflow-hidden flex items-center justify-center text-2xl font-bold text-neutral-200">
              {user.avatar_url ? (
                <img src={user.avatar_url} alt={user.display_name} className="w-full h-full object-cover" />
              ) : (
                user.display_name.charAt(0).toUpperCase()
              )}
            </div>
            {online && (
              <div
                className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-emerald-500 border-2 border-neutral-900"
                title="Online"
              />
            )}
          </div>

          <div>
            <h3 className="text-base font-bold text-white">{user.display_name}</h3>
            <p className="text-xs text-neutral-400 flex items-center justify-center space-x-1 mt-0.5">
              <AtSign className="w-3 h-3 text-emerald-400" />
              <span className="font-mono">{user.username}</span>
            </p>
          </div>
        </div>

        {/* Bio */}
        {user.bio ? (
          <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800 text-xs text-neutral-300">
            <p className="text-[10px] text-neutral-500 uppercase tracking-wider mb-1 font-semibold">About</p>
            <p className="whitespace-pre-wrap">{user.bio}</p>
          </div>
        ) : null}

        {/* Quick Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => {
              onClose();
              startCall(user, 'voice');
            }}
            className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold flex items-center justify-center space-x-2 transition-colors"
          >
            <Phone className="w-4 h-4 text-emerald-400" />
            <span>Voice Call</span>
          </button>

          <button
            onClick={() => {
              onClose();
              startCall(user, 'video');
            }}
            className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold flex items-center justify-center space-x-2 transition-colors"
          >
            <Video className="w-4 h-4 text-emerald-400" />
            <span>Video Call</span>
          </button>
        </div>

        {onBlockUser && (
          <button
            onClick={() => {
              onClose();
              onBlockUser();
            }}
            className="w-full py-2 rounded-xl text-xs text-red-400 hover:bg-red-500/10 transition-colors flex items-center justify-center space-x-1.5"
          >
            <Ban className="w-3.5 h-3.5" />
            <span>Block User</span>
          </button>
        )}
      </div>
    </div>
  );
};
