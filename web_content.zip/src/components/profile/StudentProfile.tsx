import React, { useState } from 'react';
import { HunterProfile, Language } from '../../types';
import { getRankDetails } from '../../utils/storage';
import { soundManager } from '../../utils/audio';
import { 
  User, 
  Settings, 
  Award, 
  Volume2, 
  VolumeX, 
  Download, 
  Upload, 
  Globe, 
  ShieldCheck, 
  Flame, 
  Heart, 
  Sparkles,
  Info,
  CheckCircle,
  HelpCircle
} from 'lucide-react';

interface Props {
  profile: HunterProfile;
  language: Language;
  soundEnabled: boolean;
  onUpdateProfile: (updated: HunterProfile) => void;
  onChangeLanguage: (lang: Language) => void;
  onToggleSound: () => void;
}

export const StudentProfileView: React.FC<Props> = ({
  profile,
  language,
  soundEnabled,
  onUpdateProfile,
  onChangeLanguage,
  onToggleSound
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'settings' | 'about'>('profile');
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(profile.name);
  const [backupNotice, setBackupNotice] = useState<string | null>(null);

  const rankInfo = getRankDetails(profile.rank);

  const handleSaveName = () => {
    if (nameInput.trim()) {
      onUpdateProfile({ ...profile, name: nameInput.trim() });
      setIsEditingName(false);
      soundManager.playTick(soundEnabled);
    }
  };

  // Export JSON backup
  const handleExportBackup = () => {
    soundManager.playTick(soundEnabled);
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(profile, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `shadow_radiology_backup_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setBackupNotice('تم تصدير ملف النسخة الاحتياطية بنجاح!');
    setTimeout(() => setBackupNotice(null), 3500);
  };

  // Import JSON backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], 'UTF-8');
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed && typeof parsed === 'object') {
            onUpdateProfile({ ...profile, ...parsed });
            soundManager.playSuccess(soundEnabled);
            setBackupNotice('تمت استعادة تقدمك وحسابك بنجاح!');
            setTimeout(() => setBackupNotice(null), 3500);
          }
        } catch {
          setBackupNotice('خطأ: الملف المحدد غير صالح');
        }
      };
    }
  };

  return (
    <div className="flex flex-col gap-6 text-right">
      {/* Profile Header Tabs */}
      <div className="flex items-center justify-between bg-slate-950/80 p-2 rounded-2xl border border-purple-900/40">
        <div className="flex items-center gap-1.5 text-xs">
          <button
            onClick={() => { setActiveTab('profile'); soundManager.playTick(soundEnabled); }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition-all ${
              activeTab === 'profile' ? 'bg-purple-600 text-white shadow-neon-purple' : 'text-slate-400 hover:text-white'
            }`}
          >
            <User className="w-4 h-4" />
            <span>بطاقة الصياد</span>
          </button>
          <button
            onClick={() => { setActiveTab('settings'); soundManager.playTick(soundEnabled); }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition-all ${
              activeTab === 'settings' ? 'bg-purple-600 text-white shadow-neon-purple' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>الإعدادات والنسخ</span>
          </button>
          <button
            onClick={() => { setActiveTab('about'); soundManager.playTick(soundEnabled); }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold transition-all ${
              activeTab === 'about' ? 'bg-purple-600 text-white shadow-neon-purple' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Info className="w-4 h-4" />
            <span>عن التطبيق والمصادر</span>
          </button>
        </div>

        <span className="text-[11px] font-mono text-purple-400 px-3">
          PARAMEDICAL DZ
        </span>
      </div>

      {backupNotice && (
        <div className="p-3 bg-purple-950/80 border border-purple-500 rounded-xl text-xs text-purple-200 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{backupNotice}</span>
        </div>
      )}

      {activeTab === 'profile' && (
        <>
          {/* Main Hunter Status Card (Solo Leveling Aesthetic) */}
          <div className="relative overflow-hidden bg-gradient-to-br from-purple-950/90 via-slate-950 to-slate-900 p-6 rounded-3xl border-2 border-purple-500/50 shadow-neon-purple">
            {/* Background Cyber Runes */}
            <div className="absolute top-0 left-0 w-full h-full bg-grid-runes opacity-20 pointer-events-none" />

            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                {/* Large Hunter Rank Crest */}
                <div className={`w-20 h-20 rounded-2xl flex items-center justify-center font-black text-3xl font-tech border-2 shadow-2xl ${rankInfo.color} ${rankInfo.bg}`}>
                  {profile.rank}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    {isEditingName ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={nameInput}
                          onChange={(e) => setNameInput(e.target.value)}
                          className="bg-black/60 px-3 py-1 rounded-lg border border-purple-400 text-sm text-white"
                        />
                        <button
                          onClick={handleSaveName}
                          className="bg-purple-600 px-2.5 py-1 rounded-lg text-xs text-white"
                        >
                          حفظ
                        </button>
                      </div>
                    ) : (
                      <>
                        <h2 className="text-xl md:text-2xl font-black text-slate-100">
                          {profile.name}
                        </h2>
                        <button
                          onClick={() => setIsEditingName(true)}
                          className="text-[11px] text-purple-400 hover:text-purple-300 underline"
                        >
                          تعديل
                        </button>
                      </>
                    )}
                  </div>

                  <p className="text-xs text-purple-300 font-semibold mt-0.5">
                    {language === 'ar' ? rankInfo.nameAr : rankInfo.nameFr}
                  </p>
                  <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                    ID: DZ-{profile.level.toString().padStart(3, '0')}-MIM
                  </p>
                </div>
              </div>

              {/* Level & XP Gauge */}
              <div className="w-full md:w-64 bg-black/60 p-4 rounded-2xl border border-purple-900/50">
                <div className="flex justify-between text-xs font-bold mb-1.5">
                  <span className="text-purple-300">المستوى {profile.level}</span>
                  <span className="text-slate-300 font-mono">
                    {profile.currentXp} / {profile.nextLevelXp} XP
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-purple-900">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 via-rose-500 to-amber-400 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (profile.currentXp / profile.nextLevelXp) * 100)}%` }}
                  />
                </div>
                <div className="text-[10px] text-slate-400 mt-1.5 flex justify-between">
                  <span>الرتبة القادمة بعد المستوى {profile.level < 3 ? 3 : profile.level < 7 ? 7 : profile.level < 12 ? 12 : profile.level < 20 ? 20 : 30}</span>
                  <span className="text-yellow-400 font-mono font-bold">{profile.coins} عملة</span>
                </div>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="relative z-10 grid grid-cols-2 md:grid-cols-4 gap-3 mt-6 pt-6 border-t border-purple-900/40 text-xs">
              <div className="bg-slate-900/60 p-3 rounded-xl border border-purple-900/30">
                <span className="text-slate-400 block text-[10px]">شعلة الالتزام اليومي:</span>
                <span className="text-amber-400 font-black text-sm flex items-center gap-1 font-mono">
                  <Flame className="w-4 h-4 fill-current" /> {profile.streak} أيام متواصلة
                </span>
              </div>

              <div className="bg-slate-900/60 p-3 rounded-xl border border-purple-900/30">
                <span className="text-slate-400 block text-[10px]">الدروس المنجزة:</span>
                <span className="text-purple-300 font-black text-sm font-mono">
                  {profile.completedLessonIds.length} وحدات تدريبية
                </span>
              </div>

              <div className="bg-slate-900/60 p-3 rounded-xl border border-purple-900/30">
                <span className="text-slate-400 block text-[10px]">المصطلحات المحفوظة:</span>
                <span className="text-emerald-400 font-black text-sm font-mono">
                  {profile.favoriteTermIds.length} مصطلحات
                </span>
              </div>

              <div className="bg-slate-900/60 p-3 rounded-xl border border-purple-900/30">
                <span className="text-slate-400 block text-[10px]">كلمات قيد المراجعة:</span>
                <span className="text-rose-400 font-black text-sm font-mono">
                  {profile.difficultTermIds.length} مصطلحات
                </span>
              </div>
            </div>
          </div>

          {/* Hunter Achievements Gallery */}
          <div className="bg-slate-950/80 p-5 rounded-2xl border border-purple-900/40">
            <h3 className="text-sm font-extrabold text-slate-100 mb-3 flex items-center gap-2">
              <Award className="w-4 h-4 text-yellow-400" />
              <span>أوسمة وإنجازات الصياد (Hunter Badges)</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {profile.achievements.map((ach) => (
                <div
                  key={ach.id}
                  className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
                    ach.unlocked
                      ? 'bg-purple-950/40 border-purple-500/60 text-slate-100 shadow-neon-purple'
                      : 'bg-black/40 border-slate-900 text-slate-500 opacity-60'
                  }`}
                >
                  <div className={`p-2 rounded-lg ${ach.unlocked ? 'bg-purple-600 text-white' : 'bg-slate-900 text-slate-600'}`}>
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold leading-tight">
                      {language === 'ar' ? ach.titleAr : ach.titleFr}
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                      {ach.descAr}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {activeTab === 'settings' && (
        /* Settings View */
        <div className="bg-slate-950/80 p-6 rounded-2xl border border-purple-900/40 space-y-6">
          {/* Language Selection */}
          <div className="border-b border-purple-900/30 pb-4">
            <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Globe className="w-4 h-4" />
              <span>لغة التطبيق الأساسية</span>
            </h4>
            <div className="grid grid-cols-3 gap-3">
              {[
                { code: 'ar', label: 'العربية' },
                { code: 'fr', label: 'Français' },
                { code: 'en', label: 'English' }
              ].map((l) => (
                <button
                  key={l.code}
                  onClick={() => onChangeLanguage(l.code as Language)}
                  className={`py-2.5 rounded-xl font-bold text-xs border transition-all ${
                    language === l.code
                      ? 'bg-purple-600 text-white border-purple-400 shadow-neon-purple'
                      : 'bg-black/40 border-purple-900 text-slate-300 hover:bg-slate-900'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sound & Audio Toggles */}
          <div className="border-b border-purple-900/30 pb-4 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-slate-100">
                المؤثرات الصوتية للألعاب والأنمي (Sound FX)
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                أصوات ضربات السيوف، الترقية، والألحان التفاعلية
              </p>
            </div>
            <button
              onClick={onToggleSound}
              className={`p-2.5 rounded-xl border transition-all ${
                soundEnabled
                  ? 'bg-purple-600 text-white border-purple-400'
                  : 'bg-slate-900 text-slate-500 border-slate-800'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>

          {/* Data Backup & Restore */}
          <div>
            <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider mb-2">
              النسخ الاحتياطي والمزامنة المحلية
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              يمكنك تصدير تقدمك ونقاطك في ملف JSON لحفظه على هاتفك واسترجاعه في أي وقت دون الحاجة لخادم خارجي.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleExportBackup}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-purple-700/80 hover:bg-purple-600 text-white text-xs font-bold rounded-xl transition-all shadow-md active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>تصدير نسخة احتياطية (Export Backup)</span>
              </button>

              <label className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-purple-300 text-xs font-bold rounded-xl border border-purple-800/50 cursor-pointer transition-all active:scale-95">
                <Upload className="w-4 h-4" />
                <span>استيراد واستعادة (Import File)</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportBackup}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'about' && (
        /* About & Scientific Sources View */
        <div className="bg-slate-950/80 p-6 rounded-2xl border border-purple-900/40 space-y-4 leading-relaxed text-xs text-slate-300">
          <div className="border-b border-purple-900/30 pb-3">
            <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-purple-400" />
              <span>عن تطبيق Shadow Radiology – Paramedical DZ</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              تطبيق أندرويد تعليمي متكامل صُمم خصيصاً لطلبة الشبه طبي وتخصص الأشعة (Manipulateurs en Imagerie Médicale - MIM) في الجزائر.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-purple-300 text-xs">المراجع والمصادر العلمية المعتمدة:</h4>
            <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300">
              <li>البرنامج البيداغوجي الرسمي للمعاهد الوطنية للتكوين العالي شبه الطبي في الجزائر (INFSPM).</li>
              <li>المرسوم التنفيذي الجزائري للوقاية من الإشعاعات المؤينة والسلامة الاستشفائية.</li>
              <li>توصيات اللجنة الدولية للوقاية الإشعاعية (CIPR / ICRP) ومبدأ ALARA.</li>
              <li>دليل وضعيات الأشعة السينية (Manuel des Incidences Radiologiques de Bontrager).</li>
              <li>تصنيف الكلية الأمريكية للأشعة (ACR BI-RADS) في تصوير الثدي.</li>
            </ul>
          </div>

          <div className="bg-black/50 p-4 rounded-xl border border-purple-900/40 text-[11px]">
            <h4 className="font-bold text-amber-300 mb-1">إخلاء مسؤولية طبي:</h4>
            <p className="text-slate-400 leading-relaxed">
              المعلومات الواردة في هذا التطبيق هي لغرض التعليم والتدريب الطلابي فقط، ولا يجوز الاعتماد عليها كمرجع طبي وحيد لتشخيص الحالات السريرية الحقيقية أو إعطاء قرارات طبية.
            </p>
          </div>
        </div>
      )}

      {/* Mandatory Credit in Footer */}
      <div className="mt-8 pt-4 border-t border-purple-900/40 text-center text-xs text-slate-400">
        <p className="font-semibold text-slate-300">
          Shadow Radiology – Paramedical DZ
        </p>
        <p className="text-[11px] text-purple-400 font-mono mt-0.5 font-bold">
          Développé avec fierté par Rachid Boulghiti
        </p>
        <p className="text-[10px] text-slate-500 mt-1">
          جميع الحقوق محفوظة © 2026 – مخصص لطلبة الشبه طبي في الجزائر
        </p>
      </div>
    </div>
  );
};
