import React, { useState } from 'react';
import {
  UserProfile,
  SharedProfileData,
  SharedProfilePrivacy,
  SharedProfileTheme,
  Book,
} from '../../types';
import {
  X,
  Palette,
  Eye,
  Lock,
  Sparkles,
  Image as ImageIcon,
  Check,
  BookOpen,
  User,
  Sliders,
} from 'lucide-react';

interface SharedProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  books: Book[];
  onSaveUserProfile: (updatedUser: UserProfile) => void;
}

const PRESET_BANNER_GRADIENTS = [
  { id: 'purple', label: 'Púrpura Cósmico', value: 'linear-gradient(135deg, #4c1d95 0%, #1e1b4b 100%)' },
  { id: 'cyan', label: 'Cian Océano', value: 'linear-gradient(135deg, #0c4a6e 0%, #064e3b 100%)' },
  { id: 'amber', label: 'Ámbar Cálido', value: 'linear-gradient(135deg, #78350f 0%, #450a0a 100%)' },
  { id: 'emerald', label: 'Bosque Esmeralda', value: 'linear-gradient(135deg, #064e3b 0%, #022c22 100%)' },
  { id: 'rose', label: 'Atardecer Rosa', value: 'linear-gradient(135deg, #831843 0%, #312e81 100%)' },
];

const PRESET_THEME_COLORS = [
  '#8b5cf6', // Purple
  '#06b6d4', // Cyan
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#3b82f6', // Blue
  '#ef4444', // Red
  '#ffffff', // Minimal White
];

export const SharedProfileModal: React.FC<SharedProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  books,
  onSaveUserProfile,
}) => {
  if (!isOpen) return null;

  // Initialize or fallback
  const initialShared: SharedProfileData = user.sharedProfile || {
    favoriteBookTitle: books.find((b) => b.favorite)?.title || books[0]?.title,
    favoriteBookAuthor: books.find((b) => b.favorite)?.author || books[0]?.author,
    favoriteBookCover: books.find((b) => b.favorite)?.coverUrl || books[0]?.coverUrl,
    currentBookTitle: books.find((b) => b.status === 'LEYENDO')?.title,
    currentBookAuthor: books.find((b) => b.status === 'LEYENDO')?.author,
    currentBookCover: books.find((b) => b.status === 'LEYENDO')?.coverUrl,
    favoriteAuthor: 'Frank Herbert',
    favoriteGenre: 'Ciencia Ficción',
    theme: {
      primaryColor: '#8b5cf6',
      accentColor: '#ec4899',
      avatarFrameColor: '#a855f7',
      avatarFrameShape: 'glow',
      bannerType: 'preset',
      bannerValue: 'linear-gradient(135deg, #4c1d95 0%, #1e1b4b 100%)',
      bannerBlur: 16,
    },
    privacy: {
      showBooks: true,
      showFavoriteBook: true,
      showCurrentBook: true,
      showFavoriteAuthor: true,
      showFavoriteGenre: true,
      showStats: true,
      showActivity: true,
      showCollections: true,
      showQuotes: true,
    },
  };

  const [activeTab, setActiveTab] = useState<'visual' | 'info' | 'privacy'>('visual');
  const [theme, setTheme] = useState<SharedProfileTheme>(initialShared.theme);
  const [privacy, setPrivacy] = useState<SharedProfilePrivacy>(initialShared.privacy);
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl || '');

  // Literary info fields
  const [favoriteBookTitle, setFavoriteBookTitle] = useState(initialShared.favoriteBookTitle || '');
  const [favoriteBookAuthor, setFavoriteBookAuthor] = useState(initialShared.favoriteBookAuthor || '');
  const [favoriteBookCover, setFavoriteBookCover] = useState(initialShared.favoriteBookCover || '');

  const [currentBookTitle, setCurrentBookTitle] = useState(initialShared.currentBookTitle || '');
  const [currentBookAuthor, setCurrentBookAuthor] = useState(initialShared.currentBookAuthor || '');
  const [currentBookCover, setCurrentBookCover] = useState(initialShared.currentBookCover || '');

  const [favoriteAuthor, setFavoriteAuthor] = useState(initialShared.favoriteAuthor || '');
  const [favoriteGenre, setFavoriteGenre] = useState(initialShared.favoriteGenre || '');

  // Custom banner image URL
  const [customBannerUrl, setCustomBannerUrl] = useState(
    theme.bannerType === 'image' ? theme.bannerValue : ''
  );

  const handleBookSelect = (type: 'favorite' | 'current', bookId: string) => {
    const selected = books.find((b) => b.id === bookId);
    if (!selected) return;

    if (type === 'favorite') {
      setFavoriteBookTitle(selected.title);
      setFavoriteBookAuthor(selected.author);
      setFavoriteBookCover(selected.coverUrl || '');
    } else {
      setCurrentBookTitle(selected.title);
      setCurrentBookAuthor(selected.author);
      setCurrentBookCover(selected.coverUrl || '');
    }
  };

  const handleSave = () => {
    const updatedShared: SharedProfileData = {
      favoriteBookTitle: favoriteBookTitle.trim() || undefined,
      favoriteBookAuthor: favoriteBookAuthor.trim() || undefined,
      favoriteBookCover: favoriteBookCover.trim() || undefined,
      currentBookTitle: currentBookTitle.trim() || undefined,
      currentBookAuthor: currentBookAuthor.trim() || undefined,
      currentBookCover: currentBookCover.trim() || undefined,
      favoriteAuthor: favoriteAuthor.trim() || undefined,
      favoriteGenre: favoriteGenre.trim() || undefined,
      theme,
      privacy,
    };

    onSaveUserProfile({
      ...user,
      avatarUrl: avatarUrl.trim() || undefined,
      sharedProfile: updatedShared,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-fadeIn">
      <div className="w-full max-w-2xl glass-panel rounded-3xl border border-white/20 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-white/10 flex items-center justify-between shrink-0 bg-white/[0.02]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-['Syne']">
                Personalizar Perfil Compartido & Privacidad
              </h2>
              <p className="text-xs text-zinc-400">
                Elige qué información y estilo ven tus amigos en su comunidad.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab buttons */}
        <div className="flex items-center border-b border-white/10 px-6 text-xs shrink-0">
          <button
            onClick={() => setActiveTab('visual')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'visual'
                ? 'border-purple-400 text-white'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Diseño & Banner Difuminado</span>
          </button>

          <button
            onClick={() => setActiveTab('info')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'info'
                ? 'border-purple-400 text-white'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Datos Literarios</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'privacy'
                ? 'border-purple-400 text-white'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Privacidad de Elementos</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* TAB 1: VISUAL & BANNER BLUR */}
          {activeTab === 'visual' && (
            <div className="space-y-6">
              {/* Live Preview Box */}
              <div className="relative rounded-2xl overflow-hidden border border-white/15 h-36 flex items-end p-4">
                <div
                  className="absolute inset-0 scale-110"
                  style={{
                    background:
                      theme.bannerType === 'image' && theme.bannerValue
                        ? `url(${theme.bannerValue}) center/cover no-repeat`
                        : theme.bannerValue,
                    filter: `blur(${theme.bannerBlur}px)`,
                    opacity: 0.6,
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="relative z-10 flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-xl border-2 flex items-center justify-center font-bold text-white shadow-xl text-lg bg-zinc-900"
                    style={{ borderColor: theme.avatarFrameColor }}
                  >
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <span className="font-bold text-white text-sm block">{user.name}</span>
                    <span
                      className="text-[11px] font-semibold px-2 py-0.5 rounded-full inline-block mt-0.5"
                      style={{
                        backgroundColor: `${theme.primaryColor}33`,
                        color: theme.accentColor,
                        border: `1px solid ${theme.accentColor}55`,
                      }}
                    >
                      Vista previa compartida
                    </span>
                  </div>
                </div>
              </div>

              {/* Color Principal & Color de Acento */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-zinc-300 font-semibold block mb-2">
                    Color principal del perfil
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {PRESET_THEME_COLORS.map((hex) => (
                      <button
                        key={hex}
                        type="button"
                        onClick={() => setTheme({ ...theme, primaryColor: hex })}
                        className={`w-7 h-7 rounded-full border transition-all ${
                          theme.primaryColor === hex
                            ? 'scale-125 border-white ring-2 ring-white/40 shadow-lg'
                            : 'border-white/20'
                        }`}
                        style={{ backgroundColor: hex }}
                      />
                    ))}
                    <input
                      type="color"
                      value={theme.primaryColor}
                      onChange={(e) => setTheme({ ...theme, primaryColor: e.target.value })}
                      className="w-7 h-7 rounded-full cursor-pointer bg-transparent border-0"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-zinc-300 font-semibold block mb-2">
                    Color de acento del perfil
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {PRESET_THEME_COLORS.map((hex) => (
                      <button
                        key={hex}
                        type="button"
                        onClick={() => setTheme({ ...theme, accentColor: hex })}
                        className={`w-7 h-7 rounded-full border transition-all ${
                          theme.accentColor === hex
                            ? 'scale-125 border-white ring-2 ring-white/40 shadow-lg'
                            : 'border-white/20'
                        }`}
                        style={{ backgroundColor: hex }}
                      />
                    ))}
                    <input
                      type="color"
                      value={theme.accentColor}
                      onChange={(e) => setTheme({ ...theme, accentColor: e.target.value })}
                      className="w-7 h-7 rounded-full cursor-pointer bg-transparent border-0"
                    />
                  </div>
                </div>
              </div>

              {/* Marco y Color de la Foto de Perfil */}
              <div className="space-y-3 pt-2 border-t border-white/10">
                <label className="text-zinc-300 font-semibold block">
                  Foto de perfil y Marco
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-zinc-400 block mb-1">URL de foto de perfil</span>
                    <input
                      type="url"
                      value={avatarUrl}
                      onChange={(e) => setAvatarUrl(e.target.value)}
                      placeholder="https://ejemplo.com/mi-foto.jpg"
                      className="w-full bg-zinc-900 border border-white/15 focus:border-purple-400 rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-zinc-400 block mb-1">Color del marco</span>
                    <div className="flex items-center gap-2 flex-wrap mt-1">
                      {PRESET_THEME_COLORS.map((hex) => (
                        <button
                          key={hex}
                          type="button"
                          onClick={() => setTheme({ ...theme, avatarFrameColor: hex })}
                          className={`w-6 h-6 rounded-full border transition-all ${
                            theme.avatarFrameColor === hex ? 'scale-125 border-white ring-2 ring-white/40' : 'border-white/20'
                          }`}
                          style={{ backgroundColor: hex }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Banner difuminado (Blur) & Tipo de Banner */}
              <div className="space-y-3 pt-2 border-t border-white/10">
                <div className="flex items-center justify-between">
                  <label className="text-zinc-300 font-semibold block">
                    Banner del perfil (con efecto difuminado / blur)
                  </label>
                  <span className="text-zinc-400 text-[11px]">Blur: {theme.bannerBlur}px</span>
                </div>

                <div className="space-y-3">
                  {/* Presets */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {PRESET_BANNER_GRADIENTS.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() =>
                          setTheme({ ...theme, bannerType: 'preset', bannerValue: p.value })
                        }
                        className={`px-3 py-1.5 rounded-xl border font-semibold text-[11px] transition-all ${
                          theme.bannerValue === p.value
                            ? 'border-purple-400 bg-purple-500/20 text-white'
                            : 'border-white/10 bg-white/[0.03] text-zinc-400 hover:text-white'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>

                  {/* Imagen propia como banner */}
                  <div>
                    <span className="text-[11px] text-zinc-400 block mb-1">
                      O usa una imagen como banner (URL)
                    </span>
                    <div className="flex items-center gap-2">
                      <input
                        type="url"
                        value={customBannerUrl}
                        onChange={(e) => {
                          setCustomBannerUrl(e.target.value);
                          if (e.target.value.trim()) {
                            setTheme({
                              ...theme,
                              bannerType: 'image',
                              bannerValue: e.target.value.trim(),
                            });
                          }
                        }}
                        placeholder="https://images.unsplash.com/..."
                        className="flex-1 bg-zinc-900 border border-white/15 focus:border-purple-400 rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  {/* Intensidad del Blur */}
                  <div>
                    <span className="text-[11px] text-zinc-400 block mb-1">
                      Intensidad del difuminado de fondo
                    </span>
                    <input
                      type="range"
                      min="4"
                      max="32"
                      value={theme.bannerBlur}
                      onChange={(e) =>
                        setTheme({ ...theme, bannerBlur: Number(e.target.value) })
                      }
                      className="w-full accent-purple-400 bg-white/10 h-1.5 rounded cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-zinc-400 text-[11px]">
                ℹ️ Esta personalización solo se aplica al perfil que ven tus amigos y NO modifica el diseño del resto de la aplicación.
              </div>
            </div>
          )}

          {/* TAB 2: DATOS LITERARIOS */}
          {activeTab === 'info' && (
            <div className="space-y-4">
              <p className="text-zinc-400 text-xs">
                Configura los libros, autores y géneros que te definen. Si alguno no está configurado, no se mostrará un hueco vacío innecesario.
              </p>

              {/* Libro Favorito */}
              <div className="glass-panel-subtle rounded-2xl p-4 border border-white/10 space-y-2">
                <span className="text-zinc-300 font-semibold block">Libro Favorito</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select
                    onChange={(e) => handleBookSelect('favorite', e.target.value)}
                    className="bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="">-- Seleccionar de mi biblioteca --</option>
                    {books.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title} ({b.author})
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={favoriteBookTitle}
                    onChange={(e) => setFavoriteBookTitle(e.target.value)}
                    placeholder="O escribe el título..."
                    className="bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              {/* Libro que está leyendo actualmente */}
              <div className="glass-panel-subtle rounded-2xl p-4 border border-white/10 space-y-2">
                <span className="text-zinc-300 font-semibold block">
                  Libro que está leyendo actualmente
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select
                    onChange={(e) => handleBookSelect('current', e.target.value)}
                    className="bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="">-- Seleccionar de mi biblioteca --</option>
                    {books.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title} ({b.author})
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={currentBookTitle}
                    onChange={(e) => setCurrentBookTitle(e.target.value)}
                    placeholder="O escribe el título..."
                    className="bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              {/* Autor Favorito */}
              <div className="glass-panel-subtle rounded-2xl p-4 border border-white/10 space-y-2">
                <span className="text-zinc-300 font-semibold block">Autor Favorito</span>
                <input
                  type="text"
                  value={favoriteAuthor}
                  onChange={(e) => setFavoriteAuthor(e.target.value)}
                  placeholder="Ej: Mary Shelley, Frank Herbert, Gabriel García Márquez..."
                  className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              {/* Género Favorito */}
              <div className="glass-panel-subtle rounded-2xl p-4 border border-white/10 space-y-2">
                <span className="text-zinc-300 font-semibold block">Género Favorito</span>
                <input
                  type="text"
                  value={favoriteGenre}
                  onChange={(e) => setFavoriteGenre(e.target.value)}
                  placeholder="Ej: Ciencia Ficción, Misterio, Novela Histórica..."
                  className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>
            </div>
          )}

          {/* TAB 3: PRIVACIDAD */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <p className="text-zinc-400 text-xs">
                Activa o desactiva qué secciones podrán ver tus amigos cuando visiten tu perfil compartido. Lo desactivado se ocultará en el perfil público, pero seguirá 100% visible en tu perfil privado.
              </p>

              <div className="space-y-2">
                {[
                  { key: 'showBooks', label: 'Libros de mi biblioteca', desc: 'Permitir ver tus libros leídos' },
                  { key: 'showFavoriteBook', label: 'Libro favorito', desc: 'Mostrar tu libro favorito en el perfil' },
                  { key: 'showCurrentBook', label: 'Libro que está leyendo', desc: 'Mostrar tu lectura en curso' },
                  { key: 'showFavoriteAuthor', label: 'Autor favorito', desc: 'Mostrar tu autor predilecto' },
                  { key: 'showFavoriteGenre', label: 'Género favorito', desc: 'Mostrar tu género literario predilecto' },
                  { key: 'showStats', label: 'Estadísticas de lectura', desc: 'Páginas leídas, racha y libros completados' },
                  { key: 'showActivity', label: 'Actividad reciente', desc: 'Hitos recientes y lecturas finalizadas' },
                  { key: 'showCollections', label: 'Colecciones', desc: 'Listas de libros organizadas' },
                  { key: 'showQuotes', label: 'Frases y citas destacadas', desc: 'Subrayados compartidos en tu biblioteca' },
                ].map((item) => {
                  const isChecked = privacy[item.key as keyof SharedProfilePrivacy];
                  return (
                    <div
                      key={item.key}
                      onClick={() =>
                        setPrivacy({ ...privacy, [item.key]: !isChecked })
                      }
                      className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/10 hover:border-white/20 transition-all flex items-center justify-between cursor-pointer"
                    >
                      <div>
                        <span className="text-xs font-semibold text-white block">
                          {item.label}
                        </span>
                        <span className="text-[11px] text-zinc-400 block mt-0.5">
                          {item.desc}
                        </span>
                      </div>

                      <div
                        className={`w-10 h-6 rounded-full transition-colors relative p-0.5 ${
                          isChecked ? 'bg-purple-500' : 'bg-white/10'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-white transition-transform ${
                            isChecked ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 border-t border-white/10 bg-white/[0.02] flex items-center justify-end gap-2 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs text-zinc-400 hover:text-white"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 bg-white hover:bg-zinc-200 text-zinc-950 font-bold text-xs rounded-xl shadow-lg transition-all"
          >
            Guardar cambios
          </button>
        </div>
      </div>
    </div>
  );
};
