import React from 'react';
import { Hammer, Shuffle, Bomb, X } from 'lucide-react';
import { PowerUpState, PowerUpType } from '../types/game';

interface PowerUpBarProps {
  powerUps: PowerUpState;
  onActivatePowerUp: (type: PowerUpType) => void;
  onCancelActivePowerUp: () => void;
  disabled?: boolean;
}

export const PowerUpBar: React.FC<PowerUpBarProps> = ({
  powerUps,
  onActivatePowerUp,
  onCancelActivePowerUp,
  disabled = false,
}) => {
  return (
    <div className="w-full max-w-[400px] mx-auto px-2 py-0.5 select-none shrink-0">
      {/* If a targeting power-up is active, show instruction banner */}
      {powerUps.activePowerUp && (
        <div className="flex items-center justify-between px-2.5 py-1 mb-1 rounded-lg bg-cyan-950/90 border border-cyan-400/60 shadow-md animate-pulse text-[11px]">
          <span className="font-bold text-cyan-300">
            {powerUps.activePowerUp === 'HAMMER'
              ? 'Tap any cell to smash!'
              : 'Tap any cell to blast 3x3!'}
          </span>
          <button
            onClick={onCancelActivePowerUp}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold"
          >
            <X className="w-3 h-3" />
            Cancel
          </button>
        </div>
      )}

      {/* 3 Power-up Buttons */}
      <div className="grid grid-cols-3 gap-1.5">
        {/* 1. Hammer */}
        <button
          onClick={() => onActivatePowerUp('HAMMER')}
          disabled={disabled || powerUps.hammerCount <= 0}
          className={`relative py-1.5 px-2 rounded-xl border flex items-center justify-center gap-1.5 transition-all duration-100 active:scale-95 ${
            powerUps.activePowerUp === 'HAMMER'
              ? 'bg-cyan-500 text-slate-950 border-white shadow-[0_0_12px_rgba(6,182,212,0.8)]'
              : powerUps.hammerCount > 0 && !disabled
              ? 'bg-[#101b38]/90 hover:bg-[#182852] border-slate-700/80 text-cyan-300 shadow-sm'
              : 'bg-[#091122]/60 border-slate-800/40 text-slate-600 cursor-not-allowed opacity-50'
          }`}
        >
          <Hammer className="w-3.5 h-3.5 shrink-0" />
          <span className="text-[11px] font-bold font-display uppercase tracking-wider">Hammer</span>
          <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-slate-900/80 font-mono-numbers text-slate-200">
            {powerUps.hammerCount}
          </span>
        </button>

        {/* 2. Reroll / Shuffle */}
        <button
          onClick={() => onActivatePowerUp('REROLL')}
          disabled={disabled || powerUps.rerollCount <= 0}
          className={`relative py-1.5 px-2 rounded-xl border flex items-center justify-center gap-1.5 transition-all duration-100 active:scale-95 ${
            powerUps.rerollCount > 0 && !disabled
              ? 'bg-[#101b38]/90 hover:bg-[#182852] border-slate-700/80 text-purple-300 shadow-sm'
              : 'bg-[#091122]/60 border-slate-800/40 text-slate-600 cursor-not-allowed opacity-50'
          }`}
        >
          <Shuffle className="w-3.5 h-3.5 shrink-0" />
          <span className="text-[11px] font-bold font-display uppercase tracking-wider">Shuffle</span>
          <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-slate-900/80 font-mono-numbers text-slate-200">
            {powerUps.rerollCount}
          </span>
        </button>

        {/* 3. Bomb Blast */}
        <button
          onClick={() => onActivatePowerUp('BOMB_BLAST')}
          disabled={disabled || powerUps.bombBlastCount <= 0}
          className={`relative py-1.5 px-2 rounded-xl border flex items-center justify-center gap-1.5 transition-all duration-100 active:scale-95 ${
            powerUps.activePowerUp === 'BOMB_BLAST'
              ? 'bg-rose-500 text-slate-950 border-white shadow-[0_0_12px_rgba(244,63,94,0.8)]'
              : powerUps.bombBlastCount > 0 && !disabled
              ? 'bg-[#101b38]/90 hover:bg-[#182852] border-slate-700/80 text-rose-300 shadow-sm'
              : 'bg-[#091122]/60 border-slate-800/40 text-slate-600 cursor-not-allowed opacity-50'
          }`}
        >
          <Bomb className="w-3.5 h-3.5 shrink-0" />
          <span className="text-[11px] font-bold font-display uppercase tracking-wider">Blast</span>
          <span className="text-[9px] font-black px-1.5 py-0.2 rounded-full bg-slate-900/80 font-mono-numbers text-slate-200">
            {powerUps.bombBlastCount}
          </span>
        </button>
      </div>
    </div>
  );
};
