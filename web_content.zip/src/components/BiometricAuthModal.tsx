import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Fingerprint, 
  Scan, 
  ShieldCheck, 
  Lock, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Key, 
  Sparkles,
  Smartphone,
  Cpu
} from 'lucide-react';
import { webAuthnBiometric, BiometricAuthResult } from '../lib/webAuthnBiometric';

interface BiometricAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (result: BiometricAuthResult) => void;
  amountText: string;
  destinationText: string;
}

export const BiometricAuthModal: React.FC<BiometricAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  amountText,
  destinationText
}) => {
  const [selectedMethod, setSelectedMethod] = useState<'fingerprint' | 'face_id'>('fingerprint');
  const [scanState, setScanState] = useState<'idle' | 'scanning' | 'success' | 'failed'>('idle');
  const [progress, setProgress] = useState<number>(0);
  const [statusMsg, setStatusMsg] = useState<string>('Touch biometric sensor or hold to scan');
  const [hasHardwareWebAuthn, setHasHardwareWebAuthn] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setScanState('idle');
      setProgress(0);
      setStatusMsg('Touch biometric sensor to authorize withdrawal');
      webAuthnBiometric.isPlatformAuthenticatorAvailable().then(avail => {
        setHasHardwareWebAuthn(avail);
      });
    }
  }, [isOpen]);

  const handleStartScan = async () => {
    if (scanState === 'scanning' || scanState === 'success') return;

    setScanState('scanning');
    setProgress(15);
    setStatusMsg(selectedMethod === 'fingerprint' 
      ? 'Scanning fingerprint biometric ridges...' 
      : 'Analyzing 3D facial facial contour mesh...'
    );

    // Progressive visual scan
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 25;
      });
    }, 180);

    try {
      const authResult = await webAuthnBiometric.verifyBiometric(
        `Withdrawal of ${amountText} to ${destinationText}`,
        selectedMethod
      );

      clearInterval(interval);
      setProgress(100);
      setScanState('success');
      setStatusMsg('Biometric Identity Verified & Cryptographically Signed!');

      setTimeout(() => {
        onSuccess(authResult);
      }, 900);
    } catch (err: any) {
      clearInterval(interval);
      setScanState('failed');
      setStatusMsg(`Biometric verification failed: ${err.message || 'Sensor error'}`);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 15 }}
          className="relative w-full max-w-md bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/80 border-2 border-amber-500/60 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-slate-100 overflow-hidden"
        >
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <h3 className="text-base font-bold font-serif text-amber-100">
                  WebAuthn Biometric Security
                </h3>
                <p className="text-[11px] text-slate-400">
                  FIDO2 / Touch ID / Face ID Authentication Required
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              disabled={scanState === 'scanning'}
              className="text-slate-400 hover:text-white text-sm font-bold p-1"
            >
              ✕
            </button>
          </div>

          {/* Withdrawal Details Reminder */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-amber-500/30 text-xs space-y-1.5 font-mono">
            <div className="flex justify-between">
              <span className="text-slate-400">Transaction:</span>
              <span className="text-emerald-400 font-bold">{amountText}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Destination:</span>
              <span className="text-amber-200 truncate max-w-[200px]">{destinationText}</span>
            </div>
          </div>

          {/* Biometric Method Selector */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => { setSelectedMethod('fingerprint'); setScanState('idle'); setProgress(0); }}
              className={`p-2.5 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 border transition-all ${
                selectedMethod === 'fingerprint'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}
            >
              <Fingerprint className="w-4 h-4" />
              <span>Fingerprint / Touch</span>
            </button>

            <button
              onClick={() => { setSelectedMethod('face_id'); setScanState('idle'); setProgress(0); }}
              className={`p-2.5 rounded-xl text-xs font-bold flex items-center justify-center space-x-2 border transition-all ${
                selectedMethod === 'face_id'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}
            >
              <Scan className="w-4 h-4" />
              <span>Face ID / Optical</span>
            </button>
          </div>

          {/* Interactive Biometric Sensor Touch Pad */}
          <div className="flex flex-col items-center justify-center space-y-4 py-2">
            <button
              onClick={handleStartScan}
              disabled={scanState === 'scanning' || scanState === 'success'}
              className={`relative w-28 h-28 rounded-full border-2 flex items-center justify-center transition-all cursor-pointer group ${
                scanState === 'success'
                  ? 'bg-emerald-950/80 border-emerald-400 text-emerald-400 shadow-2xl shadow-emerald-500/30'
                  : scanState === 'scanning'
                  ? 'bg-amber-950/60 border-amber-400 text-amber-300 shadow-2xl shadow-amber-500/40 animate-pulse'
                  : scanState === 'failed'
                  ? 'bg-rose-950/60 border-rose-500 text-rose-400'
                  : 'bg-slate-900 hover:bg-slate-850 border-amber-500/50 hover:border-amber-400 text-amber-300 hover:scale-105'
              }`}
            >
              {/* Rotating Progress Track */}
              {scanState === 'scanning' && (
                <div 
                  className="absolute inset-0 rounded-full border-4 border-amber-400 border-t-transparent animate-spin"
                />
              )}

              {scanState === 'success' ? (
                <CheckCircle2 className="w-14 h-14 text-emerald-400 animate-bounce" />
              ) : selectedMethod === 'fingerprint' ? (
                <Fingerprint className={`w-14 h-14 ${scanState === 'scanning' ? 'text-amber-400 scale-110' : 'text-amber-300 group-hover:scale-110'} transition-transform`} />
              ) : (
                <Scan className={`w-14 h-14 ${scanState === 'scanning' ? 'text-amber-400 scale-110' : 'text-amber-300 group-hover:scale-110'} transition-transform`} />
              )}
            </button>

            {/* Scan Progress Bar & Instructions */}
            <div className="w-full space-y-2 text-center">
              <p className={`text-xs font-bold ${
                scanState === 'success' ? 'text-emerald-300' :
                scanState === 'failed' ? 'text-rose-400' :
                scanState === 'scanning' ? 'text-amber-300 animate-pulse' :
                'text-slate-300'
              }`}>
                {statusMsg}
              </p>

              {scanState === 'scanning' && (
                <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-amber-500/30">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-200"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Action Trigger Button */}
          {scanState !== 'success' && (
            <button
              onClick={handleStartScan}
              disabled={scanState === 'scanning'}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-xl shadow-amber-500/30 flex items-center justify-center space-x-2 transition-all hover:scale-102"
            >
              {scanState === 'scanning' ? (
                <>
                  <RefreshCw className="w-4 h-4 text-slate-950 animate-spin" />
                  <span>AUTHENTICATING BIOMETRIC KEY...</span>
                </>
              ) : (
                <>
                  <Fingerprint className="w-4 h-4 text-slate-950" />
                  <span>SCAN BIOMETRIC & APPROVE WITHDRAWAL</span>
                </>
              )}
            </button>
          )}

          {/* Security Guarantee Note */}
          <div className="flex items-center space-x-2 text-[10px] text-slate-400 justify-center font-mono">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>FIDO2 / WebAuthn Hardware Cryptographic Verification</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
