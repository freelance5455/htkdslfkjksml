import React from "react";
import { LandPlot, Player } from "../types";
import { sound } from "../audio";
import { X, MapPin, Coins, Check, Unlock, Trees, Sparkles } from "lucide-react";

interface LandModalProps {
  isOpen: boolean;
  onClose: () => void;
  player: Player;
  landPlots: LandPlot[];
  onBuyPlot: (plot: LandPlot) => void;
}

export const LandModal: React.FC<LandModalProps> = ({
  isOpen,
  onClose,
  player,
  landPlots,
  onBuyPlot,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-xl bg-stone-900 border-2 border-amber-600/70 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-950 via-amber-950/60 to-stone-950 p-4 border-b border-amber-700/50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-600/20 text-amber-400 rounded-lg border border-amber-500/30">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-amber-200 font-['Hind_Siliguri']">
                গ্রামের নতুন জমি ক্রয় ও সীমানা উন্মোচন
              </h2>
              <p className="text-xs text-stone-300">
                Expand village territory to fell wild trees, grow crops, and give dogs open space
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-stone-950/80 px-2.5 py-1 rounded-lg border border-amber-500/40 flex items-center gap-1.5 text-amber-300 text-xs font-bold font-mono">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>{player.coins} Tk</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-white hover:bg-stone-700 cursor-pointer transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Plots List */}
        <div className="p-4 overflow-y-auto space-y-3.5 flex-1">
          {landPlots.map((plot) => {
            const canAfford = player.coins >= plot.cost;

            return (
              <div
                key={plot.id}
                className={`p-3.5 rounded-xl border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                  plot.isUnlocked
                    ? "bg-emerald-950/40 border-emerald-600/50"
                    : canAfford
                    ? "bg-stone-800/80 border-amber-500/40 hover:border-amber-400"
                    : "bg-stone-950/50 border-stone-800 opacity-80"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl shrink-0 border ${
                      plot.isUnlocked
                        ? "bg-emerald-900/60 border-emerald-500 text-emerald-300"
                        : "bg-stone-900 border-stone-700 text-amber-400"
                    }`}
                  >
                    {plot.isUnlocked ? <Check className="w-6 h-6" /> : <Trees className="w-6 h-6" />}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-stone-100 font-['Hind_Siliguri'] text-base">
                        {plot.bengaliName}
                      </span>
                      {plot.isUnlocked ? (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-900/80 text-emerald-300 border border-emerald-600/50">
                          মালিকানাধীন (Owned)
                        </span>
                      ) : (
                        <span className="text-[11px] font-mono font-bold text-amber-300">
                          {plot.cost} Tk
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-stone-300 mt-1 leading-relaxed">
                      {plot.description}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 w-full sm:w-auto">
                  {plot.isUnlocked ? (
                    <div className="text-xs text-emerald-400 font-bold flex items-center gap-1 font-mono">
                      <Unlock className="w-4 h-4" />
                      <span>সীমানা উন্মুক্ত!</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        sound.playHarvest();
                        onBuyPlot(plot);
                      }}
                      disabled={!canAfford}
                      className={`w-full sm:w-auto px-4 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition ${
                        canAfford
                          ? "bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-900/30"
                          : "bg-stone-800 text-stone-500 cursor-not-allowed border border-stone-700"
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5 text-amber-200" />
                      <span>জমি কিনুন ({plot.cost} Tk)</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 text-[11px] text-stone-400 flex items-center justify-between">
          <span>💡 জমি কিনলে সীমানার বেড়া খুলে যাবে এবং নতুন গাছপালা ও কুকুরদের বিচরণক্ষেত্র উন্মুক্ত হবে।</span>
          <span className="text-amber-400 font-mono">কচুবন রিয়েল এস্টেট</span>
        </div>
      </div>
    </div>
  );
};
