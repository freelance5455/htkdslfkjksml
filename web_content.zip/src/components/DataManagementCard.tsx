import React, { useState } from 'react';
import { Database, Copy, Download, Trash2, AlertTriangle, FileText, Check } from 'lucide-react';
import { CNICRecord, SendingEntry, ReplyEntry, Language } from '../types';
import { formatCNIC } from '../utils/cnic';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface DataManagementCardProps {
  records: CNICRecord[];
  sending: SendingEntry[];
  replies: ReplyEntry[];
  onDeleteAll: () => void;
  language: Language;
  onShowToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const DataManagementCard: React.FC<DataManagementCardProps> = ({
  records,
  sending,
  replies,
  onDeleteAll,
  language,
  onShowToast,
}) => {
  const tr = t[language];
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const generateReportString = (): string => {
    let output = `=================================================\n`;
    output += `        AKS 668 PREMIUM SYSTEM REPORT            \n`;
    output += `Generated at: ${new Date().toLocaleString()}\n`;
    output += `Total CNIC Records: ${records.length}\n`;
    output += `=================================================\n\n`;

    output += `[CNIC RECORDS]\n`;
    if (records.length === 0) {
      output += `(No records)\n`;
    } else {
      records.forEach((r, i) => {
        output += `${i + 1}. CNIC: ${formatCNIC(r.cnic)} | Status: ${r.status} | SIM: ${r.sim} | Time: ${r.time}\n`;
      });
    }

    output += `\n[SENDING HISTORY (PORT 668)]\n`;
    if (sending.length === 0) {
      output += `(No sending activity)\n`;
    } else {
      sending.forEach((s, i) => {
        output += `${i + 1}. ${formatCNIC(s.cnic)} -> Dest: ${s.destination} | SIM: ${s.sim} | ${s.status} | ${s.time}\n`;
      });
    }

    output += `\n[REPLY MONITOR (PTA 668 RESPONSES)]\n`;
    if (replies.length === 0) {
      output += `(No replies)\n`;
    } else {
      replies.forEach((rep, i) => {
        output += `${i + 1}. [${rep.time}] CNIC: ${formatCNIC(rep.cnic)}\n   ${rep.rawText}\n`;
      });
    }

    output += `\n=================================================\n`;
    output += `AKS 668 System - Professional Interface\n`;
    return output;
  };

  const handleCopyAll = () => {
    if (!records.length && !sending.length && !replies.length) {
      sounds.playError();
      onShowToast(language === 'ur' ? 'کاپی کرنے کے لیے کوئی ڈیٹا نہیں ہے' : 'No data to copy', 'warning');
      return;
    }

    const text = generateReportString();
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    sounds.playSuccess();
    onShowToast(tr.copiedSuccess, 'success');
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!records.length && !sending.length && !replies.length) {
      sounds.playError();
      onShowToast(language === 'ur' ? 'ڈاؤن لوڈ کرنے کے لیے کوئی ڈیٹا نہیں ہے' : 'No data available to download', 'warning');
      return;
    }

    const text = generateReportString();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AKS-668-records-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    sounds.playSuccess();
    onShowToast(language === 'ur' ? 'ریکارڈ فائل تیار ہے اور ڈاؤن لوڈ ہو گئی' : 'Records file downloaded successfully', 'success');
  };

  const handleConfirmDelete = () => {
    onDeleteAll();
    setShowConfirmModal(false);
    sounds.playSuccess();
    onShowToast(language === 'ur' ? 'تمام مقامی ریکارڈز حذف کر دیے گئے' : 'All local records deleted', 'info');
  };

  return (
    <div className="card-cyber relative p-5 rounded-2xl border border-[#247ab0] bg-gradient-to-br from-[#172e4d] to-[#0a1425] shadow-[0_5px_25px_rgba(0,30,65,0.45)] transition-all hover:border-[#389bd9]">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#214c77]">
        <div className="flex items-center gap-2">
          <Database className="w-5 h-5 text-[#41eaff]" />
          <h3 className="text-base sm:text-lg font-bold text-[#41eaff] tracking-wide m-0">
            {tr.dataManagement}
          </h3>
        </div>
      </div>

      {/* Buttons */}
      <div className="space-y-2.5">
        <button
          type="button"
          onClick={handleCopyAll}
          className="w-full p-3.5 border-0 rounded-xl bg-gradient-to-r from-[#087a58] to-[#12c995] text-white font-bold text-sm tracking-wide shadow-[0_4px_15px_rgba(18,201,149,0.25)] hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          {isCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          <span>{isCopied ? 'COPIED TO CLIPBOARD!' : tr.copyAllBtn}</span>
        </button>

        <button
          type="button"
          onClick={handleDownload}
          className="w-full p-3.5 border-0 rounded-xl bg-gradient-to-r from-[#087bd1] to-[#00d5ed] text-white font-bold text-sm tracking-wide shadow-[0_4px_15px_rgba(0,213,237,0.25)] hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <Download className="w-4 h-4" />
          <span>{tr.downloadRecordsBtn}</span>
        </button>

        <button
          type="button"
          onClick={() => {
            sounds.playClick();
            setShowConfirmModal(true);
          }}
          className="w-full p-3.5 border-0 rounded-xl bg-gradient-to-r from-[#a62c44] to-[#ed5267] text-white font-bold text-sm tracking-wide shadow-[0_4px_15px_rgba(237,82,103,0.25)] hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <Trash2 className="w-4 h-4" />
          <span>{tr.deleteAllBtn}</span>
        </button>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#0b1b2e] border-2 border-rose-500/80 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h4 className="text-lg font-bold text-white m-0">
                {language === 'ur' ? 'تصدیق برائے حذف ریکارڈز' : 'Confirm Data Deletion'}
              </h4>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed m-0">
              {tr.clearAllConfirm}
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-xl bg-[#14283f] hover:bg-[#1a3452] text-slate-300 text-sm font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-sm font-bold shadow-lg transition-colors cursor-pointer"
              >
                Delete Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
