import React, { useState } from 'react';
import { MemoryItem } from '../types/jarvis';
import {
  Brain,
  Search,
  Plus,
  Trash2,
  Edit2,
  Save,
  X,
  Sparkles,
  ShieldCheck,
  Tag,
  Clock,
  Code2,
  Check,
  RotateCcw,
} from 'lucide-react';

interface SmartMemoryCoreProps {
  memories: MemoryItem[];
  onSaveMemory: (key: string, value: string, category?: MemoryItem['category'], label?: string) => void;
  onUpdateMemory: (keyOrId: string, newValue: string) => void;
  onDeleteMemory: (target: string) => void;
  onClearMemories: () => void;
  onVoiceCommandExecute: (cmd: string) => void;
}

export const SmartMemoryCore: React.FC<SmartMemoryCoreProps> = ({
  memories,
  onSaveMemory,
  onUpdateMemory,
  onDeleteMemory,
  onClearMemories,
  onVoiceCommandExecute,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAndroidCode, setShowAndroidCode] = useState(false);

  // Form states
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newCategory, setNewCategory] = useState<MemoryItem['category']>('identity');

  // Inline editing
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  const categories = ['all', 'identity', 'preference', 'instruction', 'general'];

  const filteredMemories = memories.filter((item) => {
    const matchesSearch =
      item.key.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.value.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.label.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    onSaveMemory(newKey.trim(), newValue.trim(), newCategory);
    setNewKey('');
    setNewValue('');
    setShowAddModal(false);
  };

  const startEdit = (item: MemoryItem) => {
    setEditingId(item.id);
    setEditValue(item.value);
  };

  const saveEdit = (id: string) => {
    if (editValue.trim()) {
      onUpdateMemory(id, editValue.trim());
    }
    setEditingId(null);
  };

  const getCategoryColor = (cat: MemoryItem['category']) => {
    switch (cat) {
      case 'identity':
        return 'text-cyan-300 border-cyan-500/30 bg-cyan-950/40';
      case 'preference':
        return 'text-purple-300 border-purple-500/30 bg-purple-950/40';
      case 'instruction':
        return 'text-amber-300 border-amber-500/30 bg-amber-950/40';
      default:
        return 'text-slate-300 border-slate-700 bg-slate-900';
    }
  };

  return (
    <div className="bg-gray-900/90 border border-cyan-500/30 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-2xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-800 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Brain className="w-5 h-5 animate-pulse" />
            </span>
            <h2 className="font-orbitron text-lg font-bold tracking-wider text-slate-100 uppercase">
              Smart Neural Memory
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-rajdhani mt-0.5">
            Persistent key-value knowledge base stored locally on Android with natural language recall
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setShowAndroidCode(!showAndroidCode)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-950 border border-gray-800 hover:border-cyan-500/50 text-slate-400 hover:text-cyan-300 text-xs font-mono-code transition"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Android Code</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition shadow-md shadow-cyan-600/30"
          >
            <Plus className="w-4 h-4" />
            Save Memory
          </button>
        </div>
      </div>

      {/* Voice Prompt Shortcuts for Memory */}
      <div className="mb-4 p-2.5 rounded-xl bg-gray-950/70 border border-cyan-500/20 flex flex-wrap items-center gap-2">
        <span className="text-[11px] font-mono-code text-cyan-400 flex items-center gap-1 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Voice Memory Triggers:
        </span>
        <button
          onClick={() => onVoiceCommandExecute('My name is Prince, remember this')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "My name is Prince, remember this"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('What is my name?')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "What is my name?"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('Remember that I like black coffee')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "Remember I like black coffee"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('What do you remember about me?')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
        >
          "What do you remember?"
        </button>
        <button
          onClick={() => onVoiceCommandExecute('Forget my name')}
          className="text-xs font-mono-code px-2.5 py-1 rounded bg-gray-900 border border-gray-700 hover:border-red-400 text-slate-300 hover:text-red-300 transition"
        >
          "Forget my name"
        </button>
      </div>

      {/* Android Native SharedPreferences / Room DB Guide Dropdown */}
      {showAndroidCode && (
        <div className="mb-4 p-4 rounded-xl bg-gray-950 border border-cyan-500/40 text-xs font-mono-code text-slate-300 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-gray-800">
            <span className="text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Code2 className="w-4 h-4" />
              Android Native Implementation (Kotlin / SharedPreferences & Room)
            </span>
            <button onClick={() => setShowAndroidCode(false)} className="text-slate-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-slate-400 font-rajdhani text-xs">
            In our Web/PWA Android environment, memory is persisted in browser <code className="text-cyan-300">localStorage</code>.
            If you export to a standalone Kotlin Android APK, here is the exact native SharedPreferences / Room implementation:
          </p>
          <pre className="p-3 bg-black/60 rounded-lg overflow-x-auto text-[11px] text-cyan-200 border border-gray-800 leading-relaxed">
{`// Android Kotlin: MemoryHandler.kt
class MemoryHandler(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_neural_mem", Context.MODE_PRIVATE)

    fun saveMemory(key: String, value: String) {
        prefs.edit().putString(key.lowercase().trim(), value).apply()
    }

    fun getMemory(key: String): String? {
        return prefs.getString(key.lowercase().trim(), null)
    }

    fun updateMemory(key: String, newValue: String) {
        saveMemory(key, newValue)
    }

    fun deleteMemory(key: String) {
        prefs.edit().remove(key.lowercase().trim()).apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}`}
          </pre>
        </div>
      )}

      {/* Search & Categories Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search stored memories or preferences..."
            className="w-full bg-gray-950 border border-gray-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono-code uppercase transition shrink-0 ${
                selectedCategory === cat
                  ? 'bg-cyan-500 text-gray-950 font-bold'
                  : 'bg-gray-950 border border-gray-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Memory Items List */}
      {filteredMemories.length === 0 ? (
        <div className="text-center py-10 border border-dashed border-gray-800 rounded-xl">
          <Brain className="w-8 h-8 text-gray-600 mx-auto mb-2" />
          <p className="text-sm text-slate-400 font-rajdhani">
            No memories match your query. Tell Jarvis "My name is [Name], remember this" or tap "Save Memory".
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredMemories.map((item) => (
            <div
              key={item.id}
              className="p-3.5 rounded-xl bg-gray-950/80 border border-gray-800 hover:border-cyan-500/40 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
            >
              <div className="flex items-start sm:items-center gap-3 flex-1">
                <div className="p-2 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 shrink-0">
                  <Brain className="w-4 h-4" />
                </div>

                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono-code text-xs font-bold text-cyan-300">
                      {item.key}
                    </span>
                    <span className={`text-[10px] uppercase font-mono-code px-2 py-0.5 rounded border ${getCategoryColor(item.category)}`}>
                      {item.category}
                    </span>
                  </div>

                  {editingId === item.id ? (
                    <div className="flex items-center gap-2 mt-1.5">
                      <input
                        type="text"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        className="bg-gray-900 border border-cyan-400 rounded-lg px-2.5 py-1 text-xs text-slate-100 flex-1 focus:outline-none"
                      />
                      <button
                        onClick={() => saveEdit(item.id)}
                        className="p-1 rounded-lg bg-cyan-600 text-gray-950 hover:bg-cyan-500 transition"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setEditingId(null)}
                        className="p-1 rounded-lg bg-gray-800 text-slate-400 hover:text-white transition"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <p className="text-sm font-semibold text-slate-100 mt-0.5">
                      {item.value}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1.5 self-end sm:self-center">
                <button
                  onClick={() => startEdit(item)}
                  aria-label={`Edit ${item.key}`}
                  className="p-1.5 rounded-lg bg-gray-900 border border-gray-800 text-slate-400 hover:text-cyan-300 transition"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onDeleteMemory(item.id)}
                  aria-label={`Delete ${item.key}`}
                  className="p-1.5 rounded-lg bg-gray-900 border border-gray-800 text-slate-400 hover:text-red-400 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Footer Actions */}
      <div className="mt-4 pt-3 border-t border-gray-800 flex items-center justify-between text-xs font-mono-code text-slate-400">
        <span>Total Memories Stored: <strong className="text-cyan-300">{memories.length}</strong></span>
        {memories.length > 0 && (
          <button
            onClick={() => {
              if (confirm('Clear all stored memories from Jarvis neural bank?')) {
                onClearMemories();
              }
            }}
            className="text-red-400 hover:text-red-300 flex items-center gap-1 transition"
          >
            <Trash2 className="w-3 h-3" />
            Wipe Memory Bank
          </button>
        )}
      </div>

      {/* Add Memory Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-gray-900 border border-cyan-500/40 rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800">
              <h3 className="font-orbitron text-sm font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                <Brain className="w-4 h-4" />
                Commit New Memory
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Memory Key / Identifier
                </label>
                <input
                  type="text"
                  required
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="e.g. user_name / favorite_drink / home_address"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Information Value
                </label>
                <input
                  type="text"
                  required
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="e.g. Prince / Black Coffee with no sugar"
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">
                  Classification Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full bg-gray-950 border border-gray-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
                >
                  <option value="identity">Identity (Name, Role, Title)</option>
                  <option value="preference">Preference (Food, Drink, Style)</option>
                  <option value="instruction">Instruction (Custom Rules)</option>
                  <option value="fact">Fact / Knowledge</option>
                  <option value="general">General Note</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-gray-950 font-bold font-orbitron text-xs uppercase tracking-wider transition shadow-lg shadow-cyan-600/30"
                >
                  Store Memory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
