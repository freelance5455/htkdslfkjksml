import React, { useState, useEffect } from 'react';
import { Wifi, X, Lock, Check, Terminal, ExternalLink, RefreshCw } from 'lucide-react';
import { AVAILABLE_WIFI_NETWORKS } from '../services/catalogData';

interface WifiSettingsModalProps {
  isOpen: boolean;
  connectedSsid: string;
  onClose: () => void;
  onSelectNetwork: (ssid: string) => void;
  onLaunchAndroidWifiSettings: () => void;
}

export const WifiSettingsModal: React.FC<WifiSettingsModalProps> = ({
  isOpen,
  connectedSsid,
  onClose,
  onSelectNetwork,
  onLaunchAndroidWifiSettings,
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [copied, setCopied] = useState(false);
  const [focusIndex, setFocusIndex] = useState(0);

  // Targets:
  // 0: "TV Settings" button
  // 1: "Scan Networks" button
  // 2 to 2 + networks.length - 1: Network cards
  // 2 + networks.length: "Done" button
  const totalTargets = 2 + AVAILABLE_WIFI_NETWORKS.length + 1;

  useEffect(() => {
    if (isOpen) {
      setFocusIndex(2); // Focus first available network by default
    }
  }, [isOpen]);

  const handleScan = () => {
    setIsScanning(true);
    setTimeout(() => setIsScanning(false), 1200);
  };

  const adbWifiCommand = 'adb shell am start -a android.settings.WIFI_SETTINGS';

  const handleCopyAdb = () => {
    navigator.clipboard.writeText(adbWifiCommand).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Keyboard and TV remote navigation inside modal
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.keyCode === 20) {
        e.preventDefault();
        setFocusIndex((prev) => (prev < totalTargets - 1 ? prev + 1 : 0));
      } else if (e.key === 'ArrowUp' || e.keyCode === 19) {
        e.preventDefault();
        setFocusIndex((prev) => (prev > 0 ? prev - 1 : totalTargets - 1));
      } else if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 23 || e.keyCode === 66) {
        e.preventDefault();
        if (focusIndex === 0) {
          onLaunchAndroidWifiSettings();
        } else if (focusIndex === 1) {
          handleScan();
        } else if (focusIndex >= 2 && focusIndex < 2 + AVAILABLE_WIFI_NETWORKS.length) {
          const net = AVAILABLE_WIFI_NETWORKS[focusIndex - 2];
          if (net) onSelectNetwork(net.ssid);
        } else if (focusIndex === totalTargets - 1) {
          onClose();
        }
      } else if (e.key === 'Escape' || e.key === 'Backspace' || e.keyCode === 4 || e.keyCode === 111) {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, focusIndex, totalTargets, onLaunchAndroidWifiSettings, onSelectNetwork, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in select-none"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-gradient-to-b from-[#181a20] to-[#0e1014] border border-white/20 rounded-3xl shadow-2xl p-6 md:p-8 text-white overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Wifi className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white">Wi-Fi & Network Settings</h2>
              <p className="text-xs text-slate-400 mt-0.5">Android TV Connectivity (Navigable via Remote)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Currently Connected Info Card */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <div>
              <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Current Network</p>
              <h3 className="text-base font-bold text-white mt-0.5">{connectedSsid}</h3>
              <p className="text-xs text-slate-400">Connected · 5 GHz · 866 Mbps</p>
            </div>
          </div>

          <button
            onClick={onLaunchAndroidWifiSettings}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1.5 cursor-pointer outline-hidden ${
              focusIndex === 0
                ? 'bg-white text-slate-950 ring-4 ring-white scale-105 border-white'
                : 'bg-white/10 hover:bg-white/20 text-white border-white/15'
            }`}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>TV Settings</span>
          </button>
        </div>

        {/* Available Networks List */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-300">Available Networks (Use Arrow Keys)</span>
            <button
              onClick={handleScan}
              disabled={isScanning}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[11px] font-medium transition-all cursor-pointer outline-hidden ${
                focusIndex === 1
                  ? 'bg-sky-400 text-slate-950 font-bold ring-2 ring-white'
                  : 'text-sky-400 hover:text-sky-300'
              }`}
            >
              <RefreshCw className={`w-3 h-3 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'Scanning...' : 'Scan Networks'}</span>
            </button>
          </div>

          <div className="space-y-2">
            {AVAILABLE_WIFI_NETWORKS.map((net, idx) => {
              const isSelected = net.ssid === connectedSsid;
              const isItemFocused = focusIndex === 2 + idx;

              return (
                <div
                  key={net.ssid}
                  onClick={() => onSelectNetwork(net.ssid)}
                  className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition-all ${
                    isItemFocused
                      ? 'bg-white text-slate-950 ring-4 ring-white scale-102 font-semibold shadow-2xl'
                      : isSelected
                      ? 'bg-emerald-500/15 border border-emerald-500/30 text-white'
                      : 'bg-white/5 hover:bg-white/10 border border-white/10 text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Wifi className={`w-4 h-4 ${isItemFocused ? 'text-slate-950' : isSelected ? 'text-emerald-400' : 'text-slate-400'}`} />
                    <div>
                      <p className={`text-sm ${isItemFocused ? 'font-bold text-slate-950' : 'font-semibold text-white'}`}>{net.ssid}</p>
                      <p className={`text-[11px] ${isItemFocused ? 'text-slate-700' : 'text-slate-400'}`}>Signal: {net.signal}%</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {net.secure && <Lock className={`w-3.5 h-3.5 ${isItemFocused ? 'text-slate-700' : 'text-slate-400'}`} />}
                    {isSelected && <Check className={`w-4 h-4 ${isItemFocused ? 'text-slate-950' : 'text-emerald-400'}`} />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Android TV Intent Shell Command */}
        <div className="p-3 rounded-2xl bg-black/40 border border-white/10 mb-4 text-xs">
          <div className="flex items-center justify-between mb-1">
            <span className="flex items-center gap-1 text-[10px] font-mono text-amber-400">
              <Terminal className="w-3.5 h-3.5" />
              Android TV Direct Intent
            </span>
            <button
              onClick={handleCopyAdb}
              className="text-[10px] text-slate-300 hover:text-white px-2 py-0.5 rounded bg-white/10 cursor-pointer"
            >
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <p className="font-mono text-[11px] text-slate-300 truncate">{adbWifiCommand}</p>
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10 text-xs">
          <button
            onClick={onClose}
            className={`px-6 py-2.5 rounded-xl font-bold transition-all cursor-pointer outline-hidden ${
              focusIndex === totalTargets - 1
                ? 'bg-white text-slate-950 ring-4 ring-white scale-105'
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            Done (Press OK)
          </button>
        </div>
      </div>
    </div>
  );
};
