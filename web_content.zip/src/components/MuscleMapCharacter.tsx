import React, { useId } from 'react';
import { Exercise } from '../types';

export type MuscleGroupId =
  | 'chest'
  | 'front-delts'
  | 'side-delts'
  | 'rear-delts'
  | 'traps'
  | 'mid-back'
  | 'lats'
  | 'lower-back'
  | 'biceps'
  | 'triceps'
  | 'forearms'
  | 'abs'
  | 'obliques'
  | 'glutes'
  | 'quads'
  | 'adductors'
  | 'hamstrings'
  | 'calves';

export const MUSCLE_GROUP_LABELS: Record<MuscleGroupId, string> = {
  chest: 'Chest (Pectorals)',
  'front-delts': 'Front Delts',
  'side-delts': 'Side Delts',
  'rear-delts': 'Rear Delts',
  traps: 'Traps (Upper)',
  'mid-back': 'Mid-Back & Rhomboids',
  lats: 'Lats (Latissimus)',
  'lower-back': 'Lower Back (Erectors)',
  biceps: 'Biceps & Brachialis',
  triceps: 'Triceps',
  forearms: 'Forearms & Grip',
  abs: 'Abs & Core',
  obliques: 'Obliques & Serratus',
  glutes: 'Glutes',
  quads: 'Quadriceps',
  adductors: 'Adductors & Hip Flexors',
  hamstrings: 'Hamstrings',
  calves: 'Calves & Shins'
};

/**
 * Maps a human-readable targetMuscle string (e.g. "Pectoralis Major", "Latissimus Dorsi")
 * to one or more canonical MuscleGroupId regions on the Front & Back character.
 */
export function mapMuscleStringToGroups(raw: string): MuscleGroupId[] {
  const s = raw.toLowerCase();
  const matched: MuscleGroupId[] = [];

  if (s.includes('pectoral') || s.includes('chest') || s.includes('sternal') || s.includes('clavicular')) {
    matched.push('chest');
  }
  if (s.includes('anterior delt') || s.includes('front delt')) {
    matched.push('front-delts');
  }
  if (s.includes('lateral delt') || s.includes('side delt') || s.includes('middle delt') || s.includes('supraspinatus')) {
    matched.push('side-delts');
  }
  if (
    s.includes('rear delt') ||
    s.includes('posterior delt') ||
    s.includes('posterior shoulder') ||
    s.includes('posterior capsule')
  ) {
    matched.push('rear-delts');
  }
  if (
    (s.includes('deltoid') || s.includes('shoulder')) &&
    !s.includes('anterior') &&
    !s.includes('front') &&
    !s.includes('lateral') &&
    !s.includes('side') &&
    !s.includes('rear') &&
    !s.includes('posterior')
  ) {
    matched.push('front-delts', 'side-delts');
  }
  if (s.includes('upper trap') || s.includes('levator') || (s.includes('trap') && !s.includes('mid') && !s.includes('lower'))) {
    matched.push('traps');
  }
  if (
    s.includes('rhomboid') ||
    s.includes('middle trap') ||
    s.includes('mid trap') ||
    s.includes('lower trap') ||
    s.includes('upper back') ||
    s.includes('infraspinatus') ||
    s.includes('teres minor') ||
    s.includes('rotator cuff') ||
    s.includes('subscapularis') ||
    s.includes('thoracic') ||
    s.includes('scapula')
  ) {
    matched.push('mid-back');
  }
  if (s.includes('latissimus') || s.includes('lats') || s.includes('lat ') || s.includes('teres major')) {
    matched.push('lats');
  }
  if (
    s.includes('erector') ||
    s.includes('lower back') ||
    s.includes('lumbar') ||
    s.includes('spinal') ||
    s.includes('posterior chain')
  ) {
    matched.push('lower-back');
  }
  if (s.includes('bicep') || s.includes('brachialis')) {
    matched.push('biceps');
  }
  if (s.includes('tricep') || s.includes('anconeus')) {
    matched.push('triceps');
  }
  if (
    s.includes('forearm') ||
    s.includes('brachioradialis') ||
    s.includes('wrist') ||
    s.includes('finger') ||
    s.includes('grip') ||
    s.includes('flexor') ||
    s.includes('extensor')
  ) {
    if (!s.includes('hip flexor')) {
      matched.push('forearms');
    }
  }
  if (
    s.includes('abdomin') ||
    s.includes('rectus') ||
    s.includes('transverse') ||
    s.includes('core') ||
    s.includes('six-pack')
  ) {
    if (!s.includes('rectus femoris')) {
      matched.push('abs');
    }
  }
  if (
    s.includes('oblique') ||
    s.includes('serratus') ||
    s.includes('quadratus lumborum') ||
    s.includes('rotational')
  ) {
    matched.push('obliques');
  }
  if (s.includes('glute') || s.includes('abductor') || s.includes('tensor fasciae')) {
    matched.push('glutes');
  }
  if (
    s.includes('quad') ||
    s.includes('vastus') ||
    s.includes('rectus femoris') ||
    s.includes('patellar')
  ) {
    matched.push('quads');
  }
  if (s.includes('adductor') || s.includes('hip flexor') || s.includes('iliopsoas') || s.includes('psoas') || s.includes('hips')) {
    matched.push('adductors');
    if (s.includes('hip flexor') || s.includes('iliopsoas') || s.includes('psoas')) {
      matched.push('abs');
    }
  }
  if (
    s.includes('hamstring') ||
    s.includes('biceps femoris') ||
    s.includes('semitendinosus') ||
    s.includes('semimembranosus')
  ) {
    matched.push('hamstrings');
  }
  if (
    s.includes('calf') ||
    s.includes('calves') ||
    s.includes('gastrocnemius') ||
    s.includes('soleus') ||
    s.includes('tibialis') ||
    s.includes('achilles') ||
    s.includes('ankle')
  ) {
    matched.push('calves');
  }

  return Array.from(new Set(matched));
}

export interface ResolvedMuscleHighlight {
  primary: Set<MuscleGroupId>;
  secondary: Set<MuscleGroupId>;
}

/**
 * Resolves primary & secondary muscles for a single Exercise or list of Exercises.
 */
export function resolveMuscleHighlights(
  exercise?: Exercise | null,
  exercisesList?: Exercise[],
  rawMuscleNames?: string[]
): ResolvedMuscleHighlight {
  const primary = new Set<MuscleGroupId>();
  const secondary = new Set<MuscleGroupId>();

  if (exercise) {
    exercise.targetMuscles.forEach((m, index) => {
      const groups = mapMuscleStringToGroups(m);
      groups.forEach((g) => {
        if (index <= 1) {
          primary.add(g);
        } else if (!primary.has(g)) {
          secondary.add(g);
        }
      });
    });

    // Add natural synergistic secondary muscles if only 1 group was matched
    if (primary.has('chest') && !primary.has('triceps') && !secondary.has('triceps')) {
      secondary.add('front-delts');
      secondary.add('triceps');
    }
    if (primary.has('lats') && !primary.has('biceps') && !secondary.has('biceps')) {
      secondary.add('mid-back');
      secondary.add('biceps');
    }
  } else if (exercisesList && exercisesList.length > 0) {
    const scoreMap = new Map<MuscleGroupId, number>();
    exercisesList.forEach((ex) => {
      ex.targetMuscles.forEach((m, idx) => {
        const weight = idx === 0 ? 3 : idx === 1 ? 2 : 1;
        const groups = mapMuscleStringToGroups(m);
        groups.forEach((g) => {
          scoreMap.set(g, (scoreMap.get(g) || 0) + weight);
        });
      });
    });

    const entries = Array.from(scoreMap.entries()).sort((a, b) => b[1] - a[1]);
    const maxScore = entries[0]?.[1] || 1;

    entries.forEach(([group, score], idx) => {
      if (score >= Math.max(2, maxScore * 0.45) || idx < 3) {
        primary.add(group);
      } else {
        secondary.add(group);
      }
    });
  } else if (rawMuscleNames && rawMuscleNames.length > 0) {
    rawMuscleNames.forEach((m, idx) => {
      const groups = mapMuscleStringToGroups(m);
      groups.forEach((g) => {
        if (idx <= 1) primary.add(g);
        else if (!primary.has(g)) secondary.add(g);
      });
    });
  }

  return { primary, secondary };
}

interface MuscleMapCharacterProps {
  exercise?: Exercise | null;
  exercises?: Exercise[];
  customMuscleNames?: string[];
  size?: 'sm' | 'md' | 'lg';
  showLegend?: boolean;
  interactive?: boolean;
  selectedMuscleGroup?: MuscleGroupId | null;
  onSelectMuscleGroup?: (group: MuscleGroupId | null) => void;
  title?: string;
  subtitle?: string;
}

export const MuscleMapCharacter: React.FC<MuscleMapCharacterProps> = ({
  exercise,
  exercises,
  customMuscleNames,
  size = 'md',
  showLegend = true,
  interactive = false,
  selectedMuscleGroup = null,
  onSelectMuscleGroup,
  title,
  subtitle
}) => {
  const uid = useId().replace(/:/g, '');
  const { primary, secondary } = resolveMuscleHighlights(exercise, exercises, customMuscleNames);

  // If interactive filter mode is active with a selected muscle group, highlight that group
  if (selectedMuscleGroup) {
    primary.add(selectedMuscleGroup);
  }

  const getMuscleStyle = (group: MuscleGroupId, baseShade: 'light' | 'mid' | 'dark' = 'mid') => {
    const isPrimary = primary.has(group);
    const isSecondary = !isPrimary && secondary.has(group);

    const baseFill =
      baseShade === 'light'
        ? '#242d40'
        : baseShade === 'dark'
        ? '#181f2e'
        : '#1e2638';

    if (isPrimary) {
      return {
        fill: `url(#primaryCyan_${uid})`,
        stroke: '#a5f3fc',
        strokeWidth: 1.35,
        filter: `url(#cyanGlow_${uid})`
      };
    }

    if (isSecondary) {
      return {
        fill: `url(#secondaryCyan_${uid})`,
        stroke: '#22d3ee',
        strokeWidth: 1.15,
        filter: 'none'
      };
    }

    return {
      fill: baseFill,
      stroke: '#0d111a',
      strokeWidth: 1.1,
      filter: 'none'
    };
  };

  const handleGroupClick = (group: MuscleGroupId) => {
    if (!interactive || !onSelectMuscleGroup) return;
    onSelectMuscleGroup(selectedMuscleGroup === group ? null : group);
  };

  const interactiveCursor = interactive ? 'cursor-pointer hover:opacity-90 transition-opacity' : '';

  const heightClass =
    size === 'sm'
      ? 'h-44 sm:h-48'
      : size === 'lg'
      ? 'h-72 sm:h-80'
      : 'h-56 sm:h-64';

  const primaryList = Array.from(primary);
  const secondaryList = Array.from(secondary);

  return (
    <div className="rounded-2xl bg-[#090b10] border border-neutral-800/90 p-3.5 relative overflow-hidden">
      {/* Ambient Cyan Backlight Glow */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          background:
            'radial-gradient(circle at 28% 38%, rgba(6, 182, 212, 0.22), transparent 55%), radial-gradient(circle at 72% 38%, rgba(8, 145, 178, 0.2), transparent 55%)'
        }}
      />

      {/* Optional Header */}
      {(title || subtitle) && (
        <div className="relative z-10 flex items-center justify-between mb-2 pb-2 border-b border-neutral-800/70">
          <div>
            {title && <h4 className="text-xs font-bold text-white tracking-wide">{title}</h4>}
            {subtitle && <p className="text-[11px] text-slate-400">{subtitle}</p>}
          </div>
          {interactive && selectedMuscleGroup && onSelectMuscleGroup && (
            <button
              type="button"
              onClick={() => onSelectMuscleGroup(null)}
              className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300"
            >
              Reset Muscle ({MUSCLE_GROUP_LABELS[selectedMuscleGroup].split(' ')[0]})
            </button>
          )}
        </div>
      )}

      {/* Front & Back Labels */}
      <div className="relative z-10 grid grid-cols-2 text-center mb-1">
        <span className="text-[10px] font-semibold uppercase tracking-widest text-slate-400">
          Front View
        </span>
        <span className="text-[10px] font-semibold uppercase tracking-widest text-slate-400">
          Back View
        </span>
      </div>

      {/* Dual Front & Back Anatomical Character SVG */}
      <div className={`relative z-10 w-full ${heightClass} flex items-center justify-center`}>
        <svg
          viewBox="0 0 520 430"
          className="w-full h-full max-w-[460px] select-none"
          role="img"
          aria-label="Front and back anatomical muscle map character"
        >
          <defs>
            {/* Primary Active Muscle Gradient (Vibrant Electric Cyan) */}
            <linearGradient id={`primaryCyan_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#67e8f9" />
              <stop offset="45%" stopColor="#22d3ee" />
              <stop offset="100%" stopColor="#0891b2" />
            </linearGradient>

            {/* Secondary Active Muscle Gradient (Deep Cyan-Teal) */}
            <linearGradient id={`secondaryCyan_${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.72" />
              <stop offset="100%" stopColor="#0e7490" stopOpacity="0.82" />
            </linearGradient>

            {/* Base Silhouette Body Gradient */}
            <linearGradient id={`bodyBase_${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#263044" />
              <stop offset="100%" stopColor="#181f2c" />
            </linearGradient>

            {/* Cyan Neon Glow Filter */}
            <filter id={`cyanGlow_${uid}`} x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="3.2" floodColor="#22d3ee" floodOpacity="0.55" />
            </filter>
          </defs>

          {/* ============================================================
              LEFT CHARACTER: ANTERIOR (FRONT) VIEW (Center X = 135)
             ============================================================ */}
          <g id="front-character">
            {/* Base Silhouette Underlay (Head, Neck, Hands, Knees, Feet) */}
            {/* Neck Base */}
            <path
              d="M 121 63 L 120 82 L 150 82 L 149 63 Z"
              fill="#232c3f"
              stroke="#475569"
              strokeWidth="1.5"
            />
            {/* Ears */}
            <ellipse cx="112" cy="46" rx="4.5" ry="6" fill="#232c3f" stroke="#475569" strokeWidth="1.5" />
            <ellipse cx="158" cy="46" rx="4.5" ry="6" fill="#232c3f" stroke="#475569" strokeWidth="1.5" />
            {/* Faceless Head Contour */}
            <path
              d="M 114 36 C 113 53, 121 68, 135 69 C 149 68, 157 53, 156 36 C 156 24, 147 18, 135 18 C 123 18, 114 24, 114 36 Z"
              fill="#252f42"
              stroke="#475569"
              strokeWidth="1.8"
            />
            {/* Stylized Swooping Hair (Matches Reference Screenshot) */}
            <path
              d="M 112 40 C 107 32, 110 21, 117 18 C 121 9, 138 7, 148 11 C 151 9, 154 6, 155 4 C 156 9, 154 14, 151 16 C 159 19, 162 28, 158 36 C 159 38, 160 40, 157 42 C 153 41, 151 42, 150 38 C 150 33, 149 29, 145 29 C 137 30, 125 29, 119 26 C 117 30, 117 35, 115 41 Z"
              fill="#2d384f"
              stroke="#475569"
              strokeWidth="1.6"
              strokeLinejoin="round"
            />

            {/* Left & Right Hands (Non-muscle extremities) */}
            <path
              d="M 55 198 C 48 202, 43 209, 41 213 C 40 215, 43 217, 47 213 C 45 221, 46 232, 53 234 C 60 236, 66 231, 67 221 C 68 212, 65 203, 62 199 Z"
              fill="#252f42"
              stroke="#475569"
              strokeWidth="1.6"
            />
            <path
              d="M 215 198 C 222 202, 227 209, 229 213 C 230 215, 227 217, 223 213 C 225 221, 224 232, 217 234 C 210 236, 204 231, 203 221 C 202 212, 205 203, 208 199 Z"
              fill="#252f42"
              stroke="#475569"
              strokeWidth="1.6"
            />

            {/* Left & Right Knees / Shins / Feet Base Silhouette */}
            <path
              d="M 92 292 C 88 302, 89 312, 93 320 L 98 390 L 82 405 C 77 410, 79 417, 89 417 L 116 411 C 120 410, 121 404, 118 396 L 116 320 C 118 310, 118 300, 116 292 Z"
              fill="#232c3f"
              stroke="#475569"
              strokeWidth="1.6"
            />
            <path
              d="M 178 292 C 182 302, 181 312, 177 320 L 172 390 L 188 405 C 193 410, 191 417, 181 417 L 154 411 C 150 410, 149 404, 152 396 L 154 320 C 152 310, 152 300, 154 292 Z"
              fill="#232c3f"
              stroke="#475569"
              strokeWidth="1.6"
            />

            {/* 1. TRAPS (FRONT UPPER TRAPEZIUS & NECK) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('traps')}
            >
              <title>{MUSCLE_GROUP_LABELS.traps}</title>
              {/* Left Trap */}
              <path
                d="M 120 69 L 97 79 C 105 83, 116 86, 126 86 L 122 69 Z"
                style={getMuscleStyle('traps', 'light')}
              />
              {/* Right Trap */}
              <path
                d="M 150 69 L 173 79 C 165 83, 154 86, 144 86 L 148 69 Z"
                style={getMuscleStyle('traps', 'light')}
              />
              {/* Sternocleidomastoid V-neck */}
              <path
                d="M 122 67 L 134 87 L 130 68 Z"
                style={getMuscleStyle('traps', 'mid')}
              />
              <path
                d="M 148 67 L 136 87 L 140 68 Z"
                style={getMuscleStyle('traps', 'mid')}
              />
            </g>

            {/* 2. CHEST (PECTORALIS MAJOR - UPPER CLAVICULAR & MAIN STERNAL PLATES) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('chest')}
            >
              <title>{MUSCLE_GROUP_LABELS.chest}</title>
              {/* Left Upper/Main Pec */}
              <path
                d="M 99 84 C 110 84, 124 87, 134 91 L 134 120 C 120 121, 104 119, 92 113 C 93 101, 95 90, 99 84 Z"
                style={getMuscleStyle('chest', 'mid')}
              />
              {/* Right Upper/Main Pec */}
              <path
                d="M 171 84 C 160 84, 146 87, 136 91 L 136 120 C 150 121, 166 119, 178 113 C 177 101, 175 90, 171 84 Z"
                style={getMuscleStyle('chest', 'mid')}
              />
              {/* Left Lower Costal Pec Sweep */}
              <path
                d="M 92 114 C 104 120, 120 122, 133 121 C 126 127, 115 135, 108 142 C 101 135, 95 125, 92 114 Z"
                style={getMuscleStyle('chest', 'dark')}
              />
              {/* Right Lower Costal Pec Sweep */}
              <path
                d="M 178 114 C 166 120, 150 122, 137 121 C 144 127, 155 135, 162 142 C 169 135, 175 125, 178 114 Z"
                style={getMuscleStyle('chest', 'dark')}
              />
            </g>

            {/* 3. FRONT DELTS (ANTERIOR DELTOID FEATHERS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('front-delts')}
            >
              <title>{MUSCLE_GROUP_LABELS['front-delts']}</title>
              {/* Left Anterior Delt */}
              <path
                d="M 98 81 C 90 85, 84 95, 84 113 C 88 113, 91 112, 93 108 C 95 98, 97 89, 98 81 Z"
                style={getMuscleStyle('front-delts', 'mid')}
              />
              {/* Right Anterior Delt */}
              <path
                d="M 172 81 C 180 85, 186 95, 186 113 C 182 113, 179 112, 177 108 C 175 98, 173 89, 172 81 Z"
                style={getMuscleStyle('front-delts', 'mid')}
              />
            </g>

            {/* 4. SIDE DELTS (LATERAL DELTOID CAPS - OUTER 2 SEGMENTS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('side-delts')}
            >
              <title>{MUSCLE_GROUP_LABELS['side-delts']}</title>
              {/* Left Mid & Outer Deltoid */}
              <path
                d="M 96 79 C 84 80, 75 90, 76 112 C 79 114, 82 114, 84 112 C 84 95, 90 85, 96 79 Z"
                style={getMuscleStyle('side-delts', 'light')}
              />
              <path
                d="M 91 79 C 78 81, 71 93, 72 110 C 74 112, 76 112, 77 110 C 76 92, 83 82, 91 79 Z"
                style={getMuscleStyle('side-delts', 'mid')}
              />
              {/* Right Mid & Outer Deltoid */}
              <path
                d="M 174 79 C 186 80, 195 90, 194 112 C 191 114, 188 114, 186 112 C 186 95, 180 85, 174 79 Z"
                style={getMuscleStyle('side-delts', 'light')}
              />
              <path
                d="M 179 79 C 192 81, 199 93, 198 110 C 196 112, 194 112, 193 110 C 194 92, 187 82, 179 79 Z"
                style={getMuscleStyle('side-delts', 'mid')}
              />
            </g>

            {/* 5. BICEPS & BRACHIALIS (UPPER ARM FRONT) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('biceps')}
            >
              <title>{MUSCLE_GROUP_LABELS.biceps}</title>
              {/* Left Bicep Inner & Outer Heads */}
              <path
                d="M 85 114 C 79 122, 77 137, 81 151 C 87 151, 92 144, 93 130 C 93 122, 90 116, 85 114 Z"
                style={getMuscleStyle('biceps', 'mid')}
              />
              <path
                d="M 75 112 C 69 122, 68 136, 73 149 C 76 150, 79 150, 80 148 C 77 136, 78 122, 83 114 Z"
                style={getMuscleStyle('biceps', 'light')}
              />
              {/* Right Bicep Inner & Outer Heads */}
              <path
                d="M 185 114 C 191 122, 193 137, 189 151 C 183 151, 178 144, 177 130 C 177 122, 180 116, 185 114 Z"
                style={getMuscleStyle('biceps', 'mid')}
              />
              <path
                d="M 195 112 C 201 122, 202 136, 197 149 C 194 150, 191 150, 190 148 C 193 136, 192 122, 187 114 Z"
                style={getMuscleStyle('biceps', 'light')}
              />
            </g>

            {/* 6. FOREARMS (BRACHIORADIALIS & WRIST FLEXORS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('forearms')}
            >
              <title>{MUSCLE_GROUP_LABELS.forearms}</title>
              {/* Left Forearm Outer & Inner */}
              <path
                d="M 71 150 C 62 162, 57 180, 56 197 L 63 199 C 68 185, 74 168, 79 152 Z"
                style={getMuscleStyle('forearms', 'light')}
              />
              <path
                d="M 80 152 C 75 168, 69 185, 63 199 L 68 198 C 77 186, 84 170, 86 152 Z"
                style={getMuscleStyle('forearms', 'mid')}
              />
              {/* Right Forearm Outer & Inner */}
              <path
                d="M 199 150 C 208 162, 213 180, 214 197 L 207 199 C 202 185, 196 168, 191 152 Z"
                style={getMuscleStyle('forearms', 'light')}
              />
              <path
                d="M 190 152 C 195 168, 201 185, 207 199 L 202 198 C 193 186, 186 170, 184 152 Z"
                style={getMuscleStyle('forearms', 'mid')}
              />
            </g>

            {/* 7. ABS (RECTUS ABDOMINIS 6-PACK + LOWER AB V-TAPER) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('abs')}
            >
              <title>{MUSCLE_GROUP_LABELS.abs}</title>
              {/* Upper Abs Pair */}
              <path
                d="M 121 128 C 125 124, 130 123, 134 125 L 134 143 L 119 142 C 119 136, 120 131, 121 128 Z"
                style={getMuscleStyle('abs', 'mid')}
              />
              <path
                d="M 149 128 C 145 124, 140 123, 136 125 L 136 143 L 151 142 C 151 136, 150 131, 149 128 Z"
                style={getMuscleStyle('abs', 'mid')}
              />
              {/* Mid Abs Pair */}
              <rect
                x="119"
                y="145"
                width="15"
                height="16"
                rx="3"
                style={getMuscleStyle('abs', 'light')}
              />
              <rect
                x="136"
                y="145"
                width="15"
                height="16"
                rx="3"
                style={getMuscleStyle('abs', 'light')}
              />
              {/* Lower Abs Pair */}
              <rect
                x="120"
                y="163"
                width="14"
                height="15"
                rx="3"
                style={getMuscleStyle('abs', 'mid')}
              />
              <rect
                x="136"
                y="163"
                width="14"
                height="15"
                rx="3"
                style={getMuscleStyle('abs', 'mid')}
              />
              {/* Lower Abdominal V-Point */}
              <path
                d="M 121 180 L 134 180 L 134 206 C 127 201, 122 191, 121 180 Z"
                style={getMuscleStyle('abs', 'dark')}
              />
              <path
                d="M 149 180 L 136 180 L 136 206 C 143 201, 148 191, 149 180 Z"
                style={getMuscleStyle('abs', 'dark')}
              />
            </g>

            {/* 8. OBLIQUES & SERRATUS ANTERIOR (FLANKING RIBCAGE & WAIST) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('obliques')}
            >
              <title>{MUSCLE_GROUP_LABELS.obliques}</title>
              {/* Left Serratus & Oblique */}
              <path
                d="M 107 142 C 112 135, 116 131, 118 130 L 118 182 C 114 190, 118 199, 125 205 C 114 199, 107 185, 106 168 C 105 158, 105 149, 107 142 Z"
                style={getMuscleStyle('obliques', 'dark')}
              />
              {/* Right Serratus & Oblique */}
              <path
                d="M 163 142 C 158 135, 154 131, 152 130 L 152 182 C 156 190, 152 199, 145 205 C 156 199, 163 185, 164 168 C 165 158, 165 149, 163 142 Z"
                style={getMuscleStyle('obliques', 'dark')}
              />
            </g>

            {/* 9. ADDUCTORS & HIP FLEXORS (INNER THIGH / PECTINEUS / SARTORIUS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('adductors')}
            >
              <title>{MUSCLE_GROUP_LABELS.adductors}</title>
              {/* Left Inner Thigh */}
              <path
                d="M 106 196 C 114 204, 123 209, 131 212 C 129 235, 124 256, 119 272 C 115 248, 110 222, 106 196 Z"
                style={getMuscleStyle('adductors', 'dark')}
              />
              {/* Right Inner Thigh */}
              <path
                d="M 164 196 C 156 204, 147 209, 139 212 C 141 235, 146 256, 151 272 C 155 248, 160 222, 164 196 Z"
                style={getMuscleStyle('adductors', 'dark')}
              />
            </g>

            {/* 10. QUADRICEPS (RECTUS FEMORIS, VASTUS LATERALIS, VASTUS MEDIALIS TEARDROP) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('quads')}
            >
              <title>{MUSCLE_GROUP_LABELS.quads}</title>
              {/* Left Vastus Lateralis (Outer Quad Sweep) */}
              <path
                d="M 103 195 C 90 212, 84 242, 91 285 C 95 276, 98 258, 101 232 C 102 215, 103 203, 103 195 Z"
                style={getMuscleStyle('quads', 'light')}
              />
              {/* Left Rectus Femoris (Center Quad) */}
              <path
                d="M 104 198 C 101 224, 98 258, 95 288 L 105 288 C 110 262, 112 230, 104 198 Z"
                style={getMuscleStyle('quads', 'mid')}
              />
              {/* Left Vastus Medialis (Inner VMO Teardrop) */}
              <path
                d="M 113 255 C 108 266, 106 280, 108 292 C 114 292, 119 283, 119 272 C 118 264, 116 259, 113 255 Z"
                style={getMuscleStyle('quads', 'light')}
              />

              {/* Right Vastus Lateralis (Outer Quad Sweep) */}
              <path
                d="M 167 195 C 180 212, 186 242, 179 285 C 175 276, 172 258, 169 232 C 168 215, 167 203, 167 195 Z"
                style={getMuscleStyle('quads', 'light')}
              />
              {/* Right Rectus Femoris (Center Quad) */}
              <path
                d="M 166 198 C 169 224, 172 258, 175 288 L 165 288 C 160 262, 158 230, 166 198 Z"
                style={getMuscleStyle('quads', 'mid')}
              />
              {/* Right Vastus Medialis (Inner VMO Teardrop) */}
              <path
                d="M 157 255 C 162 266, 164 280, 162 292 C 156 292, 151 283, 151 272 C 152 264, 154 259, 157 255 Z"
                style={getMuscleStyle('quads', 'light')}
              />
            </g>

            {/* 11. CALVES & SHINS (FRONT TIBIALIS & INNER GASTROCNEMIUS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('calves')}
            >
              <title>{MUSCLE_GROUP_LABELS.calves}</title>
              {/* Left Outer Tibialis & Inner Calf */}
              <path
                d="M 92 318 C 85 335, 86 362, 95 385 L 102 385 C 101 360, 100 335, 97 318 Z"
                style={getMuscleStyle('calves', 'mid')}
              />
              <path
                d="M 105 318 C 104 342, 106 366, 111 385 C 119 365, 121 340, 115 318 Z"
                style={getMuscleStyle('calves', 'light')}
              />
              {/* Right Outer Tibialis & Inner Calf */}
              <path
                d="M 178 318 C 185 335, 184 362, 175 385 L 168 385 C 169 360, 170 335, 173 318 Z"
                style={getMuscleStyle('calves', 'mid')}
              />
              <path
                d="M 165 318 C 166 342, 164 366, 159 385 C 151 365, 149 340, 155 318 Z"
                style={getMuscleStyle('calves', 'light')}
              />
            </g>
          </g>

          {/* ============================================================
              RIGHT CHARACTER: POSTERIOR (BACK) VIEW (Center X = 385)
             ============================================================ */}
          <g id="back-character">
            {/* Back of Head, Ears, and Hair Silhouette */}
            <ellipse cx="362" cy="46" rx="4.5" ry="6" fill="#232c3f" stroke="#475569" strokeWidth="1.5" />
            <ellipse cx="408" cy="46" rx="4.5" ry="6" fill="#232c3f" stroke="#475569" strokeWidth="1.5" />
            {/* Nape of Neck Base */}
            <path
              d="M 370 56 L 369 66 L 401 66 L 400 56 Z"
              fill="#252f42"
              stroke="#475569"
              strokeWidth="1.6"
            />
            {/* Back Hair (Full back-of-head hair matching reference screenshot) */}
            <path
              d="M 364 56 C 358 45, 357 26, 367 18 C 371 9, 388 7, 398 11 C 401 9, 404 6, 405 4 C 406 9, 404 14, 401 16 C 409 19, 413 30, 408 42 C 409 46, 407 52, 405 56 Z"
              fill="#2d384f"
              stroke="#475569"
              strokeWidth="1.7"
              strokeLinejoin="round"
            />

            {/* Back Left & Right Hands */}
            <path
              d="M 305 198 C 298 202, 293 209, 291 213 C 290 215, 293 217, 297 213 C 295 221, 296 232, 303 234 C 310 236, 316 231, 317 221 C 318 212, 315 203, 312 199 Z"
              fill="#252f42"
              stroke="#475569"
              strokeWidth="1.6"
            />
            <path
              d="M 465 198 C 472 202, 477 209, 479 213 C 480 215, 477 217, 473 213 C 475 221, 474 232, 467 234 C 460 236, 454 231, 453 221 C 452 212, 455 203, 458 199 Z"
              fill="#252f42"
              stroke="#475569"
              strokeWidth="1.6"
            />

            {/* Back Knees, Ankles & Heels Base */}
            <path
              d="M 342 292 L 348 390 L 336 402 C 331 407, 335 415, 344 416 L 364 416 C 369 415, 370 409, 367 396 L 366 292 Z"
              fill="#232c3f"
              stroke="#475569"
              strokeWidth="1.6"
            />
            <path
              d="M 428 292 L 422 390 L 434 402 C 439 407, 435 415, 426 416 L 406 416 C 401 415, 400 409, 403 396 L 404 292 Z"
              fill="#232c3f"
              stroke="#475569"
              strokeWidth="1.6"
            />

            {/* 1. TRAPS (UPPER TRAPEZIUS HOOD ON BACK) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('traps')}
            >
              <title>{MUSCLE_GROUP_LABELS.traps}</title>
              <path
                d="M 369 66 L 345 79 C 358 83, 371 88, 384 92 L 384 66 Z"
                style={getMuscleStyle('traps', 'light')}
              />
              <path
                d="M 401 66 L 425 79 C 412 83, 399 88, 386 92 L 386 66 Z"
                style={getMuscleStyle('traps', 'light')}
              />
            </g>

            {/* 2. MID-BACK (MIDDLE/LOWER TRAPEZIUS DIAMOND, RHOMBOIDS, INFRASPINATUS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('mid-back')}
            >
              <title>{MUSCLE_GROUP_LABELS['mid-back']}</title>
              {/* Left Mid/Lower Trap Diamond */}
              <path
                d="M 360 86 L 384 92 L 384 146 C 376 130, 368 108, 360 86 Z"
                style={getMuscleStyle('mid-back', 'mid')}
              />
              {/* Right Mid/Lower Trap Diamond */}
              <path
                d="M 410 86 L 386 92 L 386 146 C 394 130, 402 108, 410 86 Z"
                style={getMuscleStyle('mid-back', 'mid')}
              />
              {/* Left Infraspinatus / Teres Minor Plate */}
              <path
                d="M 347 104 C 354 98, 361 95, 366 99 C 369 109, 369 118, 364 123 C 356 120, 350 113, 347 104 Z"
                style={getMuscleStyle('mid-back', 'light')}
              />
              {/* Right Infraspinatus / Teres Minor Plate */}
              <path
                d="M 423 104 C 416 98, 409 95, 404 99 C 401 109, 401 118, 406 123 C 414 120, 420 113, 423 104 Z"
                style={getMuscleStyle('mid-back', 'light')}
              />
            </g>

            {/* 3. REAR DELTS & SIDE DELTS ON BACK */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('rear-delts')}
            >
              <title>{MUSCLE_GROUP_LABELS['rear-delts']}</title>
              {/* Left Posterior Deltoid */}
              <path
                d="M 346 80 C 354 83, 361 90, 364 98 C 355 103, 344 107, 333 110 C 334 95, 339 85, 346 80 Z"
                style={getMuscleStyle('rear-delts', 'mid')}
              />
              {/* Right Posterior Deltoid */}
              <path
                d="M 424 80 C 416 83, 409 90, 406 98 C 415 103, 426 107, 437 110 C 436 95, 431 85, 424 80 Z"
                style={getMuscleStyle('rear-delts', 'mid')}
              />
            </g>

            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('side-delts')}
            >
              <title>{MUSCLE_GROUP_LABELS['side-delts']}</title>
              {/* Left Lateral Deltoid Cap (Back View) */}
              <path
                d="M 344 79 C 331 81, 322 93, 323 111 C 327 112, 330 111, 333 109 C 334 94, 338 84, 344 79 Z"
                style={getMuscleStyle('side-delts', 'light')}
              />
              {/* Right Lateral Deltoid Cap (Back View) */}
              <path
                d="M 426 79 C 439 81, 448 93, 447 111 C 443 112, 440 111, 437 109 C 436 94, 432 84, 426 79 Z"
                style={getMuscleStyle('side-delts', 'light')}
              />
            </g>

            {/* 4. LATS (LATISSIMUS DORSI V-TAPER WINGS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('lats')}
            >
              <title>{MUSCLE_GROUP_LABELS.lats}</title>
              {/* Left Lat Wing */}
              <path
                d="M 346 112 C 354 118, 363 124, 373 128 L 383 152 L 383 176 C 372 168, 361 162, 355 156 C 351 142, 347 127, 346 112 Z"
                style={getMuscleStyle('lats', 'mid')}
              />
              {/* Right Lat Wing */}
              <path
                d="M 424 112 C 416 118, 407 124, 397 128 L 387 152 L 387 176 C 398 168, 409 162, 415 156 C 419 142, 423 127, 424 112 Z"
                style={getMuscleStyle('lats', 'mid')}
              />
            </g>

            {/* 5. LOWER BACK (ERECTOR SPINAE / THORACOLUMBAR) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('lower-back')}
            >
              <title>{MUSCLE_GROUP_LABELS['lower-back']}</title>
              {/* Left Lumbar Erector */}
              <path
                d="M 356 158 C 365 164, 374 170, 384 177 L 384 206 C 374 198, 364 192, 355 190 C 356 178, 356 168, 356 158 Z"
                style={getMuscleStyle('lower-back', 'dark')}
              />
              {/* Right Lumbar Erector */}
              <path
                d="M 414 158 C 405 164, 396 170, 386 177 L 386 206 C 396 198, 406 192, 415 190 C 414 178, 414 168, 414 158 Z"
                style={getMuscleStyle('lower-back', 'dark')}
              />
            </g>

            {/* 6. TRICEPS (HORSESHOE LATERAL & LONG HEADS - MATCHES REFERENCE SCREENSHOT) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('triceps')}
            >
              <title>{MUSCLE_GROUP_LABELS.triceps}</title>
              {/* Left Tricep Lateral Head (Outer) */}
              <path
                d="M 332 109 C 323 118, 318 132, 319 150 C 323 145, 327 137, 331 129 C 333 122, 333 115, 332 109 Z"
                style={getMuscleStyle('triceps', 'light')}
              />
              {/* Left Tricep Long Head (Inner) */}
              <path
                d="M 334 111 C 332 125, 330 139, 333 153 C 339 147, 343 135, 344 118 C 342 114, 338 112, 334 111 Z"
                style={getMuscleStyle('triceps', 'mid')}
              />
              {/* Right Tricep Lateral Head (Outer) */}
              <path
                d="M 438 109 C 447 118, 452 132, 451 150 C 447 145, 443 137, 439 129 C 437 122, 437 115, 438 109 Z"
                style={getMuscleStyle('triceps', 'light')}
              />
              {/* Right Tricep Long Head (Inner) */}
              <path
                d="M 436 111 C 438 125, 440 139, 437 153 C 431 147, 427 135, 426 118 C 428 114, 432 112, 436 111 Z"
                style={getMuscleStyle('triceps', 'mid')}
              />
            </g>

            {/* 7. POSTERIOR FOREARMS */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('forearms')}
            >
              <title>{MUSCLE_GROUP_LABELS.forearms}</title>
              {/* Left Forearm Extensors */}
              <path
                d="M 320 150 C 312 163, 307 180, 306 197 L 313 199 C 318 184, 324 166, 330 148 Z"
                style={getMuscleStyle('forearms', 'light')}
              />
              <path
                d="M 330 148 C 325 166, 319 184, 313 199 L 318 198 C 327 186, 334 170, 336 152 Z"
                style={getMuscleStyle('forearms', 'mid')}
              />
              {/* Right Forearm Extensors */}
              <path
                d="M 450 150 C 458 163, 463 180, 464 197 L 457 199 C 452 184, 446 166, 440 148 Z"
                style={getMuscleStyle('forearms', 'light')}
              />
              <path
                d="M 440 148 C 445 166, 451 184, 457 199 L 452 198 C 443 186, 436 170, 434 152 Z"
                style={getMuscleStyle('forearms', 'mid')}
              />
            </g>

            {/* 8. GLUTES (GLUTEUS MEDIUS & GLUTEUS MAXIMUS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('glutes')}
            >
              <title>{MUSCLE_GROUP_LABELS.glutes}</title>
              {/* Left Gluteus Medius & Maximus */}
              <path
                d="M 354 190 C 344 199, 339 214, 340 232 C 350 242, 371 243, 384 232 L 384 206 C 374 198, 364 192, 354 190 Z"
                style={getMuscleStyle('glutes', 'mid')}
              />
              {/* Right Gluteus Medius & Maximus */}
              <path
                d="M 416 190 C 426 199, 431 214, 430 232 C 420 242, 399 243, 386 232 L 386 206 C 396 198, 406 192, 416 190 Z"
                style={getMuscleStyle('glutes', 'mid')}
              />
            </g>

            {/* 9. HAMSTRINGS (BICEPS FEMORIS & SEMITENDINOSUS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('hamstrings')}
            >
              <title>{MUSCLE_GROUP_LABELS.hamstrings}</title>
              {/* Left Outer & Inner Hamstring */}
              <path
                d="M 341 234 C 337 254, 339 276, 343 292 L 354 292 C 354 272, 354 252, 354 239 C 349 238, 344 236, 341 234 Z"
                style={getMuscleStyle('hamstrings', 'light')}
              />
              <path
                d="M 355 239 C 355 253, 355 273, 355 292 L 367 292 C 371 273, 374 252, 377 237 C 370 240, 362 241, 355 239 Z"
                style={getMuscleStyle('hamstrings', 'mid')}
              />
              {/* Right Outer & Inner Hamstring */}
              <path
                d="M 429 234 C 433 254, 431 276, 427 292 L 416 292 C 416 272, 416 252, 416 239 C 421 238, 426 236, 429 234 Z"
                style={getMuscleStyle('hamstrings', 'light')}
              />
              <path
                d="M 415 239 C 415 253, 415 273, 415 292 L 403 292 C 399 273, 396 252, 393 237 C 400 240, 408 241, 415 239 Z"
                style={getMuscleStyle('hamstrings', 'mid')}
              />
            </g>

            {/* 10. CALVES (GASTROCNEMIUS LATERAL & MEDIAL HEADS) */}
            <g
              className={interactiveCursor}
              onClick={() => handleGroupClick('calves')}
            >
              <title>{MUSCLE_GROUP_LABELS.calves}</title>
              {/* Left Outer & Inner Gastrocnemius */}
              <path
                d="M 342 312 C 335 330, 336 355, 345 372 L 354 370 C 354 348, 354 328, 353 312 Z"
                style={getMuscleStyle('calves', 'light')}
              />
              <path
                d="M 355 312 C 355 328, 355 348, 355 370 L 364 372 C 371 355, 371 330, 365 312 Z"
                style={getMuscleStyle('calves', 'mid')}
              />
              {/* Right Outer & Inner Gastrocnemius */}
              <path
                d="M 428 312 C 435 330, 434 355, 425 372 L 416 370 C 416 348, 416 328, 417 312 Z"
                style={getMuscleStyle('calves', 'light')}
              />
              <path
                d="M 415 312 C 415 328, 415 348, 415 370 L 406 372 C 399 355, 399 330, 405 312 Z"
                style={getMuscleStyle('calves', 'mid')}
              />
            </g>
          </g>
        </svg>
      </div>

      {/* Target Muscle Legend & Breakdown */}
      {showLegend && (primaryList.length > 0 || secondaryList.length > 0) && (
        <div className="relative z-10 mt-2 pt-2.5 border-t border-neutral-800/80 space-y-1.5">
          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-cyan-300 font-semibold">
                <span className="w-2.5 h-2.5 rounded-sm bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                Primary Target
              </span>
              {secondaryList.length > 0 && (
                <span className="flex items-center gap-1.5 text-slate-400 font-medium">
                  <span className="w-2.5 h-2.5 rounded-sm bg-cyan-700/80 border border-cyan-400/50" />
                  Secondary / Stabilizer
                </span>
              )}
            </div>
            {interactive && (
              <span className="text-[10px] text-slate-400">Tap any muscle on character to filter</span>
            )}
          </div>

          <div className="text-[11px] text-slate-300 leading-relaxed">
            <span className="text-cyan-400 font-semibold">
              {primaryList.map((g) => MUSCLE_GROUP_LABELS[g]).join(' · ')}
            </span>
            {secondaryList.length > 0 && (
              <span className="text-slate-400">
                {' '}
                · {secondaryList.map((g) => MUSCLE_GROUP_LABELS[g]).join(' · ')}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
