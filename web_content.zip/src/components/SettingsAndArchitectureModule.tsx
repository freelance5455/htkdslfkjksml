import React, { useState } from 'react';
import {
  Settings,
  Smartphone,
  Shield,
  Download,
  Trash2,
  LogIn,
  LogOut,
  CheckCircle2,
  Cpu,
  Database,
  Layers,
} from 'lucide-react';
import type { SupportedLanguage, VoiceProfileId } from '../types';
import { VOICE_PROFILES } from '../utils/rajuEngine';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface SettingsModuleProps {
  userEmail: string | null;
  displayName: string;
  onUpdateDisplayName: (name: string) => void;
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  selectedVoice: VoiceProfileId;
  onVoiceChange: (voice: VoiceProfileId) => void;
  thinkingLevel: 'LOW' | 'HIGH' | 'XHIGH';
  onThinkingLevelChange: (lvl: 'LOW' | 'HIGH' | 'XHIGH') => void;
  memoryConsent: boolean;
  onToggleMemoryConsent: (val: boolean) => void;
  totalTokensUsed: number;
  totalRequestsCount: number;
  onSignInGoogle: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onExportPersonalData: () => void;
  onDeleteAllUserData: () => Promise<void>;
}

export const SettingsAndArchitectureModule: React.FC<SettingsModuleProps> = ({
  userEmail,
  displayName,
  onUpdateDisplayName,
  language,
  onLanguageChange,
  selectedVoice,
  onVoiceChange,
  thinkingLevel,
  onThinkingLevelChange,
  memoryConsent,
  onToggleMemoryConsent,
  totalTokensUsed,
  totalRequestsCount,
  onSignInGoogle,
  onSignOut,
  onExportPersonalData,
  onDeleteAllUserData,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [nameInput, setNameInput] = useState(displayName);
  const [savedNotice, setSavedNotice] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (nameInput.trim()) {
      onUpdateDisplayName(nameInput.trim());
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 2500);
    }
  };

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-slate-800/80">
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Settings, Security, Android APK & Platform Architecture
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Configure Gemini 4 Hydrogen reasoning depth, cloud synchronization, privacy controls, PWA installation, and Capacitor Android packaging.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Account & AI Brain Configuration (6 cols) */}
        <div className="lg:col-span-6 space-y-5">
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Settings className="w-4 h-4 text-cyan-400" />
              Shared Account & Profile Preferences
            </h3>

            <div className="p-3.5 rounded-xl bg-[#060919] border border-slate-800 flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-white">
                  {userEmail ? `Signed in as ${userEmail}` : 'Local / Guest Mode Active'}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {userEmail
                    ? 'Synced with Firebase Cloud Firestore across Website, PWA & Android'
                    : 'Sign in with Google to synchronize conversations, memories, and tasks across devices.'}
                </p>
              </div>
              {userEmail ? (
                <button
                  type="button"
                  onClick={onSignOut}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onSignInGoogle}
                  className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-semibold text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  Google Sign-In
                </button>
              )}
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div>
                <label htmlFor="settings-name" className="block text-xs font-medium text-slate-300 mb-1">
                  Display Name
                </label>
                <div className="flex gap-2">
                  <input
                    id="settings-name"
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="flex-1 px-3.5 py-2 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                  >
                    Save
                  </button>
                </div>
                {savedNotice && (
                  <p className="text-xs text-emerald-300 mt-1">Profile display name updated!</p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="settings-lang" className="block text-xs font-medium text-slate-300 mb-1">
                    Primary Language
                  </label>
                  <select
                    id="settings-lang"
                    value={language}
                    onChange={(e) => onLanguageChange(e.target.value as SupportedLanguage)}
                    className="w-full px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
                  >
                    <option value="English">English</option>
                    <option value="Hindi">Hindi (हिंदी)</option>
                    <option value="Hinglish">Hinglish</option>
                    <option value="Japanese">Japanese (日本語)</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="settings-voice" className="block text-xs font-medium text-slate-300 mb-1">
                    Default Voice Persona
                  </label>
                  <select
                    id="settings-voice"
                    value={selectedVoice}
                    onChange={(e) => onVoiceChange(e.target.value as VoiceProfileId)}
                    className="w-full px-3 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
                  >
                    {VOICE_PROFILES.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.geminiVoice})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </form>
          </div>

          {/* Gemini 4 Hydrogen Brain & Token Usage Monitor */}
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-400" />
              AI Brain & Token Usage Monitor
            </h3>

            <div>
              <label htmlFor="settings-thinking" className="block text-xs font-medium text-slate-300 mb-1.5">
                Gemini 4 Hydrogen Thinking Depth (<span className="font-mono text-cyan-300">thinkingLevel</span>)
              </label>
              <select
                id="settings-thinking"
                value={thinkingLevel}
                onChange={(e) => onThinkingLevelChange(e.target.value as 'LOW' | 'HIGH' | 'XHIGH')}
                className="w-full px-3.5 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white"
              >
                <option value="LOW">LOW — Fastest response & lowest latency</option>
                <option value="HIGH">HIGH — Balanced intelligence & reasoning (Default)</option>
                <option value="XHIGH">XHIGH — Maximum multi-step reasoning depth</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-[#060919] border border-slate-800">
                <p className="text-xs text-slate-400">Session Tokens Processed</p>
                <p className="text-xl font-bold text-cyan-300 font-mono tabular-nums mt-1">
                  {totalTokensUsed.toLocaleString()}
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#060919] border border-slate-800">
                <p className="text-xs text-slate-400">API Requests Completed</p>
                <p className="text-xl font-bold text-purple-300 font-mono tabular-nums mt-1">
                  {totalRequestsCount.toLocaleString()}
                </p>
              </div>
            </div>
          </div>

          {/* Security & Privacy Controls */}
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              Security, Privacy & Data Sovereignty
            </h3>

            <label className="flex items-center justify-between p-3 rounded-xl bg-[#060919] border border-slate-800 cursor-pointer">
              <span className="text-xs text-slate-200">
                Allow RAJU AI to store and retrieve user-consented memories
              </span>
              <input
                type="checkbox"
                checked={memoryConsent}
                onChange={(e) => onToggleMemoryConsent(e.target.checked)}
                className="w-4 h-4 rounded border-slate-600 bg-slate-900 text-cyan-500"
              />
            </label>

            <div className="flex flex-wrap gap-2.5">
              <button
                type="button"
                onClick={onExportPersonalData}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-300"
              >
                <Download className="w-3.5 h-3.5" />
                Export All Personal Data (JSON)
              </button>

              {!deleteConfirm ? (
                <button
                  type="button"
                  onClick={() => setDeleteConfirm(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-950/60 border border-rose-500/40 hover:bg-rose-900/60 text-xs font-semibold text-rose-200"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete All Account Data
                </button>
              ) : (
                <button
                  type="button"
                  onClick={async () => {
                    await onDeleteAllUserData();
                    setDeleteConfirm(false);
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white"
                >
                  Confirm Permanent Data Wipe
                </button>
              )}
            </div>
          </div>
        </div>

        {/* PWA Installation & Capacitor Android APK Packaging Workflow (6 cols) */}
        <div className="lg:col-span-6 space-y-5">
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              Installable PWA & Android Packaging (Capacitor)
            </h3>

            <div className="p-4 rounded-xl bg-[#060919] border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-300">Progressive Web App (PWA) Status</span>
                <span className="text-xs text-emerald-300 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {isInstalled ? 'Installed Standalone' : 'Manifest & Service Worker Ready'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Install RAJU AI directly onto your Android, iOS, Windows, or macOS home screen for instant full-screen launch and offline asset caching.
              </p>
              {isInstallable && !isInstalled && (
                <button
                  type="button"
                  onClick={install}
                  className="mt-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 text-white text-xs font-semibold"
                >
                  Install RAJU AI App Now
                </button>
              )}
              {isIOS && !isInstalled && (
                <p className="text-xs text-amber-200 pt-1">
                  On iOS Safari: Tap <strong>Share</strong> → <strong>Add to Home Screen</strong>.
                </p>
              )}
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white">
                Android APK & Play Store App Bundle Build Workflow (<span className="font-mono text-cyan-300">capacitor.config.ts</span>)
              </h4>
              <p className="text-xs text-slate-400">
                Capacitor 8 is pre-configured (<span className="font-mono">com.rajuai.assistant</span>). To build a signed APK or Android App Bundle (.aab) locally with Android Studio / Gradle SDK:
              </p>
              <pre className="p-3.5 rounded-xl bg-[#060919] border border-slate-800 font-mono text-[11px] text-cyan-200 overflow-x-auto leading-relaxed">
{`# 1. Build production web bundle
npm run build

# 2. Initialize & sync Capacitor Android project
npx cap add android
npx cap sync android

# 3. Verify permissions in android/app/src/main/AndroidManifest.xml:
# <uses-permission android:name="android.permission.INTERNET" />
# <uses-permission android:name="android.permission.RECORD_AUDIO" />
# <uses-permission android:name="android.permission.ModifyAudioSettings" />

# 4. Build APK or Play Store Bundle (.aab)
cd android && ./gradlew assembleDebug
./gradlew bundleRelease`}
              </pre>
            </div>
          </div>

          {/* System Architecture & Security Summary */}
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              Unified Platform Architecture
            </h3>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="p-3 rounded-xl bg-[#060919] border border-slate-800 flex items-start gap-2.5">
                <Database className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white">Zero-Trust Firestore Database</p>
                  <p className="text-slate-400 mt-0.5">
                    Collections: <span className="font-mono text-cyan-300">/users</span>, <span className="font-mono text-cyan-300">/conversations</span>, <span className="font-mono text-cyan-300">/memories</span>, <span className="font-mono text-cyan-300">/tasks</span>, and <span className="font-mono text-cyan-300">/study_progress</span> protected by strict schema & ownership rules.
                  </p>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-[#060919] border border-slate-800 flex items-start gap-2.5">
                <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white">Server-Side API Key Isolation</p>
                  <p className="text-slate-400 mt-0.5">
                    All <span className="font-mono text-cyan-300">@google/genai</span> calls execute strictly on the Express/WebSocket backend. Zero API keys are ever exposed in browser bundles or Android APK assets.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
