import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

const stroke = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

export function HomeIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} {...props}>
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V21h14V9.5" />
      <path d="M10 21v-6h4v6" />
    </svg>
  );
}

export function ServersIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} {...props}>
      <rect x="3" y="4" width="18" height="7" rx="2" />
      <rect x="3" y="13" width="18" height="7" rx="2" />
      <path d="M7 7.5h.01M7 16.5h.01M17 7.5h.01M11 7.5h.01M17 16.5h.01M11 16.5h.01" strokeWidth="2.4" />
    </svg>
  );
}

export function FeedIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} {...props}>
      <path d="M4 11a9 9 0 0 1 9 9" />
      <path d="M4 4a16 16 0 0 1 16 16" />
      <circle cx="5.2" cy="18.8" r="1.7" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function SlidersIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} {...props}>
      <path d="M4 7h8.5M17.5 7H20M4 17h3.5M12.5 17H20" />
      <circle cx="15" cy="7" r="2.3" />
      <circle cx="10" cy="17" r="2.3" />
    </svg>
  );
}

export function BoltIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...props}>
      <path d="M13.2 2 4.6 13.4h6L9.4 22l9-11.9h-6L13.2 2Z" fill="currentColor" />
    </svg>
  );
}

export function CopyIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} strokeWidth={1.7} {...props}>
      <rect x="9" y="9" width="11.5" height="11.5" rx="2.5" />
      <path d="M5.5 14.5h-1A1.5 1.5 0 0 1 3 13V4.5A1.5 1.5 0 0 1 4.5 3H13a1.5 1.5 0 0 1 1.5 1.5v1" />
    </svg>
  );
}

export function CheckIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} strokeWidth={2.2} {...props}>
      <path d="m4.5 12.8 5 5L19.5 6" />
    </svg>
  );
}

export function RefreshIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} {...props}>
      <path d="M20 12a8 8 0 1 1-2.34-5.66" />
      <path d="M20 3.5V8h-4.5" />
    </svg>
  );
}

export function SearchIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} {...props}>
      <circle cx="11" cy="11" r="7" />
      <path d="m20.5 20.5-4-4" />
    </svg>
  );
}

export function XIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} strokeWidth={2} {...props}>
      <path d="M6 6l12 12M18 6 6 18" />
    </svg>
  );
}

export function SignalIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} strokeWidth={2.4} {...props}>
      <path d="M4.5 18v-2.5M9 18v-6M13.5 18v-9M18 18V6" />
    </svg>
  );
}

export function WifiIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} {...props}>
      <path d="M5 10.5a12 12 0 0 1 14 0" />
      <path d="M8.2 14a7.5 7.5 0 0 1 7.6 0" />
      <circle cx="12" cy="17.6" r="1.5" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function BatteryIcon(props: P) {
  return (
    <svg viewBox="0 0 24 24" {...stroke} strokeWidth={1.5} {...props}>
      <rect x="2.5" y="8" width="16.5" height="9" rx="2.5" />
      <path d="M21.5 11.5v2" strokeWidth="2.2" />
      <rect x="4.5" y="10" width="10" height="5" rx="1" fill="currentColor" stroke="none" />
    </svg>
  );
}
