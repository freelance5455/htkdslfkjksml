type IconProps = { className?: string };

export function SoundOnIcon({ className = "size-[18px]" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path
        d="M4 9.5h3.2L12 5.5v13L7.2 14.5H4a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1Z"
        fill="currentColor"
      />
      <path
        d="M15.8 9a4 4 0 0 1 0 6M18.4 6.6a7.5 7.5 0 0 1 0 10.8"
        stroke="currentColor"
        strokeWidth="1.9"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function SoundOffIcon({ className = "size-[18px]" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path
        d="M4 9.5h3.2L12 5.5v13L7.2 14.5H4a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1Z"
        fill="currentColor"
      />
      <path
        d="M16 9.6l4.6 4.8M20.6 9.6L16 14.4"
        stroke="currentColor"
        strokeWidth="1.9"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function TouchIcon({ className = "size-[18px]" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path
        d="M10 11V6.4a1.7 1.7 0 0 1 3.4 0V13"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      <path
        d="M13.4 10.6a1.5 1.5 0 0 1 3 0v1.2m0-.4a1.5 1.5 0 0 1 3 0v4.1a5.1 5.1 0 0 1-5.1 5.1h-1.5a5 5 0 0 1-4-2l-2.4-3.2a1.6 1.6 0 0 1 2.4-2.1L10 14.6"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function ArrowIcon({ className = "size-[18px]" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path
        d="M14 6l-6 6 6 6"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function CheckIcon({ className = "size-[18px]" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path
        d="M5 12.8l4.4 4.2L19 7.6"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function CoinIcon({ className = "size-4" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <circle cx="12" cy="12" r="9" fill="currentColor" opacity="0.95" />
      <circle cx="12" cy="12" r="6.4" fill="none" stroke="#fff" strokeOpacity="0.5" strokeWidth="1.3" />
      <path
        d="M12 8.2v7.6M10 10.1h3a1.7 1.7 0 0 1 0 3.4h-3"
        stroke="#fff"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}

export function CloseIcon({ className = "size-4" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path d="M6.5 6.5l11 11M17.5 6.5l-11 11" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

export function LockIcon({ className = "size-3" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <rect x="4.5" y="10.5" width="15" height="10" rx="3" fill="currentColor" />
      <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

export function BagIcon({ className = "size-4" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path
        d="M4.6 8.5h14.8l-1.1 10.2a2.4 2.4 0 0 1-2.4 2.1H8.1a2.4 2.4 0 0 1-2.4-2.1L4.6 8.5Z"
        fill="currentColor"
      />
      <path
        d="M8.8 9.4V6.9a3.2 3.2 0 0 1 6.4 0v2.5"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function SeedIcon({ className = "size-4" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <ellipse cx="8.4" cy="14.6" rx="3.1" ry="4.1" transform="rotate(-24 8.4 14.6)" fill="currentColor" />
      <ellipse cx="15.4" cy="15.2" rx="2.6" ry="3.5" transform="rotate(22 15.4 15.2)" fill="currentColor" opacity="0.75" />
      <ellipse cx="12.6" cy="7.6" rx="2.3" ry="3.1" transform="rotate(-8 12.6 7.6)" fill="currentColor" opacity="0.55" />
    </svg>
  );
}

export function BoltIcon({ className = "size-3.5" }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path d="M13.4 2.5L5 13.6h5.3L9.8 21.5 18.6 10h-5.6l.4-7.5Z" fill="currentColor" />
    </svg>
  );
}

/** Little Jeeko chick mark used as the logo. */
export function JeekoMark({ className = "size-6" }: IconProps) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden>
      <circle cx="16" cy="18.5" r="10.5" fill="#FFC629" />
      <circle cx="16" cy="11" r="7.4" fill="#FFD84D" />
      <path d="M16 3.2c.6 1.5.2 2.6-1 3.4 1.6.3 2.4-.4 2.9-1.7" fill="#FFC629" />
      <circle cx="13.2" cy="10.4" r="1.35" fill="#3A2409" />
      <circle cx="18.8" cy="10.4" r="1.35" fill="#3A2409" />
      <circle cx="13.7" cy="9.9" r="0.45" fill="#fff" />
      <circle cx="19.3" cy="9.9" r="0.45" fill="#fff" />
      <path d="M16 12.4l2.2 1.9h-4.4L16 12.4Z" fill="#FF9412" transform="rotate(180 16 13.3)" />
    </svg>
  );
}
