import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { buildSearchItems, searchItems } from "@/lib/search";
import { useAppStore } from "@/lib/store";

export function SearchBar() {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const games = useAppStore((state) => state.games);
  const presets = useAppStore((state) => state.clickPresets);
  const notes = useAppStore((state) => state.notes);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const items = useMemo(() => buildSearchItems(games, presets, notes), [games, presets, notes]);
  const results = useMemo(() => searchItems(query, items), [query, items]);

  useEffect(() => {
    setQuery("");
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    setActive(0);
  }, [query]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target;
      const typing = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement;
      if (event.key === "/" && !typing) {
        event.preventDefault();
        inputRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function go(index: number) {
    const item = results[index];
    if (!item) return;
    setOpen(false);
    setQuery("");
    void navigate({ to: item.to, hash: item.hash });
  }

  return (
    <div className="relative min-w-0 flex-1">
      <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint" aria-hidden="true" />
      <input
        ref={inputRef}
        type="search"
        value={query}
        aria-label="Search screens, games, tools, and settings"
        placeholder="Search"
        className="field-input pl-9"
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={(event) => {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            setActive((index) => Math.min(index + 1, Math.max(results.length - 1, 0)));
          } else if (event.key === "ArrowUp") {
            event.preventDefault();
            setActive((index) => Math.max(index - 1, 0));
          } else if (event.key === "Enter") {
            event.preventDefault();
            go(active);
          } else if (event.key === "Escape") {
            setOpen(false);
          }
        }}
      />
      {open && query.trim() ? (
        <ul className="surface absolute top-full right-0 left-0 z-30 mt-2 max-h-80 overflow-auto p-1" role="listbox">
          {results.length === 0 ? (
            <li className="px-3 py-3 text-sm text-muted">No matches.</li>
          ) : (
            results.map((item, index) => (
              <li key={item.id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={index === active}
                  className={`flex w-full min-h-11 flex-col items-start rounded-lg px-3 py-2 text-left ${index === active ? "bg-surface-2" : ""}`}
                  onMouseEnter={() => setActive(index)}
                  onClick={() => go(index)}
                >
                  <span className="text-sm font-semibold">{item.title}</span>
                  <span className="text-xs text-faint">{item.group} · {item.hint}</span>
                </button>
              </li>
            ))
          )}
        </ul>
      ) : null}
    </div>
  );
}
