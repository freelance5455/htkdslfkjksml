import React, { useState } from 'react';
import { ClassInfo, Language, ParchiExam, ParchiQuestion } from '../types';
import { translations } from '../utils/translations';
import {
  FileText,
  Printer,
  Cloud,
  Plus,
  Trash2,
  Sparkles,
  CheckCircle,
  HelpCircle,
  Download,
  AlertCircle
} from 'lucide-react';
import { uploadFileToDrive } from '../services/googleDriveService';

interface ParchiMakerViewProps {
  classes: ClassInfo[];
  lang: Language;
  parchis: ParchiExam[];
  onSaveParchi: (parchi: ParchiExam) => void;
  isGoogleDriveConnected: boolean;
  onConnectGoogle: () => void;
}

export const ParchiMakerView: React.FC<ParchiMakerViewProps> = ({
  classes,
  lang,
  parchis,
  onSaveParchi,
  isGoogleDriveConnected,
  onConnectGoogle,
}) => {
  const t = translations[lang];

  const [activeParchi, setActiveParchi] = useState<ParchiExam>(
    parchis[0] || {
      id: 'parchi_custom_' + Date.now(),
      title: 'Elementary A - Grammar & Vocabulary Parchi Exam',
      classId: classes[0]?.id || '',
      examType: 'monthly',
      totalMarks: 50,
      timeAllowed: '60 Minutes',
      date: new Date().toISOString().split('T')[0],
      instructions: 'Attempt all questions. Cutting and erasing is strictly prohibited.',
      questions: [
        {
          id: 'q1',
          type: 'mcq',
          prompt: 'Choose the correct form of "To Be": He _______ studying at Rahbar English Center.',
          options: ['am', 'is', 'are', 'were'],
          correctAnswer: 'is',
          marks: 5
        },
        {
          id: 'q2',
          type: 'fill_in_the_blank',
          prompt: 'Fill in the blank with suitable preposition: We have class _______ 8:00 AM.',
          options: ['at', 'on', 'in', 'to'],
          correctAnswer: 'at',
          marks: 5
        }
      ]
    }
  );

  // New Question Form state
  const [isAddingQuestion, setIsAddingQuestion] = useState(false);
  const [newQuestionType, setNewQuestionType] = useState<ParchiQuestion['type']>('mcq');
  const [newPrompt, setNewPrompt] = useState('');
  const [newMarks, setNewMarks] = useState(5);
  const [option1, setOption1] = useState('');
  const [option2, setOption2] = useState('');
  const [option3, setOption3] = useState('');
  const [option4, setOption4] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('');

  // Google Drive upload state
  const [isUploadingToDrive, setIsUploadingToDrive] = useState(false);
  const [driveUploadSuccess, setDriveUploadSuccess] = useState<string | null>(null);
  const [confirmDriveModal, setConfirmDriveModal] = useState(false);

  const selectedClass = classes.find((c) => c.id === activeParchi.classId) || classes[0];

  const handleAddQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPrompt.trim()) return;

    const options =
      newQuestionType === 'mcq'
        ? [option1, option2, option3, option4].filter(Boolean)
        : undefined;

    const newQ: ParchiQuestion = {
      id: 'q_' + Date.now(),
      type: newQuestionType,
      prompt: newPrompt.trim(),
      options: options && options.length > 0 ? options : undefined,
      correctAnswer: correctAnswer.trim() || undefined,
      marks: Number(newMarks) || 5,
    };

    const updated = {
      ...activeParchi,
      questions: [...activeParchi.questions, newQ],
      totalMarks: activeParchi.totalMarks + (Number(newMarks) || 5),
    };

    setActiveParchi(updated);
    onSaveParchi(updated);

    // Reset form
    setNewPrompt('');
    setOption1('');
    setOption2('');
    setOption3('');
    setOption4('');
    setCorrectAnswer('');
    setIsAddingQuestion(false);
  };

  const handleDeleteQuestion = (qId: string) => {
    const qToRemove = activeParchi.questions.find((q) => q.id === qId);
    const marksToRemove = qToRemove ? qToRemove.marks : 0;
    const updated = {
      ...activeParchi,
      questions: activeParchi.questions.filter((q) => q.id !== qId),
      totalMarks: Math.max(0, activeParchi.totalMarks - marksToRemove),
    };
    setActiveParchi(updated);
    onSaveParchi(updated);
  };

  const handlePrint = () => {
    window.print();
  };

  // Build clean HTML text content for saving to Google Drive
  const buildParchiHtml = () => {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${activeParchi.title}</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 40px; color: #111; line-height: 1.6; }
    .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 12px; margin-bottom: 20px; }
    .title { font-size: 22px; font-weight: bold; text-transform: uppercase; }
    .subtitle { font-size: 14px; margin: 4px 0; }
    .meta-box { border: 1px solid #000; padding: 12px; margin-bottom: 20px; font-size: 13px; }
    .row { display: flex; justify-content: space-between; margin-bottom: 6px; }
    .question { margin-bottom: 16px; page-break-inside: avoid; }
    .q-prompt { font-weight: bold; }
    .options { margin-left: 20px; }
  </style>
</head>
<body>
  <div class="header">
    <div class="title">RAHBAR ENGLISH CENTER</div>
    <div class="subtitle">Trat, Pishin, Balochistan | Class Examination Paper (Parchi)</div>
    <div style="font-weight: bold; font-size: 16px; margin-top: 6px;">${activeParchi.title}</div>
  </div>
  <div class="meta-box">
    <div class="row">
      <span><strong>Student Name:</strong> _____________________________</span>
      <span><strong>Roll No:</strong> _____________</span>
    </div>
    <div class="row">
      <span><strong>Father's Name:</strong> _____________________________</span>
      <span><strong>Class:</strong> ${selectedClass?.nameEn || ''}</span>
    </div>
    <div class="row">
      <span><strong>Time Allowed:</strong> ${activeParchi.timeAllowed}</span>
      <span><strong>Total Marks:</strong> ${activeParchi.totalMarks}</span>
      <span><strong>Date:</strong> ${activeParchi.date}</span>
    </div>
  </div>
  <div style="font-style: italic; margin-bottom: 15px;"><strong>Instructions:</strong> ${activeParchi.instructions}</div>
  <hr/>
  <div class="questions">
    ${activeParchi.questions
      .map(
        (q, i) => `
      <div class="question">
        <div class="q-prompt">Q${i + 1}. ${q.prompt} (${q.marks} Marks)</div>
        ${
          q.options
            ? `<div class="options">${q.options.map((opt, idx) => `<div>${String.fromCharCode(65 + idx)}) ${opt}</div>`).join('')}</div>`
            : '<div style="height: 40px; border-bottom: 1px dotted #999; margin: 10px 0;"></div>'
        }
      </div>`
      )
      .join('')}
  </div>
</body>
</html>`;
  };

  const handleConfirmSaveToDrive = async () => {
    setConfirmDriveModal(false);
    setIsUploadingToDrive(true);
    setDriveUploadSuccess(null);
    try {
      const fileName = `Parchi_${activeParchi.title.replace(/[^a-zA-Z0-9]/g, '_')}_${activeParchi.date}.html`;
      const htmlContent = buildParchiHtml();
      const result = await uploadFileToDrive(fileName, htmlContent, 'text/html');
      setDriveUploadSuccess(
        `Successfully saved "${result.name}" to your Google Drive!`
      );
    } catch (err: any) {
      alert(`Google Drive Upload error: ${err.message}`);
    } finally {
      setIsUploadingToDrive(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls & Banner */}
      <div className="no-print bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full mb-2 border border-emerald-200">
            <FileText className="w-3.5 h-3.5 text-emerald-600" />
            <span>Rahbar Exam Paper (Parchi) Studio</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900">
            {t.parchiMakerTitle}
          </h2>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            {t.parchiSub}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Print Button */}
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-2.5 rounded-2xl text-xs shadow-md transition"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            <span>{t.printParchi}</span>
          </button>

          {/* Save to Drive Button */}
          <button
            onClick={() => {
              if (!isGoogleDriveConnected) {
                onConnectGoogle();
              } else {
                setConfirmDriveModal(true);
              }
            }}
            disabled={isUploadingToDrive}
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2.5 rounded-2xl text-xs shadow-md transition disabled:opacity-50"
          >
            <Cloud className="w-4 h-4 text-emerald-200" />
            <span>{isUploadingToDrive ? 'Saving...' : t.saveToDrive}</span>
          </button>
        </div>
      </div>

      {driveUploadSuccess && (
        <div className="no-print bg-emerald-50 text-emerald-800 border border-emerald-300 p-4 rounded-2xl text-xs font-bold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>{driveUploadSuccess}</span>
          </div>
          <button
            onClick={() => setDriveUploadSuccess(null)}
            className="text-slate-400 hover:text-slate-600 text-xs"
          >
            ✕
          </button>
        </div>
      )}

      {/* Editor Controls (Select template or customize properties) */}
      <div className="no-print bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <span>Select Saved Parchi Template:</span>
            <div className="flex gap-1.5 overflow-x-auto">
              {parchis.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setActiveParchi(p)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    activeParchi.id === p.id
                      ? 'bg-emerald-600 text-white shadow'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {p.title.split('-')[0]}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => setIsAddingQuestion(true)}
            className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-xl text-xs font-bold transition"
          >
            <Plus className="w-4 h-4 text-emerald-600" />
            <span>{t.addQuestion}</span>
          </button>
        </div>

        {/* Inputs for Title, Class, Time, Marks */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">{t.parchiExamTitle}</label>
            <input
              type="text"
              value={activeParchi.title}
              onChange={(e) => setActiveParchi({ ...activeParchi, title: e.target.value })}
              className="w-full px-3 py-2 border rounded-xl font-bold outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">{t.classEnrolled}</label>
            <select
              value={activeParchi.classId}
              onChange={(e) => setActiveParchi({ ...activeParchi, classId: e.target.value })}
              className="w-full px-3 py-2 border rounded-xl font-medium outline-none bg-white"
            >
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nameEn}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">{t.timeAllowed}</label>
            <input
              type="text"
              value={activeParchi.timeAllowed}
              onChange={(e) => setActiveParchi({ ...activeParchi, timeAllowed: e.target.value })}
              className="w-full px-3 py-2 border rounded-xl font-bold outline-none"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">{t.totalMarks}</label>
            <input
              type="number"
              value={activeParchi.totalMarks}
              onChange={(e) => setActiveParchi({ ...activeParchi, totalMarks: Number(e.target.value) })}
              className="w-full px-3 py-2 border rounded-xl font-bold outline-none"
            />
          </div>
        </div>
      </div>

      {/* Add Question Inline Modal */}
      {isAddingQuestion && (
        <div className="no-print bg-slate-50 border-2 border-emerald-400 rounded-3xl p-6 shadow-md space-y-4 text-xs">
          <div className="flex items-center justify-between border-b pb-2">
            <h4 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-600" />
              {t.addQuestion}
            </h4>
            <button
              onClick={() => setIsAddingQuestion(false)}
              className="text-slate-400 hover:text-slate-600 font-bold"
            >
              ✕
            </button>
          </div>

          <form onSubmit={handleAddQuestionSubmit} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Question Type</label>
                <select
                  value={newQuestionType}
                  onChange={(e) => setNewQuestionType(e.target.value as any)}
                  className="w-full px-3 py-2 border rounded-xl bg-white font-bold"
                >
                  <option value="mcq">Multiple Choice Question (MCQ)</option>
                  <option value="fill_in_the_blank">Fill in the Blanks</option>
                  <option value="grammar_rule">Grammar Rule / Transformation</option>
                  <option value="speaking_dialogue">Speaking Dialogue / Conversation</option>
                  <option value="translation_essay">Translation / Composition Essay</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Question Marks</label>
                <input
                  type="number"
                  value={newMarks}
                  onChange={(e) => setNewMarks(Number(e.target.value))}
                  className="w-full px-3 py-2 border rounded-xl font-bold bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Question Prompt / Heading</label>
              <textarea
                required
                rows={2}
                value={newPrompt}
                onChange={(e) => setNewPrompt(e.target.value)}
                placeholder="e.g. Choose the correct tense or rewrite the following sentence in indirect speech..."
                className="w-full px-3 py-2 border rounded-xl bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {newQuestionType === 'mcq' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                <div>
                  <label className="block font-bold text-slate-600 text-[11px] mb-1">Option A</label>
                  <input
                    type="text"
                    value={option1}
                    onChange={(e) => setOption1(e.target.value)}
                    placeholder="Option A"
                    className="w-full px-2.5 py-1.5 border rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 text-[11px] mb-1">Option B</label>
                  <input
                    type="text"
                    value={option2}
                    onChange={(e) => setOption2(e.target.value)}
                    placeholder="Option B"
                    className="w-full px-2.5 py-1.5 border rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 text-[11px] mb-1">Option C</label>
                  <input
                    type="text"
                    value={option3}
                    onChange={(e) => setOption3(e.target.value)}
                    placeholder="Option C"
                    className="w-full px-2.5 py-1.5 border rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 text-[11px] mb-1">Option D</label>
                  <input
                    type="text"
                    value={option4}
                    onChange={(e) => setOption4(e.target.value)}
                    placeholder="Option D"
                    className="w-full px-2.5 py-1.5 border rounded-lg bg-white"
                  />
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setIsAddingQuestion(false)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-200 font-bold"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow"
              >
                Save Question to Parchi
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* AUTHENTIC PRINTABLE EXAMINATION PAPER (PARCHI) VIEW                       */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl border-2 border-slate-900 shadow-xl p-8 sm:p-12 print:border-none print:shadow-none print:p-0 text-slate-950 font-sans print-break-inside-avoid">
        {/* Paper Header */}
        <div className="text-center border-b-2 border-slate-900 pb-4 mb-6">
          <h1 className="text-2xl sm:text-3xl font-black tracking-wider uppercase text-slate-900">
            RAHBAR ENGLISH CENTER
          </h1>
          <p className="text-xs font-bold text-slate-700 tracking-wide mt-0.5">
            Pakistan, Balochistan, Pishin, Trat | Contact: +92 312 3456789
          </p>
          <div className="mt-2.5 inline-block bg-slate-900 text-white text-xs font-black tracking-widest px-4 py-1 rounded-full uppercase">
            {activeParchi.title}
          </div>
        </div>

        {/* Student Identification Meta Box */}
        <div className="border border-slate-900 p-4 rounded-xl mb-6 text-xs font-bold space-y-2.5 bg-slate-50/50 print:bg-white">
          <div className="flex flex-col sm:flex-row justify-between gap-3">
            <span className="flex-1">{t.parchiStudentNameLine}</span>
            <span className="w-48">{t.parchiRollLine}</span>
          </div>
          <div className="flex flex-col sm:flex-row justify-between gap-3">
            <span className="flex-1">{t.parchiFatherLine}</span>
            <span className="w-48">
              Class: <strong>{selectedClass?.nameEn}</strong>
            </span>
          </div>
          <div className="flex flex-wrap justify-between gap-3 pt-1 border-t border-slate-300 text-slate-700">
            <span>
              {t.timeAllowed}: <strong>{activeParchi.timeAllowed}</strong>
            </span>
            <span>
              {t.totalMarks}: <strong>{activeParchi.totalMarks}</strong>
            </span>
            <span>
              Date: <strong>{activeParchi.date}</strong>
            </span>
            <span>
              Passing Marks: <strong>{Math.round(activeParchi.totalMarks * 0.5)}</strong>
            </span>
          </div>
        </div>

        {/* Instructions */}
        <div className="text-xs italic text-slate-600 mb-6 bg-slate-50 p-2.5 rounded-lg border border-slate-200 print:bg-white print:border-none">
          <strong>Instructions:</strong> {activeParchi.instructions}
        </div>

        {/* Questions List */}
        <div className="space-y-6 text-xs leading-relaxed">
          {activeParchi.questions.map((q, idx) => (
            <div key={q.id} className="relative group border-b border-slate-100 pb-5">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <span className="font-black text-slate-900 text-sm mr-2">
                    Q{idx + 1}.
                  </span>
                  <span className="font-bold text-slate-900 text-sm">
                    {q.prompt}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="bg-slate-100 text-slate-800 font-extrabold px-2 py-0.5 rounded text-[11px] border border-slate-300 print:border-none">
                    ({q.marks} Marks)
                  </span>

                  {/* Delete button (hidden when printing) */}
                  <button
                    onClick={() => handleDeleteQuestion(q.id)}
                    className="no-print opacity-0 group-hover:opacity-100 text-rose-500 hover:text-rose-700 p-1 transition"
                    title="Delete Question"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* MCQ Options Display */}
              {q.options && q.options.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3 ml-6 font-medium text-slate-800">
                  {q.options.map((opt, oIdx) => (
                    <div key={oIdx} className="flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full border border-slate-800 flex items-center justify-center text-[10px] font-bold">
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span>{opt}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Blank writing lines for non-MCQ */}
              {!q.options && (
                <div className="mt-3 ml-6 space-y-3">
                  <div className="w-full border-b border-dotted border-slate-400 h-4" />
                  <div className="w-full border-b border-dotted border-slate-400 h-4" />
                  <div className="w-full border-b border-dotted border-slate-400 h-4" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Paper Footer with Official Signature */}
        <div className="mt-16 pt-8 border-t-2 border-slate-900 flex justify-between items-end text-xs font-bold text-slate-800">
          <div className="text-center">
            <div className="w-36 border-b border-slate-900 mb-1.5" />
            <span>Subject Teacher Signature</span>
          </div>

          <div className="text-center">
            <div className="w-36 border-b border-slate-900 mb-1.5" />
            <span>Controller of Examinations</span>
          </div>

          <div className="text-center">
            <div className="w-36 border-b border-slate-900 mb-1.5" />
            <span>Director / Principal Stamp</span>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Google Drive Upload (Mandatory per workspace-integration rules) */}
      {confirmDriveModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3 text-emerald-800 border-b pb-3">
              <Cloud className="w-6 h-6 text-emerald-600" />
              <h3 className="font-extrabold text-slate-900 text-base">
                Confirm Google Drive Upload
              </h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              With your permission, this will save <strong>"{activeParchi.title}"</strong> as an examination paper document directly in your Google Drive cloud account.
            </p>

            <div className="bg-slate-50 p-3 rounded-2xl text-xs space-y-1 text-slate-700">
              <div><strong>Document Name:</strong> {activeParchi.title}</div>
              <div><strong>Class:</strong> {selectedClass?.nameEn}</div>
              <div><strong>Total Marks:</strong> {activeParchi.totalMarks}</div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                onClick={() => setConfirmDriveModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleConfirmSaveToDrive}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md flex items-center gap-1.5"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Confirm & Upload</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
