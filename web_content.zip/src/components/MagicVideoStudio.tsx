import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Video, Sparkles, Download, RefreshCw, AlertCircle, CheckCircle2, Play, Pause } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../utils/sound';

interface MagicVideoStudioProps {
  isOpen: boolean;
  onClose: () => void;
  childName: string;
}

export const MagicVideoStudio: React.FC<MagicVideoStudioProps> = ({
  isOpen,
  onClose,
  childName,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [prompt, setPrompt] = useState<string>(
    `A joyful magical animation bringing this photo to life in a cheerful 3D cartoon classroom with floating alphabets and stars.`
  );
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isAnimatedPreview, setIsAnimatedPreview] = useState<boolean>(false);
  const [isCanvasPlaying, setIsCanvasPlaying] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const animCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameId = useRef<number | null>(null);

  const samplePresets = [
    {
      name: 'استاد میاں بھالو (Teacher Bear)',
      src: '/src/assets/images/teacher_character_1790357459776.jpg',
      prompt: 'Bring Teacher Bear to life waving warmly with twinkling eyes and joyful cartoon movements.',
    },
    {
      name: 'جادوئی کلاس روم (Magic Classroom)',
      src: '/src/assets/images/learning_classroom_1790357476488.jpg',
      prompt: 'Magical 3D camera pan through the classroom as colorful ABC blocks and 123 numbers gently bounce.',
    },
    {
      name: 'چمکتارا ٹرافی (Golden Star Trophy)',
      src: '/src/assets/images/kid_trophy_star_1790357488422.jpg',
      prompt: 'Golden star trophy spins joyfully with rainbow confetti bursting and radiant sparkle trails.',
    },
  ];

  useEffect(() => {
    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, []);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('براہ کرم تصویر منتخب کریں (JPG یا PNG)');
      return;
    }

    setMimeType(file.type);
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
      setVideoUrl(null);
      setIsAnimatedPreview(false);
      setErrorMessage(null);
      sound.playPopSound();
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = async (preset: typeof samplePresets[0]) => {
    try {
      sound.playPopSound();
      setPrompt(preset.prompt);
      setVideoUrl(null);
      setIsAnimatedPreview(false);
      setErrorMessage(null);

      const res = await fetch(preset.src);
      const blob = await res.blob();
      setMimeType(blob.type || 'image/jpeg');

      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(blob);
    } catch {
      // ignore
    }
  };

  // Generate magical animated canvas video (for instant preview & recorder)
  const generateMagicalCanvasAnimation = (imgSrc: string) => {
    setIsAnimatedPreview(true);
    setIsCanvasPlaying(true);
    sound.playSuccessSound();

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imgSrc;

    img.onload = () => {
      const canvas = animCanvasRef.current;
      if (!canvas) return;

      const isWide = aspectRatio === '16:9';
      canvas.width = isWide ? 640 : 360;
      canvas.height = isWide ? 360 : 640;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let startTime = Date.now();
      const particles: Array<{ x: number; y: number; speed: number; char: string; size: number }> = [];
      const magicChars = ['⭐', '✨', '🎈', 'ا', 'ب', 'A', 'B', '1', '2', '🧸'];

      for (let i = 0; i < 18; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speed: 0.8 + Math.random() * 1.5,
          char: magicChars[i % magicChars.length],
          size: 14 + Math.random() * 16,
        });
      }

      // Try capturing to a video Blob via MediaRecorder
      let recorder: MediaRecorder | null = null;
      let recordedChunks: Blob[] = [];

      try {
        const stream = canvas.captureStream(30);
        const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
          ? 'video/webm;codecs=vp9'
          : 'video/webm';

        recorder = new MediaRecorder(stream, { mimeType: mime });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) recordedChunks.push(e.data);
        };
        recorder.onstop = () => {
          const blob = new Blob(recordedChunks, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          setVideoUrl(url);
        };
        recorder.start();
        setTimeout(() => {
          if (recorder && recorder.state === 'recording') {
            recorder.stop();
          }
        }, 5000);
      } catch {
        // MediaRecorder optional, canvas will loop live
      }

      const render = () => {
        const now = Date.now();
        const elapsed = (now - startTime) / 1000;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Animated subtle background gradient
        const bgGrad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        bgGrad.addColorStop(0, '#fef3c7');
        bgGrad.addColorStop(1, '#fed7aa');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Image animation (gentle floating breathing scale)
        const scale = 1.05 + Math.sin(elapsed * 2) * 0.05;
        const bounceY = Math.sin(elapsed * 2.5) * 6;

        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2 + bounceY);
        ctx.scale(scale, scale);

        // Draw image rounded & centered
        const targetW = canvas.width * 0.85;
        const targetH = (img.height / img.width) * targetW;
        ctx.drawImage(img, -targetW / 2, -targetH / 2, targetW, targetH);
        ctx.restore();

        // Draw floating magical particles (Alphabets, stars, balloons)
        particles.forEach((p) => {
          p.y -= p.speed;
          if (p.y < -20) {
            p.y = canvas.height + 20;
            p.x = Math.random() * canvas.width;
          }
          ctx.font = `${p.size}px sans-serif`;
          ctx.fillText(p.char, p.x, p.y);
        });

        // Bottom Banner with Arhan's name
        ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
        ctx.fillRect(0, canvas.height - 44, canvas.width, 44);

        ctx.font = 'bold 15px sans-serif';
        ctx.fillStyle = '#fef08a';
        ctx.textAlign = 'center';
        ctx.fillText(`🌟 پیارے ${childName} کی جادوئی ویڈیو کلاس 🌟`, canvas.width / 2, canvas.height - 18);

        animationFrameId.current = requestAnimationFrame(render);
      };

      render();
    };
  };

  const handleGenerateVideo = async () => {
    if (!selectedImage) {
      setErrorMessage('براہ کرم پہلے تصویر اپلوڈ کریں یا نیچے دیے گئے نمونے میں سے چنیں!');
      return;
    }

    setIsGenerating(true);
    setVideoUrl(null);
    setIsAnimatedPreview(false);
    setErrorMessage(null);
    setStatusMessage('ویڈیو پروسیسنگ شروع ہو رہی ہے... (Veo Video)');
    sound.playPopSound();

    try {
      // Step 1: Start video operation
      const startRes = await fetch('/api/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          imageBase64: selectedImage,
          mimeType,
          aspectRatio,
        }),
      });

      const startData = await startRes.json();

      // If project has reached quota or Veo requires paid key:
      if (startData.quotaExceeded || !startData.operationName) {
        setStatusMessage('مفت کوٹہ مکمل، ارہان کے لیے جادوئی اینیمیٹڈ ویڈیو تیار کی جا رہی ہے... ✨');
        setTimeout(() => {
          generateMagicalCanvasAnimation(selectedImage);
          setIsGenerating(false);
          setStatusMessage('');
        }, 1200);
        return;
      }

      const { operationName } = startData;

      // Step 2: Poll operation status
      const reassuranceMessages = [
        'جیمنائی ویو (Veo) تصویر میں جان ڈال رہا ہے... 🌟',
        'میاں بھالو کیمرے کے اینگل اور اینیمیشن سیٹ کر رہے ہیں... 🎬',
        'رنگ برنگے فریم تیار ہو رہے ہیں... بس چند لمحے! 🎨',
      ];
      let msgIdx = 0;

      const pollInterval = 5000;
      const maxAttempts = 50;

      for (let attempt = 0; attempt < maxAttempts; attempt++) {
        await new Promise((r) => setTimeout(r, pollInterval));
        setStatusMessage(reassuranceMessages[msgIdx % reassuranceMessages.length]);
        msgIdx++;

        const statusRes = await fetch('/api/video-status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ operationName }),
        });

        if (!statusRes.ok) continue;

        const statusData = await statusRes.json();
        if (statusData.error) {
          // If polling errors with quota or error, gracefully switch to animation
          generateMagicalCanvasAnimation(selectedImage);
          break;
        }

        if (statusData.done) {
          setStatusMessage('ویڈیو تیار ہے! ڈاؤنلوڈ کی جا رہی ہے... 🎉');

          // Step 3: Download video
          const dlRes = await fetch('/api/video-download', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ operationName }),
          });

          if (dlRes.ok) {
            const videoBlob = await dlRes.blob();
            const url = URL.createObjectURL(videoBlob);
            setVideoUrl(url);
            sound.playSuccessSound();
          } else {
            generateMagicalCanvasAnimation(selectedImage);
          }
          break;
        }
      }
    } catch {
      // Seamless fallback to animation for Arhan
      generateMagicalCanvasAnimation(selectedImage);
    } finally {
      setIsGenerating(false);
      setStatusMessage('');
    }
  };

  const handleDownloadCanvas = () => {
    const canvas = animCanvasRef.current;
    if (!canvas) return;

    if (videoUrl) {
      const a = document.createElement('a');
      a.href = videoUrl;
      a.download = `arhan_magic_video_${Date.now()}.webm`;
      a.click();
    } else {
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `arhan_magic_frame_${Date.now()}.png`;
      a.click();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden border-4 border-purple-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 p-4 sm:p-5 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center shadow-inner">
              <Video className="w-6 h-6 text-pink-300" />
            </div>
            <div>
              <h3 className="font-urdu text-lg sm:text-xl font-bold flex items-center gap-2">
                <span>جادوئی ویڈیو اسٹوڈیو (Veo Video) 🎬</span>
              </h3>
              <p className="text-xs text-purple-200">
                تصویر اپلوڈ کریں اور دیکھیں کیسے جادو سے اینیمیٹڈ ویڈیو بنتی ہے!
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Preset Samples */}
          <div>
            <span className="font-urdu text-xs font-bold text-purple-900 block mb-2">
              یا ان تیار نمونوں میں سے چنیں:
            </span>
            <div className="grid grid-cols-3 gap-2.5">
              {samplePresets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectPreset(preset)}
                  className="group relative rounded-xl overflow-hidden border-2 border-purple-200 hover:border-purple-500 transition-all p-1 text-right bg-purple-50 hover:bg-purple-100 cursor-pointer"
                >
                  <img
                    src={preset.src}
                    alt={preset.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-16 sm:h-20 object-cover rounded-lg group-hover:scale-105 transition-transform"
                  />
                  <span className="font-urdu text-[11px] font-bold text-purple-900 block mt-1 truncate">
                    {preset.name}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Upload / Image Preview Area */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-urdu text-sm font-bold text-slate-800">
                تصویر منتخب کریں (ارہان کی تصویر یا ڈرائنگ):
              </span>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>تصویر اپلوڈ کریں</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {selectedImage ? (
              <div className="relative rounded-2xl overflow-hidden border-3 border-purple-300 max-h-56 flex items-center justify-center bg-slate-900 shadow-inner group">
                <img
                  src={selectedImage}
                  alt="Selected Preview"
                  referrerPolicy="no-referrer"
                  className="max-h-56 object-contain"
                />
                <button
                  onClick={() => {
                    setSelectedImage(null);
                    setIsAnimatedPreview(false);
                    setVideoUrl(null);
                  }}
                  className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full transition-all cursor-pointer"
                  title="Remove"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-3 border-dashed border-purple-200 hover:border-purple-400 bg-purple-50/50 rounded-2xl p-6 text-center cursor-pointer transition-all hover:bg-purple-50 flex flex-col items-center justify-center gap-2"
              >
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-600">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="font-urdu text-sm font-bold text-purple-950">
                  یہاں کلک کر کے {childName} کی تصویر یا ڈرائنگ اپلوڈ کریں
                </p>
                <p className="text-xs text-purple-600 font-sans">
                  PNG, JPG (Maximum 20MB)
                </p>
              </div>
            )}
          </div>

          {/* Video Options: Aspect Ratio & Prompt */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-urdu text-xs font-bold text-slate-700 block mb-1.5">
                ویڈیو کا سائز (Aspect Ratio):
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setAspectRatio('16:9')}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer ${
                    aspectRatio === '16:9'
                      ? 'bg-purple-600 text-white border-purple-600 shadow-md'
                      : 'bg-white text-slate-700 border-purple-200 hover:bg-purple-50'
                  }`}
                >
                  <span>16:9 (Landscape)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAspectRatio('9:16')}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer ${
                    aspectRatio === '9:16'
                      ? 'bg-purple-600 text-white border-purple-600 shadow-md'
                      : 'bg-white text-slate-700 border-purple-200 hover:bg-purple-50'
                  }`}
                >
                  <span>9:16 (Portrait)</span>
                </button>
              </div>
            </div>

            <div>
              <label className="font-urdu text-xs font-bold text-slate-700 block mb-1.5">
                حرکت کی ہدایات (Motion Prompt):
              </label>
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter animation prompt..."
                className="w-full text-xs bg-slate-50 border-2 border-purple-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Error notice */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border-2 border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-800 font-bold">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Animated Canvas Video Player (Magical Animation Output) */}
          {isAnimatedPreview && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-3xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-urdu text-sm font-bold text-emerald-900 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>پیارے {childName} کی جادوئی اینیمیٹڈ ویڈیو تیار ہے! 🎉</span>
                </span>
                <button
                  onClick={handleDownloadCanvas}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>ڈاؤنلوڈ کریں (Save)</span>
                </button>
              </div>

              <div className="rounded-2xl overflow-hidden bg-black flex items-center justify-center shadow-lg p-2">
                <canvas
                  ref={animCanvasRef}
                  className={`rounded-xl max-h-72 object-contain shadow-md ${
                    aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]'
                  }`}
                />
              </div>
            </div>
          )}

          {/* Downloaded Veo MP4 Video Player (when Veo returns video stream) */}
          {videoUrl && !isAnimatedPreview && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-3xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-urdu text-sm font-bold text-emerald-900 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>مبارک ہو! ویڈیو کامیابی سے بن گئی ہے! 🎉</span>
                </span>
                <a
                  href={videoUrl}
                  download={`arhan_veo_video_${Date.now()}.mp4`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>ڈاؤنلوڈ کریں (Save)</span>
                </a>
              </div>

              <div className="rounded-2xl overflow-hidden bg-black aspect-video flex items-center justify-center shadow-lg">
                <video
                  src={videoUrl}
                  controls
                  autoPlay
                  loop
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-purple-100 flex items-center justify-between">
          <div className="text-xs text-purple-700 font-urdu font-semibold">
            {isGenerating ? statusMessage : `ماڈل: veo-3.1-fast-generate-preview`}
          </div>

          <button
            onClick={handleGenerateVideo}
            disabled={isGenerating || !selectedImage}
            className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 active:scale-95 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-lg flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>ویڈیو بن رہی ہے...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-yellow-300" />
                <span>ویڈیو بنائیں (Generate Video)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
