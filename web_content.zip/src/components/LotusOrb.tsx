import React from 'react';

interface LotusOrbProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  state?: 'idle' | 'listening' | 'speaking' | 'thinking';
  onClick?: () => void;
  label?: string;
}

export const LotusOrb: React.FC<LotusOrbProps> = ({
  size = 'lg',
  state = 'idle',
  onClick,
  label,
}) => {
  const dimensions = {
    sm: 'w-9 h-9',
    md: 'w-16 h-16',
    lg: 'w-36 h-36 sm:w-44 sm:h-44',
    xl: 'w-48 h-48 sm:w-56 sm:h-56',
  }[size];

  const stateRingColor = {
    idle: 'from-cyan-400/40 via-indigo-500/40 to-fuchsia-500/40',
    listening: 'from-emerald-400/60 via-cyan-400/60 to-blue-500/60',
    speaking: 'from-cyan-300/75 via-purple-500/75 to-pink-500/75',
    thinking: 'from-amber-400/60 via-purple-500/60 to-cyan-400/60',
  }[state];

  const Wrapper = onClick ? 'button' : 'div';

  return (
    <Wrapper
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      aria-label={label || 'RAJU AI Assistant Orb'}
      className={`relative inline-flex items-center justify-center rounded-full select-none group ${dimensions} ${
        onClick ? 'cursor-pointer focus-visible:outline-2 focus-visible:outline-cyan-400' : ''
      }`}
    >
      {/* Ambient Radial Aura */}
      <span
        className={`absolute inset-0 rounded-full bg-gradient-to-tr ${stateRingColor} blur-xl animate-orb-pulse pointer-events-none`}
      />

      {/* Outer Orbital Ring */}
      <span className="absolute inset-1 rounded-full border border-cyan-400/40 shadow-[0_0_30px_rgba(0,210,255,0.35)] animate-orb-rotate pointer-events-none" />

      {/* Secondary Tilted Ring */}
      <span className="absolute inset-2.5 rounded-full border border-fuchsia-400/35 pointer-events-none" />

      {/* Core Glass Sphere */}
      <span className="relative flex items-center justify-center w-[82%] h-[82%] rounded-full bg-gradient-to-b from-[#131C4E] via-[#0B1130] to-[#060919] border border-cyan-300/45 shadow-inner overflow-hidden">
        <svg
          viewBox="0 0 200 200"
          className="w-[74%] h-[74%] drop-shadow-[0_0_12px_rgba(56,189,248,0.75)] transition-transform duration-200 group-hover:scale-105"
          fill="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="rajuLotusGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00F0FF" />
              <stop offset="50%" stopColor="#818CF8" />
              <stop offset="100%" stopColor="#E879F9" />
            </linearGradient>
          </defs>
          {/* Center Lotus Petal */}
          <path
            d="M100 32C116 64 122 98 100 142C78 98 84 64 100 32Z"
            fill="url(#rajuLotusGrad)"
          />
          {/* Inner Left Petal */}
          <path
            d="M92 143C60 122 42 90 50 54C72 72 88 102 92 143Z"
            fill="url(#rajuLotusGrad)"
            opacity="0.88"
          />
          {/* Inner Right Petal */}
          <path
            d="M108 143C140 122 158 90 150 54C128 72 112 102 108 143Z"
            fill="url(#rajuLotusGrad)"
            opacity="0.88"
          />
          {/* Outer Left Petal */}
          <path
            d="M84 152C44 148 18 126 12 92C40 98 68 120 84 152Z"
            fill="url(#rajuLotusGrad)"
            opacity="0.7"
          />
          {/* Outer Right Petal */}
          <path
            d="M116 152C156 148 182 126 188 92C160 98 132 120 116 152Z"
            fill="url(#rajuLotusGrad)"
            opacity="0.7"
          />
          {/* Horizon Arc */}
          <path
            d="M44 166C70 178 130 178 156 166"
            stroke="#00F0FF"
            strokeWidth="5"
            strokeLinecap="round"
          />
        </svg>
      </span>
    </Wrapper>
  );
};
