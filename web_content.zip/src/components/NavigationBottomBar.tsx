/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { LayoutDashboard, Smartphone, Gamepad2, Sparkles, SlidersHorizontal } from 'lucide-react';

export type TabType = 'dashboard' | 'devices' | 'gaming' | 'optimizer' | 'distribution';

interface NavigationBottomBarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  deviceCount: number;
  gamingModeActive: boolean;
}

export const NavigationBottomBar: React.FC<NavigationBottomBarProps> = ({
  activeTab,
  onTabChange,
  deviceCount,
  gamingModeActive,
}) => {
  const tabs = [
    {
      id: 'dashboard' as TabType,
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'devices' as TabType,
      label: 'Devices',
      icon: Smartphone,
      badge: deviceCount,
    },
    {
      id: 'gaming' as TabType,
      label: 'Gaming QoS',
      icon: Gamepad2,
      activeDot: gamingModeActive,
    },
    {
      id: 'distribution' as TabType,
      label: 'Bandwidth',
      icon: SlidersHorizontal,
    },
    {
      id: 'optimizer' as TabType,
      label: 'Wi-Fi Tuning',
      icon: Sparkles,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 px-2 py-1.5 transition-all">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex flex-col items-center justify-center flex-1 py-1.5 px-1 rounded-xl transition-all duration-200 ${
                isActive 
                  ? 'text-cyan-400' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Active Pill Indicator for Android Material 3 look */}
              <div
                className={`relative flex items-center justify-center w-12 h-7 rounded-full transition-all duration-200 ${
                  isActive 
                    ? 'bg-cyan-500/20 text-cyan-400' 
                    : 'bg-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />

                {/* Badge count */}
                {tab.badge !== undefined && (
                  <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-cyan-500 text-[10px] font-bold text-slate-950 font-mono">
                    {tab.badge}
                  </span>
                )}

                {/* Gaming mode active dot */}
                {tab.activeDot && (
                  <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-950 animate-pulse" />
                )}
              </div>

              {/* Label */}
              <span className={`text-[11px] font-medium tracking-tight mt-0.5 transition-colors ${
                isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400'
              }`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Android Gesture Bar */}
      <div className="w-full flex justify-center pt-1 pb-0.5">
        <div className="w-32 h-1 bg-slate-700/60 rounded-full" />
      </div>
    </nav>
  );
};
