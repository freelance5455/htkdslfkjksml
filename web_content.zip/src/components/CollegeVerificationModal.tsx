import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { College } from '../types';
import { INDIA_COLLEGES_DATA } from '../utils/indiaCollegesData';
import { 
  X, 
  KeyRound, 
  GraduationCap, 
  Search, 
  Crown, 
  CheckCircle2, 
  AlertCircle,
  Building2,
  Map,
  MapPin 
} from 'lucide-react';

export const CollegeVerificationModal: React.FC = () => {
  const { 
    isCollegeModalOpen, 
    setIsCollegeModalOpen, 
    joinCollege, 
    addNewCollege,
    colleges, 
    user 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'directory' | 'active'>('directory');

  // State -> District -> College Hierarchy
  const [selectedState, setSelectedState] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedCollegeItem, setSelectedCollegeItem] = useState<{ id: string; name: string; badge: string } | null>(null);
  const [collegePasscode, setCollegePasscode] = useState('');
  
  // Active Colleges Quick Search
  const [searchActive, setSearchActive] = useState('');
  const [activeCollegeToJoin, setActiveCollegeToJoin] = useState<College | null>(null);
  const [joinPasscode, setJoinPasscode] = useState('');

  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isCollegeModalOpen) return null;

  const currentStateObj = INDIA_COLLEGES_DATA.find(s => s.state === selectedState);
  const availableDistricts = currentStateObj ? currentStateObj.districts : [];
  const currentDistrictObj = availableDistricts.find(d => d.district === selectedDistrict);
  const availableColleges = currentDistrictObj ? currentDistrictObj.colleges : [];

  const chosenCollegeName = selectedCollegeItem?.name || '';
  const existingCollege = colleges.find(c => 
    c.name.trim().toLowerCase() === chosenCollegeName.toLowerCase() &&
    (c.district?.toLowerCase() === selectedDistrict.toLowerCase() || c.city.toLowerCase() === selectedDistrict.toLowerCase())
  );

  // Submit from State/District directory
  const handleDirectorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    if (!selectedState || !selectedDistrict || !chosenCollegeName) {
      setStatusMsg({ type: 'error', text: 'Please select State, District, and College.' });
      return;
    }
    if (!collegePasscode.trim()) {
      setStatusMsg({ type: 'error', text: 'Please enter a College Passcode.' });
      return;
    }

    if (existingCollege) {
      const res = joinCollege(existingCollege.code, collegePasscode);
      if (res.success) {
        setStatusMsg({ type: 'success', text: res.message });
        setTimeout(() => setIsCollegeModalOpen(false), 1200);
      } else {
        setStatusMsg({ type: 'error', text: res.message });
      }
      return;
    }

    // Activate as Founder & Admin
    const res = addNewCollege(
      chosenCollegeName,
      selectedDistrict,
      collegePasscode,
      selectedCollegeItem?.badge || '🏛️',
      selectedState,
      selectedDistrict
    );

    if (res.success) {
      setStatusMsg({ type: 'success', text: res.message });
      setTimeout(() => setIsCollegeModalOpen(false), 1200);
    } else {
      setStatusMsg({ type: 'error', text: res.message });
    }
  };

  // Join already active campus
  const handleJoinActive = (target: College) => {
    setStatusMsg(null);
    if (!joinPasscode.trim()) {
      setStatusMsg({ type: 'error', text: 'Please enter the College Secret Code to join.' });
      return;
    }

    const res = joinCollege(target.code, joinPasscode);
    if (res.success) {
      setStatusMsg({ type: 'success', text: res.message });
      setTimeout(() => setIsCollegeModalOpen(false), 1200);
    } else {
      setStatusMsg({ type: 'error', text: res.message });
    }
  };

  const filteredActiveColleges = colleges.filter(c => 
    !searchActive.trim() || 
    c.name.toLowerCase().includes(searchActive.toLowerCase()) ||
    c.city.toLowerCase().includes(searchActive.toLowerCase()) ||
    c.code.toLowerCase().includes(searchActive.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-[#0c0f1d] border border-cyan-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-cyan-900/30 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Campus Selection Directory</h2>
              <p className="text-[11px] text-slate-400">Current: <span className="text-cyan-400 font-semibold">{user.collegeName || 'Not Verified'}</span></p>
            </div>
          </div>
          <button 
            onClick={() => setIsCollegeModalOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-900 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex rounded-xl bg-slate-950 p-1 my-4 border border-slate-800">
          <button
            onClick={() => { setActiveTab('directory'); setStatusMsg(null); }}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'directory' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-white'
            }`}
          >
            State & District Directory
          </button>
          <button
            onClick={() => { setActiveTab('active'); setStatusMsg(null); }}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'active' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-white'
            }`}
          >
            Active Campuses ({colleges.length})
          </button>
        </div>

        {/* Notifications */}
        {statusMsg && (
          <div className={`mb-4 p-3 rounded-xl border text-xs flex items-start gap-2 animate-in fade-in ${
            statusMsg.type === 'success' 
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' 
              : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
          }`}>
            {statusMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />}
            <span>{statusMsg.text}</span>
          </div>
        )}

        {/* TAB 1: STATE -> DISTRICT -> COLLEGE DIRECTORY */}
        {activeTab === 'directory' && (
          <form onSubmit={handleDirectorySubmit} className="space-y-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                <Map className="w-3 h-3 text-pink-400" />
                <span>1. Select State</span>
              </label>
              <select
                required
                value={selectedState}
                onChange={(e) => {
                  setSelectedState(e.target.value);
                  setSelectedDistrict('');
                  setSelectedCollegeItem(null);
                }}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-pink-500 text-xs text-slate-100 outline-none"
              >
                <option value="">-- Choose State --</option>
                {INDIA_COLLEGES_DATA.map((st) => (
                  <option key={st.state} value={st.state}>
                    {st.state}
                  </option>
                ))}
              </select>
            </div>

            {selectedState && (
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <Building2 className="w-3 h-3 text-purple-400" />
                  <span>2. Select District / City</span>
                </label>
                <select
                  required
                  value={selectedDistrict}
                  onChange={(e) => {
                    setSelectedDistrict(e.target.value);
                    setSelectedCollegeItem(null);
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-xs text-slate-100 outline-none"
                >
                  <option value="">-- Choose District in {selectedState} --</option>
                  {availableDistricts.map((d) => (
                    <option key={d.district} value={d.district}>
                      {d.district}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {selectedDistrict && (
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
                  <span>3. Choose College from {selectedDistrict}</span>
                </label>
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {availableColleges.map((col) => {
                    const isSelected = selectedCollegeItem?.id === col.id;
                    const isActivated = colleges.some(c => c.name.trim().toLowerCase() === col.name.trim().toLowerCase());
                    return (
                      <div
                        key={col.id}
                        onClick={() => setSelectedCollegeItem(col)}
                        className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                          isSelected ? 'bg-slate-900 border-cyan-400' : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span>{col.badge}</span>
                          <span className="text-xs font-bold text-white">{col.name}</span>
                        </div>
                        {isActivated ? (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            Active
                          </span>
                        ) : (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                            Be Founder
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {chosenCollegeName && (
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <p className="text-[11px] text-slate-300">
                  {existingCollege ? (
                    <span className="text-emerald-400 font-semibold">Yeh college active hai! Join karne ke liye college passcode daalein:</span>
                  ) : (
                    <span className="text-amber-400 font-semibold">Aap is college ke official Admin banenge! Secret join passcode create karein:</span>
                  )}
                </p>
                <div className="relative">
                  <KeyRound className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400" />
                  <input
                    type="text"
                    required
                    value={collegePasscode}
                    onChange={(e) => setCollegePasscode(e.target.value.toUpperCase())}
                    placeholder={existingCollege ? "Enter College Code to join" : "Create Secret Code (e.g. DU2026)"}
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-cyan-500 text-xs font-mono text-cyan-300 uppercase outline-none"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={!chosenCollegeName || !collegePasscode.trim()}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-500 via-purple-600 to-cyan-500 hover:from-pink-400 hover:to-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all disabled:opacity-40"
            >
              {existingCollege ? 'Verify & Join Campus' : 'Activate College & Become Admin 👑'}
            </button>
          </form>
        )}

        {/* TAB 2: CURRENT ACTIVE CAMPUSES */}
        {activeTab === 'active' && (
          <div className="space-y-3">
            {colleges.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/60 rounded-2xl border border-slate-800">
                <p>Abhi koi college activate nahi hua hai.</p>
                <button
                  onClick={() => setActiveTab('directory')}
                  className="mt-2 text-cyan-400 font-bold hover:underline"
                >
                  Directory se pehla college activate karein!
                </button>
              </div>
            ) : (
              <>
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchActive}
                    onChange={(e) => setSearchActive(e.target.value)}
                    placeholder="Search active college..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 outline-none"
                  />
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {filteredActiveColleges.map((c) => {
                    const isSelected = activeCollegeToJoin?.code === c.code;
                    return (
                      <div key={c.code} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span>{c.badge}</span>
                            <div>
                              <p className="text-xs font-bold text-white">{c.name}</p>
                              <p className="text-[10px] text-slate-400">{c.city} · {c.studentsCount} students</p>
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              setActiveCollegeToJoin(isSelected ? null : c);
                              setJoinPasscode('');
                            }}
                            className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 text-xs font-semibold"
                          >
                            {isSelected ? 'Cancel' : 'Join'}
                          </button>
                        </div>

                        {isSelected && (
                          <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
                            <input
                              type="text"
                              value={joinPasscode}
                              onChange={(e) => setJoinPasscode(e.target.value.toUpperCase())}
                              placeholder="Enter College Code"
                              className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-300 uppercase outline-none"
                            />
                            <button
                              onClick={() => handleJoinActive(c)}
                              className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs"
                            >
                              Verify
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
