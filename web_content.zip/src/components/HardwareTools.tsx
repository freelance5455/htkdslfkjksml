import React, { useState } from 'react';
import { 
  Wrench, 
  Battery, 
  BatteryCharging, 
  Flashlight, 
  Youtube, 
  Globe, 
  Cpu, 
  Activity, 
  ShieldCheck, 
  Radio, 
  ExternalLink,
  RefreshCw,
  Sun
} from 'lucide-react';
import { SystemTelemetry, SupportedLanguage } from '../types/assistant';

interface HardwareToolsProps {
  telemetry: SystemTelemetry;
  language: SupportedLanguage;
  onRefreshTelemetry: () => void;
  onToggleTorch: () => void;
  isTorchActive: boolean;
}

export const HardwareTools: React.FC<HardwareToolsProps> = ({
  telemetry,
  language,
  onRefreshTelemetry,
  onToggleTorch,
  isTorchActive,
}) => {
  const [showYtModal, setShowYtModal] = useState(false);
  const [ytQuery, setYtQuery] = useState('');
  const [showWebModal, setShowWebModal] = useState(false);
  const [webQuery, setWebQuery] = useState('');
  const [isScreenLightOn, setIsScreenLightOn] = useState(false);

  const handleYtSearch = () => {
    if (!ytQuery.trim()) return;
    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(ytQuery.trim())}`;
    window.open(url, '_blank');
    setShowYtModal(false);
    setYtQuery('');
  };

  const handleWebSearch = () => {
    if (!webQuery.trim()) return;
    const url = `https://www.google.com/search?q=${encodeURIComponent(webQuery.trim())}`;
    window.open(url, '_blank');
    setShowWebModal(false);
    setWebQuery('');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0d1629] to-[#0f2334] border border-cyan-500/30 p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono-tech mb-1">
              <Wrench className="w-3.5 h-3.5 text-cyan-400" />
              <span>DIAGNOSTICS & HARDWARE INTEGRATION</span>
            </div>
            <h2 className="text-2xl font-orbitron font-extrabold tracking-wide text-white">
              SYSTEM HARDWARE & TOOLS
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm">
              Live battery monitoring, torch, search shortcuts, and system dossier.
            </p>
          </div>

          <button
            onClick={onRefreshTelemetry}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 text-cyan-300 text-xs font-mono-tech flex items-center gap-1.5 transition-all shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Stats</span>
          </button>
        </div>
      </div>

      {/* Main Hardware Telemetry Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Battery Telemetry Card */}
        <div className="rounded-2xl bg-[#090f1f]/90 border border-cyan-900/50 p-5 space-y-3 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {telemetry.isCharging ? (
                <BatteryCharging className="w-6 h-6 text-emerald-400 animate-pulse" />
              ) : (
                <Battery className={`w-6 h-6 ${telemetry.batteryLevel > 20 ? 'text-cyan-400' : 'text-red-400'}`} />
              )}
              <span className="font-orbitron font-bold text-sm text-white">BATTERY STATUS</span>
            </div>
            <span className="text-xl font-orbitron font-extrabold text-cyan-300">
              {telemetry.batteryLevel}%
            </span>
          </div>

          <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
            <div
              className={`h-full transition-all duration-500 ${
                telemetry.batteryLevel > 20
                  ? 'bg-gradient-to-r from-cyan-500 to-emerald-400'
                  : 'bg-red-500'
              }`}
              style={{ width: `${telemetry.batteryLevel}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 font-mono-tech pt-1">
            <span>Power State:</span>
            <span className="text-slate-200">
              {telemetry.isCharging ? `Charging (${telemetry.powerSource})` : 'Discharging'}
            </span>
          </div>
        </div>

        {/* Torch / Flashlight Card */}
        <div className="rounded-2xl bg-[#090f1f]/90 border border-cyan-900/50 p-5 space-y-3 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flashlight className={`w-6 h-6 ${isTorchActive ? 'text-amber-400' : 'text-slate-400'}`} />
              <span className="font-orbitron font-bold text-sm text-white">TORCH / FLASHLIGHT</span>
            </div>
            <span className={`text-xs font-mono-tech px-2.5 py-0.5 rounded-full ${
              isTorchActive ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50' : 'bg-slate-900 text-slate-400'
            }`}>
              {isTorchActive ? 'ACTIVE' : 'STANDBY'}
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Toggles hardware camera flash (on mobile) and high-luminance screen torch illumination.
          </p>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={onToggleTorch}
              className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                isTorchActive
                  ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/40'
                  : 'bg-slate-900 border border-cyan-500/40 text-cyan-300 hover:bg-slate-800'
              }`}
            >
              <Flashlight className="w-4 h-4" />
              <span>{isTorchActive ? 'TURN OFF TORCH' : 'ACTIVATE TORCH'}</span>
            </button>

            <button
              onClick={() => setIsScreenLightOn(!isScreenLightOn)}
              title="Full Screen Illumination"
              className="py-2 px-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-xs font-mono-tech flex items-center gap-1"
            >
              <Sun className="w-4 h-4 text-amber-300" />
              <span>Screen Light</span>
            </button>
          </div>
        </div>
      </div>

      {/* Screen Illumination Overlay if active */}
      {isScreenLightOn && (
        <div 
          onClick={() => setIsScreenLightOn(false)}
          className="fixed inset-0 z-50 bg-white cursor-pointer flex flex-col items-center justify-center p-6 text-slate-900 select-none"
        >
          <Sun className="w-20 h-20 text-amber-500 animate-spin" />
          <h1 className="text-3xl font-black mt-4">MAXIMUM SCREEN TORCH ACTIVE</h1>
          <p className="text-base text-slate-700 mt-2">Tap anywhere to turn off</p>
        </div>
      )}

      {/* Quick Launchers: YouTube & Google Web Search */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* YouTube Launcher */}
        <div 
          onClick={() => setShowYtModal(true)}
          className="rounded-2xl bg-gradient-to-r from-[#180d12] to-[#120a1c] border border-red-500/40 hover:border-red-400 p-5 space-y-2 cursor-pointer transition-all shadow-md group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-red-400">
              <Youtube className="w-6 h-6" />
              <span className="font-orbitron font-bold text-sm text-white">YOUTUBE SEARCH</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-red-400 transition-colors" />
          </div>
          <p className="text-xs text-slate-400">
            Instantly search music, sci-fi documentaries, or technical tutorials on YouTube.
          </p>
        </div>

        {/* Web Search Launcher */}
        <div 
          onClick={() => setShowWebModal(true)}
          className="rounded-2xl bg-gradient-to-r from-[#091524] to-[#0c1a2e] border border-cyan-500/40 hover:border-cyan-400 p-5 space-y-2 cursor-pointer transition-all shadow-md group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-cyan-400">
              <Globe className="w-6 h-6" />
              <span className="font-orbitron font-bold text-sm text-white">GOOGLE SEARCH</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition-colors" />
          </div>
          <p className="text-xs text-slate-400">
            Look up live queries, news, documents, and references directly.
          </p>
        </div>
      </div>

      {/* System Dossier & Creator Specifications */}
      <div className="rounded-3xl bg-[#090f1f]/95 border border-cyan-500/40 p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-cyan-900/40 pb-3">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
          <h3 className="font-orbitron font-bold text-sm text-white tracking-wide">
            SYSTEM INTEL & SPECIFICATIONS
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-mono-tech">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-500">ASSISTANT CODENAME</span>
            <p className="text-cyan-300 font-bold">RUBEL BOSS AI</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-500">MASTERMIND / CREATOR</span>
            <p className="text-fuchsia-300 font-bold">RUBEL BOSS (রুবেল বস)</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-500">AI INFERENCE ENGINE</span>
            <p className="text-emerald-300 font-bold">GEMINI 2.5 FLASH MULTIMODAL</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-500">SPEECH MATRIX</span>
            <p className="text-slate-200">বাংলা (bn-BD) & English (en-US)</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-500">RESOLUTION & VIEWPORT</span>
            <p className="text-slate-200">{telemetry.screenResolution}</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-500">SECURITY & PRIVACY</span>
            <p className="text-cyan-400 font-bold">PRIVATE & CLIENT-CONTAINED</p>
          </div>
        </div>
      </div>

      {/* YouTube Modal */}
      {showYtModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#090f1f] border border-red-500/50 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-red-900/40 pb-3">
              <div className="flex items-center gap-2 text-red-400">
                <Youtube className="w-5 h-5" />
                <h3 className="font-orbitron font-bold text-sm text-white">YOUTUBE SEARCH</h3>
              </div>
              <button onClick={() => setShowYtModal(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <input
              type="text"
              value={ytQuery}
              onChange={(e) => setYtQuery(e.target.value)}
              placeholder="Search song, video or topic..."
              className="w-full bg-slate-950 text-slate-100 text-sm px-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-red-400"
              onKeyDown={(e) => e.key === 'Enter' && handleYtSearch()}
            />
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setShowYtModal(false)} className="px-4 py-2 text-xs font-mono-tech text-slate-400">Cancel</button>
              <button onClick={handleYtSearch} className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs tracking-wider font-orbitron">SEARCH</button>
            </div>
          </div>
        </div>
      )}

      {/* Web Search Modal */}
      {showWebModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#090f1f] border border-cyan-500/50 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-cyan-900/40 pb-3">
              <div className="flex items-center gap-2 text-cyan-400">
                <Globe className="w-5 h-5" />
                <h3 className="font-orbitron font-bold text-sm text-white">WEB SEARCH</h3>
              </div>
              <button onClick={() => setShowWebModal(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <input
              type="text"
              value={webQuery}
              onChange={(e) => setWebQuery(e.target.value)}
              placeholder="Enter search query..."
              className="w-full bg-slate-950 text-slate-100 text-sm px-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-400"
              onKeyDown={(e) => e.key === 'Enter' && handleWebSearch()}
            />
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setShowWebModal(false)} className="px-4 py-2 text-xs font-mono-tech text-slate-400">Cancel</button>
              <button onClick={handleWebSearch} className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs tracking-wider font-orbitron">SEARCH</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
