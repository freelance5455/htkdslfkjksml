import React, { useState, useMemo } from 'react';
import { Search, X, Zap, Star, Check, Wifi, Globe, Server, Film, Share2 } from 'lucide-react';
import { VpnServer, RegionFilter } from '../types/vpn';
import { Language, TRANSLATIONS } from '../translations';

interface ServerListModalProps {
  isOpen: boolean;
  onClose: () => void;
  servers: VpnServer[];
  currentServer: VpnServer;
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onSelectServer: (server: VpnServer) => void;
  language: Language;
}

export const ServerListModal: React.FC<ServerListModalProps> = ({
  isOpen,
  onClose,
  servers,
  currentServer,
  favorites,
  onToggleFavorite,
  onSelectServer,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const [searchQuery, setSearchQuery] = useState('');
  const [activeRegion, setActiveRegion] = useState<RegionFilter>('all');
  const [onlyFavorites, setOnlyFavorites] = useState(false);

  // Filter servers
  const filteredServers = useMemo(() => {
    return servers.filter((s) => {
      // Favorite filter
      if (onlyFavorites && !favorites.includes(s.id)) return false;

      // Region filter
      if (activeRegion === 'asia' && s.region !== 'asia') return false;
      if (activeRegion === 'europe' && s.region !== 'europe') return false;
      if (activeRegion === 'americas' && s.region !== 'americas') return false;
      if (activeRegion === 'specialized' && !s.isStreaming && !s.isP2P) return false;

      // Text search
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchCountry = s.country.toLowerCase().includes(query) || s.countryBn.toLowerCase().includes(query);
        const matchCity = s.city.toLowerCase().includes(query) || s.cityBn.toLowerCase().includes(query);
        return matchCountry || matchCity;
      }

      return true;
    });
  }, [servers, searchQuery, activeRegion, onlyFavorites, favorites]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Globe className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              {t.selectServerTitle}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 sm:p-6 pb-2 border-b border-slate-100 dark:border-slate-800/60 flex flex-col gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchServerPlaceholder}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Region Tabs (Interactive Filter Controls) */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none">
            <button
              onClick={() => { setActiveRegion('all'); setOnlyFavorites(false); }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeRegion === 'all' && !onlyFavorites
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {t.allServers}
            </button>
            <button
              onClick={() => { setActiveRegion('asia'); setOnlyFavorites(false); }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeRegion === 'asia' && !onlyFavorites
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {t.asia}
            </button>
            <button
              onClick={() => { setActiveRegion('europe'); setOnlyFavorites(false); }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeRegion === 'europe' && !onlyFavorites
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {t.europe}
            </button>
            <button
              onClick={() => { setActiveRegion('americas'); setOnlyFavorites(false); }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeRegion === 'americas' && !onlyFavorites
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {t.americas}
            </button>
            <button
              onClick={() => { setActiveRegion('specialized'); setOnlyFavorites(false); }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeRegion === 'specialized' && !onlyFavorites
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {t.specialized}
            </button>
            <button
              onClick={() => setOnlyFavorites(!onlyFavorites)}
              className={`flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                onlyFavorites
                  ? 'bg-amber-500 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <Star className="w-3 h-3 fill-current" />
              <span>{t.favorites} ({favorites.length})</span>
            </button>
          </div>
        </div>

        {/* Server List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-2">
          {filteredServers.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <Server className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm font-medium">No matching servers found</p>
              <button
                onClick={() => { setSearchQuery(''); setActiveRegion('all'); setOnlyFavorites(false); }}
                className="mt-2 text-xs text-indigo-500 underline"
              >
                Reset filters
              </button>
            </div>
          ) : (
            filteredServers.map((server) => {
              const isSelected = server.id === currentServer.id;
              const isFav = favorites.includes(server.id);

              return (
                <div
                  key={server.id}
                  onClick={() => {
                    onSelectServer(server);
                    onClose();
                  }}
                  className={`w-full p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 cursor-pointer group ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500/50 dark:border-indigo-500/40'
                      : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Star Favorite Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(server.id);
                      }}
                      className="p-1 rounded text-slate-400 hover:text-amber-500 transition-colors"
                    >
                      <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400 text-amber-400' : ''}`} />
                    </button>

                    {/* Flag */}
                    <span className="text-2xl select-none" role="img" aria-label={server.country}>
                      {server.flag}
                    </span>

                    {/* Server Info */}
                    <div className="text-left min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {language === 'bn' ? server.cityBn : server.city}
                        </span>
                        <span className="text-xs text-slate-500 truncate">
                          ({language === 'bn' ? server.countryBn : server.country})
                        </span>
                        {server.isFastest && (
                          <span className="text-[10px] font-semibold text-amber-700 dark:text-amber-300 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.2 rounded">
                            Fastest
                          </span>
                        )}
                      </div>

                      {/* Capabilities: P2P, Streaming, IP */}
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <span className="font-mono">{server.ip}</span>
                        {server.isStreaming && (
                          <span className="flex items-center gap-0.5 text-sky-500" title="Streaming Optimized">
                            <Film className="w-3 h-3" />
                            <span>Stream</span>
                          </span>
                        )}
                        {server.isP2P && (
                          <span className="flex items-center gap-0.5 text-purple-500" title="P2P Supported">
                            <Share2 className="w-3 h-3" />
                            <span>P2P</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Latency & Server Load */}
                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-right">
                      <div className="flex items-center justify-end gap-1 text-xs font-mono font-bold">
                        <Wifi className="w-3 h-3 text-slate-400" />
                        <span className={
                          server.ping < 50
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : server.ping < 120
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-rose-500'
                        }>
                          {server.ping} {t.ms}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        Load: {server.load}%
                      </div>
                    </div>

                    {isSelected ? (
                      <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                      </div>
                    ) : (
                      <div className="w-6 h-6 rounded-full border border-slate-300 dark:border-slate-700 group-hover:border-indigo-500 transition-colors" />
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between text-xs text-slate-500">
          <span>{filteredServers.length} {t.allServers}</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-medium transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
