import React, {useState} from 'react';
import {Lock, Shield, Sparkles, X} from 'lucide-react';
import {PROTAGONISTS, type ProtagonistId} from '../game/types';

interface CharacterWheelProps {
  open: boolean;
  active: ProtagonistId;
  unlocked: ProtagonistId[];
  cash: Record<ProtagonistId, number>;
  onSelect: (id: ProtagonistId) => void;
  onClose: () => void;
}

const SLOTS: {id: ProtagonistId; keyNum: string; posClass: string}[] = [
  {id: 'michael', keyNum: '1', posClass: 'col-start-1 row-start-1'},
  {id: 'trevor', keyNum: '3', posClass: 'col-start-2 row-start-1'},
  {id: 'franklin', keyNum: '2', posClass: 'col-span-2 row-start-2 justify-self-center w-1/2'},
];

export const CharacterWheel: React.FC<CharacterWheelProps> = ({
  open,
  active,
  unlocked,
  cash,
  onSelect,
  onClose,
}) => {
  const [focusedId, setFocusedId] = useState<ProtagonistId>(active);

  if (!open) return null;

  const focused = PROTAGONISTS[focusedId];
  const focusedUnlocked = unlocked.includes(focusedId);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 p-4">
      <div className="w-full max-w-3xl rounded-xl border border-white/15 bg-[#0b0f16] p-5 shadow-2xl sm:p-6">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div>
            <h2 className="font-display text-xl font-bold tracking-wider text-white uppercase">
              Character Switch Wheel
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              Press Keys 1 / 2 / 3 or select a sector · Complete story missions to unlock Michael & Trevor
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-11 w-11 items-center justify-center rounded-lg border border-white/15 bg-slate-900 text-slate-300 hover:text-white"
            aria-label="Close Character Wheel"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-5 grid grid-cols-1 items-center gap-6 md:grid-cols-[1fr_290px]">
          {/* Radial 3-Sector GTA V Wheel */}
          <div className="relative mx-auto flex w-full max-w-[340px] flex-col items-center">
            <div className="relative grid w-full grid-cols-2 gap-3 rounded-2xl border border-white/10 bg-[#101722] p-4">
              {SLOTS.map(({id, keyNum, posClass}) => {
                const prof = PROTAGONISTS[id];
                const isUnlocked = unlocked.includes(id);
                const isCurrent = active === id;
                const isFocused = focusedId === id;

                return (
                  <button
                    key={id}
                    type="button"
                    onMouseEnter={() => setFocusedId(id)}
                    onFocus={() => setFocusedId(id)}
                    onClick={() => {
                      setFocusedId(id);
                      if (isUnlocked) {
                        onSelect(id);
                        onClose();
                      }
                    }}
                    className={`${posClass} group relative flex min-h-[112px] flex-col justify-between rounded-xl border p-3.5 text-left transition ${
                      isCurrent
                        ? 'border-white bg-slate-800/95'
                        : isFocused
                          ? 'border-white/40 bg-slate-900'
                          : 'border-white/10 bg-slate-950/80 hover:border-white/25'
                    } ${!isUnlocked ? 'opacity-70' : ''}`}
                    style={isCurrent ? {borderColor: prof.accentColor} : undefined}
                  >
                    <div className="flex w-full items-center justify-between">
                      <div
                        className="flex h-10 w-10 items-center justify-center rounded-lg font-display text-lg font-bold text-slate-950"
                        style={{
                          backgroundColor: isUnlocked ? prof.accentColor : '#334155',
                          color: isUnlocked ? '#090d16' : '#94a3b8',
                        }}
                      >
                        {isUnlocked ? prof.nickname : <Lock className="h-4 w-4" />}
                      </div>
                      <span className="font-mono-num text-xs font-semibold text-slate-400">
                        [{keyNum}]
                      </span>
                    </div>

                    <div className="mt-2">
                      <div className="font-display text-sm font-bold text-white">
                        {prof.name.split(' ')[0]}
                      </div>
                      <div className="font-mono-num text-xs font-semibold text-emerald-400">
                        {isUnlocked ? `$${cash[id].toLocaleString()}` : 'LOCKED'}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Character Dossier */}
          <div className="flex h-full flex-col justify-between rounded-xl border border-white/10 bg-[#101722] p-4">
            <div>
              <div className="flex items-center gap-3">
                <div
                  className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg font-display text-xl font-bold text-slate-950"
                  style={{backgroundColor: focusedUnlocked ? focused.accentColor : '#334155'}}
                >
                  {focusedUnlocked ? focused.nickname : <Lock className="h-5 w-5 text-slate-300" />}
                </div>
                <div>
                  <div className="font-display text-lg font-bold text-white">{focused.name}</div>
                  <div className="text-xs text-slate-400">
                    {focused.role} · {focused.district}
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-3 border-t border-white/10 pt-3">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                    <Sparkles className="h-3.5 w-3.5" style={{color: focused.accentColor}} />
                    <span>Special Ability: {focused.specialName}</span>
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-slate-400">
                    {focused.specialDesc}
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                    <Shield className="h-3.5 w-3.5 text-slate-400" />
                    <span>Personal Ride: {focused.vehicleLabel}</span>
                  </div>
                </div>

                {!focusedUnlocked && (
                  <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3">
                    <div className="text-xs font-bold text-amber-300 uppercase">Unlock Requirement</div>
                    <div className="mt-0.5 text-xs text-amber-100">{focused.unlockRequirement}</div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-3">
              <div>
                <div className="text-[11px] text-slate-400 uppercase">Bank Balance</div>
                <div className="font-mono-num text-base font-bold text-emerald-400">
                  ${cash[focusedId].toLocaleString()}
                </div>
              </div>

              {focusedUnlocked ? (
                <button
                  type="button"
                  onClick={() => {
                    onSelect(focusedId);
                    onClose();
                  }}
                  className="min-h-[42px] rounded-lg px-4 text-xs font-bold text-slate-950 transition hover:brightness-110"
                  style={{backgroundColor: focused.accentColor}}
                >
                  {active === focusedId ? 'Currently Active' : `Switch to ${focused.name.split(' ')[0]}`}
                </button>
              ) : (
                <div className="flex min-h-[42px] items-center gap-1.5 rounded-lg border border-white/10 bg-slate-900 px-3 text-xs font-semibold text-slate-400">
                  <Lock className="h-3.5 w-3.5" />
                  <span>Locked</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
