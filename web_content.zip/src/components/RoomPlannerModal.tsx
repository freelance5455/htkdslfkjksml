import React, { useState } from 'react';
import { X, CheckSquare, Square, ShoppingBag, Plus, Trash2, Sparkles } from 'lucide-react';
import { RoomChecklistItem, Room, CurrencyCode, Product } from '../types';
import { formatPrice } from '../utils/currency';

interface RoomPlannerModalProps {
  isOpen: boolean;
  checklist: RoomChecklistItem[];
  activeCurrency: CurrencyCode;
  products: Product[];
  onClose: () => void;
  onToggleItem: (id: string) => void;
  onAddCustomItem: (room: Room, name: string, costUsd: number) => void;
  onRemoveItem: (id: string) => void;
  onAddCheckedToCart: (checkedItems: RoomChecklistItem[]) => void;
}

const ROOM_TABS: Room[] = ['Bedroom', 'Kitchen', 'Dining Room', 'Living Room', 'Bathroom'];

export const RoomPlannerModal: React.FC<RoomPlannerModalProps> = ({
  isOpen,
  checklist,
  activeCurrency,
  products,
  onClose,
  onToggleItem,
  onAddCustomItem,
  onRemoveItem,
  onAddCheckedToCart
}) => {
  if (!isOpen) return null;

  const [activeRoom, setActiveRoom] = useState<Room>('Bedroom');
  const [newItemName, setNewItemName] = useState('');
  const [newItemCost, setNewItemCost] = useState('');

  const currentRoomItems = checklist.filter((item) => item.room === activeRoom);
  const checkedItems = currentRoomItems.filter((item) => item.checked);
  const totalRoomCostUsd = checkedItems.reduce((sum, item) => sum + item.estimatedCostUsd, 0);

  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;
    const cost = parseFloat(newItemCost) || 25;
    onAddCustomItem(activeRoom, newItemName.trim(), cost);
    setNewItemName('');
    setNewItemCost('');
  };

  const handleBundleAdd = () => {
    onAddCheckedToCart(checkedItems);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 relative flex flex-col p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-200">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-stone-700" />
              <h2 className="font-serif text-2xl font-semibold text-stone-900">
                Sanctuary Room Planner & Checklist
              </h2>
            </div>
            <p className="text-xs text-stone-500 mt-1">
              Curate the essential elements for each space and estimate full room setup costs.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Room Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-stone-200 pt-4 pb-2 overflow-x-auto">
          {ROOM_TABS.map((room) => {
            const count = checklist.filter((i) => i.room === room && i.checked).length;
            return (
              <button
                key={room}
                onClick={() => setActiveRoom(room)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  activeRoom === room
                    ? 'bg-stone-900 text-white'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                <span>{room}</span>
                <span className="ml-1.5 text-[10px] opacity-75">({count})</span>
              </button>
            );
          })}
        </div>

        {/* Checklist Content */}
        <div className="mt-6 flex-1 space-y-4">
          <div className="flex items-center justify-between text-xs text-stone-600 pb-2 border-b border-stone-100">
            <span>Essential Items for {activeRoom}</span>
            <span className="font-medium">
              Checked: {checkedItems.length} of {currentRoomItems.length}
            </span>
          </div>

          <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
            {currentRoomItems.map((item) => (
              <div
                key={item.id}
                onClick={() => onToggleItem(item.id)}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                  item.checked
                    ? 'bg-stone-50 border-stone-300'
                    : 'bg-white border-stone-200 opacity-60 hover:opacity-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  {item.checked ? (
                    <CheckSquare className="w-4 h-4 text-stone-900 shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-stone-400 shrink-0" />
                  )}
                  <div>
                    <span className={`text-xs font-medium text-stone-900 ${item.checked ? '' : 'line-through text-stone-500'}`}>
                      {item.name}
                    </span>
                    {item.productId && (
                      <span className="block text-[10px] text-stone-500">
                        In catalog inventory
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-semibold text-stone-800 tabular-nums">
                    {formatPrice(item.estimatedCostUsd, activeCurrency)}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveItem(item.id);
                    }}
                    className="text-stone-300 hover:text-rose-600 p-1"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Add custom item form */}
          <form onSubmit={handleAddNewItem} className="pt-3 border-t border-stone-100 flex gap-2">
            <input
              type="text"
              placeholder={`Add custom item to ${activeRoom}...`}
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              className="flex-1 px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white"
            />
            <input
              type="number"
              placeholder="Est. $ Cost"
              value={newItemCost}
              onChange={(e) => setNewItemCost(e.target.value)}
              className="w-24 px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white"
            />
            <button
              type="submit"
              className="px-3 py-1.5 bg-stone-800 text-white rounded-lg text-xs font-medium hover:bg-stone-900 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </form>
        </div>

        {/* Room Total & Add to Bag Footer */}
        <div className="mt-8 pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-xs text-stone-500 uppercase tracking-wider block">
              Estimated {activeRoom} Setup Total
            </span>
            <span className="font-serif text-2xl font-bold text-stone-900 tabular-nums">
              {formatPrice(totalRoomCostUsd, activeCurrency)}
            </span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={handleBundleAdd}
              disabled={checkedItems.length === 0}
              className="flex-1 sm:flex-initial px-6 py-2.5 bg-stone-900 text-white hover:bg-stone-800 disabled:bg-stone-300 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add Room Items to Bag</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
