import React, { useState, useEffect } from "react";
import { ScientificPlant, BiochemicalCompound } from "../types";
import {
  X,
  BookOpen,
  Dna,
  ExternalLink,
  Search,
  FlaskConical,
  Sprout,
  ShieldAlert,
  Sparkles,
} from "lucide-react";

interface BioscienceJournalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BioscienceJournalModal: React.FC<BioscienceJournalModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [speciesList, setSpeciesList] = useState<ScientificPlant[]>([]);
  const [selectedSpecies, setSelectedSpecies] = useState<ScientificPlant | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (!isOpen) return;
    setLoading(true);
    fetch("/api/science/plants")
      .then((res) => res.json())
      .then((data) => {
        if (data.species && Array.isArray(data.species)) {
          setSpeciesList(data.species);
          setSelectedSpecies(data.species[0] || null);
        }
      })
      .catch((err) => console.error("Failed to load science data", err))
      .finally(() => setLoading(false));
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredSpecies = speciesList.filter(
    (s) =>
      s.bengaliName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.scientificName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-4xl bg-stone-900 border-2 border-teal-600/70 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header following Scientific UI Guidelines */}
        <div className="bg-gradient-to-r from-stone-950 via-teal-950/60 to-stone-950 p-4 border-b border-teal-700/50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-teal-900/60 text-teal-300 rounded-xl border border-teal-500/40 shadow-inner">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-teal-200 font-['Hind_Siliguri']">
                  কচুবন বায়োসায়েন্স ও উদ্ভিদবিজ্ঞান ফিল্ড জার্নাল
                </h2>
                <span className="text-[10px] bg-teal-950 text-teal-300 px-2 py-0.5 rounded border border-teal-600/50 font-mono">
                  NCBI & PubChem Grounded
                </span>
              </div>
              <p className="text-xs text-stone-300">
                Ethnobotanical biochemistry of Colocasia esculenta, crop physiology & canine neurobiology
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-white hover:bg-stone-700 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Example Quick-Try Pill Bar (as specified by science skill) */}
        <div className="flex items-center gap-2 px-4 py-2 bg-stone-950 border-b border-stone-800 text-xs overflow-x-auto shrink-0">
          <span className="text-stone-400 text-[11px] shrink-0 font-medium">দ্রুত নির্বাচন:</span>
          {speciesList.map((sp) => (
            <button
              key={sp.id}
              onClick={() => setSelectedSpecies(sp)}
              className={`px-2.5 py-1 rounded-full text-xs font-mono whitespace-nowrap cursor-pointer transition ${
                selectedSpecies?.id === sp.id
                  ? "bg-teal-600 text-white font-bold shadow"
                  : "bg-stone-800 text-stone-300 hover:bg-stone-700"
              }`}
            >
              {sp.scientificName} ({sp.bengaliName.split(" ")[0]})
            </button>
          ))}
        </div>

        {/* Split Workbench View */}
        <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
          {/* Left: Species Navigation */}
          <div className="w-full md:w-72 bg-stone-950/80 border-r border-stone-800 p-3 overflow-y-auto shrink-0 flex flex-col gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="প্রজাতি খুঁজুন (Search)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-stone-900 border border-stone-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-stone-200 focus:outline-none focus:border-teal-500 font-['Hind_Siliguri']"
              />
            </div>

            <div className="space-y-1.5 mt-1">
              {filteredSpecies.map((sp) => {
                const isSelected = selectedSpecies?.id === sp.id;
                return (
                  <button
                    key={sp.id}
                    onClick={() => setSelectedSpecies(sp)}
                    className={`w-full text-left p-2.5 rounded-xl border transition cursor-pointer flex flex-col ${
                      isSelected
                        ? "bg-teal-950/80 border-teal-500 text-white shadow"
                        : "bg-stone-900/60 border-stone-800 text-stone-300 hover:bg-stone-800"
                    }`}
                  >
                    <span className="font-bold text-xs font-['Hind_Siliguri'] text-teal-300">
                      {sp.bengaliName}
                    </span>
                    <span className="text-[11px] text-stone-400 italic font-mono">
                      {sp.scientificName}
                    </span>
                    <span className="text-[10px] text-stone-500 mt-0.5">
                      Family: {sp.family}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Detailed Synchronized Scientific Inspector */}
          <div className="flex-1 p-5 overflow-y-auto bg-stone-900/90 text-stone-200 space-y-4">
            {selectedSpecies ? (
              <>
                {/* Botanical Card Header */}
                <div className="p-4 bg-stone-950 rounded-2xl border border-stone-800 shadow-md">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-bold text-amber-300 font-['Hind_Siliguri']">
                          {selectedSpecies.bengaliName}
                        </span>
                        <span className="text-xs bg-teal-900/80 text-teal-200 px-2 py-0.5 rounded border border-teal-600/40 font-mono">
                          [Literature curated]
                        </span>
                      </div>
                      <p className="text-sm italic font-mono text-stone-300 mt-1">
                        {selectedSpecies.scientificName} • Family: {selectedSpecies.family}
                      </p>
                    </div>

                    <a
                      href={`https://pubchem.ncbi.nlm.nih.gov/#query=${encodeURIComponent(
                        selectedSpecies.scientificName
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-[11px] text-teal-400 hover:text-teal-300 bg-teal-950/60 px-2.5 py-1 rounded-lg border border-teal-700/50"
                    >
                      <span>NCBI / PubChem Record</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  {/* Ethnobotany in Bengal */}
                  <div className="mt-3 text-xs bg-stone-900/80 p-3 rounded-xl border border-stone-800 leading-relaxed font-['Hind_Siliguri'] text-stone-200">
                    <strong className="text-teal-300">🌿 গ্রামীণ বাংলায় ব্যবহার ও বৈশিষ্ট্য:</strong>{" "}
                    {selectedSpecies.ethnobotanyBengali}
                  </div>
                </div>

                {/* Biochemical Compounds & Defense Mechanisms */}
                {selectedSpecies.biochemicalCompounds && (
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-teal-400 mb-2 flex items-center gap-1.5">
                      <Dna className="w-4 h-4" />
                      <span>বায়োকেমিক্যাল যৌগ ও জৈবিক ক্রিয়া (Compounds & Molecular Defense)</span>
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {selectedSpecies.biochemicalCompounds.map((comp, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-stone-950/90 rounded-xl border border-stone-800 flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-bold text-xs text-amber-200 font-mono">
                                {comp.name}
                              </span>
                              <span className="text-[10px] bg-stone-900 text-teal-300 px-1.5 py-0.5 rounded border border-stone-700 font-mono">
                                CID: {comp.pubchemCid}
                              </span>
                            </div>
                            <span className="text-[11px] font-mono text-stone-400 block mt-0.5">
                              সংকেত: {comp.formula}
                            </span>
                            <p className="text-xs text-stone-300 mt-2 leading-relaxed">
                              {comp.role}
                            </p>
                          </div>

                          <div className="mt-3 pt-2 border-t border-stone-900 flex justify-end">
                            <a
                              href={`https://pubchem.ncbi.nlm.nih.gov/compound/${comp.pubchemCid}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[10px] text-teal-400 hover:text-teal-300 flex items-center gap-1 font-mono"
                            >
                              <span>PubChem স্ট্রাকচার দেখুন</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Behavioral Neuroscience (for Black Dog) */}
                {(selectedSpecies as any).behavioralNeuroscience && (
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2 flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4" />
                      <span>কুকুরের স্নায়ুবিজ্ঞান ও লাঠির ভয় (Canine Fear Conditioning)</span>
                    </h3>
                    <div className="space-y-2">
                      {(selectedSpecies as any).behavioralNeuroscience.map(
                        (b: any, idx: number) => (
                          <div
                            key={idx}
                            className="p-3 bg-stone-950/90 rounded-xl border border-stone-800 text-xs space-y-1"
                          >
                            <div className="text-red-400 font-bold font-mono">
                              উদ্দীপক (Stimulus): {b.stimulus}
                            </div>
                            <div className="text-stone-300">
                              <strong className="text-teal-300">শারীরবৃত্তীয় প্রতিক্রিয়া:</strong>{" "}
                              {b.response}
                            </div>
                            <div className="text-stone-400 text-[11px]">
                              💡 {b.mechanic}
                            </div>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                )}

                {/* Cultivation & Soil requirements */}
                {selectedSpecies.soilRequirements && (
                  <div className="p-3 bg-stone-950/70 rounded-xl border border-stone-800 text-xs">
                    <span className="font-bold text-teal-300">মাটি ও চাষাবাদ নির্দেশিকা: </span>
                    <span className="text-stone-300">{selectedSpecies.soilRequirements}</span>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-16 text-stone-500">
                প্রজাতি নির্বাচন করুন
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 text-[11px] text-stone-400 flex items-center justify-between">
          <span>
            🔬 বিজ্ঞান ও এথনোবটানি ডাটাবেজ: Colocasia esculenta, Oryza sativa, Canis lupus familiaris
          </span>
          <span className="text-teal-400 font-mono">কচুবন বায়োসায়েন্স ল্যাব</span>
        </div>
      </div>
    </div>
  );
};
