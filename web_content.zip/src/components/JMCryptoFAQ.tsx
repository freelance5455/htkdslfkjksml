import React from 'react';
import { HelpCircle, Cpu, ShieldCheck, Lock, Zap, Coins, CheckCircle2, Globe } from 'lucide-react';

export const JMCryptoFAQ: React.FC = () => {
  const faqs = [
    {
      question: "How does the JM-CRYPTO mining process work?",
      answer: "JM-CRYPTO utilizes a proprietary sovereign consensus algorithm called Proof-of-Praise & Anointing (PoP) combined with SHA-256 Altar hashing. As your device runs the mining engine, it solves valid cryptographic nonces. Rewards are automatically governed by the 50/50 Device Share Rule: 50% goes directly to your claimable wallet, and 50% is allocated to the Protocol Treasury & Liquidity Reserve to back the $35,000 USD / ₦52,500,000 NGN peg."
    },
    {
      question: "What does 'high-speed' 100,000 hashrate mean for my device?",
      answer: "The 100,000 HashRate/sec (100 kH/s) velocity engine is optimized to compute high-frequency cryptographic solutions without straining your hardware. It operates under a strict 10% device power limit and automatic thermal throttle guard, ensuring zero battery drain, no overheating, and zero background execution when minimized or closed."
    },
    {
      question: "How does end-to-end encryption secure my wallet and mining data?",
      answer: "All wallet private keys, seed phrases, and mining balances are encrypted locally using AES-256 client-side encryption. No other user can view your wallet or mining statistics. Data privacy is strictly enforced, and transactions are only revealed publicly if you choose to participate in the JUHNKRIX MUSIKA Blockchain Public Chat Network."
    },
    {
      question: "Can I mine JM-CRYPTO 24/7 without daily limits?",
      answer: "Yes! There are no daily mining limits. As long as your device is turned on and the app is open, your rig continues mining at high speed. Once your unclaimed rewards reach the claimable threshold (e.g., 0.0500 JMC), an in-app real-time notification alert will notify you so you can claim your rewards instantly."
    },
    {
      question: "How can I exchange or withdraw my mined JM-CRYPTO?",
      answer: "Mined JM-CRYPTO can be swapped instantly within the app for USDT, BTC, ETH, SOL, BNB, or NGN fiat currency. You can also withdraw cash directly into your local Nigerian bank account (OPay, Wema, GTBank, etc. via Flutterwave & NIBSS clearing) or transfer crypto to over 500+ integrated external wallets like Coinbase, Trust Wallet, MetaMask, and Binance Pay."
    }
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950/40 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center space-x-4 relative z-10">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/30 border border-amber-300 flex-shrink-0">
            <HelpCircle className="w-7 h-7 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-3 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/40">
                KNOWLEDGE BASE & FAQ
              </span>
              <span className="text-xs text-slate-400 font-mono">JM-CRYPTO v4.5</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-100 font-serif mt-1">
              Frequently Asked Questions & Security Guide
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Everything you need to know about sovereign 100k H/s mining, 10% power limits, end-to-end wallet encryption, and global fiat exchange.
            </p>
          </div>
        </div>
      </div>

      {/* FAQ Accordion / Grid */}
      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <div 
            key={index}
            className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-6 shadow-xl hover:border-amber-400/60 transition-all space-y-3"
          >
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-bold text-xs flex-shrink-0 mt-0.5">
                0{index + 1}
              </div>
              <h3 className="text-base font-bold text-amber-100 font-serif">
                {faq.question}
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 pl-11 leading-relaxed">
              {faq.answer}
            </p>
          </div>
        ))}
      </div>

      {/* Security & Encryption Trust Box */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/40 border-2 border-emerald-500/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-5">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 flex-shrink-0">
            <Lock className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h4 className="text-base font-bold text-emerald-100 font-serif">
              End-to-End Encrypted Sovereign Security
            </h4>
            <p className="text-xs text-slate-300 mt-0.5">
              Your cryptographic keys and rewards never leave your device unencrypted. Fully audited for global compliance.
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs font-mono font-bold text-emerald-300 bg-emerald-500/10 px-4 py-2 rounded-xl border border-emerald-500/30">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>AES-256 SECURED</span>
        </div>
      </div>
    </div>
  );
};
