"use client";

import { useState } from "react";
import { apiDelete } from "@/lib/client/api";
import { CopyButton, Pill } from "./ui";

export type CalendarRow = {
  id: number;
  name: string;
  planLength: number;
  createdAt: string;
  days: { day: number; topic: string; platform: string; contentType: string; postTime: string }[];
};

export default function CalendarList({ initial }: { initial: CalendarRow[] }) {
  const [items, setItems] = useState(initial);
  const [openId, setOpenId] = useState<number | null>(initial[0]?.id ?? null);
  const [pending, setPending] = useState<number | null>(null);

  if (!items.length) {
    return (
      <div className="card p-6 text-center">
        <p className="text-sm font-medium">No saved plans yet</p>
        <p className="mt-1 text-sm text-[color:var(--muted)]">
          Generate a 7, 30 or 90 day plan above, then hit “Save plan” to keep it here.
        </p>
      </div>
    );
  }

  return (
    <ul className="space-y-2">
      {items.map((item) => {
        const isOpen = openId === item.id;
        const text = item.days
          .map((d) => `Day ${d.day}: ${d.topic}\n${d.platform} • ${d.contentType} • ${d.postTime}`)
          .join("\n\n");
        return (
          <li key={item.id} className="card overflow-hidden">
            <button
              type="button"
              className="flex w-full items-center justify-between gap-3 p-3 text-left"
              onClick={() => setOpenId(isOpen ? null : item.id)}
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{item.name}</p>
                <p className="text-xs text-[color:var(--muted)]">
                  {item.planLength} days • saved {new Date(item.createdAt).toLocaleDateString()}
                </p>
              </div>
              <span className="text-[color:var(--muted)]">{isOpen ? "▲" : "▼"}</span>
            </button>
            {isOpen ? (
              <div className="space-y-2 border-t border-white/10 p-3">
                <div className="flex flex-wrap gap-2">
                  <CopyButton value={text} label="Copy plan" />
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    disabled={pending === item.id}
                    onClick={async () => {
                      setPending(item.id);
                      try {
                        await apiDelete("/api/calendar", { id: item.id });
                        setItems((list) => list.filter((i) => i.id !== item.id));
                      } finally {
                        setPending(null);
                      }
                    }}
                  >
                    🗑 Delete
                  </button>
                </div>
                <ul className="grid gap-2 sm:grid-cols-2">
                  {item.days.map((d) => (
                    <li key={d.day} className="rounded-xl border border-white/10 bg-black/25 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold text-violet-200">Day {d.day}</p>
                        <Pill>{d.postTime}</Pill>
                      </div>
                      <p className="mt-1 text-sm">{d.topic}</p>
                      <p className="text-xs text-[color:var(--muted)]">
                        {d.platform} • {d.contentType}
                      </p>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </li>
        );
      })}
    </ul>
  );
}
