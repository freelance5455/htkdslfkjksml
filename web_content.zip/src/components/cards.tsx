"use client";

import Link from "next/link";
import { ArrowRight, Clock, Heart, MessageCircle } from "lucide-react";
import { useI18n, useSite } from "@/components/providers";
import { Avatar, buttonClass, ServiceIcon, Stars, VerificationBadge } from "@/components/ui";
import type { ArticleDTO, ProfessionalDTO, ServiceDTO } from "@/lib/types";
import { cn, formatPrice, loc } from "@/lib/utils";

const CATEGORY_GRADIENT: Record<string, string> = {
  nursing: "from-sky-500 to-cyan-400",
  wound: "from-teal-500 to-emerald-400",
  injections: "from-cyan-500 to-sky-400",
  monitoring: "from-emerald-500 to-teal-400",
  postop: "from-sky-600 to-teal-500",
  elderly: "from-teal-600 to-sky-400",
  hygiene: "from-sky-400 to-emerald-400",
  mobility: "from-emerald-600 to-sky-500",
  followup: "from-sky-500 to-indigo-400",
  chronic: "from-teal-500 to-cyan-600",
};

/** Service card: icon, description, price in MAD, and WhatsApp booking button with the service and price pre-filled. */
export function ServiceCard({ service }: { service: ServiceDTO }) {
  const { t, locale } = useI18n();
  const { whatsapp } = useSite();
  const name = loc(service.name, locale);
  const price = formatPrice(service.priceMad, locale);
  const message = t("wa.bookService", { service: name, price });

  return (
    <article className="group flex flex-col rounded-3xl bg-white p-6 shadow-sm ring-1 ring-sky-100/80 transition duration-300 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-sky-100">
      <div className="flex items-start justify-between gap-3">
        <div className={cn("flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br text-white shadow-md", CATEGORY_GRADIENT[service.category] ?? "from-teal-500 to-sky-500")}>
          <ServiceIcon name={service.icon} className="h-7 w-7" />
        </div>
        <div className="text-end">
          <p className="text-2xl font-extrabold text-slate-900">{price}</p>
          <p className="mt-0.5 inline-flex items-center gap-1 text-xs text-slate-500">
            <Clock className="h-3.5 w-3.5" />
            {service.durationMinutes} {t("common.minutes")}
          </p>
        </div>
      </div>
      <h3 className="mt-5 text-lg font-bold leading-snug text-slate-900">{name}</h3>
      <p className="mt-2 text-sm leading-relaxed text-slate-600">{loc(service.description, locale)}</p>
      <div className="mt-6 grid gap-2.5 sm:grid-cols-2">
        <a
          href={whatsapp(message)}
          target="_blank"
          rel="noopener noreferrer"
          className={buttonClass("whatsapp", "md", "w-full")}
          aria-label={`${t("btn.bookWhatsapp")}: ${name}`}
        >
          <MessageCircle className="h-5 w-5" />
          {t("btn.bookWhatsapp")}
        </a>
        <Link href={`/book?service=${service.slug}`} className={buttonClass("outline", "md", "w-full")}>
          {t("btn.book")}
        </Link>
      </div>
      <Link href={`/services/${service.slug}`} className="mt-3 inline-flex items-center justify-center gap-1 text-sm font-semibold text-teal-700 hover:underline">
        {t("btn.details")}
        <ArrowRight className="h-4 w-4 rtl:rotate-180" />
      </Link>
    </article>
  );
}

export function ArticleCard({
  article,
  favorited,
  onToggleFavorite,
}: {
  article: ArticleDTO;
  favorited?: boolean;
  onToggleFavorite?: () => void;
}) {
  const { t, locale } = useI18n();
  const { categoryName } = useSite();
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-sky-100/80 transition duration-300 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-sky-100">
      <div className="flex items-center justify-between gap-3 bg-gradient-to-br from-sky-50 via-white to-teal-50 px-5 py-4">
        <span className="text-3xl" aria-hidden>
          {article.emoji}
        </span>
        <span className="me-10 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-teal-800 ring-1 ring-teal-100">
          {categoryName(article.category)}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-base font-bold leading-snug text-slate-900">
          <Link href={`/articles/${article.slug}`} className="after:absolute after:inset-0 hover:text-teal-700">
            {loc(article.title, locale)}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-slate-600">{loc(article.summary, locale)}</p>
        <div className="mt-4 flex items-center gap-1 text-xs text-slate-500">
          <Clock className="h-3.5 w-3.5" />
          {t("art.readTime", { n: article.readMinutes })}
        </div>
      </div>
      {onToggleFavorite && (
        <button
          type="button"
          onClick={onToggleFavorite}
          aria-label={favorited ? t("art.favRemove") : t("art.favAdd")}
          aria-pressed={!!favorited}
          className="absolute end-3 top-3 z-10 rounded-full bg-white/95 p-2 shadow ring-1 ring-slate-100 transition hover:scale-110"
        >
          <Heart className={cn("h-[18px] w-[18px]", favorited ? "fill-rose-500 text-rose-500" : "text-slate-400")} />
        </button>
      )}
    </article>
  );
}

export function TipCard({ tip }: { tip: ArticleDTO }) {
  const { locale } = useI18n();
  const { categoryName } = useSite();
  return (
    <div className="flex gap-4 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-sky-100/80 transition hover:shadow-md">
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-50 to-sky-50 text-2xl ring-1 ring-emerald-100">
        {tip.emoji}
      </span>
      <div className="min-w-0">
        <p className="text-xs font-semibold uppercase tracking-wide text-teal-700">{categoryName(tip.category)}</p>
        <h3 className="mt-1 font-bold text-slate-900">{loc(tip.title, locale)}</h3>
        <p className="mt-1 text-sm leading-relaxed text-slate-600">{loc(tip.summary, locale)}</p>
      </div>
    </div>
  );
}

export function ProfessionalCard({ pro }: { pro: ProfessionalDTO }) {
  const { t, locale } = useI18n();
  return (
    <Link
      href={`/professionals/${pro.id}`}
      className="group flex flex-col rounded-2xl bg-white p-5 shadow-sm ring-1 ring-sky-100/80 transition duration-300 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-sky-100"
    >
      <div className="flex items-start gap-4">
        <Avatar src={pro.photoUrl} name={pro.fullName} className="h-16 w-16" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="truncate font-semibold text-slate-900">{pro.fullName}</h3>
            <VerificationBadge status={pro.verificationStatus} />
          </div>
          <p className="text-sm text-slate-600">
            {t(`pro.profession.${pro.profession}`)} · {pro.city}
          </p>
          <div className="mt-1 flex items-center gap-2 text-xs text-slate-500">
            <Stars value={pro.ratingAvg} size={13} />
            {pro.ratingCount > 0 ? <span>{pro.ratingAvg.toFixed(1)} · {t("pro.ratingCount", { n: pro.ratingCount })}</span> : <span>{t("pro.newPro")}</span>}
          </div>
        </div>
      </div>
      <p className="mt-4 line-clamp-2 text-sm leading-relaxed text-slate-600">{loc(pro.bio, locale)}</p>
      <div className="mt-auto flex items-center justify-between pt-5 text-sm">
        <span className="text-slate-500">{t("pro.experience", { n: pro.experienceYears })}</span>
        <span className="inline-flex items-center gap-1 font-semibold text-teal-700">
          {t("common.viewDetails")}
          <ArrowRight className="h-4 w-4 rtl:rotate-180" />
        </span>
      </div>
    </Link>
  );
}
