import React, { useState } from 'react';
import { PoketSafeData, IncomeFrequency } from '../types/budget';
import { 
  User, 
  Wallet, 
  Settings, 
  Bell, 
  Info, 
  RotateCcw, 
  ShieldCheck, 
  HardDrive
} from 'lucide-react';

interface ProfilePageProps {
  data: PoketSafeData;
  onUpdateIncome: (amount: number, frequency: IncomeFrequency) => void;
  onUpdateCurrentMoney: (amount: number) => void;
  onResetData: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  data,
  onUpdateIncome,
  onUpdateCurrentMoney,
  onResetData,
}) => {
  const [isEditingCash, setIsEditingCash] = useState(false);
  const [tempCash, setTempCash] = useState(data.currentMoney > 0 ? data.currentMoney.toString() : '');

  const [isEditingIncome, setIsEditingIncome] = useState(false);
  const [incomeAmount, setIncomeAmount] = useState((data.incomeAmount || 0) > 0 ? (data.incomeAmount || 0).toString() : '');
  const [incomeFreq, setIncomeFreq] = useState<IncomeFrequency>(data.incomeFrequency || 'monthly');

  // Local notification toggles
  const [dueReminders, setDueReminders] = useState(true);
  const [safeToSpendAlerts, setSafeToSpendAlerts] = useState(true);
  const [endOfMonthAudit, setEndOfMonthAudit] = useState(false);

  const handleSaveCash = () => {
    const val = parseFloat(tempCash) || 0;
    onUpdateCurrentMoney(val);
    setIsEditingCash(false);
  };

  const handleSaveIncome = () => {
    const val = parseFloat(incomeAmount) || 0;
    onUpdateIncome(val, incomeFreq);
    setIsEditingIncome(false);
  };

  return (
    <div className="space-y-4 pb-6">
      {/* 1. USER INFORMATION */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 text-slate-300 flex items-center justify-center shrink-0">
            <User className="w-6 h-6 text-slate-300" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white truncate">Personal Device User</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Active
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Offline & Private · On-Device Storage</span>
            </p>
          </div>
        </div>
      </div>

      {/* 2. INCOME FREQUENCY & FINANCIAL BASELINE */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg space-y-3">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Wallet className="w-3.5 h-3.5 text-emerald-400" />
          <span>Income & Cash Baseline</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          {/* Current Cash */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between text-slate-400">
              <span className="font-medium text-slate-300">Current Cash / Bank</span>
              <button
                onClick={() => {
                  setTempCash(data.currentMoney > 0 ? data.currentMoney.toString() : '');
                  setIsEditingCash(!isEditingCash);
                }}
                className="text-emerald-400 hover:text-emerald-300 font-medium"
              >
                {isEditingCash ? 'Cancel' : (data.currentMoney === 0 ? '+ Set' : 'Edit')}
              </button>
            </div>
            {isEditingCash ? (
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="number"
                  step="any"
                  autoFocus
                  placeholder="0.00"
                  value={tempCash}
                  onChange={e => setTempCash(e.target.value)}
                  className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm"
                />
                <button
                  onClick={handleSaveCash}
                  className="px-3 py-1.5 bg-emerald-500 text-slate-950 font-bold rounded-lg hover:bg-emerald-400"
                >
                  Save
                </button>
              </div>
            ) : (
              <div className="text-2xl font-bold font-mono text-white tabular-nums">
                RM {data.currentMoney.toFixed(2)}
              </div>
            )}
          </div>

          {/* Income Frequency */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between text-slate-400">
              <span className="font-medium text-slate-300">Income Frequency</span>
              <button
                onClick={() => {
                  setIncomeAmount((data.incomeAmount || 0) > 0 ? (data.incomeAmount || 0).toString() : '');
                  setIncomeFreq(data.incomeFrequency || 'monthly');
                  setIsEditingIncome(!isEditingIncome);
                }}
                className="text-emerald-400 hover:text-emerald-300 font-medium"
              >
                {isEditingIncome ? 'Cancel' : (data.incomeAmount === 0 ? '+ Set' : 'Edit')}
              </button>
            </div>

            {isEditingIncome ? (
              <div className="space-y-2 pt-1">
                <div className="flex items-center gap-1 p-0.5 bg-slate-900 rounded-lg border border-slate-800">
                  {(['daily', 'weekly', 'monthly'] as IncomeFrequency[]).map(freq => (
                    <button
                      key={freq}
                      type="button"
                      onClick={() => setIncomeFreq(freq)}
                      className={`flex-1 py-1 rounded text-[11px] capitalize transition-colors font-semibold ${
                        incomeFreq === freq
                          ? 'bg-emerald-500 text-slate-950'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {freq}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 font-mono text-xs">RM</span>
                  <input
                    type="number"
                    step="any"
                    autoFocus
                    placeholder="0.00"
                    value={incomeAmount}
                    onChange={e => setIncomeAmount(e.target.value)}
                    className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm"
                  />
                  <button
                    onClick={handleSaveIncome}
                    className="px-3 py-1.5 bg-emerald-500 text-slate-950 font-bold rounded-lg hover:bg-emerald-400"
                  >
                    Save
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                  RM {(data.incomeAmount || 0).toFixed(2)}
                </div>
                <div className="text-[11px] text-slate-400 capitalize mt-0.5">
                  Paid {data.incomeFrequency || 'monthly'}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. NOTIFICATIONS */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg space-y-3">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Bell className="w-3.5 h-3.5 text-blue-400" />
          <span>Notifications</span>
        </h3>

        <div className="divide-y divide-slate-800 text-xs">
          <div className="py-2.5 flex items-center justify-between">
            <div>
              <p className="font-medium text-white">Due Date Reminders</p>
              <p className="text-[10px] text-slate-400">Notify before commitments and loans are due</p>
            </div>
            <button
              onClick={() => setDueReminders(!dueReminders)}
              className={`w-10 h-5 rounded-full transition-colors relative ${dueReminders ? 'bg-emerald-500' : 'bg-slate-800'}`}
            >
              <div className={`w-4 h-4 rounded-full bg-white transition-transform ${dueReminders ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </div>

          <div className="py-2.5 flex items-center justify-between">
            <div>
              <p className="font-medium text-white">Safe-To-Spend Alerts</p>
              <p className="text-[10px] text-slate-400">Warn if safe balance reaches RM 0</p>
            </div>
            <button
              onClick={() => setSafeToSpendAlerts(!safeToSpendAlerts)}
              className={`w-10 h-5 rounded-full transition-colors relative ${safeToSpendAlerts ? 'bg-emerald-500' : 'bg-slate-800'}`}
            >
              <div className={`w-4 h-4 rounded-full bg-white transition-transform ${safeToSpendAlerts ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </div>

          <div className="py-2.5 flex items-center justify-between">
            <div>
              <p className="font-medium text-white">Month-End Balance Audit</p>
              <p className="text-[10px] text-slate-400">Prompt to reconcile real bank balance</p>
            </div>
            <button
              onClick={() => setEndOfMonthAudit(!endOfMonthAudit)}
              className={`w-10 h-5 rounded-full transition-colors relative ${endOfMonthAudit ? 'bg-emerald-500' : 'bg-slate-800'}`}
            >
              <div className={`w-4 h-4 rounded-full bg-white transition-transform ${endOfMonthAudit ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </div>
        </div>
      </div>

      {/* 4. APP SETTINGS */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg space-y-3">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Settings className="w-3.5 h-3.5 text-slate-400" />
          <span>App Settings</span>
        </h3>

        <div className="space-y-3 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-white">Default Currency</p>
              <p className="text-[10px] text-slate-400">Fixed throughout the app</p>
            </div>
            <span className="px-2.5 py-1 bg-slate-800 text-emerald-400 font-bold rounded-lg font-mono">
              RM (Ringgit)
            </span>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-slate-400" />
              <div>
                <p className="font-medium text-white">Local Device Storage</p>
                <p className="text-[10px] text-slate-400">Data never leaves your browser / phone</p>
              </div>
            </div>
            <button
              onClick={onResetData}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-rose-400 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear Data</span>
            </button>
          </div>
        </div>
      </div>

      {/* 5. ABOUT */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg space-y-2 text-xs">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-slate-400" />
          <span>About PoketSafe</span>
        </h3>

        <div className="space-y-1.5 text-slate-400">
          <div className="flex items-center justify-between text-slate-300">
            <span>Version</span>
            <span className="font-mono text-slate-400">2.4.0 (Personal Build)</span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span>Core Concept</span>
            <span className="font-mono text-emerald-400 text-[11px]">Safe To Spend = Cash − Commitments − Debts</span>
          </div>
          <p className="text-[10px] text-slate-500 pt-1">
            Built strictly for genuine daily personal finance. No ads, no third-party trackers, no bank scrapers.
          </p>
        </div>
      </div>
    </div>
  );
};
