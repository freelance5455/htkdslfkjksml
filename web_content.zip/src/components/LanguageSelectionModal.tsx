import React, { useState, useMemo } from 'react';
import { Globe, X, Search, Check, Sparkles } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { ALL_SUPPORTED_LANGUAGES, LanguageInfo } from '../lib/translations';

interface LanguageSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: Language;
  onSelectLanguage: (lang: Language) => void;
  userProfile?: UserProfile;
  setUserProfile?: React.Dispatch<React.SetStateAction<UserProfile>>;
}

export default function LanguageSelectionModal({
  isOpen,
  onClose,
  currentLanguage,
  onSelectLanguage,
  userProfile,
  setUserProfile
}: LanguageSelectionModalProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLanguages = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return ALL_SUPPORTED_LANGUAGES;
    return ALL_SUPPORTED_LANGUAGES.filter(
      l =>
        l.name.toLowerCase().includes(q) ||
        l.nativeName.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  if (!isOpen) return null;

  const handleSelect = (langCode: Language) => {
    onSelectLanguage(langCode);
    
    // Update document direction if RTL (Urdu, etc.)
    const langInfo = ALL_SUPPORTED_LANGUAGES.find(l => l.code === langCode);
    if (langInfo?.isRtl) {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }

    // Save to user profile & localStorage
    try {
      localStorage.setItem('edumind_language', langCode);
      if (userProfile && setUserProfile) {
        const updated = { ...userProfile, preferredLanguage: langCode };
        setUserProfile(updated);
        localStorage.setItem('edumind_user_profile', JSON.stringify(updated));
      }
    } catch (e) {
      console.error('Error saving language preference:', e);
    }
  };

  const isBengali = currentLanguage === 'bn';
  const isHindi = currentLanguage === 'hi';

  const modalTitle = isBengali
    ? 'অ্যাপের ভাষা নির্বাচন করুন'
    : isHindi
    ? 'ऐप की भाषा चुनें'
    : 'Select App Language';

  const modalSubtitle = isBengali
    ? '১. ইংরেজি (গ্লোবাল), ২. ভারতীয় বাংলা, ৩. হিন্দি'
    : isHindi
    ? '1. अंग्रेजी (ग्लोबल), 2. भारतीय बांग्ला, 3. हिन्दी'
    : '1. English (Global), 2. Indian Bengali, 3. Hindi';

  return (
    <div
      id="language-selection-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200"
    >
      <div
        id="language-selection-modal-card"
        className="bg-[#0e1424] border border-slate-700/80 rounded-3xl w-full max-w-md p-4 sm:p-5 shadow-2xl space-y-3.5 my-auto text-left relative overflow-hidden"
      >
        {/* Ambient Top Glow */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-indigo-500/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800/90 pb-3 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 rounded-2xl shadow-inner">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-1.5">
                <span>{modalTitle}</span>
              </h3>
              <p className="text-[11px] text-slate-400 font-medium">
                {modalSubtitle}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Search Input */}
        <div className="relative z-10">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isBengali
                  ? 'ভাষা অনুসন্ধান... (English, বাংলা, हिन्दी)'
                  : isHindi
                  ? 'भाषा खोजें... (English, हिन्दी, বাংলা)'
                  : 'Search language... (English, Bengali, Hindi)'
              }
              className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl pl-9 pr-8 py-2.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500/80 transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 text-slate-500 hover:text-slate-300 p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Language Radio Button List */}
        <div className="space-y-1.5 max-h-[340px] overflow-y-auto pr-1 select-none relative z-10 custom-scrollbar">
          {filteredLanguages.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              {isBengali
                ? 'কোনো ভাষা খুঁজে পাওয়া যায়নি'
                : isHindi
                ? 'कोई भाषा नहीं मिली'
                : 'No languages match your search'}
            </div>
          ) : (
            filteredLanguages.map((lang) => {
              const isSelected = currentLanguage === lang.code;
              return (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => handleSelect(lang.code)}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer text-left group ${
                    isSelected
                      ? 'bg-gradient-to-r from-indigo-950/90 via-indigo-900/40 to-slate-900 border-indigo-500/80 text-white shadow-md shadow-indigo-950/50'
                      : 'bg-slate-950/60 hover:bg-slate-900/80 border-slate-800/80 hover:border-slate-700 text-slate-200'
                  }`}
                >
                  {/* Left: Native Name & English Label */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 transition-transform group-hover:scale-105 ${
                        isSelected
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-slate-800/80 text-slate-400 border border-slate-700/50'
                      }`}
                    >
                      {lang.code.toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-bold tracking-wide ${isSelected ? 'text-white' : 'text-slate-100'}`}>
                          {lang.nativeName}
                        </span>
                        {lang.code === 'en' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30">
                            1 • Global
                          </span>
                        )}
                        {lang.code === 'bn' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                            2 • ভারত (India)
                          </span>
                        )}
                        {lang.code === 'hi' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                            3 • भारत (India)
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 font-normal block truncate">
                        {lang.name}
                      </span>
                    </div>
                  </div>

                  {/* Right: Modern Sleek Radio Button */}
                  <div className="shrink-0 pl-3">
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                        isSelected
                          ? 'border-indigo-500 bg-indigo-600 shadow-sm shadow-indigo-500/50'
                          : 'border-slate-600 bg-slate-900 group-hover:border-slate-400'
                      }`}
                    >
                      {isSelected ? (
                        <div className="w-2 h-2 rounded-full bg-white animate-in zoom-in-50 duration-150" />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-transparent" />
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Footer info & Apply button */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2 relative z-10">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>
              {isBengali
                ? 'স্বয়ংক্রিয়ভাবে সংরক্ষিত হবে'
                : isHindi
                ? 'स्वचालित रूप से सहेजा गया'
                : 'Auto-saved to profile'}
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
          >
            {isBengali ? 'সম্পন্ন' : isHindi ? 'पूर्ण' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
}
