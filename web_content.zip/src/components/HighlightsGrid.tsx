import React from 'react';
import { HighlightVideo, Match } from '../types';
import { Play, Clock, Eye, Flame, Trophy } from 'lucide-react';

interface HighlightsGridProps {
  highlights: HighlightVideo[];
  onPlayHighlight: (highlight: HighlightVideo) => void;
}

export const HighlightsGrid: React.FC<HighlightsGridProps> = ({ highlights, onPlayHighlight }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2 font-['Changa']">
            <Flame className="w-5 h-5 text-amber-500" />
            <span>أهداف وملخصات مباريات اليوم والأمس</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            شاهد جميع أهداف القمم الكروية بجودة عالية HD
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {highlights.map((hl) => (
          <div
            key={hl.id}
            id={`highlight-card-${hl.id}`}
            onClick={() => onPlayHighlight(hl)}
            className="group bg-white dark:bg-[#111624] hover:bg-slate-50/90 dark:hover:bg-[#151c2e] border border-slate-200 dark:border-slate-800 hover:border-rose-400 dark:hover:border-rose-500/50 rounded-2xl overflow-hidden shadow-sm dark:shadow-xl transition-all duration-300 hover:shadow-md dark:hover:shadow-2xl cursor-pointer flex flex-col justify-between"
          >
            {/* Thumbnail Box */}
            <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
              <img
                src={hl.thumbnail}
                alt={hl.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

              {/* Duration badge */}
              <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md bg-black/80 backdrop-blur-xs text-[10px] font-mono font-bold text-white border border-white/10">
                {hl.duration}
              </span>

              {/* Tournament tag */}
              <span className="absolute top-2 right-2 px-2.5 py-0.5 rounded-full bg-rose-600/90 backdrop-blur-xs text-[10px] font-bold text-white shadow">
                {hl.tournament}
              </span>

              {/* Play icon overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-rose-600 group-hover:bg-rose-500 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                  <Play className="w-5 h-5 fill-white mr-0.5" />
                </div>
              </div>
            </div>

            {/* Title & Stats */}
            <div className="p-4 space-y-2">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors line-clamp-2 leading-snug">
                {hl.title}
              </h3>

              <div className="p-2 rounded-lg bg-amber-50 dark:bg-[#182133] border border-amber-200/70 dark:border-transparent text-[11px] text-amber-800 dark:text-amber-300 font-medium">
                ⚽ {hl.goalsSummary}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                <div className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                  <span>{hl.views}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                  <span>{hl.date}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
