import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wrench, 
  Cpu, 
  Smartphone, 
  Sparkles, 
  Zap, 
  Unlock, 
  CreditCard, 
  Languages, 
  Layers, 
  ArrowLeft,
  Headphones,
  CheckCircle2
} from 'lucide-react';

interface SplashSignboardProps {
  onComplete: () => void;
}

const services = [
  { name: 'قطع غيار أصلية', icon: Layers, tag: 'شاشات وبطاريات' },
  { name: 'إكسسوارات', icon: Headphones, tag: 'حمايات وشواحن' },
  { name: 'صيانة', icon: Wrench, tag: 'هاردوير متقدم' },
  { name: 'برمجة', icon: Cpu, tag: 'سوفتوير وفلاش' },
  { name: 'شحن فوري', icon: Zap, tag: 'رصيد وباقات' },
  { name: 'فك شفرات', icon: Unlock, tag: 'جميع الشبكات' },
  { name: 'شرائح', icon: Smartphone, tag: 'تفعيل وبدل فاقد' },
  { name: 'كروت', icon: CreditCard, tag: 'إنترنت وألعاب' },
  { name: 'تعريب', icon: Languages, tag: 'لكافة الأجهزة' },
];

export const SplashSignboard: React.FC<SplashSignboardProps> = ({ onComplete }) => {
  const [timeLeft, setTimeLeft] = useState<number>(4);
  const [progress, setProgress] = useState<number>(100);

  useEffect(() => {
    const totalDuration = 4000;
    const intervalTime = 50;
    const startTime = Date.now();

    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remainingMs = Math.max(0, totalDuration - elapsed);
      const remainingSeconds = Math.ceil(remainingMs / 1000);
      
      setTimeLeft(remainingSeconds);
      setProgress((remainingMs / totalDuration) * 100);

      if (remainingMs <= 0) {
        clearInterval(timer);
        onComplete();
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950 overflow-y-auto px-4 py-6">
      {/* Background ambient lighting */}
      <div className="absolute inset-0 bg-radial from-red-950/40 via-slate-950 to-black pointer-events-none" />
      <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-red-600 via-white to-red-600" />

      {/* Main Signboard Canvas (Simulating Shop Storefront Plaque) */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-2xl bg-white text-slate-950 rounded-3xl shadow-2xl border-4 border-red-600 overflow-hidden flex flex-col my-auto"
      >
        {/* Top Header of Plaque: Red Ribbon with Shop Title */}
        <div className="relative bg-gradient-to-r from-red-700 via-red-600 to-red-800 text-white px-6 py-5 text-center shadow-lg border-b-2 border-red-900">
          {/* Subtle Islamic/Geometric or tech background motif */}
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-black pointer-events-none" />

          {/* Shop Name in Big Prominent Calligraphy Style */}
          <div className="relative flex flex-col items-center justify-center">
            <div className="inline-flex items-center gap-2 mb-1">
              <span className="w-8 h-0.5 bg-white/70 rounded-full" />
              <span className="text-xs uppercase tracking-widest text-red-100 font-semibold">
                لوحة المحل المعتمدة
              </span>
              <span className="w-8 h-0.5 bg-white/70 rounded-full" />
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-white drop-shadow-md leading-tight font-heading">
              العجردي
            </h1>

            <p className="mt-1 text-base sm:text-xl font-bold text-red-100 tracking-wide">
              لصيانة وبرمجة الجوال
            </p>
          </div>
        </div>

        {/* Visual Workbench Banner & Smartphone Repair Image */}
        <div className="relative h-44 sm:h-52 w-full overflow-hidden bg-slate-900">
          <img
            src="/src/assets/images/alajradi_phone_repair_1793106557031.jpg"
            alt="صيانة وبرمجة الجوال - العجردي"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-95"
          />
          {/* Subtle contrast gradient for clean integration */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          
          <div className="absolute bottom-3 inset-x-4 flex items-center justify-between text-white text-xs">
            <span className="inline-flex items-center gap-1.5 bg-red-600/90 text-white font-medium px-2.5 py-1 rounded-md backdrop-blur-sm shadow">
              <Sparkles className="w-3.5 h-3.5" />
              أحدث أجهزة الفحص المجهري والبرمجة الدقيقة
            </span>
            <span className="hidden sm:inline-block text-slate-200 font-medium">
              خبرة واحترافية متكاملة
            </span>
          </div>
        </div>

        {/* Services Grid (In neat, coordinated, clear boxes) */}
        <div className="p-4 sm:p-6 bg-slate-50 flex-1">
          <div className="text-center mb-3">
            <span className="text-xs font-bold text-red-700 bg-red-100/80 px-3 py-1 rounded-full border border-red-200">
              خدماتنا الشاملة والمتكاملة
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            {services.map((item, idx) => {
              const IconComp = item.icon;
              return (
                <motion.div
                  key={item.name}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * idx, duration: 0.25 }}
                  className="bg-white border border-red-100 hover:border-red-400 rounded-xl p-2 sm:p-2.5 text-center shadow-xs transition-all flex flex-col items-center justify-center group"
                >
                  <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center mb-1.5 group-hover:bg-red-600 group-hover:text-white transition-colors">
                    <IconComp className="w-4 h-4" />
                  </div>
                  <span className="text-xs sm:text-sm font-bold text-slate-900 leading-tight">
                    {item.name}
                  </span>
                  <span className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">
                    {item.tag}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Bottom Bar: Timer, ScreenSound Fixer Branding, Skip Button */}
        <div className="bg-white border-t border-slate-200 p-3 sm:p-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-red-600 text-white font-bold text-xs flex items-center justify-center font-mono">
              {timeLeft}
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-slate-900">
                ScreenSound Fixer
              </p>
              <p className="text-[10px] text-slate-500">
                الانتقال التلقائي خلال {timeLeft} ثوانٍ...
              </p>
            </div>
          </div>

          {/* Skip Button */}
          <button
            onClick={onComplete}
            className="inline-flex items-center gap-1.5 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all cursor-pointer"
          >
            <span>دخول التطبيق الآن</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Linear Progress Bar at bottom */}
        <div className="w-full bg-slate-200 h-1.5">
          <div
            className="bg-red-600 h-full transition-all duration-75 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      </motion.div>
    </div>
  );
};
