import React from 'react';
import { HeartPulse, Home, Play, Save } from 'lucide-react';
import { GamePhase } from '../types/game';
import { PWAInstallButton } from './PWAInstallButton';

interface PauseMenuProps {
  phase: GamePhase;
  onResume: () => void;
  onSaveGame: () => void;
  onRespawnHospital: () => void;
  onExitToTitle: () => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({
  phase,
  onResume,
  onSaveGame,
  onRespawnHospital,
  onExitToTitle,
}) => {
  if (phase === 'wasted') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-rose-950/75">
        <div className="w-full max-w-sm bg-slate-950 border-2 border-rose-500 rounded-2xl p-6 text-center shadow-2xl space-y-4">
          <div className="text-3xl font-black tracking-widest text-rose-500">WASTED</div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Karachi emergency paramedics picked you up and stabilized you at Jinnah Saddar Hospital.
          </p>
          <button
            type="button"
            onClick={onRespawnHospital}
            className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 cursor-pointer"
          >
            <HeartPulse className="w-4 h-4" />
            RESPAWN AT HOSPITAL (-Rs. 2,500)
          </button>
        </div>
      </div>
    );
  }

  if (phase !== 'paused') return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75">
      <div className="w-full max-w-sm bg-slate-950 border-2 border-slate-700 rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="text-center">
          <div className="text-xs font-black tracking-[0.25em] text-amber-400 uppercase">
            AQ GAMES · GKC 1
          </div>
          <h2 className="text-xl font-black text-white mt-1">GAME PAUSED</h2>
        </div>

        <div className="space-y-2.5">
          <button
            type="button"
            onClick={onResume}
            className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-slate-950" /> RESUME KARACHI
          </button>
          <button
            type="button"
            onClick={onSaveGame}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
          >
            <Save className="w-4 h-4" /> SAVE PROGRESS
          </button>
          <button
            type="button"
            onClick={onExitToTitle}
            className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" /> TITLE SCREEN
          </button>
          <PWAInstallButton compact />
        </div>

        <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
          <div className="font-bold text-slate-300">Controls</div>
          <div>Move / Steer: WASD or Arrow Keys (or Touch Joystick)</div>
          <div>Jump / Handbrake: Space · Sprint: Shift</div>
          <div>Enter / Exit Vehicle: F · Interact Shop: E · Horn: H</div>
          <div>Camera (3rd / 1st / Cine): C · K-Phone: P</div>
        </div>
      </div>
    </div>
  );
};
