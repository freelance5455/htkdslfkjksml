import React, { useState } from "react";
import {
  X,
  Trash2,
  RotateCcw,
  AlertTriangle,
  ShieldAlert,
  Search,
  CheckSquare,
  Square,
  Clock,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  FolderOpen
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { TrashItem } from "../types";

interface TrashModalProps {
  trash: TrashItem[];
  onRestore: (id: string) => void;
  onDeleteForever: (id: string) => void;
  onEmptyTrash: () => void;
  onClose: () => void;
}

export const TrashModal: React.FC<TrashModalProps> = ({
  trash,
  onRestore,
  onDeleteForever,
  onEmptyTrash,
  onClose,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Filtered trash items based on search query
  const filteredTrash = trash.filter((item) => {
    const titleMatch = (item.title || "").toLowerCase().includes(searchQuery.toLowerCase());
    const contentMatch = (item.content || "").toLowerCase().includes(searchQuery.toLowerCase());
    const catMatch = (item.category || "").toLowerCase().includes(searchQuery.toLowerCase());
    return titleMatch || contentMatch || catMatch;
  });

  const formatDate = (isoString: string) => {
    try {
      return new Date(isoString).toLocaleDateString("tr-TR", {
        day: "numeric",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "";
    }
  };

  // Calculate remaining retention days (out of 30 days)
  const getRemainingDays = (deletedAtIso: string) => {
    try {
      const deletedDate = new Date(deletedAtIso).getTime();
      const now = Date.now();
      const elapsedDays = Math.floor((now - deletedDate) / (1000 * 60 * 60 * 24));
      const remaining = Math.max(0, 30 - elapsedDays);
      return remaining;
    } catch {
      return 30;
    }
  };

  // Selection toggle
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedIds.length === filteredTrash.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredTrash.map((item) => item.id));
    }
  };

  // Batch restore
  const handleBatchRestore = () => {
    if (selectedIds.length === 0) return;
    selectedIds.forEach((id) => onRestore(id));
    setSelectedIds([]);
  };

  // Batch delete forever
  const handleBatchDeleteForever = () => {
    if (selectedIds.length === 0) return;
    if (
      confirm(
        `Seçilen ${selectedIds.length} not kalıcı olarak silinecektir. Bu işlem geri alınamaz. Onaylıyor musunuz?`
      )
    ) {
      selectedIds.forEach((id) => onDeleteForever(id));
      setSelectedIds([]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">Çöp Kutusu & Geri Yükleme</h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 font-bold text-slate-600 dark:text-slate-300">
                  {trash.length}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Silinen notları geri kurtarın veya kalıcı olarak temizleyin
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Info notice banner */}
        <div className="px-5 py-2.5 bg-amber-50/80 dark:bg-amber-950/30 border-b border-amber-200/60 dark:border-amber-900/50 flex items-center justify-between gap-2 text-xs text-amber-800 dark:text-amber-300">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
            <span>Notlar 30 gün boyunca saklanır, ardından kalıcı silinir.</span>
          </div>
          {trash.length > 0 && (
            <button
              onClick={() => {
                if (confirm("Çöp kutusundaki TÜM notlar kalıcı olarak silinecektir. Onaylıyor musunuz?")) {
                  onEmptyTrash();
                }
              }}
              className="text-[11px] font-extrabold text-rose-600 dark:text-rose-400 hover:underline shrink-0 cursor-pointer"
            >
              Hepsini Temizle
            </button>
          )}
        </div>

        {/* Search & Batch Actions Bar */}
        {trash.length > 0 && (
          <div className="p-3.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Çöp kutusunda ara..."
                className="w-full pl-9 pr-3 py-1.5 rounded-xl text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 dark:text-slate-200"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={selectAll}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                {selectedIds.length === filteredTrash.length && filteredTrash.length > 0 ? (
                  <CheckSquare className="w-3.5 h-3.5 text-blue-600" />
                ) : (
                  <Square className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span>{selectedIds.length > 0 ? `${selectedIds.length} Seçildi` : "Tümünü Seç"}</span>
              </button>

              {selectedIds.length > 0 && (
                <>
                  <button
                    onClick={handleBatchRestore}
                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Seçilenleri Kurtar</span>
                  </button>

                  <button
                    onClick={handleBatchDeleteForever}
                    className="flex items-center gap-1 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Sil</span>
                  </button>
                </>
              )}
            </div>
          </div>
        )}

        {/* Trash list */}
        <div className="p-4 overflow-y-auto flex-1 space-y-2.5">
          {trash.length === 0 ? (
            <div className="text-center py-16 text-slate-400 space-y-2">
              <div className="w-14 h-14 bg-slate-100 dark:bg-slate-800 rounded-3xl flex items-center justify-center mx-auto text-slate-400">
                <Trash2 className="w-7 h-7 opacity-40" />
              </div>
              <p className="text-xs font-bold text-slate-600 dark:text-slate-300">Çöp kutunuz tertemiz</p>
              <p className="text-[11px] text-slate-400">Silinen herhangi bir not bulunmuyor.</p>
            </div>
          ) : filteredTrash.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs font-semibold">
              Aramanızla eşleşen silinmiş not bulunamadı.
            </div>
          ) : (
            filteredTrash.map((item) => {
              const isSelected = selectedIds.includes(item.id);
              const isExpanded = expandedId === item.id;
              const remainingDays = getRemainingDays(item.deletedAt);

              return (
                <div
                  key={item.id}
                  className={`rounded-2xl border transition-all ${
                    isSelected
                      ? "bg-blue-50/70 dark:bg-blue-950/30 border-blue-300 dark:border-blue-700"
                      : "bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700/80 hover:border-slate-300"
                  }`}
                >
                  <div className="p-3.5 flex items-start gap-3">
                    {/* Checkbox */}
                    <button
                      type="button"
                      onClick={() => toggleSelect(item.id)}
                      className="mt-0.5 text-slate-400 hover:text-blue-600 transition-colors cursor-pointer"
                    >
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 text-blue-600" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-300 dark:text-slate-600" />
                      )}
                    </button>

                    {/* Note Content Info */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                        <span className="font-bold text-xs text-slate-900 dark:text-white truncate">
                          {item.title || "Başlıksız Not"}
                        </span>

                        {item.category && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                            {item.category}
                          </span>
                        )}

                        {item.originalVault && (
                          <span className="flex items-center gap-0.5 text-[10px] font-bold text-amber-700 bg-amber-100 dark:bg-amber-950 dark:text-amber-300 px-1.5 py-0.5 rounded-md">
                            <ShieldAlert className="w-3 h-3" /> Gizli Kasa
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mb-2">
                        {item.content || "(İçerik boş)"}
                      </p>

                      <div className="flex items-center gap-3 text-[10px] text-slate-400">
                        <span>Silinme: {formatDate(item.deletedAt)}</span>
                        <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400 font-bold">
                          <Clock className="w-3 h-3" /> {remainingDays} gün kaldı
                        </span>
                        <button
                          type="button"
                          onClick={() => setExpandedId(isExpanded ? null : item.id)}
                          className="text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-0.5 cursor-pointer ml-auto"
                        >
                          <span>{isExpanded ? "Gizle" : "Önizle"}</span>
                          {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>

                    {/* Quick Action Buttons */}
                    <div className="flex items-center gap-1.5 shrink-0 ml-1">
                      <button
                        onClick={() => onRestore(item.id)}
                        title="Notu Kurtar"
                        className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Kurtar</span>
                      </button>

                      <button
                        onClick={() => {
                          if (confirm("Bu not kalıcı olarak silinecektir. Onaylıyor musunuz?")) {
                            onDeleteForever(item.id);
                          }
                        }}
                        title="Kalıcı Olarak Sil"
                        className="p-1.5 text-rose-500 hover:bg-rose-100 dark:hover:bg-rose-950/50 rounded-xl transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Expanded Full Preview */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="px-4 pb-3.5 pt-1 text-xs text-slate-700 dark:text-slate-300 border-t border-slate-200/60 dark:border-slate-700/60 bg-white/50 dark:bg-slate-900/50 rounded-b-2xl"
                      >
                        <div className="whitespace-pre-wrap font-sans text-xs bg-slate-100/70 dark:bg-slate-800/80 p-3 rounded-xl max-h-48 overflow-y-auto">
                          {item.content || "(İçerik boş)"}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50 flex justify-between items-center">
          <span className="text-[11px] text-slate-400">
            {trash.length > 0 ? `${trash.length} adet silinmiş not` : "Çöp kutusu boş"}
          </span>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
