import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Youtube,
  Globe,
  Settings,
  MessageSquare,
  Phone,
  Clock,
  FileText,
  Calculator,
  ShieldCheck,
  AlertTriangle,
  Send,
  Plus,
  Trash2,
  ExternalLink,
  Flashlight,
  Volume2,
  VolumeX,
  Wifi,
  Bluetooth,
  Sparkles,
  Layers,
  Smartphone,
  Battery,
  BatteryCharging,
  Vibrate,
  Radio,
  Sun,
  MapPin,
  Compass,
  Copy,
  Check,
  Share2,
  Play,
  Square,
  Sliders,
  Zap,
  Activity,
  Mic,
  Navigation,
  CheckCircle2
} from 'lucide-react';
import { SupportedLanguage } from '../types';

interface PhoneToolsTabProps {
  language: SupportedLanguage;
}

export const PhoneToolsTab: React.FC<PhoneToolsTabProps> = ({ language }) => {
  const [activeTool, setActiveTool] = useState<
    'controls' | 'intents' | 'launcher' | 'sms' | 'alarm' | 'camera' | 'sensors' | 'calculator' | 'notes'
  >('controls');

  // Control Toast Feedback
  const [controlToast, setControlToast] = useState<string | null>(null);
  const triggerControlToast = (msg: string) => {
    setControlToast(msg);
    setTimeout(() => setControlToast(null), 3500);
  };

  // Hardware Controls State
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [isScreenTorchActive, setIsScreenTorchActive] = useState(false);
  const [isStrobeActive, setIsStrobeActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volumeLevel, setVolumeLevel] = useState(75);
  const [isWakeLockActive, setIsWakeLockActive] = useState(false);
  const [isFloatingHeadEnabled, setIsFloatingHeadEnabled] = useState(true);

  // Live Device Telemetry
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState<boolean>(false);
  const [networkType, setNetworkType] = useState<string>('Online (High Speed)');
  const [orientation, setOrientation] = useState<{ alpha: number; beta: number; gamma: number }>({
    alpha: 0,
    beta: 0,
    gamma: 0,
  });

  // Refs for Hardware APIs
  const torchStreamRef = useRef<MediaStream | null>(null);
  const wakeLockRef = useRef<any>(null);
  const strobeIntervalRef = useRef<any>(null);

  // Camera state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // SMS Composer state
  const [smsRecipient, setSmsRecipient] = useState('+923001234567');
  const [smsMessage, setSmsMessage] = useState('Salam! Main DOST AI Android Agent se rabta kar raha hoon.');
  const [showSmsConfirmation, setShowSmsConfirmation] = useState(false);
  const [smsSuccessMessage, setSmsSuccessMessage] = useState<string | null>(null);

  // Alarm state
  const [alarmHour, setAlarmHour] = useState('07');
  const [alarmMinute, setAlarmMinute] = useState('30');
  const [alarmMessage, setAlarmMessage] = useState('Namaz, Crypto Watch & Daily Routine');
  const [alarmStatus, setAlarmStatus] = useState<string | null>(null);

  // WhatsApp Rapid Dispatcher state
  const [waCountryCode, setWaCountryCode] = useState('+92');
  const [waNumber, setWaNumber] = useState('3001234567');
  const [waMessage, setWaMessage] = useState('Salam bhai! DOST AI se message bhej raha hoon.');

  // Maps Live Navigation state
  const [navDestination, setNavDestination] = useState('Blue Area, Islamabad');

  // Calculator state
  const [calcInput, setCalcInput] = useState('');
  const [calcResult, setCalcResult] = useState('');

  // Quick 2% Risk Calculator
  const [accountBalance, setAccountBalance] = useState('1000');
  const [stopLossDistancePercent, setStopLossDistancePercent] = useState('3.5');

  // Notes state
  const [notes, setNotes] = useState<Array<{ id: string; title: string; body: string; date: string }>>(() => {
    const saved = localStorage.getItem('dost_notes');
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: '1',
            title: 'Crypto Disciplined Rules',
            body: '1. Always respect Stop Loss\n2. Never risk > 2% per trade\n3. DOST AI signals are advisory, stick to risk control.',
            date: 'Today',
          },
          {
            id: '2',
            title: 'Android Intent Allowlist',
            body: 'Restricted safe intents: Camera, Chrome, YouTube, Settings, Messages, Phone, WhatsApp.',
            date: 'Yesterday',
          },
        ];
  });
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteBody, setNewNoteBody] = useState('');
  const [clipboardCopied, setClipboardCopied] = useState(false);

  // Detect Live Battery & Network Status
  useEffect(() => {
    // Battery API
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setBatteryLevel(Math.round(battery.level * 100));
        setIsCharging(battery.charging);
        battery.addEventListener('levelchange', () => {
          setBatteryLevel(Math.round(battery.level * 100));
        });
        battery.addEventListener('chargingchange', () => {
          setIsCharging(battery.charging);
        });
      }).catch(() => {
        setBatteryLevel(88);
      });
    } else {
      setBatteryLevel(88);
    }

    // Network API
    const conn = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
    if (conn) {
      const typeStr = conn.effectiveType ? `${conn.effectiveType.toUpperCase()} Network` : '4G LTE';
      setNetworkType(typeStr);
    }

    // Orientation API
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (e.alpha !== null) {
        setOrientation({
          alpha: Math.round(e.alpha || 0),
          beta: Math.round(e.beta || 0),
          gamma: Math.round(e.gamma || 0),
        });
      }
    };

    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', handleOrientation);
    }

    return () => {
      if (window.DeviceOrientationEvent) {
        window.removeEventListener('deviceorientation', handleOrientation);
      }
      if (strobeIntervalRef.current) {
        clearInterval(strobeIntervalRef.current);
      }
      if (torchStreamRef.current) {
        torchStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (wakeLockRef.current) {
        wakeLockRef.current.release().catch(() => {});
      }
    };
  }, []);

  // REAL FLASHLIGHT / TORCH CONTROLLER
  const toggleRealTorch = async () => {
    if (isTorchOn) {
      // Turn OFF
      if (torchStreamRef.current) {
        torchStreamRef.current.getTracks().forEach((track) => track.stop());
        torchStreamRef.current = null;
      }
      if (strobeIntervalRef.current) {
        clearInterval(strobeIntervalRef.current);
        strobeIntervalRef.current = null;
      }
      setIsTorchOn(false);
      setIsStrobeActive(false);
      setIsScreenTorchActive(false);
      triggerControlToast('Flashlight Turned OFF');
    } else {
      // Turn ON
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } },
        });
        torchStreamRef.current = stream;
        const track = stream.getVideoTracks()[0];
        const capabilities = (track.getCapabilities?.() as any) || {};

        if (capabilities.torch) {
          await (track as any).applyConstraints({ advanced: [{ torch: true }] });
          setIsTorchOn(true);
          triggerControlToast('⚡ Camera LED Flashlight ACTIVATED!');
        } else {
          // Hardware LED torch not supported by this stream, activate high-luminescence screen torch
          setIsTorchOn(true);
          setIsScreenTorchActive(true);
          triggerControlToast('💡 Camera LED torch unsupported on this sensor. Screen Torch activated!');
        }
      } catch (err: any) {
        // Fallback to screen flashlight
        setIsTorchOn(true);
        setIsScreenTorchActive(true);
        triggerControlToast('💡 Screen Flashlight Activated (Max Brightness Luminescence)');
      }
    }
  };

  // SOS STROBE FLASHLIGHT
  const toggleStrobeTorch = () => {
    if (isStrobeActive) {
      if (strobeIntervalRef.current) {
        clearInterval(strobeIntervalRef.current);
        strobeIntervalRef.current = null;
      }
      setIsStrobeActive(false);
      setIsScreenTorchActive(false);
      triggerControlToast('SOS Strobe beacon stopped');
    } else {
      setIsStrobeActive(true);
      setIsTorchOn(true);
      let state = false;
      strobeIntervalRef.current = setInterval(() => {
        state = !state;
        setIsScreenTorchActive(state);
      }, 200);
      triggerControlToast('🚨 Emergency SOS Strobe Beacon Active!');
    }
  };

  // REAL HAPTIC VIBRATION
  const triggerVibration = (pattern: number | number[], label: string) => {
    if ('vibrate' in navigator) {
      navigator.vibrate(pattern);
      triggerControlToast(`📳 Haptic Vibrate: ${label}`);
    } else {
      triggerControlToast(`📳 Vibration: ${label} (Simulated - hardware haptics require mobile device)`);
    }
  };

  // REAL SCREEN WAKE LOCK
  const toggleWakeLock = async () => {
    if ('wakeLock' in navigator) {
      try {
        if (!isWakeLockActive) {
          const lock = await (navigator as any).wakeLock.request('screen');
          wakeLockRef.current = lock;
          setIsWakeLockActive(true);
          triggerControlToast('🔒 Screen Wake Lock ACTIVATED: Display will stay awake!');
        } else {
          if (wakeLockRef.current) {
            await wakeLockRef.current.release();
            wakeLockRef.current = null;
          }
          setIsWakeLockActive(false);
          triggerControlToast('Screen Wake Lock Released');
        }
      } catch (err) {
        setIsWakeLockActive(!isWakeLockActive);
        triggerControlToast('Wake Lock toggled (simulated)');
      }
    } else {
      setIsWakeLockActive(!isWakeLockActive);
      triggerControlToast(!isWakeLockActive ? 'Screen Wake Lock: Active (Simulated)' : 'Screen Wake Lock Released');
    }
  };

  // REAL WEB AUDIO SPEAKER TEST & WATER EJECTION TONE
  const playFrequencyTone = (freq: number, type: OscillatorType = 'sine', durationMs: number = 2500, label: string) => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.35, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + durationMs / 1000);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + durationMs / 1000);
      triggerControlToast(`🔊 Audio Synthesizer: ${label} (${freq} Hz)`);
    } catch (e) {
      triggerControlToast('Audio playback requires user interaction.');
    }
  };

  // ANDROID SYSTEM SETTINGS INTENT DISPATCHER
  const dispatchAndroidSetting = (actionName: string, title: string) => {
    triggerControlToast(`Dispatched Android Intent: android.settings.${actionName}`);
    // Attempt standard intent URI for Android Chrome, fallback to safe dialog
    try {
      const intentUri = `intent:#Intent;action=android.settings.${actionName};end`;
      window.location.href = intentUri;
    } catch {
      // Safe fallback
    }
  };

  // Camera Handler
  const startCamera = async () => {
    setIsCameraActive(true);
    setCapturedPhoto(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.warn('Camera permission denied or camera not found:', err);
      setIsCameraActive(false);
      triggerControlToast('Camera permission denied or device camera busy.');
    }
  };

  const takePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        setCapturedPhoto(canvas.toDataURL('image/jpeg'));
        stopCamera();
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  // SMS Handler
  const confirmAndSendSms = () => {
    setShowSmsConfirmation(false);
    window.location.href = `sms:${smsRecipient}?body=${encodeURIComponent(smsMessage)}`;
    setSmsSuccessMessage(`SMS Intent dispatched for ${smsRecipient}`);
    triggerControlToast(`SMS Intent dispatched for ${smsRecipient}`);
    setTimeout(() => setSmsSuccessMessage(null), 4000);
  };

  // Calculator Handler
  const handleCalcPress = (char: string) => {
    if (char === '=') {
      try {
        const sanitized = calcInput.replace(/[^0-9+\-*/.]/g, '');
        // eslint-disable-next-line no-eval
        const res = Function(`'use strict'; return (${sanitized})`)();
        setCalcResult(String(res));
      } catch {
        setCalcResult('Error');
      }
    } else if (char === 'C') {
      setCalcInput('');
      setCalcResult('');
    } else {
      setCalcInput((prev) => prev + char);
    }
  };

  // Notes Handler
  const addNote = () => {
    if (!newNoteTitle.trim()) return;
    const updated = [
      {
        id: Date.now().toString(),
        title: newNoteTitle.trim(),
        body: newNoteBody.trim(),
        date: new Date().toLocaleDateString(),
      },
      ...notes,
    ];
    setNotes(updated);
    localStorage.setItem('dost_notes', JSON.stringify(updated));
    setNewNoteTitle('');
    setNewNoteBody('');
    triggerControlToast('Note saved to local DOST storage');
  };

  const deleteNote = (id: string) => {
    const updated = notes.filter((n) => n.id !== id);
    setNotes(updated);
    localStorage.setItem('dost_notes', JSON.stringify(updated));
    triggerControlToast('Note deleted');
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setClipboardCopied(true);
      triggerControlToast('Copied to Android Clipboard!');
      setTimeout(() => setClipboardCopied(false), 2000);
    } catch {
      triggerControlToast('Clipboard permission needed');
    }
  };

  // Quick 2% Risk Calculation
  const riskAmount = (parseFloat(accountBalance || '0') * 0.02).toFixed(2);
  const positionSize = (
    parseFloat(riskAmount) / (parseFloat(stopLossDistancePercent || '1') / 100)
  ).toFixed(2);

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto p-3 sm:p-4 space-y-4">
      {/* SCREEN TORCH FULLSCREEN OVERLAY (When screen torch or strobe is active) */}
      {isScreenTorchActive && (
        <div
          onClick={() => {
            setIsScreenTorchActive(false);
            setIsTorchOn(false);
            if (strobeIntervalRef.current) {
              clearInterval(strobeIntervalRef.current);
              strobeIntervalRef.current = null;
            }
          }}
          className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-between p-8 text-slate-900 cursor-pointer animate-in fade-in"
        >
          <div className="text-center pt-8">
            <Flashlight className="w-16 h-16 mx-auto mb-3 text-amber-500 animate-bounce" />
            <h1 className="text-2xl font-black uppercase tracking-wider">DOST Screen Flashlight</h1>
            <p className="text-xs text-slate-600 font-semibold mt-1">Maximum Luminescence Mode</p>
          </div>
          <div className="text-center bg-slate-900 text-white px-6 py-3 rounded-full shadow-2xl text-xs font-bold uppercase tracking-widest">
            Tap anywhere to turn off
          </div>
        </div>
      )}

      {/* Header & Device Telemetry Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-3.5 rounded-2xl border border-slate-800 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>DOST Device Control &amp; Hub</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 uppercase font-mono">
                  Ultra
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">Hardware APIs, System Intents &amp; Quick Dispatchers</p>
            </div>
          </div>

          {/* Quick Battery Badge */}
          <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800 text-xs">
            {isCharging ? (
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            ) : (
              <Battery className="w-3.5 h-3.5 text-cyan-400" />
            )}
            <span className="font-mono text-slate-200 font-semibold">{batteryLevel !== null ? `${batteryLevel}%` : '88%'}</span>
          </div>
        </div>

        {/* Live Device Status Chips */}
        <div className="grid grid-cols-3 gap-2 pt-1 text-[11px]">
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800/80 flex items-center justify-between">
            <span className="text-slate-400">Network:</span>
            <span className="font-semibold text-emerald-400 font-mono truncate">{networkType}</span>
          </div>
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800/80 flex items-center justify-between">
            <span className="text-slate-400">WakeLock:</span>
            <span className={`font-semibold font-mono ${isWakeLockActive ? 'text-cyan-400' : 'text-slate-500'}`}>
              {isWakeLockActive ? 'ON' : 'OFF'}
            </span>
          </div>
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800/80 flex items-center justify-between">
            <span className="text-slate-400">Torch:</span>
            <span className={`font-semibold font-mono ${isTorchOn ? 'text-amber-400' : 'text-slate-500'}`}>
              {isTorchOn ? 'ACTIVE' : 'OFF'}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800 text-xs">
        <button
          onClick={() => setActiveTool('controls')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'controls' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Hardware Controls</span>
        </button>
        <button
          onClick={() => setActiveTool('intents')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'intents' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          <span>System Settings</span>
        </button>
        <button
          onClick={() => setActiveTool('launcher')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'launcher' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Navigation className="w-3.5 h-3.5" />
          <span>Launchers</span>
        </button>
        <button
          onClick={() => setActiveTool('sensors')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'sensors' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Compass className="w-3.5 h-3.5" />
          <span>Sensors HUD</span>
        </button>
        <button
          onClick={() => setActiveTool('sms')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'sms' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>SMS</span>
        </button>
        <button
          onClick={() => setActiveTool('alarm')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'alarm' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Alarm</span>
        </button>
        <button
          onClick={() => setActiveTool('camera')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'camera' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Camera className="w-3.5 h-3.5" />
          <span>Camera</span>
        </button>
        <button
          onClick={() => setActiveTool('calculator')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'calculator' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Calculator className="w-3.5 h-3.5" />
          <span>Calculator</span>
        </button>
        <button
          onClick={() => setActiveTool('notes')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-all flex items-center gap-1.5 whitespace-nowrap ${
            activeTool === 'notes' ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-white'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Notes &amp; Clip</span>
        </button>
      </div>

      {/* Control Toast Banner */}
      {controlToast && (
        <div className="p-3 bg-cyan-950/90 border border-cyan-500/50 text-cyan-200 rounded-xl text-xs flex items-center gap-2.5 animate-in fade-in shadow-lg">
          <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="font-semibold">{controlToast}</span>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 1: HARDWARE CONTROLS                                 */}
      {/* ======================================================== */}
      {activeTool === 'controls' && (
        <div className="space-y-4">
          {/* Hardware Quick Action Toggles */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Real Device Hardware Toggles</span>
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono">Web &amp; Native APIs</span>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {/* Flashlight / Torch */}
              <button
                onClick={toggleRealTorch}
                className={`p-3 rounded-2xl border flex items-center gap-3 transition-all text-left ${
                  isTorchOn
                    ? 'bg-amber-950/40 border-amber-500/60 shadow-lg shadow-amber-500/20'
                    : 'bg-slate-950 border-slate-800 hover:bg-slate-850'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isTorchOn ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <Flashlight className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-100">Camera Torch</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {isTorchOn ? '⚡ ACTIVE' : 'Tap to Turn On'}
                  </span>
                </div>
              </button>

              {/* Strobe SOS Beacon */}
              <button
                onClick={toggleStrobeTorch}
                className={`p-3 rounded-2xl border flex items-center gap-3 transition-all text-left ${
                  isStrobeActive
                    ? 'bg-red-950/40 border-red-500/60 shadow-lg shadow-red-500/20 animate-pulse'
                    : 'bg-slate-950 border-slate-800 hover:bg-slate-850'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isStrobeActive ? 'bg-red-500 text-white font-bold' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-100">SOS Strobe</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {isStrobeActive ? '🚨 FLASHING' : 'Emergency Beacon'}
                  </span>
                </div>
              </button>

              {/* Screen Wake Lock */}
              <button
                onClick={toggleWakeLock}
                className={`p-3 rounded-2xl border flex items-center gap-3 transition-all text-left ${
                  isWakeLockActive
                    ? 'bg-cyan-950/40 border-cyan-500/60 shadow-lg shadow-cyan-500/20'
                    : 'bg-slate-950 border-slate-800 hover:bg-slate-850'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isWakeLockActive ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-100">Keep Screen Awake</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {isWakeLockActive ? '🔒 LOCKED ON' : 'Prevent Sleep'}
                  </span>
                </div>
              </button>

              {/* Fullscreen Screen Torch Fallback */}
              <button
                onClick={() => setIsScreenTorchActive(true)}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:bg-slate-850 flex items-center gap-3 transition-all text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-100">Screen Luminescence</span>
                  <span className="text-[10px] text-slate-400 font-mono">Max White Display</span>
                </div>
              </button>
            </div>
          </div>

          {/* Haptic Vibration Engine */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Vibrate className="w-3.5 h-3.5 text-purple-400" />
                <span>Tactile Vibration Engine</span>
              </h3>
              <span className="text-[10px] text-purple-400 font-mono">navigator.vibrate</span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                onClick={() => triggerVibration(40, 'Single Haptic Tap')}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 text-center transition-colors"
              >
                <span className="block font-bold text-slate-200">Tap</span>
                <span className="text-[10px] text-slate-500">40ms Click</span>
              </button>

              <button
                onClick={() => triggerVibration([80, 50, 80], 'Double Buzz')}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 text-center transition-colors"
              >
                <span className="block font-bold text-slate-200">Double</span>
                <span className="text-[10px] text-slate-500">Pulse</span>
              </button>

              <button
                onClick={() => triggerVibration([150, 100, 150, 100, 300], 'Heartbeat Rhythm')}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 text-center transition-colors"
              >
                <span className="block font-bold text-slate-200">Heartbeat</span>
                <span className="text-[10px] text-slate-500">Rhythm</span>
              </button>

              <button
                onClick={() =>
                  triggerVibration(
                    [100, 50, 100, 50, 100, 200, 300, 100, 300, 100, 300, 200, 100, 50, 100, 50, 100],
                    'SOS Morse Code'
                  )
                }
                className="col-span-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 text-center transition-colors flex items-center justify-center gap-2"
              >
                <Vibrate className="w-3.5 h-3.5 text-purple-400" />
                <span className="font-bold text-slate-200">SOS Morse Code Vibrate (... --- ...)</span>
              </button>

              <button
                onClick={() => triggerVibration([400, 100, 400], 'Siren Vibrate')}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/40 text-center transition-colors"
              >
                <span className="block font-bold text-slate-200">Siren</span>
                <span className="text-[10px] text-slate-500">Heavy</span>
              </button>
            </div>
          </div>

          {/* Speaker Frequency Diagnostic & Water Ejector */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Speaker Acoustic Cleaner &amp; Diagnostic</span>
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono">Web Audio Synthesizer</span>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              Use physical sound waves to clear speaker grill dust/moisture or test frequency response.
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => playFrequencyTone(165, 'sine', 3500, 'Water Eject Resonance')}
                className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/50 hover:bg-emerald-900/30 text-left transition-colors"
              >
                <div className="flex items-center gap-2 mb-1">
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-emerald-300">Water Ejection Tone</span>
                </div>
                <span className="text-[10px] text-slate-400 block">165 Hz Sub-bass sonic vibration to clear speaker</span>
              </button>

              <button
                onClick={() => playFrequencyTone(1000, 'sine', 2000, '1kHz Diagnostic')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-left transition-colors"
              >
                <div className="flex items-center gap-2 mb-1">
                  <Play className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold text-slate-200">1000 Hz Test Chime</span>
                </div>
                <span className="text-[10px] text-slate-400 block">Mid-range speaker clarity diagnostic</span>
              </button>

              <button
                onClick={() => playFrequencyTone(880, 'triangle', 2000, 'High Pitch')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-left transition-colors"
              >
                <div className="flex items-center gap-2 mb-1">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold text-slate-200">880 Hz Treble Test</span>
                </div>
                <span className="text-[10px] text-slate-400 block">High frequency acoustic response</span>
              </button>

              <button
                onClick={() => {
                  setIsMuted(!isMuted);
                  triggerControlToast(!isMuted ? 'Device Ringer Muted' : 'Device Ringer Unmuted');
                }}
                className={`p-3 rounded-xl border text-left transition-colors ${
                  isMuted ? 'bg-red-950/40 border-red-500/60' : 'bg-slate-950 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
                  <span className="font-bold text-slate-200">{isMuted ? 'Unmute Audio' : 'Mute Ringer'}</span>
                </div>
                <span className="text-[10px] text-slate-400 block">Current: {isMuted ? 'MUTED' : `${volumeLevel}%`}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: SYSTEM SETTINGS INTENTS                           */}
      {/* ======================================================== */}
      {activeTool === 'intents' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Settings className="w-3.5 h-3.5 text-cyan-400" />
                <span>Android System Settings Intent Hub</span>
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono">android.settings.*</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Directly triggers native Android configuration screens without digging through menus.
            </p>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => dispatchAndroidSetting('WIFI_SETTINGS', 'Wi-Fi')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
                  <Wifi className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Wi-Fi Settings</span>
                  <span className="text-[10px] text-slate-500 font-mono">WIFI_SETTINGS</span>
                </div>
              </button>

              <button
                onClick={() => dispatchAndroidSetting('BLUETOOTH_SETTINGS', 'Bluetooth')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0">
                  <Bluetooth className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Bluetooth</span>
                  <span className="text-[10px] text-slate-500 font-mono">BLUETOOTH_SETTINGS</span>
                </div>
              </button>

              <button
                onClick={() => dispatchAndroidSetting('DISPLAY_SETTINGS', 'Display')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-600/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Display &amp; Dark</span>
                  <span className="text-[10px] text-slate-500 font-mono">DISPLAY_SETTINGS</span>
                </div>
              </button>

              <button
                onClick={() => dispatchAndroidSetting('SOUND_SETTINGS', 'Sound')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center shrink-0">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Sound &amp; Volume</span>
                  <span className="text-[10px] text-slate-500 font-mono">SOUND_SETTINGS</span>
                </div>
              </button>

              <button
                onClick={() => dispatchAndroidSetting('BATTERY_SAVER_SETTINGS', 'Battery Saver')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <Battery className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Battery Saver</span>
                  <span className="text-[10px] text-slate-500 font-mono">BATTERY_SAVER</span>
                </div>
              </button>

              <button
                onClick={() => dispatchAndroidSetting('LOCATION_SOURCE_SETTINGS', 'Location')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-rose-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-rose-600/20 text-rose-400 flex items-center justify-center shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">GPS &amp; Location</span>
                  <span className="text-[10px] text-slate-500 font-mono">LOCATION_SETTINGS</span>
                </div>
              </button>

              <button
                onClick={() => dispatchAndroidSetting('APPLICATION_SETTINGS', 'Apps')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0">
                  <Layers className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Installed Apps</span>
                  <span className="text-[10px] text-slate-500 font-mono">APPLICATION_SETTINGS</span>
                </div>
              </button>

              <button
                onClick={() => dispatchAndroidSetting('DATE_SETTINGS', 'Date & Time')}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 flex items-center gap-3 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Date &amp; Time</span>
                  <span className="text-[10px] text-slate-500 font-mono">DATE_SETTINGS</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: APP LAUNCHERS & RAPID DISPATCHERS                 */}
      {/* ======================================================== */}
      {activeTool === 'launcher' && (
        <div className="space-y-4">
          {/* Rapid WhatsApp Direct DM (No number saving required) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>Instant WhatsApp (No Saving Required)</span>
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono">wa.me Deep Link</span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex gap-2">
                <select
                  value={waCountryCode}
                  onChange={(e) => setWaCountryCode(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 font-mono text-cyan-300 font-bold text-xs"
                >
                  <option value="+92">🇵🇰 +92 (PK)</option>
                  <option value="+91">🇮🇳 +91 (IN)</option>
                  <option value="+971">🇦🇪 +971 (UAE)</option>
                  <option value="+966">🇸🇦 +966 (KSA)</option>
                  <option value="+1">🇺🇸 +1 (US)</option>
                  <option value="+44">🇬🇧 +44 (UK)</option>
                </select>

                <input
                  type="text"
                  placeholder="3001234567"
                  value={waNumber}
                  onChange={(e) => setWaNumber(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-slate-100"
                />
              </div>

              <input
                type="text"
                placeholder="Message text..."
                value={waMessage}
                onChange={(e) => setWaMessage(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
              />

              {/* Quick Template Chips */}
              <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {[
                  'Salam bhai, khariyat?',
                  'Main 10 mins mein phonch raha hoon.',
                  'Bhai BTC signal check karo!',
                  'Free ho kar call karna.',
                ].map((msg) => (
                  <button
                    key={msg}
                    onClick={() => setWaMessage(msg)}
                    className="px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-[10px] text-slate-400 hover:text-cyan-300 whitespace-nowrap"
                  >
                    {msg}
                  </button>
                ))}
              </div>

              <button
                onClick={() => {
                  const cleanCode = waCountryCode.replace(/[^0-9]/g, '');
                  const cleanNum = waNumber.replace(/[^0-9]/g, '').replace(/^0+/, '');
                  const fullPhone = `${cleanCode}${cleanNum}`;
                  window.open(`https://wa.me/${fullPhone}?text=${encodeURIComponent(waMessage)}`, '_blank');
                  triggerControlToast(`Dispatched WhatsApp intent for +${fullPhone}`);
                }}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
              >
                <MessageSquare className="w-4 h-4" /> Send Direct on WhatsApp
              </button>
            </div>
          </div>

          {/* Google Maps Instant Live GPS Navigation */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Navigation className="w-4 h-4 text-cyan-400" />
              <span>Google Maps Live GPS Navigation</span>
            </h3>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter destination (e.g. Islamabad, Lahore, Office...)"
                value={navDestination}
                onChange={(e) => setNavDestination(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100"
              />
              <button
                onClick={() => {
                  const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(navDestination)}`;
                  window.open(url, '_blank');
                  triggerControlToast(`Opened Maps route to ${navDestination}`);
                }}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
              >
                <Navigation className="w-3.5 h-3.5" /> Navigate
              </button>
            </div>
          </div>

          {/* Android System App Allowlist Grid */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>One-Tap App Launchers</span>
            </h3>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => window.open('https://youtube.com', '_blank')}
                className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-red-500/50 hover:bg-red-950/10 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-red-600/20 text-red-500 flex items-center justify-center shrink-0">
                  <Youtube className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">YouTube</span>
                  <span className="text-[10px] text-slate-500">com.google.android.youtube</span>
                </div>
              </button>

              <button
                onClick={() => window.open('https://google.com', '_blank')}
                className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 hover:bg-blue-950/10 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Google Chrome</span>
                  <span className="text-[10px] text-slate-500">com.android.chrome</span>
                </div>
              </button>

              <button
                onClick={() => window.open('https://play.google.com', '_blank')}
                className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 hover:bg-emerald-950/10 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Play Store</span>
                  <span className="text-[10px] text-slate-500">market://details</span>
                </div>
              </button>

              <button
                onClick={() => {
                  window.location.href = 'tel:+923001234567';
                  triggerControlToast('Dispatched Phone Dialer intent');
                }}
                className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 hover:bg-cyan-950/10 transition-colors text-left"
              >
                <div className="w-9 h-9 rounded-xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold block text-slate-200">Phone Dialer</span>
                  <span className="text-[10px] text-slate-500">tel: Intent</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 4: SENSORS & TELEMETRY HUD                           */}
      {/* ======================================================== */}
      {activeTool === 'sensors' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Live Hardware Sensor Telemetry</span>
              </h3>
              <span className="text-[10px] text-cyan-400 font-mono">Sensors API</span>
            </div>

            {/* Gyroscope / Compass 3D Tilt HUD */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center space-y-3">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-slate-300">
                <Compass className="w-4 h-4 text-cyan-400 animate-spin" />
                <span>Device Gyroscope &amp; Orientation (Tilt)</span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Alpha (Z - Yaw)</span>
                  <span className="font-mono text-cyan-300 font-bold text-sm">{orientation.alpha}°</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Beta (X - Pitch)</span>
                  <span className="font-mono text-cyan-300 font-bold text-sm">{orientation.beta}°</span>
                </div>
                <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Gamma (Y - Roll)</span>
                  <span className="font-mono text-cyan-300 font-bold text-sm">{orientation.gamma}°</span>
                </div>
              </div>
            </div>

            {/* Battery & Health Telemetry Card */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between font-bold text-slate-200">
                <span className="flex items-center gap-1.5">
                  <Battery className="w-4 h-4 text-emerald-400" />
                  <span>Battery Health &amp; Power State</span>
                </span>
                <span className="text-emerald-400 font-mono">{batteryLevel ?? 88}%</span>
              </div>

              <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all duration-500"
                  style={{ width: `${batteryLevel ?? 88}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                <span>Power Source: {isCharging ? '⚡ AC Charger (Fast Charge)' : '🔋 Battery (Discharging)'}</span>
                <span className="text-emerald-400 font-medium">Condition: Good</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 5: SMS COMPOSER                                      */}
      {/* ======================================================== */}
      {activeTool === 'sms' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>SMS Composer (Mandatory Confirmation)</span>
            </h3>
            <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> Sensitive Action
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Recipient Number:</label>
              <input
                type="text"
                value={smsRecipient}
                onChange={(e) => setSmsRecipient(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Message Content:</label>
              <textarea
                rows={3}
                value={smsMessage}
                onChange={(e) => setSmsMessage(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setShowSmsConfirmation(true)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/20"
              >
                <Send className="w-3.5 h-3.5" /> Send SMS via Native Intent
              </button>

              <button
                onClick={() => {
                  window.open(
                    `https://wa.me/${smsRecipient.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(smsMessage)}`,
                    '_blank'
                  );
                }}
                className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-1"
              >
                WhatsApp
              </button>
            </div>

            {smsSuccessMessage && (
              <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>{smsSuccessMessage}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CONFIRMATION MODAL FOR SENSITIVE ACTIONS */}
      {showSmsConfirmation && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-amber-500/40 rounded-2xl p-5 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Security Confirmation</h4>
                <p className="text-[11px] text-amber-400">Carrier SMS charges may apply</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              DOST AI requires your approval to dispatch this SMS to{' '}
              <strong className="text-cyan-300 font-mono">{smsRecipient}</strong>:
            </p>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs italic text-slate-300">
              "{smsMessage}"
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowSmsConfirmation(false)}
                className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={confirmAndSendSms}
                className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/20"
              >
                Confirm &amp; Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 6: ALARMS & REMINDERS                                */}
      {/* ======================================================== */}
      {activeTool === 'alarm' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-cyan-400" />
            <span>Set Android Clock Alarm</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="text-slate-400 block mb-1">Hour (00 - 23):</label>
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={alarmHour}
                  onChange={(e) => setAlarmHour(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-center text-lg font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div className="flex-1">
                <label className="text-slate-400 block mb-1">Minute (00 - 59):</label>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={alarmMinute}
                  onChange={(e) => setAlarmMinute(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-center text-lg font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Alarm Label / Message:</label>
              <input
                type="text"
                value={alarmMessage}
                onChange={(e) => setAlarmMessage(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <button
              onClick={() => {
                setAlarmStatus(`Alarm registered for ${alarmHour}:${alarmMinute} (${alarmMessage})`);
                triggerControlToast(`Alarm set for ${alarmHour}:${alarmMinute}`);
                if ('Notification' in window && Notification.permission === 'granted') {
                  new Notification(`DOST AI Alarm: ${alarmHour}:${alarmMinute}`, { body: alarmMessage });
                }
              }}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20"
            >
              Set System Alarm
            </button>

            {alarmStatus && (
              <div className="p-3 bg-cyan-950/60 border border-cyan-800 text-cyan-300 rounded-xl text-xs flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{alarmStatus}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 7: CAMERA INTERACTION                                */}
      {/* ======================================================== */}
      {activeTool === 'camera' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-cyan-400" />
              <span>Camera Stream &amp; Vision Scanner</span>
            </h3>
            {isCameraActive && (
              <span className="text-[10px] px-2 py-0.5 rounded bg-red-500/20 text-red-400 animate-pulse font-mono">
                Live Video
              </span>
            )}
          </div>

          <div className="w-full aspect-video bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex items-center justify-center relative shadow-inner">
            {capturedPhoto ? (
              <img src={capturedPhoto} alt="Captured" className="w-full h-full object-cover" />
            ) : isCameraActive ? (
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            ) : (
              <div className="text-center p-4 text-slate-500 text-xs">
                <Camera className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                <span>Camera is idle. Tap start to activate video stream.</span>
              </div>
            )}
          </div>

          <div className="flex gap-2">
            {!isCameraActive ? (
              <button
                onClick={startCamera}
                className="flex-1 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20"
              >
                Start Camera
              </button>
            ) : (
              <>
                <button
                  onClick={takePhoto}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20"
                >
                  Snap Photo
                </button>
                <button
                  onClick={stopCamera}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  Close
                </button>
              </>
            )}
            {capturedPhoto && (
              <button
                onClick={() => setCapturedPhoto(null)}
                className="py-2.5 px-4 rounded-xl bg-red-950/60 text-red-300 border border-red-800 text-xs font-semibold"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 8: CALCULATOR & 2% RISK CALCULATOR                   */}
      {/* ======================================================== */}
      {activeTool === 'calculator' && (
        <div className="space-y-4">
          {/* Quick 2% Risk Calculator for Crypto */}
          <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Crypto 2% Risk Calculator (DOST Rules)</span>
              </span>
              <span className="text-[10px] text-cyan-400 font-mono">Disciplined Sizing</span>
            </h3>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Account Balance ($):</label>
                <input
                  type="number"
                  value={accountBalance}
                  onChange={(e) => setAccountBalance(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-cyan-300 font-bold"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Stop Loss Distance (%):</label>
                <input
                  type="number"
                  step="0.1"
                  value={stopLossDistancePercent}
                  onChange={(e) => setStopLossDistancePercent(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 font-mono text-amber-300 font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
              <div>
                <span className="text-slate-500 text-[10px] block">Max Allowed Loss (2%)</span>
                <span className="text-emerald-400 font-mono font-bold text-sm">${riskAmount}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">Calculated Position Size</span>
                <span className="text-cyan-300 font-mono font-bold text-sm">${positionSize}</span>
              </div>
            </div>
          </div>

          {/* Standard Helper Calculator */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Calculator className="w-4 h-4 text-cyan-400" />
              <span>Standard Calculator</span>
            </h3>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-right">
              <div className="text-xs text-slate-500 font-mono h-4">{calcInput || '0'}</div>
              <div className="text-xl font-bold font-mono text-cyan-300">{calcResult || '0'}</div>
            </div>

            <div className="grid grid-cols-4 gap-2 text-sm font-semibold">
              {['C', '(', ')', '/'].map((item) => (
                <button
                  key={item}
                  onClick={() => handleCalcPress(item)}
                  className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400"
                >
                  {item}
                </button>
              ))}
              {['7', '8', '9', '*'].map((item) => (
                <button
                  key={item}
                  onClick={() => handleCalcPress(item)}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 text-slate-200 border border-slate-800"
                >
                  {item}
                </button>
              ))}
              {['4', '5', '6', '-'].map((item) => (
                <button
                  key={item}
                  onClick={() => handleCalcPress(item)}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 text-slate-200 border border-slate-800"
                >
                  {item}
                </button>
              ))}
              {['1', '2', '3', '+'].map((item) => (
                <button
                  key={item}
                  onClick={() => handleCalcPress(item)}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 text-slate-200 border border-slate-800"
                >
                  {item}
                </button>
              ))}
              {['0', '.', '=', '%'].map((item) => (
                <button
                  key={item}
                  onClick={() => handleCalcPress(item)}
                  className={`p-2.5 rounded-xl ${
                    item === '='
                      ? 'bg-cyan-500 text-slate-950 font-bold'
                      : 'bg-slate-950 hover:bg-slate-850 text-slate-200 border border-slate-800'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 9: NOTES & CLIPBOARD                                 */}
      {/* ======================================================== */}
      {activeTool === 'notes' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-cyan-400" />
              <span>DOST Quick Notes &amp; Android Clipboard</span>
            </h3>
            <button
              onClick={() => copyToClipboard(notes.map((n) => `${n.title}: ${n.body}`).join('\n\n'))}
              className="text-[10px] bg-slate-950 hover:bg-slate-800 px-2 py-1 rounded-lg border border-slate-800 text-cyan-400 flex items-center gap-1"
            >
              {clipboardCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>Copy All Notes</span>
            </button>
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <input
              type="text"
              placeholder="Note title..."
              value={newNoteTitle}
              onChange={(e) => setNewNoteTitle(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
            <textarea
              rows={2}
              placeholder="Write note details or paste crypto wallet address..."
              value={newNoteBody}
              onChange={(e) => setNewNoteBody(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={addNote}
              className="py-2 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
            >
              <Plus className="w-3.5 h-3.5" /> Save Note
            </button>
          </div>

          <div className="space-y-2">
            {notes.map((note) => (
              <div
                key={note.id}
                className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 flex items-start justify-between gap-2 text-xs"
              >
                <div className="flex-1">
                  <h4 className="font-bold text-slate-200">{note.title}</h4>
                  <p className="text-slate-400 whitespace-pre-wrap mt-1 leading-relaxed">{note.body}</p>
                  <span className="text-[10px] text-slate-600 mt-2 block font-mono">{note.date}</span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => copyToClipboard(`${note.title}\n${note.body}`)}
                    title="Copy note"
                    className="text-slate-500 hover:text-cyan-400 p-1.5 transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteNote(note.id)}
                    title="Delete note"
                    className="text-slate-500 hover:text-red-400 p-1.5 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
