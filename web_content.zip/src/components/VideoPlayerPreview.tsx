import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Download,
  Volume2,
  VolumeX,
  Heart,
  MessageCircle,
  Share2,
  Sparkles,
  ShoppingBag,
  Disc,
  Flame,
  CheckCircle2,
  Sliders,
  Maximize2
} from 'lucide-react';
import { UgcScript, SearchInsights } from '../types';
import { CREATOR_AVATARS, CreatorAvatar } from '../data/presets';

interface VideoPlayerPreviewProps {
  script: UgcScript;
  insights: SearchInsights;
  productImage?: string;
  avatarType: string;
  audioBase64?: string;
  onRegenerateScript: () => void;
  isRegenerating: boolean;
}

export const VideoPlayerPreview: React.FC<VideoPlayerPreviewProps> = ({
  script,
  insights,
  productImage,
  avatarType,
  audioBase64,
  onRegenerateScript,
  isRegenerating,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(24800);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const pausedTimeRef = useRef<number>(0);

  const selectedAvatar = CREATOR_AVATARS.find((a) => a.id === avatarType) || CREATOR_AVATARS[0];
  const TOTAL_DURATION = 16.0;

  // Initialize or update audio element when audioBase64 changes
  useEffect(() => {
    if (audioBase64) {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      const audio = new Audio(`data:audio/wav;base64,${audioBase64}`);
      audioRef.current = audio;
      audio.muted = isMuted;

      audio.onended = () => {
        setIsPlaying(false);
        setCurrentTime(0);
        pausedTimeRef.current = 0;
      };
    }
  }, [audioBase64]);

  // Master 16-second playback timer sync
  useEffect(() => {
    if (isPlaying) {
      const now = performance.now();
      startTimeRef.current = now - pausedTimeRef.current * 1000;

      if (audioRef.current && audioRef.current.paused) {
        audioRef.current.currentTime = pausedTimeRef.current;
        audioRef.current.play().catch((e) => console.warn('Audio play prevented:', e));
      }

      const tick = () => {
        const elapsed = (performance.now() - startTimeRef.current) / 1000;
        if (elapsed >= TOTAL_DURATION) {
          setCurrentTime(TOTAL_DURATION);
          setIsPlaying(false);
          pausedTimeRef.current = 0;
          if (audioRef.current) {
            audioRef.current.pause();
            audioRef.current.currentTime = 0;
          }
        } else {
          setCurrentTime(elapsed);
          animFrameRef.current = requestAnimationFrame(tick);
        }
      };
      animFrameRef.current = requestAnimationFrame(tick);
    } else {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
      pausedTimeRef.current = currentTime;
    }

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying]);

  const togglePlay = () => {
    if (currentTime >= TOTAL_DURATION) {
      setCurrentTime(0);
      pausedTimeRef.current = 0;
    }
    setIsPlaying(!isPlaying);
  };

  const handleRestart = () => {
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    pausedTimeRef.current = 0;
    setCurrentTime(0);
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
    }
    setIsPlaying(true);
  };

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (audioRef.current) {
      audioRef.current.muted = nextMuted;
    }
  };

  // Determine current beat segment
  const currentBeat: 'hook' | 'demo' | 'cta' =
    currentTime < 3.0 ? 'hook' : currentTime < 12.0 ? 'demo' : 'cta';

  // Find active timed caption
  const activeCaption = script.timedCaptions?.find(
    (c) => currentTime >= c.start && currentTime <= c.end
  );

  // Fallback caption based on beat
  const displayCaption =
    activeCaption?.text ||
    (currentBeat === 'hook'
      ? script.hook.verbal
      : currentBeat === 'demo'
      ? script.demo.verbal
      : script.cta.verbal);

  const displayOverlayBadge =
    currentBeat === 'hook'
      ? script.hook.overlayText
      : currentBeat === 'demo'
      ? script.demo.overlayText
      : script.cta.overlayText;

  // Handle Export 16s Video using Canvas Compositor & MediaRecorder
  const handleExportVideo = async () => {
    try {
      setIsExporting(true);
      setExportProgress(10);

      // Create offscreen 9:16 Canvas (720 x 1280)
      const canvas = document.createElement('canvas');
      canvas.width = 720;
      canvas.height = 1280;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas 2D context unavailable');

      // Load product image
      const prodImg = new Image();
      prodImg.crossOrigin = 'anonymous';
      prodImg.src =
        productImage ||
        'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=720&q=80';
      await new Promise((res) => {
        prodImg.onload = res;
        prodImg.onerror = res;
      });

      // Load avatar image
      const avatarImg = new Image();
      avatarImg.crossOrigin = 'anonymous';
      avatarImg.src = selectedAvatar.avatarUrl;
      await new Promise((res) => {
        avatarImg.onload = res;
        avatarImg.onerror = res;
      });

      setExportProgress(25);

      // Prepare AudioContext for mixing TTS audio into video stream
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const dest = audioCtx.createMediaStreamDestination();

      if (audioBase64) {
        try {
          const raw = atob(audioBase64);
          const rawLength = raw.length;
          const array = new Uint8Array(new ArrayBuffer(rawLength));
          for (let i = 0; i < rawLength; i++) {
            array[i] = raw.charCodeAt(i);
          }
          const audioBuffer = await audioCtx.decodeAudioData(array.buffer);
          const source = audioCtx.createBufferSource();
          source.buffer = audioBuffer;
          source.connect(dest);
          source.start(0);
        } catch (e) {
          console.warn('Audio export mix fallback:', e);
        }
      }

      setExportProgress(40);

      // Setup MediaStream
      const canvasStream = canvas.captureStream(30);
      dest.stream.getAudioTracks().forEach((track) => canvasStream.addTrack(track));

      const recordedChunks: Blob[] = [];
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';
      const recorder = new MediaRecorder(canvasStream, { mimeType, videoBitsPerSecond: 4000000 });

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunks.push(e.data);
      };

      const renderPromise = new Promise<Blob>((resolve) => {
        recorder.onstop = () => {
          const blob = new Blob(recordedChunks, { type: 'video/webm' });
          resolve(blob);
        };
      });

      recorder.start();

      // Render 16 seconds frame by frame
      const fps = 30;
      const totalFrames = fps * 16;
      let frame = 0;

      const renderInterval = setInterval(() => {
        frame++;
        const t = frame / fps;
        setExportProgress(Math.min(95, Math.floor(40 + (frame / totalFrames) * 55)));

        // Clear canvas
        ctx.fillStyle = '#080811';
        ctx.fillRect(0, 0, 720, 1280);

        // Dynamic background gradient
        const grad = ctx.createLinearGradient(0, 0, 720, 1280);
        grad.addColorStop(0, '#0c0f1e');
        grad.addColorStop(0.5, '#16192e');
        grad.addColorStop(1, '#080911');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 720, 1280);

        // Draw product image with subtle dynamic zoom
        const scale = 1 + Math.sin(t * 0.8) * 0.05;
        const imgW = 600 * scale;
        const imgH = 600 * scale;
        ctx.save();
        ctx.drawImage(prodImg, (720 - imgW) / 2, 260 + Math.sin(t * 1.5) * 15, imgW, imgH);
        ctx.restore();

        // Top Hook Banner (Sticker)
        const activeBeat = t < 3 ? 'hook' : t < 12 ? 'demo' : 'cta';
        const stickerText =
          activeBeat === 'hook'
            ? script.hook.overlayText
            : activeBeat === 'demo'
            ? script.demo.overlayText
            : script.cta.overlayText;

        // Draw Sticker Badge
        ctx.save();
        ctx.fillStyle = activeBeat === 'hook' ? '#f59e0b' : activeBeat === 'demo' ? '#06b6d4' : '#10b981';
        ctx.shadowColor = 'rgba(0,0,0,0.6)';
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.roundRect(60, 120, 600, 70, 20);
        ctx.fill();

        ctx.fillStyle = '#000000';
        ctx.font = 'bold 32px "Plus Jakarta Sans", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(stickerText || 'VIRAL PRODUCT', 360, 168);
        ctx.restore();

        // Draw Creator Avatar in bottom right
        ctx.save();
        ctx.beginPath();
        ctx.arc(630, 940, 50, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatarImg, 580, 890, 100, 100);
        ctx.restore();

        // Draw Captions at bottom
        const caption =
          script.timedCaptions?.find((c) => t >= c.start && t <= c.end)?.text ||
          (t < 3 ? script.hook.verbal : t < 12 ? script.demo.verbal : script.cta.verbal);

        ctx.save();
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.beginPath();
        ctx.roundRect(40, 1020, 640, 100, 24);
        ctx.fill();

        ctx.font = 'bold 30px "Plus Jakarta Sans", sans-serif';
        ctx.fillStyle = '#fef08a';
        ctx.textAlign = 'center';
        ctx.fillText(caption || '', 360, 1080);
        ctx.restore();

        // Scrubber bar on canvas
        ctx.fillStyle = 'rgba(255,255,255,0.2)';
        ctx.fillRect(40, 1230, 640, 6);
        ctx.fillStyle = '#06b6d4';
        ctx.fillRect(40, 1230, (t / 16) * 640, 6);

        if (frame >= totalFrames) {
          clearInterval(renderInterval);
          recorder.stop();
        }
      }, 1000 / fps);

      const blob = await renderPromise;
      setExportProgress(100);

      // Trigger download
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(insights.productName || 'ugc-ad').replace(/\s+/g, '-').toLowerCase()}-16s-ad.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export error:', err);
    } finally {
      setIsExporting(false);
      setExportProgress(0);
    }
  };

  return (
    <div className="w-full glass-panel rounded-3xl p-5 sm:p-7 border border-white/10 shadow-[0_15px_50px_rgba(0,0,0,0.7)] flex flex-col items-center">
      {/* Header bar above phone preview */}
      <div className="w-full flex items-center justify-between pb-4 mb-4 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold uppercase tracking-wider font-mono">
            9:16 VERTICAL PLAYER
          </span>
          <span className="text-xs text-slate-300 font-semibold truncate max-w-[200px]">
            {insights.productName || '16s UGC Commercial'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleMute}
            className="p-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 border border-white/10 transition-colors"
            title={isMuted ? 'Unmute TTS' : 'Mute TTS'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          <button
            onClick={handleRestart}
            className="p-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 border border-white/10 transition-colors"
            title="Restart playback"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 9:16 Smartphone Mockup with Glass reflection & TikTok overlay */}
      <div className="relative w-full max-w-[340px] aspect-[9/16] rounded-[44px] p-3 bg-gradient-to-b from-slate-700/60 via-slate-800/40 to-slate-900/80 border-2 border-white/20 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_30px_rgba(99,102,241,0.2)]">
        {/* Dynamic Island / Punch Hole */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2 z-30 w-24 h-5 rounded-full bg-black/90 border border-white/15 flex items-center justify-between px-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700" />
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
        </div>

        {/* Video Frame Canvas Screen */}
        <div className="relative w-full h-full rounded-[34px] overflow-hidden bg-[#060810] flex flex-col justify-between p-4 select-none">
          {/* Background image / Video scene with dynamic zoom */}
          <div className="absolute inset-0 z-0 overflow-hidden">
            <img
              src={
                productImage ||
                'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=720&q=80'
              }
              alt="Ad Product Scene"
              className={`w-full h-full object-cover transition-transform duration-700 ${
                isPlaying ? 'scale-110' : 'scale-100'
              }`}
            />
            {/* Dark gradient overlay for contrast */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/85" />
          </div>

          {/* TOP SECTION: Beat Badge & Hook Sticker */}
          <div className="relative z-10 pt-6">
            <div className="flex items-center justify-between">
              <span
                className={`text-[9px] uppercase font-mono font-bold px-2 py-0.5 rounded-full border shadow-sm ${
                  currentBeat === 'hook'
                    ? 'bg-amber-500/30 text-amber-300 border-amber-400'
                    : currentBeat === 'demo'
                    ? 'bg-cyan-500/30 text-cyan-300 border-cyan-400'
                    : 'bg-emerald-500/30 text-emerald-300 border-emerald-400'
                }`}
              >
                {currentBeat === 'hook'
                  ? '⚡️ 0-3s HOOK'
                  : currentBeat === 'demo'
                  ? '✨ 3-12s DEMO'
                  : '🔥 12-16s CTA'}
              </span>

              <span className="text-[10px] font-mono font-bold text-white/90 bg-black/50 px-2 py-0.5 rounded-full backdrop-blur-md">
                {currentTime.toFixed(1)}s / 16.0s
              </span>
            </div>

            {/* Prominent On-Screen Hook / Offer Sticker */}
            <div className="mt-4 text-center">
              <div
                className={`inline-block px-4 py-2 rounded-2xl font-black text-sm uppercase tracking-wide shadow-2xl transition-all transform duration-300 ${
                  currentBeat === 'hook'
                    ? 'bg-amber-400 text-black rotate-[-2deg] scale-105'
                    : currentBeat === 'demo'
                    ? 'bg-cyan-400 text-black rotate-[1deg]'
                    : 'bg-emerald-400 text-black rotate-[-1deg] animate-bounce'
                }`}
              >
                {displayOverlayBadge}
              </div>
            </div>
          </div>

          {/* CENTER: Play / Pause interactive trigger overlay */}
          <div
            onClick={togglePlay}
            className="absolute inset-0 z-10 flex items-center justify-center cursor-pointer group"
          >
            {!isPlaying && (
              <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-xl border border-white/20 flex items-center justify-center text-white shadow-[0_0_30px_rgba(0,0,0,0.8)] group-hover:scale-110 transition-transform">
                <Play className="w-8 h-8 fill-white translate-x-0.5" />
              </div>
            )}
          </div>

          {/* RIGHT SIDE: TikTok / Reels Social Interaction Icons */}
          <div className="absolute right-3 bottom-24 z-20 flex flex-col items-center gap-4 text-white">
            {/* Creator avatar with soundwave indicator */}
            <div className="relative">
              <img
                src={selectedAvatar.avatarUrl}
                alt={selectedAvatar.name}
                className={`w-11 h-11 rounded-full border-2 border-white object-cover shadow-lg ${
                  isPlaying ? 'ring-2 ring-cyan-400 ring-offset-2 ring-offset-black' : ''
                }`}
              />
              <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-pink-500 text-white flex items-center justify-center text-[10px] font-bold">
                +
              </div>
            </div>

            {/* Like button */}
            <button
              onClick={() => {
                setLiked(!liked);
                setLikesCount((prev) => (liked ? prev - 1 : prev + 1));
              }}
              className="flex flex-col items-center gap-0.5"
            >
              <div
                className={`p-2 rounded-full backdrop-blur-md transition-colors ${
                  liked ? 'bg-pink-500/30 text-pink-500' : 'bg-black/40 text-white'
                }`}
              >
                <Heart className={`w-6 h-6 ${liked ? 'fill-pink-500' : ''}`} />
              </div>
              <span className="text-[10px] font-bold font-mono">{(likesCount / 1000).toFixed(1)}k</span>
            </button>

            {/* Comment */}
            <div className="flex flex-col items-center gap-0.5">
              <div className="p-2 rounded-full bg-black/40 backdrop-blur-md">
                <MessageCircle className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold font-mono">482</span>
            </div>

            {/* Share */}
            <div className="flex flex-col items-center gap-0.5">
              <div className="p-2 rounded-full bg-black/40 backdrop-blur-md">
                <Share2 className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold font-mono">Share</span>
            </div>

            {/* Spinning Music Vinyl */}
            <div className={`p-1.5 rounded-full bg-black/70 border border-white/20 ${isPlaying ? 'animate-spin' : ''}`}>
              <Disc className="w-6 h-6 text-cyan-400" />
            </div>
          </div>

          {/* BOTTOM SECTION: Creator info, Dynamic Subtitles, E-Commerce CTA */}
          <div className="relative z-20 space-y-2.5">
            {/* E-Commerce Offer Card (Shows on Demo & CTA) */}
            {currentBeat === 'cta' && (
              <div className="p-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-black shadow-xl animate-fade-in flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-extrabold uppercase">TikTok Viral Deal</p>
                  <p className="text-[9px] font-bold opacity-90">Code VIRAL20 for 20% OFF</p>
                </div>
                <div className="px-3 py-1 rounded-xl bg-black text-white text-[11px] font-black uppercase flex items-center gap-1">
                  <ShoppingBag className="w-3 h-3 text-yellow-300" />
                  Order Now
                </div>
              </div>
            )}

            {/* Dynamic Karaoke Subtitles Overlay */}
            <div className="p-3 rounded-2xl bg-black/75 backdrop-blur-xl border border-white/15 text-center min-h-[58px] flex items-center justify-center shadow-xl">
              <p className="text-xs sm:text-sm font-extrabold text-yellow-300 tracking-wide drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                "{displayCaption}"
              </p>
            </div>

            {/* Creator @handle & Audio Track */}
            <div className="text-left text-white drop-shadow-md">
              <p className="text-xs font-bold flex items-center gap-1">
                {selectedAvatar.handle}
                <span className="text-cyan-400">✓</span>
              </p>
              <p className="text-[10px] text-slate-300 truncate mt-0.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-pink-400" />
                Original Audio · Gemini TTS ({selectedAvatar.name})
              </p>
            </div>

            {/* Progress Bar (Scrubber) */}
            <div className="pt-1">
              <div className="w-full h-1.5 rounded-full bg-white/20 overflow-hidden relative cursor-pointer">
                {/* 0-3s marker */}
                <div className="absolute top-0 bottom-0 left-0 w-[18.75%] border-r border-amber-400/80" />
                {/* 3-12s marker */}
                <div className="absolute top-0 bottom-0 left-[18.75%] w-[56.25%] border-r border-cyan-400/80" />

                {/* Active progress fill */}
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 via-indigo-400 to-pink-500 rounded-full transition-all duration-100"
                  style={{ width: `${(currentTime / TOTAL_DURATION) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Control Buttons Under Phone Frame */}
      <div className="w-full max-w-[340px] mt-4 flex items-center justify-between gap-2">
        <button
          onClick={togglePlay}
          className="flex-1 py-2.5 px-4 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] border border-white/15 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md"
        >
          {isPlaying ? (
            <>
              <Pause className="w-4 h-4 text-cyan-400" />
              <span>Pause</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-cyan-400 text-cyan-400" />
              <span>Play 16s Ad</span>
            </>
          )}
        </button>

        <button
          onClick={handleExportVideo}
          disabled={isExporting}
          className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-[0_0_20px_rgba(16,185,129,0.35)] disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          <span>{isExporting ? `Exporting (${exportProgress}%)` : 'Export Video'}</span>
        </button>
      </div>

      {isExporting && (
        <div className="w-full max-w-[340px] mt-3">
          <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-400 transition-all duration-150"
              style={{ width: `${exportProgress}%` }}
            />
          </div>
          <p className="text-[10px] text-center text-slate-400 mt-1">
            Rendering 720x1280 9:16 vertical video with synced TTS narration...
          </p>
        </div>
      )}
    </div>
  );
};
