import React, { useState } from "react";
import {
  X,
  Plus,
  Edit2,
  Trash2,
  Check,
  User,
  Briefcase,
  Lightbulb,
  FolderKanban,
  GraduationCap,
  Star,
  Heart,
  Bookmark,
  Code,
  Tag,
  Folder
} from "lucide-react";
import { SectionItem } from "../types";

interface SectionManagerModalProps {
  sections: SectionItem[];
  onSaveSections: (sections: SectionItem[]) => void;
  onClose: () => void;
  onSelectSection?: (sectionName: string) => void;
}

const AVAILABLE_ICONS: Array<{ name: string; label: string; component: any }> = [
  { name: "User", label: "Kişisel", component: User },
  { name: "Briefcase", label: "İş", component: Briefcase },
  { name: "Lightbulb", label: "Fikirler", component: Lightbulb },
  { name: "FolderKanban", label: "Projeler", component: FolderKanban },
  { name: "GraduationCap", label: "Eğitim", component: GraduationCap },
  { name: "Star", label: "Önemli", component: Star },
  { name: "Heart", label: "Sağlık/Yaşam", component: Heart },
  { name: "Bookmark", label: "Arşiv", component: Bookmark },
  { name: "Code", label: "Yazılım", component: Code },
  { name: "Folder", label: "Klasör", component: Folder },
];

const AVAILABLE_COLORS = [
  { id: "teal", label: "Teal", class: "bg-teal-500" },
  { id: "emerald", label: "Zümrüt", class: "bg-emerald-500" },
  { id: "blue", label: "Mavi", class: "bg-blue-500" },
  { id: "amber", label: "Kehribar", class: "bg-amber-500" },
  { id: "rose", label: "Gül", class: "bg-rose-500" },
  { id: "purple", label: "Mor", class: "bg-purple-500" },
  { id: "slate", label: "Gri", class: "bg-slate-500" },
];

export const SectionManagerModal: React.FC<SectionManagerModalProps> = ({
  sections,
  onSaveSections,
  onClose,
  onSelectSection,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [nameInput, setNameInput] = useState("");
  const [descInput, setDescInput] = useState("");
  const [selectedIcon, setSelectedIcon] = useState("Folder");
  const [selectedColor, setSelectedColor] = useState("teal");
  const [isAddingNew, setIsAddingNew] = useState(false);

  const startEdit = (sec: SectionItem) => {
    setEditingId(sec.id);
    setNameInput(sec.name);
    setDescInput(sec.description || "");
    setSelectedIcon(sec.icon || "Folder");
    setSelectedColor(sec.color || "teal");
    setIsAddingNew(false);
  };

  const startNew = () => {
    setEditingId(null);
    setNameInput("");
    setDescInput("");
    setSelectedIcon("Lightbulb");
    setSelectedColor("teal");
    setIsAddingNew(true);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setIsAddingNew(false);
    setNameInput("");
    setDescInput("");
  };

  const saveEdit = () => {
    if (!nameInput.trim()) return;

    if (isAddingNew) {
      const newSec: SectionItem = {
        id: `sec-${Date.now()}`,
        name: nameInput.trim(),
        icon: selectedIcon,
        color: selectedColor,
        description: descInput.trim(),
      };
      const updated = [...sections, newSec];
      onSaveSections(updated);
      setIsAddingNew(false);
    } else if (editingId) {
      const updated = sections.map((s) =>
        s.id === editingId
          ? {
              ...s,
              name: nameInput.trim(),
              icon: selectedIcon,
              color: selectedColor,
              description: descInput.trim(),
            }
          : s
      );
      onSaveSections(updated);
      setEditingId(null);
    }
    setNameInput("");
    setDescInput("");
  };

  const deleteSection = (id: string, name: string) => {
    if (sections.length <= 1) {
      alert("En az bir bölüm bulunmalıdır.");
      return;
    }
    if (window.confirm(`"${name}" bölümünü silmek istediğinize emin misiniz? (Notlarınız silinmez, 'Tümü' bölümünden erişilebilir.)`)) {
      const updated = sections.filter((s) => s.id !== id);
      onSaveSections(updated);
      if (editingId === id) cancelEdit();
    }
  };

  const getIconComponent = (iconName?: string) => {
    const found = AVAILABLE_ICONS.find((i) => i.name === iconName);
    return found ? found.component : Folder;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
              <FolderKanban className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Bölümleri Yönet ve İsimlendir
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Kişisel, iş, fikirler ve projelerinizi özelleştirin
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Add / Edit Form */}
          {(isAddingNew || editingId) && (
            <div className="p-4 rounded-2xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/60 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-teal-800 dark:text-teal-300">
                  {isAddingNew ? "＋ Yeni Bölüm Ekle" : "Bölümü Yeniden Adlandır & Düzenle"}
                </span>
                <button
                  onClick={cancelEdit}
                  className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                >
                  Vazgeç
                </button>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Bölüm İsmi
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Örn: Kişisel, İş, Fikirler, Seyahat..."
                  className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-teal-500 text-slate-900 dark:text-white"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Açıklama (İsteğe bağlı)
                </label>
                <input
                  type="text"
                  value={descInput}
                  onChange={(e) => setDescInput(e.target.value)}
                  placeholder="Bu bölümün kapsamı hakkında kısa not"
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-teal-500 text-slate-900 dark:text-white"
                />
              </div>

              {/* Icon Picker */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
                  Bölüm İkonu
                </label>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {AVAILABLE_ICONS.map((item) => {
                    const IconComp = item.component;
                    const isSelected = selectedIcon === item.name;
                    return (
                      <button
                        key={item.name}
                        type="button"
                        onClick={() => setSelectedIcon(item.name)}
                        title={item.label}
                        className={`p-2 rounded-xl border transition-all ${
                          isSelected
                            ? "bg-teal-600 text-white border-teal-600 shadow-xs"
                            : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-teal-400"
                        }`}
                      >
                        <IconComp className="w-4 h-4" />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Color Picker */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
                  Tema Rengi
                </label>
                <div className="flex items-center gap-2">
                  {AVAILABLE_COLORS.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedColor(c.id)}
                      title={c.label}
                      className={`w-6 h-6 rounded-full ${c.class} transition-transform ${
                        selectedColor === c.id ? "ring-2 ring-offset-2 ring-teal-500 scale-110" : "opacity-80 hover:opacity-100"
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={cancelEdit}
                  className="px-3 py-1.5 text-xs font-semibold rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800"
                >
                  İptal
                </button>
                <button
                  type="button"
                  onClick={saveEdit}
                  disabled={!nameInput.trim()}
                  className="px-4 py-1.5 text-xs font-bold rounded-xl bg-teal-600 hover:bg-teal-500 text-white shadow-xs disabled:opacity-50 flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{isAddingNew ? "Bölümü Kaydet" : "Değişiklikleri Kaydet"}</span>
                </button>
              </div>
            </div>
          )}

          {/* Section List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Mevcut Bölümler ({sections.length})
              </span>
              {!isAddingNew && !editingId && (
                <button
                  onClick={startNew}
                  className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:text-teal-500 flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Yeni Bölüm Ekle</span>
                </button>
              )}
            </div>

            {sections.map((sec) => {
              const IconComp = getIconComponent(sec.icon);
              return (
                <div
                  key={sec.id}
                  className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 hover:border-teal-300 dark:hover:border-teal-700 transition-colors"
                >
                  <div
                    onClick={() => {
                      if (onSelectSection) {
                        onSelectSection(sec.name);
                        onClose();
                      }
                    }}
                    className="flex items-center gap-3 cursor-pointer flex-1"
                  >
                    <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-700/80 flex items-center justify-center text-teal-600 dark:text-teal-400 shadow-xs">
                      <IconComp className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900 dark:text-white">
                          {sec.name}
                        </span>
                        {sec.isDefault && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400">
                            Varsayılan
                          </span>
                        )}
                      </div>
                      {sec.description && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                          {sec.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => startEdit(sec)}
                      title="Bölüm Adını & İkonunu Düzenle"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-teal-50 dark:hover:bg-teal-950/40 transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    {!sec.isDefault && (
                      <button
                        onClick={() => deleteSection(sec.id, sec.name)}
                        title="Bölümü Sil"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white transition-colors"
          >
            Tamam
          </button>
        </div>
      </div>
    </div>
  );
};
