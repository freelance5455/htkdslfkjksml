import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';

interface GameLoadingOverlayProps {
  worldName: string;
  onFinish: () => void;
}

const LETTERS = ['S', 'L', 'A', 'P', 'B', 'O', 'X'];

export const GameLoadingOverlay: React.FC<GameLoadingOverlayProps> = ({ worldName, onFinish }) => {
  const [progress, setProgress] = useState(0);
  const onFinishRef = useRef(onFinish);
  onFinishRef.current = onFinish;

  useEffect(() => {
    const start = performance.now();
    const duration = 2100;
    let finishTimer: number | null = null;
    let completed = false;

    const interval = window.setInterval(() => {
      const elapsed = performance.now() - start;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      if (pct >= 100 && !completed) {
        completed = true;
        window.clearInterval(interval);
        finishTimer = window.setTimeout(() => {
          onFinishRef.current();
        }, 180);
      }
    }, 30);

    // Hard safety fallback in case timers are throttled
    const hardFallback = window.setTimeout(() => {
      if (!completed) {
        completed = true;
        window.clearInterval(interval);
        setProgress(100);
        onFinishRef.current();
      }
    }, duration + 600);

    return () => {
      window.clearInterval(interval);
      window.clearTimeout(hardFallback);
      if (finishTimer !== null) {
        window.clearTimeout(finishTimer);
      }
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.25 } }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#09090b] text-white overflow-hidden select-none p-6"
    >
      {/* Animated Monochrome Grid Background */}
      <div
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(255,255,255,0.22) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.22) 1px, transparent 1px)',
          backgroundSize: '42px 42px',
        }}
      />

      <div className="relative z-10 flex flex-col items-center max-w-md w-full text-center space-y-6">
        {/* Falling SLAPBOX Letters from Top */}
        <div className="flex items-center justify-center gap-1.5 sm:gap-2.5 pt-2">
          {LETTERS.map((char, idx) => (
            <motion.span
              key={`${char}-${idx}`}
              initial={{ y: -220, opacity: 0, rotate: idx % 2 === 0 ? -14 : 14, scale: 1.25 }}
              animate={{ y: 0, opacity: 1, rotate: 0, scale: 1 }}
              transition={{
                type: 'spring',
                stiffness: 290,
                damping: 15,
                delay: idx * 0.07,
              }}
              className={`font-display text-4xl sm:text-5xl font-black tracking-tight inline-flex items-center justify-center w-10 h-12 sm:w-12 sm:h-14 rounded-xl border ${
                idx < 4
                  ? 'bg-white text-black border-white shadow-[0_6px_0_rgba(255,255,255,0.3)]'
                  : 'bg-zinc-900 text-white border-white/40 shadow-[0_6px_0_rgba(255,255,255,0.18)]'
              }`}
            >
              {char}
            </motion.span>
          ))}
        </div>

        {/* Eating Noob Character Animation */}
        <motion.div
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.35 }}
          className="relative flex flex-col items-center py-2"
        >
          {/* Floating Speech Bubble */}
          <motion.div
            animate={{ y: [0, -5, 0], scale: [1, 1.06, 1] }}
            transition={{ repeat: Infinity, duration: 0.9, ease: 'easeInOut' }}
            className="mb-2 px-3 py-1 rounded-full bg-white text-black text-xs font-extrabold tracking-wide shadow-lg"
          >
            NYAM NYAM!
          </motion.div>

          {/* Classic Noob SVG Eating Burger */}
          <svg
            width="156"
            height="148"
            viewBox="0 0 160 150"
            className="drop-shadow-[0_10px_25px_rgba(255,255,255,0.12)]"
            aria-label="Noob sedang makan"
          >
            {/* Floor Shadow */}
            <ellipse cx="80" cy="138" rx="46" ry="8" fill="rgba(255,255,255,0.14)" />

            {/* Left & Right Green Legs */}
            <rect x="54" y="102" width="23" height="32" rx="3" fill="#22c55e" stroke="#09090b" strokeWidth="2.5" />
            <rect x="83" y="102" width="23" height="32" rx="3" fill="#22c55e" stroke="#09090b" strokeWidth="2.5" />

            {/* Blue Torso */}
            <rect x="52" y="58" width="56" height="46" rx="4" fill="#2563eb" stroke="#09090b" strokeWidth="2.5" />

            {/* Left Yellow Arm resting */}
            <rect x="33" y="60" width="18" height="38" rx="3" fill="#fde047" stroke="#09090b" strokeWidth="2.5" />

            {/* Yellow Blocky Head with gentle chew bounce */}
            <motion.g
              animate={{ y: [0, 2, 0] }}
              transition={{ repeat: Infinity, duration: 0.45, ease: 'easeInOut' }}
            >
              <rect x="56" y="14" width="48" height="44" rx="5" fill="#fde047" stroke="#09090b" strokeWidth="2.5" />
              {/* Eyes */}
              <rect x="68" y="27" width="6" height="9" rx="1.5" fill="#09090b" />
              <rect x="86" y="27" width="6" height="9" rx="1.5" fill="#09090b" />
              {/* Animated Chewing Mouth */}
              <motion.ellipse
                cx="80"
                cy="45"
                rx="8"
                animate={{ ry: [2, 6.5, 2] }}
                transition={{ repeat: Infinity, duration: 0.45, ease: 'easeInOut' }}
                fill="#09090b"
              />
            </motion.g>

            {/* Right Arm + Burger Lifting to Mouth (anchored cleanly at shoulder 118,66) */}
            <g transform="translate(118, 66)">
              <motion.g
                animate={{ rotate: [18, -36, 18] }}
                transition={{ repeat: Infinity, duration: 0.85, ease: 'easeInOut' }}
              >
                <rect x="-9" y="-6" width="18" height="36" rx="3" fill="#fde047" stroke="#09090b" strokeWidth="2.5" />
                {/* Burger in Hand */}
                <g transform="translate(-19, -22)">
                  <path d="M2 10 C2 2, 26 2, 26 10 Z" fill="#f59e0b" stroke="#09090b" strokeWidth="2" />
                  <rect x="1" y="10" width="26" height="4" rx="2" fill="#22c55e" />
                  <rect x="2" y="14" width="24" height="5" rx="1.5" fill="#78350f" />
                  <rect x="2" y="19" width="24" height="4" rx="2" fill="#fbbf24" stroke="#09090b" strokeWidth="1.5" />
                </g>
              </motion.g>
            </g>

            {/* Animated Flying Crumbs */}
            <motion.circle
              cx="60"
              cy="46"
              r="2.5"
              fill="#fbbf24"
              animate={{ x: [-2, -16], y: [0, 14], opacity: [1, 0] }}
              transition={{ repeat: Infinity, duration: 0.7, ease: 'easeOut' }}
            />
            <motion.circle
              cx="96"
              cy="44"
              r="2.2"
              fill="#f59e0b"
              animate={{ x: [2, 18], y: [0, 12], opacity: [1, 0] }}
              transition={{ repeat: Infinity, duration: 0.7, delay: 0.25, ease: 'easeOut' }}
            />
          </svg>
        </motion.div>

        {/* World Info + Animated Progress Bar */}
        <motion.div
          initial={{ y: 24, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.25 }}
          className="w-full rounded-2xl bg-zinc-900 border border-white/15 p-4 space-y-3"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-400 font-semibold uppercase tracking-wider">Memasuki Map</span>
            <span className="font-mono-num font-bold text-white">{progress}%</span>
          </div>
          <div className="font-display text-lg font-extrabold text-white truncate">{worldName}</div>

          <div className="w-full h-3 rounded-full bg-zinc-800 border border-white/10 overflow-hidden p-0.5">
            <motion.div
              className="h-full rounded-full bg-white"
              style={{ width: `${progress}%` }}
              transition={{ ease: 'linear', duration: 0.08 }}
            />
          </div>

          <div className="text-[11px] text-zinc-400">
            {progress < 40
              ? 'Menyiapkan arena & suara...'
              : progress < 80
              ? 'Memuat karakter, sepatu & efek...'
              : 'Hampir siap, ayo bermain!'}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};
