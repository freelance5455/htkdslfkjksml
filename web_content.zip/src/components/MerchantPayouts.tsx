import React, { useState } from 'react';
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  CreditCard, 
  Building2, 
  Phone, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  Zap, 
  Settings, 
  FileText, 
  Download, 
  HelpCircle,
  KeyRound,
  Check,
  AlertCircle
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { MerchantPayoutSettings } from '../types';

export const MerchantPayouts: React.FC = () => {
  const { 
    merchantSettings, 
    updateMerchantSettings, 
    availableBalance, 
    totalRevenue, 
    totalWithdrawn, 
    payouts, 
    requestPayout,
    addToast
  } = useStore();

  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [isSubmittingWithdrawal, setIsSubmittingWithdrawal] = useState(false);
  const [showSettingsForm, setShowSettingsForm] = useState(false);

  // Form local state
  const [formData, setFormData] = useState<MerchantPayoutSettings>({ ...merchantSettings });
  const [isCopiedWebhook, setIsCopiedWebhook] = useState(false);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateMerchantSettings(formData);
    setShowSettingsForm(false);
  };

  const handleExecuteWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(withdrawAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      addToast('Valor Inválido', 'Digite um valor válido para levantamento.', 'error');
      return;
    }
    if (amountNum > availableBalance) {
      addToast('Saldo Insuficiente', `O teu saldo disponível é de ${availableBalance.toLocaleString('pt-MZ')} MT.`, 'error');
      return;
    }

    setIsSubmittingWithdrawal(true);
    await new Promise(r => setTimeout(r, 900));
    const success = await requestPayout(amountNum);
    setIsSubmittingWithdrawal(false);
    if (success) {
      setWithdrawAmount('');
    }
  };

  const webhookUrl = 'https://escalebuilder.escalepay.com/api/webhooks/mpesa-callback';

  return (
    <div className="space-y-8 pb-16 max-w-5xl mx-auto">
      
      {/* Top Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600">
            <Wallet className="w-4 h-4" />
            <span>Painel do Comerciante & Carteira</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Como Você Recebe os Pagamentos
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Gestão do saldo arrecadado em vendas, contas de recebimento e levantamentos para M-Pesa e Bancos.
          </p>
        </div>

        <button
          onClick={() => setShowSettingsForm(!showSettingsForm)}
          className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-2 self-start sm:self-auto"
        >
          <Settings className="w-4 h-4" />
          <span>{showSettingsForm ? 'Ver Carteira' : 'Configurar Contas de Recebimento'}</span>
        </button>
      </div>

      {/* Explanatory Banner: "Como funciona o fluxo do dinheiro" */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-[#0b291d] text-white border border-emerald-900/60 shadow-lg space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider">
          <Zap className="w-4 h-4" />
          <span>Fluxo Direto de Recebimento em Moçambique</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-200">
          
          <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-emerald-300">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">1</span>
              <span>Cliente Paga na Loja</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              O comprador seleciona <strong>M-Pesa, e-Mola, Cartão ou Ponto 24</strong> e autoriza o PIN no telemóvel no checkout.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-emerald-300">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">2</span>
              <span>Liquidação no Gateway</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              O valor em Meticais (MT) é confirmado em tempo real e fica creditado no seu <strong>Saldo Disponível</strong> imediatamente.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-emerald-300">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">3</span>
              <span>Você Recebe o Dinheiro</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              O valor cai diretamente no seu <strong>M-Pesa ({merchantSettings.mpesaNumber})</strong> ou na sua <strong>conta bancária ({merchantSettings.bankName})</strong> por saque ou envio diário automático.
            </p>
          </div>

        </div>
      </div>

      {/* KPI Financial Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* Card 1: Available for Payout */}
        <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-sm space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Saldo Disponível para Saque</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <div>
            <div className="text-3xl font-extrabold font-mono text-emerald-700 tabular-nums">
              Mt {availableBalance.toLocaleString('pt-MZ')},00 <span className="text-sm font-normal text-slate-500">MZN</span>
            </div>
            <div className="text-[11px] text-emerald-700 font-medium mt-1">
              Livre para transferência imediata
            </div>
          </div>
          <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-100 flex items-center justify-between">
            <span>Destino configurado:</span>
            <strong className="text-slate-700 capitalize">
              {merchantSettings.payoutMethod === 'mpesa' ? `M-Pesa (+258 ${merchantSettings.mpesaNumber})` : merchantSettings.bankName}
            </strong>
          </div>
        </div>

        {/* Card 2: Total Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold">Total Bruto de Vendas</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-600" />
          </div>
          <div>
            <div className="text-3xl font-extrabold font-mono text-slate-900 tabular-nums">
              Mt {totalRevenue.toLocaleString('pt-MZ')},00 <span className="text-sm font-normal text-slate-400">MZN</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Total acumulado em pedidos pagos
            </div>
          </div>
          <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-100 flex items-center justify-between">
            <span>Taxa do gateway:</span>
            <span className="text-emerald-600 font-semibold">0% Promocional</span>
          </div>
        </div>

        {/* Card 3: Total Withdrawn */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold">Total Já Transferido</span>
            <CheckCircle2 className="w-4 h-4 text-sky-600" />
          </div>
          <div>
            <div className="text-3xl font-extrabold font-mono text-slate-900 tabular-nums">
              Mt {totalWithdrawn.toLocaleString('pt-MZ')},00 <span className="text-sm font-normal text-slate-400">MZN</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Depositado na sua conta ou carteira
            </div>
          </div>
          <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-100 flex items-center justify-between">
            <span>Transferência Automática:</span>
            <span className="text-emerald-700 font-semibold">
              {merchantSettings.autoPayout ? 'Ativa (Diária às 18h)' : 'Manual'}
            </span>
          </div>
        </div>

      </div>

      {/* Quick Withdrawal Box */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Solicitar Levantamento / Transferência Imediata
            </h2>
            <p className="text-xs text-slate-500">
              Transfira o seu saldo disponível diretamente para o seu M-Pesa ou conta bancária em poucos segundos.
            </p>
          </div>
          <div className="text-xs text-slate-600 font-medium">
            Saldo Disponível: <strong className="font-mono text-emerald-700">{availableBalance.toLocaleString('pt-MZ')} MT</strong>
          </div>
        </div>

        <form onSubmit={handleExecuteWithdrawal} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Valor a Levantar (MT / MZN)
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="10"
                  max={availableBalance}
                  step="1"
                  required
                  placeholder={`Ex: ${Math.min(1000, availableBalance)}`}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="w-full pl-3 pr-20 py-2.5 text-sm bg-white border border-slate-300 rounded-xl font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => setWithdrawAmount(availableBalance.toString())}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors"
                >
                  Tudo ({availableBalance} MT)
                </button>
              </div>
            </div>

            <div className="flex flex-col justify-end">
              <button
                type="submit"
                disabled={availableBalance <= 0 || isSubmittingWithdrawal}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2"
              >
                {isSubmittingWithdrawal ? (
                  <span className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Processando B2C...
                  </span>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    <span>Transferir para o Meu {merchantSettings.payoutMethod.toUpperCase()}</span>
                  </>
                )}
              </button>
            </div>

          </div>

          <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl text-xs text-slate-600 flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                Os fundos serão enviados para: <strong>{merchantSettings.accountHolder}</strong> ({merchantSettings.payoutMethod === 'mpesa' ? `M-Pesa +258 ${merchantSettings.mpesaNumber}` : `${merchantSettings.bankName} NIB ${merchantSettings.nib}`})
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowSettingsForm(true)}
              className="text-xs text-emerald-700 font-semibold hover:underline"
            >
              Alterar dados de destino
            </button>
          </div>
        </form>
      </div>

      {/* Account Settings Configuration Form (Collapsible or toggleable) */}
      {showSettingsForm && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-md space-y-6 animate-in fade-in">
          
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Configurações da Conta do Dono (Onde Você Recebe)
              </h2>
              <p className="text-xs text-slate-500">
                Configure os números de telemóvel e contas bancárias onde a EscalePay deposita o valor das suas vendas.
              </p>
            </div>
            <button
              onClick={() => setShowSettingsForm(false)}
              className="text-slate-400 hover:text-slate-700 text-sm font-semibold"
            >
              ✕ Fechar
            </button>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Account Holder Name */}
              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Nome Completo do Titular da Conta <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.accountHolder}
                  onChange={(e) => setFormData(prev => ({ ...prev, accountHolder: e.target.value }))}
                  placeholder="Nome completo conforme registo do M-Pesa / BI"
                  className="w-full px-3.5 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              {/* Preferred Payout Method */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Método de Recebimento Principal
                </label>
                <select
                  value={formData.payoutMethod}
                  onChange={(e) => setFormData(prev => ({ ...prev, payoutMethod: e.target.value as any }))}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
                >
                  <option value="mpesa">M-Pesa (Vodacom Moçambique)</option>
                  <option value="emola">e-Mola (Movitel)</option>
                  <option value="bank">Conta Bancária (Transferência NIB)</option>
                </select>
              </div>

              {/* Automatic Payout Toggle */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Levantamento Automático Diário
                </label>
                <select
                  value={formData.autoPayout ? 'yes' : 'no'}
                  onChange={(e) => setFormData(prev => ({ ...prev, autoPayout: e.target.value === 'yes' }))}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
                >
                  <option value="yes">Sim - Transferir automaticamente todos os dias às 18h</option>
                  <option value="no">Não - Apenas quando eu solicitar manualmente</option>
                </select>
              </div>

              {/* M-Pesa Number */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Número M-Pesa para Recebimento (Vodacom)
                </label>
                <div className="flex border border-slate-300 rounded-lg overflow-hidden">
                  <span className="px-3 py-2 bg-slate-100 text-slate-600 font-semibold border-r border-slate-300">
                    +258
                  </span>
                  <input
                    type="tel"
                    value={formData.mpesaNumber}
                    onChange={(e) => setFormData(prev => ({ ...prev, mpesaNumber: e.target.value }))}
                    placeholder="84 16 34 528"
                    className="flex-1 px-3 py-2 text-xs text-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              {/* e-Mola Number */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Número e-Mola para Recebimento (Movitel)
                </label>
                <div className="flex border border-slate-300 rounded-lg overflow-hidden">
                  <span className="px-3 py-2 bg-slate-100 text-slate-600 font-semibold border-r border-slate-300">
                    +258
                  </span>
                  <input
                    type="tel"
                    value={formData.emolaNumber}
                    onChange={(e) => setFormData(prev => ({ ...prev, emolaNumber: e.target.value }))}
                    placeholder="86 12 34 567"
                    className="flex-1 px-3 py-2 text-xs text-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              {/* Bank Name */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Banco Moçambicano
                </label>
                <select
                  value={formData.bankName}
                  onChange={(e) => setFormData(prev => ({ ...prev, bankName: e.target.value }))}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
                >
                  <option value="Millennium BIM">Millennium BIM</option>
                  <option value="BCI">BCI (Banco Comercial e de Investimentos)</option>
                  <option value="Standard Bank">Standard Bank Moçambique</option>
                  <option value="Moza Banco">Moza Banco</option>
                  <option value="Absa Bank">Absa Bank Moçambique</option>
                  <option value="Nedbank">Nedbank Moçambique</option>
                </select>
              </div>

              {/* Bank NIB */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  NIB da Conta (21 dígitos)
                </label>
                <input
                  type="text"
                  value={formData.nib}
                  onChange={(e) => setFormData(prev => ({ ...prev, nib: e.target.value }))}
                  placeholder="0001 0000 2910 8420 1902 4"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 font-mono"
                />
              </div>

            </div>

            {/* Technical API credentials view */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="flex items-center gap-2 font-bold text-slate-800">
                <KeyRound className="w-4 h-4 text-emerald-600" />
                <span>Integração de Webhook & Chave do Gateway (EscalePay / Vodacom)</span>
              </div>
              <p className="text-[11px] text-slate-500">
                O seu webhook está configurado para receber confirmações instantâneas de pagamento (callbacks).
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={webhookUrl}
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-mono text-slate-600"
                />
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(webhookUrl);
                    setIsCopiedWebhook(true);
                    setTimeout(() => setIsCopiedWebhook(false), 2000);
                  }}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  {isCopiedWebhook ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : 'Copiar'}
                </button>
              </div>
            </div>

            <div className="pt-3 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowSettingsForm(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold"
              >
                Salvar Configurações de Recebimento
              </button>
            </div>

          </form>

        </div>
      )}

      {/* Payout History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Histórico de Transferências para a Sua Conta
            </h3>
            <p className="text-xs text-slate-500">
              Todos os levantamentos enviados com sucesso pelo gateway EscalePay para o seu M-Pesa ou Banco.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-500">
            {payouts.length} saques realizados
          </span>
        </div>

        {payouts.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            Nenhum levantamento realizado ainda.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {payouts.map((pay) => (
              <div key={pay.id} className="p-4 flex items-center justify-between text-xs hover:bg-slate-50/60 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-200">
                    <ArrowDownLeft className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 flex items-center gap-2">
                      <span>{pay.destination}</span>
                      <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-semibold uppercase">
                        {pay.status === 'completed' ? 'Liquidado' : 'Processando'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                      <span>ID: {pay.id}</span>
                      <span>·</span>
                      <span className="font-mono text-slate-400">Ref Operadora: {pay.reference}</span>
                      <span>·</span>
                      <span>{new Date(pay.requestedAt).toLocaleDateString('pt-MZ')} às {new Date(pay.requestedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-bold font-mono text-emerald-700 tabular-nums">
                    + Mt {pay.amount.toLocaleString('pt-MZ')},00 MZN
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    Taxa de saque: Grátis
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
