import React, { useEffect, useRef, useState } from 'react';
import {
  Battery,
  BellOff,
  Cpu,
  Gauge,
  GripVertical,
  Lock,
  Maximize2,
  Minimize2,
  Unlock,
  Wifi,
  X,
  Zap,
} from 'lucide-react';
import { HudConfig, ScreenId, SystemTelemetry } from '../types';

interface FloatingGameHudProps {
  config: HudConfig;
  telemetry: SystemTelemetry;
  dndActive: boolean;
  onToggleDnd: () => void;
  onUpdateConfig: (partial: Partial<HudConfig>) => void;
  onNavigate: (screen: ScreenId) => void;
}

export const FloatingGameHud: React.FC<FloatingGameHudProps> = ({
  config,
  telemetry,
  dndActive,
  onToggleDnd,
  onUpdateConfig,
  onNavigate,
}) => {
  const [minimized, setMinimized] = useState(false);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const draggingRef = useRef<{
    active: boolean;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
  }>({ active: false, startX: 0, startY: 0, originX: 0, originY: 0 });

  // Reset drag offset whenever user picks a preset corner
  useEffect(() => {
    setDragOffset({ x: 0, y: 0 });
  }, [config.corner]);

  if (!config.enabled) return null;

  const cornerClasses: Record<HudConfig['corner'], string> = {
    'top-left': 'top-20 left-4',
    'top-right': 'top-20 right-4',
    'bottom-left': 'bottom-20 left-4',
    'bottom-right': 'bottom-20 right-4',
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (config.locked) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    draggingRef.current = {
      active: true,
      startX: e.clientX,
      startY: e.clientY,
      originX: dragOffset.x,
      originY: dragOffset.y,
    };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draggingRef.current.active || config.locked) return;
    setDragOffset({
      x: draggingRef.current.originX + (e.clientX - draggingRef.current.startX),
      y: draggingRef.current.originY + (e.clientY - draggingRef.current.startY),
    });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (draggingRef.current.active) {
      draggingRef.current.active = false;
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // ignore if pointer already released
      }
    }
  };

  const opacityValue = Math.max(0.45, Math.min(1, config.opacity / 100));

  if (minimized) {
    return (
      <div
        style={{
          transform: `translate3d(${dragOffset.x}px, ${dragOffset.y}px, 0)`,
          opacity: opacityValue,
        }}
        className={`fixed z-50 ${cornerClasses[config.corner]} select-none`}
      >
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className={`flex items-center gap-2.5 px-3 py-2 rounded-xl bg-[#101010]/90 backdrop-blur-md text-neutral-100 shadow-xl ${
            config.neonBorder
              ? 'border border-[#39E52D]/70 shadow-[#39E52D]/15'
              : 'border border-neutral-700'
          } ${config.locked ? 'cursor-default' : 'cursor-grab active:cursor-grabbing'}`}
        >
          <Gauge className="w-4 h-4 text-[#39E52D]" />
          <span className="font-mono text-xs font-semibold tabular-nums text-[#39E52D]">
            {telemetry.fps} FPS
          </span>
          <button
            type="button"
            onClick={() => setMinimized(false)}
            aria-label="Expand Game HUD"
            className="p-1 rounded hover:bg-white/10 text-neutral-300"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        transform: `translate3d(${dragOffset.x}px, ${dragOffset.y}px, 0)`,
        opacity: opacityValue,
      }}
      className={`fixed z-50 ${cornerClasses[config.corner]} select-none max-w-[290px] w-[268px]`}
    >
      <div
        className={`rounded-2xl bg-[#101010]/92 backdrop-blur-md text-neutral-100 shadow-2xl overflow-hidden transition-colors ${
          config.neonBorder
            ? 'border border-[#39E52D]/70 shadow-[0_0_24px_rgba(57,229,45,0.16)]'
            : 'border border-neutral-800'
        }`}
      >
        {/* Drag Handle Header */}
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className={`flex items-center justify-between px-3 py-2 border-b border-white/10 bg-white/[0.03] ${
            config.locked ? 'cursor-default' : 'cursor-grab active:cursor-grabbing'
          }`}
        >
          <div className="flex items-center gap-1.5 min-w-0">
            <GripVertical className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
            <span className="text-xs font-semibold tracking-tight text-white truncate">
              Game HUD
            </span>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => onUpdateConfig({ locked: !config.locked })}
              aria-label={config.locked ? 'Unlock HUD position' : 'Lock HUD position'}
              title={config.locked ? 'Unlock position' : 'Lock position'}
              className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-300"
            >
              {config.locked ? (
                <Lock className="w-3.5 h-3.5 text-[#39E52D]" />
              ) : (
                <Unlock className="w-3.5 h-3.5" />
              )}
            </button>
            <button
              type="button"
              onClick={() => setMinimized(true)}
              aria-label="Minimize Game HUD"
              className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-300"
            >
              <Minimize2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => onUpdateConfig({ enabled: false })}
              aria-label="Close Game HUD"
              className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Metrics Grid */}
        <div
          className={`p-3 ${
            config.appearance === 'minimal' ? 'space-y-2' : 'grid grid-cols-2 gap-2'
          }`}
        >
          {config.showFps && (
            <div className="rounded-xl bg-white/[0.04] px-2.5 py-2 border border-white/5">
              <div className="flex items-center gap-1 text-[11px] text-neutral-400">
                <Gauge className="w-3 h-3 text-[#39E52D]" />
                <span>Frame Rate</span>
              </div>
              <div className="mt-0.5 font-mono text-sm font-bold tabular-nums text-[#39E52D]">
                {telemetry.fps} FPS
              </div>
            </div>
          )}

          {config.showBattery && (
            <div className="rounded-xl bg-white/[0.04] px-2.5 py-2 border border-white/5">
              <div className="flex items-center gap-1 text-[11px] text-neutral-400">
                <Battery className="w-3 h-3 text-[#39E52D]" />
                <span>Battery</span>
              </div>
              <div className="mt-0.5 font-mono text-sm font-bold tabular-nums text-white">
                {telemetry.batteryLevel !== null ? `${telemetry.batteryLevel}%` : 'AC / N/A'}
              </div>
            </div>
          )}

          {config.showRam && config.appearance !== 'minimal' && (
            <div className="rounded-xl bg-white/[0.04] px-2.5 py-2 border border-white/5">
              <div className="flex items-center gap-1 text-[11px] text-neutral-400">
                <Cpu className="w-3 h-3 text-neutral-300" />
                <span>Memory</span>
              </div>
              <div className="mt-0.5 font-mono text-xs font-semibold tabular-nums text-neutral-100">
                {telemetry.jsHeapUsedMb !== null
                  ? `${telemetry.jsHeapUsedMb} MB`
                  : telemetry.deviceMemoryGb
                  ? `${telemetry.deviceMemoryGb} GB Tier`
                  : `${telemetry.cpuCores} Cores`}
              </div>
            </div>
          )}

          {config.showNetwork && config.appearance !== 'minimal' && (
            <div className="rounded-xl bg-white/[0.04] px-2.5 py-2 border border-white/5">
              <div className="flex items-center gap-1 text-[11px] text-neutral-400">
                <Wifi className="w-3 h-3 text-neutral-300" />
                <span>Network</span>
              </div>
              <div className="mt-0.5 font-mono text-xs font-semibold tabular-nums text-neutral-100">
                {telemetry.online
                  ? telemetry.networkRttMs !== null
                    ? `${telemetry.networkRttMs} ms`
                    : telemetry.effectiveType?.toUpperCase() || 'Online'
                  : 'Offline'}
              </div>
            </div>
          )}
        </div>

        {/* Tactical Shortcuts */}
        {config.showShortcuts && config.appearance === 'tactical' && (
          <div className="px-3 pb-3 pt-1 flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleDnd}
              className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                dndActive
                  ? 'bg-[#39E52D] text-black'
                  : 'bg-white/10 text-neutral-200 hover:bg-white/15'
              }`}
            >
              <BellOff className="w-3.5 h-3.5" />
              <span>{dndActive ? 'DND On' : 'DND Off'}</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('ultra')}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-lg text-xs font-medium bg-white/10 text-neutral-200 hover:bg-white/15 transition-colors whitespace-nowrap"
            >
              <Zap className="w-3.5 h-3.5 text-[#39E52D]" />
              <span>Ultra</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
