import Link from "next/link";
import { PLAN_RANK, type PlanTier, type ToolDef } from "@/lib/ai/tools";

export default function ToolTabs({ tools, active }: { tools: ToolDef[]; active: string }) {
  return (
    <div className="scrollbar-slim -mx-3 mb-4 flex gap-2 overflow-x-auto px-3 pb-1 md:mx-0 md:flex-wrap md:px-0">
      {tools.map((tool) => {
        const isActive = tool.id === active;
        return (
          <Link
            key={tool.id}
            href={tool.id === "ideas" ? "/ideas" : tool.id === "calendar" ? "/calendar" : tool.id === "analyze" ? "/analyze" : `/create?tool=${tool.id}`}
            className={`flex shrink-0 items-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold transition ${
              isActive
                ? "border-violet-400/50 bg-violet-500/20 text-white"
                : "border-white/10 bg-white/[0.04] text-[color:var(--muted)] hover:text-white"
            }`}
          >
            <span>{tool.emoji}</span>
            {tool.name.replace(" Generator", "").replace(" Generator", "")}
          </Link>
        );
      })}
    </div>
  );
}

export function planRank(key: string): number {
  return PLAN_RANK[(key as PlanTier) ?? "free"] ?? 0;
}
