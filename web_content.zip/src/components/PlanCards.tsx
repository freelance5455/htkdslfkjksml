"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { ApiError, apiPost } from "@/lib/client/api";
import { Spinner, useToast } from "./ui";
import type { PublicPlan } from "@/lib/plans";

export function formatPriceLabel(cents: number, currency: string, interval: string) {
  if (cents <= 0) return "Free";
  const value = (cents / 100).toFixed(2).replace(/\.00$/, "");
  return `$${value}/${interval === "month" ? "mo" : interval}`;
}

export default function PlanCards({
  plans,
  currentPlan,
  signedIn,
  compact = false,
}: {
  plans: PublicPlan[];
  currentPlan?: string;
  signedIn: boolean;
  compact?: boolean;
}) {
  const router = useRouter();
  const { show, node } = useToast();
  const [pending, setPending] = useState<string | null>(null);

  const subscribe = async (planKey: string) => {
    if (!signedIn) {
      router.push("/signup");
      return;
    }
    setPending(planKey);
    try {
      await apiPost("/api/billing", { planKey });
      show(`You're on the ${planKey} plan. Limits updated.`);
      router.refresh();
    } catch (error) {
      show(error instanceof ApiError ? error.message : "Could not update subscription", "bad");
    } finally {
      setPending(null);
    }
  };

  return (
    <div className="grid gap-3 md:grid-cols-3">
      {node}
      {plans
        .map((plan) => {
          const isCurrent = currentPlan === plan.key;
          const isFree = plan.priceCents <= 0;
          return (
            <div
              key={plan.key}
              className={`card flex flex-col p-5 ${plan.key === "creator" ? "border-violet-400/40" : ""}`}
            >
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-lg font-bold">{plan.name}</h3>
                {plan.key === "creator" ? (
                  <span className="chip border-violet-400/30 bg-violet-500/20 text-violet-100">Most popular</span>
                ) : null}
                {isCurrent ? (
                  <span className="chip border-emerald-400/30 bg-emerald-500/15 text-emerald-100">Current</span>
                ) : null}
              </div>
              <p className="mt-1 text-sm text-[color:var(--muted)]">{plan.tagline}</p>
              <p className="mt-3 text-3xl font-black">
                {formatPriceLabel(plan.priceCents, plan.currency, plan.interval)}
              </p>
              <p className="text-xs text-[color:var(--muted)]">
                {plan.monthlyLimit.toLocaleString()} generations / month
              </p>
              <ul className="mt-4 flex-1 space-y-2 text-sm text-white/85">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex gap-2">
                    <span className="text-cyan-300">✓</span>
                    {feature}
                  </li>
                ))}
              </ul>
              {!compact ? (
                <div className="mt-4">
                  {isCurrent ? (
                    <button type="button" className="btn btn-ghost w-full" disabled>
                      Current plan
                    </button>
                  ) : isFree ? (
                    <Link href={signedIn ? "/create?tool=titles" : "/signup"} className="btn btn-ghost w-full">
                      {signedIn ? "Start creating" : "Create free account"}
                    </Link>
                  ) : (
                    <button
                      type="button"
                      className="btn btn-primary w-full"
                      disabled={pending === plan.key}
                      onClick={() => subscribe(plan.key)}
                    >
                      {pending === plan.key ? (
                        <>
                          <Spinner /> Updating…
                        </>
                      ) : (
                        `Upgrade to ${plan.name}`
                      )}
                    </button>
                  )}
                </div>
              ) : null}
            </div>
          );
        })}
    </div>
  );
}
