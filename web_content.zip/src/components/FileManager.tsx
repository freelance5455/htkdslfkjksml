import React, { useState, useRef } from 'react';
import { 
  Folder, 
  FileText, 
  FileArchive, 
  FileCode, 
  FileSpreadsheet, 
  Search, 
  CheckSquare, 
  Square, 
  Upload, 
  Trash2, 
  Download, 
  Lock, 
  X, 
  HardDrive, 
  FolderPlus,
  Eye,
  Check,
  FileCheck,
  Edit2,
  Copy,
  Terminal,
  Info,
  Layers,
  Sparkles,
  HelpCircle,
  ShieldCheck
} from 'lucide-react';
import { FileItem } from '../types';

interface FileManagerProps {
  files: FileItem[];
  setFiles: React.Dispatch<React.SetStateAction<FileItem[]>>;
  currentPath: string;
  setCurrentPath: (path: string) => void;
  onOpenInTerminal?: (cmd: string) => void;
}

export const FileManager: React.FC<FileManagerProps> = ({
  files,
  setFiles,
  currentPath,
  setCurrentPath,
  onOpenInTerminal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  
  // Modais
  const [showCompressModal, setShowCompressModal] = useState(false);
  const [compressTargetItem, setCompressTargetItem] = useState<FileItem | null>(null);
  const [compressName, setCompressName] = useState('meus_arquivos_pat_backup.7z');
  const [compressFormat, setCompressFormat] = useState<'7z' | 'zip'>('7z');
  const [compressLevel, setCompressLevel] = useState<'store' | 'fast' | 'normal' | 'ultra'>('normal');
  const [compressPassword, setCompressPassword] = useState('');
  const [encryptHeaders, setEncryptHeaders] = useState(true);
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressProgress, setCompressProgress] = useState(0);
  
  const [showNewFolderModal, setShowNewFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  // Context Menu ao Segurar (Long Press / Right Click)
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    item: FileItem | null;
  }>({
    visible: false,
    x: 0,
    y: 0,
    item: null,
  });

  // Modal de Renomear
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [renameTargetItem, setRenameTargetItem] = useState<FileItem | null>(null);
  const [renameValue, setRenameValue] = useState('');

  // Modal de Detalhes / Propriedades
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [detailsItem, setDetailsItem] = useState<FileItem | null>(null);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Filtered files
  const filteredFiles = files.filter(f => 
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Toggle selection
  const toggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedIds.length === filteredFiles.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredFiles.map(f => f.id));
    }
  };

  // Delete selected
  const deleteSelected = () => {
    if (selectedIds.length === 0) return;
    setFiles(prev => prev.filter(f => !selectedIds.includes(f.id)));
    showToast(`✓ ${selectedIds.length} item(ns) removido(s) com sucesso.`);
    setSelectedIds([]);
  };

  // Local file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files;
    if (!uploaded || uploaded.length === 0) return;

    const newItems: FileItem[] = Array.from(uploaded).map((file, idx) => {
      const ext = file.name.split('.').pop()?.toLowerCase() || 'bin';
      const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
      return {
        id: `upload-${Date.now()}-${idx}`,
        name: file.name,
        type: 'file',
        size: file.size,
        formattedSize: file.size > 1024 * 1024 ? `${sizeMb} MB` : `${Math.round(file.size / 1024)} KB`,
        modified: new Date().toLocaleDateString('pt-BR'),
        ext,
        permissions: '-rw-r--r--'
      };
    });

    setFiles(prev => [...prev, ...newItems]);
    showToast(`✓ ${newItems.length} arquivo(s) importado(s) com sucesso.`);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Create folder
  const handleCreateFolder = () => {
    if (!newFolderName.trim()) return;
    const newFolder: FileItem = {
      id: `folder-${Date.now()}`,
      name: newFolderName.trim(),
      type: 'folder',
      size: 0,
      formattedSize: '--',
      itemsCount: 0,
      modified: new Date().toLocaleDateString('pt-BR'),
      permissions: 'drwxr-xr-x'
    };
    setFiles(prev => [newFolder, ...prev]);
    setNewFolderName('');
    setShowNewFolderModal(false);
    showToast(`✓ Pasta "${newFolder.name}" criada.`);
  };

  // Start compression simulation
  const handleStartCompression = () => {
    setIsCompressing(true);
    setCompressProgress(10);

    const interval = setInterval(() => {
      setCompressProgress(prev => {
        if (prev >= 95) {
          clearInterval(interval);
          setTimeout(() => {
            setIsCompressing(false);
            setShowCompressModal(false);
            setCompressProgress(0);

            const finalExt = compressFormat;
            const finalName = compressName.endsWith(`.${finalExt}`) ? compressName : `${compressName}.${finalExt}`;

            // Add new compressed file to list
            const archiveItem: FileItem = {
              id: `archive-${Date.now()}`,
              name: finalName,
              type: 'file',
              size: 2450000,
              formattedSize: compressLevel === 'ultra' ? '1.8 MB' : '2.4 MB',
              modified: new Date().toLocaleDateString('pt-BR'),
              ext: finalExt,
              permissions: '-rw-r--r--'
            };
            setFiles(prev => [archiveItem, ...prev]);
            showToast(`✓ Compactação ${compressFormat.toUpperCase()} AES-256 concluída! Arquivo "${archiveItem.name}" salvo.`);

            // Trigger real download
            const payload = `PAT_ARCHIVE_ENCRYPTED_AES256\nFormat: ${compressFormat}\nAlgorithm: ${compressFormat === '7z' ? 'LZMA2' : 'Deflate'}\nLevel: ${compressLevel}\nHeadersEncrypted: ${encryptHeaders}\nTimestamp: ${new Date().toISOString()}`;
            const blob = new Blob([payload], { type: 'application/octet-stream' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = archiveItem.name;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }, 400);
          return 100;
        }
        return prev + 25;
      });
    }, 250);
  };

  // Long press detection for mobile & desktop
  const handleTouchStart = (item: FileItem, e: React.TouchEvent | React.MouseEvent) => {
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;

    longPressTimerRef.current = setTimeout(() => {
      openContextMenu(item, clientX, clientY);
    }, 450);
  };

  const handleTouchEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handleContextMenu = (item: FileItem, e: React.MouseEvent) => {
    e.preventDefault();
    openContextMenu(item, e.clientX, e.clientY);
  };

  const openContextMenu = (item: FileItem, x: number, y: number) => {
    // Keep context menu on screen
    const menuWidth = 220;
    const menuHeight = 260;
    const safeX = Math.min(window.innerWidth - menuWidth - 10, Math.max(10, x));
    const safeY = Math.min(window.innerHeight - menuHeight - 10, Math.max(10, y));

    setContextMenu({
      visible: true,
      x: safeX,
      y: safeY,
      item,
    });
  };

  const closeContextMenu = () => {
    setContextMenu(prev => ({ ...prev, visible: false }));
  };

  // Action: Rename
  const handleRenameSubmit = () => {
    if (!renameTargetItem || !renameValue.trim()) return;
    setFiles(prev => prev.map(f => f.id === renameTargetItem.id ? { ...f, name: renameValue.trim() } : f));
    showToast(`✓ Renomeado para "${renameValue.trim()}".`);
    setShowRenameModal(false);
    setRenameTargetItem(null);
  };

  // Action: Duplicate
  const handleDuplicateItem = (item: FileItem) => {
    const copyItem: FileItem = {
      ...item,
      id: `copy-${Date.now()}`,
      name: `${item.name}_copia`,
      modified: new Date().toLocaleDateString('pt-BR')
    };
    setFiles(prev => [copyItem, ...prev]);
    showToast(`✓ Cópia de "${item.name}" criada.`);
  };

  // Icon helper
  const getFileIcon = (file: FileItem) => {
    if (file.type === 'folder') {
      return <Folder className="w-5 h-5 text-amber-400 shrink-0" />;
    }
    const ext = file.ext?.toLowerCase();
    if (['zip', '7z', 'rar', 'tar', 'gz'].includes(ext || '')) {
      return <FileArchive className="w-5 h-5 text-emerald-400 shrink-0" />;
    }
    if (['sh', 'kt', 'xml', 'js', 'ts', 'py', 'json', 'bat'].includes(ext || '')) {
      return <FileCode className="w-5 h-5 text-cyan-400 shrink-0" />;
    }
    if (['csv', 'xlsx'].includes(ext || '')) {
      return <FileSpreadsheet className="w-5 h-5 text-blue-400 shrink-0" />;
    }
    return <FileText className="w-5 h-5 text-neutral-400 shrink-0" />;
  };

  return (
    <div 
      className="flex-1 flex flex-col min-w-0 bg-black overflow-hidden relative"
      onClick={closeContextMenu}
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 border border-neutral-700 text-white text-xs px-4 py-2 rounded-lg shadow-xl font-mono flex items-center space-x-2 animate-fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        multiple
        className="hidden"
      />

      {/* Path & Storage Bar */}
      <div className="h-11 px-4 border-b border-neutral-800 bg-neutral-950 flex items-center justify-between text-xs shrink-0">
        <div className="flex items-center space-x-2 text-neutral-400 font-mono">
          <HardDrive className="w-3.5 h-3.5 text-neutral-500" />
          <span className="text-neutral-500">Caminho:</span>
          <span className="text-white font-bold">{currentPath}</span>
        </div>

        <div className="flex items-center space-x-3 text-[11px] text-neutral-400 font-mono">
          <span className="hidden sm:inline">18.4 GB usados / 128 GB</span>
          <div className="w-20 bg-neutral-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-white h-full" style={{ width: '15%' }} />
          </div>
        </div>
      </div>

      {/* Instructions Ribbon */}
      <div className="px-4 py-1.5 bg-neutral-900/60 border-b border-neutral-800/80 text-[11px] text-neutral-400 flex items-center justify-between font-mono">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span><strong>Dica:</strong> Segure o toque ou clique com botão direito em qualquer pasta para abrir o menu de opções!</span>
        </span>
        <span className="hidden md:inline text-neutral-500">Total: {files.length} itens</span>
      </div>

      {/* File Toolbar */}
      <div className="p-3 border-b border-neutral-800 bg-neutral-950/80 flex flex-wrap gap-2 items-center justify-between shrink-0">
        
        {/* Left Actions */}
        <div className="flex items-center space-x-2">
          <button
            onClick={selectAll}
            className="px-2.5 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-white flex items-center space-x-1.5 transition"
          >
            {selectedIds.length === filteredFiles.length && filteredFiles.length > 0 ? (
              <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Square className="w-3.5 h-3.5 text-neutral-400" />
            )}
            <span>{selectedIds.length > 0 ? `${selectedIds.length} Sel.` : 'Selecionar Tudo'}</span>
          </button>

          <button
            onClick={() => {
              setCompressTargetItem(null);
              setCompressName('meus_arquivos_pat_backup.7z');
              setShowCompressModal(true);
            }}
            className="px-3 py-1.5 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 flex items-center space-x-1.5 transition shadow"
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>Compactar (.7z AES)</span>
          </button>

          <button
            onClick={() => setShowNewFolderModal(true)}
            className="px-2.5 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 hover:text-white flex items-center space-x-1.5 transition"
          >
            <FolderPlus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Nova Pasta</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-2.5 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 hover:text-white flex items-center space-x-1.5 transition"
          >
            <Upload className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Importar</span>
          </button>

          {selectedIds.length > 0 && (
            <button
              onClick={deleteSelected}
              className="px-2.5 py-1.5 rounded bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-xs text-rose-300 flex items-center space-x-1.5 transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Excluir ({selectedIds.length})</span>
            </button>
          )}
        </div>

        {/* Right Search Bar */}
        <div className="relative flex-1 max-w-xs">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Pesquisar ficheiros..."
            className="w-full bg-black border border-neutral-800 pl-9 pr-3 py-1.5 text-xs text-white rounded-lg focus:outline-none focus:border-white transition font-mono"
          />
        </div>
      </div>

      {/* Files Grid View */}
      <div className="flex-1 p-4 overflow-y-auto custom-scrollbar">
        {filteredFiles.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-neutral-500 text-xs space-y-2">
            <Search className="w-8 h-8 text-neutral-600" />
            <span>Nenhum ficheiro encontrado com o termo &quot;{searchQuery}&quot;.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {filteredFiles.map(file => {
              const isSelected = selectedIds.includes(file.id);
              const isFolder = file.type === 'folder';

              return (
                <div
                  key={file.id}
                  onTouchStart={e => handleTouchStart(file, e)}
                  onTouchEnd={handleTouchEnd}
                  onMouseDown={e => handleTouchStart(file, e)}
                  onMouseUp={handleTouchEnd}
                  onContextMenu={e => handleContextMenu(file, e)}
                  onClick={() => {
                    if (isFolder) {
                      setCurrentPath(`${currentPath}/${file.name}`);
                      showToast(`Navegando para: ${file.name}`);
                    } else {
                      setDetailsItem(file);
                      setShowDetailsModal(true);
                    }
                  }}
                  className={`p-3 rounded-lg border transition cursor-pointer flex items-center justify-between select-none relative group ${
                    isSelected
                      ? 'bg-neutral-900 border-white ring-1 ring-white/30'
                      : 'bg-neutral-950 border-neutral-800/80 hover:border-neutral-600'
                  }`}
                  title="Segure para abrir opções de gerenciamento"
                >
                  <div className="flex items-center space-x-3 truncate">
                    {getFileIcon(file)}
                    <div className="truncate">
                      <div className="text-xs font-bold text-white truncate group-hover:text-neutral-200">
                        {file.name}
                      </div>
                      <div className="text-[10px] text-neutral-500 font-mono">
                        {isFolder ? `${file.itemsCount ?? 0} itens` : file.formattedSize} · {file.modified}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1 shrink-0 ml-2" onClick={e => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelect(file.id)}
                      className="accent-white w-4 h-4 cursor-pointer"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* CONTEXT MENU FLUTUANTE (AO SEGURAR NA PASTA/ARQUIVO) */}
      {contextMenu.visible && contextMenu.item && (
        <div
          style={{ top: `${contextMenu.y}px`, left: `${contextMenu.x}px` }}
          onClick={e => e.stopPropagation()}
          className="fixed z-50 w-56 rounded-xl bg-neutral-950 border border-neutral-700 shadow-2xl p-1.5 text-xs font-mono animate-fade-in divide-y divide-neutral-800"
        >
          {/* Header of Context Menu */}
          <div className="px-2.5 py-1.5 text-[11px] text-neutral-400 truncate font-bold text-white flex items-center space-x-1.5">
            {getFileIcon(contextMenu.item)}
            <span className="truncate">{contextMenu.item.name}</span>
          </div>

          {/* Action List */}
          <div className="py-1 space-y-0.5">
            {contextMenu.item.type === 'folder' ? (
              <button
                onClick={() => {
                  setCurrentPath(`${currentPath}/${contextMenu.item!.name}`);
                  closeContextMenu();
                }}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-neutral-800 text-neutral-200 hover:text-white flex items-center space-x-2"
              >
                <Folder className="w-3.5 h-3.5 text-amber-400" />
                <span>Abrir Pasta</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setDetailsItem(contextMenu.item);
                  setShowDetailsModal(true);
                  closeContextMenu();
                }}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-neutral-800 text-neutral-200 hover:text-white flex items-center space-x-2"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span>Visualizar Arquivo</span>
              </button>
            )}

            {/* Compactar este item */}
            <button
              onClick={() => {
                setCompressTargetItem(contextMenu.item);
                setCompressName(`${contextMenu.item!.name}.7z`);
                setShowCompressModal(true);
                closeContextMenu();
              }}
              className="w-full text-left px-2.5 py-1.5 rounded hover:bg-neutral-800 text-neutral-200 hover:text-white flex items-center space-x-2"
            >
              <FileArchive className="w-3.5 h-3.5 text-emerald-400" />
              <span>Compactar (.7z AES)</span>
            </button>

            {/* Renomear */}
            <button
              onClick={() => {
                setRenameTargetItem(contextMenu.item);
                setRenameValue(contextMenu.item!.name);
                setShowRenameModal(true);
                closeContextMenu();
              }}
              className="w-full text-left px-2.5 py-1.5 rounded hover:bg-neutral-800 text-neutral-200 hover:text-white flex items-center space-x-2"
            >
              <Edit2 className="w-3.5 h-3.5 text-blue-400" />
              <span>Renomear</span>
            </button>

            {/* Fazer Cópia / Duplicar */}
            <button
              onClick={() => {
                handleDuplicateItem(contextMenu.item!);
                closeContextMenu();
              }}
              className="w-full text-left px-2.5 py-1.5 rounded hover:bg-neutral-800 text-neutral-200 hover:text-white flex items-center space-x-2"
            >
              <Copy className="w-3.5 h-3.5 text-purple-400" />
              <span>Criar Cópia</span>
            </button>

            {/* Executar no Terminal se for script */}
            {contextMenu.item.type === 'file' && onOpenInTerminal && (
              <button
                onClick={() => {
                  onOpenInTerminal(`sh ${currentPath}/${contextMenu.item!.name}`);
                  closeContextMenu();
                }}
                className="w-full text-left px-2.5 py-1.5 rounded hover:bg-neutral-800 text-neutral-200 hover:text-white flex items-center space-x-2"
              >
                <Terminal className="w-3.5 h-3.5 text-amber-400" />
                <span>Executar no Terminal ADB</span>
              </button>
            )}
          </div>

          {/* Properties & Delete */}
          <div className="pt-1 space-y-0.5">
            <button
              onClick={() => {
                setDetailsItem(contextMenu.item);
                setShowDetailsModal(true);
                closeContextMenu();
              }}
              className="w-full text-left px-2.5 py-1.5 rounded hover:bg-neutral-800 text-neutral-200 hover:text-white flex items-center space-x-2"
            >
              <Info className="w-3.5 h-3.5 text-neutral-400" />
              <span>Propriedades & Detalhes</span>
            </button>

            <button
              onClick={() => {
                const idToDelete = contextMenu.item!.id;
                setFiles(prev => prev.filter(f => f.id !== idToDelete));
                showToast(`✓ "${contextMenu.item!.name}" excluído.`);
                closeContextMenu();
              }}
              className="w-full text-left px-2.5 py-1.5 rounded hover:bg-rose-950 text-rose-400 hover:text-rose-300 flex items-center space-x-2"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-400" />
              <span>Excluir Item</span>
            </button>
          </div>
        </div>
      )}

      {/* MODAL DE COMPACTAÇÃO COM EXPLICAÇÃO COMPLETA */}
      {showCompressModal && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl w-full max-w-lg p-5 space-y-4 shadow-2xl my-6">
            <div className="flex justify-between items-center border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2">
                <Lock className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold tracking-wider text-white">COMPACTAÇÃO AVANÇADA COM CRIPTOGRAFIA</h3>
              </div>
              <button
                onClick={() => !isCompressing && setShowCompressModal(false)}
                className="text-neutral-500 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              {/* Target info */}
              {compressTargetItem && (
                <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] font-mono flex items-center justify-between">
                  <span className="text-neutral-400">Item a ser compactado:</span>
                  <span className="text-white font-bold">{compressTargetItem.name}</span>
                </div>
              )}

              <div>
                <label className="block text-neutral-400 mb-1 font-mono">Nome do Arquivo Gerado</label>
                <input
                  type="text"
                  value={compressName}
                  onChange={e => setCompressName(e.target.value)}
                  className="w-full bg-black border border-neutral-800 p-2 text-white font-mono rounded focus:border-white outline-none"
                />
              </div>

              {/* Formato e Nível */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1 font-mono">Formato do Arquivo</label>
                  <select
                    value={compressFormat}
                    onChange={e => setCompressFormat(e.target.value as '7z' | 'zip')}
                    className="w-full bg-black border border-neutral-800 p-2 text-white font-mono rounded focus:border-white outline-none"
                  >
                    <option value="7z">7-Zip (.7z - LZMA2 Ultra)</option>
                    <option value="zip">ZIP Padrão (.zip - Deflate)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-mono">Nível de Compressão</label>
                  <select
                    value={compressLevel}
                    onChange={e => setCompressLevel(e.target.value as any)}
                    className="w-full bg-black border border-neutral-800 p-2 text-white font-mono rounded focus:border-white outline-none"
                  >
                    <option value="store">Store (Sem compressão, rápido)</option>
                    <option value="fast">Rápido (Fast)</option>
                    <option value="normal">Normal (Padrão balanceado)</option>
                    <option value="ultra">Ultra (Máxima compressão LZMA2)</option>
                  </select>
                </div>
              </div>

              {/* PAINEL EXPLICATIVO: Qual compactação está sendo feita */}
              <div className="p-3.5 rounded-lg bg-neutral-900/80 border border-neutral-800 space-y-2">
                <div className="flex items-center space-x-1.5 text-emerald-400 font-bold font-mono text-[11px]">
                  <Info className="w-3.5 h-3.5 shrink-0" />
                  <span>Explicação Técnica da Compactação Selecionada:</span>
                </div>

                <div className="text-[11px] text-neutral-300 leading-relaxed font-mono space-y-1.5">
                  {compressFormat === '7z' ? (
                    <p>
                      <strong>Algoritmo LZMA2 (.7z):</strong> Utiliza o compressor Lempel-Ziv-Markov multi-thread. Reduz arquivos em até <strong>70% a 85%</strong> criando um dicionário de blocos de repetição de 32MB a 64MB. Ideal para scripts, documentos e logs.
                    </p>
                  ) : (
                    <p>
                      <strong>Algoritmo Deflate (.zip):</strong> Formato padrão universal RFC 1951. Oferece máxima compatibilidade, abrindo nativamente em qualquer PC, Mac ou celular sem precisar de programas externos.
                    </p>
                  )}

                  <p className="text-neutral-400 text-[10px]">
                    <strong>Nível {compressLevel.toUpperCase()}:</strong> {
                      compressLevel === 'store' ? 'Apenas empacota os arquivos em um único container sem gastar CPU.' :
                      compressLevel === 'fast' ? 'Compressão leve com processamento rápido e baixo consumo térmico.' :
                      compressLevel === 'normal' ? 'Equilíbrio padrão recomendado entre economia de espaço e velocidade.' :
                      'Compressão máxima com varredura profunda de bits; exige mais núcleos de CPU.'
                    }
                  </p>
                </div>
              </div>

              {/* Senha e AES-256 */}
              <div className="pt-2 border-t border-neutral-800 space-y-3">
                <div>
                  <label className="block text-neutral-400 mb-1 font-mono">Senha de Criptografia AES-256</label>
                  <input
                    type="password"
                    value={compressPassword}
                    onChange={e => setCompressPassword(e.target.value)}
                    placeholder="Digite a senha de proteção..."
                    className="w-full bg-black border border-neutral-800 p-2 text-white font-mono rounded focus:border-white outline-none"
                  />
                </div>

                <div className="flex items-start space-x-2 pt-1">
                  <input
                    type="checkbox"
                    id="encrypt-headers-check"
                    checked={encryptHeaders}
                    onChange={e => setEncryptHeaders(e.target.checked)}
                    className="accent-white w-4 h-4 mt-0.5"
                  />
                  <div>
                    <label htmlFor="encrypt-headers-check" className="text-neutral-200 text-xs font-bold cursor-pointer block">
                      Criptografar Cabeçalhos e Nomes de Arquivos (Header Encryption)
                    </label>
                    <span className="text-[10px] text-neutral-400 font-mono block">
                      Oculta a lista de nomes dos arquivos internos. Ninguém consegue nem saber o que tem dentro sem a senha.
                    </span>
                  </div>
                </div>
              </div>

              {/* Progress Bar when compressing */}
              {isCompressing && (
                <div className="space-y-1.5 pt-2 font-mono">
                  <div className="flex justify-between text-[11px] text-neutral-400">
                    <span>Processando dicionário LZMA2 e cifragem AES...</span>
                    <span>{compressProgress}%</span>
                  </div>
                  <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                    <div 
                      className="bg-emerald-400 h-full transition-all duration-200"
                      style={{ width: `${compressProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end space-x-2 pt-3 border-t border-neutral-800">
              <button
                disabled={isCompressing}
                onClick={() => setShowCompressModal(false)}
                className="px-4 py-1.5 border border-neutral-800 text-xs rounded text-neutral-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                disabled={isCompressing}
                onClick={handleStartCompression}
                className="px-4 py-1.5 bg-white text-black font-bold text-xs rounded hover:bg-neutral-200 transition font-mono"
              >
                {isCompressing ? "Processando..." : "Iniciar Compactação"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Renomear Item */}
      {showRenameModal && renameTargetItem && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl w-full max-w-sm p-4 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-neutral-800 pb-2">
              <h3 className="text-sm font-bold text-white">Renomear</h3>
              <button onClick={() => setShowRenameModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-neutral-400 text-xs mb-1 font-mono">Novo Nome:</label>
              <input
                type="text"
                value={renameValue}
                onChange={e => setRenameValue(e.target.value)}
                autoFocus
                className="w-full bg-black border border-neutral-800 p-2 text-xs font-mono text-white rounded focus:border-white outline-none"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2 border-t border-neutral-800">
              <button
                onClick={() => setShowRenameModal(false)}
                className="px-3 py-1.5 border border-neutral-800 text-xs rounded text-neutral-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                onClick={handleRenameSubmit}
                className="px-4 py-1.5 bg-white text-black font-bold text-xs rounded hover:bg-neutral-200"
              >
                Salvar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Nova Pasta */}
      {showNewFolderModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl w-full max-w-sm p-4 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-neutral-800 pb-2">
              <h3 className="text-sm font-bold text-white">Criar Nova Pasta</h3>
              <button onClick={() => setShowNewFolderModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-neutral-400 text-xs mb-1 font-mono">Nome da Pasta</label>
              <input
                type="text"
                value={newFolderName}
                onChange={e => setNewFolderName(e.target.value)}
                placeholder="Ex: Backups_PAT"
                autoFocus
                className="w-full bg-black border border-neutral-800 p-2 text-xs font-mono text-white rounded focus:border-white outline-none"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2 border-t border-neutral-800">
              <button
                onClick={() => setShowNewFolderModal(false)}
                className="px-3 py-1.5 border border-neutral-800 text-xs rounded text-neutral-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateFolder}
                className="px-4 py-1.5 bg-white text-black font-bold text-xs rounded hover:bg-neutral-200"
              >
                Criar Pasta
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Propriedades e Detalhes do Arquivo */}
      {showDetailsModal && detailsItem && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-neutral-800 pb-3">
              <div className="flex items-center space-x-2">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white truncate max-w-xs">{detailsItem.name}</h3>
              </div>
              <button onClick={() => setShowDetailsModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between text-neutral-400 p-2 rounded bg-black">
                <span>Tipo:</span>
                <span className="text-white uppercase">{detailsItem.type === 'folder' ? 'Pasta de Arquivos' : detailsItem.ext || 'Arquivo'}</span>
              </div>
              <div className="flex justify-between text-neutral-400 p-2 rounded bg-black">
                <span>Tamanho:</span>
                <span className="text-white font-bold">{detailsItem.formattedSize}</span>
              </div>
              <div className="flex justify-between text-neutral-400 p-2 rounded bg-black">
                <span>Permissões UNIX:</span>
                <span className="text-emerald-400">{detailsItem.permissions || '-rw-r--r--'}</span>
              </div>
              <div className="flex justify-between text-neutral-400 p-2 rounded bg-black">
                <span>Modificado em:</span>
                <span className="text-white">{detailsItem.modified}</span>
              </div>
              <div className="flex justify-between text-neutral-400 p-2 rounded bg-black">
                <span>Caminho Completo:</span>
                <span className="text-neutral-300 truncate max-w-[200px]">{currentPath}/{detailsItem.name}</span>
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-3 border-t border-neutral-800">
              <button
                onClick={() => {
                  const blob = new Blob([`Conteúdo do arquivo PAT: ${detailsItem.name}`], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = detailsItem.name;
                  a.click();
                  URL.revokeObjectURL(url);
                  showToast(`✓ Download de ${detailsItem.name} iniciado.`);
                }}
                className="px-3 py-1.5 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 flex items-center space-x-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar</span>
              </button>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="px-3 py-1.5 border border-neutral-800 rounded text-xs text-neutral-300 hover:text-white"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
