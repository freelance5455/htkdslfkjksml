import React, { useState } from 'react';
import { MAP_CATALOG, MapInfo } from '../game/map/MapRegistry';
import { CHARACTERS } from '../game/models/CharacterModels';
import { WEAPON_REGISTRY } from '../game/models/WeaponModels';
import {
  MatchSettingsManager,
  MatchConfiguration,
  ZombieMatchSettings,
  PlayerMatchSettings,
} from '../game/settings/MatchSettingsManager';
import { DifficultyLevel } from '../game/difficulty/DifficultyManager';
import { sound } from '../audio/SoundEngine';
import {
  MapPin,
  Trophy,
  ShieldAlert,
  Play,
  X,
  ChevronRight,
  Skull,
  Heart,
  Sliders,
  Crosshair,
} from 'lucide-react';

interface MatchSetupModalProps {
  onStartMatch: (mapId: string, cfg: MatchConfiguration) => void;
  onClose: () => void;
}

type SetupTab = 'map' | 'difficulty' | 'zombies' | 'player' | 'loadout';

export const MatchSetupModal: React.FC<MatchSetupModalProps> = ({ onStartMatch, onClose }) => {
  const [cfg, setCfg] = useState<MatchConfiguration>(() => MatchSettingsManager.get());
  const [tab, setTab] = useState<SetupTab>('map');

  const selectedMap: MapInfo = MAP_CATALOG.find(m => m.id === cfg.mapId) || MAP_CATALOG[0];
  const selectedChar = CHARACTERS.find(c => c.id === cfg.operatorId) || CHARACTERS[0];
  const primaryWep = WEAPON_REGISTRY[cfg.primaryWeaponId] || WEAPON_REGISTRY.rifle;

  const getBestWave = (key: string): number => {
    try {
      const v = localStorage.getItem(key);
      return v ? parseInt(v, 10) : 0;
    } catch {
      return 0;
    }
  };

  const handleSelectMap = (mapId: string) => {
    sound.playUIClick();
    const updated = { ...cfg, mapId };
    setCfg(updated);
    MatchSettingsManager.save(updated);
  };

  const handleDifficultyPreset = (lvl: DifficultyLevel) => {
    sound.playUIClick();
    const zSettings = MatchSettingsManager.applyDifficultyPreset(lvl);
    setCfg(prev => ({
      ...prev,
      difficulty: lvl,
      zombieSettings: zSettings,
    }));
  };

  const updateZombieSetting = <K extends keyof ZombieMatchSettings>(key: K, val: ZombieMatchSettings[K]) => {
    setCfg(prev => {
      const updatedZ = { ...prev.zombieSettings, [key]: val };
      const updated = { ...prev, difficulty: 'custom' as DifficultyLevel, zombieSettings: updatedZ };
      MatchSettingsManager.save(updated);
      return updated;
    });
  };

  const updatePlayerSetting = <K extends keyof PlayerMatchSettings>(key: K, val: PlayerMatchSettings[K]) => {
    setCfg(prev => {
      const updatedP = { ...prev.playerSettings, [key]: val };
      const updated = { ...prev, playerSettings: updatedP };
      MatchSettingsManager.save(updated);
      return updated;
    });
  };

  const handleLaunch = () => {
    sound.playBuySound();
    MatchSettingsManager.save(cfg);
    onStartMatch(cfg.mapId, cfg);
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-5 select-none font-sans">
      <div className="relative w-full max-w-5xl h-[92vh] bg-zinc-950 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header bar with Stepper Tabs */}
        <div className="flex justify-between items-center px-4 sm:px-6 py-3 border-b border-zinc-800 bg-zinc-900/70">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                sound.playUIClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 font-teko text-xl tracking-wider uppercase font-semibold cursor-pointer active:scale-95 transition-all"
            >
              <span className="text-red-500">←</span>
              <span>BACK</span>
            </button>

            <h2 className="text-2xl sm:text-3xl font-teko uppercase text-white font-bold tracking-wider hidden md:block">
              OPERATION <span className="text-red-500">BRIEFING & SETUP</span>
            </h2>

            {/* Stepper Tabs */}
            <div className="flex gap-1 overflow-x-auto py-0.5">
              {[
                { id: 'map', label: '1. THEATER (10)', icon: MapPin },
                { id: 'difficulty', label: '2. DIFFICULTY', icon: Skull },
                { id: 'zombies', label: '3. ZOMBIE SETTINGS', icon: Sliders },
                { id: 'player', label: '4. PLAYER SETTINGS', icon: Heart },
                { id: 'loadout', label: '5. LOADOUT', icon: Crosshair },
              ].map(t => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      sound.playUIClick();
                      setTab(t.id as SetupTab);
                    }}
                    className={`px-3 py-1 rounded-lg font-mono-tech text-xs tracking-wider uppercase flex items-center gap-1.5 cursor-pointer transition-all shrink-0 ${
                      tab === t.id
                        ? 'bg-red-600 text-white shadow-md'
                        : 'bg-zinc-900 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => {
              sound.playUIClick();
              onClose();
            }}
            className="w-9 h-9 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* --- TAB CONTENT BODY --- */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6" style={{ WebkitOverflowScrolling: 'touch' }}>
          {/* --- TAB 1: 10 MAP SELECTION --- */}
          {tab === 'map' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
              {/* Map Cards Column (10 Maps) */}
              <div className="md:col-span-5 flex flex-col gap-2">
                <span className="font-mono-tech text-xs text-zinc-500 uppercase tracking-widest">
                  SELECT FROM 10 CONFLICT THEATERS:
                </span>
                <div className="flex flex-col gap-2 overflow-y-auto max-h-[64vh] pr-1">
                  {MAP_CATALOG.map(m => {
                    const isSelected = selectedMap.id === m.id;
                    const best = getBestWave(m.bestWaveKey);

                    return (
                      <div
                        key={m.id}
                        onClick={() => handleSelectMap(m.id)}
                        className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-zinc-900 border-red-500 shadow-lg shadow-red-500/25'
                            : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'
                        }`}
                      >
                        <div className="flex flex-col">
                          <div className="flex items-center gap-2">
                            <span className="font-mono-tech text-[10px] text-red-400 font-bold">{m.codename}</span>
                            <span
                              className={`text-[9px] font-mono-tech px-1.5 py-0.2 rounded font-bold ${
                                m.difficulty === 'EASY'
                                  ? 'bg-emerald-950 text-emerald-400'
                                  : m.difficulty === 'MEDIUM'
                                  ? 'bg-amber-950 text-amber-400'
                                  : m.difficulty === 'HARD'
                                  ? 'bg-orange-950 text-orange-400'
                                  : 'bg-red-950 text-red-400'
                              }`}
                            >
                              {m.difficulty}
                            </span>
                          </div>

                          <h4 className="font-teko text-2xl text-white font-bold leading-tight mt-0.5">
                            {m.name}
                          </h4>

                          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-zinc-400 mt-0.5">
                            <span className="flex items-center gap-0.5 text-amber-400">
                              <Trophy className="w-3 h-3" />
                              BEST: W{best > 0 ? best : '--'}
                            </span>
                            <span>•</span>
                            <span className="text-zinc-400 uppercase">{m.defaultTime}</span>
                          </div>
                        </div>

                        <ChevronRight className={`w-5 h-5 ${isSelected ? 'text-red-500' : 'text-zinc-600'}`} />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Selected Map Dossier & Detailed Preview (Right) */}
              <div className="md:col-span-7 bg-zinc-900/60 rounded-2xl border border-zinc-800 p-5 flex flex-col justify-between">
                <div>
                  {/* Map Visual Preview Card */}
                  <div
                    className={`w-full h-44 rounded-xl border border-zinc-700/80 bg-gradient-to-br ${selectedMap.previewGradient} flex flex-col justify-between p-4 shadow-inner relative overflow-hidden mb-4`}
                  >
                    <div className="flex justify-between items-start z-10">
                      <span className="font-mono-tech text-xs bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-red-400 border border-red-500/40 font-bold">
                        {selectedMap.codename}
                      </span>
                      <div className="flex gap-1 flex-wrap">
                        {selectedMap.tags.map(t => (
                          <span
                            key={t}
                            className="font-mono-tech text-[9px] bg-black/60 px-2 py-0.5 rounded text-zinc-300 border border-zinc-700 font-bold"
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="z-10">
                      <span className="font-mono-tech text-xs text-zinc-300 uppercase">
                        DEFAULT LIGHTING: {selectedMap.defaultTime.toUpperCase()}
                      </span>
                      <h3 className="text-4xl font-teko font-extrabold text-white leading-none mt-0.5">
                        {selectedMap.name}
                      </h3>
                    </div>

                    {/* Architectural Map Layout Blueprint Graphics (Requirement 4) */}
                    <div className="absolute inset-0 flex items-center justify-end pr-4 pointer-events-none opacity-40">
                      <svg width="220" height="140" viewBox="0 0 220 140" fill="none" xmlns="http://www.w3.org/2000/svg">
                        {selectedMap.id === 'suburban' && (
                          <g stroke="#f97316" strokeWidth="1.5">
                            {/* Main Road & Crossroad */}
                            <line x1="110" y1="10" x2="110" y2="130" stroke="#fbbf24" strokeDasharray="4 3" />
                            <line x1="20" y1="70" x2="200" y2="70" stroke="#fbbf24" strokeDasharray="4 3" />
                            {/* House A */}
                            <rect x="40" y="25" width="45" height="35" rx="2" fill="#ef4444" fillOpacity="0.2" />
                            {/* 2-Story Command Post */}
                            <rect x="135" y="25" width="50" height="40" rx="2" fill="#3b82f6" fillOpacity="0.25" />
                            <rect x="145" y="60" width="30" height="10" rx="1" fill="#60a5fa" fillOpacity="0.4" />
                            {/* House B */}
                            <rect x="135" y="85" width="45" height="35" rx="2" fill="#ef4444" fillOpacity="0.2" />
                            {/* Depot */}
                            <rect x="40" y="85" width="50" height="40" rx="2" fill="#64748b" fillOpacity="0.3" />
                            {/* Swimming Pool */}
                            <rect x="45" y="10" width="30" height="12" rx="3" fill="#0284c7" fillOpacity="0.6" stroke="#38bdf8" />
                          </g>
                        )}
                        {selectedMap.id === 'military' && (
                          <g stroke="#38bdf8" strokeWidth="1.5">
                            <rect x="30" y="20" width="160" height="100" strokeDasharray="4 2" />
                            {/* Watchtower */}
                            <circle cx="110" cy="50" r="12" fill="#38bdf8" fillOpacity="0.3" />
                            {/* Bunkers */}
                            <rect x="45" y="35" width="40" height="30" fill="#64748b" fillOpacity="0.4" />
                            <rect x="135" y="35" width="40" height="30" fill="#64748b" fillOpacity="0.4" />
                            {/* Hangar */}
                            <rect x="75" y="85" width="70" height="35" rx="4" fill="#475569" fillOpacity="0.35" />
                            {/* Reservoir */}
                            <rect x="45" y="85" width="22" height="18" rx="2" fill="#0284c7" fillOpacity="0.5" />
                          </g>
                        )}
                        {selectedMap.id === 'forest' && (
                          <g stroke="#10b981" strokeWidth="1.5">
                            {/* Pine clusters */}
                            <circle cx="40" cy="35" r="14" fill="#065f46" fillOpacity="0.4" />
                            <circle cx="170" cy="35" r="16" fill="#065f46" fillOpacity="0.4" />
                            <circle cx="45" cy="105" r="15" fill="#065f46" fillOpacity="0.4" />
                            <circle cx="165" cy="105" r="15" fill="#065f46" fillOpacity="0.4" />
                            {/* Modular Lab Delta */}
                            <polygon points="90,45 130,45 130,75 145,75 145,95 90,95" fill="#10b981" fillOpacity="0.3" />
                            {/* Forest Pond */}
                            <ellipse cx="140" cy="110" rx="22" ry="14" fill="#0284c7" fillOpacity="0.6" stroke="#38bdf8" />
                          </g>
                        )}
                        {selectedMap.id === 'industrial' && (
                          <g stroke="#f59e0b" strokeWidth="1.5">
                            {/* Smelter Foundry */}
                            <rect x="70" y="25" width="80" height="40" fill="#78350f" fillOpacity="0.35" />
                            <circle cx="85" cy="35" r="6" fill="#f59e0b" />
                            {/* Container Maze */}
                            <rect x="40" y="80" width="28" height="12" fill="#b91c1c" fillOpacity="0.5" />
                            <rect x="75" y="80" width="28" height="12" fill="#1d4ed8" fillOpacity="0.5" />
                            <rect x="110" y="80" width="28" height="12" fill="#047857" fillOpacity="0.5" />
                            <rect x="145" y="80" width="28" height="12" fill="#d97706" fillOpacity="0.5" />
                            {/* Canal */}
                            <rect x="30" y="105" width="160" height="16" fill="#0284c7" fillOpacity="0.5" stroke="#38bdf8" />
                          </g>
                        )}
                        {selectedMap.id === 'night_city' && (
                          <g stroke="#a855f7" strokeWidth="1.5">
                            {/* Avenue */}
                            <line x1="110" y1="15" x2="110" y2="125" stroke="#c084fc" strokeDasharray="3 3" />
                            {/* Storefronts */}
                            <rect x="45" y="30" width="45" height="35" fill="#581c87" fillOpacity="0.4" />
                            <rect x="130" y="30" width="45" height="35" fill="#581c87" fillOpacity="0.4" />
                            {/* Metro Canopy */}
                            <polygon points="95,85 125,85 135,115 85,115" fill="#7e22ce" fillOpacity="0.5" />
                            {/* Storm Canal */}
                            <rect x="40" y="110" width="40" height="16" fill="#0284c7" fillOpacity="0.5" stroke="#38bdf8" />
                          </g>
                        )}
                        {selectedMap.id === 'hospital' && (
                          <g stroke="#06b6d4" strokeWidth="1.5">
                            {/* St. Jude Triage Wing */}
                            <rect x="40" y="35" width="50" height="40" fill="#0f766e" fillOpacity="0.3" />
                            {/* ICU Wing */}
                            <rect x="130" y="35" width="50" height="40" fill="#0f766e" fillOpacity="0.3" />
                            {/* Corridors */}
                            <rect x="90" y="45" width="40" height="20" fill="#14b8a6" fillOpacity="0.35" />
                            {/* Rooftop Helipad with H */}
                            <circle cx="110" cy="55" r="16" stroke="#facc15" strokeWidth="1" />
                            <text x="105" y="60" fill="#facc15" fontSize="14" fontWeight="bold">H</text>
                            {/* Therapy Pool */}
                            <rect x="45" y="90" width="30" height="18" rx="3" fill="#0284c7" fillOpacity="0.6" stroke="#38bdf8" />
                          </g>
                        )}
                        {selectedMap.id === 'desert_outpost' && (
                          <g stroke="#eab308" strokeWidth="1.5">
                            {/* Desert Perimeter */}
                            <rect x="35" y="25" width="150" height="90" strokeDasharray="3 3" />
                            {/* Barracks */}
                            <rect x="45" y="35" width="45" height="30" fill="#854d0e" fillOpacity="0.4" />
                            <rect x="130" y="35" width="45" height="30" fill="#854d0e" fillOpacity="0.4" />
                            {/* Observation Tower */}
                            <polygon points="110,40 120,55 100,55" fill="#ca8a04" fillOpacity="0.5" />
                            {/* Bunker Ramp */}
                            <polygon points="95,85 125,85 120,115 100,115" fill="#44403c" fillOpacity="0.5" />
                            {/* Oasis Basin */}
                            <ellipse cx="150" cy="95" rx="18" ry="12" fill="#0284c7" fillOpacity="0.6" stroke="#38bdf8" />
                          </g>
                        )}
                        {selectedMap.id === 'flooded_suburb' && (
                          <g stroke="#0ea5e9" strokeWidth="1.5">
                            {/* Flooded Water Base */}
                            <rect x="25" y="15" width="170" height="110" fill="#0369a1" fillOpacity="0.3" />
                            {/* Boardwalks */}
                            <line x1="110" y1="15" x2="110" y2="125" stroke="#fde047" strokeWidth="3" />
                            <line x1="25" y1="70" x2="195" y2="70" stroke="#fde047" strokeWidth="3" />
                            {/* Houses on stilts */}
                            <rect x="45" y="30" width="40" height="30" fill="#b45309" fillOpacity="0.4" />
                            <rect x="135" y="30" width="40" height="30" fill="#b45309" fillOpacity="0.4" />
                            <rect x="45" y="80" width="40" height="30" fill="#b45309" fillOpacity="0.4" />
                            <rect x="135" y="80" width="40" height="30" fill="#b45309" fillOpacity="0.4" />
                          </g>
                        )}
                        {selectedMap.id === 'factory' && (
                          <g stroke="#64748b" strokeWidth="1.5">
                            {/* Factory Floor */}
                            <rect x="45" y="25" width="130" height="45" fill="#334155" fillOpacity="0.35" />
                            {/* Twin Conveyors */}
                            <line x1="65" y1="35" x2="65" y2="60" stroke="#f59e0b" strokeWidth="3" />
                            <line x1="155" y1="35" x2="155" y2="60" stroke="#f59e0b" strokeWidth="3" />
                            {/* Catwalk at 4.5m */}
                            <rect x="60" y="80" width="100" height="14" fill="#94a3b8" fillOpacity="0.4" />
                            {/* Cooling Vat */}
                            <rect x="135" y="105" width="28" height="16" rx="2" fill="#0284c7" fillOpacity="0.6" stroke="#38bdf8" />
                          </g>
                        )}
                        {selectedMap.id === 'research_facility' && (
                          <g stroke="#22c55e" strokeWidth="1.5">
                            {/* Cryo Labs */}
                            <rect x="60" y="25" width="100" height="50" rx="3" fill="#14532d" fillOpacity="0.35" />
                            {/* Generator Pods */}
                            <rect x="40" y="90" width="22" height="18" fill="#0369a1" fillOpacity="0.5" />
                            <rect x="158" y="90" width="22" height="18" fill="#0369a1" fillOpacity="0.5" />
                            {/* Security Kiosk */}
                            <rect x="98" y="95" width="24" height="18" fill="#1e293b" fillOpacity="0.5" />
                            {/* Runoff Basin */}
                            <rect x="50" y="115" width="30" height="12" rx="2" fill="#0284c7" fillOpacity="0.6" stroke="#38bdf8" />
                          </g>
                        )}
                      </svg>
                    </div>
                  </div>

                  {/* Description Box */}
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 mb-3">
                    <span className="text-amber-400 font-mono-tech text-xs uppercase font-bold block mb-1">
                      OPERATIONAL INTEL:
                    </span>
                    <p className="text-zinc-300 text-xs font-mono-tech leading-relaxed">
                      {selectedMap.description}
                    </p>
                  </div>

                  {/* Water Feature & Terrain */}
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex flex-col gap-1 text-xs font-mono-tech">
                    <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>WATER FEATURE (REQUIREMENT 30):</span>
                    </div>
                    <span className="text-zinc-300 pl-5">{selectedMap.waterFeature}</span>

                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold mt-1">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>TERRAIN & INTERIORS:</span>
                    </div>
                    <span className="text-zinc-300 pl-5">{selectedMap.environment}</span>
                  </div>
                </div>

                <div className="flex justify-between items-center mt-4">
                  <span className="font-mono-tech text-xs text-zinc-400">
                    CLICK NEXT TO CONFIGURE DIFFICULTY & ZOMBIES
                  </span>
                  <button
                    onClick={() => {
                      sound.playUIClick();
                      setTab('difficulty');
                    }}
                    className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-lg shadow-red-600/30 cursor-pointer"
                  >
                    <span>NEXT: DIFFICULTY</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* --- TAB 2: DIFFICULTY PRESETS --- */}
          {tab === 'difficulty' && (
            <div className="max-w-3xl mx-auto flex flex-col gap-4">
              <div>
                <span className="font-mono-tech text-xs text-zinc-400 uppercase tracking-wider block mb-2 font-bold">
                  CHOOSE DIFFICULTY PRESET:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {(['easy', 'normal', 'hard', 'custom'] as DifficultyLevel[]).map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => handleDifficultyPreset(lvl)}
                      className={`p-4 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                        cfg.difficulty === lvl
                          ? 'bg-red-600 border-red-400 text-white shadow-xl shadow-red-600/30 scale-105'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <Skull className="w-6 h-6 mb-1" />
                      <span className="font-teko text-3xl font-bold uppercase leading-none">{lvl}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Difficulty Summary Box */}
              <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 font-mono-tech text-xs text-zinc-300">
                {cfg.difficulty === 'easy' && (
                  <div>
                    <span className="text-emerald-400 font-bold block mb-1">EASY MODE:</span>
                    Classic slow shambling zombies with 70% health, 65% damage, and slower attack cooldown. Ideal for casual wave survival.
                  </div>
                )}
                {cfg.difficulty === 'normal' && (
                  <div>
                    <span className="text-amber-400 font-bold block mb-1">NORMAL MODE (BALANCED):</span>
                    Standard tactical horde pressure, 100% health & damage, standard attack frequency, and progressive wave difficulty.
                  </div>
                )}
                {cfg.difficulty === 'hard' && (
                  <div>
                    <span className="text-red-400 font-bold block mb-1">HARD MODE (TACTICAL):</span>
                    Aggressive flanking AI, 135% health, 130% damage, fast spawn pressure. (Note: zombies remain realistically paced and never turn into uncontrollable sprinters).
                  </div>
                )}
                {cfg.difficulty === 'custom' && (
                  <div>
                    <span className="text-cyan-400 font-bold block mb-1">CUSTOM MODE:</span>
                    Full manual control over health, damage, speed, intelligence, and spawn limits. Configure in the next tab!
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center mt-4">
                <button
                  onClick={() => setTab('map')}
                  className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-teko text-xl tracking-wider uppercase font-bold border border-zinc-700 cursor-pointer"
                >
                  ← BACK TO THEATERS
                </button>
                <button
                  onClick={() => setTab('zombies')}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-lg shadow-red-600/30 cursor-pointer"
                >
                  <span>NEXT: ZOMBIE SETTINGS</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* --- TAB 3: ZOMBIE SETTINGS MANAGER (Requirement 11) --- */}
          {tab === 'zombies' && (
            <div className="max-w-3xl mx-auto flex flex-col gap-4">
              <span className="font-mono-tech text-xs text-zinc-400 uppercase tracking-wider font-bold">
                ZOMBIE HORDE CONFIGURATION:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Health Multiplier */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>ZOMBIE HEALTH MULTIPLIER</span>
                    <span className="text-red-400 font-bold">{Math.round(cfg.zombieSettings.healthMultiplier * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.5"
                    step="0.1"
                    value={cfg.zombieSettings.healthMultiplier}
                    onChange={e => updateZombieSetting('healthMultiplier', parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>

                {/* Damage Multiplier */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>ZOMBIE ATTACK DAMAGE</span>
                    <span className="text-red-400 font-bold">{Math.round(cfg.zombieSettings.damageMultiplier * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.5"
                    step="0.1"
                    value={cfg.zombieSettings.damageMultiplier}
                    onChange={e => updateZombieSetting('damageMultiplier', parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>

                {/* Speed Multiplier (Requirement 3: Kept realistic, 0.8x to 1.2x) */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>ZOMBIE SPEED (REALISTIC CONTROLLED)</span>
                    <span className="text-red-400 font-bold">{Math.round(cfg.zombieSettings.speedMultiplier * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.2"
                    step="0.05"
                    value={cfg.zombieSettings.speedMultiplier}
                    onChange={e => updateZombieSetting('speedMultiplier', parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>

                {/* Zombies Per Wave / Max Limit */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>MAX SIMULTANEOUS ZOMBIES</span>
                    <span className="text-red-400 font-bold">{cfg.zombieSettings.zombiesPerWave}</span>
                  </div>
                  <input
                    type="range"
                    min="12"
                    max="36"
                    step="2"
                    value={cfg.zombieSettings.zombiesPerWave}
                    onChange={e => updateZombieSetting('zombiesPerWave', parseInt(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                  <span className="font-mono-tech text-xs text-zinc-300">SPECIAL ZOMBIES (BRUTES & RUNNERS)</span>
                  <button
                    onClick={() => updateZombieSetting('specialZombies', !cfg.zombieSettings.specialZombies)}
                    className={`px-3 py-1 rounded font-mono-tech text-xs ${
                      cfg.zombieSettings.specialZombies ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {cfg.zombieSettings.specialZombies ? 'ENABLED' : 'DISABLED'}
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                  <span className="font-mono-tech text-xs text-zinc-300">PROGRESSIVE WAVE DIFFICULTY</span>
                  <button
                    onClick={() => updateZombieSetting('progressiveScaling', !cfg.zombieSettings.progressiveScaling)}
                    className={`px-3 py-1 rounded font-mono-tech text-xs ${
                      cfg.zombieSettings.progressiveScaling ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {cfg.zombieSettings.progressiveScaling ? 'ENABLED' : 'STATIC'}
                  </button>
                </div>
              </div>

              <div className="flex justify-between items-center mt-4">
                <button
                  onClick={() => setTab('difficulty')}
                  className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-teko text-xl tracking-wider uppercase font-bold border border-zinc-700 cursor-pointer"
                >
                  ← BACK
                </button>
                <button
                  onClick={() => setTab('player')}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-lg shadow-red-600/30 cursor-pointer"
                >
                  <span>NEXT: PLAYER SETTINGS</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* --- TAB 4: PLAYER SETTINGS MANAGER (Requirement 12) --- */}
          {tab === 'player' && (
            <div className="max-w-3xl mx-auto flex flex-col gap-4">
              <span className="font-mono-tech text-xs text-zinc-400 uppercase tracking-wider font-bold">
                OPERATOR CAPABILITIES & CONTROLS:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Player Health (Default 250 HP) */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>PLAYER BASE HEALTH (DEFAULT: 250 HP)</span>
                    <span className="text-emerald-400 font-bold">{cfg.playerSettings.health} HP</span>
                  </div>
                  <input
                    type="range"
                    min="150"
                    max="500"
                    step="25"
                    value={cfg.playerSettings.health}
                    onChange={e => updatePlayerSetting('health', parseInt(e.target.value))}
                    className="accent-emerald-500 cursor-pointer"
                  />
                </div>

                {/* Starting Armor */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>STARTING ARMOR PLATING</span>
                    <span className="text-cyan-400 font-bold">{cfg.playerSettings.armor} AP</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="150"
                    step="10"
                    value={cfg.playerSettings.armor}
                    onChange={e => updatePlayerSetting('armor', parseInt(e.target.value))}
                    className="accent-cyan-500 cursor-pointer"
                  />
                </div>

                {/* Movement Speed */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>MOVEMENT SPEED MULTIPLIER</span>
                    <span className="text-red-400 font-bold">{Math.round(cfg.playerSettings.movementSpeedMultiplier * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.3"
                    step="0.05"
                    value={cfg.playerSettings.movementSpeedMultiplier}
                    onChange={e => updatePlayerSetting('movementSpeedMultiplier', parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>

                {/* Camera Sensitivity */}
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col gap-1">
                  <div className="flex justify-between font-mono-tech text-xs text-zinc-300">
                    <span>CAMERA LOOK SENSITIVITY</span>
                    <span className="text-red-400 font-bold">{cfg.playerSettings.sensitivity.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="3.0"
                    step="0.1"
                    value={cfg.playerSettings.sensitivity}
                    onChange={e => updatePlayerSetting('sensitivity', parseFloat(e.target.value))}
                    className="accent-red-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Toggles: Auto Sprint & Slide */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="font-mono-tech text-xs text-zinc-200">AUTO SPRINT (MOBILE)</span>
                    <span className="font-mono-tech text-[10px] text-zinc-400">Pushing stick forward sprints automatically</span>
                  </div>
                  <button
                    onClick={() => updatePlayerSetting('autoSprint', !cfg.playerSettings.autoSprint)}
                    className={`px-3 py-1 rounded font-mono-tech text-xs ${
                      cfg.playerSettings.autoSprint ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {cfg.playerSettings.autoSprint ? 'ON' : 'OFF'}
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="font-mono-tech text-xs text-zinc-200">TACTICAL SLIDE MECHANIC</span>
                    <span className="font-mono-tech text-[10px] text-zinc-400">Sprint + Crouch executes forward slide</span>
                  </div>
                  <button
                    onClick={() => updatePlayerSetting('slideMechanic', !cfg.playerSettings.slideMechanic)}
                    className={`px-3 py-1 rounded font-mono-tech text-xs ${
                      cfg.playerSettings.slideMechanic ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {cfg.playerSettings.slideMechanic ? 'ENABLED' : 'DISABLED'}
                  </button>
                </div>
              </div>

              <div className="flex justify-between items-center mt-4">
                <button
                  onClick={() => setTab('zombies')}
                  className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-teko text-xl tracking-wider uppercase font-bold border border-zinc-700 cursor-pointer"
                >
                  ← BACK
                </button>
                <button
                  onClick={() => setTab('loadout')}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-teko text-xl tracking-wider uppercase font-bold flex items-center gap-1.5 shadow-lg shadow-red-600/30 cursor-pointer"
                >
                  <span>NEXT: LOADOUT</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* --- TAB 5: QUICK LOADOUT & OPERATOR CONFIRM --- */}
          {tab === 'loadout' && (
            <div className="max-w-3xl mx-auto flex flex-col gap-4">
              <span className="font-mono-tech text-xs text-zinc-400 uppercase tracking-wider font-bold">
                OPERATOR & STARTING WEAPON:
              </span>

              {/* Operator Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {CHARACTERS.map(c => {
                  const isSel = cfg.operatorId === c.id;
                  return (
                    <div
                      key={c.id}
                      onClick={() => {
                        sound.playUIClick();
                        setCfg(prev => {
                          const updated = { ...prev, operatorId: c.id };
                          MatchSettingsManager.save(updated);
                          return updated;
                        });
                      }}
                      className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col items-center text-center ${
                        isSel ? 'bg-zinc-900 border-red-500 shadow-lg' : 'bg-zinc-900/40 border-zinc-800'
                      }`}
                    >
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center font-teko text-2xl font-bold text-white mb-1.5 shadow-inner"
                        style={{ backgroundColor: c.color }}
                      >
                        {c.name[0]}
                      </div>
                      <span className="font-teko text-xl text-white font-bold">{c.name}</span>
                      <span className="font-mono-tech text-[10px] text-zinc-400">{c.role}</span>
                    </div>
                  );
                })}
              </div>

              {/* Starting Weapons */}
              <span className="font-mono-tech text-xs text-zinc-400 uppercase tracking-wider font-bold mt-2">
                STARTING PRIMARY FIREARM:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {['rifle', 'ar2', 'shotgun', 'smg', 'smg2', 'sniper', 'dmr', 'lmg'].map(wid => {
                  const wep = WEAPON_REGISTRY[wid];
                  const isSel = cfg.primaryWeaponId === wid;
                  return (
                    <div
                      key={wid}
                      onClick={() => {
                        sound.playUIClick();
                        setCfg(prev => {
                          const updated = { ...prev, primaryWeaponId: wid };
                          MatchSettingsManager.save(updated);
                          return updated;
                        });
                      }}
                      className={`p-3 rounded-xl border cursor-pointer transition-all ${
                        isSel ? 'bg-zinc-900 border-red-500 shadow-md' : 'bg-zinc-900/40 border-zinc-800'
                      }`}
                    >
                      <span className="font-teko text-lg text-white font-bold leading-none">{wep.name}</span>
                      <div className="flex justify-between font-mono-tech text-[10px] text-zinc-400 mt-1">
                        <span>DMG: {wep.damage}</span>
                        <span>MAG: {wep.magSize}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Launch Briefing Box */}
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-800/80 flex items-center justify-between mt-2">
                <div>
                  <span className="font-teko text-2xl text-white font-bold">READY FOR MISSION INSERTION</span>
                  <div className="font-mono-tech text-xs text-zinc-300">
                    THEATER: <span className="text-red-400 font-bold">{selectedMap.name}</span> • OPERATOR: <span className="text-cyan-400 font-bold">{selectedChar.name}</span> • WEAPON: <span className="text-amber-400 font-bold">{primaryWep.name}</span>
                  </div>
                </div>

                <button
                  onClick={handleLaunch}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-3xl tracking-widest uppercase font-bold flex items-center gap-2 shadow-2xl shadow-red-600/50 cursor-pointer active:scale-95 transition-all"
                >
                  <Play className="w-6 h-6 fill-white" />
                  <span>START MATCH</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
