import React, { useRef, useState } from 'react';
import { VideoItem } from '../types/video';
import { VideoCard } from './VideoCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Top10RowProps {
  title: string;
  videos: VideoItem[];
}

export const Top10Row: React.FC<Top10RowProps> = ({ title, videos }) => {
  const rowRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const uniqueVideos = Array.from(new Map(videos.map((v) => [v.id, v])).values());
  const top10 = uniqueVideos.slice(0, 10);
  if (top10.length === 0) return null;

  const handleScroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollAmount = clientWidth * 0.7;
      const targetScroll = direction === 'left' ? scrollLeft - scrollAmount : scrollLeft + scrollAmount;
      rowRef.current.scrollTo({ left: targetScroll, behavior: 'smooth' });
    }
  };

  const checkScrollLimits = () => {
    if (rowRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = rowRef.current;
      setCanScrollLeft(scrollLeft > 10);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  return (
    <div className="relative group/top10 my-8 sm:my-10 px-4 sm:px-6 lg:px-8">
      {/* Header with Top 10 Badge */}
      <div className="flex items-center space-x-2 mb-3">
        <span className="bg-[#E50914] text-white text-xs font-black px-1.5 py-0.5 rounded-xs tracking-wider">
          TOP 10
        </span>
        <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-white tracking-wide">
          {title}
        </h3>
      </div>

      {/* Row Carousel with stylized numbers */}
      <div className="relative">
        {canScrollLeft && (
          <button
            onClick={() => handleScroll('left')}
            className="absolute left-0 top-0 bottom-0 z-30 w-10 sm:w-12 bg-black/70 hover:bg-black/90 text-white flex items-center justify-center opacity-0 group-hover/top10:opacity-100 transition-all rounded-r backdrop-blur-xs cursor-pointer"
          >
            <ChevronLeft className="w-6 h-6 sm:w-8 sm:h-8" />
          </button>
        )}

        <div
          ref={rowRef}
          onScroll={checkScrollLimits}
          className="flex items-center space-x-6 sm:space-x-8 overflow-x-auto no-scrollbar scroll-smooth py-4 -my-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {top10.map((video, idx) => {
            const rank = idx + 1;
            return (
              <div key={`${video.id}-top-${rank}`} className="relative flex-none flex items-center">
                {/* Giant Stylized Rank Number SVG / Text */}
                <div
                  className="font-black text-7xl sm:text-8xl md:text-9xl text-zinc-800 select-none -mr-4 sm:-mr-6 z-0 tracking-tighter"
                  style={{
                    WebkitTextStroke: '3px #595959',
                    fontFamily: 'impact, "Plus Jakarta Sans", sans-serif',
                  }}
                >
                  {rank}
                </div>

                {/* Video Card */}
                <div className="relative z-10">
                  <VideoCard video={video} rank={rank} />
                </div>
              </div>
            );
          })}
        </div>

        {canScrollRight && (
          <button
            onClick={() => handleScroll('right')}
            className="absolute right-0 top-0 bottom-0 z-30 w-10 sm:w-12 bg-black/70 hover:bg-black/90 text-white flex items-center justify-center opacity-0 group-hover/top10:opacity-100 transition-all rounded-l backdrop-blur-xs cursor-pointer"
          >
            <ChevronRight className="w-6 h-6 sm:w-8 sm:h-8" />
          </button>
        )}
      </div>
    </div>
  );
};
