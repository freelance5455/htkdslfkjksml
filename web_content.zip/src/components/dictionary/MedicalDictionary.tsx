import React, { useState, useMemo } from 'react';
import { ALL_MEDICAL_TERMS, MEDICAL_CATEGORIES } from '../../data/medicalTerms';
import { MedicalTerm, Language } from '../../types';
import { soundManager } from '../../utils/audio';
import { speakText } from '../../utils/speech';
import { 
  Search, 
  Volume2, 
  Bookmark, 
  BookmarkCheck, 
  AlertCircle, 
  Sparkles, 
  Layers, 
  Filter, 
  BookOpen,
  Check
} from 'lucide-react';

interface Props {
  language: Language;
  soundEnabled: boolean;
  favorites: string[];
  difficultWords: string[];
  onToggleFavorite: (id: string) => void;
  onToggleDifficult: (id: string) => void;
}

export const MedicalDictionary: React.FC<Props> = ({
  language,
  soundEnabled,
  favorites,
  difficultWords,
  onToggleFavorite,
  onToggleDifficult
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeFilterTab, setActiveFilterTab] = useState<'all' | 'favorites' | 'difficult'>('all');
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [speakingTermId, setSpeakingTermId] = useState<string | null>(null);

  // Filter terms based on query, category, and tabs
  const filteredTerms = useMemo(() => {
    let result = ALL_MEDICAL_TERMS;

    // Filter tab
    if (activeFilterTab === 'favorites') {
      result = result.filter((t) => favorites.includes(t.id));
    } else if (activeFilterTab === 'difficult') {
      result = result.filter((t) => difficultWords.includes(t.id));
    }

    // Category
    if (selectedCategory !== 'all') {
      result = result.filter((t) => t.category === selectedCategory);
    }

    // Search query in French, Arabic, or English
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter((t) => {
        return (
          t.termFr.toLowerCase().includes(q) ||
          t.termAr.toLowerCase().includes(q) ||
          t.termEn.toLowerCase().includes(q) ||
          t.definitionFr.toLowerCase().includes(q) ||
          t.definitionAr.toLowerCase().includes(q) ||
          (t.acronym && t.acronym.toLowerCase().includes(q))
        );
      });
    }

    return result;
  }, [searchQuery, selectedCategory, activeFilterTab, favorites, difficultWords]);

  const handlePronounce = async (term: MedicalTerm, lang: 'fr' | 'ar' | 'en' = 'fr') => {
    soundManager.playTick(soundEnabled);
    setSpeakingTermId(term.id);
    const textToSpeak = lang === 'fr' ? term.termFr : lang === 'ar' ? term.termAr : term.termEn;
    const res = await speakText(textToSpeak, lang);

    setSpeakingTermId(null);
    if (!res.success && res.message) {
      setSpeechError(`${term.termFr}: ${res.message}`);
      setTimeout(() => setSpeechError(null), 4000);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Search Header Banner */}
      <div className="relative bg-gradient-to-r from-purple-950/80 via-slate-950 to-indigo-950/80 p-5 rounded-2xl border border-purple-500/30 shadow-neon-purple">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-xl md:text-2xl font-black text-slate-100 flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-purple-400" />
              <span>قاموس المصطلحات الطبية والأشعة (Trilingual Lexicon)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              أكثر من 1000 مصطلح طبي وشعاعي بالفرنسية والعربية والإنجليزية مع النطق الصوتي وأمثلة الاستعمال.
            </p>
          </div>

          {/* Quick Filter Tabs (All / Favorites / Difficult) */}
          <div className="flex items-center gap-1.5 bg-black/60 p-1 rounded-xl border border-purple-900/40 text-xs">
            <button
              onClick={() => { setActiveFilterTab('all'); soundManager.playTick(soundEnabled); }}
              className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                activeFilterTab === 'all'
                  ? 'bg-purple-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              الكل ({ALL_MEDICAL_TERMS.length})
            </button>
            <button
              onClick={() => { setActiveFilterTab('favorites'); soundManager.playTick(soundEnabled); }}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg font-bold transition-colors ${
                activeFilterTab === 'favorites'
                  ? 'bg-purple-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>المفضلة ({favorites.length})</span>
            </button>
            <button
              onClick={() => { setActiveFilterTab('difficult'); soundManager.playTick(soundEnabled); }}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg font-bold transition-colors ${
                activeFilterTab === 'difficult'
                  ? 'bg-rose-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5" />
              <span>للمراجعة ({difficultWords.length})</span>
            </button>
          </div>
        </div>

        {/* Search Input Bar */}
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-purple-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بالفرنسية، العربية، الإنجليزية أو بالاختصارات (مثال: TDM, IRM, Thorax, مريلة)..."
            className="w-full pr-12 pl-4 py-3 bg-black/60 text-slate-100 placeholder-slate-500 rounded-xl border border-purple-500/40 focus:outline-none focus:border-purple-400 shadow-inner text-sm"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white bg-slate-800 px-2 py-0.5 rounded-md"
            >
              مسح
            </button>
          )}
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pt-3 pb-1 no-scrollbar text-xs">
          {MEDICAL_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => { setSelectedCategory(cat.id); soundManager.playTick(soundEnabled); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-purple-600 text-white shadow-neon-purple'
                  : 'bg-slate-900/80 text-slate-300 hover:bg-slate-800 border border-purple-900/30'
              }`}
            >
              <span>{language === 'ar' ? cat.nameAr : cat.nameFr}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Speech Error Feedback Banner if any */}
      {speechError && (
        <div className="flex items-center gap-2 p-3 bg-amber-950/70 border border-amber-600/50 rounded-xl text-amber-200 text-xs animate-shake">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{speechError}</span>
        </div>
      )}

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>عرض {filteredTerms.length} من أصل {ALL_MEDICAL_TERMS.length} مصطلحاً</span>
        {activeFilterTab !== 'all' && (
          <span className="text-purple-400 font-semibold">
            {activeFilterTab === 'favorites' ? 'عرض الكلمات المحفوظة' : 'عرض الكلمات الصعبة'}
          </span>
        )}
      </div>

      {/* Terms Grid */}
      {filteredTerms.length === 0 ? (
        <div className="text-center py-16 bg-slate-950/60 rounded-2xl border border-purple-900/30">
          <Sparkles className="w-10 h-10 text-purple-500 mx-auto mb-2 opacity-50" />
          <p className="text-slate-300 font-bold">لم يتم العثور على أي مصطلح يطابق بحثك</p>
          <p className="text-xs text-slate-500 mt-1">جرب البحث بكلمات أخرى أو اختر «جميع المصطلحات»</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredTerms.map((term) => {
            const isFav = favorites.includes(term.id);
            const isDiff = difficultWords.includes(term.id);
            const isSpeaking = speakingTermId === term.id;

            return (
              <div
                key={term.id}
                className="flex flex-col justify-between bg-slate-950/80 hover:bg-slate-900/90 rounded-2xl p-4 border border-purple-900/40 hover:border-purple-500/60 transition-all duration-200 shadow-lg text-right"
              >
                <div>
                  {/* Top Bar with Term Headings & Action Buttons */}
                  <div className="flex items-start justify-between gap-2 border-b border-purple-900/30 pb-2.5 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-extrabold text-purple-300 font-tech">
                          {term.termFr}
                        </h3>
                        <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800/60 px-2 py-0.5 rounded-full font-mono">
                          {term.category.toUpperCase().replace('_', ' ')}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-100 mt-0.5">
                        {term.termAr}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-mono">
                        EN: {term.termEn}
                      </p>
                    </div>

                    {/* Action Buttons: Audio, Favorite, Difficult */}
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {/* Audio Pronunciation */}
                      <button
                        onClick={() => handlePronounce(term, 'fr')}
                        disabled={isSpeaking}
                        title="نطق المصطلح بالفرنسية"
                        className={`p-2 rounded-xl border transition-all ${
                          isSpeaking
                            ? 'bg-purple-600 text-white border-purple-400'
                            : 'bg-slate-900 text-purple-300 hover:text-white hover:bg-purple-900/50 border-purple-800/40'
                        }`}
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>

                      {/* Favorite Bookmark */}
                      <button
                        onClick={() => {
                          onToggleFavorite(term.id);
                          soundManager.playTick(soundEnabled);
                        }}
                        title={isFav ? 'إزالة من المفضلة' : 'حفظ في المفضلة'}
                        className={`p-2 rounded-xl border transition-all ${
                          isFav
                            ? 'bg-amber-600/30 text-amber-300 border-amber-500/60'
                            : 'bg-slate-900 text-slate-400 hover:text-amber-300 border-purple-800/40'
                        }`}
                      >
                        {isFav ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                      </button>

                      {/* Difficult Review Marker */}
                      <button
                        onClick={() => {
                          onToggleDifficult(term.id);
                          soundManager.playTick(soundEnabled);
                        }}
                        title={isDiff ? 'تمت المراجعة بنجاح' : 'تمييز ككلمة صعبة للمراجعة'}
                        className={`p-2 rounded-xl border transition-all ${
                          isDiff
                            ? 'bg-rose-900/40 text-rose-300 border-rose-500/60'
                            : 'bg-slate-900 text-slate-400 hover:text-rose-300 border-purple-800/40'
                        }`}
                      >
                        <AlertCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Definitions */}
                  <div className="space-y-1.5 text-xs text-slate-300 leading-relaxed mb-3">
                    <p className="text-slate-200">
                      <span className="font-bold text-purple-400">التعريف: </span>
                      {term.definitionAr}
                    </p>
                    <p className="text-slate-400 italic text-[11px]">
                      🇫🇷 {term.definitionFr}
                    </p>
                  </div>

                  {/* Clinical Example */}
                  <div className="bg-purple-950/30 border border-purple-900/40 rounded-xl p-2.5 mb-2.5 text-xs">
                    <div className="font-bold text-purple-300 text-[11px] mb-1">
                      مثال في الممارسة الطبية:
                    </div>
                    <p className="text-slate-200 font-mono text-[11px] leading-relaxed">
                      {term.exampleAr}
                    </p>
                    <p className="text-slate-400 font-mono text-[10px] mt-0.5">
                      {term.exampleFr}
                    </p>
                  </div>
                </div>

                {/* Practical Clinical Tip if available */}
                {term.clinicalTip && (
                  <div className="text-[11px] text-emerald-400 bg-emerald-950/20 border border-emerald-900/40 rounded-xl p-2 mt-1">
                    <span className="font-bold">💡 نصيحة ميدانية لطلبة الأشعة: </span>
                    {term.clinicalTip}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
