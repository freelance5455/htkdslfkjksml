import { useRef, useState } from "react";
import { cn } from "../utils/cn";
import { pingColor, type Subscription } from "../data/subscriptions";
import { CheckIcon, CopyIcon } from "./icons";

function RuFlag({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 30 20" className={className}>
      <defs>
        <clipPath id="ru-clip">
          <rect width="30" height="20" rx="5" />
        </clipPath>
      </defs>
      <g clipPath="url(#ru-clip)">
        <rect width="30" height="6.7" fill="#F4F6FB" />
        <rect y="6.7" width="30" height="6.7" fill="#2A4CBB" />
        <rect y="13.3" width="30" height="6.7" fill="#D5313B" />
      </g>
      <rect x="0.5" y="0.5" width="29" height="19" rx="4.6" fill="none" stroke="rgba(255,255,255,0.5)" />
    </svg>
  );
}

function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onToggle}
      className={cn(
        "relative h-[26px] w-[46px] shrink-0 cursor-pointer rounded-full transition-all duration-300 active:scale-95",
        on
          ? "bg-gradient-to-r from-[#00D4FF] to-[#8B5CF6] shadow-[0_0_16px_rgba(0,212,255,0.5)]"
          : "bg-white/10 ring-1 ring-inset ring-white/15"
      )}
    >
      <span
        className={cn(
          "absolute top-[3px] h-5 w-5 rounded-full transition-all duration-300",
          on ? "left-[23px] bg-white shadow-[0_1px_4px_rgba(0,0,0,0.4)]" : "left-[3px] bg-white/70"
        )}
      />
    </button>
  );
}

type Props = {
  sub: Subscription;
  enabled: boolean;
  ping: number;
  onToggle: (id: string) => void;
  onToast: (msg: string) => void;
};

export function SubscriptionCard({ sub, enabled, ping, onToggle, onToast }: Props) {
  const [copied, setCopied] = useState(false);
  const copyTimer = useRef<number | null>(null);
  const color = pingColor(ping);

  const copy = async () => {
    let ok = true;
    try {
      await navigator.clipboard.writeText(sub.url);
    } catch {
      try {
        const ta = document.createElement("textarea");
        ta.value = sub.url;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
      } catch {
        ok = false;
      }
    }
    if (!ok) {
      onToast("Clipboard is blocked by the browser");
      return;
    }
    setCopied(true);
    if (copyTimer.current) window.clearTimeout(copyTimer.current);
    copyTimer.current = window.setTimeout(() => setCopied(false), 1600);
    onToast("Source URL copied to clipboard");
  };

  return (
    <div
      className="group relative rounded-[20px] p-px transition-all duration-300 hover:-translate-y-0.5"
      style={{
        background: enabled
          ? `linear-gradient(135deg, ${sub.accent}99, rgba(148,163,184,0.26) 42%, ${sub.accent}40)`
          : "linear-gradient(135deg, rgba(148,163,184,0.32), rgba(148,163,184,0.09) 45%, rgba(148,163,184,0.22))",
        boxShadow: enabled
          ? `0 10px 34px -12px ${sub.accent}70, 0 2px 10px -4px rgba(0,0,0,0.55)`
          : "0 8px 26px -14px rgba(2,4,18,0.95)",
      }}
    >
      <div className="relative overflow-hidden rounded-[19px] bg-[#0B1132]/90 px-3.5 pb-3 pt-3.5 backdrop-blur-xl">
        {/* per-card accent wash */}
        <div
          className="pointer-events-none absolute -right-10 -top-14 h-32 w-44 opacity-25 blur-2xl transition-opacity duration-500 group-hover:opacity-45"
          style={{ background: `radial-gradient(closest-side, ${sub.from}, transparent)` }}
        />

        <div className="relative flex items-start gap-3">
          {/* icon tile */}
          <div
            className="flex h-[46px] w-[46px] shrink-0 items-center justify-center rounded-[14px] ring-1 ring-inset ring-white/25"
            style={{
              background: `linear-gradient(135deg, ${sub.from}, ${sub.to})`,
              boxShadow: `0 6px 18px -6px ${sub.accent}99, inset 0 1px 0 rgba(255,255,255,0.35)`,
            }}
          >
            {sub.isFlag ? (
              <RuFlag className="h-[22px] w-[33px] drop-shadow" />
            ) : (
              <span className="text-[22px] leading-none drop-shadow-sm">{sub.icon}</span>
            )}
          </div>

          {/* name + badges */}
          <div className="min-w-0 flex-1 pt-0.5">
            <div className="flex items-center gap-1.5">
              <h3 className="truncate font-display text-[13.5px] font-semibold tracking-tight text-slate-50">
                {sub.name}
              </h3>
              {sub.beta && (
                <span className="shrink-0 rounded-md border border-amber-300/30 bg-amber-300/10 px-1.5 py-px font-mono text-[8px] font-medium tracking-wider text-amber-300">
                  beta
                </span>
              )}
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-1">
              {sub.badges.map((b) => (
                <span
                  key={b}
                  className="rounded-full border px-1.5 py-px font-mono text-[8.5px] font-medium leading-[1.4]"
                  style={{ color: sub.accent, borderColor: `${sub.accent}55`, background: `${sub.accent}14` }}
                >
                  {b}
                </span>
              ))}
            </div>
          </div>

          {/* ping + toggle */}
          <div className="flex shrink-0 flex-col items-end gap-2 pt-1">
            <div className="flex items-center gap-1.5">
              <span className="relative flex h-1.5 w-1.5">
                {enabled && (
                  <span
                    className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-70"
                    style={{ background: color, animationDuration: "1.6s" }}
                  />
                )}
                <span
                  className="relative inline-flex h-1.5 w-1.5 rounded-full"
                  style={{ background: enabled ? color : "#5B6584" }}
                />
              </span>
              <span className="font-mono text-[9px] tabular-nums" style={{ color: enabled ? color : "#5B6584" }}>
                {ping} ms
              </span>
            </div>
            <Toggle on={enabled} onToggle={() => onToggle(sub.id)} />
          </div>
        </div>

        {/* source URL */}
        <div className="relative mt-2.5 flex items-center gap-2 rounded-[10px] border border-white/[0.06] bg-black/30 py-1.5 pl-2.5 pr-1.5">
          <span className="h-1 w-1 shrink-0 rounded-full" style={{ background: sub.accent }} />
          <span className="min-w-0 flex-1 truncate font-mono text-[9.5px] leading-none text-[#00D4FF]" title={sub.url}>
            {sub.url}
          </span>
          <button
            type="button"
            onClick={copy}
            title="Copy source URL"
            className="ml-1 flex h-6 w-6 shrink-0 cursor-pointer items-center justify-center rounded-md text-slate-400 transition hover:bg-white/10 hover:text-[#00D4FF] active:scale-90"
          >
            {copied ? <CheckIcon className="h-3.5 w-3.5 text-emerald-400" /> : <CopyIcon className="h-3.5 w-3.5" />}
          </button>
        </div>
      </div>
    </div>
  );
}
