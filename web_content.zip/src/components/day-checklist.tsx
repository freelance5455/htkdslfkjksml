import { useState } from "react";
import { Droplets, Moon } from "lucide-react";
import { toast } from "sonner";
import { CheckItem } from "@/components/check-item";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { FOOD_ITEMS, SKIN_CARE_ITEMS, SLEEP_QUICK, WATER_QUICK } from "@/lib/defaults";
import {
  formatLongDate,
  getDayChecks,
  getDayStatus,
  parseDateKey,
  projectDayNumber,
} from "@/lib/dates";
import { useAppStore } from "@/lib/store";
import { formatHours } from "@/lib/utils";
import { Textarea } from "@/components/ui/textarea";

export function DayChecklist({ date }: { date: string }) {
  const settings = useAppStore((s) => s.settings);
  const log = useAppStore((s) => s.logs[date]);
  const toggleSkinCare = useAppStore((s) => s.toggleSkinCare);
  const addWater = useAppStore((s) => s.addWater);
  const setWater = useAppStore((s) => s.setWater);
  const setSleep = useAppStore((s) => s.setSleep);
  const toggleFood = useAppStore((s) => s.toggleFood);
  const togglePostureHabit = useAppStore((s) => s.togglePostureHabit);
  const toggleWorkoutHabit = useAppStore((s) => s.toggleWorkoutHabit);
  const toggleExtraHabit = useAppStore((s) => s.toggleExtraHabit);
  const setDayNotes = useAppStore((s) => s.setDayNotes);
  const [customMl, setCustomMl] = useState("");

  const checks = getDayChecks(log, settings);
  const status = getDayStatus(log, settings);
  const water = log?.waterMl ?? 0;
  const waterPct = Math.min(100, Math.round((water / settings.waterGoalMl) * 100));
  const sleep = log?.sleepHours ?? null;
  const sleepPct =
    sleep == null
      ? 0
      : Math.min(100, Math.round((sleep / settings.sleepGoalHours) * 100));
  const dayNum = projectDayNumber(parseDateKey(date));

  function ping(ok: boolean, label: string) {
    if (ok) toast.success(`${label} concluído`);
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
          {dayNum > 0 ? `Dia ${String(dayNum).padStart(2, "0")}` : "Fora do ciclo"}
        </p>
        <h2 className="font-display text-xl font-semibold">
          {formatLongDate(date)}
        </h2>
      </div>

      {status === "complete" ? (
        <Card className="border-success/40 bg-success/8 p-4">
          <p className="font-display text-sm font-semibold text-success">
            Dia concluído
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Tudo marcado. Amanhã é só repetir o padrão.
          </p>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Treino</CardTitle>
        </CardHeader>
        <CardContent className="pt-3">
          <CheckItem
            checked={Boolean(log?.workout)}
            label="Treino do dia"
            onToggle={() => {
              const next = !log?.workout;
              toggleWorkoutHabit(date);
              ping(next, "Treino");
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Postura</CardTitle>
        </CardHeader>
        <CardContent className="pt-3">
          <CheckItem
            checked={Boolean(log?.posture)}
            label="Rotina de postura"
            onToggle={() => {
              const next = !log?.posture;
              togglePostureHabit(date);
              ping(next, "Postura");
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Skin care</CardTitle>
        </CardHeader>
        <CardContent className="space-y-0.5 pt-3">
          {SKIN_CARE_ITEMS.map((item) => (
            <CheckItem
              key={item.key}
              checked={Boolean(log?.skinCare[item.key])}
              label={item.label}
              onToggle={() => {
                const next = !log?.skinCare[item.key];
                toggleSkinCare(date, item.key);
                ping(next, item.label);
              }}
            />
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplets className="size-4 text-primary" /> Hidratação
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-3">
          <div className="flex items-end justify-between">
            <p className="font-mono text-2xl font-semibold tabular-nums">
              {water}{" "}
              <span className="text-sm font-normal text-muted-foreground">
                / {settings.waterGoalMl} ml
              </span>
            </p>
            {checks.water ? (
              <span className="text-xs font-medium text-success">
                Meta de água concluída
              </span>
            ) : null}
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-300"
              style={{ width: `${waterPct}%` }}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {WATER_QUICK.map((ml) => (
              <Button
                key={ml}
                size="sm"
                variant="secondary"
                onClick={() => {
                  addWater(date, ml);
                  const next = water + ml;
                  if (water < settings.waterGoalMl && next >= settings.waterGoalMl) {
                    toast.success("Meta de água concluída");
                  }
                }}
              >
                +{ml} ml
              </Button>
            ))}
            <Button
              size="sm"
              variant="ghost"
              onClick={() => addWater(date, -250)}
            >
              −250
            </Button>
          </div>
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              const n = Number(customMl);
              if (!Number.isFinite(n) || n <= 0) return;
              addWater(date, n);
              setCustomMl("");
            }}
          >
            <Input
              inputMode="numeric"
              placeholder="Quantidade (ml)"
              value={customMl}
              onChange={(e) => setCustomMl(e.target.value)}
            />
            <Button type="submit" variant="outline">
              Somar
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setWater(date, 0)}
            >
              Zerar
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Moon className="size-4 text-primary" /> Sono
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-3">
          <p className="font-mono text-2xl font-semibold tabular-nums">
            {formatHours(sleep)}{" "}
            <span className="text-sm font-normal text-muted-foreground">
              / {formatHours(settings.sleepGoalHours)}
            </span>
          </p>
          <div className="h-2 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-300"
              style={{ width: `${sleepPct}%` }}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {SLEEP_QUICK.map((h) => (
              <Button
                key={h}
                size="sm"
                variant={sleep === h ? "default" : "secondary"}
                onClick={() => {
                  setSleep(date, h);
                  if (h >= settings.sleepGoalHours) {
                    toast.success("Meta de sono concluída");
                  }
                }}
              >
                {formatHours(h)}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Alimentação</CardTitle>
        </CardHeader>
        <CardContent className="space-y-0.5 pt-3">
          {FOOD_ITEMS.map((item) => (
            <CheckItem
              key={item.key}
              checked={Boolean(log?.food[item.key])}
              label={item.label}
              onToggle={() => {
                const next = !log?.food[item.key];
                toggleFood(date, item.key);
                ping(next, "Alimentação");
              }}
            />
          ))}
        </CardContent>
      </Card>

      {settings.extraHabits.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Hábitos extras</CardTitle>
          </CardHeader>
          <CardContent className="space-y-0.5 pt-3">
            {settings.extraHabits.map((h) => (
              <CheckItem
                key={h.id}
                checked={Boolean(log?.extraHabits[h.id])}
                label={h.name}
                onToggle={() => {
                  const next = !log?.extraHabits[h.id];
                  toggleExtraHabit(date, h.id);
                  ping(next, h.name);
                }}
              />
            ))}
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Observações</CardTitle>
        </CardHeader>
        <CardContent className="pt-3">
          <Textarea
            value={log?.notes ?? ""}
            onChange={(e) => setDayNotes(date, e.target.value)}
            placeholder="Como foi o dia — curto e direto."
          />
        </CardContent>
      </Card>
    </div>
  );
}
