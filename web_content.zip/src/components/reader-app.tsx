import { useEffect, useState } from "react";
import { BookOpen, Clapperboard, Library, MessagesSquare, UserRound } from "lucide-react";
import { Toaster } from "sonner";
import { UserButton } from "@/lib/auth/gates";
import { loadMe, type Me } from "@/lib/library-api";
import { errorText } from "@/components/bits";
import { LibraryPanel } from "@/components/library-panel";
import { ShortsPanel } from "@/components/shorts-panel";
import { ChatPanel } from "@/components/chat-panel";
import { ProfilePanel } from "@/components/profile-panel";

const TABS = [
  { id: "library", label: "Library", icon: Library },
  { id: "shorts", label: "Shorts", icon: Clapperboard },
  { id: "chat", label: "Chat", icon: MessagesSquare },
  { id: "profile", label: "Profile", icon: UserRound },
] as const;

type TabId = (typeof TABS)[number]["id"];

export function BootScreen() {
  return (
    <div className="min-h-screen bg-paper">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
          <span className="grid size-10 place-items-center rounded-xl bg-primary text-primary-fg">
            <BookOpen className="size-5" />
          </span>
          <span className="font-display text-xl">Good Health Reader</span>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="h-8 w-40 animate-pulse rounded-lg bg-paper-deep motion-reduce:animate-none" />
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((item) => (
            <div key={item} className="h-72 animate-pulse rounded-2xl bg-paper-deep motion-reduce:animate-none" />
          ))}
        </div>
      </main>
    </div>
  );
}

export function ReaderApp() {
  const [tab, setTab] = useState<TabId>("library");
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    loadMe()
      .then((next) => {
        if (!cancelled) setMe(next);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(errorText(err));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (error) {
    return (
      <main className="grid min-h-screen place-items-center px-6 text-center">
        <div>
          <h1 className="font-display text-3xl">The shelf did not open</h1>
          <p className="mt-2 text-sm text-muted">{error}</p>
        </div>
      </main>
    );
  }

  if (!me) return <BootScreen />;

  return (
    <div className="min-h-screen bg-paper pb-24 md:pb-10">
      <header className="sticky top-0 z-30 border-b border-line bg-surface">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
          <button type="button" className="flex min-w-0 items-center gap-2" onClick={() => setTab("library")}>
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-fg">
              <BookOpen className="size-5" />
            </span>
            <span className="truncate font-display text-lg sm:text-xl">Good Health Reader</span>
          </button>
          <nav className="mx-auto hidden items-center gap-1 md:flex">
            {TABS.map((item) => (
              <TabButton key={item.id} item={item} active={tab === item.id} onSelect={setTab} />
            ))}
          </nav>
          <div className="user-slot ml-auto shrink-0">
            <UserButton />
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">
        {tab === "library" && <LibraryPanel onChange={() => void loadMe().then(setMe)} />}
        {tab === "shorts" && <ShortsPanel onChange={() => void loadMe().then(setMe)} />}
        {tab === "chat" && <ChatPanel myPublicId={me.publicId} />}
        {tab === "profile" && <ProfilePanel me={me} onChange={setMe} />}
      </main>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden">
        <div className="grid grid-cols-4">
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-semibold ${
                tab === item.id ? "text-primary" : "text-muted"
              }`}
            >
              <item.icon className="size-5" />
              {item.label}
            </button>
          ))}
        </div>
      </nav>
      <Toaster position="top-center" />
    </div>
  );
}

function TabButton({
  item,
  active,
  onSelect,
}: {
  item: (typeof TABS)[number];
  active: boolean;
  onSelect: (id: TabId) => void;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={() => onSelect(item.id)}
      className={`inline-flex h-10 items-center gap-2 rounded-full px-3 text-sm font-semibold ${
        active ? "bg-primary text-primary-fg" : "text-muted hover:bg-paper"
      }`}
    >
      <Icon className="size-4" />
      {item.label}
    </button>
  );
}
