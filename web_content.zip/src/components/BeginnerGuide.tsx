import React from 'react';
import {
  BookOpen,
  CheckCircle,
  HelpCircle,
  Terminal,
  Smartphone,
  FolderOpen,
  Volume2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

export const BeginnerGuide: React.FC = () => {
  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto">
      {/* Welcome Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 flex flex-col gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">
              शुरुआती गाइड: एंड्रॉइड स्टूडियो में प्रोजेक्ट कैसे चलाएं (Beginner's Guide)
            </h3>
            <p className="text-xs text-slate-400">
              कोटलिन (Kotlin) और जेटपैक कंपोज़ (Jetpack Compose) में मूल ऐप बनाने के लिए आसान चरण
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          यदि आप एंड्रॉइड डेवलपमेंट में नए हैं, तो चिंता न करें! यह गाइड आपको अपने कंप्यूटर पर एंड्रॉइड स्टूडियो इंस्टॉल करने से लेकर अपने असली फ़ोन पर ऐप चलाने तक हर कदम समझाएगी।
        </p>
      </div>

      {/* Step by Step Guide */}
      <div className="flex flex-col gap-4">
        {/* Step 1 */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-orange-500 text-white font-bold text-sm flex items-center justify-center shrink-0">
              1
            </span>
            <h4 className="text-sm font-bold text-white">
              एंड्रॉइड स्टूडियो (Android Studio) डाउनलोड और इंस्टॉल करें
            </h4>
          </div>

          <div className="pl-10 text-xs text-slate-300 space-y-2 leading-relaxed">
            <p>
              आधिकारिक वेबसाइट (
              <a
                href="https://developer.android.com/studio"
                target="_blank"
                rel="noreferrer"
                className="text-orange-400 underline"
              >
                developer.android.com/studio
              </a>
              ) से नवीनतम <strong>Android Studio (Iguana या Jellyfish)</strong> डाउनलोड करें।
            </p>
            <p className="text-slate-400 text-[11px]">
              स्थापना के दौरान "Android SDK" और "Android Virtual Device" को चेक रहने दें। JDK 17/21 स्वचालित रूप से शामिल होता है।
            </p>
          </div>
        </div>

        {/* Step 2 */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-orange-500 text-white font-bold text-sm flex items-center justify-center shrink-0">
              2
            </span>
            <h4 className="text-sm font-bold text-white">
              प्रोजेक्ट .ZIP फ़ाइल निकालें (Extract) और खोलें
            </h4>
          </div>

          <div className="pl-10 text-xs text-slate-300 space-y-2 leading-relaxed">
            <p>
              ऊपर दिए गए <strong className="text-orange-400">"प्रोजेक्ट डाउनलोड (.ZIP)"</strong> बटन पर क्लिक करके <code className="bg-slate-950 px-1.5 py-0.5 rounded text-orange-300">HindiVideoTranslator.zip</code> डाउनलोड करें।
            </p>
            <p>
              फ़ाइल को अनज़िप करें। एंड्रॉइड स्टूडियो खोलें और <strong className="text-white">"Open"</strong> चुनें, फिर निकाले गए <code className="bg-slate-950 px-1.5 py-0.5 rounded text-orange-300">HindiVideoTranslator</code> फ़ोल्डर को चुनें।
            </p>
            <p className="text-slate-400 text-[11px]">
              Gradle पहली बार स्वचालित रूप से आवश्यक लाइब्रेरी (Media3 ExoPlayer और Compose) डाउनलोड करेगा।
            </p>
          </div>
        </div>

        {/* Step 3 */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-orange-500 text-white font-bold text-sm flex items-center justify-center shrink-0">
              3
            </span>
            <h4 className="text-sm font-bold text-white">
              अपने फ़ोन में हिंदी आवाज़ (TTS Voice Pack) चालू करें
            </h4>
          </div>

          <div className="pl-10 text-xs text-slate-300 space-y-2 leading-relaxed">
            <p>
              यह कदम बहुत महत्वपूर्ण है ताकि <strong>हिंदी डब ऑडियो</strong> बिना इंटरनेट के पूरी तरह से साफ़ और प्राकृतिक सुनाई दे:
            </p>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-xs">
              <li>अपने फ़ोन या एमुलेटर की <strong>सेटिंग्स (Settings)</strong> खोलें।</li>
              <li>
                <strong>सिस्टम (System)</strong> → <strong>भाषा और इनपुट (Languages & input)</strong> (या एक्सेसिबिलिटी) पर जाएं।
              </li>
              <li>
                <strong>टेक्स्ट-टू-स्पीच आउटपुट (Text-to-speech output)</strong> पर टैप करें।
              </li>
              <li>
                <strong>Speech Recognition and Synthesis from Google</strong> के बगल में सेटिंग गियर पर टैप करें।
              </li>
              <li>
                <strong>आवाज़ डेटा इंस्टॉल करें (Install voice data)</strong> चुनें → <strong>हिंदी (भारत)</strong> खोजें और डाउनलोड (Download) पर क्लिक करें (~15-20 MB)।
              </li>
            </ol>
            <p className="text-emerald-400 font-semibold text-[11px]">
              ✓ अब आपका फ़ोन बिना किसी बाहरी सर्वर या शुल्क के किसी भी हिंदी टेक्स्ट को बोल सकता है!
            </p>
          </div>
        </div>

        {/* Step 4 */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-lg bg-orange-500 text-white font-bold text-sm flex items-center justify-center shrink-0">
              4
            </span>
            <h4 className="text-sm font-bold text-white">
              ऐप चलाएं और स्थानीय वीडियो का परीक्षण करें (Run & Test)
            </h4>
          </div>

          <div className="pl-10 text-xs text-slate-300 space-y-2 leading-relaxed">
            <p>
              एंड्रॉइड स्टूडियो में ऊपर हरे रंग का <strong className="text-emerald-400">Run ▶️</strong> बटन दबाएं।
            </p>
            <p>
              ऐप खुलने के बाद:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-300 text-xs">
              <li>
                <strong className="text-blue-400">"वीडियो चुनें"</strong> दबाकर अपनी गैलरी से कोई भी वीडियो (.mp4, .mkv) चुनें।
              </li>
              <li>
                <strong className="text-yellow-400">"हिंदी उपशीर्षक"</strong> दबाकर स्क्रीन पर पीले रंग के देवनागरी सबटाइटल्स देखें।
              </li>
              <li>
                <strong className="text-emerald-400">"हिंदी डब ऑडियो"</strong> दबाकर देखें कि कैसे वीडियो का मूल ऑडियो धीमा होता है और फ़ोन हिंदी में बोलता है।
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Troubleshooting FAQ */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-3">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-orange-400" />
          <span>अक्सर पूछे जाने वाले सवाल और समाधान (Troubleshooting FAQ)</span>
        </h4>

        <div className="space-y-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <strong className="text-white block mb-1">
              प्र: क्या वीडियो अनुवाद के लिए इंटरनेट या क्रेडिट कार्ड की आवश्यकता है?
            </strong>
            <p className="text-slate-400">
              उत्तर: बिल्कुल नहीं! स्थानीय वीडियो प्लेबैक, सबटाइटल सिंकिंग, और Android TextToSpeech 100% ऑफ़लाइन और मुफ़्त काम करते हैं। क्लाउड अनुवाद (Gemini) भी मुफ़्त टियर में उपलब्ध है।
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <strong className="text-white block mb-1">
              प्र: Android 13/14 पर वीडियो चयन में अनुमति त्रुटि क्यों आ सकती है?
            </strong>
            <p className="text-slate-400">
              उत्तर: Android 13+ में <code className="text-orange-300">READ_MEDIA_VIDEO</code> अनुमति आवश्यक है। हमने यह अनुमति आपके <code className="text-orange-300">AndroidManifest.xml</code> में पहले से जोड़ दी है।
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
            <strong className="text-white block mb-1">
              प्र: डबिंग के दौरान आवाज़ अंग्रेज़ी या रोबोटिक क्यों लग रही है?
            </strong>
            <p className="text-slate-400">
              उत्तर: इसका मतलब है कि डिवाइस में Google Hindi Voice Pack अभी डाउनलोड नहीं हुआ है और सिस्टम डिफ़ॉल्ट इंग्लिश आवाज़ पर वापस आ गया है। चरण 3 के अनुसार सेटिंग्स में जाकर हिंदी वॉइस पैक डाउनलोड करें।
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
