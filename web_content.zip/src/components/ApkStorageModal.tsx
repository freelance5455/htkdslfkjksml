import React, { useState, useEffect } from 'react';
import {
  CheckCircle,
  Download,
  Package,
  X,
  Copy,
  Check,
  AlertCircle,
  Loader2,
  Smartphone,
  ExternalLink,
  UploadCloud,
  LogOut,
  FolderDown,
  ShieldCheck,
  FileArchive,
  Link as LinkIcon,
} from 'lucide-react';
import {
  downloadApkBlob,
  getFullApkDownloadUrl,
  downloadZipBlob,
  getFullZipDownloadUrl,
} from '../utils/downloadHelper';
import {
  initAuth,
  logoutGoogle,
  uploadApkToGoogleDrive,
  uploadZipToGoogleDrive,
} from '../utils/googleDrive';
import { User } from 'firebase/auth';

interface ApkStorageModalProps {
  onClose: () => void;
}

export const ApkStorageModal: React.FC<ApkStorageModalProps> = ({ onClose }) => {
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'apk' | 'zip' | 'drive'>('all');
  const [copiedApkLink, setCopiedApkLink] = useState(false);
  const [copiedZipLink, setCopiedZipLink] = useState(false);
  const [copiedDriveLink, setCopiedDriveLink] = useState(false);
  const [copiedDirectDriveLink, setCopiedDirectDriveLink] = useState(false);
  const [copiedZipDriveLink, setCopiedZipDriveLink] = useState(false);

  // APK download state
  const [isDownloadingApk, setIsDownloadingApk] = useState(false);
  const [apkDownloadProgress, setApkDownloadProgress] = useState<string | null>(null);
  const [apkDownloadSuccess, setApkDownloadSuccess] = useState(false);
  const [apkDownloadError, setApkDownloadError] = useState<string | null>(null);

  // ZIP download state
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [zipDownloadProgress, setZipDownloadProgress] = useState<string | null>(null);
  const [zipDownloadSuccess, setZipDownloadSuccess] = useState(false);
  const [zipDownloadError, setZipDownloadError] = useState<string | null>(null);

  // Google Drive APK state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isUploadingToDrive, setIsUploadingToDrive] = useState(false);
  const [driveProgressPercent, setDriveProgressPercent] = useState<number>(0);
  const [driveProgressText, setDriveProgressText] = useState<string>('');
  const [driveResultUrl, setDriveResultUrl] = useState<string | null>(null);
  const [driveDirectDownloadUrl, setDriveDirectDownloadUrl] = useState<string | null>(null);
  const [driveError, setDriveError] = useState<string | null>(null);

  // Google Drive ZIP state
  const [isUploadingZipToDrive, setIsUploadingZipToDrive] = useState(false);
  const [driveZipProgressPercent, setDriveZipProgressPercent] = useState<number>(0);
  const [driveZipProgressText, setDriveZipProgressText] = useState<string>('');
  const [driveZipResultUrl, setDriveZipResultUrl] = useState<string | null>(null);
  const [driveZipDirectDownloadUrl, setDriveZipDirectDownloadUrl] = useState<string | null>(null);
  const [driveZipError, setDriveZipError] = useState<string | null>(null);

  const directApkUrl = getFullApkDownloadUrl();
  const directZipUrl = getFullZipDownloadUrl();

  useEffect(() => {
    // Subscribe to Google Auth
    const unsubscribe = initAuth(
      (user) => {
        setCurrentUser(user);
      },
      () => {
        setCurrentUser(null);
      }
    );

    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    };
  }, []);

  // Direct APK Blob Download (Strict 7.09 MB package validation, no webviews)
  const handleDownloadApk = async () => {
    setIsDownloadingApk(true);
    setApkDownloadError(null);
    setApkDownloadProgress('Fetching 7.09 MB verified binary package...');

    try {
      const result = await downloadApkBlob((msg) => setApkDownloadProgress(msg));
      if (!result.success) {
        throw new Error(result.error || 'Download failed');
      }

      setIsDownloadingApk(false);
      setApkDownloadProgress(null);
      setApkDownloadSuccess(true);
      setTimeout(() => setApkDownloadSuccess(false), 9000);
    } catch (err: any) {
      console.warn('In-browser blob download error:', err);
      setIsDownloadingApk(false);
      setApkDownloadProgress(null);
      setApkDownloadError(err?.message || 'Download failed. Please try again.');
    }
  };

  // Direct ZIP Blob Download (no webviews)
  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    setZipDownloadError(null);
    setZipDownloadProgress('Connecting to Project ZIP server...');

    try {
      const result = await downloadZipBlob((msg) => setZipDownloadProgress(msg));
      if (!result.success) {
        throw new Error(result.error || 'ZIP download failed');
      }

      setIsDownloadingZip(false);
      setZipDownloadProgress(null);
      setZipDownloadSuccess(true);
      setTimeout(() => setZipDownloadSuccess(false), 9000);
    } catch (err: any) {
      console.warn('ZIP download error:', err);
      setIsDownloadingZip(false);
      setZipDownloadProgress(null);
      setZipDownloadError(err?.message || 'ZIP download failed.');
    }
  };

  // Upload APK directly to user's Google Drive
  const handleUploadToDrive = async () => {
    setIsUploadingToDrive(true);
    setDriveError(null);
    setDriveResultUrl(null);
    setDriveDirectDownloadUrl(null);
    setDriveProgressPercent(5);
    setDriveProgressText('Google Drive ke sath connect kiya ja raha hai...');

    try {
      const result = await uploadApkToGoogleDrive((percent, text) => {
        setDriveProgressPercent(percent);
        setDriveProgressText(text);
      });

      if (!result.success || !result.webViewLink) {
        throw new Error(result.error || 'Google Drive upload asafal raha.');
      }

      setDriveProgressPercent(100);
      setDriveProgressText('Aapke Google Drive me safalta se save ho gaya!');
      setDriveResultUrl(result.webViewLink);
      if (result.directDownloadLink) {
        setDriveDirectDownloadUrl(result.directDownloadLink);
      }
    } catch (err: any) {
      console.error('Drive upload failed:', err);
      setDriveError(err?.message || 'Google Drive upload me truti aayi. Kripya dobara try karein.');
    } finally {
      setIsUploadingToDrive(false);
    }
  };

  // Upload ZIP directly to user's Google Drive
  const handleUploadZipToDrive = async () => {
    setIsUploadingZipToDrive(true);
    setDriveZipError(null);
    setDriveZipResultUrl(null);
    setDriveZipDirectDownloadUrl(null);
    setDriveZipProgressPercent(5);
    setDriveZipProgressText('Google Drive ke sath connect kiya ja raha hai...');

    try {
      const result = await uploadZipToGoogleDrive((percent, text) => {
        setDriveZipProgressPercent(percent);
        setDriveZipProgressText(text);
      });

      if (!result.success || !result.webViewLink) {
        throw new Error(result.error || 'Google Drive ZIP upload asafal raha.');
      }

      setDriveZipProgressPercent(100);
      setDriveZipProgressText('Project ZIP aapke Google Drive me save ho gaya!');
      setDriveZipResultUrl(result.webViewLink);
      if (result.directDownloadLink) {
        setDriveZipDirectDownloadUrl(result.directDownloadLink);
      }
    } catch (err: any) {
      console.error('Drive ZIP upload failed:', err);
      setDriveZipError(err?.message || 'Google Drive ZIP upload me truti aayi.');
    } finally {
      setIsUploadingZipToDrive(false);
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await logoutGoogle();
      setCurrentUser(null);
      setDriveResultUrl(null);
      setDriveDirectDownloadUrl(null);
      setDriveZipResultUrl(null);
    } catch (e) {
      console.error('Logout error:', e);
    }
  };

  const handleCopyApkLink = () => {
    navigator.clipboard.writeText(directApkUrl).then(() => {
      setCopiedApkLink(true);
      setTimeout(() => setCopiedApkLink(false), 3000);
    });
  };

  const handleCopyZipLink = () => {
    navigator.clipboard.writeText(directZipUrl).then(() => {
      setCopiedZipLink(true);
      setTimeout(() => setCopiedZipLink(false), 3000);
    });
  };

  const handleCopyDriveLink = () => {
    if (!driveResultUrl) return;
    navigator.clipboard.writeText(driveResultUrl).then(() => {
      setCopiedDriveLink(true);
      setTimeout(() => setCopiedDriveLink(false), 3000);
    });
  };

  const handleCopyDirectDriveLink = () => {
    if (!driveDirectDownloadUrl) return;
    navigator.clipboard.writeText(driveDirectDownloadUrl).then(() => {
      setCopiedDirectDriveLink(true);
      setTimeout(() => setCopiedDirectDriveLink(false), 3000);
    });
  };

  const handleCopyZipDriveLink = () => {
    if (!driveZipResultUrl) return;
    navigator.clipboard.writeText(driveZipResultUrl).then(() => {
      setCopiedZipDriveLink(true);
      setTimeout(() => setCopiedZipDriveLink(false), 3000);
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="bg-slate-950 border border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl flex flex-col animate-in zoom-in-95 duration-200 overflow-hidden max-h-[94vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-purple-950 text-purple-400 border border-purple-500/40">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-extrabold text-white">App Download & Google Drive Hub</h2>
              <p className="text-[11px] text-slate-400">1. Full APK • 2. Full Project ZIP • 3. Drive Share Links</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Quick Filters */}
        <div className="flex items-center gap-1.5 px-4 pt-3 pb-1 border-b border-slate-800/80 bg-slate-950 text-xs overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer shrink-0 ${
              activeSubTab === 'all' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            Sabhi Options
          </button>
          <button
            onClick={() => setActiveSubTab('apk')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
              activeSubTab === 'apk' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" /> 1. Full APK (7.09 MB)
          </button>
          <button
            onClick={() => setActiveSubTab('zip')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
              activeSubTab === 'zip' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5" /> 2. Full ZIP (3.0 MB)
          </button>
          <button
            onClick={() => setActiveSubTab('drive')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer shrink-0 flex items-center gap-1 ${
              activeSubTab === 'drive' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            <UploadCloud className="w-3.5 h-3.5" /> 3. Drive Links
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto">

          {/* ITEM 1: FULL ANDROID APK COMPLETE & DIRECT DOWNLOAD */}
          {(activeSubTab === 'all' || activeSubTab === 'apk') && (
            <div className="p-4 bg-gradient-to-br from-purple-950/70 via-slate-900 to-indigo-950/70 border border-purple-500/40 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-400/40">
                    <Smartphone className="w-5 h-5 text-purple-300" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      1. Full Android APK (Direct Phone Save)
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono font-bold">
                        7.10 MB REAL BINARY
                      </span>
                    </h3>
                    <p className="text-[11px] text-purple-300">
                      BrandMorph_Julli_v1.0.apk • Standalone Android Installer • Pure Offline Suite
                    </p>
                  </div>
                </div>
              </div>

              {/* Progress & Feedback for APK */}
              {isDownloadingApk && (
                <div className="p-3 bg-indigo-950/80 border border-indigo-500/40 rounded-xl text-indigo-200 text-xs flex items-center gap-2.5 animate-pulse">
                  <Loader2 className="w-4 h-4 text-indigo-400 animate-spin shrink-0" />
                  <div>
                    <span className="font-bold block">Downloading APK Binary (7.10 MB)...</span>
                    <span className="text-[11px] text-indigo-300">{apkDownloadProgress || 'Please wait...'}</span>
                  </div>
                </div>
              )}

              {apkDownloadSuccess && (
                <div className="p-3 bg-emerald-950/90 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <span className="font-bold block">Download Shuru ho gaya!</span>
                    <span className="text-[11px] text-emerald-300">
                      BrandMorph_Julli_v1.0.apk (7.10 MB) download ho chuka hai. Notification se Open karke Install karein.
                    </span>
                  </div>
                </div>
              )}

              {apkDownloadError && (
                <div className="p-2.5 bg-rose-950/80 border border-rose-500/40 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="text-[11px]">{apkDownloadError}</span>
                </div>
              )}

              {/* Primary APK Download Action Button */}
              <button
                onClick={handleDownloadApk}
                disabled={isDownloadingApk}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs sm:text-sm shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-transform hover:scale-[1.01] disabled:opacity-50 cursor-pointer"
              >
                {isDownloadingApk ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Fetching 7.09 MB Package...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    Download APK (BrandMorph_Julli_v1.0.apk • 7.09 MB)
                  </>
                )}
              </button>

              {/* Direct APK Link Controls */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDownloadApk}
                  type="button"
                  className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-purple-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <FolderDown className="w-3.5 h-3.5 text-purple-400" />
                  Direct Download Trigger
                </button>

                <button
                  onClick={handleCopyApkLink}
                  type="button"
                  className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold text-xs border border-slate-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedApkLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-indigo-400" />}
                  {copiedApkLink ? 'APK URL Copied!' : 'Copy APK Link'}
                </button>
              </div>

              {/* URL preview */}
              <div className="p-2 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] font-mono text-slate-400 select-all truncate">
                {directApkUrl}
              </div>
            </div>
          )}

          {/* ITEM 2: FULL PROJECT ZIP ARCHIVE */}
          {(activeSubTab === 'all' || activeSubTab === 'zip') && (
            <div className="p-4 bg-gradient-to-br from-amber-950/60 via-slate-900 to-amber-950/40 border border-amber-500/40 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-amber-600/30 text-amber-300 border border-amber-400/40">
                    <FileArchive className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      2. Full Project ZIP (Complete Code & APK)
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono font-bold">
                        3.08 MB ZIP
                      </span>
                    </h3>
                    <p className="text-[11px] text-amber-200/90">
                      BrandMorph_Project.zip • Complete source code, models, and binary APK
                    </p>
                  </div>
                </div>
              </div>

              {/* Progress & Feedback for ZIP */}
              {isDownloadingZip && (
                <div className="p-3 bg-amber-950/80 border border-amber-500/40 rounded-xl text-amber-200 text-xs flex items-center gap-2.5 animate-pulse">
                  <Loader2 className="w-4 h-4 text-amber-400 animate-spin text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold block">Downloading Full Project ZIP (3.08 MB)...</span>
                    <span className="text-[11px] text-amber-300">{zipDownloadProgress || 'Please wait...'}</span>
                  </div>
                </div>
              )}

              {zipDownloadSuccess && (
                <div className="p-3 bg-emerald-950/90 border border-emerald-500/50 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <span className="font-bold block">ZIP Download Ho Gaya!</span>
                    <span className="text-[11px] text-emerald-300">
                      BrandMorph_Project.zip (3.08 MB) aapke device me save ho chuka hai.
                    </span>
                  </div>
                </div>
              )}

              {zipDownloadError && (
                <div className="p-2.5 bg-rose-950/80 border border-rose-500/40 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="text-[11px]">{zipDownloadError}</span>
                </div>
              )}

              {/* Primary ZIP Action Button */}
              <button
                onClick={handleDownloadZip}
                disabled={isDownloadingZip}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-600/30 flex items-center justify-center gap-2 transition-transform hover:scale-[1.01] disabled:opacity-50 cursor-pointer"
              >
                {isDownloadingZip ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                    Packaging & Downloading 3.0 MB ZIP...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 text-slate-950" />
                    Download Full Project ZIP (BrandMorph_Project.zip • 3.0 MB)
                  </>
                )}
              </button>

              {/* Secondary Controls: Copy link & Google Drive upload for ZIP */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleCopyZipLink}
                  type="button"
                  className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold text-xs border border-slate-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedZipLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
                  {copiedZipLink ? 'ZIP URL Copied!' : 'Copy ZIP Link'}
                </button>

                <button
                  onClick={handleUploadZipToDrive}
                  disabled={isUploadingZipToDrive}
                  type="button"
                  className="py-2 px-3 rounded-xl bg-emerald-950/90 hover:bg-emerald-900 text-emerald-200 font-bold text-xs border border-emerald-500/40 flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isUploadingZipToDrive ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Uploading ZIP...
                    </>
                  ) : (
                    <>
                      <UploadCloud className="w-3.5 h-3.5 text-emerald-400" />
                      ZIP to Google Drive
                    </>
                  )}
                </button>
              </div>

              {/* Drive ZIP Progress or Result */}
              {isUploadingZipToDrive && (
                <div className="space-y-1 p-2.5 bg-slate-950/90 rounded-xl border border-amber-500/30 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-amber-300">{driveZipProgressText}</span>
                    <span className="font-mono text-amber-400 font-bold">{driveZipProgressPercent}%</span>
                  </div>
                </div>
              )}

              {driveZipResultUrl && (
                <div className="p-2.5 bg-emerald-950/90 border border-emerald-500/50 rounded-xl space-y-1.5 text-xs">
                  <span className="font-bold text-emerald-200 block">ZIP Google Drive me Save Ho Gaya:</span>
                  <div className="flex items-center justify-between gap-2 p-1.5 bg-slate-950 rounded-lg">
                    <span className="truncate font-mono text-[11px] text-emerald-300">{driveZipResultUrl}</span>
                    <button
                      onClick={handleCopyZipDriveLink}
                      className="px-2 py-0.5 bg-emerald-800 text-white rounded font-bold text-[10px]"
                    >
                      {copiedZipDriveLink ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                </div>
              )}

              {driveZipError && (
                <div className="p-2 bg-rose-950 border border-rose-500/40 rounded-xl text-rose-300 text-xs">
                  {driveZipError}
                </div>
              )}

              {/* URL preview */}
              <div className="p-2 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] font-mono text-slate-400 select-all truncate">
                {directZipUrl}
              </div>
            </div>
          )}

          {/* ITEM 3: DOWNLOAD APK SHARE LINK TO GOOGLE DRIVE */}
          {(activeSubTab === 'all' || activeSubTab === 'drive') && (
            <div className="p-4 bg-gradient-to-br from-emerald-950/60 via-slate-900 to-indigo-950/60 border border-emerald-500/40 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-emerald-600/30 text-emerald-300 border border-emerald-400/40">
                    <UploadCloud className="w-5 h-5 text-emerald-300" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      3. Download APK Share Link to Google Drive
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono font-bold">
                        GOOGLE DRIVE
                      </span>
                    </h3>
                    <p className="text-[11px] text-emerald-300">
                      APK ko seedha apne Google Drive account me upload karein aur direct download share link payein
                    </p>
                  </div>
                </div>

                {currentUser && (
                  <button
                    onClick={handleGoogleLogout}
                    title="Sign out of Google"
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span className="text-[10px]">Logout</span>
                  </button>
                )}
              </div>

              {currentUser && (
                <div className="flex items-center gap-2 px-2.5 py-1.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-300">
                  {currentUser.photoURL ? (
                    <img src={currentUser.photoURL} alt="User" className="w-5 h-5 rounded-full" />
                  ) : (
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  )}
                  <span className="truncate text-[11px]">
                    Google Drive Account: <b className="text-emerald-300">{currentUser.email || currentUser.displayName}</b>
                  </span>
                </div>
              )}

              {/* Drive Upload Progress Bar */}
              {isUploadingToDrive && (
                <div className="space-y-1.5 p-3 bg-slate-950/90 rounded-xl border border-indigo-500/30">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-indigo-300 flex items-center gap-1.5 font-medium">
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />
                      {driveProgressText || 'Uploading to Drive...'}
                    </span>
                    <span className="font-mono text-indigo-400 font-bold">{driveProgressPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-emerald-500 to-indigo-500 h-full transition-all duration-300 rounded-full"
                      style={{ width: `${driveProgressPercent}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Drive Upload Success & SHARE LINK DISPLAY */}
              {driveResultUrl && (
                <div className="p-3 bg-emerald-950/90 border border-emerald-500/50 rounded-xl space-y-3">
                  <div className="flex items-center gap-2 text-xs text-emerald-200">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-bold">
                      APK Google Drive par save ho gaya aur Share Link ready hai!
                    </span>
                  </div>

                  {/* 1. Google Drive App View / Share Link */}
                  <div className="space-y-1">
                    <span className="text-[11px] text-emerald-300 font-semibold flex items-center gap-1">
                      <LinkIcon className="w-3 h-3 text-emerald-400" />
                      Google Drive Share Link (Google Drive App me kholne ke liye):
                    </span>
                    <div className="flex items-center justify-between gap-2 p-2 bg-slate-950 rounded-xl border border-emerald-500/40">
                      <span className="truncate font-mono text-[11px] text-emerald-200 select-all">
                        {driveResultUrl}
                      </span>
                      <button
                        onClick={handleCopyDriveLink}
                        className="px-2.5 py-1 rounded-md bg-emerald-800 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                      >
                        {copiedDriveLink ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedDriveLink ? 'Copied!' : 'Copy Link'}
                      </button>
                    </div>
                  </div>

                  {/* 2. Direct Google Drive High-Speed CDN Download Link */}
                  {driveDirectDownloadUrl && (
                    <div className="space-y-1">
                      <span className="text-[11px] text-emerald-300 font-semibold flex items-center gap-1">
                        <Download className="w-3 h-3 text-emerald-400" />
                        Google Direct Download Link (Instant 1-Click Save):
                      </span>
                      <div className="flex items-center justify-between gap-2 p-2 bg-slate-950 rounded-xl border border-emerald-500/40">
                        <span className="truncate font-mono text-[11px] text-emerald-200 select-all">
                          {driveDirectDownloadUrl}
                        </span>
                        <button
                          onClick={handleCopyDirectDriveLink}
                          className="px-2.5 py-1 rounded-md bg-emerald-800 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                        >
                          {copiedDirectDriveLink ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                          {copiedDirectDriveLink ? 'Copied!' : 'Copy Direct'}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Direct Button to open link in Google Drive */}
                  <a
                    href={driveResultUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 transition-transform hover:scale-[1.01] shadow-lg shadow-emerald-500/20"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Open in Google Drive App
                  </a>
                </div>
              )}

              {/* Drive Error */}
              {driveError && (
                <div className="p-2.5 bg-rose-950/80 border border-rose-500/40 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="text-[11px]">{driveError}</span>
                </div>
              )}

              {/* Upload Button */}
              {!driveResultUrl && (
                <button
                  onClick={handleUploadToDrive}
                  disabled={isUploadingToDrive}
                  className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2 transition-transform hover:scale-[1.01] disabled:opacity-50 cursor-pointer"
                >
                  {isUploadingToDrive ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Drive me Upload ho raha hai ({driveProgressPercent}%)...
                    </>
                  ) : (
                    <>
                      <UploadCloud className="w-4 h-4" />
                      {currentUser ? 'Apne Google Drive me Save Karein (7.09 MB)' : 'Google Drive me Bhejo & Share Link Banao'}
                    </>
                  )}
                </button>
              )}
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
