import { useQuery } from "@tanstack/react-query";
import { Calendar, FileText, Inbox } from "lucide-react";
import { getBriefing } from "@/lib/assistant/briefing";
import { useRefetchWhenConnectorReady } from "@/lib/app-data";
import { ConnectorState } from "@/components/connector-state";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/lib/store";
import { formatWhen } from "@/lib/device";
import type { ConnectorPack, LibraryItem } from "@/lib/assistant/types";

function Section({
  icon: Icon,
  title,
  pack,
  empty,
  onAsk,
}: {
  icon: typeof Calendar;
  title: string;
  pack: ConnectorPack;
  empty: string;
  onAsk: (item: LibraryItem) => void;
}) {
  return (
    <section className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <Icon className="size-4 text-muted" />
        <h2 className="text-sm font-medium text-fg">{title}</h2>
      </div>
      <ConnectorState pack={pack} label={title} />
      {pack.ok && !pack.error && pack.items.length === 0 ? (
        <p className="text-sm text-muted">{empty}</p>
      ) : null}
      <ul className="flex flex-col gap-2">
        {pack.items.map((item) => (
          <li key={item.id}>
            <button
              type="button"
              onClick={() => onAsk(item)}
              className="flex w-full flex-col gap-0.5 rounded-xl bg-raised px-4 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.98]"
            >
              <span className="text-sm font-medium text-fg">{item.title}</span>
              {item.subtitle || item.extra ? (
                <span className="text-xs text-muted">
                  {formatWhen(item.extra) ?? item.subtitle}
                </span>
              ) : null}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function TodayPane() {
  const setTab = useAppStore((s) => s.setTab);
  const setDraft = useAppStore((s) => s.setDraft);
  const query = useQuery({
    queryKey: ["briefing"],
    queryFn: () => getBriefing({ data: { nowISO: new Date().toISOString() } }),
  });

  const waiting = Boolean(
    query.data?.calendar.pending ||
      query.data?.drive.pending ||
      query.data?.mail.pending,
  );
  useRefetchWhenConnectorReady(waiting, () => query.refetch());

  function askAbout(prefix: string, item: LibraryItem) {
    setDraft(`${prefix} ${item.title}`);
    setTab("ask");
  }

  if (query.isLoading) {
    return (
      <div className="flex flex-col gap-4 px-4 pt-2">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-24 w-full rounded-xl" />
        <Skeleton className="h-24 w-full rounded-xl" />
      </div>
    );
  }

  if (query.isError || !query.data) {
    return (
      <p className="px-4 pt-6 text-sm text-muted">
        Could not load today. Pull this tab again in a moment.
      </p>
    );
  }

  const data = query.data;

  return (
    <div className="mx-auto flex w-full max-w-lg flex-col gap-8 overflow-y-auto px-4 pb-8 pt-2">
      <header className="stagger-in">
        <p className="text-sm font-medium text-muted">Today</p>
        <h2 className="font-display mt-1 text-3xl tracking-[-0.03em] text-fg">
          Your briefing
        </h2>
      </header>

      <div className="flex flex-wrap gap-2">
        {["Brief me for today", "What's next on my calendar?", "Summarize new mail"].map(
          (prompt) => (
            <button
              key={prompt}
              type="button"
              onClick={() => {
                setDraft(prompt);
                setTab("ask");
              }}
              className="rounded-full bg-raised px-3.5 py-2 text-sm text-fg shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]"
            >
              {prompt}
            </button>
          ),
        )}
      </div>

      <Section
        icon={Calendar}
        title="Calendar"
        pack={data.calendar}
        empty="No upcoming events in the next week."
        onAsk={(item) => askAbout("Tell me about this event:", item)}
      />
      <Section
        icon={FileText}
        title="Recent files"
        pack={data.drive}
        empty="No recent Drive files."
        onAsk={(item) => askAbout("Open and summarize this file:", item)}
      />
      <Section
        icon={Inbox}
        title="Mail"
        pack={data.mail}
        empty="No recent mail, or Gmail is not connected yet."
        onAsk={(item) => askAbout("Summarize this email:", item)}
      />
    </div>
  );
}
