import React from 'react';

interface JarvisCoreProps {
  status: 'idle' | 'listening' | 'speaking' | 'thinking';
  onCoreClick?: () => void;
}

export const JarvisCore: React.FC<JarvisCoreProps> = ({ status, onCoreClick }) => {
  const getStatusLabel = () => {
    switch (status) {
      case 'listening':
        return 'TINGLANMOQDA';
      case 'speaking':
        return 'GAPIRMOQDA';
      case 'thinking':
        return 'HISOB-KITOBLAR';
      default:
        return 'TIZIM TAYYOR';
    }
  };

  const isListening = status === 'listening';
  const isSpeaking = status === 'speaking';
  const isThinking = status === 'thinking';

  return (
    <div className="flex flex-col items-center justify-center my-2 select-none">
      {/* Reaktiv Yadro Karkasi */}
      <div 
        onClick={onCoreClick}
        className="relative w-32 h-32 md:w-36 md:h-36 flex items-center justify-center cursor-pointer group"
        title="Ovozli kiritishni faollashtirish uchun bosing"
      >
        {/* Tashqi aylanuvchi uzuk */}
        <div 
          className={`absolute inset-0 rounded-full border border-dashed border-cyan-500/40 ${
            isThinking ? 'animate-spin' : 'animate-spin-slow'
          }`} 
        />

        {/* O'rta teskari aylanuvchi halqa */}
        <div 
          className={`absolute inset-2 rounded-full border border-cyan-400/50 border-t-transparent ${
            isThinking ? 'animate-spin-reverse' : 'animate-spin-reverse'
          }`} 
        />

        {/* Uchburchak yoki markaziy segmentlar */}
        <div className="absolute inset-4 rounded-full border border-cyan-300/20" />

        {/* Reaktiv markaz (Core) */}
        <div 
          className={`relative w-16 h-16 rounded-full flex flex-col items-center justify-center transition-all duration-300 ${
            isListening 
              ? 'scale-115 shadow-[0_0_40px_rgba(34,211,238,0.9)] bg-cyan-400 text-slate-950 font-bold' 
              : isSpeaking
              ? 'scale-105 shadow-[0_0_30px_rgba(6,182,212,0.8)] bg-cyan-500/90 text-slate-950 font-bold animate-pulse-slow'
              : isThinking
              ? 'scale-110 shadow-[0_0_35px_rgba(56,189,248,0.8)] bg-sky-400 text-slate-950 font-bold'
              : 'shadow-[0_0_20px_rgba(6,182,212,0.4)] bg-gradient-to-br from-cyan-500/30 via-cyan-950/60 to-black text-cyan-300 border border-cyan-400/40 group-hover:shadow-[0_0_30px_rgba(6,182,212,0.7)]'
          }`}
        >
          <span className="font-display text-[9px] tracking-wider text-center leading-none">
            {isListening ? 'MIC' : isSpeaking ? 'VOX' : isThinking ? 'PROC' : 'CORE'}
          </span>
          <span className="text-[8px] font-mono opacity-80 mt-0.5">70B</span>
        </div>
      </div>

      {/* Holat matni */}
      <div className="mt-2 text-center">
        <span className="font-display text-xs tracking-widest text-cyan-400 uppercase">
          {getStatusLabel()}
        </span>
      </div>

      {/* Ovoz to'lqini (Audio Wave Visualizer) */}
      <div className="flex items-center justify-center gap-1 h-6 mt-1">
        {[40, 70, 100, 60, 90, 50, 80, 40].map((h, i) => (
          <div
            key={i}
            className={`w-1 rounded-full transition-all duration-150 ${
              isSpeaking || isListening
                ? 'bg-cyan-400 animate-pulse'
                : 'bg-cyan-900/60 h-1.5'
            }`}
            style={{
              height: isSpeaking || isListening ? `${(h * 0.22) + 4}px` : '4px',
              animationDelay: `${i * 0.1}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
};
