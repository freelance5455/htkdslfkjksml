import React, { useState } from 'react';
import { Language } from '../types/calculator';
import { 
  X, 
  Download, 
  Copy, 
  Check, 
  Smartphone, 
  FileCode, 
  WifiOff, 
  ExternalLink 
} from 'lucide-react';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const ApkExportModal: React.FC<ApkExportModalProps> = ({ isOpen, onClose, language }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);
  const isUrdu = language === 'ur';

  if (!isOpen) return null;

  const handleDownload = async () => {
    try {
      setDownloading(true);
      const res = await fetch('/standalone_calculator.html');
      const text = await res.text();
      const blob = new Blob([text], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'index.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      window.open('/standalone_calculator.html', '_blank');
    } finally {
      setDownloading(false);
    }
  };

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCode(id);
      setTimeout(() => setCopiedCode(null), 2000);
    } catch {
      // fallback
    }
  };

  const androidJavaCode = `package com.example.calculator;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);

        // Load the offline single-file calculator
        webView.loadUrl("file:///android_asset/index.html");
    }
}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                {isUrdu ? 'Android APK کے لیے مکمل سورس فائل' : 'Offline Source Code for Android APK'}
              </h2>
              <span className="text-xs text-emerald-400 flex items-center gap-1">
                <WifiOff className="w-3 h-3" />
                <span>{isUrdu ? '100٪ بغیر انٹرنیٹ (آف لائن) کام کرتا ہے' : '100% Offline Single File'}</span>
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-slate-300">
          {/* Download Action Banner */}
          <div className="bg-gradient-to-br from-amber-500/10 via-slate-800/40 to-slate-900 border border-amber-500/30 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-start">
              <span className="font-bold text-slate-100 text-base block">
                {isUrdu ? 'مکمل Standalone index.html فائل' : 'Complete Standalone index.html'}
              </span>
              <p className="text-xs text-slate-400">
                {isUrdu 
                  ? 'تمام HTML، CSS اور JavaScript ایک ہی فائل میں شامل ہیں۔ کسی بیرونی لنک یا انٹرنیٹ کی ضرورت نہیں۔'
                  : 'All HTML, CSS & JavaScript in 1 file. Zero CDNs, zero internet required.'}
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={handleDownload}
                disabled={downloading}
                className="w-full sm:w-auto px-4 py-2.5 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-xs"
              >
                <Download className="w-4 h-4" />
                <span>{downloading ? (isUrdu ? 'ڈاؤن لوڈ ہو رہا ہے...' : 'Downloading...') : (isUrdu ? 'index.html ڈاؤن لوڈ کریں' : 'Download index.html')}</span>
              </button>

              <a
                href="/standalone_calculator.html"
                target="_blank"
                rel="noreferrer"
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 transition-colors flex items-center justify-center"
                title={isUrdu ? 'براؤزر میں دیکھیں' : 'Open preview'}
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* 3 Simple Conversion Methods */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
              <FileCode className="w-4 h-4 text-amber-400" />
              <span>{isUrdu ? 'اس فائل کو APK میں تبدیل کرنے کے 3 آسان طریقے:' : '3 Simple Ways to Build the APK:'}</span>
            </h3>

            {/* Method 1 */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <span className="font-semibold text-amber-300 text-xs block">
                {isUrdu ? 'طریقہ 1: Website 2 APK Builder یا WebIntoApp (آسان ترین طریقہ - بغیر کوڈنگ کے)' : 'Method 1: Website 2 APK Builder or WebIntoApp (No Coding)'}
              </span>
              <ol className="list-decimal list-inside text-xs text-slate-400 space-y-1">
                <li>{isUrdu ? 'اوپر سے index.html فائل ڈاؤن لوڈ کریں اور ایک نئے فولڈر میں رکھیں۔' : 'Download index.html above and place it inside a folder.'}</li>
                <li>{isUrdu ? 'Website 2 APK Builder میں "Local HTML Website" منتخب کریں اور وہ فولڈر سلیکٹ کریں۔' : 'In Website 2 APK Builder, choose "Local HTML Website" and pick that folder.'}</li>
                <li>{isUrdu ? 'ایپ کا نام "سادہ کیلکولیٹر" دیں اور "Generate APK" پر کلک کریں۔ آپ کی APK 1 منٹ میں تیار ہو جائے گی!' : 'Enter app name "Simple Calculator" and click "Generate APK". Done in 1 minute!'}</li>
              </ol>
            </div>

            {/* Method 2 */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <span className="font-semibold text-amber-300 text-xs block">
                {isUrdu ? 'طریقہ 2: Capacitor (جدید اور پیشہ ورانہ طریقہ)' : 'Method 2: Capacitor (Modern & Clean)'}
              </span>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 font-mono text-xs text-slate-300 overflow-x-auto">
                <code>
                  npm init @capacitor/app<br/>
                  # index.html کو www یا dist فولڈر میں کاپی کریں<br/>
                  npx cap add android<br/>
                  npx cap open android
                </code>
              </div>
            </div>

            {/* Method 3 */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-amber-300 text-xs">
                  {isUrdu ? 'طریقہ 3: Android Studio (WebView کوڈ)' : 'Method 3: Android Studio (WebView)'}
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(androidJavaCode, 'java')}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded-md text-[11px] text-slate-300 flex items-center gap-1 transition-colors"
                >
                  {copiedCode === 'java' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">{isUrdu ? 'کاپی ہو گیا' : 'Copied'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>{isUrdu ? 'کوڈ کاپی کریں' : 'Copy Java'}</span>
                    </>
                  )}
                </button>
              </div>
              <p className="text-xs text-slate-400">
                {isUrdu 
                  ? 'فائل کو app/src/main/assets/index.html میں رکھیں اور MainActivity میں درج ذیل کوڈ لکھیں:'
                  : 'Place index.html at app/src/main/assets/index.html and use this MainActivity:'}
              </p>
              <pre className="bg-slate-900 border border-slate-800 rounded-lg p-3 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-40">
                {androidJavaCode}
              </pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            {isUrdu ? 'بند کریں' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
