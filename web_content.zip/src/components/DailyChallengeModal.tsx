import React from 'react';
import { DailyChallenge } from '../types';
import { X, Calendar, Coins, CheckCircle, Award } from 'lucide-react';

interface DailyChallengeModalProps {
  challenge: DailyChallenge;
  onClaim: () => void;
  onClose: () => void;
  onPlayNow: () => void;
}

export const DailyChallengeModal: React.FC<DailyChallengeModalProps> = ({
  challenge,
  onClaim,
  onClose,
  onPlayNow,
}) => {
  const progressRatio = Math.min(1, challenge.current / challenge.target);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="flex w-full max-w-sm flex-col rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-indigo-400" />
            <h2 className="text-lg font-black text-white">DAILY CHALLENGE</h2>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Challenge Content Card */}
        <div className="my-5 flex flex-col items-center rounded-2xl bg-slate-950/80 p-5 border border-slate-800 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 mb-3 shadow-[0_0_20px_rgba(99,102,241,0.25)]">
            <Award className="h-8 w-8 text-amber-400" />
          </div>

          <h3 className="text-base font-black text-white">{challenge.title}</h3>
          <p className="mt-1 text-xs text-slate-400">{challenge.description}</p>

          {/* Progress Bar */}
          <div className="mt-4 w-full">
            <div className="flex justify-between text-xs font-mono font-bold text-slate-400 mb-1.5">
              <span>Progress</span>
              <span className="text-white">
                {challenge.current} / {challenge.target}
              </span>
            </div>
            <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-300 rounded-full"
                style={{ width: `${progressRatio * 100}%` }}
              />
            </div>
          </div>

          {/* Reward Pill */}
          <div className="mt-4 flex items-center gap-1.5 rounded-full bg-amber-500/20 px-3 py-1 border border-amber-500/40 text-xs font-black text-amber-300">
            <Coins className="h-4 w-4 fill-amber-400/30" />
            <span>REWARD: +{challenge.rewardCoins} COINS</span>
          </div>
        </div>

        {/* Action Button */}
        {challenge.claimed ? (
          <div className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-slate-800/80 text-emerald-400 font-bold text-sm">
            <CheckCircle className="h-4 w-4" />
            <span>Completed & Claimed</span>
          </div>
        ) : challenge.completed ? (
          <button
            onClick={onClaim}
            className="flex h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-sm shadow-[0_4px_20px_rgba(245,158,11,0.4)] active:scale-95 transition-all hover:brightness-110"
          >
            <Coins className="h-4 w-4" />
            <span>CLAIM REWARD (+{challenge.rewardCoins})</span>
          </button>
        ) : (
          <button
            onClick={onPlayNow}
            className="flex h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 font-black text-sm text-white shadow-lg active:scale-95 transition-all"
          >
            <span>PLAY NOW</span>
          </button>
        )}
      </div>
    </div>
  );
};
