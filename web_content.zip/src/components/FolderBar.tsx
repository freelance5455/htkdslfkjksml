import React from 'react';
import { Folder as FolderIcon, Plus, Edit2, Trash2 } from 'lucide-react';
import { Folder } from '../types';

interface FolderBarProps {
  folders: Folder[];
  selectedFolderId: string | 'all';
  onSelectFolder: (id: string | 'all') => void;
  onAddFolder: () => void;
  onEditFolder: (folder: Folder) => void;
  onDeleteFolder: (folder: Folder) => void;
  getCustomerCountForFolder: (folderId: string | 'all') => number;
}

export const FolderBar: React.FC<FolderBarProps> = ({
  folders,
  selectedFolderId,
  onSelectFolder,
  onAddFolder,
  onEditFolder,
  onDeleteFolder,
  getCustomerCountForFolder,
}) => {
  const activeFolder = folders.find((f) => f.id === selectedFolderId);

  return (
    <div className="bg-white border-b border-orange-100 shadow-xs px-3 py-2.5 sm:px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 uppercase tracking-wider">
            <FolderIcon className="w-4 h-4 text-orange-600" />
            <span>इलाका / फोल्डर चुनें:</span>
          </div>

          <button
            onClick={onAddFolder}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-orange-100 hover:bg-orange-200 text-orange-800 text-xs font-bold transition active:scale-95 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ नया फोल्डर</span>
          </button>
        </div>

        {/* Scrollable folder pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none no-scrollbar">
          {/* 'All Folders' Button */}
          <button
            onClick={() => onSelectFolder('all')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer shrink-0 ${
              selectedFolderId === 'all'
                ? 'bg-orange-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>सभी फोल्डर</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[11px] font-extrabold ${
                selectedFolderId === 'all' ? 'bg-orange-700 text-white' : 'bg-slate-200 text-slate-800'
              }`}
            >
              {getCustomerCountForFolder('all')}
            </span>
          </button>

          {/* Folder List */}
          {folders.map((folder) => {
            const isSelected = selectedFolderId === folder.id;
            const count = getCustomerCountForFolder(folder.id);

            return (
              <button
                key={folder.id}
                onClick={() => onSelectFolder(folder.id)}
                className={`group flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer shrink-0 border ${
                  isSelected
                    ? 'bg-orange-600 border-orange-600 text-white shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-orange-300 hover:bg-orange-50/50'
                }`}
              >
                <span>{folder.name}</span>
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[11px] font-extrabold ${
                    isSelected ? 'bg-orange-700 text-white' : 'bg-slate-100 text-slate-800'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Active Folder Actions (Edit / Delete) if a specific folder is selected */}
        {activeFolder && (
          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span className="font-semibold truncate">
              वर्तमान फोल्डर: <strong className="text-slate-900">{activeFolder.name}</strong>
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onEditFolder(activeFolder)}
                className="flex items-center gap-1 text-slate-600 hover:text-orange-600 px-2 py-0.5 rounded bg-slate-100 hover:bg-orange-50 font-medium cursor-pointer"
                title="नाम बदलें"
              >
                <Edit2 className="w-3 h-3" />
                <span>नाम बदलें</span>
              </button>
              <button
                onClick={() => onDeleteFolder(activeFolder)}
                className="flex items-center gap-1 text-rose-600 hover:text-rose-700 px-2 py-0.5 rounded bg-rose-50 hover:bg-rose-100 font-medium cursor-pointer"
                title="फोल्डर हटाएं"
              >
                <Trash2 className="w-3 h-3" />
                <span>हटाएं</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
