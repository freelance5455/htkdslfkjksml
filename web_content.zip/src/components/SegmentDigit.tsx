import React from 'react';

interface SegmentDigitProps {
  char: string; // '0'-'9', ':', or ' '
  color: string;
  unlitColor: string;
  glowColor?: string;
  className?: string;
  blinking?: boolean;
}

// 7 segments: a, b, c, d, e, f, g
const DIGIT_SEGMENTS: Record<string, boolean[]> = {
  '0': [true, true, true, true, true, true, false],
  '1': [false, true, true, false, false, false, false],
  '2': [true, true, false, true, true, false, true],
  '3': [true, true, true, true, false, false, true],
  '4': [false, true, true, false, false, true, true],
  '5': [true, false, true, true, false, true, true],
  '6': [true, false, true, true, true, true, true],
  '7': [true, true, true, false, false, false, false],
  '8': [true, true, true, true, true, true, true],
  '9': [true, true, true, true, false, true, true],
  ' ': [false, false, false, false, false, false, false],
};

export const SegmentDigit: React.FC<SegmentDigitProps> = ({
  char,
  color,
  unlitColor,
  glowColor,
  className = 'w-16 h-28 sm:w-24 sm:h-44 md:w-32 md:h-56',
  blinking = false,
}) => {
  if (char === ':') {
    return (
      <svg
        viewBox="0 0 40 140"
        className={`w-6 h-28 sm:w-10 sm:h-44 md:w-12 md:h-56 inline-block transition-opacity duration-300 ${
          blinking ? 'opacity-30' : 'opacity-100'
        }`}
        style={{
          filter: glowColor ? `drop-shadow(0 0 8px ${glowColor})` : undefined,
        }}
      >
        <circle cx="20" cy="46" r="6.5" fill={color} />
        <circle cx="20" cy="94" r="6.5" fill={color} />
      </svg>
    );
  }

  const segments = DIGIT_SEGMENTS[char] || DIGIT_SEGMENTS[' '];

  return (
    <svg
      viewBox="0 0 78 140"
      className={`${className} inline-block select-none`}
      style={{
        filter: glowColor ? `drop-shadow(0 0 10px ${glowColor})` : undefined,
      }}
    >
      <defs>
        {/* Horizontal segment path (a, g, d) */}
        <polygon id="h-seg" points="10,0 60,0 52,8 18,8" />
        {/* Center horizontal segment (g) */}
        <polygon id="m-seg" points="14,0 56,0 62,5 56,10 14,10 8,5" />
        {/* Vertical segment (b, c, e, f) with slight angle */}
        <polygon id="v-seg" points="0,10 8,16 8,52 0,60" />
      </defs>

      {/* Segment a (top) */}
      <polygon
        points="13,10 65,10 57,19 21,19"
        fill={segments[0] ? color : unlitColor}
      />

      {/* Segment b (top-right) */}
      <polygon
        points="68,14 68,64 59,57 59,22"
        fill={segments[1] ? color : unlitColor}
      />

      {/* Segment c (bottom-right) */}
      <polygon
        points="68,76 68,126 59,118 59,83"
        fill={segments[2] ? color : unlitColor}
      />

      {/* Segment d (bottom) */}
      <polygon
        points="21,121 57,121 65,130 13,130"
        fill={segments[3] ? color : unlitColor}
      />

      {/* Segment e (bottom-left) */}
      <polygon
        points="10,76 19,83 19,118 10,126"
        fill={segments[4] ? color : unlitColor}
      />

      {/* Segment f (top-left) */}
      <polygon
        points="10,14 19,22 19,57 10,64"
        fill={segments[5] ? color : unlitColor}
      />

      {/* Segment g (middle) */}
      <polygon
        points="14,70 20,65 58,65 64,70 58,75 20,75"
        fill={segments[6] ? color : unlitColor}
      />
    </svg>
  );
};
