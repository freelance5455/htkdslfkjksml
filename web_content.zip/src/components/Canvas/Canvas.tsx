import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Board,
  CanvasElement,
  ToolType,
  Viewport,
  StrokePoint,
  StylusSettings,
  CanvasBackgroundType,
} from '../../canvas/types';
import {
  screenToWorld,
  worldToScreen,
  getElementBounds,
  getSelectionBounds,
  getTransformHandles,
  hitTestElement,
  elementIntersectsRect,
  calculateResizedBox,
  calculatePressureWidth,
  BoundingBox,
  TransformHandle,
} from '../../canvas/geometry';
import { StylusManager } from '../../canvas/stylus';
import { renderElementToContext, exportBoardToPNG, exportBoardToJSON, generateThumbnailDataUrl } from '../../canvas/export';
import { recognizeShape } from '../../canvas/shapeRecognition';
import { Toolbar } from './Toolbar';
import { useCollaboration } from '../../collaboration/useCollaboration';
import { CollaborationModal } from '../Collaboration/CollaborationModal';

interface CanvasProps {
  board: Board;
  onSaveBoard: (board: Board) => void;
  onBackToDashboard: () => void;
  stylusSettings: StylusSettings;
  shapeRecognition?: boolean;
}

export const Canvas: React.FC<CanvasProps> = ({
  board,
  onSaveBoard,
  onBackToDashboard,
  stylusSettings,
  shapeRecognition = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Board State
  const [elements, setElements] = useState<CanvasElement[]>(board.elements || []);
  const [viewport, setViewport] = useState<Viewport>(board.viewport || { x: 0, y: 0, zoom: 1 });
  const [bgType, setBgType] = useState<CanvasBackgroundType>(board.bgType || 'dots');
  const [boardTitle, setBoardTitle] = useState(board.title);
  const [isSaving, setIsSaving] = useState(false);

  // Undo / Redo History
  const [historyPast, setHistoryPast] = useState<CanvasElement[][]>([]);
  const [historyFuture, setHistoryFuture] = useState<CanvasElement[][]>([]);

  // Active Tool & Properties
  const [activeTool, setActiveTool] = useState<ToolType>('select');
  const [strokeColor, setStrokeColor] = useState('#38bdf8');
  const [strokeWidth, setStrokeWidth] = useState(4);
  const [fillColor, setFillColor] = useState('transparent');
  const [opacity, setOpacity] = useState(1);
  const [stickyColor, setStickyColor] = useState('#fef08a');
  const [fontSize, setFontSize] = useState(18);
  const [fontWeight, setFontWeight] = useState<'normal' | 'bold'>('normal');
  const [fontStyle, setFontStyle] = useState<'normal' | 'italic'>('normal');
  const [textAlign, setTextAlign] = useState<'left' | 'center' | 'right'>('left');

  // Selection
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // In-progress Action State
  const [isInteracting, setIsInteracting] = useState(false);
  const interactionModeRef = useRef<
    | 'none'
    | 'drawing'
    | 'shape-create'
    | 'panning'
    | 'marquee'
    | 'dragging-selection'
    | 'transform-handle'
  >('none');

  const inProgressElementRef = useRef<CanvasElement | null>(null);
  const dragStartPointRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const initialElementsSnapshotRef = useRef<CanvasElement[]>([]);
  const activeHandleRef = useRef<TransformHandle['id'] | null>(null);
  const initialBoundingBoxRef = useRef<BoundingBox | null>(null);

  // Inline Text Editor
  const [editingTextElement, setEditingTextElement] = useState<{
    id: string;
    text: string;
    x: number;
    y: number;
    width: number;
    height: number;
    fontSize: number;
    stickyColor?: string;
  } | null>(null);

  // Stylus Hover
  const [hoverPosition, setHoverPosition] = useState<{ x: number; y: number } | null>(null);

  // Stylus Manager
  const stylusManagerRef = useRef<StylusManager>(new StylusManager(stylusSettings));

  useEffect(() => {
    stylusManagerRef.current.updateSettings(stylusSettings);
  }, [stylusSettings]);

  // Debounced Autosave to IndexedDB
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const triggerAutosave = useCallback(
    (newElements: CanvasElement[], newViewport: Viewport, newBgType: CanvasBackgroundType) => {
      setIsSaving(true);
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);

      saveTimeoutRef.current = setTimeout(() => {
        const updatedBoard: Board = {
          ...board,
          title: boardTitle,
          elements: newElements,
          viewport: newViewport,
          bgType: newBgType,
          updatedAt: Date.now(),
        };
        // Update thumbnail
        updatedBoard.thumbnail = generateThumbnailDataUrl(updatedBoard);

        onSaveBoard(updatedBoard);
        setIsSaving(false);
      }, 500);
    },
    [board, boardTitle, onSaveBoard]
  );

  const [isCollabModalOpen, setIsCollabModalOpen] = useState(false);

  // Real-Time Collaboration Hook
  const {
    status: collabStatus,
    roomId: collabRoomId,
    peers: collabPeers,
    localPeer,
    liveStrokes,
    isCollaborating,
    connectToRoom,
    leaveRoom,
    sendCursor,
    sendElementUpsert,
    sendElementDelete,
    sendLiveStrokePoint,
    updateLocalPeer,
  } = useCollaboration({
    onSyncElements: useCallback(
      (remoteElements: CanvasElement[], remoteTitle?: string) => {
        setElements(remoteElements);
        if (remoteTitle) setBoardTitle(remoteTitle);
        triggerAutosave(remoteElements, viewport, bgType);
      },
      [viewport, bgType, triggerAutosave]
    ),

    onRemoteElementUpsert: useCallback((remoteEl: CanvasElement) => {
      setElements((prev) => {
        const idx = prev.findIndex((el) => el.id === remoteEl.id);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = remoteEl;
          return next;
        }
        return [...prev, remoteEl];
      });
    }, []),

    onRemoteElementDelete: useCallback((deletedId: string) => {
      setElements((prev) => prev.filter((el) => el.id !== deletedId));
      setSelectedIds((prev) => prev.filter((id) => id !== deletedId));
    }, []),
  });

  // Auto-join room if URL has ?room=...
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const roomFromUrl = params.get('room');
    if (roomFromUrl) {
      connectToRoom(roomFromUrl, {
        title: board.title,
        elements: board.elements,
        bgType: board.bgType,
        bgColor: board.bgColor,
      });
    }
  }, [connectToRoom, board]);

  // Push state to undo history
  const pushHistory = (newElements: CanvasElement[]) => {
    setHistoryPast((prev) => [...prev.slice(-30), elements]);
    setHistoryFuture([]);
    setElements(newElements);
    triggerAutosave(newElements, viewport, bgType);
  };

  const handleUndo = () => {
    if (historyPast.length === 0) return;
    const previous = historyPast[historyPast.length - 1];
    setHistoryPast((prev) => prev.slice(0, -1));
    setHistoryFuture((prev) => [elements, ...prev]);
    setElements(previous);
    setSelectedIds([]);
    triggerAutosave(previous, viewport, bgType);
  };

  const handleRedo = () => {
    if (historyFuture.length === 0) return;
    const next = historyFuture[0];
    setHistoryFuture((prev) => prev.slice(1));
    setHistoryPast((prev) => [...prev, elements]);
    setElements(next);
    setSelectedIds([]);
    triggerAutosave(next, viewport, bgType);
  };

  // Keyboard Shortcuts (Delete, Undo, Redo, Esc)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in text editor
      if (editingTextElement) return;

      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedIds.length > 0) {
        e.preventDefault();
        const updated = elements.filter((el) => !selectedIds.includes(el.id));
        pushHistory(updated);
        setSelectedIds([]);
      } else if (e.key === 'z' && (e.ctrlKey || e.metaKey) && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      } else if ((e.key === 'y' && (e.ctrlKey || e.metaKey)) || (e.key === 'z' && (e.ctrlKey || e.metaKey) && e.shiftKey)) {
        e.preventDefault();
        handleRedo();
      } else if (e.key === 'Escape') {
        setSelectedIds([]);
        setActiveTool('select');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [elements, selectedIds, editingTextElement, historyPast, historyFuture]);

  // Main Canvas Rendering Loop
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = canvas.width / dpr;
    const height = canvas.height / dpr;

    // Clear
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Apply DPI scaling
    ctx.scale(dpr, dpr);

    // Canvas Background
    ctx.fillStyle = board.bgColor || '#121418';
    ctx.fillRect(0, 0, width, height);

    // Draw Infinite Grid in World Space
    ctx.save();
    ctx.translate(viewport.x, viewport.y);
    ctx.scale(viewport.zoom, viewport.zoom);

    const worldTopLeft = screenToWorld(0, 0, viewport);
    const worldBottomRight = screenToWorld(width, height, viewport);

    if (bgType === 'dots') {
      const gridSize = 40;
      const startX = Math.floor(worldTopLeft.x / gridSize) * gridSize;
      const endX = Math.ceil(worldBottomRight.x / gridSize) * gridSize;
      const startY = Math.floor(worldTopLeft.y / gridSize) * gridSize;
      const endY = Math.ceil(worldBottomRight.y / gridSize) * gridSize;

      ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
      const dotRadius = Math.max(1, 1.5 / viewport.zoom);

      for (let x = startX; x <= endX; x += gridSize) {
        for (let y = startY; y <= endY; y += gridSize) {
          ctx.beginPath();
          ctx.arc(x, y, dotRadius, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (bgType === 'grid') {
      const gridSize = 40;
      const startX = Math.floor(worldTopLeft.x / gridSize) * gridSize;
      const endX = Math.ceil(worldBottomRight.x / gridSize) * gridSize;
      const startY = Math.floor(worldTopLeft.y / gridSize) * gridSize;
      const endY = Math.ceil(worldBottomRight.y / gridSize) * gridSize;

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
      ctx.lineWidth = 1 / viewport.zoom;
      ctx.beginPath();

      for (let x = startX; x <= endX; x += gridSize) {
        ctx.moveTo(x, startY);
        ctx.lineTo(x, endY);
      }
      for (let y = startY; y <= endY; y += gridSize) {
        ctx.moveTo(startX, y);
        ctx.lineTo(endX, y);
      }
      ctx.stroke();
    }

    // Render Canvas Elements
    const sorted = [...elements].sort((a, b) => a.zIndex - b.zIndex);
    for (const el of sorted) {
      renderElementToContext(ctx, el);
    }

    // Render in-progress element (drawing / shape creation)
    if (inProgressElementRef.current) {
      renderElementToContext(ctx, inProgressElementRef.current);
    }

    // Render Selection Outlines & Transform Handles
    const selectedElements = elements.filter((el) => selectedIds.includes(el.id));
    if (selectedElements.length > 0) {
      const bounds = getSelectionBounds(selectedElements);
      if (bounds) {
        ctx.save();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5 / viewport.zoom;
        ctx.setLineDash([4 / viewport.zoom, 4 / viewport.zoom]);
        ctx.strokeRect(bounds.minX - 4, bounds.minY - 4, bounds.width + 8, bounds.height + 8);
        ctx.setLineDash([]);

        // Transform handles
        const handles = getTransformHandles(bounds);
        const handleRadius = 5 / viewport.zoom;

        for (const h of handles) {
          ctx.fillStyle = '#ffffff';
          ctx.strokeStyle = '#0284c7';
          ctx.lineWidth = 2 / viewport.zoom;

          ctx.beginPath();
          if (h.id === 'rotate') {
            // Draw connector line up to rotate handle
            ctx.beginPath();
            ctx.moveTo((bounds.minX + bounds.maxX) / 2, bounds.minY - 4);
            ctx.lineTo(h.x, h.y);
            ctx.stroke();

            ctx.beginPath();
            ctx.arc(h.x, h.y, handleRadius + 1 / viewport.zoom, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
          } else {
            ctx.rect(h.x - handleRadius, h.y - handleRadius, handleRadius * 2, handleRadius * 2);
            ctx.fill();
            ctx.stroke();
          }
        }
        ctx.restore();
      }
    }

    // Render Marquee selection rectangle
    if (
      interactionModeRef.current === 'marquee' &&
      inProgressElementRef.current &&
      inProgressElementRef.current.type === 'rect'
    ) {
      const m = inProgressElementRef.current;
      ctx.save();
      ctx.strokeStyle = '#60a5fa';
      ctx.fillStyle = 'rgba(96, 165, 250, 0.12)';
      ctx.lineWidth = 1 / viewport.zoom;
      ctx.setLineDash([4 / viewport.zoom, 4 / viewport.zoom]);
      ctx.fillRect(m.x, m.y, m.width, m.height);
      ctx.strokeRect(m.x, m.y, m.width, m.height);
      ctx.restore();
    }

    // Render live streaming strokes from remote collaborators
    for (const stroke of liveStrokes.values()) {
      if (stroke.points && stroke.points.length > 1) {
        ctx.save();
        ctx.strokeStyle = stroke.color || '#38bdf8';
        ctx.lineWidth = stroke.strokeWidth || 4;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
        for (let i = 1; i < stroke.points.length; i++) {
          const midX = (stroke.points[i - 1].x + stroke.points[i].x) / 2;
          const midY = (stroke.points[i - 1].y + stroke.points[i].y) / 2;
          ctx.quadraticCurveTo(stroke.points[i - 1].x, stroke.points[i - 1].y, midX, midY);
        }
        ctx.lineTo(stroke.points[stroke.points.length - 1].x, stroke.points[stroke.points.length - 1].y);
        ctx.stroke();
        ctx.restore();
      }
    }

    ctx.restore();

    // Render remote collaborator cursors and name badges in screen space
    const now = Date.now();
    for (const peer of collabPeers) {
      if (peer.cursor && now - peer.cursor.lastActive < 20000) {
        const screenPos = worldToScreen(peer.cursor.x, peer.cursor.y, viewport);

        ctx.save();
        ctx.translate(screenPos.x, screenPos.y);

        // Draw cursor pointer arrow
        ctx.fillStyle = peer.color || '#38bdf8';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, 16);
        ctx.lineTo(4, 12);
        ctx.lineTo(9, 18);
        ctx.lineTo(12, 16);
        ctx.lineTo(7, 10);
        ctx.lineTo(13, 10);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Draw Peer Name pill badge
        ctx.font = 'bold 11px "Google Sans", "Roboto", sans-serif';
        const textWidth = ctx.measureText(peer.name).width;
        const badgeW = textWidth + 12;
        const badgeH = 18;
        const badgeX = 12;
        const badgeY = 12;

        ctx.fillStyle = peer.color || '#38bdf8';
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 9);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.textBaseline = 'middle';
        ctx.fillText(peer.name, badgeX + 6, badgeY + badgeH / 2);

        ctx.restore();
      }
    }
  }, [elements, viewport, bgType, board.bgColor, selectedIds, liveStrokes, collabPeers]);

  // Keep Canvas Resized to Window
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      renderCanvas();
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [renderCanvas]);

  useEffect(() => {
    renderCanvas();
  }, [renderCanvas]);

  // ===================== POINTER EVENT HANDLING =====================

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    // Dismiss active text editor on canvas click
    if (editingTextElement) {
      commitTextEdit();
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;
    const worldPos = screenToWorld(screenX, screenY, viewport);

    dragStartPointRef.current = { x: screenX, y: screenY };

    // Pass event to Stylus & Palm Rejection manager
    const evaluation = stylusManagerRef.current.evaluatePointerDown(e);

    if (evaluation === 'palm-reject') {
      return; // Discard palm touch
    }

    if (evaluation === 'touch-navigation' || activeTool === 'hand' || e.buttons === 4) {
      // Pan canvas
      interactionModeRef.current = 'panning';
      setIsInteracting(true);
      return;
    }

    // 1. Check if clicking on a Transform Handle of selected elements
    if (selectedIds.length > 0) {
      const selectedElements = elements.filter((el) => selectedIds.includes(el.id));
      const bounds = getSelectionBounds(selectedElements);
      if (bounds) {
        const handles = getTransformHandles(bounds);
        const hitHandle = handles.find((h) => {
          const handleScreen = worldToScreen(h.x, h.y, viewport);
          return Math.hypot(handleScreen.x - screenX, handleScreen.y - screenY) <= 14;
        });

        if (hitHandle) {
          interactionModeRef.current = 'transform-handle';
          activeHandleRef.current = hitHandle.id;
          initialBoundingBoxRef.current = bounds;
          initialElementsSnapshotRef.current = JSON.parse(JSON.stringify(elements));
          setIsInteracting(true);
          return;
        }
      }
    }

    // 2. Selection Tool Handling
    if (activeTool === 'select') {
      // Hit test clicked elements (topmost first)
      const reversed = [...elements].reverse();
      const hit = reversed.find((el) => hitTestElement(worldPos.x, worldPos.y, el));

      if (hit) {
        if (e.shiftKey) {
          // Multi-selection toggle
          setSelectedIds((prev) =>
            prev.includes(hit.id) ? prev.filter((id) => id !== hit.id) : [...prev, hit.id]
          );
        } else if (!selectedIds.includes(hit.id)) {
          setSelectedIds([hit.id]);
        }

        // Start dragging selection
        interactionModeRef.current = 'dragging-selection';
        initialElementsSnapshotRef.current = JSON.parse(JSON.stringify(elements));
        setIsInteracting(true);
      } else {
        // Clicked on empty canvas -> Marquee selection
        if (!e.shiftKey) setSelectedIds([]);
        interactionModeRef.current = 'marquee';
        inProgressElementRef.current = {
          id: 'temp-marquee',
          type: 'rect',
          x: worldPos.x,
          y: worldPos.y,
          width: 0,
          height: 0,
          zIndex: 9999,
        };
        setIsInteracting(true);
      }
      return;
    }

    // 3. Eraser Tool Handling
    if (activeTool === 'eraser') {
      const hit = elements.find((el) => hitTestElement(worldPos.x, worldPos.y, el, 16));
      if (hit) {
        const updated = elements.filter((el) => el.id !== hit.id);
        pushHistory(updated);
        setSelectedIds([]);
      }
      return;
    }

    // 4. Sticky Note Tool Handling
    if (activeTool === 'sticky') {
      const newSticky: CanvasElement = {
        id: `sticky-${Date.now()}`,
        type: 'sticky',
        x: worldPos.x - 90,
        y: worldPos.y - 70,
        width: 200,
        height: 160,
        zIndex: elements.length + 1,
        stickyColor,
        text: 'New Note',
        fontSize: 16,
        fontFamily: 'handwritten',
      };
      const updated = [...elements, newSticky];
      pushHistory(updated);
      if (isCollaborating) sendElementUpsert(newSticky);
      setSelectedIds([newSticky.id]);
      setActiveTool('select');
      startTextEditing(newSticky);
      return;
    }

    // 5. Text Box Tool Handling
    if (activeTool === 'text') {
      const newText: CanvasElement = {
        id: `text-${Date.now()}`,
        type: 'text',
        x: worldPos.x,
        y: worldPos.y,
        width: 240,
        height: 50,
        zIndex: elements.length + 1,
        strokeColor,
        text: 'Type text here...',
        fontSize,
        fontWeight,
        fontStyle,
        textAlign,
      };
      const updated = [...elements, newText];
      pushHistory(updated);
      if (isCollaborating) sendElementUpsert(newText);
      setSelectedIds([newText.id]);
      setActiveTool('select');
      startTextEditing(newText);
      return;
    }

    // 6. Freehand Drawing Tools (Pen, Pencil, Highlighter)
    if (activeTool === 'pen' || activeTool === 'pencil' || activeTool === 'highlighter') {
      interactionModeRef.current = 'drawing';
      const pressure = stylusSettings.pressureSensitivity && e.pressure > 0 ? e.pressure : 0.5;
      const initialWidth =
        activeTool === 'pencil'
          ? 2
          : activeTool === 'highlighter'
          ? 24
          : calculatePressureWidth(strokeWidth, pressure, stylusSettings.pressureSensitivity);

      inProgressElementRef.current = {
        id: `stroke-${Date.now()}`,
        type: activeTool,
        x: worldPos.x,
        y: worldPos.y,
        width: 0,
        height: 0,
        zIndex: elements.length + 1,
        strokeColor,
        strokeWidth: initialWidth,
        opacity: activeTool === 'highlighter' ? 0.45 : opacity,
        points: [{ x: worldPos.x, y: worldPos.y, pressure }],
      };
      setIsInteracting(true);
      return;
    }

    // 7. Shape Tools
    if (['rect', 'rounded-rect', 'circle', 'triangle', 'diamond', 'arrow', 'line'].includes(activeTool)) {
      interactionModeRef.current = 'shape-create';
      inProgressElementRef.current = {
        id: `shape-${Date.now()}`,
        type: activeTool as any,
        x: worldPos.x,
        y: worldPos.y,
        width: 0,
        height: 0,
        zIndex: elements.length + 1,
        strokeColor,
        strokeWidth,
        fillColor,
        opacity,
      };
      setIsInteracting(true);
      return;
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;
    const worldPos = screenToWorld(screenX, screenY, viewport);

    // Broadcast cursor position to collaborators
    if (isCollaborating) {
      sendCursor(worldPos.x, worldPos.y);
    }

    const evaluation = stylusManagerRef.current.evaluatePointerMove(e);

    // Stylus hover cursor
    if (evaluation.action === 'hover') {
      setHoverPosition({ x: screenX, y: screenY });
      return;
    }

    if (hoverPosition) {
      setHoverPosition(null);
    }

    if (!isInteracting && interactionModeRef.current === 'none') {
      // If hovering near transform handles with select tool, update cursor
      return;
    }

    if (evaluation.action === 'palm-reject') {
      return;
    }

    // 1. Panning Canvas
    if (interactionModeRef.current === 'panning' || evaluation.action === 'nav-move') {
      const dx = screenX - dragStartPointRef.current.x;
      const dy = screenY - dragStartPointRef.current.y;
      dragStartPointRef.current = { x: screenX, y: screenY };

      setViewport((prev) => {
        const next = { ...prev, x: prev.x + dx, y: prev.y + dy };
        triggerAutosave(elements, next, bgType);
        return next;
      });
      return;
    }

    // 2. Drawing Stroke (Pen, Pencil, Highlighter)
    if (interactionModeRef.current === 'drawing' && inProgressElementRef.current) {
      const currentPoints = inProgressElementRef.current.points || [];
      const pressure = evaluation.pressure;
      const newPoints: StrokePoint[] = [...currentPoints, { x: worldPos.x, y: worldPos.y, pressure }];

      inProgressElementRef.current = {
        ...inProgressElementRef.current,
        points: newPoints,
      };

      if (isCollaborating) {
        sendLiveStrokePoint(
          inProgressElementRef.current.id,
          { x: worldPos.x, y: worldPos.y, pressure },
          inProgressElementRef.current.strokeColor || strokeColor,
          inProgressElementRef.current.strokeWidth || 4,
          false
        );
      }

      renderCanvas();
      return;
    }

    // 3. Shape Creation Drag
    if (interactionModeRef.current === 'shape-create' && inProgressElementRef.current) {
      const startX = inProgressElementRef.current.x;
      const startY = inProgressElementRef.current.y;
      const w = worldPos.x - startX;
      const h = worldPos.y - startY;

      inProgressElementRef.current = {
        ...inProgressElementRef.current,
        width: w,
        height: h,
      };
      renderCanvas();
      return;
    }

    // 4. Marquee Selection Drag
    if (interactionModeRef.current === 'marquee' && inProgressElementRef.current) {
      const startWorld = screenToWorld(dragStartPointRef.current.x, dragStartPointRef.current.y, viewport);
      const w = worldPos.x - startWorld.x;
      const h = worldPos.y - startWorld.y;

      inProgressElementRef.current = {
        ...inProgressElementRef.current,
        x: Math.min(startWorld.x, worldPos.x),
        y: Math.min(startWorld.y, worldPos.y),
        width: Math.abs(w),
        height: Math.abs(h),
      };

      // Find intersecting elements
      const hitIds = elements
        .filter((el) => elementIntersectsRect(el, inProgressElementRef.current!.x, inProgressElementRef.current!.y, inProgressElementRef.current!.width, inProgressElementRef.current!.height))
        .map((el) => el.id);

      setSelectedIds(hitIds);
      renderCanvas();
      return;
    }

    // 5. Dragging Selection
    if (interactionModeRef.current === 'dragging-selection') {
      const dxWorld = (screenX - dragStartPointRef.current.x) / viewport.zoom;
      const dyWorld = (screenY - dragStartPointRef.current.y) / viewport.zoom;

      const updated = initialElementsSnapshotRef.current.map((el) => {
        if (selectedIds.includes(el.id)) {
          if (el.points) {
            return {
              ...el,
              points: el.points.map((p) => ({ x: p.x + dxWorld, y: p.y + dyWorld, pressure: p.pressure })),
            };
          }
          return {
            ...el,
            x: el.x + dxWorld,
            y: el.y + dyWorld,
          };
        }
        return el;
      });

      setElements(updated);
      return;
    }

    // 6. Transform Handle Resizing
    if (
      interactionModeRef.current === 'transform-handle' &&
      activeHandleRef.current &&
      initialBoundingBoxRef.current
    ) {
      const dxWorld = (screenX - dragStartPointRef.current.x) / viewport.zoom;
      const dyWorld = (screenY - dragStartPointRef.current.y) / viewport.zoom;

      const newBox = calculateResizedBox(
        initialBoundingBoxRef.current,
        activeHandleRef.current,
        dxWorld,
        dyWorld,
        e.shiftKey
      );

      const scaleX = newBox.width / initialBoundingBoxRef.current.width;
      const scaleY = newBox.height / initialBoundingBoxRef.current.height;

      const updated = initialElementsSnapshotRef.current.map((el) => {
        if (selectedIds.includes(el.id)) {
          const relX = (el.x - initialBoundingBoxRef.current!.minX) * scaleX;
          const relY = (el.y - initialBoundingBoxRef.current!.minY) * scaleY;
          return {
            ...el,
            x: newBox.minX + relX,
            y: newBox.minY + relY,
            width: el.width * scaleX,
            height: el.height * scaleY,
          };
        }
        return el;
      });

      setElements(updated);
      return;
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    stylusManagerRef.current.handlePointerUp(e);

    // Finalize drawing or shape creation
    if (interactionModeRef.current === 'drawing' && inProgressElementRef.current) {
      const newEl = inProgressElementRef.current;
      inProgressElementRef.current = null;
      if (newEl.points && newEl.points.length > 1) {
        let recognizedShape: CanvasElement | null = null;
        if (shapeRecognition && (newEl.type === 'pen' || newEl.type === 'pencil')) {
          recognizedShape = recognizeShape(
            newEl.points,
            newEl.strokeColor || strokeColor,
            newEl.strokeWidth || 4,
            newEl.opacity ?? 1
          );
        }

        if (recognizedShape) {
          recognizedShape = {
            ...recognizedShape,
            zIndex: elements.length + 1,
          };
          // Push initial elements and raw hand-drawn sketch to history stack.
          // This allows Undo to first revert the shape back to the user's hand-drawn sketch,
          // and a second Undo to remove the sketch completely.
          setHistoryPast((prev) => [...prev.slice(-30), elements, [...elements, newEl]]);
          setHistoryFuture([]);
          const nextElements = [...elements, recognizedShape];
          setElements(nextElements);
          triggerAutosave(nextElements, viewport, bgType);

          if (isCollaborating) {
            sendLiveStrokePoint(
              newEl.id,
              newEl.points[newEl.points.length - 1],
              newEl.strokeColor || strokeColor,
              newEl.strokeWidth || 4,
              true
            );
            sendElementUpsert(recognizedShape);
          }
        } else {
          pushHistory([...elements, newEl]);
          if (isCollaborating) {
            sendLiveStrokePoint(
              newEl.id,
              newEl.points[newEl.points.length - 1],
              newEl.strokeColor || strokeColor,
              newEl.strokeWidth || 4,
              true
            );
            sendElementUpsert(newEl);
          }
        }
      }
    } else if (interactionModeRef.current === 'shape-create' && inProgressElementRef.current) {
      const shape = inProgressElementRef.current;
      inProgressElementRef.current = null;
      // Normalize negative dimensions
      let finalX = shape.x;
      let finalY = shape.y;
      let finalW = shape.width;
      let finalH = shape.height;

      if (['rect', 'rounded-rect', 'circle', 'triangle', 'diamond'].includes(shape.type)) {
        if (finalW < 0) {
          finalX += finalW;
          finalW = Math.abs(finalW);
        }
        if (finalH < 0) {
          finalY += finalH;
          finalH = Math.abs(finalH);
        }
      }

      if (Math.abs(finalW) > 5 || Math.abs(finalH) > 5) {
        const finalShape = { ...shape, x: finalX, y: finalY, width: finalW, height: finalH };
        pushHistory([...elements, finalShape]);
        setSelectedIds([finalShape.id]);
        setActiveTool('select');
        if (isCollaborating) {
          sendElementUpsert(finalShape);
        }
      }
    } else if (
      interactionModeRef.current === 'dragging-selection' ||
      interactionModeRef.current === 'transform-handle'
    ) {
      pushHistory(elements);
      if (isCollaborating) {
        elements.filter((el) => selectedIds.includes(el.id)).forEach(sendElementUpsert);
      }
    }

    inProgressElementRef.current = null;
    interactionModeRef.current = 'none';
    setIsInteracting(false);
    activeHandleRef.current = null;
    initialBoundingBoxRef.current = null;
    renderCanvas();
  };

  // Mouse Wheel: Pan & Smooth Zoom
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const cursorX = e.clientX - rect.left;
    const cursorY = e.clientY - rect.top;

    if (e.ctrlKey || e.metaKey) {
      // Zoom centered at cursor
      const zoomFactor = Math.pow(0.992, e.deltaY);
      const newZoom = Math.min(4.0, Math.max(0.15, viewport.zoom * zoomFactor));

      const worldCursor = screenToWorld(cursorX, cursorY, viewport);
      const newViewport = {
        x: cursorX - worldCursor.x * newZoom,
        y: cursorY - worldCursor.y * newZoom,
        zoom: newZoom,
      };

      setViewport(newViewport);
      triggerAutosave(elements, newViewport, bgType);
    } else {
      // Pan
      const newViewport = {
        ...viewport,
        x: viewport.x - e.deltaX,
        y: viewport.y - e.deltaY,
      };
      setViewport(newViewport);
      triggerAutosave(elements, newViewport, bgType);
    }
  };

  // Inline Text Editing
  const startTextEditing = (el: CanvasElement) => {
    setEditingTextElement({
      id: el.id,
      text: el.text || '',
      x: el.x,
      y: el.y,
      width: el.width,
      height: el.height,
      fontSize: el.fontSize || 16,
      stickyColor: el.stickyColor,
    });
  };

  const commitTextEdit = () => {
    if (!editingTextElement) return;
    const updated = elements.map((el) => {
      if (el.id === editingTextElement.id) {
        const withNewText = {
          ...el,
          text: editingTextElement.text,
        };
        if (isCollaborating) {
          sendElementUpsert(withNewText);
        }
        return withNewText;
      }
      return el;
    });
    pushHistory(updated);
    setEditingTextElement(null);
  };

  // Double click to edit text / sticky
  const handleDoubleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;
    const worldPos = screenToWorld(screenX, screenY, viewport);

    const hit = [...elements].reverse().find((el) => hitTestElement(worldPos.x, worldPos.y, el));
    if (hit && (hit.type === 'text' || hit.type === 'sticky' || hit.type === 'rounded-rect')) {
      startTextEditing(hit);
    }
  };

  // Upload image to canvas
  const handleUploadImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const img = new Image();
      img.onload = () => {
        const centerWorld = screenToWorld(window.innerWidth / 2, window.innerHeight / 2, viewport);
        const maxDim = 380;
        let w = img.width;
        let h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) {
            h = (h / w) * maxDim;
            w = maxDim;
          } else {
            w = (w / h) * maxDim;
            h = maxDim;
          }
        }

        const newImgElement: CanvasElement = {
          id: `img-${Date.now()}`,
          type: 'image',
          x: centerWorld.x - w / 2,
          y: centerWorld.y - h / 2,
          width: w,
          height: h,
          zIndex: elements.length + 1,
          imageUrl: dataUrl,
          originalWidth: img.width,
          originalHeight: img.height,
        };

        const updated = [...elements, newImgElement];
        pushHistory(updated);
        setSelectedIds([newImgElement.id]);
        setActiveTool('select');
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  // Zoom Helpers
  const handleZoomIn = () => {
    const newZoom = Math.min(4.0, viewport.zoom * 1.25);
    const newViewport = {
      x: window.innerWidth / 2 - ((window.innerWidth / 2 - viewport.x) * newZoom) / viewport.zoom,
      y: window.innerHeight / 2 - ((window.innerHeight / 2 - viewport.y) * newZoom) / viewport.zoom,
      zoom: newZoom,
    };
    setViewport(newViewport);
    triggerAutosave(elements, newViewport, bgType);
  };

  const handleZoomOut = () => {
    const newZoom = Math.max(0.15, viewport.zoom / 1.25);
    const newViewport = {
      x: window.innerWidth / 2 - ((window.innerWidth / 2 - viewport.x) * newZoom) / viewport.zoom,
      y: window.innerHeight / 2 - ((window.innerHeight / 2 - viewport.y) * newZoom) / viewport.zoom,
      zoom: newZoom,
    };
    setViewport(newViewport);
    triggerAutosave(elements, newViewport, bgType);
  };

  const handleResetZoom = () => {
    const newViewport = { x: 0, y: 0, zoom: 1.0 };
    setViewport(newViewport);
    triggerAutosave(elements, newViewport, bgType);
  };

  return (
    <div
      ref={containerRef}
      className="relative w-screen h-screen overflow-hidden bg-[var(--md-sys-color-background)] select-none"
    >
      {/* Floating Toolbar and Header Controls */}
      <Toolbar
        activeTool={activeTool}
        onSelectTool={setActiveTool}
        strokeColor={strokeColor}
        onChangeStrokeColor={setStrokeColor}
        strokeWidth={strokeWidth}
        onChangeStrokeWidth={setStrokeWidth}
        fillColor={fillColor}
        onChangeFillColor={setFillColor}
        opacity={opacity}
        onChangeOpacity={setOpacity}
        stickyColor={stickyColor}
        onChangeStickyColor={setStickyColor}
        fontSize={fontSize}
        onChangeFontSize={setFontSize}
        fontWeight={fontWeight}
        onChangeFontWeight={setFontWeight}
        fontStyle={fontStyle}
        onChangeFontStyle={setFontStyle}
        textAlign={textAlign}
        onChangeTextAlign={setTextAlign}
        canUndo={historyPast.length > 0}
        canRedo={historyFuture.length > 0}
        onUndo={handleUndo}
        onRedo={handleRedo}
        selectedElementsCount={selectedIds.length}
        onDeleteSelected={() => {
          const updated = elements.filter((el) => !selectedIds.includes(el.id));
          if (isCollaborating) {
            selectedIds.forEach(sendElementDelete);
          }
          pushHistory(updated);
          setSelectedIds([]);
        }}
        onDuplicateSelected={() => {
          const duplicates = elements
            .filter((el) => selectedIds.includes(el.id))
            .map((el) => {
              const dup = {
                ...JSON.parse(JSON.stringify(el)),
                id: `${el.id}-copy-${Date.now()}`,
                x: el.x + 25,
                y: el.y + 25,
                zIndex: elements.length + 1,
              };
              if (isCollaborating) sendElementUpsert(dup);
              return dup;
            });
          const updated = [...elements, ...duplicates];
          pushHistory(updated);
          setSelectedIds(duplicates.map((d) => d.id));
        }}
        onUploadImage={handleUploadImage}
        zoom={viewport.zoom}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onResetZoom={handleResetZoom}
        bgType={bgType}
        onChangeBgType={(bg) => {
          setBgType(bg);
          triggerAutosave(elements, viewport, bg);
        }}
        boardTitle={boardTitle}
        onBackToDashboard={onBackToDashboard}
        onExportPNG={() => exportBoardToPNG(board, { selectedOnly: false })}
        onExportJSON={() => exportBoardToJSON(board)}
        isSaving={isSaving}
        isCollaborating={isCollaborating}
        peersCount={collabPeers.length}
        peers={collabPeers}
        onOpenCollaboration={() => setIsCollabModalOpen(true)}
      />

      {/* Main HTML5 Canvas */}
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onWheel={handleWheel}
        onDoubleClick={handleDoubleClick}
        style={{
          touchAction: 'none',
          cursor:
            activeTool === 'hand'
              ? 'grab'
              : activeTool === 'select'
              ? 'default'
              : activeTool === 'eraser'
              ? 'cell'
              : 'crosshair',
        }}
        className="absolute inset-0 block w-full h-full"
      />

      {/* Stylus Hover Ring Indicator */}
      {hoverPosition && stylusSettings.showHoverCursor && (
        <div
          className="pointer-events-none fixed -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-[var(--md-sys-color-primary)] bg-[var(--md-sys-color-primary)]/15 shadow-sm transition-transform duration-75"
          style={{
            left: hoverPosition.x,
            top: hoverPosition.y,
            width: Math.max(12, strokeWidth * 2.2),
            height: Math.max(12, strokeWidth * 2.2),
          }}
        />
      )}

      {/* Inline Text & Sticky Editor Overlay */}
      {editingTextElement && (
        <div
          className="fixed z-50 p-2 rounded-2xl shadow-2xl border border-[var(--md-sys-color-primary)] animate-in fade-in zoom-in-95"
          style={{
            left: worldToScreen(editingTextElement.x, editingTextElement.y, viewport).x,
            top: worldToScreen(editingTextElement.y, editingTextElement.y, viewport).y,
            width: Math.max(220, editingTextElement.width * viewport.zoom),
            backgroundColor: editingTextElement.stickyColor || 'var(--md-sys-color-surface-container-high)',
          }}
        >
          <textarea
            value={editingTextElement.text}
            onChange={(e) =>
              setEditingTextElement({
                ...editingTextElement,
                text: e.target.value,
              })
            }
            onKeyDown={(e) => {
              if (e.key === 'Escape') commitTextEdit();
            }}
            onBlur={commitTextEdit}
            autoFocus
            rows={4}
            className={`w-full bg-transparent border-0 outline-none resize-none font-medium ${
              editingTextElement.stickyColor ? 'text-slate-900' : 'text-[var(--md-sys-color-on-surface)]'
            }`}
            style={{
              fontSize: `${Math.max(14, editingTextElement.fontSize * viewport.zoom)}px`,
            }}
          />
          <div className="flex justify-end pt-1">
            <button
              onClick={commitTextEdit}
              className="px-3 py-1 rounded-full text-xs font-semibold bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Real-Time Collaboration Modal */}
      <CollaborationModal
        isOpen={isCollabModalOpen}
        onClose={() => setIsCollabModalOpen(false)}
        status={collabStatus}
        roomId={collabRoomId}
        peers={collabPeers}
        localPeer={localPeer}
        onStartCollaboration={(customRoomId) => {
          const target = customRoomId || `board-room-${board.id.replace(/[^a-zA-Z0-9]/g, '')}`;
          connectToRoom(target, {
            title: boardTitle,
            elements,
            bgType,
            bgColor: board.bgColor,
          });
        }}
        onLeaveCollaboration={leaveRoom}
        onUpdateLocalPeer={updateLocalPeer}
      />
    </div>
  );
};
