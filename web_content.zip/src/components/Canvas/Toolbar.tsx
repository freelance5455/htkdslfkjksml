import React, { useState, useRef } from 'react';
import {
  MousePointer,
  Hand,
  Pen,
  Pencil,
  Highlighter,
  Eraser,
  Square,
  Circle,
  Triangle,
  ArrowRight,
  Minus,
  StickyNote,
  Type,
  Image as ImageIcon,
  Undo2,
  Redo2,
  Trash2,
  Copy,
  ZoomIn,
  ZoomOut,
  Maximize2,
  ChevronDown,
  ArrowLeft,
  Check,
  Download,
  Grid,
  Sparkles,
  Bold,
  Italic,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Users,
  Radio,
} from 'lucide-react';
import { ToolType, CanvasElement, CanvasBackgroundType } from '../../canvas/types';

interface ToolbarProps {
  activeTool: ToolType;
  onSelectTool: (tool: ToolType) => void;
  // Stroke & Colors
  strokeColor: string;
  onChangeStrokeColor: (color: string) => void;
  strokeWidth: number;
  onChangeStrokeWidth: (width: number) => void;
  fillColor: string;
  onChangeFillColor: (color: string) => void;
  opacity: number;
  onChangeOpacity: (opacity: number) => void;
  // Sticky & Text properties
  stickyColor: string;
  onChangeStickyColor: (color: string) => void;
  fontSize: number;
  onChangeFontSize: (size: number) => void;
  fontWeight: 'normal' | 'bold';
  onChangeFontWeight: (weight: 'normal' | 'bold') => void;
  fontStyle: 'normal' | 'italic';
  onChangeFontStyle: (style: 'normal' | 'italic') => void;
  textAlign: 'left' | 'center' | 'right';
  onChangeTextAlign: (align: 'left' | 'center' | 'right') => void;
  // History & Selection
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  selectedElementsCount: number;
  onDeleteSelected: () => void;
  onDuplicateSelected: () => void;
  // Image upload
  onUploadImage: (file: File) => void;
  // Canvas Viewport & Grid
  zoom: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetZoom: () => void;
  bgType: CanvasBackgroundType;
  onChangeBgType: (bg: CanvasBackgroundType) => void;
  // Board meta
  boardTitle: string;
  onBackToDashboard: () => void;
  onExportPNG: () => void;
  onExportJSON: () => void;
  isSaving: boolean;
  // Collaboration
  isCollaborating?: boolean;
  peersCount?: number;
  peers?: Array<{ id: string; name: string; color: string }>;
  onOpenCollaboration?: () => void;
}

const COLOR_PALETTE = [
  '#f8fafc', // White/Light
  '#94a3b8', // Slate
  '#38bdf8', // Sky Blue
  '#818cf8', // Indigo
  '#c084fc', // Purple
  '#f43f5e', // Rose
  '#fbbf24', // Amber
  '#34d399', // Emerald
  '#0f172a', // Dark
];

const STICKY_COLORS = [
  { label: 'Amber', hex: '#fef08a', stroke: '#eab308' },
  { label: 'Rose', hex: '#fbcfe8', stroke: '#f43f5e' },
  { label: 'Emerald', hex: '#bbf7d0', stroke: '#10b981' },
  { label: 'Sky', hex: '#bae6fd', stroke: '#0284c7' },
  { label: 'Lavender', hex: '#e9d5ff', stroke: '#a855f7' },
  { label: 'Peach', hex: '#fed7aa', stroke: '#f97316' },
];

export const Toolbar: React.FC<ToolbarProps> = ({
  activeTool,
  onSelectTool,
  strokeColor,
  onChangeStrokeColor,
  strokeWidth,
  onChangeStrokeWidth,
  fillColor,
  onChangeFillColor,
  opacity,
  onChangeOpacity,
  stickyColor,
  onChangeStickyColor,
  fontSize,
  onChangeFontSize,
  fontWeight,
  onChangeFontWeight,
  fontStyle,
  onChangeFontStyle,
  textAlign,
  onChangeTextAlign,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  selectedElementsCount,
  onDeleteSelected,
  onDuplicateSelected,
  onUploadImage,
  zoom,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  bgType,
  onChangeBgType,
  boardTitle,
  onBackToDashboard,
  onExportPNG,
  onExportJSON,
  isSaving,
  isCollaborating = false,
  peersCount = 0,
  peers = [],
  onOpenCollaboration,
}) => {
  const [showShapeMenu, setShowShapeMenu] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showGridMenu, setShowGridMenu] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isShapeTool = ['rect', 'rounded-rect', 'circle', 'triangle', 'diamond', 'line', 'arrow'].includes(activeTool);

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadImage(file);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <>
      {/* Top Floating App Bar */}
      <header className="fixed top-4 left-4 right-4 z-40 flex items-center justify-between pointer-events-none">
        
        {/* Left: Back button, Title & Saving Indicator */}
        <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-[var(--md-sys-color-surface-container)]/90 backdrop-blur-md border border-[var(--md-sys-color-outline-variant)] shadow-lg pointer-events-auto">
          <button
            onClick={onBackToDashboard}
            aria-label="Back to Dashboard"
            className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] transition"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          
          <div className="flex items-center gap-2 pr-1">
            <span className="text-xs font-bold text-[var(--md-sys-color-on-surface)] max-w-[140px] sm:max-w-xs truncate">
              {boardTitle}
            </span>
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-[var(--md-sys-color-surface-container-high)] text-[10px] font-medium text-[var(--md-sys-color-on-surface-variant)]">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  isSaving ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'
                }`}
              />
              <span className="hidden sm:inline">{isSaving ? 'Saving...' : 'Saved'}</span>
            </div>
          </div>
        </div>

        {/* Right: History, Grid, Zoom & Export */}
        <div className="flex items-center gap-1.5 px-2 py-1.5 rounded-full bg-[var(--md-sys-color-surface-container)]/90 backdrop-blur-md border border-[var(--md-sys-color-outline-variant)] shadow-lg pointer-events-auto">
          {/* Undo / Redo */}
          <button
            onClick={onUndo}
            disabled={!canUndo}
            aria-label="Undo"
            className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] disabled:opacity-30 disabled:pointer-events-none text-[var(--md-sys-color-on-surface)] transition"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            aria-label="Redo"
            className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] disabled:opacity-30 disabled:pointer-events-none text-[var(--md-sys-color-on-surface)] transition"
          >
            <Redo2 className="w-4 h-4" />
          </button>

          <div className="w-[1px] h-4 bg-[var(--md-sys-color-outline-variant)] mx-0.5" />

          {/* Grid Toggle Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowGridMenu(!showGridMenu)}
              aria-label="Canvas Grid Style"
              className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] transition"
            >
              <Grid className="w-4 h-4" />
            </button>
            {showGridMenu && (
              <div className="absolute right-0 top-full mt-2 w-32 rounded-2xl bg-[var(--md-sys-color-surface-container-highest)] shadow-xl border border-[var(--md-sys-color-outline-variant)] py-1 z-50 animate-in fade-in">
                {(['dots', 'grid', 'plain'] as const).map((g) => (
                  <button
                    key={g}
                    onClick={() => {
                      onChangeBgType(g);
                      setShowGridMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-1.5 text-xs capitalize text-left transition ${
                      bgType === g
                        ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] font-medium'
                        : 'text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container)]'
                    }`}
                  >
                    <span>{g}</span>
                    {bgType === g && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-0.5 px-1">
            <button
              onClick={onZoomOut}
              aria-label="Zoom out"
              className="p-1 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] transition"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onResetZoom}
              title="Reset Zoom to 100%"
              className="px-1.5 py-0.5 text-[11px] font-semibold text-[var(--md-sys-color-on-surface)] min-w-[42px] text-center hover:bg-[var(--md-sys-color-surface-container-high)] rounded-md transition"
            >
              {Math.round(zoom * 100)}%
            </button>
            <button
              onClick={onZoomIn}
              aria-label="Zoom in"
              className="p-1 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] transition"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="w-[1px] h-4 bg-[var(--md-sys-color-outline-variant)] mx-0.5" />

          {/* Export Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              aria-label="Export board"
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-xs font-semibold hover:opacity-95 transition shadow-sm active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export</span>
            </button>

            {showExportMenu && (
              <div className="absolute right-0 top-full mt-2 w-44 rounded-2xl bg-[var(--md-sys-color-surface-container-highest)] shadow-2xl border border-[var(--md-sys-color-outline-variant)] py-1.5 z-50 animate-in fade-in">
                <button
                  onClick={() => {
                    onExportPNG();
                    setShowExportMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container)] transition text-left"
                >
                  <Download className="w-3.5 h-3.5 text-[var(--md-sys-color-primary)]" />
                  <span>Download PNG Image</span>
                </button>
                <button
                  onClick={() => {
                    onExportJSON();
                    setShowExportMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container)] transition text-left"
                >
                  <Download className="w-3.5 h-3.5 text-[var(--md-sys-color-secondary)]" />
                  <span>Download .xvboard</span>
                </button>
              </div>
            )}
          </div>

          <div className="w-[1px] h-4 bg-[var(--md-sys-color-outline-variant)] mx-0.5" />

          {/* Real-Time Collaboration Button */}
          {onOpenCollaboration && (
            <div className="flex items-center gap-1.5">
              <button
                onClick={onOpenCollaboration}
                aria-label="Open Real-Time Collaboration"
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition shadow-sm active:scale-95 ${
                  isCollaborating
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] hover:bg-[var(--md-sys-color-surface-container-highest)]'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">
                  {isCollaborating ? `Live (${peersCount + 1})` : 'Collaborate'}
                </span>
                {isCollaborating && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </button>

              {/* Online Collaborator Avatar Stack */}
              {peers && peers.length > 0 && (
                <div
                  onClick={onOpenCollaboration}
                  title="Collaborators active in this room"
                  className="hidden md:flex items-center -space-x-1.5 pl-0.5 cursor-pointer"
                >
                  {peers.slice(0, 3).map((p) => (
                    <div
                      key={p.id}
                      title={p.name}
                      className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[9px] font-bold border border-[var(--md-sys-color-surface)] shadow-sm"
                      style={{ backgroundColor: p.color }}
                    >
                      {p.name.charAt(0)}
                    </div>
                  ))}
                  {peers.length > 3 && (
                    <div className="w-5 h-5 rounded-full flex items-center justify-center bg-slate-700 text-white text-[8px] font-semibold border border-[var(--md-sys-color-surface)]">
                      +{peers.length - 3}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </header>

      {/* Floating Main Material 3 Bottom Toolbar */}
      <nav
        aria-label="Canvas Tools"
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex flex-col items-center gap-2 pointer-events-none select-none max-w-[95vw]"
      >
        
        {/* Secondary Tool Properties Sub-bar */}
        {(activeTool === 'pen' ||
          activeTool === 'pencil' ||
          activeTool === 'highlighter' ||
          isShapeTool ||
          activeTool === 'text' ||
          activeTool === 'sticky' ||
          selectedElementsCount > 0) && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[var(--md-sys-color-surface-container)]/95 backdrop-blur-md border border-[var(--md-sys-color-outline-variant)] shadow-lg pointer-events-auto animate-in fade-in slide-in-from-bottom-2">
            
            {/* Color Swatches */}
            {activeTool !== 'sticky' && (
              <div className="flex items-center gap-1.5 pr-1">
                {COLOR_PALETTE.map((c) => (
                  <button
                    key={c}
                    onClick={() => onChangeStrokeColor(c)}
                    className={`w-5 h-5 rounded-full border border-black/20 transition-transform ${
                      strokeColor.toLowerCase() === c.toLowerCase() ? 'scale-125 ring-2 ring-[var(--md-sys-color-primary)]' : 'hover:scale-110'
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
                {/* Custom Color Input */}
                <input
                  type="color"
                  value={strokeColor}
                  onChange={(e) => onChangeStrokeColor(e.target.value)}
                  className="w-5 h-5 rounded-full cursor-pointer bg-transparent border-0"
                  title="Pick custom color"
                />
              </div>
            )}

            {/* Sticky Color Swatches */}
            {activeTool === 'sticky' && (
              <div className="flex items-center gap-1.5 pr-1">
                {STICKY_COLORS.map((sc) => (
                  <button
                    key={sc.hex}
                    onClick={() => onChangeStickyColor(sc.hex)}
                    className={`w-6 h-6 rounded-full border transition-transform ${
                      stickyColor === sc.hex ? 'scale-125 ring-2 ring-[var(--md-sys-color-primary)]' : 'hover:scale-110'
                    }`}
                    style={{ backgroundColor: sc.hex, borderColor: sc.stroke }}
                  />
                ))}
              </div>
            )}

            {/* Stroke Thickness (for pen/pencil/highlighter/shapes) */}
            {(activeTool === 'pen' || activeTool === 'pencil' || activeTool === 'highlighter' || isShapeTool) && (
              <div className="flex items-center gap-1 pl-1 border-l border-[var(--md-sys-color-outline-variant)]">
                {[2, 4, 8, 16, 24].map((w) => (
                  <button
                    key={w}
                    onClick={() => onChangeStrokeWidth(w)}
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition ${
                      strokeWidth === w
                        ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] font-bold'
                        : 'hover:bg-[var(--md-sys-color-surface-container-high)]'
                    }`}
                  >
                    <span
                      className="rounded-full bg-current"
                      style={{ width: Math.max(3, w * 0.7), height: Math.max(3, w * 0.7) }}
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Typography controls (for Text Tool) */}
            {activeTool === 'text' && (
              <div className="flex items-center gap-1 pl-1 border-l border-[var(--md-sys-color-outline-variant)]">
                {/* Font Size */}
                <select
                  value={fontSize}
                  onChange={(e) => onChangeFontSize(Number(e.target.value))}
                  className="text-xs bg-transparent text-[var(--md-sys-color-on-surface)] rounded px-1 py-0.5 outline-none font-medium"
                >
                  <option value={14} className="bg-slate-800">14px</option>
                  <option value={18} className="bg-slate-800">18px</option>
                  <option value={24} className="bg-slate-800">24px</option>
                  <option value={32} className="bg-slate-800">32px</option>
                  <option value={48} className="bg-slate-800">48px</option>
                </select>

                <button
                  onClick={() => onChangeFontWeight(fontWeight === 'bold' ? 'normal' : 'bold')}
                  className={`p-1 rounded ${fontWeight === 'bold' ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]' : 'hover:bg-slate-700/50'}`}
                >
                  <Bold className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onChangeFontStyle(fontStyle === 'italic' ? 'normal' : 'italic')}
                  className={`p-1 rounded ${fontStyle === 'italic' ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]' : 'hover:bg-slate-700/50'}`}
                >
                  <Italic className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Selection actions: Duplicate / Delete */}
            {selectedElementsCount > 0 && (
              <div className="flex items-center gap-1 pl-1 border-l border-[var(--md-sys-color-outline-variant)]">
                <button
                  onClick={onDuplicateSelected}
                  title="Duplicate selection"
                  className="p-1.5 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] transition"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={onDeleteSelected}
                  title="Delete selection"
                  className="p-1.5 rounded-full hover:bg-rose-500/20 text-rose-400 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Primary Floating Toolbar Pill */}
        <div className="flex items-center gap-1 p-1.5 rounded-full bg-[var(--md-sys-color-surface-container)]/95 backdrop-blur-md border border-[var(--md-sys-color-outline-variant)] shadow-2xl pointer-events-auto">
          
          {/* Select Tool */}
          <button
            onClick={() => onSelectTool('select')}
            aria-label="Select tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'select'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <MousePointer className="w-5 h-5" />
          </button>

          {/* Hand / Pan Tool */}
          <button
            onClick={() => onSelectTool('hand')}
            aria-label="Hand Pan tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'hand'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <Hand className="w-5 h-5" />
          </button>

          <div className="w-[1px] h-5 bg-[var(--md-sys-color-outline-variant)] mx-0.5" />

          {/* Pen (Smooth Pressure) */}
          <button
            onClick={() => onSelectTool('pen')}
            aria-label="Pen tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'pen'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <Pen className="w-5 h-5" />
          </button>

          {/* Pencil (Fine) */}
          <button
            onClick={() => onSelectTool('pencil')}
            aria-label="Pencil tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'pencil'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <Pencil className="w-5 h-5" />
          </button>

          {/* Highlighter */}
          <button
            onClick={() => onSelectTool('highlighter')}
            aria-label="Highlighter tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'highlighter'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <Highlighter className="w-5 h-5" />
          </button>

          {/* Eraser */}
          <button
            onClick={() => onSelectTool('eraser')}
            aria-label="Eraser tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'eraser'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <Eraser className="w-5 h-5" />
          </button>

          <div className="w-[1px] h-5 bg-[var(--md-sys-color-outline-variant)] mx-0.5" />

          {/* Shapes Dropdown / Flyout */}
          <div className="relative">
            <button
              onClick={() => setShowShapeMenu(!showShapeMenu)}
              aria-label="Shapes tool"
              className={`flex items-center gap-0.5 p-2.5 rounded-full transition ${
                isShapeTool
                  ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                  : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
              }`}
            >
              {activeTool === 'circle' && <Circle className="w-5 h-5" />}
              {activeTool === 'triangle' && <Triangle className="w-5 h-5" />}
              {activeTool === 'arrow' && <ArrowRight className="w-5 h-5" />}
              {activeTool === 'line' && <Minus className="w-5 h-5" />}
              {!['circle', 'triangle', 'arrow', 'line'].includes(activeTool) && <Square className="w-5 h-5" />}
              <ChevronDown className="w-3 h-3 -mr-1" />
            </button>

            {showShapeMenu && (
              <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 flex items-center gap-1.5 p-1.5 rounded-2xl bg-[var(--md-sys-color-surface-container-highest)] shadow-xl border border-[var(--md-sys-color-outline-variant)] z-50 animate-in fade-in">
                <button
                  onClick={() => { onSelectTool('rect'); setShowShapeMenu(false); }}
                  title="Rectangle"
                  className="p-2 rounded-xl hover:bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)]"
                >
                  <Square className="w-4 h-4" />
                </button>
                <button
                  onClick={() => { onSelectTool('rounded-rect'); setShowShapeMenu(false); }}
                  title="Rounded Rectangle"
                  className="p-2 rounded-xl hover:bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)] font-semibold text-xs"
                >
                  ▢
                </button>
                <button
                  onClick={() => { onSelectTool('circle'); setShowShapeMenu(false); }}
                  title="Circle / Ellipse"
                  className="p-2 rounded-xl hover:bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)]"
                >
                  <Circle className="w-4 h-4" />
                </button>
                <button
                  onClick={() => { onSelectTool('triangle'); setShowShapeMenu(false); }}
                  title="Triangle"
                  className="p-2 rounded-xl hover:bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)]"
                >
                  <Triangle className="w-4 h-4" />
                </button>
                <button
                  onClick={() => { onSelectTool('arrow'); setShowShapeMenu(false); }}
                  title="Arrow"
                  className="p-2 rounded-xl hover:bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)]"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => { onSelectTool('line'); setShowShapeMenu(false); }}
                  title="Straight Line"
                  className="p-2 rounded-xl hover:bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)]"
                >
                  <Minus className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Sticky Note */}
          <button
            onClick={() => onSelectTool('sticky')}
            aria-label="Sticky note tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'sticky'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <StickyNote className="w-5 h-5" />
          </button>

          {/* Text Box */}
          <button
            onClick={() => onSelectTool('text')}
            aria-label="Text box tool"
            className={`p-2.5 rounded-full transition ${
              activeTool === 'text'
                ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)]'
            }`}
          >
            <Type className="w-5 h-5" />
          </button>

          {/* Image Insertion */}
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={handleImageFile}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            aria-label="Insert image"
            className="p-2.5 rounded-full text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-high)] transition"
          >
            <ImageIcon className="w-5 h-5" />
          </button>

        </div>
      </nav>
    </>
  );
};
