import React, { useState, useRef } from 'react';
import { X, Video, Music, Volume2, VolumeX, Eye, Save, Upload, Check, ChevronDown, Sparkles } from 'lucide-react';
import { Alarm, MediaType, PresetMediaItem } from '../types/alarm';
import { PRESET_MEDIA_ITEMS, saveUserMediaFile, getMediaPlaybackUrl } from '../utils/mediaStore';
import { WEEKDAY_LABELS, formatAlarmTime } from '../utils/alarmEngine';

interface CreateAlarmModalProps {
  isOpen: boolean;
  editingAlarm?: Alarm | null;
  onClose: () => void;
  onSave: (alarmData: Partial<Alarm>) => void;
  is24h: boolean;
}

export const CreateAlarmModal: React.FC<CreateAlarmModalProps> = ({
  isOpen,
  editingAlarm,
  onClose,
  onSave,
  is24h,
}) => {
  if (!isOpen) return null;

  const initialDate = editingAlarm
    ? { hour: editingAlarm.hour, minute: editingAlarm.minute }
    : { hour: 7, minute: 30 };

  const [hour, setHour] = useState<number>(initialDate.hour);
  const [minute, setMinute] = useState<number>(initialDate.minute);
  const [period, setPeriod] = useState<'AM' | 'PM'>(initialDate.hour >= 12 ? 'PM' : 'AM');
  const [alarmLabel, setAlarmLabel] = useState<string>(editingAlarm?.alarmLabel || 'Morning WakeUp');
  const [repeatDays, setRepeatDays] = useState<number[]>(editingAlarm?.repeatDays || [1, 2, 3, 4, 5]);
  const [volume, setVolume] = useState<number>(editingAlarm?.volume ?? 85);
  const [gradualVolumeEnabled, setGradualVolumeEnabled] = useState<boolean>(editingAlarm?.gradualVolumeEnabled ?? true);
  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(editingAlarm?.vibrationEnabled ?? true);
  const [snoozeDuration, setSnoozeDuration] = useState<number>(editingAlarm?.snoozeDuration || 5);
  const [customSnooze, setCustomSnooze] = useState<string>('');

  // Selected Media state
  const [selectedMediaType, setSelectedMediaType] = useState<MediaType>(editingAlarm?.mediaType || 'video');
  const [mediaUri, setMediaUri] = useState<string>(editingAlarm?.mediaUri || PRESET_MEDIA_ITEMS[0].id);
  const [mediaName, setMediaName] = useState<string>(editingAlarm?.mediaName || PRESET_MEDIA_ITEMS[0].name);
  const [mediaThumbnail, setMediaThumbnail] = useState<string | undefined>(editingAlarm?.mediaThumbnail || PRESET_MEDIA_ITEMS[0].thumbnail);

  // File Uploading & Preview state
  const [isUploading, setIsUploading] = useState(false);
  const [previewingMedia, setPreviewingMedia] = useState<{ url: string; isVideo: boolean; name: string } | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  const videoFileInputRef = useRef<HTMLInputElement>(null);
  const audioFileInputRef = useRef<HTMLInputElement>(null);

  // Handle 12-hour hour change
  const handleHourChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = parseInt(e.target.value, 10);
    if (is24h) {
      setHour(val);
    } else {
      let h24 = val % 12;
      if (period === 'PM') h24 += 12;
      setHour(h24);
    }
  };

  const handlePeriodChange = (newPeriod: 'AM' | 'PM') => {
    setPeriod(newPeriod);
    if (!is24h) {
      let current12 = hour % 12;
      if (newPeriod === 'PM') {
        setHour(current12 + 12);
      } else {
        setHour(current12);
      }
    }
  };

  const toggleRepeatDay = (dayVal: number) => {
    if (repeatDays.includes(dayVal)) {
      setRepeatDays(repeatDays.filter((d) => d !== dayVal));
    } else {
      setRepeatDays([...repeatDays, dayVal].sort());
    }
  };

  const handleSelectPreset = (preset: PresetMediaItem) => {
    setSelectedMediaType(preset.type);
    setMediaUri(preset.id);
    setMediaName(preset.name);
    setMediaThumbnail(preset.thumbnail);
  };

  const handleLocalFileUpload = async (event: React.ChangeEvent<HTMLInputElement>, type: MediaType) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    setIsUploading(true);
    setValidationError(null);

    try {
      // Save file persistent blob to IndexedDB
      const storedItem = await saveUserMediaFile(file, type);
      setSelectedMediaType(type);
      setMediaUri(storedItem.id);
      setMediaName(file.name);
      setMediaThumbnail(undefined);
    } catch (err) {
      console.error('Error saving media file:', err);
      setValidationError('Failed to load local media file. Please try another file.');
    } finally {
      setIsUploading(false);
    }
  };

  const handlePreviewCurrentMedia = async () => {
    const media = await getMediaPlaybackUrl(mediaUri);
    setPreviewingMedia({
      url: media.url,
      isVideo: selectedMediaType === 'video',
      name: mediaName,
    });
  };

  const handleSave = () => {
    if (!mediaUri) {
      setValidationError('Please select a video or music track for your alarm.');
      return;
    }

    const finalSnooze = snoozeDuration === -1 ? Math.max(1, parseInt(customSnooze, 10) || 5) : snoozeDuration;

    onSave({
      id: editingAlarm ? editingAlarm.id : undefined,
      hour,
      minute,
      alarmLabel: alarmLabel.trim() || 'Alarm',
      mediaUri,
      mediaName,
      mediaType: selectedMediaType,
      mediaThumbnail,
      repeatDays,
      isEnabled: true,
      volume,
      gradualVolumeEnabled,
      vibrationEnabled,
      snoozeDuration: finalSnooze,
    });

    onClose();
  };

  // Convert hour to 12h display if needed
  let displayHour = hour;
  if (!is24h) {
    displayHour = hour % 12;
    if (displayHour === 0) displayHour = 12;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-slate-900 dark:text-white" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-white font-sans">
              {editingAlarm ? 'Edit Alarm' : 'Set New Alarm'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {validationError && (
            <div className="p-3 text-xs font-semibold bg-red-50 text-red-700 dark:bg-red-950/80 dark:text-red-300 rounded-2xl border border-red-200 dark:border-red-800">
              {validationError}
            </div>
          )}

          {/* Time Wheel / Selectors */}
          <div className="p-5 rounded-2xl bg-slate-900 dark:bg-slate-950 text-white flex flex-col items-center justify-center shadow-lg">
            <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 mb-2">
              Select Alarm Time
            </span>
            <div className="flex items-center gap-3">
              {/* Hour Dropdown */}
              <div className="relative">
                <select
                  value={displayHour}
                  onChange={handleHourChange}
                  className="appearance-none bg-slate-800/90 text-3xl font-extrabold font-mono text-white px-4 py-3 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer text-center"
                >
                  {is24h
                    ? Array.from({ length: 24 }).map((_, i) => (
                        <option key={i} value={i}>
                          {i < 10 ? `0${i}` : i}
                        </option>
                      ))
                    : Array.from({ length: 12 }).map((_, i) => {
                        const val = i === 0 ? 12 : i;
                        return (
                          <option key={val} value={val}>
                            {val < 10 ? `0${val}` : val}
                          </option>
                        );
                      })}
                </select>
              </div>

              <span className="text-3xl font-extrabold font-mono text-slate-400">:</span>

              {/* Minute Dropdown */}
              <div className="relative">
                <select
                  value={minute}
                  onChange={(e) => setMinute(parseInt(e.target.value, 10))}
                  className="appearance-none bg-slate-800/90 text-3xl font-extrabold font-mono text-white px-4 py-3 rounded-2xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer text-center"
                >
                  {Array.from({ length: 60 }).map((_, i) => (
                    <option key={i} value={i}>
                      {i < 10 ? `0${i}` : i}
                    </option>
                  ))}
                </select>
              </div>

              {/* AM/PM Switch */}
              {!is24h && (
                <div className="flex flex-col gap-1 p-1 bg-slate-800/90 rounded-2xl border border-slate-700">
                  <button
                    type="button"
                    onClick={() => handlePeriodChange('AM')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                      period === 'AM' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    AM
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePeriodChange('PM')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                      period === 'PM' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    PM
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Alarm Label Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              Alarm Name / Title
            </label>
            <input
              type="text"
              value={alarmLabel}
              onChange={(e) => setAlarmLabel(e.target.value)}
              placeholder="e.g. Morning Workout, Deep Work Wakeup"
              className="w-full px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white font-medium text-sm focus:outline-none focus:ring-2 focus:ring-slate-900 dark:focus:ring-white transition-all"
            />
          </div>

          {/* Repeat Weekdays Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Repeat Schedule
              </label>
              <button
                type="button"
                onClick={() => setRepeatDays([])}
                className={`text-xs font-semibold hover:underline cursor-pointer ${
                  repeatDays.length === 0 ? 'text-slate-900 dark:text-white' : 'text-slate-400'
                }`}
              >
                One-time Alarm
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1.5">
              {WEEKDAY_LABELS.map((day) => {
                const isSelected = repeatDays.includes(day.value);
                return (
                  <button
                    key={day.value}
                    type="button"
                    onClick={() => toggleRepeatDay(day.value)}
                    className={`h-11 rounded-2xl text-xs font-bold flex flex-col items-center justify-center transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    <span>{day.short}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Media Selection Feature */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Alarm Sound & Video Media
              </label>

              <button
                type="button"
                onClick={handlePreviewCurrentMedia}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Preview Media</span>
              </button>
            </div>

            {/* Hidden Local File Inputs */}
            <input
              ref={videoFileInputRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => handleLocalFileUpload(e, 'video')}
            />
            <input
              ref={audioFileInputRef}
              type="file"
              accept="audio/*"
              className="hidden"
              onChange={(e) => handleLocalFileUpload(e, 'audio')}
            />

            {/* Primary Media Source Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => videoFileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-900 dark:text-white font-semibold text-xs"
              >
                <Video className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                <span>Choose Local Video</span>
              </button>

              <button
                type="button"
                onClick={() => audioFileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-900 dark:text-white font-semibold text-xs"
              >
                <Music className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Choose Local Song</span>
              </button>
            </div>

            {/* Currently Selected Media Summary Card */}
            <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-200 dark:bg-slate-800 flex items-center justify-center shrink-0">
                  {selectedMediaType === 'video' ? (
                    <Video className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                  ) : (
                    <Music className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  )}
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[200px]">
                    {mediaName}
                  </div>
                  <div className="text-[11px] text-slate-500 capitalize">
                    {selectedMediaType} alarm sound
                  </div>
                </div>
              </div>
              <Check className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            </div>

            {/* Preset Library Quick Carousel */}
            <div>
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                Or pick from WakeUp Presets
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PRESET_MEDIA_ITEMS.map((item) => {
                  const isSelected = mediaUri === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectPreset(item)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'border-slate-900 dark:border-white bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 text-xs font-bold mb-1">
                        {item.type === 'video' ? (
                          <Video className="w-3.5 h-3.5 shrink-0" />
                        ) : (
                          <Music className="w-3.5 h-3.5 shrink-0" />
                        )}
                        <span className="truncate">{item.name}</span>
                      </div>
                      <div className="text-[10px] opacity-75 truncate">{item.artistOrDesc}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Volume, Gradual Volume & Vibration Controls */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                <span className="flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4" />
                  <span>Alarm Volume</span>
                </span>
                <span>{volume}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={volume}
                onChange={(e) => setVolume(parseInt(e.target.value, 10))}
                className="w-full accent-slate-900 dark:accent-white cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Gradual Volume Fade-In
                </span>
                <span className="text-[11px] text-slate-500">
                  Gently ramps sound volume over 30 seconds
                </span>
              </div>
              <input
                type="checkbox"
                checked={gradualVolumeEnabled}
                onChange={(e) => setGradualVolumeEnabled(e.target.checked)}
                className="w-5 h-5 accent-slate-900 dark:accent-white rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Vibration Pattern
                </span>
                <span className="text-[11px] text-slate-500">
                  Trigger device haptic motor when ringing
                </span>
              </div>
              <input
                type="checkbox"
                checked={vibrationEnabled}
                onChange={(e) => setVibrationEnabled(e.target.checked)}
                className="w-5 h-5 accent-slate-900 dark:accent-white rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Snooze Options */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              Snooze Duration
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[5, 10, 15].map((mins) => (
                <button
                  key={mins}
                  type="button"
                  onClick={() => {
                    setSnoozeDuration(mins);
                    setCustomSnooze('');
                  }}
                  className={`py-2.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                    snoozeDuration === mins
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  {mins} min
                </button>
              ))}

              <button
                type="button"
                onClick={() => setSnoozeDuration(-1)}
                className={`py-2.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                  snoozeDuration === -1
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800'
                }`}
              >
                Custom
              </button>
            </div>

            {snoozeDuration === -1 && (
              <div className="mt-2 flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="60"
                  placeholder="Minutes (e.g. 8)"
                  value={customSnooze}
                  onChange={(e) => setCustomSnooze(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 font-medium"
                />
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 px-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isUploading}
            className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-slate-900 dark:bg-white dark:text-slate-900 rounded-xl hover:bg-slate-800 dark:hover:bg-slate-100 shadow-md transition-all cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Alarm</span>
          </button>
        </div>
      </div>

      {/* Media Preview Modal Overlay */}
      {previewingMedia && (
        <div className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl overflow-hidden border border-slate-800">
            <div className="flex items-center justify-between p-4 bg-slate-950">
              <span className="text-xs font-bold text-white truncate max-w-[280px]">
                Preview: {previewingMedia.name}
              </span>
              <button
                onClick={() => setPreviewingMedia(null)}
                className="p-1 text-slate-400 hover:text-white rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 flex items-center justify-center bg-black min-h-[260px]">
              {previewingMedia.isVideo ? (
                <video
                  src={previewingMedia.url}
                  controls
                  autoPlay
                  className="max-h-[350px] w-full object-contain rounded-xl"
                />
              ) : (
                <div className="w-full flex flex-col items-center justify-center gap-4 py-8">
                  <Music className="w-16 h-16 text-emerald-400 animate-pulse" />
                  <audio src={previewingMedia.url} controls autoPlay className="w-full max-w-md" />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
