import React, { useState, useEffect, useRef } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import JsBarcode from 'jsbarcode';
import { Product, StoreSettings } from '../types';
import { 
  Barcode as BarcodeIcon, 
  Camera, 
  Sparkles, 
  Save, 
  Tag, 
  Check, 
  Printer, 
  X,
  PackagePlus,
  TrendingUp
} from 'lucide-react';

interface RegisterProductViewProps {
  initialProduct?: Product | null;
  settings: StoreSettings;
  onSaveProduct: (product: Product) => void;
  onOpenBarcodeModal: (product: Product) => void;
  onCancelEdit?: () => void;
}

export const RegisterProductView: React.FC<RegisterProductViewProps> = ({
  initialProduct,
  settings,
  onSaveProduct,
  onOpenBarcodeModal,
  onCancelEdit
}) => {
  const [code, setCode] = useState(initialProduct?.code || '');
  const [name, setName] = useState(initialProduct?.name || '');
  const [category, setCategory] = useState(initialProduct?.category || 'General');
  const [price, setPrice] = useState(initialProduct?.price ? initialProduct.price.toString() : '');
  const [costPrice, setCostPrice] = useState(initialProduct?.costPrice ? initialProduct.costPrice.toString() : '');
  const [stock, setStock] = useState(initialProduct?.stock !== undefined ? initialProduct.stock.toString() : '10');
  const [minStock, setMinStock] = useState(initialProduct?.minStock !== undefined ? initialProduct.minStock.toString() : '5');
  const [unit, setUnit] = useState(initialProduct?.unit || 'pcs');

  // Mini scanner for scanning into the barcode input
  const [showScannerModal, setShowScannerModal] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);

  // SVG barcode preview
  const barcodePreviewRef = useRef<SVGSVGElement | null>(null);

  // Update when initialProduct changes
  useEffect(() => {
    if (initialProduct) {
      setCode(initialProduct.code);
      setName(initialProduct.name);
      setCategory(initialProduct.category || 'General');
      setPrice(initialProduct.price.toString());
      setCostPrice(initialProduct.costPrice ? initialProduct.costPrice.toString() : '');
      setStock(initialProduct.stock.toString());
      setMinStock(initialProduct.minStock.toString());
      setUnit(initialProduct.unit || 'pcs');
    }
  }, [initialProduct]);

  // Live render barcode preview
  useEffect(() => {
    if (barcodePreviewRef.current && code.trim()) {
      try {
        JsBarcode(barcodePreviewRef.current, code.trim(), {
          format: 'CODE128',
          lineColor: '#0f172a',
          width: 1.5,
          height: 40,
          displayValue: true,
          fontSize: 12,
          margin: 6,
          background: '#ffffff'
        });
      } catch {
        // format might be invalid while typing
      }
    }
  }, [code]);

  // Generate random unique SKU code
  const handleGenerateSKU = () => {
    const randomDigits = Math.floor(100000 + Math.random() * 900000);
    setCode(randomDigits.toString());
  };

  // Start mini scanner
  const handleOpenScanner = async () => {
    setShowScannerModal(true);
    setTimeout(async () => {
      try {
        if (!scannerRef.current) {
          scannerRef.current = new Html5Qrcode("reg_scanner_reader");
        }
        await scannerRef.current.start(
          { facingMode: "environment" },
          { fps: 10, qrbox: 220 },
          (decoded) => {
            setCode(decoded);
            stopScannerModal();
          },
          () => {}
        );
      } catch (err) {
        alert("Camera error: " + err);
        stopScannerModal();
      }
    }, 200);
  };

  const stopScannerModal = () => {
    if (scannerRef.current) {
      scannerRef.current.stop().then(() => {
        scannerRef.current?.clear();
        scannerRef.current = null;
      }).catch(() => {});
    }
    setShowScannerModal(false);
  };

  // Form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim() || !price) {
      alert('Please fill out product code, name, and selling price.');
      return;
    }

    const numPrice = parseFloat(price);
    const numCostPrice = parseFloat(costPrice) || 0;
    const numStock = parseInt(stock, 10) || 0;
    const numMinStock = parseInt(minStock, 10) || 5;

    if (isNaN(numPrice) || numPrice < 0) {
      alert('Please enter a valid selling price.');
      return;
    }

    const savedProduct: Product = {
      id: initialProduct?.id || `prod-${Date.now()}`,
      code: code.trim(),
      name: name.trim(),
      category: category.trim() || 'General',
      price: numPrice,
      costPrice: numCostPrice,
      stock: numStock,
      minStock: numMinStock,
      unit: unit.trim() || 'pcs',
      createdAt: initialProduct?.createdAt || new Date().toISOString()
    };

    onSaveProduct(savedProduct);

    if (!initialProduct) {
      // Clear form
      setCode('');
      setName('');
      setPrice('');
      setCostPrice('');
      setStock('10');
      setMinStock('5');
    }
  };

  // Profit calculation
  const numPrice = parseFloat(price) || 0;
  const numCost = parseFloat(costPrice) || 0;
  const profit = numPrice - numCost;
  const marginPct = numPrice > 0 ? ((profit / numPrice) * 100).toFixed(1) : '0';

  const categoryPresets = ['Beverages', 'Food & Snacks', 'Electronics', 'Apparel', 'Dairy', 'Bakery', 'General'];
  const unitPresets = ['pcs', 'bottle', 'can', 'pack', 'box', 'kg', 'loaf'];

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div className="glass-card rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <PackagePlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-100">
                {initialProduct ? 'Edit Product' : 'Register New Product'}
              </h2>
              <p className="text-xs text-slate-400">
                Configure barcode, pricing, category, and inventory levels
              </p>
            </div>
          </div>

          {initialProduct && onCancelEdit && (
            <button
              onClick={onCancelEdit}
              className="text-xs text-slate-400 hover:text-slate-200 px-3 py-1.5 rounded-xl border border-slate-800 hover:bg-slate-800 cursor-pointer"
            >
              Cancel Edit
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Barcode / SKU field */}
          <div>
            <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
              Barcode / SKU Code <span className="text-rose-400">*</span>
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <BarcodeIcon className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="text"
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  placeholder="e.g. 1001 or scan with camera"
                  required
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              <button
                type="button"
                onClick={handleOpenScanner}
                className="px-3.5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                Scan
              </button>

              <button
                type="button"
                onClick={handleGenerateSKU}
                className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-xl text-xs flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
                title="Generate unique 6-digit barcode"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                Auto SKU
              </button>
            </div>
          </div>

          {/* Barcode Live Preview */}
          {code.trim() && (
            <div className="p-3 bg-white/5 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="bg-white p-2 rounded-xl flex justify-center">
                <svg ref={barcodePreviewRef} className="max-w-[180px] h-12"></svg>
              </div>
              <div className="text-right">
                <button
                  type="button"
                  onClick={() => {
                    const tempProduct: Product = {
                      id: initialProduct?.id || 'temp',
                      code: code.trim(),
                      name: name || 'Preview Product',
                      category: category || 'General',
                      price: parseFloat(price) || 0,
                      costPrice: parseFloat(costPrice) || 0,
                      stock: parseInt(stock, 10) || 0,
                      minStock: parseInt(minStock, 10) || 5,
                      unit: unit || 'pcs',
                      createdAt: new Date().toISOString()
                    };
                    onOpenBarcodeModal(tempProduct);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-cyan-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Label Tag
                </button>
              </div>
            </div>
          )}

          {/* Product Name */}
          <div>
            <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
              Product Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Bottled Mineral Water (500ml)"
              required
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Category */}
          <div>
            <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
              Category
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={category}
                onChange={e => setCategory(e.target.value)}
                placeholder="Category name"
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
            {/* Quick Category Chips */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {categoryPresets.map(cat => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                    category === cat
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-bold'
                      : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Price & Cost */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
                Selling Price ({settings.currency}) <span className="text-rose-400">*</span>
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={price}
                onChange={e => setPrice(e.target.value)}
                placeholder="0.00"
                required
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-cyan-300 font-bold focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
                Cost Price ({settings.currency}) <span className="text-slate-500 font-normal">(Optional)</span>
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={costPrice}
                onChange={e => setCostPrice(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-300 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Profit Indicator */}
          {numPrice > 0 && numCost > 0 && (
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <TrendingUp className="w-4 h-4" />
                <span>Estimated Profit: {settings.currency}{profit.toFixed(2)}</span>
              </div>
              <span className="font-bold text-emerald-300">
                {marginPct}% Margin
              </span>
            </div>
          )}

          {/* Stock, Low Stock Alert, & Unit */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
                Stock Qty
              </label>
              <input
                type="number"
                min="0"
                value={stock}
                onChange={e => setStock(e.target.value)}
                placeholder="0"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
                Min Alert Level
              </label>
              <input
                type="number"
                min="0"
                value={minStock}
                onChange={e => setMinStock(e.target.value)}
                placeholder="5"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1.5 block">
                Unit
              </label>
              <select
                value={unit}
                onChange={e => setUnit(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
              >
                {unitPresets.map(u => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4">
            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-2xl shadow-lg shadow-cyan-500/25 transition flex items-center justify-center gap-2 cursor-pointer text-sm"
            >
              <Save className="w-4 h-4" />
              {initialProduct ? 'Update Product' : 'Save & Register Product'}
            </button>
          </div>
        </form>
      </div>

      {/* Mini Scanner Modal for Barcode scanning into input */}
      {showScannerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-cyan-400" />
                Scan Product Barcode
              </h3>
              <button
                onClick={stopScannerModal}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div id="reg_scanner_reader" className="w-full rounded-xl overflow-hidden min-h-[220px] bg-slate-950"></div>
            
            <p className="text-[11px] text-center text-slate-400">
              Hold the barcode in front of the camera to automatically capture the code.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
