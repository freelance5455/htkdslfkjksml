import React, { useState } from 'react';
import { BannerFormat, AdCreativeData } from '../types';
import { renderBannerToCanvas, downloadCanvasAsPng, RenderOptions } from '../utils/canvasRenderer';
import { Download, Copy, Check, Eye, Sparkles } from 'lucide-react';

interface BannerDisplayCardProps {
  format: BannerFormat;
  creative: AdCreativeData;
  options: RenderOptions;
  onFocus?: (format: BannerFormat) => void;
}

export const BannerDisplayCard: React.FC<BannerDisplayCardProps> = ({
  format,
  creative,
  options,
  onFocus,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [copied, setCopied] = useState(false);

  const copy = creative.copyVariations[format.shape] || {
    headline: creative.primaryHeadline,
    subhead: creative.subheadline,
    cta: creative.ctaText,
  };

  const handleDownload = async () => {
    try {
      setDownloading(true);
      const canvas = await renderBannerToCanvas(format, creative, options);
      const filename = `${creative.brandName.toLowerCase().replace(/\s+/g, '-')}-${format.width}x${format.height}.png`;
      downloadCanvasAsPng(canvas, filename);
    } catch (err) {
      console.error('Download failed:', err);
    } finally {
      setDownloading(false);
    }
  };

  const handleCopyEmbed = () => {
    const embedHtml = `<!-- ${creative.brandName} ${format.name} (${format.width}x${format.height}) -->
<div class="ad-banner" style="width:${format.width}px;height:${format.height}px;background:${creative.primaryColor};position:relative;overflow:hidden;font-family:system-ui,-apple-system,sans-serif;">
  <a href="${creative.productUrl || '#'}" target="_blank" rel="noopener noreferrer" style="text-decoration:none;display:block;width:100%;height:100%;">
    <div style="padding:12px;color:#fff;">
      <span style="display:inline-block;background:rgba(255,255,255,0.25);padding:2px 8px;border-radius:12px;font-size:10px;font-weight:700;">${creative.offerBadge || 'SPECIAL'}</span>
      <h3 style="margin:6px 0 2px;font-size:14px;font-weight:700;">${copy.headline}</h3>
      <p style="margin:0 0 8px;font-size:11px;opacity:0.85;">${copy.subhead}</p>
      <button style="background:#fff;color:${creative.primaryColor};border:none;padding:6px 14px;border-radius:4px;font-weight:700;font-size:12px;cursor:pointer;">${copy.cta}</button>
    </div>
  </a>
</div>`;
    navigator.clipboard.writeText(embedHtml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Determine dynamic container scale to keep preview neat in grid
  const maxDisplayWidth = 360;
  const scale = format.width > maxDisplayWidth ? maxDisplayWidth / format.width : 1;
  const scaledWidth = format.width * scale;
  const scaledHeight = format.height * scale;

  return (
    <div
      id={`banner-card-${format.id}`}
      className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between transition-all hover:border-slate-700 shadow-lg group"
    >
      {/* Card Header with Dimension and Controls */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-100">{format.name}</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-mono">
              {format.width} × {format.height}
            </span>
          </div>
          <span className="text-xs text-slate-500">{format.category}</span>
        </div>

        <div className="flex items-center gap-1.5 opacity-90 group-hover:opacity-100 transition-opacity">
          {onFocus && (
            <button
              id={`btn-focus-${format.id}`}
              onClick={() => onFocus(format)}
              title="Inspect banner"
              className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg text-xs flex items-center gap-1"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            id={`btn-copy-${format.id}`}
            onClick={handleCopyEmbed}
            title="Copy HTML5 embed code"
            className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg text-xs flex items-center gap-1"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          <button
            id={`btn-download-${format.id}`}
            onClick={handleDownload}
            disabled={downloading}
            title="Download high-resolution 2x PNG"
            className="p-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium flex items-center gap-1 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">PNG</span>
          </button>
        </div>
      </div>

      {/* Banner Preview Sandbox Area */}
      <div className="w-full flex items-center justify-center p-3 bg-slate-950/60 rounded-lg overflow-hidden min-h-[140px]">
        <div
          style={{
            width: `${scaledWidth}px`,
            height: `${scaledHeight}px`,
          }}
          className="relative flex-shrink-0 origin-top-left transition-transform"
        >
          <div
            style={{
              width: `${format.width}px`,
              height: `${format.height}px`,
              transform: `scale(${scale})`,
              transformOrigin: 'top left',
            }}
            className="relative overflow-hidden select-none shadow-2xl bg-slate-900 border border-white/10"
          >
            {/* Background image if available */}
            {creative.imageUrl && (
              <img
                src={creative.imageUrl}
                alt={creative.brandName}
                referrerPolicy="no-referrer"
                className={`absolute inset-0 w-full h-full object-cover ${
                  format.shape === 'story'
                    ? 'opacity-85'
                    : format.shape === 'leaderboard'
                    ? 'w-1/3 object-cover'
                    : 'opacity-70'
                }`}
              />
            )}

            {/* Gradient Overlays tailored to shape */}
            <div
              className={`absolute inset-0 pointer-events-none ${
                format.shape === 'story'
                  ? 'bg-gradient-to-t from-slate-950 via-slate-950/40 to-slate-950/80'
                  : format.shape === 'leaderboard'
                  ? 'bg-gradient-to-r from-transparent via-slate-950/80 to-slate-950'
                  : 'bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/30'
              }`}
            />

            {/* Content layout based on shape */}
            {format.shape === 'leaderboard' ? (
              // Horizontal layout (728x90, 970x250, 320x50)
              <div className="relative z-10 w-full h-full flex items-center justify-between px-4">
                <div className="flex items-center gap-3 pl-20 sm:pl-28 max-w-[65%]">
                  {format.height > 55 && creative.offerBadge && (
                    <span
                      style={{ backgroundColor: creative.primaryColor }}
                      className="px-2 py-0.5 rounded-full text-[10px] font-bold text-white uppercase tracking-wider flex-shrink-0"
                    >
                      {creative.offerBadge}
                    </span>
                  )}
                  <div className="truncate">
                    <p className="text-white font-bold text-sm leading-tight truncate">{copy.headline}</p>
                    {format.height > 60 && (
                      <p className="text-slate-300 text-xs truncate mt-0.5">{copy.subhead}</p>
                    )}
                  </div>
                </div>
                <button
                  style={{ backgroundColor: creative.primaryColor }}
                  className="px-3.5 py-1.5 rounded text-xs font-bold text-white shadow-md hover:brightness-110 flex-shrink-0 transition-transform active:scale-95"
                >
                  {copy.cta}
                </button>
              </div>
            ) : format.shape === 'skyscraper' ? (
              // Vertical layout (160x600, 300x600)
              <div className="relative z-10 w-full h-full flex flex-col justify-between p-3.5 text-center">
                <div>
                  <div className="text-[11px] font-bold tracking-widest text-slate-300 uppercase mb-1">
                    {creative.brandName}
                  </div>
                  {creative.offerBadge && (
                    <span
                      style={{ backgroundColor: creative.primaryColor }}
                      className="inline-block px-2.5 py-0.5 rounded-full text-[9px] font-bold text-white uppercase tracking-wider mb-2"
                    >
                      {creative.offerBadge}
                    </span>
                  )}
                  <h4 className="text-white font-extrabold text-sm leading-tight px-1">{copy.headline}</h4>
                </div>

                <div className="my-auto py-2">
                  <p className="text-slate-200 text-xs leading-relaxed px-1 line-clamp-3">{copy.subhead}</p>
                </div>

                <button
                  style={{ backgroundColor: creative.primaryColor }}
                  className="w-full py-2 rounded text-xs font-bold text-white shadow-lg hover:brightness-110 transition-transform active:scale-95"
                >
                  {copy.cta}
                </button>
              </div>
            ) : format.shape === 'story' ? (
              // Vertical Fullscreen (1080x1920)
              <div className="relative z-10 w-full h-full flex flex-col justify-between p-6 text-center">
                <div className="pt-8">
                  <span className="text-xs font-bold tracking-widest uppercase text-white/80">
                    {creative.brandName}
                  </span>
                  {creative.offerBadge && (
                    <div className="mt-2">
                      <span
                        style={{ backgroundColor: creative.primaryColor }}
                        className="px-3 py-1 rounded-full text-xs font-bold text-white uppercase"
                      >
                        {creative.offerBadge}
                      </span>
                    </div>
                  )}
                </div>

                <div className="mb-8">
                  <h3 className="text-white font-extrabold text-xl leading-snug mb-2">{copy.headline}</h3>
                  <p className="text-white/90 text-sm leading-relaxed max-w-[85%] mx-auto">{copy.subhead}</p>
                  <button
                    style={{ backgroundColor: creative.primaryColor }}
                    className="mt-6 w-full max-w-[85%] mx-auto py-3 rounded-xl font-bold text-sm text-white shadow-xl hover:brightness-110"
                  >
                    {copy.cta} →
                  </button>
                </div>
              </div>
            ) : (
              // Square / Rectangle (300x250, 336x280, 250x250, 1200x628)
              <div className="relative z-10 w-full h-full flex flex-col justify-between p-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold tracking-wider text-white/80 uppercase">
                    {creative.brandName}
                  </span>
                  {creative.offerBadge && (
                    <span
                      style={{ backgroundColor: creative.primaryColor }}
                      className="px-2 py-0.5 rounded-full text-[9px] font-bold text-white uppercase"
                    >
                      {creative.offerBadge}
                    </span>
                  )}
                </div>

                <div className="mt-auto">
                  <h4 className="text-white font-bold text-sm leading-snug mb-1 line-clamp-2">
                    {copy.headline}
                  </h4>
                  <p className="text-slate-300 text-xs leading-normal mb-3 line-clamp-2">{copy.subhead}</p>
                  <button
                    style={{ backgroundColor: creative.primaryColor }}
                    className="w-full py-2 rounded text-xs font-bold text-white shadow-md hover:brightness-110 transition-transform active:scale-95"
                  >
                    {copy.cta}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Card Footer notes */}
      <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
        <span>Aspect: {format.aspectRatioLabel}</span>
        <span className="flex items-center gap-1 text-slate-400">
          <Sparkles className="w-3 h-3 text-amber-400" />
          Retina 2× Ready
        </span>
      </div>
    </div>
  );
};
