import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowDownUp,
  ArrowLeft,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Clock,
  Hammer,
  Search,
  Star,
  Trophy,
} from 'lucide-react';
import {
  ClanDashboardState,
  OfficialUnitEntry,
  PlayerProfile,
  ROLE_LABELS_RU,
  UpgradeDetailType,
  VillageCategory,
  VillageId,
} from '../shared/cocData';
import { translateCocUnitNameRu } from '../utils/clanAnalytics';
import {
  formatDateTimeRu,
  formatRelativeTimeRu,
} from '../utils/formatters';
import {
  CocUnitBadge,
  UPGRADE_PERIOD_OPTIONS,
  UpgradePeriodId,
  formatCountdownRu,
  getDataSourceLabel,
  getUpgradeCategoryShortLabel,
  getVillageShortTitle,
  isActualUpgradeEvent,
  matchesUpgradePeriod,
  resolveUpgradeDetailType,
  resolveUpgradeVillage,
} from './CocUnitBadge';

interface PlayersAndInspectorViewProps {
  state: ClanDashboardState;
  selectedPlayerTag: string;
  profileOpenTrigger?: number;
  externalPlayer: PlayerProfile | null;
  nowMs: number;
  onSelectPlayer: (tag: string) => void;
  onClearExternalPlayer: () => void;
  onOpenJsonImport?: (playerTag?: string) => void;
  onOpenSettingsImport?: () => void;
  onOpenGlobalSearch: () => void;
}

type MemberSortKey =
  | 'trophies'
  | 'townHallLevel'
  | 'expLevel'
  | 'donations'
  | 'donationsReceived'
  | 'warStars';

type ProfileTab = 'army' | 'history' | 'achievements' | 'village_json';

const UnitProgressGrid: React.FC<{
  title: string;
  detailType: UpgradeDetailType;
  items: OfficialUnitEntry[];
  emptyText?: string;
}> = ({ title, detailType, items, emptyText }) => {
  if (items.length === 0) {
    if (!emptyText) return null;
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-5">
        <h3 className="font-display text-sm font-semibold text-slate-100">{title}</h3>
        <p className="mt-2 text-xs text-slate-500">{emptyText}</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-slate-800 bg-[#121824] p-5">
      <div className="mb-3 flex items-center justify-between border-b border-slate-800/80 pb-2.5">
        <h3 className="font-display text-sm font-semibold text-slate-100">{title}</h3>
        <span className="font-mono text-xs tabular-nums text-slate-400">{items.length} поз.</span>
      </div>
      <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {items.map((u, idx) => {
          const maxLv = Math.max(1, u.maxLevel || u.level || 1);
          const pct = Math.min(100, Math.round((u.level / maxLv) * 100));
          const isMax = u.maxLevel > 0 && u.level >= u.maxLevel;
          const ru = translateCocUnitNameRu(u.name);
          const isSuper = Boolean(u.superTroopIsActive || u.name.startsWith('Super '));
          return (
            <div
              key={`${u.name}-${u.village}-${idx}`}
              className="rounded-md border border-slate-800/80 bg-[#0B0F17] px-3 py-2.5 flex items-center gap-2.5"
            >
              <CocUnitBadge
                detailType={detailType}
                apiName={u.name}
                isSuperTroop={isSuper}
                size="sm"
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="truncate font-medium text-slate-100" title={u.name}>
                    {u.name}
                    {u.village === 'builderBase' && (
                      <span className="ml-1 text-[10px] text-sky-400">(ДС)</span>
                    )}
                    {u.superTroopIsActive && (
                      <span className="ml-1 text-[10px] text-amber-400">Супер</span>
                    )}
                  </span>
                  <span
                    className={`font-mono font-semibold tabular-nums shrink-0 ${
                      isMax ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {u.level}/{u.maxLevel || u.level}
                  </span>
                </div>
                {ru !== u.name && (
                  <div className="text-[10px] text-slate-500 truncate">{ru}</div>
                )}
                <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                  <div
                    className={`h-full ${isMax ? 'bg-emerald-500' : 'bg-amber-500'}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const PlayersAndInspectorView: React.FC<PlayersAndInspectorViewProps> = ({
  state,
  selectedPlayerTag,
  profileOpenTrigger = 0,
  externalPlayer,
  nowMs,
  onSelectPlayer,
  onClearExternalPlayer,
  onOpenGlobalSearch,
}) => {
  const [viewMode, setViewMode] = useState<'roster' | 'profile'>(
    externalPlayer || profileOpenTrigger > 0 ? 'profile' : 'roster'
  );
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<MemberSortKey>('trophies');
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');
  const [page, setPage] = useState(1);
  const pageSize = 20;

  const [profileTab, setProfileTab] = useState<ProfileTab>('army');
  const [historyPeriod, setHistoryPeriod] = useState<UpgradePeriodId>('all');
  const [historyCat, setHistoryCat] = useState<'all' | UpgradeDetailType>('all');
  const [achFilter, setAchFilter] = useState<'all' | 'completed' | 'in_progress'>('all');
  const [villageCat, setVillageCat] = useState<VillageCategory>('defenses');
  const [jsonVillageTab, setJsonVillageTab] = useState<'home' | 'builderBase'>('home');

  useEffect(() => {
    if (profileOpenTrigger > 0 && selectedPlayerTag) {
      setViewMode('profile');
    }
  }, [profileOpenTrigger, selectedPlayerTag]);

  const activeProfile: PlayerProfile | null = useMemo(() => {
    if (externalPlayer) return externalPlayer;
    if (!selectedPlayerTag && state.players.length > 0) return state.players[0];
    return state.players.find((p) => p.tag === selectedPlayerTag) ?? state.players[0] ?? null;
  }, [externalPlayer, selectedPlayerTag, state.players]);

  useEffect(() => {
    if (
      profileTab === 'village_json' &&
      activeProfile &&
      !activeProfile.buildingsVerified &&
      !activeProfile.jsonVillage
    ) {
      setProfileTab('army');
    }
  }, [profileTab, activeProfile]);

  const filteredSortedMembers = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = state.players.filter(
      (p) =>
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.tag.toLowerCase().includes(q)
    );
    return list.sort((a, b) => {
      const av = a[sortKey] ?? 0;
      const bv = b[sortKey] ?? 0;
      return sortDir === 'desc' ? bv - av : av - bv;
    });
  }, [state.players, search, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filteredSortedMembers.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pageMembers = filteredSortedMembers.slice(
    (safePage - 1) * pageSize,
    safePage * pageSize
  );

  // If external player was opened, show profile automatically
  const showProfile = Boolean(externalPlayer) || viewMode === 'profile';

  const openMemberProfile = (tag: string) => {
    onClearExternalPlayer();
    onSelectPlayer(tag);
    setViewMode('profile');
  };

  if (showProfile && activeProfile) {
    const p = activeProfile;
    const heroEquipmentMerged = (() => {
      const list = [...p.apiHeroEquipment];
      if (list.length === 0) {
        for (const h of p.apiHeroes) {
          for (const eq of h.equipment ?? []) {
            list.push({
              name: `${eq.name} (${h.name})`,
              level: eq.level,
              maxLevel: eq.maxLevel,
              village: eq.village ?? 'home',
            });
          }
        }
      }
      return list;
    })();

    const filteredAchievements = p.achievements.filter((a) => {
      if (achFilter === 'completed') return a.stars >= 3;
      if (achFilter === 'in_progress') return a.stars < 3;
      return true;
    });

    const totalAchStars = p.achievements.reduce((s, a) => s + a.stars, 0);
    const maxAchStars = p.achievements.length * 3;

    const playerUpgradeEvents = state.events.filter(
      (ev) => ev.playerTag === p.tag && isActualUpgradeEvent(ev)
    );
    const periodPlayerEvents = playerUpgradeEvents.filter((ev) =>
      matchesUpgradePeriod(ev.timestamp, historyPeriod, nowMs)
    );
    const filteredPlayerEvents = periodPlayerEvents.filter(
      (ev) => historyCat === 'all' || resolveUpgradeDetailType(ev) === historyCat
    );

    const periodGainStats = {
      eventsCount: periodPlayerEvents.length,
      totalLevels: periodPlayerEvents.reduce((s, ev) => s + Math.max(0, ev.toLevel - ev.fromLevel), 0),
      heroesLevels: periodPlayerEvents
        .filter((ev) => resolveUpgradeDetailType(ev) === 'hero')
        .reduce((s, ev) => s + Math.max(0, ev.toLevel - ev.fromLevel), 0),
      equipmentLevels: periodPlayerEvents
        .filter((ev) => resolveUpgradeDetailType(ev) === 'equipment')
        .reduce((s, ev) => s + Math.max(0, ev.toLevel - ev.fromLevel), 0),
      troopsLevels: periodPlayerEvents
        .filter((ev) => {
          const dt = resolveUpgradeDetailType(ev);
          return dt === 'troop' || dt === 'siege';
        })
        .reduce((s, ev) => s + Math.max(0, ev.toLevel - ev.fromLevel), 0),
      spellsAndPetsLevels: periodPlayerEvents
        .filter((ev) => {
          const dt = resolveUpgradeDetailType(ev);
          return dt === 'spell' || dt === 'pet';
        })
        .reduce((s, ev) => s + Math.max(0, ev.toLevel - ev.fromLevel), 0),
    };

    const homeHeroes = p.apiHeroes.filter((h) => h.village !== 'builderBase');
    const builderHeroes = p.apiHeroes.filter((h) => h.village === 'builderBase');
    const homeTroops = p.apiTroops.filter((t) => t.village !== 'builderBase');
    const builderTroops = p.apiTroops.filter((t) => t.village === 'builderBase');
    const playerActiveUpgrades = (state.activeUpgrades ?? []).filter(
      (au) => au.playerTag === p.tag && au.status === 'in_progress'
    );

    return (
      <div className="space-y-6">
        {/* Top Back / Switch Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/90 pb-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                onClearExternalPlayer();
                setViewMode('roster');
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-[#121824] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-amber-500/60 hover:text-amber-400 transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>К списку игроков</span>
            </button>
            {state.players.length > 0 && !externalPlayer && (
              <select
                value={p.tag}
                onChange={(e) => onSelectPlayer(e.target.value)}
                className="rounded-md border border-slate-800 bg-[#121824] px-3 py-1.5 text-xs text-slate-200 focus:border-amber-500 focus:outline-none"
              >
                {state.players.map((pl) => (
                  <option key={pl.tag} value={pl.tag}>
                    {pl.name} ({pl.tag} · TH{pl.townHallLevel})
                  </option>
                ))}
              </select>
            )}
          </div>

          <button
            type="button"
            onClick={onOpenGlobalSearch}
            className="text-xs font-medium text-amber-400 hover:text-amber-300"
          >
            Найти другого игрока по #тегу
          </button>
        </div>

        {/* Player Identity & Key Stats */}
        <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-5">
          <div className="flex flex-col gap-4 border-b border-slate-800 pb-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-start gap-4">
              {p.league?.iconUrl && (
                <img
                  src={p.league.iconUrl}
                  alt={p.league.name}
                  referrerPolicy="no-referrer"
                  className="h-14 w-14 shrink-0 object-contain"
                />
              )}
              <div>
                <div className="flex flex-wrap items-baseline gap-3">
                  <h1 className="font-display text-2xl font-bold text-slate-100">{p.name}</h1>
                  <span className="font-mono text-sm font-semibold text-amber-400">
                    Ратуша {p.townHallLevel}
                    {p.townHallWeaponLevel ? ` (Ур. оружия ${p.townHallWeaponLevel})` : ''}
                  </span>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="font-mono text-slate-300">{p.tag}</span>
                  <span aria-hidden="true">·</span>
                  <span>Уровень опыта: <strong className="font-mono text-slate-200">{p.expLevel}</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>{ROLE_LABELS_RU[p.role]}</span>
                  {p.league?.name && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>{p.league.name}</span>
                    </>
                  )}
                  {p.clanRef && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>Клан: {p.clanRef.name} ({p.clanRef.tag})</span>
                    </>
                  )}
                  <span aria-hidden="true">·</span>
                  <span>Синхр. {formatRelativeTimeRu(p.lastSyncedAt, nowMs)}</span>
                </div>
                {p.labels && p.labels.length > 0 && (
                  <div className="mt-2.5 flex flex-wrap items-center gap-2">
                    {p.labels.map((lbl) => (
                      <span
                        key={lbl.id}
                        className="inline-flex items-center gap-1.5 rounded border border-slate-700/80 bg-[#0B0F17] px-2 py-1 text-[11px] text-slate-200"
                      >
                        {lbl.iconUrl && (
                          <img
                            src={lbl.iconUrl}
                            alt={lbl.name}
                            referrerPolicy="no-referrer"
                            className="h-3.5 w-3.5 object-contain"
                          />
                        )}
                        <span>{lbl.name}</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {p.warPreference && (
              <div className="text-xs text-slate-400 shrink-0">
                Статус в КВ:{' '}
                <span className={p.warPreference === 'in' ? 'text-emerald-400 font-medium' : 'text-slate-400'}>
                  {p.warPreference === 'in' ? 'Участвует' : 'Пропускает'}
                </span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <div>
              <div className="text-xs text-slate-400">Трофеи</div>
              <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-amber-400">
                {p.trophies.toLocaleString('ru-RU')}
              </div>
              {p.bestTrophies > 0 && (
                <div className="font-mono text-[11px] text-slate-500 tabular-nums">
                  Рекорд: {p.bestTrophies.toLocaleString('ru-RU')}
                </div>
              )}
            </div>

            <div>
              <div className="text-xs text-slate-400">Деревня строителя</div>
              <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-sky-400">
                {p.builderBaseTrophies.toLocaleString('ru-RU')}
              </div>
              <div className="font-mono text-[11px] text-slate-500 tabular-nums">
                BH{p.builderHallLevel || '—'}
                {p.bestBuilderBaseTrophies > 0 ? ` · Макс ${p.bestBuilderBaseTrophies}` : ''}
              </div>
              {p.builderBaseLeague?.name && (
                <div className="text-[11px] text-sky-300/90 truncate">
                  {p.builderBaseLeague.name}
                </div>
              )}
            </div>

            <div>
              <div className="text-xs text-slate-400">Звёзды войны</div>
              <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-100">
                {p.warStars.toLocaleString('ru-RU')}
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Донаты (отдано / получено)</div>
              <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-emerald-400">
                {p.donations.toLocaleString('ru-RU')} / {p.donationsReceived.toLocaleString('ru-RU')}
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Атаки / Обороны (сезон)</div>
              <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-100">
                {p.combat.attacksWon} / {p.combat.defensesWon}
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">Вклад в столицу</div>
              <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-100">
                {p.clanCapitalContributions.toLocaleString('ru-RU')}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-800 pt-3 text-xs font-mono text-slate-400">
            <span>
              Последнее обновление Supercell API: <strong className="text-slate-200">{formatDateTimeRu(p.lastSyncedAt)}</strong>
            </span>
            <span>
              Позиций API: {p.apiHeroes.length + p.apiHeroEquipment.length + p.apiTroops.length + p.apiSpells.length + p.apiPets.length + p.apiSiegeMachines.length}
            </span>
          </div>
        </section>

        {/* Active Upgrades for this Player */}
        {playerActiveUpgrades.length > 0 && (
          <section className="rounded-lg border border-amber-500/40 bg-[#121824] p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
              <div className="flex items-center gap-2">
                <Hammer className="h-4 w-4 text-amber-400" />
                <h2 className="font-display text-sm font-semibold text-slate-100">
                  Сейчас улучшается у {p.name} ({playerActiveUpgrades.length})
                </h2>
              </div>
              <span className="font-mono text-[11px] text-amber-300">Статус: УЛУЧШАЕТСЯ</span>
            </div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {playerActiveUpgrades.map((item) => {
                const cd = formatCountdownRu(item.estimatedFinishesAt, nowMs);
                return (
                  <div
                    key={item.id}
                    className="rounded-md border border-amber-500/35 bg-[#0B0F17] p-3.5 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-mono font-semibold text-sky-300">
                        {getVillageShortTitle(item.village)}
                      </span>
                      <span className="font-mono text-[11px] text-slate-400">
                        {getDataSourceLabel(item.source)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-bold text-slate-100">{item.objectName}</span>
                      <span className="font-mono text-sm font-bold text-amber-400">
                        {item.fromLevel} → {item.toLevel}
                      </span>
                    </div>
                    <div className="font-mono text-[11px] text-emerald-300">
                      {cd ? cd.label : `Подтверждено: ${formatDateTimeRu(item.lastConfirmedAt)}`}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Legend League Statistics (ONLY if present in API response) */}
        {p.legendStatistics && (
          <section className="rounded-lg border border-amber-500/30 bg-[#121824] p-5">
            <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
              <Trophy className="h-4 w-4 text-amber-400" />
              <h2 className="font-display text-sm font-semibold text-slate-100">
                Статистика Легендарной лиги
              </h2>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4 text-xs">
              {p.legendStatistics.legendTrophies !== undefined && (
                <div>
                  <div className="text-slate-400">Легендарные трофеи</div>
                  <div className="mt-1 font-mono text-base font-semibold tabular-nums text-amber-400">
                    {p.legendStatistics.legendTrophies.toLocaleString('ru-RU')}
                  </div>
                </div>
              )}
              {p.legendStatistics.currentSeason && (
                <div>
                  <div className="text-slate-400">Текущий сезон</div>
                  <div className="mt-1 font-mono text-base font-semibold tabular-nums text-slate-100">
                    {p.legendStatistics.currentSeason.trophies ?? '—'} кубк.
                    {p.legendStatistics.currentSeason.rank
                      ? ` (#${p.legendStatistics.currentSeason.rank.toLocaleString('ru-RU')})`
                      : ''}
                  </div>
                </div>
              )}
              {p.legendStatistics.previousSeason && (
                <div>
                  <div className="text-slate-400">Прошлый сезон ({p.legendStatistics.previousSeason.id ?? '—'})</div>
                  <div className="mt-1 font-mono text-base font-semibold tabular-nums text-slate-200">
                    {p.legendStatistics.previousSeason.trophies ?? '—'} кубк.
                    {p.legendStatistics.previousSeason.rank
                      ? ` (#${p.legendStatistics.previousSeason.rank.toLocaleString('ru-RU')})`
                      : ''}
                  </div>
                </div>
              )}
              {p.legendStatistics.bestSeason && (
                <div>
                  <div className="text-slate-400">Лучший сезон ({p.legendStatistics.bestSeason.id ?? '—'})</div>
                  <div className="mt-1 font-mono text-base font-semibold tabular-nums text-emerald-400">
                    {p.legendStatistics.bestSeason.trophies ?? '—'} кубк.
                    {p.legendStatistics.bestSeason.rank
                      ? ` (#${p.legendStatistics.bestSeason.rank.toLocaleString('ru-RU')})`
                      : ''}
                  </div>
                </div>
              )}
            </div>
          </section>
        )}

        {/* Profile Sub-Tabs */}
        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1 w-fit">
          <button
            type="button"
            onClick={() => setProfileTab('army')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              profileTab === 'army'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Герои, армия и снаряжение
          </button>
          <button
            type="button"
            onClick={() => setProfileTab('history')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              profileTab === 'history'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Журнал улучшений ({playerUpgradeEvents.length})
          </button>
          <button
            type="button"
            onClick={() => setProfileTab('achievements')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              profileTab === 'achievements'
                ? 'bg-amber-500 text-slate-950 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Достижения ({totalAchStars}/{maxAchStars}★)
          </button>
          {(p.buildingsVerified || p.jsonVillage) && (
            <button
              type="button"
              onClick={() => setProfileTab('village_json')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                profileTab === 'village_json'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Здания и стены (Доп. JSON)
            </button>
          )}
        </div>

        {profileTab === 'army' && (
          <div className="space-y-6">
            <div className="border-l-2 border-amber-500 pl-3">
              <div className="font-display text-sm font-bold tracking-wider text-amber-400">
                HOME VILLAGE — Родная деревня
              </div>
              <div className="text-xs text-slate-400">Источник: Supercell API</div>
            </div>
            <UnitProgressGrid
              title="Герои Home Village"
              detailType="hero"
              items={homeHeroes}
              emptyText="Герои основной деревни отсутствуют в ответе API."
            />
            <UnitProgressGrid
              title="Оборудование героев"
              detailType="equipment"
              items={heroEquipmentMerged}
              emptyText="Данные об оборудовании героев отсутствуют в ответе API."
            />
            <UnitProgressGrid
              title="Войска Home Village"
              detailType="troop"
              items={homeTroops}
              emptyText="Данные о войсках основной деревни не получены."
            />
            <UnitProgressGrid
              title="Заклинания"
              detailType="spell"
              items={p.apiSpells}
              emptyText="Заклинания ещё не открыты."
            />
            <UnitProgressGrid
              title="Питомцы героев"
              detailType="pet"
              items={p.apiPets}
            />
            <UnitProgressGrid
              title="Осадные машины"
              detailType="siege"
              items={p.apiSiegeMachines}
            />

            <div className="border-l-2 border-sky-500 pl-3 pt-2">
              <div className="font-display text-sm font-bold tracking-wider text-sky-400">
                BUILDER BASE — Деревня строителя (BH{p.builderHallLevel || '—'})
              </div>
              <div className="text-xs text-slate-400">Источник: Supercell API</div>
            </div>
            <UnitProgressGrid
              title="Герои Деревни строителя (Battle Machine, Battle Copter)"
              detailType="hero"
              items={builderHeroes}
              emptyText="Герои Деревни строителя ещё не открыты в профиле API."
            />
            <UnitProgressGrid
              title="Войска Деревни строителя"
              detailType="troop"
              items={builderTroops}
              emptyText="Войска Деревни строителя отсутствуют в профиле API."
            />
          </div>
        )}

        {profileTab === 'history' && (
          <div className="space-y-6">
            {/* Period progress & stats (without charts) */}
            <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3.5">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-100">
                    Прогресс игрока за выбранный период
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-400">
                    Только реальные повышения уровней, зафиксированные при проверках через Supercell API
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-1 rounded-md border border-slate-800 bg-[#0B0F17] p-1">
                  {UPGRADE_PERIOD_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setHistoryPeriod(opt.id)}
                      className={`px-2.5 py-1 text-xs rounded transition-colors whitespace-nowrap ${
                        historyPeriod === opt.id
                          ? 'bg-amber-500 text-slate-950 font-semibold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6 text-xs">
                <div className="rounded border border-slate-800 bg-[#0B0F17] p-3">
                  <div className="text-slate-400">Улучшений</div>
                  <div className="mt-1 font-mono text-lg font-bold tabular-nums text-amber-400">
                    {periodGainStats.eventsCount}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#0B0F17] p-3">
                  <div className="text-slate-400">Уровней набрано</div>
                  <div className="mt-1 font-mono text-lg font-bold tabular-nums text-emerald-400">
                    +{periodGainStats.totalLevels}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#0B0F17] p-3">
                  <div className="text-slate-400">Герои</div>
                  <div className="mt-1 font-mono text-lg font-bold tabular-nums text-amber-300">
                    +{periodGainStats.heroesLevels}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#0B0F17] p-3">
                  <div className="text-slate-400">Оборудование</div>
                  <div className="mt-1 font-mono text-lg font-bold tabular-nums text-violet-300">
                    +{periodGainStats.equipmentLevels}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#0B0F17] p-3">
                  <div className="text-slate-400">Войска и осадки</div>
                  <div className="mt-1 font-mono text-lg font-bold tabular-nums text-sky-400">
                    +{periodGainStats.troopsLevels}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-[#0B0F17] p-3">
                  <div className="text-slate-400">Закл. и питомцы</div>
                  <div className="mt-1 font-mono text-lg font-bold tabular-nums text-cyan-300">
                    +{periodGainStats.spellsAndPetsLevels}
                  </div>
                </div>
              </div>
            </section>

            {/* Detailed Player Upgrade History List */}
            <section className="rounded-lg border border-slate-800 bg-[#121824] overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-5 py-4">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-100">
                    История всех обнаруженных улучшений ({filteredPlayerEvents.length})
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-400">
                    Точное название объекта из API, изменение уровня и время обнаружения
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-1 rounded-md border border-slate-800 bg-[#0B0F17] p-1">
                  {(
                    [
                      { id: 'all', label: 'Все' },
                      { id: 'hero', label: 'Герои' },
                      { id: 'equipment', label: 'Оборудование' },
                      { id: 'troop', label: 'Войска' },
                      { id: 'spell', label: 'Заклинания' },
                      { id: 'pet', label: 'Питомцы' },
                      { id: 'siege', label: 'Осадные' },
                      { id: 'townhall', label: 'Ратуша' },
                    ] as const
                  ).map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setHistoryCat(c.id)}
                      className={`px-2 py-1 text-xs rounded transition-colors whitespace-nowrap ${
                        historyCat === c.id
                          ? 'bg-slate-800 text-amber-400 font-medium'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              {filteredPlayerEvents.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 leading-relaxed">
                  {playerUpgradeEvents.length === 0
                    ? 'Для этого игрока пока не обнаружено повышений уровней. Когда при следующей проверке уровень героя, войска, заклинания, питомца, оборудования или Ратуши вырастет — событие появится здесь.'
                    : 'За выбранный период и категорию улучшений не найдено. Выберите «За всё время» или другую категорию.'}
                </div>
              ) : (
                <div className="divide-y divide-slate-800/70">
                  {filteredPlayerEvents.map((ev) => {
                    const detailType = resolveUpgradeDetailType(ev);
                    const apiObjName = ev.apiName || ev.itemNameRu;
                    const ruName = translateCocUnitNameRu(apiObjName);
                    const delta = Math.max(1, ev.toLevel - ev.fromLevel);

                    return (
                      <div
                        key={ev.id}
                        className="flex flex-col gap-3 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between"
                      >
                        <div className="flex items-start gap-3 min-w-0">
                          <CocUnitBadge
                            detailType={detailType}
                            apiName={apiObjName}
                            isSuperTroop={ev.isSuperTroop}
                            size="md"
                          />
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-sm font-semibold text-slate-100">{apiObjName}</span>
                              {ruName !== apiObjName && (
                                <span className="text-xs text-slate-400">({ruName})</span>
                              )}
                            </div>
                            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                              <span className="text-slate-300 font-medium">
                                {getUpgradeCategoryShortLabel(detailType)}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span className="text-sky-300 font-mono text-[11px]">
                                {getVillageShortTitle(resolveUpgradeVillage(ev) as VillageId)}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span className="text-slate-300 font-mono text-[11px]">
                                {getDataSourceLabel(ev.source)}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span className="inline-flex items-center gap-1 text-slate-400">
                                <Clock className="h-3 w-3 text-slate-500" />
                                Обнаружено {formatDateTimeRu(ev.timestamp)}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 pl-12 sm:pl-0 shrink-0 font-mono tabular-nums">
                          <div className="flex items-center gap-1.5 rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-1.5 text-sm">
                            <span className="text-slate-400">Ур. {ev.fromLevel}</span>
                            <ArrowRight className="h-3.5 w-3.5 text-emerald-400" />
                            <span className="font-bold text-emerald-400">{ev.toLevel}</span>
                          </div>
                          <span className="text-xs font-semibold text-emerald-300">
                            +{delta} {delta === 1 ? 'уровень' : delta >= 2 && delta <= 4 ? 'уровня' : 'уровней'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          </div>
        )}

        {profileTab === 'achievements' && (
          <section className="rounded-lg border border-slate-800 bg-[#121824]">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-5 py-4">
              <div>
                <h2 className="font-display text-base font-semibold text-slate-100">
                  Достижения игрока ({p.achievements.length})
                </h2>
                <p className="mt-0.5 text-xs text-slate-400">
                  Набрано {totalAchStars} из {maxAchStars} звёзд достижений
                </p>
              </div>
              <div className="flex items-center gap-1 rounded-md border border-slate-800 bg-[#0B0F17] p-1">
                {(
                  [
                    { id: 'all', label: 'Все' },
                    { id: 'completed', label: 'Выполнены (3★)' },
                    { id: 'in_progress', label: 'В процессе' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setAchFilter(f.id)}
                    className={`px-2.5 py-1 text-xs rounded transition-colors whitespace-nowrap ${
                      achFilter === f.id
                        ? 'bg-slate-800 text-amber-400 font-medium'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="divide-y divide-slate-800/60">
              {filteredAchievements.map((ach, idx) => {
                const target = Math.max(1, ach.target);
                const pct = Math.min(100, Math.round((ach.value / target) * 100));
                return (
                  <div
                    key={`${ach.name}-${idx}`}
                    className="flex flex-col gap-2 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-slate-100">{ach.name}</span>
                        <span className="inline-flex items-center gap-0.5">
                          {[1, 2, 3].map((s) => (
                            <Star
                              key={s}
                              className={`h-3.5 w-3.5 ${
                                s <= ach.stars
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-slate-700'
                              }`}
                            />
                          ))}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-slate-400">{ach.info}</p>
                    </div>

                    <div className="w-full sm:w-56 shrink-0">
                      <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                        <span className="text-slate-300">
                          {ach.value.toLocaleString('ru-RU')} / {ach.target.toLocaleString('ru-RU')}
                        </span>
                        <span className="text-amber-400">{pct}%</span>
                      </div>
                      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                        <div
                          className={`h-full ${ach.stars >= 3 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
              {filteredAchievements.length === 0 && (
                <div className="py-8 text-center text-xs text-slate-500">
                  Достижения по выбранному фильтру не найдены.
                </div>
              )}
            </div>
          </section>
        )}

        {profileTab === 'village_json' && (p.buildingsVerified || p.jsonVillage) && (
          <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setJsonVillageTab('home')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    jsonVillageTab === 'home'
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-[#0B0F17] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  HOME VILLAGE — Родная деревня
                </button>
                <button
                  type="button"
                  onClick={() => setJsonVillageTab('builderBase')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    jsonVillageTab === 'builderBase'
                      ? 'bg-sky-500 text-slate-950'
                      : 'bg-[#0B0F17] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  BUILDER BASE — Деревня строителя
                </button>
              </div>
              <span className="font-mono text-[11px] text-sky-300">Источник: Доп. JSON Export</span>
            </div>

                {jsonVillageTab === 'home' ? (
                  p.jsonVillage && p.jsonVillage.homeBuildings.length > 0 ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        {[...p.jsonVillage.homeBuildings, ...p.jsonVillage.homeTraps].map((item) => (
                          <div
                            key={`${item.dataId}-${item.name}`}
                            className="rounded-md border border-slate-800 bg-[#0B0F17] p-3"
                          >
                            <div className="flex items-center justify-between text-xs gap-2">
                              <span className="font-semibold text-slate-100 truncate">{item.name}</span>
                              <span className="font-mono text-[11px] text-sky-300 shrink-0">
                                {item.levels.length} шт.
                              </span>
                            </div>
                            {item.nameRu !== item.name && (
                              <div className="text-[11px] text-slate-500 truncate">{item.nameRu}</div>
                            )}
                            <div className="mt-2 flex flex-wrap gap-1.5 font-mono text-xs tabular-nums">
                              {item.levels.map((lv, idx) => (
                                <span
                                  key={idx}
                                  className="rounded bg-slate-800 px-1.5 py-0.5 text-amber-300"
                                >
                                  {lv}
                                </span>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                      {p.jsonVillage.homeWallsTotal > 0 && (
                        <div className="rounded-md border border-slate-800 bg-[#0B0F17] p-3 space-y-2">
                          <div className="text-xs font-semibold text-slate-200">
                            Стены HOME VILLAGE ({p.jsonVillage.homeWallsTotal} шт.)
                          </div>
                          <div className="flex flex-wrap gap-2 font-mono text-xs">
                            {Object.entries(p.jsonVillage.homeWallsByLevel)
                              .sort((a, b) => Number(b[0]) - Number(a[0]))
                              .map(([lv, cnt]) => (
                                <span key={lv} className="rounded bg-slate-800 px-2 py-0.5 text-amber-300">
                                  Ур. {lv}: {cnt} шт.
                                </span>
                              ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-wrap items-center gap-1 border-b border-slate-800 pb-3">
                        {(
                          [
                            { id: 'defenses', label: 'Оборона' },
                            { id: 'traps', label: 'Ловушки' },
                            { id: 'resources', label: 'Ресурсы и армия' },
                            { id: 'walls', label: 'Стены' },
                          ] as const
                        ).map((cat) => (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={() => setVillageCat(cat.id)}
                            className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                              villageCat === cat.id
                                ? 'bg-amber-500 text-slate-950 font-semibold'
                                : 'text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            {cat.label}
                          </button>
                        ))}
                      </div>

                      {villageCat === 'walls' ? (
                        <div className="divide-y divide-slate-800/70">
                          {Object.entries(p.walls.byLevel)
                            .sort((a, b) => Number(b[0]) - Number(a[0]))
                            .map(([lv, cnt]) => (
                              <div key={lv} className="flex justify-between py-2.5 text-xs sm:text-sm">
                                <span className="font-mono text-slate-200">Стены Ур. {lv}</span>
                                <span className="font-mono tabular-nums text-amber-400">{cnt} шт.</span>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                          {p.items
                            .filter((i) => i.category === villageCat)
                            .map((item) => (
                              <div
                                key={item.id}
                                className="rounded-md border border-slate-800 bg-[#0B0F17] p-3"
                              >
                                <div className="flex items-center justify-between text-xs">
                                  <span className="font-semibold text-slate-100">{item.nameRu}</span>
                                  <span className="font-mono text-slate-400">Макс: {item.maxLevelForTh}</span>
                                </div>
                                <div className="mt-2 flex flex-wrap gap-1.5 font-mono text-xs tabular-nums">
                                  {item.levels.map((lv, idx) => (
                                    <span
                                      key={idx}
                                      className={`rounded px-1.5 py-0.5 ${
                                        lv >= item.maxLevelForTh
                                          ? 'bg-emerald-500/15 text-emerald-400'
                                          : 'bg-slate-800 text-slate-200'
                                      }`}
                                    >
                                      {lv}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            ))}
                        </div>
                      )}
                    </>
                  )
                ) : p.jsonVillage && p.jsonVillage.builderBuildings.length > 0 ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                      {[...p.jsonVillage.builderBuildings, ...p.jsonVillage.builderTraps].map((item) => (
                        <div
                          key={`${item.dataId}-${item.name}`}
                          className="rounded-md border border-slate-800 bg-[#0B0F17] p-3"
                        >
                          <div className="flex items-center justify-between text-xs gap-2">
                            <span className="font-semibold text-slate-100 truncate">{item.name}</span>
                            <span className="font-mono text-[11px] text-sky-300 shrink-0">
                              {item.levels.length} шт.
                            </span>
                          </div>
                          {item.nameRu !== item.name && (
                            <div className="text-[11px] text-slate-500 truncate">{item.nameRu}</div>
                          )}
                          <div className="mt-2 flex flex-wrap gap-1.5 font-mono text-xs tabular-nums">
                            {item.levels.map((lv, idx) => (
                              <span
                                key={idx}
                                className="rounded bg-slate-800 px-1.5 py-0.5 text-sky-300"
                              >
                                {lv}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                    {p.jsonVillage.builderWallsTotal > 0 && (
                      <div className="rounded-md border border-slate-800 bg-[#0B0F17] p-3 space-y-2">
                        <div className="text-xs font-semibold text-slate-200">
                          Стены BUILDER BASE ({p.jsonVillage.builderWallsTotal} шт.)
                        </div>
                        <div className="flex flex-wrap gap-2 font-mono text-xs">
                          {Object.entries(p.jsonVillage.builderWallsByLevel)
                            .sort((a, b) => Number(b[0]) - Number(a[0]))
                            .map(([lv, cnt]) => (
                              <span key={lv} className="rounded bg-slate-800 px-2 py-0.5 text-sky-300">
                                Ур. {lv}: {cnt} шт.
                              </span>
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="rounded-md border border-slate-800 bg-[#0B0F17] p-4 text-xs text-slate-400">
                    В дополнительном JSON-экспорте этого игрока отсутствовали поля BUILDER BASE (<span className="font-mono">buildings2</span> / <span className="font-mono">traps2</span>).
                  </div>
                )}
          </section>
        )}
      </div>
    );
  }

  // Roster View (GET /clans/{clanTag}/members + enriched player stats)
  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Участники клана и инспектор игроков
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Нажмите на любого участника для подробной статистики из{' '}
            <span className="font-mono text-slate-300">GET /players/{'{playerTag}'}</span>
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenGlobalSearch}
          className="rounded-md border border-slate-700 bg-[#121824] px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-amber-500/60 hover:text-amber-400 transition-colors self-start sm:self-auto whitespace-nowrap"
        >
          Найти игрока по #тегу
        </button>
      </section>

      {state.players.length === 0 ? (
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
          Сначала подключите клан на вкладке «Обзор» или откройте поиск игрока по #тегу.
        </div>
      ) : (
        <section className="rounded-lg border border-slate-800 bg-[#121824]">
          {/* Search & Sort Toolbar */}
          <div className="flex flex-col gap-3 border-b border-slate-800 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="relative w-full lg:w-80">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder="Поиск по имени или #тегу..."
                className="w-full rounded-md border border-slate-800 bg-[#0B0F17] py-2 pl-9 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex items-center gap-1.5 rounded-md border border-slate-800 bg-[#0B0F17] px-2.5 py-1.5 text-xs text-slate-400">
                <ArrowDownUp className="h-3.5 w-3.5 text-slate-500" />
                <select
                  value={sortKey}
                  onChange={(e) => setSortKey(e.target.value as MemberSortKey)}
                  className="bg-transparent text-xs text-slate-200 focus:outline-none"
                >
                  <option value="trophies">По трофеям</option>
                  <option value="townHallLevel">По уровню Ратуши</option>
                  <option value="expLevel">По опыту</option>
                  <option value="donations">По донатам</option>
                  <option value="donationsReceived">По полученным войскам</option>
                  <option value="warStars">По звёздам войны</option>
                </select>
              </div>

              <button
                type="button"
                onClick={() => setSortDir((d) => (d === 'desc' ? 'asc' : 'desc'))}
                className="rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-1.5 text-xs font-mono text-slate-300 hover:border-amber-500/60"
              >
                {sortDir === 'desc' ? '↓ По убыванию' : '↑ По возрастанию'}
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-800/80 text-xs font-medium text-slate-400 bg-[#0B0F17]/40">
                  <th className="px-4 py-2.5">#</th>
                  <th className="px-4 py-2.5">Игрок</th>
                  <th className="px-3 py-2.5">Роль</th>
                  <th className="px-3 py-2.5 text-right">TH</th>
                  <th className="px-3 py-2.5 text-right">BH</th>
                  <th className="px-3 py-2.5 text-right">Опыт</th>
                  <th className="px-3 py-2.5 text-right">Трофеи</th>
                  <th className="px-3 py-2.5 text-right">Троф. ДС</th>
                  <th className="px-3 py-2.5">Лига</th>
                  <th className="px-3 py-2.5 text-right">Донаты</th>
                  <th className="px-3 py-2.5 text-right">Получено</th>
                  <th className="px-3 py-2.5 text-right">Звёзды КВ</th>
                  <th className="px-3 py-2.5 text-right">Достиж.</th>
                  <th className="px-4 py-2.5 text-right">Столица</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {pageMembers.map((m, idx) => {
                  const completedAch = m.achievements.filter((a) => a.stars === 3).length;
                  return (
                    <tr
                      key={m.tag}
                      onClick={() => openMemberProfile(m.tag)}
                      className="cursor-pointer transition-colors hover:bg-slate-800/40"
                    >
                      <td className="px-4 py-2.5 font-mono text-xs tabular-nums text-slate-500">
                        {(safePage - 1) * pageSize + idx + 1}
                      </td>
                      <td className="px-4 py-2.5 whitespace-nowrap">
                        <div className="font-medium text-slate-100">{m.name}</div>
                        <div className="font-mono text-[11px] text-slate-500">{m.tag}</div>
                      </td>
                      <td className="px-3 py-2.5 text-xs text-slate-300 whitespace-nowrap">
                        {ROLE_LABELS_RU[m.role]}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-amber-400">
                        {m.townHallLevel}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-sky-400">
                        {m.builderHallLevel || '—'}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                        {m.expLevel}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono font-semibold tabular-nums text-slate-100">
                        {m.trophies.toLocaleString('ru-RU')}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-sky-400">
                        {m.builderBaseTrophies.toLocaleString('ru-RU')}
                      </td>
                      <td className="px-3 py-2.5 whitespace-nowrap text-xs text-slate-300">
                        <span className="inline-flex items-center gap-1.5">
                          {m.league?.iconUrl && (
                            <img
                              src={m.league.iconUrl}
                              alt={m.league.name}
                              referrerPolicy="no-referrer"
                              className="h-4 w-4 object-contain"
                            />
                          )}
                          <span>{m.league?.name ?? 'Без лиги'}</span>
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-emerald-400">
                        {m.donations.toLocaleString('ru-RU')}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                        {m.donationsReceived.toLocaleString('ru-RU')}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-amber-400">
                        {m.warStars.toLocaleString('ru-RU')}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                        {m.achievements.length > 0 ? `${completedAch}/${m.achievements.length}` : '—'}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-300">
                        {m.clanCapitalContributions.toLocaleString('ru-RU')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination Footer */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 px-5 py-3 text-xs text-slate-400">
            <span className="tabular-nums">
              Показано {pageMembers.length} из {filteredSortedMembers.length} участников
            </span>
            {totalPages > 1 && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={safePage <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="inline-flex items-center gap-1 rounded border border-slate-700 bg-[#0B0F17] px-2.5 py-1 text-slate-300 disabled:opacity-40"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                  Назад
                </button>
                <span className="font-mono tabular-nums">
                  {safePage} / {totalPages}
                </span>
                <button
                  type="button"
                  disabled={safePage >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  className="inline-flex items-center gap-1 rounded border border-slate-700 bg-[#0B0F17] px-2.5 py-1 text-slate-300 disabled:opacity-40"
                >
                  Вперёд
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
