import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Lock, 
  FileCheck, 
  Upload, 
  CreditCard,
  UserCheck,
  Calendar,
  Check
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface AdvancedKycModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdvancedKycModal: React.FC<AdvancedKycModalProps> = ({ isOpen, onClose }) => {
  const { advancedKyc, submitAdvancedKyc, currentUser } = useApp();
  const [fullName, setFullName] = useState(advancedKyc?.fullName || currentUser?.name || '');
  const [aadhaarNumber, setAadhaarNumber] = useState('');
  const [panNumber, setPanNumber] = useState('');
  const [dob, setDob] = useState(advancedKyc?.dateOfBirth || '1998-08-15');
  const [consent, setConsent] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const isVerified = advancedKyc?.overallStatus === 'verified';
  const isPending = advancedKyc?.overallStatus === 'pending';
  const isRejected = advancedKyc?.overallStatus === 'rejected';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!fullName.trim() || fullName.trim().length < 3) {
      setErrorMsg('Please enter your full legal name as per government records.');
      return;
    }

    const cleanAadhaar = aadhaarNumber.replace(/[\s-]+/g, '');
    if (!/^\d{12}$/.test(cleanAadhaar)) {
      setErrorMsg('Aadhaar number must be exactly 12 numeric digits.');
      return;
    }

    const cleanPan = panNumber.trim().toUpperCase();
    if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(cleanPan)) {
      setErrorMsg('PAN card number must be valid 10-character alphanumeric (e.g. ABCDE1234F).');
      return;
    }

    if (!consent) {
      setErrorMsg('Please consent to authorized identity verification via DigiLocker / UIDAI guidelines.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = submitAdvancedKyc(fullName, cleanAadhaar, cleanPan, dob);
      setIsSubmitting(false);
      if (res.success) {
        setSuccessMsg(res.message);
        setTimeout(() => {
          setSuccessMsg(null);
          onClose();
        }, 1500);
      } else {
        setErrorMsg(res.message);
      }
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div 
        className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-teal-500/40 shadow-2xl shadow-teal-950/40 p-5 sm:p-6 space-y-5 relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow Accent */}
        <div className="absolute top-0 right-0 w-40 h-40 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <UserCheck className="w-5 h-5 text-teal-400" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white">Authorized KYC Verification</h2>
              <p className="text-[11px] text-slate-400">Aadhaar (UIDAI) & PAN (Income Tax Dept) Verified</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Status Pill Card */}
        {advancedKyc && (
          <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-2 relative z-10 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-slate-400">Current KYC Verification State</span>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                isVerified 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : isPending 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
              }`}>
                {isVerified ? 'KYC Verified' : isPending ? 'Verification Pending' : 'KYC Rejected'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
              <div>
                <span className="text-[10px] text-slate-400 block">Aadhaar Masked</span>
                <span className="font-mono font-bold text-slate-200">{advancedKyc.aadhaarNumberMasked}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">PAN Masked</span>
                <span className="font-mono font-bold text-slate-200">{advancedKyc.panNumberMasked}</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-500 pt-1 border-t border-slate-850">
              Provider: <strong className="text-teal-400">{advancedKyc.authorizedProviderName}</strong> • Verified at: {advancedKyc.verifiedAt || advancedKyc.submittedAt}
            </p>
          </div>
        )}

        {/* KYC Submission Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs relative z-10">
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">
              Full Legal Name (as per Aadhaar / PAN)
            </label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="e.g. Subhodip Garai"
              required
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Aadhaar Number (12 Digits)
              </label>
              <input
                type="text"
                value={aadhaarNumber}
                onChange={(e) => setAadhaarNumber(e.target.value)}
                placeholder="XXXX XXXX XXXX"
                required
                maxLength={14}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 font-mono focus:outline-none focus:border-teal-500"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">Stored strictly masked as XXXX-XXXX-1234</span>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                PAN Number (10 Alphanumeric)
              </label>
              <input
                type="text"
                value={panNumber}
                onChange={(e) => setPanNumber(e.target.value.toUpperCase())}
                placeholder="e.g. ABCDE1234F"
                required
                maxLength={10}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 font-mono uppercase focus:outline-none focus:border-teal-500"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">Stored strictly masked as ABCDE****F</span>
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">
              Date of Birth (as per ID proof)
            </label>
            <input
              type="date"
              value={dob}
              onChange={(e) => setDob(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* User Consent Checkbox */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[10px] text-slate-300 flex items-start gap-2">
            <input
              type="checkbox"
              id="kycConsent"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 rounded border-slate-700 bg-slate-900 text-teal-500 cursor-pointer"
            />
            <label htmlFor="kycConsent" className="cursor-pointer">
              I give my voluntary consent to verify my masked identity credentials through authorized UIDAI / DigiLocker / NSDL verification gateways for Gold bullion trading and high-limit payouts.
            </label>
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <div className="pt-2 flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-750 transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black shadow-lg shadow-teal-500/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'Verifying...' : 'Submit KYC Verification'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
