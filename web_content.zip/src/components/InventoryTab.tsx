import React, { useState } from 'react';
import {
  Package,
  Search,
  Barcode,
  AlertTriangle,
  Clock,
  TrendingUp,
  Plus,
  X,
  ChevronLeft,
  DollarSign,
  Layers,
  Edit2,
  Check,
} from 'lucide-react';
import type { MedicineStock, MedicineItem } from '../types/pharmacy.ts';
import { formatIQD, formatDateArabic } from '../utils/calculations.ts';

interface InventoryTabProps {
  stocks: Record<string, MedicineStock>;
  medicines: MedicineItem[];
  onSelectMedicine: (barcode: string) => void;
  onAddNewMedicine: (med: Omit<MedicineItem, 'id'>) => void;
  onUpdateMinStock: (barcode: string, newMin: number) => void;
}

export const InventoryTab: React.FC<InventoryTabProps> = ({
  stocks,
  medicines,
  onSelectMedicine,
  onAddNewMedicine,
  onUpdateMinStock,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'lowStock' | 'nearExpiry' | 'outOfStock'>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // Quick edit min stock inline state
  const [editingMinStockBarcode, setEditingMinStockBarcode] = useState<string | null>(null);
  const [tempMinStock, setTempMinStock] = useState('');

  // New medicine form
  const [newName, setNewName] = useState('');
  const [newBarcode, setNewBarcode] = useState('');
  const [newScientific, setNewScientific] = useState('');
  const [newUnit, setNewUnit] = useState('باكيت');
  const [newMinStock, setNewMinStock] = useState('10');

  const stockList = Object.values(stocks);

  const filtered = stockList
    .filter((item) => {
      const matchSearch =
        !searchQuery ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.barcode.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchSearch) return false;

      if (filterMode === 'lowStock') {
        return item.remaining > 0 && item.remaining <= item.minStockAlert;
      }
      if (filterMode === 'nearExpiry') {
        return item.remaining > 0 && item.daysToExpiry !== null && item.daysToExpiry <= 90;
      }
      if (filterMode === 'outOfStock') {
        return item.remaining === 0;
      }
      return true;
    })
    .sort((a, b) => {
      // Sort out of stock or low stock first
      if (a.remaining === 0 && b.remaining > 0) return -1;
      if (b.remaining === 0 && a.remaining > 0) return 1;
      return a.name.localeCompare(b.name, 'ar');
    });

  const totalInventoryValue = stockList.reduce((sum, item) => sum + item.stockValue, 0);
  const totalItemsCount = stockList.length;
  const lowStockCount = stockList.filter((s) => s.remaining > 0 && s.remaining <= s.minStockAlert).length;
  const nearExpiryCount = stockList.filter((s) => s.remaining > 0 && s.daysToExpiry !== null && s.daysToExpiry <= 90).length;

  const handleSaveNewMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    onAddNewMedicine({
      name: newName.trim(),
      barcode: newBarcode.trim() || `629${Date.now().toString().slice(-10)}`,
      scientificName: newScientific.trim() || undefined,
      unit: newUnit.trim() || 'باكيت',
      minStockAlert: parseInt(newMinStock, 10) || 10,
    });

    setShowAddModal(false);
    setNewName('');
    setNewBarcode('');
    setNewScientific('');
    setNewUnit('باكيت');
  };

  return (
    <div className="space-y-4 pb-20 animate-fadeIn">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Package className="h-6 w-6 text-teal-700" />
            جرد المخزون والأدوية
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            متابعة الرصيد الحالي، متوسط كلفة الشراء، وقيمة البضاعة المخزونة لكل مادة
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center justify-center gap-2 rounded-xl bg-teal-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-teal-800 active:scale-98 transition self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          إضافة مادة دوائية جديدة
        </button>
      </div>

      {/* Inventory Value KPI Card */}
      <div className="rounded-2xl bg-gradient-to-r from-teal-800 to-teal-900 p-4 text-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-xs font-bold text-teal-200 flex items-center gap-1.5">
            <DollarSign className="h-4 w-4" />
            القيمة الإجمالية للمخزون بالمستودع
          </span>
          <div className="text-2xl sm:text-3xl font-black mt-1">
            {formatIQD(totalInventoryValue)}
          </div>
          <p className="text-xs text-teal-100/70 mt-0.5">
            مجموع (الرصيد المتبقي × متوسط كلفة الشراء لكل دواء)
          </p>
        </div>

        <div className="flex gap-2 text-center text-xs">
          <div className="rounded-xl bg-teal-950/50 p-2.5 border border-teal-700/50 min-w-20">
            <div className="text-teal-200">إجمالي المواد</div>
            <div className="text-base font-black mt-0.5">{totalItemsCount}</div>
          </div>
          <div className="rounded-xl bg-teal-950/50 p-2.5 border border-teal-700/50 min-w-20">
            <div className="text-amber-300">منخفض</div>
            <div className="text-base font-black mt-0.5">{lowStockCount}</div>
          </div>
          <div className="rounded-xl bg-teal-950/50 p-2.5 border border-teal-700/50 min-w-20">
            <div className="text-rose-300">قريب الانتهاء</div>
            <div className="text-base font-black mt-0.5">{nearExpiryCount}</div>
          </div>
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setFilterMode('all')}
          className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
            filterMode === 'all'
              ? 'bg-teal-700 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          جميع المواد ({stockList.length})
        </button>

        <button
          onClick={() => setFilterMode('lowStock')}
          className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition flex items-center gap-1.5 ${
            filterMode === 'lowStock'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-amber-700 hover:bg-amber-50'
          }`}
        >
          <AlertTriangle className="h-3.5 w-3.5" />
          أوشك على النفاد ({lowStockCount})
        </button>

        <button
          onClick={() => setFilterMode('nearExpiry')}
          className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition flex items-center gap-1.5 ${
            filterMode === 'nearExpiry'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-rose-700 hover:bg-rose-50'
          }`}
        >
          <Clock className="h-3.5 w-3.5" />
          قريب الصلاحية ({nearExpiryCount})
        </button>

        <button
          onClick={() => setFilterMode('outOfStock')}
          className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition ${
            filterMode === 'outOfStock'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          نفذ المخزون (0)
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute right-3.5 top-3 h-4 w-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث بالاسم أو الباركود..."
          className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pr-10 pl-3 text-xs placeholder:text-slate-400 focus:border-teal-500 focus:outline-hidden focus:ring-1 focus:ring-teal-500"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Instruction Tip */}
      <p className="text-[11px] text-slate-500">
        💡 <strong>تلميح:</strong> اضغط على أي دواء في القائمة لفتح <strong>شاشة تفاصيل المادة</strong> الكاملة وعرض الوجبات وحركات الشراء والبيع وتعديل البيانات.
      </p>

      {/* Medicine Stock Cards / Rows */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center text-slate-400">
          <Package className="mx-auto h-8 w-8 text-slate-300 mb-2" />
          <p className="text-sm font-bold text-slate-600">لا توجد أدوية مطابقة للبحث</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((item) => (
            <div
              key={item.barcode}
              onClick={() => onSelectMedicine(item.barcode)}
              className="group cursor-pointer rounded-2xl bg-white p-4 border border-slate-200/80 shadow-xs hover:border-teal-400 hover:shadow-md transition active:scale-[0.99]"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Barcode className="h-3 w-3 text-slate-400" />
                      {item.barcode}
                    </span>
                    {item.remaining === 0 ? (
                      <span className="text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-md">
                        نفذ المخزون
                      </span>
                    ) : item.isLowStock ? (
                      <span className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                        مخزون منخفض
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                        متوفر
                      </span>
                    )}

                    {item.isNearExpiry && (
                      <span className="text-[10px] font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md">
                        قريب الصلاحية ({item.daysToExpiry} يوم)
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-black text-slate-900 group-hover:text-teal-700 transition">
                    {item.name}
                  </h3>
                </div>

                <div className="text-left flex items-center gap-2">
                  <div>
                    <div className="text-lg font-black text-slate-900">
                      {item.remaining}{' '}
                      <span className="text-xs font-medium text-slate-500">
                        {item.unit || 'باكيت'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">الرصيد المتبقي</div>
                  </div>
                  <ChevronLeft className="h-5 w-5 text-slate-300 group-hover:text-teal-600 transition" />
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div>
                  <span className="text-slate-400">إجمالي المشتراة:</span>
                  <div className="font-bold text-slate-800">{item.totalBought}</div>
                </div>
                <div>
                  <span className="text-slate-400">إجمالي المباعة:</span>
                  <div className="font-bold text-slate-800">{item.totalSold}</div>
                </div>
                <div>
                  <span className="text-slate-400">متوسط كلفة الشراء:</span>
                  <div className="font-bold text-slate-800">{formatIQD(item.averageCost)}</div>
                </div>
                <div>
                  <span className="text-slate-400">قيمة المخزون الحالي:</span>
                  <div className="font-black text-teal-800">{formatIQD(item.stockValue)}</div>
                </div>
              </div>

              {/* Bottom bar with expiry and min alert */}
              <div className="mt-2 pt-2 border-t border-slate-50 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center gap-1.5">
                  <Clock className="h-3 w-3 text-slate-400" />
                  <span>
                    أقرب إكسباير: {item.nearestExpiry ? formatDateArabic(item.nearestExpiry) : 'لا يوجد'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span>حد التنبيه: {item.minStockAlert}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Medicine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl animate-scaleIn">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Package className="h-5 w-5 text-teal-700" />
                إضافة مادة دوائية جديدة
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewMedicine} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم الدواء التجاري <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="مثال: Panadol Extra 500mg"
                  required
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-teal-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  الباركود (اختياري - سيتم توليده تلقائياً إذا ترك فارغاً)
                </label>
                <input
                  type="text"
                  value={newBarcode}
                  onChange={(e) => setNewBarcode(e.target.value)}
                  placeholder="رقم الباركود"
                  dir="ltr"
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-mono focus:border-teal-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  الاسم العلمي / الشركة المصنعة
                </label>
                <input
                  type="text"
                  value={newScientific}
                  onChange={(e) => setNewScientific(e.target.value)}
                  placeholder="مثال: Paracetamol (GSK)"
                  className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-teal-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الوحدة
                  </label>
                  <select
                    value={newUnit}
                    onChange={(e) => setNewUnit(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs focus:border-teal-500 focus:bg-white focus:outline-hidden"
                  >
                    <option value="باكيت">باكيت</option>
                    <option value="علبة">علبة</option>
                    <option value="شريط">شريط</option>
                    <option value="قارورة">قارورة</option>
                    <option value="كرتونة">كرتونة</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    حد التنبيه الأدنى
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newMinStock}
                    onChange={(e) => setNewMinStock(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-bold focus:border-teal-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 rounded-xl bg-teal-700 px-5 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-teal-800 transition"
                >
                  <Check className="h-4 w-4" />
                  حفظ المادة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
