import React, { useState } from 'react';
import { AppSettings } from '../../types';
import {
  HardDrive,
  Download,
  Upload,
  Clock,
  FileCheck,
  ShieldCheck,
  Maximize2,
  AlertTriangle,
  ChevronRight,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getDualAccentInfo } from '../../utils/theme';

interface BackupAndRestoreCardProps {
  appSettings: AppSettings;
  onDownloadBackup: () => void;
  onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  autoSnapshots: { dateStr: string; data: any }[];
  onOpenInPopup?: () => void;
  onResetAllData?: () => void;
  isPopupView?: boolean;
}

export const BackupAndRestoreCard: React.FC<BackupAndRestoreCardProps> = ({
  appSettings,
  onDownloadBackup,
  onFileUpload,
  autoSnapshots = [],
  onOpenInPopup,
  onResetAllData,
  isPopupView = false,
}) => {
  const safeSnapshots = Array.isArray(autoSnapshots) ? autoSnapshots : [];
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const cardBg = isLight
    ? 'bg-white/95 border-slate-200 shadow-sm'
    : 'bg-slate-800/90 border-slate-700/70 shadow-md';
  const innerCardBg = isLight ? 'bg-slate-50/70 border-slate-200/80' : 'bg-slate-900/60 border-slate-800';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';
  const modalBg = isLight
    ? 'bg-white text-slate-900 border-slate-200'
    : 'bg-slate-900 text-slate-100 border-slate-700';

  return (
    <div
      className={`${isPopupView ? '' : `${cardBg} border rounded-3xl p-5`} space-y-4 transition-all`}
      id="backup-and-restore-section"
    >
      {/* Header */}
      {!isPopupView && (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className="p-2.5 rounded-2xl shadow-sm"
              style={{
                backgroundColor: `${dualAccent.primary.hex}20`,
                color: dualAccent.primary.hex,
              }}
            >
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className={`text-base font-black tracking-tight ${headingText}`}>
                  {isEn ? 'Backup & Restore' : 'ব্যাকআপ ও রিস্টোর (Backup & Restore)'}
                </h2>
                <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                  <ShieldCheck className="w-3 h-3" />
                  <span>JSON / E2EE</span>
                </span>
              </div>
              <p className={`text-[11px] ${subText}`}>
                {isEn
                  ? 'Export encrypted backup file to device or restore previously saved records'
                  : 'আপনার এনক্রিপ্টেড হিসাবের ফাইল ডিভাইসে ডাউনলোড করুন বা পুরোনো ফাইল থেকে রিস্টোর করুন'}
              </p>
            </div>
          </div>

          {onOpenInPopup && (
            <button
              type="button"
              onClick={onOpenInPopup}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800'
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
              }`}
              title={isEn ? 'Open in Popup Modal' : 'পপআপে খুলুন'}
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isEn ? 'Open Popup' : 'পপআপ ভিউ'}</span>
            </button>
          )}
        </div>
      )}

      {/* Main Download & Restore Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Export / Download */}
        <button
          type="button"
          onClick={onDownloadBackup}
          className={`p-4 rounded-2xl text-left border transition flex items-start gap-3 cursor-pointer active:scale-98 ${
            isLight
              ? 'bg-slate-50/90 hover:bg-slate-100/90 border-slate-200'
              : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800'
          }`}
        >
          <div
            className={`p-2.5 rounded-xl shrink-0 ${
              isLight ? 'bg-emerald-100 text-emerald-800' : 'bg-emerald-950 text-emerald-400'
            }`}
          >
            <Download className="w-5 h-5" />
          </div>
          <div>
            <p className={`text-xs font-bold ${headingText}`}>
              {isEn ? 'Download Backup File' : 'ডাউনলোড ব্যাকআপ ফাইল'}
            </p>
            <p className={`text-[10px] mt-0.5 ${subText}`}>
              {isEn
                ? 'Save your encrypted financial JSON backup file directly to your device.'
                : 'আপনার হিসাবের এনক্রিপ্টেড JSON ফাইল ডিভাইসে সেভ করুন।'}
            </p>
          </div>
        </button>

        {/* Import / Restore */}
        <label
          className={`p-4 rounded-2xl text-left border transition flex items-start gap-3 cursor-pointer active:scale-98 ${
            isLight
              ? 'bg-slate-50/90 hover:bg-slate-100/90 border-slate-200'
              : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800'
          }`}
        >
          <div
            className={`p-2.5 rounded-xl shrink-0 ${
              isLight ? 'bg-indigo-100 text-indigo-800' : 'bg-indigo-950 text-indigo-400'
            }`}
          >
            <Upload className="w-5 h-5" />
          </div>
          <div>
            <p className={`text-xs font-bold ${headingText}`}>
              {isEn ? 'Restore Backup File' : 'রিস্টোর ব্যাকআপ ফাইল'}
            </p>
            <p className={`text-[10px] mt-0.5 ${subText}`}>
              {isEn
                ? 'Load data from a previously saved JSON backup file.'
                : 'পূর্বে সেভ করা ব্যাকআপ ফাইল থেকে ডেটা লোড করুন।'}
            </p>
          </div>
          <input type="file" accept=".json" onChange={onFileUpload} className="hidden" />
        </label>
      </div>

      {/* Local Auto-Snapshot History */}
      <div className={`p-4 rounded-2xl border ${innerCardBg} space-y-3`}>
        <div className="flex items-center justify-between">
          <h3 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
            <Clock className="w-4 h-4 text-amber-500" />
            <span>{isEn ? 'Local Auto-Snapshot History (Offline)' : 'অটো-স্ন্যাপশট হিস্ট্রি (অফলাইন)'}</span>
          </h3>
          <span className={`text-[10px] font-semibold ${subText}`}>
            {autoSnapshots.length} {isEn ? 'snapshots' : 'স্ন্যাপশট'}
          </span>
        </div>

        <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
          {safeSnapshots.length === 0 ? (
            <p className={`text-xs ${subText} py-1 text-center`}>
              {isEn ? 'No local snapshots found yet.' : 'কোনো লোকাল স্ন্যাপশট পাওয়া যায়নি।'}
            </p>
          ) : (
            safeSnapshots.map((snap, idx) => (
              <div
                key={idx}
                className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
                  isLight ? 'bg-white border-slate-200/90' : 'bg-slate-800/80 border-slate-700/60'
                }`}
              >
                <div className={`flex items-center gap-2 ${headingText}`}>
                  <FileCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="text-[11px] font-medium">
                    {isEn ? 'Auto Snapshot: ' : 'স্বয়ংক্রিয় স্ন্যাপশট: '}
                    {snap.dateStr}
                  </span>
                </div>
                <span className={`text-[10px] font-mono ${subText}`}>
                  {snap.data?.transactions?.length || 0} {isEn ? 'txns' : 'লেনদেন'}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Danger Zone: Reset All Data (Settings' Reset All Data button and confirmation popup) */}
      {onResetAllData && (
        <>
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setIsResetModalOpen(true)}
              className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between group transition cursor-pointer hover:border-rose-400 ${
                isLight
                  ? 'bg-rose-50/60 border-rose-200/90 hover:bg-rose-50'
                  : 'bg-rose-950/20 border-rose-500/30 hover:bg-rose-950/30'
              }`}
              id="btn-open-backup-restore-reset-modal"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <div
                  className={`p-3 rounded-2xl border transition shrink-0 ${
                    isLight
                      ? 'bg-rose-100 text-rose-700 border-rose-200'
                      : 'bg-rose-950/60 text-rose-400 border-rose-500/40'
                  }`}
                >
                  <AlertTriangle className="w-5 h-5" />
                </div>

                <div className="truncate">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-bold text-rose-600 dark:text-rose-400 transition">
                      {isEn ? 'Reset All Data' : 'সকল ডেটা রিসেট'}
                    </h3>
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full border bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30">
                      {isEn ? 'Danger Zone' : 'সতর্কতা'}
                    </span>
                  </div>
                  <p className={`text-[11px] ${subText} mt-0.5 truncate`}>
                    {isEn
                      ? 'Clear transactions, budgets and reset application to defaults'
                      : 'সকল লেনদেন ও হিসাব মুছে নতুন করে শুরু করতে ক্লিক করুন'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400 hidden sm:inline">
                  {isEn ? 'Reset' : 'রিসেট'}
                </span>
                <ChevronRight className="w-4 h-4 text-rose-400 group-hover:text-rose-600 group-hover:translate-x-0.5 transition" />
              </div>
            </button>
          </div>

          {/* Reset Confirmation Modal */}
          <AnimatePresence>
            {isResetModalOpen && (
              <div
                className={`fixed inset-0 z-50 flex items-center justify-center ${
                  isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/75 backdrop-blur-xs'
                } p-3 sm:p-4 animate-in fade-in duration-200`}
              >
                <div className="absolute inset-0" onClick={() => setIsResetModalOpen(false)} />

                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2, ease: 'easeOut' }}
                  className={`relative z-10 w-full max-w-md p-5 rounded-3xl shadow-2xl border border-rose-500/40 ${modalBg} space-y-4`}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-500 flex items-center justify-center mx-auto">
                    <AlertTriangle className="w-6 h-6" />
                  </div>

                  <div className="text-center space-y-1.5">
                    <h3 className="text-lg font-black text-rose-600 dark:text-rose-400">
                      {isEn ? 'Reset All Data?' : 'সকল ডেটা রিসেট করবেন?'}
                    </h3>
                    <p className={`text-xs ${subText} leading-relaxed`}>
                      {isEn
                        ? 'Warning: This will permanently erase all transactions, categories, budgets, and security settings. This action cannot be undone.'
                        : 'সতর্কতা: আপনার সমস্ত আয়-ব্যয়ের লেনদেন, বাজেট, কেনাকাটার তালিকা এবং কাস্টম সেটিংস স্থায়ীভাবে মুছে ডিফল্ট হয়ে যাবে।'}
                    </p>
                  </div>

                  <div
                    className={`p-3 rounded-2xl border text-xs text-rose-600 dark:text-rose-400 font-medium ${
                      isLight ? 'bg-rose-50 border-rose-200' : 'bg-rose-950/30 border-rose-900/50'
                    }`}
                  >
                    {isEn
                      ? 'Tip: Download a JSON Backup before resetting to protect your records.'
                      : 'পরামর্শ: রিসেট করার আগে ডেটার একটি ব্যাকআপ ফাইল ডাউনলোড করে রাখুন।'}
                  </div>

                  <div className="flex gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsResetModalOpen(false)}
                      className={`flex-1 py-2.5 rounded-2xl border font-bold text-xs transition cursor-pointer ${
                        isLight
                          ? 'border-slate-300 text-slate-700 hover:bg-slate-100'
                          : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {isEn ? 'Cancel' : 'বাতিল করুন'}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setIsResetModalOpen(false);
                        onResetAllData();
                      }}
                      className="flex-1 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
                    >
                      {isEn ? 'Yes, Reset All' : 'হ্যাঁ, সমস্ত ডেটা মুছুন'}
                    </button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>
        </>
      )}
    </div>
  );
};
