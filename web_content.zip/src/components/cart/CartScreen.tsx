import React, { useState } from 'react';
import {
  ShoppingBag, Trash2, Plus, Minus, ArrowRight,
  ShieldCheck, ArrowLeft, Tag, Check, Truck, Heart
} from 'lucide-react';
import { CartItem, Product } from '../../types';
import { getProductById } from '../../data/products';
import { api } from '../../services/api';

interface CartScreenProps {
  items: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
  onMoveToWishlist?: (product: Product, index: number) => void;
  onSelectProduct?: (product: Product) => void;
  deliveryCity?: string;
  deliveryPincode?: string;
  onChangeLocation?: () => void;
}

export const CartScreen: React.FC<CartScreenProps> = ({
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  onContinueShopping,
  onMoveToWishlist,
  onSelectProduct,
  deliveryCity = '',
  deliveryPincode = '',
  onChangeLocation,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponDiscount, setCouponDiscount] = useState(0);
  const [couponError, setCouponError] = useState<string | null>(null);

  const resolvedItems = items
    .map((it) => {
      const p = getProductById(it.product.id) || it.product;
      return {
        ...it,
        product: p,
      };
    })
    .filter((it) => Boolean(it.product));

  const originalSubtotal = resolvedItems.reduce(
    (sum, item) => sum + (item.product.originalPrice || item.product.price) * item.quantity,
    0
  );

  const discountedSubtotal = resolvedItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const discountTotal = Math.max(0, originalSubtotal - discountedSubtotal);
  const deliveryFee = 0; // 100% Free Shipping Promotion
  const grandTotal = Math.max(0, discountedSubtotal - couponDiscount + deliveryFee);

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    const code = couponCode.trim().toUpperCase();
    if (!code) return;

    try {
      const res: any = await api.validateCoupon(code, discountedSubtotal);
      if (res.valid && res.coupon) {
        setAppliedCoupon(res.coupon.code);
        setCouponDiscount(res.discountAmount || 0);
      } else {
        setCouponError(res.message || 'Invalid or expired coupon code');
      }
    } catch {
      if (code === 'WELCOME100') {
        setAppliedCoupon('WELCOME100');
        setCouponDiscount(Math.min(100, discountedSubtotal));
      } else {
        setCouponError('Invalid coupon code. Try WELCOME100');
      }
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponDiscount(0);
    setCouponCode('');
  };

  if (resolvedItems.length === 0) {
    return (
      <div className="w-full min-h-screen bg-[#FAFAFA] pb-20 flex flex-col">
        <div className="sticky top-0 z-30 bg-white border-b border-[#EAEAEA] px-4 py-3.5 flex items-center gap-3">
          <button
            onClick={onContinueShopping}
            className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] text-[#111111] flex items-center justify-center transition-all cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="text-base sm:text-lg font-black text-[#111111] tracking-tight">
            Shopping Cart
          </h1>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-sm mx-auto">
          <div className="w-20 h-20 rounded-full bg-white border border-[#EAEAEA] flex items-center justify-center text-[#111111] mb-4 shadow-2xs">
            <ShoppingBag className="w-10 h-10 stroke-[1.5]" />
          </div>
          <h2 className="text-xl font-black text-[#111111]">
            Your cart is empty
          </h2>
          <p className="text-xs text-[#666666] mt-2 leading-relaxed">
            Discover trending fashion, shoes, bags and lifestyle items on OMAZIFY.
          </p>
          <button
            onClick={onContinueShopping}
            className="mt-6 w-full py-3 px-6 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-all"
          >
            <span>Continue Shopping</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen bg-[#FAFAFA] pb-28 flex flex-col">
      {/* Sticky Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-[#EAEAEA] px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <button
              onClick={onContinueShopping}
              className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] text-[#111111] flex items-center justify-center transition-all cursor-pointer"
              aria-label="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h1 className="text-base sm:text-lg font-black text-[#111111] tracking-tight">
                My Shopping Bag ({resolvedItems.length})
              </h1>
              <p className="text-[10px] text-[#111111] font-bold uppercase tracking-wider">
                100% Cash on Delivery Available
              </p>
            </div>
          </div>
          <button
            onClick={onContinueShopping}
            className="text-xs font-bold text-[#111111] hover:underline cursor-pointer"
          >
            Add More
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto w-full px-4 py-3 space-y-4">
        {/* Delivery Destination Card */}
        <div className="p-3.5 bg-white rounded-xl sm:rounded-2xl border border-[#EAEAEA] shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-[#FAFAFA] text-[#000000] flex items-center justify-center flex-shrink-0 border border-[#EAEAEA]">
              <Truck className="w-4 h-4" />
            </div>
            <div className="truncate">
              <p className="text-xs font-bold text-[#111111] truncate">
                Deliver to: <span className="text-[#000000] font-black">{deliveryCity ? (deliveryPincode ? `${deliveryCity} - ${deliveryPincode}` : deliveryCity) : 'Select Delivery Location'}</span>
              </p>
              <p className="text-[10px] text-[#666666] font-medium">
                Standard Delivery: 2-3 business days • Free Shipping
              </p>
            </div>
          </div>
          {onChangeLocation && (
            <button
              onClick={onChangeLocation}
              className="text-xs font-black text-[#000000] hover:underline flex-shrink-0 ml-2 cursor-pointer"
            >
              Change
            </button>
          )}
        </div>

        {/* Free Shipping Banner */}
        <div className="p-3 rounded-xl bg-white border border-[#EAEAEA] flex items-center justify-between text-xs shadow-2xs">
          <div className="flex items-center gap-2 text-[#111111] font-bold">
            <ShieldCheck className="w-4 h-4 text-[#000000] flex-shrink-0" />
            <span>Eligible for FREE Express Delivery & COD</span>
          </div>
          <span className="text-[11px] font-black text-[#000000] bg-[#FFD400] px-2 py-0.5 rounded">
            FREE
          </span>
        </div>

        {/* Product Items List */}
        <div className="space-y-3">
          {resolvedItems.map((item, idx) => (
            <div
              key={`${item.product.id}-${idx}`}
              className="bg-white rounded-xl sm:rounded-2xl border border-[#EAEAEA] p-3 sm:p-4 shadow-2xs flex flex-col justify-between transition-all"
            >
              <div className="flex gap-3 sm:gap-4">
                <div
                  onClick={() => onSelectProduct?.(item.product)}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#FAFAFA] overflow-hidden flex items-center justify-center flex-shrink-0 cursor-pointer border border-[#EAEAEA]"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-full h-full object-cover object-center"
                    loading="lazy"
                  />
                </div>
                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3
                        onClick={() => onSelectProduct?.(item.product)}
                        className="text-xs sm:text-sm font-bold text-[#111111] hover:text-[#000000] transition-colors line-clamp-2 leading-tight cursor-pointer"
                      >
                        {item.product.name}
                      </h3>
                      <button
                        onClick={() => onRemoveItem(idx)}
                        className="text-[#666666] hover:text-rose-600 transition-colors p-1 cursor-pointer"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      {item.selectedSize && (
                        <span className="text-[10px] font-semibold text-[#111111] bg-[#FAFAFA] border border-[#EAEAEA] px-2 py-0.5 rounded-md">
                          Size: {item.selectedSize}
                        </span>
                      )}
                      {item.selectedColor && (
                        <span className="text-[10px] font-semibold text-[#111111] bg-[#FAFAFA] border border-[#EAEAEA] px-2 py-0.5 rounded-md">
                          Color: {item.selectedColor}
                        </span>
                      )}
                      <span className="text-[10px] font-bold text-[#111111] bg-[#FFF9DB] px-2 py-0.5 rounded-md border border-[#FFD400]/40">
                        In Stock
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#EAEAEA]">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-sm sm:text-base font-black text-[#111111]">
                        ₹{(item.product.price * item.quantity).toLocaleString()}
                      </span>
                      {item.product.originalPrice > item.product.price && (
                        <span className="text-[11px] text-[#666666] line-through">
                          ₹{(item.product.originalPrice * item.quantity).toLocaleString()}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 bg-[#FAFAFA] border border-[#EAEAEA] rounded-lg p-0.5">
                      <button
                        onClick={() => onUpdateQuantity(idx, item.quantity - 1)}
                        className="w-7 h-7 rounded-md bg-white hover:bg-[#EAEAEA] text-[#111111] flex items-center justify-center transition-all cursor-pointer shadow-2xs"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center text-xs font-black text-[#111111]">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(idx, item.quantity + 1)}
                        className="w-7 h-7 rounded-md bg-[#000000] text-[#FFD400] hover:bg-neutral-800 flex items-center justify-center transition-all cursor-pointer shadow-2xs"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {onMoveToWishlist && (
                <div className="mt-2.5 pt-2 border-t border-[#EAEAEA] flex items-center justify-end">
                  <button
                    onClick={() => onMoveToWishlist(item.product, idx)}
                    className="text-[11px] font-bold text-[#666666] hover:text-[#000000] flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Heart className="w-3.5 h-3.5" />
                    <span>Move to Wishlist</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Coupons Card */}
        <div className="bg-white rounded-xl sm:rounded-2xl border border-[#EAEAEA] p-4 shadow-2xs space-y-3">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-[#000000]" />
            <h3 className="text-xs sm:text-sm font-black text-[#111111] uppercase tracking-wider">
              Coupons & Offers
            </h3>
          </div>

          {appliedCoupon ? (
            <div className="p-3 rounded-xl bg-[#FFF9DB] border border-[#FFD400]/40 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-[#000000]" />
                <div>
                  <p className="text-xs font-bold text-[#111111]">
                    Coupon <span className="text-[#000000] font-black">{appliedCoupon}</span> Applied!
                  </p>
                  <p className="text-[10px] text-[#111111] font-semibold mt-0.5">
                    Saved ₹{couponDiscount.toLocaleString()} on this order
                  </p>
                </div>
              </div>
              <button
                onClick={handleRemoveCoupon}
                className="text-xs font-black text-[#000000] hover:underline cursor-pointer"
              >
                Remove
              </button>
            </div>
          ) : (
            <form onSubmit={handleApplyCoupon} className="space-y-2">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Enter Coupon Code (e.g. WELCOME100)"
                  className="flex-1 h-10 px-3.5 text-xs font-bold uppercase tracking-wider bg-[#FAFAFA] border border-[#EAEAEA] rounded-xl focus:bg-white focus:outline-none focus:border-[#000000] focus:ring-1 focus:ring-[#FFD400] transition-all placeholder:normal-case placeholder:font-medium placeholder:text-[#666666]"
                />
                <button
                  type="submit"
                  className="h-10 px-4 bg-[#000000] hover:bg-neutral-800 text-[#FFD400] font-black text-xs rounded-xl transition-colors cursor-pointer shadow-xs"
                >
                  Apply
                </button>
              </div>
              {couponError && <p className="text-xs font-semibold text-rose-600">{couponError}</p>}
            </form>
          )}
        </div>

        {/* PRICE DETAILS SECTION */}
        <div className="bg-white rounded-xl sm:rounded-2xl border border-[#EAEAEA] p-4 sm:p-5 shadow-2xs space-y-3">
          <h3 className="text-xs sm:text-sm font-black text-[#111111] uppercase tracking-wider pb-2 border-b border-[#EAEAEA]">
            PRICE DETAILS
          </h3>
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-[#666666]">
              <span>Subtotal ({resolvedItems.length} items)</span>
              <span className="font-semibold text-[#111111]">₹{originalSubtotal.toLocaleString()}</span>
            </div>

            {discountTotal > 0 && (
              <div className="flex items-center justify-between text-[#666666]">
                <span>Discount</span>
                <span className="font-bold text-[#111111]">- ₹{discountTotal.toLocaleString()}</span>
              </div>
            )}

            {couponDiscount > 0 && (
              <div className="flex items-center justify-between text-[#666666]">
                <span>Coupon Savings ({appliedCoupon})</span>
                <span className="font-bold text-[#111111]">- ₹{couponDiscount.toLocaleString()}</span>
              </div>
            )}

            <div className="flex items-center justify-between text-[#666666]">
              <span>Delivery Fee</span>
              <span className="font-bold text-[#111111]">FREE</span>
            </div>

            <div className="flex items-center justify-between text-[#666666]">
              <span>Payment Mode</span>
              <span className="font-bold text-[#111111]">Cash on Delivery</span>
            </div>

            <div className="pt-3 border-t border-[#EAEAEA] flex items-center justify-between text-sm sm:text-base font-black text-[#111111]">
              <span>Total Amount</span>
              <span className="text-[#000000] text-base sm:text-lg">₹{grandTotal.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="p-3 bg-white rounded-xl sm:rounded-2xl border border-[#EAEAEA] text-[11px] text-[#666666] flex items-center justify-around text-center shadow-2xs">
          <div>
            <p className="font-black text-[#111111]">100% Genuine</p>
            <p className="text-[10px] text-[#666666]">Verified OMAZIFY Quality</p>
          </div>
          <div className="w-px h-6 bg-[#EAEAEA]" />
          <div>
            <p className="font-black text-[#111111]">7-Day Return</p>
            <p className="text-[10px] text-[#666666]">Easy Doorstep Pickup</p>
          </div>
          <div className="w-px h-6 bg-[#EAEAEA]" />
          <div>
            <p className="font-black text-[#111111]">Cash on Delivery</p>
            <p className="text-[10px] text-[#666666]">Pay at Doorstep</p>
          </div>
        </div>
      </div>

      {/* Fixed Checkout CTA Bar */}
      <div
        className="fixed bottom-[54px] sm:bottom-[58px] left-0 right-0 z-30 bg-white border-t border-[#EAEAEA] px-4 py-2.5 shadow-[0_-2px_12px_rgba(0,0,0,0.06)]"
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          <div>
            <p className="text-[10px] text-[#666666] font-bold uppercase tracking-wider">
              Total Amount
            </p>
            <p className="text-base sm:text-xl font-black text-[#111111] leading-tight">
              ₹{grandTotal.toLocaleString()}
            </p>
          </div>
          <button
            onClick={onProceedToCheckout}
            className="flex-1 max-w-xs h-11 sm:h-12 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm cursor-pointer transition-all active:scale-95"
          >
            <span>Proceed to Checkout</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartScreen;
