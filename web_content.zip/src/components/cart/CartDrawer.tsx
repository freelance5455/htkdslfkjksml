import React, { useMemo } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, Plus, Minus } from 'lucide-react';
import { CartItem } from '../../types';
import { getProductById } from '../../data/products';
import { useLanguage } from '../../context/LanguageContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  onContinueShopping,
}) => {
  const { t } = useLanguage();

  const resolvedItems = useMemo(() => {
    return items
      .map((item) => {
        const rawId = item.product?.id || (item as any).productId;
        const authoritative = getProductById(rawId) || item.product;
        if (!authoritative) return null;
        return {
          ...item,
          product: authoritative,
        };
      })
      .filter((item): item is CartItem => item !== null);
  }, [items]);

  const subtotal = resolvedItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeDelivery = subtotal >= 999;
  const deliveryFee = resolvedItems.length === 0 ? 0 : isFreeDelivery ? 0 : 99;
  const grandTotal = subtotal + deliveryFee;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
        <div className="p-4 sm:p-5 border-b border-[#EAEAEA] flex items-center justify-between bg-white sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#000000]" />
            <h2 className="text-base font-black text-[#111111]">Shopping Cart</h2>
            <span className="text-xs bg-[#000000] text-[#FFD400] font-black px-2 py-0.5 rounded-full">
              {resolvedItems.reduce((acc, it) => acc + it.quantity, 0)} items
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] text-[#111111] flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {resolvedItems.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-[#FAFAFA] text-[#000000] border border-[#EAEAEA] flex items-center justify-center mb-4 shadow-2xs">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <h3 className="text-base font-black text-[#111111]">Your cart is empty</h3>
            <p className="text-xs text-[#666666] mt-1 max-w-xs">Discover trending fashion, shoes, bags and lifestyle items on OMAZIFY.</p>
            <button
              onClick={onContinueShopping}
              className="mt-6 px-6 py-2.5 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs shadow-xs transition-colors cursor-pointer"
            >
              Start Shopping
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {resolvedItems.map((item, index) => (
                <div
                  key={`${item.product.id}-${item.selectedSize}-${item.selectedColor}-${index}`}
                  className="flex gap-3 p-3 bg-white border border-[#EAEAEA] rounded-xl shadow-2xs"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-lg object-cover bg-[#FAFAFA] border border-[#EAEAEA] flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-[#111111] truncate">{item.product.name}</h4>
                      <p className="text-xs font-black text-[#000000] mt-0.5">
                        ₹{item.product.price.toLocaleString()}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border border-[#EAEAEA] rounded-lg bg-[#FAFAFA]">
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                          className="w-6 h-6 flex items-center justify-center text-[#111111] hover:bg-white cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center text-xs font-black text-[#111111]">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                          className="w-6 h-6 flex items-center justify-center text-[#111111] hover:bg-white cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => onRemoveItem(index)}
                        className="text-[#666666] hover:text-rose-600 transition-colors p-1 cursor-pointer"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-[#EAEAEA] bg-white space-y-3">
              <div className="space-y-1.5 text-xs text-[#666666]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-bold text-[#111111]">₹{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span className="font-bold text-[#111111]">
                    {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-black text-[#111111] pt-1.5 border-t border-[#EAEAEA]">
                  <span>Total Amount</span>
                  <span className="text-[#000000]">₹{grandTotal.toLocaleString()}</span>
                </div>
              </div>

              <button
                onClick={onProceedToCheckout}
                className="w-full py-3 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] text-[#000000] font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CartDrawer;
