import { useMemo } from "react";
import { areaPin } from "@/lib/rooms-model";
import { cn } from "@/lib/utils";

export type AreaCount = { area: string; count: number };

function shorten(area: string) {
  return area.length > 18 ? `${area.slice(0, 16)}…` : area;
}

export function BrowseAreaMap({
  groups,
  onSelect,
}: {
  groups: AreaCount[];
  onSelect: (area: string) => void;
}) {
  const pins = useMemo(
    () => groups.map((g) => ({ ...g, ...areaPin(g.area) })),
    [groups],
  );

  if (!pins.length) {
    return (
      <svg viewBox="0 0 600 320" className="block w-full rounded-md border border-line bg-paper-alt" role="img" aria-label="Area map">
        <text x="300" y="160" textAnchor="middle" fill="currentColor" className="fill-ink-soft text-[13px]">
          No available rooms to map yet.
        </text>
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 600 320" className="block w-full rounded-md border border-line bg-paper-alt" role="img" aria-label="Rooms grouped by area">
      {pins.map((p) => {
        const r = 12 + Math.min(p.count, 8) * 3;
        return (
          <g
            key={p.area}
            className="cursor-pointer"
            transform={`translate(${p.x},${p.y})`}
            onClick={() => onSelect(p.area)}
          >
            <circle r={r} className="fill-brass/85 stroke-brass-deep" strokeWidth="1" />
            <text y="4" textAnchor="middle" className="fill-white text-[10px] font-bold">
              {p.count}
            </text>
            <text y={r + 14} textAnchor="middle" className="fill-ink text-[10px]">
              {shorten(p.area)}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function PickAreaMap({
  groups,
  picked,
  onPickExisting,
}: {
  groups: AreaCount[];
  picked: string;
  onPickExisting: (area: string) => void;
}) {
  const pins = useMemo(
    () => groups.map((g) => ({ ...g, ...areaPin(g.area) })),
    [groups],
  );
  const extra = picked && !groups.some((g) => g.area === picked) ? { area: picked, ...areaPin(picked) } : null;

  return (
    <svg viewBox="0 0 600 320" className="block w-full rounded-md border border-line bg-paper-alt" role="img" aria-label="Pick an area">
      {pins.map((p) => {
        const selected = p.area === picked;
        return (
          <g
            key={p.area}
            className="cursor-pointer"
            transform={`translate(${p.x},${p.y})`}
            onClick={() => onPickExisting(p.area)}
          >
            <circle
              r={10 + Math.min(p.count, 8) * 2}
              className={cn(selected ? "fill-brass-deep" : "fill-ink-soft/45", "stroke-brass-deep")}
              strokeWidth={selected ? 2 : 1}
            />
            <text y="24" textAnchor="middle" className="fill-ink text-[10px]">
              {shorten(p.area)}
            </text>
          </g>
        );
      })}
      {extra ? (
        <g transform={`translate(${extra.x},${extra.y})`}>
          <circle r="12" className="fill-brass-deep stroke-brass-deep" strokeWidth="2" />
          <text y="24" textAnchor="middle" className="fill-ink text-[10px]">
            {shorten(extra.area)}
          </text>
        </g>
      ) : null}
    </svg>
  );
}
