import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Check,
  CheckCircle2,
  Sparkles,
  Palette,
  PenTool,
  Clock,
  Layers,
  Image as ImageIcon,
  Mic,
  FileText,
  ChevronRight,
  RotateCcw,
  Sun,
  Moon,
  Monitor,
  Tablet,
  Smartphone,
  Feather,
  SlidersHorizontal,
  Tag,
  Eraser,
  Lock,
} from "lucide-react";
import { CanvasThemeStyle, CanvasThemeDefinition, BoundedFramePreset, PaperThemeId } from "../types";
import {
  CanvasThemeController,
  CANVAS_THEME_DEFINITIONS,
} from "../utils/canvasThemeConfig";
import {
  usePaperNotebook,
  PAPER_THEME_DEFINITIONS,
  computeNotebookMetrics,
} from "../utils/paperNotebookConfig";
import { StylusSettingsManager } from "../utils/digitalInkEngine";
import { Frame, Maximize, EyeOff, Link as LinkIcon, BookOpen, Calendar } from "lucide-react";
import { RealisticPenPalette } from "./RealisticPenPalette";

interface CanvasThemeSelectorProps {
  onThemeChanged?: (style: CanvasThemeStyle) => void;
}

export const CanvasThemeSelector: React.FC<CanvasThemeSelectorProps> = ({
  onThemeChanged,
}) => {
  const [activeStyle, setActiveStyle] = useState<CanvasThemeStyle>(
    CanvasThemeController.getStyle()
  );
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [cardNightModes, setCardNightModes] = useState<Record<CanvasThemeStyle, boolean>>({
    hybrid_white: false,
    zen_sapphire: true,
    fluid_parchment: false,
    timeline_chronicle: false,
  });

  const {
    config: paperConfig,
    themeDef: paperThemeDef,
    setTheme: setPaperTheme,
    setFontSize: setPaperFontSize,
    setLineHeightRatio: setPaperLineHeightRatio,
    toggleRuledLines,
    toggleMarginLine,
  } = usePaperNotebook();

  const [activeFramePreset, setActiveFramePreset] = useState<BoundedFramePreset>(() => {
    return StylusSettingsManager.getSettings().activeFramePreset || "infinite";
  });

  const handleSelectFramePreset = (preset: BoundedFramePreset) => {
    setActiveFramePreset(preset);
    StylusSettingsManager.updateSettings({ activeFramePreset: preset });
    setToastMessage(`✓ Tuval çerçeve şablonu '${preset.toUpperCase()}' olarak ayarlandı.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  useEffect(() => {
    const unsubscribe = CanvasThemeController.subscribe((newStyle) => {
      setActiveStyle(newStyle);
    });
    return unsubscribe;
  }, []);

  const handleSelectStyle = (styleKey: CanvasThemeStyle) => {
    CanvasThemeController.setStyle(styleKey);
    setActiveStyle(styleKey);
    if (onThemeChanged) onThemeChanged(styleKey);

    const def = CANVAS_THEME_DEFINITIONS[styleKey];
    setToastMessage(`✓ Yazı Tahtası teması '${def.title}' olarak güncellendi.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const toggleCardNightMode = (styleKey: CanvasThemeStyle, e: React.MouseEvent) => {
    e.stopPropagation();
    setCardNightModes((prev) => ({
      ...prev,
      [styleKey]: !prev[styleKey],
    }));
  };

  const THEME_KEYS_ORDER: CanvasThemeStyle[] = [
    "hybrid_white",
    "zen_sapphire",
    "fluid_parchment",
    "timeline_chronicle",
  ];

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-200">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="p-3 sm:p-4 rounded-2xl bg-emerald-600 text-white flex items-center justify-between shadow-xl animate-in slide-in-from-top-2 duration-200 z-30">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{toastMessage}</span>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="p-1 hover:bg-emerald-700 rounded-lg text-emerald-100 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* ULTRA-REALISTIC STUDIO STYLUS PEN PALETTE */}
      <RealisticPenPalette />

      {/* TOP HEADER: Library Header with Time Badge & Title */}
      <div className="rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800">
        <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white px-5 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-2 border-b border-blue-900/50">
          <div className="flex items-center gap-2 text-xs font-semibold text-blue-200">
            <Clock className="w-3.5 h-3.5 text-blue-400" />
            <span>29.09.2026 00:41</span>
          </div>
          <h2 className="text-sm sm:text-base font-black tracking-wider uppercase text-blue-100 flex items-center gap-2">
            <Palette className="w-4 h-4 text-amber-400" />
            <span>TEMA KÜTÜPHANESİ</span>
          </h2>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Yazı Tahtası (Canvas Styles)</span>
          </div>
        </div>

        {/* Subtitle Intro */}
        <div className="p-4 sm:p-6 bg-white dark:bg-slate-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <PenTool className="w-5 h-5 text-teal-600 dark:text-teal-400" />
              <span>Yazı Tahtası & Kanvas Galerisi</span>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                4 Ana Stil & Gündüz/Gece Modu
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-2xl leading-relaxed">
              Masaüstü (PC), tablet ve akıllı telefonlarda esnek (adaptive) çalışan 4 özel kanvas temasını canlı ön izleme kartlarında test edin. Her kart üzerindeki <strong>Gündüz/Gece</strong> butonlarıyla varyasyonları görüntüleyebilirsiniz.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => handleSelectStyle("hybrid_white")}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              title="Varsayılan Minimalist Temaya Sıfırla"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Sıfırla</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4 ANA TEMA KARTLARI (2x2 GRID / INTERACTIVE DAY/NIGHT PREVIEW CARDS)      */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {THEME_KEYS_ORDER.map((styleKey) => {
          const def = CANVAS_THEME_DEFINITIONS[styleKey];
          const isSelected = activeStyle === styleKey;
          const isNight = cardNightModes[styleKey];

          return (
            <div
              key={styleKey}
              onClick={() => handleSelectStyle(styleKey)}
              className={`relative rounded-3xl border-2 transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between p-4 sm:p-5 ${
                isSelected
                  ? "border-teal-500 dark:border-teal-400 ring-4 ring-teal-500/20 bg-white dark:bg-slate-900 shadow-xl"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900/90 shadow-xs"
              }`}
            >
              {/* Card Header with Title, Badge & Day/Night Interactive Switcher */}
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                      isSelected
                        ? "border-teal-600 bg-teal-600 text-white shadow-xs"
                        : "border-slate-300 dark:border-slate-600 bg-transparent"
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-slate-900 dark:text-white">
                      {def.title}
                    </h4>
                    <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400">
                      {def.badge}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Interactive Day/Night Mode Switcher on Card */}
                  <button
                    type="button"
                    onClick={(e) => toggleCardNightMode(styleKey, e)}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold flex items-center gap-1.5 transition-all shadow-2xs border cursor-pointer ${
                      isNight
                        ? "bg-slate-800 text-amber-300 border-slate-700"
                        : "bg-amber-50 text-amber-900 border-amber-200"
                    }`}
                    title="Gündüz/Gece Modu Canlı Ön İzlemesi"
                  >
                    {isNight ? (
                      <>
                        <Moon className="w-3 h-3 text-amber-300 fill-amber-300" />
                        <span>Gece Modu</span>
                      </>
                    ) : (
                      <>
                        <Sun className="w-3 h-3 text-amber-500 fill-amber-500" />
                        <span>Gündüz Modu</span>
                      </>
                    )}
                  </button>

                  {isSelected && (
                    <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800 flex items-center gap-1 animate-pulse">
                      <Check className="w-3 h-3 stroke-[3]" />
                      <span className="hidden sm:inline">Aktif</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Live Simulated Mobile/Tablet Mockup Preview Graphic */}
              <div className="py-3.5">
                {styleKey === "hybrid_white" && (
                  /* ------------------------------------------------------------- */
                  /* 1. STYLE: MODERN MİNİMALİST (CLEAN CANVAS)                   */
                  /* ------------------------------------------------------------- */
                  <div
                    className={`w-full h-48 sm:h-56 rounded-2xl border transition-all duration-300 relative flex flex-col justify-between p-3 overflow-hidden select-none ${
                      isNight
                        ? "bg-[#1A1A1A] border-slate-800 text-white"
                        : "bg-[#FFFFFF] border-slate-200 text-slate-900 shadow-inner"
                    }`}
                  >
                    {/* Top Auto-hidden Bar */}
                    <div
                      className={`flex items-center justify-between text-[10px] px-2 py-1 rounded-xl transition-all ${
                        isNight ? "bg-slate-900/80 text-slate-300" : "bg-slate-100 text-slate-600"
                      }`}
                    >
                      <span className="font-mono text-[9px]">✨ Clean Canvas Focus Mode</span>
                      <span className="font-bold">Otomatik Gizli Üst Bar</span>
                    </div>

                    {/* Canvas Main Body */}
                    <div className="flex-1 my-2 flex flex-col justify-center px-3 space-y-2">
                      <h4
                        className={`text-base sm:text-lg font-black tracking-tight ${
                          isNight ? "text-white" : "text-slate-900"
                        }`}
                        style={{ fontFamily: def.fontFamily }}
                      >
                        {isNight ? "Gece: Kömür Siyahı (#1A1A1A)" : "Gündüz: Saf Beyaz (#FFFFFF)"}
                      </h4>
                      <p
                        className={`text-xs leading-relaxed ${
                          isNight ? "text-slate-300" : "text-slate-600"
                        }`}
                      >
                        Gözü yormayan minimalist tipografi, sıfır dikkat dağıtıcı öğe ve yüksek kontrastlı odak alanı...
                      </p>
                    </div>

                    {/* Footer Status */}
                    <div
                      className={`flex items-center justify-between text-[10px] pt-1.5 border-t ${
                        isNight ? "border-slate-800 text-slate-500" : "border-slate-100 text-slate-400"
                      }`}
                    >
                      <span>Minimalist Style 1</span>
                      <span className="font-mono">Auto-Hide UI</span>
                    </div>
                  </div>
                )}

                {styleKey === "zen_sapphire" && (
                  /* ------------------------------------------------------------- */
                  /* 2. STYLE: KATMANLI SENSÖREL (LAYERED DEPTH)                  */
                  /* ------------------------------------------------------------- */
                  <div
                    className={`w-full h-48 sm:h-56 rounded-2xl border transition-all duration-300 relative flex flex-col justify-between p-3 overflow-hidden select-none ${
                      isNight
                        ? "bg-gradient-to-b from-[#0A1128] via-[#101A36] to-[#1C2541] border-sky-900/60 text-sky-100"
                        : "bg-gradient-to-b from-[#FDFBF7] via-[#FAF6F0] to-[#F5EFEB] border-sky-200/80 text-slate-900 shadow-inner"
                    }`}
                  >
                    {/* Glassmorphism Top Bar */}
                    <div
                      className={`flex items-center justify-between text-[10px] px-2.5 py-1 rounded-xl backdrop-blur-md border ${
                        isNight
                          ? "bg-sky-950/60 border-sky-500/30 text-sky-200"
                          : "bg-white/70 border-sky-200 text-sky-900 shadow-xs"
                      }`}
                    >
                      <div className="flex items-center gap-1 font-bold">
                        <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse" />
                        <span>Buzlu Cam Katmanları</span>
                      </div>
                      <span className="font-mono text-[9px]">Glassmorphism</span>
                    </div>

                    {/* Canvas Body with Sapphire Mesh */}
                    <div className="relative flex-1 my-2 flex flex-col justify-center px-3 space-y-1.5">
                      {/* Grid Mesh lines */}
                      <div
                        className="absolute inset-0 opacity-15 pointer-events-none"
                        style={{
                          backgroundImage: `linear-gradient(to right, #38BDF8 1px, transparent 1px), linear-gradient(to bottom, #38BDF8 1px, transparent 1px)`,
                          backgroundSize: "16px 16px",
                        }}
                      />

                      <div className="relative z-10 space-y-1">
                        <h4
                          className={`text-base sm:text-lg font-extrabold ${
                            isNight ? "text-sky-300" : "text-sky-900"
                          }`}
                          style={{ fontFamily: def.fontFamily }}
                        >
                          {isNight ? "Gece: Derin Safir Mavisi (#0A1128)" : "Gündüz: Sıcak Krem (#FDFBF7)"}
                        </h4>
                        <p
                          className={`text-xs leading-relaxed ${
                            isNight ? "text-sky-100/90" : "text-slate-700"
                          }`}
                        >
                          Derinlik veren gölgeler, safir vurgular ve altın/kehribar ışıldayan radyal menü katmanı...
                        </p>
                      </div>

                      {/* Luminous Glowing Radial Menu Mockup */}
                      <div className="absolute right-2 bottom-1 flex items-center gap-1.5">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-400 via-amber-500 to-yellow-500 shadow-lg shadow-amber-500/30 ring-2 ring-amber-300 flex items-center justify-center text-slate-900 font-bold text-[10px]">
                          ❖
                        </div>
                        <span className="text-[8px] font-black text-amber-500">Gold Glow</span>
                      </div>
                    </div>

                    {/* Footer Status */}
                    <div
                      className={`flex items-center justify-between text-[10px] pt-1.5 border-t ${
                        isNight ? "border-sky-900/50 text-sky-400/80" : "border-sky-100 text-sky-800/80"
                      }`}
                    >
                      <span>Sensory Depth Style 2</span>
                      <span className="font-mono">Sapphire Grid</span>
                    </div>
                  </div>
                )}

                {styleKey === "fluid_parchment" && (
                  /* ------------------------------------------------------------- */
                  /* 3. STYLE: HİBRİT KANVAS (INTERACTIVE DRAWING & STYLUS)       */
                  /* ------------------------------------------------------------- */
                  <div
                    className={`w-full h-48 sm:h-56 rounded-2xl border transition-all duration-300 relative flex flex-col justify-between p-3 overflow-hidden select-none ${
                      isNight
                        ? "bg-[#081432] border-indigo-900 text-cyan-100"
                        : "bg-[#F5EFEB] border-amber-200 text-amber-950 shadow-inner"
                    }`}
                  >
                    {/* Top Bar with Palm Rejection Indicator */}
                    <div
                      className={`flex items-center justify-between text-[10px] px-2.5 py-1 rounded-xl border ${
                        isNight
                          ? "bg-indigo-950/80 border-cyan-500/40 text-cyan-200"
                          : "bg-amber-100/80 border-amber-300 text-amber-900 shadow-xs"
                      }`}
                    >
                      <div className="flex items-center gap-1.5 font-bold">
                        <Feather className="w-3.5 h-3.5 text-amber-500" />
                        <span>Sınırsız Kanvas & Stylus</span>
                      </div>
                      <span className="px-2 py-0.2 rounded bg-emerald-500 text-white font-extrabold text-[9px]">
                        Palm Rejection ✓
                      </span>
                    </div>

                    {/* Canvas Body with Neon Strokes & Handwriting Sketch */}
                    <div className="relative flex-1 my-2 flex flex-col justify-center px-2">
                      <div className="relative z-10 space-y-1">
                        <h4
                          className={`text-base font-bold ${
                            isNight ? "text-cyan-300" : "text-amber-950"
                          }`}
                          style={{ fontFamily: def.fontFamily }}
                        >
                          {isNight ? "Gece: Koyu Lacivert Kanvas (#081432)" : "Gündüz: Yumuşak Parşömen (#F5EFEB)"}
                        </h4>
                        <p
                          className={`text-xs ${
                            isNight ? "text-cyan-100/80" : "text-amber-900/80"
                          }`}
                        >
                          Klavyeden metin ve dijital kalem ile el yazısı bir arada...
                        </p>
                      </div>

                      {/* SVG Digital Neon Strokes */}
                      <svg className="w-full h-14 pointer-events-none mt-1" viewBox="0 0 200 45">
                        <path
                          d="M 10,25 Q 50,5 90,25 T 170,20"
                          fill="none"
                          stroke={isNight ? "#38BDF8" : "#B45309"}
                          strokeWidth="2.5"
                          strokeLinecap="round"
                        />
                        <path
                          d="M 20,35 Q 70,20 120,35"
                          fill="none"
                          stroke={isNight ? "#F43F5E" : "#D97706"}
                          strokeWidth="2"
                          strokeDasharray="3,3"
                        />
                      </svg>
                    </div>

                    {/* Footer Status */}
                    <div
                      className={`flex items-center justify-between text-[10px] pt-1.5 border-t ${
                        isNight ? "border-indigo-900 text-cyan-400" : "border-amber-200 text-amber-800"
                      }`}
                    >
                      <span>Hybrid Canvas Style 3</span>
                      <span className="font-mono">Glow Pen Active</span>
                    </div>
                  </div>
                )}

                {styleKey === "timeline_chronicle" && (
                  /* ------------------------------------------------------------- */
                  /* 4. STYLE: KRONOLOJİK AKIŞ (CHRONICLE TIMELINE)               */
                  /* ------------------------------------------------------------- */
                  <div
                    className={`w-full h-48 sm:h-56 rounded-2xl border transition-all duration-300 relative flex flex-col justify-between p-3 overflow-hidden select-none ${
                      isNight
                        ? "bg-[#121827] border-slate-800 text-slate-100"
                        : "bg-[#F5F5F5] border-slate-200 text-slate-900 shadow-inner"
                    }`}
                  >
                    {/* Top Horizontally Scrollable Tag Badges */}
                    <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[9px] font-bold">
                      <span className="px-2 py-0.5 rounded-full bg-teal-500 text-white shrink-0">
                        🏷️ #Proje
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-indigo-500 text-white shrink-0">
                        📁 İş Planı
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white shrink-0">
                        🕒 29.09.2026
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white shrink-0">
                        ⭐ Önemli
                      </span>
                    </div>

                    {/* Vertical Timeline Track with Node Block Cards */}
                    <div className="relative flex-1 my-1 flex gap-2.5 items-center">
                      <div
                        className={`relative pl-3.5 flex flex-col gap-1.5 border-l-2 ${
                          isNight ? "border-amber-500" : "border-teal-600"
                        }`}
                      >
                        <div
                          className={`relative flex items-center gap-1.5 px-2 py-1 rounded-md text-[9px] font-bold shadow-2xs ${
                            isNight ? "bg-slate-800 text-amber-300 border border-amber-500/50" : "bg-white text-slate-800 border border-slate-200"
                          }`}
                        >
                          <span
                            className={`absolute -left-[18px] w-2.5 h-2.5 rounded-full ring-2 ring-white ${
                              isNight ? "bg-amber-400" : "bg-teal-600"
                            }`}
                          />
                          <ImageIcon className="w-3 h-3 text-amber-500" />
                          <span>Görsel Medya Blok</span>
                        </div>

                        <div
                          className={`relative flex items-center gap-1.5 px-2 py-1 rounded-md text-[9px] font-bold shadow-2xs ${
                            isNight ? "bg-slate-800 text-cyan-300 border border-cyan-500/50" : "bg-white text-slate-800 border border-slate-200"
                          }`}
                        >
                          <span
                            className={`absolute -left-[18px] w-2.5 h-2.5 rounded-full ring-2 ring-white ${
                              isNight ? "bg-cyan-400" : "bg-indigo-600"
                            }`}
                          />
                          <Mic className="w-3 h-3 text-cyan-400" />
                          <span>Ses Dalgası (0:45)</span>
                        </div>
                      </div>

                      <div className="flex-1 space-y-1">
                        <h4
                          className={`text-sm font-black ${
                            isNight ? "text-amber-400" : "text-slate-900"
                          }`}
                          style={{ fontFamily: def.fontFamily }}
                        >
                          {isNight ? "Gece: Koyu Kömür & Amber" : "Gündüz: Temiz Nötr Gri"}
                        </h4>
                        <p className="text-[10px] text-slate-500 leading-tight">
                          Zaman damgalı blok kartları ve tarihsel akış...
                        </p>
                      </div>
                    </div>

                    {/* Footer Status */}
                    <div
                      className={`flex items-center justify-between text-[10px] pt-1.5 border-t ${
                        isNight ? "border-slate-800 text-slate-400" : "border-slate-200 text-slate-500"
                      }`}
                    >
                      <span>Chronicle Style 4</span>
                      <span className="font-mono">Timeline Tags</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Description & Feature Chips */}
              <div className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed min-h-[36px]">
                  {def.description}
                </p>

                <div className="flex flex-wrap gap-1 pt-1">
                  {def.features.map((feat, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700/60"
                    >
                      {feat}
                    </span>
                  ))}
                </div>

                {/* Apply Theme Button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSelectStyle(styleKey);
                  }}
                  className={`w-full py-2.5 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-2 ${
                    isSelected
                      ? "bg-teal-600 text-white shadow-md shadow-teal-600/20"
                      : "bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
                  }`}
                >
                  {isSelected ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Bu Kanvas Teması Aktif</span>
                    </>
                  ) : (
                    <>
                      <span>Bu Temayı Uygula</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* 1.5 COLORNOTE ÇİZGİLİ DEFTER & KAĞIT TEMALARI (FULL-BLEED NOTEBOOK)       */}
      {/* ========================================================================= */}
      <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-start gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center justify-center font-black shrink-0 shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  ColorNote Çizgili Defter & Kağıt Temaları (Full-Bleed Ruled Paper)
                </h3>
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                  Tam Ekran Defter
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
                Not okuma ve metin yazma ekranlarını gözü yormayan sarı parşömen, kömür siyahı veya pastel yeşil çizgili defter kâğıdına dönüştürün. Metin taban çizgisi (baseline) defter çizgisiyle milimetrik senkronize çalışır.
              </p>
            </div>
          </div>

          <span className="text-xs font-mono font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950 px-3 py-1.5 rounded-xl border border-amber-200 dark:border-amber-800 self-start sm:self-auto shrink-0">
            Aktif: {paperThemeDef.name}
          </span>
        </div>

        {/* 4 KAĞIT TEMASI KARTLARI */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {(Object.keys(PAPER_THEME_DEFINITIONS) as PaperThemeId[]).map((themeKey) => {
            const def = PAPER_THEME_DEFINITIONS[themeKey];
            const isSelected = paperConfig.activeTheme === themeKey;

            return (
              <div
                key={themeKey}
                onClick={() => {
                  setPaperTheme(themeKey);
                  setToastMessage(`✓ Kağıt teması '${def.name}' olarak seçildi.`);
                  setTimeout(() => setToastMessage(null), 3000);
                }}
                className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 shadow-xs ${
                  isSelected
                    ? "border-amber-500 bg-amber-50/40 dark:bg-amber-950/20 ring-2 ring-amber-500/20 shadow-md"
                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span
                      className="w-6 h-6 rounded-full border shadow-xs shrink-0"
                      style={{ backgroundColor: def.bgColor, borderColor: def.lineColor }}
                    />
                    <span
                      className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                        isSelected
                          ? "bg-amber-600 text-white"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      {def.badge}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-xs font-black text-slate-900 dark:text-white">
                      {def.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {def.description}
                    </p>
                  </div>
                </div>

                {/* Color Swatch Bar */}
                <div
                  className="h-10 rounded-xl border flex items-center justify-between px-3 text-[10px] font-mono select-none"
                  style={{
                    backgroundColor: def.bgColor,
                    borderColor: def.lineColor,
                    color: def.textColor,
                  }}
                >
                  <span className="font-bold">Aa Örnek Yazı</span>
                  <span className="opacity-60 text-[9px]">{def.bgColor}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* HASSAS DEFTER & BASELINE AYARLARI */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-black text-slate-900 dark:text-white">
                  Defter Çizgileri (Ruled Paper Lines)
                </h4>
                <p className="text-[10px] text-slate-500">
                  Satır aralıklarını belirten yatay defter çizgileri
                </p>
              </div>
              <input
                type="checkbox"
                checked={paperConfig.showRuledLines}
                onChange={toggleRuledLines}
                className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 cursor-pointer accent-amber-600"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-black text-slate-900 dark:text-white">
                  Kırmızı Marj Kılavuzu (Margin Guide)
                </h4>
                <p className="text-[10px] text-slate-500">
                  Sol tarafta dikey kırmızı defter marj çizgisi (48px)
                </p>
              </div>
              <input
                type="checkbox"
                checked={paperConfig.showMarginLine}
                onChange={toggleMarginLine}
                className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer accent-rose-600"
              />
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                <span>Yazı Boyutu (Font Size):</span>
                <span className="font-mono text-amber-600 dark:text-amber-400">{paperConfig.fontSize}sp</span>
              </div>
              <input
                type="range"
                min="14"
                max="24"
                step="1"
                value={paperConfig.fontSize}
                onChange={(e) => setPaperFontSize(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-amber-600"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                <span>Satır Aralığı Katsayısı (Line Height):</span>
                <span className="font-mono text-amber-600 dark:text-amber-400">{paperConfig.lineHeightRatio.toFixed(2)}x ({Math.round(paperConfig.fontSize * paperConfig.lineHeightRatio)}px)</span>
              </div>
              <input
                type="range"
                min="1.40"
                max="2.00"
                step="0.05"
                value={paperConfig.lineHeightRatio}
                onChange={(e) => setPaperLineHeightRatio(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer accent-amber-600"
              />
            </div>
          </div>
        </div>

        {/* CANLI ÇİZGİLİ DEFTER SİMÜLASYON KARTI (LIVE INTERACTIVE NOTEBOOK PREVIEW) */}
        <div className="p-4 sm:p-5 rounded-2xl border shadow-inner space-y-3 select-none"
          style={{
            backgroundColor: paperThemeDef.bgColor,
            backgroundImage: paperThemeDef.bgGradient,
            borderColor: paperThemeDef.lineColor,
            color: paperThemeDef.textColor,
          }}
        >
          {/* Header Date Line */}
          <div className="flex items-center justify-between pb-2 border-b text-xs font-mono"
            style={{
              borderColor: paperThemeDef.lineColor,
              color: paperThemeDef.dateColor,
            }}
          >
            <div className="flex items-center gap-1.5 font-bold">
              <Calendar className="w-3.5 h-3.5" />
              <span>15 Ağustos 18:06 • Defter Önizlemesi</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded border" style={{ borderColor: paperThemeDef.lineColor }}>
              Baseline Grid Aktif
            </span>
          </div>

          {/* Ruled Lines Arena */}
          {(() => {
            const previewMetrics = computeNotebookMetrics(
              paperConfig.fontSize,
              1.0,
              paperConfig.lineHeightRatio,
              paperThemeDef.lineColor,
              paperThemeDef.marginLineColor,
              paperConfig.showMarginLine
            );

            return (
              <div
                className="w-full rounded-xl py-2 relative overflow-hidden"
                style={{
                  backgroundImage: paperConfig.showRuledLines ? previewMetrics.backgroundImage : undefined,
                  backgroundSize: paperConfig.showRuledLines ? previewMetrics.backgroundSize : undefined,
                  paddingLeft: paperConfig.showMarginLine ? "calc(48px + 16px)" : "16px",
                  paddingRight: "16px",
                }}
              >
                <h4
                  className="font-black"
                  style={{
                    fontSize: `${previewMetrics.fontSize + 2}px`,
                    lineHeight: `${previewMetrics.lineHeight}px`,
                  }}
                >
                  Fizik & Zihin Haritası Notları
                </h4>
                <div
                  style={{
                    fontSize: `${previewMetrics.fontSize}px`,
                    lineHeight: `${previewMetrics.lineHeight}px`,
                  }}
                >
                  <p>1. Termodinamik yasaları ve enerji korunumu kuralları.</p>
                  <p>2. ColorNote tarzı sarı parşömen kâğıdı gözü dinlendirir.</p>
                  <p>3. Satır basamağı defter çizgisine milimetrik oturur.</p>
                </div>
              </div>
            );
          })()}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. HİBRİT TUVAL MODELİ (INFINITE CANVAS + BOUNDED FRAMES)                  */}
      {/* ========================================================================= */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Frame className="w-5 h-5 text-teal-600 dark:text-teal-400" />
              <span>Hibrit Tuval Modeli (Sonsuz Tuval + Sınırlandırılmış Çerçeveler)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-2xl leading-relaxed">
              Sonsuz tuvalde serbestçe gezinebilir (Pan & Zoom) ve istediğiniz an sabit boyutlu A4, B5 veya PDF sayfa çerçeveleri ekleyebilirsiniz.
            </p>
          </div>
          <span className="text-[10px] font-extrabold px-2.5 py-1 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
            Infinite + Bounded
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
          {[
            {
              id: "infinite",
              name: "Sonsuz Tuval (Infinite)",
              dims: "Sınırsız Alan (X / Y)",
              desc: "Kısıtsız serbest akış ve zihin haritası alanı",
              icon: Maximize,
            },
            {
              id: "a4",
              name: "A4 Belge Çerçevesi",
              dims: "210 × 297 mm (794×1123px)",
              desc: "Yazdırılabilir resmi doküman ve PDF standardı",
              icon: FileText,
            },
            {
              id: "b5",
              name: "B5 Defter Çerçevesi",
              dims: "176 × 250 mm (665×945px)",
              desc: "Akademik defter ve çalışma sayfası boyutu",
              icon: Layers,
            },
            {
              id: "pdf_page",
              name: "PDF Sayfa Şablonu",
              dims: "Sayfa Bazlı Grid",
              desc: "Ders notu ve slayt açıklamaları için optimize",
              icon: Frame,
            },
          ].map((item) => {
            const isSel = activeFramePreset === item.id;
            const IconComp = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectFramePreset(item.id as BoundedFramePreset)}
                className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                  isSel
                    ? "border-teal-500 bg-teal-50/70 dark:bg-teal-950/40 text-teal-950 dark:text-teal-100 font-bold shadow-xs ring-2 ring-teal-500/20"
                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-teal-600 dark:text-teal-400">
                    <IconComp className="w-4 h-4" />
                  </div>
                  {isSel && <Check className="w-4 h-4 text-teal-600 dark:text-teal-400" />}
                </div>
                <div>
                  <p className="text-xs font-black">{item.name}</p>
                  <p className="text-[10px] font-mono text-teal-600 dark:text-teal-400 font-bold">{item.dims}</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{item.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. KATMAN (LAYER) YÖNETİCİSİ & Z-INDEX HİYERARŞİSİ MİMARİSİ                 */}
      {/* ========================================================================= */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-extrabold uppercase tracking-wider">
            <Layers className="w-4 h-4" />
            <span>Katman (Layer) Yöneticisi & Z-Index Hiyerarşisi</span>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
            Object-Based Vector Stack
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
          Çizimler tek bir piksel bitmap&apos;inde birbirini ezmez. Vektörel nesne motorumuz 5 katmanlı Z-Index derinliğinde render edilir:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 pt-1 text-xs">
          {[
            { z: "Z=0", title: "Şablon & Izgara", desc: "A4/B5 Çerçeveleri, noktalı kılavuzlar", color: "border-slate-700 bg-slate-800/80 text-slate-300" },
            { z: "Z=1", title: "Vurgulayıcı", desc: "Altta yarı şeffaf multiply marker", color: "border-amber-500/40 bg-amber-950/40 text-amber-300" },
            { z: "Z=2", title: "Metin & Köprüler", desc: "Metin kutuları ve [[Not]] linkleri", color: "border-sky-500/40 bg-sky-950/40 text-sky-300" },
            { z: "Z=3", title: "El Yazısı Çizgileri", desc: "Tükenmez, dolma, kaligrafi vektörleri", color: "border-teal-500/40 bg-teal-950/40 text-teal-300" },
            { z: "Z=4", title: "Hafıza Bandı", desc: "Üstü kapatan interaktif recall bandı", color: "border-rose-500/40 bg-rose-950/40 text-rose-300" },
          ].map((ly) => (
            <div key={ly.z} className={`p-3 rounded-2xl border flex flex-col justify-between gap-1.5 ${ly.color}`}>
              <div className="flex items-center justify-between">
                <span className="font-mono font-black text-[11px]">{ly.z}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-current" />
              </div>
              <p className="font-extrabold text-xs">{ly.title}</p>
              <p className="text-[10px] text-slate-400 leading-tight">{ly.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* ÇAPRAZ PLATFORM DUYARLILIK (RESPONSIVE ARCHITECTURE BREAKDOWN CARD)      */}
      {/* ========================================================================= */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-amber-400 text-xs font-extrabold uppercase tracking-wider">
          <Sparkles className="w-4 h-4" />
          <span>Çapraz Platform Duyarlılık (Responsive & Adaptive Design)</span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
          Tüm yazı tahtası temaları PC (Masaüstü), Tablet ve Akıllı Telefonlarda ekran genşliğine göre araç çubuklarını, radyal çark menülerini ve kanvas düzenini tam uyumlu olarak adapte eder:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
          {/* PC / Desktop */}
          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
            <div className="flex items-center gap-2 text-teal-400 font-extrabold text-xs">
              <Monitor className="w-4 h-4" />
              <span>Masaüstü (PC / Laptop)</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-normal">
              Sol tarafta sabit sidebar menü, sağ tarafta tam genişlikte esnek (fluid flex) kanvas alanı ve hızlı klavye kısayolları.
            </p>
          </div>

          {/* Tablet */}
          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-extrabold text-xs">
              <Tablet className="w-4 h-4" />
              <span>Tablet (Landscape/Portrait)</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-normal">
              Split-screen bölünmüş ekran desteği, Apple Pencil & S-Pen için Optimize Stylus fırça paneli ve avuç içi engelleme.
            </p>
          </div>

          {/* Phone */}
          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
            <div className="flex items-center gap-2 text-rose-400 font-extrabold text-xs">
              <Smartphone className="w-4 h-4" />
              <span>Akıllı Telefon (Mobile)</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-normal">
              Başparmak erişim alanına (Thumb Zone) yerleştirilmiş yüzen eylem çubuğu (FAB) ve dokunmatik kompakt radyal çark.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
