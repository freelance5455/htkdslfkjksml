import React, { useMemo, useState } from 'react';
import { Shield } from 'lucide-react';
import {
  CLAN_TYPE_LABELS_RU,
  ClanDashboardState,
  WAR_FREQUENCY_LABELS_RU,
} from '../shared/cocData';
import { AnalyticsChartsView } from './AnalyticsChartsView';
import { WarEfficiencyChart } from './ProgressCharts';

interface ClanStatsViewProps {
  state: ClanDashboardState;
  onSelectPlayer: (tag: string) => void;
}

export const ClanStatsView: React.FC<ClanStatsViewProps> = ({
  state,
  onSelectPlayer,
}) => {
  const [subView, setSubView] = useState<'clan' | 'players'>('clan');

  const warTotalFinished = useMemo(() => {
    if (!state.clan) return 0;
    return (
      (state.clan.warWins ?? 0) +
      (state.clan.warLosses ?? 0) +
      (state.clan.warTies ?? 0)
    );
  }, [state.clan]);

  const winPctAllTime = useMemo(() => {
    if (!state.clan || warTotalFinished === 0) return null;
    return ((state.clan.warWins / warTotalFinished) * 100).toFixed(1);
  }, [state.clan, warTotalFinished]);

  if (!state.clan) {
    return (
      <div className="rounded-lg border border-slate-800 bg-[#121824] p-8 text-center text-sm text-slate-400">
        Сначала найдите и подключите клан через официальный Supercell Clash of Clans API на вкладке «Обзор».
      </div>
    );
  }

  const c = state.clan;

  if (subView === 'players') {
    return (
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/90 pb-4">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
              Статистика — Сравнение игроков
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Баланс категорий базы участников клана {c.name}
            </p>
          </div>
          <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1">
            <button
              type="button"
              onClick={() => setSubView('clan')}
              className="px-3 py-1.5 text-xs font-medium rounded-md text-slate-400 hover:text-slate-200 transition-colors whitespace-nowrap"
            >
              Полный паспорт клана
            </button>
            <button
              type="button"
              onClick={() => setSubView('players')}
              className="px-3 py-1.5 text-xs font-semibold rounded-md bg-amber-500 text-slate-950 transition-colors whitespace-nowrap"
            >
              Сравнение игроков
            </button>
          </div>
        </div>

        <AnalyticsChartsView state={state} onSelectPlayer={onSelectPlayer} />
      </div>
    );
  }

  const infoRows: Array<{ label: string; value: string; mono?: boolean }> = [
    { label: 'Название клана', value: c.name },
    { label: 'Тег клана', value: c.tag, mono: true },
    { label: 'Уровень клана', value: String(c.level), mono: true },
    { label: 'Участники', value: `${c.membersCount} / 50`, mono: true },
    { label: 'Очки клана (Трофеи)', value: c.clanPoints.toLocaleString('ru-RU'), mono: true },
    {
      label: 'Очки деревни строителя',
      value:
        c.clanBuilderBasePoints !== undefined
          ? c.clanBuilderBasePoints.toLocaleString('ru-RU')
          : 'Недоступно в API',
      mono: true,
    },
    { label: 'Трофеи / очки столицы', value: c.clanCapitalPoints.toLocaleString('ru-RU'), mono: true },
    {
      label: 'Уровень Столицы клана',
      value: c.capitalHallLevel ? `Уровень ${c.capitalHallLevel}` : 'Недоступно',
      mono: true,
    },
    { label: 'Лига столицы', value: c.capitalLeague ?? 'Без лиги' },
    { label: 'Лига клановых войн (CWL)', value: c.warLeague },
    { label: 'Язык чата', value: c.chatLanguage ?? 'Не указан' },
    { label: 'Местоположение', value: c.locationName ?? 'Не указано' },
    { label: 'Тип клана', value: c.type ? CLAN_TYPE_LABELS_RU[c.type] ?? c.type : 'Не указан' },
    {
      label: 'Требуемый уровень Ратуши',
      value: c.requiredTownhallLevel ? `TH ${c.requiredTownhallLevel}` : 'Не ограничен',
      mono: true,
    },
    {
      label: 'Требуемые трофеи',
      value: c.requiredTrophies !== undefined ? c.requiredTrophies.toLocaleString('ru-RU') : '0',
      mono: true,
    },
    {
      label: 'Частота войн',
      value: c.warFrequency ? WAR_FREQUENCY_LABELS_RU[c.warFrequency] ?? c.warFrequency : 'Не указана',
    },
    { label: 'Победы в войнах', value: c.warWins.toLocaleString('ru-RU'), mono: true },
    {
      label: 'Поражения в войнах',
      value: c.warLosses !== undefined ? c.warLosses.toLocaleString('ru-RU') : 'Скрыто настройками клана',
      mono: true,
    },
    {
      label: 'Ничьи в войнах',
      value: c.warTies !== undefined ? c.warTies.toLocaleString('ru-RU') : 'Скрыто настройками клана',
      mono: true,
    },
    { label: 'Текущая серия побед', value: String(c.warWinStreak), mono: true },
    {
      label: 'Журнал войн',
      value: c.isWarLogPublic === false ? 'Закрытый (приватный)' : 'Открытый (публичный)',
    },
  ];

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-4 border-b border-slate-800/90 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
            Полная статистика клана
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Все официальные показатели из <span className="font-mono text-slate-300">GET /clans/{c.tag}</span>
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#121824] p-1 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setSubView('clan')}
            className="px-3 py-1.5 text-xs font-semibold rounded-md bg-amber-500 text-slate-950 transition-colors whitespace-nowrap"
          >
            Полный паспорт клана
          </button>
          <button
            type="button"
            onClick={() => setSubView('players')}
            className="px-3 py-1.5 text-xs font-medium rounded-md text-slate-400 hover:text-slate-200 transition-colors whitespace-nowrap"
          >
            Сравнение игроков
          </button>
        </div>
      </section>

      {/* Clan Bio & Labels */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-4">
            <div className="h-16 w-16 shrink-0 rounded-lg border border-slate-800 bg-[#0B0F17] flex items-center justify-center overflow-hidden">
              {c.badgeUrl ? (
                <img
                  src={c.badgeUrl}
                  alt={c.name}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-contain p-1"
                />
              ) : (
                <Shield className="h-7 w-7 text-amber-400" />
              )}
            </div>
            <div>
              <h2 className="font-display text-xl font-bold text-slate-100">
                {c.name}{' '}
                <span className="font-mono text-sm font-normal text-amber-400">{c.tag}</span>
              </h2>
              <p className="mt-1.5 text-sm text-slate-300 leading-relaxed max-w-2xl">
                {c.description || 'Описание клана не задано.'}
              </p>
              {c.labels && c.labels.length > 0 && (
                <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  {c.labels.map((lbl, idx) => (
                    <React.Fragment key={lbl.id}>
                      {idx > 0 && <span aria-hidden="true">·</span>}
                      <span className="inline-flex items-center gap-1.5 text-slate-300">
                        {lbl.iconUrl && (
                          <img
                            src={lbl.iconUrl}
                            alt={lbl.name}
                            referrerPolicy="no-referrer"
                            className="h-4 w-4 object-contain"
                          />
                        )}
                        {lbl.name}
                      </span>
                    </React.Fragment>
                  ))}
                </div>
              )}
            </div>
          </div>

          {winPctAllTime !== null && (
            <div className="text-left sm:text-right shrink-0">
              <div className="text-xs text-slate-400">Общий винрейт в КВ</div>
              <div className="font-mono text-2xl font-bold tabular-nums text-emerald-400">
                {winPctAllTime}%
              </div>
              <div className="font-mono text-xs text-slate-500 tabular-nums">
                {c.warWins}В / {c.warLosses ?? 0}П / {c.warTies ?? 0}Н
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Complete API Fields Grid */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] overflow-hidden">
        <div className="border-b border-slate-800 px-5 py-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Все параметры клана из официального API
          </h2>
        </div>
        <div className="grid grid-cols-1 divide-y divide-slate-800/70 md:grid-cols-2 md:divide-y-0">
          {infoRows.map((row) => (
            <div
              key={row.label}
              className="flex items-center justify-between gap-4 border-b border-slate-800/60 px-5 py-3 text-xs sm:text-sm md:odd:border-r md:odd:border-slate-800/60"
            >
              <span className="text-slate-400">{row.label}</span>
              <span
                className={`text-right font-medium text-slate-100 ${
                  row.mono ? 'font-mono tabular-nums' : ''
                }`}
              >
                {row.value}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Capital Districts + War Log Chart */}
      <section className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 xl:col-span-5">
          <div className="border-b border-slate-800/80 pb-3">
            <h2 className="font-display text-base font-semibold text-slate-100">
              Районы Столицы клана
            </h2>
            <p className="mt-0.5 text-xs text-slate-400">
              {c.capitalHallLevel
                ? `Ратуша столицы: уровень ${c.capitalHallLevel}`
                : 'Данные о столице недоступны'}
            </p>
          </div>
          {c.capitalDistricts && c.capitalDistricts.length > 0 ? (
            <div className="mt-3 divide-y divide-slate-800/60">
              {c.capitalDistricts.map((d) => (
                <div key={d.id} className="flex items-center justify-between py-2.5 text-xs sm:text-sm">
                  <span className="text-slate-200">{d.name}</span>
                  <span className="font-mono font-semibold tabular-nums text-amber-400">
                    Ур. {d.districtHallLevel}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-slate-500">
              Районы столицы ещё не открыты или не возвращены API.
            </div>
          )}
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#121824] p-5 xl:col-span-7 flex flex-col justify-between">
          <div>
            <div className="border-b border-slate-800/80 pb-3">
              <h2 className="font-display text-base font-semibold text-slate-100">
                Результативность в последних войнах
              </h2>
              <p className="mt-0.5 text-xs text-slate-400">
                {c.isWarLogPublic === false
                  ? 'Журнал войн закрыт настройками приватности клана'
                  : `Звёзды (% от максимума) и средний процент разрушения по ${state.wars.length} войнам`}
              </p>
            </div>
            <div className="mt-4">
              {c.isWarLogPublic === false ? (
                <div className="flex h-[220px] items-center justify-center text-center text-xs text-slate-400 px-4">
                  В настройках этого клана журнал войн установлен как приватный (isWarLogPublic = false).
                </div>
              ) : (
                <WarEfficiencyChart wars={state.wars} height={240} />
              )}
            </div>
          </div>
          {c.isWarLogPublic !== false && state.wars.length > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-4 border-t border-slate-800/80 pt-3 text-xs text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-xs bg-[#10B981]" /> Звёзды (% от макс.)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-xs bg-[#38BDF8]" /> Разрушение %
              </span>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
