import React, { useState, useEffect } from "react";
import {
  StickyNote,
  FileText,
  Network,
  Shield,
  BookOpen,
  User,
  Sparkles,
  Sliders,
  ChevronRight,
  PanelLeftClose,
  PanelRightClose,
  Search,
  Plus
} from "lucide-react";
import { ActiveTab, Note } from "../types";

export type ScreenBreakpoint = "phone" | "tablet" | "desktop";

interface AdaptiveLayoutWrapperProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  notes?: Note[];
  selectedNote?: Note | null;
  onSelectNote?: (note: Note) => void;
  onOpenCreateMenu?: () => void;
  onOpenAIChat?: () => void;
  menuOrder?: ActiveTab[];
  children: React.ReactNode;
}

/**
 * AdaptiveLayoutWrapper Component
 * Handles dynamic multi-breakpoint responsive UI layout switching across Phone, Tablet, and Desktop:
 * - < 600px: Phone Layout (Single Column + Bottom Dock)
 * - 600px - 1024px: Tablet Layout (Left Rail + Split Screen Dual Pane)
 * - > 1024px: Desktop Layout (Left Sidebar + Center Main Workspace + Right Inspector Detail Panel)
 */
export const AdaptiveLayoutWrapper: React.FC<AdaptiveLayoutWrapperProps> = ({
  activeTab,
  setActiveTab,
  notes = [],
  selectedNote,
  onSelectNote,
  onOpenCreateMenu,
  onOpenAIChat,
  menuOrder,
  children,
}) => {
  const [windowWidth, setWindowWidth] = useState<number>(
    typeof window !== "undefined" ? window.innerWidth : 1200
  );
  const [isLeftRailExpanded, setIsLeftRailExpanded] = useState<boolean>(true);
  const [isRightPanelExpanded, setIsRightPanelExpanded] = useState<boolean>(true);

  // ResizeObserver / Window Listener with debounced-effect for lag-free performance on desktop window resizing
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const handleResize = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        setWindowWidth(window.innerWidth);
      }, 16); // ~60fps smooth frame handling
    };

    window.addEventListener("resize", handleResize);
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // Determine current breakpoint
  const getBreakpoint = (): ScreenBreakpoint => {
    if (windowWidth < 600) return "phone";
    if (windowWidth <= 1024) return "tablet";
    return "desktop";
  };

  const breakpoint = getBreakpoint();

  const menuNavItemsMap: Record<ActiveTab, { id: ActiveTab; label: string; icon: React.ReactNode }> = {
    home: { id: "home", label: "Notlar", icon: <StickyNote className="w-5 h-5" /> },
    docs: { id: "docs", label: "Belgeler", icon: <FileText className="w-5 h-5" /> },
    mindmap: { id: "mindmap", label: "Zihin Haritası", icon: <Network className="w-5 h-5" /> },
    vault: { id: "vault", label: "Şifreli Kasa", icon: <Shield className="w-5 h-5" /> },
    study: { id: "study", label: "Öğrenme", icon: <BookOpen className="w-5 h-5" /> },
    profile: { id: "profile", label: "Profil", icon: <User className="w-5 h-5" /> },
    tips: { id: "tips", label: "İpuçları", icon: <Sparkles className="w-5 h-5" /> },
    settings: { id: "settings", label: "Ayarlar", icon: <Sliders className="w-5 h-5" /> },
    ai_chat: { id: "ai_chat", label: "AI Asistan", icon: <Sparkles className="w-5 h-5" /> },
    plus_action: { id: "plus_action", label: "Hızlı Ekle", icon: <StickyNote className="w-5 h-5" /> },
    quick_search: { id: "quick_search", label: "Arama", icon: <Sliders className="w-5 h-5" /> },
    voice_memo: { id: "voice_memo", label: "Ses Kaydı", icon: <FileText className="w-5 h-5" /> },
  };

  const menuNavItems = menuOrder && menuOrder.length > 0
    ? menuOrder.map((id) => menuNavItemsMap[id]).filter(Boolean)
    : [
        menuNavItemsMap.home,
        menuNavItemsMap.docs,
        menuNavItemsMap.mindmap,
        menuNavItemsMap.vault,
        menuNavItemsMap.study,
        menuNavItemsMap.profile,
        menuNavItemsMap.tips,
        menuNavItemsMap.settings,
      ];

  // =========================================================================
  // 1. PHONE LAYOUT (< 600px): Single Column Main Stream
  // =========================================================================
  if (breakpoint === "phone") {
    return (
      <div className="w-full min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
        {/* Main Content Area */}
        <main className="flex-1 w-full max-w-full px-3 py-4">
          {children}
        </main>
      </div>
    );
  }

  // =========================================================================
  // 2. TABLET LAYOUT (600px - 1024px): Left Rail + Split-Screen Dual Pane
  // =========================================================================
  if (breakpoint === "tablet") {
    return (
      <div className="w-full min-h-screen flex bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors overflow-hidden">
        {/* Tablet Left Vertical Navigation Rail */}
        <aside
          className={`shrink-0 border-r border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md flex flex-col justify-between py-5 px-3 transition-all duration-300 ${
            isLeftRailExpanded ? "w-48" : "w-16 items-center"
          }`}
        >
          <div className="space-y-6">
            {/* App Brand Header */}
            <div className="flex items-center justify-between px-2">
              {isLeftRailExpanded ? (
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-teal-600 text-white font-extrabold flex items-center justify-center text-sm shadow-md">
                    NF
                  </div>
                  <span className="font-black text-sm tracking-tight text-slate-900 dark:text-white">
                    NoteFlow
                  </span>
                </div>
              ) : (
                <div className="w-8 h-8 rounded-xl bg-teal-600 text-white font-extrabold flex items-center justify-center text-sm shadow-md">
                  NF
                </div>
              )}
            </div>

            {/* Nav Links */}
            <nav className="space-y-1.5">
              {menuNavItems.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      isActive
                        ? "bg-teal-600 text-white shadow-md shadow-teal-600/20"
                        : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                    }`}
                    title={item.label}
                  >
                    <span className="shrink-0">{item.icon}</span>
                    {isLeftRailExpanded && <span className="truncate">{item.label}</span>}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Bottom Quick Actions */}
          <div className="space-y-2">
            {onOpenCreateMenu && (
              <button
                onClick={onOpenCreateMenu}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow-md cursor-pointer transition-transform active:scale-95"
                title="Yeni Not"
              >
                <Plus className="w-4 h-4" />
                {isLeftRailExpanded && <span>Yeni Ekle</span>}
              </button>
            )}

            <button
              onClick={() => setIsLeftRailExpanded((prev) => !prev)}
              className="w-full py-2 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs font-semibold cursor-pointer"
            >
              <PanelLeftClose className={`w-4 h-4 transition-transform ${!isLeftRailExpanded ? "rotate-180" : ""}`} />
            </button>
          </div>
        </aside>

        {/* Tablet Main Split Workspace */}
        <div className="flex-1 flex overflow-hidden">
          {/* Main Content Area */}
          <main className="flex-1 overflow-y-auto px-6 py-6">
            {children}
          </main>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 3. DESKTOP LAYOUT (> 1024px): Left Sidebar + Center Workspace + Right Inspector
  // =========================================================================
  return (
    <div className="w-full min-h-screen flex bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors overflow-hidden">
      {/* 1. Left Sidebar Navigation Timeline */}
      <aside
        className={`shrink-0 border-r border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900 flex flex-col justify-between py-6 px-4 transition-all duration-300 ${
          isLeftRailExpanded ? "w-64" : "w-20"
        }`}
      >
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between px-1">
            {isLeftRailExpanded ? (
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-500 text-white font-extrabold flex items-center justify-center text-sm shadow-md shadow-teal-500/20">
                  NF
                </div>
                <div>
                  <h1 className="font-black text-sm tracking-tight text-slate-900 dark:text-white leading-none">
                    NoteFlow
                  </h1>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    PKM Studio
                  </span>
                </div>
              </div>
            ) : (
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-500 text-white font-extrabold flex items-center justify-center text-sm shadow-md">
                NF
              </div>
            )}

            <button
              onClick={() => setIsLeftRailExpanded((prev) => !prev)}
              className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
            >
              <PanelLeftClose className={`w-4 h-4 transition-transform ${!isLeftRailExpanded ? "rotate-180" : ""}`} />
            </button>
          </div>

          {/* Nav Items */}
          <nav className="space-y-1.5">
            {menuNavItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? "bg-teal-600 text-white shadow-md shadow-teal-600/20"
                      : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-slate-900 dark:hover:text-slate-100"
                  }`}
                  title={item.label}
                >
                  <span className="shrink-0">{item.icon}</span>
                  {isLeftRailExpanded && <span>{item.label}</span>}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Quick Action Button */}
        <div className="space-y-3">
          {onOpenAIChat && isLeftRailExpanded && (
            <button
              onClick={onOpenAIChat}
              className="w-full p-3 rounded-2xl bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-300 text-xs font-bold flex items-center gap-2 hover:bg-teal-100 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-teal-600 shrink-0" />
              <span>AI Asistan Soru Sor</span>
            </button>
          )}

          {onOpenCreateMenu && (
            <button
              onClick={onOpenCreateMenu}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold shadow-lg shadow-teal-600/25 flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              {isLeftRailExpanded && <span>Yeni Not & İçerik</span>}
            </button>
          )}
        </div>
      </aside>

      {/* 2. Middle Main Board & Notes Workspace */}
      <main className="flex-1 overflow-y-auto px-8 py-8 max-w-full">
        {children}
      </main>

      {/* 3. Right Context / Detail Panel (Inspector) */}
      <aside
        className={`shrink-0 border-l border-slate-200 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md transition-all duration-300 flex flex-col ${
          isRightPanelExpanded ? "w-80" : "w-12 items-center"
        }`}
      >
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between w-full">
          {isRightPanelExpanded ? (
            <span className="text-xs font-black uppercase tracking-wider text-slate-400">
              Not & İçerik Detayı
            </span>
          ) : null}
          <button
            onClick={() => setIsRightPanelExpanded((prev) => !prev)}
            className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
            title="Detay Panelini Aç/Kapat"
          >
            <PanelRightClose className={`w-4 h-4 transition-transform ${!isRightPanelExpanded ? "rotate-180" : ""}`} />
          </button>
        </div>

        {isRightPanelExpanded ? (
          <div className="p-5 overflow-y-auto space-y-5 flex-1">
            {selectedNote ? (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-2">
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                    {selectedNote.title || "Başlıksız Not"}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-3">
                    {selectedNote.content || "İçerik henüz girilmedi."}
                  </p>
                </div>

                <div className="text-xs space-y-2 text-slate-500 dark:text-slate-400">
                  <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                    <span>Kategori</span>
                    <strong className="text-slate-800 dark:text-slate-200">{selectedNote.category || "Genel"}</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                    <span>Son Güncelleme</span>
                    <strong className="text-slate-800 dark:text-slate-200">
                      {new Date(selectedNote.updatedAt || Date.now()).toLocaleDateString("tr-TR")}
                    </strong>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 px-4 space-y-2 text-slate-400">
                <StickyNote className="w-8 h-8 mx-auto opacity-40" />
                <p className="text-xs font-semibold">
                  İncelemek için bir not seçin
                </p>
              </div>
            )}
          </div>
        ) : null}
      </aside>
    </div>
  );
};
