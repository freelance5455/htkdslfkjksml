import React, { useState, useEffect, useRef } from 'react';
import { ChevronRight, RefreshCw, AlertOctagon, CheckCircle2, XCircle } from 'lucide-react';
import { WordData } from '../types';
import { sound } from '../services/sound';

interface QuizQuestion {
  word: string;
  bengali: string;
  prompt: string;
  options: { text: string; correct: boolean }[];
  correctDef: string;
}

interface UserAnswerRecord {
  word: string;
  chosenText: string;
  correctText: string;
  isCorrect: boolean;
  bengali: string;
}

interface QuizTabProps {
  words: WordData[];
  mistakesVaultWords: string[];
  onAddMistake: (word: string, wrongAns: string, correctAns: string, question: string) => void;
  onSetStatus: (word: string, status: 'mastered' | 'revise' | 'learn') => void;
  onNavigateToVault: () => void;
  onQuizComplete?: (accuracy: number) => void;
}

export const QuizTab: React.FC<QuizTabProps> = ({
  words,
  mistakesVaultWords,
  onAddMistake,
  onSetStatus,
  onNavigateToVault,
  onQuizComplete,
}) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<UserAnswerRecord[]>([]);
  const [isFinished, setIsFinished] = useState(false);
  const [selectedOptionIdx, setSelectedOptionIdx] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes
  const [startTime, setStartTime] = useState(Date.now());
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const startQuiz = () => {
    setCurrentIdx(0);
    setScore(0);
    setUserAnswers([]);
    setIsFinished(false);
    setSelectedOptionIdx(null);
    setTimeLeft(300);
    setStartTime(Date.now());

    // Pool strategy: Prioritize words from Mistakes Vault if available, plus exam hot words
    let pool: WordData[] = [];
    if (mistakesVaultWords.length > 0) {
      const vaultPool = words.filter(w => mistakesVaultWords.includes(w.word));
      pool = [...vaultPool];
    }
    const hotPool = words.filter(w => w.cefr.includes('C1') || w.frequency.includes('High'));
    pool = [...pool, ...hotPool];
    if (pool.length < 10) pool = [...words];

    // Pick 10 unique words
    const uniquePool = Array.from(new Set(pool)).sort(() => 0.5 - Math.random()).slice(0, 10);

    const generated: QuizQuestion[] = uniquePool.map(item => {
      const others = words.filter(w => w.word !== item.word).sort(() => 0.5 - Math.random()).slice(0, 3);
      const options = [
        { text: item.simpleDef, correct: true },
        { text: others[0]?.simpleDef || 'To alter or change radically', correct: false },
        { text: others[1]?.simpleDef || 'To support firmly with evidence', correct: false },
        { text: others[2]?.simpleDef || 'To reduce or decrease gradually', correct: false },
      ].sort(() => 0.5 - Math.random());

      return {
        word: item.word,
        bengali: item.bengali,
        prompt: `Choose the closest meaning of: ${item.word.toUpperCase()}`,
        options,
        correctDef: item.simpleDef,
      };
    });

    setQuestions(generated);
  };

  useEffect(() => {
    startQuiz();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  useEffect(() => {
    if (isFinished) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          setIsFinished(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isFinished]);

  const handleSelectOption = (optIdx: number) => {
    if (selectedOptionIdx !== null) return; // already selected
    setSelectedOptionIdx(optIdx);

    const q = questions[currentIdx];
    const chosen = q.options[optIdx];
    const isCorrect = chosen.correct;

    setUserAnswers(prev => [
      ...prev,
      {
        word: q.word,
        chosenText: chosen.text,
        correctText: q.correctDef,
        isCorrect,
        bengali: q.bengali,
      }
    ]);

    if (isCorrect) {
      setScore(s => s + 1);
      sound.triggerFloatingXp(15);
      onSetStatus(q.word, 'mastered');
    } else {
      sound.wrong();
      onAddMistake(q.word, chosen.text, q.correctDef, q.prompt);
    }
  };

  const handleNext = () => {
    setSelectedOptionIdx(null);
    if (currentIdx + 1 < questions.length) {
      setCurrentIdx(c => c + 1);
    } else {
      setIsFinished(true);
      const finalAccuracy = Math.round(((score + (selectedOptionIdx !== null && questions[currentIdx]?.options[selectedOptionIdx]?.correct ? 0 : 0)) / questions.length) * 100);
      if (finalAccuracy >= 70) {
        sound.triggerCelebration();
      }
      onQuizComplete?.(finalAccuracy);
    }
  };

  const minutes = String(Math.floor(timeLeft / 60)).padStart(2, '0');
  const seconds = String(timeLeft % 60).padStart(2, '0');

  if (questions.length === 0) {
    return (
      <div className="flex-1 p-8 text-center text-slate-400">
        Loading Diagnostic Drill...
      </div>
    );
  }

  const q = questions[currentIdx];
  const totalTimeSpent = Math.max(1, Math.round((Date.now() - startTime) / 1000));
  const avgSpeed = (totalTimeSpent / Math.max(1, userAnswers.length)).toFixed(1);
  const accuracy = Math.round((score / Math.max(1, questions.length)) * 100);

  return (
    <div className="flex-1 smooth-scroll p-4 space-y-4 pb-28 max-w-md mx-auto w-full">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white rounded-3xl p-5 shadow-[0_4px_0_0_#1e40af] space-y-2">
        <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider">
          <span className="bg-white/20 px-2.5 py-0.5 rounded-full">Competitive Exam Arena</span>
          <span className="font-mono text-sm bg-black/20 px-2.5 py-0.5 rounded-xl">
            {minutes}:{seconds}
          </span>
        </div>

        <h2 className="text-xl sm:text-2xl font-black">10-Question Diagnostic Drill</h2>
        <p className="text-xs text-blue-100 font-bengali">
          বিসিএস ও ব্যাংক পরীক্ষার মতো প্রশ্নমালা। ভুল উত্তরগুলো স্বয়ংক্রিয়ভাবে মিস্টেক্স ব্যাংকে যুক্ত হবে।
        </p>

        <div className="flex items-center justify-between pt-2 text-xs font-bold border-t border-white/20">
          <span>Score: <strong className="text-base">{score}</strong> / 10</span>
          <button
            onClick={startQuiz}
            className="px-3 py-1 bg-white text-blue-800 font-extrabold rounded-xl shadow-sm hover:bg-blue-50 active:scale-95 transition-all flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" /> Restart
          </button>
        </div>
      </div>

      {!isFinished ? (
        <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center text-xs font-bold text-slate-400">
            <span>Question {currentIdx + 1} of 10</span>
            <span className="text-emerald-500 font-extrabold">BCS Pattern MCQ</span>
          </div>

          <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-snug">
            Choose the closest meaning of: <span className="text-emerald-500">{q.word.toUpperCase()}</span>
          </h3>

          {/* Options */}
          <div className="space-y-2.5">
            {q.options.map((opt, idx) => {
              const isSelected = selectedOptionIdx === idx;
              const hasAnswered = selectedOptionIdx !== null;

              let style = "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white hover:border-emerald-500";
              if (hasAnswered) {
                if (opt.correct) {
                  style = "bg-emerald-600 text-white font-bold border-emerald-600 shadow-[0_3px_0_0_#059669]";
                } else if (isSelected) {
                  style = "bg-rose-600 text-white font-bold border-rose-600 shadow-[0_3px_0_0_#e11d48]";
                } else {
                  style = "opacity-50 bg-slate-100 dark:bg-slate-800 border-transparent text-slate-400";
                }
              }

              return (
                <button
                  key={idx}
                  disabled={hasAnswered}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full text-left p-3.5 rounded-2xl border-2 text-xs sm:text-sm font-bold shadow-sm active:translate-y-0.5 transition-all flex items-center ${style}`}
                >
                  <span className="font-mono mr-2.5 opacity-60">
                    {String.fromCharCode(65 + idx)})
                  </span>
                  <span>{opt.text}</span>
                </button>
              );
            })}
          </div>

          {/* Feedback */}
          {selectedOptionIdx !== null && (
            <div className={`p-3 rounded-2xl text-xs font-bengali leading-relaxed animate-in fade-in ${
              q.options[selectedOptionIdx].correct
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200'
                : 'bg-rose-50 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200'
            }`}>
              {q.options[selectedOptionIdx].correct ? (
                <div>
                  <strong>✓ চমৎকার! সঠিক উত্তর।</strong> বাংলা অর্থ: {q.bengali}
                </div>
              ) : (
                <div>
                  <strong>✗ ভুল উত্তর।</strong> সঠিক অর্থ: "{q.correctDef}" (বাংলা: {q.bengali})। শব্দটি মিস্টেক্স ব্যাংকে যুক্ত হয়েছে।
                </div>
              )}
            </div>
          )}

          {/* Next Button */}
          {selectedOptionIdx !== null && (
            <button
              onClick={handleNext}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm rounded-2xl shadow-[0_4px_0_0_#0369a1] active:translate-y-1 transition-all flex items-center justify-center gap-1.5"
            >
              <span>{currentIdx + 1 === questions.length ? 'View Diagnostic Report' : 'Next Question'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      ) : (
        /* Report View */
        <div className="bg-white dark:bg-[#111827] border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div className="text-center space-y-2 pb-2 border-b border-slate-200 dark:border-slate-800">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white flex items-center justify-center font-black text-2xl mx-auto shadow-md">
              {score}/10
            </div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Diagnostic Performance Report
            </h3>
            <p className="text-xs text-slate-500 font-bengali">
              {score >= 8
                ? 'দারুণ প্রস্তুতি! আপনার নির্ভুলতা প্রতিযোগিতামূলক পরীক্ষার প্রথম সারির মানের।'
                : 'কিছু শব্দে দুর্বলতা রয়েছে। নিচের বিশদ বিশ্লেষণ পর্যালোচনা করুন।'}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
              <div className="font-black text-emerald-600 dark:text-emerald-400 text-base">{accuracy}%</div>
              <div className="text-[10px] text-slate-400 font-bold">Accuracy</div>
            </div>
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
              <div className="font-black text-blue-500 text-base">{avgSpeed}s</div>
              <div className="text-[10px] text-slate-400 font-bold">Speed/Q</div>
            </div>
            <div className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
              <div className="font-black text-rose-500 text-base">{10 - score}</div>
              <div className="text-[10px] text-slate-400 font-bold">Weak Words</div>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
              Question Itemization Review
            </h4>
            <div className="space-y-2 max-h-60 smooth-scroll pr-1">
              {userAnswers.map((ans, i) => (
                <div
                  key={i}
                  className={`p-2.5 rounded-xl border text-xs space-y-1 ${
                    ans.isCorrect
                      ? 'border-emerald-200 dark:border-emerald-950 bg-emerald-50/40 dark:bg-emerald-950/20'
                      : 'border-rose-200 dark:border-rose-950 bg-rose-50/40 dark:bg-rose-950/20'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-slate-900 dark:text-white">{i + 1}. {ans.word}</span>
                    <span className={`flex items-center gap-1 ${ans.isCorrect ? 'text-emerald-600' : 'text-rose-600'}`}>
                      {ans.isCorrect ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                      {ans.isCorrect ? 'Correct' : 'Missed'}
                    </span>
                  </div>

                  {!ans.isCorrect && (
                    <div className="text-[11px] text-rose-600 font-medium">
                      Your Pick: {ans.chosenText}
                    </div>
                  )}

                  <div className="text-[11px] text-slate-700 dark:text-slate-300">
                    <strong>Correct:</strong> {ans.correctText}
                  </div>

                  <div className="text-[11px] font-bengali text-emerald-800 dark:text-emerald-300">
                    বাংলা: {ans.bengali}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={startQuiz}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#059669] active:scale-95 transition-all"
            >
              Take Another Test
            </button>
            <button
              onClick={onNavigateToVault}
              className="px-4 py-3 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-2xl shadow-[0_4px_0_0_#e11d48] active:scale-95 transition-all flex items-center gap-1"
            >
              <AlertOctagon className="w-4 h-4" /> Mistakes ({10 - score})
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
