"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Component, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { AppProvider, useApp } from "@/lib/store";
import { Icon, type IconName } from "@/components/ui/Icon";
import { Btn, Toaster } from "@/components/ui/primitives";
import { LockScreen, SetupScreen } from "@/components/screens/Auth";
import { HomeScreen } from "@/components/screens/Home";
import { LedgerScreen } from "@/components/screens/Ledger";
import { CalendarScreen } from "@/components/screens/Calendar";
import { BillsScreen } from "@/components/screens/Bills";
import { InsightsScreen } from "@/components/screens/Insights";
import { SettingsScreen } from "@/components/screens/Settings";
import { AddEntrySheet, BillEditorSheet, PayBillSheet, ReceiptSheet } from "@/components/sheets/Sheets";
import { Confirm } from "@/components/ui/primitives";
import type { TabKey } from "@/lib/types";

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}

const NAV: { key: TabKey; label: string; icon: IconName }[] = [
  { key: "home", label: "Home", icon: "home" },
  { key: "insights", label: "Insights", icon: "chart" },
  { key: "bills", label: "Bills", icon: "bolt" },
  { key: "calendar", label: "Calendar", icon: "calendar" },
];

function Ambient() {
  return (
    <div className="amb">
      <div className="amb-grid" />
      <div
        className="amb-glow drift-a"
        style={{
          width: "46vw",
          height: "46vw",
          left: "-8vw",
          top: "-10vw",
          background: "var(--c-glow-a)",
        }}
      />
      <div
        className="amb-glow drift-b"
        style={{
          width: "38vw",
          height: "38vw",
          right: "-6vw",
          top: "22vh",
          background: "var(--c-glow-b)",
        }}
      />
      <div
        className="amb-glow drift-c"
        style={{
          width: "42vw",
          height: "42vw",
          left: "24vw",
          bottom: "-16vw",
          background: "var(--c-glow-c)",
        }}
      />
      <div className="amb-noise" />
    </div>
  );
}

function Clock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 20_000);
    return () => clearInterval(t);
  }, []);
  return (
    <span className="font-mono text-[12px] font-semibold tracking-tight">
      {now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
    </span>
  );
}

function StatusBar() {
  return (
    <div className="hidden h-9 shrink-0 items-center justify-between px-6 text-ink lg:flex">
      <Clock />
      <div className="flex items-center gap-1.5">
        <span className="flex items-end gap-[2px]">
          {[4, 6, 8, 10].map((h, i) => (
            <span
              key={h}
              className="w-[3px] rounded-sm bg-ink"
              style={{ height: h, opacity: i < 3 ? 1 : 0.35 }}
            />
          ))}
        </span>
        <Icon name="wifi" size={14} />
        <span className="relative ml-0.5 flex h-[11px] w-[22px] items-center rounded-[3px] border border-ink/70 px-[1.5px]">
          <span className="h-[6px] w-[13px] rounded-[1px] bg-brand" />
          <span className="absolute -right-[3px] h-[5px] w-[2px] rounded-r bg-ink/70" />
        </span>
      </div>
    </div>
  );
}

function Splash() {
  return (
    <div className="grid h-full place-items-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 22 }}
        className="flex flex-col items-center gap-4"
      >
        <div className="relative grid h-20 w-20 place-items-center rounded-3xl bg-brand text-brandink pulse-ring">
          <Icon name="ledger" size={34} />
        </div>
        <div className="text-center">
          <p className="font-display text-[24px] font-extrabold tracking-[-0.03em]">Keep Tracked</p>
          <p className="font-mono text-[10.5px] uppercase tracking-[0.24em] text-ink3">
            opening your ledger
          </p>
        </div>
        <div className="h-1 w-32 overflow-hidden rounded-full bg-surface2">
          <motion.div
            className="h-full rounded-full bg-brand"
            initial={{ width: "8%" }}
            animate={{ width: "92%" }}
            transition={{ duration: 1.1, ease: "easeInOut" }}
          />
        </div>
      </motion.div>
    </div>
  );
}

class ScreenErrorBoundary extends Component<
  { children: ReactNode; resetKey: string },
  { error: Error | null }
> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  componentDidUpdate(prev: { resetKey: string }) {
    if (prev.resetKey !== this.props.resetKey && this.state.error) this.setState({ error: null });
  }
  render() {
    if (this.state.error) {
      return (
        <div className="grid h-full place-items-center px-6">
          <div className="card w-full max-w-[340px] p-5 text-center">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-spend/35 bg-spend/12 text-spend">
              <Icon name="alert" size={20} />
            </span>
            <p className="mt-3 font-display text-[16px] font-extrabold">This screen crashed</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-ink2">
              {this.state.error.message || "Unexpected render error."} Your data is safe on the
              server.
            </p>
            <div className="mt-4 flex justify-center gap-2">
              <Btn variant="outline" icon="refresh" onClick={() => this.setState({ error: null })}>
                Try again
              </Btn>
              <Btn variant="brand" icon="undo" onClick={() => window.location.reload()}>
                Reload app
              </Btn>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function DataProblem() {
  const { dataError, reload, refresh } = useApp();
  const [busy, setBusy] = useState(false);
  return (
    <div className="grid h-full place-items-center px-6">
      <div className="card w-full max-w-[340px] p-5 text-center">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-bill/35 bg-bill/12 text-bill">
          <Icon name="wifi" size={20} />
        </span>
        <p className="mt-3 font-display text-[16px] font-extrabold">
          {dataError ? "Lost the connection" : "Opening your ledger"}
        </p>
        <p className="mt-1 text-[12.5px] leading-relaxed text-ink2">
          {dataError
            ? `${dataError} — your entries are safe on the server, we just could not load them.`
            : "Fetching earnings, spendings and bills…"}
        </p>
        {dataError ? (
          <div className="mt-4 flex justify-center gap-2">
            <Btn
              variant="brand"
              icon="refresh"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                await reload();
                setBusy(false);
              }}
            >
              Retry now
            </Btn>
            <Btn variant="outline" icon="undo" onClick={() => void refresh()}>
              Quiet retry
            </Btn>
          </div>
        ) : (
          <div className="mt-4 flex justify-center gap-1.5">
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="h-2 w-2 rounded-full bg-brand"
                animate={{ opacity: [0.25, 1, 0.25] }}
                transition={{ duration: 1, repeat: Infinity, delay: i * 0.18 }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Shell() {
  const { boot, tab, setTab, data, openAdd, confirm, closeConfirm } = useApp();
  const inApp = boot === "ready" && !!data;

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);

  const screens: Record<TabKey, React.ReactNode> = {
    home: <HomeScreen />,
    ledger: <LedgerScreen />,
    calendar: <CalendarScreen />,
    bills: <BillsScreen />,
    insights: <InsightsScreen />,
    settings: <SettingsScreen />,
  };

  const isSub = tab === "settings" || tab === "ledger" || tab === "insights";

  return (
    <div className="relative min-h-[100dvh] w-full">
      <Ambient />

      <div className="relative z-10 hidden xl:block">
        <div className="pointer-events-none fixed bottom-8 left-10 max-w-[280px]">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand text-brandink">
              <Icon name="ledger" size={18} />
            </span>
            <div>
              <p className="font-display text-[17px] font-extrabold leading-none tracking-[-0.02em]">
                Keep Tracked
              </p>
              <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-ink3">
                money diary · v1.0
              </p>
            </div>
          </div>
          <p className="mt-3 text-[12.5px] leading-relaxed text-ink2">
            Every earning, spending and bill in one pocket ledger — auto-graphed, calendar-mapped and
            printed as receipts.
          </p>
        </div>
        <div className="pointer-events-none fixed bottom-8 right-10 max-w-[220px] text-right">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink3">
            tip · add to home screen
          </p>
          <p className="mt-1.5 text-[12px] leading-relaxed text-ink3">
            Installs as a standalone Android-style app with its own icon and PIN gate.
          </p>
        </div>
      </div>

      <div className="relative z-10 flex min-h-[100dvh] items-stretch justify-center lg:items-center lg:p-6">
        <div className="relative flex h-[100dvh] w-full flex-col overflow-hidden bg-bg lg:h-[min(890px,94vh)] lg:w-[424px] lg:rounded-[46px] lg:border lg:border-line device-shadow">
          {/* inner ambient wash so screens feel layered on mobile too */}
          <div
            className="pointer-events-none absolute inset-0 z-0"
            style={{
              background:
                "radial-gradient(120% 60% at 50% -10%, var(--c-glow-a), transparent 60%), radial-gradient(90% 50% at 100% 100%, var(--c-glow-b), transparent 65%)",
              opacity: 0.55,
            }}
          />
          <StatusBar />

          <div className="relative z-10 flex min-h-0 flex-1 flex-col">
            <AnimatePresence mode="wait">
              {boot === "boot" ? (
                <motion.div key="splash" className="min-h-0 flex-1" exit={{ opacity: 0 }}>
                  <Splash />
                </motion.div>
              ) : boot === "setup" ? (
                <motion.div
                  key="setup"
                  className="min-h-0 flex-1"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                >
                  <SetupScreen />
                </motion.div>
              ) : boot === "lock" ? (
                <motion.div
                  key="lock"
                  className="min-h-0 flex-1"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                >
                  <LockScreen />
                </motion.div>
              ) : (
                <motion.div key="app" className="min-h-0 flex-1" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                  <div className="relative flex h-full flex-col">
                    <div className="min-h-0 flex-1">
                      {!data ? (
                        <DataProblem />
                      ) : (
                        <ScreenErrorBoundary resetKey={`${tab}:${data.transactions.length}:${data.bills.length}`}>
                          <AnimatePresence mode="wait">
                            <motion.div
                              key={tab}
                              className="h-full"
                              initial={{ opacity: 0, x: isSub ? 40 : 0, y: isSub ? 0 : 12 }}
                              animate={{ opacity: 1, x: 0, y: 0 }}
                              exit={{ opacity: 0, x: isSub ? -30 : 0, y: isSub ? 0 : -8 }}
                              transition={{ type: "spring", stiffness: 340, damping: 34 }}
                            >
                              {screens[tab]}
                            </motion.div>
                          </AnimatePresence>
                        </ScreenErrorBoundary>
                      )}
                    </div>

                    {/* bottom navigation */}
                    <nav className="relative z-30 shrink-0 border-t border-line bg-bg/92 px-3 pb-safe pt-2 backdrop-blur-xl">
                      <div className="flex items-end justify-between">
                        {NAV.slice(0, 2).map((item) => (
                          <NavBtn key={item.key} item={item} active={tab === item.key} onClick={() => setTab(item.key)} />
                        ))}
                        <motion.button
                          whileTap={{ scale: 0.9 }}
                          onClick={() => openAdd("spend")}
                          aria-label="Add earning or spending"
                          className="press -mt-7 grid h-16 w-16 place-items-center rounded-[22px] bg-brand text-brandink shadow-[0_16px_34px_-12px_var(--c-brand)]"
                        >
                          <Icon name="plus" size={28} strokeWidth={2.4} />
                        </motion.button>
                        {NAV.slice(2).map((item) => (
                          <NavBtn key={item.key} item={item} active={tab === item.key} onClick={() => setTab(item.key)} />
                        ))}
                      </div>
                    </nav>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <Toaster />
            {inApp ? (
              <>
                <Sheets />
                <Confirm
                  open={confirm.open}
                  title={confirm.title}
                  body={confirm.body}
                  confirmLabel={confirm.confirmLabel}
                  tone={confirm.tone}
                  onConfirm={() => {
                    confirm.onConfirm();
                    closeConfirm();
                  }}
                  onCancel={closeConfirm}
                />
              </>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

function NavBtn({
  item,
  active,
  onClick,
}: {
  item: { key: TabKey; label: string; icon: IconName };
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={item.label}
      className="press relative flex w-[62px] flex-col items-center gap-1 rounded-xl py-1.5"
    >
      <span className={active ? "text-brandtext" : "text-ink3"}>
        <Icon name={item.icon} size={21} />
      </span>
      <span
        className={`font-mono text-[9px] uppercase tracking-[0.12em] transition-colors ${
          active ? "text-ink" : "text-ink3"
        }`}
      >
        {item.label}
      </span>
      {active ? (
        <motion.span
          layoutId="nav-pill"
          transition={{ type: "spring", stiffness: 520, damping: 38 }}
          className="absolute -top-2 h-1 w-8 rounded-full bg-brand"
        />
      ) : null}
    </button>
  );
}

function Sheets() {
  return (
    <>
      <AddEntrySheet />
      <BillEditorSheet />
      <PayBillSheet />
      <ReceiptSheet />
    </>
  );
}
