import { useCallback, useEffect, useState } from "react";
import type { ModelState, Settings } from "../types";
import { ASR_MODELS, FFMPEG_CORE, MT_MODELS, type ModelDef } from "../lib/catalog";
import {
  downloadFFmpegCore,
  downloadModel,
  ffmpegCoreInstalled,
  filesForRepo,
  fmtBytes,
  listAllCacheFiles,
  removeModel,
  storageInfo,
  type CacheFile,
  type Prog,
} from "../lib/modelManager";
import { releaseASR, releaseMT } from "../lib/engines";
import {
  ENGINE_APPROX_MB,
  engineStatus,
  prefetchEngine,
  removeEngineFiles,
} from "../lib/tjs";
import { Bar, Btn, Card, Chip, Icon, SectionTitle, useToast } from "./ui";
import { cn } from "../utils/cn";

interface Props {
  settings: Settings;
  onSettings: (p: Partial<Settings>) => void;
}

export default function ModelsTab({ settings, onSettings }: Props) {
  const toast = useToast();
  const [files, setFiles] = useState<CacheFile[]>([]);
  const [store, setStore] = useState({ usage: 0, quota: 0 });
  const [states, setStates] = useState<Record<string, ModelState>>({});
  const [busyId, setBusyId] = useState<string | null>(null);
  const [confirmRemove, setConfirmRemove] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const [f, s, ff, es] = await Promise.all([
      listAllCacheFiles(),
      storageInfo(),
      ffmpegCoreInstalled(),
      engineStatus(),
    ]);
    setFiles(f);
    setStore(s);
    const st: Record<string, ModelState> = {};
    st["tjs-engine"] = {
      status: es.installed ? "installed" : "missing",
      progress: 0,
      bytes: es.bytes,
    };
    for (const m of [...ASR_MODELS, ...MT_MODELS]) {
      const repoFiles = filesForRepo(f, m.repo);
      st[m.id] = {
        status: settings.installed[m.id] && repoFiles.length > 0 ? "installed" : "missing",
        progress: 0,
        bytes: repoFiles.reduce((a, b) => a + b.size, 0),
      };
    }
    st[FFMPEG_CORE.id] = {
      status: ff.installed ? "installed" : "missing",
      progress: 0,
      bytes: ff.bytes,
    };
    setStates((prev) => ({
      ...st,
      // keep in-flight progress
      ...Object.fromEntries(
        Object.entries(prev).filter(([k, v]) => v.status === "installing" && busyId === k)
      ),
    }));
  }, [settings.installed, busyId]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const setOne = (id: string, s: Partial<ModelState>) =>
    setStates((p) => ({ ...p, [id]: { ...(p[id] || { status: "missing", progress: 0 }), ...s } }));

  const install = async (def: ModelDef) => {
    if (busyId) return;
    setBusyId(def.id);
    setConfirmRemove(null);
    setOne(def.id, { status: "installing", progress: 0, detail: "connecting to huggingface.co…" });
    try {
      if (def.kind === "asr") releaseASR();
      if (def.kind === "mt") releaseMT(def.id);
      if (def.id === "tjs-engine") {
        const idx = { i: 0 };
        await prefetchEngine((file, frac) => {
          const n = ["transformers.min.js", "wasm", "wasm-boot"].indexOf(file.startsWith("transformers") ? "transformers.min.js" : file.endsWith(".mjs") ? "wasm-boot" : "wasm");
          idx.i = Math.max(idx.i, n);
          setOne(def.id, {
            status: "installing",
            progress: (n + frac) / 3,
            detail: file,
          });
        });
      } else if (def.id === FFMPEG_CORE.id) {
        await downloadFFmpegCore((p: Prog) =>
          setOne(def.id, { status: "installing", progress: p.progress, detail: p.detail })
        );
      } else {
        await downloadModel(def, (p: Prog) =>
          setOne(def.id, { status: "installing", progress: p.progress, detail: p.detail })
        );
      }
      const inst = { ...settings.installed };
      if (def.id !== FFMPEG_CORE.id) inst[def.id] = { at: Date.now() };
      onSettings({ installed: inst });
      setOne(def.id, { status: "installed", progress: 1, detail: "installed & verified" });
      toast(`${def.name} installed and verified`, "ok");
    } catch (e: any) {
      setOne(def.id, {
        status: "error",
        detail: "failed",
        error: String(e?.message || e),
      });
      toast(`${def.name} failed: ${String(e?.message || e).slice(0, 120)}`, "err");
    } finally {
      setBusyId(null);
      void refresh();
    }
  };

  const remove = async (def: ModelDef) => {
    setConfirmRemove(null);
    if (def.id === "tjs-engine") {
      const n = await removeEngineFiles();
      toast(`Core engine: removed ${n} cached file(s) — it re-downloads on first use`, "ok");
      void refresh();
      return;
    }
    if (def.id === FFMPEG_CORE.id) {
      const c = await caches.open("urdu-subs-assets");
      await c.delete(FFMPEG_CORE.base + FFMPEG_CORE.js);
      await c.delete(FFMPEG_CORE.base + FFMPEG_CORE.wasm);
    } else {
      if (def.kind === "asr") releaseASR();
      if (def.kind === "mt") releaseMT(def.id);
      const n = await removeModel(def.id, def.repo);
      toast(`${def.name}: removed ${n} cached file(s)`, "ok");
    }
    setConfirmRemove(null);
    void refresh();
  };

  const mem = (navigator as any).deviceMemory as number | undefined;
  const cores = navigator.hardwareConcurrency || 0;
  const free = store.quota - store.usage;

  const renderModel = (def: ModelDef) => {
    const st = states[def.id] || { status: "missing", progress: 0 };
    const tooBig = mem ? mem < def.minMemGB : false;
    const installing = st.status === "installing";
    return (
      <Card key={def.id} className={cn("space-y-2.5 p-3.5", tooBig && "border-rust-500/30")}>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="font-display text-sm font-semibold text-mist-100">{def.name}</p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-mist-500">{def.sub}</p>
            {def.repo.startsWith("Xenova/") ? (
              <a
                href={`https://huggingface.co/${def.repo}`}
                target="_blank"
                rel="noreferrer"
                className="mt-0.5 inline-flex max-w-full items-center gap-1 truncate text-[11px] text-jade-300 hover:underline"
              >
                <Icon name="globe" className="h-3 w-3" />
                <span className="truncate">{def.repo}</span>
              </a>
            ) : (
              <p className="mt-0.5 inline-flex max-w-full items-center gap-1 truncate text-[11px] text-jade-300">
                <Icon name="globe" className="h-3 w-3" />
                <span className="truncate">{def.repo}</span>
              </p>
            )}
          </div>
          <div className="flex flex-col items-end gap-1.5">
            {st.status === "installed" && <Chip tone="moss">installed</Chip>}
            {st.status === "missing" && <Chip tone="mist">not installed</Chip>}
            {st.status === "error" && <Chip tone="rust">error</Chip>}
            {st.status === "installing" && <Chip tone="brass">downloading</Chip>}
          </div>
        </div>
        <p className="text-[11px] leading-relaxed text-mist-400">{def.notes}</p>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-mist-500">
          <span>
            download ≈ <b className="text-mist-300">{fmtBytes(def.approxMB * 1048576)}</b>
          </span>
          {st.status === "installed" && (st.bytes ?? 0) > 0 && (
            <span>
              cached: <b className="text-mist-300">{fmtBytes(st.bytes ?? 0)}</b>
            </span>
          )}
          <span>license: {def.license}</span>
        </div>
        {tooBig && (
          <p className="flex items-start gap-1.5 rounded-lg bg-rust-500/10 px-2.5 py-1.5 text-[11px] font-semibold text-rust-400">
            <Icon name="alert" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            This device reports {mem} GB RAM — the model needs ~{def.minMemGB} GB+. It may be very
            slow or fail. Try on a desktop or 8 GB phone.
          </p>
        )}
        {store.quota > 0 && st.status !== "installed" && free < def.approxMB * 1048576 * 0.8 && (
          <p className="flex items-start gap-1.5 rounded-lg bg-brass-500/10 px-2.5 py-1.5 text-[11px] font-semibold text-brass-300">
            <Icon name="alert" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            Low storage: only {fmtBytes(free)} free of the required ~
            {fmtBytes(def.approxMB * 1048576)}.
          </p>
        )}
        {st.status === "error" && (
          <p className="rounded-lg bg-rust-500/10 px-2.5 py-1.5 text-[11px] text-rust-400">
            {st.error}
          </p>
        )}
        {installing && (
          <>
            <Bar value={st.progress} active />
            <p className="truncate text-[11px] text-mist-400">
              {st.detail}
              {st.progress > 0 && ` · ${Math.round(st.progress * 100)}%`}
            </p>
          </>
        )}
        <div className="flex gap-2">
          {st.status !== "installed" && (
            <Btn
              size="sm"
              onClick={() => void install(def)}
              disabled={busyId !== null}
              className="flex-1"
            >
              <Icon name="download" className="h-4 w-4" />
              {st.status === "error" ? "Retry (cached files keep)" : "Download & install"}
            </Btn>
          )}
          {(st.status === "installed" || st.status === "installing") && (
            <Btn
              size="sm"
              variant={confirmRemove === def.id ? "danger" : "outline"}
              className={confirmRemove === def.id ? "flex-1" : ""}
              onClick={() => {
                if (confirmRemove === def.id) void remove(def);
                else setConfirmRemove(def.id);
              }}
            >
              <Icon name="trash" className="h-4 w-4" />
              {confirmRemove === def.id ? "Tap again to remove" : "Remove"}
            </Btn>
          )}
        </div>
      </Card>
    );
  };

  return (
    <div className="space-y-5">
      {/* device & storage */}
      <Card className="space-y-3 p-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold text-mist-100">Device & storage</h2>
          <Chip tone={navigator.onLine ? "jade" : "rust"}>
            {navigator.onLine ? "online" : "offline"}
          </Chip>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-lg bg-ink-850 p-2">
            <p className="font-display text-lg font-bold text-mist-100">
              {mem ? `${mem} GB` : "?"}
            </p>
            <p className="text-[10px] text-mist-500 uppercase">RAM</p>
          </div>
          <div className="rounded-lg bg-ink-850 p-2">
            <p className="font-display text-lg font-bold text-mist-100">{cores || "?"}</p>
            <p className="text-[10px] text-mist-500 uppercase">CPU threads</p>
          </div>
          <div className="rounded-lg bg-ink-850 p-2">
            <p className="font-display text-lg font-bold text-mist-100">
              {store.quota ? `${Math.round(store.usage / 1048576)} MB` : "?"}
            </p>
            <p className="text-[10px] text-mist-500 uppercase">used</p>
          </div>
        </div>
        {store.quota > 0 && (
          <>
            <Bar value={store.usage / store.quota} />
            <p className="text-[11px] text-mist-500">
              {fmtBytes(store.usage)} of ~{fmtBytes(store.quota)} browser storage ·{" "}
              {fmtBytes(Math.max(0, free))} free · {files.length} cached model file(s)
            </p>
          </>
        )}
        <p className="rounded-lg bg-ink-850 p-2.5 text-[11px] leading-relaxed text-mist-400">
          <Icon name="shield" className="mr-1 inline h-3.5 w-3.5 text-jade-400" />
          Models download once from <b>huggingface.co</b> (official checkpoints), are verified by
          loading them into the ONNX runtime, and are stored in browser cache. After that, all
          transcription and translation run <b>fully offline</b>.
        </p>
      </Card>

      <div>
        <SectionTitle>Speech recognition — Whisper (ONNX, int8)</SectionTitle>
        <div className="space-y-2.5">{ASR_MODELS.map(renderModel)}</div>
        <p className="mt-2 text-[11px] text-mist-600">
          Whisper transcribes multilingual speech to text with timestamps. It does not translate —
          Urdu output comes from the translation model below. Install one; Base is recommended.
        </p>
      </div>

      <div>
        <SectionTitle>Urdu translation (ONNX, int8)</SectionTitle>
        <div className="space-y-2.5">{MT_MODELS.map(renderModel)}</div>
        <p className="mt-2 text-[11px] leading-relaxed text-mist-600">
          No small ONNX English→Urdu model exists on the Hub yet — the smallest real option is
          M2M100 418M. On low-RAM phones, generate on a desktop (same code) or use the packaged
          APK path (see Docs). Both models output Urdu script (urd_Arab).
        </p>
      </div>

      <div>
        <SectionTitle>Inference core</SectionTitle>
        {renderModel({
          id: "tjs-engine",
          kind: "mt",
          repo: "@huggingface/transformers@3.8.1 (jsDelivr, official)",
          name: "ONNX core engine",
          sub: "transformers.js 3.8.1 + ONNX Runtime WASM · Apache-2.0 / MIT",
          approxMB: ENGINE_APPROX_MB,
          minMemGB: 2,
          license: "Apache-2.0 / MIT",
          notes:
            "Required by all AI models. Downloaded once from the official jsDelivr CDN, cached for offline use, and verified by the self-tests (WASM runtime + offline inference). Re-downloads automatically if removed.",
        })}
      </div>

      <div>
        <SectionTitle>Media tools</SectionTitle>
        {renderModel({
          id: FFMPEG_CORE.id,
          kind: "asr",
          repo: "ffmpeg-core",
          name: FFMPEG_CORE.name,
          sub: FFMPEG_CORE.sub,
          approxMB: FFMPEG_CORE.approxMB,
          minMemGB: 2,
          license: "LGPL (FFmpeg)",
          notes:
            "Fallback audio extractor for containers the browser decoder rejects (MKV, MOV, some codecs). Browser-native decoding covers MP3 / WAV / OGG / FLAC / AAC-in-MP4 on Chrome & Safari — install this for broader format support. Verified by WASM magic-byte check.",
        })}
      </div>

      <Card className="p-4">
        <Btn size="sm" variant="outline" className="w-full" onClick={() => void refresh()}>
          <Icon name="refresh" className="h-4 w-4" /> Re-check installed files & storage
        </Btn>
        <p className="mt-2 text-center text-[10px] text-mist-600">
          Removing a model deletes its cached files and frees storage. Downloads retry by skipping
          already-cached files (file-level resume).
        </p>
      </Card>
    </div>
  );
}
