const bubbles = Array.from({ length: 16 }, (_, index) => ({
  left: (index * 37 + 9) % 97,
  size: 3 + ((index * 7) % 11),
  duration: 9 + ((index * 13) % 10),
  delay: -((index * 17) % 15),
  drift: ((index % 5) - 2) * 14,
}));

const motes = Array.from({ length: 18 }, (_, index) => ({
  left: (index * 53 + 4) % 100,
  top: (index * 29 + 7) % 92,
  delay: -((index * 11) % 12),
  duration: 7 + (index % 6),
}));

export default function OceanBackground() {
  return (
    <div className="ocean-scene" aria-hidden="true">
      <div className="ocean-depth" />
      <div className="sun-pool" />
      <div className="light-rays">
        <i className="ray ray-one" />
        <i className="ray ray-two" />
        <i className="ray ray-three" />
        <i className="ray ray-four" />
      </div>
      <div className="caustic-light" />
      <div className="ocean-motes">
        {motes.map((mote, index) => (
          <i
            key={index}
            style={{
              left: `${mote.left}%`,
              top: `${mote.top}%`,
              animationDelay: `${mote.delay}s`,
              animationDuration: `${mote.duration}s`,
            }}
          />
        ))}
      </div>
      <div className="ocean-bubbles">
        {bubbles.map((bubble, index) => (
          <i
            key={index}
            style={{
              left: `${bubble.left}%`,
              width: bubble.size,
              height: bubble.size,
              animationDuration: `${bubble.duration}s`,
              animationDelay: `${bubble.delay}s`,
              ["--drift" as string]: `${bubble.drift}px`,
            } as React.CSSProperties}
          />
        ))}
      </div>
      <svg className="reef reef-back" viewBox="0 0 1440 260" preserveAspectRatio="none">
        <path d="M0 208 Q130 155 260 212 T520 200 T790 214 T1060 188 T1320 209 L1440 184 V260 H0Z" />
        <path d="M88 220 Q62 146 98 105 Q82 170 122 213 M111 180 Q147 135 139 97 Q165 151 133 215" />
        <path d="M1240 216 Q1206 155 1239 90 Q1228 165 1271 213 M1260 171 Q1300 139 1301 99 Q1320 159 1280 220" />
      </svg>
      <svg className="reef reef-front" viewBox="0 0 1440 210" preserveAspectRatio="none">
        <path d="M0 166 Q160 128 312 174 T625 161 T930 177 T1240 154 L1440 168 V210 H0Z" />
        <path className="coral" d="M70 181 V121 M70 151 L42 126 M70 142 L94 108 M42 126 L37 103 M94 108 L112 100 M1322 174 V119 M1322 145 L1295 124 M1322 137 L1348 105 M1295 124 L1289 105" />
        <path className="grass" d="M260 185 Q231 128 257 82 Q251 140 278 183 M287 183 Q312 134 298 99 Q328 141 303 188 M1120 181 Q1091 126 1113 83 Q1108 137 1136 181 M1150 183 Q1176 135 1163 98 Q1191 143 1168 187" />
      </svg>
      <div className="ocean-vignette" />
    </div>
  );
}
