import React, { useState } from 'react';
import { useData } from '../context/DataContext.tsx';
import { Mail, MessageSquare, Send, CheckCircle2, ArrowRight, ShieldCheck, MapPin } from 'lucide-react';

interface ContactSectionProps {
  onNavigateStartProject: () => void;
  onOpenAdmin: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  onNavigateStartProject,
  onOpenAdmin
}) => {
  const { data, submitContactMessage } = useData();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      setErrorMsg('Please complete all fields.');
      return;
    }
    setErrorMsg(null);
    setSending(true);

    const res = await submitContactMessage({ name, email, message });
    setSending(false);

    if (res.success) {
      setSentSuccess(true);
      setName('');
      setEmail('');
      setMessage('');
    } else {
      setErrorMsg(res.error || 'Failed to send message. Please try again.');
    }
  };

  return (
    <footer id="contact" className="py-16 border-t border-cyan-500/15 bg-gradient-to-b from-[#030712] via-[#050e1c] to-[#02050b]">
      <div className="max-w-[1120px] mx-auto px-4 sm:px-6">
        {/* Contact Invitation & Form Box */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
          {/* Left Info Column */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3 py-1 rounded-full border border-cyan-500/30">
                GET IN TOUCH
              </span>
              <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight mt-4 mb-3 font-['Plus_Jakarta_Sans']">
                Let's Discuss Your Next Build.
              </h2>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                {data?.settings?.contactDescription ||
                  'Have a project in mind or need technical consultation? Reach out directly or start a project brief with our team.'}
              </p>
            </div>

            {/* Direct contact items */}
            <div className="space-y-3.5 pt-2">
              <a
                href={`mailto:${data?.settings?.contactEmail || 'real1cubix@gmail.com'}`}
                className="flex items-center gap-3.5 p-4 rounded-xl bg-white/[0.03] border border-white/10 hover:border-cyan-500/40 text-slate-200 hover:text-white transition-all group"
              >
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/30 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-colors">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono uppercase text-slate-400">Direct Email</div>
                  <div className="text-sm font-bold text-white font-mono">{data?.settings?.contactEmail || 'real1cubix@gmail.com'}</div>
                </div>
              </a>

              {data?.settings?.discordUrl && (
                <a
                  href={data.settings.discordUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3.5 p-4 rounded-xl bg-white/[0.03] border border-white/10 hover:border-cyan-500/40 text-slate-200 hover:text-white transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/30 group-hover:bg-blue-500 group-hover:text-slate-950 transition-colors">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono uppercase text-slate-400">Discord Community</div>
                    <div className="text-sm font-bold text-white">Join Cubix Discord Server</div>
                  </div>
                </a>
              )}

              <div className="flex items-center gap-3.5 p-4 rounded-xl bg-white/[0.03] border border-white/10 text-slate-300">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-mono uppercase text-slate-400">Studio Location</div>
                  <div className="text-sm font-bold text-white">{data?.settings?.location || 'Gurgaon, Haryana, India'}</div>
                </div>
              </div>
            </div>

            {/* Clear Path to Start a Project */}
            <div className="p-5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 space-y-3">
              <div className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                Start a Project
              </div>
              <p className="text-xs text-slate-300">
                Explore our full catalog of services, digital products, and connect with our live support ticket desk.
              </p>
              <button
                onClick={onNavigateStartProject}
                className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-sm shadow-[0_0_20px_rgba(0,210,255,0.3)] transition-all cursor-pointer"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Form Column: Quick Message */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl bg-[#081427]/80 border border-cyan-500/20 shadow-xl">
            <h3 className="text-xl font-bold text-white mb-2">Send a Message</h3>
            <p className="text-xs text-slate-400 mb-6">
              Drop us a direct note and we will get back to you via email within 2-4 hours.
            </p>

            {sentSuccess ? (
              <div className="p-6 rounded-2xl bg-cyan-950/40 border border-cyan-400/40 text-center space-y-3 animate-fadeIn">
                <CheckCircle2 className="w-10 h-10 text-cyan-400 mx-auto" />
                <h4 className="text-lg font-bold text-white">Message Sent Successfully</h4>
                <p className="text-xs text-slate-300 max-w-sm mx-auto">
                  Thank you for contacting Cubix Studio. We have received your inquiry and will respond shortly.
                </p>
                <button
                  onClick={() => setSentSuccess(false)}
                  className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {errorMsg && (
                  <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                    {errorMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="contact-name" className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1.5">
                      Your Name *
                    </label>
                    <input
                      id="contact-name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Alex"
                      className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all"
                    />
                  </div>
                  <div>
                    <label htmlFor="contact-email" className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1.5">
                      Email Address *
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. alex@example.com"
                      className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="contact-message" className="block text-xs font-mono font-bold uppercase text-slate-300 mb-1.5">
                    Message *
                  </label>
                  <textarea
                    id="contact-message"
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Tell us what you'd like to discuss or build..."
                    className="w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-all resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={sending}
                  className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-bold text-sm shadow-[0_0_20px_rgba(0,210,255,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{sending ? 'Sending Message...' : 'Get in Touch'}</span>
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Footer Sub-Row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 border-t border-white/10 text-xs text-slate-500">
          <div className="flex items-center gap-2.5">
            <div className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-400/40 p-0.5 flex items-center justify-center">
              <img
                src={data.settings.logoUrl || '/cubix-logo.jpg'}
                alt="Cubix"
                className="w-full h-full rounded-full object-cover"
              />
            </div>
            <span>© {new Date().getFullYear()} Cubix Studio. Operated by RealCubix. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-4">
            <span>Gurgaon, Haryana, India</span>
            <span className="text-slate-600">•</span>
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors font-mono cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
