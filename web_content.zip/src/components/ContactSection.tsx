import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Send, 
  Clock, 
  CheckCircle, 
  Crown
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { language, showToast } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';

  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryMsg, setInquiryMsg] = useState('');
  const [inquirySubmitted, setInquirySubmitted] = useState(false);

  const handleSubmitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName.trim() || !inquiryPhone.trim()) {
      showToast(isAr ? 'يرجى إدخال الاسم ورقم الهاتف' : 'Please provide name and phone');
      return;
    }

    setInquirySubmitted(true);
    showToast(isAr ? 'شكراً لك! تم استلام استفسارك وسيتواصل معك منسق الحالة' : 'Inquiry received. A medical coordinator will reach out shortly.');
  };

  return (
    <section className="py-20 bg-zinc-950 text-white border-b border-[#D4AF37]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Info Side */}
          <div className="lg:col-span-5 space-y-6">
            <div className="inline-flex items-center gap-1.5 bg-black text-amber-300 text-xs font-bold px-3.5 py-1.5 rounded-full border border-[#D4AF37]/40 shadow-sm">
              <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'استجابة سريعة على مدار 24 ساعة' : '24/7 Rapid Response Desk'}</span>
            </div>

            <h2 className="text-3xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent tracking-tight">
              {isAr ? 'تواصل مع مكتب التنسيق الطبي والاستفسارات' : 'Get in Touch with our Medical Coordination Desk'}
            </h2>

            <p className="text-zinc-400 text-sm leading-relaxed">
              {isAr
                ? 'فريق من المنسقين الطبيين ذوي الخبرة العالية مستعد للإجابة على جميع تساؤلاتك حول المستشفيات المصرية، التكاليف التقديرية، التأشيرات العلاجية، وإجراءات الاستقبال.'
                : 'Our experienced clinical liaison team is available to assist you with inquiries regarding top hospital matching, estimates, and logistics.'}
            </p>

            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border border-zinc-800 shadow-md">
                <div className="w-11 h-11 rounded-xl bg-zinc-900 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-500 font-medium">{isAr ? 'الخط الساخن والمراسلات المباشرة:' : 'Direct Hotline & WhatsApp:'}</div>
                  <div className="text-sm font-bold text-amber-300 font-mono">+20 2 2400 9900 / +20 100 000 8899</div>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border border-zinc-800 shadow-md">
                <div className="w-11 h-11 rounded-xl bg-zinc-900 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-500 font-medium">{isAr ? 'البريد الإلكتروني المعتمد:' : 'Official Inquiries Email:'}</div>
                  <div className="text-sm font-bold text-amber-300 font-mono">desk@almowasat.eg</div>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border border-zinc-800 shadow-md">
                <div className="w-11 h-11 rounded-xl bg-zinc-900 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-zinc-500 font-medium">{isAr ? 'المقر الرئيسي للمنصة:' : 'Headquarters:'}</div>
                  <div className="text-xs font-bold text-zinc-200">
                    {isAr ? 'القاهرة الجديدة، التجمع الخامس، جمهورية مصر العربية' : 'New Cairo, 5th Settlement, Cairo, Egypt'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="lg:col-span-7">
            <div className="bg-black/95 rounded-3xl p-7 sm:p-9 border border-[#D4AF37]/40 shadow-2xl">
              {inquirySubmitted ? (
                <div className="text-center py-10 space-y-4">
                  <div className="w-16 h-16 bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-amber-300 rounded-full flex items-center justify-center mx-auto shadow-lg">
                    <CheckCircle className="w-10 h-10" />
                  </div>
                  <h3 className="text-xl font-bold text-white">
                    {isAr ? 'تم استلام استفسارك بنجاح!' : 'Your inquiry has been received!'}
                  </h3>
                  <p className="text-xs text-zinc-400 max-w-md mx-auto">
                    {isAr 
                      ? 'سيقوم أحد منسقي الرعاية الطبية بالتواصل معك عبر الواتساب أو الهاتف خلال دقائق لتزويدك بكافة المعلومات المطلوبة.'
                      : 'A dedicated patient care navigator will reach out to you via WhatsApp or phone shortly.'}
                  </p>
                  <button
                    onClick={() => {
                      setInquirySubmitted(false);
                      setInquiryMsg('');
                    }}
                    className="text-xs font-bold text-amber-400 hover:underline pt-2 block mx-auto"
                  >
                    {isAr ? 'إرسال استفسار آخر' : 'Send another inquiry'}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitInquiry} className="space-y-4">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Crown className="w-5 h-5 text-[#D4AF37]" />
                    <span>{isAr ? 'أرسل استفسارك السريع' : 'Submit Rapid Inquiry'}</span>
                  </h3>
                  <p className="text-xs text-zinc-400">
                    {isAr ? 'سيرد عليك استشاري التنسيق الطبي مع ملف استرشادي مجاني' : 'Our clinical desk will reply with a complimentary guidance brief'}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-amber-200 mb-1">
                        {isAr ? 'الاسم الكريم' : 'Your Name'} *
                      </label>
                      <input
                        type="text"
                        value={inquiryName}
                        onChange={(e) => setInquiryName(e.target.value)}
                        placeholder={isAr ? 'الاسم' : 'Name'}
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-amber-200 mb-1">
                        {isAr ? 'رقم الهاتف / واتساب' : 'Phone / WhatsApp'} *
                      </label>
                      <input
                        type="tel"
                        value={inquiryPhone}
                        onChange={(e) => setInquiryPhone(e.target.value)}
                        placeholder="+966 50 000 0000"
                        className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37] font-mono"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-amber-200 mb-1">
                      {isAr ? 'نص الاستفسار أو التخصص المطلوب' : 'Inquiry Details or Specialty'}
                    </label>
                    <textarea
                      rows={3}
                      value={inquiryMsg}
                      onChange={(e) => setInquiryMsg(e.target.value)}
                      placeholder={isAr ? 'اكتب ما تود الاستفسار عنه بخصوص الأطباء، المستشفيات، أو برامج الاستشفاء...' : 'Describe what you would like to ask regarding treatments, logistics, or hospitals...'}
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white focus:outline-hidden focus:border-[#D4AF37]"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold rounded-xl text-xs sm:text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4 text-black" />
                    <span>{isAr ? 'إرسال الاستفسار الآن' : 'Submit Inquiry'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
