import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Phone, 
  MessageCircle, 
  MapPin, 
  Clock, 
  ExternalLink, 
  ShieldCheck, 
  Mail,
  Navigation,
  Send
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { shopSettings, language, t } = useApp();

  const openWhatsApp = (phone: string) => {
    const text = encodeURIComponent(
      language === 'hi'
        ? 'नमस्ते ए के गोलू कंप्यूटर! मुझे कंप्यूटर/लैपटॉप या सीसीटीवी के बारे में जानकारी चाहिए।'
        : 'Hello A K Golu Computer! I want to enquire about products or technical services.'
    );
    window.open(`https://wa.me/91${phone}?text=${text}`, '_blank');
  };

  return (
    <section id="contact" className="py-14 sm:py-16 bg-slate-950 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
            <MapPin className="w-3.5 h-3.5" />
            <span>{t.contactSection.badge}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.contactSection.title}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            {t.contactSection.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Direct Call & WhatsApp Action Cards */}
          <div className="lg:col-span-5 space-y-4 flex flex-col justify-between">
            {/* Phone Number 1 Card */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/40 transition shadow-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
                  {language === 'hi' ? 'मुख्य संपर्क नंबर (Primary)' : 'Primary Contact'}
                </span>
                <span className="text-[11px] font-medium text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  24x7 WhatsApp
                </span>
              </div>
              <div className="text-xl sm:text-2xl font-black text-white">
                +91 {shopSettings.phone1}
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <a
                  href={`tel:${shopSettings.phone1}`}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{t.callNow}</span>
                </a>
                <button
                  onClick={() => openWhatsApp(shopSettings.phone1)}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>

            {/* Phone Number 2 Card */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/40 transition shadow-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
                  {language === 'hi' ? 'वैकल्पिक संपर्क नंबर (Secondary)' : 'Secondary Contact'}
                </span>
                <span className="text-[11px] font-medium text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  Quick Reply
                </span>
              </div>
              <div className="text-xl sm:text-2xl font-black text-white">
                +91 {shopSettings.phone2}
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <a
                  href={`tel:${shopSettings.phone2}`}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{t.callNow}</span>
                </a>
                <button
                  onClick={() => openWhatsApp(shopSettings.phone2)}
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>

            {/* Address & Hours Summary */}
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-rose-400 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-white text-xs mb-0.5">{t.contactSection.addressTitle}:</h4>
                  <p>{shopSettings.addressLine1}</p>
                  <p>{shopSettings.addressLine2}, {shopSettings.cityState} - {shopSettings.pincode}</p>
                  <p className="text-slate-400 text-[11px] mt-0.5">({shopSettings.landmark})</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 pt-2 border-t border-slate-800/80">
                <Clock className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-white text-xs mb-0.5">{t.contactSection.hoursTitle}:</h4>
                  <p>{shopSettings.openingHours[language] || shopSettings.openingHours.en}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Google Maps & Directions */}
          <div className="lg:col-span-7 flex flex-col rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl min-h-[360px]">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-2">
                <Navigation className="w-4 h-4 text-blue-400" />
                <span className="font-bold text-white text-xs sm:text-sm">
                  {language === 'hi' ? 'दुकान की लोकेशन व नक्शा' : 'Shop Location & Map View'}
                </span>
              </div>
              <a
                href={shopSettings.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 transition"
              >
                <span>{t.contactSection.directionsBtn}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="relative flex-1 w-full min-h-[300px] bg-slate-950">
              <iframe
                title="A K Golu Computer Google Map"
                src={shopSettings.googleMapsEmbedUrl}
                className="w-full h-full border-0 absolute inset-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            
            <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>{t.contactSection.contactCardNote}</span>
              <span className="text-slate-500 hidden sm:inline">UPI ID: {shopSettings.upiId}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
