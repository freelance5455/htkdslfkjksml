import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlertTriangle,
  CalendarPlus,
  CheckSquare,
  Edit3,
  FileSpreadsheet,
  Lock,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import {
  COMPLAINT_STATUSES,
  COMPLAINT_TYPES,
  ComplaintRecord,
  ComplaintStatus,
  ComplaintType,
  ConfirmDialogState,
  FIELD_LIMITS,
  STORE_NAMES,
  StoreName,
} from '../types/ops';
import {
  createComplaint,
  deleteComplaint,
  updateComplaintHandling,
} from '../lib/firestoreOps';
import {
  createCalendarEvent,
  createSpreadsheet,
  createTask,
  listTaskLists,
  overwriteSheetValues,
} from '../lib/workspaceApi';

interface ComplaintsViewProps {
  ownerId: string;
  userEmail: string;
  userName: string;
  isAdmin: boolean;
  teamEmails: string[];
  complaints: ComplaintRecord[];
  accessToken: string | null;
  onRequestConfirm: (dialog: ConfirmDialogState) => void;
  onReconnectWorkspace: () => void;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

const STATUS_TEXT_CLASS: Record<ComplaintStatus, string> = {
  'Baru Masuk': 'text-red-700 font-semibold',
  'Sedang Dicek Gudang': 'text-orange-700 font-semibold',
  'Menunggu Penggantian': 'text-amber-700 font-semibold',
  Selesai: 'text-emerald-700 font-semibold',
};

export const ComplaintsView: React.FC<ComplaintsViewProps> = ({
  ownerId,
  userEmail,
  userName,
  isAdmin,
  teamEmails,
  complaints,
  accessToken,
  onRequestConfirm,
  onReconnectWorkspace,
  onNotify,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'Semua' | ComplaintStatus>('Semua');
  const [storeFilter, setStoreFilter] = useState<'Semua' | StoreName>('Semua');

  // Create Modal
  const [showCreate, setShowCreate] = useState(false);
  const [orderCode, setOrderCode] = useState('');
  const [store, setStore] = useState<StoreName>('Tiga Rekan ID (TikTok)');
  const [customerName, setCustomerName] = useState('');
  const [complaintType, setComplaintType] = useState<ComplaintType>('Barang Rusak');
  const [description, setDescription] = useState('');
  const [picName, setPicName] = useState(userName);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // Edit Handling Modal
  const [editingItem, setEditingItem] = useState<ComplaintRecord | null>(null);
  const [editStatus, setEditStatus] = useState<ComplaintStatus>('Sedang Dicek Gudang');
  const [editPic, setEditPic] = useState('');
  const [editResolution, setEditResolution] = useState('');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return complaints.filter((c) => {
      if (statusFilter !== 'Semua' && c.status !== statusFilter) return false;
      if (storeFilter !== 'Semua' && c.store !== storeFilter) return false;
      if (!q) return true;
      return (
        c.orderCode.toLowerCase().includes(q) ||
        c.customerName.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.picName.toLowerCase().includes(q)
      );
    });
  }, [complaints, search, statusFilter, storeFilter]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      await createComplaint(ownerId, userEmail, {
        orderCode,
        store,
        customerName,
        complaintType,
        description,
        resolutionNotes: '',
        status: 'Baru Masuk',
        picName: picName || userName,
        assignedEmails: teamEmails,
      });
      setShowCreate(false);
      setOrderCode('');
      setCustomerName('');
      setDescription('');
      onNotify('Catatan komplain pesanan berhasil disimpan.', 'success');
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Gagal menyimpan komplain.');
    } finally {
      setSaving(false);
    }
  };

  const openEdit = (item: ComplaintRecord) => {
    setEditingItem(item);
    setEditStatus(item.status);
    setEditPic(item.picName || userName);
    setEditResolution(item.resolutionNotes || '');
  };

  const handleSaveUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    const perform = async () => {
      await updateComplaintHandling(editingItem.id, {
        status: editStatus,
        resolutionNotes: editResolution,
        picName: editPic,
      });
      setEditingItem(null);
      onNotify(`Penanganan komplain ${editingItem.orderCode} diperbarui.`, 'success');
    };

    if (editStatus === 'Selesai' && !isAdmin) {
      onRequestConfirm({
        open: true,
        title: `Tutup Komplain ${editingItem.orderCode} sebagai Selesai?`,
        description:
          'Setelah berstatus Selesai, catatan komplain dikunci dan hanya dapat dibuka kembali oleh Administrator.',
        confirmLabel: 'Tandai Selesai',
        onConfirm: perform,
      });
    } else {
      await perform();
    }
  };

  const handleDelete = (item: ComplaintRecord) => {
    onRequestConfirm({
      open: true,
      title: `Hapus Catatan Komplain ${item.orderCode}?`,
      description: `Komplain pembeli ${item.customerName} (${item.store}) akan dihapus permanen.`,
      confirmLabel: 'Hapus Catatan',
      variant: 'danger',
      onConfirm: async () => {
        await deleteComplaint(item.id);
        onNotify(`Catatan komplain ${item.orderCode} dihapus.`, 'success');
      },
    });
  };

  const handleScheduleCalendar = (item: ComplaintRecord) => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    const start = new Date(Date.now() + 60 * 60 * 1000);
    const end = new Date(start.getTime() + 30 * 60 * 1000);
    onRequestConfirm({
      open: true,
      title: 'Jadwalkan Tindak Lanjut Komplain ke Google Calendar?',
      description: `Membuat pengingat penyelesaian komplain ${item.orderCode} (${item.store}) di kalender utama Anda.`,
      confirmLabel: 'Buat Acara Calendar',
      details: [
        `No. Pesanan: ${item.orderCode} · ${item.complaintType}`,
        `Pembeli: ${item.customerName} · PIC: ${item.picName || '-'}`,
      ],
      onConfirm: async () => {
        await createCalendarEvent(accessToken, {
          summary: `Komplain ${item.orderCode} (${item.store})`,
          description: `Jenis: ${item.complaintType}\nPembeli: ${item.customerName}\nKronologi: ${item.description}\nSolusi: ${item.resolutionNotes || '-'}`,
          location: item.store,
          startIso: start.toISOString(),
          endIso: end.toISOString(),
        });
        onNotify(`Agenda komplain ${item.orderCode} ditambahkan ke Google Calendar.`, 'success');
      },
    });
  };

  const handleCreateTask = (item: ComplaintRecord) => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    onRequestConfirm({
      open: true,
      title: 'Buat Tugas Penanganan Komplain di Google Tasks?',
      description: `Menambahkan tugas tindak lanjut komplain ${item.orderCode} ke Google Tasks Anda.`,
      confirmLabel: 'Tambahkan ke Google Tasks',
      onConfirm: async () => {
        const lists = await listTaskLists(accessToken);
        const listId = lists[0]?.id || '@default';
        await createTask(accessToken, listId, {
          title: `Komplain ${item.orderCode} (${item.store}) - ${item.complaintType}`,
          notes: `Pembeli: ${item.customerName}\nKronologi: ${item.description}\nPIC: ${item.picName || '-'}`,
          dueIso: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        });
        onNotify(`Tugas komplain ${item.orderCode} dibuat di Google Tasks.`, 'success');
      },
    });
  };

  const handleExportSheets = () => {
    if (!accessToken) {
      onReconnectWorkspace();
      return;
    }
    if (filtered.length === 0) {
      onNotify('Tidak ada catatan komplain untuk diekspor.', 'error');
      return;
    }
    onRequestConfirm({
      open: true,
      title: 'Ekspor Catatan Komplain Pesanan ke Google Sheets?',
      description: `Aplikasi akan membuat spreadsheet baru berisi ${filtered.length} catatan komplain pesanan.`,
      confirmLabel: 'Buat & Ekspor ke Sheets',
      onConfirm: async () => {
        const title = `Catatan Komplain Pesanan Tiga Rekan ID - ${new Date().toLocaleDateString('id-ID')}`;
        const meta = await createSpreadsheet(accessToken, title, 'Komplain Pesanan');
        const tabTitle = meta.sheets[0]?.properties?.title || 'Komplain Pesanan';
        const rows: (string | number)[][] = [
          ['No. Pesanan', 'Toko', 'Pembeli', 'Jenis Komplain', 'Kronologi', 'Status', 'PIC', 'Catatan Penyelesaian'],
          ...filtered.map((c) => [
            c.orderCode,
            c.store,
            c.customerName,
            c.complaintType,
            c.description,
            c.status,
            c.picName,
            c.resolutionNotes,
          ]),
        ];
        await overwriteSheetValues(accessToken, meta.spreadsheetId, tabTitle, rows);
        onNotify(`Spreadsheet "${title}" berhasil dibuat di Google Sheets.`, 'success');
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-5 border-b border-stone-200">
        <div>
          <p className="text-xs font-semibold text-orange-700">
            Layanan Purna Jual · Tiga Rekan ID & Veelo Store ID
          </p>
          <h1 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight mt-1">
            Catatan Komplain Pesanan
          </h1>
          <p className="text-sm text-stone-600 mt-1">
            Catat kendala barang rusak, salah kirim, keterlambatan kurir, dan pantau penyelesaian komplain lintas toko.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-2.5 sm:gap-3 w-full md:w-auto shrink-0">
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            onClick={handleExportSheets}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            Ekspor ke Google Sheets
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            onClick={() => setShowCreate(true)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 sm:py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            Catat Komplain Baru
          </motion.button>
        </div>
      </div>

      {/* Filters Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 sm:gap-4">
        <div className="w-full lg:w-auto overflow-x-auto pb-1 lg:pb-0">
          <div className="inline-flex items-center gap-1 p-1 bg-stone-100 rounded-xl min-w-max">
            {(['Semua', ...COMPLAINT_STATUSES] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === st
                    ? 'bg-white text-orange-700 shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-2.5 sm:gap-3 w-full lg:w-auto">
          <select
            value={storeFilter}
            onChange={(e) => setStoreFilter(e.target.value as 'Semua' | StoreName)}
            aria-label="Filter toko"
            className="w-full sm:w-auto px-3 py-2 text-sm bg-white border border-stone-300 rounded-lg text-stone-700 focus:outline-none focus:border-orange-600"
          >
            <option value="Semua">Semua Toko</option>
            {STORE_NAMES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari no. pesanan, pembeli, PIC..."
              className="pl-9 pr-3 py-2 text-sm bg-white border border-stone-300 rounded-lg w-full focus:outline-none focus:border-orange-600"
            />
          </div>
        </div>
      </div>

      {/* Complaints List / Table */}
      <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 sm:p-10 text-center">
            <AlertTriangle className="w-6 h-6 text-orange-500 mx-auto mb-2" />
            <p className="text-sm font-semibold text-stone-800">
              {complaints.length === 0
                ? 'Belum ada catatan komplain pesanan'
                : 'Tidak ada komplain sesuai filter'}
            </p>
            <p className="text-xs text-stone-500 mt-1 mb-4">
              Catat setiap komplain pelanggan di sini agar tim gudang dan CS dapat menindaklanjuti dengan cepat.
            </p>
            {complaints.length === 0 && (
              <button
                type="button"
                onClick={() => setShowCreate(true)}
                className="px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700"
              >
                Catat Komplain Pertama
              </button>
            )}
          </div>
        ) : (
          <>
            {/* Mobile Card List */}
            <div className="md:hidden divide-y divide-stone-100">
              {filtered.map((item) => {
                const lockedForEmployee = item.status === 'Selesai' && !isAdmin;
                return (
                  <div key={item.id} className="p-4 space-y-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-mono text-xs font-bold text-stone-900">
                          {item.orderCode}
                        </p>
                        <p className="text-xs text-orange-700 font-medium mt-0.5 truncate">
                          {item.store}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <span className={`text-xs ${STATUS_TEXT_CLASS[item.status]}`}>
                          {item.status}
                        </span>
                        {lockedForEmployee && <Lock className="w-3 h-3 text-stone-400" />}
                      </div>
                    </div>

                    <div className="text-xs text-stone-700">
                      <span className="font-semibold text-stone-900">{item.customerName}</span>
                      {' · '}
                      <span className="text-stone-500">{item.complaintType}</span>
                    </div>

                    <p className="text-xs text-stone-800 leading-relaxed bg-stone-50 rounded-lg px-3 py-2">
                      {item.description}
                    </p>

                    {item.resolutionNotes && (
                      <p className="text-xs text-emerald-700 leading-relaxed">
                        Solusi: {item.resolutionNotes}
                      </p>
                    )}

                    <div className="pt-1 flex items-center justify-between gap-2 border-t border-stone-100">
                      <span className="text-xs text-stone-500 truncate">
                        PIC: <span className="font-medium text-stone-700">{item.picName || '-'}</span>
                      </span>
                      <div className="inline-flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleScheduleCalendar(item)}
                          title="Jadwalkan di Google Calendar"
                          className="p-2 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                        >
                          <CalendarPlus className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCreateTask(item)}
                          title="Buat Tugas di Google Tasks"
                          className="p-2 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                        >
                          <CheckSquare className="w-4 h-4" />
                        </button>
                        {!lockedForEmployee && (
                          <button
                            type="button"
                            onClick={() => openEdit(item)}
                            title="Perbarui penanganan"
                            className="p-2 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        )}
                        {isAdmin && (
                          <button
                            type="button"
                            onClick={() => handleDelete(item)}
                            title="Hapus komplain"
                            className="p-2 text-stone-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-stone-200 bg-stone-50 text-xs font-semibold text-stone-600">
                    <th className="py-3 px-4 whitespace-nowrap">Pesanan & Toko</th>
                    <th className="py-3 px-4 whitespace-nowrap">Pembeli & Jenis</th>
                    <th className="py-3 px-4 whitespace-nowrap">Kronologi & Solusi</th>
                    <th className="py-3 px-4 whitespace-nowrap">PIC</th>
                    <th className="py-3 px-4 whitespace-nowrap">Status</th>
                    <th className="py-3 px-4 whitespace-nowrap text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-sm">
                  {filtered.map((item) => {
                    const lockedForEmployee = item.status === 'Selesai' && !isAdmin;
                    return (
                      <tr key={item.id} className="hover:bg-orange-50/40 transition-colors">
                        <td className="py-3 px-4 align-top whitespace-nowrap">
                          <div className="font-mono text-xs font-bold text-stone-900">
                            {item.orderCode}
                          </div>
                          <div className="text-xs text-orange-700 font-medium mt-0.5">{item.store}</div>
                        </td>
                        <td className="py-3 px-4 align-top whitespace-nowrap">
                          <div className="font-medium text-stone-900">{item.customerName}</div>
                          <div className="text-xs text-stone-500 mt-0.5">{item.complaintType}</div>
                        </td>
                        <td className="py-3 px-4 align-top max-w-sm">
                          <p className="text-xs text-stone-800 leading-relaxed">{item.description}</p>
                          {item.resolutionNotes && (
                            <p className="text-xs text-emerald-700 mt-1">
                              Solusi: {item.resolutionNotes}
                            </p>
                          )}
                        </td>
                        <td className="py-3 px-4 align-top text-xs text-stone-700 whitespace-nowrap">
                          {item.picName || '-'}
                        </td>
                        <td className="py-3 px-4 align-top whitespace-nowrap">
                          <span className={`text-xs ${STATUS_TEXT_CLASS[item.status]}`}>
                            {item.status}
                          </span>
                          {lockedForEmployee && (
                            <Lock className="w-3 h-3 text-stone-400 inline ml-1.5" />
                          )}
                        </td>
                        <td className="py-3 px-4 align-top text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleScheduleCalendar(item)}
                              title="Jadwalkan di Google Calendar"
                              className="p-1.5 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                            >
                              <CalendarPlus className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCreateTask(item)}
                              title="Buat Tugas di Google Tasks"
                              className="p-1.5 text-stone-500 hover:text-orange-700 hover:bg-orange-50 rounded-md"
                            >
                              <CheckSquare className="w-4 h-4" />
                            </button>
                            {!lockedForEmployee && (
                              <button
                                type="button"
                                onClick={() => openEdit(item)}
                                title="Perbarui penanganan"
                                className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-md"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                            )}
                            {isAdmin && (
                              <button
                                type="button"
                                onClick={() => handleDelete(item)}
                                title="Hapus komplain"
                                className="p-1.5 text-stone-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Create Complaint Modal */}
      <AnimatePresence>
        {showCreate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-stone-900/40 p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              className="w-full max-w-lg bg-white border border-stone-200 rounded-xl p-6 shadow-xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-4">
                <h2 className="text-base font-bold text-stone-900">Catat Komplain Pesanan Baru</h2>
                <button
                  type="button"
                  onClick={() => setShowCreate(false)}
                  className="p-1 text-stone-400 hover:text-stone-700 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {formError && (
                <div className="mb-4 p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
                  {formError}
                </div>
              )}

              <form onSubmit={handleCreate} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Nomor Pesanan
                    </label>
                    <input
                      type="text"
                      required
                      minLength={FIELD_LIMITS.orderCodeMin}
                      maxLength={FIELD_LIMITS.orderCodeMax}
                      value={orderCode}
                      onChange={(e) => setOrderCode(e.target.value)}
                      placeholder="TT-2026-8891"
                      className="w-full px-3 py-2 text-sm font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Toko</label>
                    <select
                      value={store}
                      onChange={(e) => setStore(e.target.value as StoreName)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                    >
                      {STORE_NAMES.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Nama Pembeli
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={FIELD_LIMITS.customerNameMax}
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Jenis Komplain
                    </label>
                    <select
                      value={complaintType}
                      onChange={(e) => setComplaintType(e.target.value as ComplaintType)}
                      className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                    >
                      {COMPLAINT_TYPES.map((tp) => (
                        <option key={tp} value={tp}>
                          {tp}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Kronologi & Detail Keluhan
                  </label>
                  <textarea
                    rows={3}
                    required
                    maxLength={FIELD_LIMITS.descriptionMax}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Jelaskan detail kekurangan barang, bukti video unboxing, atau kendala pengiriman..."
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    PIC Penanggung Jawab
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.picNameMax}
                    value={picName}
                    onChange={(e) => setPicName(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCreate(false)}
                    className="px-4 py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="px-4 py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 disabled:opacity-60"
                  >
                    {saving ? 'Menyimpan...' : 'Simpan Komplain'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Handling Modal */}
      <AnimatePresence>
        {editingItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 flex items-center justify-center bg-stone-900/40 p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
              className="w-full max-w-md bg-white border border-stone-200 rounded-xl p-6 shadow-xl"
            >
              <div className="flex items-center justify-between pb-3 border-b border-stone-200 mb-4">
                <h2 className="text-base font-bold text-stone-900">
                  Update Komplain {editingItem.orderCode}
                </h2>
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="p-1 text-stone-400 hover:text-stone-700 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveUpdate} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Status Penanganan
                  </label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as ComplaintStatus)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white focus:outline-none focus:border-orange-600"
                  >
                    {COMPLAINT_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    PIC Penanganan
                  </label>
                  <input
                    type="text"
                    maxLength={FIELD_LIMITS.picNameMax}
                    value={editPic}
                    onChange={(e) => setEditPic(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">
                    Catatan Penyelesaian / Tindak Lanjut
                  </label>
                  <textarea
                    rows={3}
                    maxLength={FIELD_LIMITS.resolutionNotesMax}
                    value={editResolution}
                    onChange={(e) => setEditResolution(e.target.value)}
                    placeholder="Contoh: Kirim ulang barang kurang via J&T / Refund disetujui"
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingItem(null)}
                    className="px-4 py-2 text-sm font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-sm font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700"
                  >
                    Simpan Pembaruan
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
