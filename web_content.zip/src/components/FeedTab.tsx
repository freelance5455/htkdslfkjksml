import React, { useEffect, useState } from 'react';
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';
import {
  Bookmark,
  Camera,
  Edit3,
  Flag,
  Heart,
  Image as ImageIcon,
  MessageSquare,
  Mic,
  Plus,
  Send,
  Share2,
  Square,
  Trash2,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { TRANSLATIONS } from '../lib/i18n';
import { compressImageFile, formatRelativeTime } from '../lib/mediaUtils';
import type { LanguageCode, PostComment, PostItem, StatusItem, UserProfile } from '../types';

interface FeedTabProps {
  profile: UserProfile;
  isAdmin: boolean;
  language: LanguageCode;
  onlineUids: string[];
  onAskAiAboutText: (text: string) => void;
}

export const FeedTab: React.FC<FeedTabProps> = ({
  profile,
  isAdmin,
  language,
  onlineUids,
  onAskAiAboutText,
}) => {
  const t = TRANSLATIONS[language];
  const [posts, setPosts] = useState<PostItem[]>([]);
  const [statuses, setStatuses] = useState<StatusItem[]>([]);
  const [likedPostIds, setLikedPostIds] = useState<Set<string>>(new Set());
  const [savedPostIds, setSavedPostIds] = useState<Set<string>>(new Set());
  const [filter, setFilter] = useState<'all' | 'popular' | 'educational' | 'practical' | 'saved'>('all');

  // Composer state
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<'social' | 'educational' | 'practical' | 'announcement'>('educational');
  const [courseTag, setCourseTag] = useState(profile.course || 'General TEVETA');
  const [mediaDataUrl, setMediaDataUrl] = useState<string | null>(null);
  const [publishing, setPublishing] = useState(false);

  // Edit / Comments state
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [openCommentsPostId, setOpenCommentsPostId] = useState<string | null>(null);
  const [comments, setComments] = useState<PostComment[]>([]);
  const [commentText, setCommentText] = useState('');

  // Status modal state
  const [showStatusCreator, setShowStatusCreator] = useState(false);
  const [statusType, setStatusType] = useState<'text' | 'image' | 'audio'>('text');
  const [statusText, setStatusText] = useState('');
  const [statusBg, setStatusBg] = useState('#1D4ED8');
  const [statusMedia, setStatusMedia] = useState<string | null>(null);
  const [recordingAudio, setRecordingAudio] = useState(false);
  const [recorderRef, setRecorderRef] = useState<MediaRecorder | null>(null);
  const [activeStatus, setActiveStatus] = useState<StatusItem | null>(null);
  const [statusReplyText, setStatusReplyText] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const items = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<PostItem, 'id'>) }));
        setPosts(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'posts')
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'statuses'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const now = Date.now();
        const valid = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<StatusItem, 'id'>) }))
          .filter((s) => !s.expiresAt || s.expiresAt.toMillis() > now);
        setStatuses(valid);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'statuses')
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    const loadSaved = async () => {
      try {
        const snap = await getDocs(collection(db, 'savedPosts'));
        const mine = new Set<string>();
        snap.docs.forEach((d) => {
          const data = d.data() as { uid?: string; postId?: string };
          if (data.uid === profile.uid && data.postId) {
            mine.add(data.postId);
          }
        });
        setSavedPostIds(mine);
      } catch {
        // Ignore initial saved check if restricted
      }
    };
    void loadSaved();
  }, [profile.uid]);

  useEffect(() => {
    if (!openCommentsPostId) {
      setComments([]);
      return;
    }
    const q = query(collection(db, 'posts', openCommentsPostId, 'comments'), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        setComments(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<PostComment, 'id'>) })));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `posts/${openCommentsPostId}/comments`)
    );
    return () => unsub();
  }, [openCommentsPostId]);

  const handleImagePick = async (e: React.ChangeEvent<HTMLInputElement>, forStatus = false) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 900, 0.72);
      if (forStatus) {
        setStatusMedia(compressed);
      } else {
        setMediaDataUrl(compressed);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handlePublishPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    setPublishing(true);
    try {
      await addDoc(collection(db, 'posts'), {
        authorId: profile.uid,
        authorName: profile.fullName,
        authorUsername: profile.username,
        authorPhoto: profile.photoUrl || '',
        authorCourse: profile.course || 'TEVETA Learner',
        content: content.trim(),
        mediaUrl: mediaDataUrl || '',
        mediaType: mediaDataUrl ? 'image' : 'none',
        category,
        courseTag: courseTag.trim() || 'General',
        likesCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setContent('');
      setMediaDataUrl(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'posts');
    } finally {
      setPublishing(false);
    }
  };

  const handleToggleLike = async (post: PostItem) => {
    const alreadyLiked = likedPostIds.has(post.id);
    const likeRef = doc(db, 'posts', post.id, 'likes', profile.uid);
    const postRef = doc(db, 'posts', post.id);
    try {
      if (alreadyLiked) {
        await deleteDoc(likeRef);
        await updateDoc(postRef, {
          likesCount: Math.max(0, (post.likesCount || 1) - 1),
          updatedAt: serverTimestamp(),
        });
        setLikedPostIds((prev) => {
          const next = new Set(prev);
          next.delete(post.id);
          return next;
        });
      } else {
        await setDoc(likeRef, {
          uid: profile.uid,
          reaction: 'like',
          createdAt: serverTimestamp(),
        });
        await updateDoc(postRef, {
          likesCount: increment(1),
          updatedAt: serverTimestamp(),
        });
        setLikedPostIds((prev) => new Set(prev).add(post.id));
        if (post.authorId !== profile.uid) {
          await addDoc(collection(db, 'notifications'), {
            recipientUid: post.authorId,
            actorUid: profile.uid,
            type: 'like',
            title: `${profile.fullName} liked your post`,
            body: post.content.slice(0, 120),
            read: false,
            createdAt: serverTimestamp(),
          });
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `posts/${post.id}/likes`);
    }
  };

  const handleToggleSave = async (postId: string) => {
    const saveId = `${profile.uid}__${postId}`;
    const ref = doc(db, 'savedPosts', saveId);
    try {
      if (savedPostIds.has(postId)) {
        await deleteDoc(ref);
        setSavedPostIds((prev) => {
          const next = new Set(prev);
          next.delete(postId);
          return next;
        });
      } else {
        await setDoc(ref, {
          uid: profile.uid,
          postId,
          createdAt: serverTimestamp(),
        });
        setSavedPostIds((prev) => new Set(prev).add(postId));
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `savedPosts/${saveId}`);
    }
  };

  const handleAddComment = async (e: React.FormEvent, post: PostItem) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    try {
      await addDoc(collection(db, 'posts', post.id, 'comments'), {
        postId: post.id,
        authorId: profile.uid,
        authorName: profile.fullName,
        authorPhoto: profile.photoUrl || '',
        text: commentText.trim(),
        createdAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'posts', post.id), {
        commentsCount: increment(1),
        updatedAt: serverTimestamp(),
      });
      if (post.authorId !== profile.uid) {
        await addDoc(collection(db, 'notifications'), {
          recipientUid: post.authorId,
          actorUid: profile.uid,
          type: 'comment',
          title: `${profile.fullName} commented on your post`,
          body: commentText.trim().slice(0, 140),
          read: false,
          createdAt: serverTimestamp(),
        });
      }
      setCommentText('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `posts/${post.id}/comments`);
    }
  };

  const handleSharePost = async (post: PostItem) => {
    try {
      await updateDoc(doc(db, 'posts', post.id), {
        sharesCount: increment(1),
        updatedAt: serverTimestamp(),
      });
      if (navigator.share) {
        await navigator.share({
          title: `${post.authorName} on TEVET POWER APP`,
          text: post.content,
        });
      }
    } catch {
      // Ignore user cancelling native share sheet
    }
  };

  const handleSaveEdit = async (postId: string) => {
    if (!editContent.trim()) return;
    try {
      await updateDoc(doc(db, 'posts', postId), {
        content: editContent.trim(),
        updatedAt: serverTimestamp(),
      });
      setEditingPostId(null);
      setEditContent('');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  const handleDeletePost = async (postId: string) => {
    try {
      await deleteDoc(doc(db, 'posts', postId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `posts/${postId}`);
    }
  };

  const handleReportPost = async (postId: string) => {
    try {
      await addDoc(collection(db, 'reports'), {
        reporterUid: profile.uid,
        targetType: 'post',
        targetId: postId,
        reason: 'Reported from social feed for administrator review',
        status: 'open',
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'reports');
    }
  };

  const toggleAudioRecording = async () => {
    if (recordingAudio && recorderRef) {
      recorderRef.stop();
      setRecordingAudio(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      mr.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };
      mr.onstop = () => {
        stream.getTracks().forEach((tr) => tr.stop());
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => setStatusMedia(String(reader.result));
        reader.readAsDataURL(blob);
      };
      mr.start();
      setRecorderRef(mr);
      setRecordingAudio(true);
    } catch {
      setStatusType('text');
    }
  };

  const handlePublishStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const expiresAt = Timestamp.fromMillis(Date.now() + 24 * 60 * 60 * 1000);
      await addDoc(collection(db, 'statuses'), {
        authorId: profile.uid,
        authorName: profile.fullName,
        authorPhoto: profile.photoUrl || '',
        type: statusType,
        text: statusText.trim(),
        mediaUrl: statusMedia || '',
        bgColor: statusBg,
        privacy: 'public',
        viewersCount: 0,
        expiresAt,
        createdAt: serverTimestamp(),
      });
      setShowStatusCreator(false);
      setStatusText('');
      setStatusMedia(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'statuses');
    }
  };

  const handleOpenStatus = async (st: StatusItem) => {
    setActiveStatus(st);
    if (st.authorId !== profile.uid) {
      try {
        await updateDoc(doc(db, 'statuses', st.id), {
          viewersCount: increment(1),
        });
      } catch {
        // Ignore viewer increment errors
      }
    }
  };

  const handleReplyStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStatus || !statusReplyText.trim()) return;
    try {
      await addDoc(collection(db, 'notifications'), {
        recipientUid: activeStatus.authorId,
        actorUid: profile.uid,
        type: 'message',
        title: `${profile.fullName} replied to your status`,
        body: statusReplyText.trim(),
        read: false,
        createdAt: serverTimestamp(),
      });
      setStatusReplyText('');
      setActiveStatus(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'notifications');
    }
  };

  const filteredPosts = posts.filter((p) => {
    if (profile.blockedUids?.includes(p.authorId)) return false;
    if (filter === 'popular') return (p.likesCount || 0) + (p.commentsCount || 0) >= 1;
    if (filter === 'educational') return p.category === 'educational';
    if (filter === 'practical') return p.category === 'practical';
    if (filter === 'saved') return savedPostIds.has(p.id);
    return true;
  });

  return (
    <div className="space-y-6">
      {/* 24-Hour WhatsApp-Style Status Strip */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-semibold text-sm text-slate-900 dark:text-white">
            {t.feed.statusTitle}
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">Expires after 24h</span>
        </div>
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-1">
          <button
            type="button"
            onClick={() => setShowStatusCreator(true)}
            className="shrink-0 w-20 flex flex-col items-center gap-1.5 group cursor-pointer"
          >
            <div className="w-14 h-14 rounded-full border-2 border-dashed border-blue-600 dark:border-blue-400 bg-blue-50 dark:bg-blue-950/60 flex items-center justify-center text-blue-700 dark:text-blue-400 group-hover:scale-105 transition-transform">
              <Plus className="w-6 h-6" />
            </div>
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate max-w-full">
              {t.feed.addStatus}
            </span>
          </button>

          {statuses.map((st) => (
            <button
              key={st.id}
              type="button"
              onClick={() => handleOpenStatus(st)}
              className="shrink-0 w-20 flex flex-col items-center gap-1.5 cursor-pointer"
            >
              <div className="w-14 h-14 rounded-full p-0.5 border-2 border-emerald-500 overflow-hidden bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                {st.authorPhoto ? (
                  <img
                    src={st.authorPhoto}
                    alt={st.authorName}
                    className="w-full h-full rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <span className="font-display font-bold text-sm text-blue-700 dark:text-blue-300">
                    {st.authorName.slice(0, 2).toUpperCase()}
                  </span>
                )}
              </div>
              <span className="text-xs text-slate-700 dark:text-slate-300 truncate max-w-full">
                {st.authorName.split(' ')[0]}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Facebook-Style Post Composer */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5">
        <form onSubmit={handlePublishPost} className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center font-display font-bold text-sm shrink-0 overflow-hidden">
              {profile.photoUrl ? (
                <img
                  src={profile.photoUrl}
                  alt={profile.fullName}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                profile.fullName.slice(0, 2).toUpperCase()
              )}
            </div>
            <textarea
              rows={3}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={t.feed.composerPlaceholder}
              className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 resize-none"
            />
          </div>

          {mediaDataUrl && (
            <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 max-h-72">
              <img src={mediaDataUrl} alt="Post attachment preview" className="w-full object-cover max-h-72" />
              <button
                type="button"
                onClick={() => setMediaDataUrl(null)}
                className="absolute top-2 right-2 w-8 h-8 rounded-full bg-slate-900/75 text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap items-center gap-2">
              <label className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">
                <ImageIcon className="w-4 h-4 text-emerald-600" />
                <span>Photo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => void handleImagePick(e, false)}
                  className="hidden"
                />
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as typeof category)}
                className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium"
              >
                <option value="educational">Educational</option>
                <option value="practical">Practical Workshop</option>
                <option value="social">Social Update</option>
                {isAdmin && <option value="announcement">Announcement</option>}
              </select>
              <input
                type="text"
                value={courseTag}
                onChange={(e) => setCourseTag(e.target.value)}
                placeholder="Trade tag"
                className="min-h-[40px] w-36 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>

            <button
              type="submit"
              disabled={publishing || !content.trim()}
              className="min-h-[42px] px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{publishing ? 'Posting...' : t.actions.publish}</span>
            </button>
          </div>
        </form>
      </section>

      {/* Feed Filter Bar */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl overflow-x-auto no-scrollbar">
        {(['all', 'popular', 'educational', 'practical', 'saved'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setFilter(tab)}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              filter === tab
                ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {t.feed[tab]}
          </button>
        ))}
      </div>

      {/* Feed Posts */}
      {filteredPosts.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center">
          <p className="text-sm text-slate-500 dark:text-slate-400">{t.feed.noPosts}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPosts.map((post) => {
            const isOnline = onlineUids.includes(post.authorId);
            const isLiked = likedPostIds.has(post.id);
            const isSaved = savedPostIds.has(post.id);
            const canModify = post.authorId === profile.uid || isAdmin;

            return (
              <article
                key={post.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative w-11 h-11 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 flex items-center justify-center font-display font-bold text-sm shrink-0 overflow-hidden">
                      {post.authorPhoto ? (
                        <img
                          src={post.authorPhoto}
                          alt={post.authorName}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        post.authorName.slice(0, 2).toUpperCase()
                      )}
                      {isOnline && (
                        <span
                          title="Online now"
                          className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900"
                        />
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="font-display font-semibold text-sm text-slate-900 dark:text-white truncate">
                        {post.authorName}
                      </p>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                        <span>{post.courseTag || post.authorCourse || 'TEVETA'}</span>
                        <span aria-hidden="true">·</span>
                        <span className="capitalize">{post.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{formatRelativeTime(post.createdAt)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleToggleSave(post.id)}
                      title="Save post"
                      className={`min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 ${
                        isSaved ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'
                      }`}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                    {canModify ? (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingPostId(post.id);
                            setEditContent(post.content);
                          }}
                          title="Edit post"
                          className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeletePost(post.id)}
                          title="Delete post"
                          className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleReportPost(post.id)}
                        title="Report post"
                        className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-400 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                      >
                        <Flag className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Body */}
                {editingPostId === post.id ? (
                  <div className="space-y-2">
                    <textarea
                      rows={3}
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-3 text-sm"
                    />
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => handleSaveEdit(post.id)}
                        className="px-3 py-1.5 rounded-lg bg-blue-700 text-white text-xs font-semibold"
                      >
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingPostId(null)}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                    {post.content}
                  </p>
                )}

                {post.mediaUrl && (
                  <div className="rounded-xl overflow-hidden border border-slate-100 dark:border-slate-800 bg-slate-100 dark:bg-slate-950">
                    <img
                      src={post.mediaUrl}
                      alt="Post media"
                      className="w-full max-h-96 object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}

                {/* Actions */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1 sm:gap-2">
                    <button
                      type="button"
                      onClick={() => handleToggleLike(post)}
                      className={`min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
                        isLiked
                          ? 'text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60'
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                      <span className="tabular-nums">{post.likesCount || 0}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setOpenCommentsPostId(openCommentsPostId === post.id ? null : post.id)
                      }
                      className="min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span className="tabular-nums">{post.commentsCount || 0}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSharePost(post)}
                      className="min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Share2 className="w-4 h-4" />
                      <span className="tabular-nums">{post.sharesCount || 0}</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onAskAiAboutText(post.content)}
                    className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 cursor-pointer"
                  >
                    Ask AI
                  </button>
                </div>

                {/* Comment Drawer */}
                {openCommentsPostId === post.id && (
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
                    {comments.map((c) => (
                      <div key={c.id} className="flex items-start gap-2.5 text-xs">
                        <span className="font-semibold text-slate-900 dark:text-white shrink-0">
                          {c.authorName}:
                        </span>
                        <span className="text-slate-700 dark:text-slate-300 flex-1">{c.text}</span>
                      </div>
                    ))}
                    <form onSubmit={(e) => handleAddComment(e, post)} className="flex gap-2">
                      <input
                        type="text"
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        placeholder="Write a reply..."
                        className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs"
                      />
                      <button
                        type="submit"
                        className="px-3.5 py-2 rounded-xl bg-blue-700 text-white text-xs font-semibold"
                      >
                        Reply
                      </button>
                    </form>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}

      {/* Create Status Modal */}
      {showStatusCreator && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base">Post 24-Hour Status</h3>
              <button type="button" onClick={() => setShowStatusCreator(false)} className="p-2">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              {(['text', 'image', 'audio'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusType(st)}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg capitalize ${
                    statusType === st
                      ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <form onSubmit={handlePublishStatus} className="space-y-3">
              {statusType === 'text' && (
                <>
                  <textarea
                    rows={4}
                    required
                    value={statusText}
                    onChange={(e) => setStatusText(e.target.value)}
                    placeholder="Share a quick study tip or workshop update..."
                    style={{ backgroundColor: statusBg }}
                    className="w-full rounded-xl p-4 text-white placeholder-white/75 text-sm font-medium"
                  />
                  <div className="flex items-center gap-2">
                    {['#1D4ED8', '#059669', '#0F172A', '#0369A1'].map((hex) => (
                      <button
                        key={hex}
                        type="button"
                        onClick={() => setStatusBg(hex)}
                        style={{ backgroundColor: hex }}
                        className={`w-7 h-7 rounded-full ${statusBg === hex ? 'ring-2 ring-offset-2 ring-blue-500' : ''}`}
                      />
                    ))}
                  </div>
                </>
              )}

              {statusType === 'image' && (
                <div className="space-y-2">
                  <label className="flex items-center justify-center gap-2 h-32 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 cursor-pointer text-xs text-slate-500">
                    <Camera className="w-5 h-5" />
                    <span>Select compressed photo</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => void handleImagePick(e, true)}
                      className="hidden"
                    />
                  </label>
                  {statusMedia && <img src={statusMedia} alt="Status" className="max-h-48 w-full object-cover rounded-xl" />}
                  <input
                    type="text"
                    value={statusText}
                    onChange={(e) => setStatusText(e.target.value)}
                    placeholder="Optional caption..."
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
                  />
                </div>
              )}

              {statusType === 'audio' && (
                <div className="space-y-3 text-center py-4">
                  <button
                    type="button"
                    onClick={toggleAudioRecording}
                    className={`mx-auto px-5 py-3 rounded-xl text-white text-xs font-semibold flex items-center gap-2 ${
                      recordingAudio ? 'bg-red-600' : 'bg-blue-700'
                    }`}
                  >
                    {recordingAudio ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    <span>{recordingAudio ? 'Stop Recording' : 'Record Voice Status'}</span>
                  </button>
                  {statusMedia && <audio controls src={statusMedia} className="w-full" />}
                  <input
                    type="text"
                    value={statusText}
                    onChange={(e) => setStatusText(e.target.value)}
                    placeholder="Voice note title..."
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-sm"
                  />
                </div>
              )}

              <button
                type="submit"
                className="w-full min-h-[44px] rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold"
              >
                Publish 24h Status
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Status Viewer Modal */}
      {activeStatus && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 text-white">
            <div className="p-4 flex items-center justify-between border-b border-slate-800">
              <div>
                <p className="font-display font-semibold text-sm">{activeStatus.authorName}</p>
                <p className="text-xs text-slate-400">
                  {formatRelativeTime(activeStatus.createdAt)} · {activeStatus.viewersCount} views
                </p>
              </div>
              <button type="button" onClick={() => setActiveStatus(null)} className="p-2">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div
              className="min-h-[260px] flex flex-col items-center justify-center p-6 text-center"
              style={{ backgroundColor: activeStatus.type === 'text' ? activeStatus.bgColor || '#1D4ED8' : undefined }}
            >
              {activeStatus.type === 'image' && activeStatus.mediaUrl && (
                <img src={activeStatus.mediaUrl} alt="Status" className="max-h-72 rounded-xl object-contain mb-3" />
              )}
              {activeStatus.type === 'audio' && activeStatus.mediaUrl && (
                <audio controls src={activeStatus.mediaUrl} className="w-full mb-3" />
              )}
              {activeStatus.text && <p className="text-base font-medium leading-relaxed">{activeStatus.text}</p>}
            </div>
            <form onSubmit={handleReplyStatus} className="p-3 bg-slate-950 flex gap-2">
              <input
                type="text"
                value={statusReplyText}
                onChange={(e) => setStatusReplyText(e.target.value)}
                placeholder="Reply to status..."
                className="flex-1 rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-600 text-xs font-semibold">
                Reply
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
