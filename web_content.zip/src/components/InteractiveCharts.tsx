import React, { useState, useMemo } from 'react';
import { ClimbEntry, ClimbingStyle, WallAngle, ClimbOutcome } from '../types/climbing';
import { BarChart3, TrendingUp, PieChart, Layers, Calendar, ChevronDown } from 'lucide-react';

export type ChartViewType = 'grades' | 'styles' | 'outcomes' | 'angles' | 'volume';

interface InteractiveChartsProps {
  climbs: ClimbEntry[];
}

export const InteractiveCharts: React.FC<InteractiveChartsProps> = ({ climbs }) => {
  const [chartType, setChartType] = useState<ChartViewType>('grades');
  const [styleFilter, setStyleFilter] = useState<string>('All');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  // Filtered climbs based on style filter
  const filteredClimbs = useMemo(() => {
    if (styleFilter === 'All') return climbs;
    return climbs.filter(c => c.style === styleFilter);
  }, [climbs, styleFilter]);

  // Data for Grade Progression & Distribution
  const gradeData = useMemo(() => {
    const counts: Record<string, { count: number; climbs: ClimbEntry[] }> = {};
    filteredClimbs.forEach(c => {
      if (!counts[c.grade]) {
        counts[c.grade] = { count: 0, climbs: [] };
      }
      counts[c.grade].count++;
      counts[c.grade].climbs.push(c);
    });

    const gradeOrder = [
      'VB', 'V0', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10+',
      '3', '4', '4+', '5a', '5b', '5c', '6a', '6a+', '6b', '6b+', '6c', '6c+', '7a', '7a+', '7b', '7c', '8a+'
    ];

    const entries = Object.keys(counts).sort((a, b) => {
      const idxA = gradeOrder.indexOf(a);
      const idxB = gradeOrder.indexOf(b);
      if (idxA !== -1 && idxB !== -1) return idxA - idxB;
      if (idxA !== -1) return -1;
      if (idxB !== -1) return 1;
      return a.localeCompare(b);
    });

    const maxCount = Math.max(...Object.values(counts).map(v => v.count), 1);

    return entries.map(grade => ({
      label: grade,
      value: counts[grade].count,
      percent: Math.round((counts[grade].count / (filteredClimbs.length || 1)) * 100),
      rawMax: maxCount
    }));
  }, [filteredClimbs]);

  // Data for Styles Breakdown
  const styleData = useMemo(() => {
    const styles: ClimbingStyle[] = ['Top Rope', 'Lead', 'Bouldering', 'Auto-Belay'];
    const counts: Record<ClimbingStyle, number> = {
      'Top Rope': 0,
      'Lead': 0,
      'Bouldering': 0,
      'Auto-Belay': 0
    };
    climbs.forEach(c => {
      if (counts[c.style] !== undefined) counts[c.style]++;
    });
    const total = climbs.length || 1;
    const colors: Record<ClimbingStyle, string> = {
      'Top Rope': '#ea580c', // Orange
      'Lead': '#c2410c', // Deep orange
      'Bouldering': '#f97316', // Bright orange
      'Auto-Belay': '#fb923c' // Light orange
    };

    return styles.map(s => ({
      label: s,
      value: counts[s],
      percent: Math.round((counts[s] / total) * 100),
      color: colors[s]
    }));
  }, [climbs]);

  // Data for Outcome Breakdown
  const outcomeData = useMemo(() => {
    const outcomes: ClimbOutcome[] = ['Onsite', 'Flash', 'Redpoint', 'Attempt'];
    const counts: Record<ClimbOutcome, number> = {
      Onsite: 0,
      Flash: 0,
      Redpoint: 0,
      Attempt: 0
    };
    filteredClimbs.forEach(c => {
      if (counts[c.outcome] !== undefined) counts[c.outcome]++;
    });
    const total = filteredClimbs.length || 1;
    const colors: Record<ClimbOutcome, string> = {
      Onsite: '#16a34a', // Emerald
      Flash: '#ea580c', // Orange
      Redpoint: '#f97316', // Light Orange
      Attempt: '#64748b' // Slate
    };

    return outcomes.map(o => ({
      label: o,
      value: counts[o],
      percent: Math.round((counts[o] / total) * 100),
      color: colors[o]
    }));
  }, [filteredClimbs]);

  // Data for Wall Angle
  const angleData = useMemo(() => {
    const angles: WallAngle[] = ['Slab', 'Vertical', 'Overhang', 'Roof'];
    const counts: Record<WallAngle, number> = {
      Slab: 0,
      Vertical: 0,
      Overhang: 0,
      Roof: 0
    };
    filteredClimbs.forEach(c => {
      if (counts[c.wallAngle] !== undefined) counts[c.wallAngle]++;
    });
    const total = filteredClimbs.length || 1;
    const colors: Record<WallAngle, string> = {
      Slab: '#ea580c',
      Vertical: '#c2410c',
      Overhang: '#f97316',
      Roof: '#9a3412'
    };

    return angles.map(a => ({
      label: a,
      value: counts[a],
      percent: Math.round((counts[a] / total) * 100),
      color: colors[a]
    }));
  }, [filteredClimbs]);

  // Data for Activity Timeline / Volume by Date
  const volumeData = useMemo(() => {
    const dateMap: Record<string, number> = {};
    const sorted = [...climbs].sort((a, b) => a.date.localeCompare(b.date));
    sorted.forEach(c => {
      dateMap[c.date] = (dateMap[c.date] || 0) + 1;
    });

    const dates = Object.keys(dateMap).slice(-8);
    const maxVal = Math.max(...dates.map(d => dateMap[d]), 1);

    return dates.map(d => {
      const parts = d.split('-');
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const short = parts.length === 3 ? `${parseInt(parts[2], 10)} ${monthNames[parseInt(parts[1], 10) - 1]}` : d;
      return {
        label: short,
        fullDate: d,
        value: dateMap[d],
        percent: Math.round((dateMap[d] / maxVal) * 100)
      };
    });
  }, [climbs]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-6 shadow-xs w-full max-w-full overflow-hidden">
      {/* Dropdown & Controls Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-orange-50 border border-orange-100 flex items-center justify-center text-orange-600 shrink-0">
            {chartType === 'grades' && <TrendingUp className="w-4 h-4" />}
            {chartType === 'styles' && <PieChart className="w-4 h-4" />}
            {chartType === 'outcomes' && <BarChart3 className="w-4 h-4" />}
            {chartType === 'angles' && <Layers className="w-4 h-4" />}
            {chartType === 'volume' && <Calendar className="w-4 h-4" />}
          </div>
          <div>
            <span className="text-[10px] font-semibold text-orange-600 uppercase tracking-wider block">Progression Graphs</span>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-tight">
              {chartType === 'grades' && 'Grade Progression'}
              {chartType === 'styles' && 'Climbing Styles'}
              {chartType === 'outcomes' && 'Ascent Outcomes'}
              {chartType === 'angles' && 'Wall Angles'}
              {chartType === 'volume' && 'Session Volume'}
            </h3>
          </div>
        </div>

        {/* Dropdowns */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Primary Chart Selector Dropdown */}
          <div className="relative flex-1 sm:flex-initial">
            <select
              aria-label="Select Graph View"
              value={chartType}
              onChange={e => setChartType(e.target.value as ChartViewType)}
              className="w-full appearance-none bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs sm:text-sm font-medium py-2 pl-3 pr-8 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer transition-colors"
            >
              <option value="grades">Graph: Grade Progression</option>
              <option value="styles">Graph: Climbing Styles</option>
              <option value="outcomes">Graph: Outcomes (Onsite / Flash)</option>
              <option value="angles">Graph: Wall Angles</option>
              <option value="volume">Graph: Session Volume</option>
            </select>
            <ChevronDown className="w-4 h-4 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Style Filter Sub-Dropdown */}
          {chartType !== 'styles' && chartType !== 'volume' && (
            <div className="relative">
              <select
                aria-label="Filter by Style"
                value={styleFilter}
                onChange={e => setStyleFilter(e.target.value)}
                className="appearance-none bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-medium py-2 pl-2.5 pr-7 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer transition-colors"
              >
                <option value="All">All Styles</option>
                <option value="Top Rope">Top Rope</option>
                <option value="Lead">Lead</option>
                <option value="Bouldering">Bouldering</option>
                <option value="Auto-Belay">Auto-Belay</option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          )}
        </div>
      </div>

      {/* Chart Canvas Area */}
      <div className="pt-4 overflow-x-auto">
        {filteredClimbs.length === 0 ? (
          <div className="py-10 text-center text-slate-500 space-y-2">
            <p className="text-sm font-semibold text-slate-700">No ascents logged yet.</p>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Once you log climbs on the "Log Climb" tab, your progress graphs and grade breakdowns will render here automatically.
            </p>
          </div>
        ) : (
          <>
            {/* 1. GRADE PROGRESSION CHART */}
            {chartType === 'grades' && (
              <div className="space-y-4 min-w-[280px]">
                <div className="h-56 w-full flex items-end gap-1.5 sm:gap-2 pt-6 pb-2 px-1 border-b border-slate-200">
                  {gradeData.map((item, idx) => {
                    const heightPercent = Math.max(14, Math.round((item.value / item.rawMax) * 100));
                    const isHovered = hoveredIndex === idx;
                    return (
                      <div
                        key={item.label}
                        className="flex-1 flex flex-col items-center h-full justify-end group relative cursor-pointer"
                        onMouseEnter={() => setHoveredIndex(idx)}
                        onMouseLeave={() => setHoveredIndex(null)}
                      >
                        {isHovered && (
                          <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[11px] px-2 py-1 rounded shadow-md whitespace-nowrap z-20 pointer-events-none">
                            <span className="font-bold">{item.label}</span>: {item.value} ({item.percent}%)
                          </div>
                        )}
                        <span className="text-[10px] sm:text-[11px] font-mono text-slate-500 mb-1 tabular-nums group-hover:text-orange-600 font-semibold">
                          {item.value}
                        </span>
                        <div
                          style={{ height: `${heightPercent}%` }}
                          className={`w-full max-w-[36px] rounded-t-md transition-all duration-200 ${
                            isHovered ? 'bg-orange-600 shadow-xs' : 'bg-orange-500/80 group-hover:bg-orange-600'
                          }`}
                        />
                        <span className="text-[10px] sm:text-xs font-mono font-medium text-slate-700 mt-2 truncate max-w-full text-center">
                          {item.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500 px-1">
                  <span>Ascents by grade</span>
                  <span className="tabular-nums font-mono">Sample: {filteredClimbs.length} climbs</span>
                </div>
              </div>
            )}

            {/* 2. STYLES BREAKDOWN CHART */}
            {chartType === 'styles' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {styleData.map(item => (
                    <div
                      key={item.label}
                      className="p-3 rounded-xl border border-slate-100 bg-slate-50/70"
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-[11px] font-semibold text-slate-600 truncate">{item.label}</span>
                      </div>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-xl font-bold font-mono tabular-nums text-slate-900">{item.value}</span>
                        <span className="text-[10px] font-medium text-slate-500 tabular-nums">({item.percent}%)</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <div className="h-5 w-full rounded-lg overflow-hidden flex bg-slate-100 shadow-inner">
                    {styleData.map(item => (
                      <div
                        key={item.label}
                        title={`${item.label}: ${item.value} (${item.percent}%)`}
                        style={{ width: `${item.percent}%`, backgroundColor: item.color }}
                        className="h-full transition-all hover:opacity-90 cursor-pointer"
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 3. OUTCOMES CHART */}
            {chartType === 'outcomes' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {outcomeData.map(item => (
                    <div
                      key={item.label}
                      className="p-3 rounded-xl border border-slate-100 bg-slate-50/70"
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-[11px] font-semibold text-slate-600">{item.label}</span>
                      </div>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-xl font-bold font-mono tabular-nums text-slate-900">{item.value}</span>
                        <span className="text-[10px] font-medium text-slate-500 tabular-nums">({item.percent}%)</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 bg-slate-50/70 p-3.5 rounded-xl border border-slate-100">
                  {outcomeData.map(item => (
                    <div key={item.label} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-slate-700">{item.label}</span>
                        <span className="font-mono tabular-nums text-slate-500">{item.value} ({item.percent}%)</span>
                      </div>
                      <div className="h-2.5 w-full bg-slate-200 rounded-full overflow-hidden">
                        <div
                          style={{ width: `${item.percent}%`, backgroundColor: item.color }}
                          className="h-full rounded-full transition-all duration-300"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 4. WALL ANGLES CHART */}
            {chartType === 'angles' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {angleData.map(item => (
                    <div
                      key={item.label}
                      className="p-3 rounded-xl border border-slate-100 bg-slate-50/70"
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-[11px] font-semibold text-slate-600">{item.label}</span>
                      </div>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-xl font-bold font-mono tabular-nums text-slate-900">{item.value}</span>
                        <span className="text-[10px] font-medium text-slate-500 tabular-nums">({item.percent}%)</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="h-40 w-full flex items-end gap-3 pt-4 pb-2 px-4 border-b border-slate-200 bg-slate-50/30 rounded-xl">
                  {angleData.map(item => {
                    const maxVal = Math.max(...angleData.map(a => a.value), 1);
                    const h = Math.max(14, Math.round((item.value / maxVal) * 100));
                    return (
                      <div key={item.label} className="flex-1 flex flex-col items-center h-full justify-end">
                        <span className="text-xs font-mono font-bold text-slate-700 mb-1 tabular-nums">{item.value}</span>
                        <div
                          style={{ height: `${h}%`, backgroundColor: item.color }}
                          className="w-full max-w-[50px] rounded-t-lg transition-all"
                        />
                        <span className="text-[11px] font-medium text-slate-700 mt-2 truncate">{item.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 5. VOLUME TIMELINE */}
            {chartType === 'volume' && (
              <div className="space-y-3">
                <div className="h-48 w-full flex items-end gap-2 pt-6 pb-2 px-1 border-b border-slate-200">
                  {volumeData.map((item, idx) => {
                    const isHovered = hoveredIndex === idx;
                    return (
                      <div
                        key={item.fullDate}
                        className="flex-1 flex flex-col items-center h-full justify-end group relative cursor-pointer"
                        onMouseEnter={() => setHoveredIndex(idx)}
                        onMouseLeave={() => setHoveredIndex(null)}
                      >
                        {isHovered && (
                          <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[11px] px-2 py-1 rounded shadow-md whitespace-nowrap z-20">
                            {item.fullDate}: {item.value} climbs
                          </div>
                        )}
                        <span className="text-[10px] sm:text-xs font-mono text-slate-600 mb-1 tabular-nums font-semibold">
                          {item.value}
                        </span>
                        <div
                          style={{ height: `${Math.max(14, item.percent)}%` }}
                          className="w-full max-w-[40px] bg-orange-600 rounded-t-md group-hover:bg-orange-700 transition-colors"
                        />
                        <span className="text-[10px] text-slate-600 mt-2 truncate font-mono text-center">
                          {item.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
