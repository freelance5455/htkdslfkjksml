import React from 'react';
import { X, Timer, Check, Plus, RotateCcw } from 'lucide-react';
import { soundService } from '../utils/sound';

interface TimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  secondsRemaining: number | null;
  onSetTimerMinutes: (mins: number) => void;
  onCancelTimer: () => void;
  isOled: boolean;
}

const PRESETS = [1, 3, 5, 10, 15, 30, 60];

export const TimerModal: React.FC<TimerModalProps> = ({
  isOpen,
  onClose,
  secondsRemaining,
  onSetTimerMinutes,
  onCancelTimer,
  isOled,
}) => {
  if (!isOpen) return null;

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div
        className={`w-full max-w-sm rounded-3xl p-6 border shadow-2xl transition-all ${
          isOled ? 'bg-black border-neutral-800' : 'bg-slate-900 border-slate-800'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <Timer className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-white">Časovač automatického vypnutí</h3>
          </div>
          <button
            onClick={() => {
              soundService.playTick();
              onClose();
            }}
            className="p-1.5 rounded-full text-slate-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Zavřít"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current status / Countdown display */}
        <div
          className={`rounded-2xl p-4 text-center mb-5 border ${
            isOled ? 'bg-neutral-950 border-neutral-900' : 'bg-slate-950 border-slate-800/80'
          }`}
        >
          {secondsRemaining !== null ? (
            <div>
              <span className="text-[10px] text-cyan-400 uppercase font-bold tracking-widest block mb-1">
                Zbývající čas
              </span>
              <span className="text-3xl font-black font-mono text-white tabular-nums">
                {formatTimer(secondsRemaining)}
              </span>
              <div className="mt-3 flex items-center justify-center gap-2">
                <button
                  onClick={() => {
                    soundService.playTick();
                    onCancelTimer();
                  }}
                  className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg bg-red-950/60 border border-red-800/60 text-red-300 hover:bg-red-900/60 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Zrušit časovač</span>
                </button>
              </div>
            </div>
          ) : (
            <div>
              <span className="text-xs text-slate-400">
                Časovač není aktivní. Zvolte dobu, po které svítilna sama zhasne:
              </span>
            </div>
          )}
        </div>

        {/* Presets grid */}
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-4">
          {PRESETS.map((mins) => (
            <button
              key={mins}
              onClick={() => {
                soundService.playTick();
                onSetTimerMinutes(mins);
              }}
              className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                isOled
                  ? 'bg-neutral-950 border-neutral-800 hover:border-cyan-400 text-slate-200'
                  : 'bg-slate-950 border-slate-800 hover:border-cyan-400 text-slate-200'
              }`}
            >
              <span className="text-xs font-bold block">{mins} min</span>
            </button>
          ))}
        </div>

        <button
          onClick={() => {
            soundService.playTick();
            onClose();
          }}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
        >
          Hotovo
        </button>
      </div>
    </div>
  );
};
