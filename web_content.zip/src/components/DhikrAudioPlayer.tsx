import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  Repeat, 
  Gauge, 
  ChevronDown,
  Check,
  User,
  Sparkles,
  X
} from 'lucide-react';
import { DhikrItem, ReciterId } from '../types';
import { recitationEngine, RECITERS_LIST, ReciterInfo } from '../utils/recitationService';
import { useApp } from '../context/AppContext';
import { triggerVibration } from '../utils/audioFeedback';

interface DhikrAudioPlayerProps {
  dhikr: DhikrItem;
  isNightReadingActive?: boolean;
}

export const DhikrAudioPlayer: React.FC<DhikrAudioPlayerProps> = ({ 
  dhikr, 
  isNightReadingActive = false 
}) => {
  const { settings, updateSettings, showToast } = useApp();
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [speed, setSpeed] = useState<number>(0.85); // Tajweed default
  const [repeat, setRepeat] = useState<number>(1);
  const [currentRep, setCurrentRep] = useState<number>(1);
  const [showReciterPicker, setShowReciterPicker] = useState<boolean>(false);

  const progressBarRef = useRef<HTMLDivElement>(null);

  const selectedReciterId: ReciterId = settings.selectedReciter || 'alafasy';
  const currentReciter = RECITERS_LIST.find(r => r.id === selectedReciterId) || RECITERS_LIST[0];

  // Sync engine reciter with user settings
  useEffect(() => {
    recitationEngine.setReciter(selectedReciterId);
  }, [selectedReciterId]);

  // Sync state with engine
  useEffect(() => {
    const update = () => {
      setIsPlaying(recitationEngine.isPlaying());
      setProgress(recitationEngine.getProgress());
      setCurrentTime(recitationEngine.getCurrentTime());
      setDuration(recitationEngine.getDuration());
      const rep = recitationEngine.getRepetition();
      setCurrentRep(rep.current);
    };

    recitationEngine.setOnStateChange(update);
    update();

    return () => {
      // Cleanup listener
    };
  }, []);

  // When dhikr changes, stop previous recitation
  useEffect(() => {
    recitationEngine.stop();
    setIsPlaying(false);
    setProgress(0);
    setCurrentTime(0);
  }, [dhikr.id]);

  const handleTogglePlay = () => {
    triggerVibration(settings.vibration !== false, 'light');
    if (isPlaying) {
      recitationEngine.pause();
      setIsPlaying(false);
      showToast('تم إيقاف الصوت مؤقتاً');
    } else {
      recitationEngine.setReciter(selectedReciterId);
      recitationEngine.setSpeed(speed);
      recitationEngine.setRepeat(repeat);
      recitationEngine.resume(dhikr);
      setIsPlaying(true);
      showToast(`استماع للذكر بصوت ${currentReciter.title} 🎙️`);
    }
  };

  const handleRestart = () => {
    triggerVibration(settings.vibration !== false, 'light');
    recitationEngine.setReciter(selectedReciterId);
    recitationEngine.setSpeed(speed);
    recitationEngine.setRepeat(repeat);
    recitationEngine.playDhikr(dhikr, true);
    setIsPlaying(true);
    showToast('بدء الاستماع من البداية');
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    // RTL calculation: click from right to left
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, (rect.width - clickX) / rect.width));
    recitationEngine.seek(ratio);
    setProgress(ratio);
    triggerVibration(settings.vibration !== false, 'light');
  };

  const handleSpeedCycle = () => {
    triggerVibration(settings.vibration !== false, 'light');
    const speeds = [0.75, 0.85, 1.0, 1.2];
    const curIdx = speeds.indexOf(speed);
    const nextSpeed = speeds[(curIdx + 1) % speeds.length];
    setSpeed(nextSpeed);
    recitationEngine.setSpeed(nextSpeed);
    showToast(`سرعة القراءة: ${nextSpeed === 0.75 ? 'بطيء للتجويد (0.75x)' : nextSpeed + 'x'}`);
  };

  const handleRepeatCycle = () => {
    triggerVibration(settings.vibration !== false, 'light');
    const targetRep = dhikr.count > 1 ? dhikr.count : 3;
    const repeats = [1, targetRep, 3, 7];
    const uniqueRepeats = Array.from(new Set(repeats));
    const curIdx = uniqueRepeats.indexOf(repeat);
    const nextRepeat = uniqueRepeats[(curIdx + 1) % uniqueRepeats.length];
    setRepeat(nextRepeat);
    recitationEngine.setRepeat(nextRepeat);
    showToast(`تكرار الاستماع: ${nextRepeat} مرات للمساعدة في الحفظ`);
  };

  const handleSelectReciter = (reciter: ReciterInfo) => {
    triggerVibration(settings.vibration !== false, 'tap');
    updateSettings({ selectedReciter: reciter.id });
    recitationEngine.setReciter(reciter.id);
    setShowReciterPicker(false);
    showToast(`تم اختيار القارئ: ${reciter.name} 🎙️`);
    if (isPlaying) {
      recitationEngine.playDhikr(dhikr, false);
    }
  };

  const formatTime = (secs: number) => {
    const s = Math.floor(secs || 0);
    const m = Math.floor(s / 60);
    const rem = s % 60;
    return `${m}:${rem < 10 ? '0' : ''}${rem}`;
  };

  return (
    <div className={`w-full my-2.5 p-3 rounded-2xl border transition-all select-none text-right ${
      isNightReadingActive
        ? 'bg-[#140e09] border-amber-800/40 text-amber-200'
        : 'bg-gradient-to-br from-[#03241b] via-[#042d22] to-[#021c15] border-emerald-700/50 shadow-sm'
    }`}>
      {/* 1. Header: Reciter Selector Badge & Live Wave Indicator */}
      <div className="flex items-center justify-between gap-2 mb-2">
        {/* Reciter Picker Trigger Button */}
        <button
          onClick={() => {
            triggerVibration(settings.vibration !== false, 'light');
            setShowReciterPicker(!showReciterPicker);
          }}
          className={`px-2.5 py-1 rounded-xl text-xs font-bold font-cairo flex items-center gap-1.5 border transition-all cursor-pointer ${
            showReciterPicker
              ? isNightReadingActive
                ? 'bg-amber-500/25 border-amber-400 text-amber-100 shadow-xs ring-1 ring-amber-400/40'
                : 'bg-emerald-700/60 border-emerald-400 text-white shadow-xs ring-1 ring-emerald-400/30'
              : isNightReadingActive
                ? 'bg-[#1f150e] border-amber-700/40 text-amber-200 hover:border-amber-500'
                : 'bg-[#063326] border-emerald-600/40 text-emerald-200 hover:border-emerald-500'
          }`}
          title="اضغط لاختيار قارئ الأذكار"
        >
          <User className="w-3.5 h-3.5 text-amber-400" />
          <span>بصوت: <strong className="text-amber-300 font-extrabold">{currentReciter.name}</strong></span>
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showReciterPicker ? 'rotate-180' : ''}`} />
        </button>

        {/* Status / Equalizer */}
        <div className="flex items-center gap-1.5 text-[11px] font-tajawal">
          {isPlaying ? (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-black/30 border border-emerald-600/30">
              <span className="w-1 h-2.5 bg-amber-400 rounded-full animate-bounce" />
              <span className="w-1 h-3.5 bg-amber-300 rounded-full animate-bounce [animation-delay:0.15s]" />
              <span className="w-1 h-2 bg-amber-400 rounded-full animate-bounce [animation-delay:0.3s]" />
              <span className="text-amber-300 font-bold mr-1 font-mono text-[10px]">
                {formatTime(currentTime)}
              </span>
            </div>
          ) : (
            <span className="text-[10px] text-[#84b8a0] font-tajawal hidden sm:inline">
              نطق وتجويد واضح
            </span>
          )}
        </div>
      </div>

      {/* Reciter Selection Drawer (ينفتح بنقرة لاختيار القارئ المفضل) */}
      {showReciterPicker && (
        <div className="my-2.5 p-2 rounded-2xl bg-black/40 border border-emerald-700/50 space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-center justify-between px-1 mb-1">
            <span className="text-[11px] font-bold text-amber-300 font-cairo">
              اختر القارئ المفضل للأذكار:
            </span>
            <button
              onClick={() => setShowReciterPicker(false)}
              className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {RECITERS_LIST.map((reciter) => {
              const isSelected = selectedReciterId === reciter.id;
              return (
                <button
                  key={reciter.id}
                  onClick={() => handleSelectReciter(reciter)}
                  className={`p-2 rounded-xl border text-right transition-all flex items-center justify-between gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-amber-100 ring-1 ring-amber-400/40 shadow-xs'
                      : 'bg-[#042017] border-emerald-800/60 text-[#d4ebe0] hover:bg-[#073023]'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold font-cairo truncate">{reciter.name}</span>
                      <span className="text-[9px] px-1 py-0.2 rounded bg-amber-400/20 text-amber-300 font-mono">
                        {reciter.badge}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#84b8a0] font-tajawal truncate mt-0.5">
                      {reciter.description}
                    </p>
                  </div>

                  {isSelected && (
                    <div className="w-4 h-4 rounded-full bg-amber-400 text-[#0c2e20] flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. Interactive Audio Progress Bar */}
      <div 
        ref={progressBarRef}
        onClick={handleSeek}
        className="w-full h-2 bg-black/50 rounded-full cursor-pointer relative overflow-hidden my-2 border border-white/5 hover:h-2.5 transition-all"
        title="انقر للتقديم أو التأخير في التلاوة"
      >
        <div 
          className={`h-full rounded-full transition-all duration-150 ${
            isNightReadingActive
              ? 'bg-gradient-to-l from-amber-400 to-amber-600'
              : 'bg-gradient-to-l from-amber-300 via-emerald-400 to-emerald-500'
          }`}
          style={{ width: `${Math.round(progress * 100)}%` }}
        />
      </div>

      {/* 3. Controls Bar: Play / Pause / Repeat / Speed */}
      <div className="flex items-center justify-between gap-2 pt-0.5">
        <div className="flex items-center gap-1.5">
          {/* Main Play / Pause Button */}
          <button
            onClick={handleTogglePlay}
            className={`py-1.5 px-3.5 rounded-xl font-bold font-cairo text-xs flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-xs ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-400 text-[#0c2e20]'
                : isNightReadingActive
                  ? 'bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-[#0c2e20]'
                  : 'bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white'
            }`}
            aria-label={isPlaying ? 'إيقاف مؤقت' : 'تشغيل الاستماع للذكر'}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span>إيقاف</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                <span>استمع للذكر</span>
              </>
            )}
          </button>

          {/* Replay From Beginning Button */}
          <button
            onClick={handleRestart}
            className="p-1.5 rounded-xl bg-black/30 hover:bg-black/50 border border-emerald-700/40 text-emerald-300 hover:text-white transition-colors cursor-pointer"
            title="إعادة الاستماع من البداية"
            aria-label="إعادة الاستماع"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Aux Controls: Speed & Repeat */}
        <div className="flex items-center gap-1.5">
          {/* Speed Button */}
          <button
            onClick={handleSpeedCycle}
            className="px-2 py-1 rounded-xl bg-black/30 hover:bg-black/50 border border-emerald-700/40 text-[10px] font-tajawal font-bold text-amber-300 transition-colors cursor-pointer flex items-center gap-1"
            title="تغيير سرعة القراءة"
          >
            <Gauge className="w-3 h-3 text-emerald-400" />
            <span>{speed === 0.85 ? 'تجويد' : `${speed}x`}</span>
          </button>

          {/* Repeat Counter Button */}
          <button
            onClick={handleRepeatCycle}
            className={`px-2 py-1 rounded-xl border text-[10px] font-tajawal font-bold transition-colors cursor-pointer flex items-center gap-1 ${
              repeat > 1
                ? 'bg-amber-500/20 border-amber-400/60 text-amber-300'
                : 'bg-black/30 border-emerald-700/40 text-[#84b8a0] hover:text-white'
            }`}
            title="تكرار الاستماع للمساعدة في حفظ الذكر"
          >
            <Repeat className="w-3 h-3 text-amber-400" />
            <span>{repeat > 1 ? `${currentRep}/${repeat}` : `${repeat}x`}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
