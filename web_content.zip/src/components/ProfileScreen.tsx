import React, { useState, useEffect } from 'react';
import {
  Settings,
  Grid,
  Film,
  Bookmark,
  CheckCircle2,
  Pencil,
  Award,
  Play,
  Heart,
  Calendar,
  Lock,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Post, UserProfile } from '../types';
import { getUserProfile, fetchFeedPosts } from '../services/db';

interface ProfileScreenProps {
  targetUsername?: string;
  onOpenSettings: () => void;
  onOpenCertificate: (certId: string) => void;
  onSelectPost: (post: Post) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  targetUsername,
  onOpenSettings,
  onOpenCertificate,
  onSelectPost,
}) => {
  const { userProfile, updateProfileData, canChangeUsername, daysUntilUsernameChange } = useAuth();
  const [activeTab, setActiveTab] = useState<'posts' | 'videos' | 'saved'>('posts');
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editDisplayName, setEditDisplayName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editPhotoURL, setEditPhotoURL] = useState('');
  const [editError, setEditError] = useState<string | null>(null);

  const isMyProfile = !targetUsername || targetUsername === userProfile?.username;

  useEffect(() => {
    async function loadData() {
      if (isMyProfile && userProfile) {
        setProfile(userProfile);
      } else if (targetUsername) {
        const found = await getUserProfile(targetUsername);
        if (found) setProfile(found);
      }
      const allPosts = await fetchFeedPosts();
      setPosts(allPosts);
    }
    loadData();
  }, [targetUsername, userProfile, isMyProfile]);

  const activeUserProfile = profile || userProfile;

  const handleStartEdit = () => {
    if (!activeUserProfile) return;
    setEditDisplayName(activeUserProfile.displayName);
    setEditUsername(activeUserProfile.username);
    setEditBio(activeUserProfile.bio);
    setEditPhotoURL(activeUserProfile.photoURL);
    setEditError(null);
    setIsEditing(true);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setEditError(null);
    const res = await updateProfileData({
      displayName: editDisplayName,
      username: editUsername,
      bio: editBio,
      photoURL: editPhotoURL,
    });

    if (res.success) {
      setIsEditing(false);
    } else {
      setEditError(res.error || 'Erro ao atualizar perfil.');
    }
  };

  const formatCount = (count?: number) => {
    if (!count) return '0';
    if (count >= 1000000) return (count / 1000000).toFixed(1).replace('.', ',') + 'M';
    if (count >= 1000) return (count / 1000).toFixed(1).replace('.', ',') + 'K';
    return count.toString();
  };

  // Real user posts
  const profilePosts = posts.filter(
    (p) => (activeUserProfile?.id && p.userId === activeUserProfile.id) ||
           (activeUserProfile?.username && p.username === activeUserProfile.username)
  );

  return (
    <div className="w-full max-w-lg mx-auto min-h-screen bg-[#050505] text-white pb-24 md:pb-12 animate-fade-in">
      {/* Top Bar matching reference image Screen 3 */}
      <div className="flex items-center justify-between px-6 py-4 sticky top-0 bg-[#050505]/90 backdrop-blur-md z-30 border-b border-[#19191F]">
        <h2 className="text-lg font-bold">Perfil</h2>
        <button
          onClick={onOpenSettings}
          className="p-2 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F] transition-colors cursor-pointer"
        >
          <Settings size={20} />
        </button>
      </div>

      {/* Header Gradient Banner */}
      <div className="relative h-36 w-full bg-gradient-to-r from-[#FF4038] via-[#FF008C] to-[#9900FF] overflow-hidden">
        <div className="absolute inset-0 bg-black/10" />
      </div>

      {/* Profile Info Section with Centered Avatar overlapping banner */}
      <div className="relative px-6 -mt-16 text-center">
        {/* Avatar with edit pencil badge */}
        <div className="relative inline-block mx-auto">
          <div className="w-28 h-28 rounded-full p-[3px] bg-[#050505] shadow-2xl">
            <img
              src={activeUserProfile?.photoURL || '/icon.svg'}
              alt={activeUserProfile?.displayName}
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          {isMyProfile && (
            <button
              onClick={handleStartEdit}
              className="absolute bottom-1 right-1 w-7 h-7 rounded-full bg-clipshare-gradient flex items-center justify-center text-white border-2 border-[#050505] cursor-pointer shadow-md hover:scale-105 transition-transform"
              title="Editar foto ou perfil"
            >
              <Pencil size={12} strokeWidth={2.5} />
            </button>
          )}
        </div>

        {/* Username & Verified Badge */}
        <div className="flex items-center justify-center gap-1.5 mt-3">
          <h1 className="text-xl font-extrabold text-white">
            @{activeUserProfile?.username || 'joaovibes'}
          </h1>
          {activeUserProfile?.isVerified && (
            <CheckCircle2 size={18} className="fill-[#0095F6] text-black" />
          )}
        </div>

        {/* Bio */}
        <p className="text-xs md:text-sm text-[#A1A1AA] mt-1 font-medium">
          {activeUserProfile?.bio || 'Viva. Crie. Inspire. ✏️'}
        </p>

        {/* Statistics Row: Posts | Seguidores | Seguindo */}
        <div className="flex items-center justify-center gap-8 md:gap-12 mt-5 py-2">
          <div className="text-center">
            <span className="block text-lg font-black text-white">
              {formatCount(activeUserProfile?.postsCount ?? 128)}
            </span>
            <span className="text-xs text-[#A1A1AA]">Posts</span>
          </div>
          <div className="text-center">
            <span className="block text-lg font-black text-white">
              {formatCount(activeUserProfile?.followersCount ?? 24600)}
            </span>
            <span className="text-xs text-[#A1A1AA]">Seguidores</span>
          </div>
          <div className="text-center">
            <span className="block text-lg font-black text-white">
              {formatCount(activeUserProfile?.followingCount ?? 342)}
            </span>
            <span className="text-xs text-[#A1A1AA]">Seguindo</span>
          </div>
        </div>

        {/* Main Action Button: "Editar perfil" with official gradient */}
        {isMyProfile ? (
          <div className="mt-4 space-y-2">
            <button
              onClick={handleStartEdit}
              className="w-full max-w-sm py-3 px-6 rounded-full font-bold text-sm text-white bg-clipshare-gradient glow-clipshare-sm hover:opacity-95 active:scale-98 transition-all cursor-pointer shadow-lg"
            >
              Editar perfil
            </button>
            {/* Special rule note from reference image */}
            <p className="text-[11px] text-[#A1A1AA]">
              Você pode alterar seu nome a cada 14 dias.
            </p>
          </div>
        ) : (
          <button className="mt-4 w-full max-w-sm py-3 px-6 rounded-full font-bold text-sm text-white bg-clipshare-gradient hover:opacity-95 cursor-pointer">
            Seguir
          </button>
        )}

        {/* Influencer Certificate Banner if unlocked */}
        {(activeUserProfile?.hasInfluencerCertificate || (activeUserProfile?.followersCount ?? 0) >= 10) && (
          <div
            onClick={() => onOpenCertificate(activeUserProfile?.certificateId || 'cert-joaovibes-10k')}
            className="mt-5 p-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-purple-500/15 border border-amber-500/30 flex items-center justify-between cursor-pointer hover:border-amber-400/60 transition-all text-left shadow-lg"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-black font-black">
                <Award size={22} />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 block">
                  Conquista Oficial
                </span>
                <span className="text-xs font-bold text-white">
                  Certificado de Influenciador ClipShare
                </span>
              </div>
            </div>
            <span className="text-xs text-amber-300 font-semibold px-2 py-1 rounded-lg bg-amber-500/20">
              Ver
            </span>
          </div>
        )}
      </div>

      {/* 3 Tabs matching reference image:
          Grid icon (Posts) | Reel icon (Vídeos) | Bookmark icon (Salvos) */}
      <div className="flex items-center justify-around border-b border-[#19191F] mt-6">
        <button
          onClick={() => setActiveTab('posts')}
          className={`flex-1 py-3.5 flex justify-center items-center transition-colors relative ${
            activeTab === 'posts' ? 'text-[#FF008C]' : 'text-[#A1A1AA] hover:text-white'
          }`}
        >
          <Grid size={22} />
          {activeTab === 'posts' && (
            <span className="absolute bottom-0 left-1/4 right-1/4 h-[2px] bg-[#FF008C] shadow-[0_0_8px_#FF008C]" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('videos')}
          className={`flex-1 py-3.5 flex justify-center items-center transition-colors relative ${
            activeTab === 'videos' ? 'text-[#FF008C]' : 'text-[#A1A1AA] hover:text-white'
          }`}
        >
          <Film size={22} />
          {activeTab === 'videos' && (
            <span className="absolute bottom-0 left-1/4 right-1/4 h-[2px] bg-[#FF008C] shadow-[0_0_8px_#FF008C]" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('saved')}
          className={`flex-1 py-3.5 flex justify-center items-center transition-colors relative ${
            activeTab === 'saved' ? 'text-[#FF008C]' : 'text-[#A1A1AA] hover:text-white'
          }`}
        >
          <Bookmark size={22} />
          {activeTab === 'saved' && (
            <span className="absolute bottom-0 left-1/4 right-1/4 h-[2px] bg-[#FF008C] shadow-[0_0_8px_#FF008C]" />
          )}
        </button>
      </div>

      {/* 3-Column Publications Grid matching reference image Screen 3 */}
      {profilePosts.length === 0 ? (
        <div className="py-16 px-6 text-center text-[#A1A1AA]">
          <div className="w-16 h-16 rounded-full bg-[#101014] border border-[#19191F] flex items-center justify-center mx-auto mb-3">
            <Film size={28} className="text-[#A1A1AA]" />
          </div>
          <h3 className="text-sm font-bold text-white">Nenhum clipe publicado</h3>
          <p className="text-xs text-[#A1A1AA] mt-1 max-w-xs mx-auto">
            {isMyProfile
              ? 'Compartilhe momentos, danças, rotinas ou gravações com a comunidade.'
              : 'Este criador ainda não publicou nenhum clipe.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-1 p-1">
          {profilePosts.map((post, idx) => (
            <div
              key={post.id + idx}
              onClick={() => onSelectPost(post)}
              className="relative aspect-square bg-[#101014] overflow-hidden group cursor-pointer"
            >
              <img
                src={post.coverUrl || post.mediaUrl}
                alt={post.caption}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              {/* Play icon with view count badge */}
              <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 text-[11px] font-bold text-white drop-shadow-md">
                <Play size={12} className="fill-white" />
                <span>{formatCount(post.viewsCount || 0)}</span>
              </div>
              {/* Top right video marker */}
              <div className="absolute top-1.5 right-1.5 text-white/80 drop-shadow">
                <Film size={12} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="w-full max-w-md bg-[#101014] border border-[#272730] rounded-3xl p-6 text-left shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-4">Editar perfil</h3>

            {editError && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-red-300 text-xs">
                {editError}
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#A1A1AA] mb-1">
                  Foto de perfil (URL)
                </label>
                <input
                  type="url"
                  value={editPhotoURL}
                  onChange={(e) => setEditPhotoURL(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#19191F] border border-[#272730] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[#FF008C]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A1A1AA] mb-1">
                  Nome de exibição
                </label>
                <input
                  type="text"
                  value={editDisplayName}
                  onChange={(e) => setEditDisplayName(e.target.value)}
                  required
                  className="w-full bg-[#19191F] border border-[#272730] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[#FF008C]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-[#A1A1AA]">
                    Nome de usuário (@)
                  </label>
                  {!canChangeUsername && (
                    <span className="text-[10px] text-amber-400 flex items-center gap-1">
                      <Lock size={10} /> Bloqueado por {daysUntilUsernameChange} dia(s)
                    </span>
                  )}
                </div>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-[#A1A1AA] text-xs">@</span>
                  <input
                    type="text"
                    value={editUsername}
                    disabled={!canChangeUsername}
                    onChange={(e) => setEditUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                    className={`w-full bg-[#19191F] border border-[#272730] rounded-xl pl-8 pr-4 py-2.5 text-xs text-white focus:outline-none ${
                      canChangeUsername ? 'focus:border-[#FF008C]' : 'opacity-60 cursor-not-allowed'
                    }`}
                  />
                </div>
                <p className="text-[11px] text-[#A1A1AA] mt-1">
                  Você pode alterar seu nome a cada 14 dias.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A1A1AA] mb-1">Biografia</label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  maxLength={160}
                  rows={3}
                  className="w-full bg-[#19191F] border border-[#272730] rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#FF008C]"
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="flex-1 py-2.5 rounded-full bg-[#19191F] text-xs text-white font-semibold hover:bg-[#272730] cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-full bg-clipshare-gradient text-xs text-white font-bold hover:opacity-95 cursor-pointer shadow-md"
                >
                  Salvar alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
