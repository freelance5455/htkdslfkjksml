import React, { useState } from 'react';
import { CharacterGender, UserProfile } from '../types';
import { ABLogo } from './ABLogo';
import { playClickTone } from '../utils/audioEffects';
import { User, Sparkles, Check, ArrowRight } from 'lucide-react';

interface ProfileScreenProps {
  initialProfile: UserProfile;
  onSave: (profile: UserProfile) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  initialProfile,
  onSave,
}) => {
  const [name, setName] = useState(initialProfile.name || '');
  const [gender, setGender] = useState<CharacterGender>(initialProfile.gender || 'Male');
  const [persona, setPersona] = useState<UserProfile['persona']>(
    initialProfile.persona || 'friend'
  );
  const [error, setError] = useState('');

  const handleGenderSelect = (selected: CharacterGender) => {
    playClickTone();
    setGender(selected);
  };

  const handlePersonaSelect = (p: UserProfile['persona']) => {
    playClickTone();
    setPersona(p);
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('براہ کرم اپنا نام درج کریں! (Please enter your name)');
      return;
    }

    playClickTone();
    const characterName = gender === 'Female' ? 'عائشہ (Ayesha)' : 'حمزہ (Hamza)';
    onSave({
      ...initialProfile,
      name: trimmed,
      gender,
      characterName,
      persona,
    });
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-4 bg-[#081225] text-white">
      {/* Background Glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full bg-[#E2C067]/10 blur-3xl pointer-events-none" />

      <div className="w-full max-w-sm bg-[#111e38] border border-[#1e3258] p-6 rounded-2xl shadow-2xl relative z-10 text-center animate-in fade-in zoom-in-95 duration-300">
        {/* Brand Icon */}
        <div className="flex justify-center -mt-10 mb-3">
          <div className="p-1 rounded-full bg-[#081225] border border-[#2a4365] shadow-lg">
            <ABLogo size={70} glow={false} />
          </div>
        </div>

        <h2 className="text-xl font-bold text-[#E2C067] tracking-wider mb-1">
          پروفائل سیٹ اپ
        </h2>
        <p className="text-xs text-gray-400 mb-5">
          Set Up Your Voice Companion Profile
        </p>

        <form onSubmit={handleSave} className="space-y-4 text-left">
          {/* Name Input */}
          <div>
            <label
              htmlFor="userName"
              className="block text-xs font-semibold text-gray-300 mb-1.5"
            >
              آپ کا نام (Your Name):
            </label>
            <div className="relative">
              <input
                type="text"
                id="userName"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (error) setError('');
                }}
                placeholder="مثال: Ali یا Bilal"
                className="w-full px-4 py-3 bg-[#081225] border border-[#2a4365] rounded-xl text-white text-sm placeholder-gray-500 focus:outline-none focus:border-[#E2C067] transition-colors"
              />
              <User className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {error && (
              <p className="text-xs text-red-400 mt-1 font-medium">{error}</p>
            )}

            {/* Quick Name Suggestions */}
            <div className="flex items-center gap-1.5 mt-2">
              <span className="text-[11px] text-gray-400">فوری تجاویز:</span>
              {['Ali', 'Bilal', 'Sara', 'Zain'].map((s) => (
                <button
                  type="button"
                  key={s}
                  onClick={() => {
                    playClickTone();
                    setName(s);
                    setError('');
                  }}
                  className="px-2 py-0.5 text-[10px] rounded-md bg-[#081225] border border-[#2a4365] text-gray-300 hover:text-[#E2C067] hover:border-[#E2C067] transition-colors cursor-pointer"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Character Gender Selector */}
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1.5">
              AI کا کردار منتخب کریں (Character):
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => handleGenderSelect('Male')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                  gender === 'Male'
                    ? 'bg-gradient-to-br from-[#E2C067] to-[#b89230] text-[#081225] border-[#E2C067] font-bold shadow-[0_0_15px_rgba(226,192,103,0.4)]'
                    : 'bg-[#081225] text-gray-300 border-[#2a4365] hover:border-gray-500'
                }`}
              >
                <span className="text-base font-bold">حمزہ (Hamza)</span>
                <span className="text-xs opacity-90">لڑکا (Boy / Friend)</span>
              </button>

              <button
                type="button"
                onClick={() => handleGenderSelect('Female')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                  gender === 'Female'
                    ? 'bg-gradient-to-br from-[#E2C067] to-[#b89230] text-[#081225] border-[#E2C067] font-bold shadow-[0_0_15px_rgba(226,192,103,0.4)]'
                    : 'bg-[#081225] text-gray-300 border-[#2a4365] hover:border-gray-500'
                }`}
              >
                <span className="text-base font-bold">عائشہ (Ayesha)</span>
                <span className="text-xs opacity-90">لڑکی (Girl / Friend)</span>
              </button>
            </div>
          </div>

          {/* Bot Persona Tone */}
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#E2C067]" />
              <span>بات چیت کا انداز (Persona Style):</span>
            </label>
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              {[
                { id: 'friend', label: 'دوستانہ (Friend)', desc: 'Warm & Natural' },
                { id: 'mentor', label: 'رہبر (Mentor)', desc: 'Wise & Guiding' },
                { id: 'funny', label: 'شوخ (Playful)', desc: 'Witty & Fun' },
                { id: 'formal', label: 'شائستہ (Polite)', desc: 'Respectful' },
              ].map((item) => (
                <button
                  type="button"
                  key={item.id}
                  onClick={() => handlePersonaSelect(item.id as any)}
                  className={`p-2 rounded-lg border text-left flex items-center justify-between transition-all cursor-pointer ${
                    persona === item.id
                      ? 'bg-[#182d56] border-[#E2C067] text-[#E2C067] font-medium'
                      : 'bg-[#081225] border-[#1e3258] text-gray-400 hover:text-gray-200'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-[11px]">{item.label}</div>
                    <div className="text-[9px] text-gray-400">{item.desc}</div>
                  </div>
                  {persona === item.id && <Check className="w-3.5 h-3.5 text-[#E2C067]" />}
                </button>
              ))}
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full mt-4 py-3.5 px-4 bg-gradient-to-r from-[#FFF2B2] via-[#E2C067] to-[#B89230] text-[#081225] font-extrabold rounded-xl shadow-[0_4px_20px_rgba(226,192,103,0.35)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>محفوظ کریں اور جاری رکھیں (Save & Continue)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
