import React from 'react';
import { Sparkles, Trophy } from 'lucide-react';
import { Badge } from '../types/game';
import { sound } from '../utils/sound';

interface BadgeModalProps {
  badge: Badge | null;
  onClose: () => void;
}

export const BadgeModal: React.FC<BadgeModalProps> = ({ badge, onClose }) => {
  if (!badge) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-amber-400/50 p-6 shadow-2xl text-center text-slate-100 animate-in zoom-in-95 duration-200">
        {/* Glow */}
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-28 h-28 rounded-full bg-amber-400/20 blur-xl pointer-events-none" />

        {/* Icon */}
        <div className="relative mx-auto w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-500/20 to-yellow-500/30 border border-amber-400/40 flex items-center justify-center text-5xl shadow-lg shadow-amber-500/20 animate-bounce">
          {badge.icon}
        </div>

        <div className="mt-4 flex items-center justify-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-400">
          <Trophy className="w-4 h-4" />
          <span>New Achievement Unlocked!</span>
          <Sparkles className="w-4 h-4" />
        </div>

        <h3 className="mt-2 text-2xl font-black font-display text-white">{badge.title}</h3>

        <p className="mt-2 text-xs text-slate-300 leading-relaxed px-2">{badge.description}</p>

        {/* Reward pill */}
        <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold">
          <span>+50 Bonus Healthy Gems</span>
          <span>💎</span>
        </div>

        <div className="mt-6">
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-amber-500/30 transition active:scale-95 cursor-pointer"
          >
            Claim & Keep Playing!
          </button>
        </div>
      </div>
    </div>
  );
};
