import React, { useState, useMemo } from 'react';
import { Search, Heart, Eye, Plus, Check, Star, Filter, Upload, Edit3, Trash2, Settings2, Sparkles, RefreshCw, Lock } from 'lucide-react';
import { Product, Category, Room, CurrencyCode } from '../types';
import { formatPrice } from '../utils/currency';

interface ProductGridProps {
  products: Product[];
  activeCurrency: CurrencyCode;
  wishlistIds: string[];
  isOwner: boolean;
  onToggleWishlist: (productId: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  addedProductId: string | null;
  onOpenUploadModal: () => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onClearDemoProducts: () => void;
  onResetDemoProducts: () => void;
  onOpenAuth: () => void;
  hasDemoProducts: boolean;
}

const CATEGORIES: Category[] = [
  'All',
  'Bedding & Linens',
  'Kitchen & Dining',
  'Fragrance & Oud',
  'Bath & Wellness',
  'Living & Storage'
];

const ROOMS: Room[] = [
  'All',
  'Bedroom',
  'Dining Room',
  'Kitchen',
  'Living Room',
  'Bathroom'
];

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  activeCurrency,
  wishlistIds,
  isOwner,
  onToggleWishlist,
  onSelectProduct,
  onAddToCart,
  addedProductId,
  onOpenUploadModal,
  onEditProduct,
  onDeleteProduct,
  onClearDemoProducts,
  onResetDemoProducts,
  onOpenAuth,
  hasDemoProducts
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category>('All');
  const [selectedRoom, setSelectedRoom] = useState<Room>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [isManageMode, setIsManageMode] = useState(false);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return products
      .filter((item) => {
        const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
        const matchesRoom = selectedRoom === 'All' || item.room === selectedRoom;
        const matchesSearch =
          item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (item.arabicSubtitle && item.arabicSubtitle.includes(searchQuery));
        const matchesStock = !inStockOnly || item.inStock;

        return matchesCategory && matchesRoom && matchesSearch && matchesStock;
      })
      .sort((a, b) => {
        if (sortBy === 'price-asc') return a.priceUsd - b.priceUsd;
        if (sortBy === 'price-desc') return b.priceUsd - a.priceUsd;
        if (sortBy === 'rating') return b.rating - a.rating;
        return 0; // featured default
      });
  }, [products, selectedCategory, selectedRoom, searchQuery, inStockOnly, sortBy]);

  return (
    <section id="catalog-section" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-6 border-b border-stone-200">
        <div>
          <span className="text-xs uppercase tracking-[0.2em] text-stone-500 font-medium">
            Artisanal Home Inventory
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif text-stone-900 mt-1">
            The Living Catalog
          </h2>
          <p className="text-stone-600 text-sm mt-1 max-w-xl">
            Thoughtfully curated textures, natural clays, and aromatic accents for every sanctuary.
          </p>
        </div>

        {/* Live Search & Conditional Upload Button */}
        <div className="mt-4 md:mt-0 flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-72">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search items, scents, fabrics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 bg-white border border-stone-300 rounded-lg text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-1 focus:ring-stone-600 focus:border-stone-600 shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          {/* Only Owner can see the Upload Product button */}
          {isOwner && (
            <button
              onClick={onOpenUploadModal}
              className="px-4 py-2.5 bg-[#2D2A26] hover:bg-stone-850 text-white rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-sm shrink-0 whitespace-nowrap"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Product</span>
            </button>
          )}
        </div>
      </div>

      {/* Owner-Only Customization Control Banner */}
      {isOwner && (
        <div className="mb-8 p-4 bg-amber-50/70 rounded-xl border border-amber-200/80 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-stone-900">
            <Sparkles className="w-4 h-4 text-amber-800" />
            <span className="font-semibold">👑 Store Owner Controls (Prince Ukasha):</span>
            <span className="text-stone-600">
              {products.length} {products.length === 1 ? 'item' : 'items'} in your store
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Toggle Manage Mode */}
            <button
              onClick={() => setIsManageMode(!isManageMode)}
              className={`px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5 cursor-pointer transition-all ${
                isManageMode
                  ? 'bg-stone-900 text-white shadow-2xs'
                  : 'bg-white border border-stone-300 text-stone-700 hover:bg-stone-50'
              }`}
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>{isManageMode ? 'Done Managing' : 'Manage / Edit Items'}</span>
            </button>

            {/* Clear Demo Items button if any demo products exist */}
            {hasDemoProducts && (
              <button
                onClick={() => {
                  if (window.confirm('Clear all sample items so the catalog contains ONLY your own uploaded products?')) {
                    onClearDemoProducts();
                  }
                }}
                className="px-3 py-1.5 bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 rounded-lg font-medium flex items-center gap-1.5 cursor-pointer"
                title="Remove default sample products and keep only your own uploads"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                <span>Clear Demo Items (Only My Products)</span>
              </button>
            )}

            {/* Restore demo items if user wants them back */}
            {!hasDemoProducts && (
              <button
                onClick={() => {
                  if (window.confirm('Restore initial sample demo products?')) {
                    onResetDemoProducts();
                  }
                }}
                className="px-3 py-1.5 bg-white border border-stone-300 text-stone-700 hover:bg-stone-50 rounded-lg font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-stone-600" />
                <span>Restore Sample Items</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Filter Controls Bar */}
      <div className="flex flex-col gap-4 mb-10">
        {/* Category Segmented Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider shrink-0 mr-1 hidden sm:inline">
            Category:
          </span>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer shrink-0 ${
                selectedCategory === cat
                  ? 'bg-[#2D2A26] text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200 hover:text-stone-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Room Filter & Sort Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-stone-200/60">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider shrink-0 mr-1 hidden sm:inline">
              Room:
            </span>
            {ROOMS.map((room) => (
              <button
                key={room}
                onClick={() => setSelectedRoom(room)}
                className={`px-3 py-1 text-xs rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  selectedRoom === room
                    ? 'bg-stone-800 text-white font-medium'
                    : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-50'
                }`}
              >
                {room}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4 text-xs ml-auto">
            {/* In stock toggle */}
            <label className="flex items-center gap-2 text-stone-700 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="rounded border-stone-300 text-stone-800 focus:ring-0 cursor-pointer"
              />
              <span>In Stock Only</span>
            </label>

            {/* Sort Select */}
            <div className="flex items-center gap-1.5 bg-white border border-stone-200 rounded-md px-2.5 py-1">
              <Filter className="w-3.5 h-3.5 text-stone-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-stone-700 font-medium cursor-pointer outline-none text-xs"
              >
                <option value="featured">Featured Collection</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Product Items Count */}
      <div className="flex items-center justify-between text-xs text-stone-500 mb-6">
        <span>Showing {filteredProducts.length} of {products.length} home essentials</span>
        {(selectedCategory !== 'All' || selectedRoom !== 'All' || searchQuery) && (
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSelectedRoom('All');
              setSearchQuery('');
            }}
            className="text-stone-700 hover:text-stone-950 underline cursor-pointer"
          >
            Reset Filters
          </button>
        )}
      </div>

      {/* Product Cards Grid */}
      {filteredProducts.length === 0 ? (
        <div className="py-20 text-center bg-white rounded-2xl border-2 border-dashed border-stone-300 p-8 max-w-xl mx-auto flex flex-col items-center">
          <div className="w-14 h-14 rounded-full bg-stone-100 text-stone-700 flex items-center justify-center mb-3">
            {isOwner ? <Upload className="w-6 h-6" /> : <Lock className="w-6 h-6" />}
          </div>
          <p className="font-serif text-2xl text-stone-900 mb-2">No products in this view</p>
          <p className="text-xs text-stone-500 max-w-sm mx-auto mb-6">
            {isOwner
              ? 'Upload your own choice products with photos right from your device.'
              : 'Our master craftsmen are curating new arrivals. Please check back soon or adjust search filters.'}
          </p>
          <div className="flex items-center gap-3">
            {isOwner ? (
              <button
                onClick={onOpenUploadModal}
                className="px-5 py-2.5 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Upload Product Now</span>
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-semibold hover:bg-stone-800 cursor-pointer"
              >
                Store Owner Sign In
              </button>
            )}
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSelectedRoom('All');
                setSearchQuery('');
                setInStockOnly(false);
              }}
              className="px-4 py-2 bg-stone-100 text-stone-700 hover:bg-stone-200 rounded-lg text-xs font-medium cursor-pointer"
            >
              Clear Filters
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
          {/* Card 0: Upload Your Product Card (ONLY visible to the store OWNER) */}
          {isOwner && (
            <div
              onClick={onOpenUploadModal}
              className="group flex flex-col bg-stone-50/70 hover:bg-white rounded-xl border-2 border-dashed border-stone-300 hover:border-stone-800 overflow-hidden transition-all duration-300 cursor-pointer p-6 items-center justify-center text-center min-h-[360px]"
            >
              <div className="w-14 h-14 rounded-2xl bg-amber-100/80 group-hover:bg-amber-200 text-stone-900 flex items-center justify-center mb-4 transition-all group-hover:scale-110 shadow-2xs">
                <Upload className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-stone-900 mb-1">
                Upload Your Choice Product
              </h3>
              <p className="text-xs text-stone-500 max-w-[200px] mb-4">
                Add photos from your computer or phone, set prices, and customize specs.
              </p>
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-stone-900 text-white group-hover:bg-stone-800 rounded-lg text-xs font-medium transition-colors shadow-2xs">
                <Plus className="w-3.5 h-3.5" />
                <span>Add New Item</span>
              </span>
            </div>
          )}

          {filteredProducts.map((product) => {
            const isWishlisted = wishlistIds.includes(product.id);
            const isJustAdded = addedProductId === product.id;

            return (
              <div
                key={product.id}
                className="group flex flex-col bg-white rounded-xl border border-stone-200/80 hover:border-stone-300 overflow-hidden transition-all duration-300 hover:shadow-md relative"
              >
                {/* Management Toolbar Overlay when in Manage Mode (Owner only) */}
                {isOwner && isManageMode && (
                  <div className="absolute top-2 left-2 z-20 flex items-center gap-1.5 bg-white/95 backdrop-blur-xs p-1 rounded-lg border border-stone-200 shadow-md">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditProduct(product);
                      }}
                      className="p-1.5 text-stone-700 hover:text-stone-950 hover:bg-stone-100 rounded cursor-pointer"
                      title="Edit Product"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm(`Delete "${product.name}" from your store?`)) {
                          onDeleteProduct(product.id);
                        }
                      }}
                      className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded cursor-pointer"
                      title="Delete Product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Product Image Frame */}
                <div 
                  className="relative aspect-[4/3] bg-stone-100 overflow-hidden cursor-pointer" 
                  onClick={() => onSelectProduct(product)}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  
                  {/* Subtle badge if present (unboxed text badge) */}
                  {product.badge && (
                    <div className="absolute top-3 left-3 bg-[#FAF8F5]/90 backdrop-blur-xs text-stone-900 text-[11px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded shadow-2xs border border-stone-200/60">
                      {product.badge}
                    </div>
                  )}

                  {/* Wishlist Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleWishlist(product.id);
                    }}
                    className={`absolute top-3 right-3 p-2 rounded-full transition-all cursor-pointer ${
                      isWishlisted
                        ? 'bg-rose-50 text-rose-600 shadow-sm'
                        : 'bg-white/85 text-stone-600 hover:text-stone-900 hover:bg-white shadow-2xs'
                    }`}
                    title={isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
                    aria-label="Wishlist toggle"
                  >
                    <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>

                  {/* Quick View Button overlay on hover */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectProduct(product);
                    }}
                    className="absolute inset-x-4 bottom-3 py-2 bg-stone-900/85 hover:bg-stone-950 text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs cursor-pointer shadow-sm"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Quick View Details</span>
                  </button>
                </div>

                {/* Card Content & Metadata */}
                <div className="p-4 flex flex-col flex-1 justify-between">
                  <div>
                    {/* Category & Room Metadata */}
                    <div className="flex items-center gap-2 text-[11px] text-stone-500 uppercase tracking-wider mb-1 font-medium">
                      <span>{product.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{product.room}</span>
                    </div>

                    {/* Product Name */}
                    <h3 
                      onClick={() => onSelectProduct(product)}
                      className="text-stone-900 font-semibold text-base leading-snug hover:text-stone-700 cursor-pointer transition-colors line-clamp-1"
                    >
                      {product.name}
                    </h3>

                    {/* Arabic Subtitle */}
                    {product.arabicSubtitle && (
                      <p className="text-[12px] text-stone-600 font-serif line-clamp-1 mt-0.5">
                        {product.arabicSubtitle}
                      </p>
                    )}

                    {/* Rating & Reviews */}
                    <div className="flex items-center gap-1.5 mt-2 text-xs text-stone-500">
                      <div className="flex items-center text-amber-500">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span className="ml-1 font-medium text-stone-800">{product.rating}</span>
                      </div>
                      <span aria-hidden="true">·</span>
                      <span>({product.reviewsCount} reviews)</span>
                    </div>
                  </div>

                  {/* Card Bottom: Price & Add to Bag */}
                  <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
                    <div className="flex flex-col">
                      <div className="flex items-baseline gap-1.5">
                        <span className="font-semibold text-stone-900 text-base tabular-nums">
                          {formatPrice(product.priceUsd, activeCurrency)}
                        </span>
                        {product.originalPriceUsd && (
                          <span className="text-xs text-stone-500 line-through tabular-nums">
                            {formatPrice(product.originalPriceUsd, activeCurrency)}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-emerald-800 font-medium">
                        {product.stockCount} in stock
                      </span>
                    </div>

                    {/* Add to Bag Button */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onAddToCart(product)}
                        disabled={!product.inStock}
                        className={`px-3 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                          isJustAdded
                            ? 'bg-emerald-700 text-white'
                            : product.inStock
                            ? 'bg-stone-900 hover:bg-stone-800 text-white shadow-2xs'
                            : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                        }`}
                      >
                        {isJustAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add to Bag</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
