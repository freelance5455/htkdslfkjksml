"use client";

import React, { useState } from "react";
import {
  Users,
  Copy,
  ShieldCheck,
  TrendingUp,
  Award,
  Sliders,
  CheckCircle2,
} from "lucide-react";

export interface MasterTraderProfile {
  traderId: string;
  nameHe: string;
  badgeHe: string;
  strategyTypeHe: string;
  winRatePct: number;
  roi7dPct: number;
  roi30dPct: number;
  maxDrawdownPct: number;
  profitFactor: number;
  riskScore: number; // 1 - 10
  followersCount: number;
  aumUsdtMillions: number;
  primarySymbol: string;
  activeTradeSide: "LONG" | "SHORT";
  descriptionHe: string;
}

export const MASTER_TRADERS_LIST: MasterTraderProfile[] = [
  {
    traderId: "TRADER_ALPHA_AI",
    nameHe: "אלפא קוואנט AI (AlphaQuant)",
    badgeHe: "אלגוריתם מוסדי #1",
    strategyTypeHe: "קונפלואנס רב-שכבתי + Volume Profile POC",
    winRatePct: 84.2,
    roi7dPct: 18.6,
    roi30dPct: 64.8,
    maxDrawdownPct: 4.8,
    profitFactor: 3.15,
    riskScore: 3,
    followersCount: 4820,
    aumUsdtMillions: 18.4,
    primarySymbol: "BTCUSDT",
    activeTradeSide: "LONG",
    descriptionHe:
      "מנוע AI כמותי הסורק חריגות נזילות ב-Bybit Linear ומשלב Kelly Criterion לניהול בטחונות קפדני.",
  },
  {
    traderId: "TRADER_DANIEL_PRO",
    nameHe: "דניאל כהן - סווינג מוסדי",
    badgeHe: "סוחר מאומת (Master)",
    strategyTypeHe: "פריצות מבנה שוק + EMA 20/50/200",
    winRatePct: 79.5,
    roi7dPct: 14.2,
    roi30dPct: 49.3,
    maxDrawdownPct: 6.4,
    profitFactor: 2.68,
    riskScore: 4,
    followersCount: 2910,
    aumUsdtMillions: 9.2,
    primarySymbol: "ETHUSDT",
    activeTradeSide: "LONG",
    descriptionHe:
      "מתמחה בעסקאות סווינג על ביטקוין, את'ריום וסולאנה עם יחס סיכוי/סיכון מינימלי של 1:2.5.",
  },
  {
    traderId: "TRADER_DELTA_NEUTRAL",
    nameHe: "דלתא ניטרל - ארביטראז' ומימון",
    badgeHe: "סיכון נמוך במיוחד",
    strategyTypeHe: "גידור שיעורי מימון (Funding Rate) ומומנטום קצר",
    winRatePct: 91.0,
    roi7dPct: 7.4,
    roi30dPct: 28.9,
    maxDrawdownPct: 2.1,
    profitFactor: 4.12,
    riskScore: 2,
    followersCount: 3640,
    aumUsdtMillions: 24.1,
    primarySymbol: "SOLUSDT",
    activeTradeSide: "LONG",
    descriptionHe:
      "אסטרטגיה סולידית המנצלת פערי מימון וחוסר איזון בספר הפקודות עם Drawdown מזערי.",
  },
  {
    traderId: "TRADER_MOMENTUM_SHARK",
    nameHe: "כריש המומנטום (High-Beta AI)",
    badgeHe: "תשואה אגרסיבית",
    strategyTypeHe: "פריצות נפח באלטקוינס (SOL, SUI, RENDER)",
    winRatePct: 73.8,
    roi7dPct: 29.4,
    roi30dPct: 98.2,
    maxDrawdownPct: 11.9,
    profitFactor: 2.34,
    riskScore: 7,
    followersCount: 1890,
    aumUsdtMillions: 6.5,
    primarySymbol: "SUIUSDT",
    activeTradeSide: "LONG",
    descriptionHe:
      "מזהה זרימת הון מוקדמת לסקטור ה-AI ו-Layer 1 מהירים לפני תנועות אימפולס חדות.",
  },
];

interface CopyTradingModuleProps {
  copiedSubscriptions: Array<{
    traderId: string;
    allocatedBudgetUsdt: number;
    stopLossPct: number;
    maxLeverage: number;
    isActive: boolean;
    totalCopiedTrades: number;
    copiedPnlUsdt: number;
  }>;
  livePricesMap: Record<string, number>;
  onToggleCopyTrader: (payload: {
    traderId: string;
    traderName: string;
    allocatedBudgetUsdt: number;
    stopLossPct: number;
    maxLeverage: number;
    mirrorSymbol: string;
    mirrorPrice: number;
  }) => Promise<void>;
}

export function CopyTradingModule({
  copiedSubscriptions,
  livePricesMap,
  onToggleCopyTrader,
}: CopyTradingModuleProps) {
  const [budgets, setBudgets] = useState<Record<string, number>>({
    TRADER_ALPHA_AI: 1500,
    TRADER_DANIEL_PRO: 1000,
    TRADER_DELTA_NEUTRAL: 1200,
    TRADER_MOMENTUM_SHARK: 800,
  });
  const [stopLosses, setStopLosses] = useState<Record<string, number>>({
    TRADER_ALPHA_AI: 10,
    TRADER_DANIEL_PRO: 12,
    TRADER_DELTA_NEUTRAL: 6,
    TRADER_MOMENTUM_SHARK: 15,
  });
  const [leverages, setLeverages] = useState<Record<string, number>>({
    TRADER_ALPHA_AI: 4,
    TRADER_DANIEL_PRO: 3,
    TRADER_DELTA_NEUTRAL: 2,
    TRADER_MOMENTUM_SHARK: 5,
  });
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const safeSubs = Array.isArray(copiedSubscriptions) ? copiedSubscriptions : [];

  return (
    <div dir="rtl" className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-xl border border-[#222B3A] bg-gradient-to-l from-[#11161F] via-[#181F2C] to-[#11161F] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Users className="h-6 w-6 text-[#00E676]" />
              <h2 className="text-xl font-bold text-[#F1F5F9]">
                לוח מובילי Copy Trading ושכפול עסקאות אוטומטי
              </h2>
            </div>
            <p className="mt-1 text-sm text-[#94A3B8]">
              בחר סוחר מוביל או אלגוריתם AI, הגדר תקציב בטחונות, תקרת מינוף ו-Stop-Loss,
              ולחץ על{" "}
              <strong className="text-[#00E676]">&quot;עקוב ושכפל&quot;</strong>{" "}
              לביצוע אוטומטי בחשבון הדמו שלך.
            </p>
          </div>
          <div className="flex items-center gap-4 rounded-lg border border-[#222B3A] bg-[#0B0E14] px-4 py-2.5">
            <div>
              <span className="block text-xs text-[#64748B]">אסטרטגיות פעילות</span>
              <span className="font-mono text-lg font-extrabold text-[#00E676]">
                {safeSubs.filter((s) => s.isActive).length} / 4
              </span>
            </div>
            <div className="h-8 w-px bg-[#222B3A]" />
            <div>
              <span className="block text-xs text-[#64748B]">רווח מצטבר משכפול</span>
              <span className="font-mono text-lg font-extrabold text-[#00E676]">
                +$
                {safeSubs
                  .reduce((acc, s) => acc + (s.copiedPnlUsdt || 0), 0)
                  .toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Leaderboard Cards Grid */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        {MASTER_TRADERS_LIST.map((trader) => {
          const sub = safeSubs.find((s) => s.traderId === trader.traderId);
          const isCopying = Boolean(sub?.isActive);
          const currentBudget =
            budgets[trader.traderId] ?? sub?.allocatedBudgetUsdt ?? 1000;
          const currentSl =
            stopLosses[trader.traderId] ?? sub?.stopLossPct ?? 10;
          const currentLev =
            leverages[trader.traderId] ?? sub?.maxLeverage ?? 3;

          return (
            <div
              key={trader.traderId}
              className={`rounded-xl border p-5 transition ${
                isCopying
                  ? "border-[#00E676]/60 bg-[#11161F] shadow-[0_0_24px_rgba(0,230,118,0.08)]"
                  : "border-[#222B3A] bg-[#11161F]"
              }`}
            >
              {/* Top Row */}
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-[#F59E0B]" />
                    <h3 className="text-lg font-bold text-[#F1F5F9]">
                      {trader.nameHe}
                    </h3>
                    <span className="rounded-full bg-[#3B82F6]/15 px-2.5 py-0.5 text-xs font-semibold text-[#3B82F6]">
                      {trader.badgeHe}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-[#94A3B8]">
                    {trader.strategyTypeHe}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`rounded-lg px-2.5 py-1 font-mono text-xs font-bold ${
                      trader.riskScore <= 3
                        ? "bg-[#00E676]/15 text-[#00E676]"
                        : trader.riskScore <= 5
                        ? "bg-[#F59E0B]/15 text-[#F59E0B]"
                        : "bg-[#FF3B69]/15 text-[#FF3B69]"
                    }`}
                  >
                    ציון סיכון: {trader.riskScore}/10
                  </span>
                </div>
              </div>

              <p className="mt-3 text-xs leading-relaxed text-[#94A3B8]">
                {trader.descriptionHe}
              </p>

              {/* Performance Metrics Strip */}
              <div className="mt-4 grid grid-cols-2 gap-2.5 rounded-lg bg-[#0B0E14] p-3 sm:grid-cols-5">
                <div>
                  <span className="block text-[11px] text-[#64748B]">
                    אחוז הצלחה (Win Rate)
                  </span>
                  <span className="font-mono text-base font-extrabold text-[#00E676]">
                    {trader.winRatePct}%
                  </span>
                </div>
                <div>
                  <span className="block text-[11px] text-[#64748B]">
                    תשואת 30 יום (ROI)
                  </span>
                  <span className="font-mono text-base font-extrabold text-[#00E676]">
                    +{trader.roi30dPct}%
                  </span>
                </div>
                <div>
                  <span className="block text-[11px] text-[#64748B]">
                    תשואת 7 ימים
                  </span>
                  <span className="font-mono text-base font-bold text-[#00E676]">
                    +{trader.roi7dPct}%
                  </span>
                </div>
                <div>
                  <span className="block text-[11px] text-[#64748B]">
                    נסיגה מקסימלית (DD)
                  </span>
                  <span className="font-mono text-base font-bold text-[#F59E0B]">
                    {trader.maxDrawdownPct}%
                  </span>
                </div>
                <div>
                  <span className="block text-[11px] text-[#64748B]">
                    מכפיל רווח (PF)
                  </span>
                  <span className="font-mono text-base font-bold text-[#F1F5F9]">
                    {trader.profitFactor}x
                  </span>
                </div>
              </div>

              {/* Risk Controls Form */}
              <div className="mt-4 rounded-lg border border-[#222B3A] bg-[#181F2C]/60 p-3.5">
                <div className="mb-2.5 flex items-center gap-1.5 text-xs font-bold text-[#F1F5F9]">
                  <Sliders className="h-3.5 w-3.5 text-[#3B82F6]" />
                  הגדרות בקרת סיכונים ושכפול לדמו:
                </div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <div>
                    <label className="mb-1 block text-[11px] text-[#94A3B8]">
                      תקציב מוקצה ($ USDT)
                    </label>
                    <input
                      type="number"
                      min={100}
                      max={8000}
                      step={100}
                      value={currentBudget}
                      onChange={(e) =>
                        setBudgets((prev) => ({
                          ...prev,
                          [trader.traderId]: Number(e.target.value),
                        }))
                      }
                      className="w-full rounded border border-[#222B3A] bg-[#0B0E14] px-2.5 py-1.5 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] text-[#94A3B8]">
                      קטיעת הפסד (Copy SL %)
                    </label>
                    <input
                      type="number"
                      min={3}
                      max={35}
                      value={currentSl}
                      onChange={(e) =>
                        setStopLosses((prev) => ({
                          ...prev,
                          [trader.traderId]: Number(e.target.value),
                        }))
                      }
                      className="w-full rounded border border-[#222B3A] bg-[#0B0E14] px-2.5 py-1.5 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] text-[#94A3B8]">
                      תקרת מינוף מרבית
                    </label>
                    <select
                      value={currentLev}
                      onChange={(e) =>
                        setLeverages((prev) => ({
                          ...prev,
                          [trader.traderId]: Number(e.target.value),
                        }))
                      }
                      className="w-full rounded border border-[#222B3A] bg-[#0B0E14] px-2.5 py-1.5 font-mono text-xs text-[#F1F5F9] focus:border-[#3B82F6] focus:outline-none"
                    >
                      {[2, 3, 4, 5, 10].map((lev) => (
                        <option key={lev} value={lev}>
                          עד {lev}x
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Action Footer */}
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3 text-xs text-[#94A3B8]">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="h-4 w-4 text-[#00E676]" />
                    {trader.followersCount.toLocaleString()} משכפלים
                  </span>
                  <span>•</span>
                  <span>
                    נכס מוביל:{" "}
                    <strong className="font-mono text-[#F1F5F9]">
                      {trader.primarySymbol}
                    </strong>
                  </span>
                </div>

                <button
                  type="button"
                  disabled={loadingId === trader.traderId}
                  onClick={async () => {
                    setLoadingId(trader.traderId);
                    await onToggleCopyTrader({
                      traderId: trader.traderId,
                      traderName: trader.nameHe,
                      allocatedBudgetUsdt: currentBudget,
                      stopLossPct: currentSl,
                      maxLeverage: currentLev,
                      mirrorSymbol: trader.primarySymbol,
                      mirrorPrice:
                        livePricesMap[trader.primarySymbol] || 94280,
                    });
                    setLoadingId(null);
                  }}
                  className={`inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-xs font-bold transition ${
                    isCopying
                      ? "border border-[#00E676] bg-[#00E676]/15 text-[#00E676] hover:bg-[#00E676]/25"
                      : "bg-[#00E676] text-[#0B0E14] hover:brightness-110"
                  }`}
                >
                  {isCopying ? (
                    <>
                      <CheckCircle2 className="h-4 w-4" />
                      <span>משכפל פעיל (לחץ להשהיה)</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      <span>עקוב ושכפל (One-Click Copy)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
