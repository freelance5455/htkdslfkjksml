/**
 * GODEX v0.0.1 - Read-Only Source Code Viewer
 * Inspects real project workspace files without manual editing capabilities.
 */

import React, { useState } from 'react';
import { FileCode, Copy, Check, ShieldCheck, FileText, X } from 'lucide-react';

interface ReadOnlySourceViewerProps {
  activeFile: string;
  files: Record<string, string>;
  onClose?: () => void;
}

export const ReadOnlySourceViewer: React.FC<ReadOnlySourceViewerProps> = ({
  activeFile,
  files,
  onClose
}) => {
  const currentContent = files[activeFile] !== undefined ? files[activeFile] : '// File empty or loading...';
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const lines = currentContent.split('\n');
  const getLanguage = (path: string) => {
    if (path.endsWith('.tsx') || path.endsWith('.ts')) return 'TypeScript / React';
    if (path.endsWith('.json')) return 'JSON';
    if (path.endsWith('.css')) return 'Tailwind CSS';
    if (path.endsWith('.py')) return 'Python';
    if (path.endsWith('.md')) return 'Markdown';
    return 'Text';
  };

  return (
    <div className="flex-1 h-full flex flex-col bg-[#090B10] border-r border-[#1C2230] overflow-hidden select-text">
      {/* File Inspector Header */}
      <div className="h-9 border-b border-[#1C2230] bg-[#0D1017] px-3 flex items-center justify-between shrink-0 select-none">
        <div className="flex items-center gap-2 overflow-hidden">
          <div className="flex items-center gap-2 px-3 py-1 bg-[#090B10] rounded-t border-t-2 border-cyan-400 text-xs font-mono text-cyan-300 font-semibold border-x border-[#1C2230]">
            <FileCode className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate max-w-[160px] sm:max-w-[220px]">{activeFile}</span>
          </div>
          <div className="hidden sm:flex items-center gap-1 px-2 py-0.5 rounded bg-[#131926] border border-[#222E46] text-[10px] font-mono text-neutral-400">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>WORKSPACE FILE</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs font-mono">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#131926] hover:bg-[#1C2538] border border-[#222E46] text-neutral-300 text-[10px] font-medium transition-colors"
            title="Copy file contents"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'COPIED' : 'COPY'}</span>
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1 rounded bg-[#131926] hover:bg-rose-950/60 border border-[#222E46] hover:border-rose-800 text-neutral-400 hover:text-rose-300 transition-colors"
              title="Close File Viewer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Code Inspection Stream */}
      <div className="flex-1 flex overflow-hidden relative font-mono text-xs leading-relaxed bg-[#08090D]">
        {/* Line Numbers Gutter */}
        <div className="w-12 py-3 bg-[#06070A] border-r border-[#161B26] select-none text-right pr-2.5 text-neutral-600 font-mono text-[11px] overflow-hidden shrink-0">
          {lines.map((_, i) => (
            <div key={i} className="h-5 leading-5">{i + 1}</div>
          ))}
        </div>

        {/* Read-Only Preformatted Code */}
        <div className="flex-1 overflow-auto p-3">
          <pre className="text-neutral-200 font-mono text-xs leading-5 whitespace-pre font-normal selection:bg-cyan-900 selection:text-white">
            {currentContent}
          </pre>
        </div>
      </div>

      {/* Status Bar */}
      <div className="h-5 bg-[#0D1017] border-t border-[#1C2230] px-3 flex items-center justify-between text-[10px] font-mono text-neutral-400 select-none shrink-0">
        <div className="flex items-center gap-3">
          <span>{lines.length} lines</span>
          <span>{currentContent.length} chars</span>
          <span className="text-cyan-400">{getLanguage(activeFile)}</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Managed by Codex Autonomous Agent</span>
        </div>
      </div>
    </div>
  );
};
