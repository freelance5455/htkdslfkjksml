import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Camera, Check, RefreshCw, Upload, X } from 'lucide-react';
import { LangMode } from '../data/types';

interface SiteCameraModalProps {
  taskTitle: string;
  lang: LangMode;
  onSavePhoto: (dataUrl: string) => void;
  onClose: () => void;
}

function resizeImageToJpeg(source: HTMLVideoElement | HTMLImageElement, width: number, height: number): string {
  const maxWidth = 800;
  const scale = width > maxWidth ? maxWidth / width : 1;
  const targetW = Math.max(1, Math.round(width * scale));
  const targetH = Math.max(1, Math.round(height * scale));

  const canvas = document.createElement('canvas');
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  ctx.drawImage(source, 0, 0, targetW, targetH);
  return canvas.toDataURL('image/jpeg', 0.78);
}

export const SiteCameraModal: React.FC<SiteCameraModalProps> = ({
  taskTitle,
  lang,
  onSavePhoto,
  onClose,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [cameraState, setCameraState] = useState<'starting' | 'ready' | 'captured' | 'error'>('starting');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [capturedUrl, setCapturedUrl] = useState<string>('');

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    stopStream();
    setCapturedUrl('');
    setErrorMessage('');
    setCameraState('starting');

    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setCameraState('error');
      setErrorMessage(
        lang === 'hi'
          ? 'इस ब्राउज़र में लाइव कैमरा सपोर्ट नहीं है — नीचे "फोटो अपलोड / कैमरा" बटन का उपयोग करें।'
          : 'Live camera API is unavailable in this browser. Use the Upload / Device Camera button below.'
      );
      return;
    }

    try {
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
      } catch {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      }

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraState('ready');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : '';
      setCameraState('error');
      if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('denied') || msg.toLowerCase().includes('notallowed')) {
        setErrorMessage(
          lang === 'hi'
            ? 'कैमरा अनुमति (Permission) बंद है। कृपया ब्राउज़र से कैमरा Allow करें या नीचे से फोटो चुनें।'
            : 'Camera permission was denied. Allow camera access in your browser or choose a photo below.'
        );
      } else {
        setErrorMessage(
          lang === 'hi'
            ? 'कैमरा चालू नहीं हो सका। आप नीचे से डिवाइस कैमरा / गैलरी फोटो अपलोड कर सकते हैं।'
            : 'Could not start live camera. You can still capture or upload a site photo below.'
        );
      }
    }
  }, [lang, stopStream]);

  useEffect(() => {
    startCamera();
    return () => {
      stopStream();
    };
  }, [startCamera, stopStream]);

  const handleCapture = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth || !video.videoHeight) return;
    const dataUrl = resizeImageToJpeg(video, video.videoWidth, video.videoHeight);
    if (!dataUrl) return;
    stopStream();
    setCapturedUrl(dataUrl);
    setCameraState('captured');
  };

  const handleFileFallback = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      if (!result) return;
      const img = new Image();
      img.onload = () => {
        const compressed = resizeImageToJpeg(img, img.width, img.height);
        stopStream();
        setCapturedUrl(compressed || result);
        setCameraState('captured');
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  const handleConfirm = () => {
    if (!capturedUrl) return;
    onSavePhoto(capturedUrl);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Take Site Photo"
    >
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl border border-slate-200 overflow-hidden shadow-2xl">
        {/* Modal Header */}
        <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-xs font-semibold text-blue-700">
              {lang === 'hi' ? 'साइट प्रूफ फोटो लें' : 'Take Site Photo Documentation'}
            </div>
            <h4 className="text-sm font-bold text-slate-900 truncate">{taskTitle}</h4>
          </div>
          <button
            onClick={() => {
              stopStream();
              onClose();
            }}
            aria-label="Close camera"
            className="w-10 h-10 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 flex items-center justify-center shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewport */}
        <div className="p-4 space-y-4">
          <div className="relative bg-slate-900 rounded-2xl overflow-hidden aspect-[4/3] flex items-center justify-center">
            {cameraState === 'captured' && capturedUrl ? (
              <img src={capturedUrl} alt="Captured site photo" className="w-full h-full object-cover" />
            ) : (
              <video
                ref={videoRef}
                playsInline
                muted
                className={`w-full h-full object-cover ${cameraState === 'ready' ? 'block' : 'hidden'}`}
              />
            )}

            {cameraState === 'starting' && (
              <div className="text-center text-slate-300 text-xs px-4">
                <Camera className="w-8 h-8 mx-auto mb-2 opacity-80" />
                <span>{lang === 'hi' ? 'कैमरा शुरू हो रहा है...' : 'Requesting camera permission...'}</span>
              </div>
            )}

            {cameraState === 'error' && (
              <div className="text-center text-slate-200 px-5 space-y-2">
                <AlertCircle className="w-8 h-8 mx-auto text-amber-400" />
                <p className="text-xs leading-relaxed">{errorMessage}</p>
              </div>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFileFallback}
            className="hidden"
          />

          {/* Action Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            {cameraState === 'ready' && (
              <button
                onClick={handleCapture}
                className="flex-1 h-12 px-5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center justify-center gap-2"
              >
                <Camera className="w-4 h-4" />
                <span>{lang === 'hi' ? 'फोटो खींचें' : 'Capture Photo'}</span>
              </button>
            )}

            {cameraState === 'captured' && (
              <>
                <button
                  onClick={startCamera}
                  className="h-12 px-4 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'दोबारा लें' : 'Retake'}</span>
                </button>
                <button
                  onClick={handleConfirm}
                  className="flex-1 h-12 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'चेकलिस्ट में जोड़ें' : 'Attach Site Photo'}</span>
                </button>
              </>
            )}

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="h-12 px-4 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Upload className="w-4 h-4" />
              <span>{lang === 'hi' ? 'फ़ाइल / कैमरा चुनें' : 'Upload / Device Camera'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
