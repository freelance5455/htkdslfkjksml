import { Eye, EyeOff, PanelLeft, Plus, Trash2 } from "lucide-react";
import type { RefObject } from "react";
import { MarkdownPreview } from "@/components/notes/markdown-preview";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { Note } from "@/lib/notes/types";
import { formatEdited } from "@/lib/utils";

type EditorPaneProps = {
  note: Note | null;
  preview: boolean;
  queryActive: boolean;
  onChange: (content: string) => void;
  onTogglePreview: () => void;
  onDelete: () => void;
  onCreate: () => void;
  onOpenList: () => void;
  editorRef: RefObject<HTMLTextAreaElement | null>;
  now: number;
  modLabel: string;
};

export function EditorPane({
  note,
  preview,
  queryActive,
  onChange,
  onTogglePreview,
  onDelete,
  onCreate,
  onOpenList,
  editorRef,
  now,
  modLabel,
}: EditorPaneProps) {
  return (
    <section className="flex min-h-0 min-w-0 flex-1 flex-col bg-paper">
      <header className="flex items-center gap-1 border-b border-border px-2 py-2 md:gap-2 md:px-4">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={onOpenList}
          aria-label="Open notes list"
        >
          <PanelLeft />
        </Button>

        <div className="min-w-0 flex-1 px-1">
          {note ? (
            <>
              <p className="truncate font-serif text-base font-medium tracking-tight text-fg">
                {note.title}
              </p>
              <p className="truncate font-sans text-xs text-subtle tabular-nums">
                Edited {formatEdited(note.updatedAt, now)}
              </p>
            </>
          ) : (
            <p className="font-serif text-base text-muted">
              {queryActive ? "No matching note" : "No note selected"}
            </p>
          )}
        </div>

        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={onCreate}
          aria-label="New note"
        >
          <Plus />
        </Button>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={onTogglePreview}
              disabled={!note}
              aria-label={preview ? "Show editor" : "Show preview"}
              aria-pressed={preview}
            >
              {preview ? <EyeOff /> : <Eye />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            {preview ? "Edit" : "Preview"} · {modLabel}E
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              type="button"
              variant="danger"
              size="icon"
              onClick={onDelete}
              disabled={!note}
              aria-label="Delete note"
            >
              <Trash2 />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Delete</TooltipContent>
        </Tooltip>
      </header>

      <div className="relative min-h-0 flex-1 overflow-hidden">
        {!note ? (
          <EmptyEditor queryActive={queryActive} onCreate={onCreate} />
        ) : preview ? (
          <ScrollArea className="absolute inset-0">
            <div className="mx-auto max-w-prose px-5 py-8 md:px-8 md:py-10">
              <MarkdownPreview content={note.content} />
            </div>
          </ScrollArea>
        ) : (
          <div className="absolute inset-0">
            <div className="mx-auto h-full max-w-prose">
              <label className="sr-only" htmlFor="folio-editor">
                Note content
              </label>
              <textarea
                id="folio-editor"
                key={note.id}
                ref={editorRef}
                className="writing-surface h-full w-full resize-none bg-transparent px-5 py-8 font-serif text-lg leading-relaxed text-fg focus-visible:outline-none md:px-8 md:py-10"
                value={note.content}
                onChange={(event) => onChange(event.target.value)}
                placeholder="Start writing…"
                spellCheck
                wrap="soft"
              />
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function EmptyEditor({
  queryActive,
  onCreate,
}: {
  queryActive: boolean;
  onCreate: () => void;
}) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
      <p className="font-serif text-xl tracking-tight text-fg text-balance">
        {queryActive ? "Nothing matches that search" : "A blank folio"}
      </p>
      <p className="max-w-sm font-sans text-sm text-muted text-pretty">
        {queryActive
          ? "Try another word, or start a new note from here."
          : "Create a note and begin. Everything stays on this device."}
      </p>
      <Button type="button" onClick={onCreate}>
        New note
      </Button>
    </div>
  );
}
