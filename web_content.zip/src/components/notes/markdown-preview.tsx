import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { Components } from "react-markdown";

const components: Components = {
  a: ({ href, children }) => (
    <a href={href} target="_blank" rel="noreferrer noopener">
      {children}
    </a>
  ),
  input: ({ node: _node, ...props }) => {
    if (props.type === "checkbox") {
      return <input {...props} disabled readOnly className="md-check" />;
    }
    return <input {...props} />;
  },
};

export function MarkdownPreview({ content }: { content: string }) {
  if (!content.trim()) {
    return (
      <p className="font-serif text-lg text-subtle">Nothing to preview yet. Write a little first.</p>
    );
  }

  return (
    <div className="md-preview">
      <Markdown remarkPlugins={[remarkGfm]} components={components}>
        {content}
      </Markdown>
    </div>
  );
}
