import { Plus, Search } from "lucide-react";
import type { RefObject } from "react";
import { FolioMark } from "@/components/notes/folio-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Note } from "@/lib/notes/types";
import { notePreview } from "@/lib/notes/title";
import { cn, formatEdited } from "@/lib/utils";

type SidebarProps = {
  notes: Note[];
  selectedId: string | null;
  query: string;
  totalCount: number;
  onQueryChange: (value: string) => void;
  onSelect: (id: string) => void;
  onCreate: () => void;
  searchRef: RefObject<HTMLInputElement | null>;
  listRef: RefObject<HTMLDivElement | null>;
  now: number;
  modLabel: string;
};

export function Sidebar({
  notes,
  selectedId,
  query,
  totalCount,
  onQueryChange,
  onSelect,
  onCreate,
  searchRef,
  listRef,
  now,
  modLabel,
}: SidebarProps) {
  const searching = query.trim().length > 0;

  return (
    <div className="flex h-full min-h-0 flex-col bg-bg">
      <div className="flex items-center gap-3 px-4 pt-5 pb-3">
        <FolioMark />
        <div className="min-w-0 flex-1">
          <p className="font-serif text-lg leading-tight font-medium tracking-tight italic">Folio</p>
          <p className="font-sans text-xs text-subtle">Quiet notes</p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="iconSm"
          onClick={onCreate}
          aria-label="New note"
          title={`New note (${modLabel}N)`}
        >
          <Plus />
        </Button>
      </div>

      <div className="px-3 pb-3">
        <label className="relative block">
          <span className="sr-only">Search notes</span>
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
          <Input
            ref={searchRef}
            value={query}
            onChange={(event) => onQueryChange(event.target.value)}
            placeholder="Search"
            className="pl-9"
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
            aria-keyshortcuts="Meta+K Control+K"
          />
        </label>
      </div>

      <ScrollArea className="min-h-0 flex-1 px-2">
        <div
          ref={listRef}
          role="listbox"
          aria-label="Notes"
          tabIndex={0}
          className="flex flex-col gap-1 pb-3 focus-visible:outline-none"
        >
          {notes.length === 0 ? (
            <p className="px-3 py-8 text-center font-sans text-sm text-subtle">
              {searching ? "No matching notes" : "No notes yet"}
            </p>
          ) : (
            notes.map((note) => {
              const selected = note.id === selectedId;
              return (
                <button
                  key={note.id}
                  type="button"
                  role="option"
                  aria-selected={selected}
                  onClick={() => onSelect(note.id)}
                  className={cn(
                    "note-item flex min-h-11 w-full flex-col items-start gap-1 border-l-2 px-3 py-3 text-left",
                    selected
                      ? "border-accent bg-surface-hover text-fg"
                      : "border-transparent text-muted hover:bg-surface hover:text-fg",
                  )}
                >
                  <span className="w-full truncate font-sans text-sm font-medium">{note.title}</span>
                  <span className="flex w-full items-center justify-between gap-2">
                    <span className="truncate text-xs text-subtle">{notePreview(note.content)}</span>
                    <span className="shrink-0 font-sans text-xs text-subtle tabular-nums">
                      {formatEdited(note.updatedAt, now)}
                    </span>
                  </span>
                </button>
              );
            })
          )}
        </div>
      </ScrollArea>

      <div className="flex items-center justify-between gap-2 px-4 py-3 text-xs text-subtle">
        <span className="tabular-nums">
          {searching
            ? `${notes.length} found`
            : `${totalCount} ${totalCount === 1 ? "note" : "notes"}`}
        </span>
        <span className="hidden lg:inline">{modLabel}K search</span>
      </div>
    </div>
  );
}
