import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { EditorPane } from "@/components/notes/editor-pane";
import { Sidebar } from "@/components/notes/sidebar";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { TooltipProvider } from "@/components/ui/tooltip";
import { rehydrateNotes, useNotesStore } from "@/lib/notes/store";
import { cn, isModKey } from "@/lib/utils";

function useNow(interval = 30000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), interval);
    return () => window.clearInterval(id);
  }, [interval]);
  return now;
}

function useModLabel() {
  const [label, setLabel] = useState("Ctrl");
  useEffect(() => {
    const mac = /Mac|iPhone|iPad|iPod/i.test(navigator.platform);
    setLabel(mac ? "⌘" : "Ctrl");
  }, []);
  return label;
}

export function NotesApp() {
  const hydrated = useNotesStore((state) => state.hydrated);
  const notes = useNotesStore((state) => state.notes);
  const selectedId = useNotesStore((state) => state.selectedId);
  const preview = useNotesStore((state) => state.preview);
  const createNote = useNotesStore((state) => state.createNote);
  const updateContent = useNotesStore((state) => state.updateContent);
  const deleteNote = useNotesStore((state) => state.deleteNote);
  const selectNote = useNotesStore((state) => state.selectNote);
  const togglePreview = useNotesStore((state) => state.togglePreview);

  const [query, setQuery] = useState("");
  const [listOpen, setListOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [focusTick, setFocusTick] = useState(0);

  const searchRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<HTMLTextAreaElement>(null);

  const now = useNow();
  const modLabel = useModLabel();

  useEffect(() => rehydrateNotes(), []);

  useEffect(() => {
    if (focusTick === 0) return;
    editorRef.current?.focus();
  }, [focusTick, selectedId, preview]);

  const visibleNotes = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return notes;
    return notes.filter(
      (note) =>
        note.title.toLowerCase().includes(needle) || note.content.toLowerCase().includes(needle),
    );
  }, [notes, query]);

  const selected = notes.find((note) => note.id === selectedId) ?? null;

  useEffect(() => {
    if (!hydrated) return;
    if (visibleNotes.some((note) => note.id === selectedId)) return;
    selectNote(visibleNotes[0]?.id ?? null);
  }, [hydrated, query, visibleNotes, selectedId, selectNote]);

  const handleCreate = useCallback(() => {
    setQuery("");
    setListOpen(false);
    createNote();
    setFocusTick((tick) => tick + 1);
  }, [createNote]);

  const handleSelect = useCallback(
    (id: string) => {
      selectNote(id);
      setListOpen(false);
    },
    [selectNote],
  );

  const requestDelete = useCallback(() => {
    if (!selected) return;
    if (!selected.content.trim()) {
      deleteNote(selected.id);
      return;
    }
    setDeleteOpen(true);
  }, [selected, deleteNote]);

  const confirmDelete = useCallback(() => {
    if (!selected) return;
    deleteNote(selected.id);
    setDeleteOpen(false);
  }, [selected, deleteNote]);

  const moveSelection = useCallback(
    (delta: number) => {
      if (visibleNotes.length === 0) return;
      const index = visibleNotes.findIndex((note) => note.id === selectedId);
      const nextIndex =
        index < 0
          ? delta > 0
            ? 0
            : visibleNotes.length - 1
          : Math.max(0, Math.min(visibleNotes.length - 1, index + delta));
      const next = visibleNotes[nextIndex];
      if (next) selectNote(next.id);
      listRef.current?.focus();
    },
    [visibleNotes, selectedId, selectNote],
  );

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (event.isComposing || deleteOpen) return;

      const target = event.target as HTMLElement | null;
      const inField =
        Boolean(target) &&
        (target?.tagName === "INPUT" ||
          target?.tagName === "TEXTAREA" ||
          Boolean(target?.isContentEditable));
      const mod = isModKey(event);
      const listFocused = Boolean(listRef.current?.contains(document.activeElement));

      if (event.key === "Escape") {
        if (listOpen) {
          setListOpen(false);
          event.preventDefault();
          return;
        }
        if (document.activeElement === searchRef.current && query) {
          setQuery("");
          event.preventDefault();
          return;
        }
        listRef.current?.focus();
        event.preventDefault();
        return;
      }

      if (mod && event.key.toLowerCase() === "n") {
        event.preventDefault();
        handleCreate();
        return;
      }
      if (mod && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setListOpen(true);
        searchRef.current?.focus();
        searchRef.current?.select();
        return;
      }
      if (mod && event.key.toLowerCase() === "e") {
        event.preventDefault();
        if (selected) togglePreview();
        return;
      }
      if (mod && event.key.toLowerCase() === "s") {
        event.preventDefault();
        return;
      }

      if (event.key === "/" && !inField && !mod) {
        event.preventDefault();
        setListOpen(true);
        searchRef.current?.focus();
        return;
      }

      const vertical =
        event.key === "ArrowDown" ||
        event.key === "ArrowUp" ||
        ((!inField || listFocused) && (event.key === "j" || event.key === "k"));
      if (vertical && (listFocused || document.activeElement === searchRef.current || !inField)) {
        if ((event.key === "j" || event.key === "k") && inField && !listFocused) return;
        event.preventDefault();
        moveSelection(event.key === "ArrowDown" || event.key === "j" ? 1 : -1);
        return;
      }

      if ((event.key === "Delete" || event.key === "Backspace") && listFocused && !mod) {
        if ((document.activeElement as HTMLElement | null)?.tagName === "INPUT") return;
        event.preventDefault();
        requestDelete();
      }
    }

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [
    deleteOpen,
    listOpen,
    query,
    selected,
    handleCreate,
    togglePreview,
    moveSelection,
    requestDelete,
  ]);

  if (!hydrated) {
    return <NotesSkeleton />;
  }

  return (
    <TooltipProvider>
      <div className="app-shell flex overflow-hidden bg-bg text-fg">
        <button
          type="button"
          className="sidebar-backdrop fixed inset-0 z-30 bg-overlay md:hidden"
          data-open={listOpen}
          tabIndex={listOpen ? 0 : -1}
          aria-label="Close notes list"
          onClick={() => setListOpen(false)}
        />

        <aside
          className={cn(
            "sidebar-drawer fixed inset-y-0 left-0 z-40 flex h-full flex-col shadow-float md:relative md:z-0 md:shadow-none",
            "md:w-sidebar md:shrink-0 md:border-r md:border-border",
          )}
          data-open={listOpen}
        >
          <Sidebar
            notes={visibleNotes}
            selectedId={selectedId}
            query={query}
            totalCount={notes.length}
            onQueryChange={setQuery}
            onSelect={handleSelect}
            onCreate={handleCreate}
            searchRef={searchRef}
            listRef={listRef}
            now={now}
            modLabel={modLabel}
          />
        </aside>

        <EditorPane
          note={selected}
          preview={preview}
          queryActive={query.trim().length > 0}
          onChange={(content) => {
            if (selected) updateContent(selected.id, content);
          }}
          onTogglePreview={togglePreview}
          onDelete={requestDelete}
          onCreate={handleCreate}
          onOpenList={() => setListOpen(true)}
          editorRef={editorRef}
          now={now}
          modLabel={modLabel}
        />
      </div>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this note?</AlertDialogTitle>
            <AlertDialogDescription>
              {selected
                ? `“${selected.title}” will be removed from this device. This cannot be undone.`
                : "This note will be removed from this device."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </TooltipProvider>
  );
}

function NotesSkeleton() {
  return (
    <div className="app-shell flex overflow-hidden bg-bg text-fg">
      <aside className="hidden h-full w-sidebar shrink-0 border-r border-border bg-bg md:block">
        <div className="px-4 pt-5 pb-3">
          <div className="h-6 w-24 rounded-sm bg-surface-hover" />
        </div>
        <div className="px-3 pb-3">
          <div className="h-11 rounded-md bg-surface-hover" />
        </div>
        <div className="space-y-2 px-3">
          <div className="h-16 rounded-md bg-surface" />
          <div className="h-16 rounded-md bg-surface" />
          <div className="h-16 rounded-md bg-surface" />
        </div>
      </aside>
      <section className="flex min-w-0 flex-1 flex-col bg-paper">
        <div className="border-b border-border px-4 py-4">
          <div className="h-5 w-40 rounded-sm bg-surface-hover" />
        </div>
        <div className="px-8 py-10">
          <div className="h-8 w-56 rounded-sm bg-surface-hover" />
          <div className="mt-6 h-4 w-full max-w-prose rounded-sm bg-surface" />
          <div className="mt-3 h-4 w-4/5 max-w-prose rounded-sm bg-surface" />
        </div>
      </section>
    </div>
  );
}
