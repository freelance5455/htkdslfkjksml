import { cn } from "@/lib/utils";

export function FolioMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-6", className)}
      aria-hidden="true"
      focusable="false"
    >
      <rect width="32" height="32" rx="8" className="fill-surface-hover" />
      <path d="M9 7h10.2L23 11.8V25H9V7Z" className="fill-accent" />
      <path d="M19.2 7V11.8H23" className="fill-muted" />
      <path
        d="M12 16h8M12 19.2h6"
        className="stroke-accent-fg"
        strokeWidth="1.4"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}
