import React, { useState } from 'react';
import { 
  X, 
  BellRing, 
  TrendingUp, 
  TrendingDown, 
  Trash2, 
  Play, 
  Volume2, 
  Clock, 
  CheckCircle2,
  AlertCircle,
  RotateCcw
} from 'lucide-react';
import { ActiveVoiceAlert, TriggeredAlertEvent, AudioSettings } from '../types/market';
import { executeVoiceAlert } from '../services/audioEngine';

interface ActiveAlertsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: ActiveVoiceAlert[];
  onToggleAlert: (alertId: string) => void;
  onDeleteAlert: (alertId: string) => void;
  onSimulateTrigger: (alert: ActiveVoiceAlert) => void;
  history: TriggeredAlertEvent[];
  onClearHistory: () => void;
  audioSettings: AudioSettings;
  language: 'fr' | 'en';
}

export const ActiveAlertsDrawer: React.FC<ActiveAlertsDrawerProps> = ({
  isOpen,
  onClose,
  alerts,
  onToggleAlert,
  onDeleteAlert,
  onSimulateTrigger,
  history,
  onClearHistory,
  audioSettings,
  language,
}) => {
  const [tab, setTab] = useState<'active' | 'history'>('active');

  if (!isOpen) return null;

  const handleReplayHistory = async (item: TriggeredAlertEvent) => {
    await executeVoiceAlert(item.soundChime, item.voiceScript, audioSettings, language);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-950 border-l border-slate-800 flex flex-col h-full shadow-2xl">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
              <BellRing className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white font-['Chakra_Petch']">
                GESTIONNAIRE D'ALERTES VOCALES
              </h2>
              <p className="text-xs text-slate-400">
                {alerts.filter((a) => a.enabled).length} alertes armées &bull; Surveillance active
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-slate-900/40 px-5 gap-2 pt-2">
          <button
            onClick={() => setTab('active')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
              tab === 'active'
                ? 'bg-slate-950 text-emerald-400 border-emerald-500 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Alertes Armées ({alerts.length})</span>
          </button>

          <button
            onClick={() => setTab('history')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
              tab === 'history'
                ? 'bg-slate-950 text-emerald-400 border-emerald-500 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Historique ({history.length})</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {tab === 'active' ? (
            alerts.length === 0 ? (
              <div className="p-8 text-center text-slate-400 space-y-3 bg-slate-900/30 rounded-2xl border border-slate-800/80">
                <AlertCircle className="w-10 h-10 text-slate-500 mx-auto" />
                <div className="font-semibold text-sm text-slate-300">Aucune alerte active</div>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Cliquez sur "Alerte Vocale" sur n'importe quel actif pour surveiller les cassures de cours avec annonce vocale.
                </p>
              </div>
            ) : (
              alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-xl border transition-all space-y-3 ${
                    alert.enabled
                      ? 'bg-slate-900/80 border-slate-700/80 hover:border-emerald-500/40'
                      : 'bg-slate-950 border-slate-800 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs font-mono text-white">
                        {alert.assetSymbol.slice(0, 4)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-white">{alert.assetSymbol}</span>
                          <span className={`flex items-center gap-1 text-xs font-mono font-bold px-2 py-0.5 rounded-full ${
                            alert.condition === 'above'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                          }`}>
                            {alert.condition === 'above' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            <span>{alert.condition === 'above' ? '≥' : '≤'} ${alert.targetValue.toLocaleString()}</span>
                          </span>
                        </div>
                        <span className="text-xs text-slate-400">{alert.assetName}</span>
                      </div>
                    </div>

                    {/* Toggle Enabled Switch */}
                    <button
                      onClick={() => onToggleAlert(alert.id)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        alert.enabled ? 'bg-emerald-500' : 'bg-slate-800'
                      }`}
                      title={alert.enabled ? 'Désactiver' : 'Activer'}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          alert.enabled ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Voice Script Quote */}
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 font-mono text-xs text-slate-300 italic">
                    "{alert.voiceScript}"
                  </div>

                  {/* Footer actions */}
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/80">
                    <span className="font-mono text-slate-500 text-[11px]">
                      Carillon: <strong className="text-slate-300 capitalize">{alert.soundChime}</strong>
                      {alert.triggerCount > 0 && ` &bull; Déclenché ${alert.triggerCount}x`}
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSimulateTrigger(alert)}
                        className="px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                        title="Déclencher immédiatement l'alerte pour tester le son et la bannière"
                      >
                        <Play className="w-3 h-3 fill-amber-300" />
                        <span>Tester Trigger</span>
                      </button>

                      <button
                        onClick={() => onDeleteAlert(alert.id)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                        title="Supprimer cette alerte"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )
          ) : (
            // HISTORY TAB
            history.length === 0 ? (
              <div className="p-8 text-center text-slate-400 space-y-3 bg-slate-900/30 rounded-2xl border border-slate-800/80">
                <Clock className="w-10 h-10 text-slate-500 mx-auto" />
                <div className="font-semibold text-sm text-slate-300">Aucun historique récent</div>
                <p className="text-xs text-slate-500">
                  Les alertes déclenchées par les cours apparaîtront ici avec possibilité de réécoute.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex justify-end">
                  <button
                    onClick={onClearHistory}
                    className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 cursor-pointer font-mono"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Effacer l'historique</span>
                  </button>
                </div>

                {history.map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white font-mono">{item.assetSymbol}</span>
                        <span className="font-mono text-xs text-emerald-400 font-semibold">
                          ${item.currentPrice.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 italic max-w-sm truncate">
                        "{item.voiceScript}"
                      </p>
                    </div>

                    <button
                      onClick={() => handleReplayHistory(item)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
                      title="Rejouer l'annonce vocale"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
