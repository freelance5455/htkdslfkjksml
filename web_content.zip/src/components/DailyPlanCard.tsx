import { CheckCircle2, Compass, Play, Sparkles, Trophy } from 'lucide-react';
import { useMemo } from 'react';
import type { DailyPlanStepId, PersistedSettings } from '../types';
import {
  buildDailyPlan,
  getGoalLabelAr,
} from '../utils/learningFeaturesLogic';

interface DailyPlanCardProps {
  settings: PersistedSettings;
  srsDueCount: number;
  todayKey: string;
  onStartStep: (stepId: DailyPlanStepId) => void;
  onEditPlan?: () => void;
}

export function DailyPlanCard({
  settings,
  srsDueCount,
  todayKey,
  onStartStep,
  onEditPlan,
}: DailyPlanCardProps) {
  const plan = useMemo(
    () => buildDailyPlan(settings, srsDueCount, todayKey),
    [settings, srsDueCount, todayKey]
  );

  const goalLabel = getGoalLabelAr(settings.learningGoal);

  return (
    <section
      data-testid="daily-plan-card"
      className="tmn-card rounded-3xl p-5 sm:p-6"
    >
      {/* Header Row */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Compass className="h-4.5 w-4.5 text-indigo-500 dark:text-indigo-400" aria-hidden="true" />
            <h2 className="text-base font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-lg">
              مهمتك اليوم
            </h2>
          </div>
          <p className="mt-1 text-xs font-medium text-slate-500 dark:text-slate-400">
            مستوى {plan.band} · {plan.paceMinutes} دقائق يومياً · {goalLabel}
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {onEditPlan && (
            <button
              type="button"
              onClick={onEditPlan}
              className="whitespace-nowrap rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100"
            >
              تخصيص الخطة
            </button>
          )}
          <div className="flex items-center gap-1.5 text-xs font-extrabold tabular-nums">
            {plan.allCompleted ? (
              <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                <Trophy className="h-4 w-4" aria-hidden="true" />
                +{plan.bonusXp} XP مكتسب
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400">
                <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                مكافأة +{plan.bonusXp} XP
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Segmented 4-Step Progress Bar */}
      <div className="mt-4">
        <div className="mb-2 flex items-center justify-between text-xs font-bold">
          <span className="text-slate-600 dark:text-slate-300">
            تقدم خطة اليوم
          </span>
          <span
            data-testid="daily-plan-progress-label"
            className="font-code text-slate-700 tabular-nums dark:text-slate-200"
          >
            {plan.completedCount}/{plan.totalSteps} مكتمل
          </span>
        </div>
        <div className="grid grid-cols-4 gap-2" aria-label="تقدم خطة اليوم">
          {plan.steps.map((step) => (
            <div
              key={step.id}
              className={`h-2 rounded-full transition-colors ${
                step.completed
                  ? 'bg-emerald-500 dark:bg-emerald-400'
                  : 'bg-slate-200/80 dark:bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* 4 Tailored Steps */}
      <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
        {plan.steps.map((step) => (
          <div
            key={step.id}
            data-testid={`daily-plan-step-${step.id}`}
            className={`flex items-center justify-between gap-3 rounded-2xl border p-3.5 transition-colors ${
              step.completed
                ? 'border-emerald-200/80 bg-emerald-50/60 dark:border-emerald-500/25 dark:bg-emerald-500/[0.06]'
                : 'border-slate-200/70 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-900/40'
            }`}
          >
            <div className="flex min-w-0 items-start gap-3">
              <div
                className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-extrabold tabular-nums ${
                  step.completed
                    ? 'bg-emerald-500 text-white'
                    : 'bg-indigo-600/10 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-300'
                }`}
              >
                {step.completed ? (
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                ) : (
                  step.order
                )}
              </div>
              <div className="min-w-0">
                <div
                  className={`truncate text-sm font-bold ${
                    step.completed
                      ? 'text-emerald-900 dark:text-emerald-200'
                      : 'text-slate-900 dark:text-slate-100'
                  }`}
                >
                  {step.titleAr}
                </div>
                <div className="mt-0.5 line-clamp-1 text-xs text-slate-500 dark:text-slate-400">
                  {step.subtitleAr}
                </div>
              </div>
            </div>

            <button
              type="button"
              data-testid={`daily-plan-start-${step.id}`}
              onClick={() => onStartStep(step.id)}
              className={`inline-flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl px-3.5 text-xs font-bold transition-colors ${
                step.completed
                  ? 'border border-emerald-300 bg-white text-emerald-700 hover:bg-emerald-50 dark:border-emerald-700/60 dark:bg-slate-900/60 dark:text-emerald-300'
                  : 'bg-indigo-600 text-white hover:bg-indigo-700'
              }`}
            >
              <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
              <span>{step.completed ? 'مراجعة' : step.actionLabelAr}</span>
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}
