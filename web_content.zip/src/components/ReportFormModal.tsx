import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Camera,
  Image as ImageIcon,
  Trash2,
  Check,
  AlertCircle,
  Plus
} from 'lucide-react';
import {
  OperationalReport,
  Sector,
  ReportImage,
  ImageTag,
  OperationalStatus,
  Priority,
  Shift
} from '../types/report';
import { compressImage } from '../services/storage';
import { SectorIcon } from './SectorIcon';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (report: OperationalReport) => void;
  sectors: Sector[];
  initialReport?: OperationalReport | null;
  defaultSectorId?: string;
}

export const ReportFormModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSave,
  sectors,
  initialReport,
  defaultSectorId
}) => {
  if (!isOpen) return null;

  // Selected Sector
  const [sectorId, setSectorId] = useState<string>(
    initialReport?.sectorId ||
      (defaultSectorId && defaultSectorId !== 'all' ? defaultSectorId : sectors[0]?.id || 'produzione')
  );

  const activeSector = sectors.find((s) => s.id === sectorId) || sectors[0];

  // Core Fields
  const [title, setTitle] = useState(initialReport?.title || '');
  const [dateStr, setDateStr] = useState(
    initialReport ? initialReport.timestamp.slice(0, 16) : new Date().toISOString().slice(0, 16)
  );
  const [shift, setShift] = useState<Shift>(initialReport?.shift || 'mattina');
  const [operatorName, setOperatorName] = useState(initialReport?.operatorName || '');
  const [operatorRole, setOperatorRole] = useState(initialReport?.operatorRole || '');
  const [status, setStatus] = useState<OperationalStatus>(initialReport?.status || 'completato');
  const [priority, setPriority] = useState<Priority>(initialReport?.priority || 'media');
  const [location, setLocation] = useState(initialReport?.location || '');
  const [description, setDescription] = useState(initialReport?.description || '');
  const [correctiveActions, setCorrectiveActions] = useState(initialReport?.correctiveActions || '');
  
  // Dynamic Sector Metrics
  const [metrics, setMetrics] = useState<Record<string, any>>(() => {
    if (initialReport?.metrics) return { ...initialReport.metrics };
    const defaults: Record<string, any> = {};
    activeSector?.metricFields?.forEach((f) => {
      defaults[f.key] = f.defaultValue !== undefined ? f.defaultValue : '';
    });
    return defaults;
  });

  // Images state
  const [images, setImages] = useState<ReportImage[]>(initialReport?.images || []);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Handle Sector Change
  const handleSectorChange = (newSectorId: string) => {
    setSectorId(newSectorId);
    const newSec = sectors.find((s) => s.id === newSectorId);
    if (newSec) {
      const newMetrics: Record<string, any> = {};
      newSec.metricFields.forEach((f) => {
        newMetrics[f.key] = f.defaultValue !== undefined ? f.defaultValue : '';
      });
      setMetrics(newMetrics);
    }
  };

  // Handle File Uploads (Multiple)
  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsProcessingImage(true);
    setErrorMsg('');

    try {
      const newImagesList: ReportImage[] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.type.startsWith('image/')) continue;

        const compressed = await compressImage(file, 1600, 1600, 0.82);
        newImagesList.push({
          id: `img-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          url: compressed.dataUrl,
          caption: '',
          tag: 'Prima Intervento',
          uploadedAt: new Date().toISOString(),
          fileName: compressed.originalName,
          sizeBytes: compressed.sizeBytes
        });
      }

      setImages((prev) => [...prev, ...newImagesList]);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Impossibile elaborare una o più immagini selezionate.');
    } finally {
      setIsProcessingImage(false);
    }
  };

  const handleUpdateImageCaption = (imgId: string, caption: string) => {
    setImages((prev) =>
      prev.map((img) => (img.id === imgId ? { ...img, caption } : img))
    );
  };

  const handleUpdateImageTag = (imgId: string, tag: ImageTag) => {
    setImages((prev) =>
      prev.map((img) => (img.id === imgId ? { ...img, tag } : img))
    );
  };

  const handleRemoveImage = (imgId: string) => {
    setImages((prev) => prev.filter((img) => img.id !== imgId));
  };

  // Form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Inserisci un titolo per il report.');
      return;
    }
    if (!operatorName.trim()) {
      setErrorMsg('Inserisci il nome del compilatore / operatore.');
      return;
    }

    const reportData: OperationalReport = {
      id: initialReport?.id || `rep-${Date.now()}`,
      protocolNumber:
        initialReport?.protocolNumber ||
        `REP-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
      title: title.trim(),
      sectorId,
      timestamp: new Date(dateStr).toISOString(),
      shift,
      operatorName: operatorName.trim(),
      operatorRole: operatorRole.trim() || 'Operatore di Reparto',
      status,
      priority,
      location: location.trim() || 'Stabilimento Operativo',
      description: description.trim(),
      correctiveActions: correctiveActions.trim() || undefined,
      metrics,
      images,
      tags: initialReport?.tags || [activeSector.name],
      supervisorSignoff: initialReport?.supervisorSignoff,
      createdAt: initialReport?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSave(reportData);
    onClose();
  };

  const availableTags: ImageTag[] = [
    'Prima Intervento',
    'Durante',
    'Dopo Intervento',
    'Anomalia / Danno',
    'Conferma / Verbale',
    'DDT / Scheda Tecnica',
    'Altro'
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-xl border border-neutral-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between shrink-0 bg-neutral-50/50">
          <div>
            <h2 className="text-base font-bold text-neutral-900">
              {initialReport ? 'Modifica Report Operativo' : 'Nuovo Inserimento Report & Immagini'}
            </h2>
            <p className="text-xs text-neutral-500">
              Compila le informazioni di turno, metriche di settore e allega fotografie documentali
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body (Scrollable) */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-md text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Section 1: Inquadramento & Settore */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-2">
              1. Settore Aziendale di Riferimento
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
              {sectors.map((sec) => {
                const isSelected = sec.id === sectorId;
                return (
                  <button
                    type="button"
                    key={sec.id}
                    onClick={() => handleSectorChange(sec.id)}
                    className={`p-2.5 rounded-lg border text-left transition-all flex flex-col justify-between h-20 ${
                      isSelected
                        ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                        : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <SectorIcon name={sec.iconName} className="w-4 h-4" />
                      <span className="font-mono text-[10px] opacity-75">{sec.shortCode}</span>
                    </div>
                    <span className="text-[11px] font-semibold leading-tight line-clamp-2">
                      {sec.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Dati Generali del Report */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Oggetto / Titolo Intervento o Turno <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="es. Verifica taratura assi pressa 300T / Ispezione DPI reparto verniciatura"
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 focus:border-neutral-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Data e Ora Registrazione
              </label>
              <input
                type="datetime-local"
                value={dateStr}
                onChange={(e) => setDateStr(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Turno Operativo
              </label>
              <select
                value={shift}
                onChange={(e) => setShift(e.target.value as Shift)}
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              >
                <option value="mattina">Mattina (06:00 - 14:00)</option>
                <option value="pomeriggio">Pomeriggio (14:00 - 22:00)</option>
                <option value="notte">Notte (22:00 - 06:00)</option>
                <option value="giornaliero">Giornaliero (08:00 - 17:00)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Operatore / Compilatore <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={operatorName}
                onChange={(e) => setOperatorName(e.target.value)}
                placeholder="es. Marco Bellini"
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Ruolo / Mansione
              </label>
              <input
                type="text"
                value={operatorRole}
                onChange={(e) => setOperatorRole(e.target.value)}
                placeholder="es. Tecnico Meccanico / Capo Turno"
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Stato Operativo
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as OperationalStatus)}
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              >
                <option value="completato">Completato con Successo</option>
                <option value="in_corso">In Corso / Lavorazione Aperta</option>
                <option value="in_revisione">Richiede Revisione / Approvazione</option>
                <option value="critico">Critico / Fermo Bloccante</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Livello di Priorità
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              >
                <option value="bassa">Bassa - Routine ordinaria</option>
                <option value="media">Media - Standard operativo</option>
                <option value="alta">Alta - Attenzione richiesta</option>
                <option value="urgente">Urgente - Bloccante / Immediato</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Ubicazione / Reparto / Codice Macchinario
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="es. Stabilimento 2 - Isola Saldatura 4, Baia C-12"
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              />
            </div>
          </div>

          {/* Section 3: Metriche Specifiche del Settore */}
          {activeSector && activeSector.metricFields && activeSector.metricFields.length > 0 && (
            <div className="bg-neutral-50 border border-neutral-200 p-4 rounded-lg space-y-3">
              <div className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                <SectorIcon name={activeSector.iconName} className="w-3.5 h-3.5 text-neutral-600" />
                <span>Metriche Operative per {activeSector.name}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {activeSector.metricFields.map((field) => (
                  <div key={field.key}>
                    <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                      {field.label} {field.unit && `(${field.unit})`}
                    </label>

                    {field.type === 'select' && field.options ? (
                      <select
                        value={metrics[field.key] || ''}
                        onChange={(e) =>
                          setMetrics({ ...metrics, [field.key]: e.target.value })
                        }
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
                      >
                        {field.options.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type={field.type === 'number' ? 'number' : 'text'}
                        step="any"
                        value={metrics[field.key] !== undefined ? metrics[field.key] : ''}
                        onChange={(e) =>
                          setMetrics({
                            ...metrics,
                            [field.key]: field.type === 'number' ? Number(e.target.value) : e.target.value
                          })
                        }
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900 font-mono tabular-nums"
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 4: Note e Descrizione */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Descrizione Dettagliata dell&apos;Attività o Anomalia
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrivi l'operazione svolta, i controlli eseguiti, eventuali guasti riscontrati o note di rilievo..."
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Azioni Correttive Intraprese o Raccomandazioni
              </label>
              <textarea
                rows={2}
                value={correctiveActions}
                onChange={(e) => setCorrectiveActions(e.target.value)}
                placeholder="es. Sostituito fusibile; programmata pulizia filtro per turno successivo; allertato responsabile QHSE..."
                className="w-full px-3 py-2 text-xs bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-neutral-900"
              />
            </div>
          </div>

          {/* Section 5: Immagini e Allegati Fotografici */}
          <div className="border border-neutral-200 rounded-lg p-4 space-y-4 bg-white">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-xs font-semibold text-neutral-900 flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-neutral-700" />
                  <span>Documentazione Fotografica & Prove Visive ({images.length})</span>
                </h3>
                <p className="text-[11px] text-neutral-500">
                  Carica fotografie da galleria o scatta foto da smartphone/tablet
                </p>
              </div>

              {/* Upload & Camera Buttons */}
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  multiple
                  accept="image/*"
                  onChange={(e) => handleFiles(e.target.files)}
                  className="hidden"
                />
                <input
                  type="file"
                  ref={cameraInputRef}
                  accept="image/*"
                  capture="environment"
                  onChange={(e) => handleFiles(e.target.files)}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessingImage}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-md transition-colors"
                >
                  <Upload className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Carica Foto</span>
                </button>

                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  disabled={isProcessingImage}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-neutral-900 hover:bg-neutral-800 rounded-md transition-colors"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Scatta Foto</span>
                </button>
              </div>
            </div>

            {isProcessingImage && (
              <div className="text-xs text-neutral-500 italic py-2">
                Elaborazione e ottimizzazione immagini in corso...
              </div>
            )}

            {/* Uploaded Images List with Editable Captions and Tags */}
            {images.length === 0 ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-neutral-200 hover:border-neutral-400 rounded-lg p-6 text-center cursor-pointer transition-colors bg-neutral-50/50"
              >
                <ImageIcon className="w-8 h-8 text-neutral-400 mx-auto mb-1.5" />
                <div className="text-xs font-medium text-neutral-700">
                  Trascina qui le immagini o clicca per caricare
                </div>
                <div className="text-[11px] text-neutral-400 mt-0.5">
                  PNG, JPG, WebP fino a 1600px con compressione istantanea
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {images.map((img, idx) => (
                  <div
                    key={img.id}
                    className="flex flex-col sm:flex-row items-start gap-3 p-3 bg-neutral-50 border border-neutral-200 rounded-lg"
                  >
                    {/* Thumbnail preview */}
                    <div className="w-24 h-24 rounded bg-neutral-200 overflow-hidden shrink-0 border border-neutral-300">
                      <img
                        src={img.url}
                        alt={img.caption || `Foto ${idx + 1}`}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Image details & caption editor */}
                    <div className="flex-1 w-full space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-semibold text-neutral-700">
                            Foto #{idx + 1}
                          </span>
                          {img.fileName && (
                            <span className="text-[10px] text-neutral-400 truncate max-w-xs font-mono">
                              {img.fileName}
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(img.id)}
                          className="text-neutral-400 hover:text-rose-600 p-1 rounded transition-colors"
                          title="Rimuovi immagine"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div className="sm:col-span-2">
                          <input
                            type="text"
                            placeholder="Didascalia (es. Quadro morsettiera dopo serraggio viti)"
                            value={img.caption}
                            onChange={(e) => handleUpdateImageCaption(img.id, e.target.value)}
                            className="w-full px-2.5 py-1 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-neutral-900"
                          />
                        </div>

                        <div>
                          <select
                            value={img.tag}
                            onChange={(e) => handleUpdateImageTag(img.id, e.target.value as ImageTag)}
                            className="w-full px-2 py-1 text-xs bg-white border border-neutral-300 rounded focus:outline-none focus:ring-1 focus:ring-neutral-900"
                          >
                            {availableTags.map((tag) => (
                              <option key={tag} value={tag}>
                                {tag}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Modal Footer / Actions */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-700 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-50 transition-colors"
            >
              Annulla
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-neutral-900 rounded-lg hover:bg-neutral-800 transition-colors shadow-sm"
            >
              <Check className="w-4 h-4" />
              <span>{initialReport ? 'Salva Modifiche' : 'Salva nel Database'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
