import React from 'react';

interface MinecraftHeartsProps {
  health?: number; // 0 to 20 typically (can be higher with absorption/health boost)
  maxHearts?: number;
}

export const MinecraftHearts: React.FC<MinecraftHeartsProps> = ({ health = 20, maxHearts = 10 }) => {
  // Each heart = 2 health points. 20 health = 10 hearts.
  // We render 10 heart containers by default.
  const totalHearts = Math.max(maxHearts, Math.ceil(health / 2));
  
  // Render array of heart states: 'full' | 'half' | 'empty'
  const hearts: ('full' | 'half' | 'empty')[] = [];
  for (let i = 0; i < totalHearts; i++) {
    const heartHealth = health - i * 2;
    if (heartHealth >= 2) {
      hearts.push('full');
    } else if (heartHealth >= 1) {
      hearts.push('half');
    } else {
      hearts.push('empty');
    }
  }

  // Display numerical value like "10" or "8.5"
  const heartCountDisplay = (Math.max(0, health) / 2).toFixed(health % 2 === 0 ? 0 : 1);

  return (
    <div className="flex items-center gap-1.5" title={`Leben: ${health} / 20 HP (${heartCountDisplay} Herzen)`}>
      <div className="flex items-center -space-x-0.5">
        {hearts.slice(0, 10).map((type, idx) => (
          <svg
            key={idx}
            viewBox="0 0 9 9"
            className="w-3.5 h-3.5 pixelated drop-shadow-xs shrink-0"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Dark border container of Minecraft heart */}
            <path
              d="M2 1h2v1H2V1zm3 0h2v1H5V1zM1 2h1v3H1V2zm7 0h1v3H8V2zM2 5h1v1H2V5zm5 0h1v1H7V5zm-4 1h1v1H3V6zm3 0h1v1H6V6zm-2 1h2v1H4V7z"
              fill="#18181b"
            />
            {/* Heart Background (Dark red/empty placeholder) */}
            <path
              d="M2 2h2v1H2V2zm3 0h2v1H5V2zM2 3h5v2H2V3zm1 2h3v1H3V5zm1 1h1v1H4V6z"
              fill="#3f0e0e"
            />

            {/* Full or Half Red Fill */}
            {type === 'full' && (
              <>
                {/* Main red body */}
                <path
                  d="M2 2h2v1H2V2zm3 0h2v1H5V2zM2 3h5v2H2V3zm1 2h3v1H3V5zm1 1h1v1H4V6z"
                  fill="#e11d48"
                />
                {/* Specular highlight (white pixel top-left) */}
                <rect x="2" y="2" width="1" height="1" fill="#ffffff" opacity="0.9" />
                {/* Darker red shadow on right & bottom */}
                <path
                  d="M6 3h1v2H6V3zm-1 2h1v1H5V5zm-1 1h1v1H4V6z"
                  fill="#9f1239"
                />
              </>
            )}

            {type === 'half' && (
              <>
                {/* Half red body (left side) */}
                <path
                  d="M2 2h2v1H2V2zM2 3h2v2H2V3zm1 2h1v1H3V5zm1 1h0v1H4V6z"
                  fill="#e11d48"
                />
                {/* Specular highlight */}
                <rect x="2" y="2" width="1" height="1" fill="#ffffff" opacity="0.9" />
                {/* Darker red edge */}
                <path
                  d="M4 3h1v2H4V3zm0 2h1v1H4V5z"
                  fill="#9f1239"
                />
              </>
            )}
          </svg>
        ))}
      </div>
      <span className="text-[11px] font-mono font-medium text-rose-300 ml-0.5 leading-none">
        {heartCountDisplay}
      </span>
    </div>
  );
};
