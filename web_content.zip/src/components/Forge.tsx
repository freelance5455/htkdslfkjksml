import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import JSZip from "jszip";
import type { Build, GameConfig, YunoModel } from "../lib/models";
import { GENRE_META, detectGenre, titleFromPrompt } from "../lib/models";
import { buildExportHtml, downloadBlob, downloadText, paletteFromFile, projectFiles, slugify, ENGINE_BODY } from "../lib/engine";
import GamePlayer from "./GamePlayer";
import { useReveal } from "../lib/hooks";
import {
  IconArrowRight, IconCheck, IconDownload, IconArchive, IconFlame, IconImage,
  IconX, IconFileCode, IconTerminal, IconEye, IconTrash, IconSpark, IconGamepad,
} from "./Icons";

interface Props {
  model: YunoModel;
  prefill: { text: string; nonce: number } | null;
  onBuilt: (b: Build) => void;
  onUpdateThumb: (id: string, thumb: string) => void;
  toast: (msg: string, kind?: "ok" | "warn") => void;
}

interface RefImg {
  id: string;
  name: string;
  url: string;
  paletteSource: boolean;
}

type Phase = "idle" | "running" | "ready";
const uid = () => Math.random().toString(36).slice(2, 10);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const EXAMPLES = [
  "space shooter where asteroids split in two, called Starforge",
  "a neon snake that speeds up every time it eats",
  "breakout with unbreakable gold bricks on top",
  "endless runner leaping over a lava canyon",
  "midnight highway racer dodging slow traffic",
  "dodge a meteor storm for as long as you can",
];

const CODE_LINES = [
  "const world = new Yuno.World({ seed: 8241, chaos: CHAOS });",
  "world.system('physics', { gravity: 900, drag: 0.02 });",
  "const player = world.spawn(new Player({ hue: 'PALETTE' }));",
  "player.on('hit', (e) => Particles.burst(e.at, 24));",
  "world.system('spawner', every(0.6 / chaos, () => spawnEnemy()));",
  "input.bind(['ArrowLeft', 'a'], () => player.steer(-1));",
  "input.bind(' ', () => player.fire({ speed: 380 }));",
  "render.pipeline([Starfield, Entities, HUD.score()]);",
  "world.run(document.getElementById('game'));",
];

const DIFFS = [
  { id: "chill", label: "CHILL", mul: 0.78 },
  { id: "normal", label: "NORMAL", mul: 1 },
  { id: "chaos", label: "CHAOS", mul: 1.32 },
];

const DEFAULT_COLORS: GameConfig["colors"] = {
  bg: "#0b0e13", player: "#ffb454", enemy: "#ff5d73", accent: "#2fe6c8", glow: "#ff7a2f",
};

export default function Forge({ model, prefill, onBuilt, onUpdateThumb, toast }: Props) {
  const [step, setStep] = useState(0);
  const [idea, setIdea] = useState("");
  const [creativity, setCreativity] = useState(60);
  const [diff, setDiff] = useState("normal");
  const [imgs, setImgs] = useState<RefImg[]>([]);
  const [palette, setPalette] = useState<{ colors: GameConfig["colors"]; swatches: string[] } | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<{ t: string; c: string }[]>([]);
  const [codeCount, setCodeCount] = useState(0);
  const [config, setConfig] = useState<GameConfig | null>(null);
  const [elapsed, setElapsed] = useState(0);

  const cancelRef = useRef(false);
  const logBoxRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const dragRef = useRef(0);
  const [dragging, setDragging] = useState(false);
  const headRef = useReveal<HTMLDivElement>();
  const bodyRef = useReveal<HTMLDivElement>();

  useEffect(() => {
    if (prefill) {
      setIdea(prefill.text);
      setStep(0);
      setPhase("idle");
    }
  }, [prefill]);

  useEffect(() => {
    const el = logBoxRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs]);

  const genre = useMemo(() => detectGenre(idea), [idea]);
  const diffMul = DIFFS.find((d) => d.id === diff)?.mul ?? 1;

  const addFiles = useCallback(async (files: FileList | File[]) => {
    const list = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (!list.length) return;
    const added: RefImg[] = list.map((f) => ({
      id: uid(),
      name: f.name,
      url: URL.createObjectURL(f),
      paletteSource: false,
    }));
    setImgs((prev) => [...prev, ...added].slice(0, 6));
    const pal = await paletteFromFile(list[0]);
    setPalette(pal);
    setImgs((prev) => prev.map((im, i2) => ({ ...im, paletteSource: prev.findIndex((x) => x.id === added[0].id) === i2 })));
    toast("Palette extracted from reference — " + pal.swatches.slice(0, 3).join(" · "), "ok");
  }, [toast]);

  const removeImg = (id: string) => {
    setImgs((prev) => {
      const target = prev.find((p) => p.id === id);
      if (target) URL.revokeObjectURL(target.url);
      const next = prev.filter((p) => p.id !== id);
      if (target?.paletteSource) setPalette(null);
      return next;
    });
  };

  const runForge = async () => {
    if (!idea.trim()) {
      toast("Give Yuno at least a few words to dream with", "warn");
      return;
    }
    cancelRef.current = false;
    setPhase("running");
    setProgress(0);
    setLogs([]);
    setCodeCount(0);
    const t0 = performance.now();
    const g = detectGenre(idea);
    const tokens = 340 + Math.floor(idea.length * 2.4) + Math.floor(creativity * 6);

    const events: { at: number; t: string; c: string }[] = [
      { at: 1, t: "yuno-core v2.4.1 — wasm backend: ready", c: "ok" },
      { at: 5, t: "memory pool 2048MB allocated on device:0", c: "info" },
      { at: 10, t: "seed rolled: 0x" + Math.floor(Math.random() * 0xffff).toString(16) + " — chaos " + creativity + "%", c: "info" },
      { at: 13, t: "loading " + model.name + " " + model.params + " (" + model.quant + ") from local cache", c: "info" },
      { at: 18, t: "shard 1/3 tensors ........ ok", c: "ok" },
      { at: 24, t: "shard 2/3 tensors ........ ok", c: "ok" },
      { at: 30, t: "shard 3/3 tensors ........ ok", c: "ok" },
      { at: 33, t: "kv-cache warmed — projecting " + model.tokPerSec + " tok/s", c: "info" },
      { at: 36, t: "encoding prompt: " + tokens + " tokens", c: "info" },
      { at: 42, t: "genre classifier → " + GENRE_META[g].label + " (conf 0.97)", c: "ok" },
      { at: 46, t: "sampling scene graph …", c: "info" },
      { at: 51, t: "root > world > player > spawner — 4 nodes", c: "info" },
      { at: 56, t: "systems wired: physics, input, particles, audio-synth", c: "ok" },
      { at: 62, t: "entities materialized × " + (8 + Math.floor(Math.random() * 20)), c: "info" },
      { at: 68, t: "balancing difficulty curve — " + diff.toUpperCase() + " × " + creativity + "% creativity", c: "info" },
      { at: 75, t: palette ? "baking palette from reference image … ok" : "applying yuno default palette", c: "ok" },
      { at: 82, t: "generation complete — " + tokens + " tokens in " + (tokens / model.tokPerSec).toFixed(1) + "s", c: "ok" },
      { at: 85, t: "esbuild-wasm: bundling 0 errors / 0 warnings", c: "ok" },
      { at: 90, t: "minified: " + Math.round(ENGINE_BODY.length / 1024 + 4) + " KB single file", c: "info" },
      { at: 95, t: "packaging index.html + config.json + README.md", c: "info" },
      { at: 100, t: "FORGE COMPLETE — your game is live below", c: "done" },
    ];

    let p = 0;
    let evIdx = 0;
    while (p < 100) {
      if (cancelRef.current) {
        setPhase("idle");
        setLogs((l) => [...l, { t: "forge aborted by operator", c: "warn" }]);
        return;
      }
      p = Math.min(100, p + 0.7 + Math.random() * 1.5);
      setProgress(p);
      while (evIdx < events.length && events[evIdx].at <= p) {
        const ev = events[evIdx++];
        setLogs((l) => [...l, { t: ev.t, c: ev.c }]);
      }
      setCodeCount(Math.floor((p / 100) * CODE_LINES.length));
      setElapsed((performance.now() - t0) / 1000);
      await sleep(55 + Math.random() * 45);
    }

    const cfg: GameConfig = {
      id: uid(),
      title: titleFromPrompt(idea, g),
      type: g,
      prompt: idea.trim(),
      speed: +(diffMul * (0.85 + creativity / 250)).toFixed(2),
      colors: palette ? palette.colors : DEFAULT_COLORS,
    };
    setConfig(cfg);
    setPhase("ready");
    setElapsed((performance.now() - t0) / 1000);
    const build: Build = {
      id: cfg.id,
      title: cfg.title,
      genre: GENRE_META[g].label,
      modelId: model.id,
      modelName: model.name + " " + model.params,
      date: Date.now(),
      config: cfg,
    };
    onBuilt(build);
    toast(build.title + " forged and saved to your Arcade", "ok");
  };

  const doZip = async () => {
    if (!config) return;
    const zip = new JSZip();
    for (const f of projectFiles(config)) zip.file(f.path, f.content);
    const blob = await zip.generateAsync({ type: "blob" });
    downloadBlob(slugify(config.title) + "-yuno-project.zip", blob);
    toast("Project zip downloaded — unzip, open index.html, play", "ok");
  };

  const steps = ["IDEA", "REFERENCE", "FORGE"];

  return (
    <section id="forge" className="relative py-24 border-t border-line/60">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_45%_at_50%_0%,rgba(255,122,47,0.07),transparent)] pointer-events-none" />
      <div className="mx-auto max-w-7xl px-5 relative">
        <div ref={headRef} className="reveal flex flex-wrap items-end justify-between gap-6 mb-10">
          <div>
            <p className="font-mono text-[11px] tracking-[0.3em] text-ember mb-3">// 02 — THE FORGE</p>
            <h2 className="font-display font-bold text-[clamp(1.6rem,3.4vw,2.5rem)] text-snow leading-tight">
              Describe it. Yuno builds it.<br />
              <span className="text-fog text-[0.62em] font-medium">Idea in — playable file out.</span>
            </h2>
          </div>
          <div className="border border-line bg-panel clip-hud-sm px-4 py-3 flex items-center gap-3">
            <IconGamepad size={16} className="text-ember" />
            <div className="font-mono text-[10.5px] leading-relaxed">
              <p className="text-fog tracking-[0.16em]">ACTIVE ENGINE</p>
              <p className="text-snow">{model.name} <span className="text-teal">{model.params}</span></p>
            </div>
            <a href="#models" className="ml-2 font-mono text-[10px] text-teal hover:text-ember transition-colors tracking-[0.12em] underline underline-offset-4">
              SWITCH
            </a>
          </div>
        </div>

        {/* step rail */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
          {steps.map((s, i) => (
            <div key={s} className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => phase !== "running" && setStep(i)}
                className={`flex items-center gap-2.5 clip-tag border px-4 h-10 font-mono text-[11px] tracking-[0.18em] transition-all ${
                  step === i
                    ? "bg-ember text-ink border-ember shadow-[0_0_24px_rgba(255,180,84,0.35)]"
                    : i < step
                      ? "border-teal/50 text-teal hover:border-teal"
                      : "border-line2 text-fog hover:text-snow"
                }`}
              >
                <span className="font-bold">{String(i + 1).padStart(2, "0")}</span> {s}
                {i < step && <IconCheck size={12} />}
              </button>
              {i < 2 && <svg width="26" height="8" viewBox="0 0 26 8" className="text-line2 shrink-0"><path d="M0 4h20m0 0-4-3.5M20 4l-4 3.5" stroke="currentColor" fill="none" /></svg>}
            </div>
          ))}
        </div>

        <div ref={bodyRef} className="reveal border border-line bg-panel/70 clip-hud backdrop-blur-sm">
          {/* ---------------- STEP 0 : IDEA ---------------- */}
          {step === 0 && (
            <div className="p-6 md:p-8">
              <label className="font-mono text-[10.5px] tracking-[0.24em] text-fog block mb-3">
                <IconSpark size={12} className="inline mr-2 text-ember" />
                YOUR GAME IDEA — PLAIN WORDS, ANY GENRE
              </label>
              <div className="relative border border-line2 bg-ink2 focus-within:border-ember/70 transition-colors clip-hud-sm">
                <textarea
                  value={idea}
                  onChange={(e) => setIdea(e.target.value)}
                  rows={4}
                  placeholder="e.g. a space shooter where asteroids split in two, called Starforge…"
                  className="w-full bg-transparent outline-none resize-none p-5 font-mono text-[14px] leading-relaxed text-snow placeholder:text-fog/50"
                />
                <div className="flex items-center justify-between border-t border-line px-4 py-2">
                  <span className="font-mono text-[9.5px] tracking-[0.18em] text-fog">{idea.length} CHARS</span>
                  <span className="font-mono text-[10px] tracking-[0.14em] flex items-center gap-2">
                    <span className="text-fog">DETECTED GENRE:</span>
                    <span className="text-teal border border-teal/40 bg-teal/8 px-2 py-0.5 clip-tag">{GENRE_META[genre].label}</span>
                  </span>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {EXAMPLES.map((ex) => (
                  <button
                    key={ex}
                    onClick={() => setIdea(ex)}
                    className="clip-tag border border-line2 text-fog text-[11.5px] px-3 py-1.5 hover:border-ember/60 hover:text-ember transition-all hover:-translate-y-0.5"
                  >
                    {ex}
                  </button>
                ))}
              </div>

              <div className="mt-7 grid md:grid-cols-2 gap-6">
                <div>
                  <div className="flex justify-between font-mono text-[10.5px] tracking-[0.2em] text-fog mb-2.5">
                    <span>CREATIVITY</span>
                    <span className="text-ember">{creativity}%</span>
                  </div>
                  <input type="range" min={0} max={100} value={creativity} onChange={(e) => setCreativity(+e.target.value)} className="w-full" />
                  <p className="mt-2 text-[11px] text-fog/80 leading-relaxed">
                    Low = faithful to your words. High = Yuno improvises enemies, juice and surprises.
                  </p>
                </div>
                <div>
                  <p className="font-mono text-[10.5px] tracking-[0.2em] text-fog mb-2.5">DIFFICULTY</p>
                  <div className="flex gap-2">
                    {DIFFS.map((d) => (
                      <button
                        key={d.id}
                        onClick={() => setDiff(d.id)}
                        className={`clip-tag flex-1 h-10 font-mono text-[10.5px] tracking-[0.16em] border transition-all ${
                          diff === d.id ? "bg-teal text-ink border-teal" : "border-line2 text-fog hover:text-snow"
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-8 flex justify-end">
                <button onClick={() => setStep(1)} className="btn-primary clip-hud px-7 py-3.5 font-mono font-bold text-[12.5px] tracking-[0.14em] inline-flex items-center gap-2.5">
                  CONTINUE TO REFERENCE <IconArrowRight size={15} />
                </button>
              </div>
            </div>
          )}

          {/* ---------------- STEP 1 : REFERENCE ---------------- */}
          {step === 1 && (
            <div className="p-6 md:p-8">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <label className="font-mono text-[10.5px] tracking-[0.24em] text-fog">
                  <IconImage size={12} className="inline mr-2 text-teal" />
                  REFERENCE IMAGES — MAKE IT LOOK LIKE THIS (OPTIONAL)
                </label>
                <span className="font-mono text-[9.5px] tracking-[0.16em] text-fog/70 border border-line px-2 py-1">READ LOCALLY — NEVER UPLOADED</span>
              </div>

              <div
                onDragEnter={(e) => { e.preventDefault(); dragRef.current++; setDragging(true); }}
                onDragLeave={(e) => { e.preventDefault(); dragRef.current--; if (dragRef.current <= 0) setDragging(false); }}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => { e.preventDefault(); dragRef.current = 0; setDragging(false); addFiles(e.dataTransfer.files); }}
                onClick={() => fileRef.current?.click()}
                className={`border-2 border-dashed clip-hud-sm cursor-pointer transition-all duration-300 p-10 text-center ${
                  dragging ? "border-teal bg-teal/8 scale-[1.01]" : "border-line2 hover:border-ember/60 hover:bg-ember/4"
                }`}
              >
                <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={(e) => e.target.files && addFiles(e.target.files)} />
                <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke={dragging ? "#2fe6c8" : "#8b93a7"} strokeWidth="1.4" className="mx-auto mb-4 transition-colors">
                  <rect x="3.5" y="4.5" width="17" height="15" rx="1.5" />
                  <circle cx="9" cy="10" r="1.7" />
                  <path d="M4.5 17.5 10 12l4 4 2.5-2.5 3 3" />
                </svg>
                <p className="text-mist text-[14px] font-medium">{dragging ? "Release to feed the forge" : "Drop images here, or click to browse"}</p>
                <p className="font-mono text-[10px] tracking-[0.16em] text-fog mt-2">YUNO EXTRACTS THE PALETTE + ART DIRECTION — UP TO 6 IMAGES</p>
              </div>

              {imgs.length > 0 && (
                <div className="mt-5 grid grid-cols-3 sm:grid-cols-6 gap-3">
                  {imgs.map((im) => (
                    <div key={im.id} className="relative group border border-line clip-tag overflow-hidden bg-ink2">
                      <img src={im.url} alt={im.name} className="w-full h-20 object-cover transition-transform duration-500 group-hover:scale-110" />
                      <button
                        onClick={(e) => { e.stopPropagation(); removeImg(im.id); }}
                        className="absolute top-1 right-1 w-5 h-5 bg-ink/90 border border-line2 text-coral flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        aria-label="Remove image"
                      >
                        <IconX size={11} />
                      </button>
                      {im.paletteSource && (
                        <span className="absolute bottom-0 inset-x-0 bg-teal/90 text-ink font-mono text-[8px] font-bold tracking-[0.14em] py-0.5">PALETTE SRC</span>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {palette && (
                <div className="mt-5 border border-teal/30 bg-teal/5 clip-hud-sm p-4 flex flex-wrap items-center gap-4">
                  <IconEye size={16} className="text-teal" />
                  <span className="font-mono text-[10.5px] tracking-[0.18em] text-teal">PALETTE EXTRACTED FROM YOUR IMAGE</span>
                  <div className="flex gap-2">
                    {palette.swatches.map((s) => (
                      <span key={s} className="flex items-center gap-1.5">
                        <span className="w-6 h-6 border border-line2" style={{ background: s }} />
                        <span className="font-mono text-[9px] text-fog uppercase">{s}</span>
                      </span>
                    ))}
                  </div>
                  <button onClick={() => setPalette(null)} className="ml-auto font-mono text-[10px] text-coral hover:underline underline-offset-4 flex items-center gap-1.5">
                    <IconTrash size={11} /> USE DEFAULT PALETTE
                  </button>
                </div>
              )}

              <div className="mt-8 flex justify-between">
                <button onClick={() => setStep(0)} className="btn-ghost clip-hud px-6 py-3.5 font-mono text-[12.5px] tracking-[0.14em]">BACK</button>
                <button onClick={() => setStep(2)} className="btn-primary clip-hud px-7 py-3.5 font-mono font-bold text-[12.5px] tracking-[0.14em] inline-flex items-center gap-2.5">
                  TO THE FORGE <IconArrowRight size={15} />
                </button>
              </div>
            </div>
          )}

          {/* ---------------- STEP 2 : FORGE ---------------- */}
          {step === 2 && phase === "idle" && (
            <div className="p-6 md:p-8">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="border border-line bg-ink2 clip-hud-sm p-5">
                  <p className="font-mono text-[10px] tracking-[0.24em] text-fog mb-4">BUILD SUMMARY</p>
                  {[
                    ["PROMPT", idea.trim() || "—"],
                    ["GENRE", GENRE_META[genre].label],
                    ["ENGINE", model.name + " " + model.params + " · " + model.quant],
                    ["CHAOS", creativity + "% creativity · " + diff.toUpperCase()],
                    ["PALETTE", palette ? "from reference image" : "yuno default"],
                    ["OUTPUT", "single HTML + project zip"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex gap-4 py-2 border-b border-line/60 last:border-0">
                      <span className="font-mono text-[10px] tracking-[0.18em] text-fog w-20 shrink-0 pt-0.5">{k}</span>
                      <span className="font-mono text-[12px] text-mist leading-relaxed break-words">{v}</span>
                    </div>
                  ))}
                  {palette && (
                    <div className="flex gap-1.5 mt-4">
                      {palette.swatches.map((s) => <span key={s} className="h-3 flex-1" style={{ background: s }} />)}
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-center justify-center text-center border border-ember/25 bg-[radial-gradient(ellipse_at_center,rgba(255,122,47,0.09),transparent_70%)] clip-hud-sm p-8">
                  <IconFlame size={40} className="text-ember glow-breathe mb-5" />
                  <p className="text-mist text-[14px] max-w-xs leading-relaxed mb-6">
                    Everything runs <span className="text-teal">on this device</span>. You can unplug right now — the forge does not care.
                  </p>
                  <button onClick={runForge} className="btn-primary clip-hud px-10 py-4 font-mono font-bold text-[14px] tracking-[0.18em] inline-flex items-center gap-3">
                    <IconFlame size={18} /> IGNITE FORGE
                  </button>
                  <p className="mt-4 font-mono text-[9.5px] tracking-[0.16em] text-fog">EST. {((340 + idea.length * 2.4 + creativity * 6) / model.tokPerSec).toFixed(1)}s OF INFERENCE</p>
                </div>
              </div>
            </div>
          )}

          {/* ---------------- RUNNING ---------------- */}
          {step === 2 && phase === "running" && (
            <div className="p-6 md:p-8">
              <div className="flex items-center justify-between mb-5">
                <p className="font-display font-bold text-snow text-[15px] flex items-center gap-3">
                  <IconFlame size={18} className="text-ember glow-breathe" /> FORGING "{titleFromPrompt(idea, genre).toUpperCase()}"
                </p>
                <button onClick={() => { cancelRef.current = true; }} className="btn-ghost clip-tag px-4 h-9 font-mono text-[10px] tracking-[0.16em]">ABORT</button>
              </div>

              <div className="h-3 bg-ink2 border border-line relative overflow-hidden mb-1.5">
                <div className="absolute inset-y-0 left-0 bg-gradient-to-r from-blaze via-ember to-teal stripes transition-[width] duration-150" style={{ width: progress + "%" }} />
              </div>
              <div className="flex justify-between font-mono text-[10px] tracking-[0.18em] text-fog mb-6">
                <span>{progress < 34 ? "LOADING " + model.name.toUpperCase() : progress < 82 ? "GENERATING GAME" : "COMPILING + PACKAGING"}</span>
                <span className="text-ember">{Math.floor(progress)}%</span>
              </div>

              <div className="grid lg:grid-cols-2 gap-4">
                <div className="border border-line bg-ink2 clip-hud-sm overflow-hidden">
                  <div className="flex items-center gap-2 px-4 h-9 border-b border-line">
                    <IconTerminal size={13} className="text-teal" />
                    <span className="font-mono text-[10px] tracking-[0.2em] text-fog">FORGE LOG</span>
                    <span className="ml-auto w-1.5 h-1.5 rounded-full bg-ember pulse-dot-ember" />
                  </div>
                  <div ref={logBoxRef} className="terminal-log h-64 overflow-y-auto px-4 py-3 font-mono text-[11px] leading-[1.9]">
                    {logs.map((l, i) => (
                      <div key={i} className={l.c === "ok" ? "text-teal" : l.c === "warn" ? "text-coral" : l.c === "done" ? "text-ember font-bold" : "text-fog"}>
                        <span className="text-line2 select-none">{String(i).padStart(2, "0")} </span>
                        {l.c === "ok" ? "[ok] " : l.c === "warn" ? "[!!] " : "> "}{l.t}
                      </div>
                    ))}
                    <div className="text-ember"><span className="caret">▍</span></div>
                  </div>
                </div>

                <div className="border border-line bg-ink2 clip-hud-sm overflow-hidden">
                  <div className="flex items-center gap-2 px-4 h-9 border-b border-line">
                    <IconFileCode size={13} className="text-ember" />
                    <span className="font-mono text-[10px] tracking-[0.2em] text-fog">EMITTED CODE — LIVE</span>
                  </div>
                  <div className="h-64 overflow-hidden px-4 py-3 font-mono text-[11px] leading-[2]">
                    {CODE_LINES.slice(0, Math.max(codeCount, 1)).map((l, i) => (
                      <div key={i} className="text-mist/90 whitespace-nowrap overflow-hidden">
                        <span className="text-line2 select-none">{String(i + 1).padStart(2, "0")} </span>
                        {l.replace("CHAOS", String(creativity)).replace("PALETTE", palette ? palette.swatches[0] : "#ffb454")}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ---------------- READY ---------------- */}
          {step === 2 && phase === "ready" && config && (
            <div className="p-6 md:p-8">
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <span className="relative flex w-11 h-11 items-center justify-center">
                  <span className="absolute inset-0 border-2 border-teal rounded-full burst-ring" />
                  <span className="w-11 h-11 bg-teal/12 border border-teal/60 flex items-center justify-center text-teal clip-tag">
                    <IconCheck size={20} />
                  </span>
                </span>
                <div>
                  <p className="font-display font-bold text-[19px] text-snow leading-none">"{config.title}" IS READY</p>
                  <p className="font-mono text-[10.5px] tracking-[0.16em] text-fog mt-1.5">
                    FORGED IN {elapsed.toFixed(1)}s · {GENRE_META[config.type].label} · {model.name.toUpperCase()} · SAVED TO ARCADE
                  </p>
                </div>
                <div className="ml-auto flex gap-1.5">
                  {Object.values(config.colors).filter((_c, i2) => i2 > 0).map((c) => (
                    <span key={c} className="w-5 h-8 border border-line2" style={{ background: c }} />
                  ))}
                </div>
              </div>

              <div className="border border-line2 bg-panel clip-hud shadow-[0_20px_70px_rgba(0,0,0,0.5)]">
                <div className="flex items-center gap-2 px-4 h-10 border-b border-line">
                  <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ff5d73" /></svg>
                  <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ffb454" /></svg>
                  <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#2fe6c8" /></svg>
                  <span className="ml-2 font-mono text-[10px] tracking-[0.18em] text-fog">yuno://play/{config.id}</span>
                  <span className="ml-auto font-mono text-[9px] tracking-[0.2em] text-teal border border-teal/40 px-2 py-0.5">PLAYABLE NOW</span>
                </div>
                <GamePlayer
                  config={config}
                  onThumb={(t) => onUpdateThumb(config.id, t)}
                />
                <div className="px-4 py-3 border-t border-line flex items-center justify-between gap-3 flex-wrap">
                  <span className="font-mono text-[10px] tracking-[0.14em] text-fog">CLICK TO START · ARROWS/WASD MOVE · SPACE FIRE/JUMP · P PAUSE</span>
                  <div className="flex items-center gap-1.5 font-mono text-[10px] text-teal">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal pulse-dot" /> HI-SCORES SAVED LOCALLY
                  </div>
                </div>
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                <button
                  onClick={() => { downloadText(slugify(config.title) + ".html", buildExportHtml(config)); toast("Single-file HTML downloaded — double-click to play anywhere", "ok"); }}
                  className="btn-primary clip-hud px-6 py-3.5 font-mono font-bold text-[12px] tracking-[0.14em] inline-flex items-center gap-2.5"
                >
                  <IconDownload size={15} /> DOWNLOAD .HTML
                </button>
                <button onClick={doZip} className="btn-ghost clip-hud px-6 py-3.5 font-mono text-[12px] tracking-[0.14em] inline-flex items-center gap-2.5">
                  <IconArchive size={15} /> DOWNLOAD PROJECT .ZIP
                </button>
                <button
                  onClick={() => { setPhase("idle"); setStep(0); setIdea(""); setImgs([]); setPalette(null); setConfig(null); }}
                  className="btn-ghost clip-hud px-6 py-3.5 font-mono text-[12px] tracking-[0.14em] inline-flex items-center gap-2.5"
                >
                  <IconFlame size={15} /> FORGE ANOTHER
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
