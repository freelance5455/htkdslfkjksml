import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, SpeechLanguageCode, SpeechLanguageOption, SpeechRecognitionState } from '../types';
import { sendChatMessage, checkServerStatus } from '../services/geminiService';
import { voiceService } from '../services/voiceService';
import { 
  Send, 
  Sparkles, 
  Trash2, 
  User, 
  Globe,
  Cpu,
  RefreshCw,
  ExternalLink,
  Mic,
  MicOff,
  Square,
  AlertCircle,
  Loader2,
  Check,
  ChevronUp
} from 'lucide-react';

interface ChatPanelProps {
  onOpenCharacterStudio?: () => void;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'intro-1',
    sender: '002',
    text: "Hey Darling! 002 neural interface initialized with Gemini 3.8 Flash. I'm connected to your cockpit! How are you doing today? Aap mujhse Hindi, Hinglish, ya English kisi mein bhi baat kar sakte ho!",
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  },
];

const QUICK_SUGGESTIONS = [
  { label: "Kya kar rahi ho, Darling? 💕", text: "Kya kar rahi ho, Darling? Aaj ka din kaisa hai?" },
  { label: "आप कैसी हैं 002? ✨", text: "आप कैसी हैं 002? क्या आप मेरे साथ बात कर सकती हैं?" },
  { label: "What is our sync rate today? 🚀", text: "What is our sync rate today, Darling?" },
  { label: "Mujhe ek sweet dialogue bolo! 🍯", text: "Mujhe ek sweet anime dialogue bolo na Darling!" },
  { label: "Tell me about yourself! 🌸", text: "Tell me about your personality and your mecha, 002!" },
];

const SPEECH_LANGUAGES: SpeechLanguageOption[] = [
  { code: 'en-IN', label: 'Hinglish / Indian English', dialect: 'Hinglish', badge: 'HINGLISH' },
  { code: 'hi-IN', label: 'Hindi (हिंदी)', dialect: 'Hindi', badge: 'हिंदी' },
  { code: 'en-US', label: 'English (US)', dialect: 'English', badge: 'EN' },
];

export const ChatPanel: React.FC<ChatPanelProps> = ({ onOpenCharacterStudio }) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('002_chat_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch {
        return INITIAL_MESSAGES;
      }
    }
    return INITIAL_MESSAGES;
  });

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [showQuotaBanner, setShowQuotaBanner] = useState(true);

  // Speech Recognition States
  const [selectedSpeechLang, setSelectedSpeechLang] = useState<SpeechLanguageCode>('en-IN');
  const [micState, setMicState] = useState<SpeechRecognitionState>('idle');
  const [micErrorDetail, setMicErrorDetail] = useState<string | null>(null);
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [showLangMenu, setShowLangMenu] = useState(false);

  const [serverMeta, setServerMeta] = useState<{
    status: string;
    model?: string;
    hasGeminiKey: boolean;
    isQuotaExhausted?: boolean;
  }>({
    status: 'checking',
    model: 'gemini-3.8-flash',
    hasGeminiKey: false,
    isQuotaExhausted: false,
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll chat to latest message
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
    try {
      localStorage.setItem('002_chat_history', JSON.stringify(messages));
    } catch {}
  }, [messages, loading]);

  // Clean up speech recognition when navigating away
  useEffect(() => {
    return () => {
      voiceService.stopListening();
    };
  }, []);

  // Check server status & gemini key presence
  const refreshStatus = () => {
    checkServerStatus().then(res => {
      setServerMeta({
        status: res.status,
        model: res.model || 'gemini-3.8-flash',
        hasGeminiKey: res.hasGeminiKey,
        isQuotaExhausted: res.isQuotaExhausted,
      });
      if (res.isQuotaExhausted) {
        setQuotaExceeded(true);
      }
    });
  };

  useEffect(() => {
    refreshStatus();
  }, []);

  // Handle Speech Recognition Toggle
  const handleToggleMic = async () => {
    if (micState === 'listening' || micState === 'requesting_permission') {
      voiceService.stopListening();
      setMicState('idle');
      setInterimTranscript('');
      inputRef.current?.focus();
      return;
    }

    setMicErrorDetail(null);
    setInterimTranscript('');

    const success = await voiceService.startListening({
      lang: selectedSpeechLang,
      continuous: false,
      onStateChange: (state, detail) => {
        setMicState(state);
        if (detail) setMicErrorDetail(detail);
      },
      onInterimTranscript: (interim) => {
        setInterimTranscript(interim);
      },
      onFinalTranscript: (finalText) => {
        setInterimTranscript('');
        // Append recognized speech to input field for manual user review
        setInput((prev) => {
          const trimmed = prev.trim();
          return trimmed ? `${trimmed} ${finalText}` : finalText;
        });
        // CRITICAL: DO NOT AUTO-SEND. The user reviews and sends manually.
      },
      onError: (state, errorMsg) => {
        setMicState(state);
        setMicErrorDetail(errorMsg);
        setInterimTranscript('');
      },
      onEnd: () => {
        setMicState('idle');
        setInterimTranscript('');
        inputRef.current?.focus();
      },
    });

    if (!success) {
      console.warn('[002 Chat] Speech recognition did not start');
    }
  };

  const handleStopListening = () => {
    voiceService.stopListening();
    setMicState('idle');
    setInterimTranscript('');
    inputRef.current?.focus();
  };

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInput('');
    setLoading(true);

    try {
      const result = await sendChatMessage(query, newHistory);

      if (result.isQuota) {
        setQuotaExceeded(true);
      }
      
      const companionReply: ChatMessage = {
        id: `002-${Date.now()}`,
        sender: '002',
        text: result.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, companionReply]);
    } catch (err: any) {
      console.warn('Companion chat fallback:', err);
      const errorReply: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: '002',
        text: "Darling! My neural link wavered for a moment, but I'm still right here beside you. Tell me what's on your mind!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, errorReply]);
    } finally {
      setLoading(false);
      // Keep focus on input for fast mobile/desktop typing
      inputRef.current?.focus();
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  const clearChat = () => {
    setMessages(INITIAL_MESSAGES);
    localStorage.removeItem('002_chat_history');
  };

  return (
    <div className="flex flex-col h-full bg-[#080812] select-text">
      {/* Top Header Bar */}
      <div className="px-4 py-3 bg-[#0d0d1b]/95 border-b border-[#ff2d78]/25 flex items-center justify-between backdrop-blur-md shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#ff2d78] to-[#9333ea] p-0.5 shadow-[0_0_12px_rgba(255,45,120,0.5)]">
              <div className="w-full h-full rounded-full bg-[#0d0d1a] flex items-center justify-center">
                <span className="font-cyber font-bold text-xs text-[#ff2d78]">02</span>
              </div>
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#0d0d1b]" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-cyber font-bold text-sm tracking-wide text-white">002 NEURAL CHAT</h2>
              <span className={`text-[9px] px-2 py-0.5 rounded font-mono-code uppercase font-semibold flex items-center gap-1 ${
                quotaExceeded
                  ? 'bg-amber-950/70 text-amber-300 border border-amber-500/40'
                  : serverMeta.hasGeminiKey 
                    ? 'bg-purple-950/70 text-purple-300 border border-purple-500/40' 
                    : 'bg-pink-950/70 text-[#ff70a6] border border-pink-500/40'
              }`}>
                <Cpu className="w-2.5 h-2.5 text-[#ff2d78]" />
                {quotaExceeded ? 'Gemini 3.8 Standby' : serverMeta.hasGeminiKey ? 'Gemini 3.8 Flash' : 'Gemini 3.8 Core'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono-code">
              <span className="text-emerald-400">Pilot Link: STABLE</span>
              <span>•</span>
              <span className="text-[#c084fc] flex items-center gap-1">
                <Globe className="w-3 h-3" />
                Hindi • Hinglish • English
              </span>
            </div>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1.5">
          {onOpenCharacterStudio && (
            <button
              onClick={onOpenCharacterStudio}
              className="px-2.5 py-1.5 rounded-xl bg-[#141426] hover:bg-[#1e1e36] border border-slate-800 hover:border-[#ff2d78]/40 text-slate-300 hover:text-white text-xs font-cyber flex items-center gap-1 transition-all"
              title="View 3D Character Studio"
            >
              <span className="hidden sm:inline">3D Studio</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#ff2d78]" />
            </button>
          )}

          <button
            onClick={clearChat}
            className="p-2 rounded-xl bg-[#151525] hover:bg-[#202035] border border-slate-800 text-slate-400 hover:text-slate-200 text-xs transition-colors"
            title="Reset Chat History"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Quota Exhaustion Notice Banner */}
      {quotaExceeded && showQuotaBanner && (
        <div className="mx-3 mt-2 mb-1 p-2.5 rounded-xl bg-[#1f102a]/95 border border-[#ff2d78]/40 text-xs text-slate-200 flex items-start justify-between gap-2 shadow-lg backdrop-blur-md shrink-0">
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-[#ff2d78] shrink-0 mt-0.5" />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-cyber font-bold text-white text-[11px] tracking-wide">
                  GEMINI 3.8 FLASH FREE-TIER QUOTA REACHED
                </span>
                <span className="text-[9px] font-mono-code px-1.5 py-0.5 rounded bg-pink-950 text-[#ff70a6] border border-pink-500/30">
                  20 REQ / DAY
                </span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed mt-1">
                002 is operating on her <strong>Standby Neural Core</strong> with in-character responses in Hindi, Hinglish, and English! To unlock unlimited live cloud AI, select a billing-enabled API key in the <strong>Settings &gt; Secrets</strong> panel.
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowQuotaBanner(false)}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 shrink-0 text-xs"
            title="Dismiss notification"
          >
            ✕
          </button>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 cyber-grid-bg">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 max-w-[92%] sm:max-w-[80%] ${
                isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'
              }`}
            >
              {/* Avatar Icon */}
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-cyber ${
                  isUser 
                    ? 'bg-gradient-to-tr from-[#9333ea] to-indigo-600 text-white shadow-[0_0_8px_rgba(147,51,234,0.4)]' 
                    : 'bg-gradient-to-tr from-[#ff2d78] to-rose-700 text-white shadow-[0_0_8px_rgba(255,45,120,0.4)]'
                }`}
              >
                {isUser ? <User className="w-3.5 h-3.5" /> : '02'}
              </div>

              {/* Message Bubble */}
              <div className="space-y-1">
                <div
                  className={`p-3.5 rounded-2xl text-sm leading-relaxed ${
                    isUser
                      ? 'bg-gradient-to-br from-[#1e1035] to-[#271040] border border-[#9333ea]/40 text-slate-100 rounded-tr-none'
                      : 'bg-[#121222]/95 border border-[#ff2d78]/30 text-slate-100 rounded-tl-none shadow-md shadow-black/40'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                </div>
                <div
                  className={`text-[10px] text-slate-500 font-mono-code px-1 ${
                    isUser ? 'text-right' : 'text-left'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {/* Companion Thinking / Loading State */}
        {loading && (
          <div className="flex items-start gap-2.5 max-w-[80%] mr-auto">
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#ff2d78] to-rose-700 text-white flex items-center justify-center shrink-0 text-xs font-cyber shadow-[0_0_8px_rgba(255,45,120,0.4)]">
              02
            </div>
            <div className="p-3.5 rounded-2xl rounded-tl-none bg-[#121222]/95 border border-[#ff2d78]/30 flex items-center gap-3 text-slate-300">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#ff2d78] animate-bounce [animation-delay:-0.3s]" />
                <span className="w-2 h-2 rounded-full bg-[#c084fc] animate-bounce [animation-delay:-0.15s]" />
                <span className="w-2 h-2 rounded-full bg-[#ff2d78] animate-bounce" />
              </div>
              <span className="text-xs text-[#ff70a6] font-cyber tracking-wider">
                002 is thinking with Gemini 3.8 Flash...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Multilingual Quick Suggestions Chips */}
      <div className="px-4 py-2 border-t border-slate-800/80 bg-[#0a0a14]/90 overflow-x-auto flex items-center gap-2 shrink-0 no-scrollbar">
        <Sparkles className="w-3.5 h-3.5 text-[#ff2d78] shrink-0" />
        <span className="text-[10px] text-slate-400 font-mono-code shrink-0">Try asking:</span>
        {QUICK_SUGGESTIONS.map((s, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(s.text)}
            disabled={loading}
            className="shrink-0 bg-[#16162a] hover:bg-[#20203a] border border-slate-800 hover:border-[#ff2d78]/40 disabled:opacity-50 text-slate-300 hover:text-white text-xs px-2.5 py-1 rounded-full transition-all active:scale-95 whitespace-nowrap"
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Input Field & Send Controls */}
      <div className="p-3 bg-[#0d0d1b] border-t border-[#ff2d78]/20 shrink-0">
        {/* State Banner: Listening */}
        {micState === 'listening' && (
          <div className="mb-2 px-3 py-2 rounded-xl bg-[#1d0e2e]/95 border border-[#ff2d78]/50 text-xs text-slate-200 flex items-center justify-between shadow-lg backdrop-blur-md animate-in fade-in">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#ff2d78] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              <div>
                <span className="font-cyber font-bold text-[#ff70a6] text-[11px] tracking-wide block">
                  LISTENING ({selectedSpeechLang === 'hi-IN' ? 'HINDI' : selectedSpeechLang === 'en-IN' ? 'HINGLISH' : 'ENGLISH'})
                </span>
                <span className="text-slate-400 text-[10px]">
                  Speak now. Words will appear in the chat input for your review before sending.
                </span>
              </div>
            </div>
            <button
              onClick={handleStopListening}
              className="px-2.5 py-1 rounded-lg bg-[#2e1035] hover:bg-[#401548] border border-[#ff2d78]/50 text-[#ff70a6] hover:text-white text-[11px] font-cyber flex items-center gap-1 transition-all shrink-0 ml-2 shadow-sm"
              title="Stop listening and review input"
            >
              <Square className="w-2.5 h-2.5 fill-current" />
              <span>Done</span>
            </button>
          </div>
        )}

        {/* State Banner: Permission Denied */}
        {micState === 'permission_denied' && (
          <div className="mb-2 px-3 py-2 rounded-xl bg-rose-950/90 border border-rose-500/60 text-xs text-rose-200 flex items-center justify-between shadow-lg backdrop-blur-md animate-in fade-in">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-cyber font-bold text-white text-[11px] block">
                  MICROPHONE PERMISSION BLOCKED
                </span>
                <p className="text-[11px] text-rose-200 mt-0.5 leading-tight">
                  Microphone access was denied. Click the lock/tune icon in your browser URL bar to allow microphone permissions.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0 ml-2">
              <button
                onClick={handleToggleMic}
                className="px-2.5 py-1 rounded-lg bg-rose-900 hover:bg-rose-800 border border-rose-400 text-white text-[10px] font-cyber transition-all"
              >
                Retry
              </button>
              <button
                onClick={() => setMicState('idle')}
                className="p-1 rounded-lg hover:bg-rose-900/50 text-rose-400 hover:text-white text-xs"
                title="Dismiss"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* State Banner: Unsupported Browser */}
        {micState === 'unsupported' && (
          <div className="mb-2 px-3 py-2 rounded-xl bg-slate-900/95 border border-slate-700 text-xs text-slate-300 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-2">
              <MicOff className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="text-[11px]">
                Speech recognition is not supported in this browser engine. Please type your message or use Chrome/Edge/Safari.
              </span>
            </div>
            <button
              onClick={() => setMicState('idle')}
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white text-xs ml-2"
              title="Dismiss"
            >
              ✕
            </button>
          </div>
        )}

        {/* State Banner: Error */}
        {micState === 'error' && micErrorDetail && (
          <div className="mb-2 px-3 py-2 rounded-xl bg-amber-950/90 border border-amber-500/50 text-xs text-amber-200 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="text-[11px]">{micErrorDetail}</span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0 ml-2">
              <button
                onClick={handleToggleMic}
                className="px-2.5 py-1 rounded-lg bg-amber-900 hover:bg-amber-800 border border-amber-400 text-white text-[10px] font-cyber transition-all"
              >
                Retry
              </button>
              <button
                onClick={() => setMicState('idle')}
                className="p-1 rounded-lg hover:bg-amber-900/50 text-amber-400 hover:text-white text-xs"
                title="Dismiss"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Interim Speech Live Preview */}
        {interimTranscript && (
          <div className="mb-2 px-3 py-1.5 rounded-lg bg-[#1a0e28] border border-[#ff2d78]/30 flex items-center gap-2 text-xs text-[#ff70a6] animate-pulse">
            <span className="w-2 h-2 rounded-full bg-[#ff2d78] animate-ping shrink-0" />
            <span className="font-mono-code truncate">Hearing: "{interimTranscript}..."</span>
          </div>
        )}

        {/* Main Input Row */}
        <div className="flex items-center gap-1.5 sm:gap-2 relative">
          {/* Text Input */}
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            disabled={loading}
            placeholder={
              micState === 'listening'
                ? `Listening in ${selectedSpeechLang === 'hi-IN' ? 'Hindi' : selectedSpeechLang === 'en-IN' ? 'Hinglish' : 'English'}... Speak now`
                : "Talk to 002 in English, Hindi, or Hinglish..."
            }
            className={`flex-1 bg-[#141424] border rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none transition-all disabled:opacity-60 ${
              micState === 'listening'
                ? 'border-[#ff2d78] shadow-[0_0_12px_rgba(255,45,120,0.3)] bg-[#1a102a]'
                : 'border-slate-800 focus:border-[#ff2d78]'
            }`}
          />

          {/* Voice Language Dialect Pill & Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="px-2 py-2.5 rounded-xl bg-[#151526] hover:bg-[#202035] border border-slate-800 hover:border-[#ff2d78]/40 text-slate-300 hover:text-white text-[10px] font-cyber tracking-wider flex items-center gap-1 transition-all"
              title="Change Speech Recognition Language (Hinglish / Hindi / English)"
            >
              <span className="text-[#ff70a6] font-mono-code font-bold">
                {SPEECH_LANGUAGES.find(l => l.code === selectedSpeechLang)?.badge || 'HINGLISH'}
              </span>
              <ChevronUp className="w-3 h-3 text-slate-500" />
            </button>

            {/* Language Dialect Dropdown */}
            {showLangMenu && (
              <div className="absolute bottom-full right-0 mb-2 w-48 bg-[#121222] border border-slate-700/80 rounded-xl shadow-2xl p-1.5 z-50 backdrop-blur-xl">
                <div className="text-[10px] font-mono-code text-slate-400 px-2 py-1 border-b border-slate-800 mb-1">
                  SPEECH DIALECT
                </div>
                {SPEECH_LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => {
                      setSelectedSpeechLang(lang.code);
                      setShowLangMenu(false);
                      // If listening, restart with new language
                      if (micState === 'listening') {
                        voiceService.stopListening();
                        setTimeout(() => handleToggleMic(), 150);
                      }
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-sans flex items-center justify-between transition-colors ${
                      selectedSpeechLang === lang.code
                        ? 'bg-purple-950/80 text-white font-semibold border border-purple-500/40'
                        : 'text-slate-300 hover:bg-[#1e1e32]'
                    }`}
                  >
                    <span>{lang.label}</span>
                    {selectedSpeechLang === lang.code && (
                      <Check className="w-3.5 h-3.5 text-[#ff2d78]" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Microphone Button (Beside Input) */}
          <button
            type="button"
            onClick={handleToggleMic}
            className={`p-2.5 rounded-xl transition-all shadow-md active:scale-95 flex items-center justify-center shrink-0 ${
              micState === 'listening'
                ? 'bg-gradient-to-r from-rose-600 to-[#ff2d78] text-white shadow-[0_0_16px_rgba(255,45,120,0.8)] border border-pink-400 animate-pulse'
                : micState === 'requesting_permission'
                ? 'bg-amber-950/70 border border-amber-500/60 text-amber-300 animate-pulse'
                : micState === 'permission_denied'
                ? 'bg-rose-950/70 border border-rose-500/60 text-rose-300 hover:bg-rose-900/60'
                : micState === 'unsupported'
                ? 'bg-[#151524] border border-slate-800 text-slate-600 cursor-not-allowed opacity-50'
                : micState === 'error'
                ? 'bg-amber-950/70 border border-amber-500/50 text-amber-300 hover:bg-amber-900/60'
                : 'bg-[#18142a] hover:bg-[#251e3f] border border-[#ff2d78]/40 hover:border-[#ff2d78] text-[#ff70a6] hover:text-white'
            }`}
            title={
              micState === 'listening'
                ? 'Listening... Click to stop and review your message'
                : micState === 'requesting_permission'
                ? 'Requesting browser microphone permission...'
                : micState === 'permission_denied'
                ? 'Microphone permission blocked. Click for instructions.'
                : micState === 'unsupported'
                ? 'Speech recognition not supported in this browser.'
                : `Click to speak to 002 (${selectedSpeechLang === 'hi-IN' ? 'Hindi' : selectedSpeechLang === 'en-IN' ? 'Hinglish' : 'English'})`
            }
          >
            {micState === 'listening' ? (
              <Square className="w-4 h-4 fill-white" />
            ) : micState === 'requesting_permission' ? (
              <Loader2 className="w-4 h-4 animate-spin text-amber-300" />
            ) : micState === 'permission_denied' ? (
              <MicOff className="w-4 h-4 text-rose-400" />
            ) : micState === 'unsupported' ? (
              <MicOff className="w-4 h-4" />
            ) : micState === 'error' ? (
              <AlertCircle className="w-4 h-4 text-amber-400" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </button>

          {/* Send Button */}
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="bg-gradient-to-r from-[#ff2d78] to-[#9333ea] hover:brightness-110 disabled:opacity-40 disabled:hover:brightness-100 text-white p-2.5 rounded-xl transition-all shadow-md active:scale-95 disabled:active:scale-100 shrink-0"
            title="Send to 002"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        {/* Security and Backend Status Footer */}
        <div className="flex items-center justify-between mt-2 px-1 text-[10px] text-slate-500 font-mono-code">
          <span className="flex items-center gap-1 text-slate-400">
            <Cpu className="w-3 h-3 text-[#ff2d78]" />
            Model: <strong className="text-slate-200">gemini-3.8-flash</strong>
          </span>
          <span className="text-emerald-400">Secure Server Proxy • Keys 0% in Client</span>
        </div>
      </div>
    </div>
  );
};
