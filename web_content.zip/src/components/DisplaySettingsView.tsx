import React, { useState } from "react";
import {
  Sliders,
  Type,
  PenTool,
  Layout,
  Eye,
  RotateCcw,
  Check,
  Sparkles,
  Smartphone,
  Tablet,
  Monitor,
  CheckCircle2,
  Maximize2,
  Minimize2,
  Grid,
  Shield,
  Layers,
  StickyNote,
  SlidersHorizontal,
} from "lucide-react";
import {
  useDisplayScale,
  SCALE_PRESETS,
  DEFAULT_DISPLAY_SCALE_CONFIG,
} from "../utils/displayScaleManager";
import { DisplayScalePreset } from "../types";
import {
  SkeuomorphicFountainPen,
  SkeuomorphicPencil,
  SkeuomorphicHighlighter,
  SkeuomorphicEraser,
  SkeuomorphicRecallTape,
} from "./SkeuomorphicPenIcons";

interface DisplaySettingsViewProps {
  onNotify?: (message: string) => void;
}

export const DisplaySettingsView: React.FC<DisplaySettingsViewProps> = ({
  onNotify,
}) => {
  const { scaleConfig, updateScale, resetToDefaults, applyPreset } = useDisplayScale();
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    if (onNotify) onNotify(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSliderChange = (
    key: "uiScale" | "typographyScale" | "toolDockScale" | "canvasScale",
    value: number
  ) => {
    updateScale({ [key]: value });
  };

  const handleApplyPreset = (presetKey: DisplayScalePreset) => {
    applyPreset(presetKey);
    const label = SCALE_PRESETS[presetKey].label;
    showToast(`✓ '${label}' ön ayarı uygulandı.`);
  };

  const handleReset = () => {
    resetToDefaults();
    showToast("✓ Tüm ekran ölçekleri varsayılan %100 değerine sıfırlandı.");
  };

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-200">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="p-3.5 sm:p-4 rounded-2xl bg-teal-600 text-white flex items-center justify-between shadow-xl animate-in slide-in-from-top-2 duration-200 z-30">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{toastMessage}</span>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="p-1 hover:bg-teal-700 rounded-lg text-teal-100 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* HEADER BANNER: KATEGORİK GLOBAL ÖLÇEKLENDİRME */}
      <div className="rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800">
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white px-5 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-indigo-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 flex items-center justify-center font-black">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-indigo-100 flex items-center gap-2">
                <span>KATEGORİK EKRAN & BOYUT ÖLÇEKLENDİRME</span>
                <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-indigo-800 text-indigo-200 border border-indigo-600">
                  HiDPI Vector Scale
                </span>
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Sıfır pikselleşme, sıfır kalite kaybı ve safe layout garantisi ile tüm UI ve kanvası bağımsız ölçeklendirin.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors cursor-pointer"
            title="Tüm ayarları %100 standardına döndür"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>Varsayılana Sıfırla</span>
          </button>
        </div>
      </div>

      {/* 4 READY-MADE SCALE PRESETS BAR */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Hızlı Hazır Ön Ayarlar (Scale Presets)</span>
          </span>
          <span className="text-[10px] text-slate-400">Tek tıkla tüm arayüzü kalibre edin</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {(Object.keys(SCALE_PRESETS) as DisplayScalePreset[]).map((presetKey) => {
            const p = SCALE_PRESETS[presetKey];
            const isMatch =
              Math.abs((p.config.uiScale || 1) - scaleConfig.uiScale) < 0.05 &&
              Math.abs((p.config.typographyScale || 1) - scaleConfig.typographyScale) < 0.05;

            return (
              <button
                key={presetKey}
                type="button"
                onClick={() => handleApplyPreset(presetKey)}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
                  isMatch
                    ? "border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-100 font-bold shadow-xs ring-2 ring-indigo-500/20"
                    : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/40 dark:bg-slate-800/30 text-slate-700 dark:text-slate-300"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black">{p.label}</span>
                  {isMatch && <Check className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />}
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1">{p.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CANLI ÖNİZLEME SİMÜLASYON KARTI (LIVE PREVIEW SIMULATION CARD)             */}
      {/* ========================================================================= */}
      <div className="p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-extrabold uppercase tracking-wider">
            <Eye className="w-4 h-4" />
            <span>Canlı Önizleme Simülatörü (Live Multi-Scale Sandbox)</span>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
            UI: %{Math.round(scaleConfig.uiScale * 100)} | Yazı: %{Math.round(scaleConfig.typographyScale * 100)} | Kalem: %{Math.round(scaleConfig.toolDockScale * 100)}
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Aşağıdaki simülasyon kutusu, kaydırıcıları hareket ettirdiğiniz an tüm bileşenlerin yeni oranlarla nasıl göründüğünü anlık gösterir:
        </p>

        {/* SIMULATION ARENA */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 overflow-hidden">
          {/* Sample Note Card Preview */}
          <div
            className="p-3.5 rounded-2xl bg-slate-800/90 border border-slate-700 flex flex-col justify-between gap-2 shadow-md w-full md:w-56 shrink-0 transition-transform origin-top-left"
            style={{
              padding: `${14 * scaleConfig.uiScale}px`,
              borderRadius: `${16 * scaleConfig.uiScale}px`,
            }}
          >
            <div className="flex items-center justify-between gap-1">
              <span
                className="font-black text-slate-100 truncate"
                style={{ fontSize: `${13 * scaleConfig.typographyScale}px` }}
              >
                Kuantum Fiziği & PKM
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            </div>
            <p
              className="text-slate-400 line-clamp-2 leading-relaxed"
              style={{ fontSize: `${11 * scaleConfig.typographyScale}px` }}
            >
              Dinamik ölçeklendirme ile tüm yazılar ve kartlar %175&apos;te bile ekrandan taşmaz.
            </p>
            <div className="flex items-center gap-2 pt-1 border-t border-slate-700/60">
              <button
                type="button"
                className="rounded-lg bg-teal-600 text-white font-bold transition-all flex items-center justify-center cursor-default"
                style={{
                  padding: `${4 * scaleConfig.uiScale}px ${10 * scaleConfig.uiScale}px`,
                  fontSize: `${10 * scaleConfig.typographyScale}px`,
                  minHeight: `${Math.max(28, 28 * scaleConfig.uiScale)}px`,
                }}
              >
                Aç
              </button>
              <span
                className="text-slate-500 font-mono text-[9px]"
                style={{ fontSize: `${9 * scaleConfig.typographyScale}px` }}
              >
                [[Not Bağlantısı]]
              </span>
            </div>
          </div>

          {/* Sample Floating Tool Dock Miniature Preview */}
          <div
            className="p-2 rounded-[20px] bg-white/10 backdrop-blur-md border border-white/20 flex items-center gap-1.5 shadow-2xl transition-all"
            style={{
              padding: `${6 * scaleConfig.uiScale}px ${10 * scaleConfig.uiScale}px`,
              borderRadius: `${20 * scaleConfig.uiScale}px`,
            }}
          >
            {/* Skeuomorphic Miniature Pens */}
            <div className="flex items-center gap-1">
              <div
                className="transition-transform"
                style={{ transform: `scale(${scaleConfig.toolDockScale})` }}
              >
                <SkeuomorphicFountainPen color="#0284C7" size={24} isActive={true} />
              </div>
              <div
                className="transition-transform"
                style={{ transform: `scale(${scaleConfig.toolDockScale})` }}
              >
                <SkeuomorphicPencil color="#F59E0B" size={24} />
              </div>
              <div
                className="transition-transform"
                style={{ transform: `scale(${scaleConfig.toolDockScale})` }}
              >
                <SkeuomorphicHighlighter color="#FACC15" size={24} />
              </div>
              <div
                className="transition-transform"
                style={{ transform: `scale(${scaleConfig.toolDockScale})` }}
              >
                <SkeuomorphicRecallTape color="#E11D48" size={24} />
              </div>
              <div
                className="transition-transform"
                style={{ transform: `scale(${scaleConfig.toolDockScale})` }}
              >
                <SkeuomorphicEraser size={24} />
              </div>
            </div>
          </div>

          {/* Sample Canvas Grid Preview */}
          <div
            className="w-full md:w-44 h-24 rounded-2xl border border-slate-700 flex flex-col items-center justify-center relative overflow-hidden bg-slate-900"
            style={{
              backgroundImage: `radial-gradient(#38BDF8 1px, transparent 1px)`,
              backgroundSize: `${20 * scaleConfig.canvasScale}px ${20 * scaleConfig.canvasScale}px`,
            }}
          >
            <span
              className="font-bold text-sky-300 bg-slate-950/80 px-2 py-0.5 rounded border border-sky-500/40 text-center"
              style={{ fontSize: `${10 * scaleConfig.typographyScale}px` }}
            >
              Grid: {Math.round(20 * scaleConfig.canvasScale)}px
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4 TEMEL KATEGORİK KAYDIRICI VE AYARLAR                                    */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* A. GENEL ARAYÜZ VE DÜZEN ÖLÇEĞİ (UI & LAYOUT SCALE) */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
                <Layout className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Genel Arayüz & Düzen Ölçeği
                </h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Butonlar, kartlar, barlar, dialoglar ve kenar boşlukları
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-black px-2.5 py-1 rounded-xl bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
              %{Math.round(scaleConfig.uiScale * 100)}
            </span>
          </div>

          <div className="space-y-1.5">
            <input
              type="range"
              min="0.75"
              max="1.75"
              step="0.05"
              value={scaleConfig.uiScale}
              onChange={(e) => handleSliderChange("uiScale", Number(e.target.value))}
              className="w-full accent-teal-600 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
              <span>%75 (Kompakt)</span>
              <span>%100 (Standart)</span>
              <span>%175 (Maksimum)</span>
            </div>
          </div>
        </div>

        {/* B. TİPOGRAFİ VE METİN ÖLÇEĞİ (TYPOGRAPHY SCALE) */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                <Type className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Tipografi & Metin Ölçeği
                </h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Başlıklar, menü yazıları, not gövdesi ve kullanıcı metinleri
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-black px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
              %{Math.round(scaleConfig.typographyScale * 100)}
            </span>
          </div>

          <div className="space-y-1.5">
            <input
              type="range"
              min="0.75"
              max="1.75"
              step="0.05"
              value={scaleConfig.typographyScale}
              onChange={(e) => handleSliderChange("typographyScale", Number(e.target.value))}
              className="w-full accent-amber-500 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
              <span>%75 (Küçük)</span>
              <span>%100 (Standart)</span>
              <span>%175 (Büyük Okuma)</span>
            </div>
          </div>
        </div>

        {/* C. YÜZEN KALEM ÇUBUĞU VE ARAÇLAR (TOOL DOCK & BRUSH SCALE) */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                <PenTool className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Yüzen Kalem Çubuğu & Araçlar
                </h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Kalem ikonları, silgi, kement tutma alanları ve palet butonları
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-black px-2.5 py-1 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
              %{Math.round(scaleConfig.toolDockScale * 100)}
            </span>
          </div>

          <div className="space-y-1.5">
            <input
              type="range"
              min="0.75"
              max="1.75"
              step="0.05"
              value={scaleConfig.toolDockScale}
              onChange={(e) => handleSliderChange("toolDockScale", Number(e.target.value))}
              className="w-full accent-indigo-500 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
              <span>%75 (Kompakt Bar)</span>
              <span>%100 (Standart)</span>
              <span>%175 (Geniş Stylus)</span>
            </div>
          </div>
        </div>

        {/* D. TUVAL VE NOT GÖRÜNÜMÜ ÖLÇEĞİ (CANVAS & CONTENT SCALE) */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
                <Grid className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                  Tuval & Not Görünümü Ölçeği
                </h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Yazı tahtası ızgara/nokta aralıkları ve şablon çerçeveleri
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-black px-2.5 py-1 rounded-xl bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
              %{Math.round(scaleConfig.canvasScale * 100)}
            </span>
          </div>

          <div className="space-y-1.5">
            <input
              type="range"
              min="0.75"
              max="1.75"
              step="0.05"
              value={scaleConfig.canvasScale}
              onChange={(e) => handleSliderChange("canvasScale", Number(e.target.value))}
              className="w-full accent-rose-500 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
              <span>%75 (Sıkı Grid)</span>
              <span>%100 (Standart)</span>
              <span>%175 (Geniş Aralık)</span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* ERİŞİLEBİLİRLİK & GÜVENLİ DÜZEN (ACCESSIBILITY & SAFE LAYOUT TOGGLES)      */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* SISTEM METIN BOYUTUNA OTOMATIK UY (SWITCH) */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>Sistem Metin Boyutuna Otomatik Uy</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Cihazınızın işletim sistemi (Android / iOS / Windows) erişilebilirlik yazı boyutu tercihine otomatik olarak entegre olur.
            </p>
          </div>

          <input
            type="checkbox"
            checked={scaleConfig.autoSystemFontScale}
            onChange={(e) => updateScale({ autoSystemFontScale: e.target.checked })}
            className="w-5 h-5 rounded text-teal-600 focus:ring-teal-500 cursor-pointer shrink-0"
          />
        </div>

        {/* GÜVENLİ DÜZEN VE TAŞMA KORUMASI (SAFE LAYOUT MODE) */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Güvenli Düzen ve Taşma Koruması</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Yüksek ölçeklerde butonların ve yazıların birbirinin üstüne binmesini engeller, en az 48dp dokunma alanını korur.
            </p>
          </div>

          <input
            type="checkbox"
            checked={scaleConfig.safeLayoutMode}
            onChange={(e) => updateScale({ safeLayoutMode: e.target.checked })}
            className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer shrink-0"
          />
        </div>
      </div>

      {/* ARCHITECTURAL GUARANTEE BADGE FOOTER */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-500/10 via-slate-900/40 to-teal-500/10 border border-indigo-500/30 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Physical Canvas Resolution = Logical Bounds × DevicePixelRatio × canvasScaleMultiplier (Retina Anti-Aliased)</span>
        </div>
        <span className="text-[10px] font-bold px-2 py-1 rounded bg-indigo-900 text-indigo-200 border border-indigo-700">
          Sıfır Pikselleşme Garantisi
        </span>
      </div>
    </div>
  );
};
