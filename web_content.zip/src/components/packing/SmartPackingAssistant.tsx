/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Luggage,
  Sparkles,
  CheckCircle2,
  Circle,
  Shirt,
  Cpu,
  FileText,
  HeartPulse,
  Compass,
  Plus,
  Trash2,
  RefreshCw,
  SlidersHorizontal,
  Briefcase,
  Plane,
  Sun,
  CloudSnow,
  CloudRain,
  Flame,
  CheckCheck,
  ChevronDown,
  Info,
  Calendar,
  MapPin,
  Share2,
  ShieldCheck,
} from 'lucide-react';
import {
  PackingCategory,
  PackingItem,
  PackingPlan,
  TripPurpose,
  ClimateType,
  detectClimate,
  generatePackingList,
  calculatePackingProgress,
  toggleItemPacked,
  filterPackingItems,
  addCustomPackingItem,
  deletePackingItem,
  savePackingPlan,
  loadSavedPackingPlan,
} from '../../utils/packing';
import { Language } from '../../types';

interface SmartPackingAssistantProps {
  initialDestination?: string;
  initialDuration?: number;
  language?: Language;
  onClose?: () => void;
  onSaveToVaultNotice?: (message: string) => void;
}

export const SmartPackingAssistant: React.FC<SmartPackingAssistantProps> = ({
  initialDestination = 'إسطنبول (Istanbul)',
  initialDuration = 7,
  language = 'ar',
  onClose,
  onSaveToVaultNotice,
}) => {
  const [destination, setDestination] = useState<string>(initialDestination);
  const [duration, setDuration] = useState<number>(initialDuration);
  const [purpose, setPurpose] = useState<TripPurpose>('leisure');
  const [climate, setClimate] = useState<ClimateType>(() => detectClimate(initialDestination));
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<PackingCategory | 'all'>('all');
  const [filterBaggage, setFilterBaggage] = useState<'all' | 'carry_on' | 'checked'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'unpacked' | 'packed'>('all');

  // Active items
  const [items, setItems] = useState<PackingItem[]>(() => {
    const saved = loadSavedPackingPlan(initialDestination);
    if (saved && saved.items && saved.items.length > 0) {
      return saved.items;
    }
    return generatePackingList(initialDestination, initialDuration, 'leisure');
  });

  // Custom Item Modal/Drawer State
  const [showAddForm, setShowAddForm] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customCategory, setCustomCategory] = useState<PackingCategory>('clothing');
  const [customQty, setCustomQty] = useState(1);
  const [customBaggage, setCustomBaggage] = useState<'carry_on' | 'checked'>('checked');

  // Toast notification
  const [toastMessage, setToastMessage] = useState('');

  // Auto-sync climate when destination changes
  const handleDestinationChange = (dest: string) => {
    setDestination(dest);
    setClimate(detectClimate(dest));
  };

  // Generate / Regenerate with AI Assistant
  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const generated = generatePackingList(destination, duration, purpose, climate);
      setItems(generated);
      const plan: PackingPlan = {
        id: `plan-${Date.now()}`,
        destination,
        durationDays: duration,
        purpose,
        climate,
        items: generated,
        updatedAt: new Date().toISOString(),
      };
      savePackingPlan(plan);
      setIsGenerating(false);
      showToast(language === 'ar' ? 'تم إنشاء قائمة الأمتعة الذكية وتصنيفها بنجاح!' : 'Smart packing list generated!');
    }, 450);
  };

  // Toggle Item
  const handleToggle = (id: string) => {
    setItems((prev) => {
      const updated = toggleItemPacked(prev, id);
      const plan: PackingPlan = {
        id: `plan-${Date.now()}`,
        destination,
        durationDays: duration,
        purpose,
        climate,
        items: updated,
        updatedAt: new Date().toISOString(),
      };
      savePackingPlan(plan);
      return updated;
    });
  };

  // Add Custom Item
  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;
    const updated = addCustomPackingItem(items, {
      name: customName.trim(),
      category: customCategory,
      quantity: customQty,
      baggageType: customBaggage,
    });
    setItems(updated);
    setCustomName('');
    setShowAddForm(false);
    savePackingPlan({
      id: `plan-${Date.now()}`,
      destination,
      durationDays: duration,
      purpose,
      climate,
      items: updated,
      updatedAt: new Date().toISOString(),
    });
    showToast(language === 'ar' ? 'تمت إضافة العنصر إلى حقيبتك' : 'Item added to packing list');
  };

  // Delete Item
  const handleDelete = (id: string) => {
    const updated = deletePackingItem(items, id);
    setItems(updated);
    savePackingPlan({
      id: `plan-${Date.now()}`,
      destination,
      durationDays: duration,
      purpose,
      climate,
      items: updated,
      updatedAt: new Date().toISOString(),
    });
  };

  // Toggle All
  const handleToggleAll = (markPacked: boolean) => {
    setItems((prev) => {
      const updated = prev.map((item) => ({ ...item, packed: markPacked }));
      savePackingPlan({
        id: `plan-${Date.now()}`,
        destination,
        durationDays: duration,
        purpose,
        climate,
        items: updated,
        updatedAt: new Date().toISOString(),
      });
      return updated;
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 2500);
  };

  const progress = calculatePackingProgress(items);
  const displayedItems = filterPackingItems(items, {
    category: selectedCategory,
    packedFilter: filterStatus,
    baggageType: filterBaggage,
  });

  const categoryMeta: Record<
    PackingCategory,
    { labelAr: string; labelEn: string; labelFr: string; icon: React.ReactNode; color: string }
  > = {
    clothing: {
      labelAr: 'الملابس والأزياء',
      labelEn: 'Clothing',
      labelFr: 'Vêtements',
      icon: <Shirt className="w-4 h-4" />,
      color: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
    },
    electronics: {
      labelAr: 'الإلكترونيات والتقنية',
      labelEn: 'Electronics',
      labelFr: 'Électronique',
      icon: <Cpu className="w-4 h-4" />,
      color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
    },
    documents: {
      labelAr: 'وثائق السفر والخزنة',
      labelEn: 'Documents',
      labelFr: 'Documents',
      icon: <FileText className="w-4 h-4" />,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    },
    toiletries: {
      labelAr: 'الصحة والعناية',
      labelEn: 'Toiletries & Health',
      labelFr: 'Santé & Hygiène',
      icon: <HeartPulse className="w-4 h-4" />,
      color: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
    },
    essentials: {
      labelAr: 'المستلزمات الإضافية',
      labelEn: 'Essentials',
      labelFr: 'Essentiels',
      icon: <Compass className="w-4 h-4" />,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
    },
  };

  const destinationPresets = [
    { name: 'إسطنبول (Istanbul)', days: 7, climate: 'temperate' as ClimateType },
    { name: 'مكة المكرمة (عمرة)', days: 10, climate: 'hot' as ClimateType },
    { name: 'باريس (Paris)', days: 5, climate: 'temperate' as ClimateType },
    { name: 'دبي (Dubai)', days: 4, climate: 'hot' as ClimateType },
    { name: 'كوالالمبور (Malaysia)', days: 8, climate: 'tropical' as ClimateType },
    { name: 'جنيف وسويسرا', days: 6, climate: 'cold' as ClimateType },
  ];

  return (
    <div className="space-y-6 pb-24 text-white" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Toast Feedback */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 inset-x-4 max-w-sm mx-auto z-50 p-3 rounded-2xl bg-cyan-500 text-slate-950 font-bold text-xs shadow-[0_0_30px_rgba(0,240,255,0.4)] text-center flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Header Card */}
      <div className="glass-panel-elevated rounded-3xl p-6 border border-cyan-500/30 relative overflow-hidden">
        <div className="absolute -top-16 -right-16 w-40 h-40 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-40 h-40 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 border border-cyan-400/40 text-cyan-400 flex items-center justify-center shadow-[0_0_20px_rgba(0,240,255,0.25)]">
              <Luggage className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg md:text-xl font-black text-white">
                  {language === 'ar' ? 'مساعد حزم الأمتعة الذكي' : 'Smart Packing Assistant'}
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 text-[10px] font-bold font-mono">
                  AI Pack v2
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'ar'
                  ? 'توليد ذكي ومخصص لمحتويات الحقيبة حسب الوجهة والمدة والمناخ'
                  : 'AI-tailored packing checklists based on destination, duration & climate'}
              </p>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              ✕
            </button>
          )}
        </div>

        {/* Input Parameters Controls */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 space-y-3.5">
          {/* Quick Destination Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-[11px] text-slate-400 shrink-0 font-medium ml-1">
              {language === 'ar' ? 'وجهات سريعة:' : 'Quick Presets:'}
            </span>
            {destinationPresets.map((p) => (
              <button
                key={p.name}
                onClick={() => {
                  setDestination(p.name);
                  setDuration(p.days);
                  setClimate(p.climate);
                }}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold shrink-0 transition-all cursor-pointer ${
                  destination === p.name
                    ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                    : 'bg-slate-900/90 text-slate-300 border border-slate-800 hover:border-cyan-500/40'
                }`}
              >
                {p.name} ({p.days}d)
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Destination Input */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>{language === 'ar' ? 'الوجهة السياحية:' : 'Destination:'}</span>
              </label>
              <input
                type="text"
                value={destination}
                onChange={(e) => handleDestinationChange(e.target.value)}
                placeholder={language === 'ar' ? 'مثال: إسطنبول، باريس، دبي...' : 'e.g. Istanbul, Paris, Dubai...'}
                className="w-full h-10 px-3.5 rounded-xl bg-[#060c20] border border-slate-700/80 focus:border-cyan-400 focus:outline-none text-white text-xs"
              />
            </div>

            {/* Duration Stepper */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>{language === 'ar' ? 'مدة الرحلة (أيام):' : 'Trip Duration (days):'}</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={duration}
                  onChange={(e) => setDuration(Number(e.target.value))}
                  className="flex-1 accent-cyan-400 cursor-pointer"
                />
                <span className="w-12 h-10 rounded-xl bg-[#060c20] border border-slate-700/80 flex items-center justify-center font-bold text-cyan-400 text-xs font-mono">
                  {duration}d
                </span>
              </div>
            </div>
          </div>

          {/* Trip Purpose and Climate row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
            {/* Purpose */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-[#060c20] border border-slate-800">
              <span className="text-[11px] text-slate-400 font-medium">
                {language === 'ar' ? 'نوع الرحلة:' : 'Purpose:'}
              </span>
              <select
                value={purpose}
                onChange={(e) => setPurpose(e.target.value as TripPurpose)}
                className="bg-transparent text-cyan-300 font-bold text-[11px] focus:outline-none cursor-pointer"
              >
                <option value="leisure" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'سياحة وترفيه' : 'Leisure'}
                </option>
                <option value="religious" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'عمرة ورحلة دينية' : 'Umrah / Religious'}
                </option>
                <option value="business" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'عمل ومؤتمرات' : 'Business'}
                </option>
                <option value="honeymoon" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'شهر عسل' : 'Honeymoon'}
                </option>
                <option value="adventure" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'مغامرات وطبيعة' : 'Adventure'}
                </option>
              </select>
            </div>

            {/* Climate */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-[#060c20] border border-slate-800">
              <span className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                {climate === 'hot' && <Flame className="w-3.5 h-3.5 text-amber-400" />}
                {climate === 'cold' && <CloudSnow className="w-3.5 h-3.5 text-blue-400" />}
                {climate === 'temperate' && <Sun className="w-3.5 h-3.5 text-yellow-400" />}
                {climate === 'tropical' && <CloudRain className="w-3.5 h-3.5 text-emerald-400" />}
                <span>{language === 'ar' ? 'مناخ الوجهة:' : 'Climate:'}</span>
              </span>
              <select
                value={climate}
                onChange={(e) => setClimate(e.target.value as ClimateType)}
                className="bg-transparent text-cyan-300 font-bold text-[11px] focus:outline-none cursor-pointer"
              >
                <option value="temperate" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'معتدل (Temperate)' : 'Temperate'}
                </option>
                <option value="hot" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'حار وصيفي (Hot)' : 'Hot'}
                </option>
                <option value="cold" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'بارد وشتوي (Cold)' : 'Cold'}
                </option>
                <option value="tropical" className="bg-slate-900 text-white">
                  {language === 'ar' ? 'استوائي ورطب (Tropical)' : 'Tropical'}
                </option>
              </select>
            </div>
          </div>

          {/* Regenerate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs shadow-[0_0_20px_rgba(0,240,255,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>
              {isGenerating
                ? language === 'ar'
                  ? 'جاري توليد قائمة الأمتعة المخصصة...'
                  : 'Generating Tailored Packing Plan...'
                : language === 'ar'
                ? 'توليد قائمة الأمتعة الذكية بـ AI'
                : 'Generate Custom Packing Plan'}
            </span>
          </button>
        </div>
      </div>

      {/* Live Packing Progress Banner */}
      <div className="glass-panel rounded-3xl p-5 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">
              {language === 'ar' ? 'جاهزية الحقيبة' : 'Packing Readiness'}
            </span>
            <span className="text-cyan-400 font-mono font-bold">
              ({progress.packed}/{progress.total} {language === 'ar' ? 'عنصر' : 'items'})
            </span>
          </div>
          <span className="text-sm font-black text-cyan-400 font-mono">
            {progress.percentage}%
          </span>
        </div>

        {/* Dynamic Progress Bar */}
        <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <motion.div
            className={`h-full rounded-full transition-all duration-500 ${
              progress.isComplete
                ? 'bg-gradient-to-r from-emerald-500 to-emerald-400 shadow-[0_0_12px_#10b981]'
                : 'bg-gradient-to-r from-cyan-500 to-blue-500 shadow-[0_0_12px_#00f0ff]'
            }`}
            style={{ width: `${progress.percentage}%` }}
          />
        </div>

        {/* Quick Batch Controls */}
        <div className="flex items-center justify-between pt-1 text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleToggleAll(true)}
              className="hover:text-cyan-300 underline cursor-pointer"
            >
              {language === 'ar' ? 'تحديد الكل كمحزوم' : 'Mark all packed'}
            </button>
            <span>·</span>
            <button
              onClick={() => handleToggleAll(false)}
              className="hover:text-slate-300 underline cursor-pointer"
            >
              {language === 'ar' ? 'إعادة ضبط' : 'Reset all'}
            </button>
          </div>

          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-400/30 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'إضافة عنصر مخصص' : 'Add Custom'}</span>
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="space-y-2">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {language === 'ar' ? `الكل (${items.length})` : `All (${items.length})`}
          </button>

          {(Object.keys(categoryMeta) as PackingCategory[]).map((cat) => {
            const count = items.filter((i) => i.category === cat).length;
            const meta = categoryMeta[cat];
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {meta.icon}
                <span>
                  {language === 'ar' ? meta.labelAr : meta.labelEn} ({count})
                </span>
              </button>
            );
          })}
        </div>

        {/* Secondary filters: Baggage location & packed status */}
        <div className="flex items-center justify-between gap-2 px-1 text-[11px] text-slate-400">
          <div className="flex items-center gap-1">
            <span className="ml-1">{language === 'ar' ? 'الحقيبة:' : 'Luggage:'}</span>
            {(['all', 'carry_on', 'checked'] as const).map((b) => (
              <button
                key={b}
                onClick={() => setFilterBaggage(b)}
                className={`px-2 py-0.5 rounded-lg font-mono transition-colors ${
                  filterBaggage === b
                    ? 'bg-slate-800 text-cyan-300 font-bold'
                    : 'hover:text-slate-200'
                }`}
              >
                {b === 'all'
                  ? language === 'ar'
                    ? 'الكل'
                    : 'All'
                  : b === 'carry_on'
                  ? language === 'ar'
                    ? 'حقيبة اليد'
                    : 'Carry-on'
                  : language === 'ar'
                  ? 'حقيبة الشحن'
                  : 'Checked'}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1">
            {(['all', 'unpacked', 'packed'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setFilterStatus(s)}
                className={`px-2 py-0.5 rounded-lg transition-colors ${
                  filterStatus === s
                    ? 'bg-slate-800 text-cyan-300 font-bold'
                    : 'hover:text-slate-200'
                }`}
              >
                {s === 'all'
                  ? language === 'ar'
                    ? 'الكل'
                    : 'All'
                  : s === 'unpacked'
                  ? language === 'ar'
                    ? 'غير محزوم'
                    : 'Unpacked'
                  : language === 'ar'
                  ? 'مكتمل'
                  : 'Packed'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Item Checklists */}
      <div className="space-y-2.5">
        {displayedItems.length === 0 ? (
          <div className="glass-panel rounded-3xl p-8 border border-slate-800 text-center text-slate-400 text-xs">
            <Luggage className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p>{language === 'ar' ? 'لا توجد عناصر تطابق التصفية المحددة' : 'No items match filter'}</p>
          </div>
        ) : (
          displayedItems.map((item) => {
            const meta = categoryMeta[item.category];
            return (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onClick={() => handleToggle(item.id)}
                className={`glass-panel p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 select-none ${
                  item.packed
                    ? 'bg-slate-950/40 border-slate-800/60 opacity-60'
                    : 'border-slate-800 hover:border-cyan-500/40'
                }`}
              >
                {/* Interactive Checkbox */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleToggle(item.id);
                  }}
                  className={`mt-0.5 w-6 h-6 rounded-lg flex items-center justify-center transition-all shrink-0 cursor-pointer ${
                    item.packed
                      ? 'bg-emerald-500 text-slate-950 shadow-[0_0_10px_#10b981]'
                      : 'border-2 border-slate-600 hover:border-cyan-400'
                  }`}
                >
                  {item.packed ? (
                    <CheckCircle2 className="w-4 h-4 stroke-[3]" />
                  ) : (
                    <Circle className="w-3.5 h-3.5 text-transparent" />
                  )}
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p
                      className={`text-xs font-bold truncate ${
                        item.packed ? 'line-through text-slate-400' : 'text-white'
                      }`}
                    >
                      {item.name}
                    </p>

                    {item.quantity > 1 && (
                      <span className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-cyan-400 text-[10px] font-mono font-bold shrink-0">
                        × {item.quantity}
                      </span>
                    )}
                  </div>

                  {/* Metadata Chips & Tips */}
                  <div className="flex items-center flex-wrap gap-1.5 mt-1">
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border ${meta.color}`}
                    >
                      {language === 'ar' ? meta.labelAr : meta.labelEn}
                    </span>

                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-medium ${
                        item.baggageType === 'carry_on'
                          ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                          : 'bg-slate-900 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {item.baggageType === 'carry_on'
                        ? language === 'ar'
                          ? 'حقيبة اليد'
                          : 'Carry-on'
                        : language === 'ar'
                        ? 'شحن'
                        : 'Checked'}
                    </span>

                    {item.isEssential && (
                      <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px] font-semibold">
                        {language === 'ar' ? 'أساسي' : 'Essential'}
                      </span>
                    )}
                  </div>

                  {item.tip && (
                    <p className="text-[11px] text-cyan-300/80 font-mono mt-1 flex items-center gap-1">
                      <Info className="w-3 h-3 text-cyan-400 shrink-0" />
                      <span>{item.tip}</span>
                    </p>
                  )}
                </div>

                {/* Delete button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(item.id);
                  }}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                  title="حذف العنصر"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Add Custom Item Modal / Bottom Drawer */}
      <AnimatePresence>
        {showAddForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm rounded-3xl bg-[#090d1f] border border-cyan-500/30 p-5 text-white shadow-[0_0_40px_rgba(0,240,255,0.2)]"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Plus className="w-4 h-4 text-cyan-400" />
                  <span>{language === 'ar' ? 'إضافة عنصر جديد للأمتعة' : 'Add Custom Item'}</span>
                </h3>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleAddCustom} className="mt-4 space-y-3.5 text-xs">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                    {language === 'ar' ? 'اسم العنصر:' : 'Item Name:'}
                  </label>
                  <input
                    type="text"
                    required
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    placeholder={
                      language === 'ar' ? 'مثال: معطف مطري، شاحن كاميرا...' : 'e.g. Raincoat, Camera Charger...'
                    }
                    className="w-full h-10 px-3.5 rounded-xl bg-[#060c20] border border-slate-700 focus:border-cyan-400 focus:outline-none text-white text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                      {language === 'ar' ? 'التصنيف:' : 'Category:'}
                    </label>
                    <select
                      value={customCategory}
                      onChange={(e) => setCustomCategory(e.target.value as PackingCategory)}
                      className="w-full h-10 px-2.5 rounded-xl bg-[#060c20] border border-slate-700 text-cyan-300 font-bold focus:outline-none"
                    >
                      <option value="clothing">{categoryMeta.clothing.labelAr}</option>
                      <option value="electronics">{categoryMeta.electronics.labelAr}</option>
                      <option value="documents">{categoryMeta.documents.labelAr}</option>
                      <option value="toiletries">{categoryMeta.toiletries.labelAr}</option>
                      <option value="essentials">{categoryMeta.essentials.labelAr}</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                      {language === 'ar' ? 'الكمية:' : 'Quantity:'}
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="20"
                      value={customQty}
                      onChange={(e) => setCustomQty(Number(e.target.value))}
                      className="w-full h-10 px-3 rounded-xl bg-[#060c20] border border-slate-700 text-white font-mono font-bold text-center focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                    {language === 'ar' ? 'مكان الحفظ:' : 'Baggage Location:'}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setCustomBaggage('carry_on')}
                      className={`py-2 px-3 rounded-xl border text-center font-bold text-xs transition-colors cursor-pointer ${
                        customBaggage === 'carry_on'
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      {language === 'ar' ? 'حقيبة اليد (Cabin)' : 'Carry-on'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setCustomBaggage('checked')}
                      className={`py-2 px-3 rounded-xl border text-center font-bold text-xs transition-colors cursor-pointer ${
                        customBaggage === 'checked'
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      {language === 'ar' ? 'حقيبة الشحن (Checked)' : 'Checked Bag'}
                    </button>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                  >
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black shadow-[0_0_15px_rgba(0,240,255,0.3)]"
                  >
                    {language === 'ar' ? 'إضافة' : 'Add Item'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
