import React, { useState } from 'react';
import { UserPlus, Edit, X, Trophy, Sparkles, Award } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Player } from '../types';
import { toPersianDigits } from '../utils/snooker';

interface AddPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (name: string) => void;
  playerCount: number;
}

export const AddPlayerModal: React.FC<AddPlayerModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  playerCount,
}) => {
  const [name, setName] = useState(`بازیکن ${playerCount + 1}`);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onAdd(name.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-700/80 p-5 shadow-2xl text-slate-100"
        dir="rtl"
      >
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <UserPlus className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-base text-white">افزودن بازیکن جدید</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              نام یا لقب بازیکن:
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: رونی، مهدی، علی..."
              autoFocus
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="submit"
              className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-sm transition-colors cursor-pointer"
            >
              افزودن بازیکن
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-xl text-sm transition-colors cursor-pointer"
            >
              انصراف
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface EditPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  player: Player | null;
  onSave: (id: number, newName: string) => void;
}

export const EditPlayerModal: React.FC<EditPlayerModalProps> = ({
  isOpen,
  onClose,
  player,
  onSave,
}) => {
  const [name, setName] = useState(player?.name || '');

  React.useEffect(() => {
    if (player) setName(player.name);
  }, [player]);

  if (!isOpen || !player) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onSave(player.id, name.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-700/80 p-5 shadow-2xl text-slate-100"
        dir="rtl"
      >
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-500/20 text-blue-400 rounded-xl border border-blue-500/30">
              <Edit className="w-5 h-5" />
            </div>
            <h2 className="font-bold text-base text-white">ویرایش نام بازیکن</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              نام جدید بازیکن:
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoFocus
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="submit"
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-sm transition-colors cursor-pointer"
            >
              ذخیره تغییرات
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-xl text-sm transition-colors cursor-pointer"
            >
              انصراف
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface FrameWinnerModalProps {
  isOpen: boolean;
  onClose: () => void;
  winner: Player | null;
  frameNumber: number;
  players: Player[];
  onNextFrame: () => void;
}

export const FrameWinnerModal: React.FC<FrameWinnerModalProps> = ({
  isOpen,
  onClose,
  winner,
  frameNumber,
  players,
  onNextFrame,
}) => {
  React.useEffect(() => {
    if (isOpen) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
    }
  }, [isOpen]);

  if (!isOpen || !winner) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950/60 border border-emerald-500/50 p-6 shadow-2xl text-slate-100 text-center"
        dir="rtl"
      >
        <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/20 animate-bounce">
          <Trophy className="w-8 h-8" />
        </div>

        <h2 className="text-xl font-black text-white mb-1">
          تبریک! برنده فریم {toPersianDigits(frameNumber)}
        </h2>
        <p className="text-sm font-extrabold text-amber-300 mb-4 flex items-center justify-center gap-1">
          <Sparkles className="w-4 h-4" />
          <span>{winner.name}</span>
          <Sparkles className="w-4 h-4" />
        </p>

        {/* Frame score recap */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3 mb-5 space-y-2">
          <div className="text-xs text-slate-400 font-medium">نتیجه نهایی این فریم:</div>
          <div className="flex items-center justify-around">
            {players.map((p) => (
              <div key={p.id} className="flex flex-col items-center">
                <span className="text-xs font-bold text-slate-200">{p.name}</span>
                <span
                  dir="ltr"
                  className={`text-xl font-black ${p.score < 0 ? 'text-rose-400' : 'text-amber-400'}`}
                >
                  {toPersianDigits(p.score)}
                </span>
                <span className="text-[11px] text-slate-400">
                  بریک برتر: {toPersianDigits(p.highestBreak)}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={() => {
              onNextFrame();
              onClose();
            }}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl text-sm shadow-lg shadow-emerald-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Award className="w-4 h-4" />
            <span>شروع فریم بعدی</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
          >
            مشاهده جدول فعلی
          </button>
        </div>
      </div>
    </div>
  );
};
