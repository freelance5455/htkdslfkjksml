import React, { useState } from 'react';
import {
  Briefcase,
  GraduationCap,
  Building,
  Trophy,
  CheckCircle2,
  Lock,
  ArrowUpRight,
  Sparkles,
  ChevronRight,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { CareerTrack, CareerTier, GameState } from '../../game/types';
import { ASSETS } from '../../game/constants';
import { AVAILABLE_COURSES } from '../../game/courses';
import { CAREER_POSITIONS, CAREER_TRACKS_INFO } from '../../game/careers';
import {
  getCurrentCareerPosition,
  getNextCareerPosition,
  checkPromotionEligibility,
  getMoodProductivityMultiplier
} from '../../game/engine';
import { playClickSound } from '../../utils/audio';

interface WorkTabProps {
  gameState: GameState;
  onWorkShift: () => void;
  onRequestPromotion: () => void;
  onSwitchTrack: (track: CareerTrack) => void;
  onEnrollCourse: (courseId: string) => void;
  onBuyAsset: (assetId: string) => void;
}

export const WorkTab: React.FC<WorkTabProps> = ({
  gameState,
  onWorkShift,
  onRequestPromotion,
  onSwitchTrack,
  onEnrollCourse,
  onBuyAsset
}) => {
  const currentPos = getCurrentCareerPosition(gameState);
  const nextPos = getNextCareerPosition(gameState);
  const promoCheck = checkPromotionEligibility(gameState);
  const moodInfo = getMoodProductivityMultiplier(gameState.mood);
  const trackInfo = CAREER_TRACKS_INFO[gameState.currentCareerTrack];

  const [inspectTrack, setInspectTrack] = useState<CareerTrack>(gameState.currentCareerTrack);

  const daysWorkedInTrack = gameState.careerDaysWorked?.[gameState.currentCareerTrack] || 0;

  return (
    <div className="space-y-3">
      {/* Active Position Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/30 border border-slate-800 rounded-3xl p-5 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 text-2xl shadow-inner">
              {trackInfo.icon}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  رتبة {currentPos.tier} من 5 • {trackInfo.name}
                </span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border font-bold ${
                  moodInfo.tone === 'positive'
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    : moodInfo.tone === 'negative'
                    ? 'bg-rose-950 text-rose-300 border-rose-800'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}>
                  {moodInfo.label}
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-slate-100 mt-1">
                {currentPos.title}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">{currentPos.department}</p>
            </div>
          </div>

          {/* Shift Button */}
          <button
            onClick={() => { playClickSound(); onWorkShift(); }}
            className="py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm shadow-lg shadow-amber-500/25 active:scale-95 transition flex items-center justify-center gap-2 whitespace-nowrap self-stretch sm:self-auto"
          >
            <Briefcase className="w-4 h-4" />
            <span>بدء وردية العمل اليومية</span>
          </button>
        </div>

        {/* Position Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4 pt-4 border-t border-slate-800/80 text-xs">
          <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-0.5">الراتب الأساسي / وردية</span>
            <span className="font-bold text-amber-300 text-sm font-mono">
              {currentPos.basePay.toLocaleString('en-US')} ج.م
            </span>
          </div>

          <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-0.5">أيام العمل في هذا المسار</span>
            <span className="font-bold text-slate-200 text-sm font-mono">
              {daysWorkedInTrack} أيام فعلية
            </span>
          </div>

          <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-0.5">استهلاك الطاقة / المدة</span>
            <span className="font-bold text-cyan-300 text-xs">
              {currentPos.energyCost}⚡ • {currentPos.hoursRequired} ساعات
            </span>
          </div>

          <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 block mb-0.5">إجمالي ترقياتك السابقة</span>
            <span className="font-bold text-purple-300 text-sm font-mono">
              {gameState.promotionsCount || 0} ترقيات 🎖️
            </span>
          </div>
        </div>

        {/* Responsibilities */}
        <div className="mt-3 p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs text-slate-300 leading-relaxed">
          <span className="text-amber-400 font-bold block mb-1">المسؤوليات اليومية الموكلة إليك:</span>
          <p>{currentPos.responsibilities}</p>
          <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1 font-medium">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{currentPos.perkDescription}</span>
          </div>
        </div>
      </div>

      {/* Next Promotion Tracker & Ladder */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <TrendingUp className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-100">سلم المسار المهني ومتطلبات الترقية</h2>
              <p className="text-[11px] text-slate-400">
                الترقية مبنية على المهارات وعدد أيام العمل الفعلية والمسؤوليات
              </p>
            </div>
          </div>
        </div>

        {nextPos ? (
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-900">
              <div>
                <span className="text-[10px] text-purple-400 font-bold">الرتبة القادمة المستهدفة:</span>
                <div className="text-sm font-bold text-slate-100 flex items-center gap-1.5 mt-0.5">
                  <span>🎖️</span>
                  <span>{nextPos.title}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                    رتبة {nextPos.tier}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400">{nextPos.department}</div>
              </div>

              <div className="text-left sm:text-right">
                <span className="text-[10px] text-slate-400">الراتب المرتقب:</span>
                <div className="font-bold text-emerald-400 text-sm font-mono">
                  {nextPos.basePay.toLocaleString('en-US')} ج.م / وردية
                </div>
              </div>
            </div>

            {/* Progress Bars for Promotion */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {/* Days Worked */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300 font-semibold">أيام العمل الفعلية في المسار:</span>
                  <span className="font-bold text-amber-300 font-mono">
                    {daysWorkedInTrack} / {nextPos.minDaysWorked} يوم
                  </span>
                </div>
                <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all"
                    style={{
                      width: `${Math.min(100, Math.max(0, (daysWorkedInTrack / nextPos.minDaysWorked) * 100))}%`
                    }}
                  />
                </div>
              </div>

              {/* Skill */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300 font-semibold">مستوى المهارة والخبرة:</span>
                  <span className="font-bold text-cyan-300 font-mono">
                    {Math.round(gameState.skill)} / {nextPos.minSkill}
                  </span>
                </div>
                <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-sky-400 rounded-full transition-all"
                    style={{
                      width: `${Math.min(100, Math.max(0, (gameState.skill / nextPos.minSkill) * 100))}%`
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Missing criteria or Course/Asset requirements */}
            {promoCheck.reasonsMissing.length > 0 ? (
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-300 space-y-1">
                <span className="font-semibold text-amber-300 block mb-1">شروط لازمة للترقية للرتبة {nextPos.tier}:</span>
                {promoCheck.reasonsMissing.map((reason, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-slate-400">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{reason}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/50 text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>أنت مؤهل رسمياً للترقية الآن! استوفيت كافة أيام العمل والمهارات المطلوبة.</span>
              </div>
            )}

            {/* Request Promotion Button */}
            <button
              onClick={() => { playClickSound(); onRequestPromotion(); }}
              disabled={!promoCheck.eligible}
              className={`w-full py-3 px-4 rounded-xl font-black text-xs transition flex items-center justify-center gap-2 ${
                promoCheck.eligible
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-slate-950 shadow-lg shadow-emerald-500/25 animate-pulse hover:brightness-110 active:scale-95'
                  : 'bg-slate-900 border border-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span>{promoCheck.eligible ? 'طلب الترقية الوظيفية الآن 🎖️' : 'الترقية مغلقة حتى استيفاء الشروط'}</span>
            </button>
          </div>
        ) : (
          <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-center space-y-2">
            <span className="text-3xl">👑</span>
            <h3 className="text-sm font-black text-amber-300">أعلى قمة في هذا المسار المهني!</h3>
            <p className="text-xs text-slate-300">
              وصلت إلى الرتبة الخامسة والأخيرة في هذا المسار. راتبك ونفوذك في ذروته! يمكنك دائماً استكشاف مسارات مهنية أخرى إذا رغبت.
            </p>
          </div>
        )}

        {/* Career Track Switcher & Ladder Explorer */}
        <div className="mt-5 pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs font-bold text-slate-300">استعراض المسارات المهنية الأخرى والتحويل بينها:</span>
            <span className="text-[10px] text-slate-400">5 مسارات مهنية مستقلة</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 mb-3">
            {(Object.keys(CAREER_TRACKS_INFO) as CareerTrack[]).map((t) => {
              const info = CAREER_TRACKS_INFO[t];
              const isCurrent = gameState.currentCareerTrack === t;
              const isSelected = inspectTrack === t;

              return (
                <button
                  key={t}
                  onClick={() => { playClickSound(); setInspectTrack(t); }}
                  className={`p-2.5 rounded-xl border text-right transition flex flex-col justify-between ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500 text-amber-200'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-base">{info.icon}</span>
                    {isCurrent && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 font-bold border border-emerald-800">
                        حالي
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] font-bold mt-1 truncate">{info.name}</span>
                </button>
              );
            })}
          </div>

          {/* Detailed Tiers for Selected Track */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-900">
              <div>
                <h4 className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                  <span>{CAREER_TRACKS_INFO[inspectTrack].icon}</span>
                  <span>رتب مسار {CAREER_TRACKS_INFO[inspectTrack].name}</span>
                </h4>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {CAREER_TRACKS_INFO[inspectTrack].description}
                </p>
              </div>

              {gameState.currentCareerTrack !== inspectTrack && (
                <button
                  onClick={() => { playClickSound(); onSwitchTrack(inspectTrack); }}
                  className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md shadow-purple-600/20 active:scale-95 transition whitespace-nowrap"
                >
                  التحويل لهذا المسار
                </button>
              )}
            </div>

            <div className="space-y-1.5">
              {([1, 2, 3, 4, 5] as CareerTier[]).map((tierNum) => {
                const pos = CAREER_POSITIONS[inspectTrack][tierNum];
                const isCurrentInTrack = gameState.currentCareerTrack === inspectTrack && gameState.currentCareerTier === tierNum;
                const isPassed = gameState.currentCareerTrack === inspectTrack && gameState.currentCareerTier > tierNum;

                return (
                  <div
                    key={tierNum}
                    className={`p-2.5 rounded-xl border text-xs flex items-center justify-between ${
                      isCurrentInTrack
                        ? 'bg-amber-950/30 border-amber-500/50 text-amber-200'
                        : isPassed
                        ? 'bg-slate-900/60 border-slate-800 text-slate-400'
                        : 'bg-slate-950 border-slate-900 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 font-bold text-[10px] flex items-center justify-center">
                        {tierNum}
                      </span>
                      <div>
                        <div className="font-bold text-slate-200">{pos.title}</div>
                        <div className="text-[10px] text-slate-500">
                          أيام عمل: {pos.minDaysWorked} • مهارة: {pos.minSkill}
                        </div>
                      </div>
                    </div>

                    <div className="text-left font-mono font-bold text-amber-300 text-[11px]">
                      {pos.basePay.toLocaleString('en-US')} ج.م
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Courses & Education with Duration */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <GraduationCap className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-100">الكورسات والمراحل التعليمية</h2>
              <p className="text-[11px] text-slate-400">دورات تدريبية معتمدة تؤهلك لترقيات كبرى</p>
            </div>
          </div>
        </div>

        <div className="space-y-2.5">
          {AVAILABLE_COURSES.map((course) => {
            const isCompleted = gameState.completedCourseIds.includes(course.id);
            const isEnrolled = gameState.activeCourses.some(c => c.id === course.id);

            return (
              <div key={course.id} className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base">{course.icon}</span>
                    <span className="text-xs font-bold text-slate-100">{course.name}</span>
                    {isCompleted && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                        ✅ متخرج وحاصل على الشهادة
                      </span>
                    )}
                    {isEnrolled && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-800 font-bold">
                        ⏳ قيد الدراسة
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    المدة: <b>{course.durationDays} أيام</b> ({course.dailyHours} ساعات يومياً) • تكلفة التسجيل: <b>{course.cost} ج.م</b>
                  </p>
                  <p className="text-[10px] text-purple-300 mt-0.5">
                    المزايا: +{course.skillBonus} مهارة، +{course.repBonus} سمعة • {course.unlockedCareerPerk}
                  </p>
                </div>

                {!isCompleted && !isEnrolled && (
                  <button
                    onClick={() => { playClickSound(); onEnrollCourse(course.id); }}
                    className="self-start sm:self-auto px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md shadow-purple-600/20 active:scale-95 transition whitespace-nowrap"
                  >
                    تسجيل ({course.cost} ج.م)
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Assets & Businesses */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Building className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-100">الأصول والمشاريع والعقارات</h2>
              <p className="text-[11px] text-slate-400">استثمارات ومساكن ترتقي بحياتك وتوفر أرباحاً</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {Object.values(ASSETS).map((asset) => {
            const owned = gameState.assets.includes(asset.id);
            return (
              <div key={asset.id} className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                      <span>{asset.icon}</span>
                      <span>{asset.name}</span>
                    </span>
                    {owned ? (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                        مملوك
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-amber-300 font-mono">
                        {asset.cost.toLocaleString('en-US')} ج.م
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">{asset.description}</p>
                </div>

                {!owned && (
                  <button
                    onClick={() => { playClickSound(); onBuyAsset(asset.id); }}
                    className="mt-2 w-full py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs transition"
                  >
                    شراء الآن
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
