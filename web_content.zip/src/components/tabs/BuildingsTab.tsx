import React from 'react';
import { Building, Disciple, SectResources } from '../../types/cultivation';
import { formatLargeNumber } from '../../data/realms';
import { calculateStaffCompatibility } from '../../data/compatibility';
import { ArrowUpCircle, Users, Sparkles, Lock, Unlock, FlaskConical, TrendingUp } from 'lucide-react';
import { soundEngine } from '../../services/audioEngine';

interface BuildingsTabProps {
  buildings: Building[];
  disciples: Disciple[];
  resources: SectResources;
  prestige?: number;
  devMode?: boolean;
  onUpgradeBuilding: (building: Building) => void;
  onUnlockBuilding: (building: Building) => void;
  onOpenAssignModal: (building: Building) => void;
}

export function calculateAlchemySuccessProbability(
  alchemyBuilding: Building | undefined,
  disciples: Disciple[],
  prestige: number
): { probability: number; avgTalent: number; prestigeBonus: number; levelBonus: number; staffCount: number } {
  if (!alchemyBuilding) {
    return { probability: 25, avgTalent: 0, prestigeBonus: 0, levelBonus: 0, staffCount: 0 };
  }
  const assigned = disciples.filter(d => alchemyBuilding.assignedDisciples.includes(d.id));
  const avgTalent = assigned.length > 0
    ? assigned.reduce((sum, d) => sum + d.talent, 0) / assigned.length
    : 35; // Unassigned automatic cauldron baseline fallback

  const talentContribution = avgTalent * 0.45;
  const prestigeBonus = Math.min(35, prestige / 120);
  const levelBonus = alchemyBuilding.level * 2;
  const staffBonus = assigned.length * 3;
  const raw = 20 + talentContribution + prestigeBonus + levelBonus + staffBonus;
  const probability = Math.max(15, Math.min(98, Math.round(raw)));

  return {
    probability,
    avgTalent: assigned.length > 0 ? Math.round(avgTalent) : 0,
    prestigeBonus: parseFloat(prestigeBonus.toFixed(1)),
    levelBonus,
    staffCount: assigned.length
  };
}

export function getBuildingScaledEffect(building: Building): { current: string; next: string | null } {
  const lv = building.level;
  const nextLv = lv < building.maxLevel ? lv + 1 : null;

  const formatForLevel = (level: number): string => {
    switch (building.id) {
      case 'b_hall':
        return `+${10 + (level - 1) * 5} Max Disciples · +${level * 12}% Prestige`;
      case 'b_array':
        return `+${(3 + level * 1.6).toFixed(1)} Qi/s gathering`;
      case 'b_mine':
        return `+${(4 + level * 2.5).toFixed(1)} Spirit Stones/s`;
      case 'b_alchemy':
        return `+${(0.6 + level * 0.35).toFixed(1)} Pills/s · +${level * 2}% Alchemy Odds`;
      case 'b_scripture':
        return `+${10 + (level - 1) * 4}% Cultivation Speed · +${(1 + level * 0.6).toFixed(1)} Merit/s`;
      case 'b_discipline':
        return `-${Math.min(80, 25 + (level - 1) * 4)}% Jealousy & Stress Growth`;
      case 'b_tribulation':
        return `-${Math.min(85, 30 + (level - 1) * 4)}% Lightning Damage & +${level * 2}% Break Odds`;
      case 'b_nursery':
        return `+${level * 3} Qi/s Youth Nourishment & +${Math.min(40, 10 + level * 2)}% Recovery`;
      case 'b_talisman':
        return `+${10 + (level - 1) * 4}% Sect Barrier & +${level * 2} Combat Defense`;
      case 'b_garden':
        return `+${(0.5 + level * 0.3).toFixed(1)} Herb Pills/s & +${level * 3} Longevity Glow`;
      case 'b_forge':
        return `+${10 + (level - 1) * 3}% Squad Combat Might`;
      case 'b_meditation':
        return `+${25 + (level - 1) * 4}% Mental Comprehension & Stress Calm`;
      case 'b_astronomy':
        return `+${15 + (level - 1) * 5}% Expedition Yield & Divination Luck`;
      case 'b_soul_pagoda':
        return `+${level * 3} Soul Stability & +${15 + (level - 1) * 3}% Soul Qi`;
      case 'b_vein_core':
        return `+${(2 + level * 2.2).toFixed(1)} Stones/s · +${25 + (level - 1) * 5}% Qi Purity`;
      case 'b_sword_stele':
        return `+${12 + (level - 1) * 4}% Sword Strike Crit & Arena Edge`;
      case 'b_dao_temple':
        return `+${30 + (level - 1) * 5}% Comprehension · +${level * 3} Merit Mastery`;
      case 'b_chaos_altar':
        return `+${40 + (level - 1) * 6}% Primordial Qi & +${level * 2}% All Yields`;
      default:
        return `Lv ${level} Pavilion Aura (+${level * 5}% Output)`;
    }
  };

  return {
    current: formatForLevel(lv),
    next: nextLv ? formatForLevel(nextLv) : null
  };
}

export const BuildingsTab: React.FC<BuildingsTabProps> = ({
  buildings,
  disciples,
  resources,
  prestige = 0,
  devMode = false,
  onUpgradeBuilding,
  onUnlockBuilding,
  onOpenAssignModal
}) => {
  const hall = buildings.find(b => b.type === 'hall');
  const hallLevel = hall?.level || 1;

  return (
    <div className="space-y-3.5 pb-20">
      <div className="flex justify-between items-center px-1">
        <div>
          <h2 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
            Sect Architecture &amp; Daoist Pavilions
          </h2>
          <p className="text-[11px] text-[#9fc2b2]">
            Upgrades scale live output per level. Assign compatible staff (+1 slot per 10 levels) to multiply yields.
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {buildings.map((building) => {
          const effectiveMaxDisciples = 2 + Math.floor(building.level / 10);

          if (!building.unlocked) {
            const canUnlock = devMode || !building.unlockRequirement?.minHallLevel || hallLevel >= building.unlockRequirement.minHallLevel;

            return (
              <div
                key={building.id}
                className="bg-[#09261d] border border-dashed border-[#1b4b3b] rounded-2xl p-3.5 sm:p-4 shadow-sm opacity-85 space-y-2.5"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-[#e2b054]" />
                    <span className="font-dao font-bold text-sm sm:text-base text-gray-300">
                      {building.name} (Locked)
                    </span>
                  </div>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-gray-800 text-amber-300 border border-gray-700">
                    {building.unlockRequirement?.description || 'Locked'}
                  </span>
                </div>

                <p className="text-[11px] text-[#8daea0] leading-relaxed">
                  {building.description}
                </p>

                <div className="flex justify-between items-center pt-1 border-t border-[#1b4b3b]">
                  <span className="text-[10px] text-[#9fc2b2]">
                    Prerequisite: Grand Dao Hall Lv {building.unlockRequirement?.minHallLevel || 1}
                  </span>

                  <button
                    disabled={!canUnlock}
                    onClick={() => {
                      soundEngine.playGong();
                      onUnlockBuilding(building);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-dao font-bold text-xs flex items-center gap-1.5 transition-all ${
                      canUnlock
                        ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95 shadow-sm'
                        : 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                    }`}
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    <span>Unlock Pavilion</span>
                  </button>
                </div>
              </div>
            );
          }

          const upgradeCostStones = Math.floor(building.baseCost.spiritStones * Math.pow(building.costMultiplier, Math.min(building.level, 50)));
          const upgradeCostQi = building.baseCost.qi ? Math.floor(building.baseCost.qi * Math.pow(building.costMultiplier, Math.min(building.level, 50))) : 0;
          const upgradeCostMerit = building.baseCost.merit ? Math.floor(building.baseCost.merit * Math.pow(building.costMultiplier, Math.min(building.level, 50))) : 0;

          const canAfford =
            building.level < building.maxLevel &&
            (devMode ||
              (resources.spiritStones >= upgradeCostStones &&
                resources.qi >= upgradeCostQi &&
                resources.merit >= upgradeCostMerit));

          const assignedList = disciples.filter(d => building.assignedDisciples.includes(d.id));

          let avgCompatibility = 0;
          let avgMultiplier = 1.0;
          if (assignedList.length > 0) {
            const compats = assignedList.map(d => calculateStaffCompatibility(building, d));
            avgCompatibility = Math.round(compats.reduce((acc, c) => acc + c.percentage, 0) / compats.length);
            avgMultiplier = parseFloat((compats.reduce((acc, c) => acc + c.yieldMultiplier, 0) / compats.length).toFixed(2));
          }

          const scaled = getBuildingScaledEffect(building);
          const alchemyStats = building.id === 'b_alchemy'
            ? calculateAlchemySuccessProbability(building, disciples, prestige)
            : null;

          return (
            <div
              key={building.id}
              className="bg-[#123d30] border border-[#e2b054]/30 rounded-2xl p-3.5 sm:p-4 shadow-md space-y-2.5"
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-dao font-bold text-sm sm:text-base text-[#fce18b]">
                      {building.name}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#1e5845] text-[#dcfce7] border border-[#34d399]/30 font-bold font-mono">
                      Lv {building.level}/{building.maxLevel}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#a4c5b7] mt-1 leading-relaxed">
                    {building.description}
                  </p>
                </div>
              </div>

              {/* Current Lv & Next Lv Scaled Stats */}
              <div className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] space-y-1.5 text-xs">
                <div className="flex items-center justify-between gap-2 text-[#86efac]">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <Sparkles className="w-3.5 h-3.5 text-[#e2b054] shrink-0" />
                    <span className="font-semibold">Now (Lv {building.level}): {scaled.current}</span>
                  </div>
                  {assignedList.length > 0 && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-mono font-bold shrink-0">
                      ⚡ {avgMultiplier}x ({avgCompatibility}%)
                    </span>
                  )}
                </div>

                {scaled.next && (
                  <div className="flex items-center gap-1.5 text-[10px] text-[#fce18b] border-t border-[#143d30] pt-1">
                    <TrendingUp className="w-3 h-3 text-amber-300 shrink-0" />
                    <span>Next (Lv {building.level + 1}): <strong>{scaled.next}</strong></span>
                  </div>
                )}
              </div>

              {/* Alchemy Pill Refinement Probability Card */}
              {alchemyStats && (
                <div className="bg-gradient-to-r from-[#0e3429] to-[#08221a] p-2.5 rounded-xl border border-[#34d399]/40 flex flex-wrap justify-between items-center gap-2 text-[11px]">
                  <div className="flex items-center gap-2">
                    <FlaskConical className="w-4 h-4 text-emerald-300 shrink-0" />
                    <div>
                      <span className="font-bold text-white">Pill Refinement Success Rate: </span>
                      <span className="font-mono font-extrabold text-sm text-emerald-300">
                        {alchemyStats.probability}%
                      </span>
                    </div>
                  </div>
                  <div className="text-[10px] text-[#a4c5b7] font-mono">
                    {alchemyStats.staffCount > 0 ? `Avg Talent ${alchemyStats.avgTalent}` : 'No Alchemist (Base)'} · Prestige +{alchemyStats.prestigeBonus}% · Lv +{alchemyStats.levelBonus}%
                  </div>
                </div>
              )}

              {/* Staffing / Assigned Disciples */}
              <div className="flex justify-between items-center bg-[#0d2e23] p-2.5 rounded-xl border border-[#1d5543] text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  <Users className="w-4 h-4 text-[#93c5fd] shrink-0" />
                  <span className="text-[#cbe3d7] shrink-0">
                    Staff: <strong className="text-white">{assignedList.length}/{effectiveMaxDisciples}</strong>
                  </span>
                  {assignedList.length > 0 && (
                    <span className="text-[10px] text-[#9fc2b2] truncate">
                      ({assignedList.map(d => d.name).join(', ')})
                    </span>
                  )}
                </div>
                <button
                  onClick={() => {
                    soundEngine.playClick();
                    onOpenAssignModal(building);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#184838] hover:bg-[#1f5a46] text-[#fce18b] border border-[#e2b054]/40 text-[10px] font-bold shrink-0 ml-2"
                >
                  Assign Staff
                </button>
              </div>

              {/* Upgrade Button & Costs */}
              <div className="flex items-center justify-between pt-1 border-t border-[#1b4b3b]">
                <div className="text-[10px] sm:text-[11px] text-[#a4c5b7] flex items-center gap-2 flex-wrap">
                  <span>Cost:</span>
                  <span className={resources.spiritStones >= upgradeCostStones ? "text-[#fce18b]" : "text-red-400"}>
                    💎 {formatLargeNumber(upgradeCostStones)}
                  </span>
                  {upgradeCostQi > 0 && (
                    <span className={resources.qi >= upgradeCostQi ? "text-emerald-400" : "text-red-400"}>
                      · 🟢 {formatLargeNumber(upgradeCostQi)}
                    </span>
                  )}
                  {upgradeCostMerit > 0 && (
                    <span className={resources.merit >= upgradeCostMerit ? "text-amber-400" : "text-red-400"}>
                      · 📜 {formatLargeNumber(upgradeCostMerit)}
                    </span>
                  )}
                </div>

                <button
                  disabled={!canAfford}
                  onClick={() => {
                    soundEngine.playGong();
                    onUpgradeBuilding(building);
                  }}
                  className={`px-3 py-1.5 rounded-xl font-dao font-bold text-xs flex items-center gap-1.5 transition-all ${
                    canAfford
                      ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] hover:brightness-110 active:scale-95 shadow-sm'
                      : 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700'
                  }`}
                >
                  <ArrowUpCircle className="w-3.5 h-3.5" />
                  <span>{building.level >= building.maxLevel ? 'Max Level' : 'Upgrade'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

