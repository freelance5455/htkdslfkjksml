import React, { useState, useEffect } from 'react';
import {
  Season,
  SectResources,
  ResourceRates,
  Disciple,
  Building,
  SectAlignment,
  SectAlignmentData,
  DynamicSectEvent,
  DivinePetition
} from '../../types/cultivation';
import { formatLargeNumber } from '../../data/realms';
import { SpiritStoneIcon, QiOrbIcon, PillFlaskIcon, MeritScrollIcon } from '../icons/DaoIcons';
import {
  TrendingUp,
  ShieldCheck,
  Sparkles,
  Clock,
  Flame,
  Crown,
  HeartHandshake,
  AlertOctagon,
  MessageSquare,
  Gift,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { soundEngine } from '../../services/audioEngine';

interface OverviewTabProps {
  season: Season;
  year: number;
  resources: SectResources;
  rates: ResourceRates;
  disciples: Disciple[];
  buildings: Building[];
  prestige: number;
  devMode?: boolean;
  alignmentData: SectAlignmentData;
  onSelectAlignment: (alignment: SectAlignment) => void;
  dynamicEvents: DynamicSectEvent[];
  onResolveEvent: (eventId: string, choiceIndex: number) => void;
  divinePetitions: DivinePetition[];
  onResolvePetition: (petitionId: string, action: 'grant' | 'counsel' | 'punish' | 'banish') => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  season,
  year,
  resources,
  rates,
  disciples,
  buildings,
  prestige,
  devMode = false,
  alignmentData,
  onSelectAlignment,
  dynamicEvents,
  onResolveEvent,
  divinePetitions,
  onResolvePetition
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'events' | 'alignment' | 'analytics'>('events');
  const [confirmingAlignment, setConfirmingAlignment] = useState<SectAlignment | null>(null);

  // Timers countdown tick
  const [, setTick] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const totalCombatPower = disciples.reduce((acc, d) => acc + d.combatPower, 0);
  const outerCount = disciples.filter(d => d.rank === 'Outer').length;
  const innerCount = disciples.filter(d => d.rank === 'Inner').length;
  const directCount = disciples.filter(d => d.rank === 'Direct').length;
  const elderCount = disciples.filter(d => d.rank === 'Elder' || d.rank === 'Grand Elder').length;

  const activeQuests = alignmentData.quests[alignmentData.currentAlignment] || [];

  return (
    <div className="space-y-3.5 pb-20">
      {/* Overview Top Header Banner */}
      <div className="bg-[#f9f5ea] text-[#132d23] p-3.5 sm:p-4 rounded-2xl border border-[#e8dbc0] shadow-md flex justify-between items-center">
        <div>
          <h2 className="text-base sm:text-lg font-bold font-dao text-[#0f2b20]">
            Sect Simulation & Realm Mandates
          </h2>
          <div className="text-[11px] text-[#4b6659] mt-0.5">
            Season: <strong className="text-[#995d08]">{season}, Year {year}</strong> · Alignment: <strong className="text-[#15803d]">{alignmentData.currentAlignment}</strong>
          </div>
        </div>
        <div className="w-10 h-10 rounded-xl bg-[#184838]/10 flex items-center justify-center p-1">
          <TrendingUp className="w-5 h-5 text-[#184838]" />
        </div>
      </div>

      {/* Sub-tabs: Dynamic Events & God Petitions | 5 Alignments & Quests | Resource Analytics */}
      <div className="grid grid-cols-3 bg-[#09261d] p-1 rounded-2xl border border-[#1b4b3b] text-xs font-bold font-dao">
        <button
          onClick={() => setActiveSubTab('events')}
          className={`py-2 rounded-xl transition-all relative ${
            activeSubTab === 'events'
              ? 'bg-[#184838] text-[#fce18b] shadow-xs'
              : 'text-[#8daea0] hover:text-white'
          }`}
        >
          <span>World Simulation</span>
          {(dynamicEvents.length > 0 || divinePetitions.length > 0) && (
            <span className="ml-1 bg-red-600 text-white text-[9px] px-1.5 py-0.2 rounded-full font-mono">
              {dynamicEvents.length + divinePetitions.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('alignment')}
          className={`py-2 rounded-xl transition-all ${
            activeSubTab === 'alignment'
              ? 'bg-[#184838] text-[#fce18b] shadow-xs'
              : 'text-[#8daea0] hover:text-white'
          }`}
        >
          <span>Sect Alignments</span>
        </button>

        <button
          onClick={() => setActiveSubTab('analytics')}
          className={`py-2 rounded-xl transition-all ${
            activeSubTab === 'analytics'
              ? 'bg-[#184838] text-[#fce18b] shadow-xs'
              : 'text-[#8daea0] hover:text-white'
          }`}
        >
          <span>Resource Analytics</span>
        </button>
      </div>

      {/* SUB-TAB 1: DYNAMIC EVENTS & GOD PETITIONS */}
      {activeSubTab === 'events' && (
        <div className="space-y-3.5 animate-fade-in">
          {/* Dynamic Sect Events (Appear every 2-5 min, specific time limit) */}
          <div className="space-y-2.5">
            <div className="flex justify-between items-center px-1">
              <h3 className="font-dao font-bold text-sm text-[#fce18b] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#e2b054]" />
                <span>Simulated Sect Events ({dynamicEvents.length})</span>
              </h3>
              <span className="text-[10px] text-[#9fc2b2]">
                Appears dynamically · Time-limited
              </span>
            </div>

            {dynamicEvents.length === 0 ? (
              <div className="bg-[#123d30]/60 p-6 rounded-2xl border border-dashed border-[#e2b054]/30 text-center text-xs text-[#a4c5b7]">
                The leylines are quiet. New random sect encounters, opportunities, and crises spawn every few minutes.
              </div>
            ) : (
              dynamicEvents.map((event) => {
                const timeLeft = Math.max(0, Math.floor((event.expiresAt - Date.now()) / 1000));
                const progressPct = Math.min(100, Math.max(0, (timeLeft / event.totalDurationSeconds) * 100));

                return (
                  <div
                    key={event.id}
                    className="bg-[#123d30] border-2 border-[#e2b054]/60 rounded-2xl p-3.5 shadow-md space-y-3"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-dao font-bold text-sm text-white">{event.title}</span>
                          <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#184838] text-[#86efac] font-bold border border-[#22c55e]/30">
                            {event.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#d1e6dc] mt-1 leading-relaxed">
                          {event.description}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-[10px] font-mono font-bold text-amber-300 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>{timeLeft}s left</span>
                        </span>
                      </div>
                    </div>

                    {/* Time limit progress countdown */}
                    <div className="w-full bg-[#072018] h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-amber-400 h-full transition-all duration-1000"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>

                    {/* Player Action Choices */}
                    <div className="space-y-1.5 pt-1">
                      {event.choices.map((choice, cIdx) => (
                        <button
                          key={cIdx}
                          onClick={() => {
                            soundEngine.playTalisman();
                            onResolveEvent(event.id, cIdx);
                          }}
                          className="w-full p-2 rounded-xl bg-[#09261d] hover:bg-[#184838] border border-[#1b4b3b] hover:border-[#e2b054]/50 text-left text-xs text-[#fce18b] flex justify-between items-center transition-all group"
                        >
                          <span className="group-hover:translate-x-1 transition-transform">{choice.text}</span>
                          <span className="text-[10px] text-[#86efac] font-mono">Resolve ➔</span>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Divine Petitions (Disciples Talking to the Player as a God) */}
          <div className="space-y-2.5 pt-2">
            <div className="flex justify-between items-center px-1">
              <h3 className="font-dao font-bold text-sm text-[#fce18b] flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-[#e2b054]" />
                <span>Heavenly Petitions to the Sect God ({divinePetitions.length})</span>
              </h3>
              <span className="text-[10px] text-[#9fc2b2]">
                Divine audience & judgements
              </span>
            </div>

            {divinePetitions.length === 0 ? (
              <div className="bg-[#123d30]/60 p-6 rounded-2xl border border-dashed border-[#e2b054]/30 text-center text-xs text-[#a4c5b7]">
                No disciples currently petitioning at the Heavenly Altar. Disciples seek divine counsel when facing heavy dilemmas.
              </div>
            ) : (
              divinePetitions.map((petition) => (
                <div
                  key={petition.id}
                  className="bg-[#09261d] p-3.5 rounded-2xl border border-[#1b4b3b] space-y-3"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-[#fce18b] text-sm font-dao">{petition.discipleName}</strong>
                        <span className="text-[10px] text-[#9fc2b2]">petitions the Heavenly Sovereign</span>
                      </div>
                      <div className="text-xs font-bold text-white mt-0.5">{petition.title}</div>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#184838] text-[#86efac] border border-[#22c55e]/30 font-bold">
                      {petition.type}
                    </span>
                  </div>

                  <p className="text-[11px] text-[#d1e6dc] italic bg-[#061913] p-2.5 rounded-xl border border-[#143d2f] leading-relaxed">
                    "{petition.concernText}"
                  </p>

                  {/* As a God: Reward, Counsel, Punish, Banish */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                    <button
                      onClick={() => {
                        soundEngine.playTalisman();
                        onResolvePetition(petition.id, 'grant');
                      }}
                      className="py-1.5 px-2 rounded-xl bg-[#15803d] hover:bg-[#16a34a] text-white font-bold text-[10px] flex items-center justify-center gap-1 shadow-xs"
                    >
                      <Gift className="w-3 h-3" />
                      <span>Grant Blessing</span>
                    </button>

                    <button
                      onClick={() => {
                        soundEngine.playClick();
                        onResolvePetition(petition.id, 'counsel');
                      }}
                      className="py-1.5 px-2 rounded-xl bg-[#123d30] hover:bg-[#184838] text-[#fce18b] border border-[#e2b054]/40 font-bold text-[10px] flex items-center justify-center gap-1"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>Dao Counsel</span>
                    </button>

                    <button
                      onClick={() => {
                        soundEngine.playGong();
                        onResolvePetition(petition.id, 'punish');
                      }}
                      className="py-1.5 px-2 rounded-xl bg-amber-950/60 hover:bg-amber-900 text-amber-200 border border-amber-600/40 font-bold text-[10px] flex items-center justify-center gap-1"
                    >
                      <AlertOctagon className="w-3 h-3" />
                      <span>Disciplinary Rebuke</span>
                    </button>

                    <button
                      onClick={() => {
                        soundEngine.playThunder();
                        onResolvePetition(petition.id, 'banish');
                      }}
                      className="py-1.5 px-2 rounded-xl bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-700/50 font-bold text-[10px] flex items-center justify-center gap-1"
                    >
                      <span>Banish From Sect</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: 5 SECT ALIGNMENTS & PROGRESSION QUESTS */}
      {activeSubTab === 'alignment' && (
        <div className="space-y-4 animate-fade-in">
          <div className="bg-[#123d30] p-4 rounded-2xl border border-[#e2b054]/30 space-y-3">
            <div className="flex justify-between items-center border-b border-[#1b4b3b] pb-2">
              <div>
                <h3 className="font-dao font-bold text-sm text-[#fce18b]">
                  Sect Moral Alignment
                </h3>
                <p className="text-[11px] text-[#9fc2b2]">
                  Alignments can only be consecrated <strong>once</strong> in sect history. Shapes diplomatic alliances and unlocks supreme Dao ascension quests.
                </p>
              </div>
              <span className={`text-[11px] px-2.5 py-1 rounded-xl font-bold font-dao ${
                alignmentData.canChange ? 'bg-amber-900/40 text-amber-300 border border-amber-500/40' : 'bg-green-900/40 text-green-300 border border-green-500/40'
              }`}>
                {alignmentData.canChange ? 'Can Choose Once' : 'Permanently Sealed'}
              </span>
            </div>

            {/* Confirmation Dialog to Prevent Accidental Taps */}
            {confirmingAlignment && alignmentData.canChange && (
              <div className="p-3.5 rounded-2xl bg-[#071f17] border-2 border-[#fce18b] shadow-xl space-y-2.5 animate-scale-up">
                <div className="font-dao font-bold text-sm text-[#fce18b]">
                  Seal Sect Alignment: {confirmingAlignment}?
                </div>
                <p className="text-[11px] text-[#d1e6dc] leading-relaxed">
                  Consecrating your sect’s permanent Dao Alignment can only be sealed <strong>once in sect history</strong>. Diplomatic relations and Alignment Ascension quests will permanently lock to <strong>{confirmingAlignment}</strong>.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      soundEngine.playGong();
                      onSelectAlignment(confirmingAlignment);
                      setConfirmingAlignment(null);
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs hover:brightness-110"
                  >
                    Confirm &amp; Seal Permanently
                  </button>
                  <button
                    onClick={() => {
                      soundEngine.playClick();
                      setConfirmingAlignment(null);
                    }}
                    className="py-2 px-4 rounded-xl bg-[#123d30] text-[#9fc2b2] hover:text-white border border-[#1d5543] font-bold text-xs"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* 5 Alignments Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {([
                { name: 'Righteous Orthodox' as SectAlignment, desc: 'Uphold heavenly justice. Harmonizes with Sword Sect & Pill Pavilion.', req: 'Requires Merit >= 5,000' },
                { name: 'Demonic Blood Cult' as SectAlignment, desc: 'Might makes right. Blood sacrifice and unholy dominance.', req: 'Requires Combat Power >= 10,000' },
                { name: 'Buddhic Zen' as SectAlignment, desc: 'Compassionate karmic detachment. Zero tolerance for malice.', req: 'Requires 0 Active Grudges' },
                { name: 'Cloud Mist Neutral' as SectAlignment, desc: 'Wandering hermit freedom. Independent mercantile harmony.', req: 'Accessible Anytime' },
                { name: 'Imperial Court' as SectAlignment, desc: 'Royal decree & imperial governance over the mortal realm.', req: 'Requires Noble Bloodline Disciple' }
              ]).map((align) => {
                const isSelected = alignmentData.currentAlignment === align.name;
                const grudgeCount = disciples.reduce(
                  (cnt, d) => cnt + d.relations.filter(r => r.jealousy > 0 || r.type === 'Grudge').length,
                  0
                );
                const hasNoble = disciples.some(
                  d => d.background === 'Imperial Clan Scion' || d.background === 'Ancient Aristocrat Prodigy'
                );

                let met = true;
                let statusMsg = 'Requirements Met';
                if (align.name === 'Righteous Orthodox') {
                  met = resources.merit >= 5000;
                  statusMsg = met ? 'Merit Reached' : `${formatLargeNumber(resources.merit)} / 5,000 Merit`;
                } else if (align.name === 'Demonic Blood Cult') {
                  met = totalCombatPower >= 10000;
                  statusMsg = met ? 'Might Reached' : `${formatLargeNumber(totalCombatPower)} / 10,000 Power`;
                } else if (align.name === 'Buddhic Zen') {
                  met = grudgeCount === 0;
                  statusMsg = met ? '0 Grudges · Pure' : `${grudgeCount} Active Grudges`;
                } else if (align.name === 'Imperial Court') {
                  met = hasNoble;
                  statusMsg = met ? 'Noble Scion Present' : 'Need Imperial/Aristocrat Disciple';
                }

                const canClick = alignmentData.canChange && (met || devMode);

                return (
                  <div
                    key={align.name}
                    className={`p-3 rounded-xl border transition-all ${
                      isSelected
                        ? 'bg-[#184838] border-[#e2b054] shadow-sm'
                        : confirmingAlignment === align.name
                        ? 'bg-[#123d30] border-[#fce18b]'
                        : 'bg-[#09261d] border-[#1b4b3b]'
                    }`}
                  >
                    <div className="flex justify-between items-center gap-2">
                      <strong className="font-dao text-white text-xs">{align.name}</strong>
                      {isSelected ? (
                        <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#15803d] text-white font-bold">
                          Active
                        </span>
                      ) : alignmentData.canChange ? (
                        <button
                          disabled={!canClick}
                          onClick={() => {
                            soundEngine.playClick();
                            setConfirmingAlignment(align.name);
                          }}
                          className={`text-[9px] px-2.5 py-1 rounded-lg font-bold border transition-all ${
                            canClick
                              ? 'bg-[#123d30] text-[#fce18b] border-[#e2b054]/50 hover:bg-[#184838]'
                              : 'bg-gray-900/70 text-gray-500 border-gray-700 cursor-not-allowed'
                          }`}
                        >
                          {canClick ? 'Select...' : 'Unmet'}
                        </button>
                      ) : (
                        <span className="text-[9px] text-[#64748b] flex items-center gap-0.5">
                          <Lock className="w-2.5 h-2.5" /> Locked
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-[#9fc2b2] mt-1 leading-relaxed">
                      {align.desc}
                    </p>
                    <div className="flex justify-between items-center mt-1.5 text-[9px] font-mono">
                      <span className="text-[#e2b054]">{align.req}</span>
                      <span className={met || devMode ? 'text-emerald-300 font-bold' : 'text-red-300'}>
                        {met ? `✓ ${statusMsg}` : statusMsg}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3 Progression Quests for Current Alignment */}
          <div className="bg-[#09261d] p-4 rounded-2xl border border-[#1b4b3b] space-y-3">
            <h4 className="font-dao font-bold text-sm text-[#fce18b] flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#86efac]" />
              <span>Alignment Ascension Quests: {alignmentData.currentAlignment}</span>
            </h4>

            <div className="space-y-2">
              {activeQuests.map((quest) => (
                <div
                  key={quest.id}
                  className="bg-[#123d30] p-3 rounded-xl border border-[#1b4b3b] space-y-1 text-xs"
                >
                  <div className="flex justify-between items-center">
                    <strong className="text-white font-dao">{quest.title}</strong>
                    {quest.completed ? (
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#15803d] text-white font-bold">
                        Accomplished
                      </span>
                    ) : (
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-amber-900/40 text-amber-300 font-bold border border-amber-500/40">
                        In Progress
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-[#9fc2b2]">{quest.description}</p>
                  <div className="text-[10px] text-[#fce18b] pt-0.5 flex justify-between">
                    <span>Target: {quest.requirementDesc}</span>
                    <span className="text-[#86efac] font-bold">{quest.rewardDesc}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: RESOURCE ANALYTICS */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-3.5 animate-fade-in">
          {/* Net Resource Generation Box */}
          <div className="bg-[#f9f5ea] text-[#132d23] p-4 rounded-2xl border border-[#e8dbc0] shadow-md space-y-3">
            <h3 className="text-sm sm:text-base font-bold font-dao text-[#0f2b20] border-b border-[#e5d8be] pb-2">
              Net Resource Generation
            </h3>

            <div className="space-y-3 divide-y divide-[#ebe1cd]">
              {/* Spirit Stones */}
              <div className="pt-2 flex justify-between items-center">
                <div className="flex items-center gap-2.5">
                  <SpiritStoneIcon className="w-5 h-5" />
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-[#0f2b20]">Spirit Stones</div>
                    <div className="text-[11px] text-[#557366]">Stock: {formatLargeNumber(resources.spiritStones)}</div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[#15803d] font-mono font-bold text-xs sm:text-sm">
                    +{rates.spiritStonesRate}/sec
                  </span>
                </div>
              </div>

              {/* Qi */}
              <div className="pt-2 flex justify-between items-center">
                <div className="flex items-center gap-2.5">
                  <QiOrbIcon className="w-5 h-5" />
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-[#0f2b20]">Qi</div>
                    <div className="text-[11px] text-[#557366]">Stock: {formatLargeNumber(resources.qi)}</div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[#15803d] font-mono font-bold text-xs sm:text-sm">
                    +{rates.qiRate}/sec
                  </span>
                </div>
              </div>

              {/* Pills */}
              <div className="pt-2 flex justify-between items-center">
                <div className="flex items-center gap-2.5">
                  <PillFlaskIcon className="w-5 h-5" />
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-[#0f2b20]">Pills</div>
                    <div className="text-[11px] text-[#557366]">Stock: {formatLargeNumber(resources.pills)}</div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[#0f766e] font-mono font-bold text-xs sm:text-sm">
                    +{rates.pillsRate}/sec
                  </span>
                </div>
              </div>

              {/* Merit */}
              <div className="pt-2 flex justify-between items-center">
                <div className="flex items-center gap-2.5">
                  <MeritScrollIcon className="w-5 h-5" />
                  <div>
                    <div className="font-bold text-xs sm:text-sm text-[#0f2b20]">Merit (Reputation)</div>
                    <div className="text-[11px] text-[#557366]">Stock: {formatLargeNumber(resources.merit)}</div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[#854d0e] font-mono font-bold text-xs sm:text-sm">
                    +{rates.meritRate}/sec
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Demographic & Power Analytics */}
          <div className="bg-[#123d30] border border-[#e2b054]/30 rounded-2xl p-4 shadow-md space-y-3">
            <h3 className="text-sm font-bold font-dao text-[#fce18b] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#e2b054]" />
              <span>Sect Martial Demographics</span>
            </h3>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b]">
                <div className="text-[#8daea0]">Total Sect Combat Power</div>
                <div className="text-base font-bold font-mono text-[#fce18b] mt-0.5">
                  {formatLargeNumber(totalCombatPower)}
                </div>
              </div>

              <div className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b]">
                <div className="text-[#8daea0]">Sect Prestige Rating</div>
                <div className="text-base font-bold font-mono text-[#86efac] mt-0.5">
                  {formatLargeNumber(prestige)}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-1.5 text-center text-[10px]">
              <div className="bg-[#09261d] p-2 rounded-lg border border-[#1b4b3b]">
                <div className="text-[#8daea0]">Outer</div>
                <div className="text-sm font-bold text-white mt-0.5">{outerCount}</div>
              </div>
              <div className="bg-[#09261d] p-2 rounded-lg border border-[#1b4b3b]">
                <div className="text-[#8daea0]">Inner</div>
                <div className="text-sm font-bold text-[#86efac] mt-0.5">{innerCount}</div>
              </div>
              <div className="bg-[#09261d] p-2 rounded-lg border border-[#1b4b3b]">
                <div className="text-[#8daea0]">Direct</div>
                <div className="text-sm font-bold text-[#fce18b] mt-0.5">{directCount}</div>
              </div>
              <div className="bg-[#09261d] p-2 rounded-lg border border-[#1b4b3b]">
                <div className="text-[#8daea0]">Elders</div>
                <div className="text-sm font-bold text-[#f472b6] mt-0.5">{elderCount}</div>
              </div>
            </div>
          </div>

          {/* Disciple Family Tree & Lineage History */}
          <div className="bg-[#123d30] border border-[#e2b054]/30 rounded-2xl p-4 shadow-md space-y-3">
            <h3 className="text-sm font-bold font-dao text-[#fce18b] flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-[#e2b054]" />
                <span>Disciple Lineage & Generational Heritage</span>
              </span>
              <span className="text-[10px] text-[#9fc2b2] font-mono">{disciples.length} Disciples Inscribed</span>
            </h3>

            <p className="text-[11px] text-[#9fc2b2] leading-relaxed">
              Generational lineage of the sect, tracking disciples from foundational elders to the newest outer acolytes:
            </p>

            <div className="space-y-2 pt-1">
              {(['Sect Leader', 'Grand Elder', 'Elder', 'Direct', 'Inner', 'Outer'] as const).map(rank => {
                const rankDisciples = disciples.filter(d => d.rank === rank);
                if (rankDisciples.length === 0) return null;

                return (
                  <div key={rank} className="bg-[#09261d] p-2.5 rounded-xl border border-[#1b4b3b] space-y-1.5">
                    <div className="flex justify-between items-center text-[10px] font-bold text-[#e2b054]">
                      <span>{rank} Tier</span>
                      <span className="text-[#a4c5b7]">{rankDisciples.length} cultivator(s)</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {rankDisciples.map(d => {
                        const mentorBond = d.relations.find(r => r.type === 'Master-Disciple');
                        const mentor = mentorBond ? disciples.find(m => m.id === mentorBond.targetId) : null;
                        const companionBond = d.relations.find(r => r.type === 'Lover');
                        const companion = companionBond ? disciples.find(c => c.id === companionBond.targetId) : null;

                        return (
                          <div
                            key={d.id}
                            className="p-2 rounded-lg bg-[#123d30] border border-[#1b4b3b] text-[10px] flex justify-between items-center"
                          >
                            <div>
                              <div className="font-bold text-white flex items-center gap-1">
                                <span>{d.name}</span>
                                {d.championTitle && (
                                  <span className="text-[8px] text-amber-300 font-mono">👑</span>
                                )}
                              </div>
                              <div className="text-[9px] text-[#86efac]">
                                {d.spiritRoot} Root · {d.constitution}
                              </div>
                            </div>

                            <div className="text-right text-[9px] text-[#9fc2b2]">
                              {mentor ? (
                                <span className="text-sky-300">Disciple of {mentor.name}</span>
                              ) : companion ? (
                                <span className="text-rose-300">Dao Mate of {companion.name}</span>
                              ) : (
                                <span>Independent Path</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
