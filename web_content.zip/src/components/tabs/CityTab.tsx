import React from 'react';
import { Building2, Coffee, Trees, Film, Trophy, Skull, RotateCcw, Award } from 'lucide-react';
import { GameState } from '../../game/types';
import { playClickSound } from '../../utils/audio';

interface CityTabProps {
  gameState: GameState;
  onCityAction: (action: 'cafe' | 'park' | 'cinema' | 'tournament' | 'festival') => void;
  onToggleDarkPath: () => void;
  onResetGame: () => void;
}

export const CityTab: React.FC<CityTabProps> = ({
  gameState,
  onCityAction,
  onToggleDarkPath,
  onResetGame
}) => {
  const achievementsList = [
    { id: 'first_job', title: 'أول يوم عمل شريف', done: gameState.daysWorked >= 1 },
    { id: 'engaged', title: 'إتمام الخطوبة الرسمية', done: gameState.engaged || gameState.married },
    { id: 'wedding', title: 'عش الزوجية السعيد 💒', done: gameState.married },
    { id: 'first_baby', title: 'المولود الأول في الأسرة 👶', done: gameState.children.length >= 1 },
    { id: 'fitness_10', title: 'لياقة الأبطال (مستوى 5+ في الجيم)', done: gameState.fitnessLevel >= 5 },
    { id: 'home_owner', title: 'امتلاك منزل الأحلام', done: gameState.assets.includes('home') || gameState.assets.includes('villa') },
    { id: 'business_owner', title: 'رائد أعمال ومشروع تجاري', done: gameState.assets.includes('business') || gameState.assets.includes('workshop') },
    { id: 'degree', title: 'خريج بدرجة جامعية عليا', done: gameState.completedCourseIds.includes('university_degree') },
    { id: 'millionaire', title: 'مليونير المستقبل (1,000,000 ج.م)', done: gameState.money >= 1000000 }
  ];

  return (
    <div className="space-y-3">
      {/* City Entertainment */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
            <Building2 className="w-5 h-5" />
          </span>
          <div>
            <h2 className="text-sm font-bold text-slate-100">استكشف شوارع وفعاليات المدينة</h2>
            <p className="text-[11px] text-slate-400">غير جو، ترفّه عن نفسك، وشارك في بطولات وأنشطة</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {/* Cafe */}
          <button
            onClick={() => { playClickSound(); onCityAction('cafe'); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">☕</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-amber-300">
              قعدة كافيه هادئة
            </strong>
            <small className="block text-[10px] text-slate-400 mt-0.5">
              مشروب يروق المزاج • 90 ج.م
            </small>
          </button>

          {/* Park */}
          <button
            onClick={() => { playClickSound(); onCityAction('park'); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-emerald-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">🌳</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-emerald-300">
              حديقة عامة وطبيعة
            </strong>
            <small className="block text-[10px] text-slate-400 mt-0.5">
              هواء منعش وطاقة إيجابية • 30 ج.م
            </small>
          </button>

          {/* Cinema */}
          <button
            onClick={() => { playClickSound(); onCityAction('cinema'); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-indigo-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">🎬</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-indigo-300">
              سينما وفيلم جديد
            </strong>
            <small className="block text-[10px] text-slate-400 mt-0.5">
              أجواء تسلية ومرح • 180 ج.م
            </small>
          </button>

          {/* Chess / Intellect Tournament */}
          <button
            onClick={() => { playClickSound(); onCityAction('tournament'); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-cyan-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">🏆</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-cyan-300">
              بطولة شطرنج وذكاء
            </strong>
            <small className="block text-[10px] text-slate-400 mt-0.5">
              جوائز وسمعة وتطوير مهارة • 100 ج.م
            </small>
          </button>

          {/* Family Festival */}
          <button
            onClick={() => { playClickSound(); onCityAction('festival'); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-rose-400/50 text-right transition group sm:col-span-2"
          >
            <div className="text-xl mb-1">🎪</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-rose-300">
              مهرجان العائلة والترفيه
            </strong>
            <small className="block text-[10px] text-slate-400 mt-0.5">
              خروجة عائلية شاملة تسعد الزوجة والأولاد • 250 ج.م
            </small>
          </button>
        </div>
      </div>

      {/* Achievements List */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
            <Award className="w-5 h-5" />
          </span>
          <div>
            <h2 className="text-sm font-bold text-slate-100">لوحة الإنجازات والذكريات</h2>
            <p className="text-[11px] text-slate-400">
              محطات مضيئة تشهد على كفاحك ونجاحك
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {achievementsList.map((ach) => (
            <div
              key={ach.id}
              className={`p-3 rounded-2xl border text-xs flex items-center justify-between ${
                ach.done
                  ? 'bg-amber-950/20 border-amber-500/30 text-amber-200'
                  : 'bg-slate-950/60 border-slate-800 text-slate-500'
              }`}
            >
              <span className="font-semibold">{ach.title}</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                ach.done ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-500'
              }`}>
                {ach.done ? 'متحقق 🌟' : 'قيد الكفاح'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Settings & System Actions */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md space-y-2">
        <h2 className="text-sm font-bold text-slate-200 mb-2">⚙️ مسار اللعبة والخيارات الكبرى</h2>

        {/* Toggle Dark Path Button */}
        <button
          onClick={() => { playClickSound(); onToggleDarkPath(); }}
          className="w-full py-2.5 px-4 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center gap-2 transition"
        >
          <Skull className="w-4 h-4 text-red-400" />
          <span>
            {gameState.path === 'dark' ? 'إغلاق تبويب عالم الظلام' : '🕶️ دخول عالم الظلام والمخاطرة'}
          </span>
        </button>

        {/* Reset Game */}
        <button
          onClick={() => { playClickSound(); onResetGame(); }}
          className="w-full py-2.5 px-4 rounded-xl bg-red-950/40 hover:bg-red-900/50 border border-red-800/40 text-red-300 text-xs font-bold flex items-center justify-center gap-2 transition"
        >
          <RotateCcw className="w-4 h-4" />
          <span>بدء حياة جديدة ومسح التقدم</span>
        </button>
      </div>
    </div>
  );
};
