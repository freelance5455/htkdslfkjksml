import React from 'react';
import { Heart, Sparkles, Send, Coffee, Sunset, Gift, MessageCircleHeart, ShieldCheck } from 'lucide-react';
import { GameState } from '../../game/types';
import { playClickSound } from '../../utils/audio';

interface LoveTabProps {
  gameState: GameState;
  onRomanticAction: (action: 'poetry' | 'nile_dinner' | 'sunset_drive' | 'surprise_gift' | 'deep_talk' | 'reconcile') => void;
  onPropose: () => void;
  onWedding: () => void;
}

export const LoveTab: React.FC<LoveTabProps> = ({
  gameState,
  onRomanticAction,
  onPropose,
  onWedding
}) => {
  const { partnerName, love, trust, engaged, married } = gameState;

  return (
    <div className="space-y-3">
      {/* Partner Profile Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-500/20 to-pink-500/20 border border-rose-500/30 flex items-center justify-center text-3xl shadow-inner">
            👩🏻
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">{partnerName}</h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 font-bold">
                {married ? 'زوجتك وشريكة حياتك' : engaged ? 'خطيبتك الغالية' : 'شريكة روحك وحبيبتك'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
              {married
                ? `بيتكما دافئ ومستقر، والترابط الأسري يعتمد على عنايتك المستمرة بـ ${partnerName}.`
                : engaged
                ? `تستعدان لخطوة حفل الزفاف وإتمام عش الزوجية السعيد.`
                : `العلاقة تتطور تدريجياً بالاهتمام والاحترام واللقاءات الصادقة.`}
            </p>
          </div>
        </div>

        {/* Meters */}
        <div className="grid grid-cols-2 gap-3 mt-4 pt-3 border-t border-slate-800/80">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-rose-300 font-semibold flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400/20" />
                مستوى الحب
              </span>
              <span className="font-bold text-slate-200">{Math.round(love)}%</span>
            </div>
            <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-rose-500 to-pink-400 rounded-full transition-all"
                style={{ width: `${Math.min(100, Math.max(0, love))}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-cyan-300 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                الثقة والأمان
              </span>
              <span className="font-bold text-slate-200">{Math.round(trust)}%</span>
            </div>
            <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-sky-400 rounded-full transition-all"
                style={{ width: `${Math.min(100, Math.max(0, trust))}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Romantic Actions */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <h2 className="text-sm font-bold text-slate-200 mb-3">🌹 خيارات رومانسية واهتمام</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* Poetry & Letters */}
          <button
            onClick={() => { playClickSound(); onRomanticAction('poetry'); }}
            className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-rose-400/50 text-right transition group flex items-start gap-3"
          >
            <span className="p-2 rounded-xl bg-rose-500/10 text-rose-400 group-hover:scale-110 transition">
              <Send className="w-4 h-4" />
            </span>
            <div>
              <strong className="block text-xs font-bold text-slate-200 group-hover:text-rose-300">
                رسالة حب وتقدير رقيقة
              </strong>
              <small className="block text-[10px] text-slate-400 mt-0.5">
                كلمات صادقة تلمس القلب وتزيد القرب والمودة
              </small>
            </div>
          </button>

          {/* Nile Romantic Dinner */}
          <button
            onClick={() => { playClickSound(); onRomanticAction('nile_dinner'); }}
            className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-rose-400/50 text-right transition group flex items-start gap-3"
          >
            <span className="p-2 rounded-xl bg-rose-500/10 text-rose-400 group-hover:scale-110 transition">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <strong className="block text-xs font-bold text-slate-200 group-hover:text-rose-300">
                عشاء رومانسي على النيل
              </strong>
              <small className="block text-[10px] text-slate-400 mt-0.5">
                أجواء فاخرة وذكريات لا تُنسى • 320 ج.م
              </small>
            </div>
          </button>

          {/* Sunset Drive */}
          <button
            onClick={() => { playClickSound(); onRomanticAction('sunset_drive'); }}
            className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-400/50 text-right transition group flex items-start gap-3"
          >
            <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:scale-110 transition">
              <Sunset className="w-4 h-4" />
            </span>
            <div>
              <strong className="block text-xs font-bold text-slate-200 group-hover:text-amber-300">
                نزهة بالسيارة وقت الغروب
              </strong>
              <small className="block text-[10px] text-slate-400 mt-0.5">
                جولة على الكورنيش مع نسمات المسيل الهادئة
              </small>
            </div>
          </button>

          {/* Surprise Gift */}
          <button
            onClick={() => { playClickSound(); onRomanticAction('surprise_gift'); }}
            className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-pink-400/50 text-right transition group flex items-start gap-3"
          >
            <span className="p-2 rounded-xl bg-pink-500/10 text-pink-400 group-hover:scale-110 transition">
              <Gift className="w-4 h-4" />
            </span>
            <div>
              <strong className="block text-xs font-bold text-slate-200 group-hover:text-pink-300">
                مفاجأة عطر وورود أنيقة
              </strong>
              <small className="block text-[10px] text-slate-400 mt-0.5">
                هدية تبهج روحها وتظهر اهتمامك • 220 ج.م
              </small>
            </div>
          </button>

          {/* Deep Talk */}
          <button
            onClick={() => { playClickSound(); onRomanticAction('deep_talk'); }}
            className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-purple-400/50 text-right transition group flex items-start gap-3"
          >
            <span className="p-2 rounded-xl bg-purple-500/10 text-purple-400 group-hover:scale-110 transition">
              <MessageCircleHeart className="w-4 h-4" />
            </span>
            <div>
              <strong className="block text-xs font-bold text-slate-200 group-hover:text-purple-300">
                حديث القلب والمستقبل
              </strong>
              <small className="block text-[10px] text-slate-400 mt-0.5">
                تفاهم وانسجام عميق وتخطيط للأيام القادمة
              </small>
            </div>
          </button>

          {/* Reconcile */}
          <button
            onClick={() => { playClickSound(); onRomanticAction('reconcile'); }}
            className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-teal-400/50 text-right transition group flex items-start gap-3"
          >
            <span className="p-2 rounded-xl bg-teal-500/10 text-teal-400 group-hover:scale-110 transition">
              <Coffee className="w-4 h-4" />
            </span>
            <div>
              <strong className="block text-xs font-bold text-slate-200 group-hover:text-teal-300">
                مصالحة واحتواء راقٍ
              </strong>
              <small className="block text-[10px] text-slate-400 mt-0.5">
                إزالة أي عتاب وتجديد صفاء القلوب
              </small>
            </div>
          </button>
        </div>
      </div>

      {/* Engagement & Marriage Milestone Card */}
      {!married && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
          <h2 className="text-sm font-bold text-slate-200 mb-2">💍 الارتباط الرسمي وبناء البيت</h2>
          {!engaged ? (
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-100">التقدم لطلب إيدها رسمياً (الخطوبة)</div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  يتطلب: شقة تمليك/فيلا + 2,500 ج.م شبكة ودبلة + حب 60%+
                </p>
              </div>
              <button
                onClick={() => { playClickSound(); onPropose(); }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition"
              >
                تقدم للخطوبة
              </button>
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-100">إقامة حفل الزفاف المبارك 💒</div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  تكاليف الفرح وتجهيز بيت الزوجية: 15,000 ج.م
                </p>
              </div>
              <button
                onClick={() => { playClickSound(); onWedding(); }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 text-white font-bold text-xs shadow-md shadow-rose-500/20 active:scale-95 transition"
              >
                أقِم الفرح وتزوج
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
