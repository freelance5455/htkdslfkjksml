import React from 'react';
import { Skull, AlertTriangle, Shield, DollarSign, LogOut, FileSearch, UserX } from 'lucide-react';
import { GameState } from '../../game/types';
import { GANG_RANKS } from '../../game/constants';
import { playClickSound } from '../../utils/audio';

interface DarkTabProps {
  gameState: GameState;
  onCrime: (crimeType: 'steal' | 'smuggle' | 'heist' | 'bribe' | 'snitch' | 'quit' | 'join') => void;
}

export const DarkTab: React.FC<DarkTabProps> = ({ gameState, onCrime }) => {
  const { gang, heat, suspicion, loyalty, jail, crimesCount, partnerKnowsDark, partnerName } = gameState;
  const currentRank = GANG_RANKS[gang] || GANG_RANKS[0];

  return (
    <div className="space-y-3">
      {/* Warning Alert */}
      <div className="bg-red-950/40 border border-red-800/60 rounded-3xl p-4 shadow-lg">
        <div className="flex items-center gap-2.5">
          <span className="p-2.5 rounded-2xl bg-red-500/20 text-red-400 border border-red-500/30">
            <Skull className="w-6 h-6" />
          </span>
          <div>
            <h2 className="text-sm font-bold text-red-200">🕶️ عالم الظلام والجريمة المنظمة</h2>
            <p className="text-[11px] text-red-300/80 mt-0.5">
              طريق محفوف بالمخاطر. أموال سهلة وسريعة لكن وراءها تحريات المفتش كريم وعيون الشرطة!
            </p>
          </div>
        </div>

        {/* Meters */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-3 pt-3 border-t border-red-900/40 text-xs">
          <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-red-950">
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-red-400 font-semibold">مستوى المطاردة والحرارة</span>
              <span className="font-bold text-slate-200">{Math.round(heat)}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-red-500 rounded-full"
                style={{ width: `${Math.min(100, Math.max(0, heat))}%` }}
              />
            </div>
          </div>

          <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-red-950">
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-amber-400 font-semibold">شكوك المباحث والشرطة</span>
              <span className="font-bold text-slate-200">{Math.round(suspicion)}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-yellow-500 to-amber-500 rounded-full"
                style={{ width: `${Math.min(100, Math.max(0, suspicion))}%` }}
              />
            </div>
          </div>

          <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-red-950 col-span-2 sm:col-span-1">
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-300 font-semibold">رتبتك وسوابق الحجز</span>
              <span className="font-bold text-red-300">{jail}/3 سجون</span>
            </div>
            <div className="text-[10px] text-amber-300 font-bold truncate">
              {currentRank}
            </div>
          </div>
        </div>

        {partnerKnowsDark && (
          <div className="mt-2.5 p-2 rounded-xl bg-red-900/40 border border-red-700/50 text-[10px] text-red-200 flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{partnerName} تشك في تصرفاتك المشبوهة وقلقة من تعرض البيت للخطر!</span>
          </div>
        )}
      </div>

      {/* Operations Grid */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <h2 className="text-sm font-bold text-slate-200 mb-3">💼 العمليات والمناورات المتاحة</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* Join Gang if not member */}
          {gang === 0 && (
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between sm:col-span-2">
              <div>
                <div className="text-xs font-bold text-amber-300">البيعة لعصابة الريس سعد</div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  يتطلب سمعة 6+ لبدء الثقة والحصول على عمليات أكبر ونفوذ في الحي
                </p>
              </div>
              <button
                onClick={() => { playClickSound(); onCrime('join'); }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition"
              >
                انضم للعصابة
              </button>
            </div>
          )}

          {/* Steal */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">نشل وسرقة خفيفة</div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                كاش ~150-350 ج.م • مخاطرة متوسطة
              </p>
            </div>
            <button
              onClick={() => { playClickSound(); onCrime('steal'); }}
              className="px-3 py-1.5 rounded-xl bg-red-900 hover:bg-red-800 text-red-100 font-bold text-xs transition active:scale-95"
            >
              تنفيذ
            </button>
          </div>

          {/* Smuggle */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">تهريب ونقل شحنة ممنوعة</div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                كاش ~600-1200 ج.م • يتطلب رتبة منفذ
              </p>
            </div>
            <button
              onClick={() => { playClickSound(); onCrime('smuggle'); }}
              disabled={gang < 1}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs transition active:scale-95 ${
                gang >= 1
                  ? 'bg-red-900 hover:bg-red-800 text-red-100'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              {gang >= 1 ? 'تنفيذ' : 'رتبة غير كافية'}
            </button>
          </div>

          {/* Heist */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-200">عملية سطو كبرى منظمة</div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                كاش ~4000-8000 ج.م • يتطلب رتبة ذراع أيمن
              </p>
            </div>
            <button
              onClick={() => { playClickSound(); onCrime('heist'); }}
              disabled={gang < 3}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs transition active:scale-95 ${
                gang >= 3
                  ? 'bg-red-900 hover:bg-red-800 text-red-100'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              {gang >= 3 ? 'تنفيذ السطو' : 'مطلوب رتبة 3'}
            </button>
          </div>

          {/* Bribe */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-amber-300">تمرير رشوة أمنية (3,500 ج)</div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                يقلل الشكوك والمطاردة بشكل كبير
              </p>
            </div>
            <button
              onClick={() => { playClickSound(); onCrime('bribe'); }}
              disabled={gameState.money < 3500}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs transition active:scale-95 ${
                gameState.money >= 3500
                  ? 'bg-amber-600 hover:bg-amber-500 text-slate-950'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              دفع الرشوة
            </button>
          </div>

          {/* Snitch / Deal */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-cyan-300">صفقة مع المفتش كريم</div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                تسليم معلومات مقابل إسقاط قضاياك (+1000 ج.م)
              </p>
            </div>
            <button
              onClick={() => { playClickSound(); onCrime('snitch'); }}
              className="px-3 py-1.5 rounded-xl bg-cyan-900 hover:bg-cyan-800 text-cyan-100 font-bold text-xs transition active:scale-95"
            >
              صفقة سرية
            </button>
          </div>

          {/* Quit Dark Path */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-emerald-300">اعتزال عالم الظلام</div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                توبة وعودة للحياة الشريفة والرزق الحلال
              </p>
            </div>
            <button
              onClick={() => { playClickSound(); onCrime('quit'); }}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition active:scale-95"
            >
              توبة واعتزال
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
