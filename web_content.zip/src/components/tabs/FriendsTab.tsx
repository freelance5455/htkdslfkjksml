import React from 'react';
import { Users, Coffee, HandCoins, Lightbulb, Dumbbell, HeartHandshake } from 'lucide-react';
import { Friend, GameState } from '../../game/types';
import { playClickSound } from '../../utils/audio';

interface FriendsTabProps {
  friends: Friend[];
  onInteract: (friendId: string, action: 'hangout' | 'borrow' | 'biz_advice' | 'workout') => void;
}

export const FriendsTab: React.FC<FriendsTabProps> = ({ friends, onInteract }) => {
  return (
    <div className="space-y-3">
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <div className="flex items-center gap-2 mb-2">
          <span className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
            <Users className="w-5 h-5" />
          </span>
          <div>
            <h2 className="text-sm font-bold text-slate-100">شبكة الأصدقاء والعلاقات</h2>
            <p className="text-[11px] text-slate-400">
              الأصدقاء سندك في الحياة: استشارات بيزنس، مساندة مالية، وتدريب بدني
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
          {friends.map((friend) => (
            <div key={friend.id} className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center gap-2.5">
                  <div className="w-11 h-11 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-2xl shadow-inner">
                    {friend.avatar}
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-100">{friend.name}</h3>
                    <span className="text-[10px] text-cyan-300">{friend.role}</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                  {friend.description}
                </p>

                <div className="mt-2 p-2 rounded-xl bg-cyan-950/30 border border-cyan-800/30 text-[10px] text-cyan-300 flex items-center gap-1.5">
                  <HeartHandshake className="w-3.5 h-3.5" />
                  <span>الميزة: {friend.perk}</span>
                </div>

                {/* Closeness meter */}
                <div className="mt-2.5">
                  <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                    <span>قوة الصداقة والترابط</span>
                    <span className="font-bold text-slate-200">{Math.round(friend.closeness)}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-teal-400 rounded-full transition-all"
                      style={{ width: `${Math.min(100, Math.max(0, friend.closeness))}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-900">
                {/* Hangout */}
                <button
                  onClick={() => { playClickSound(); onInteract(friend.id, 'hangout'); }}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold flex items-center gap-1 transition"
                >
                  <Coffee className="w-3 h-3 text-amber-400" />
                  <span>قعدة قهوة (60 ج)</span>
                </button>

                {/* Borrow loan */}
                <button
                  onClick={() => { playClickSound(); onInteract(friend.id, 'borrow'); }}
                  className="px-2.5 py-1.5 rounded-xl bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-800 text-emerald-200 text-[11px] font-bold flex items-center gap-1 transition"
                  title="طلب سلفة مالية عند الحاجة والضيق"
                >
                  <HandCoins className="w-3 h-3 text-emerald-400" />
                  <span>طلب سلفة</span>
                </button>

                {/* Special Friend Perk Button */}
                {friend.id === 'hossam' && (
                  <button
                    onClick={() => { playClickSound(); onInteract(friend.id, 'biz_advice'); }}
                    className="px-2.5 py-1.5 rounded-xl bg-purple-950/70 hover:bg-purple-900 border border-purple-800 text-purple-200 text-[11px] font-bold flex items-center gap-1 transition"
                  >
                    <Lightbulb className="w-3 h-3 text-purple-400" />
                    <span>استشارة بيزنس</span>
                  </button>
                )}

                {friend.id === 'captain_tarek' && (
                  <button
                    onClick={() => { playClickSound(); onInteract(friend.id, 'workout'); }}
                    className="px-2.5 py-1.5 rounded-xl bg-cyan-950/70 hover:bg-cyan-900 border border-cyan-800 text-cyan-200 text-[11px] font-bold flex items-center gap-1 transition"
                  >
                    <Dumbbell className="w-3 h-3 text-cyan-400" />
                    <span>تمرين تحت إشرافه</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
