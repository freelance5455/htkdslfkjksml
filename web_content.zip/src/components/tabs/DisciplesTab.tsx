import React, { useState } from 'react';
import { Disciple } from '../../types/cultivation';
import { CULTIVATION_REALMS, formatLargeNumber } from '../../data/realms';
import { CultivatorAvatar } from '../cultivation/CultivatorAvatar';
import { ChampionTitleBadge } from '../cultivation/ChampionTitleBadge';
import { StatDetailModal } from '../cultivation/StatDetailModal';
import { Scroll, Users, Building2, Zap, Clock, Flame, Star, UserX, Sparkles } from 'lucide-react';
import { soundEngine } from '../../services/audioEngine';

interface DisciplesTabProps {
  disciples: Disciple[];
  maxDisciples: number;
  year?: number;
  autoTribulation: boolean;
  autoBreakthrough: boolean;
  onToggleAutoTribulation: () => void;
  onToggleAutoBreakthrough: () => void;
  onOpenRecruit: () => void;
  onOpenRelations: () => void;
  onPromoteAll: () => void;
  onSelectDisciple: (disciple: Disciple) => void;
  onQuickBreakthrough: (disciple: Disciple) => void;
  onToggleFavorite: (discipleId: string) => void;
  onKickDisciple: (disciple: Disciple) => void;
}

export const DisciplesTab: React.FC<DisciplesTabProps> = ({
  disciples,
  maxDisciples,
  year = 1,
  autoTribulation,
  autoBreakthrough,
  onToggleAutoTribulation,
  onToggleAutoBreakthrough,
  onOpenRecruit,
  onOpenRelations,
  onPromoteAll,
  onSelectDisciple,
  onQuickBreakthrough,
  onToggleFavorite,
  onKickDisciple
}) => {
  const [favoritesOnly, setFavoritesOnly] = useState<boolean>(false);
  const [inspectStatKey, setInspectStatKey] = useState<string | null>(null);

  const filteredDisciples = disciples.filter((d) => {
    if (favoritesOnly && !d.isFavorite) return false;
    return true;
  });

  const favoritesCount = disciples.filter(d => d.isFavorite).length;

  return (
    <div className="space-y-3.5 pb-20">
      {/* Header Counter & Quick Action Cards */}
      <div className="flex justify-between items-center px-1">
        <div>
          <h2 className="text-base sm:text-lg font-bold font-dao text-[#fce18b]">
            Disciples <span className="font-mono text-white text-sm">({disciples.length}/{maxDisciples})</span>
          </h2>
          <span className="text-[10px] text-[#9fc2b2]">
            Favorites: <strong className="text-[#fce18b]">{favoritesCount}/3</strong>
          </span>
        </div>

        <button
          onClick={() => setFavoritesOnly(!favoritesOnly)}
          className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 border transition-all ${
            favoritesOnly
              ? 'bg-[#e2b054] text-[#072018] border-[#fce18b]'
              : 'bg-[#123d30] text-[#fce18b] border-[#e2b054]/40 hover:bg-[#184838]'
          }`}
        >
          <Star className="w-3 h-3 fill-current" />
          <span>{favoritesOnly ? 'Showing Favorites' : 'Filter Favorites'}</span>
        </button>
      </div>

      {/* Top 4 + 1 Action Buttons */}
      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-2">
          {/* Recruit */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenRecruit();
            }}
            className="bg-[#f9f5ea] text-[#132d23] hover:bg-[#eae0c8] p-3 rounded-2xl border border-[#e8dbc0] flex items-center justify-between shadow-xs active:scale-98 transition-all"
          >
            <div className="text-left">
              <div className="font-dao font-bold text-xs sm:text-sm">Recruit</div>
              <div className="text-[10px] text-[#537063]">Custom or Test Entry</div>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center">
              <Scroll className="w-4 h-4 text-[#184838]" />
            </div>
          </button>

          {/* Disciple Relations */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenRelations();
            }}
            className="bg-[#f9f5ea] text-[#132d23] hover:bg-[#eae0c8] p-3 rounded-2xl border border-[#e8dbc0] flex items-center justify-between shadow-xs active:scale-98 transition-all"
          >
            <div className="text-left">
              <div className="font-dao font-bold text-xs sm:text-sm">Disciple Relations</div>
              <div className="text-[10px] text-[#537063]">Bonds & Jealousy</div>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center">
              <Users className="w-4 h-4 text-[#b45309]" />
            </div>
          </button>

          {/* Promote All */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onPromoteAll();
            }}
            className="bg-[#f9f5ea] text-[#132d23] hover:bg-[#eae0c8] p-3 rounded-2xl border border-[#e8dbc0] flex items-center justify-between shadow-xs active:scale-98 transition-all"
          >
            <div className="text-left">
              <div className="font-dao font-bold text-xs sm:text-sm">Promote All</div>
              <div className="text-[10px] text-[#537063]">Merit Evaluation</div>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-[#0284c7]" />
            </div>
          </button>

          {/* Auto Tribulation */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onToggleAutoTribulation();
            }}
            className={`p-3 rounded-2xl border flex items-center justify-between shadow-xs active:scale-98 transition-all ${
              autoTribulation
                ? 'bg-[#184838] text-[#fce18b] border-[#e2b054]'
                : 'bg-[#f9f5ea] text-[#132d23] border-[#e8dbc0]'
            }`}
          >
            <div className="text-left">
              <div className="font-dao font-bold text-xs sm:text-sm">Auto Tribulation</div>
              <div className={`text-[10px] ${autoTribulation ? 'text-[#a7f3d0]' : 'text-[#537063]'}`}>
                {autoTribulation ? 'Lightning Array Active' : 'Manual Defense'}
              </div>
            </div>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${autoTribulation ? 'bg-[#e2b054]/20' : 'bg-[#184838]/10'}`}>
              <Zap className={`w-4 h-4 ${autoTribulation ? 'text-[#fce18b]' : 'text-[#ca8a04]'}`} />
            </div>
          </button>
        </div>

        {/* Auto Breakthrough Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onToggleAutoBreakthrough();
          }}
          className={`w-full py-2.5 px-4 rounded-xl border font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-all min-h-[42px] ${
            autoBreakthrough
              ? 'bg-[#14532d] text-[#86efac] border-[#22c55e]'
              : 'bg-[#f9f5ea] text-[#183a2d] border-[#e8dbc0]'
          }`}
        >
          <Clock className="w-4 h-4 text-[#e2b054]" />
          <span>Auto Breakthrough: {autoBreakthrough ? 'ACTIVE' : 'OFF (Manual)'}</span>
        </button>
      </div>

      {/* Disciples List (Rank/Status/Spirit Root filter box removed per specification) */}
      <div className="space-y-3">
        {filteredDisciples.length === 0 ? (
          <div className="bg-[#123d30]/60 p-8 rounded-2xl border border-dashed border-[#e2b054]/30 text-center text-xs text-[#a4c5b7]">
            No disciples match the selected filters.
          </div>
        ) : (
          filteredDisciples.map((disciple) => {
            const currentRealm = CULTIVATION_REALMS[disciple.currentRealmIndex] || CULTIVATION_REALMS[0];
            const isReadyForBreakthrough = disciple.cultivationExp >= disciple.maxExp;
            const highestJealousy = Math.max(0, ...disciple.relations.map(r => r.jealousy || 0));
            const isStagnant5Yrs =
              isReadyForBreakthrough &&
              disciple.breakthroughReadySinceYear !== undefined &&
              year - disciple.breakthroughReadySinceYear >= 5;

            return (
              <div
                key={disciple.id}
                className="bg-[#123d30] border border-[#e2b054]/30 rounded-2xl p-3.5 shadow-md space-y-3 hover:border-[#fce18b]/60 transition-all cursor-pointer relative"
                onClick={() => onSelectDisciple(disciple)}
              >
                {/* Upper Avatar & Identity Header: Avatar strictly on left, Name, Position, & Champion Badge strictly beside avatar */}
                <div className="flex items-start gap-3">
                  <div className="shrink-0">
                    <CultivatorAvatar
                      gender={disciple.gender}
                      rank={disciple.rank}
                      spiritRoot={disciple.spiritRoot}
                      realmIndex={disciple.currentRealmIndex}
                      isBreakthroughReady={isReadyForBreakthrough}
                      appearanceIndex={disciple.appearanceIndex ?? disciple.avatarStyle?.appearanceIndex}
                      skinTone={disciple.skinTone ?? disciple.avatarStyle?.skinTone}
                      clothingColor={disciple.clothingColor ?? disciple.avatarStyle?.clothingColor}
                      hairColor={disciple.hairColor ?? disciple.avatarStyle?.hairColor}
                      expression={disciple.expression ?? disciple.avatarStyle?.expression}
                      auraEffect={disciple.auraEffect ?? disciple.avatarStyle?.auraEffect}
                      mythicalForm={disciple.mythicalForm ?? disciple.avatarStyle?.mythicalForm}
                      soulProtected={disciple.soulProtected}
                      showGenderBadge={true}
                      size="md"
                    />
                  </div>

                  {/* Name and Position strictly BESIDE avatar */}
                  <div className="grow min-w-0">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-dao font-bold text-sm sm:text-base text-[#fce18b]">
                          {disciple.name}
                        </span>

                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#1e5845] text-[#dcfce7] border border-[#34d399]/30 font-medium">
                          {disciple.rank}
                        </span>

                        {/* Champion title badge placed strictly BESIDE avatar, never blocking */}
                        {disciple.championTitle && (
                          <div onClick={(e) => e.stopPropagation()}>
                            <ChampionTitleBadge title={disciple.championTitle} size="sm" />
                          </div>
                        )}

                        {disciple.isFavorite && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-400/50 font-bold">
                            ★ Fav (+20% Cult · +12% Pwr)
                          </span>
                        )}

                        <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-[#09261d] text-sky-300 border border-sky-500/30">
                          {disciple.cultivationType || 'Qi Cultivator'} · {disciple.emotion || 'Serene'}
                        </span>

                        {/* Status only appears if triggered / NOT Idle */}
                        {disciple.status !== 'Idle' && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#0b261d] text-[#bae6fd] border border-[#38bdf8]/40 animate-pulse">
                            {disciple.status}
                          </span>
                        )}

                        {/* Grudge only appears if jealousy > 0 */}
                        {highestJealousy > 0 && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-900/70 text-red-200 border border-red-500/50 flex items-center gap-1 font-bold animate-pulse">
                            <Flame className="w-3 h-3 text-red-400" />
                            <span>Grudge {highestJealousy}%</span>
                          </span>
                        )}

                        {(isStagnant5Yrs || (disciple.negativeTraits && disciple.negativeTraits.length > 0)) && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-red-950 text-red-300 border border-red-500/50 font-bold">
                            ⚠ {disciple.negativeTraits?.[0] || '5+ Yr Stagnant'}
                          </span>
                        )}
                      </div>

                      {/* Favorite & Kick Options in upper right */}
                      <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => {
                            soundEngine.playClick();
                            onToggleFavorite(disciple.id);
                          }}
                          title={disciple.isFavorite ? "Remove from Favorites" : "Mark as Favorite (Max 3)"}
                          className={`p-1.5 rounded-lg border transition-all ${
                            disciple.isFavorite
                              ? 'bg-[#e2b054] text-[#072018] border-[#fce18b] shadow-xs'
                              : 'bg-[#09261d] text-[#6b8c7e] hover:text-[#fce18b] border-[#1b4b3b]'
                          }`}
                        >
                          <Star className={`w-3.5 h-3.5 ${disciple.isFavorite ? 'fill-current' : ''}`} />
                        </button>

                        <button
                          onClick={() => {
                            soundEngine.playClick();
                            if (window.confirm(`Are you sure you want to banish ${disciple.name} from the sect?`)) {
                              onKickDisciple(disciple);
                            }
                          }}
                          title="Banish from Sect"
                          className="p-1.5 rounded-lg bg-[#09261d] text-red-400 hover:bg-red-900/50 hover:text-red-200 border border-red-900/30 transition-all"
                        >
                          <UserX className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Lifespan & Power details with Stat explanation triggers */}
                    <div className="text-[11px] text-[#a4c5b7] mt-1 flex items-center gap-1.5 flex-wrap">
                      <span className="text-[#86efac] font-medium">{currentRealm.name}</span>
                      <span>·</span>
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectStatKey('Lifespan');
                        }}
                        className="cursor-pointer hover:underline text-[#fce18b] flex items-center gap-0.5"
                      >
                        <span>Age {disciple.age}/{disciple.lifespan} yrs</span>
                      </span>
                      <span>·</span>
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectStatKey('Combat Power');
                        }}
                        className="cursor-pointer hover:underline text-[#38bdf8]"
                      >
                        Combat: <strong className="font-mono text-[#fce18b]">{formatLargeNumber(disciple.combatPower)}</strong>
                      </span>
                      <span>·</span>
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectStatKey('Contribution');
                        }}
                        className="cursor-pointer hover:underline text-[#ca8a04]"
                      >
                        Contrib: <strong className="font-mono">{disciple.contribution || 0} pts</strong>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Realm Exp Bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] text-[#9fc2b2]">
                    <span>Cultivation Qi</span>
                    <span className="font-mono">
                      {formatLargeNumber(disciple.cultivationExp)} / {formatLargeNumber(disciple.maxExp)}
                    </span>
                  </div>
                  <div className="w-full bg-[#072018] h-2 rounded-full overflow-hidden border border-[#1b4b3b]">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isReadyForBreakthrough
                          ? 'bg-gradient-to-r from-[#e2b054] to-[#fce18b] animate-pulse'
                          : 'bg-gradient-to-r from-[#15803d] to-[#4ade80]'
                      }`}
                      style={{ width: `${Math.min(100, (disciple.cultivationExp / disciple.maxExp) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Spiritual Traits */}
                <div className="grid grid-cols-2 gap-2 text-[11px] bg-[#09281e]/80 p-2 rounded-xl border border-[#1b4b3b]">
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      setInspectStatKey('Spirit Root');
                    }}
                    className="cursor-pointer hover:underline"
                  >
                    <span className="text-[#7ea091]">Root: </span>
                    <span className="text-[#e2b054] font-medium">{disciple.spiritRoot} ({disciple.spiritRootPurity})</span>
                  </div>
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      setInspectStatKey('Physique');
                    }}
                    className="cursor-pointer hover:underline"
                  >
                    <span className="text-[#7ea091]">Physique: </span>
                    <span className="text-[#93c5fd] font-medium truncate">{disciple.constitution}</span>
                  </div>
                  <div className="col-span-2 text-[10px] text-[#9fc2b2]">
                    <span className="text-[#7ea091]">Talent: </span>
                    <span
                      onClick={(e) => {
                        e.stopPropagation();
                        setInspectStatKey('Talent');
                      }}
                      className="text-amber-300 font-bold cursor-pointer hover:underline"
                    >
                      {disciple.talentTier || 'Mediocre'} ({disciple.talent})
                    </span> ·
                    <span className="text-[#7ea091] ml-1">Loyalty: </span>
                    <span className="text-[#86efac]">{disciple.loyalty}%</span> ·
                    <span className="text-[#7ea091] ml-1">Morale: </span>
                    <span className="text-[#86efac]">{disciple.morale}%</span>
                  </div>
                </div>

                {/* Quick Action Buttons */}
                <div className="flex items-center justify-end gap-2 pt-0.5" onClick={(e) => e.stopPropagation()}>
                  {isReadyForBreakthrough && (
                    <button
                      onClick={() => onQuickBreakthrough(disciple)}
                      className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs flex items-center gap-1 shadow-xs animate-bounce"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Breakthrough!</span>
                    </button>
                  )}
                  <button
                    onClick={() => onSelectDisciple(disciple)}
                    className="px-3 py-1.5 rounded-lg bg-[#184838] hover:bg-[#1e5845] text-[#fce18b] border border-[#e2b054]/50 font-dao text-xs"
                  >
                    Manage Disciple
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Stat Detail Popover */}
      {inspectStatKey && (
        <StatDetailModal
          statKey={inspectStatKey}
          onClose={() => setInspectStatKey(null)}
        />
      )}
    </div>
  );
};
