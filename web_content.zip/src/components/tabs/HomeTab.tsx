import React from 'react';
import { Utensils, Coffee, Moon, Dumbbell, BookOpen, Footprints, Sparkles, GraduationCap } from 'lucide-react';
import { GameState, PlayerCourse } from '../../game/types';
import { playClickSound, playLevelUpSound } from '../../utils/audio';

interface HomeTabProps {
  gameState: GameState;
  onEat: (big: boolean) => void;
  onSleep: () => void;
  onGym: () => void;
  onStudy: () => void;
  onWalk: () => void;
  onAttendCourse: (courseId: string) => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  gameState,
  onEat,
  onSleep,
  onGym,
  onStudy,
  onWalk,
  onAttendCourse
}) => {
  return (
    <div className="space-y-3">
      {/* Active Courses Quick Study Card */}
      {gameState.activeCourses.length > 0 && (
        <div className="bg-gradient-to-r from-purple-950/40 to-slate-900 border border-purple-800/40 rounded-3xl p-4 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="flex items-center gap-2 text-xs font-bold text-purple-300">
              <GraduationCap className="w-4 h-4 text-purple-400" />
              <span>متابعة دراسة الكورسات الحالية</span>
            </span>
            <span className="text-[10px] text-purple-400 bg-purple-900/50 px-2 py-0.5 rounded-full border border-purple-700">
              {gameState.activeCourses.length} كورس قيد الدراسة
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
            {gameState.activeCourses.map((c) => (
              <div key={c.id} className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                    <span>{c.icon}</span>
                    <span>{c.name}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    أتممت {c.daysEnrolled} من {c.durationDays} أيام • {c.dailyHours} ساعات يومياً
                  </div>
                  <div className="w-28 h-1.5 bg-slate-800 rounded-full mt-1.5 overflow-hidden">
                    <div
                      className="h-full bg-purple-500 rounded-full transition-all"
                      style={{ width: `${(c.daysEnrolled / c.durationDays) * 100}%` }}
                    />
                  </div>
                </div>

                <button
                  onClick={() => { playClickSound(); onAttendCourse(c.id); }}
                  className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md shadow-purple-600/20 active:scale-95 transition"
                >
                  حضور المحاضرة
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Daily Routine Actions */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-slate-200">⚡ روتينك وأفعالك اليومية</h2>
          <span className="text-[11px] text-slate-400">كل نشاط يستهلك وقتاً هادئاً ومدروساً</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {/* Gym button with progressive level highlight */}
          <button
            onClick={() => { playClickSound(); onGym(); }}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-cyan-950/40 to-slate-950 border border-cyan-800/40 hover:border-cyan-400 text-right transition group relative overflow-hidden"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xl">🏋️</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-900/60 text-cyan-300 font-bold border border-cyan-700/50">
                Lvl {gameState.fitnessLevel}
              </span>
            </div>
            <strong className="block text-xs font-bold text-cyan-200 group-hover:text-cyan-100">
              تمرين في الجيم
            </strong>
            <small className="block text-[10px] text-slate-400 mt-1">
              يرفع لياقتك ويكبر سعة شريط الطاقة تلقائياً
            </small>
          </button>

          {/* Big Meal */}
          <button
            onClick={() => { playClickSound(); onEat(true); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">🍔</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-amber-300">
              وجبة رئيسية مشبعة
            </strong>
            <small className="block text-[10px] text-slate-400 mt-1">
              تشبع كامل ومزاج هادئ • 60 ج.م
            </small>
          </button>

          {/* Light Snack */}
          <button
            onClick={() => { playClickSound(); onEat(false); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">🥙</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-amber-300">
              سندوتش ومشروب خفيف
            </strong>
            <small className="block text-[10px] text-slate-400 mt-1">
              يسد الجوع السريع • 25 ج.م
            </small>
          </button>

          {/* Deep Sleep */}
          <button
            onClick={() => { playClickSound(); onSleep(); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-indigo-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">🛌</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-indigo-300">
              نوم عميق وراحة
            </strong>
            <small className="block text-[10px] text-slate-400 mt-1">
              يستعيد كامل طاقتك وصحتك البدنية
            </small>
          </button>

          {/* Self-Study */}
          <button
            onClick={() => { playClickSound(); onStudy(); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-emerald-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">📚</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-emerald-300">
              قراءة وتطوير ذات
            </strong>
            <small className="block text-[10px] text-slate-400 mt-1">
              يزيد مهارتك المهنية ووعيك • 30 دقيقة
            </small>
          </button>

          {/* Walk / Stroll */}
          <button
            onClick={() => { playClickSound(); onWalk(); }}
            className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-teal-400/50 text-right transition group"
          >
            <div className="text-xl mb-1">🚶</div>
            <strong className="block text-xs font-bold text-slate-200 group-hover:text-teal-300">
              تمشية في الهواء الطلق
            </strong>
            <small className="block text-[10px] text-slate-400 mt-1">
              يحسن مزاجك النفسي ويجدد نشاطك
            </small>
          </button>
        </div>
      </div>

      {/* Activity Log */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <h2 className="text-sm font-bold text-slate-200 mb-2">📌 سجل أحداثك اليومية</h2>
        <div className="space-y-2">
          {gameState.log.slice(0, 6).map((item) => (
            <div key={item.id} className="p-2.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs flex items-start gap-2.5">
              <span className="text-base">{item.icon || '🔹'}</span>
              <div className="flex-1">
                <span className="text-[10px] text-slate-500 font-mono">يوم {item.day} • {item.time}</span>
                <p className="text-slate-300 mt-0.5 leading-relaxed">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
