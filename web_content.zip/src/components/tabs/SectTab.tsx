import React from 'react';
import { DailyActionUsage, DailyDivinationResult, Season } from '../../types/cultivation';
import {
  Briefcase,
  GraduationCap,
  Dumbbell,
  Compass,
  Users2,
  Sparkles,
  Trophy,
  Flame,
  CalendarCheck2,
  Zap,
  FlaskConical,
  MapPin,
  Package,
  Swords,
  CalendarDays,
  FastForward
} from 'lucide-react';
import { soundEngine } from '../../services/audioEngine';
import peakArenaArt from '../../assets/images/art_peak_arena_1794844216353.jpg';
import merchantArt from '../../assets/images/art_merchant_treasures_1794844217760.jpg';

interface SectTabProps {
  season: Season;
  year: number;
  currentDateIso: string;
  soulProtectedCount: number;
  disciplesCount: number;
  unlockedSectorsCount: number;
  totalSectorsCount: number;
  storageCount: number;
  eligibleDeathDuelCount: number;
  dailyUsage: DailyActionUsage;
  hasUnclaimedCheckIn: boolean;
  hasDrawnDivinationToday: boolean;
  activeDivination: DailyDivinationResult | null;
  checkInStreak: number;
  onOpenMerchant: () => void;
  onOpenStorage: () => void;
  onOpenRecruit: () => void;
  onTrainAll: () => void;
  onMeditate: () => void;
  onLeylineSurge: () => void;
  onPillInfusion: () => void;
  onOpenExpeditions: () => void;
  onOpenDiplomacy: () => void;
  onAdvanceDays: (days: 1 | 7 | 30) => void;
  onOpenTournament: () => void;
  onOpenLifeDeathArena: () => void;
  onOpenSoulLanterns: () => void;
  onOpenDivination: () => void;
  onOpenDailyCheckIn: () => void;
  onOpenSectors: () => void;
}

export const SectTab: React.FC<SectTabProps> = ({
  season,
  year,
  soulProtectedCount,
  disciplesCount,
  unlockedSectorsCount,
  totalSectorsCount,
  storageCount,
  eligibleDeathDuelCount,
  dailyUsage,
  hasUnclaimedCheckIn,
  hasDrawnDivinationToday,
  activeDivination,
  checkInStreak,
  onOpenMerchant,
  onOpenStorage,
  onOpenRecruit,
  onTrainAll,
  onMeditate,
  onLeylineSurge,
  onPillInfusion,
  onOpenExpeditions,
  onOpenDiplomacy,
  onAdvanceDays,
  onOpenTournament,
  onOpenLifeDeathArena,
  onOpenSoulLanterns,
  onOpenDivination,
  onOpenDailyCheckIn,
  onOpenSectors
}) => {
  const trainLeft = Math.max(0, 3 - dailyUsage.trainAllCount);
  const meditateLeft = Math.max(0, 3 - dailyUsage.meditateCount);
  const leylineLeft = Math.max(0, 3 - dailyUsage.leylineSurgeCount);
  const pillLeft = Math.max(0, 2 - dailyUsage.pillInfusionCount);

  return (
    <div className="space-y-3.5 pb-16">
      {/* Intro & Traveling Merchant + Sect Storage */}
      <div className="relative overflow-hidden bg-[#123d30] text-[#e8f1eb] p-3.5 sm:p-4 rounded-2xl border border-[#e2b054]/45 shadow-md space-y-3">
        <img
          src={merchantArt}
          alt="Traveling Merchant Pavilion Treasures"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none"
        />
        <div className="relative z-10 space-y-2.5">
          <p className="text-xs sm:text-sm text-[#e8f1eb] leading-relaxed drop-shadow-xs">
            Govern your mountain peak, tend ancestral Soul Lanterns, divine the Heavenly Dao, and cultivate immortal prodigies.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              onClick={() => {
                soundEngine.playClick();
                onOpenMerchant();
              }}
              className="sm:col-span-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#184838] to-[#0f3427] text-[#fce18b] border border-[#e2b054]/60 font-dao font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm hover:from-[#1d5543] hover:to-[#174737] active:scale-[0.98] transition-all min-h-[42px]"
            >
              <Briefcase className="w-4 h-4 text-[#e2b054] shrink-0" />
              <span className="truncate">Visit Traveling Merchant</span>
            </button>
            <button
              onClick={() => {
                soundEngine.playClick();
                onOpenStorage();
              }}
              className="py-2.5 px-3 rounded-xl bg-[#f9f5ea] hover:bg-[#efe6d0] text-[#0f2b20] border border-[#e2b054]/80 font-dao font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.98] transition-all min-h-[42px]"
            >
              <Package className="w-4 h-4 text-[#b45309] shrink-0" />
              <span>Storage (<span className="font-mono tabular-nums">{storageCount}</span>)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Immortal Sanctuary & Daily Rituals Hub */}
      <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
        {/* Soul Lanterns */}
        <button
          onClick={() => {
            soundEngine.playLanternLit();
            onOpenSoulLanterns();
          }}
          className="relative bg-gradient-to-b from-[#164233] to-[#0b271e] hover:from-[#1b523f] hover:to-[#0f3427] p-3 rounded-2xl border border-[#e2b054]/60 text-left shadow-md active:scale-95 transition-all flex flex-col justify-between min-h-[92px]"
        >
          <div className="flex justify-between items-start w-full">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center">
              <Flame className="w-4 h-4 text-amber-300" />
            </div>
            <span className="text-[10px] font-mono tabular-nums text-[#fce18b] font-semibold">
              {soulProtectedCount}/{disciplesCount}
            </span>
          </div>
          <div className="mt-2">
            <div className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] leading-tight">
              Soul Lanterns
            </div>
            <div className="text-[10px] text-[#9fc2b2] leading-tight mt-0.5 truncate">
              Life-Flames · Seals
            </div>
          </div>
        </button>

        {/* Daily Divinations */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onOpenDivination();
          }}
          className="relative bg-gradient-to-b from-[#164233] to-[#0b271e] hover:from-[#1b523f] hover:to-[#0f3427] p-3 rounded-2xl border border-[#e2b054]/60 text-left shadow-md active:scale-95 transition-all flex flex-col justify-between min-h-[92px]"
        >
          <div className="flex justify-between items-start w-full">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-400/50 flex items-center justify-center">
              <Compass className="w-4 h-4 text-sky-300" />
            </div>
            <span className={`text-[10px] font-bold ${!hasDrawnDivinationToday ? 'text-amber-300' : 'text-emerald-300'}`}>
              {!hasDrawnDivinationToday ? 'Ready' : 'Drawn'}
            </span>
          </div>
          <div className="mt-2">
            <div className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] leading-tight">
              Divinations
            </div>
            <div className="text-[10px] text-[#9fc2b2] leading-tight mt-0.5 truncate">
              {activeDivination ? activeDivination.hexagramName.split('·')[0].trim() : 'Cast Daily Omen'}
            </div>
          </div>
        </button>

        {/* Daily Check-In */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onOpenDailyCheckIn();
          }}
          className="relative bg-gradient-to-b from-[#164233] to-[#0b271e] hover:from-[#1b523f] hover:to-[#0f3427] p-3 rounded-2xl border border-[#e2b054]/60 text-left shadow-md active:scale-95 transition-all flex flex-col justify-between min-h-[92px]"
        >
          <div className="flex justify-between items-start w-full">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center">
              <CalendarCheck2 className="w-4 h-4 text-emerald-300" />
            </div>
            <span className={`text-[10px] font-mono tabular-nums font-bold ${hasUnclaimedCheckIn ? 'text-amber-300' : 'text-emerald-300'}`}>
              {hasUnclaimedCheckIn ? 'Claim' : `Day ${checkInStreak}`}
            </span>
          </div>
          <div className="mt-2">
            <div className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] leading-tight">
              Daily Check-In
            </div>
            <div className="text-[10px] text-[#9fc2b2] leading-tight mt-0.5 truncate">
              {hasUnclaimedCheckIn ? 'Tribute Waiting' : `Streak: ${checkInStreak}d`}
            </div>
          </div>
        </button>
      </div>

      {/* Peak Challenge, Life-and-Death Arena & Sect Sectors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <div className="relative overflow-hidden bg-[#123d30] p-3.5 rounded-2xl border-2 border-[#e2b054] shadow-lg flex justify-between items-center gap-2.5 text-xs">
          <img
            src={peakArenaArt}
            alt="Peak Challenge Arena"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none"
          />
          <div className="relative z-10 flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-full bg-amber-500/20 flex items-center justify-center border border-amber-400/50 shrink-0">
              <Trophy className="w-5 h-5 text-amber-300" />
            </div>
            <div className="min-w-0">
              <div className="font-dao font-bold text-[#fce18b] text-sm leading-tight">
                Peak Challenge
              </div>
              <div className="text-[10px] text-[#d1e6dc] truncate mt-0.5">
                5-Round Gauntlet · Champion Glory
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playGong();
              onOpenTournament();
            }}
            className="relative z-10 py-2 px-3 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all shrink-0 whitespace-nowrap min-h-[40px]"
          >
            Enter Arena
          </button>
        </div>

        <div className="bg-gradient-to-r from-[#134232] via-[#0e3226] to-[#09241b] p-3.5 rounded-2xl border border-[#34d399]/60 shadow-lg flex justify-between items-center gap-2.5 text-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-full bg-emerald-500/20 flex items-center justify-center border border-emerald-400/40 shrink-0">
              <MapPin className="w-5 h-5 text-emerald-300" />
            </div>
            <div className="min-w-0">
              <div className="font-dao font-bold text-emerald-200 text-sm leading-tight">
                Sect Sectors · <span className="font-mono tabular-nums">{unlockedSectorsCount}/{totalSectorsCount}</span>
              </div>
              <div className="text-[10px] text-[#9fc2b2] truncate mt-0.5">
                Peaks, Veins &amp; Sector Lords
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenSectors();
            }}
            className="py-2 px-3 rounded-xl bg-[#184838] hover:bg-[#1e5c48] text-[#fce18b] border border-[#e2b054]/60 font-dao font-bold text-xs shadow-md active:scale-95 transition-all shrink-0 whitespace-nowrap min-h-[40px]"
          >
            Manage Peaks
          </button>
        </div>
      </div>

      {/* Life-and-Death Grudge Arena Strip */}
      <div className="bg-gradient-to-r from-[#2b0f13] via-[#1f0b0e] to-[#120709] p-3.5 rounded-2xl border border-rose-500/45 shadow-md flex justify-between items-center gap-2.5 text-xs">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-full bg-rose-500/15 border border-rose-400/50 flex items-center justify-center shrink-0">
            <Swords className="w-5 h-5 text-rose-300" />
          </div>
          <div className="min-w-0">
            <div className="font-dao font-bold text-rose-200 text-sm leading-tight">
              Life-and-Death Arena
            </div>
            <div className="text-[10px] text-rose-200/80 truncate mt-0.5">
              {eligibleDeathDuelCount > 0
                ? `${eligibleDeathDuelCount} mortal feud${eligibleDeathDuelCount > 1 ? 's' : ''} (80–100 Grudge) awaiting trial`
                : 'Strictly for 80–100 Grudge · Zero rewards · Loser perishes'}
            </div>
          </div>
        </div>
        <button
          onClick={() => {
            soundEngine.playGong();
            onOpenLifeDeathArena();
          }}
          className="py-2 px-3 rounded-xl bg-rose-900/90 hover:bg-rose-800 text-rose-100 border border-rose-400/50 font-dao font-bold text-xs shadow-sm active:scale-95 transition-all shrink-0 whitespace-nowrap min-h-[40px]"
        >
          Open Arena
        </button>
      </div>

      {/* Time Advancement Control Strip (+1d, +7d, +30d) */}
      <div className="bg-[#0e3226] border border-[#e2b054]/40 rounded-2xl p-3.5 space-y-2.5 shadow-md">
        <div className="flex justify-between items-center text-xs">
          <div className="flex items-center gap-2 font-dao font-bold text-[#fce18b]">
            <CalendarDays className="w-4 h-4 text-[#e2b054]" />
            <span>Advance Sect Calendar</span>
          </div>
          <span className="text-[11px] text-[#9fc2b2]">
            {season} · Year <span className="font-mono tabular-nums">{year}</span>
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => {
              soundEngine.playClick();
              onAdvanceDays(1);
            }}
            className="min-h-[42px] px-3 py-2 rounded-xl bg-[#184838] hover:bg-[#1f5c48] text-[#fce18b] border border-[#e2b054]/50 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all whitespace-nowrap"
          >
            <span>Next Day</span>
            <span className="font-mono tabular-nums text-[10px] text-emerald-300">+1d</span>
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              onAdvanceDays(7);
            }}
            className="min-h-[42px] px-3 py-2 rounded-xl bg-[#184838] hover:bg-[#1f5c48] text-[#fce18b] border border-[#e2b054]/50 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all whitespace-nowrap"
          >
            <span>Next Week</span>
            <span className="font-mono tabular-nums text-[10px] text-amber-300">+7d</span>
          </button>
          <button
            onClick={() => {
              soundEngine.playGong();
              onAdvanceDays(30);
            }}
            className="min-h-[42px] px-3 py-2 rounded-xl bg-gradient-to-r from-[#b4802c] to-[#d49e38] hover:brightness-110 text-[#072018] border border-[#fce18b]/60 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all whitespace-nowrap"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>Next Month</span>
            <span className="font-mono tabular-nums text-[10px]">+30d</span>
          </button>
        </div>
      </div>

      {/* Sect Actions Box (Symmetric 8-button grid) */}
      <div className="bg-[#f9f5ea] text-[#1a3329] p-4 rounded-2xl border border-[#e8dbc0] shadow-md space-y-3">
        <div className="flex justify-between items-center border-b border-[#e5d8be] pb-2">
          <h2 className="text-base sm:text-lg font-bold font-dao text-[#0f2b20]">
            Sect Governance &amp; Actions
          </h2>
          <span className="text-[11px] text-[#5c7a6e] font-medium">
            Mountain Peak · Daily Caps Reset at Midnight
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5 pt-0.5">
          {/* Recruit */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenRecruit();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <GraduationCap className="w-4 h-4 text-[#184838]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Recruit</span>
            <span className="text-[10px] text-[#5a766a]">Invite disciple</span>
          </button>

          {/* Train All */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onTrainAll();
            }}
            disabled={trainLeft <= 0}
            className={`active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px] ${
              trainLeft > 0
                ? 'bg-[#f3ebd7] hover:bg-[#eae0c8] border-[#dfd0b5]'
                : 'bg-[#e7dec9]/60 border-[#d6c9ae] opacity-60 cursor-not-allowed'
            }`}
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Dumbbell className="w-4 h-4 text-[#184838]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Train All</span>
            <span className="text-[10px] text-[#5a766a] font-mono tabular-nums">80 Qi · {trainLeft}/3</span>
          </button>

          {/* Meditate */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onMeditate();
            }}
            disabled={meditateLeft <= 0}
            className={`active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px] ${
              meditateLeft > 0
                ? 'bg-[#f3ebd7] hover:bg-[#eae0c8] border-[#dfd0b5]'
                : 'bg-[#e7dec9]/60 border-[#d6c9ae] opacity-60 cursor-not-allowed'
            }`}
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Sparkles className="w-4 h-4 text-[#b45309]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Meditate</span>
            <span className="text-[10px] text-[#5a766a] font-mono tabular-nums">+25 Qi · {meditateLeft}/3</span>
          </button>

          {/* Leyline Surge */}
          <button
            onClick={() => {
              soundEngine.playTalisman();
              onLeylineSurge();
            }}
            disabled={leylineLeft <= 0}
            className={`active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px] ${
              leylineLeft > 0
                ? 'bg-[#f3ebd7] hover:bg-[#eae0c8] border-[#dfd0b5]'
                : 'bg-[#e7dec9]/60 border-[#d6c9ae] opacity-60 cursor-not-allowed'
            }`}
          >
            <div className="w-8 h-8 rounded-full bg-cyan-600/15 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Zap className="w-4 h-4 text-cyan-700" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Leyline Surge</span>
            <span className="text-[10px] text-[#5a766a] font-mono tabular-nums">60 Stones · {leylineLeft}/3</span>
          </button>

          {/* Pill Infusion */}
          <button
            onClick={() => {
              soundEngine.playCauldronBubble();
              onPillInfusion();
            }}
            disabled={pillLeft <= 0}
            className={`active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px] ${
              pillLeft > 0
                ? 'bg-[#f3ebd7] hover:bg-[#eae0c8] border-[#dfd0b5]'
                : 'bg-[#e7dec9]/60 border-[#d6c9ae] opacity-60 cursor-not-allowed'
            }`}
          >
            <div className="w-8 h-8 rounded-full bg-emerald-600/15 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <FlaskConical className="w-4 h-4 text-emerald-700" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Pill Infusion</span>
            <span className="text-[10px] text-[#5a766a] font-mono tabular-nums">2 Pills · {pillLeft}/2</span>
          </button>

          {/* Expeditions */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenExpeditions();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Compass className="w-4 h-4 text-[#0284c7]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Expeditions</span>
            <span className="text-[10px] text-[#5a766a]">Secret Realms</span>
          </button>

          {/* Diplomacy */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenDiplomacy();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Users2 className="w-4 h-4 text-[#d97706]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Diplomacy</span>
            <span className="text-[10px] text-[#5a766a]">Sect Relations</span>
          </button>

          {/* Sect Storage Shortcut */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenStorage();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[84px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Package className="w-4 h-4 text-[#9333ea]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Sect Storage</span>
            <span className="text-[10px] text-[#5a766a] font-mono tabular-nums">{storageCount} Stored</span>
          </button>
        </div>
      </div>

      {/* Atmospheric Omen Footer Card */}
      <div className="bg-[#123d30]/80 border border-[#e2b054]/30 rounded-2xl p-3.5 text-xs text-[#d1e6dc] flex flex-wrap items-center justify-between gap-2">
        <div>
          <span className="text-[#fce18b] font-bold">Current Cycle: </span>
          <span>{season} of Year <span className="font-mono tabular-nums">{year}</span></span>
        </div>
        <span className="text-[11px] text-[#86efac] font-medium">
          {activeDivination ? `Omen: ${activeDivination.hexagramName}` : 'Heavenly Dao Flow: Serene'}
        </span>
      </div>
    </div>
  );
};
