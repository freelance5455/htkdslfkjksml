import React from 'react';
import { DailyDivinationResult, Season } from '../../types/cultivation';
import {
  Briefcase,
  GraduationCap,
  Dumbbell,
  Compass,
  Users2,
  Moon,
  Sparkles,
  Trophy,
  Flame,
  CalendarCheck2,
  Zap,
  FlaskConical,
  MapPin
} from 'lucide-react';
import { soundEngine } from '../../services/audioEngine';

interface SectTabProps {
  season: Season;
  year: number;
  soulProtectedCount: number;
  disciplesCount: number;
  unlockedSectorsCount: number;
  totalSectorsCount: number;
  hasUnclaimedCheckIn: boolean;
  hasDrawnDivinationToday: boolean;
  activeDivination: DailyDivinationResult | null;
  checkInStreak: number;
  onOpenMerchant: () => void;
  onOpenRecruit: () => void;
  onTrainAll: () => void;
  onMeditate: () => void;
  onLeylineSurge: () => void;
  onPillInfusion: () => void;
  onOpenExpeditions: () => void;
  onOpenDiplomacy: () => void;
  onAdvanceSeason: () => void;
  onOpenTournament: () => void;
  onOpenSoulLanterns: () => void;
  onOpenDivination: () => void;
  onOpenDailyCheckIn: () => void;
  onOpenSectors: () => void;
}

export const SectTab: React.FC<SectTabProps> = ({
  season,
  year,
  soulProtectedCount,
  disciplesCount,
  unlockedSectorsCount,
  totalSectorsCount,
  hasUnclaimedCheckIn,
  hasDrawnDivinationToday,
  activeDivination,
  checkInStreak,
  onOpenMerchant,
  onOpenRecruit,
  onTrainAll,
  onMeditate,
  onLeylineSurge,
  onPillInfusion,
  onOpenExpeditions,
  onOpenDiplomacy,
  onAdvanceSeason,
  onOpenTournament,
  onOpenSoulLanterns,
  onOpenDivination,
  onOpenDailyCheckIn,
  onOpenSectors
}) => {
  return (
    <div className="space-y-3.5 pb-16">
      {/* Intro & Traveling Merchant Card */}
      <div className="bg-[#f9f5ea] text-[#1a3329] p-3.5 sm:p-4 rounded-2xl border border-[#e8dbc0] shadow-md space-y-2.5">
        <p className="text-xs sm:text-sm text-[#2c473c] leading-relaxed">
          Govern your mountain peak, tend ancestral Soul Lanterns, divine the Heavenly Dao, and cultivate immortal prodigies.
        </p>
        <button
          onClick={() => {
            soundEngine.playClick();
            onOpenMerchant();
          }}
          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#184838] to-[#123d30] text-[#fce18b] border border-[#e2b054]/60 font-dao font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm hover:from-[#1d5543] hover:to-[#174737] active:scale-[0.98] transition-all min-h-[42px]"
        >
          <Briefcase className="w-4 h-4 text-[#e2b054]" />
          <span>Visit Traveling Merchant (Bao&apos;s Immortal Pavilion)</span>
        </button>
      </div>

      {/* Immortal Sanctuary & Daily Rituals Hub (Soul Lanterns, Daily Divinations, Daily Check-In) */}
      <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
        {/* Soul Lanterns */}
        <button
          onClick={() => {
            soundEngine.playLanternLit();
            onOpenSoulLanterns();
          }}
          className="relative bg-gradient-to-b from-[#164233] to-[#0b271e] hover:from-[#1b523f] hover:to-[#0f3427] p-3 rounded-2xl border border-[#e2b054]/60 text-left shadow-md active:scale-95 transition-all flex flex-col justify-between min-h-[92px]"
        >
          <div className="flex justify-between items-start w-full">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center">
              <Flame className="w-4 h-4 text-amber-300 animate-pulse" />
            </div>
            <span className="text-[10px] font-mono tabular-nums px-1.5 py-0.5 rounded-md bg-[#071913] text-[#fce18b] border border-[#e2b054]/30">
              {soulProtectedCount}/{disciplesCount}
            </span>
          </div>
          <div className="mt-2">
            <div className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] leading-tight">
              Soul Lanterns
            </div>
            <div className="text-[10px] text-[#9fc2b2] leading-tight mt-0.5 truncate">
              Life-Flames &amp; Seals
            </div>
          </div>
        </button>

        {/* Daily Divinations */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onOpenDivination();
          }}
          className="relative bg-gradient-to-b from-[#164233] to-[#0b271e] hover:from-[#1b523f] hover:to-[#0f3427] p-3 rounded-2xl border border-[#e2b054]/60 text-left shadow-md active:scale-95 transition-all flex flex-col justify-between min-h-[92px]"
        >
          <div className="flex justify-between items-start w-full">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-400/50 flex items-center justify-center">
              <Compass className="w-4 h-4 text-sky-300" />
            </div>
            {!hasDrawnDivinationToday ? (
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-amber-400 text-[#072018] animate-pulse">
                FREE
              </span>
            ) : (
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                Blessed
              </span>
            )}
          </div>
          <div className="mt-2">
            <div className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] leading-tight">
              Divinations
            </div>
            <div className="text-[10px] text-[#9fc2b2] leading-tight mt-0.5 truncate">
              {activeDivination ? activeDivination.hexagramName.split('·')[0].trim() : 'Cast Daily Omen'}
            </div>
          </div>
        </button>

        {/* Daily Check-In */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onOpenDailyCheckIn();
          }}
          className="relative bg-gradient-to-b from-[#164233] to-[#0b271e] hover:from-[#1b523f] hover:to-[#0f3427] p-3 rounded-2xl border border-[#e2b054]/60 text-left shadow-md active:scale-95 transition-all flex flex-col justify-between min-h-[92px]"
        >
          <div className="flex justify-between items-start w-full">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center">
              <CalendarCheck2 className="w-4 h-4 text-emerald-300" />
            </div>
            {hasUnclaimedCheckIn ? (
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-amber-400 text-[#072018] animate-pulse">
                CLAIM
              </span>
            ) : (
              <span className="text-[10px] font-mono tabular-nums px-1.5 py-0.5 rounded-md bg-[#071913] text-emerald-300 border border-emerald-500/30">
                Day {checkInStreak}
              </span>
            )}
          </div>
          <div className="mt-2">
            <div className="font-dao font-bold text-xs sm:text-sm text-[#fce18b] leading-tight">
              Daily Check-In
            </div>
            <div className="text-[10px] text-[#9fc2b2] leading-tight mt-0.5 truncate">
              {hasUnclaimedCheckIn ? 'Tribute Waiting' : `Streak: ${checkInStreak}d`}
            </div>
          </div>
        </button>
      </div>

      {/* Peak Challenge & Sect Sectors Dual Highlight Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <div className="bg-gradient-to-r from-[#1b4838] via-[#123d30] to-[#0f3427] p-3.5 rounded-2xl border-2 border-[#e2b054] shadow-lg flex justify-between items-center gap-2.5 text-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-full bg-amber-500/20 flex items-center justify-center border border-amber-400/40 shrink-0">
              <Trophy className="w-5 h-5 text-amber-300" />
            </div>
            <div className="min-w-0">
              <div className="font-dao font-bold text-[#fce18b] text-sm leading-tight">
                Peak Challenge
              </div>
              <div className="text-[10px] text-[#9fc2b2] truncate mt-0.5">
                5-Round Gauntlet · Champion Glory
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playGong();
              onOpenTournament();
            }}
            className="py-2 px-3 rounded-xl bg-gradient-to-r from-[#e2b054] to-[#fce18b] text-[#072018] font-dao font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all shrink-0 whitespace-nowrap min-h-[40px]"
          >
            Enter Arena
          </button>
        </div>

        <div className="bg-gradient-to-r from-[#134232] via-[#0e3226] to-[#09241b] p-3.5 rounded-2xl border border-[#34d399]/60 shadow-lg flex justify-between items-center gap-2.5 text-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-full bg-emerald-500/20 flex items-center justify-center border border-emerald-400/40 shrink-0">
              <MapPin className="w-5 h-5 text-emerald-300" />
            </div>
            <div className="min-w-0">
              <div className="font-dao font-bold text-emerald-200 text-sm leading-tight flex items-center gap-1.5">
                <span>Sect Sectors</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#071913] text-emerald-300 border border-emerald-500/30">
                  {unlockedSectorsCount}/{totalSectorsCount}
                </span>
              </div>
              <div className="text-[10px] text-[#9fc2b2] truncate mt-0.5">
                Peaks, Veins &amp; Sector Lords
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenSectors();
            }}
            className="py-2 px-3 rounded-xl bg-[#184838] hover:bg-[#1e5c48] text-[#fce18b] border border-[#e2b054]/60 font-dao font-bold text-xs shadow-md active:scale-95 transition-all shrink-0 whitespace-nowrap min-h-[40px]"
          >
            Manage Peaks
          </button>
        </div>
      </div>

      {/* Sect Actions Box (Symmetric 8-button grid: 2x4 on mobile, 4x2 on tablet/desktop) */}
      <div className="bg-[#f9f5ea] text-[#1a3329] p-4 rounded-2xl border border-[#e8dbc0] shadow-md space-y-3">
        <div className="flex justify-between items-center border-b border-[#e5d8be] pb-2">
          <h2 className="text-base sm:text-lg font-bold font-dao text-[#0f2b20]">
            Sect Governance &amp; Actions
          </h2>
          <span className="text-[11px] text-[#5c7a6e] bg-[#eee5d3] px-2.5 py-0.5 rounded-full font-medium">
            Mountain Peak
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5 pt-0.5">
          {/* Recruit */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenRecruit();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <GraduationCap className="w-4 h-4 text-[#184838]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Recruit</span>
            <span className="text-[10px] text-[#5a766a]">Invite disciple</span>
          </button>

          {/* Train All */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onTrainAll();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Dumbbell className="w-4 h-4 text-[#184838]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Train All</span>
            <span className="text-[10px] text-[#5a766a]">80 Qi · Sermon</span>
          </button>

          {/* Meditate */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onMeditate();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Sparkles className="w-4 h-4 text-[#b45309]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Meditate</span>
            <span className="text-[10px] text-[#5a766a]">+45 Qi Vein</span>
          </button>

          {/* Leyline Surge */}
          <button
            onClick={() => {
              soundEngine.playTalisman();
              onLeylineSurge();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-cyan-600/15 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Zap className="w-4 h-4 text-cyan-700" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Leyline Surge</span>
            <span className="text-[10px] text-[#5a766a]">60 Stones → Qi</span>
          </button>

          {/* Pill Infusion */}
          <button
            onClick={() => {
              soundEngine.playCauldronBubble();
              onPillInfusion();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-600/15 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <FlaskConical className="w-4 h-4 text-emerald-700" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Pill Infusion</span>
            <span className="text-[10px] text-[#5a766a]">2 Pills → +Exp</span>
          </button>

          {/* Expeditions */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenExpeditions();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Compass className="w-4 h-4 text-[#0284c7]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Expeditions</span>
            <span className="text-[10px] text-[#5a766a]">Secret Realms</span>
          </button>

          {/* Diplomacy */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onOpenDiplomacy();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Users2 className="w-4 h-4 text-[#d97706]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Diplomacy</span>
            <span className="text-[10px] text-[#5a766a]">Sect Relations</span>
          </button>

          {/* Advance Time */}
          <button
            onClick={() => {
              soundEngine.playClick();
              onAdvanceSeason();
            }}
            className="bg-[#f3ebd7] hover:bg-[#eae0c8] active:scale-95 transition-all p-2.5 sm:p-3 rounded-xl border border-[#dfd0b5] flex flex-col items-center justify-center text-center shadow-xs group min-h-[82px]"
          >
            <div className="w-8 h-8 rounded-full bg-[#184838]/10 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Moon className="w-4 h-4 text-[#9333ea]" />
            </div>
            <span className="text-xs font-bold font-dao text-[#0f2b20]">Advance Time</span>
            <span className="text-[10px] text-[#5a766a]">Next season</span>
          </button>
        </div>
      </div>

      {/* Seasonal Atmosphere & Active Omen Footer Card */}
      <div className="bg-[#123d30]/80 border border-[#e2b054]/30 rounded-2xl p-3.5 text-xs text-[#d1e6dc] flex flex-wrap items-center justify-between gap-2">
        <div>
          <span className="text-[#fce18b] font-bold">Current Cycle: </span>
          <span>{season} of Year <span className="font-mono tabular-nums">{year}</span></span>
        </div>
        <span className="text-[11px] text-[#86efac] font-medium">
          {activeDivination ? `Omen: ${activeDivination.hexagramName}` : 'Heavenly Dao Flow: Serene'}
        </span>
      </div>
    </div>
  );
};
