import React, { useState } from 'react';
import { ChronicleEvent } from '../../types/cultivation';
import { formatCalendarDate } from '../../utils/dateUtils';
import { MeritScrollIcon } from '../icons/DaoIcons';
import { Sparkles, Zap, Compass, Users, HeartHandshake, Crown, Award, History } from 'lucide-react';

interface ChronicleTabProps {
  events: ChronicleEvent[];
}

export const ChronicleTab: React.FC<ChronicleTabProps> = ({ events }) => {
  const [filterCategory, setFilterCategory] = useState<string>('All');

  const filteredEvents = events.filter((e) => {
    if (filterCategory === 'All') return true;
    return e.category === filterCategory;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Breakthrough':
        return <Sparkles className="w-4 h-4 text-[#b45309]" />;
      case 'Tribulation':
        return <Zap className="w-4 h-4 text-[#dc2626]" />;
      case 'Expedition':
        return <Compass className="w-4 h-4 text-[#0284c7]" />;
      case 'Relation':
        return <Users className="w-4 h-4 text-[#db2777]" />;
      case 'Diplomacy':
        return <HeartHandshake className="w-4 h-4 text-[#ca8a04]" />;
      case 'Ceremony':
        return <Crown className="w-4 h-4 text-[#b45309]" />;
      case 'Tournament':
        return <Award className="w-4 h-4 text-[#15803d]" />;
      default:
        return <History className="w-4 h-4 text-[#15803d]" />;
    }
  };

  return (
    <div className="space-y-3.5">
      {/* Top Banner */}
      <div className="bg-[#f9f5ea] text-[#132d23] p-4 rounded-2xl border border-[#e8dbc0] shadow-md flex justify-between items-start">
        <div>
          <h2 className="text-lg font-bold font-dao text-[#0f2b20]">
            Sect Chronicle
          </h2>
          <p className="text-xs text-[#4b6659]">
            Official historical annals of Mystic Daoist Temple across the immortal calendar.
          </p>
        </div>
        <div className="w-12 h-12 bg-white rounded-lg border border-[#ded3be] flex items-center justify-center p-1 shadow-inner">
          <MeritScrollIcon className="w-8 h-8 text-[#ca8a04]" />
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scroll-hide">
        {(['All', 'Breakthrough', 'Tribulation', 'Expedition', 'Relation', 'Diplomacy', 'Tournament', 'Ceremony'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1 rounded-xl text-[11px] font-bold shrink-0 transition-all ${
              filterCategory === cat
                ? 'bg-[#15803d] text-white shadow-xs'
                : 'bg-[#123d30] text-[#a4c5b7] hover:bg-[#184c3c]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Recent Events Container */}
      <div className="bg-[#f9f5ea] text-[#132d23] p-4 rounded-2xl border border-[#e8dbc0] shadow-md space-y-3">
        <div className="flex justify-between items-center border-b border-[#e5d8be] pb-2">
          <h3 className="text-sm sm:text-base font-bold font-dao text-[#0f2b20]">
            Recent Events
          </h3>
          <span className="text-[10px] text-[#557366] font-mono tabular-nums">
            {filteredEvents.length} Recorded
          </span>
        </div>

        <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
          {filteredEvents.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#6e8a7d] italic">
              No chronicle records found for this category yet.
            </div>
          ) : (
            filteredEvents.map((event) => (
              <div
                key={event.id}
                className="bg-[#f3ebd7] p-3 rounded-xl border border-[#dfd0b5] space-y-1.5 text-xs shadow-xs"
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="p-1 rounded-md bg-[#184838]/10 shrink-0">
                      {getCategoryIcon(event.category)}
                    </div>
                    <span className="font-bold text-[#0f2b20] text-xs sm:text-sm truncate">
                      {event.title}
                    </span>
                  </div>
                  <span className="text-[10px] text-[#557366] font-mono tabular-nums shrink-0">
                    {event.dateStr ? formatCalendarDate(event.dateStr) : `Year ${event.year} · ${event.season}`}
                  </span>
                </div>

                <p className="text-[11px] sm:text-xs text-[#324f42] leading-relaxed pl-7">
                  {event.details}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
