import React from 'react';
import { Baby, Heart, GraduationCap, Sparkles, BookOpen, UserCheck, ShieldAlert, Gift, Activity, Clock, Edit2 } from 'lucide-react';
import { Child, GameState } from '../../game/types';
import { SCHOOL_STAGES } from '../../game/constants';
import { PREGNANCY_TOTAL_DAYS } from '../../game/engine';
import { playClickSound } from '../../utils/audio';

interface FamilyTabProps {
  gameState: GameState;
  onStartPregnancy: () => void;
  onSonarCheckup: () => void;
  onEducateChild: (childId: string, action: 'study' | 'tutor' | 'books') => void;
  onCheckGrades: (childId: string) => void;
  onDisciplineChild: (childId: string, action: 'advice' | 'ground' | 'reward' | 'extra_study') => void;
  onChangeSchoolType: (childId: string, schoolType: 'public' | 'experimental' | 'private') => void;
  onRenameChild: (childId: string) => void;
}

export const FamilyTab: React.FC<FamilyTabProps> = ({
  gameState,
  onStartPregnancy,
  onSonarCheckup,
  onEducateChild,
  onCheckGrades,
  onDisciplineChild,
  onChangeSchoolType,
  onRenameChild
}) => {
  const { married, pregnancyDaysRemaining, pregnancyGender, children, familyMood, partnerName } = gameState;

  return (
    <div className="space-y-3">
      {/* Visual Live Pregnancy Card */}
      {married && pregnancyDaysRemaining > 0 && (
        <div className="bg-gradient-to-r from-rose-950/60 via-slate-900 to-pink-950/60 border border-rose-500/40 rounded-3xl p-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="p-2.5 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse">
                <Baby className="w-6 h-6" />
              </span>
              <div>
                <h2 className="text-sm font-bold text-rose-200">
                  🤰 متابعة الحمل: مولود قادم في الطريق!
                </h2>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  شريكة حياتك {partnerName} حامل • الجنين ينمو بصحة وعافية
                </p>
              </div>
            </div>

            <button
              onClick={() => { playClickSound(); onSonarCheckup(); }}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md shadow-cyan-600/20 flex items-center gap-1.5 active:scale-95 transition"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>فحص السونار والنوع</span>
            </button>
          </div>

          {/* Pregnancy progress visual countdown */}
          <div className="mt-3.5 p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="flex items-center gap-1.5 text-rose-300 font-semibold">
                <Clock className="w-3.5 h-3.5 text-rose-400" />
                <span>العد التنازلي لموعد الولادة:</span>
              </span>
              <span className="font-bold text-amber-300 font-mono">
                متبقي {pregnancyDaysRemaining} أيام حتى الولادة
              </span>
            </div>
            <div className="h-2.5 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-rose-500 via-pink-400 to-amber-400 rounded-full transition-all duration-500"
                style={{
                  width: `${Math.max(5, ((PREGNANCY_TOTAL_DAYS - pregnancyDaysRemaining) / PREGNANCY_TOTAL_DAYS) * 100)}%`
                }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-400 mt-1.5">
              <span>بداية الحمل</span>
              <span>
                {pregnancyGender
                  ? `النوع المؤكد بالسونار: ${pregnancyGender === 'boy' ? 'ولد 👦' : 'بنت 👧'}`
                  : 'نوع الجنين: لم يُفحص بالسونار بعد'}
              </span>
              <span>يوم الولادة المبارك 🍼</span>
            </div>
          </div>
        </div>
      )}

      {/* Family Overview */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Heart className="w-5 h-5 text-amber-400" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-100">البيت والاستقرار الأسري</h2>
              <p className="text-[11px] text-slate-400">سعادة البيت: {Math.round(familyMood)}%</p>
            </div>
          </div>

          {married && pregnancyDaysRemaining === 0 && children.length < 5 && (
            <button
              onClick={() => { playClickSound(); onStartPregnancy(); }}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 text-white font-bold text-xs shadow-md shadow-rose-500/20 active:scale-95 transition flex items-center gap-1.5"
            >
              <Baby className="w-3.5 h-3.5" />
              <span>التخطيط لطفل جديد</span>
            </button>
          )}
        </div>
      </div>

      {/* Children & Detailed Education */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <GraduationCap className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-slate-100">الأولاد، التعليم، والتربية</h2>
              <p className="text-[11px] text-slate-400">
                عدد الأولاد: {children.length} • متابعة الدروس والشهادات والانضباط
              </p>
            </div>
          </div>
        </div>

        {children.length === 0 ? (
          <div className="text-center py-6 text-slate-400 text-xs bg-slate-950/60 rounded-2xl border border-slate-800/80">
            {married
              ? 'ليس لديك أطفال بعد. يمكنك التخطيط لمولود جديد بالضغط على "التخطيط لطفل جديد" أعلاه.'
              : 'التربية والمدارس للأطفال تبدأ بعد تأسيس عش الزوجية السعيد.'}
          </div>
        ) : (
          <div className="space-y-3.5">
            {children.map((child) => {
              const stageInfo = SCHOOL_STAGES[child.stage] || SCHOOL_STAGES.primary;

              return (
                <div key={child.id} className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                  {/* Child Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{child.gender === 'boy' ? '👦' : '👧'}</span>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-100">{child.name}</span>
                          <span className="text-[10px] text-slate-400">({child.gender === 'boy' ? 'ولد' : 'بنت'})</span>
                          <button
                            onClick={() => { playClickSound(); onRenameChild(child.id); }}
                            className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-amber-300"
                            title="تغيير اسم الطفل"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                          <span>{stageInfo.icon} {stageInfo.label}</span>
                          <span>•</span>
                          <span>العمر: {child.ageDays} يوم</span>
                          {child.lastGrade && (
                            <span className="px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 border border-purple-800 font-bold">
                              التقدير: {child.lastGrade}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* School Type Selector */}
                    <div className="text-left">
                      <span className="block text-[10px] text-slate-400 mb-1">نوع المدرسة:</span>
                      <select
                        value={child.schoolType}
                        onChange={(e) => {
                          playClickSound();
                          onChangeSchoolType(child.id, e.target.value as 'public' | 'experimental' | 'private');
                        }}
                        className="text-[11px] bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-2.5 py-1 focus:outline-none focus:border-amber-400"
                      >
                        <option value="public">مدرسة حكومية (عادية)</option>
                        <option value="experimental">مدرسة تجريبية (متميزة)</option>
                        <option value="private">مدرسة لغات ودولية (ممتازة)</option>
                      </select>
                    </div>
                  </div>

                  {/* Progress bars: Education & Discipline & Happiness */}
                  <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-900 text-[10px]">
                    <div>
                      <div className="flex justify-between mb-0.5">
                        <span className="text-purple-300 font-semibold">التحصيل العلمي</span>
                        <span>{Math.round(child.education)}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-purple-500 rounded-full"
                          style={{ width: `${Math.min(100, Math.max(0, child.education))}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-0.5">
                        <span className="text-cyan-300 font-semibold">الانضباط والأخلاق</span>
                        <span>{Math.round(child.discipline || 70)}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-cyan-500 rounded-full"
                          style={{ width: `${Math.min(100, Math.max(0, child.discipline || 70))}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-0.5">
                        <span className="text-amber-300 font-semibold">السعادة والمرح</span>
                        <span>{Math.round(child.happiness)}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full"
                          style={{ width: `${Math.min(100, Math.max(0, child.happiness))}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {child.groundedDays && child.groundedDays > 0 ? (
                    <div className="p-2 rounded-xl bg-red-950/40 border border-red-800/40 text-[10px] text-red-300 flex items-center gap-1.5">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>الطفل معاقب حالياً بسحب الألعاب والموبايل (متبقي {child.groundedDays} أيام)</span>
                    </div>
                  ) : null}

                  {/* Child Actions */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {/* Check Grades */}
                    <button
                      onClick={() => { playClickSound(); onCheckGrades(child.id); }}
                      className="px-2.5 py-1.5 rounded-xl bg-purple-950 hover:bg-purple-900 border border-purple-800 text-purple-200 text-[11px] font-bold transition flex items-center gap-1"
                    >
                      <BookOpen className="w-3 h-3 text-purple-400" />
                      <span>فحص شهادة الدرجات</span>
                    </button>

                    {/* Study Together */}
                    <button
                      onClick={() => { playClickSound(); onEducateChild(child.id, 'study'); }}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold transition flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3 text-amber-400" />
                      <span>مذاكرة معاً (طاقة)</span>
                    </button>

                    {/* Private Tutor */}
                    <button
                      onClick={() => { playClickSound(); onEducateChild(child.id, 'tutor'); }}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold transition flex items-center gap-1"
                    >
                      <span>درس خصوصي (120 ج)</span>
                    </button>

                    {/* Parental Advice */}
                    <button
                      onClick={() => { playClickSound(); onDisciplineChild(child.id, 'advice'); }}
                      className="px-2.5 py-1.5 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-200 text-[11px] font-bold transition flex items-center gap-1"
                    >
                      <UserCheck className="w-3 h-3 text-cyan-400" />
                      <span>نصيحة وتوجيه (+انضباط)</span>
                    </button>

                    {/* Ground / Punishment */}
                    <button
                      onClick={() => { playClickSound(); onDisciplineChild(child.id, 'ground'); }}
                      className="px-2.5 py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900/60 border border-red-800 text-red-200 text-[11px] font-bold transition flex items-center gap-1"
                      title="سحب الألعاب والموبايل كعقاب على التقصير"
                    >
                      <ShieldAlert className="w-3 h-3 text-red-400" />
                      <span>عقاب تربوي (سحب الموبايل)</span>
                    </button>

                    {/* Reward */}
                    <button
                      onClick={() => { playClickSound(); onDisciplineChild(child.id, 'reward'); }}
                      className="px-2.5 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800 text-emerald-200 text-[11px] font-bold transition flex items-center gap-1"
                    >
                      <Gift className="w-3 h-3 text-emerald-400" />
                      <span>مكافأة وهدية (80 ج)</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
