import React from 'react';
import { SaveData } from '../types/game';
import { X, Calendar, Flame, Check, Play, Star, Coins } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface DailyCalendarModalProps {
  saveData: SaveData;
  onPlayToday: () => void;
  onClose: () => void;
}

export const DailyCalendarModal: React.FC<DailyCalendarModalProps> = ({
  saveData,
  onPlayToday,
  onClose
}) => {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-indexed
  const todayDateNum = today.getDate();
  const todayDateStr = today.toISOString().split('T')[0];

  const monthName = today.toLocaleString('default', { month: 'long' });
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfWeek = new Date(year, month, 1).getDay(); // 0 = Sun

  const isTodayDone = Boolean(saveData.dailyCompletions[todayDateStr]?.completed);

  // Generate calendar cells
  const calendarCells: { dayNum: number | null; dateStr: string; isToday: boolean; isPast: boolean; isDone: boolean; stars: number }[] = [];

  for (let i = 0; i < firstDayOfWeek; i++) {
    calendarCells.push({ dayNum: null, dateStr: '', isToday: false, isPast: false, isDone: false, stars: 0 });
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const dStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const isToday = d === todayDateNum;
    const isPast = d < todayDateNum;
    const completion = saveData.dailyCompletions[dStr];
    const isDone = Boolean(completion?.completed);
    const stars = completion?.stars || 0;

    calendarCells.push({
      dayNum: d,
      dateStr: dStr,
      isToday,
      isPast,
      isDone,
      stars
    });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                DAILY CHALLENGE
              </h2>
              <p className="text-xs text-slate-400">
                {monthName} {year} · Streak: {saveData.stats.dailyStreak} Days
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              onClose();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Streak & Rewards Card */}
        <div className="my-4 p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Flame className="w-5 h-5 fill-orange-500 text-orange-500" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">
                {saveData.stats.dailyStreak} Day Streak
              </div>
              <div className="text-[11px] text-slate-400">
                Daily Completion: +100 Coins Bonus
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(2);
              onPlayToday();
            }}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-[0_0_15px_rgba(245,158,11,0.3)] hover:scale-105 active:scale-95 transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>{isTodayDone ? 'REPLAY TODAY' : "PLAY TODAY'S PUZZLE"}</span>
          </button>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-slate-500 mb-2">
          {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map((day) => (
            <div key={day}>{day}</div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1.5 mb-2">
          {calendarCells.map((cell, idx) => {
            if (!cell.dayNum) {
              return <div key={idx} className="aspect-square" />;
            }

            return (
              <div
                key={idx}
                className={`aspect-square rounded-xl flex flex-col items-center justify-center relative border transition-all text-xs font-mono font-bold ${
                  cell.isToday
                    ? 'border-amber-400 bg-amber-500/10 text-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
                    : cell.isDone
                    ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-400'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400'
                }`}
              >
                <span>{cell.dayNum}</span>
                {cell.isDone ? (
                  <Check className="w-3 h-3 text-emerald-400 mt-0.5" />
                ) : cell.isToday ? (
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-0.5" />
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
