import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Wand2,
  PenTool,
  Check,
  Copy,
  ArrowRight,
  Send,
  RotateCcw,
  Sliders,
  Layers,
  ChevronRight,
  Cpu,
  Info,
  Edit3,
} from 'lucide-react';
import { ChatSettings } from '../types/index.ts';

export type AIAssistTab = 'enhance' | 'write';

interface AIAssistModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: AIAssistTab;
  currentInputText: string;
  onApplyText: (newText: string, andSend?: boolean) => void;
  settings: ChatSettings;
}

export const AIAssistModal: React.FC<AIAssistModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'enhance',
  currentInputText,
  onApplyText,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<AIAssistTab>(initialTab);

  // Enhance Draft states
  const [draftText, setDraftText] = useState('');
  const [enhanceStyle, setEnhanceStyle] = useState<
    'clarify' | 'professional' | 'concise' | 'prompt_engineering' | 'expand' | 'creative'
  >('clarify');
  const [enhanceCustomInstruction, setEnhanceCustomInstruction] = useState('');
  const [enhancedResult, setEnhancedResult] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhanceError, setEnhanceError] = useState<string | null>(null);

  // Write For Me states
  const [topicInput, setTopicInput] = useState('');
  const [writeType, setWriteType] = useState<
    'general' | 'coding' | 'business' | 'learning' | 'creative'
  >('general');
  const [writeTone, setWriteTone] = useState<
    'balanced' | 'formal' | 'casual' | 'analytical' | 'creative'
  >('balanced');
  const [writeCustomInstruction, setWriteCustomInstruction] = useState('');
  const [writtenResult, setWrittenResult] = useState('');
  const [isWriting, setIsWriting] = useState(false);
  const [writeError, setWriteError] = useState<string | null>(null);

  // Copy feedback
  const [copiedEnhanced, setCopiedEnhanced] = useState(false);
  const [copiedWritten, setCopiedWritten] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      if (initialTab === 'enhance' && currentInputText.trim()) {
        setDraftText(currentInputText.trim());
      } else if (!draftText && currentInputText.trim()) {
        setDraftText(currentInputText.trim());
      }
    }
  }, [isOpen, initialTab, currentInputText]);

  if (!isOpen) return null;

  // Handle Enhance Call
  const handleEnhance = async () => {
    if (!draftText.trim()) return;
    setIsEnhancing(true);
    setEnhanceError(null);

    try {
      const res = await fetch('/api/prompt/enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          draft: draftText.trim(),
          style: enhanceStyle,
          customInstruction: enhanceCustomInstruction.trim(),
          model: settings.model,
          provider: settings.provider,
          openRouterApiKey: settings.openRouterApiKey,
          openRouterModel: settings.openRouterModel,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Gagal menyempurnakan draf');
      }

      setEnhancedResult(data.enhancedText || '');
    } catch (err: any) {
      setEnhanceError(err.message || 'Terjadi kesalahan jaringan.');
    } finally {
      setIsEnhancing(false);
    }
  };

  // Handle Write For Me Call
  const handleWrite = async () => {
    if (!topicInput.trim()) return;
    setIsWriting(true);
    setWriteError(null);

    try {
      const res = await fetch('/api/prompt/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topicInput.trim(),
          type: writeType,
          tone: writeTone,
          customInstruction: writeCustomInstruction.trim(),
          model: settings.model,
          provider: settings.provider,
          openRouterApiKey: settings.openRouterApiKey,
          openRouterModel: settings.openRouterModel,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Gagal menuliskan pesan');
      }

      setWrittenResult(data.generatedText || '');
    } catch (err: any) {
      setWriteError(err.message || 'Terjadi kesalahan jaringan.');
    } finally {
      setIsWriting(false);
    }
  };

  const handleCopy = (text: string, isEnhanced: boolean) => {
    navigator.clipboard.writeText(text);
    if (isEnhanced) {
      setCopiedEnhanced(true);
      setTimeout(() => setCopiedEnhanced(false), 2000);
    } else {
      setCopiedWritten(true);
      setTimeout(() => setCopiedWritten(false), 2000);
    }
  };

  const handleApply = (text: string, andSend = false) => {
    onApplyText(text, andSend);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <span>Asisten Penulisan AI</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-medium">
                  Cerdas &amp; Cepat
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Tingkatkan draf pesan Anda atau minta AI menuliskan prompt lengkap siap kirim.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-4 pt-1 gap-2">
          <button
            onClick={() => setActiveTab('enhance')}
            className={`flex items-center gap-2 py-2.5 px-3.5 border-b-2 text-xs font-semibold transition cursor-pointer ${
              activeTab === 'enhance'
                ? 'border-indigo-500 text-white bg-slate-900/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>Sempurnakan Draf (Enhance)</span>
          </button>

          <button
            onClick={() => setActiveTab('write')}
            className={`flex items-center gap-2 py-2.5 px-3.5 border-b-2 text-xs font-semibold transition cursor-pointer ${
              activeTab === 'write'
                ? 'border-indigo-500 text-white bg-slate-900/40'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <PenTool className="w-3.5 h-3.5 text-sky-400" />
            <span>Tuliskan Untuk Saya (Write for Me)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* TAB 1: ENHANCE MY DRAFT */}
          {activeTab === 'enhance' && (
            <div className="space-y-4">
              {/* Draft Input Field */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Teks Draf Awal Anda:</span>
                  </label>
                  {draftText.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setDraftText('')}
                      className="text-[10px] text-slate-400 hover:text-rose-400 transition cursor-pointer"
                    >
                      Bersihkan
                    </button>
                  )}
                </div>
                <textarea
                  value={draftText}
                  onChange={(e) => setDraftText(e.target.value)}
                  placeholder="Ketik atau tempel draf pertanyaan/pesan Anda di sini (misal: 'tolong jelaskan cara kerja docker tapi yang simpel buat pemula')..."
                  rows={4}
                  className="w-full bg-slate-950 border border-slate-750 focus:border-indigo-500 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500/30 transition resize-y"
                />
              </div>

              {/* Style Selection Chips */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-200">
                  Pilih Gaya Penyempurnaan:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    {
                      id: 'clarify',
                      title: '⚡ Rapi & Jelas',
                      desc: 'Perbaiki tata bahasa, ejaan & alur kalimat',
                    },
                    {
                      id: 'prompt_engineering',
                      title: '🧠 Prompt AI Pro',
                      desc: 'Format master prompt: Persona, Task, Context',
                    },
                    {
                      id: 'professional',
                      title: '💼 Formal & Santun',
                      desc: 'Gaya bisnis profesional & baku (EYD V)',
                    },
                    {
                      id: 'concise',
                      title: '🎯 Ringkas & Padat',
                      desc: 'Langsung to the point, hapus kata mubazir',
                    },
                    {
                      id: 'expand',
                      title: '📚 Detail & Konteks',
                      desc: 'Perkaya dengan rincian & latar belakang',
                    },
                    {
                      id: 'creative',
                      title: '🎨 Kreatif & Naratif',
                      desc: 'Gaya bercerita hidup & kosakata imajinatif',
                    },
                  ].map((st) => (
                    <div
                      key={st.id}
                      onClick={() => setEnhanceStyle(st.id as any)}
                      className={`p-2.5 rounded-xl border cursor-pointer transition ${
                        enhanceStyle === st.id
                          ? 'bg-indigo-600/20 border-indigo-500 text-white ring-1 ring-indigo-500/40'
                          : 'bg-slate-800/40 border-slate-750 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs">{st.title}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                        {st.desc}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Optional Custom Directive */}
              <div className="space-y-1">
                <label className="block text-[11px] font-medium text-slate-300">
                  Instruksi Khusus Tambahan (Opsional):
                </label>
                <input
                  type="text"
                  value={enhanceCustomInstruction}
                  onChange={(e) => setEnhanceCustomInstruction(e.target.value)}
                  placeholder="Contoh: Sertakan analogi memasak, atau fokuskan pada performa sistem..."
                  className="w-full bg-slate-950 border border-slate-750 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Action Button */}
              <button
                type="button"
                onClick={handleEnhance}
                disabled={!draftText.trim() || isEnhancing}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-xs sm:text-sm font-semibold text-white shadow-lg shadow-indigo-600/25 transition cursor-pointer"
              >
                {isEnhancing ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" />
                    <span>Sedang Menyempurnakan Draf...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" />
                    <span>Sempurnakan Draf Sekarang</span>
                  </>
                )}
              </button>

              {/* Error Notice */}
              {enhanceError && (
                <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-300">
                  {enhanceError}
                </div>
              )}

              {/* Enhanced Result Box */}
              {enhancedResult && (
                <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-indigo-500/40 space-y-3 shadow-inner">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                      <Check className="w-4 h-4" />
                      <span>Hasil Draf yang Ditingkatkan:</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(enhancedResult, true)}
                      className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer"
                    >
                      {copiedEnhanced ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 font-medium">Disalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Salin Teks</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs sm:text-sm text-slate-100 leading-relaxed whitespace-pre-wrap select-text">
                    {enhancedResult}
                  </div>

                  {/* Actions for Result */}
                  <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleApply(enhancedResult, false)}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition cursor-pointer"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                      <span>Terapkan ke Kotak Teks</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApply(enhancedResult, true)}
                      className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-md shadow-indigo-600/30 transition cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Terapkan &amp; Kirim Langsung</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: WRITE FOR ME */}
          {activeTab === 'write' && (
            <div className="space-y-4">
              {/* Topic / Idea Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <PenTool className="w-3.5 h-3.5 text-sky-400" />
                  <span>Topik atau Ide Utama Pesan:</span>
                </label>
                <textarea
                  value={topicInput}
                  onChange={(e) => setTopicInput(e.target.value)}
                  placeholder="Ketik ide apa yang ingin Anda tanyakan atau tuliskan (misal: 'Bantu buatkan rencana riset pasar kopi susu lokal' atau 'Buatkan email permohonan magang')..."
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-750 focus:border-indigo-500 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500/30 transition resize-y"
                />

                {/* Quick Ideas Chips */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-400 self-center">Inspirasi Cepat:</span>
                  {[
                    'Arsitektur REST API Clean Code',
                    'Email penawaran kerjasama bisnis',
                    'Jelaskan Machine Learning untuk pemula',
                    'Strategi pemasaran media sosial 2026',
                    'Kisah petualangan sci-fi cyberpunk',
                  ].map((idea) => (
                    <button
                      key={idea}
                      type="button"
                      onClick={() => setTopicInput(idea)}
                      className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-750 text-[10px] text-slate-300 font-medium transition cursor-pointer border border-slate-700/60"
                    >
                      {idea}
                    </button>
                  ))}
                </div>
              </div>

              {/* Category & Type */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-200">
                  Tipe Permintaan:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'general', title: '💬 Konsultasi & Tanya', desc: 'Pertanyaan terstruktur mendalam' },
                    { id: 'coding', title: '💻 Koding & Teknis', desc: 'Kode, debugging & arsitektur' },
                    { id: 'business', title: '🏢 Bisnis & Email', desc: 'Pesan profesional & kerja' },
                    { id: 'learning', title: '📖 Konsep & Tutorial', desc: 'Penjelasan langkah demi langkah' },
                    { id: 'creative', title: '✨ Fiksi & Kreatif', desc: 'Cerita, narasi & ide imajinatif' },
                  ].map((tp) => (
                    <div
                      key={tp.id}
                      onClick={() => setWriteType(tp.id as any)}
                      className={`p-2.5 rounded-xl border cursor-pointer transition ${
                        writeType === tp.id
                          ? 'bg-indigo-600/20 border-indigo-500 text-white ring-1 ring-indigo-500/40'
                          : 'bg-slate-800/40 border-slate-750 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-xs">{tp.title}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5 truncate">{tp.desc}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tone Selection */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-200">
                  Gaya Bahasa / Tone:
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { id: 'balanced', label: '⚖️ Seimbang & Lugas' },
                    { id: 'formal', label: '👔 Formal & Santun' },
                    { id: 'casual', label: '☕ Santai & Ramah' },
                    { id: 'analytical', label: '📊 Analitis & Kritis' },
                    { id: 'creative', label: '🎨 Penuh Imajinasi' },
                  ].map((tn) => (
                    <button
                      key={tn.id}
                      type="button"
                      onClick={() => setWriteTone(tn.id as any)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                        writeTone === tn.id
                          ? 'bg-sky-600/20 border-sky-500 text-sky-200'
                          : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {tn.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Optional Custom Instructions */}
              <div className="space-y-1">
                <label className="block text-[11px] font-medium text-slate-300">
                  Instruksi Tambahan (Opsional):
                </label>
                <input
                  type="text"
                  value={writeCustomInstruction}
                  onChange={(e) => setWriteCustomInstruction(e.target.value)}
                  placeholder="Contoh: Cantumkan 3 poin utama, atau gunakan istilah teknis bahasa Inggris..."
                  className="w-full bg-slate-950 border border-slate-750 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Submit Button */}
              <button
                type="button"
                onClick={handleWrite}
                disabled={!topicInput.trim() || isWriting}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-50 text-xs sm:text-sm font-semibold text-white shadow-lg shadow-sky-600/25 transition cursor-pointer"
              >
                {isWriting ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" />
                    <span>Sedang Merangkai Tulisan...</span>
                  </>
                ) : (
                  <>
                    <PenTool className="w-4 h-4" />
                    <span>Tuliskan Untuk Saya Sekarang</span>
                  </>
                )}
              </button>

              {/* Error Notice */}
              {writeError && (
                <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-300">
                  {writeError}
                </div>
              )}

              {/* Written Result Box */}
              {writtenResult && (
                <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-sky-500/40 space-y-3 shadow-inner">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-sky-400">
                      <Check className="w-4 h-4" />
                      <span>Draf Pesan Siap Kirim:</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(writtenResult, false)}
                      className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer"
                    >
                      {copiedWritten ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 font-medium">Disalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Salin Teks</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs sm:text-sm text-slate-100 leading-relaxed whitespace-pre-wrap select-text">
                    {writtenResult}
                  </div>

                  {/* Actions for Written Result */}
                  <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleApply(writtenResult, false)}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition cursor-pointer"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                      <span>Terapkan ke Kotak Teks</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApply(writtenResult, true)}
                      className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-xs font-semibold text-white shadow-md shadow-sky-600/30 transition cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Terapkan &amp; Kirim Langsung</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
