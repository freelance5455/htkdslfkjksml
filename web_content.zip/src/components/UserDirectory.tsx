import React, { useState, useEffect } from 'react';
import { Search, MessageSquare, Flag, ShieldBan, ShieldCheck, UserCheck } from 'lucide-react';
import type { User } from '../types/index.ts';
import { api } from '../services/api.ts';
import { BlueTick } from './BlueTick.tsx';

interface UserDirectoryProps {
  currentUser: User;
  onStartChat: (targetUserId: string) => void;
  onOpenReport: (userId: string, username: string) => void;
}

export const UserDirectory: React.FC<UserDirectoryProps> = ({
  currentUser,
  onStartChat,
  onOpenReport,
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getUsers().then(data => {
      // Exclude self from messaging directory list
      setUsers(data || []);
      setLoading(false);
    });
  }, []);

  const filteredUsers = users.filter(u => {
    if (u.id === currentUser.id) return false;
    const q = searchQuery.toLowerCase();
    return u.username.toLowerCase().includes(q) || u.fullName.toLowerCase().includes(q);
  });

  const aiAgent = users.find(u => u.id === 'usr_ug_ai_agent');
  const humanUsers = filteredUsers.filter(u => u.id !== 'usr_ug_ai_agent');

  return (
    <div className="flex-1 flex flex-col h-full bg-[#080a0f] overflow-hidden text-slate-100">
      {/* Search Header */}
      <div className="p-4 bg-[#0a0f18] border-b border-slate-800 shrink-0">
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search permitted esports players or AI support..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700/80 text-white placeholder-slate-500 text-xs focus:border-cyan-400 outline-none"
          />
        </div>
      </div>

      {/* Directory List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {/* Pinned AI Agent Support Banner */}
        {aiAgent && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0c1a2e] to-[#0a1220] border border-cyan-500/50 shadow-[0_0_20px_rgba(0,210,255,0.15)] flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative shrink-0">
                <img
                  src={aiAgent.avatarUrl}
                  alt={aiAgent.fullName}
                  className="w-12 h-12 rounded-xl bg-cyan-950 border-2 border-cyan-400 object-cover shadow-[0_0_12px_rgba(0,210,255,0.4)]"
                />
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-cyan-400 ring-2 ring-[#0c1a2e]" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5 font-bold text-white text-sm truncate">
                  <span>{aiAgent.fullName}</span>
                  <BlueTick size="sm" />
                </div>
                <div className="text-[11px] text-cyan-300 font-mono">@{aiAgent.username}</div>
                <div className="text-[11px] text-slate-300 truncate mt-0.5">
                  Trained by Admin · 24/7 AI help with bans, rules & disputes
                </div>
              </div>
            </div>

            <button
              onClick={() => onStartChat(aiAgent.id)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/25 active:scale-95 transition-all cursor-pointer shrink-0"
            >
              <MessageSquare size={14} />
              <span>Chat with AI</span>
            </button>
          </div>
        )}

        <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 px-1 mb-1">
          Permitted Clan Players ({humanUsers.length})
        </div>

        {humanUsers.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <UserCheck size={32} className="mx-auto mb-2 text-slate-600" />
            <p className="text-xs">No gamers found matching your search</p>
          </div>
        ) : (
          humanUsers.map((user) => (
            <div
              key={user.id}
              className="p-3 rounded-2xl bg-[#0c121e] border border-slate-800/80 hover:border-cyan-500/30 transition-all flex items-center justify-between gap-3 group"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative shrink-0">
                  <img
                    src={user.avatarUrl}
                    alt={user.username}
                    className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-700 object-cover"
                  />
                  {user.online && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-[#0c121e]" />
                  )}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 font-bold text-white text-sm truncate">
                    <span className="truncate">{user.fullName}</span>
                    {user.verifiedBlueTick && <BlueTick size="sm" />}
                  </div>
                  <div className="text-xs text-cyan-400 font-mono">@{user.username}</div>
                  <div className="text-[11px] text-slate-400 truncate max-w-[200px] mt-0.5">
                    {user.bio || 'Unknown Gamer Player'}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => onStartChat(user.id)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 active:scale-95 transition-all cursor-pointer"
                >
                  <MessageSquare size={14} />
                  <span>Chat</span>
                </button>

                <button
                  onClick={() => onOpenReport(user.id, user.username)}
                  className="p-2 rounded-xl bg-slate-800/60 hover:bg-red-950/60 text-slate-400 hover:text-red-400 transition-colors"
                  title="Report User"
                >
                  <Flag size={15} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
