import React, { useState } from 'react';

export const OMAZIFY_LOGO_URL = '/omazify-logo.png';
export const OMAZIFY_LOGO_FALLBACK =
  'https://i.ibb.co/1GhYtbLb/file-00000000b01482108ffc58c623c8aea4.png';

interface OmazifyLogoProps {
  variant?: 'container' | 'bare' | 'white';
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const OmazifyLogo: React.FC<OmazifyLogoProps> = ({
  variant = 'container',
  className = '',
  size = 'md',
  showText = true,
}) => {
  const [imgSrc, setImgSrc] = useState(OMAZIFY_LOGO_URL);

  const sizeConfig = {
    sm: {
      img: 'w-7 h-7 sm:w-8 sm:h-8',
      box: 'p-0.5 rounded-lg',
      text: 'text-xs sm:text-sm',
    },
    md: {
      img: 'w-9 h-9 sm:w-10 sm:h-10',
      box: 'p-0.5 rounded-xl',
      text: 'text-sm sm:text-base',
    },
    lg: {
      img: 'w-14 h-14 sm:w-16 sm:h-16',
      box: 'p-1 rounded-2xl',
      text: 'text-lg sm:text-xl',
    },
    xl: {
      img: 'w-20 h-20 sm:w-24 sm:h-24',
      box: 'p-1.5 rounded-3xl',
      text: 'text-2xl',
    },
  }[size];

  return (
    <div
      className={`inline-flex items-center gap-2 select-none ${className}`}
      title="OMAZIFY"
    >
      {/* Official OMAZIFY App Logo from https://ibb.co/qYXL3xdx */}
      <div
        className={`flex-shrink-0 flex items-center justify-center bg-black border border-black/90 shadow-xs overflow-hidden ${
          sizeConfig.box
        } ${variant === 'white' ? 'ring-1 ring-[#EAEAEA]' : ''}`}
      >
        <img
          src={imgSrc}
          alt="OMAZIFY Logo"
          className={`${sizeConfig.img} object-contain rounded-md transition-transform duration-200 hover:scale-105`}
          onError={() => {
            if (imgSrc !== OMAZIFY_LOGO_FALLBACK) {
              setImgSrc(OMAZIFY_LOGO_FALLBACK);
            }
          }}
          loading="eager"
        />
      </div>

      {/* Brand Typography */}
      {showText && (
        <div className={`flex items-center tracking-wider font-black leading-none ${sizeConfig.text}`}>
          <span className="text-[#000000]">OMAZ</span>
          <span className="text-[#FFD400]">IFY</span>
        </div>
      )}
    </div>
  );
};

export default OmazifyLogo;
