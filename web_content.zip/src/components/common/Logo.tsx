import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  variant?: 'full' | 'bag-only' | 'horizontal';
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showTagline = true,
  variant = 'full',
}) => {
  const sizeMap = {
    sm: { bag: 32, text: 'text-base', subtext: 'text-[9px]' },
    md: { bag: 44, text: 'text-xl', subtext: 'text-[11px]' },
    lg: { bag: 64, text: 'text-2xl', subtext: 'text-xs' },
    xl: { bag: 96, text: 'text-4xl', subtext: 'text-sm' },
  };

  const { bag, text, subtext } = sizeMap[size];

  // SVG representation of the PCMART shopping bag icon
  const BagSvg = () => (
    <svg
      width={bag}
      height={bag}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 drop-shadow-md"
    >
      <defs>
        <linearGradient id="bagGrad" x1="15" y1="25" x2="85" y2="95" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1E56D0" />
          <stop offset="0.6" stopColor="#1746A2" />
          <stop offset="1" stopColor="#0F337B" />
        </linearGradient>
        <linearGradient id="yellowGrad" x1="40" y1="35" x2="80" y2="75" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFE066" />
          <stop offset="1" stopColor="#FFC820" />
        </linearGradient>
        <filter id="shadow" x="0" y="0" width="100" height="100" filterUnits="userSpaceOnUse">
          <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#000" floodOpacity="0.25" />
        </filter>
      </defs>

      {/* Bag handle */}
      <path
        d="M38 30 V20 C38 13.5 43.5 8 50 8 C56.5 8 62 13.5 62 20 V30"
        stroke="#1E56D0"
        strokeWidth="6"
        strokeLinecap="round"
        fill="none"
      />
      {/* Handle attachment grommets */}
      <circle cx="38" cy="28" r="4.5" fill="#FFD447" />
      <circle cx="62" cy="28" r="4.5" fill="#FFD447" />

      {/* Bag Body with Trapezoidal Curve */}
      <path
        d="M26 28 H74 C78 28 81 31 82 35 L89 82 C90 87 86 91 81 91 H19 C14 91 10 87 11 82 L18 35 C19 31 22 28 26 28 Z"
        fill="url(#bagGrad)"
      />

      {/* Yellow 'C' shape in background of emblem */}
      <path
        d="M58 40 C67 36 78 43 78 54 C78 66 66 73 54 71 C45 69 41 63 43 56 C44 51 51 51 52 56 C53 60 58 63 64 62 C69 61 71 56 70 51 C69 45 62 44 57 47 Z"
        fill="url(#yellowGrad)"
      />

      {/* Speed lines for White 'P' */}
      <rect x="23" y="44" width="13" height="3.5" rx="1.75" fill="#FFD447" />
      <rect x="23" y="50" width="16" height="3.5" rx="1.75" fill="#FFD447" />
      <rect x="23" y="56" width="12" height="3.5" rx="1.75" fill="#FFD447" />

      {/* White 'P' */}
      <path
        d="M31 38 H48 C57 38 61 44 59 52 C57 59 51 63 43 63 H39 L35 77 H28 L31 38 Z M38 45 L36 56 H43 C47 56 49 54 50 51 C51 47 48 45 44 45 H38 Z"
        fill="#FFFFFF"
      />
    </svg>
  );

  if (variant === 'bag-only') {
    return <BagSvg />;
  }

  if (variant === 'horizontal') {
    return (
      <div className={`flex items-center gap-2 shrink-0 ${className}`}>
        <BagSvg />
        <div className="flex flex-col leading-none">
          <div className="flex items-center tracking-tight font-black">
            <span className="text-[#3B82F6] dark:text-[#60A5FA] font-black text-sm tracking-tight">PC</span>
            <span className="text-[#FFD447] font-black text-sm tracking-tight">MART</span>
          </div>
          {showTagline && (
            <span className="text-[8px] text-slate-400 font-medium tracking-tight whitespace-nowrap">
              Har Choice, Premium Choice
            </span>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`flex flex-col items-center select-none ${className}`}>
      <BagSvg />
      <div className="mt-1 flex items-baseline tracking-tight font-black">
        <span className="text-[#1746A2] dark:text-[#4F83F7] font-extrabold" style={{ fontSize: size === 'xl' ? '2.5rem' : size === 'lg' ? '1.75rem' : '1.25rem' }}>
          PC
        </span>
        <span className="text-[#FFD447] font-extrabold" style={{ fontSize: size === 'xl' ? '2.5rem' : size === 'lg' ? '1.75rem' : '1.25rem' }}>
          MART
        </span>
      </div>
      {showTagline && (
        <div className="flex items-center gap-1.5 mt-0.5 text-slate-500 dark:text-slate-300 font-semibold">
          <span className="h-[1.5px] w-3 bg-[#FFD447] rounded-full"></span>
          <span className={`${subtext} tracking-wider uppercase font-bold text-slate-300`}>
            Har Choice, Premium Choice
          </span>
          <span className="h-[1.5px] w-3 bg-[#FFD447] rounded-full"></span>
        </div>
      )}
    </div>
  );
};
