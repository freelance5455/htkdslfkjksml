import React from 'react';
import { MembershipTier } from '../../types';
import { Crown, Sparkles, Shield, Award } from 'lucide-react';

interface VipBadgeProps {
  tier?: MembershipTier | string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const VipBadge: React.FC<VipBadgeProps> = ({ tier = 'basic', size = 'sm', showIcon = true }) => {
  const getBadgeConfig = (t: string) => {
    switch (t) {
      case 'vip4':
      case 'premium300':
        return {
          label: 'Diamond VIP 💎',
          bg: 'bg-gradient-to-r from-cyan-500 via-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/25 border border-cyan-300/40',
          icon: <Sparkles className="w-3 h-3 animate-spin text-cyan-200" />
        };
      case 'vip3':
      case 'premium100':
        return {
          label: 'Gold VIP 🏆',
          bg: 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-slate-950 font-black shadow-md shadow-amber-500/25 border border-amber-300/60',
          icon: <Crown className="w-3 h-3 text-slate-950" />
        };
      case 'vip2':
      case 'pro':
        return {
          label: 'Silver VIP 🥈',
          bg: 'bg-gradient-to-r from-slate-300 via-slate-200 to-slate-400 text-slate-950 font-bold shadow-sm border border-slate-400/50',
          icon: <Shield className="w-3 h-3 text-slate-900" />
        };
      case 'vip1':
      case 'premium':
        return {
          label: 'Bronze VIP 🥉',
          bg: 'bg-gradient-to-r from-amber-700 via-amber-600 to-yellow-800 text-white shadow-sm border border-amber-600/40',
          icon: <Award className="w-3 h-3 text-amber-200" />
        };
      default:
        return {
          label: 'Free Tier',
          bg: 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700',
          icon: <Shield className="w-3 h-3 text-slate-500" />
        };
    }
  };

  const config = getBadgeConfig(tier);

  const sizeClasses = size === 'lg' 
    ? 'px-3.5 py-1 text-xs' 
    : size === 'md' 
      ? 'px-2.5 py-0.5 text-[11px]' 
      : 'px-2 py-0.5 text-[10px]';

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-black uppercase tracking-wider transition-all ${config.bg} ${sizeClasses}`}>
      {showIcon && config.icon}
      <span>{config.label}</span>
    </span>
  );
};
