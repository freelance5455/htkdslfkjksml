import { useState, useRef } from 'react';
import {
  X,
  Upload,
  Download,
  FileCode,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Terminal,
  FolderArchive,
  RefreshCw,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { TravelTrip, WalletDocument, UserProfile, Language } from '../../types';
import {
  createAppExport,
  validateImportData,
  downloadBackupFile,
  AppExportData,
  ImportValidationResult,
} from '../../utils/appImportExport';

interface AppImportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  user: UserProfile;
  activeTrip: TravelTrip;
  walletDocuments: WalletDocument[];
  onImportData: (importedData: AppExportData) => void;
}

export function AppImportExportModal({
  isOpen,
  onClose,
  language,
  user,
  activeTrip,
  walletDocuments,
  onImportData,
}: AppImportExportModalProps) {
  const [activeTab, setActiveTab] = useState<'import' | 'export' | 'code'>('import');
  const [jsonInput, setJsonInput] = useState('');
  const [validationResult, setValidationResult] = useState<ImportValidationResult | null>(null);
  const [importSuccess, setImportSuccess] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const isRTL = language === 'ar';

  const handleJsonChange = (text: string) => {
    setJsonInput(text);
    if (!text.trim()) {
      setValidationResult(null);
      return;
    }
    const result = validateImportData(text);
    setValidationResult(result);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const content = event.target?.result as string;
      if (content) {
        handleJsonChange(content);
      }
    };
    reader.readAsText(file);
  };

  const handleExecuteImport = () => {
    if (validationResult?.valid && validationResult.data) {
      onImportData(validationResult.data);
      setImportSuccess(true);
      setTimeout(() => {
        setImportSuccess(false);
        onClose();
      }, 1500);
    }
  };

  const handleTriggerExport = () => {
    const backup = createAppExport(activeTrip, walletDocuments, user);
    downloadBackupFile(backup, `takigo-backup-${Date.now().toString(36)}.json`);
  };

  const cliSnippet = `# 1. Clone or extract the downloaded project\ncd applet\n\n# 2. Install all dependencies\nnpm install\n\n# 3. Start local development server\nnpm run dev\n\n# 4. Run tests\nnpm test`;

  const handleCopyCli = () => {
    navigator.clipboard?.writeText(cliSnippet);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#091129] border border-cyan-500/40 text-white shadow-[0_0_50px_rgba(0,102,255,0.3)] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/40 shadow-[0_0_15px_rgba(0,240,255,0.3)]">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {isRTL ? 'استيراد وتصدير التطبيق' : 'App Import & Export'}
              </h3>
              <p className="text-[11px] text-cyan-400 font-mono">
                TAKI-GO Unified State & Code Manager
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2 bg-[#050918] border-b border-slate-800/80">
          <button
            onClick={() => setActiveTab('import')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'import'
                ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{isRTL ? 'استيراد البيانات' : 'Import Data'}</span>
          </button>

          <button
            onClick={() => setActiveTab('export')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'export'
                ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isRTL ? 'تصدير نسخة' : 'Export Backup'}</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'code'
                ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>{isRTL ? 'تنزيل الكود' : 'Source Code'}</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {activeTab === 'import' && (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300">
                <p>
                  {isRTL
                    ? 'قم بتحميل ملف نسخة احتياطية (.json) أو الصق محتوى بيانات الرحلات والمحفظة لاستعادتها فوراً في التطبيق.'
                    : 'Upload a backup JSON file or paste travel dossier data to restore trips, tickets, and user settings.'}
                </p>
              </div>

              {/* Upload Drop Area */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-cyan-500/40 hover:border-cyan-400 rounded-2xl p-6 text-center cursor-pointer bg-[#050b1e]/60 hover:bg-[#071129] transition-all group"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".json"
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="text-xs font-bold text-white">
                  {isRTL ? 'اضغط لاختيار ملف JSON من جهازك' : 'Click to select a JSON file'}
                </p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  takigo-backup.json
                </p>
              </div>

              {/* Paste JSON Area */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 block">
                  {isRTL ? 'أو الصق كود JSON مباشرة هنا:' : 'Or paste raw JSON string:'}
                </label>
                <textarea
                  value={jsonInput}
                  onChange={e => handleJsonChange(e.target.value)}
                  placeholder='{"activeTrip": { ... }, "walletDocuments": [ ... ]}'
                  rows={4}
                  className="w-full bg-[#050918] border border-slate-800 rounded-2xl p-3 text-xs font-mono text-cyan-300 placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Validation Feedback */}
              {validationResult && (
                <div
                  className={`p-3.5 rounded-2xl border text-xs space-y-1.5 ${
                    validationResult.valid
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                      : 'bg-rose-950/40 border-rose-500/40 text-rose-200'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold">
                    {validationResult.valid ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>{isRTL ? 'الملف سليم وقابل للاستيراد' : 'Valid Backup File'}</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-4 h-4 text-rose-400" />
                        <span>{isRTL ? 'خطأ في بنية الملف' : 'Invalid Backup Data'}</span>
                      </>
                    )}
                  </div>

                  {validationResult.summary && (
                    <div className="text-[11px] font-mono pt-1 text-slate-300 space-y-0.5">
                      {validationResult.summary.tripDestination && (
                        <p>📍 {validationResult.summary.tripDestination}</p>
                      )}
                      <p>📄 {validationResult.summary.documentsCount} documents included</p>
                      {validationResult.summary.userName && (
                        <p>👤 User: {validationResult.summary.userName}</p>
                      )}
                    </div>
                  )}

                  {validationResult.error && (
                    <p className="text-[11px] text-rose-300">{validationResult.error}</p>
                  )}
                </div>
              )}

              {/* Success Toast */}
              {importSuccess && (
                <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-400 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isRTL ? 'تم استيراد بيانات التطبيق بنجاح!' : 'App data imported successfully!'}</span>
                </div>
              )}

              {/* Action Button */}
              <button
                onClick={handleExecuteImport}
                disabled={!validationResult?.valid}
                className="w-full h-11 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_20px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-95 transition-all disabled:opacity-40"
              >
                {isRTL ? 'تطبيق واستعادة البيانات المستوردة' : 'Restore & Apply Imported Data'}
              </button>
            </div>
          )}

          {activeTab === 'export' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
                  <FolderArchive className="w-4 h-4" />
                  <span>{isRTL ? 'ملخص النسخة الاحتياطية الحالية:' : 'Current Backup Summary:'}</span>
                </div>

                <div className="text-xs space-y-1.5 text-slate-300 font-mono">
                  <p>• {isRTL ? 'الرحلة النشطة:' : 'Active Trip:'} {activeTrip.destinationCity}</p>
                  <p>• {isRTL ? 'وثائق وتذاكر المحفظة:' : 'Wallet Documents:'} {walletDocuments.length} {isRTL ? 'وثيقة' : 'items'}</p>
                  <p>• {isRTL ? 'المسافر:' : 'Traveler:'} {user.fullName}</p>
                  <p>• {isRTL ? 'الإصدار:' : 'Format:'} TAKI-GO v1.2.0 JSON</p>
                </div>
              </div>

              <button
                onClick={handleTriggerExport}
                className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>{isRTL ? 'تحميل ملف النسخة الاحتياطية (Download .json)' : 'Download Backup File (.json)'}</span>
              </button>
            </div>
          )}

          {activeTab === 'code' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 text-xs text-cyan-200 space-y-1">
                <p className="font-bold">
                  {isRTL ? 'كيفية تنزيل وتشغيل التطبيق في بيئتك المحلية:' : 'How to Run Locally:'}
                </p>
                <p className="text-[11px] text-slate-300">
                  {isRTL
                    ? 'يمكنك تنزيل الكود الكامل عبر زر "Download Code" أو "Export to GitHub" من القائمة العلوية لمنصة AI Studio، ثم تشغيله محلياً.'
                    : 'Download the source code via "Download Code" or "Export to GitHub" in the AI Studio top bar, then run locally.'}
                </p>
              </div>

              {/* Direct Zip Download Button */}
              <a
                href="/takigo-app.zip"
                download="takigo-app.zip"
                className="w-full h-12 rounded-2xl bg-gradient-to-r from-emerald-500 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_4px_25px_rgba(16,185,129,0.35)] hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>
                  {isRTL
                    ? 'تحميل كود المشروع بالكامل الآن (takigo-app.zip)'
                    : 'Download Full Project Code (takigo-app.zip)'}
                </span>
              </a>

              {/* Code Snippet */}
              <div className="relative rounded-2xl bg-[#030712] border border-slate-800 p-3.5 font-mono text-[11px] text-cyan-300 space-y-1">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Terminal Commands</span>
                  </div>
                  <button
                    onClick={handleCopyCli}
                    className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 text-[10px]"
                  >
                    {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="whitespace-pre-wrap leading-relaxed">{cliSnippet}</pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
