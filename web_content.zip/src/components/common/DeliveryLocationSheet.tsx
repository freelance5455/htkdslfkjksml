import React, { useState, useEffect, useRef } from 'react';
import {
  X, MapPin, Check, Navigation, Loader2, AlertCircle, Search, CornerDownLeft
} from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useAuth } from '../../context/AuthContext';
import {
  getCurrentLiveLocation,
  resolveExactLocation,
  searchLocationsNominatim,
  GeocodedAddress,
  SearchLocationResult,
} from '../../utils/locationService';

interface DeliveryLocationSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currentPincode?: string;
  currentCity?: string;
  onSelectLocation: (pincode: string, city: string, fullAddress?: string) => void;
}

// Custom Ola-inspired Omazify delivery pin marker
const createDeliveryPinIcon = () => {
  return L.divIcon({
    className: 'custom-delivery-pin',
    html: `
      <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 44px; height: 44px; cursor: grab;">
        <!-- Pulsing radar wave ring -->
        <div style="position: absolute; width: 40px; height: 40px; background: rgba(255, 212, 0, 0.4); border-radius: 50%; animation: ping 1.8s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
        <!-- Shadow beneath pin -->
        <div style="position: absolute; bottom: 0; width: 14px; height: 6px; background: rgba(0,0,0,0.35); border-radius: 50%; filter: blur(1.5px);"></div>
        <!-- Pin teardrop body -->
        <div style="position: relative; width: 32px; height: 32px; background: #000000; border: 3px solid #FFD400; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 14px rgba(0,0,0,0.45); top: -6px;">
          <!-- Central glowing yellow dot -->
          <div style="width: 10px; height: 10px; background: #FFD400; border-radius: 50%; transform: rotate(45deg); box-shadow: 0 0 6px #FFD400;"></div>
        </div>
      </div>
    `,
    iconSize: [44, 44],
    iconAnchor: [22, 38],
    popupAnchor: [0, -38],
  });
};

export const DeliveryLocationSheet: React.FC<DeliveryLocationSheetProps> = ({
  isOpen,
  onClose,
  currentCity,
  onSelectLocation,
}) => {
  const { addresses } = useAuth();

  // Map DOM reference and Leaflet instances
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);

  // Search States
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchLocationResult[]>([]);
  const [searchMessage, setSearchMessage] = useState<{ type: 'error' | 'info'; text: string } | null>(null);
  const [isSearchDropdownOpen, setIsSearchDropdownOpen] = useState(false);

  // Selected Location States
  const [selectedCoords, setSelectedCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [geocodedAddress, setGeocodedAddress] = useState<GeocodedAddress | null>(null);
  const [isGeocoding, setIsGeocoding] = useState(false);

  // Geolocation & Error states
  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // Initialize and tear down Leaflet Map when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }
      setSelectedCoords(null);
      setGeocodedAddress(null);
      setGpsError(null);
      setSearchQuery('');
      setSearchResults([]);
      setSearchMessage(null);
      setIsSearchDropdownOpen(false);
      return;
    }

    // Modal is open - allow slight tick for DOM container to lay out
    const initTimer = setTimeout(() => {
      if (!mapContainerRef.current) return;

      // Clean up previous instance if any
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }

      // Default initial view: Pan-India center overview without hardcoded selection
      const defaultCenter: [number, number] = [20.5937, 78.9629];
      const defaultZoom = 5;

      const map = L.map(mapContainerRef.current, {
        center: defaultCenter,
        zoom: defaultZoom,
        zoomControl: true,
        attributionControl: true,
      });

      // Configure Leaflet Attribution according to Requirement 7:
      // "Leaflet | © Omazify Map | © OpenStreetMap contributors"
      // with Omazify Map linking to https://omazify.com/ and OpenStreetMap contributors linking to https://www.openstreetmap.org/copyright
      // both opening in a new tab with rel='noopener noreferrer'
      if (map.attributionControl) {
        map.attributionControl.setPrefix(
          '<a href="https://leafletjs.com" target="_blank" rel="noopener noreferrer">Leaflet</a>'
        );
      }

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution:
          '&copy; <a href="https://omazify.com/" target="_blank" rel="noopener noreferrer">Omazify Map</a> | &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',
      }).addTo(map);

      // Handle user tapping/clicking anywhere on the map
      map.on('click', (e: L.LeafletMouseEvent) => {
        handlePointSelected(e.latlng.lat, e.latlng.lng, map);
      });

      mapInstanceRef.current = map;

      // Invalidate size in multiple intervals to ensure responsive tile rendering across Android and desktop
      setTimeout(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize();
        }
      }, 100);

      setTimeout(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize();
        }
      }, 300);

      setTimeout(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize();
        }
      }, 600);
    }, 60);

    const handleResize = () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      clearTimeout(initTimer);
      window.removeEventListener('resize', handleResize);
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        markerRef.current = null;
      }
    };
  }, [isOpen]);

  // Request sequence counter to prevent race conditions
  const lookupIdRef = useRef(0);

  // Handle coordinates selection either from tap, GPS, or search result
  const handlePointSelected = async (
    lat: number,
    lng: number,
    mapOverride?: L.Map,
    knownDetails?: {
      displayName?: string;
      shortLabel?: string;
      city?: string;
      pincode?: string;
    }
  ) => {
    setGpsError(null);
    setSelectedCoords({ lat, lng });

    // Immediately clear stale location-dependent values while new lookup is pending
    setGeocodedAddress(null);
    setIsGeocoding(true);

    const currentLookupId = ++lookupIdRef.current;

    const map = mapOverride || mapInstanceRef.current;
    if (map) {
      if (markerRef.current) {
        markerRef.current.setLatLng([lat, lng]);
      } else {
        const marker = L.marker([lat, lng], {
          icon: createDeliveryPinIcon(),
          draggable: true,
        }).addTo(map);

        marker.on('dragend', () => {
          const newPos = marker.getLatLng();
          handlePointSelected(newPos.lat, newPos.lng);
        });

        markerRef.current = marker;
      }

      map.panTo([lat, lng], { animate: true });
    }

    try {
      const geo = await resolveExactLocation(lat, lng);
      // Only commit if this is still the newest lookup
      if (lookupIdRef.current === currentLookupId) {
        setGeocodedAddress(geo);
      }
    } catch {
      if (lookupIdRef.current === currentLookupId) {
        setGeocodedAddress({
          latitude: lat,
          longitude: lng,
          displayName: knownDetails?.displayName || `Selected Point (${lat.toFixed(5)}, ${lng.toFixed(5)})`,
          shortLabel: knownDetails?.shortLabel || `Pinned Point (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
          street: knownDetails?.shortLabel || `Location (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
          city: knownDetails?.city || 'Selected Location',
          state: '',
          pincode: '',
          fullAddress: knownDetails?.displayName || `Coordinates: ${lat.toFixed(5)}, ${lng.toFixed(5)}`,
          isPinVerified: false,
          pinVerificationMessage: 'PIN code could not be verified for this location.',
        });
      }
    } finally {
      if (lookupIdRef.current === currentLookupId) {
        setIsGeocoding(false);
      }
    }
  };

  // Handle Search using Nominatim search API
  const handleSearchSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const query = searchQuery.trim();
    if (!query) {
      setSearchMessage({
        type: 'error',
        text: 'Please enter a city, locality, street, or landmark to search.',
      });
      setSearchResults([]);
      setIsSearchDropdownOpen(false);
      return;
    }

    setIsSearching(true);
    setSearchMessage(null);
    setSearchResults([]);
    setIsSearchDropdownOpen(true);

    try {
      const results = await searchLocationsNominatim(query);
      if (results.length === 0) {
        setSearchMessage({
          type: 'info',
          text: `No locations found matching "${query}". Try searching by city name, major locality, or tap directly on the map.`,
        });
        setSearchResults([]);
      } else {
        setSearchResults(results);
        setSearchMessage(null);
      }
    } catch (err: any) {
      setSearchMessage({
        type: 'error',
        text: err.message || 'Location search service is temporarily unavailable. Please tap directly on the map or use GPS.',
      });
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  // Handle selecting a place result from search
  const handleSelectSearchResult = (result: SearchLocationResult) => {
    setIsSearchDropdownOpen(false);
    setSearchQuery(result.primaryName);
    setSearchMessage(null);

    const map = mapInstanceRef.current;
    if (map) {
      map.setView([result.latitude, result.longitude], 16, { animate: true });
    }

    handlePointSelected(result.latitude, result.longitude, map || undefined, {
      displayName: result.displayName,
      shortLabel: result.primaryName,
      city: result.city,
      pincode: result.pincode,
    });
  };

  // Handle browser Geolocation API
  const handleUseCurrentLocation = async () => {
    setIsDetectingGps(true);
    setGpsError(null);
    setSearchMessage(null);
    setIsSearchDropdownOpen(false);

    try {
      const liveData = await getCurrentLiveLocation();
      const map = mapInstanceRef.current;
      if (map) {
        map.setView([liveData.latitude, liveData.longitude], 17, { animate: true });
      }
      await handlePointSelected(liveData.latitude, liveData.longitude, map || undefined, {
        displayName: liveData.displayName,
        shortLabel: liveData.shortLabel,
        city: liveData.city,
        pincode: liveData.pincode,
      });
    } catch (err: any) {
      setGpsError(
        err.message ||
          'Unable to detect live location. Please check your browser location permission or tap directly on the map.'
      );
    } finally {
      setIsDetectingGps(false);
    }
  };

  // Confirm selected location and close
  const handleConfirmLocation = () => {
    if (!selectedCoords) return;

    const chosenCity = geocodedAddress?.shortLabel || geocodedAddress?.city || 'Selected Location';
    const chosenPin = geocodedAddress?.isPinVerified ? (geocodedAddress.pincode || '') : '';
    const fullAddr =
      geocodedAddress?.displayName ||
      `Lat: ${selectedCoords.lat.toFixed(5)}, Lng: ${selectedCoords.lng.toFixed(5)}`;

    onSelectLocation(chosenPin, chosenCity, fullAddr);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200 p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="delivery-sheet-title"
    >
      <div className="w-full max-w-xl bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh] sm:max-h-[90vh] animate-in slide-in-from-bottom duration-300 border border-[#EAEAEA]">
        {/* Header - Omazify Branding */}
        <div className="px-5 py-3.5 border-b border-[#EAEAEA] flex items-center justify-between bg-white flex-shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-[#FFD400] text-[#000000] flex items-center justify-center flex-shrink-0 font-black shadow-xs text-xs">
              OM
            </div>
            <div className="truncate">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-extrabold tracking-wider text-[#111111] uppercase px-1.5 py-0.5 rounded bg-[#FFF9DB] border border-[#FFD400]/40">
                  OMAZIFY MAPS
                </span>
              </div>
              <h3 id="delivery-sheet-title" className="text-sm sm:text-base font-black text-[#111111] truncate leading-tight mt-0.5">
                Set Delivery Location
              </h3>
            </div>
          </div>
          <button
            id="delivery-sheet-close-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-[#111111] flex items-center justify-center cursor-pointer transition-colors flex-shrink-0"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Container */}
        <div className="overflow-y-auto flex-1 flex flex-col">
          {/* Ola-style Top Location Search Bar */}
          <div className="p-3.5 sm:p-4 bg-[#FAFAFA] border-b border-[#EAEAEA] relative z-20">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center gap-2">
              <div className="relative flex-1 flex items-center">
                <Search className="w-4 h-4 text-[#888888] absolute left-3.5 pointer-events-none" />
                <input
                  id="location-search-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    if (searchMessage) setSearchMessage(null);
                  }}
                  placeholder="Search city, locality, landmark, or street..."
                  className="w-full pl-9 pr-9 py-2.5 bg-white border border-[#D5D5D5] focus:border-[#000000] rounded-xl text-xs sm:text-sm text-[#111111] placeholder:text-[#888888] outline-none shadow-xs transition-all font-medium"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setSearchResults([]);
                      setSearchMessage(null);
                      setIsSearchDropdownOpen(false);
                    }}
                    className="absolute right-3 p-0.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100"
                    aria-label="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Search Button */}
              <button
                id="location-search-btn"
                type="submit"
                disabled={isSearching}
                className="px-4 py-2.5 bg-[#FFD400] hover:bg-[#FFC800] active:scale-[0.98] text-[#000000] font-black text-xs sm:text-sm rounded-xl transition-all cursor-pointer shadow-xs flex items-center gap-1.5 flex-shrink-0 disabled:opacity-60"
              >
                {isSearching ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-[#000000]" />
                    <span className="hidden sm:inline">Searching...</span>
                  </>
                ) : (
                  <>
                    <span className="hidden sm:inline">Search</span>
                    <CornerDownLeft className="w-3.5 h-3.5 sm:hidden text-[#000000]" />
                  </>
                )}
              </button>
            </form>

            {/* Search Feedback Message */}
            {searchMessage && (
              <div
                className={`mt-2 p-2.5 rounded-xl text-xs flex items-start gap-2 animate-in fade-in ${
                  searchMessage.type === 'error'
                    ? 'bg-red-50 text-red-700 border border-red-200'
                    : 'bg-amber-50 text-amber-800 border border-amber-200'
                }`}
              >
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span className="font-medium leading-relaxed">{searchMessage.text}</span>
              </div>
            )}

            {/* Ola-style Search Results Overlay Dropdown */}
            {isSearchDropdownOpen && searchResults.length > 0 && (
              <div
                id="search-results-list"
                className="absolute top-full left-3.5 right-3.5 sm:left-4 sm:right-4 mt-1 bg-white border border-[#000000] rounded-2xl shadow-xl max-h-56 overflow-y-auto divide-y divide-[#EAEAEA] z-30 animate-in fade-in slide-in-from-top-1 duration-150"
              >
                <div className="px-3 py-1.5 bg-[#FFF9DB] text-[11px] font-bold text-[#111111] flex items-center justify-between border-b border-[#FFD400]/40">
                  <span>OpenStreetMap Search Results ({searchResults.length})</span>
                  <span className="text-[10px] text-[#666666]">Tap to select</span>
                </div>
                {searchResults.map((item) => (
                  <button
                    key={item.placeId}
                    type="button"
                    onClick={() => handleSelectSearchResult(item)}
                    className="w-full p-3 text-left hover:bg-[#FFF9DB]/40 active:bg-[#FFF9DB] transition-colors flex items-start gap-3 cursor-pointer group"
                  >
                    <div className="w-7 h-7 rounded-full bg-neutral-100 group-hover:bg-[#FFD400] text-[#111111] flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors">
                      <MapPin className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-bold text-[#111111] truncate group-hover:text-black">
                        {item.primaryName}
                      </p>
                      <p className="text-[11px] text-[#666666] line-clamp-1 mt-0.5">
                        {item.secondaryName}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Interactive Map Area (Main Focus of Modal) */}
          <div className="relative w-full h-72 sm:h-80 md:h-96 bg-neutral-100 flex-shrink-0 overflow-hidden">
            <div
              ref={mapContainerRef}
              className="w-full h-full z-0 cursor-crosshair"
              style={{ minHeight: '280px' }}
            />

            {/* Ola-style floating map hint pill */}
            <div className="absolute top-3 left-3 z-10 pointer-events-none bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-full border border-black/10 shadow-md flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#FFD400] animate-pulse" />
              <span className="text-[11px] font-bold text-[#111111]">
                {selectedCoords ? 'Tap anywhere or drag pin to adjust' : 'Tap anywhere to drop delivery pin'}
              </span>
            </div>
          </div>

          {/* Prominent Yellow 'Use My Current Location' Button directly below map */}
          <div className="p-3.5 sm:p-4 bg-white border-b border-[#EAEAEA]">
            <button
              id="use-current-location-btn"
              type="button"
              disabled={isDetectingGps}
              onClick={handleUseCurrentLocation}
              className="w-full py-3 sm:py-3.5 px-4 rounded-xl bg-[#FFD400] hover:bg-[#FFC800] active:scale-[0.99] text-[#000000] font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm disabled:opacity-60"
            >
              {isDetectingGps ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-[#000000]" />
                  <span>Detecting GPS Location via Browser...</span>
                </>
              ) : (
                <>
                  <Navigation className="w-4 h-4 text-[#000000] fill-current" />
                  <span>Use My Current Location</span>
                </>
              )}
            </button>

            {/* GPS Error Message Display */}
            {gpsError && (
              <div className="mt-2.5 p-3 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-xs font-semibold flex items-start gap-2 animate-in fade-in">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-amber-600 mt-0.5" />
                <div className="flex-1">{gpsError}</div>
              </div>
            )}
          </div>

          {/* Ola Ride-Hailing Bottom Location-Details Panel */}
          <div className="p-3.5 sm:p-4 bg-white space-y-3 flex-1">
            {selectedCoords ? (
              <div
                id="selected-location-panel"
                className="p-4 rounded-2xl bg-[#FAFAFA] border-2 border-[#000000] space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-200 shadow-xs"
              >
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#000000] text-[#FFD400] flex items-center justify-center flex-shrink-0 shadow-xs">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[#FFD400] text-[#000000]">
                        Delivery Point Set
                      </span>
                      {isGeocoding && (
                        <span className="text-[10px] text-[#666666] font-semibold flex items-center gap-1">
                          <Loader2 className="w-3 h-3 animate-spin text-neutral-500" /> Resolving address...
                        </span>
                      )}
                    </div>

                    <h4 className="text-sm sm:text-base font-black text-[#111111] mt-1 break-words leading-tight">
                      {geocodedAddress?.shortLabel || geocodedAddress?.city || 'Pinned Map Location'}
                    </h4>

                    <p className="text-xs text-[#555555] font-medium mt-1 break-words line-clamp-2 leading-relaxed">
                      {geocodedAddress?.displayName || `Coordinates: ${selectedCoords.lat.toFixed(5)}, ${selectedCoords.lng.toFixed(5)}`}
                    </p>

                    <div className="mt-1.5 flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] text-[#666666] font-mono bg-white px-2 py-0.5 rounded border border-[#EAEAEA]">
                        GPS: {selectedCoords.lat.toFixed(5)}° N, {selectedCoords.lng.toFixed(5)}° E
                      </span>
                      {geocodedAddress?.isPinVerified && geocodedAddress?.pincode ? (
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-600" />
                          PIN: {geocodedAddress.pincode} (India Post Verified)
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 text-amber-600" />
                          PIN code could not be verified for this location
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Confirm Delivery Location Button */}
                <button
                  id="confirm-delivery-location-btn"
                  type="button"
                  onClick={handleConfirmLocation}
                  className="w-full py-3 sm:py-3.5 px-4 rounded-xl bg-[#000000] hover:bg-neutral-800 active:scale-[0.99] text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
                >
                  <Check className="w-4 h-4 text-[#FFD400]" />
                  <span>Confirm Delivery Location</span>
                </button>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-neutral-50 border border-[#EAEAEA] text-center space-y-1">
                <p className="text-xs font-bold text-[#111111]">
                  No delivery point chosen yet
                </p>
                <p className="text-[11px] text-[#666666]">
                  Tap anywhere on the interactive map, search your locality above, or tap &apos;Use My Current Location&apos;.
                </p>
              </div>
            )}

            {/* Optional Saved Addresses from User Profile */}
            {addresses.length > 0 && !selectedCoords && (
              <div className="pt-2 border-t border-[#EAEAEA] space-y-2">
                <p className="text-[11px] font-black text-[#666666] uppercase tracking-wider">
                  Or pick from saved addresses
                </p>
                <div className="space-y-1.5 max-h-32 overflow-y-auto">
                  {addresses.map((addr) => (
                    <div
                      key={addr.id}
                      onClick={() => {
                        onSelectLocation(
                          addr.pincode || '',
                          addr.city || addr.street,
                          `${addr.street}, ${addr.city}`
                        );
                        onClose();
                      }}
                      className="p-2.5 rounded-xl border border-[#EAEAEA] hover:border-[#000000] hover:bg-[#FAFAFA] text-left cursor-pointer transition-all flex items-center justify-between"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="text-xs font-bold text-[#111111] truncate">
                          {addr.fullName}{' '}
                          <span className="text-[10px] font-normal text-[#666666]">
                            ({addr.type})
                          </span>
                        </p>
                        <p className="text-[11px] text-[#666666] truncate">
                          {addr.street}, {addr.city}
                        </p>
                      </div>
                      {currentCity === addr.city && (
                        <Check className="w-3.5 h-3.5 text-[#000000] flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
