import React, { useState } from 'react';

interface StarRatingProps {
  rating: number; // 0 to 5, supports 0.5, 1, 1.5, ... 5
  maxRating?: number;
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  showNumber?: boolean;
}

export const StarRating: React.FC<StarRatingProps> = ({
  rating,
  maxRating = 5,
  interactive = false,
  onRatingChange,
  size = 'sm',
  showNumber = false,
}) => {
  const [hoverRating, setHoverRating] = useState<number | null>(null);

  const sizeDimensions = {
    xs: { px: 11, text: 'text-[9.5px]' },
    sm: { px: 13, text: 'text-[11px]' },
    md: { px: 15, text: 'text-xs' },
    lg: { px: 18, text: 'text-sm' },
  };

  const currentVal = hoverRating !== null ? hoverRating : rating;
  const roundedRating = Math.round(currentVal * 2) / 2;

  const starPath =
    'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z';

  return (
    <div
      className="inline-flex items-center gap-1 select-none"
      onMouseLeave={() => interactive && setHoverRating(null)}
    >
      <div className="flex items-center gap-0.5">
        {Array.from({ length: maxRating }).map((_, i) => {
          const starVal = i + 1;
          const isFull = roundedRating >= starVal;
          const isHalf = !isFull && roundedRating >= starVal - 0.5;

          const dim = sizeDimensions[size].px;

          return (
            <div
              key={i}
              className="relative inline-flex items-center justify-center"
              style={{ width: dim, height: dim }}
            >
              {interactive && onRatingChange && (
                <>
                  {/* Left half clickable */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRatingChange(roundedRating === starVal - 0.5 ? 0 : starVal - 0.5);
                    }}
                    onMouseEnter={() => setHoverRating(starVal - 0.5)}
                    className="absolute left-0 top-0 bottom-0 w-1/2 z-20 cursor-pointer focus:outline-none"
                    aria-label={`${starVal - 0.5} estrellas`}
                  />
                  {/* Right half clickable */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRatingChange(roundedRating === starVal ? 0 : starVal);
                    }}
                    onMouseEnter={() => setHoverRating(starVal)}
                    className="absolute right-0 top-0 bottom-0 w-1/2 z-20 cursor-pointer focus:outline-none"
                    aria-label={`${starVal} estrellas`}
                  />
                </>
              )}

              {/* Background empty star */}
              <svg
                viewBox="0 0 24 24"
                width={dim}
                height={dim}
                className="text-white/20 transition-colors"
                fill="currentColor"
              >
                <path d={starPath} />
              </svg>

              {/* Half Star */}
              {isHalf && (
                <div
                  className="absolute inset-0 overflow-hidden pointer-events-none"
                  style={{ width: '50%' }}
                >
                  <svg
                    viewBox="0 0 24 24"
                    width={dim}
                    height={dim}
                    className="text-white"
                    fill="currentColor"
                  >
                    <path d={starPath} />
                  </svg>
                </div>
              )}

              {/* Full Star */}
              {isFull && (
                <svg
                  viewBox="0 0 24 24"
                  width={dim}
                  height={dim}
                  className="absolute inset-0 text-white pointer-events-none"
                  fill="currentColor"
                >
                  <path d={starPath} />
                </svg>
              )}
            </div>
          );
        })}
      </div>

      {showNumber && roundedRating > 0 && (
        <span
          className={`font-mono font-medium text-zinc-300 ml-0.5 tabular-nums ${sizeDimensions[size].text}`}
        >
          {roundedRating.toFixed(1)}
        </span>
      )}
    </div>
  );
};
