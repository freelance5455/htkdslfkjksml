import React from 'react';

interface SilverBullionVisualProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showDetails?: boolean;
}

export const SilverBullionVisual: React.FC<SilverBullionVisualProps> = ({ 
  className = '', 
  size = 'md',
  showDetails = true 
}) => {
  const sizeMap = {
    sm: 'w-16 h-14',
    md: 'w-32 h-24 sm:w-36 sm:h-28',
    lg: 'w-48 h-36 sm:w-60 sm:h-44'
  };

  return (
    <div className={`relative flex items-center justify-center select-none ${sizeMap[size]} ${className}`}>
      {/* Ambient Silver & Cyan Glow Aura */}
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-600/30 via-slate-300/25 to-blue-500/10 rounded-full blur-xl pointer-events-none transform scale-110 animate-pulse" />

      {/* Photorealistic 3D Pure 999 Silver Ingot Vector */}
      <svg 
        viewBox="0 0 320 240" 
        className="w-full h-full drop-shadow-[0_12px_24px_rgba(6,182,212,0.3)] transform transition-transform duration-300 hover:scale-105"
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Main Silver Face Linear Gradient */}
          <linearGradient id="silverTopFace" x1="40" y1="60" x2="280" y2="150" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="20%" stopColor="#E2E8F0" />
            <stop offset="50%" stopColor="#94A3B8" />
            <stop offset="75%" stopColor="#CBD5E1" />
            <stop offset="90%" stopColor="#64748B" />
            <stop offset="100%" stopColor="#475569" />
          </linearGradient>

          {/* Front Bevel Gradient */}
          <linearGradient id="silverFrontFace" x1="40" y1="140" x2="280" y2="200" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#64748B" />
            <stop offset="35%" stopColor="#475569" />
            <stop offset="70%" stopColor="#334155" />
            <stop offset="100%" stopColor="#1E293B" />
          </linearGradient>

          {/* Left Bevel Gradient */}
          <linearGradient id="silverLeftBevel" x1="20" y1="80" x2="60" y2="180" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#F8FAFC" />
            <stop offset="50%" stopColor="#94A3B8" />
            <stop offset="100%" stopColor="#475569" />
          </linearGradient>

          {/* Right Bevel Gradient */}
          <linearGradient id="silverRightBevel" x1="260" y1="80" x2="300" y2="180" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#CBD5E1" />
            <stop offset="50%" stopColor="#64748B" />
            <stop offset="100%" stopColor="#1E293B" />
          </linearGradient>

          {/* Specular Sheen Stripe */}
          <linearGradient id="silverSpecular" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.9" />
            <stop offset="40%" stopColor="#F1F5F9" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#E2E8F0" stopOpacity="0" />
          </linearGradient>

          {/* Silver Coin Radial Gradient */}
          <radialGradient id="silverCoinGrad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="40%" stopColor="#E2E8F0" />
            <stop offset="75%" stopColor="#94A3B8" />
            <stop offset="100%" stopColor="#475569" />
          </radialGradient>
        </defs>

        {/* Ingot Shadow Base */}
        <ellipse cx="160" cy="205" rx="130" ry="22" fill="#020617" fillOpacity="0.75" filter="blur(8px)" />

        {/* Pure Silver Stack Ingot (Back Layer) */}
        <g opacity="0.85" transform="translate(14, -18) scale(0.92)">
          <path d="M 60 70 L 260 70 L 290 140 L 30 140 Z" fill="url(#silverTopFace)" />
          <path d="M 30 140 L 290 140 L 275 175 L 45 175 Z" fill="url(#silverFrontFace)" />
          <path d="M 60 70 L 30 140 L 45 175 L 75 105 Z" fill="url(#silverLeftBevel)" />
          <path d="M 260 70 L 290 140 L 275 175 L 245 105 Z" fill="url(#silverRightBevel)" />
        </g>

        {/* Main Foreground Ingot Top Face */}
        <path 
          d="M 68 76 L 252 76 L 284 150 L 36 150 Z" 
          fill="url(#silverTopFace)" 
          stroke="#F8FAFC" 
          strokeWidth="0.75"
        />

        {/* Front Lip / Face */}
        <path 
          d="M 36 150 L 284 150 L 268 188 L 52 188 Z" 
          fill="url(#silverFrontFace)" 
          stroke="#64748B" 
          strokeWidth="0.5"
        />

        {/* Left Side Face */}
        <path 
          d="M 68 76 L 36 150 L 52 188 L 82 110 Z" 
          fill="url(#silverLeftBevel)" 
        />

        {/* Right Side Face */}
        <path 
          d="M 252 76 L 284 150 L 268 188 L 238 110 Z" 
          fill="url(#silverRightBevel)" 
        />

        {/* Metallic Specular Highlight Line */}
        <polygon 
          points="80,82 120,82 72,144 48,144" 
          fill="url(#silverSpecular)" 
          opacity="0.7"
        />

        {/* 999 Fine Silver Hallmarked Stamp on Top Face */}
        {showDetails && (
          <g transform="translate(160, 112) rotate(-1)">
            {/* Stamp Border */}
            <rect 
              x="-68" 
              y="-22" 
              width="136" 
              height="44" 
              rx="4" 
              fill="none" 
              stroke="#334155" 
              strokeWidth="1.2" 
              strokeDasharray="4 2"
              opacity="0.8"
            />
            {/* Fine Silver Inscription */}
            <text 
              x="0" 
              y="-6" 
              fill="#1E293B" 
              fontSize="11" 
              fontWeight="900" 
              fontFamily="monospace" 
              letterSpacing="2" 
              textAnchor="middle"
              opacity="0.9"
            >
              FINE SILVER
            </text>
            <text 
              x="0" 
              y="11" 
              fill="#0F172A" 
              fontSize="16" 
              fontWeight="900" 
              fontFamily="sans-serif" 
              letterSpacing="2.5" 
              textAnchor="middle"
            >
              999.0
            </text>
            <text 
              x="0" 
              y="20" 
              fill="#334155" 
              fontSize="7" 
              fontWeight="800" 
              fontFamily="monospace" 
              letterSpacing="1" 
              textAnchor="middle"
              opacity="0.8"
            >
              PURE • 1000g • CERTIFIED
            </text>
          </g>
        )}

        {/* Gleaming Silver Mint Coins in Foreground */}
        {/* Coin 1 (Left) */}
        <g transform="translate(48, 168)">
          <ellipse cx="0" cy="0" rx="26" ry="14" fill="#334155" />
          <ellipse cx="0" cy="-3" rx="26" ry="14" fill="url(#silverCoinGrad)" stroke="#F8FAFC" strokeWidth="0.75" />
          <ellipse cx="0" cy="-3" rx="20" ry="10" fill="none" stroke="#475569" strokeWidth="0.75" strokeDasharray="2 1" />
          <text x="0" y="1" fill="#1E293B" fontSize="8" fontWeight="900" textAnchor="middle">₹ 999</text>
        </g>

        {/* Coin 2 (Right) */}
        <g transform="translate(268, 172)">
          <ellipse cx="0" cy="0" rx="22" ry="12" fill="#334155" />
          <ellipse cx="0" cy="-2.5" rx="22" ry="12" fill="url(#silverCoinGrad)" stroke="#F8FAFC" strokeWidth="0.75" />
          <ellipse cx="0" cy="-2.5" rx="16" ry="8" fill="none" stroke="#475569" strokeWidth="0.5" />
          <text x="0" y="1" fill="#1E293B" fontSize="7" fontWeight="900" textAnchor="middle">SILVER</text>
        </g>

        {/* Star Sparkle Accents */}
        <g transform="translate(80, 72)">
          <path d="M 0,-8 L 2,-2 L 8,0 L 2,2 L 0,8 L -2,2 L -8,0 L -2,-2 Z" fill="#FFFFFF" />
          <circle cx="0" cy="0" r="1.5" fill="#E2E8F0" />
        </g>
        <g transform="translate(245, 95) scale(0.7)">
          <path d="M 0,-8 L 2,-2 L 8,0 L 2,2 L 0,8 L -2,2 L -8,0 L -2,-2 Z" fill="#FFFFFF" />
        </g>
      </svg>
    </div>
  );
};
