import React from 'react';
import * as Icons from 'lucide-react';

interface CategoryIconProps {
  name: string;
  className?: string;
  color?: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, className = 'w-5 h-5', color }) => {
  // @ts-expect-error dynamic lucide icon lookup
  const IconComponent = Icons[name] || Icons.CircleDollarSign;

  return <IconComponent className={className} style={color ? { color } : undefined} />;
};
