import React, { useEffect, useState } from 'react';
import { Wifi, WifiOff, RefreshCw, CheckCircle2, AlertCircle, Clock, ChevronDown, X, ShieldCheck, Cpu } from 'lucide-react';
import {
  subscribeOfflineQueue,
  getOfflineQueue,
  processOfflineQueue,
  removeOfflineAction,
} from '../../utils/offlineQueue.ts';
import {
  requestServiceWorkerSync,
  subscribeServiceWorkerSync,
  ServiceWorkerSyncEvent,
} from '../../utils/serviceWorkerSync.ts';
import { OfflineAction } from '../../types/index.ts';

export const OfflineBadge: React.FC = () => {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [queue, setQueue] = useState<OfflineAction[]>([]);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [showQueueDetails, setShowQueueDetails] = useState<boolean>(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  useEffect(() => {
    const handleOnline = async () => {
      setIsOnline(true);
      // Auto-trigger Service Worker sync when connectivity returns
      await runSync();
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const unsubQueue = subscribeOfflineQueue((newQueue) => {
      setQueue(newQueue);
    });

    const unsubSw = subscribeServiceWorkerSync((event: ServiceWorkerSyncEvent) => {
      if (event.type === 'started') {
        setIsSyncing(true);
      } else if (event.type === 'completed') {
        setIsSyncing(false);
        const parts: string[] = [];
        if (event.attendanceCount) parts.push(`${event.attendanceCount} attendance`);
        if (event.taskCount) parts.push(`${event.taskCount} task update${event.taskCount > 1 ? 's' : ''}`);
        const detail = parts.length > 0 ? ` (${parts.join(', ')})` : '';
        setSyncFeedback(`Uploaded ${event.syncedCount || 'records'}${detail} successfully!`);
        setTimeout(() => setSyncFeedback(null), 5000);
      } else if (event.type === 'failed') {
        setIsSyncing(false);
        setSyncFeedback('Sync failed. Will retry automatically.');
        setTimeout(() => setSyncFeedback(null), 4000);
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubQueue();
      unsubSw();
    };
  }, []);

  const runSync = async () => {
    if (!navigator.onLine) return;
    setIsSyncing(true);
    setSyncFeedback('Service Worker uploading...');
    try {
      await requestServiceWorkerSync();
    } catch (e: any) {
      console.error('Offline sync failed:', e);
      setSyncFeedback('Sync failed. Will retry automatically.');
      setIsSyncing(false);
    }
  };

  const pendingCount = queue.filter((i) => i.status === 'pending' || i.status === 'failed' || i.status === 'syncing').length;
  const failedCount = queue.filter((i) => i.status === 'failed').length;
  const attendanceCount = queue.filter((i) => (i.type === 'check_in' || i.type === 'check_out') && i.status !== 'synced').length;
  const taskCount = queue.filter((i) => i.type === 'update_task' && i.status !== 'synced').length;

  return (
    <div className="relative">
      {isOnline && pendingCount === 0 ? (
        <div className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 rounded-full border border-emerald-200">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="hidden sm:inline">SW Synced</span>
        </div>
      ) : (
        <div className="flex items-center gap-2 px-2.5 py-1 text-xs font-medium rounded-full border bg-amber-50 text-amber-900 border-amber-300 shadow-xs">
          {!isOnline ? (
            <div className="flex items-center gap-1 text-amber-700 font-bold">
              <WifiOff className="w-3.5 h-3.5" />
              <span>Offline</span>
            </div>
          ) : (
            <div className="flex items-center gap-1 text-amber-700 font-bold">
              <Wifi className="w-3.5 h-3.5" />
              <span>Online</span>
            </div>
          )}

          {pendingCount > 0 && (
            <button
              onClick={() => setShowQueueDetails(!showQueueDetails)}
              className="bg-amber-200 hover:bg-amber-300 text-amber-950 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 transition-colors"
              title="Click to view pending items"
            >
              <span>{pendingCount} Pending Sync</span>
              <ChevronDown className="w-3 h-3" />
            </button>
          )}

          {isOnline && pendingCount > 0 && (
            <button
              onClick={runSync}
              disabled={isSyncing}
              className="flex items-center gap-1 bg-amber-600 hover:bg-amber-700 text-white font-bold px-2 py-0.5 rounded-full transition-colors active:scale-95 disabled:opacity-50"
              title="Trigger Service Worker upload"
            >
              <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Uploading...' : failedCount > 0 ? 'Retry Upload' : 'Upload Now'}</span>
            </button>
          )}

          {syncFeedback && (
            <span className="text-[11px] font-bold text-slate-700 hidden md:inline animate-fade-in bg-white px-2 py-0.5 rounded-md border border-slate-200">
              {syncFeedback}
            </span>
          )}
        </div>
      )}

      {/* Queue Details Dropdown */}
      {showQueueDetails && queue.length > 0 && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 p-3 z-50 animate-in fade-in-0 slide-in-from-top-1 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Clock className="w-4 h-4 text-amber-500" />
              <span>Service Worker Offline Queue ({queue.length})</span>
            </div>
            <button
              onClick={() => setShowQueueDetails(false)}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2 mb-2 p-1.5 bg-slate-50 rounded-lg text-[11px] text-slate-600">
            <Cpu className="w-3.5 h-3.5 text-sky-600 shrink-0" />
            <span>
              Background Sync will automatically upload {attendanceCount > 0 ? `${attendanceCount} attendance` : ''}
              {attendanceCount > 0 && taskCount > 0 ? ' and ' : ''}
              {taskCount > 0 ? `${taskCount} task updates` : ''} once connectivity returns.
            </span>
          </div>

          <div className="max-h-60 overflow-y-auto space-y-1.5">
            {queue.map((item) => (
              <div
                key={item.id}
                className={`p-2 rounded-xl border flex items-start justify-between gap-2 ${
                  item.status === 'failed'
                    ? 'bg-red-50 border-red-200'
                    : item.status === 'synced'
                    ? 'bg-emerald-50 border-emerald-200'
                    : item.status === 'syncing'
                    ? 'bg-sky-50 border-sky-200'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div>
                  <div className="font-bold text-slate-800 capitalize">
                    {item.type.replace('_', ' ')}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </div>
                  {item.error && (
                    <div className="text-[10px] text-red-600 font-semibold mt-0.5">
                      Error: {item.error}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      item.status === 'synced'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'failed'
                        ? 'bg-red-100 text-red-800'
                        : item.status === 'syncing'
                        ? 'bg-sky-100 text-sky-800 animate-pulse'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.status}
                  </span>

                  {item.status === 'failed' && (
                    <button
                      onClick={runSync}
                      className="p-1 text-slate-500 hover:text-slate-800 font-bold"
                      title="Retry"
                    >
                      <RefreshCw className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {isOnline && (
            <div className="pt-2 mt-2 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={runSync}
                disabled={isSyncing}
                className="w-full py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl flex items-center justify-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Syncing Queue...' : 'Force Sync All Now'}</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
