import React, { useEffect, useState } from 'react';
import { OmazifyLogo } from './OmazifyLogo';
import { Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onFinish?: () => void;
  minDurationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  minDurationMs = 850,
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    const fadeTimer = setTimeout(() => {
      setIsFading(true);
    }, minDurationMs);

    const endTimer = setTimeout(() => {
      setIsVisible(false);
      onFinish?.();
    }, minDurationMs + 300);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(endTimer);
    };
  }, [minDurationMs, onFinish]);

  if (!isVisible) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between py-12 px-6 bg-white transition-opacity duration-300 ease-out select-none ${
        isFading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      aria-label="OMAZIFY Loading"
    >
      <div className="w-full" />

      {/* Center Logo */}
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="relative flex items-center justify-center p-6 rounded-3xl bg-[#FAFAFA] border border-[#EAEAEA] shadow-sm">
          <OmazifyLogo size="lg" />
          <div className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-[#FFD400] text-[#000000] flex items-center justify-center shadow-xs">
            <Sparkles className="w-3.5 h-3.5 fill-[#000000] text-[#000000]" />
          </div>
        </div>

        <div className="space-y-1">
          <p className="text-sm font-black text-[#111111] tracking-tight">
            SHOP SMART • LIVE BETTER
          </p>
          <p className="text-xs text-[#666666] font-semibold tracking-wide">
            India's Trendiest Shopping Destination
          </p>
        </div>
      </div>

      {/* Bottom Brand Credential */}
      <div className="flex flex-col items-center space-y-2 text-center">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#FFD400] animate-ping" />
          <span className="text-[11px] font-bold text-[#666666] uppercase tracking-widest">
            100% Genuine Products • Cash on Delivery
          </span>
        </div>
      </div>
    </div>
  );
};
