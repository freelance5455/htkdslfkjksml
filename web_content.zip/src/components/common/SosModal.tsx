import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldAlert,
  PhoneCall,
  MapPin,
  X,
  Volume2,
  CheckCircle2,
  AlertTriangle,
  Send
} from 'lucide-react';

export const SosModal: React.FC = () => {
  const { isSosOpen, setIsSosOpen, triggerEmergencySos, currentLocation, user, adminConfig } = useApp();
  const [sosSent, setSosSent] = useState(false);
  const [isSirenActive, setIsSirenActive] = useState(false);
  const [customNote, setCustomNote] = useState('');

  if (!isSosOpen) return null;

  const handleTrigger = async () => {
    await triggerEmergencySos(customNote || undefined);
    setSosSent(true);
    setIsSirenActive(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 text-white rounded-3xl border border-red-500/30 max-w-sm w-full p-5 shadow-2xl relative overflow-hidden">
        {/* Pulsating emergency glow */}
        {isSirenActive && (
          <div className="absolute inset-0 bg-red-600/15 pointer-events-none animate-pulse" />
        )}

        {/* Close Button */}
        <button
          onClick={() => {
            setIsSosOpen(false);
            setSosSent(false);
            setIsSirenActive(false);
          }}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500 shadow-inner">
            <ShieldAlert className="w-7 h-7 animate-bounce" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>AllJi 24x7 Safety Guard</span>
            </h3>
            <p className="text-xs text-slate-400">Instant Police & Emergency Response</p>
          </div>
        </div>

        {/* GPS location display */}
        <div className="mt-4 p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-xs">
          <div className="flex items-center gap-2 text-red-400 font-semibold mb-1">
            <MapPin className="w-4 h-4" />
            <span>Your Live Location</span>
          </div>
          <p className="text-slate-200 font-medium">{currentLocation.locality}, {currentLocation.city}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Coordinates: {currentLocation.coordinates ? `${currentLocation.coordinates.lat}, ${currentLocation.coordinates.lng}` : 'Live GPS Calibrated'}
          </p>
        </div>

        {/* Main Action or Confirmation */}
        {!sosSent ? (
          <div className="mt-5 space-y-4">
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                Optional note (e.g. Unsafe driver / medical):
              </label>
              <input
                type="text"
                value={customNote}
                onChange={e => setCustomNote(e.target.value)}
                placeholder="Describe situation briefly..."
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-hidden focus:border-red-500"
              />
            </div>

            <button
              id="confirm-trigger-sos-btn"
              onClick={handleTrigger}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-red-600/40 active:scale-98 transition-all"
            >
              <ShieldAlert className="w-5 h-5" />
              <span>TAP TO SEND EMERGENCY SOS ALERT</span>
            </button>
            <p className="text-[10px] text-center text-slate-400">
              Immediately alerts AllJi Safety Command Center, nearest police, and your emergency contacts.
            </p>
          </div>
        ) : (
          <div className="mt-5 p-4 rounded-2xl bg-red-950/60 border border-red-500 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2 animate-bounce" />
            <h4 className="text-sm font-black text-white">EMERGENCY SOS BROADCASTED!</h4>
            <p className="text-xs text-slate-300 mt-1">
              Safety team notified. Live location link sent via SMS to {user.emergencyContacts.length || 2} emergency contacts.
            </p>

            <button
              onClick={() => setIsSirenActive(!isSirenActive)}
              className="mt-3 px-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-amber-300 flex items-center justify-center gap-2 mx-auto font-semibold"
            >
              <Volume2 className="w-4 h-4" />
              <span>{isSirenActive ? 'Siren Pulsing (Mute)' : 'Sound Alarm'}</span>
            </button>
          </div>
        )}

        {/* Quick Helplines */}
        <div className="mt-5 pt-4 border-t border-slate-800">
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Direct Emergency Helplines (India)
          </p>
          <div className="grid grid-cols-2 gap-2">
            <a
              href="tel:112"
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-2 text-xs font-bold text-white transition-colors"
            >
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <div>
                <span>Police / All 112</span>
                <span className="block text-[10px] text-slate-400 font-normal">Toll-Free</span>
              </div>
            </a>
            <a
              href="tel:1091"
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-2 text-xs font-bold text-white transition-colors"
            >
              <PhoneCall className="w-4 h-4 text-pink-400" />
              <div>
                <span>Women Helpline</span>
                <span className="block text-[10px] text-slate-400 font-normal">1091</span>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
