import React, { useState, useEffect, useRef } from 'react';
import {
  Compass,
  Search,
  Bell,
  LogOut,
  Building2,
  ChevronDown,
  ShieldAlert,
  Smartphone,
  LayoutDashboard,
  Sparkles,
  User,
  Check,
  Crown,
  Shield,
  ShieldCheck,
} from 'lucide-react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { OfflineBadge } from './OfflineBadge.tsx';
import { GlobalSearchModal } from './GlobalSearchModal.tsx';
import { NotificationsModal } from './NotificationsModal.tsx';
import { UserProfileModal } from './UserProfileModal.tsx';

interface NavbarProps {
  onOpenAiAssistant?: () => void;
  onNavigate?: (module: string) => void;
  activeExperience: 'admin' | 'technician' | 'owner';
  setActiveExperience: (exp: 'admin' | 'technician' | 'owner') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAiAssistant,
  onNavigate,
  activeExperience,
  setActiveExperience,
}) => {
  const {
    userProfile,
    currentOrg,
    availableOrgs,
    isPlatformOwner,
    isAdmin,
    signOutUser,
    switchOrganization,
  } = useAuth();

  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isOrgDropdownOpen, setIsOrgDropdownOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [unreadNotifsCount, setUnreadNotifsCount] = useState<number>(0);

  const orgDropdownRef = useRef<HTMLDivElement>(null);
  const profileDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click or Escape key - ONLY active when a dropdown is open
  useEffect(() => {
    if (!isOrgDropdownOpen && !isProfileDropdownOpen) return;

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node;
      if (isOrgDropdownOpen && orgDropdownRef.current && !orgDropdownRef.current.contains(target)) {
        setIsOrgDropdownOpen(false);
      }
      if (isProfileDropdownOpen && profileDropdownRef.current && !profileDropdownRef.current.contains(target)) {
        setIsProfileDropdownOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOrgDropdownOpen(false);
        setIsProfileDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('touchstart', handlePointerDown, { passive: true });
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('touchstart', handlePointerDown);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOrgDropdownOpen, isProfileDropdownOpen]);

  // Poll or check unread notifications count
  useEffect(() => {
    if (!userProfile) return;
    let isMounted = true;

    const checkUnread = async () => {
      try {
        const userQ = query(
          collection(db, 'notifications'),
          where('userId', '==', userProfile.id),
          where('read', '==', false)
        );
        const snap = await getDocs(userQ);
        if (isMounted) {
          setUnreadNotifsCount(snap.size);
        }
      } catch (e) {
        // ignore
      }
    };

    checkUnread();
    const interval = setInterval(checkUnread, 30000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [userProfile, currentOrg]);

  return (
    <>
      <header
        className={`sticky top-0 bg-white border-b border-slate-200 transition-all ${
          isOrgDropdownOpen || isProfileDropdownOpen ? 'z-[60] shadow-sm' : 'z-50'
        }`}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-2">
          {/* Left: Brand & Company Selector */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0 min-w-0">
            <div className="flex items-center gap-1.5 shrink-0">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-sky-600 flex items-center justify-center text-white shadow-xs shrink-0">
                <Compass className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.2]" />
              </div>
              <div className="hidden xs:block">
                <span className="font-black text-sm sm:text-base tracking-tight text-slate-900">
                  Field<span className="text-sky-600">Flow</span>
                </span>
              </div>
            </div>

            {/* Organization Selector */}
            {(currentOrg || isPlatformOwner) && (
              <div className="relative" ref={orgDropdownRef}>
                <button
                  type="button"
                  onClick={() => setIsOrgDropdownOpen((prev) => !prev)}
                  aria-haspopup="listbox"
                  aria-expanded={isOrgDropdownOpen}
                  className={`flex items-center gap-1.5 px-2 sm:px-3 py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                    isOrgDropdownOpen
                      ? 'bg-sky-50 border-sky-300 text-sky-950 ring-2 ring-sky-500/20 shadow-xs'
                      : 'bg-slate-100/90 hover:bg-slate-200/80 border-slate-200 text-slate-800'
                  }`}
                  title={`Current Workspace: ${currentOrg?.name || 'Select Workspace'}`}
                >
                  {currentOrg?.logoUrl ? (
                    <img src={currentOrg.logoUrl} alt="" className="w-4 h-4 object-contain rounded shrink-0" />
                  ) : (
                    <div
                      className="w-4 h-4 rounded text-white text-[9px] font-black flex items-center justify-center shrink-0"
                      style={{ backgroundColor: currentOrg?.accentColor || '#0284c7' }}
                    >
                      {(currentOrg?.name || 'F').charAt(0)}
                    </div>
                  )}
                  <span className="truncate max-w-[110px] xs:max-w-[150px] sm:max-w-[200px] md:max-w-[260px] text-left">
                    {currentOrg?.name || 'Select Workspace'}
                  </span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform ${
                      isOrgDropdownOpen ? 'rotate-180 text-sky-600' : ''
                    }`}
                  />
                </button>

                {isOrgDropdownOpen && (
                  <div
                    role="listbox"
                    className="absolute left-0 mt-2 w-72 sm:w-80 max-w-[calc(100vw-24px)] bg-white rounded-2xl shadow-2xl border border-slate-200 py-1.5 z-[80] text-xs overflow-hidden animate-in fade-in-0 duration-150"
                  >
                    <div className="px-3.5 py-2 border-b border-slate-100 flex items-center justify-between text-[11px]">
                      <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">
                        {isPlatformOwner ? 'All Customer Workspaces' : 'Authorized Workspace'}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-bold">
                        {isPlatformOwner ? `${availableOrgs.length} active` : 'Isolated'}
                      </span>
                    </div>

                    <div className="max-h-64 overflow-y-auto divide-y divide-slate-50 py-1">
                      {(isPlatformOwner
                        ? availableOrgs
                        : availableOrgs.filter(
                            (o) =>
                              o.id === currentOrg?.id ||
                              o.createdBy?.toLowerCase() === userProfile?.email.toLowerCase() ||
                              o.createdBy === userProfile?.id
                          )
                      ).map((org) => {
                        const isSelected = currentOrg?.id === org.id;
                        return (
                          <button
                            key={org.id}
                            type="button"
                            role="option"
                            aria-selected={isSelected}
                            onClick={() => {
                              switchOrganization(org.id);
                              setIsOrgDropdownOpen(false);
                            }}
                            className={`w-full text-left px-3.5 py-2.5 flex items-center justify-between gap-2.5 transition-colors cursor-pointer ${
                              isSelected ? 'bg-sky-50/80 text-sky-950 font-bold' : 'hover:bg-slate-50 text-slate-700'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              {org.logoUrl ? (
                                <img src={org.logoUrl} alt="" className="w-5 h-5 rounded object-contain shrink-0" />
                              ) : (
                                <div
                                  className="w-5 h-5 rounded text-white text-[10px] font-bold flex items-center justify-center shrink-0"
                                  style={{ backgroundColor: org.accentColor || '#0284c7' }}
                                >
                                  {org.name.charAt(0)}
                                </div>
                              )}
                              <div className="min-w-0">
                                <div className="truncate text-xs">{org.name}</div>
                                <div className="text-[10px] text-slate-400 font-mono truncate">{org.id}</div>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              {org.status === 'suspended' && (
                                <span className="text-[10px] text-rose-600 bg-rose-50 border border-rose-200 px-1.5 py-0.5 rounded-full font-semibold">
                                  Suspended
                                </span>
                              )}
                              {isSelected && <Check className="w-4 h-4 text-sky-600 stroke-[2.5]" />}
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {isPlatformOwner && (
                      <div className="p-2 border-t border-slate-100 bg-slate-50/80">
                        <button
                          type="button"
                          onClick={() => {
                            setActiveExperience('owner');
                            setIsOrgDropdownOpen(false);
                          }}
                          className="w-full py-1.5 px-2 rounded-xl text-center font-bold text-[11px] text-purple-700 hover:bg-purple-100/70 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Crown className="w-3.5 h-3.5" />
                          <span>Manage All Tenants in Owner Console</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Center: Distinct Role Clarity & Navigation */}
          <div className="flex items-center">
            {isPlatformOwner ? (
              <div className="flex items-center gap-1 sm:gap-1.5">
                <button
                  type="button"
                  onClick={() => setActiveExperience('owner')}
                  className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl text-xs font-bold transition-all border ${
                    activeExperience === 'owner'
                      ? 'bg-purple-600 text-white border-purple-700 shadow-xs'
                      : 'bg-purple-50 text-purple-800 border-purple-200 hover:bg-purple-100'
                  }`}
                  title="Platform Owner Root Console"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-300" />
                  <span className="hidden sm:inline">Platform Owner</span>
                  <span className="sm:hidden">Owner</span>
                </button>

                <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs">
                  <button
                    type="button"
                    onClick={() => setActiveExperience('admin')}
                    className={`px-2 py-0.5 rounded-lg font-bold transition-all ${
                      activeExperience === 'admin'
                        ? 'bg-white text-sky-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Admin
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveExperience('technician')}
                    className={`px-2 py-0.5 rounded-lg font-bold transition-all ${
                      activeExperience === 'technician'
                        ? 'bg-white text-emerald-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Tech
                  </button>
                </div>
              </div>
            ) : isAdmin ? (
              <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setActiveExperience('admin')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                    activeExperience === 'admin'
                      ? 'bg-white text-sky-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="w-3.5 h-3.5 text-sky-600" />
                  <span className="hidden sm:inline">Admin Console</span>
                  <span className="sm:hidden">Admin</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveExperience('technician')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
                    activeExperience === 'technician'
                      ? 'bg-white text-emerald-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Field Technician Mobile Experience"
                >
                  <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="hidden sm:inline">Field Tech View</span>
                  <span className="sm:hidden">Tech</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 font-bold text-xs">
                <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">Field Technician</span>
              </div>
            )}
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-1 sm:gap-2">
            <OfflineBadge />

            {/* Global Search */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              title="Global Search"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Notifications */}
            <button
              onClick={() => setIsNotifOpen(true)}
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors relative cursor-pointer"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifsCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 bg-rose-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}
                </span>
              )}
            </button>

            {/* AI Assistant button */}
            {onOpenAiAssistant && (
              <button
                onClick={onOpenAiAssistant}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-xs hover:opacity-95 transition-opacity cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span className="hidden md:inline">FieldFlow AI</span>
              </button>
            )}

            {/* User Profile & Menu */}
            <div className="relative" ref={profileDropdownRef}>
              <button
                type="button"
                onClick={() => setIsProfileDropdownOpen((prev) => !prev)}
                aria-haspopup="true"
                aria-expanded={isProfileDropdownOpen}
                className="flex items-center gap-2 p-0.5 rounded-full hover:bg-slate-100 transition-colors border border-slate-200 cursor-pointer"
              >
                {userProfile?.avatarUrl ? (
                  <img
                    src={userProfile.avatarUrl}
                    alt={userProfile.displayName}
                    className="w-7 h-7 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-xs">
                    {userProfile?.displayName?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}
              </button>

              {isProfileDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 max-w-[calc(100vw-24px)] bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-[80] text-xs animate-in fade-in-0 duration-150">
                  <div className="px-4 py-2.5 border-b border-slate-100 space-y-1">
                    <div className="font-bold text-slate-800 truncate">{userProfile?.displayName}</div>
                    <div className="text-slate-500 text-[11px] truncate">{userProfile?.email}</div>
                    <div className="pt-0.5">
                      {isPlatformOwner ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                          <Crown className="w-3 h-3" />
                          <span>Platform Owner (Root)</span>
                        </span>
                      ) : userProfile?.role === 'org_admin' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                          <Building2 className="w-3 h-3" />
                          <span>Company Main Admin</span>
                        </span>
                      ) : userProfile?.role === 'sub_admin' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                          <ShieldCheck className="w-3 h-3" />
                          <span>Sub-Admin</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          <Smartphone className="w-3 h-3" />
                          <span>Field Technician</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* My Profile Action */}
                  <div className="px-2 py-1 border-b border-slate-100">
                    <button
                      onClick={() => {
                        setIsProfileModalOpen(true);
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-2 rounded-xl text-slate-800 font-bold hover:bg-sky-50 hover:text-sky-700 transition-colors cursor-pointer"
                    >
                      <User className="w-4 h-4 text-sky-600" />
                      <span>My Profile & Photos</span>
                    </button>
                  </div>

                  <div className="px-2 pt-1">
                    <button
                      onClick={() => {
                        signOutUser();
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-xl font-bold transition-colors cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Modals */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={(mod) => {
          if (onNavigate) onNavigate(mod);
        }}
      />

      <NotificationsModal
        isOpen={isNotifOpen}
        onClose={() => setIsNotifOpen(false)}
      />
    </>
  );
};
