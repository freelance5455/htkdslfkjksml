import React from 'react';
import { 
  Coins, 
  Bell, 
  User as UserIcon, 
  Globe, 
  ShieldCheck, 
  Sparkles,
  ChevronRight,
  Headphones
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../pwa/PWAInstallButton';

interface NavbarProps {
  onOpenNotifications: () => void;
  onOpenAuth: () => void;
  onOpenAdminLogin: () => void;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenSupport: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenNotifications,
  onOpenAuth,
  onOpenAdminLogin,
  currentTab,
  setCurrentTab,
  onOpenSupport,
}) => {
  const { 
    currentUser, 
    isAdminAuthenticated, 
    language, 
    setLanguage, 
    notifications,
    systemSettings,
    t 
  } = useApp();

  const [logoClicks, setLogoClicks] = React.useState(0);
  const [showAdminBtn, setShowAdminBtn] = React.useState(false);

  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === 'true') {
      setShowAdminBtn(true);
    }
  }, []);

  const handleLogoClick = () => {
    setLogoClicks(prev => {
      const next = prev + 1;
      if (next >= 5) {
        if (isAdminAuthenticated) {
          setCurrentTab('admin');
        } else {
          onOpenAdminLogin();
        }
        return 0;
      }
      return next;
    });
    setCurrentTab('dashboard');
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const userCoins = currentUser ? currentUser.coins : 450;
  const rate = systemSettings.coinsPerCurrencyUnit || 1;
  const inrValue = (userCoins / rate).toFixed(2);

  const toggleLang = () => {
    setLanguage(language === 'en' ? 'bn' : 'en');
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#090D16]/85 backdrop-blur-xl border-b border-slate-800/70 transition-colors">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-14 gap-2">
          
          {/* Logo on the Left - Secret 5-Click Admin Entry */}
          <button
            onClick={handleLogoClick}
            className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-indigo-600 flex items-center justify-center shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <Coins className="w-4 h-4 text-white" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-sm tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                Task Earn Pro
              </span>
              <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                VIP
              </span>
            </div>
          </button>

          {/* Right Action Icons & Coin Pill */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* Install Android App / APK Pill */}
            <PWAInstallButton />

            {/* Admin Panel Button (ONLY shown to Authenticated Administrators) */}
            {isAdminAuthenticated && (
              <button
                onClick={() => setCurrentTab('admin')}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-purple-950/70 hover:bg-purple-900 border border-purple-700/60 text-purple-300 hover:text-white transition-all cursor-pointer shadow-xs active:scale-95 animate-pulse"
                title="Admin Panel"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                <span className="text-[11px] font-black tracking-tight whitespace-nowrap">Admin Panel</span>
              </button>
            )}

            {/* Coin Balance Pill */}
            <button
              onClick={() => setCurrentTab('wallet')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800/90 border border-slate-700/60 transition-all cursor-pointer group shadow-xs active:scale-95"
              title="View Wallet & Cashout"
            >
              <div className="w-4 h-4 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center text-[10px] font-black">
                🪙
              </div>
              <span className="text-xs font-black text-slate-100 group-hover:text-emerald-400">
                {userCoins.toLocaleString()}
              </span>
              <span className="text-[10px] font-semibold text-emerald-400/90 hidden xs:inline">
                (₹{inrValue})
              </span>
            </button>

            {/* Support / Problem Help Button */}
            <button
              onClick={onOpenSupport}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-teal-950/70 hover:bg-teal-900 border border-teal-700/60 text-teal-300 hover:text-white transition-all cursor-pointer shadow-xs active:scale-95"
              title="Support Team / Problem Help"
            >
              <Headphones className="w-3.5 h-3.5 text-teal-400" />
              <span className="text-[11px] font-black tracking-tight hidden sm:inline">Support</span>
            </button>

            {/* Language Selector Pill */}
            <button
              onClick={toggleLang}
              className="px-2 py-1 rounded-full bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-[11px] font-bold text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
              title="Change Language"
            >
              <Globe className="w-3 h-3 text-slate-400" />
              <span>{language === 'en' ? 'EN' : 'বাং'}</span>
            </button>

            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              )}
            </button>

            {/* Admin & Profile Entry Point - ALWAYS UNHIDDEN AND VISIBLE */}
            <button
              onClick={() => {
                if (isAdminAuthenticated) {
                  setCurrentTab('admin');
                } else {
                  onOpenAdminLogin();
                }
              }}
              className="px-2 sm:px-2.5 py-1 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-95 text-white transition-all cursor-pointer flex items-center gap-1 text-[10px] sm:text-[11px] font-black shrink-0 shadow-md shadow-purple-600/20 active:scale-95 whitespace-nowrap"
              title="Admin Dashboard"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>

            {currentUser ? (
              <button
                onClick={() => setCurrentTab('profile')}
                className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center overflow-hidden cursor-pointer transition-colors shrink-0"
                title="Profile"
              >
                {currentUser.avatar ? (
                  <img src={currentUser.avatar} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <UserIcon className="w-4 h-4 text-slate-300" />
                )}
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white font-bold text-xs cursor-pointer transition-all shrink-0 flex items-center gap-1 shadow-sm"
              >
                <span>Google / Login</span>
              </button>
            )}

          </div>

        </div>
      </div>
    </header>
  );
};
