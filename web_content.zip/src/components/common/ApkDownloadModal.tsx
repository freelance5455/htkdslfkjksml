import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Download,
  ExternalLink,
  Check,
  Copy,
  Sparkles,
  ShieldCheck,
  Cpu,
  Layers,
  ArrowRight,
  Terminal,
  HelpCircle,
  Package,
} from 'lucide-react';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenFlutterCenter?: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({
  isOpen,
  onClose,
  onOpenFlutterCenter,
}) => {
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'instant' | 'pwabuilder' | 'flutter'>('instant');

  // Live app URL for APK packaging
  const liveAppUrl = window.location.origin;

  // Listen for native Android PWA install prompt
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(liveAppUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleNativeInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstallable(false);
      }
      setDeferredPrompt(null);
    } else {
      alert(
        'To install directly on Android:\n1. Open this link in Google Chrome on your phone.\n2. Tap the three dots (⋮) menu.\n3. Tap "Install App" or "Add to Home screen".'
      );
    }
  };

  // Direct PWABuilder URL prefilled with live site
  const pwaBuilderUrl = `https://www.pwabuilder.com?url=${encodeURIComponent(liveAppUrl)}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1746A2] via-[#10347a] to-slate-900 p-5 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 bg-black/30 hover:bg-black/50 text-white rounded-full transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <span className="w-7 h-7 rounded-xl bg-[#FFD447] text-slate-950 flex items-center justify-center font-black text-xs shadow">
              APK
            </span>
            <span className="text-[10px] bg-white/20 text-white font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
              Android Application Package
            </span>
          </div>

          <h3 className="text-lg font-black text-white">PCMART Android APK Download & Build Center</h3>
          <p className="text-xs text-blue-100/80 mt-0.5">
            अपने मोबाइल पर ऐप इंस्टॉल करें या 1-क्लिक में प्रोडक्शन APK डाउनलोड करें
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950 px-4 pt-2 gap-2 text-xs">
          <button
            onClick={() => setActiveTab('instant')}
            className={`pb-2.5 px-3 font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'instant'
                ? 'border-[#FFD447] text-[#FFD447]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>1. Direct Android Install</span>
          </button>

          <button
            onClick={() => setActiveTab('pwabuilder')}
            className={`pb-2.5 px-3 font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'pwabuilder'
                ? 'border-[#FFD447] text-[#FFD447]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>2. Generate .APK Online</span>
          </button>

          <button
            onClick={() => setActiveTab('flutter')}
            className={`pb-2.5 px-3 font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'flutter'
                ? 'border-[#FFD447] text-[#FFD447]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>3. Flutter CLI Build</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs flex-1">
          {/* TAB 1: Direct Android Install & Direct APK Download */}
          {activeTab === 'instant' && (
            <div className="space-y-4">
              {/* PRIMARY ACTION: DIRECT APK FILE DOWNLOAD */}
              <div className="p-4 bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border border-emerald-500/50 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                      <Download className="w-4 h-4" />
                    </span>
                    <div>
                      <h4 className="text-sm font-black text-white">Direct APK File Download</h4>
                      <span className="text-[10px] text-emerald-300 font-mono">pcmart-v1.0.apk (Ready to install)</span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold font-mono">
                    Universal APK
                  </span>
                </div>

                <a
                  href="/download/pcmart.apk"
                  download="pcmart-v1.0.apk"
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 text-slate-950 font-black text-sm rounded-xl shadow-xl flex items-center justify-center gap-2 active:scale-98 transition-all"
                >
                  <Download className="w-4 h-4 fill-current" />
                  <span>Download pcmart-v1.0.apk</span>
                </a>

                <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 text-center pt-1 border-t border-slate-800">
                  <div>Package: <strong className="text-slate-200">in.pcmart.app</strong></div>
                  <div>Android: <strong className="text-slate-200">8.0 - 14+</strong></div>
                  <div>Security: <strong className="text-emerald-400">Verified Safe</strong></div>
                </div>
              </div>

              {/* SECONDARY ACTION: PWA Native WebAPK Install */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-[#FFD447]" />
                  <span className="font-bold text-white text-xs">Alternative: Direct Browser Install (No Download Required)</span>
                </div>
                <button
                  onClick={handleNativeInstall}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  <Smartphone className="w-3.5 h-3.5 text-[#FFD447]" />
                  <span>Add PCMART to Home Screen (Instant WebAPK)</span>
                </button>
              </div>

              {/* Simple 3-step guide for Android Chrome */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2.5">
                <span className="font-bold text-white uppercase text-[10px] tracking-wider block">
                  How to install on your Android Mobile (चरण-दर-चरण):
                </span>
                <div className="space-y-2 text-slate-300 text-[11px]">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1746A2] text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      1
                    </span>
                    <span>
                      अपने Android फोन में Google Chrome ब्राउज़र खोलें और नीचे दिए गए लिंक को पेस्ट करें:
                    </span>
                  </div>

                  <div className="flex items-center gap-2 bg-slate-900 p-2 rounded-xl border border-slate-800 font-mono text-[10px]">
                    <span className="truncate flex-1 text-[#FFD447]">{liveAppUrl}</span>
                    <button
                      onClick={handleCopyUrl}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded font-bold flex items-center gap-1 shrink-0"
                    >
                      {copiedUrl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      {copiedUrl ? 'Copied' : 'Copy'}
                    </button>
                  </div>

                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1746A2] text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      2
                    </span>
                    <span>
                      Chrome के ऊपरी दाएं कोने में <strong>तीन बिंदु (⋮)</strong> दबाएं।
                    </span>
                  </div>

                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1746A2] text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                      3
                    </span>
                    <span>
                      <strong>"Install app"</strong> या <strong>"Add to Home screen"</strong> पर क्लिक करें। PCMART आपके फोन की होम स्क्रीन पर ऐप बनकर आ जाएगा!
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Generate .APK Online (PWABuilder) */}
          {activeTab === 'pwabuilder' && (
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-blue-950/40 via-slate-950 to-blue-950/40 border border-blue-500/40 rounded-2xl flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Generate Signed Android APK / AAB Online</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                    <strong>PWABuilder</strong> (Microsoft & Google समर्थित टूल) की मदद से आप इस ऐप का स्टैंडअलोन <code>.apk</code> और Google Play <code>.aab</code> पैकेज 30 सेकंड में मुफ्त डाउनलोड कर सकते हैं।
                  </p>
                </div>
              </div>

              {/* Direct generator button */}
              <a
                href={pwaBuilderUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 bg-[#1746A2] hover:bg-blue-600 text-white font-bold text-sm rounded-2xl shadow-xl flex items-center justify-center gap-2 active:scale-98 transition-all"
              >
                <span>Open 1-Click APK Generator (PWABuilder)</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              {/* Instructions */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-[11px] text-slate-300">
                <span className="font-bold text-white block uppercase text-[10px] tracking-wider">
                  APK डाउनलोड करने के 3 आसान कदम:
                </span>
                <ol className="list-decimal list-inside space-y-1.5 leading-relaxed">
                  <li>ऊपर दिए गए नीले बटन <strong>"Open 1-Click APK Generator"</strong> पर क्लिक करें।</li>
                  <li>
                    PWABuilder पर <strong>"Package for Android"</strong> चुनें।
                  </li>
                  <li>
                    <strong>"Generate APK / Package"</strong> बटन दबाएं और अपना <code>pcmart.apk</code> फ़ाइल डाउनलोड करके किसी भी Android फ़ोन में इंस्टॉल कर लें!
                  </li>
                </ol>
              </div>

              {/* App URL reference */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">PWA Manifest Status:</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> 100% Valid (/manifest.json)
                </span>
              </div>
            </div>
          )}

          {/* TAB 3: Flutter CLI Build */}
          {activeTab === 'flutter' && (
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-amber-950/40 via-slate-950 to-amber-950/40 border border-amber-500/40 rounded-2xl flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Native Flutter & Android Source Code</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                    इस ऐप का संपूर्ण <strong>Flutter Android Codebase</strong> (Material 3 Theme, BLoC State Management, और Razorpay Payment) पहले से ऐप में तैयार है।
                  </p>
                </div>
              </div>

              {/* CLI command box */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 font-mono text-[11px] space-y-2">
                <div className="flex items-center justify-between text-slate-400 text-[10px] pb-1 border-b border-slate-800">
                  <span className="flex items-center gap-1">
                    <Terminal className="w-3 h-3 text-emerald-400" /> Terminal / Command Prompt
                  </span>
                  <span>Flutter SDK 3.x</span>
                </div>
                <div className="text-emerald-400 space-y-1">
                  <p className="text-slate-500"># 1. Clone or extract Flutter code</p>
                  <p className="text-white">flutter pub get</p>
                  <p className="text-slate-500 pt-1"># 2. Build release Android APK</p>
                  <p className="text-amber-400 font-bold">flutter build apk --release</p>
                  <p className="text-slate-500 pt-1"># Output APK location:</p>
                  <p className="text-slate-300">build/app/outputs/flutter-apk/app-release.apk</p>
                </div>
              </div>

              {onOpenFlutterCenter && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenFlutterCenter();
                  }}
                  className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  <Layers className="w-4 h-4 text-[#FFD447]" />
                  <span>Open Full Flutter Code & Architecture Center</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>Package ID: <strong className="text-white font-mono">in.pcmart.app</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
