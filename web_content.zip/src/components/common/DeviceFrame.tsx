import React from 'react';
import { useApp } from '../../context/AppContext';
import { Smartphone, Monitor, ShieldAlert, Sparkles, UserCheck } from 'lucide-react';
import { UserRole } from '../../types';

interface DeviceFrameProps {
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children }) => {
  const {
    deviceFrame,
    setDeviceFrame,
    role,
    switchRoleQuickly,
    currentLocation,
    setIsSosOpen,
    setIsAuthOpen,
    user
  } = useApp();

  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-0 sm:p-4 md:p-6 select-none overflow-x-hidden">
      {/* Top Universal Platform Bar */}
      <header className="w-full max-w-5xl mb-3 flex flex-wrap items-center justify-between gap-3 px-3 py-2 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 text-xs shadow-xl">
        {/* Brand & Slogan */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500 flex items-center justify-center font-black text-white text-base shadow-md shadow-orange-500/20">
            A
          </div>
          <div>
            <div className="flex items-center gap-1.5 font-bold tracking-tight text-white text-sm">
              <span>AllJi</span>
              <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                Super App
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">Sab Kuch, Ek Hi Jagah</p>
          </div>
        </div>

        {/* Quick Role Switcher Bar */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          {(['customer', 'provider', 'delivery', 'admin'] as UserRole[]).map(r => {
            const isActive = role === r;
            const labels: Record<UserRole, string> = {
              customer: '👤 Customer',
              provider: '⚡ Provider / Worker',
              delivery: '🛵 Delivery Partner',
              admin: '🛡️ Admin Panel'
            };
            return (
              <button
                key={r}
                id={`role-btn-${r}`}
                onClick={() => switchRoleQuickly(r)}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-sm font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                {labels[r]}
              </button>
            );
          })}
        </div>

        {/* Device Mode & SOS Button */}
        <div className="flex items-center gap-2">
          {/* Frame selector */}
          <div className="hidden sm:flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              id="frame-btn-iphone"
              onClick={() => setDeviceFrame('iphone')}
              className={`p-1.5 rounded-lg text-[11px] flex items-center gap-1 transition-all ${
                deviceFrame === 'iphone' ? 'bg-slate-800 text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="iPhone View"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>iOS</span>
            </button>
            <button
              id="frame-btn-android"
              onClick={() => setDeviceFrame('android')}
              className={`p-1.5 rounded-lg text-[11px] flex items-center gap-1 transition-all ${
                deviceFrame === 'android' ? 'bg-slate-800 text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="Android Pixel View"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Android</span>
            </button>
            <button
              id="frame-btn-responsive"
              onClick={() => setDeviceFrame('responsive')}
              className={`p-1.5 rounded-lg text-[11px] flex items-center gap-1 transition-all ${
                deviceFrame === 'responsive' ? 'bg-slate-800 text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
              title="Responsive Web View"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Full Screen</span>
            </button>
          </div>

          {/* Quick SOS button */}
          <button
            id="top-emergency-sos-btn"
            onClick={() => setIsSosOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-md shadow-red-600/30 animate-pulse transition-all"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>SOS</span>
          </button>

          {/* User badge */}
          <button
            id="auth-toggle-btn"
            onClick={() => setIsAuthOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="truncate max-w-[80px] font-medium">{user.name.split(' ')[0]}</span>
          </button>
        </div>
      </header>

      {/* Main Container / Mobile Mockup */}
      <main className="w-full flex items-center justify-center flex-1">
        {deviceFrame === 'responsive' ? (
          <div className="w-full max-w-5xl min-h-[85vh] bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col relative text-slate-800">
            {children}
          </div>
        ) : (
          <div
            className={`w-full max-w-[420px] h-[860px] max-h-[92vh] bg-white text-slate-900 rounded-[44px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] border-[9px] ${
              deviceFrame === 'iphone' ? 'border-slate-800' : 'border-slate-900'
            } flex flex-col relative overflow-hidden ring-1 ring-slate-700/50`}
          >
            {/* Phone Status Bar */}
            <div className="w-full h-11 bg-slate-900 text-white px-7 flex items-center justify-between text-xs font-semibold z-40 select-none shrink-0 relative">
              <span>{currentTime}</span>

              {/* Dynamic Island or Punch Hole */}
              {deviceFrame === 'iphone' ? (
                <div className="absolute left-1/2 -translate-x-1/2 top-2 w-28 h-5 bg-black rounded-full flex items-center justify-end px-2 gap-1.5 border border-slate-800">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700" />
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </div>
              ) : (
                <div className="absolute left-1/2 -translate-x-1/2 top-2.5 w-3.5 h-3.5 bg-black rounded-full border border-slate-800" />
              )}

              <div className="flex items-center gap-1.5 text-[10px]">
                <span className="text-[10px] text-amber-400 font-bold">AllJi 5G</span>
                <span className="w-4 h-2.5 border border-white/80 rounded-sm p-[1px] inline-flex items-center">
                  <span className="w-full h-full bg-emerald-400 rounded-2xs" />
                </span>
              </div>
            </div>

            {/* Screen Viewport */}
            <div className="w-full flex-1 overflow-y-auto no-scrollbar relative flex flex-col bg-slate-50">
              {children}
            </div>

            {/* Phone Gesture Bottom Bar */}
            <div className="w-full h-5 bg-white flex items-center justify-center shrink-0 z-40">
              <div className="w-32 h-1 bg-slate-300 rounded-full" />
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
