import { useState, useEffect } from 'react';
import {
  Smartphone,
  Download,
  ExternalLink,
  CheckCircle2,
  X,
  Sparkles,
  QrCode,
  Copy,
  Check,
  Play,
  Layers,
  ArrowRight,
  ArrowLeft,
  ShieldCheck,
  Terminal,
} from 'lucide-react';
import { Language } from '../../types';
import { generateQRCodeDataURL } from '../../utils/qrcode';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export function AndroidApkModal({ isOpen, onClose, language }: AndroidApkModalProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'direct' | 'builder' | 'studio'>('direct');

  const appUrl = 'https://ais-pre-pefxpunhricz2tyrciaqkq-565742544358.europe-west3.run.app';
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`;

  const isRTL = language === 'ar';

  // Generate QR Code data URL on load
  useEffect(() => {
    generateQRCodeDataURL(appUrl, {
      width: 260,
      margin: 2,
      color: { dark: '#00f0ff', light: '#050b1e' },
      errorCorrectionLevel: 'M',
    })
      .then(url => setQrCodeUrl(url))
      .catch(() => {});
  }, [appUrl]);

  // Listen for beforeinstallprompt event on Android Chrome
  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallPwa = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      // Fallback instructions for manual Chrome install
      alert(
        isRTL
          ? 'من قائمة متصفح Chrome على هاتفك (الثلاث نقاط ⋮)، اضغط على "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية" لإنشاء ملف WebAPK فوري.'
          : 'From your mobile Chrome menu (⋮), tap "Install App" or "Add to Home Screen" to generate your Android WebAPK instantly.'
      );
    }
  };

  const handleCopyUrl = () => {
    navigator.clipboard?.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#091129] border border-cyan-500/40 text-white shadow-[0_0_50px_rgba(0,102,255,0.3)] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-cyan-500 text-slate-950 flex items-center justify-center font-bold shadow-[0_0_15px_rgba(16,185,129,0.4)]">
              <Smartphone className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {isRTL ? 'تحميل وتثبيت تطبيق الأندرويد (APK)' : 'Download & Install Android APK'}
              </h3>
              <p className="text-[11px] text-cyan-400 font-mono">
                TAKI-GO Mobile Android Ecosystem
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2 bg-[#050918] border-b border-slate-800/80">
          <button
            onClick={() => setActiveTab('direct')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'direct'
                ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{isRTL ? 'تثبيت فوري WebAPK' : 'Instant WebAPK'}</span>
          </button>

          <button
            onClick={() => setActiveTab('builder')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'builder'
                ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isRTL ? 'تنزيل APK جاهز' : 'Generate APK'}</span>
          </button>

          <button
            onClick={() => setActiveTab('studio')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'studio'
                ? 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{isRTL ? 'مشروع Android Studio' : 'Android Studio'}</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {activeTab === 'direct' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-cyan-950/30 to-[#071129] border border-emerald-500/30 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                  <ShieldCheck className="w-4 h-4" />
                  <span>
                    {isRTL
                      ? 'تثبيت تطبيق أندرويد حقيقي (Android WebAPK) بنقرة واحدة:'
                      : 'Install Native Android WebAPK (1-Tap):'}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isRTL
                    ? 'يقوم نظام أندرويد (Google Play Services) بتحويل هذا التطبيق فورياً إلى تطبيق نظام كامل (WebAPK) مع أيقونة مستقلة، شاشة تحميل Splash Screen، ويعمل بدون شريط المتصفح وبدون إنترنت.'
                    : 'Android Google Play Services automatically compiles this PWA into an authentic standalone WebAPK on your phone with custom launcher icon, offline caching, and native feel.'}
                </p>
              </div>

              {/* QR Code for Instant Phone Scan */}
              <div className="p-4 rounded-2xl bg-[#050b1e] border border-cyan-500/40 text-center space-y-2.5">
                <div className="flex items-center justify-center gap-2 text-cyan-400 font-bold text-xs">
                  <QrCode className="w-4 h-4" />
                  <span>
                    {isRTL
                      ? 'امسح الباركود بكاميرا هاتفك لفتح وتثبيت التطبيق:'
                      : 'Scan with Phone Camera to Open & Install:'}
                  </span>
                </div>
                {qrCodeUrl ? (
                  <div className="w-44 h-44 mx-auto p-2.5 bg-[#050b1e] rounded-2xl border-2 border-cyan-400/50 shadow-[0_0_30px_rgba(0,240,255,0.35)] flex items-center justify-center">
                    <img src={qrCodeUrl} alt="Scan to open on phone" className="w-full h-full object-contain rounded-xl" />
                  </div>
                ) : (
                  <div className="w-44 h-44 mx-auto bg-slate-900 rounded-2xl animate-pulse" />
                )}
                <p className="text-[11px] text-slate-300 font-medium">
                  {isRTL
                    ? 'وجّه كاميرا الهاتف نحو الشاشة وسيفتح التطبيق فوراً، ثم اضغط "تثبيت"'
                    : 'Point phone camera at screen to open instantly, then tap "Install"'}
                </p>
              </div>

              {/* Install CTA Button */}
              <button
                onClick={handleInstallPwa}
                className="w-full h-12 rounded-2xl bg-gradient-to-r from-emerald-500 via-cyan-400 to-blue-500 text-slate-950 font-black text-xs shadow-[0_0_25px_rgba(16,185,129,0.4)] hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-slate-950" />
                <span>
                  {isInstalled
                    ? (isRTL ? '✓ التطبيق مثبت بالفعل على جهازك' : '✓ App Installed on Device')
                    : (isRTL ? 'تثبيت TAKI-GO كـ APK على الهاتف الآن' : 'Install TAKI-GO APK on Device Now')}
                </span>
              </button>

              {/* Mobile steps visual guide */}
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs space-y-2">
                <p className="font-bold text-cyan-400">
                  {isRTL ? 'طريقة التثبيت اليدوي من متصفح الهاتف:' : 'Manual Installation Steps:'}
                </p>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px] leading-relaxed">
                  <li>{isRTL ? 'افتح هذا الرابط في متصفح Chrome على هاتفك الأندرويد.' : 'Open this URL in Google Chrome on your Android phone.'}</li>
                  <li>{isRTL ? 'اضغط على زر القائمة (⋮) أعلى اليمين.' : 'Tap the top-right menu icon (⋮).'}</li>
                  <li>{isRTL ? 'اختر "تثبيت التطبيق" (Install App) أو "إضافة إلى الشاشة الرئيسية".' : 'Select "Install App" or "Add to Home Screen".'}</li>
                  <li>{isRTL ? 'سيظهر التطبيق كملف APK حقيقي بين تطبيقات هاتفك.' : 'The app installs as a full Android WebAPK in your app drawer.'}</li>
                </ol>
              </div>

              {/* Copy URL Box */}
              <div className="flex items-center gap-2 p-2 rounded-xl bg-[#050b1e] border border-slate-800 text-xs">
                <input
                  type="text"
                  readOnly
                  value={appUrl}
                  className="flex-1 bg-transparent px-2 text-[11px] font-mono text-cyan-300 outline-none truncate"
                />
                <button
                  onClick={handleCopyUrl}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-bold flex items-center gap-1 shrink-0"
                >
                  {copiedUrl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedUrl ? (isRTL ? 'تم النسخ' : 'Copied') : (isRTL ? 'نسخ الرابط' : 'Copy URL')}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'builder' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-cyan-500/30 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-cyan-400 font-bold">
                  <Sparkles className="w-4 h-4" />
                  <span>{isRTL ? 'توليد ملف APK جاهز للتثبيت المباشر:' : 'Build & Download Signed APK:'}</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  {isRTL
                    ? 'يمكنك تنزيل ملف APK جاهز فورياً بواسطة أداة PWABuilder الرسمية (المعتمدة من Google و Microsoft). الرابط مُعد مسبقاً لهذا التطبيق مع حزمة الأيقونات والصلاحيات.'
                    : 'Download a standalone signed Android APK using PWABuilder (official Google/Microsoft partner tool). The package configuration is pre-filled for this app.'}
                </p>
              </div>

              {/* PWABuilder Action Button */}
              <a
                href={pwaBuilderUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full h-12 rounded-2xl bg-gradient-to-r from-blue-600 via-cyan-500 to-emerald-500 text-white font-bold text-xs shadow-[0_4px_25px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{isRTL ? 'فتح مولد الـ APK المباشر (PWABuilder) ←' : 'Open 1-Click APK Generator (PWABuilder) →'}</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              {/* Direct Zip download fallback */}
              <div className="pt-2">
                <p className="text-[11px] text-slate-400 mb-1.5">
                  {isRTL ? 'أو حمّل سورس كود المشروع المضغوط بالكامل:' : 'Or download the full source code archive:'}
                </p>
                <a
                  href="/takigo-app.zip"
                  download="takigo-app.zip"
                  className="w-full h-11 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-all"
                >
                  <Download className="w-4 h-4 text-cyan-400" />
                  <span>takigo-app.zip (330 KB)</span>
                </a>
              </div>
            </div>
          )}

          {activeTab === 'studio' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 text-xs text-cyan-200 space-y-1">
                <p className="font-bold">
                  {isRTL ? 'بناء ملف APK عبر Capacitor و Android Studio:' : 'Build APK via Capacitor & Android Studio:'}
                </p>
                <p className="text-[11px] text-slate-300">
                  {isRTL
                    ? 'مشروع TAKI-GO مجهز بملف capacitor.config.json. يمكنك في دقيقة واحدة تحويله إلى مشروع أندرويد ستوديو وبناء ملف APK أو AAB.'
                    : 'The codebase is configured with capacitor.config.json. You can wrap it into a native Android project and compile your APK in minutes.'}
                </p>
              </div>

              {/* Commands Box */}
              <div className="relative rounded-2xl bg-[#030712] border border-slate-800 p-3.5 font-mono text-[11px] text-cyan-300 space-y-1">
                <pre className="whitespace-pre-wrap leading-relaxed text-[10px]">
{`# 1. تثبيت Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. بناء ملفات الويب
npm run build

# 3. إنشاء مجلد الأندرويد
npx cap add android

# 4. فتح المشروع في Android Studio وبناء APK
npx cap open android`}
                </pre>
              </div>

              <a
                href="/takigo-app.zip"
                download="takigo-app.zip"
                className="w-full h-11 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-bold text-xs shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4 text-slate-950" />
                <span>{isRTL ? 'تحميل كود المشروع للبدء (ZIP)' : 'Download Source Code (ZIP)'}</span>
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
