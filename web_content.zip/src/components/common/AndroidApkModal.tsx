import React, { useState } from 'react';
import { Modal } from './Modal';
import {
  Smartphone,
  Flame,
  Code2,
  Download,
  Check,
  Copy,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'apk' | 'firebase'>('apk');
  const [copiedCode, setCopiedCode] = useState(false);

  const capacitorCommands = `// 1. Instalar dependencias de Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

// 2. Inicializar el proyecto Android
npx cap init RestoTurno com.restaurante.turnos --web-dir dist

// 3. Compilar la aplicación web
npm run build

// 4. Agregar plataforma Android y abrir en Android Studio
npx cap add android
npx cap open android

// En Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)`;

  const handleCopyCapacitor = () => {
    navigator.clipboard.writeText(capacitorCommands);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Conversión a APK Android y Conexión Firebase"
      subtitle="Guía técnica para exportar e instalar en celulares de restaurante"
      maxWidth="lg"
    >
      {/* Subtabs */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-2">
        <button
          onClick={() => setActiveTab('apk')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
            activeTab === 'apk'
              ? 'bg-neutral-900 text-white'
              : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
          }`}
        >
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span>Generar APK Android</span>
        </button>
        <button
          onClick={() => setActiveTab('firebase')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
            activeTab === 'firebase'
              ? 'bg-orange-600 text-white'
              : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
          }`}
        >
          <Flame className="w-4 h-4 text-amber-300" />
          <span>Arquitectura Firebase</span>
        </button>
      </div>

      {activeTab === 'apk' && (
        <div className="space-y-4 text-xs sm:text-sm text-neutral-700">
          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-950 space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-xs text-emerald-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>PWA y Manifest Android ya configurados en esta versión</span>
            </div>
            <p className="text-[11px] text-emerald-800 leading-relaxed">
              El archivo <code>manifest.webmanifest</code>, meta-etiquetas de pantalla completa, botones táctiles de 48px y viewport responsivo ya están integrados en el código.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-neutral-900 text-xs uppercase tracking-wider">
              Opción 1: Convertir a APK Nativo con Capacitor (Recomendado)
            </h4>
            <div className="relative">
              <pre className="bg-neutral-900 text-neutral-200 p-3.5 rounded-xl text-xs font-mono overflow-x-auto leading-relaxed">
                {capacitorCommands}
              </pre>
              <button
                onClick={handleCopyCapacitor}
                className="absolute top-2 right-2 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-semibold flex items-center gap-1 border border-neutral-700 active:scale-95"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>¡Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-orange-400" />
                    <span>Copiar</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="space-y-1.5 p-3.5 bg-neutral-50 rounded-xl border border-neutral-200">
            <h4 className="font-bold text-neutral-900 text-xs uppercase tracking-wider">
              Opción 2: Generar APK en la nube con PWABuilder
            </h4>
            <p className="text-xs text-neutral-600 leading-relaxed">
              1. Despliega esta aplicación en Google Cloud Run o tu servidor web.<br />
              2. Ingresa a <strong>pwabuilder.com</strong> y pega el enlace web.<br />
              3. Haz clic en "Package for Android" para descargar el archivo <code>.apk</code> firmado listo para instalar en cualquier teléfono o subir a Google Play Store.
            </p>
          </div>
        </div>
      )}

      {activeTab === 'firebase' && (
        <div className="space-y-3 text-xs sm:text-sm text-neutral-700">
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-950 space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-xs text-amber-800">
              <Flame className="w-4 h-4 text-orange-600 shrink-0" />
              <span>Estructura Preparada para Firebase Firestore</span>
            </div>
            <p className="text-[11px] text-amber-800 leading-relaxed">
              Todo el acceso a datos está centralizado en <code>src/services/storage.ts</code> mediante funciones asíncronas limpias con esquemas TypeScript en <code>src/types.ts</code>.
            </p>
          </div>

          <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-200 space-y-2">
            <h4 className="font-bold text-xs uppercase text-neutral-800">
              Colecciones diseñadas para Firestore:
            </h4>
            <ul className="list-disc pl-4 space-y-1 text-xs text-neutral-600">
              <li><code>users</code>: Credenciales, rol (ADMIN / EMPLEADO), área, turno.</li>
              <li><code>workAreas</code>: Áreas de trabajo del restaurante.</li>
              <li><code>taskTemplates</code>: Catálogo de tareas maestras creadas por el admin.</li>
              <li><code>taskRecords</code>: Ejecuciones diarias con nombre de empleado, hora y motivos.</li>
              <li><code>shortages</code>: Faltantes reportados y estado (Pendiente / Comprado).</li>
              <li><code>shiftHandovers</code>: Cierres de turno con resumen y observaciones.</li>
              <li><code>activityLogs</code>: Trazabilidad cronológica completa para gerencia.</li>
            </ul>
          </div>
        </div>
      )}

      <div className="pt-2 flex justify-end">
        <button
          onClick={onClose}
          className="px-5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs active:scale-95 transition-all"
        >
          Entendido
        </button>
      </div>
    </Modal>
  );
};
