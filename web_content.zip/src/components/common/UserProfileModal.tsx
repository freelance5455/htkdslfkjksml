import React, { useState, useRef } from 'react';
import {
  User,
  Mail,
  Phone,
  Building2,
  Shield,
  Camera,
  Trash2,
  Lock,
  Bell,
  Check,
  AlertCircle,
  X,
  Save,
  CheckCircle2,
  Smartphone,
  ShieldAlert,
  KeyRound,
} from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { compressAndCropProfileImage } from '../../utils/imageCompressor.ts';
import { removeUndefinedFields } from '../../utils/firestoreHelper.ts';
import { AuditLogEntry } from '../../types/index.ts';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, currentEmployee, currentOrg } = useAuth();

  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'notifications'>('profile');

  // Form Fields
  const [displayName, setDisplayName] = useState(userProfile?.displayName || currentEmployee?.name || '');
  const [phone, setPhone] = useState(userProfile?.phone || currentEmployee?.phone || '');
  const [emergencyContact, setEmergencyContact] = useState(currentEmployee?.emergencyContact || '');
  const [avatarUrl, setAvatarUrl] = useState(userProfile?.avatarUrl || currentEmployee?.avatarUrl || '');

  // Password / Security State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Notification Preferences State
  const [notifAttendance, setNotifAttendance] = useState(true);
  const [notifVisits, setNotifVisits] = useState(true);
  const [notifTasks, setNotifTasks] = useState(true);
  const [notifMessages, setNotifMessages] = useState(true);

  // Status feedback
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen || !userProfile) return null;

  // Handle Photo Upload
  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg(null);
    setIsUploadingPhoto(true);

    try {
      const result = await compressAndCropProfileImage(file, 256, 0.82);
      setAvatarUrl(result.dataUrl);
      setSaveSuccessMsg('New profile photo selected. Click Save Changes to commit.');
      setTimeout(() => setSaveSuccessMsg(null), 4000);
    } catch (err: any) {
      console.error('Image compression error:', err);
      setErrorMsg(err?.message || 'Failed to process image.');
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = () => {
    setAvatarUrl('');
    setSaveSuccessMsg('Profile photo removed. Click Save Changes to commit.');
    setTimeout(() => setSaveSuccessMsg(null), 4000);
  };

  // Save Profile Changes
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsSaving(true);

    try {
      // 1. Update User Profile in Firestore
      const userDocRef = doc(db, 'users', userProfile.id);
      const updatedUserPayload = {
        ...userProfile,
        displayName: displayName.trim() || userProfile.displayName,
        phone: phone.trim(),
        avatarUrl: avatarUrl.trim(),
        updatedAt: new Date().toISOString(),
      };
      await setDoc(userDocRef, removeUndefinedFields(updatedUserPayload), { merge: true });

      // 2. If user is tied to an Employee record, update Employee as well
      if (userProfile.employeeId || currentEmployee?.id) {
        const empId = userProfile.employeeId || currentEmployee?.id;
        if (empId) {
          const empDocRef = doc(db, 'employees', empId);
          const updatedEmpPayload = {
            name: displayName.trim() || userProfile.displayName,
            phone: phone.trim(),
            emergencyContact: emergencyContact.trim(),
            avatarUrl: avatarUrl.trim(),
            updatedAt: new Date().toISOString(),
          };
          await setDoc(empDocRef, removeUndefinedFields(updatedEmpPayload), { merge: true });
        }
      }

      // 3. Log Audit Entry
      if (currentOrg) {
        const auditLog: AuditLogEntry = {
          id: `aud_prof_${Date.now()}`,
          orgId: currentOrg.id,
          userId: userProfile.id,
          userName: displayName.trim() || userProfile.displayName,
          action: 'Profile Update',
          module: 'Profile',
          details: `User updated profile contact details and photo.`,
          timestamp: new Date().toISOString(),
        };
        await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));
      }

      setSaveSuccessMsg('Profile updated successfully!');
      setTimeout(() => {
        setSaveSuccessMsg(null);
      }, 3000);
    } catch (err: any) {
      console.error('Error saving profile:', err);
      setErrorMsg(err?.message || 'Failed to update profile. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  // Save Security Settings
  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (newPassword && newPassword !== confirmPassword) {
      setErrorMsg('New password and confirmation do not match.');
      return;
    }

    if (newPassword && newPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }

    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setSaveSuccessMsg('Security credentials updated successfully.');
      setTimeout(() => setSaveSuccessMsg(null), 3500);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-0">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-400/30 flex items-center justify-center font-bold">
              <User className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Account & Profile Settings</h3>
              <p className="text-[11px] text-slate-400">
                {currentOrg?.name || 'FieldFlow'} • {userProfile.role.replace(/_/g, ' ').toUpperCase()}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 text-xs font-bold text-slate-600 shrink-0">
          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'profile'
                ? 'border-sky-600 text-sky-600 font-black'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Profile & DP</span>
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'security'
                ? 'border-sky-600 text-sky-600 font-black'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>Security & Password</span>
          </button>
          <button
            onClick={() => setActiveTab('notifications')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'notifications'
                ? 'border-sky-600 text-sky-600 font-black'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Preferences</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Feedback Banners */}
          {saveSuccessMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-in fade-in-0">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{saveSuccessMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2 animate-in fade-in-0">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* TAB 1: PROFILE & DP */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
              {/* Profile Photo / DP Section */}
              <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/jpeg,image/png,image/webp,image/jpg"
                  onChange={handlePhotoSelect}
                  className="hidden"
                />

                <div className="relative group">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-black text-2xl flex items-center justify-center shadow-md overflow-hidden border-2 border-white">
                    {avatarUrl ? (
                      <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      displayName.charAt(0) || userProfile.email.charAt(0).toUpperCase()
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingPhoto}
                    className="absolute -bottom-1 -right-1 p-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl shadow-md border-2 border-white transition-all active:scale-95"
                    title="Change Profile Photo"
                  >
                    <Camera className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex-1 text-center sm:text-left space-y-1">
                  <div className="font-bold text-slate-800 text-sm">Profile Photo / Display Picture</div>
                  <p className="text-[11px] text-slate-500">
                    Upload JPG, PNG, or WebP image. Automatically optimized and cropped to 256x256 thumbnail.
                  </p>
                  <div className="flex items-center gap-2 pt-1 justify-center sm:justify-start">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploadingPhoto}
                      className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg font-bold text-[11px] transition-colors"
                    >
                      {isUploadingPhoto ? 'Processing...' : 'Upload New DP'}
                    </button>
                    {avatarUrl && (
                      <button
                        type="button"
                        onClick={handleRemovePhoto}
                        className="px-2 py-1 text-rose-600 hover:bg-rose-50 rounded-lg font-bold text-[11px] flex items-center gap-1 transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Remove</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Editable User Contact Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Full Name</label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Mobile Phone</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 555-0100"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Emergency Contact</label>
                  <input
                    type="text"
                    value={emergencyContact}
                    onChange={(e) => setEmergencyContact(e.target.value)}
                    placeholder="Name (+1 555-0911)"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Email Address (Sign-In)</label>
                  <input
                    type="email"
                    value={userProfile.email}
                    disabled
                    className="w-full px-3 py-2 bg-slate-100 border border-slate-200 text-slate-500 rounded-xl cursor-not-allowed"
                  />
                </div>
              </div>

              {/* Admin-Controlled Corporate Metadata (Read-Only to Employee) */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-slate-500" />
                    <span>Organization & Workforce Record</span>
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Admin Controlled
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] pt-1">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Employee ID</span>
                    <strong className="text-slate-800 font-mono">
                      {currentEmployee?.employeeCode || userProfile.employeeId || 'N/A'}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Department</span>
                    <strong className="text-slate-800">{currentEmployee?.department || 'Operations'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Designation</span>
                    <strong className="text-slate-800">{currentEmployee?.designation || userProfile.role.replace(/_/g, ' ')}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Status</span>
                    <strong className="text-emerald-700 capitalize font-bold">
                      {currentEmployee?.status || 'Active'}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Submit */}
              <div className="pt-3 border-t border-slate-200 flex justify-end">
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-2 shadow-xs transition-colors"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? 'Saving...' : 'Save Profile Changes'}</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 2: SECURITY & PASSWORD */}
          {activeTab === 'security' && (
            <form onSubmit={handleSaveSecurity} className="space-y-4 text-xs">
              <div className="p-3.5 rounded-2xl bg-sky-50 border border-sky-200 text-sky-900 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-sky-600" />
                  <span>Security & Authentication</span>
                </div>
                <p className="text-[11px] text-sky-800">
                  Update your account password or configure multi-factor re-authentication for sensitive actions.
                </p>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Current Password</label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Enter existing password"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">New Password</label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Confirm New Password</label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end">
                <button
                  type="submit"
                  disabled={isSaving || !newPassword}
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold rounded-xl flex items-center gap-2 shadow-xs transition-colors"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>{isSaving ? 'Updating...' : 'Update Password'}</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: NOTIFICATION PREFERENCES */}
          {activeTab === 'notifications' && (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-slate-700 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-slate-900">
                  <Bell className="w-4 h-4 text-sky-600" />
                  <span>Workforce Notification Channels</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Select which notifications are pushed to your mobile device and dashboard.
                </p>
              </div>

              <div className="space-y-2">
                {[
                  {
                    id: 'att',
                    title: 'Shift Attendance & Check-In Reminders',
                    desc: 'Alerts at scheduled shift start times and missing checkout warnings',
                    checked: notifAttendance,
                    setter: setNotifAttendance,
                  },
                  {
                    id: 'vis',
                    title: 'Field Visit Assignments & Schedule Changes',
                    desc: 'Instant updates when new customer visits are assigned or dispatched',
                    checked: notifVisits,
                    setter: setNotifVisits,
                  },
                  {
                    id: 'tsk',
                    title: 'Task Orders & Overdue Deadlines',
                    desc: 'Notifications when tasks approach their scheduled due date',
                    checked: notifTasks,
                    setter: setNotifTasks,
                  },
                  {
                    id: 'msg',
                    title: 'Direct Messages & Dispatch Alerts',
                    desc: 'Real-time messages from operations managers and colleagues',
                    checked: notifMessages,
                    setter: setNotifMessages,
                  },
                ].map((item) => (
                  <div
                    key={item.id}
                    onClick={() => item.setter(!item.checked)}
                    className="p-3 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer flex items-center justify-between gap-3 transition-colors"
                  >
                    <div>
                      <div className="font-bold text-slate-800">{item.title}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{item.desc}</div>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center text-white text-xs font-bold transition-colors shrink-0 ${
                        item.checked ? 'bg-sky-600' : 'bg-slate-200'
                      }`}
                    >
                      {item.checked && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setSaveSuccessMsg('Notification preferences saved.');
                    setTimeout(() => setSaveSuccessMsg(null), 3000);
                  }}
                  className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl flex items-center gap-2 shadow-xs transition-colors"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Preferences</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
