import React, { useEffect, useState } from 'react';
import { audioEngine } from '../../services/audioEngine';

interface EqualizerAnimationProps {
  isPlaying: boolean;
  barsCount?: number;
  height?: number;
  color?: string;
  className?: string;
  mode?: 'bars' | 'wave';
}

export const EqualizerAnimation: React.FC<EqualizerAnimationProps> = ({
  isPlaying,
  barsCount = 5,
  height = 16,
  color = 'bg-purple-500',
  className = '',
  mode = 'bars'
}) => {
  const [frequencyLevels, setFrequencyLevels] = useState<number[]>(
    () => Array(barsCount).fill(15)
  );

  useEffect(() => {
    if (!isPlaying) {
      setFrequencyLevels(Array(barsCount).fill(12));
      return;
    }

    let animationFrameId: number;

    const update = () => {
      const freqData = audioEngine.getFrequencyData();
      if (freqData && freqData.length > 0) {
        const step = Math.floor(freqData.length / barsCount);
        const newLevels = [];
        for (let i = 0; i < barsCount; i++) {
          const val = freqData[i * step] || 0;
          // Scale 0-255 to percentage 15% - 100%
          const pct = Math.max(15, Math.min(100, Math.round((val / 255) * 100)));
          newLevels.push(pct);
        }
        setFrequencyLevels(newLevels);
      } else {
        // Fallback procedural lively bounce
        const procedural = Array.from({ length: barsCount }, (_, idx) => {
          const time = Date.now() / 150;
          const sine = Math.sin(time + idx * 0.7);
          return Math.round(30 + Math.abs(sine) * 65);
        });
        setFrequencyLevels(procedural);
      }

      animationFrameId = requestAnimationFrame(update);
    };

    animationFrameId = requestAnimationFrame(update);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, barsCount]);

  if (mode === 'wave') {
    return (
      <div className={`flex items-center gap-[3px] h-${height} ${className}`}>
        {frequencyLevels.map((lvl, i) => (
          <div
            key={i}
            className={`w-1 rounded-full transition-all duration-75 ${color}`}
            style={{
              height: `${(lvl / 100) * height}px`,
              opacity: isPlaying ? 0.9 : 0.35
            }}
          />
        ))}
      </div>
    );
  }

  return (
    <div
      className={`flex items-end gap-[2px] ${className}`}
      style={{ height: `${height}px` }}
    >
      {frequencyLevels.map((lvl, i) => (
        <span
          key={i}
          className={`w-[3px] rounded-full transition-all duration-100 ${color}`}
          style={{
            height: isPlaying ? `${Math.max(4, (lvl / 100) * height)}px` : '4px',
            opacity: isPlaying ? 1 : 0.4
          }}
        />
      ))}
    </div>
  );
};
