import React from 'react';
import { Modal } from './Modal';
import { User } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { ShieldCheck, User as UserIcon, Check } from 'lucide-react';

interface UserSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
}

export const UserSwitcherModal: React.FC<UserSwitcherModalProps> = ({
  isOpen,
  onClose,
  users,
}) => {
  const { currentUser, quickLogin } = useAuth();

  const handleSelectUser = (u: User) => {
    quickLogin(u);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Cambiar de Usuario (Pruebas)"
      subtitle="Prueba los diferentes roles, turnos y permisos con un solo toque"
    >
      <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
        {users.map((u) => {
          const isSelected = currentUser?.id === u.id;
          const isAdmin = u.role === 'ADMIN';

          return (
            <button
              key={u.id}
              onClick={() => handleSelectUser(u)}
              className={`w-full p-3 rounded-xl border flex items-center justify-between text-left transition-all active:scale-[0.99] ${
                isSelected
                  ? 'border-orange-500 bg-orange-50/80 ring-2 ring-orange-500/20'
                  : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
                    isAdmin
                      ? 'bg-amber-500 text-neutral-900'
                      : 'bg-neutral-200 text-neutral-700'
                  }`}
                >
                  {isAdmin ? <ShieldCheck className="w-5 h-5" /> : u.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-bold text-neutral-900 flex items-center gap-1.5">
                    <span>{u.name}</span>
                    <span
                      className={`text-[10px] font-black uppercase px-1.5 py-0.5 rounded ${
                        isAdmin
                          ? 'bg-amber-100 text-amber-900'
                          : 'bg-neutral-100 text-neutral-600'
                      }`}
                    >
                      {u.role}
                    </span>
                  </div>
                  <div className="text-xs text-neutral-500">
                    {u.areaName || 'Área'} • <span className="font-semibold text-orange-600">{u.shift}</span>
                  </div>
                </div>
              </div>

              {isSelected && (
                <div className="w-6 h-6 rounded-full bg-orange-600 text-white flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                </div>
              )}
            </button>
          );
        })}
      </div>
    </Modal>
  );
};
