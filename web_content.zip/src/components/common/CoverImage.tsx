import React, { useState } from 'react';
import { BookOpen } from 'lucide-react';

interface CoverImageProps {
  url?: string;
  title: string;
  author: string;
  className?: string;
  aspectRatio?: 'book' | 'square';
  showShadow?: boolean;
}

export const CoverImage: React.FC<CoverImageProps> = ({
  url,
  title,
  author,
  className = '',
  aspectRatio = 'book',
  showShadow = true,
}) => {
  const [hasError, setHasError] = useState(false);

  // Generate consistent subtle gradient for placeholder based on title hash
  const getPlaceholderGradient = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hues = [
      'from-zinc-950 to-neutral-900 border-zinc-800/60',
      'from-neutral-900 via-zinc-950 to-black border-zinc-700/40',
      'from-[#0d0e12] via-[#17181f] to-[#090a0d] border-white/10',
      'from-zinc-900 via-neutral-900 to-zinc-950 border-white/10',
    ];
    return hues[Math.abs(hash) % hues.length];
  };

  const ratioClass = aspectRatio === 'book' ? 'aspect-[2/3]' : 'aspect-square';
  const shadowClass = showShadow ? 'shadow-[0_12px_24px_-6px_rgba(0,0,0,0.6)]' : '';

  if (!url || hasError) {
    return (
      <div
        className={`relative ${ratioClass} w-full rounded-lg overflow-hidden bg-gradient-to-br ${getPlaceholderGradient(
          title
        )} border flex flex-col justify-between p-3.5 select-none ${shadowClass} ${className}`}
      >
        {/* Subtle glass reflection overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-white/[0.04] to-transparent pointer-events-none" />
        <div className="absolute top-0 bottom-0 left-1.5 w-[3px] bg-white/[0.08] pointer-events-none" />

        <div className="relative z-10 flex items-center justify-between">
          <BookOpen className="w-4 h-4 text-white/40" />
          <span className="text-[10px] uppercase tracking-wider font-semibold text-white/30">Libro</span>
        </div>

        <div className="relative z-10 my-auto text-center py-2">
          <h4 className="font-semibold text-xs text-white/90 line-clamp-3 leading-snug">{title}</h4>
          <p className="text-[11px] text-white/50 line-clamp-1 mt-1 font-medium">{author}</p>
        </div>

        <div className="relative z-10 flex justify-center">
          <div className="h-0.5 w-6 bg-white/20 rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className={`relative ${ratioClass} w-full rounded-lg overflow-hidden ${shadowClass} ${className} bg-zinc-950`}>
      <img
        src={url}
        alt={`Portada de ${title}`}
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={() => setHasError(true)}
        className="w-full h-full object-cover select-none transition-transform duration-300 hover:scale-[1.02]"
      />
      {/* Book spine highlight shine */}
      <div className="absolute top-0 bottom-0 left-0 w-2.5 bg-gradient-to-r from-black/50 via-white/10 to-transparent pointer-events-none" />
      {/* Right page-turn edge highlight */}
      <div className="absolute top-0 bottom-0 right-0 w-[1.5px] bg-white/15 pointer-events-none" />
      {/* Top subtle rim light */}
      <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
      <div className="absolute inset-0 border border-white/10 rounded-lg pointer-events-none" />
    </div>
  );
};
