import React, { useEffect, useState } from 'react';
import { Bell, Check, X, Info, CheckCircle2, Clock, Award, MessageSquare, UserPlus, ShieldAlert, ArrowRight } from 'lucide-react';
import { collection, query, where, getDocs, doc, updateDoc, writeBatch } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { NotificationItem } from '../../types/index.ts';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAction?: (tab: string) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({ isOpen, onClose, onSelectAction }) => {
  const { userProfile, currentOrg, isPlatformOwner, isAdmin } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchNotifications = async () => {
    if (!userProfile) return;
    setLoading(true);
    try {
      const list: NotificationItem[] = [];
      const seenIds = new Set<string>();

      // 1. Fetch personal notifications directly addressed to user
      const userQ = query(
        collection(db, 'notifications'),
        where('userId', '==', userProfile.id)
      );
      const userSnap = await getDocs(userQ);
      userSnap.forEach((d) => {
        if (!seenIds.has(d.id)) {
          seenIds.add(d.id);
          list.push(d.data() as NotificationItem);
        }
      });

      // 2. If Admin, also fetch org-scoped admin notifications
      if (isAdmin && currentOrg) {
        const [adminRoleSnap, adminUserSnap] = await Promise.all([
          getDocs(query(collection(db, 'notifications'), where('orgId', '==', currentOrg.id), where('targetRole', '==', 'org_admin'))),
          getDocs(query(collection(db, 'notifications'), where('orgId', '==', currentOrg.id), where('userId', '==', 'admin'))),
        ]);

        adminRoleSnap.forEach((d) => {
          if (!seenIds.has(d.id)) {
            seenIds.add(d.id);
            list.push(d.data() as NotificationItem);
          }
        });
        adminUserSnap.forEach((d) => {
          if (!seenIds.has(d.id)) {
            seenIds.add(d.id);
            list.push(d.data() as NotificationItem);
          }
        });
      }

      // 3. If Platform Owner, also fetch platform-level notifications
      if (isPlatformOwner) {
        const ownerSnap = await getDocs(
          query(collection(db, 'notifications'), where('targetRole', '==', 'platform_owner'))
        );
        ownerSnap.forEach((d) => {
          if (!seenIds.has(d.id)) {
            seenIds.add(d.id);
            list.push(d.data() as NotificationItem);
          }
        });
      }

      list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setNotifications(list);
    } catch (e) {
      console.error('Error fetching notifications:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchNotifications();
    }
  }, [isOpen, userProfile, currentOrg]);

  const markItemAsRead = async (item: NotificationItem) => {
    if (item.read) return;
    try {
      await updateDoc(doc(db, 'notifications', item.id), { read: true });
      setNotifications((prev) =>
        prev.map((n) => (n.id === item.id ? { ...n, read: true } : n))
      );
    } catch (err) {
      console.warn('Error marking notification as read:', err);
    }
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter((n) => !n.read);
    if (unread.length === 0) return;

    try {
      const batch = writeBatch(db);
      unread.forEach((n) => {
        batch.update(doc(db, 'notifications', n.id), { read: true });
      });
      await batch.commit();

      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    } catch (err) {
      console.warn('Error marking all as read in Firestore:', err);
      // Fallback local update
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    }
  };

  const handleNotificationClick = async (item: NotificationItem) => {
    await markItemAsRead(item);
    if (item.linkTab && onSelectAction) {
      onSelectAction(item.linkTab);
      onClose();
    }
  };

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-end p-4 pt-16 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm border border-slate-200 overflow-hidden animate-in fade-in-0 duration-150">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Bell className="w-4 h-4 text-sky-600" />
              {unreadCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-rose-500 absolute -top-0.5 -right-0.5 animate-pulse" />
              )}
            </div>
            <span className="font-bold text-sm text-slate-800">Notifications</span>
            {unreadCount > 0 && (
              <span className="px-1.5 py-0.2 bg-rose-100 text-rose-700 text-[10px] font-bold rounded-full">
                {unreadCount} new
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="text-xs text-sky-600 hover:text-sky-800 font-semibold"
              >
                Mark all read
              </button>
            )}
            <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="max-h-[420px] overflow-y-auto divide-y divide-slate-100 p-2 space-y-1">
          {loading ? (
            <div className="py-8 text-center text-xs text-slate-500">Loading alerts...</div>
          ) : notifications.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400 space-y-1">
              <CheckCircle2 className="w-6 h-6 text-slate-300 mx-auto" />
              <div className="font-semibold text-slate-600">All caught up!</div>
              <div>No new notifications for your account.</div>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                onClick={() => handleNotificationClick(item)}
                className={`p-3 rounded-xl text-left transition-all cursor-pointer ${
                  item.read
                    ? 'bg-white hover:bg-slate-50 opacity-80'
                    : 'bg-sky-50/70 hover:bg-sky-100/70 border border-sky-100 font-medium shadow-2xs'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="mt-0.5 shrink-0">
                    {item.type === 'award' ? (
                      <Award className="w-4 h-4 text-amber-500" />
                    ) : item.type === 'visit' ? (
                      <Clock className="w-4 h-4 text-sky-600" />
                    ) : item.type === 'join_request' ? (
                      <UserPlus className="w-4 h-4 text-purple-600" />
                    ) : item.type === 'message' ? (
                      <MessageSquare className="w-4 h-4 text-emerald-600" />
                    ) : item.type === 'owner' ? (
                      <ShieldAlert className="w-4 h-4 text-indigo-600" />
                    ) : (
                      <Info className="w-4 h-4 text-slate-500" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-bold text-slate-900 truncate">{item.title}</span>
                      <span className="text-[10px] text-slate-400 shrink-0 font-normal">
                        {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5 leading-relaxed">{item.message}</div>
                    {item.linkTab && (
                      <div className="mt-1 flex items-center gap-1 text-[10px] text-sky-600 font-bold">
                        <span>View details</span>
                        <ArrowRight className="w-2.5 h-2.5" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
