import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Smartphone, Mail, KeyRound, CheckCircle2, UserCheck, ShieldCheck } from 'lucide-react';
import { UserRole } from '../../types';

export const AuthModal: React.FC = () => {
  const { isAuthOpen, setIsAuthOpen, user, setUser, switchRoleQuickly } = useApp();
  const [authMode, setAuthMode] = useState<'phone' | 'email'>('phone');
  const [phone, setPhone] = useState('+91 98765 43210');
  const [email, setEmail] = useState('aarav.sharma@example.com');
  const [fullName, setFullName] = useState('Aarav Sharma');
  const [otpStep, setOtpStep] = useState(false);
  const [otpInput, setOtpInput] = useState('1234');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isAuthOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpStep(true);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('Logged in successfully!');
    setUser({
      ...user,
      name: fullName || 'User',
      phone: authMode === 'phone' ? phone : user.phone,
      email: authMode === 'email' ? email : user.email
    });
    setTimeout(() => {
      setSuccessMsg('');
      setIsAuthOpen(false);
      setOtpStep(false);
    }, 1200);
  };

  const testAccounts = [
    { role: 'customer' as UserRole, name: 'Aarav Sharma (Customer)', desc: 'Order food, grocery, cabs, services' },
    { role: 'provider' as UserRole, name: 'Rajesh Verma (Electrician Provider)', desc: 'Manage jobs, availability, custom catalog' },
    { role: 'delivery' as UserRole, name: 'Vikram Singh (Delivery Rider)', desc: 'Pick up orders, live GPS route, delivery OTP' },
    { role: 'admin' as UserRole, name: 'Super Admin (Owner)', desc: 'Commissions, withdrawals, chat rules & safety' }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white text-slate-900 rounded-3xl border border-slate-200 max-w-sm w-full p-5 shadow-2xl relative overflow-hidden">
        <button
          onClick={() => setIsAuthOpen(false)}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 rounded-full bg-slate-100"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white font-black text-xl flex items-center justify-center mx-auto mb-2 shadow-md">
            A
          </div>
          <h3 className="text-lg font-bold text-slate-900">AllJi Login & Sign Up</h3>
          <p className="text-xs text-slate-500">Sab Kuch, Ek Hi Jagah</p>
        </div>

        {successMsg ? (
          <div className="py-8 text-center">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2 animate-bounce" />
            <p className="font-bold text-slate-900">{successMsg}</p>
          </div>
        ) : (
          <>
            {/* Quick 1-Click Role Switch */}
            <div className="mb-4 p-3 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                1-Click Demo Accounts
              </span>
              <div className="space-y-1.5">
                {testAccounts.map(acc => (
                  <button
                    key={acc.role}
                    onClick={() => {
                      switchRoleQuickly(acc.role);
                      setIsAuthOpen(false);
                    }}
                    className="w-full text-left p-2 rounded-xl bg-white hover:bg-amber-50/80 border border-slate-200 hover:border-amber-300 transition-all flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-bold text-slate-900">{acc.name}</p>
                      <p className="text-[10px] text-slate-500">{acc.desc}</p>
                    </div>
                    <span className="text-[10px] font-bold text-amber-600 px-2 py-0.5 rounded-full bg-amber-50">
                      Login
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Phone / Email Input */}
            {!otpStep ? (
              <form onSubmit={handleSendOtp} className="space-y-3">
                <div className="flex rounded-xl bg-slate-100 p-1">
                  <button
                    type="button"
                    onClick={() => setAuthMode('phone')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                      authMode === 'phone' ? 'bg-white shadow-xs text-slate-900' : 'text-slate-500'
                    }`}
                  >
                    Phone OTP
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuthMode('email')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                      authMode === 'email' ? 'bg-white shadow-xs text-slate-900' : 'text-slate-500'
                    }`}
                  >
                    Email
                  </button>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block mb-1">Full Name</label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                {authMode === 'phone' ? (
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">Mobile Number</label>
                    <div className="relative flex items-center">
                      <Smartphone className="w-4 h-4 text-slate-400 absolute left-3" />
                      <input
                        type="tel"
                        value={phone}
                        onChange={e => setPhone(e.target.value)}
                        placeholder="+91 XXXXX XXXXX"
                        required
                        className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:border-amber-500"
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">Email Address</label>
                    <div className="relative flex items-center">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3" />
                      <input
                        type="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        placeholder="you@domain.com"
                        required
                        className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:border-amber-500"
                      />
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-md transition-all"
                >
                  Continue & Send OTP
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3">
                <div className="p-3 bg-amber-50 rounded-xl text-center">
                  <p className="text-xs text-amber-900 font-semibold">Enter 4-digit code sent to {phone}</p>
                  <p className="text-[10px] text-amber-700 mt-0.5">Demo OTP is prefilled as 1234</p>
                </div>

                <div>
                  <div className="relative flex items-center">
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3" />
                    <input
                      type="text"
                      maxLength={4}
                      value={otpInput}
                      onChange={e => setOtpInput(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-sm font-bold tracking-widest text-center focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setOtpStep(false)}
                    className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-2 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs"
                  >
                    Verify & Login
                  </button>
                </div>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
};
