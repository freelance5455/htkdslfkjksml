import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import {
  Bell,
  WifiOff,
  ShieldCheck,
  Smartphone,
  Tablet,
  Monitor,
  Sparkles,
  Check
} from 'lucide-react';

interface TopAppBarProps {
  deviceView: 'mobile' | 'tablet' | 'responsive';
  setDeviceView: (view: 'mobile' | 'tablet' | 'responsive') => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({ deviceView, setDeviceView }) => {
  const {
    user,
    setActiveTab,
    offlineMode,
    setOfflineMode,
    setIsAdminOpen,
    activeTab
  } = useMusic();

  const [showNotifications, setShowNotifications] = useState(false);

  // Time based greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const notifications = [
    {
      id: '1',
      title: 'New Bengali Acoustic Track',
      desc: 'Anupam Roy just released a remastered edition.',
      time: '10m ago',
      unread: true
    },
    {
      id: '2',
      title: 'Weekly Radar Ready',
      desc: 'Updated for your personalized listening habits.',
      time: '2h ago',
      unread: true
    },
    {
      id: '3',
      title: 'Offline Sync Complete',
      desc: 'Your selected favorite tracks are ready for offline play.',
      time: 'Yesterday',
      unread: false
    }
  ];

  return (
    <header className="sticky top-0 z-30 w-full backdrop-blur-xl bg-[#0b0c10]/85 dark:bg-[#0b0c10]/85 border-b border-white/[0.06] px-4 py-2.5 transition-colors">
      <div className="flex items-center justify-between gap-3 max-w-7xl mx-auto">
        {/* Left: Brand & Greeting */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2 text-left focus:outline-none group shrink-0"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 flex items-center justify-center shadow-md shadow-purple-500/25 group-hover:scale-105 transition-transform">
              <span className="font-display font-black text-white text-base tracking-tighter">ME</span>
            </div>
            <div className="hidden sm:block">
              <span className="font-display font-extrabold text-base tracking-tight bg-gradient-to-r from-white via-purple-100 to-pink-200 bg-clip-text text-transparent">
                Music Express
              </span>
            </div>
          </button>

          {activeTab === 'home' && (
            <div className="border-l border-white/10 pl-3 hidden min-[480px]:block truncate">
              <p className="text-xs text-slate-400 font-medium truncate">
                {getGreeting()}, <span className="text-slate-100 font-semibold">{user.name.split(' ')[0]}</span>
              </p>
            </div>
          )}
        </div>

        {/* Center: Device Frame Switcher (for previewing responsive Android phone / tablet / fluid) */}
        <div className="hidden md:flex items-center gap-1 bg-white/[0.04] p-1 rounded-xl border border-white/[0.08]">
          <button
            onClick={() => setDeviceView('mobile')}
            title="Mobile Android View (400px)"
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
              deviceView === 'mobile'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="text-[11px]">Phone</span>
          </button>
          <button
            onClick={() => setDeviceView('tablet')}
            title="Tablet Android View (768px)"
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
              deviceView === 'tablet'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="text-[11px]">Tablet</span>
          </button>
          <button
            onClick={() => setDeviceView('responsive')}
            title="Fluid View (100% width)"
            className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
              deviceView === 'responsive'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span className="text-[11px]">Fluid</span>
          </button>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Offline Mode indicator toggle */}
          {offlineMode && (
            <button
              onClick={() => setOfflineMode(false)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-medium active:scale-95 transition-transform"
              title="Offline mode is active. Tap to turn off."
            >
              <WifiOff className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Offline</span>
            </button>
          )}

          {/* Admin Dashboard button */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="p-2 rounded-xl text-slate-300 hover:text-purple-400 hover:bg-white/[0.06] transition-colors relative"
            title="Admin Dashboard"
          >
            <ShieldCheck className="w-4 h-4" />
          </button>

          {/* Notifications Button */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/[0.06] transition-colors relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-pink-500 ring-2 ring-[#0b0c10]" />
            </button>

            {/* Notification Dropdown Panel */}
            {showNotifications && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowNotifications(false)}
                />
                <div className="absolute right-0 mt-2 w-80 rounded-2xl glass-panel p-3 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between pb-2 border-b border-white/[0.08] mb-2 px-1">
                    <span className="font-semibold text-xs tracking-wide uppercase text-slate-400">
                      Notifications
                    </span>
                    <button
                      onClick={() => setShowNotifications(false)}
                      className="text-[11px] text-purple-400 hover:underline"
                    >
                      Clear all
                    </button>
                  </div>
                  <div className="space-y-2">
                    {notifications.map((n) => (
                      <div
                        key={n.id}
                        className={`p-2.5 rounded-xl transition-colors ${
                          n.unread ? 'bg-purple-950/30 border border-purple-500/20' : 'bg-white/[0.03]'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
                          <span className="truncate">{n.title}</span>
                          <span className="text-[10px] text-slate-400 font-normal shrink-0">{n.time}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">
                          {n.desc}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Profile Avatar */}
          <button
            onClick={() => setActiveTab('profile')}
            className={`w-8 h-8 rounded-full p-0.5 transition-all ${
              activeTab === 'profile'
                ? 'ring-2 ring-purple-500 ring-offset-2 ring-offset-[#0b0c10]'
                : 'hover:scale-105'
            }`}
            title="Your Profile"
          >
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center font-bold text-white text-xs shadow-inner">
              {user.name[0]}
            </div>
          </button>
        </div>
      </div>
    </header>
  );
};
