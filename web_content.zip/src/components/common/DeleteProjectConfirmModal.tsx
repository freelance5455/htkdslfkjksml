import { Trash2, AlertTriangle, X } from "lucide-react";

interface DeleteProjectConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  projectTitle: string;
  isDeleting?: boolean;
}

export function DeleteProjectConfirmModal({
  isOpen,
  onClose,
  onConfirm,
  projectTitle,
  isDeleting = false,
}: DeleteProjectConfirmModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div
        className="w-full max-w-md rounded-2xl bg-studio-surface border border-rose-500/30 p-6 shadow-2xl shadow-rose-950/40 relative space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-studio-text-muted hover:text-studio-text hover:bg-studio-panel transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center shrink-0 text-rose-400">
            <Trash2 className="w-6 h-6" />
          </div>
          <div className="space-y-1 pr-6">
            <h3 className="text-lg font-bold text-studio-text font-display">
              Apagar Projeto Definitivamente?
            </h3>
            <p className="text-xs text-studio-text-muted leading-relaxed">
              Esta ação removerá o projeto e todos os seus dados associados (roteiro, storyboard, prompts e mídias geradas).
            </p>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-studio-panel border border-studio-border text-xs text-studio-text">
          <span className="text-studio-text-muted block mb-1">Projeto a ser removido:</span>
          <span className="font-semibold text-rose-300 block truncate text-sm">
            {projectTitle || "Sem título"}
          </span>
        </div>

        <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>A remoção é permanente e não poderá ser desfeita.</span>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl border border-studio-border text-studio-text hover:bg-studio-panel text-xs font-semibold transition-all disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            type="button"
            id="btn-confirm-delete-project"
            onClick={onConfirm}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-rose-900/30 transition-all disabled:opacity-50"
          >
            <Trash2 className="w-4 h-4" />
            <span>{isDeleting ? "Apagando..." : "Sim, Apagar Projeto"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
