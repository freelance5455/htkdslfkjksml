import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Moon, Sun, Smartphone, Settings, Globe } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings }) => {
  const { settings, updateSettings, phoneFrameMode, togglePhoneFrameMode, triggerHaptic } = useApp();

  const toggleTheme = () => {
    triggerHaptic();
    const nextTheme = settings.theme === 'dark' ? 'light' : 'dark';
    updateSettings({ theme: nextTheme });
  };

  const toggleLanguage = () => {
    triggerHaptic();
    const nextLang = settings.language === 'en' ? 'ur' : 'en';
    updateSettings({ language: nextLang });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#006C4C] text-white shadow-md">
      {/* Android Style Status Bar / Top Strip */}
      <div className="flex items-center justify-between px-4 py-1 text-xs opacity-90 border-b border-emerald-600/40">
        <div className="flex items-center space-x-1.5">
          <span className="font-mono font-medium">100% OFFLINE CAPABLE</span>
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse"></span>
        </div>
        <div className="flex items-center space-x-2 text-[11px]">
          <span>Android Edition</span>
          <span>•</span>
          <span className="font-mono">v1.0.0</span>
        </div>
      </div>

      {/* Main App Bar */}
      <div className="flex items-center justify-between px-4 py-2.5">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center border border-white/20 shadow-inner">
            <ShieldCheck className="w-5 h-5 text-emerald-200" />
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight leading-tight flex items-center gap-1.5">
              <span>{settings.language === 'ur' ? 'پاکٹ ٹول کٹ' : 'Pocket Toolkit'}</span>
            </h1>
            <p className="text-[11px] text-emerald-100/90 leading-none">
              {settings.language === 'ur' ? 'سید سلمان مہدی' : 'Syed Salman Mehdi'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-1">
          {/* Language Toggle */}
          <button
            onClick={toggleLanguage}
            title="Switch Language (English / Urdu)"
            className="p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors flex items-center gap-1 text-xs font-medium"
          >
            <Globe className="w-4 h-4 text-emerald-200" />
            <span className="font-semibold uppercase text-[11px]">{settings.language}</span>
          </button>

          {/* Desktop/Phone Frame toggle */}
          <button
            onClick={togglePhoneFrameMode}
            title="Toggle Phone Frame Preview"
            className={`hidden md:flex p-2 rounded-lg transition-colors ${
              phoneFrameMode ? 'bg-white/20 text-white' : 'hover:bg-white/10 text-emerald-100'
            }`}
          >
            <Smartphone className="w-4 h-4" />
          </button>

          {/* Theme switcher */}
          <button
            onClick={toggleTheme}
            title="Toggle Theme"
            className="p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors text-emerald-100"
          >
            {settings.theme === 'dark' ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Settings modal trigger */}
          <button
            onClick={() => {
              triggerHaptic();
              onOpenSettings();
            }}
            title="App Settings"
            className="p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors text-emerald-100"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
