import React from 'react';
import { Film, Crown, Globe, RotateCcw, RotateCw, Download, ArrowLeft, Share2, CheckCircle2 } from 'lucide-react';
import { Language, translations } from '../../i18n/translations';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  isPremium: boolean;
  onOpenPremium: () => void;
  isInEditor?: boolean;
  projectName?: string;
  onBackToHome?: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
  onOpenExport?: () => void;
  onOpenShare?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  isPremium,
  onOpenPremium,
  isInEditor = false,
  projectName = '',
  onBackToHome,
  onUndo,
  onRedo,
  canUndo = false,
  canRedo = false,
  onOpenExport,
  onOpenShare,
}) => {
  const t = translations[language];

  return (
    <header className="w-full h-13 bg-neutral-950/95 backdrop-blur-xl border-b border-neutral-800/80 text-white px-3 sm:px-5 flex items-center justify-between z-30 select-none shrink-0 shadow-lg shadow-black/40">
      {/* Left: Brand / Studio Navigation */}
      <div className="flex items-center gap-3">
        {isInEditor ? (
          <button
            onClick={onBackToHome}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white transition-all text-xs font-semibold shadow-sm active:scale-95"
            title={t.back}
          >
            <ArrowLeft className="w-3.5 h-3.5 text-neutral-400 group-hover:text-white" />
            <span className="hidden sm:inline">{language === 'hi' ? 'मुख्य पृष्ठ' : 'Projects'}</span>
          </button>
        ) : null}

        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-orange-600 flex items-center justify-center shadow-md shadow-amber-500/25 ring-1 ring-white/20">
            <Film className="w-4 h-4 text-black stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm sm:text-base tracking-wider bg-gradient-to-r from-amber-200 via-amber-400 to-orange-400 bg-clip-text text-transparent">
                CLIPORA
              </span>
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 font-mono tracking-tight hidden sm:inline">
                STUDIO PRO
              </span>
            </div>
            {!isInEditor && (
              <p className="text-[10px] text-neutral-400 hidden xs:block">
                Professional Non-AI Video Editor • By Kamlesh Meena
              </p>
            )}
          </div>
        </div>

        {isInEditor && (
          <div className="hidden sm:flex items-center ml-2 pl-3 border-l border-neutral-800 gap-2">
            <span className="text-xs font-semibold text-neutral-200 max-w-[150px] md:max-w-[220px] truncate">
              {projectName || 'Untitled Master Project'}
            </span>
            <div className="flex items-center gap-1 text-[10px] text-emerald-400/90 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="hidden md:inline">{language === 'hi' ? 'सुरक्षित' : 'Saved'}</span>
            </div>
          </div>
        )}
      </div>

      {/* Center: Tactile Studio Undo / Redo */}
      {isInEditor && (
        <div className="flex items-center gap-1 bg-neutral-900/90 p-1 rounded-xl border border-neutral-800 shadow-inner">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-neutral-800 disabled:opacity-25 disabled:hover:bg-transparent text-neutral-300 hover:text-white transition-all text-[11px] font-medium"
            title={`${t.undo} (Ctrl+Z)`}
          >
            <RotateCcw className="w-3.5 h-3.5 text-neutral-400" />
            <span className="hidden md:inline text-[10px]">{t.undo}</span>
          </button>
          <div className="w-[1px] h-3.5 bg-neutral-800" />
          <button
            onClick={onRedo}
            disabled={!canRedo}
            className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-neutral-800 disabled:opacity-25 disabled:hover:bg-transparent text-neutral-300 hover:text-white transition-all text-[11px] font-medium"
            title={`${t.redo} (Ctrl+Y)`}
          >
            <RotateCw className="w-3.5 h-3.5 text-neutral-400" />
            <span className="hidden md:inline text-[10px]">{t.redo}</span>
          </button>
        </div>
      )}

      {/* Right: Language, Share, Premium & High-Visibility Export */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {/* Language switcher */}
        <button
          onClick={() => onLanguageChange(language === 'en' ? 'hi' : 'en')}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 text-xs font-semibold text-neutral-300 hover:text-white transition-all shadow-sm"
          title="Switch Language / भाषा बदलें"
        >
          <Globe className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-[11px]">{language === 'en' ? 'हिन्दी' : 'English'}</span>
        </button>

        {/* Share & APK button */}
        {onOpenShare && (
          <button
            onClick={onOpenShare}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 text-amber-300 hover:text-amber-200 text-xs font-semibold transition-all shadow-sm"
            title={language === 'hi' ? 'ऐप शेयर व APK डाउनलोड' : 'Share App & Download APK'}
          >
            <Share2 className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">
              {language === 'hi' ? 'APK / शेयर' : 'Share / APK'}
            </span>
          </button>
        )}

        {/* 100% Free Pro Badge (No Payment) */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold shadow-sm">
          <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span className="hidden md:inline font-mono text-[11px]">
            {language === 'hi' ? '100% मुफ़्त प्रो' : '100% Free Pro'}
          </span>
        </div>

        {/* Export Master Button inside editor */}
        {isInEditor && (
          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-xs shadow-lg shadow-amber-500/25 transition-all active:scale-95"
            title="Export master video (4K, 1080p, 60fps)"
          >
            <Download className="w-4 h-4 stroke-[3]" />
            <span className="tracking-wide uppercase">{language === 'hi' ? 'एक्सपोर्ट' : 'Export'}</span>
          </button>
        )}
      </div>
    </header>
  );
};
