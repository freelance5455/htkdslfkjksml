import React, { useState } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import { KARACHI_AREAS, OTHER_CITIES } from '../../utils/geo';
import {
  MapPin,
  Globe,
  Bell,
  UserCheck,
  ShieldCheck,
  Wrench,
  User as UserIcon,
  ChevronDown,
  Check,
  X,
  LogOut,
  LogIn,
  KeyRound,
  UserPlus,
} from 'lucide-react';
import { UserRole } from '../../types';

interface HeaderProps {
  activeView: string;
  setActiveView: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeView, setActiveView }) => {
  const {
    currentUser,
    language,
    setLanguage,
    t,
    selectedCity,
    setSelectedCity,
    selectedArea,
    setSelectedArea,
    notifications,
    markNotificationRead,
    unreadNotificationCount,
    isAuthenticated,
    openAuthModal,
    logoutUser,
  } = useMohalla();

  const [showLocationModal, setShowLocationModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const handleRoleSelection = (role: UserRole) => {
    setShowRoleModal(false);
    if (role === 'admin') {
      if (currentUser.role !== 'admin' || !isAuthenticated) {
        // Enforce strict admin login
        openAuthModal('admin', 'login');
      } else {
        setActiveView('admin');
      }
    } else if (role === 'provider') {
      if (currentUser.role !== 'provider' || !isAuthenticated) {
        openAuthModal('provider', 'login');
      } else {
        setActiveView('provider');
      }
    } else {
      setActiveView('home');
    }
  };

  const handleLogout = async () => {
    await logoutUser();
    setShowUserDropdown(false);
    setActiveView('home');
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo & Brand */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={() => {
                  if (currentUser.role === 'admin' && isAuthenticated) setActiveView('admin');
                  else if (currentUser.role === 'provider' && isAuthenticated) setActiveView('provider');
                  else setActiveView('home');
                }}
                className="flex items-center gap-2 text-left group cursor-pointer focus:outline-hidden"
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white shadow-md shadow-emerald-700/20 group-hover:scale-105 transition-transform">
                  <span className="font-extrabold text-xl tracking-tight">M</span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-lg tracking-tight text-slate-900 group-hover:text-emerald-700 transition-colors">
                      {t('appName')}
                    </span>
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                      PK
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium hidden sm:block">
                    {t('tagline')}
                  </p>
                </div>
              </button>

              {/* Location Selector Pill */}
              <button
                onClick={() => setShowLocationModal(true)}
                className="ml-1 sm:ml-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200/80 text-slate-800 text-xs sm:text-sm font-medium transition-colors border border-slate-200/70 cursor-pointer"
                title="Change Location"
              >
                <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="truncate max-w-[95px] sm:max-w-[140px]">
                  {language === 'ur' ? selectedArea.urduName : selectedArea.name}
                </span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>
            </div>

            {/* Right Actions: Lang, Admin Quick Button, Notifications, User Menu */}
            <div className="flex items-center gap-2 sm:gap-2.5">
              {/* CLEARLY VISIBLE ADMIN LOGIN SHORTCUT */}
              <button
                onClick={() => {
                  if (currentUser.role === 'admin' && isAuthenticated) {
                    setActiveView('admin');
                  } else {
                    openAuthModal('admin', 'login');
                  }
                }}
                className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border transition-all cursor-pointer ${
                  currentUser.role === 'admin' && isAuthenticated
                    ? 'bg-purple-700 text-white border-purple-800 shadow-xs'
                    : 'bg-purple-50 hover:bg-purple-100 text-purple-900 border-purple-200'
                }`}
                title="Admin Control Center"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
                <span>Admin Login</span>
              </button>

              {/* Language Switcher */}
              <button
                onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-200 cursor-pointer transition-colors"
                title="Toggle Language"
              >
                <Globe className="w-3.5 h-3.5 text-slate-500" />
                <span>{language === 'en' ? 'اردو' : 'English'}</span>
              </button>

              {/* Notifications */}
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 rounded-lg text-slate-600 hover:bg-slate-100 border border-slate-200 cursor-pointer transition-colors"
                  title="Notifications"
                >
                  <Bell className="w-4 h-4" />
                  {unreadNotificationCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-[10px] font-bold text-white flex items-center justify-center animate-pulse">
                      {unreadNotificationCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                      <h4 className="font-bold text-slate-900 text-sm">Notifications</h4>
                      <span className="text-xs text-slate-500 font-medium">
                        {notifications.length} alerts
                      </span>
                    </div>
                    <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                      {notifications.length === 0 ? (
                        <div className="p-4 text-center text-xs text-slate-400">
                          No notifications yet
                        </div>
                      ) : (
                        notifications.map((n) => (
                          <div
                            key={n.id}
                            onClick={() => {
                              markNotificationRead(n.id);
                              if (n.bookingId) setActiveView('bookings');
                              setShowNotifications(false);
                            }}
                            className={`p-3 hover:bg-slate-50 cursor-pointer transition-colors ${
                              !n.read ? 'bg-emerald-50/50' : ''
                            }`}
                          >
                            <div className="flex items-start gap-2">
                              <div
                                className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                                  !n.read ? 'bg-emerald-600' : 'bg-slate-300'
                                }`}
                              />
                              <div>
                                <p className="text-xs font-semibold text-slate-900">{n.title}</p>
                                <p className="text-xs text-slate-600 mt-0.5 leading-snug">
                                  {n.message}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* USER PROFILE & AUTHENTICATION TRIGGER */}
              <div className="relative">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-full bg-slate-900 text-white hover:bg-slate-800 text-xs font-medium cursor-pointer transition-all shadow-xs"
                >
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-6 h-6 rounded-full object-cover border border-white/20"
                  />
                  <div className="text-left hidden md:block">
                    <div className="text-[11px] font-bold leading-none capitalize">
                      {currentUser.role}
                    </div>
                    <div className="text-[10px] text-slate-300 leading-tight truncate max-w-[80px]">
                      {currentUser.name.split(' ')[0]}
                    </div>
                  </div>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {/* User Dropdown Menu */}
                {showUserDropdown && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in duration-150 text-xs">
                    <div className="p-3 border-b border-slate-100 flex items-center gap-3">
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200"
                      />
                      <div className="min-w-0">
                        <div className="font-bold text-slate-900 truncate">{currentUser.name}</div>
                        <div className="text-slate-500 text-[11px] truncate">{currentUser.phone}</div>
                        <span
                          className={`inline-block mt-0.5 px-1.5 py-0.2 rounded text-[10px] font-bold uppercase ${
                            currentUser.role === 'admin'
                              ? 'bg-purple-100 text-purple-800'
                              : currentUser.role === 'provider'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {currentUser.role} Account
                        </span>
                      </div>
                    </div>

                    <div className="p-1 space-y-0.5">
                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          setShowRoleModal(true);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 font-medium flex items-center gap-2 cursor-pointer"
                      >
                        <UserCheck className="w-4 h-4 text-emerald-600" />
                        <span>Switch Account / Persona</span>
                      </button>

                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          openAuthModal('customer', 'login');
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 font-medium flex items-center gap-2 cursor-pointer"
                      >
                        <LogIn className="w-4 h-4 text-blue-600" />
                        <span>Sign In / Create Account</span>
                      </button>

                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          openAuthModal('admin', 'login');
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-purple-50 text-purple-900 font-bold flex items-center gap-2 cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4 text-purple-700" />
                        <span>Admin Secure Portal</span>
                      </button>

                      <div className="pt-1 border-t border-slate-100">
                        <button
                          onClick={handleLogout}
                          className="w-full text-left p-2.5 rounded-xl hover:bg-rose-50 text-rose-700 font-semibold flex items-center gap-2 cursor-pointer"
                        >
                          <LogOut className="w-4 h-4 text-rose-600" />
                          <span>Log Out</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Role Switcher Modal */}
      {showRoleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-base">Select User Persona</h3>
                <p className="text-xs text-slate-500">
                  Switch between Customer, Verified Technician, or Admin roles
                </p>
              </div>
              <button
                onClick={() => setShowRoleModal(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5">
              {/* Customer */}
              <button
                onClick={() => handleRoleSelection('customer')}
                className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                  currentUser.role === 'customer'
                    ? 'border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                    <UserIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">Ahmed Tariq (Customer)</div>
                    <div className="text-xs text-slate-500">
                      Finds & books services in Karachi • Gulshan-e-Iqbal
                    </div>
                  </div>
                </div>
                {currentUser.role === 'customer' && (
                  <Check className="w-5 h-5 text-emerald-600" />
                )}
              </button>

              {/* Provider */}
              <button
                onClick={() => handleRoleSelection('provider')}
                className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                  currentUser.role === 'provider'
                    ? 'border-amber-500 bg-amber-50/50 ring-2 ring-amber-500/20'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                    <Wrench className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      Ali Electrician (Service Provider)
                    </div>
                    <div className="text-xs text-slate-500">
                      Accepts jobs • Earnings wallet • Toggle Available Now
                    </div>
                  </div>
                </div>
                {currentUser.role === 'provider' && (
                  <Check className="w-5 h-5 text-amber-600" />
                )}
              </button>

              {/* Admin */}
              <button
                onClick={() => handleRoleSelection('admin')}
                className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                  currentUser.role === 'admin'
                    ? 'border-purple-600 bg-purple-50/50 ring-2 ring-purple-500/20'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                      <span>Operations Admin (Mohalla HQ)</span>
                      <span className="text-[10px] bg-purple-200 text-purple-900 px-1.5 py-0.2 rounded font-bold">
                        Protected
                      </span>
                    </div>
                    <div className="text-xs text-slate-500">
                      Requires Server Password Authentication
                    </div>
                  </div>
                </div>
                {currentUser.role === 'admin' && <Check className="w-5 h-5 text-purple-600" />}
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-400">Need a new account?</span>
              <button
                onClick={() => {
                  setShowRoleModal(false);
                  openAuthModal('customer', 'signup');
                }}
                className="font-bold text-emerald-700 hover:underline cursor-pointer"
              >
                Sign Up as Customer or Technician
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Location Selector Modal */}
      {showLocationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-base">Select Your Neighborhood</h3>
                <p className="text-xs text-slate-500">
                  Mohalla finds reliable verified providers closest to you
                </p>
              </div>
              <button
                onClick={() => setShowLocationModal(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* City Tabs */}
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1 text-xs font-semibold">
              {OTHER_CITIES.map((c) => (
                <button
                  key={c.id}
                  disabled={!c.active}
                  onClick={() => setSelectedCity(c.name)}
                  className={`px-3 py-1.5 rounded-full shrink-0 transition-colors ${
                    c.active
                      ? selectedCity === c.name
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      : 'bg-slate-50 text-slate-400 cursor-not-allowed border border-dashed border-slate-200'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>

            {/* Karachi Areas Grid */}
            <div className="mt-4 overflow-y-auto flex-1 space-y-1.5 pr-1">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Karachi Neighborhoods
              </div>
              {KARACHI_AREAS.map((area) => {
                const isSelected = selectedArea.id === area.id;
                return (
                  <button
                    key={area.id}
                    onClick={() => {
                      setSelectedArea(area);
                      setShowLocationModal(false);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-colors cursor-pointer ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-950 font-semibold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <MapPin
                        className={`w-4 h-4 ${isSelected ? 'text-emerald-600' : 'text-slate-400'}`}
                      />
                      <span className="text-sm">{area.name}</span>
                      <span className="text-xs text-slate-400 font-urdu">{area.urduName}</span>
                    </div>
                    <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {area.zone}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
