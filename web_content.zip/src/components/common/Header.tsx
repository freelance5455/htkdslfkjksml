import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole, Language } from '../../types';
import {
  Layers,
  Globe,
  Bell,
  Wallet,
  ShoppingCart,
  UserCheck,
  Shield,
  Truck,
  Store,
  Factory,
  RotateCcw,
  CheckCircle2,
  Menu,
  X
} from 'lucide-react';

export const Header: React.FC<{ onOpenCart?: () => void; onOpenNotifications?: () => void }> = ({
  onOpenCart,
  onOpenNotifications
}) => {
  const {
    language,
    setLanguage,
    t,
    currentRole,
    setCurrentRole,
    currentUser,
    walletBalance,
    cartCount,
    notifications,
    startOnboarding,
    setCustomerTab
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const roleLabels: Record<UserRole, { label: string; icon: React.ReactNode; color: string }> = {
    customer: { label: 'Customer / Builder', icon: <UserCheck className="w-4 h-4" />, color: 'bg-emerald-600 text-white' },
    manufacturer: { label: 'Kiln Manufacturer', icon: <Factory className="w-4 h-4" />, color: 'bg-amber-600 text-white' },
    wholesaler: { label: 'Wholesale Bhandar', icon: <Store className="w-4 h-4" />, color: 'bg-blue-600 text-white' },
    driver: { label: 'Transporter / Driver', icon: <Truck className="w-4 h-4" />, color: 'bg-orange-600 text-white' },
    admin: { label: 'Super Admin', icon: <Shield className="w-4 h-4" />, color: 'bg-rose-600 text-white' },
    staff: { label: 'Staff Operations', icon: <Layers className="w-4 h-4" />, color: 'bg-purple-600 text-white' }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#12161c]/95 backdrop-blur-md border-b border-[#252c38]">
      {/* Top Role Switcher Bar - Allows testing all 6 stakeholder portals seamlessly */}
      <div className="bg-[#0b0e12] border-b border-[#1f2631] px-4 py-1.5 text-xs text-slate-300">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[#e55938] uppercase tracking-wider text-[11px] flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#e55938] animate-pulse"></span>
              Role Switcher:
            </span>
            <div className="flex items-center gap-1 overflow-x-auto py-0.5 no-scrollbar">
              {(Object.keys(roleLabels) as UserRole[]).map((role) => (
                <button
                  key={role}
                  id={`role-btn-${role}`}
                  onClick={() => {
                    setCurrentRole(role);
                    if (role === 'customer') setCustomerTab('home');
                  }}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    currentRole === role
                      ? `${roleLabels[role].color} shadow-sm font-semibold`
                      : 'bg-[#181f29] hover:bg-[#222b3a] text-slate-300 border border-[#2b3545]'
                  }`}
                >
                  {roleLabels[role].icon}
                  <span>{roleLabels[role].label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="replay-onboarding-btn"
              onClick={startOnboarding}
              className="text-xs text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors cursor-pointer"
              title="Replay Splash & Onboarding Flow (Screens 01-06)"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Replay Onboarding</span>
            </button>
            <span className="text-slate-600">|</span>
            <div className="flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <select
                id="language-select"
                aria-label="Select Language"
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="bg-[#181f29] border border-[#2b3545] text-slate-200 text-xs rounded px-2 py-0.5 outline-none cursor-pointer focus:border-[#e55938]"
              >
                <option value="en">English</option>
                <option value="bn">বাংলা (Bengali)</option>
                <option value="hi">हिंदी (Hindi)</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Main App Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div
            onClick={() => {
              setCurrentRole('customer');
              setCustomerTab('home');
            }}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#d84a26] to-[#962d16] flex items-center justify-center text-white shadow-md shadow-[#d84a26]/20 border border-[#f37254]/30 group-hover:scale-105 transition-transform">
              {/* Custom brick-pattern representation */}
              <div className="grid grid-cols-2 gap-0.5 p-1.5 w-full h-full">
                <div className="bg-white/90 rounded-xs"></div>
                <div className="bg-white/70 rounded-xs"></div>
                <div className="bg-white/70 rounded-xs"></div>
                <div className="bg-white/90 rounded-xs"></div>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-white group-hover:text-[#f8714e] transition-colors">
                  BRICK<span className="text-[#f8714e]">EXCHANGE</span>
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 bg-[#e55938]/20 border border-[#e55938]/40 text-[#f8714e] rounded uppercase">
                  B2B
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                {t('tagline')}
              </p>
            </div>
          </div>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Wallet badge */}
          <button
            id="header-wallet-btn"
            onClick={() => {
              setCurrentRole('customer');
              setCustomerTab('wallet');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#171d26] hover:bg-[#1f2733] border border-[#273242] rounded-lg text-xs font-medium text-slate-200 transition-colors cursor-pointer"
          >
            <Wallet className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline text-slate-400">Wallet:</span>
            <span className="font-bold text-amber-400">₹{walletBalance.toLocaleString()}</span>
          </button>

          {/* Cart button (for Customer) */}
          {currentRole === 'customer' && (
            <button
              id="header-cart-btn"
              onClick={onOpenCart}
              className="relative p-2 rounded-lg bg-[#171d26] hover:bg-[#1f2733] border border-[#273242] text-slate-200 transition-colors cursor-pointer"
              title="Open Cart"
            >
              <ShoppingCart className="w-4 h-4 text-emerald-400" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-[#e55938] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-sm">
                  {cartCount}k
                </span>
              )}
            </button>
          )}

          {/* Notifications bell */}
          <button
            id="header-notifications-btn"
            onClick={onOpenNotifications}
            className="relative p-2 rounded-lg bg-[#171d26] hover:bg-[#1f2733] border border-[#273242] text-slate-200 transition-colors cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-4 h-4 text-slate-300" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Active Role status badge */}
          <div className="hidden md:flex items-center gap-2 pl-2 border-l border-[#273242]">
            <div className="w-8 h-8 rounded-full bg-[#202836] border border-[#2e3a4e] flex items-center justify-center text-white font-bold text-xs">
              {currentUser.name.charAt(0)}
            </div>
            <div className="text-left">
              <p className="text-xs font-semibold text-slate-200 leading-tight truncate max-w-[140px]">
                {currentUser.name}
              </p>
              <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-medium">
                <CheckCircle2 className="w-3 h-3" />
                <span>KYC Verified</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
