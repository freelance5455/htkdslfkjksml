import React from 'react';
import { useKhata } from '../../context/KhataContext';
import { PWAInstallButton } from './PWAInstallButton';
import { Languages, Lock, Smartphone, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, onTabChange }) => {
  const { language, setLanguage, t, settings, lockApp, setActiveModal } = useKhata();

  const toggleLanguage = () => {
    setLanguage(language === 'hi' ? 'en' : 'hi');
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        {/* Zone 1: Brand wordmark */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center text-white font-bold text-base shadow-xs">
            ₹
          </div>
          <span className="text-base sm:text-lg font-bold text-slate-900 tracking-tight whitespace-nowrap">
            {language === 'hi' ? 'स्मार्ट होम खाता' : 'Smart Home Khata'}
          </span>
        </div>

        {/* Zone 2: Nav links (visible on tablet and desktop) */}
        <nav className="hidden md:flex items-center gap-5 text-sm font-medium text-slate-600">
          <button
            onClick={() => onTabChange('home')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'home' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-700' : 'hover:text-slate-900'
            }`}
          >
            {t.navHome}
          </button>
          <button
            onClick={() => onTabChange('khata')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'khata' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-700' : 'hover:text-slate-900'
            }`}
          >
            {t.navKhata}
          </button>
          <button
            onClick={() => onTabChange('budget')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'budget' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-700' : 'hover:text-slate-900'
            }`}
          >
            {t.navBudget}
          </button>
          <button
            onClick={() => onTabChange('loans_bills')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'loans_bills' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-700' : 'hover:text-slate-900'
            }`}
          >
            {t.navLoansBills}
          </button>
          <button
            onClick={() => onTabChange('more')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'more' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-700' : 'hover:text-slate-900'
            }`}
          >
            {t.navMore}
          </button>
        </nav>

        {/* Zone 3: Actions (PWA install, Language Switch, Android APK modal, Security lock) */}
        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton compact />

          {/* Android APK Info Trigger */}
          <button
            onClick={() => setActiveModal('android')}
            title="Android APK & Installation"
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg text-emerald-800 bg-emerald-50 hover:bg-emerald-100 transition border border-emerald-200"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
            <span className="hidden sm:inline">Android APK</span>
          </button>

          {/* Language Switch Button */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 transition"
            title="Switch Language / भाषा बदलें"
          >
            <Languages className="w-3.5 h-3.5 text-slate-600" />
            <span>{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
          </button>

          {/* Security PIN Lock */}
          {settings.pinLockEnabled ? (
            <button
              onClick={lockApp}
              className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 transition"
              title="Lock Khata"
            >
              <Lock className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => setActiveModal('security')}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
              title="Set PIN Lock"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
