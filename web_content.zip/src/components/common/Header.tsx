import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  LogOut,
  Smartphone,
  ShieldCheck,
  User as UserIcon,
  Clock,
  ChefHat,
  RotateCcw,
} from 'lucide-react';
import { storageService } from '../../services/storage';

interface HeaderProps {
  onOpenApkInfo: () => void;
  onOpenSwitchUser?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenApkInfo, onOpenSwitchUser }) => {
  const { currentUser, logout, isAdmin } = useAuth();
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('es-MX', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        })
      );
      setDateStr(
        now.toLocaleDateString('es-MX', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!currentUser) return null;

  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 bg-neutral-900 text-white shadow-md border-b border-neutral-800"
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2">
        {/* Brand & Area Info */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-orange-600 flex items-center justify-center text-white shrink-0 shadow-sm shadow-orange-900/40">
            <ChefHat className="w-6 h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-extrabold text-sm sm:text-base tracking-tight text-neutral-100">
                RestoTurno
              </span>
              <span
                id="user-role-badge"
                className={`text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                  isAdmin
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}
              >
                {isAdmin ? 'Administrador' : 'Empleado'}
              </span>
            </div>

            {/* Shift & Area details */}
            <div className="flex items-center gap-2 text-xs text-neutral-400 truncate">
              {isAdmin ? (
                <span className="flex items-center gap-1 text-amber-400 font-medium truncate">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                  Control General Restaurante
                </span>
              ) : (
                <span className="flex items-center gap-1 font-medium text-neutral-300 truncate">
                  <span className="inline-block w-2 h-2 rounded-full bg-orange-500 shrink-0"></span>
                  <span className="truncate">{currentUser.areaName || 'Área asignada'}</span>
                  <span className="text-neutral-500">•</span>
                  <span className="text-orange-300 font-semibold">{currentUser.shift}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right side: Clock, APK button, User info & Logout */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          {/* Real-time Clock */}
          <div className="hidden sm:flex flex-col items-end text-xs text-neutral-300 bg-neutral-800/80 px-3 py-1.5 rounded-xl border border-neutral-700/60">
            <div className="flex items-center gap-1 font-semibold text-white">
              <Clock className="w-3.5 h-3.5 text-orange-400" />
              <span>{timeStr}</span>
            </div>
            <span className="text-[10px] text-neutral-400 capitalize">{dateStr}</span>
          </div>

          {/* Android APK Info Button */}
          <button
            id="btn-apk-guide"
            onClick={onOpenApkInfo}
            title="Convertir a APK Android"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold border border-neutral-700 active:scale-95 transition-all"
          >
            <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="hidden md:inline">Instalar APK</span>
          </button>

          {/* Current User Pill / Switcher */}
          <button
            id="btn-user-switch"
            onClick={onOpenSwitchUser}
            title="Cambiar de usuario"
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700/90 text-neutral-100 text-xs font-medium border border-neutral-700/80 active:scale-95 transition-all"
          >
            <div className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold text-[11px] border border-orange-500/40">
              {currentUser.name.charAt(0)}
            </div>
            <span className="hidden sm:inline max-w-[100px] truncate font-medium">
              {currentUser.name}
            </span>
            <RotateCcw className="w-3 h-3 text-neutral-400" />
          </button>

          {/* Logout button */}
          <button
            id="btn-logout"
            onClick={logout}
            title="Cerrar sesión"
            className="p-2 rounded-xl text-neutral-400 hover:text-red-400 hover:bg-red-500/10 active:scale-95 transition-all"
            aria-label="Cerrar sesión"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
