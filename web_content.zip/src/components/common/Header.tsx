import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  Search,
  Bell,
  ShieldAlert,
  ChevronDown,
  Navigation,
  Sparkles,
  X
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const {
    currentLocation,
    setCurrentLocation,
    searchQuery,
    setSearchQuery,
    notifications,
    setIsSosOpen,
    role,
    cart
  } = useApp();

  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false);
  const [isNotifDropdownOpen, setIsNotifDropdownOpen] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.read);

  const popularCities = [
    { city: 'Gurugram', locality: 'DLF Phase 5, Golf Course Rd' },
    { city: 'New Delhi', locality: 'Connaught Place, Central Delhi' },
    { city: 'Mumbai', locality: 'Bandra West, Hill Road' },
    { city: 'Bengaluru', locality: 'Indiranagar 100 Feet Rd' },
    { city: 'Hyderabad', locality: 'Hitec City, Cyberabad' },
    { city: 'Pune', locality: 'Koregaon Park, Lane 7' }
  ];

  const handleSelectCity = (city: string, locality: string) => {
    setCurrentLocation({ city, locality });
    setIsLocationDropdownOpen(false);
  };

  const handleUseGps = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => {
          setCurrentLocation({
            city: 'Near You (GPS)',
            locality: `Lat ${pos.coords.latitude.toFixed(2)}, Lng ${pos.coords.longitude.toFixed(2)}`,
            coordinates: { lat: pos.coords.latitude, lng: pos.coords.longitude }
          });
          setIsLocationDropdownOpen(false);
        },
        () => {
          setCurrentLocation({
            city: 'Gurugram (GPS Default)',
            locality: 'Cyber Hub Phase 2',
            coordinates: { lat: 28.4908, lng: 77.0906 }
          });
          setIsLocationDropdownOpen(false);
        }
      );
    }
  };

  return (
    <div className="bg-white border-b border-slate-200/80 sticky top-0 z-30 shadow-xs">
      {/* Top Location & Action Bar */}
      <div className="px-4 pt-3 pb-2 flex items-center justify-between gap-2">
        {/* Location Selector */}
        <div className="relative">
          <button
            id="location-picker-btn"
            onClick={() => setIsLocationDropdownOpen(!isLocationDropdownOpen)}
            className="flex items-center gap-1.5 text-left max-w-[200px] hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 rounded-full bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0">
              <MapPin className="w-4 h-4 text-amber-600 fill-amber-500/30" />
            </div>
            <div className="overflow-hidden">
              <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                <span>Deliver To</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </div>
              <p className="text-xs font-bold text-slate-900 truncate leading-tight">
                {currentLocation.locality}
              </p>
            </div>
          </button>

          {/* Location Dropdown Modal */}
          {isLocationDropdownOpen && (
            <div className="absolute top-11 left-0 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 p-3 z-50 text-slate-800">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold text-slate-800">Select Delivery Location</span>
                <button onClick={() => setIsLocationDropdownOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <button
                id="gps-auto-detect-btn"
                onClick={handleUseGps}
                className="w-full mt-2.5 flex items-center gap-2.5 p-2 rounded-xl bg-amber-50 hover:bg-amber-100/70 text-amber-800 transition-all font-semibold text-xs border border-amber-200/60"
              >
                <Navigation className="w-4 h-4 text-amber-600 animate-spin" style={{ animationDuration: '6s' }} />
                <span>Use Current Location (GPS)</span>
              </button>

              <div className="mt-3">
                <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1.5">
                  Popular Hubs
                </p>
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {popularCities.map(item => (
                    <button
                      key={item.city}
                      onClick={() => handleSelectCity(item.city, item.locality)}
                      className="w-full text-left p-2 rounded-xl hover:bg-slate-50 flex flex-col transition-all"
                    >
                      <span className="text-xs font-bold text-slate-900">{item.city}</span>
                      <span className="text-[11px] text-slate-500 truncate">{item.locality}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action icons: SOS, Notifications, Cart */}
        <div className="flex items-center gap-1.5">
          {/* Emergency SOS */}
          <button
            id="emergency-sos-header-btn"
            onClick={() => setIsSosOpen(true)}
            className="w-8 h-8 rounded-full bg-red-50 text-red-600 hover:bg-red-100 flex items-center justify-center border border-red-200 shadow-xs transition-transform active:scale-95"
            title="Emergency SOS / Women Safety"
          >
            <ShieldAlert className="w-4 h-4 text-red-600" />
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              id="notifications-bell-btn"
              onClick={() => setIsNotifDropdownOpen(!isNotifDropdownOpen)}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center relative transition-colors"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] flex items-center justify-center border-2 border-white">
                  {unreadNotifs.length}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            {isNotifDropdownOpen && (
              <div className="absolute top-10 right-0 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 p-3 z-50 text-slate-800">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="text-xs font-bold">Notifications</span>
                  <button onClick={() => setIsNotifDropdownOpen(false)} className="text-slate-400">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="mt-2 space-y-2 max-h-60 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-4">No notifications yet</p>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        className={`p-2 rounded-xl text-xs border ${
                          n.read ? 'bg-white border-slate-100 text-slate-600' : 'bg-amber-50/70 border-amber-200 text-slate-900 font-medium'
                        }`}
                      >
                        <p className="font-bold text-xs">{n.title}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">{n.message}</p>
                        <span className="text-[9px] text-slate-400 block mt-1">{n.timestamp}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Cart Icon (Customer mode) */}
          {role === 'customer' && (
            <button
              id="header-cart-btn"
              onClick={() => setActiveTab('cart')}
              className="px-2.5 h-8 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-transform"
            >
              <span>Cart</span>
              {cart.length > 0 && (
                <span className="w-4 h-4 rounded-full bg-slate-950 text-white font-black text-[9px] flex items-center justify-center">
                  {cart.reduce((a, b) => a + b.quantity, 0)}
                </span>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Global Search Bar */}
      {role === 'customer' && activeTab !== 'orders' && activeTab !== 'profile' && (
        <div className="px-4 pb-2.5 pt-0.5">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              id="global-search-input"
              type="text"
              placeholder="Search food, grocery, cab, electrician, repair..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-slate-100 hover:bg-slate-100/90 focus:bg-white text-xs text-slate-900 rounded-xl border border-transparent focus:border-amber-500 focus:outline-hidden transition-all placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
