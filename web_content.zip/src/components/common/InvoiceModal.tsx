import React from 'react';
import { useApp } from '../../context/AppContext';
import { Printer, Download, X, CheckCircle, ShieldCheck, QrCode } from 'lucide-react';

export const InvoiceModal: React.FC = () => {
  const { invoiceModalOrderId, setInvoiceModalOrderId, orders, t } = useApp();

  if (!invoiceModalOrderId) return null;

  const order = orders.find((o) => o.id === invoiceModalOrderId) || orders[0];
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = () => {
    alert(`Downloading Tax Invoice PDF for ${order.id}...`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-3xl bg-white text-slate-900 rounded-2xl shadow-2xl overflow-hidden my-6 border border-slate-200 print:m-0 print:border-none">
        {/* Modal Action Header (hidden when printing) */}
        <div className="bg-[#151c27] text-white px-5 py-3 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Official Tax Invoice / Consignment Note
            </span>
            <span className="font-mono text-xs text-slate-300">({order.id})</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded-lg text-xs font-semibold flex items-center gap-1.5 text-white cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              onClick={handleDownloadPdf}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 rounded-lg text-xs font-semibold flex items-center gap-1.5 text-white cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>
            <button
              onClick={() => setInvoiceModalOrderId(null)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Body */}
        <div className="p-6 sm:p-8 space-y-6 text-xs text-slate-700">
          {/* Top Header & Branding */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-[#e55938] text-white font-black rounded-lg flex items-center justify-center text-sm">
                  BX
                </div>
                <h1 className="text-xl font-black tracking-tight text-slate-900">BRICK EXCHANGE</h1>
              </div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                B2B Heavy Construction Materials Gateway & Logistics Network
              </p>
              <p className="text-[10px] text-slate-500">
                CIN: U45200WB2024PTC288190 • GSTIN: 19AABCB1234F1Z8
              </p>
            </div>

            <div className="sm:text-right">
              <span className="px-2.5 py-1 bg-amber-100 text-amber-900 font-bold rounded text-[10px] uppercase tracking-wider">
                TAX INVOICE / CONSIGNMENT NOTE
              </span>
              <div className="font-mono font-bold text-slate-900 text-sm mt-1">
                INV-{order.id.replace('ORD-', '2025-')}
              </div>
              <p className="text-[11px] text-slate-500">Invoice Date: {order.createdAt}</p>
              <p className="text-[11px] text-slate-500">Payment Ref: ESCROW-{order.id}-TXN</p>
            </div>
          </div>

          {/* Supplier & Consignee Columns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <h4 className="font-bold text-[11px] text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1 mb-1.5">
                Supplier / Kiln Manufacturer
              </h4>
              <p className="font-bold text-slate-900">Maa Tara Brick Kiln (BFB Bhatta)</p>
              <p className="text-[11px] text-slate-600">Kiln Yard: NH-12, Barasat-Baduria Road, Dist: North 24 Parganas, WB - 743424</p>
              <p className="text-[11px] text-slate-600 font-mono mt-1">GSTIN: 19AAFFM3821K1ZM</p>
              <p className="text-[11px] text-slate-600 font-mono">State Code: 19 (West Bengal)</p>
            </div>

            <div>
              <h4 className="font-bold text-[11px] text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1 mb-1.5">
                Billed & Shipped To (Buyer)
              </h4>
              <p className="font-bold text-slate-900">{order.customerName}</p>
              <p className="text-[11px] text-slate-600">Delivery Site: {order.deliveryAddress}</p>
              <p className="text-[11px] text-slate-600">Contact: {order.customerMobile}</p>
              <p className="text-[11px] text-slate-600 font-mono mt-1">
                Buyer GSTIN: 19AAACG0182E1ZS (Registered Builder)
              </p>
            </div>
          </div>

          {/* Dispatch & Logistics Details */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] p-3 bg-slate-100/70 rounded-lg">
            <div>
              <span className="text-slate-500 block">Vehicle No:</span>
              <span className="font-mono font-bold text-slate-800">{order.vehicleNumber || 'WB 39 B 4812'}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Vehicle Category:</span>
              <span className="font-bold text-slate-800">{order.vehicleType}</span>
            </div>
            <div>
              <span className="text-slate-500 block">E-Way Bill No:</span>
              <span className="font-mono font-bold text-slate-800">541098231044</span>
            </div>
            <div>
              <span className="text-slate-500 block">Driver Contact:</span>
              <span className="font-bold text-slate-800">Ramen Das (+91 94331 88201)</span>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 border-b border-slate-200 text-slate-700 text-[10px] uppercase font-bold">
                <tr>
                  <th className="p-3">#</th>
                  <th className="p-3">Description of Goods</th>
                  <th className="p-3">HSN Code</th>
                  <th className="p-3">Quantity</th>
                  <th className="p-3 text-right">Unit Rate (₹/1k)</th>
                  <th className="p-3 text-right">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {order.items.map((item, idx) => (
                  <tr key={idx}>
                    <td className="p-3 font-mono">{idx + 1}</td>
                    <td className="p-3">
                      <div className="font-bold text-slate-900">{item.productName}</div>
                      <div className="text-[10px] text-slate-500">
                        Class 1 Heavy Load Kiln Fired Red Bricks (9" x 4.25" x 2.75")
                      </div>
                    </td>
                    <td className="p-3 font-mono text-slate-600">69041000</td>
                    <td className="p-3 font-mono font-bold">
                      {item.quantityThousand}k ({item.quantityThousand * 1000} pcs)
                    </td>
                    <td className="p-3 font-mono text-right">
                      ₹{item.unitPrice.toLocaleString()}
                    </td>
                    <td className="p-3 font-mono font-bold text-right text-slate-900">
                      ₹{item.totalProductPrice.toLocaleString()}
                    </td>
                  </tr>
                ))}
                <tr>
                  <td className="p-3 font-mono">2</td>
                  <td className="p-3" colSpan={2}>
                    <div className="font-semibold text-slate-900">Heavy Haulage Freight Charges</div>
                    <div className="text-[10px] text-slate-500">Dedicated {order.vehicleType} transit</div>
                  </td>
                  <td className="p-3 font-mono">1 Trip</td>
                  <td className="p-3 font-mono text-right">-</td>
                  <td className="p-3 font-mono font-bold text-right text-slate-900">
                    ₹{order.transportCharge.toLocaleString()}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Tax Calculation Breakdown & Total */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
            <div className="max-w-xs space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
                <CheckCircle className="w-4 h-4" />
                <span>GST Tax & E-Way Bill Verified</span>
              </div>
              <p className="text-[10px] text-slate-500 leading-tight">
                This is a digitally generated tax invoice per the Central Goods and Services Tax Act 2017.
              </p>
            </div>

            <div className="w-full sm:w-64 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal (Excl. Tax):</span>
                <span className="font-mono font-semibold">
                  ₹{(order.productTotal + order.transportCharge).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>CGST (2.5%):</span>
                <span className="font-mono">₹{(order.gstAmount / 2).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>SGST (2.5%):</span>
                <span className="font-mono">₹{(order.gstAmount / 2).toLocaleString()}</span>
              </div>
              <div className="pt-2 border-t-2 border-slate-900 flex justify-between font-black text-sm text-slate-900">
                <span>Total Invoice Value:</span>
                <span className="font-mono text-[#e55938]">
                  ₹{order.totalAmount.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Signatures & Footer */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-end gap-4">
            <div className="text-[10px] text-slate-500">
              <p className="font-bold text-slate-700">Payment Status: Verified & Settled via Escrow</p>
              <p>Delivery Confirmation OTP: {order.deliveryOtp}</p>
            </div>

            <div className="text-right">
              <div className="w-32 h-10 border-b border-dashed border-slate-400 mb-1"></div>
              <p className="text-[10px] font-bold text-slate-800 uppercase">
                Authorized Signatory / Digital Seal
              </p>
              <p className="text-[9px] text-slate-500">Brick Exchange Platform Services Ltd</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
