import React from 'react';
import { SongColorTheme } from '../../types/music';

interface CoverArtProps {
  artKey: string;
  title?: string;
  artist?: string;
  colorTheme?: SongColorTheme;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'hero' | 'full';
  className?: string;
  isVinyl?: boolean;
  isPlaying?: boolean;
  type?: 'song' | 'album' | 'playlist' | 'artist';
}

export const CoverArt: React.FC<CoverArtProps> = ({
  artKey,
  title,
  artist,
  colorTheme = { from: '#7928ca', to: '#ff0080', accent: '#a855f7' },
  size = 'md',
  className = '',
  isVinyl = false,
  isPlaying = false,
  type = 'song'
}) => {
  const sizeClasses = {
    sm: 'w-10 h-10 rounded-lg text-[9px]',
    md: 'w-14 h-14 rounded-xl text-xs',
    lg: 'w-24 h-24 rounded-2xl text-sm',
    xl: 'w-40 h-40 rounded-2xl text-base',
    hero: 'w-full aspect-video rounded-3xl text-lg',
    full: 'w-64 h-64 sm:w-72 sm:h-72 rounded-3xl text-lg'
  }[size];

  const roundedShape = type === 'artist' ? 'rounded-full' : '';

  // Procedural gradient background
  const bgStyle = {
    background: `linear-gradient(135deg, ${colorTheme.from} 0%, ${colorTheme.via || '#0d1117'} 50%, ${colorTheme.to} 100%)`
  };

  return (
    <div
      className={`relative overflow-hidden flex items-center justify-center shrink-0 shadow-lg shadow-black/40 select-none ${sizeClasses} ${roundedShape} ${className}`}
      style={bgStyle}
    >
      {/* Dynamic ambient geometric SVG patterns for the album cover */}
      <svg
        className="absolute inset-0 w-full h-full opacity-35 mix-blend-overlay pointer-events-none"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
      >
        <defs>
          <radialGradient id={`glow-${artKey}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>
        </defs>

        {artKey.includes('cybernetic') && (
          <g stroke="white" strokeWidth="0.5" fill="none">
            <line x1="0" y1="20" x2="100" y2="20" />
            <line x1="0" y1="40" x2="100" y2="40" />
            <line x1="0" y1="60" x2="100" y2="60" />
            <line x1="0" y1="80" x2="100" y2="80" />
            <circle cx="50" cy="50" r="30" stroke="white" strokeWidth="1" />
            <polygon points="50,25 70,65 30,65" stroke="white" strokeWidth="0.75" />
          </g>
        )}

        {artKey.includes('bengal') && (
          <g fill="none" stroke="white" strokeWidth="0.6">
            <path d="M10,80 Q30,20 50,50 T90,20" />
            <path d="M15,90 Q40,35 60,60 T95,30" opacity="0.6" />
            <circle cx="75" cy="30" r="14" fill={`url(#glow-${artKey})`} opacity="0.5" />
            <circle cx="50" cy="50" r="22" stroke="white" strokeDasharray="2,2" />
          </g>
        )}

        {artKey.includes('heartstrings') && (
          <g stroke="white" strokeWidth="0.7" fill="none">
            <path d="M50,85 C20,55 10,35 25,20 C35,10 45,20 50,30 C55,20 65,10 75,20 C90,35 80,55 50,85 Z" opacity="0.7" />
            <line x1="20" y1="50" x2="80" y2="50" strokeDasharray="1,2" />
            <circle cx="50" cy="50" r="40" stroke="white" strokeWidth="0.4" />
          </g>
        )}

        {artKey.includes('nostalgia') && (
          <g fill="none" stroke="white" strokeWidth="0.8">
            <circle cx="50" cy="50" r="10" />
            <circle cx="50" cy="50" r="22" />
            <circle cx="50" cy="50" r="35" strokeDasharray="4,4" />
            <circle cx="50" cy="50" r="45" opacity="0.4" />
          </g>
        )}

        {artKey.includes('workout') && (
          <g stroke="white" strokeWidth="1" fill="none">
            <polyline points="10,50 30,50 40,20 50,80 60,35 70,60 80,50 90,50" />
            <polygon points="50,15 65,35 35,35" fill="white" opacity="0.4" />
          </g>
        )}

        {artKey.includes('lofi') && (
          <g stroke="white" strokeWidth="0.5" fill="none">
            <rect x="20" y="20" width="60" height="60" rx="6" />
            <line x1="20" y1="50" x2="80" y2="50" />
            <line x1="50" y1="20" x2="50" y2="80" />
            <circle cx="35" cy="35" r="8" fill="white" opacity="0.3" />
            <line x1="30" y1="70" x2="70" y2="70" strokeDasharray="2,2" />
          </g>
        )}

        {(!artKey.includes('cybernetic') &&
          !artKey.includes('bengal') &&
          !artKey.includes('heartstrings') &&
          !artKey.includes('nostalgia') &&
          !artKey.includes('workout') &&
          !artKey.includes('lofi')) && (
          <g fill="none" stroke="white" strokeWidth="0.6">
            <circle cx="50" cy="50" r="28" />
            <circle cx="50" cy="50" r="42" strokeDasharray="3,3" />
            <line x1="15" y1="15" x2="85" y2="85" opacity="0.4" />
            <line x1="85" y1="15" x2="15" y2="85" opacity="0.4" />
          </g>
        )}
      </svg>

      {/* Vinyl record overlay when enabled */}
      {isVinyl && (
        <div
          className={`absolute inset-0 rounded-full border-4 border-black/40 flex items-center justify-center transition-transform ${
            isPlaying ? 'animate-spin-slow' : 'paused'
          }`}
          style={{
            boxShadow: 'inset 0 0 20px rgba(0,0,0,0.8), 0 0 10px rgba(0,0,0,0.5)'
          }}
        >
          {/* Grooves */}
          <div className="w-[84%] h-[84%] rounded-full border border-white/10" />
          <div className="w-[68%] h-[68%] rounded-full border border-white/10 absolute" />
          <div className="w-[52%] h-[52%] rounded-full border border-white/15 absolute" />
          <div className="w-12 h-12 rounded-full bg-black/85 border-2 border-white/20 absolute flex items-center justify-center">
            <div className="w-3.5 h-3.5 rounded-full bg-white/90 shadow-inner" />
          </div>
        </div>
      )}

      {/* Typography imprint for medium/large sizes */}
      {!isVinyl && (size === 'lg' || size === 'xl' || size === 'full' || size === 'hero') && (
        <div className="relative z-10 p-3 text-center pointer-events-none drop-shadow-md">
          {type === 'artist' ? (
            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center mb-1 text-white font-bold text-sm">
                {(artist || title || 'A')[0]}
              </div>
              <span className="font-semibold text-xs text-white/90 tracking-wide line-clamp-1 max-w-[80px]">
                {artist || title}
              </span>
            </div>
          ) : (
            <>
              <p className="font-display font-extrabold text-white text-sm sm:text-base leading-tight line-clamp-2 uppercase tracking-wider">
                {title || 'Express Beat'}
              </p>
              {artist && (
                <p className="text-[11px] text-white/80 font-medium mt-1 truncate">
                  {artist}
                </p>
              )}
            </>
          )}
        </div>
      )}

      {/* Glossy lighting highlight */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/25 pointer-events-none" />
      <div className="absolute inset-0 border border-white/15 rounded-[inherit] pointer-events-none" />
    </div>
  );
};
