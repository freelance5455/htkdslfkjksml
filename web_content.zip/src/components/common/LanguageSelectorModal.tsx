import React from 'react';
import { X, Check, Globe } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { LanguageCode } from '../../types/language';

export const LanguageSelectorModal: React.FC = () => {
  const { currentLanguage, setLanguage, languages, isLanguageModalOpen, closeLanguageModal, t } =
    useLanguage();

  if (!isLanguageModalOpen) return null;

  const handleSelectLanguage = (code: LanguageCode) => {
    setLanguage(code);
    closeLanguageModal();
  };

  return (
    <div
      onClick={closeLanguageModal}
      className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#EAEAEA] max-h-[85vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom sm:slide-in-from-bottom-4 duration-250"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#EAEAEA] bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#000000] text-[#FFD400] flex items-center justify-center shadow-xs">
              <Globe className="w-5 h-5 text-[#FFD400]" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-[#111111] leading-tight">
                {t('selectLanguage')}
              </h3>
              <p className="text-[11px] text-[#666666] font-medium">13 Indian Languages Supported</p>
            </div>
          </div>
          <button
            onClick={closeLanguageModal}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#666666] hover:text-[#000000] hover:bg-[#FAFAFA] transition-colors cursor-pointer"
            aria-label="Close language selector"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Language Grid */}
        <div className="p-4 overflow-y-auto max-h-[60vh] grid grid-cols-1 sm:grid-cols-2 gap-2">
          {languages.map((lang) => {
            const isSelected = currentLanguage === lang.code;
            return (
              <button
                key={lang.code}
                onClick={() => handleSelectLanguage(lang.code)}
                className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'border-[#000000] bg-[#FFF9DB] shadow-xs ring-1 ring-[#000000]'
                    : 'border-[#EAEAEA] hover:border-[#111111] hover:bg-[#FAFAFA] bg-white'
                }`}
              >
                <div className="min-w-0">
                  <p
                    className={`text-sm sm:text-base font-extrabold leading-tight ${
                      isSelected ? 'text-[#000000]' : 'text-[#111111]'
                    }`}
                  >
                    {lang.nativeName}
                  </p>
                  <p className="text-[11px] font-medium text-[#666666] mt-0.5">{lang.name}</p>
                </div>
                {isSelected && (
                  <div className="w-6 h-6 rounded-full bg-[#000000] text-[#FFD400] flex items-center justify-center flex-shrink-0 shadow-2xs">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="px-5 py-3 bg-[#FAFAFA] border-t border-[#EAEAEA] text-center text-[11px] text-[#666666] font-semibold">
          Selected language applies instantly across all pages and features
        </div>
      </div>
    </div>
  );
};
