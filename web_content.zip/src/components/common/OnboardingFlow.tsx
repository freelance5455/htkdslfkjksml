import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole, Language } from '../../types';
import {
  Layers,
  Globe,
  Phone,
  ShieldCheck,
  User,
  MapPin,
  Building2,
  Truck,
  Store,
  Factory,
  Check,
  ArrowRight,
  ArrowLeft,
  RefreshCw,
  Camera,
  Navigation
} from 'lucide-react';

export const OnboardingFlow: React.FC = () => {
  const {
    language,
    setLanguage,
    t,
    onboardingStep,
    setOnboardingStep,
    completeOnboarding,
    currentUser,
    updateCurrentUser
  } = useApp();

  // Screen 03 & 04 Login / OTP state
  const [mobileInput, setMobileInput] = useState('+91 98301 44521');
  const [otpInputs, setOtpInputs] = useState(['7', '4', '1', '8', '5', '2']);
  const [timer, setTimer] = useState(30);

  // Screen 05 Profile state
  const [nameInput, setNameInput] = useState(currentUser.name);
  const [emailInput, setEmailInput] = useState(currentUser.email);
  const [addressInput, setAddressInput] = useState(currentUser.address);
  const [pinCodeInput, setPinCodeInput] = useState(currentUser.pinCode);
  const [gpsEnabled, setGpsEnabled] = useState(currentUser.gpsPermissionGranted);

  // Screen 06 Role selection
  const [selectedRole, setSelectedRole] = useState<UserRole>('customer');

  // Screen 01 Splash screen timer auto-advance
  useEffect(() => {
    if (onboardingStep === 1) {
      const splashTimer = setTimeout(() => {
        setOnboardingStep(2);
      }, 2200);
      return () => clearTimeout(splashTimer);
    }
  }, [onboardingStep, setOnboardingStep]);

  // Resend OTP countdown
  useEffect(() => {
    if (onboardingStep === 4 && timer > 0) {
      const countdown = setInterval(() => setTimer((t) => t - 1), 1000);
      return () => clearInterval(countdown);
    }
  }, [onboardingStep, timer]);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) value = value.slice(-1);
    const newOtp = [...otpInputs];
    newOtp[index] = value;
    setOtpInputs(newOtp);

    // Auto focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-digit-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleSaveProfile = () => {
    updateCurrentUser({
      name: nameInput,
      email: emailInput,
      address: addressInput,
      pinCode: pinCodeInput,
      gpsPermissionGranted: gpsEnabled
    });
    setOnboardingStep(6);
  };

  const handleFinishRoleSelection = () => {
    completeOnboarding(selectedRole);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0c0f14] text-slate-100 flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-[#141922] border border-[#263142] rounded-2xl p-6 sm:p-8 shadow-2xl relative">
        {/* Navigation back button if beyond step 2 */}
        {onboardingStep > 2 && (
          <button
            id="onboarding-back-btn"
            onClick={() => setOnboardingStep(onboardingStep - 1)}
            className="absolute top-5 left-5 text-slate-400 hover:text-white transition-colors cursor-pointer p-1 rounded-lg bg-[#1b222e]"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
        )}

        {/* Step indicator */}
        {onboardingStep > 1 && (
          <div className="flex items-center justify-center gap-1.5 mb-6">
            {[2, 3, 4, 5, 6].map((s) => (
              <div
                key={s}
                className={`h-1.5 rounded-full transition-all ${
                  s === onboardingStep
                    ? 'w-8 bg-[#e55938]'
                    : s < onboardingStep
                    ? 'w-3 bg-emerald-500'
                    : 'w-3 bg-[#263142]'
                }`}
              />
            ))}
          </div>
        )}

        {/* ==============================================
            SCREEN 01: SPLASH SCREEN
        ============================================== */}
        {onboardingStep === 1 && (
          <div className="py-12 flex flex-col items-center text-center">
            <div className="relative mb-6">
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#e55938] via-[#c24325] to-[#8d2a14] p-4 shadow-xl shadow-[#e55938]/20 flex items-center justify-center animate-pulse">
                <div className="grid grid-cols-2 gap-1 w-full h-full">
                  <div className="bg-white/95 rounded-sm"></div>
                  <div className="bg-white/80 rounded-sm"></div>
                  <div className="bg-white/80 rounded-sm"></div>
                  <div className="bg-white/95 rounded-sm"></div>
                </div>
              </div>
              <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white rounded-full p-1 shadow-md">
                <Check className="w-3.5 h-3.5" />
              </div>
            </div>

            <h1 className="text-3xl font-extrabold tracking-tight text-white mb-2">
              BRICK<span className="text-[#e55938]">EXCHANGE</span>
            </h1>
            <p className="text-slate-400 text-sm max-w-xs font-medium mb-8">
              {t('tagline')}
            </p>

            <div className="flex items-center gap-3 text-xs text-slate-400">
              <div className="w-4 h-4 border-2 border-[#e55938] border-t-transparent rounded-full animate-spin"></div>
              <span>Initializing secure marketplace...</span>
            </div>

            <button
              id="splash-skip-btn"
              onClick={() => setOnboardingStep(2)}
              className="mt-8 text-xs text-slate-400 hover:text-white underline cursor-pointer"
            >
              Continue to Language Selection →
            </button>
          </div>
        )}

        {/* ==============================================
            SCREEN 02: LANGUAGE SELECTION
        ============================================== */}
        {onboardingStep === 2 && (
          <div className="py-4 text-center">
            <div className="w-12 h-12 rounded-xl bg-[#222b3a] text-amber-400 flex items-center justify-center mx-auto mb-4 border border-[#2f3b50]">
              <Globe className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-1">
              Select Your Language
            </h2>
            <p className="text-slate-400 text-sm mb-6">
              পছন্দের ভাষা নির্বাচন করুন / अपनी भाषा चुनें
            </p>

            <div className="space-y-3 mb-6">
              {[
                { code: 'bn' as Language, title: 'বাংলা (Bengali)', subtitle: 'পশ্চিমবঙ্গ ও পূর্ব ভারতের জন্য বিশেষায়িত' },
                { code: 'en' as Language, title: 'English', subtitle: 'Standard English Business Portal' },
                { code: 'hi' as Language, title: 'हिंदी (Hindi)', subtitle: 'उत्तर भारत व देशव्यापी ईंट व्यापार हेतु' }
              ].map((lang) => (
                <button
                  key={lang.code}
                  id={`lang-btn-${lang.code}`}
                  onClick={() => setLanguage(lang.code)}
                  className={`w-full p-4 rounded-xl text-left border transition-all flex items-center justify-between cursor-pointer ${
                    language === lang.code
                      ? 'bg-[#e55938]/10 border-[#e55938] text-white shadow-md'
                      : 'bg-[#1a212d] border-[#293447] text-slate-300 hover:bg-[#202938]'
                  }`}
                >
                  <div>
                    <div className="font-bold text-base">{lang.title}</div>
                    <div className="text-xs text-slate-400">{lang.subtitle}</div>
                  </div>
                  {language === lang.code && (
                    <div className="w-6 h-6 rounded-full bg-[#e55938] text-white flex items-center justify-center">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              ))}
            </div>

            <button
              id="language-continue-btn"
              onClick={() => setOnboardingStep(3)}
              className="w-full py-3.5 px-4 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#e55938]/20"
            >
              <span>Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ==============================================
            SCREEN 03: LOGIN (MOBILE + OTP REQUEST)
        ============================================== */}
        {onboardingStep === 3 && (
          <div className="py-2">
            <div className="w-12 h-12 rounded-xl bg-[#222b3a] text-emerald-400 flex items-center justify-center mb-4 border border-[#2f3b50]">
              <Phone className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-1">
              {t('loginTitle')}
            </h2>
            <p className="text-slate-400 text-sm mb-6">
              Enter registered mobile number for instant OTP verification
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  {t('mobileNumber')}
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-semibold text-sm">
                    🇮🇳
                  </span>
                  <input
                    id="mobile-input-field"
                    type="text"
                    value={mobileInput}
                    onChange={(e) => setMobileInput(e.target.value)}
                    className="w-full bg-[#181f2b] border border-[#2d3a4e] rounded-xl pl-12 pr-4 py-3.5 text-white font-medium focus:border-[#e55938] outline-none text-base"
                    placeholder="+91 98301 44521"
                  />
                </div>
              </div>

              <div className="p-3 bg-[#18212d] border border-[#28364b] rounded-xl text-xs text-slate-400 flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>GST-compliant identity checks enforced for wholesale purchases.</span>
              </div>
            </div>

            <button
              id="send-otp-btn"
              onClick={() => {
                setTimer(30);
                setOnboardingStep(4);
              }}
              className="w-full py-3.5 px-4 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#e55938]/20 mb-4"
            >
              <span>{t('sendOtp')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="relative my-4 text-center">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#263142]"></div>
              </div>
              <span className="relative bg-[#141922] px-3 text-xs text-slate-400 uppercase">
                Optional
              </span>
            </div>

            <button
              id="google-login-btn"
              onClick={() => setOnboardingStep(4)}
              className="w-full py-3 px-4 bg-[#1a212d] hover:bg-[#232d3d] border border-[#2d394b] text-slate-200 font-semibold rounded-xl text-sm transition-colors flex items-center justify-center gap-2.5 cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
              <span>Continue with Google Enterprise</span>
            </button>
          </div>
        )}

        {/* ==============================================
            SCREEN 04: OTP VERIFICATION
        ============================================== */}
        {onboardingStep === 4 && (
          <div className="py-2 text-center">
            <div className="w-12 h-12 rounded-xl bg-[#222b3a] text-emerald-400 flex items-center justify-center mx-auto mb-4 border border-[#2f3b50]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-1">
              {t('verifyOtp')}
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm mb-6">
              {t('enterOtp')}{' '}
              <span className="font-semibold text-slate-200">{mobileInput}</span>
            </p>

            {/* 6 digit inputs */}
            <div className="flex items-center justify-center gap-2 mb-6">
              {otpInputs.map((digit, idx) => (
                <input
                  key={idx}
                  id={`otp-digit-${idx}`}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(idx, e.target.value)}
                  className="w-11 h-12 bg-[#181f2b] border border-[#2d3a4e] text-center text-xl font-bold text-white rounded-xl focus:border-[#e55938] outline-none"
                />
              ))}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 mb-6 px-1">
              <button
                id="change-number-btn"
                onClick={() => setOnboardingStep(3)}
                className="hover:text-white underline cursor-pointer"
              >
                {t('changeNumber')}
              </button>

              <button
                id="resend-otp-btn"
                disabled={timer > 0}
                onClick={() => setTimer(30)}
                className={`flex items-center gap-1 cursor-pointer ${
                  timer > 0 ? 'text-slate-500 cursor-not-allowed' : 'text-amber-400 hover:text-amber-300'
                }`}
              >
                <RefreshCw className="w-3 h-3" />
                <span>{timer > 0 ? `Resend in ${timer}s` : t('resendOtp')}</span>
              </button>
            </div>

            <button
              id="confirm-otp-btn"
              onClick={() => setOnboardingStep(5)}
              className="w-full py-3.5 px-4 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#e55938]/20"
            >
              <span>{t('verifyOtp')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ==============================================
            SCREEN 05: PROFILE SETUP & GPS PERMISSION
        ============================================== */}
        {onboardingStep === 5 && (
          <div className="py-1">
            <h2 className="text-2xl font-bold text-white mb-1">
              {t('profileSetup')}
            </h2>
            <p className="text-slate-400 text-xs mb-5">
              Set up your verified company or personal profile for site delivery
            </p>

            <div className="space-y-3.5 mb-6">
              {/* Profile Photo Placeholder */}
              <div className="flex items-center gap-3 p-3 bg-[#18202c] border border-[#273446] rounded-xl">
                <div className="w-12 h-12 rounded-full bg-[#242f40] border border-[#324258] flex items-center justify-center text-slate-300 relative group cursor-pointer">
                  <User className="w-6 h-6" />
                  <div className="absolute -bottom-1 -right-1 p-1 bg-[#e55938] rounded-full text-white shadow">
                    <Camera className="w-2.5 h-2.5" />
                  </div>
                </div>
                <div className="text-xs">
                  <div className="font-semibold text-slate-200">Company / User Avatar</div>
                  <div className="text-slate-400">Tap to upload GST or brand logo</div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('fullName')} / Business Name
                </label>
                <input
                  id="profile-name-input"
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full bg-[#181f2b] border border-[#2d3a4e] rounded-xl px-3.5 py-2.5 text-white text-sm focus:border-[#e55938] outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('email')}
                  </label>
                  <input
                    id="profile-email-input"
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    className="w-full bg-[#181f2b] border border-[#2d3a4e] rounded-xl px-3.5 py-2.5 text-white text-sm focus:border-[#e55938] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('pinCode')}
                  </label>
                  <input
                    id="profile-pincode-input"
                    type="text"
                    value={pinCodeInput}
                    onChange={(e) => setPinCodeInput(e.target.value)}
                    className="w-full bg-[#181f2b] border border-[#2d3a4e] rounded-xl px-3.5 py-2.5 text-white text-sm focus:border-[#e55938] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('address')}
                </label>
                <textarea
                  id="profile-address-input"
                  rows={2}
                  value={addressInput}
                  onChange={(e) => setAddressInput(e.target.value)}
                  className="w-full bg-[#181f2b] border border-[#2d3a4e] rounded-xl px-3.5 py-2.5 text-white text-sm focus:border-[#e55938] outline-none resize-none"
                />
              </div>

              {/* GPS location permission */}
              <div className="p-3.5 bg-[#18212e] border border-[#2a374b] rounded-xl flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Navigation className="w-5 h-5 text-[#e55938] shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-slate-200">GPS Location Permission</div>
                    <div className="text-[11px] text-slate-400">
                      Required for live truck tracking and distance freight quote
                    </div>
                  </div>
                </div>
                <input
                  id="profile-gps-toggle"
                  type="checkbox"
                  checked={gpsEnabled}
                  onChange={(e) => setGpsEnabled(e.target.checked)}
                  className="w-5 h-5 accent-[#e55938] cursor-pointer"
                />
              </div>
            </div>

            <button
              id="save-profile-btn"
              onClick={handleSaveProfile}
              className="w-full py-3.5 px-4 bg-[#e55938] hover:bg-[#d44827] text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#e55938]/20"
            >
              <span>Next: Select Role</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ==============================================
            SCREEN 06: ROLE SELECTION
        ============================================== */}
        {onboardingStep === 6 && (
          <div className="py-2">
            <h2 className="text-2xl font-bold text-white mb-1">
              {t('roleSelection')}
            </h2>
            <p className="text-slate-400 text-xs mb-5">
              Choose your primary operational role in the Brick Exchange supply chain
            </p>

            <div className="space-y-3 mb-6">
              {[
                {
                  role: 'customer' as UserRole,
                  title: t('customerRole'),
                  desc: t('customerRoleDesc'),
                  icon: <Building2 className="w-5 h-5 text-emerald-400" />,
                  border: 'hover:border-emerald-500'
                },
                {
                  role: 'manufacturer' as UserRole,
                  title: t('manufacturerRole'),
                  desc: t('manufacturerRoleDesc'),
                  icon: <Factory className="w-5 h-5 text-amber-400" />,
                  border: 'hover:border-amber-500'
                },
                {
                  role: 'wholesaler' as UserRole,
                  title: t('wholesalerRole'),
                  desc: t('wholesalerRoleDesc'),
                  icon: <Store className="w-5 h-5 text-blue-400" />,
                  border: 'hover:border-blue-500'
                },
                {
                  role: 'driver' as UserRole,
                  title: t('driverRole'),
                  desc: t('driverRoleDesc'),
                  icon: <Truck className="w-5 h-5 text-orange-400" />,
                  border: 'hover:border-orange-500'
                }
              ].map((item) => (
                <button
                  key={item.role}
                  id={`select-role-${item.role}`}
                  onClick={() => setSelectedRole(item.role)}
                  className={`w-full p-3.5 rounded-xl border text-left transition-all flex items-start gap-3.5 cursor-pointer ${
                    selectedRole === item.role
                      ? 'bg-[#e55938]/15 border-[#e55938] shadow-md'
                      : `bg-[#181f2b] border-[#293446] ${item.border}`
                  }`}
                >
                  <div className="p-2 rounded-lg bg-[#222c3b] shrink-0 mt-0.5">
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-sm text-white">{item.title}</h4>
                      {selectedRole === item.role && (
                        <div className="w-4 h-4 rounded-full bg-[#e55938] text-white flex items-center justify-center">
                          <Check className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </button>
              ))}
            </div>

            <button
              id="enter-platform-btn"
              onClick={handleFinishRoleSelection}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-[#e55938] to-[#cc4626] hover:from-[#d64a2a] hover:to-[#be3b1e] text-white font-extrabold rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-[#e55938]/25"
            >
              <span>Enter Brick Exchange</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
