import React, { Component, ReactNode, ErrorInfo } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Task Pro Earning Error Boundary caught an error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: '#0f172a',
          color: '#ffffff',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'system-ui, -apple-system, sans-serif',
          padding: '24px',
          textAlign: 'center',
          zIndex: 999999
        }}>
          <h1 style={{ fontSize: '26px', fontWeight: 900, marginBottom: '8px', color: '#38bdf8' }}>
            Task Pro Earning
          </h1>
          <p style={{ fontSize: '14px', color: '#f87171', marginBottom: '16px', fontWeight: 'bold' }}>
            Something went wrong
          </p>
          <p style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '24px', maxWidth: '320px', wordBreak: 'break-word' }}>
            {this.state.error?.message || 'Application encountered a runtime error'}
          </p>
          <div style={{ display: 'flex', gap: '12px', width: '100%', maxWidth: '280px', justifyContent: 'center' }}>
            <button 
              onClick={() => window.location.reload()}
              style={{ flex: 1, padding: '12px', background: '#2563eb', color: '#ffffff', borderRadius: '12px', fontWeight: 'bold', fontSize: '13px', border: 'none', cursor: 'pointer' }}
            >
              Retry
            </button>
            <button 
              onClick={() => window.location.reload()}
              style={{ flex: 1, padding: '12px', background: '#334155', color: '#ffffff', borderRadius: '12px', fontWeight: 'bold', fontSize: '13px', border: 'none', cursor: 'pointer' }}
            >
              Restart App
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
