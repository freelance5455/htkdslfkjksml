import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { Lock, Delete, Shield, Check, X } from 'lucide-react';

export const PinLockModal: React.FC = () => {
  const { isLocked, unlockApp, settings, setPin, removePin, activeModal, setActiveModal, t, language } = useKhata();
  const [pinInput, setPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [step, setStep] = useState<'enter' | 'create_first' | 'create_confirm'>('create_first');
  const [errorMsg, setErrorMsg] = useState('');

  // Unlock mode (when app is locked on start or manual lock)
  if (isLocked) {
    const handleDigit = (digit: string) => {
      if (pinInput.length < 4) {
        const next = pinInput + digit;
        setPinInput(next);
        setErrorMsg('');
        if (next.length === 4) {
          const success = unlockApp(next);
          if (!success) {
            setErrorMsg(t.pinIncorrect);
            setTimeout(() => setPinInput(''), 400);
          } else {
            setPinInput('');
          }
        }
      }
    };

    const handleDelete = () => {
      setPinInput(prev => prev.slice(0, -1));
      setErrorMsg('');
    };

    return (
      <div className="fixed inset-0 z-50 bg-slate-900 flex flex-col items-center justify-center p-6 text-white select-none">
        <div className="w-16 h-16 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center mb-6">
          <Lock className="w-8 h-8 text-emerald-400" />
        </div>

        <h2 className="text-xl font-bold tracking-tight mb-1">{t.appLocked}</h2>
        <p className="text-sm text-slate-400 mb-8">{t.enterPin}</p>

        {/* PIN Dots */}
        <div className="flex gap-4 mb-8">
          {[0, 1, 2, 3].map(i => (
            <div
              key={i}
              className={`w-4 h-4 rounded-full transition-all duration-150 ${
                pinInput.length > i ? 'bg-emerald-400 scale-110 shadow-sm shadow-emerald-400/50' : 'bg-slate-700'
              }`}
            />
          ))}
        </div>

        {errorMsg && <p className="text-rose-400 text-xs font-medium mb-6 animate-shake">{errorMsg}</p>}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-4 w-full max-w-[280px]">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
            <button
              key={num}
              onClick={() => handleDigit(num)}
              className="h-16 rounded-2xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-xl font-semibold transition active:scale-95 flex items-center justify-center"
            >
              {num}
            </button>
          ))}
          <div />
          <button
            onClick={() => handleDigit('0')}
            className="h-16 rounded-2xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-xl font-semibold transition active:scale-95 flex items-center justify-center"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-16 rounded-2xl bg-slate-800/60 hover:bg-slate-700 text-slate-300 active:scale-95 flex items-center justify-center"
          >
            <Delete className="w-6 h-6" />
          </button>
        </div>
      </div>
    );
  }

  // Settings Security Config Modal
  if (activeModal === 'security') {
    const handleSavePin = () => {
      if (pinInput.length !== 4) {
        setErrorMsg('4 अंकों का पिन दर्ज करें / Enter 4 digits');
        return;
      }
      if (step === 'create_first') {
        setStep('create_confirm');
        setErrorMsg('');
      } else if (step === 'create_confirm') {
        if (pinInput !== confirmPinInput) {
          setErrorMsg(t.pinMismatch);
          setConfirmPinInput('');
          return;
        }
        setPin(pinInput);
        setActiveModal(null);
        setPinInput('');
        setConfirmPinInput('');
        setStep('create_first');
      }
    };

    const handleRemovePin = () => {
      removePin();
      setActiveModal(null);
    };

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
        <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-600" />
              <h3 className="text-base font-bold text-slate-900">{t.securityTitle}</h3>
            </div>
            <button
              onClick={() => {
                setActiveModal(null);
                setPinInput('');
                setConfirmPinInput('');
                setStep('create_first');
              }}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {settings.pinLockEnabled ? (
            <div className="space-y-4">
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 text-xs">
                <Check className="w-4 h-4 inline-block mr-1 text-emerald-600" />
                {language === 'hi' ? 'पिन लॉक वर्तमान में सक्रिय है।' : 'PIN Lock is currently active.'}
              </div>
              <button
                onClick={handleRemovePin}
                className="w-full py-2.5 px-4 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 font-semibold text-xs border border-rose-200 transition"
              >
                {language === 'hi' ? 'पिन लॉक हटाएं (Disable PIN)' : 'Disable PIN Lock'}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                {step === 'create_first'
                  ? language === 'hi' ? 'नया 4-अंकीय सुरक्षा पिन दर्ज करें:' : 'Enter a new 4-digit security PIN:'
                  : t.confirmPin}
              </p>

              {step === 'create_first' ? (
                <input
                  type="password"
                  maxLength={4}
                  value={pinInput}
                  onChange={e => setPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••"
                  className="w-full text-center text-2xl tracking-widest py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                  autoFocus
                />
              ) : (
                <input
                  type="password"
                  maxLength={4}
                  value={confirmPinInput}
                  onChange={e => setConfirmPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••"
                  className="w-full text-center text-2xl tracking-widest py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                  autoFocus
                />
              )}

              {errorMsg && <p className="text-rose-600 text-xs font-medium">{errorMsg}</p>}

              <button
                onClick={handleSavePin}
                className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition"
              >
                {step === 'create_first'
                  ? language === 'hi' ? 'अगला (Next)' : 'Next'
                  : language === 'hi' ? 'पिन सहेजें (Confirm & Save)' : 'Confirm & Save PIN'}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
};
