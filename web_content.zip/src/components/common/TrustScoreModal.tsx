import React from 'react';
import { ProviderProfile } from '../../types';
import { X, Award, ShieldCheck, Star, Clock, CheckCircle2 } from 'lucide-react';

interface TrustScoreModalProps {
  provider: ProviderProfile;
  onClose: () => void;
}

export const TrustScoreModal: React.FC<TrustScoreModalProps> = ({ provider, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Award className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Mohalla Trust Score</h3>
              <p className="text-xs text-slate-500">Transparent Safety & Quality Algorithm</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Score Display */}
        <div className="my-5 p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-emerald-500/10 to-teal-500/10 border border-amber-200 text-center">
          <span className="text-4xl font-black text-slate-900">{provider.trustScore}</span>
          <span className="text-slate-400 font-bold text-lg"> / 100</span>
          <p className="text-xs font-bold text-emerald-800 mt-1">
            {provider.trustScore >= 90
              ? '🏆 Highly Trusted & Certified Professional'
              : provider.trustScore >= 80
              ? '⭐ Reliable Verified Provider'
              : '⚡ Standard Platform Member'}
          </p>
        </div>

        {/* Breakdown Factors */}
        <div className="space-y-3 text-xs">
          <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <span className="font-bold text-slate-900 block">Identity & CNIC Verified</span>
                <span className="text-[11px] text-slate-500">Government Nadra CNIC document</span>
              </div>
            </div>
            <span className="font-bold text-emerald-700">
              {provider.verificationStatus === 'verified' ? '+30 pts' : 'Pending'}
            </span>
          </div>

          <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-500 shrink-0" />
              <div>
                <span className="font-bold text-slate-900 block">
                  Customer Rating ({provider.rating.toFixed(1)} / 5.0)
                </span>
                <span className="text-[11px] text-slate-500">{provider.reviewCount} verified reviews</span>
              </div>
            </div>
            <span className="font-bold text-emerald-700">
              +{Math.round((provider.rating / 5) * 40)} pts
            </span>
          </div>

          <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <span className="font-bold text-slate-900 block">
                  Completed Jobs ({provider.completedJobs})
                </span>
                <span className="text-[11px] text-slate-500">Verified platform transactions</span>
              </div>
            </div>
            <span className="font-bold text-emerald-700">
              +{Math.min(20, Math.round((provider.completedJobs / 100) * 20))} pts
            </span>
          </div>

          <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-600 shrink-0" />
              <div>
                <span className="font-bold text-slate-900 block">
                  Punctuality & Low Cancellation
                </span>
                <span className="text-[11px] text-slate-500">
                  {provider.onTimePercentage}% on-time arrival
                </span>
              </div>
            </div>
            <span className="font-bold text-emerald-700">
              +{Math.round((provider.onTimePercentage / 100) * 10)} pts
            </span>
          </div>
        </div>

        <div className="mt-5">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
