import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { CategoryIcon } from './CategoryIcon';
import { X, Check } from 'lucide-react';
import { TransactionType } from '../../types';

const POPULAR_ICONS = [
  'Tag', 'Coffee', 'Utensils', 'Pizza', 'Car', 'Bike', 'Baby', 'Gamepad2',
  'Gift', 'Stethoscope', 'Wrench', 'Smartphone', 'Laptop', 'Plane', 'Home',
  'ShoppingBag', 'Tv', 'Briefcase', 'GraduationCap', 'Heart'
];

const PRESET_COLORS = [
  '#16a34a', '#0284c7', '#ea580c', '#eab308', '#dc2626',
  '#9333ea', '#db2777', '#0d9488', '#4f46e5', '#475569'
];

export const AddCategoryModal: React.FC = () => {
  const { activeModal, setActiveModal, addCategory, language, t } = useKhata();
  const [nameHi, setNameHi] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [type, setType] = useState<TransactionType>('expense');
  const [selectedIcon, setSelectedIcon] = useState('Tag');
  const [selectedColor, setSelectedColor] = useState('#16a34a');
  const [budgetLimit, setBudgetLimit] = useState('');

  if (activeModal !== 'add-category') return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameHi.trim() && !nameEn.trim()) return;

    addCategory({
      nameHi: nameHi.trim() || nameEn.trim(),
      nameEn: nameEn.trim() || nameHi.trim(),
      icon: selectedIcon,
      color: selectedColor,
      type,
      budgetLimit: budgetLimit ? parseFloat(budgetLimit) : undefined
    });

    setActiveModal(null);
    setNameHi('');
    setNameEn('');
    setBudgetLimit('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-sm rounded-2xl bg-white shadow-2xl border border-slate-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-slate-900">{t.addCustomCategory}</h3>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Type Toggle */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`py-1.5 text-xs font-semibold rounded-md transition ${
                type === 'expense' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              {t.expenses}
            </button>
            <button
              type="button"
              onClick={() => setType('income')}
              className={`py-1.5 text-xs font-semibold rounded-md transition ${
                type === 'income' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              {t.income}
            </button>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {language === 'hi' ? 'श्रेणी का नाम (हिंदी)' : 'Category Name (Hindi)'} *
            </label>
            <input
              type="text"
              required
              value={nameHi}
              onChange={e => setNameHi(e.target.value)}
              placeholder="उदा. जिम फीस, पालतू खर्च..."
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {language === 'hi' ? 'श्रेणी का नाम (English)' : 'Category Name (English)'}
            </label>
            <input
              type="text"
              value={nameEn}
              onChange={e => setNameEn(e.target.value)}
              placeholder="e.g. Gym Fees, Pet Care..."
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Color Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">रंग (Color)</label>
            <div className="flex flex-wrap gap-2">
              {PRESET_COLORS.map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setSelectedColor(c)}
                  className={`w-6 h-6 rounded-full transition-transform ${
                    selectedColor === c ? 'scale-125 ring-2 ring-offset-2 ring-slate-900' : 'hover:scale-110'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          {/* Icon Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.newCategoryIcon}</label>
            <div className="grid grid-cols-5 gap-2 max-h-32 overflow-y-auto p-1 bg-slate-50 rounded-xl border border-slate-200">
              {POPULAR_ICONS.map(ic => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setSelectedIcon(ic)}
                  className={`p-2 rounded-lg flex items-center justify-center transition ${
                    selectedIcon === ic
                      ? 'bg-emerald-100 text-emerald-800 ring-1 ring-emerald-600'
                      : 'bg-white text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <CategoryIcon name={ic} className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>

          {type === 'expense' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {language === 'hi' ? 'मासिक बजट सीमा (वैकल्पिक)' : 'Monthly Budget Limit (Optional)'}
              </label>
              <input
                type="number"
                value={budgetLimit}
                onChange={e => setBudgetLimit(e.target.value)}
                placeholder="₹ 2000"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>{t.save}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
