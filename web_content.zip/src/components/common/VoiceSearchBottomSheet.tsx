import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, Mic, RefreshCw, AlertCircle } from 'lucide-react';

export type VoiceState =
  | 'IDLE'
  | 'REQUESTING_PERMISSION'
  | 'LISTENING'
  | 'PROCESSING'
  | 'RESULTS'
  | 'ERROR'
  | 'PERMISSION_DENIED'
  | 'UNSUPPORTED';

interface VoiceSearchBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onQueryRecognized: (query: string) => void;
}

export const VoiceSearchBottomSheet: React.FC<VoiceSearchBottomSheetProps> = ({
  isOpen,
  onClose,
  onQueryRecognized,
}) => {
  const [voiceState, setVoiceState] = useState<VoiceState>('IDLE');
  const [transcript, setTranscript] = useState('');
  const [volumeLevel, setVolumeLevel] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  const [animTick, setAnimTick] = useState(0);

  const recognitionRef = useRef<any>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isCleaningUpRef = useRef(false);

  const stopAllAudio = useCallback(() => {
    isCleaningUpRef.current = true;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {
        // Ignore
      }
      recognitionRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch {
        // Ignore
      }
      audioContextRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // Ignore
        }
      });
      mediaStreamRef.current = null;
    }
    setVolumeLevel(0);
  }, []);

  const handleSafeClose = useCallback(() => {
    stopAllAudio();
    setVoiceState('IDLE');
    setTranscript('');
    onClose();
  }, [stopAllAudio, onClose]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleSafeClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, handleSafeClose]);

  const startAudioAnalyzer = (stream: MediaStream) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;
      if (audioCtx.state === 'suspended') {
        audioCtx.resume().catch(() => {});
      }
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.5;
      analyserRef.current = analyser;

      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      let step = 0;

      const updateVolume = () => {
        if (!analyserRef.current || isCleaningUpRef.current) return;
        step++;
        setAnimTick(step);
        analyserRef.current.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        const normalized = Math.min(1, Math.max(0, avg / 90));
        setVolumeLevel(normalized);

        animFrameRef.current = requestAnimationFrame(updateVolume);
      };
      updateVolume();
    } catch {
      // Fallback
    }
  };

  const startVoiceSearchPipeline = useCallback(async () => {
    stopAllAudio();
    isCleaningUpRef.current = false;
    setTranscript('');
    setErrorMessage('');
    setVoiceState('REQUESTING_PERMISSION');

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setVoiceState('UNSUPPORTED');
      setErrorMessage('Voice search is not supported on this browser. Please type your search.');
      return;
    }

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;
        startAudioAnalyzer(stream);
      }
    } catch (err: any) {
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setVoiceState('PERMISSION_DENIED');
        setErrorMessage('Microphone permission is required for voice search.');
        return;
      }
    }

    try {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = navigator.language || 'en-IN';

      recognition.onstart = () => {
        setVoiceState('LISTENING');
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        const trimmed = currentTranscript.trim();
        setTranscript(trimmed);

        if (event.results[0] && event.results[0].isFinal) {
          if (trimmed.length > 0) {
            setVoiceState('PROCESSING');
            stopAllAudio();
            setTimeout(() => {
              setVoiceState('RESULTS');
              setTimeout(() => {
                onQueryRecognized(trimmed);
                handleSafeClose();
              }, 300);
            }, 400);
          } else {
            setVoiceState('ERROR');
            setErrorMessage('Could not hear anything. Please try speaking again.');
          }
        }
      };

      recognition.onerror = (event: any) => {
        stopAllAudio();
        if (event.error === 'not-allowed') {
          setVoiceState('PERMISSION_DENIED');
          setErrorMessage('Microphone permission is required for voice search.');
        } else if (event.error === 'no-speech') {
          setVoiceState('ERROR');
          setErrorMessage('No speech detected. Please try speaking again.');
        } else {
          setVoiceState('ERROR');
          setErrorMessage('Could not catch that. Please speak again.');
        }
      };

      recognition.onend = () => {
        if (voiceState === 'LISTENING' && !transcript) {
          setVoiceState('ERROR');
          setErrorMessage('Could not catch that. Please speak again.');
        }
      };

      recognition.start();
    } catch {
      setVoiceState('ERROR');
      setErrorMessage('Could not start voice search. Please try again.');
    }
  }, [stopAllAudio, onQueryRecognized, handleSafeClose, voiceState, transcript]);

  useEffect(() => {
    if (isOpen) {
      startVoiceSearchPipeline();
    } else {
      stopAllAudio();
    }
    return () => {
      stopAllAudio();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const baseHeights = [14, 26, 42, 58, 72, 58, 42, 26, 14];
  const barHeights = baseHeights.map((bh, idx) => {
    if (voiceState === 'LISTENING') {
      const livePulse = Math.sin(animTick * 0.15 + idx * 0.8) * 6;
      const multiplier = 0.4 + volumeLevel * 1.35;
      const variation = Math.sin((idx + 1) * 1.2 + volumeLevel * 10) * 8 + livePulse;
      return Math.min(84, Math.max(14, Math.round(bh * multiplier + variation)));
    }
    if (voiceState === 'PROCESSING') {
      return 18 + Math.round(Math.sin(animTick * 0.2 + idx * 0.8) * 8);
    }
    return 12;
  });

  return (
    <div
      onClick={handleSafeClose}
      className="fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px] flex flex-col justify-end sm:justify-center items-center animate-in fade-in duration-300 p-0 sm:p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg mx-auto bg-white rounded-t-[32px] sm:rounded-[32px] border-t sm:border border-[#EAEAEA] shadow-2xl p-5 sm:p-7 flex flex-col items-center animate-in slide-in-from-bottom sm:zoom-in-95 duration-300 ease-out"
        style={{
          paddingBottom: 'max(1.75rem, env(safe-area-inset-bottom, 24px))',
        }}
      >
        <div className="w-full flex items-center justify-between pb-3 border-b border-[#FAFAFA]">
          <div className="text-left">
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight">
              Listening...
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Speak now to search products
            </p>
          </div>
          <button
            onClick={handleSafeClose}
            className="w-9 h-9 rounded-full bg-[#FAFAFA] hover:bg-[#EAEAEA] text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close voice search"
          >
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        <div className="my-6 sm:my-8 flex flex-col items-center justify-center min-h-[160px] w-full">
          {voiceState === 'PERMISSION_DENIED' ? (
            <div className="text-center px-4 max-w-sm">
              <div className="w-16 h-16 rounded-full bg-[#FAFAFA] border border-[#EAEAEA] text-[#000000] flex items-center justify-center mx-auto mb-3 shadow-sm">
                <AlertCircle className="w-8 h-8 text-[#000000]" />
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                Microphone permission is required.
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                Please grant microphone access to search by voice.
              </p>
              <div className="mt-5 flex items-center justify-center gap-2.5">
                <button
                  onClick={() => startVoiceSearchPipeline()}
                  className="px-5 py-2.5 rounded-full bg-[#000000] hover:bg-neutral-800 text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  Try Again
                </button>
                <button
                  onClick={handleSafeClose}
                  className="px-5 py-2.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : voiceState === 'ERROR' ? (
            <div className="text-center px-4 max-w-sm">
              <div className="w-16 h-16 rounded-full bg-[#FAFAFA] border border-[#EAEAEA] text-[#000000] flex items-center justify-center mx-auto mb-3">
                <Mic className="w-7 h-7 text-[#000000]" />
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                {errorMessage || 'Could not catch that. Please speak again.'}
              </h3>
              <div className="mt-5 flex items-center justify-center gap-2.5">
                <button
                  onClick={() => startVoiceSearchPipeline()}
                  className="px-5 py-2.5 rounded-full bg-[#000000] hover:bg-neutral-800 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Try Again</span>
                </button>
                <button
                  onClick={handleSafeClose}
                  className="px-5 py-2.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center w-full">
              <div className="relative flex items-center justify-center gap-2 sm:gap-2.5 my-2">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  {barHeights.slice(0, 4).map((h, i) => (
                    <div
                      key={`l-${i}`}
                      style={{ height: `${h}px` }}
                      className="w-1.5 sm:w-2 rounded-full bg-[#FFD400] transition-all duration-100 ease-out"
                    />
                  ))}
                </div>

                <div className="relative mx-2 sm:mx-3 flex items-center justify-center">
                  {voiceState === 'LISTENING' && (
                    <>
                      <div className="absolute inset-0 rounded-full bg-[#FFD400]/40 animate-ping" />
                      <div
                        className="absolute -inset-2.5 rounded-full bg-[#FFD400]/20 transition-all duration-150"
                        style={{
                          transform: `scale(${1 + volumeLevel * 0.4})`,
                        }}
                      />
                    </>
                  )}
                  {voiceState === 'PROCESSING' && (
                    <div className="absolute -inset-2 rounded-full border-2 border-[#000000] border-t-transparent animate-spin" />
                  )}
                  <button
                    onClick={() => {
                      if (voiceState === 'LISTENING') {
                        stopAllAudio();
                        setVoiceState('IDLE');
                      } else {
                        startVoiceSearchPipeline();
                      }
                    }}
                    className="relative w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-[#000000] hover:bg-neutral-800 active:scale-95 text-[#FFD400] flex items-center justify-center shadow-lg shadow-black/20 transition-all cursor-pointer"
                    aria-label="Microphone"
                  >
                    {voiceState === 'PROCESSING' ? (
                      <RefreshCw className="w-8 h-8 animate-spin text-white" />
                    ) : (
                      <Mic className="w-8 h-8 text-white transition-transform" />
                    )}
                  </button>
                </div>

                <div className="flex items-center gap-1.5 sm:gap-2">
                  {barHeights.slice(5).map((h, i) => (
                    <div
                      key={`r-${i}`}
                      style={{ height: `${h}px` }}
                      className="w-1.5 sm:w-2 rounded-full bg-[#FFD400] transition-all duration-100 ease-out"
                    />
                  ))}
                </div>
              </div>

              <div className="mt-4 text-center">
                <span className="inline-block text-xs sm:text-sm font-bold text-[#000000] uppercase tracking-wider">
                  {voiceState === 'LISTENING' && 'Listening...'}
                  {voiceState === 'PROCESSING' && 'Searching...'}
                  {voiceState === 'RESULTS' && 'Showing products...'}
                  {voiceState === 'REQUESTING_PERMISSION' && 'Starting Microphone...'}
                </span>
                <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                  {voiceState === 'LISTENING' && 'Speak your search query'}
                  {voiceState === 'PROCESSING' && 'Searching products...'}
                  {voiceState === 'RESULTS' && 'Loading results...'}
                </p>
              </div>

              <div className="mt-4 px-4 py-3 rounded-2xl bg-[#FAFAFA]/60 border border-[#EAEAEA] min-h-[48px] max-w-sm sm:max-w-md w-full flex items-center justify-center text-center">
                {transcript ? (
                  <p className="text-sm sm:text-base font-bold text-slate-900 break-words">
                    "{transcript}"
                  </p>
                ) : (
                  <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                    <span className="w-2 h-2 rounded-full bg-[#000000] animate-ping" />
                    <span>Listening to your voice... Speak now</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="w-full pt-3 border-t border-[#FAFAFA] flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1.5 font-medium">
            <Mic className="w-3.5 h-3.5 text-[#000000]" />
            OMAZIFY Voice Assistant
          </span>
          <span className="font-bold text-emerald-700">
            Cash on Delivery Available
          </span>
        </div>
      </div>
    </div>
  );
};
