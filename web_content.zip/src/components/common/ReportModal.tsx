import React, { useState } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import { UserReport, ProviderProfile } from '../../types';
import { AlertTriangle, X, ShieldAlert } from 'lucide-react';

interface ReportModalProps {
  provider: ProviderProfile;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({ provider, onClose }) => {
  const { currentUser, submitReport } = useMohalla();
  const [category, setCategory] = useState<UserReport['category']>('Fraud');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    submitReport({
      reporterId: currentUser.id,
      reporterName: currentUser.name,
      reporterRole: currentUser.role,
      targetId: provider.id,
      targetName: provider.businessName,
      targetType: 'provider',
      category,
      description: description.trim(),
    });

    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2 text-rose-600">
            <ShieldAlert className="w-5 h-5" />
            <h3 className="font-bold text-slate-900 text-base">Report Provider</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-2">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto font-bold text-xl">
              ✓
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Report Submitted</h4>
            <p className="text-xs text-slate-500">
              Our Karachi safety operations team will investigate this report within 2 hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            <p className="text-xs text-slate-500">
              Reporting: <span className="font-bold text-slate-800">{provider.businessName}</span>
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Select Violation Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as UserReport['category'])}
                className="w-full p-2.5 rounded-xl border border-slate-300 text-xs text-slate-800"
              >
                <option value="Fraud">Fraud or Overcharging</option>
                <option value="Bad behavior">Rude / Inappropriate Behavior</option>
                <option value="Unsafe">Unsafe Workmanship</option>
                <option value="Fake profile">Fake Profile or Impersonation</option>
                <option value="Payment issue">Demanding Unagreed Cash Advance</option>
                <option value="Harassment">Harassment</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Detailed Incident Description
              </label>
              <textarea
                required
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Please describe what happened in detail..."
                className="w-full p-3 rounded-xl border border-slate-300 text-xs text-slate-800 focus:border-rose-500"
              />
            </div>

            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md cursor-pointer"
              >
                Submit Report to Admin
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
