import React, { useState, useRef, useCallback } from 'react';
import { Chess, Square } from 'chess.js';
import { BoardStyle, PieceStyle, PieceColor, PieceType } from '../../types/chess';
import { get2DBoardGrid, isLightSquare } from '../../services/chessCoordinates';

interface ChessBoard2DProps {
  game: Chess;
  boardStyle: BoardStyle;
  pieceStyle: PieceStyle;
  playerPerspective: 'w' | 'b';
  selectedSquare: Square | null;
  legalMoves: string[];
  lastMove: { from: string; to: string } | null;
  hintMove: { from: string; to: string } | null;
  showCoordinates?: boolean;
  interactive: boolean;
  onSquareClick: (square: Square) => void;
  onMoveAttempt?: (from: Square, to: Square) => void;
}

// Crisp Vector Chess Pieces
const PIECE_SYMBOLS: Record<PieceColor, Record<PieceType, string>> = {
  w: {
    k: '♔',
    q: '♕',
    r: '♖',
    b: '♗',
    n: '♘',
    p: '♙',
  },
  b: {
    k: '♚',
    q: '♛',
    r: '♜',
    b: '♝',
    n: '♞',
    p: '♟',
  },
};

// SVG Piece Renderers for maximum crispness across all screen densities
export const ChessPieceSVG: React.FC<{
  type: PieceType;
  color: PieceColor;
  className?: string;
}> = ({ type, color, className = 'w-full h-full' }) => {
  const isWhite = color === 'w';
  const fill = isWhite ? '#FFFFFF' : '#171E2B';
  const stroke = isWhite ? '#2C3E50' : '#E2E8F0';
  const accent = isWhite ? '#D1D5DB' : '#0B0F19';

  switch (type) {
    case 'p':
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <path
            d="m 22.5,9 c -2.21,0 -4,1.79 -4,4 0,0.89 0.29,1.71 0.78,2.38 C 17.33,16.5 16,18.59 16,21 c 0,2.03 0.94,3.84 2.41,5.03 C 15.41,27.09 11,31.58 11,39.5 l 23,0 c 0,-7.92 -4.41,-12.41 -7.41,-13.47 C 28.06,24.84 29,23.03 29,21 29,18.59 27.67,16.5 25.72,15.38 26.21,14.71 26.5,13.89 26.5,13 c 0,-2.21 -1.79,-4 -4,-4 z"
            fill={fill}
            stroke={stroke}
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'n':
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <path
            d="m 22,10 c 10.5,1 16.5,8 16,29 l -23,0 c 0,-9 10,-6.5 8,-21"
            fill={fill}
            stroke={stroke}
            strokeWidth="1.6"
          />
          <path
            d="M 24,18 C 24.38,20.91 18.45,25.37 16,27 c -1.5,2 -2.5,5.5 -2.5,9.5 l 23,0 c 0,-8 -3.5,-12.5 -6.5,-16.5 C 27,16 26.5,13.5 26,11 c -1.25,0 -2.5,0.5 -3.5,1.5 c -1.5,1.5 -1.75,3.5 -2,5.5"
            fill={fill}
            stroke={stroke}
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          <circle cx="28.5" cy="18.5" r="1.5" fill={stroke} />
        </svg>
      );
    case 'b':
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g fill={fill} stroke={stroke} strokeWidth="1.6" strokeLinejoin="round">
            <path d="M 9,36 C 12.39,35.03 19.11,36.43 22.5,34 C 25.89,36.43 32.61,35.03 36,36 C 36,36 37.65,36.54 39,38 C 38.32,38.97 37.35,38.99 36,38.5 C 32.61,37.53 25.89,38.96 22.5,37.5 C 19.11,38.96 12.39,37.53 9,38.5 C 7.65,38.99 6.68,38.97 6,38 C 7.35,36.54 9,36 9,36 z" />
            <path d="M 15,32 C 17.5,34.5 27.5,34.5 30,32 C 30.5,30.5 30,30 30,30 C 30,27.5 27.5,26 27.5,26 C 33,24.5 33.5,14.5 22.5,10.5 C 11.5,14.5 12,24.5 17.5,26 C 17.5,26 15,27.5 15,30 C 15,30 14.5,30.5 15,32 z" />
            <path d="M 25 8 A 2.5 2.5 0 0 1 20 8 A 2.5 2.5 0 0 1 25 8 Z" />
            <path d="M 17.5,26 L 27.5,26 M 15,30 L 30,30 M 22.5,15.5 L 22.5,20.5 M 20,18 L 25,18" strokeWidth="1.3" />
          </g>
        </svg>
      );
    case 'r':
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g fill={fill} stroke={stroke} strokeWidth="1.6" strokeLinejoin="round">
            <path d="M 9,39 L 36,39 L 36,36 L 9,36 z" />
            <path d="M 12,36 L 12,32 L 33,32 L 33,36 z" />
            <path d="M 11,14 L 11,9 L 15,9 L 15,11 L 20,11 L 20,9 L 25,9 L 25,11 L 30,11 L 30,9 L 34,9 L 34,14 z" />
            <path d="M 34,14 L 31,17 L 14,17 L 11,14 z" />
            <path d="M 14,17 L 14,32 L 31,32 L 31,17 z" />
          </g>
        </svg>
      );
    case 'q':
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g fill={fill} stroke={stroke} strokeWidth="1.6" strokeLinejoin="round">
            <path d="M 9,26 C 17.5,24.5 30,24.5 36,26 L 38.5,13.5 L 31,25 L 30.7,10.5 L 25.5,24.5 L 22.5,10 L 19.5,24.5 L 14.3,10.5 L 14,25 L 6.5,13.5 z" />
            <path d="M 9,26 C 9,28 10.5,28 11.5,30 C 12.5,31.5 12.5,31 12,33.5 C 10.5,34.5 11,36 11,36 C 9.5,37.5 11,38.5 11,38.5 L 34,38.5 C 34,38.5 35.5,37.5 34,36 C 34,36 34.5,34.5 33,33.5 C 32.5,31 32.5,31.5 33.5,30 C 34.5,28 36,28 36,26 z" />
            <circle cx="6" cy="12" r="2" />
            <circle cx="14" cy="9" r="2" />
            <circle cx="22.5" cy="8" r="2" />
            <circle cx="31" cy="9" r="2" />
            <circle cx="39" cy="12" r="2" />
          </g>
        </svg>
      );
    case 'k':
      return (
        <svg viewBox="0 0 45 45" className={className}>
          <g fill={fill} stroke={stroke} strokeWidth="1.6" strokeLinejoin="round">
            <path d="M 22.5,11.63 L 22.5,6" strokeWidth="1.6" />
            <path d="M 20,8 L 25,8" strokeWidth="1.6" />
            <path d="M 22.5,25 C 22.5,25 27,17.5 25.5,14.5 C 24,11.5 21,11.5 19.5,14.5 C 18,17.5 22.5,25 22.5,25 z" />
            <path d="M 11.5,37 C 17,40.5 28,40.5 33.5,37 C 33.5,34 31,33 30,31 C 29,29 31,27.5 31.5,25.5 C 32,23.5 28.5,23.5 28.5,23.5 C 28.5,23.5 27,24 22.5,24 C 18,24 16.5,23.5 16.5,23.5 C 16.5,23.5 13,23.5 13.5,25.5 C 14,27.5 16,29 15,31 C 14,33 11.5,34 11.5,37 z" />
            <path d="M 11.5,30 C 17,27 28,27 33.5,30 M 11.5,33.5 C 17,30.5 28,30.5 33.5,33.5 M 11.5,37 C 17,34 28,34 33.5,37" strokeWidth="1.2" />
          </g>
        </svg>
      );
    default:
      return null;
  }
};

export const ChessBoard2D: React.FC<ChessBoard2DProps> = ({
  game,
  boardStyle,
  playerPerspective,
  selectedSquare,
  legalMoves,
  lastMove,
  hintMove,
  showCoordinates = true,
  interactive,
  onSquareClick,
  onMoveAttempt,
}) => {
  const [draggedSquare, setDraggedSquare] = useState<Square | null>(null);
  const [dragCoord, setDragCoord] = useState<{ x: number; y: number } | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);

  const grid = get2DBoardGrid(playerPerspective);
  const turn = game.turn();
  const inCheck = game.inCheck();

  // Find Checked King Square
  let checkedKingSquare: Square | null = null;
  if (inCheck) {
    const board = game.board();
    for (let r = 0; r < 8; r++) {
      for (let f = 0; f < 8; f++) {
        const piece = board[r][f];
        if (piece && piece.type === 'k' && piece.color === turn) {
          const fileChar = String.fromCharCode(97 + f);
          const rankChar = (8 - r).toString();
          checkedKingSquare = `${fileChar}${rankChar}` as Square;
          break;
        }
      }
      if (checkedKingSquare) break;
    }
  }

  // Board color theme palettes
  const getSquareColors = (isLight: boolean) => {
    switch (boardStyle) {
      case 'wooden':
        return isLight ? 'bg-[#E6CA9D] text-[#694825]' : 'bg-[#9D6837] text-[#E6CA9D]';
      case 'marble':
        return isLight ? 'bg-[#E5E9F0] text-[#3B4252]' : 'bg-[#6C7A89] text-[#E5E9F0]';
      case 'futuristic':
        return isLight ? 'bg-[#1E293B] text-[#38BDF8]' : 'bg-[#0F172A] text-[#0284C7]';
      case 'glass':
        return isLight ? 'bg-[#E0F2FE]/85 text-[#0369A1]' : 'bg-[#0284C7]/60 text-[#F0F9FF]';
      default:
        // Classic / Dark
        return isLight ? 'bg-[#CBD5E1] text-[#334155]' : 'bg-[#475569] text-[#CBD5E1]';
    }
  };

  const getBoardBorder = () => {
    switch (boardStyle) {
      case 'wooden':
        return 'border-[#5A381E] bg-[#3B2211] shadow-2xl';
      case 'marble':
        return 'border-[#2C3E50] bg-[#1E2836] shadow-2xl';
      case 'futuristic':
        return 'border-[#00D2FF]/40 bg-[#0A0E17] shadow-[0_0_35px_rgba(0,210,255,0.2)]';
      default:
        return 'border-slate-800 bg-[#0C1220] shadow-2xl';
    }
  };

  // Convert client pointer to square
  const getSquareFromEvent = (e: React.PointerEvent | React.MouseEvent): Square | null => {
    if (!boardRef.current) return null;
    const rect = boardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    if (x < 0 || x > rect.width || y < 0 || y > rect.height) return null;

    const col = Math.floor((x / rect.width) * 8);
    const row = Math.floor((y / rect.height) * 8);
    if (row < 0 || row > 7 || col < 0 || col > 7) return null;

    return grid[row][col].square;
  };

  // Pointer Down for Drag & Click
  const handlePointerDown = (e: React.PointerEvent, square: Square) => {
    if (!interactive) return;
    const piece = game.get(square);

    // If tapping an existing selection destination
    if (selectedSquare && selectedSquare !== square) {
      if (onMoveAttempt && legalMoves.includes(square)) {
        onMoveAttempt(selectedSquare, square);
        return;
      }
      onSquareClick(square);
      return;
    }

    if (piece && piece.color === turn) {
      setDraggedSquare(square);
      setDragCoord({ x: e.clientX, y: e.clientY });
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
      onSquareClick(square);
    } else {
      onSquareClick(square);
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (draggedSquare) {
      setDragCoord({ x: e.clientX, y: e.clientY });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!draggedSquare) return;
    const dropSquare = getSquareFromEvent(e);

    if (dropSquare && dropSquare !== draggedSquare) {
      if (onMoveAttempt) {
        onMoveAttempt(draggedSquare, dropSquare);
      } else {
        onSquareClick(dropSquare);
      }
    }

    setDraggedSquare(null);
    setDragCoord(null);
  };

  const handlePointerCancel = () => {
    setDraggedSquare(null);
    setDragCoord(null);
  };

  return (
    <div className="relative w-full aspect-square max-w-[560px] mx-auto select-none touch-none p-2 sm:p-3">
      {/* 2D Board Frame Container */}
      <div
        ref={boardRef}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerCancel}
        className={`relative w-full h-full rounded-2xl border-4 ${getBoardBorder()} overflow-hidden grid grid-rows-8 grid-cols-8 shadow-inner`}
      >
        {grid.map((row, rIdx) =>
          row.map((cell, cIdx) => {
            const { square, isLight, file, rank } = cell;
            const piece = game.get(square);
            const isSelected = selectedSquare === square;
            const isLegal = legalMoves.includes(square);
            const isLastMoveFrom = lastMove?.from === square;
            const isLastMoveTo = lastMove?.to === square;
            const isHint = hintMove?.from === square || hintMove?.to === square;
            const isKingInDanger = checkedKingSquare === square;

            // Coordinates: rank numbers on col 0, file letters on row 7
            const showRank = showCoordinates && cIdx === 0;
            const showFile = showCoordinates && rIdx === 7;

            return (
              <div
                key={square}
                onPointerDown={(e) => handlePointerDown(e, square)}
                className={`relative flex items-center justify-center cursor-pointer transition-colors duration-150 ${getSquareColors(
                  isLight
                )}`}
              >
                {/* Last Move Overlay */}
                {(isLastMoveFrom || isLastMoveTo) && (
                  <div className="absolute inset-0 bg-sky-400/25 pointer-events-none" />
                )}

                {/* Selected Square Accent */}
                {isSelected && (
                  <div className="absolute inset-0 bg-cyan-400/40 ring-4 ring-cyan-400/80 ring-inset z-10 pointer-events-none" />
                )}

                {/* Checked King Warning Aura */}
                {isKingInDanger && (
                  <div className="absolute inset-0 bg-red-600/60 animate-pulse ring-4 ring-red-500 z-10 pointer-events-none" />
                )}

                {/* Hint Move Outline */}
                {isHint && (
                  <div className="absolute inset-1 rounded-lg border-2 border-dashed border-cyan-300 animate-pulse pointer-events-none" />
                )}

                {/* Piece Rendering */}
                {piece && (
                  <div
                    className={`relative w-[82%] h-[82%] flex items-center justify-center transition-transform z-10 ${
                      draggedSquare === square ? 'opacity-25 scale-95' : 'hover:scale-105'
                    }`}
                  >
                    <ChessPieceSVG type={piece.type} color={piece.color} />
                  </div>
                )}

                {/* Legal Move Indicator */}
                {isLegal && (
                  <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
                    {piece ? (
                      // Capture ring
                      <div className="w-[84%] h-[84%] rounded-full border-4 border-red-500/80 bg-red-500/20" />
                    ) : (
                      // Move dot
                      <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-cyan-400/90 shadow-[0_0_8px_rgba(56,189,248,0.8)]" />
                    )}
                  </div>
                )}

                {/* Coordinates Labels */}
                {showRank && (
                  <span className="absolute top-0.5 left-1 text-[9px] sm:text-[11px] font-bold opacity-70 pointer-events-none">
                    {rank}
                  </span>
                )}
                {showFile && (
                  <span className="absolute bottom-0.5 right-1 text-[9px] sm:text-[11px] font-bold opacity-70 pointer-events-none">
                    {file}
                  </span>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Floating Drag Avatar */}
      {draggedSquare && dragCoord && (() => {
        const piece = game.get(draggedSquare);
        if (!piece) return null;
        return (
          <div
            style={{
              position: 'fixed',
              left: `${dragCoord.x}px`,
              top: `${dragCoord.y}px`,
              transform: 'translate(-50%, -50%)',
              pointerEvents: 'none',
              zIndex: 9999,
              width: '64px',
              height: '64px',
            }}
            className="filter drop-shadow-[0_12px_24px_rgba(0,0,0,0.7)] scale-110"
          >
            <ChessPieceSVG type={piece.type} color={piece.color} />
          </div>
        );
      })()}
    </div>
  );
};
