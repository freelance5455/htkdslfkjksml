import React, { useState, useEffect } from 'react';
import { Wifi, Signal, BatteryCharging } from 'lucide-react';
import { AppThemeSettings } from '../../types';

interface AndroidFrameProps {
  themeSettings: AppThemeSettings;
  children: React.ReactNode;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  themeSettings,
  children
}) => {
  const [currentTime, setCurrentTime] = useState('10:42');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const isPhone = themeSettings.deviceMode === 'phone';

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-300 flex items-center justify-center ${
        themeSettings.isDark ? 'dark bg-neutral-950 text-neutral-100' : 'bg-neutral-100 text-neutral-900'
      } ${isPhone ? 'p-2 sm:p-6 lg:p-8' : 'p-0'}`}
    >
      <div
        className={`relative flex flex-col overflow-hidden transition-all duration-300 ${
          isPhone
            ? 'w-full max-w-[430px] h-[915px] max-h-[96vh] rounded-[44px] shadow-2xl border-[9px] border-neutral-800 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 ring-1 ring-black/20'
            : 'w-full max-w-5xl min-h-screen sm:my-4 sm:rounded-2xl sm:shadow-lg border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900'
        }`}
      >
        {/* Android Status Bar */}
        <div className="shrink-0 flex items-center justify-between px-6 pt-3 pb-1 text-xs font-medium text-neutral-700 dark:text-neutral-300 select-none z-40 bg-white/70 dark:bg-neutral-900/70 backdrop-blur-sm">
          {/* Clock */}
          <span className="font-semibold text-xs tracking-tight">{currentTime}</span>

          {/* Front Camera Hole-punch (Phone mode only) */}
          {isPhone && (
            <div className="w-4 h-4 bg-black rounded-full mx-auto ring-1 ring-neutral-800/40" />
          )}

          {/* System Indicators */}
          <div className="flex items-center gap-1.5 text-neutral-700 dark:text-neutral-300">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px]">98%</span>
              <BatteryCharging className="w-4 h-4 text-emerald-500 fill-emerald-500/20" />
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-y-auto relative bg-neutral-50 dark:bg-neutral-900">
          {children}
        </div>

        {/* Android Gesture Bar */}
        <div className="shrink-0 py-1.5 flex justify-center items-center bg-neutral-50/90 dark:bg-neutral-900/90 z-30">
          <div className="w-32 h-1 bg-neutral-400 dark:bg-neutral-600 rounded-full" />
        </div>
      </div>
    </div>
  );
};
