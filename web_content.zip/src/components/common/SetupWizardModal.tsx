import React, { useState } from 'react';
import { Database, Copy, Check, ExternalLink, Key, RefreshCw, X, ShieldCheck } from 'lucide-react';
import { NEXA_DATABASE_MIGRATION_SQL } from '../../lib/migration-sql';
import {
  getSupabaseCredentials,
  saveCustomSupabaseCredentials,
  clearCustomSupabaseCredentials,
  sanitizeSupabaseUrl,
  sanitizeSupabaseKey,
} from '../../lib/supabase';

type SetupWizardModalProps = {
  isOpen: boolean;
  onClose?: () => void;
  isForced?: boolean;
};

export const SetupWizardModal: React.FC<SetupWizardModalProps> = ({
  isOpen,
  onClose,
  isForced = false,
}) => {
  const currentCreds = getSupabaseCredentials();
  const [url, setUrl] = useState(currentCreds.url);
  const [key, setKey] = useState(currentCreds.key);
  const [copiedSql, setCopiedSql] = useState(false);
  const [activeTab, setActiveTab] = useState<'credentials' | 'sql'>('credentials');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [urlError, setUrlError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopySql = () => {
    navigator.clipboard.writeText(NEXA_DATABASE_MIGRATION_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setUrlError(null);

    const cleanUrl = sanitizeSupabaseUrl(url);
    const cleanKey = sanitizeSupabaseKey(key);

    if (!cleanUrl) {
      setUrlError('Please enter a valid Supabase project URL (e.g. https://your-project.supabase.co)');
      return;
    }
    if (!cleanKey) {
      setUrlError('Please enter a valid Supabase anon/publishable key.');
      return;
    }

    saveCustomSupabaseCredentials(cleanUrl, cleanKey);
    setSaveSuccess(true);
  };

  const handleReset = () => {
    clearCustomSupabaseCredentials();
  };

  return (
    <div
      id="setup-wizard-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in"
    >
      <div
        id="setup-wizard-modal"
        className="w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-white"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/40">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-neutral-100">Supabase Backend Configuration</h2>
              <p className="text-xs text-neutral-400">PostgreSQL, Realtime, Storage & Auth for Nexa</p>
            </div>
          </div>
          {!isForced && onClose && (
            <button
              id="setup-wizard-close-btn"
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-neutral-800 bg-neutral-900/60 px-6 pt-2">
          <button
            id="tab-btn-credentials"
            onClick={() => setActiveTab('credentials')}
            className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors flex items-center space-x-2 ${
              activeTab === 'credentials'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Key className="w-4 h-4" />
            <span>Connection Keys</span>
          </button>
          <button
            id="tab-btn-sql"
            onClick={() => setActiveTab('sql')}
            className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors flex items-center space-x-2 ${
              activeTab === 'sql'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Database SQL Migration</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {activeTab === 'credentials' ? (
            <form onSubmit={handleSave} className="space-y-4">
              <div className="p-3.5 bg-neutral-800/60 border border-neutral-700/60 rounded-xl space-y-1.5 text-xs text-neutral-300">
                <p className="font-semibold text-neutral-200 flex items-center space-x-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Production Credentials Instructions</span>
                </p>
                <p>
                  You can provide these keys in your <code className="text-emerald-300 bg-neutral-950 px-1 py-0.5 rounded">.env</code> file (as <code className="text-emerald-300 bg-neutral-950 px-1 py-0.5 rounded">VITE_SUPABASE_URL</code> and <code className="text-emerald-300 bg-neutral-950 px-1 py-0.5 rounded">VITE_SUPABASE_PUBLISHABLE_KEY</code>) or enter them below directly.
                </p>
                <p className="text-neutral-400">
                  ⚠️ Note: Under Supabase Dashboard → <strong>Authentication</strong> → <strong>Providers</strong> → <strong>Email</strong>, turn off <em>Confirm email</em> so @username accounts activate immediately.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Project URL (VITE_SUPABASE_URL)
                </label>
                <input
                  id="input-supabase-url"
                  type="url"
                  required
                  placeholder="https://your-project.supabase.co"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  Anon / Publishable Key (VITE_SUPABASE_PUBLISHABLE_KEY)
                </label>
                <textarea
                  id="input-supabase-key"
                  required
                  rows={3}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-sm font-mono text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 resize-none"
                />
              </div>

              {urlError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center space-x-2">
                  <X className="w-4 h-4 shrink-0" />
                  <span>{urlError}</span>
                </div>
              )}

              {saveSuccess && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs flex items-center space-x-2">
                  <Check className="w-4 h-4" />
                  <span>Credentials saved! Reloading client...</span>
                </div>
              )}

              <div className="flex items-center justify-between pt-2">
                <button
                  id="btn-reset-credentials"
                  type="button"
                  onClick={handleReset}
                  className="text-xs text-neutral-400 hover:text-red-400 transition-colors flex items-center space-x-1"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset saved keys</span>
                </button>

                <div className="flex items-center space-x-3">
                  {!isForced && onClose && (
                    <button
                      id="btn-close-wizard"
                      type="button"
                      onClick={onClose}
                      className="px-4 py-2 text-sm text-neutral-400 hover:text-white rounded-xl bg-neutral-800 hover:bg-neutral-700 transition-colors"
                    >
                      Close
                    </button>
                  )}
                  <button
                    id="btn-save-credentials"
                    type="submit"
                    className="px-5 py-2 text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-lg shadow-emerald-900/30 transition-all flex items-center space-x-2"
                  >
                    <Check className="w-4 h-4" />
                    <span>Save & Connect</span>
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-neutral-200">Production SQL Migration Script</h3>
                  <p className="text-xs text-neutral-400">
                    One coherent idempotent script: tables, indexes, triggers, storage & RLS
                  </p>
                </div>
                <button
                  id="btn-copy-migration-sql"
                  onClick={handleCopySql}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl flex items-center space-x-2 transition-all shadow-sm ${
                    copiedSql
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700'
                  }`}
                >
                  {copiedSql ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Full SQL (1-Click)</span>
                    </>
                  )}
                </button>
              </div>

              <div className="relative">
                <pre className="p-4 bg-neutral-950 border border-neutral-800 rounded-xl text-xs font-mono text-neutral-300 max-h-[380px] overflow-y-auto leading-relaxed select-all">
                  {NEXA_DATABASE_MIGRATION_SQL}
                </pre>
              </div>

              <div className="p-3 bg-neutral-800/40 border border-neutral-700/50 rounded-xl text-xs text-neutral-400 flex items-center justify-between">
                <span>Go to Supabase Dashboard → SQL Editor → New Query → Paste & Run</span>
                <a
                  href="https://supabase.com/dashboard"
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-400 hover:underline flex items-center space-x-1"
                >
                  <span>Open Supabase</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
