import React from 'react';

export const CardSkeleton: React.FC = () => {
  return (
    <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 animate-pulse space-y-4">
      <div className="flex justify-between items-start">
        <div className="h-5 bg-slate-800 rounded w-1/2"></div>
        <div className="h-6 w-16 bg-slate-800 rounded-full"></div>
      </div>
      <div className="h-10 bg-slate-800/80 rounded-xl w-3/4"></div>
      <div className="h-4 bg-slate-800/50 rounded w-full"></div>
      <div className="h-4 bg-slate-800/50 rounded w-2/3"></div>
      <div className="flex justify-between pt-2">
        <div className="h-8 bg-slate-800 rounded-lg w-24"></div>
        <div className="h-8 bg-slate-800 rounded-lg w-28"></div>
      </div>
    </div>
  );
};

export const TableSkeleton: React.FC<{ rows?: number }> = ({ rows = 5 }) => {
  return (
    <div className="space-y-3 animate-pulse">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-12 bg-slate-900/80 border border-slate-800/60 rounded-xl w-full" />
      ))}
    </div>
  );
};
