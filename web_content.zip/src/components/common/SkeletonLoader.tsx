import React from 'react';

export const DashboardSkeleton: React.FC = () => {
  return (
    <div className="max-w-xl mx-auto space-y-4 pb-24 animate-pulse">
      <div className="h-10 bg-slate-800 rounded-xl w-full" />
      <div className="h-44 bg-slate-900 rounded-3xl w-full border border-slate-800" />
      <div className="h-28 bg-slate-900 rounded-3xl w-full border border-slate-800" />
      <div className="grid grid-cols-2 gap-3">
        <div className="h-32 bg-slate-900 rounded-3xl border border-slate-800" />
        <div className="h-32 bg-slate-900 rounded-3xl border border-slate-800" />
      </div>
    </div>
  );
};

export const TasksSkeleton: React.FC = () => {
  return (
    <div className="max-w-xl mx-auto space-y-4 pb-24 animate-pulse">
      <div className="h-10 bg-slate-800 rounded-xl w-full" />
      <div className="space-y-3">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="h-24 bg-slate-900 rounded-3xl w-full border border-slate-800" />
        ))}
      </div>
    </div>
  );
};
