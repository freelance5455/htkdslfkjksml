import React, { useState } from 'react';
import { Copy, Check, Smartphone, ExternalLink, ShieldCheck } from 'lucide-react';

interface PaytmQrCardProps {
  upiId?: string;
  amount?: number;
  payeeName?: string;
  transactionNote?: string;
  showDirectPayButton?: boolean;
  className?: string;
}

export const PaytmQrCard: React.FC<PaytmQrCardProps> = ({
  upiId = 'paytm.s19vihm@pty',
  amount,
  payeeName = 'Subhodip Garai',
  transactionNote = 'Task Earn Pro Bullion & VIP',
  showDirectPayButton = true,
  className = '',
}) => {
  const [copied, setCopied] = useState(false);

  const amountParam = amount && amount > 0 ? `&am=${encodeURIComponent(amount.toString())}` : '';
  const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}${amountParam}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=8&data=${encodeURIComponent(upiUrl)}`;

  const handleCopy = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handlePayDirect = () => {
    window.location.href = upiUrl;
  };

  return (
    <div className={`w-full max-w-xs mx-auto overflow-hidden rounded-3xl shadow-2xl border border-slate-700/80 bg-slate-900 ${className}`}>
      {/* Top Banner (Yellow Cashback Theme) */}
      <div className="relative bg-gradient-to-b from-[#ffd200] via-[#ffc700] to-[#ffb300] px-4 pt-3 pb-3 text-center overflow-hidden">
        {/* Subtle decorative rays & confetti */}
        <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#002970_1px,transparent_1px)] [background-size:8px_8px]" />

        <div className="relative z-10 space-y-1">
          <span className="text-[11px] font-black uppercase tracking-wider text-slate-900 block drop-shadow-sm">
            Get Assured
          </span>

          <div className="inline-block px-3.5 py-0.5 rounded-lg bg-gradient-to-b from-[#00baf2] to-[#002970] border border-white text-white font-black text-sm tracking-widest shadow-md">
            CASHBACK
          </div>

          <div>
            <span className="inline-block bg-white text-slate-900 px-3.5 py-0.5 rounded-full text-[10px] font-black shadow-sm mt-0.5">
              Scan in Paytm App
            </span>
          </div>
        </div>
      </div>

      {/* Main White QR Container */}
      <div className="bg-white px-4 py-3 text-center space-y-2">
        {/* Paytm Logo */}
        <div className="flex items-center justify-center gap-0.5 pt-0.5">
          <span className="text-[#002970] font-black text-2xl tracking-tighter leading-none">pay</span>
          <span className="text-[#00b9f1] font-black text-2xl tracking-tighter leading-none">tm</span>
        </div>

        {/* QR Code Image */}
        <div className="relative mx-auto w-48 h-48 bg-white p-1 rounded-xl shadow-inner border border-slate-200 flex items-center justify-center">
          <img
            src={qrCodeUrl}
            alt={`Paytm QR for ${upiId}`}
            className="w-full h-full object-contain"
            loading="eager"
          />
        </div>

        {/* UPI ID Text & Copy Button */}
        <div className="pt-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-100 border border-slate-200 shadow-sm max-w-full">
            <span className="text-slate-600 text-[11px] font-bold">UPI ID:</span>
            <span className="text-slate-950 font-black font-mono text-xs select-all break-all">
              {upiId}
            </span>
            <button
              type="button"
              onClick={handleCopy}
              className="p-1 rounded-lg hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer shrink-0"
              title="Copy UPI ID"
            >
              {copied ? (
                <Check className="w-3.5 h-3.5 text-emerald-600 font-bold" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-slate-600" />
              )}
            </button>
          </div>

          {copied && (
            <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">
              ✓ UPI ID Copied to Clipboard
            </span>
          )}
        </div>

        {/* Amount Badge if specified */}
        {amount && amount > 0 ? (
          <div className="text-[11px] font-bold text-slate-700">
            Payable Amount: <span className="font-black text-[#002970]">₹{amount.toLocaleString()}</span>
          </div>
        ) : null}

        {/* Paytm Postpaid & UPI & UPI LITE Footer Logos */}
        <div className="pt-2 border-t border-slate-200/80 flex items-center justify-center gap-2.5 text-[9px] font-bold text-slate-700 flex-wrap">
          <div className="flex items-center gap-1">
            <span className="w-3.5 h-3.5 rounded bg-[#002970] text-[#00b9f1] text-[8px] font-black flex items-center justify-center">
              ₹
            </span>
            <span className="font-extrabold text-[#002970]">paytm</span>
            <span className="text-[8px] font-bold text-slate-500">Postpaid</span>
          </div>

          <span className="text-slate-300">|</span>

          <div className="flex items-center gap-1">
            <span className="font-black tracking-tight text-slate-800 italic">UPI</span>
            <span className="text-[7px] text-slate-400 font-bold uppercase">Unified Interface</span>
          </div>

          <span className="text-slate-300">|</span>

          <div className="flex items-center gap-0.5">
            <span className="font-black tracking-tight text-slate-800 italic">UPI</span>
            <span className="text-[8px] font-black text-emerald-600">LITE</span>
          </div>
        </div>
      </div>

      {/* Direct App Payment Trigger */}
      {showDirectPayButton && (
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
          <button
            type="button"
            onClick={handlePayDirect}
            className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#00b9f1] to-[#002970] hover:from-[#00a8dc] hover:to-[#002058] text-white font-black text-xs shadow-md shadow-[#00b9f1]/20 flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Pay via Paytm / Any UPI App</span>
          </button>
        </div>
      )}
    </div>
  );
};
