import React, { useState, useEffect } from 'react';
import { Sparkles, ShieldCheck, Coins, TrendingUp, Clock, CheckCircle2 } from 'lucide-react';

interface SplashScreenControllerProps {
  children: React.ReactNode;
}

const TIPS = [
  "Enjoy these tips while dakche open hochena fast",
  "Tip: Activate ₹100 or ₹300 Premium Membership for ₹500/₹800 daily earnings and 100k+ surveys!",
  "Tip: Watch YouTube videos for 30s to earn 4,000 Coins instantly!",
  "Tip: Upload screenshot proof for task verification to receive coins securely.",
  "Tip: Buy 24K Digital Gold and 999 Pure Silver with instant UPI payment verification.",
  "Tip: SIP calculations help you plan systematic investments with compounding returns!"
];

export const SplashScreenController: React.FC<SplashScreenControllerProps> = ({ children }) => {
  return <>{children}</>;
};
