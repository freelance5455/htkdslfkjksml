import React, { useState } from 'react';
import {
  FileText,
  Film,
  Image as ImageIcon,
  FileArchive,
  FileSpreadsheet,
  Download,
  ExternalLink,
  RefreshCw,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Play,
} from 'lucide-react';
import type { Message } from '../../types/index.ts';
import {
  formatFileSize,
  formatUploadSpeed,
  getFileTypeLabel,
  triggerAuthenticatedDownload,
  type ResumableUploadProgress,
} from '../../utils/mediaHelper.ts';

interface ChatFileAttachmentCardProps {
  message: Message;
  isOwnMessage: boolean;
  currentUserId: string;
  currentCompanyId: string;
  currentEmployeeId?: string;
  uploadProgress?: ResumableUploadProgress;
  onRetryUpload?: (messageId: string) => void;
  onCancelUpload?: (messageId: string) => void;
  onPreviewMedia?: (url: string, type: 'image' | 'video' | 'pdf', title?: string) => void;
}

export const ChatFileAttachmentCard: React.FC<ChatFileAttachmentCardProps> = ({
  message,
  isOwnMessage,
  currentUserId,
  currentCompanyId,
  currentEmployeeId,
  uploadProgress,
  onRetryUpload,
  onCancelUpload,
  onPreviewMedia,
}) => {
  const [actionLoading, setActionLoading] = useState<'open' | 'download' | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [inlineStreamUrl, setInlineStreamUrl] = useState<string | null>(null);

  const fileName = message.fileName || 'Attachment';
  const fileSize = message.fileSizeBytes || uploadProgress?.fileSizeBytes || 0;
  const typeLabel = getFileTypeLabel(fileName, message.mimeType);
  const status = uploadProgress?.status || message.uploadStatus || 'completed';
  const thumbnailUrl = message.thumbnailUrl || (message.messageType === 'image' && message.mediaUrl?.startsWith('data:image/') ? message.mediaUrl : undefined);

  const isUploading = status === 'uploading';
  const isFailed = status === 'failed';
  const isCompleted = status === 'completed';

  const renderFileIcon = () => {
    if (message.messageType === 'image') {
      return <ImageIcon className={`w-5 h-5 shrink-0 ${isOwnMessage ? 'text-sky-200' : 'text-sky-600'}`} />;
    }
    if (message.messageType === 'video') {
      return <Film className={`w-5 h-5 shrink-0 ${isOwnMessage ? 'text-purple-200' : 'text-purple-600'}`} />;
    }
    if (typeLabel === 'XLSX' || typeLabel === 'XLS' || typeLabel === 'CSV') {
      return <FileSpreadsheet className={`w-5 h-5 shrink-0 ${isOwnMessage ? 'text-emerald-200' : 'text-emerald-600'}`} />;
    }
    if (typeLabel === 'ZIP') {
      return <FileArchive className={`w-5 h-5 shrink-0 ${isOwnMessage ? 'text-amber-200' : 'text-amber-600'}`} />;
    }
    return <FileText className={`w-5 h-5 shrink-0 ${isOwnMessage ? 'text-amber-200' : 'text-sky-600'}`} />;
  };

  const handleOpenOrPreview = async () => {
    if (!isCompleted) return;
    setActionError(null);
    setActionLoading('open');
    try {
      const url = await triggerAuthenticatedDownload({
        fileId: message.fileId,
        storagePath: message.storagePath,
        mediaUrl: message.mediaUrl,
        fileName,
        userId: currentUserId,
        companyId: currentCompanyId,
        employeeId: currentEmployeeId,
        mode: 'open',
      });

      if (message.messageType === 'image' && onPreviewMedia) {
        onPreviewMedia(url, 'image', fileName);
      } else if (message.messageType === 'video') {
        if (onPreviewMedia) {
          onPreviewMedia(url, 'video', fileName);
        } else {
          setInlineStreamUrl(url);
        }
      } else if (typeLabel === 'PDF' && onPreviewMedia) {
        onPreviewMedia(url, 'pdf', fileName);
      } else {
        // Trigger download for Office/ZIP files that browsers cannot render inline inside an iframe safely
        await triggerAuthenticatedDownload({
          fileId: message.fileId,
          storagePath: message.storagePath,
          mediaUrl: message.mediaUrl,
          fileName,
          userId: currentUserId,
          companyId: currentCompanyId,
          employeeId: currentEmployeeId,
          mode: 'download',
        });
      }
    } catch (err: any) {
      setActionError(err?.message || 'Unable to open file.');
    } finally {
      setActionLoading(null);
    }
  };

  const handleDownload = async () => {
    if (!isCompleted) return;
    setActionError(null);
    setActionLoading('download');
    try {
      await triggerAuthenticatedDownload({
        fileId: message.fileId,
        storagePath: message.storagePath,
        mediaUrl: message.mediaUrl,
        fileName,
        userId: currentUserId,
        companyId: currentCompanyId,
        employeeId: currentEmployeeId,
        mode: 'download',
      });
    } catch (err: any) {
      setActionError(err?.message || 'Download failed.');
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-2 min-w-[230px] sm:min-w-[270px] max-w-full">
      {/* Lightweight Thumbnail Preview for Images or Videos (never downloads huge files automatically) */}
      {thumbnailUrl && (message.messageType === 'image' || message.messageType === 'video') && (
        <div
          onClick={isCompleted ? handleOpenOrPreview : undefined}
          className={`relative rounded-xl overflow-hidden border ${
            isOwnMessage ? 'border-white/20 bg-sky-900/40' : 'border-slate-200 bg-slate-100'
          } ${isCompleted ? 'cursor-pointer group' : ''}`}
        >
          <img
            src={thumbnailUrl}
            alt={fileName}
            className="max-h-44 w-full object-cover transition-transform duration-200 group-hover:scale-[1.02]"
          />
          {message.messageType === 'video' && (
            <div className="absolute inset-0 bg-black/35 flex items-center justify-center">
              <div className="w-10 h-10 rounded-full bg-white/90 text-slate-900 flex items-center justify-center shadow-md">
                <Play className="w-5 h-5 fill-current ml-0.5" />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Inline Video Player when explicitly opened */}
      {inlineStreamUrl && message.messageType === 'video' && (
        <video
          controls
          src={inlineStreamUrl}
          className="rounded-xl max-h-56 w-full bg-black border border-white/20"
        />
      )}

      {/* File Card Container */}
      <div
        className={`p-2.5 rounded-xl border transition-all ${
          isOwnMessage
            ? 'bg-sky-700/80 border-sky-500/40 text-white'
            : 'bg-slate-50 border-slate-200/90 text-slate-800'
        }`}
      >
        <div className="flex items-start gap-2.5">
          <div
            className={`p-2 rounded-lg shrink-0 ${
              isOwnMessage ? 'bg-sky-800/80' : 'bg-white border border-slate-200/80 shadow-2xs'
            }`}
          >
            {renderFileIcon()}
          </div>

          <div className="flex-1 min-w-0">
            <div className="font-bold text-xs truncate" title={fileName}>
              {fileName}
            </div>

            <div className="flex flex-wrap items-center gap-1.5 mt-0.5 text-[10px] opacity-85">
              <span
                className={`px-1.5 py-0.5 rounded font-bold uppercase tracking-wider text-[9px] ${
                  isOwnMessage ? 'bg-sky-900/70 text-sky-100' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {typeLabel}
              </span>
              <span>·</span>
              <span className="font-mono">{formatFileSize(fileSize)}</span>
              <span>·</span>
              {isUploading && (
                <span className="inline-flex items-center gap-1 font-semibold text-amber-300">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  <span>Uploading {uploadProgress ? `${uploadProgress.percentage}%` : ''}</span>
                </span>
              )}
              {isCompleted && (
                <span
                  className={`inline-flex items-center gap-0.5 font-semibold ${
                    isOwnMessage ? 'text-emerald-200' : 'text-emerald-600'
                  }`}
                >
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Uploaded</span>
                </span>
              )}
              {isFailed && (
                <span
                  className={`inline-flex items-center gap-0.5 font-semibold ${
                    isOwnMessage ? 'text-rose-200' : 'text-rose-600'
                  }`}
                >
                  <AlertCircle className="w-3 h-3" />
                  <span>Upload Failed</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Live Resumable Upload Progress Details */}
        {isUploading && uploadProgress && (
          <div className="mt-2.5 space-y-1.5 pt-2 border-t border-current/10">
            <div className="w-full h-1.5 bg-black/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-400 transition-all duration-200 rounded-full"
                style={{ width: `${Math.max(2, uploadProgress.percentage)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono opacity-90">
              <span>
                {formatFileSize(uploadProgress.uploadedBytes)} / {formatFileSize(uploadProgress.fileSizeBytes)}
              </span>
              <span>{formatUploadSpeed(uploadProgress.speedBytesPerSec)}</span>
            </div>
            <div className="flex items-center justify-between text-[10px] opacity-80">
              <span>Remaining: {formatFileSize(uploadProgress.remainingBytes)}</span>
              {onCancelUpload && (
                <button
                  type="button"
                  onClick={() => onCancelUpload(message.id)}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-100 font-semibold transition-colors"
                >
                  <X className="w-3 h-3" />
                  <span>Cancel</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Upload Failure & Retry Controls */}
        {isFailed && (
          <div className="mt-2 pt-2 border-t border-current/10 flex flex-col gap-1.5">
            <div className={`text-[10px] ${isOwnMessage ? 'text-rose-200' : 'text-rose-600'}`}>
              {uploadProgress?.error || 'Upload interrupted. Your progress is saved.'}
            </div>
            <div className="flex items-center gap-2">
              {onRetryUpload && (
                <button
                  type="button"
                  onClick={() => onRetryUpload(message.id)}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors ${
                    isOwnMessage
                      ? 'bg-white text-sky-900 hover:bg-sky-50'
                      : 'bg-sky-600 text-white hover:bg-sky-700'
                  }`}
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Retry / Resume</span>
                </button>
              )}
              {onCancelUpload && (
                <button
                  type="button"
                  onClick={() => onCancelUpload(message.id)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-semibold opacity-80 hover:opacity-100"
                >
                  <X className="w-3 h-3" />
                  <span>Remove</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Completed File Actions: Open & Download */}
        {isCompleted && (
          <div className="mt-2 pt-2 border-t border-current/10 flex items-center gap-2">
            <button
              type="button"
              onClick={handleOpenOrPreview}
              disabled={actionLoading !== null}
              className={`flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                isOwnMessage
                  ? 'bg-white/15 hover:bg-white/25 text-white'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200/80 shadow-2xs'
              }`}
            >
              {actionLoading === 'open' ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <ExternalLink className="w-3.5 h-3.5" />
              )}
              <span>Open</span>
            </button>

            <button
              type="button"
              onClick={handleDownload}
              disabled={actionLoading !== null}
              className={`flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                isOwnMessage
                  ? 'bg-white text-sky-800 hover:bg-sky-50 shadow-2xs'
                  : 'bg-sky-600 hover:bg-sky-700 text-white shadow-2xs'
              }`}
            >
              {actionLoading === 'download' ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Download className="w-3.5 h-3.5" />
              )}
              <span>Download</span>
            </button>
          </div>
        )}

        {/* Action Error Message */}
        {actionError && (
          <div
            className={`mt-1.5 text-[10px] flex items-center gap-1 ${
              isOwnMessage ? 'text-rose-200' : 'text-rose-600'
            }`}
          >
            <AlertCircle className="w-3 h-3 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}
      </div>

      {/* Optional Caption */}
      {message.content &&
        !message.content.startsWith('Attached ') &&
        message.content !== fileName && (
          <div className="text-xs px-0.5">{message.content}</div>
        )}
    </div>
  );
};
