import React from 'react';
import { 
  Home, 
  Coins, 
  CheckSquare, 
  Gamepad2, 
  Crown, 
  Wallet, 
  Gift, 
  User as UserIcon,
  ShieldCheck,
  TrendingUp,
  Sparkles,
  Headphones
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VipBadge } from './VipBadge';
import { GovtLicenseBadge } from './GovtLicenseBadge';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenAdmin: () => void;
  onOpenAuth: () => void;
  onOpenSupport: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, setCurrentTab, onOpenAdmin, onOpenAuth, onOpenSupport }) => {
  const { currentUser, isAdminAuthenticated, language, systemSettings } = useApp();
  const currentCoins = currentUser?.coins ?? 0;
  const rate = systemSettings?.coinsPerCurrencyUnit ?? 100;
  const inrValue = (currentCoins / (rate || 100)).toFixed(2);

  const navLinks = [
    { id: 'dashboard', label: language === 'bn' ? 'হোম (Home)' : 'Dashboard', icon: Home },
    { id: 'investments', label: language === 'bn' ? 'গোল্ড ও সিলভার (Gold & Silver)' : 'Digital Gold & Silver', icon: Coins, highlight: true },
    { id: 'tasks', label: language === 'bn' ? 'টাস্ক ও আর্নিং (Tasks)' : 'Task Center', icon: CheckSquare },
    { id: 'games', label: language === 'bn' ? 'গেম জোন (Games)' : 'Game Zone', icon: Gamepad2 },
    { id: 'membership', label: language === 'bn' ? 'ভিআইপি প্ল্যান (VIP)' : 'VIP Membership', icon: Crown },
    { id: 'wallet', label: language === 'bn' ? 'ওয়ালেট ও উইথড্র (Wallet)' : 'Wallet & Cashout', icon: Wallet },
    { id: 'offers', label: language === 'bn' ? 'অফার ও সার্ভে (Offers)' : 'Surveys & Offers', icon: Gift },
    { id: 'profile', label: language === 'bn' ? 'প্রোফাইল (Profile)' : 'User Profile', icon: UserIcon },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 bg-slate-950/95 backdrop-blur-2xl border-r border-slate-800/80 p-5 shrink-0 min-h-screen sticky top-0 z-45">
      {/* Brand Header */}
      <div className="flex flex-col gap-3 pb-5 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 via-teal-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
            <Sparkles className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-black text-base tracking-tight text-white">Task Earn Pro</h1>
              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[8px] font-black uppercase">
                VIP
              </span>
            </div>
            <p className="text-[10px] text-slate-400">Fintech & Gold Investment</p>
          </div>
        </div>
        <GovtLicenseBadge compact={true} />
      </div>

      {/* Wallet Summary Widget */}
      {currentUser && (
        <div className="my-5 p-3.5 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-indigo-950/40 border border-amber-500/30 shadow-inner space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Balance</span>
            <span className="text-emerald-400 font-bold">≈ ₹{inrValue} INR</span>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-black text-white">{currentCoins.toLocaleString()}</span>
            <span className="text-xs font-bold text-amber-400">Coins</span>
          </div>
          <button
            type="button"
            onClick={() => setCurrentTab('wallet')}
            className="w-full py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] transition-all cursor-pointer shadow-sm"
          >
            Withdraw to UPI ↗
          </button>
        </div>
      )}

      {/* Navigation Links */}
      <nav className="flex-1 space-y-1.5 py-2 overflow-y-auto">
        {navLinks.map((link) => {
          const Icon = link.icon;
          const isActive = currentTab === link.id;
          return (
            <button
              key={link.id}
              onClick={() => setCurrentTab(link.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                link.highlight
                  ? isActive
                    ? 'bg-amber-950/90 text-amber-300 border border-amber-500/80 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20'
                  : isActive
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${
                link.highlight 
                  ? 'text-amber-400' 
                  : isActive ? 'text-emerald-400' : 'text-slate-400'
              }`} />
              <span className="truncate">{link.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer & Admin / Auth */}
      <div className="pt-4 border-t border-slate-800/80 space-y-2">
        <button
          type="button"
          onClick={onOpenSupport}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl bg-teal-950/70 hover:bg-teal-900 border border-teal-700/60 text-teal-300 hover:text-white text-xs font-black transition-all cursor-pointer shadow-xs"
        >
          <Headphones className="w-4 h-4 text-teal-400" />
          <span>Support Team (24/7)</span>
        </button>

        {isAdminAuthenticated && (
          <button
            type="button"
            onClick={onOpenAdmin}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl bg-purple-950/70 hover:bg-purple-900 border border-purple-700/60 text-purple-300 hover:text-white text-xs font-black transition-all cursor-pointer shadow-xs"
          >
            <ShieldCheck className="w-4 h-4 text-purple-400" />
            <span>Admin Dashboard</span>
          </button>
        )}

        {currentUser ? (
          <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
            <img src={currentUser.avatar} alt="Avatar" className="w-8 h-8 rounded-xl object-cover shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1 mb-0.5">
                <p className="text-xs font-bold text-white truncate">{currentUser.name}</p>
                <VipBadge tier={currentUser.membershipTier} size="sm" />
              </div>
              <p className="text-[10px] text-slate-400 truncate">{currentUser.email}</p>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={onOpenAuth}
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white font-bold text-xs shadow-sm cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            <span>Google / Login</span>
          </button>
        )}
      </div>
    </aside>
  );
};
