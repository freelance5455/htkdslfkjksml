import React from 'react';
import { 
  Home, 
  Coins,
  CheckSquare, 
  Gamepad2, 
  Crown, 
  Wallet, 
  Gift, 
  User as UserIcon 
} from 'lucide-react';

interface MobileBottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ currentTab, setCurrentTab }) => {
  const navItems = [
    { id: 'dashboard', label: 'Home', icon: Home, isGold: false },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare, isGold: false },
    { id: 'investments', label: 'Gold Buy', icon: Coins, isGold: true },
    { id: 'wallet', label: 'Wallet', icon: Wallet, isGold: false },
    { id: 'offers', label: 'Offers', icon: Gift, isGold: false },
    { id: 'profile', label: 'Profile', icon: UserIcon, isGold: false },
  ];

  return (
    <div className="fixed bottom-3 left-2 right-2 z-40 max-w-xl mx-auto">
      <nav 
        className="bg-slate-950/95 backdrop-blur-2xl border border-slate-800/90 rounded-2xl shadow-2xl shadow-black/90 p-1 flex items-center justify-between gap-1"
        aria-label="Bottom Navigation"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`flex-1 py-1.5 px-1 rounded-xl flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer relative ${
                item.isGold
                  ? isActive
                    ? 'bg-amber-950/90 text-amber-300 border border-amber-500/80 shadow-[0_0_18px_rgba(245,158,11,0.45)]'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20'
                  : isActive
                    ? 'bg-teal-950/90 text-teal-300 border border-teal-500/60 shadow-[0_0_14px_rgba(20,184,166,0.3)]'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 sm:w-4.5 sm:h-4.5 ${
                item.isGold
                  ? isActive ? 'scale-115 text-amber-300' : 'text-amber-400'
                  : isActive ? 'scale-110 text-teal-300' : 'text-slate-400'
              } transition-transform`} />
              <span className={`text-[8px] sm:text-[10px] tracking-tight leading-none truncate w-full text-center ${
                item.isGold
                  ? isActive ? 'font-black text-amber-300' : 'font-bold text-amber-400'
                  : isActive ? 'font-black text-teal-300' : 'font-semibold'
              }`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};
