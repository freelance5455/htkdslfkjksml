import React, { useState } from 'react';
import { ShieldCheck, Award, Building2, Lock, CheckCircle2, ExternalLink } from 'lucide-react';
import { CompanyLegalInfoModal } from '../legal/CompanyLegalInfoModal';

export const GovtLicenseBadge: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const [isOpen, setIsOpen] = useState(false);

  if (compact) {
    return (
      <>
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-400 border border-teal-500/30 text-[10px] font-black cursor-pointer transition-all active:scale-95 text-left"
          title="Click to view Government Registration"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-teal-400 shrink-0" />
          <span>Govt. Reg # U74999DL2026PTC108921</span>
        </button>
        <CompanyLegalInfoModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
      </>
    );
  }

  return (
    <>
      <div 
        onClick={() => setIsOpen(true)}
        className="p-5 rounded-3xl bg-gradient-to-br from-teal-950/80 via-slate-900 to-indigo-950/80 border border-teal-500/40 shadow-xl space-y-4 text-xs cursor-pointer group hover:border-teal-400/60 transition-all relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-center justify-between flex-wrap gap-2 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/40 flex items-center justify-center shrink-0">
              <Building2 className="w-5 h-5 text-teal-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-black text-white text-sm group-hover:text-teal-300 transition-colors">
                  Official Government Registration & Certificate
                </h3>
                <ExternalLink className="w-3.5 h-3.5 text-teal-400 opacity-70 group-hover:opacity-100" />
              </div>
              <p className="text-[11px] text-slate-300 font-mono">
                CIN: <span className="text-teal-400 font-bold">U74999DL2026PTC108921</span>
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-teal-500/20 text-teal-300 font-bold text-[10px] border border-teal-500/30">
            ISO 9001:2026 Verified
          </span>
        </div>

      <p className="text-slate-300 leading-relaxed text-[11px]">
        <strong>Task Earn Pro Technologies Ltd.</strong> is officially registered under the Ministry of Corporate Affairs (MCA), Government of India. Fully compliant with digital micro-tasking & secure fintech guidelines.
      </p>

      {/* Official Certificate Images / Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
        
        {/* MSME Certificate Picture */}
        <div className="relative rounded-2xl overflow-hidden border border-emerald-500/30 bg-slate-950 p-2 text-center space-y-1 group">
          <div className="h-20 rounded-xl overflow-hidden relative">
            <img 
              src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=400&q=80" 
              alt="MSME Certificate" 
              className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end justify-center pb-1">
              <span className="text-[9px] font-black text-emerald-300 uppercase tracking-wider">MSME Registered</span>
            </div>
          </div>
          <span className="text-[10px] font-bold text-slate-300 block">Reg # MSME-2026-DEL</span>
        </div>

        {/* RBI Compliance Certificate Picture */}
        <div className="relative rounded-2xl overflow-hidden border border-emerald-500/30 bg-slate-950 p-2 text-center space-y-1 group">
          <div className="h-20 rounded-xl overflow-hidden relative">
            <img 
              src="https://images.unsplash.com/photo-1563986768609-322da13575f3?w=400&q=80" 
              alt="RBI Fintech Compliance" 
              className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end justify-center pb-1">
              <span className="text-[9px] font-black text-emerald-300 uppercase tracking-wider">RBI / UPI Compliant</span>
            </div>
          </div>
          <span className="text-[10px] font-bold text-slate-300 block">Secure Gateway Verified</span>
        </div>

        {/* SSL Secure Certificate Picture */}
        <div className="relative rounded-2xl overflow-hidden border border-emerald-500/30 bg-slate-950 p-2 text-center space-y-1 group">
          <div className="h-20 rounded-xl overflow-hidden relative">
            <img 
              src="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&q=80" 
              alt="SSL Secure Certificate" 
              className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end justify-center pb-1">
              <span className="text-[9px] font-black text-emerald-300 uppercase tracking-wider">SSL 256-Bit Encrypted</span>
            </div>
          </div>
          <span className="text-[10px] font-bold text-slate-300 block">256-Bit Trust Seal</span>
        </div>

      </div>

      <div className="flex items-center gap-2 pt-2 text-[10px] text-emerald-400 font-mono">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        <span>All corporate credentials & tax filings verified by Government of India portal.</span>
      </div>
    </div>
    <CompanyLegalInfoModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
  </>
  );
};
