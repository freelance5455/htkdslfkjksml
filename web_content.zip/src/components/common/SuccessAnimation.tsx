import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, X, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

export interface SuccessAnimationProps {
  isOpen: boolean;
  title: string;
  subtitle?: string;
  actionText?: string;
  onClose: () => void;
  onAction?: () => void;
  autoCloseMs?: number;
}

export function SuccessAnimation({
  isOpen,
  title,
  subtitle,
  actionText,
  onClose,
  onAction,
  autoCloseMs = 3000,
}: SuccessAnimationProps) {
  useEffect(() => {
    if (isOpen) {
      // Trigger a gentle celebratory confetti burst
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#00F0FF', '#0066FF', '#10B981', '#F59E0B'],
        });
      } catch {
        // graceful fallback if canvas not available
      }

      if (autoCloseMs > 0) {
        const timer = setTimeout(() => {
          onClose();
        }, autoCloseMs);
        return () => clearTimeout(timer);
      }
    }
  }, [isOpen, autoCloseMs, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="success-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md select-none"
        >
          {/* Card Container */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.85, opacity: 0, y: 15 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative w-full max-w-sm glass-panel-elevated rounded-3xl p-6 border border-cyan-400/50 text-white text-center shadow-[0_0_50px_rgba(0,240,255,0.3)] overflow-hidden"
          >
            {/* Top Ambient Glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-32 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 rtl:right-auto rtl:left-4 w-7 h-7 rounded-full bg-slate-900/80 border border-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              aria-label="Close modal"
            >
              <X className="w-3.5 h-3.5" />
            </button>

            {/* Neon Checkmark Animation */}
            <div className="relative w-24 h-24 mx-auto mb-4 flex items-center justify-center">
              {/* Pulsing Neon Glow Ring */}
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: [1, 1.25, 1], opacity: [0.3, 0.7, 0.3] }}
                transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut' }}
                className="absolute inset-0 rounded-full bg-cyan-500/20 blur-xl pointer-events-none"
              />

              {/* Secondary Rotating Outer Ring */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 10, ease: 'linear' }}
                className="absolute inset-1 rounded-full border border-dashed border-cyan-400/40 pointer-events-none"
              />

              {/* SVG Checkmark with path drawing animation */}
              <svg
                className="w-20 h-20 text-cyan-400 filter drop-shadow-[0_0_12px_rgba(0,240,255,0.7)]"
                viewBox="0 0 60 60"
                fill="none"
              >
                {/* Background circle track */}
                <circle
                  cx="30"
                  cy="30"
                  r="26"
                  stroke="rgba(6, 182, 212, 0.2)"
                  strokeWidth="3"
                />

                {/* Animated circle stroke */}
                <motion.circle
                  cx="30"
                  cy="30"
                  r="26"
                  stroke="url(#neonGradient)"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.65, ease: 'easeInOut' }}
                />

                {/* Animated checkmark path */}
                <motion.path
                  d="M18 31 L26 39 L42 22"
                  stroke="#00F0FF"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.45, delay: 0.35, ease: 'easeOut' }}
                />

                <defs>
                  <linearGradient id="neonGradient" x1="0" y1="0" x2="60" y2="60" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#0066FF" />
                    <stop offset="0.5" stopColor="#00F0FF" />
                    <stop offset="1" stopColor="#10B981" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Sparkle badge */}
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.6, type: 'spring' }}
                className="absolute -top-1 -right-1 rtl:right-auto rtl:-left-1 text-amber-300 drop-shadow-[0_0_8px_#f59e0b]"
              >
                <Sparkles className="w-5 h-5 fill-amber-300" />
              </motion.div>
            </div>

            {/* Animated Title & Subtitle */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.3 }}
              className="space-y-1.5"
            >
              <h3 className="text-base md:text-lg font-black text-white tracking-wide">
                {title}
              </h3>

              {subtitle && (
                <p className="text-xs text-slate-300 leading-relaxed font-normal max-w-xs mx-auto">
                  {subtitle}
                </p>
              )}
            </motion.div>

            {/* Brand Assurance Pill */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.55 }}
              className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-[10px] text-cyan-400 font-mono"
            >
              <Check className="w-3 h-3 text-emerald-400" />
              <span>TAKI-GO · Tourism By Taki Verified</span>
            </motion.div>

            {/* Optional Action Button */}
            {actionText && (
              <motion.button
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                onClick={() => {
                  if (onAction) onAction();
                  onClose();
                }}
                className="w-full h-10 mt-4 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 text-white font-bold text-xs shadow-[0_0_20px_rgba(0,102,255,0.4)] hover:brightness-110 active:scale-[0.98] transition-all"
              >
                {actionText}
              </motion.button>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
