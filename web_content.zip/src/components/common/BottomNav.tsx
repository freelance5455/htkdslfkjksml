import React from 'react';
import { useApp } from '../../context/AppContext';
import { TabType } from '../../types';
import { LayoutDashboard, Calculator, ShieldCheck, Wrench, UserCheck } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab, triggerHaptic, settings } = useApp();

  const isUr = settings.language === 'ur';

  const navItems: { tab: TabType; label: string; icon: React.FC<{ className?: string }> }[] = [
    {
      tab: 'home',
      label: isUr ? 'ہوم' : 'Home',
      icon: LayoutDashboard,
    },
    {
      tab: 'calculator',
      label: isUr ? 'کیلکولیٹر' : 'Calculator',
      icon: Calculator,
    },
    {
      tab: 'phonecare',
      label: isUr ? 'فون کیئر' : 'Phone Care',
      icon: ShieldCheck,
    },
    {
      tab: 'tools',
      label: isUr ? 'ٹولز' : 'Tools',
      icon: Wrench,
    },
    {
      tab: 'about',
      label: isUr ? 'تعارف' : 'About',
      icon: UserCheck,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#FBFDF9] dark:bg-[#0F1512] border-t border-emerald-900/10 dark:border-emerald-800/30 shadow-[0_-4px_16px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_16px_rgba(0,0,0,0.4)]">
      <div className="max-w-md mx-auto flex items-center justify-around px-2 py-1.5 safe-area-bottom">
        {navItems.map(({ tab, label, icon: Icon }) => {
          const isActive = currentTab === tab;
          return (
            <button
              key={tab}
              onClick={() => {
                triggerHaptic();
                setCurrentTab(tab);
              }}
              className="group relative flex flex-col items-center justify-center py-1 px-3 min-w-[64px] transition-all"
            >
              {/* Active Indicator Pill */}
              <div
                className={`flex items-center justify-center w-14 h-8 rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-[#89F8C7] dark:bg-[#004D36] text-[#002114] dark:text-[#89F8C7] shadow-sm'
                    : 'text-neutral-600 dark:text-neutral-400 group-hover:text-neutral-900 dark:group-hover:text-neutral-200'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 font-bold' : ''}`} />
              </div>
              <span
                className={`text-[11px] mt-1 transition-colors ${
                  isActive
                    ? 'font-bold text-[#006C4C] dark:text-[#89F8C7]'
                    : 'text-neutral-500 dark:text-neutral-400 font-medium'
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
