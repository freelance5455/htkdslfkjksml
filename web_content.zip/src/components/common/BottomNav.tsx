import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Home,
  Clock,
  MessageSquare,
  Wallet,
  User,
  Briefcase,
  PlusCircle,
  Truck,
  Shield,
  Layers,
  Settings,
  DollarSign
} from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const { role, orders, chatSessions, user } = useApp();

  // Active order count for badge
  const activeOrdersCount = orders.filter(
    o => o.status !== 'completed' && o.status !== 'cancelled' && o.status !== 'refunded'
  ).length;

  // Total unread / active chats
  const activeChatsCount = chatSessions.length;

  if (role === 'customer') {
    const tabs = [
      { id: 'home', label: 'Explore', icon: Home },
      { id: 'orders', label: 'Bookings', icon: Clock, badge: activeOrdersCount > 0 ? activeOrdersCount : undefined },
      { id: 'chat', label: 'Chat', icon: MessageSquare, badge: activeChatsCount > 0 ? activeChatsCount : undefined },
      { id: 'wallet', label: 'Wallet', icon: Wallet },
      { id: 'profile', label: 'Profile', icon: User }
    ];

    return (
      <nav className="bg-white/95 backdrop-blur-md border-t border-slate-200/80 px-2 py-1.5 flex items-center justify-around sticky bottom-0 z-30 shrink-0">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`bottom-nav-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-1 flex flex-col items-center justify-center relative transition-all ${
                isActive ? 'text-amber-600 font-bold' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {tab.badge && (
                  <span className="absolute -top-1 -right-2 bg-rose-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight font-medium leading-none">{tab.label}</span>
              {isActive && <div className="w-1 h-1 bg-amber-500 rounded-full mt-0.5" />}
            </button>
          );
        })}
      </nav>
    );
  }

  if (role === 'provider') {
    const providerTabs = [
      { id: 'prov_dashboard', label: 'Jobs & Radar', icon: Briefcase },
      { id: 'prov_catalog', label: 'My Services', icon: PlusCircle },
      { id: 'chat', label: 'Customer Chat', icon: MessageSquare },
      { id: 'prov_earnings', label: 'Earnings & Payout', icon: DollarSign }
    ];

    return (
      <nav className="bg-slate-900 text-white px-2 py-1.5 flex items-center justify-around sticky bottom-0 z-30 shrink-0 border-t border-slate-800">
        {providerTabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`provider-nav-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-1 flex flex-col items-center justify-center relative ${
                isActive ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'scale-110 text-amber-400' : ''}`} />
              <span className="text-[10px] mt-1 font-medium">{tab.label}</span>
              {isActive && <div className="w-1 h-1 bg-amber-400 rounded-full mt-0.5" />}
            </button>
          );
        })}
      </nav>
    );
  }

  if (role === 'delivery') {
    const deliveryTabs = [
      { id: 'deliv_tasks', label: 'Trip Radar', icon: Truck },
      { id: 'chat', label: 'Order Chat', icon: MessageSquare },
      { id: 'deliv_earnings', label: 'My Trips', icon: Wallet }
    ];

    return (
      <nav className="bg-slate-900 text-white px-2 py-1.5 flex items-center justify-around sticky bottom-0 z-30 shrink-0 border-t border-slate-800">
        {deliveryTabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`delivery-nav-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-1 flex flex-col items-center justify-center relative ${
                isActive ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'scale-110 text-amber-400' : ''}`} />
              <span className="text-[10px] mt-1 font-medium">{tab.label}</span>
              {isActive && <div className="w-1 h-1 bg-amber-400 rounded-full mt-0.5" />}
            </button>
          );
        })}
      </nav>
    );
  }

  // Admin bottom bar
  const adminTabs = [
    { id: 'admin_overview', label: 'Overview', icon: Layers },
    { id: 'admin_commissions', label: 'Commissions', icon: Settings },
    { id: 'admin_payouts', label: 'Withdrawals', icon: DollarSign },
    { id: 'admin_safety', label: 'Safety & SOS', icon: Shield }
  ];

  return (
    <nav className="bg-slate-950 text-white px-2 py-1.5 flex items-center justify-around sticky bottom-0 z-30 shrink-0 border-t border-slate-800">
      {adminTabs.map(tab => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            id={`admin-nav-${tab.id}`}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-1 flex flex-col items-center justify-center relative ${
              isActive ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Icon className={`w-5 h-5 ${isActive ? 'scale-110 text-amber-400' : ''}`} />
            <span className="text-[10px] mt-1 font-medium">{tab.label}</span>
            {isActive && <div className="w-1 h-1 bg-amber-400 rounded-full mt-0.5" />}
          </button>
        );
      })}
    </nav>
  );
};
