import React from 'react';
import { useKhata } from '../../context/KhataContext';
import { Home, ReceiptText, PieChart, HandCoins, BarChart3 } from 'lucide-react';

interface BottomNavProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange }) => {
  const { t } = useKhata();

  const tabs = [
    { id: 'home', label: t.navHome, icon: Home },
    { id: 'khata', label: t.navKhata, icon: ReceiptText },
    { id: 'budget', label: t.navBudget, icon: PieChart },
    { id: 'loans_bills', label: t.navLoansBills, icon: HandCoins },
    { id: 'more', label: t.navMore, icon: BarChart3 },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe">
      <div className="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-1">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="min-h-[48px] flex flex-col items-center justify-center relative py-1 focus:outline-hidden transition-colors"
            >
              <div
                className={`p-1 rounded-xl transition-all ${
                  isActive ? 'text-emerald-700 bg-emerald-50' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>
              <span
                className={`text-[10px] tracking-tight font-medium mt-0.5 truncate max-w-[64px] ${
                  isActive ? 'text-emerald-800 font-bold' : 'text-slate-500'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
