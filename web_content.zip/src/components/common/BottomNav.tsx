import React from 'react';
import { Home, Trophy, Flame, BarChart2, Award, Settings } from 'lucide-react';
import { sound } from '../../services/sound';

export type NavTab = 'home' | 'tournaments' | 'daily' | 'leaderboard' | 'progression' | 'settings';

interface BottomNavProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange }) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'tournaments', label: 'Tourneys', icon: Trophy },
    { id: 'daily', label: 'Daily', icon: Flame },
    { id: 'leaderboard', label: 'Ranks', icon: BarChart2 },
    { id: 'progression', label: 'Mastery', icon: Award },
    { id: 'settings', label: 'Settings', icon: Settings },
  ] as const;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070B14]/95 border-t border-[#1C263B] backdrop-blur-md px-3 py-1.5 shadow-2xl">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                sound.playClick();
                onTabChange(tab.id);
              }}
              className={`flex flex-col items-center py-1 px-2 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-amber-400 scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-amber-400 rounded-full" />
                )}
              </div>
              <span
                className={`text-[10px] mt-0.5 font-medium tracking-wide ${
                  isActive ? 'text-amber-300 font-bold' : ''
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
