import React from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  CheckSquare,
  History,
  ShoppingCart,
  Users,
  Repeat,
  AlertTriangle,
  LayoutDashboard,
  ClockAlert,
  Layers,
} from 'lucide-react';

export type EmployeeTab = 'tareas' | 'pendientes_previos' | 'faltantes' | 'cambio_turno';
export type AdminTab = 'dashboard' | 'tareas_admin' | 'compras' | 'empleados' | 'historial';

interface BottomNavProps {
  currentTab: string;
  onSelectTab: (tab: any) => void;
  pendingPriorCount?: number;
  pendingPurchasesCount?: number;
  unresolvedTasksCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  pendingPriorCount = 0,
  pendingPurchasesCount = 0,
  unresolvedTasksCount = 0,
}) => {
  const { isAdmin } = useAuth();

  if (isAdmin) {
    const adminTabs: { id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
      { id: 'dashboard', label: 'Panel', icon: LayoutDashboard },
      { id: 'tareas_admin', label: 'Tareas', icon: CheckSquare, badge: unresolvedTasksCount > 0 ? unresolvedTasksCount : undefined },
      { id: 'compras', label: 'Compras', icon: ShoppingCart, badge: pendingPurchasesCount > 0 ? pendingPurchasesCount : undefined },
      { id: 'empleados', label: 'Personal', icon: Users },
      { id: 'historial', label: 'Historial', icon: History },
    ];

    return (
      <nav
        id="admin-bottom-nav"
        className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200 shadow-lg pb-[env(safe-area-inset-bottom)]"
      >
        <div className="max-w-md md:max-w-xl mx-auto flex items-center justify-around px-2 py-1.5">
          {adminTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => onSelectTab(tab.id)}
                className={`relative flex flex-col items-center justify-center flex-1 py-1 px-2 rounded-xl transition-all duration-150 active:scale-90 ${
                  isActive
                    ? 'text-orange-600 font-bold'
                    : 'text-neutral-500 hover:text-neutral-800 font-medium'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="absolute -top-1 -right-2 min-w-4 h-4 px-1 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center leading-none">
                      {tab.badge > 9 ? '9+' : tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-[11px] mt-0.5 tracking-tight">{tab.label}</span>
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-orange-600 mt-0.5"></span>
                )}
              </button>
            );
          })}
        </div>
      </nav>
    );
  }

  // Employee tabs
  const employeeTabs: { id: EmployeeTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
    { id: 'tareas', label: 'Mis Tareas', icon: CheckSquare },
    {
      id: 'pendientes_previos',
      label: 'Pend. Turno Ant.',
      icon: ClockAlert,
      badge: pendingPriorCount > 0 ? pendingPriorCount : undefined,
    },
    { id: 'faltantes', label: 'Faltantes', icon: AlertTriangle },
    { id: 'cambio_turno', label: 'Cambio Turno', icon: Repeat },
  ];

  return (
    <nav
      id="employee-bottom-nav"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200 shadow-lg pb-[env(safe-area-inset-bottom)]"
    >
      <div className="max-w-md md:max-w-lg mx-auto flex items-center justify-around px-2 py-1.5">
        {employeeTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`tab-${tab.id}`}
              onClick={() => onSelectTab(tab.id)}
              className={`relative flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all duration-150 active:scale-90 ${
                isActive
                  ? 'text-orange-600 font-bold'
                  : 'text-neutral-500 hover:text-neutral-800 font-medium'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1 -right-2 min-w-4 h-4 px-1 rounded-full bg-amber-500 text-neutral-900 text-[10px] font-bold flex items-center justify-center leading-none">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] mt-0.5 tracking-tight truncate max-w-[80px]">
                {tab.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-orange-600 mt-0.5"></span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
