import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  Download,
  Smartphone,
  Tv,
  Film,
  Image as ImageIcon,
  Sparkles,
  ExternalLink,
  Check,
  Copy,
} from "lucide-react";
import { cn } from "@/lib/utils";

export interface UniversalMediaModalProps {
  isOpen: boolean;
  onClose: () => void;
  mediaUrl: string;
  mediaType?: "VIDEO" | "IMAGE" | "AUDIO" | "AUTO";
  title?: string;
  description?: string;
  thumbnailUrl?: string;
  aspectRatio?: "16:9" | "9:16" | "1:1";
  tags?: string[];
  prompt?: string;
  sourceLabel?: string;
  durationSeconds?: number;
}

export const UniversalMediaModal: React.FC<UniversalMediaModalProps> = ({
  isOpen,
  onClose,
  mediaUrl,
  mediaType = "AUTO",
  title = "Mídia de Vídeo & Imagem IA",
  description,
  thumbnailUrl,
  aspectRatio: initialAspect = "16:9",
  tags = [],
  prompt,
  sourceLabel = "AI Creator Studio",
  durationSeconds,
}) => {
  // Determine if it is video or image
  const isVideo =
    mediaType === "VIDEO" ||
    (mediaType === "AUTO" &&
      (mediaUrl.endsWith(".mp4") ||
        mediaUrl.endsWith(".webm") ||
        mediaUrl.includes("video") ||
        mediaUrl.includes("gtv-videos-bucket")));

  const isAudio =
    mediaType === "AUDIO" ||
    (mediaType === "AUTO" && (mediaUrl.endsWith(".mp3") || mediaUrl.endsWith(".wav")));

  const [aspect, setAspect] = useState<"16:9" | "9:16" | "1:1">(initialAspect);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.9);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(durationSeconds || 0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isLooping, setIsLooping] = useState(false);
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (initialAspect) {
      setAspect(initialAspect);
    }
  }, [initialAspect]);

  const togglePlay = useCallback(() => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {});
    }
  }, [isPlaying]);

  const toggleMute = useCallback(() => {
    if (!videoRef.current) return;
    const nextMuted = !isMuted;
    videoRef.current.muted = nextMuted;
    setIsMuted(nextMuted);
  }, [isMuted]);

  const toggleFullscreen = useCallback(() => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current
        .requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch(() => {});
    } else {
      document
        .exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(() => {});
    }
  }, []);

  // Handle keyboard events (ESC, Space, M, F)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      } else if (e.code === "Space" && isVideo) {
        e.preventDefault();
        togglePlay();
      } else if (e.key === "m" || e.key === "M") {
        toggleMute();
      } else if (e.key === "f" || e.key === "F") {
        toggleFullscreen();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, isVideo, onClose, togglePlay, toggleMute, toggleFullscreen]);

  // Reset states on open
  useEffect(() => {
    if (isOpen && videoRef.current) {
      videoRef.current.currentTime = 0;
      setCurrentTime(0);
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsPlaying(true))
          .catch(() => {
            // Autoplay with audio was blocked, try muted
            if (videoRef.current) {
              videoRef.current.muted = true;
              setIsMuted(true);
              videoRef.current
                .play()
                .then(() => setIsPlaying(true))
                .catch(() => setIsPlaying(false));
            }
          });
      }
    } else {
      setIsPlaying(false);
    }
  }, [isOpen, mediaUrl]);

  if (!isOpen) return null;

  const handleVolumeChange = (newVol: number) => {
    if (!videoRef.current) return;
    videoRef.current.volume = newVol;
    setVolume(newVol);
    if (newVol > 0 && isMuted) {
      videoRef.current.muted = false;
      setIsMuted(false);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
      setCurrentTime(val);
    }
  };

  const cycleSpeed = () => {
    if (!videoRef.current) return;
    const speeds = [1, 1.25, 1.5, 2, 0.75];
    const nextIdx = (speeds.indexOf(playbackRate) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    videoRef.current.playbackRate = nextSpeed;
    setPlaybackRate(nextSpeed);
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "00:00";
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const copyPromptText = () => {
    if (prompt) {
      navigator.clipboard.writeText(prompt);
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2000);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-6 animate-fadeIn"
      onClick={onClose}
    >
      <div
        ref={containerRef}
        className="relative bg-studio-surface border border-studio-border rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Ribbon */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-studio-border bg-studio-panel/70">
          <div className="flex items-center gap-3 min-w-0">
            <span className="p-2 rounded-xl bg-studio-gold/15 text-studio-gold border border-studio-gold/30 shrink-0">
              {isVideo ? <Film className="w-4 h-4" /> : isAudio ? <Volume2 className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
            </span>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-studio-text truncate font-display">
                {title}
              </h2>
              <div className="flex items-center gap-2 text-xs text-studio-text-muted">
                <span className="font-semibold text-studio-blue">{sourceLabel}</span>
                {duration > 0 && <span>· {formatTime(duration)}</span>}
                {aspect && <span>· Formato {aspect}</span>}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isVideo && (
              <div className="hidden sm:flex items-center bg-studio-surface border border-studio-border rounded-xl p-1 gap-1">
                <button
                  onClick={() => setAspect("16:9")}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1",
                    aspect === "16:9"
                      ? "bg-studio-blue text-white shadow-xs"
                      : "text-studio-text-muted hover:text-studio-text"
                  )}
                  title="Modo Cinema 16:9"
                >
                  <Tv className="w-3.5 h-3.5" />
                  <span>16:9</span>
                </button>
                <button
                  onClick={() => setAspect("9:16")}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-semibold transition-all flex items-center gap-1",
                    aspect === "9:16"
                      ? "bg-studio-purple text-white shadow-xs"
                      : "text-studio-text-muted hover:text-studio-text"
                  )}
                  title="Modo Shorts 9:16"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>9:16</span>
                </button>
              </div>
            )}

            <a
              href={mediaUrl}
              download
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl text-studio-text-muted hover:text-studio-text hover:bg-studio-panel border border-transparent hover:border-studio-border transition-all"
              title="Baixar arquivo original"
            >
              <Download className="w-4 h-4" />
            </a>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-studio-text-muted hover:text-studio-red hover:bg-studio-red/10 transition-all"
              title="Fechar (ESC)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Media Viewing Stage */}
        <div className="flex-1 bg-black/95 flex items-center justify-center p-3 sm:p-6 overflow-hidden relative group">
          {isVideo ? (
            <div
              className={cn(
                "relative flex items-center justify-center transition-all duration-300 max-h-[62vh]",
                aspect === "9:16"
                  ? "w-full max-w-[340px] aspect-[9/16] rounded-2xl border-4 border-zinc-800 shadow-2xl overflow-hidden bg-black"
                  : "w-full aspect-video rounded-xl overflow-hidden bg-black"
              )}
            >
              <video
                ref={videoRef}
                src={mediaUrl}
                poster={thumbnailUrl}
                playsInline
                loop={isLooping}
                onClick={togglePlay}
                onTimeUpdate={() => {
                  if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
                }}
                onLoadedMetadata={() => {
                  if (videoRef.current) setDuration(videoRef.current.duration || durationSeconds || 0);
                }}
                onEnded={() => setIsPlaying(false)}
                className="w-full h-full object-contain cursor-pointer"
              />

              {/* Center Play/Pause Indicator on click or paused */}
              {!isPlaying && (
                <div
                  onClick={togglePlay}
                  className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center cursor-pointer transition-all"
                >
                  <div className="w-16 h-16 rounded-full bg-studio-gold text-black flex items-center justify-center shadow-xl hover:scale-105 transition-transform">
                    <Play className="w-7 h-7 ml-1 fill-black" />
                  </div>
                  <span className="mt-3 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-semibold">
                    Clique para assistir
                  </span>
                </div>
              )}
            </div>
          ) : isAudio ? (
            <div className="flex flex-col items-center justify-center p-8 space-y-4 max-w-md w-full">
              <div className="w-20 h-20 rounded-2xl bg-studio-gold/20 text-studio-gold border border-studio-gold/40 flex items-center justify-center shadow-lg">
                <Volume2 className="w-10 h-10 animate-pulse" />
              </div>
              <h3 className="text-base font-bold text-white text-center">{title}</h3>
              <audio controls src={mediaUrl} autoPlay className="w-full" />
            </div>
          ) : (
            <div className="relative max-h-[62vh] max-w-full flex items-center justify-center overflow-hidden rounded-xl">
              <img
                src={mediaUrl}
                alt={title}
                className="max-h-[62vh] w-auto object-contain rounded-lg shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
          )}
        </div>

        {/* Video Scrubber & Controls Bar (Only when media is video) */}
        {isVideo && (
          <div className="px-5 py-3 border-t border-studio-border bg-studio-panel/80 space-y-2">
            {/* Scrubber Progress Bar */}
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs text-studio-text-muted min-w-[42px]">
                {formatTime(currentTime)}
              </span>
              <input
                type="range"
                min={0}
                max={duration || 100}
                step={0.1}
                value={currentTime}
                onChange={handleSeek}
                className="flex-1 h-1.5 bg-studio-surface rounded-full accent-studio-gold cursor-pointer"
              />
              <span className="font-mono text-xs text-studio-text-muted min-w-[42px]">
                {formatTime(duration)}
              </span>
            </div>

            {/* Bottom Buttons */}
            <div className="flex items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-2">
                <button
                  onClick={togglePlay}
                  className="p-2 rounded-xl bg-studio-gold text-black font-bold hover:bg-studio-gold-light transition-all flex items-center gap-1.5 shadow-sm"
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-black" /> : <Play className="w-4 h-4 fill-black ml-0.5" />}
                  <span className="text-xs">{isPlaying ? "Pausar" : "Assistir"}</span>
                </button>

                <button
                  onClick={() => {
                    if (videoRef.current) {
                      videoRef.current.currentTime = 0;
                      setCurrentTime(0);
                      videoRef.current.play();
                      setIsPlaying(true);
                    }
                  }}
                  className="p-2 rounded-xl text-studio-text-muted hover:text-studio-text hover:bg-studio-surface border border-studio-border"
                  title="Reiniciar vídeo"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                {/* Volume */}
                <div className="flex items-center gap-1.5 pl-2">
                  <button
                    onClick={toggleMute}
                    className="p-2 rounded-xl text-studio-text-muted hover:text-studio-text hover:bg-studio-surface"
                  >
                    {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-studio-red" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={isMuted ? 0 : volume}
                    onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                    className="w-16 h-1 bg-studio-surface rounded-full accent-studio-blue cursor-pointer hidden sm:block"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={cycleSpeed}
                  className="px-2.5 py-1.5 rounded-xl text-xs font-mono font-bold bg-studio-surface border border-studio-border text-studio-text hover:border-studio-gold transition-all"
                  title="Velocidade de reprodução"
                >
                  {playbackRate}x
                </button>

                <button
                  onClick={() => setIsLooping(!isLooping)}
                  className={cn(
                    "px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border",
                    isLooping
                      ? "bg-studio-gold/15 text-studio-gold border-studio-gold/40"
                      : "bg-studio-surface border-studio-border text-studio-text-muted hover:text-studio-text"
                  )}
                  title="Repetir em loop"
                >
                  Loop
                </button>

                <button
                  onClick={toggleFullscreen}
                  className="p-2 rounded-xl text-studio-text-muted hover:text-studio-text hover:bg-studio-surface border border-studio-border"
                  title="Tela cheia (F)"
                >
                  {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer Details / Prompt Drawer */}
        {(description || prompt || (tags && tags.length > 0)) && (
          <div className="p-4 bg-studio-surface border-t border-studio-border space-y-2 text-xs">
            {description && (
              <p className="text-studio-text leading-relaxed font-sans">{description}</p>
            )}

            {prompt && (
              <div className="p-3 rounded-xl bg-studio-panel border border-studio-border flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <span className="font-bold text-studio-gold flex items-center gap-1 mb-1">
                    <Sparkles className="w-3.5 h-3.5" /> Prompt Criativo de IA:
                  </span>
                  <p className="text-studio-text-muted italic line-clamp-2">{prompt}</p>
                </div>
                <button
                  onClick={copyPromptText}
                  className="p-1.5 rounded-lg bg-studio-surface hover:bg-studio-border text-studio-text-muted hover:text-studio-text shrink-0"
                  title="Copiar Prompt"
                >
                  {copiedPrompt ? <Check className="w-4 h-4 text-studio-green" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            )}

            {tags && tags.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                {tags.map((t, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md bg-studio-panel border border-studio-border text-[11px] text-studio-text-muted"
                  >
                    #{t.replace(/^#/, "")}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
