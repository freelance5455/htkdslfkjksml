import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { NavTab } from '../../types/music';
import {
  Home,
  Search,
  Library,
  ArrowDownToLine,
  User as UserIcon
} from 'lucide-react';

export const BottomNavigation: React.FC = () => {
  const { activeTab, setActiveTab } = useMusic();

  const navItems: { tab: NavTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { tab: 'home', label: 'Home', icon: Home },
    { tab: 'search', label: 'Search', icon: Search },
    { tab: 'library', label: 'Library', icon: Library },
    { tab: 'downloads', label: 'Downloads', icon: ArrowDownToLine },
    { tab: 'profile', label: 'Profile', icon: UserIcon }
  ];

  return (
    <nav className="w-full bg-[#0e1017]/95 backdrop-blur-xl border-t border-white/[0.08] px-2 py-1.5 z-30 transition-colors">
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.tab;
          const Icon = item.icon;

          return (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              aria-label={item.label}
              className={`relative flex flex-col items-center justify-center min-w-[56px] min-h-[48px] py-1 px-2 rounded-xl transition-all duration-200 group ${
                isActive ? 'text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Active pill background aura */}
              {isActive && (
                <div className="absolute inset-x-2.5 top-1 bottom-1 bg-gradient-to-r from-purple-600/30 via-pink-600/25 to-blue-600/30 rounded-full blur-xs pointer-events-none" />
              )}

              <div
                className={`relative z-10 transition-transform duration-200 ${
                  isActive ? 'scale-110 text-purple-400' : 'group-hover:scale-105'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>

              <span
                className={`relative z-10 text-[10px] tracking-tight mt-1 font-medium transition-colors ${
                  isActive ? 'text-white font-semibold' : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>

              {/* Little active dot indicator */}
              {isActive && (
                <span className="w-1 h-1 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 mt-0.5 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
