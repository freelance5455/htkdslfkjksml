import React, { useState, useEffect } from 'react';
import { Search, X, User, MapPin, CheckSquare, Calendar, MessageSquare, ArrowRight } from 'lucide-react';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../../firebase.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { Employee, FieldVisit, TaskItem } from '../../types/index.ts';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (module: string, itemId?: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ isOpen, onClose, onNavigate }) => {
  const { currentOrg } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<{
    employees: Employee[];
    visits: FieldVisit[];
    tasks: TaskItem[];
  }>({
    employees: [],
    visits: [],
    tasks: [],
  });

  useEffect(() => {
    if (!isOpen) {
      setSearchTerm('');
      setResults({ employees: [], visits: [], tasks: [] });
    }
  }, [isOpen]);

  useEffect(() => {
    if (!searchTerm.trim() || searchTerm.length < 2 || !currentOrg) {
      setResults({ employees: [], visits: [], tasks: [] });
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const term = searchTerm.toLowerCase();

        // 1. Search Employees in Org
        const empQuery = query(collection(db, 'employees'), where('orgId', '==', currentOrg.id), limit(25));
        const empSnap = await getDocs(empQuery);
        const matchedEmployees: Employee[] = [];
        empSnap.forEach((doc) => {
          const emp = doc.data() as Employee;
          if (
            emp.name.toLowerCase().includes(term) ||
            emp.email.toLowerCase().includes(term) ||
            emp.employeeCode.toLowerCase().includes(term) ||
            emp.department?.toLowerCase().includes(term)
          ) {
            matchedEmployees.push(emp);
          }
        });

        // 2. Search Visits in Org
        const visQuery = query(collection(db, 'visits'), where('orgId', '==', currentOrg.id), limit(25));
        const visSnap = await getDocs(visQuery);
        const matchedVisits: FieldVisit[] = [];
        visSnap.forEach((doc) => {
          const vis = doc.data() as FieldVisit;
          if (
            vis.title.toLowerCase().includes(term) ||
            vis.customerName.toLowerCase().includes(term) ||
            vis.siteAddress?.toLowerCase().includes(term) ||
            vis.assignedEmployeeName?.toLowerCase().includes(term)
          ) {
            matchedVisits.push(vis);
          }
        });

        // 3. Search Tasks in Org
        const tskQuery = query(collection(db, 'tasks'), where('orgId', '==', currentOrg.id), limit(25));
        const tskSnap = await getDocs(tskQuery);
        const matchedTasks: TaskItem[] = [];
        tskSnap.forEach((doc) => {
          const tsk = doc.data() as TaskItem;
          if (
            tsk.title.toLowerCase().includes(term) ||
            tsk.assignedEmployeeName?.toLowerCase().includes(term) ||
            tsk.description?.toLowerCase().includes(term)
          ) {
            matchedTasks.push(tsk);
          }
        });

        setResults({
          employees: matchedEmployees,
          visits: matchedVisits,
          tasks: matchedTasks,
        });
      } catch (err) {
        console.error('Global search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [searchTerm, currentOrg]);

  if (!isOpen) return null;

  const totalResults = results.employees.length + results.visits.length + results.tasks.length;

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl border border-slate-200 overflow-hidden animate-in fade-in-0 zoom-in-95 duration-150">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-200 gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search employees, visits, tasks, customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-sm text-slate-800 focus:outline-hidden placeholder-slate-400"
          />
          {searchTerm && (
            <button onClick={() => setSearchTerm('')} className="p-1 text-slate-400 hover:text-slate-600 rounded-md">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs px-2 py-1 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 font-medium"
          >
            Esc
          </button>
        </div>

        {/* Results Area */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {isSearching && (
            <div className="py-8 text-center text-xs text-slate-500 font-medium">Searching workspace records...</div>
          )}

          {!isSearching && searchTerm.length >= 2 && totalResults === 0 && (
            <div className="py-8 text-center text-sm text-slate-500">
              No matching records found for <span className="font-semibold text-slate-700">"{searchTerm}"</span>
            </div>
          )}

          {!isSearching && !searchTerm && (
            <div className="py-6 text-center text-xs text-slate-400">
              Type at least 2 characters to search across workforce, visits, and tasks.
            </div>
          )}

          {/* Employees List */}
          {results.employees.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2 mb-1.5 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" /> Employees ({results.employees.length})
              </div>
              <div className="space-y-1">
                {results.employees.map((emp) => (
                  <button
                    key={emp.id}
                    onClick={() => {
                      onNavigate('employees', emp.id);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 text-left border border-transparent hover:border-slate-200 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-xs">
                        {emp.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-slate-800">{emp.name}</div>
                        <div className="text-xs text-slate-500">
                          {emp.employeeCode} · {emp.designation || emp.department}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Visits List */}
          {results.visits.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" /> Field Visits ({results.visits.length})
              </div>
              <div className="space-y-1">
                {results.visits.map((vis) => (
                  <button
                    key={vis.id}
                    onClick={() => {
                      onNavigate('visits', vis.id);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 text-left border border-transparent hover:border-slate-200 transition-colors"
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-800">{vis.title}</div>
                      <div className="text-xs text-slate-500">
                        {vis.customerName} · Assigned to {vis.assignedEmployeeName}
                      </div>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium capitalize">
                      {vis.status.replace('_', ' ')}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Tasks List */}
          {results.tasks.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2 mb-1.5 flex items-center gap-1.5">
                <CheckSquare className="w-3.5 h-3.5" /> Tasks ({results.tasks.length})
              </div>
              <div className="space-y-1">
                {results.tasks.map((tsk) => (
                  <button
                    key={tsk.id}
                    onClick={() => {
                      onNavigate('tasks', tsk.id);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 text-left border border-transparent hover:border-slate-200 transition-colors"
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-800">{tsk.title}</div>
                      <div className="text-xs text-slate-500">
                        Due {tsk.dueDate} · {tsk.assignedEmployeeName}
                      </div>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium capitalize">
                      {tsk.status}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
