import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts } = useApp();

  if (!toasts.length) return null;

  return (
    <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#1C1C1C] border border-[#303030] shadow-2xl text-[#F5F2ED] backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          {toast.type === 'error' ? (
            <AlertCircle className="w-5 h-5 text-[#C84A3A] shrink-0" />
          ) : toast.type === 'info' ? (
            <Info className="w-5 h-5 text-[#E87535] shrink-0" />
          ) : (
            <CheckCircle2 className="w-5 h-5 text-[#72A65A] shrink-0" />
          )}
          <span className="text-xs font-semibold leading-snug">{toast.message}</span>
        </div>
      ))}
    </div>
  );
};
