import React from 'react';
import { OmazifyLogo } from './OmazifyLogo';

interface NtixLogoProps {
  variant?: 'color' | 'white';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const NtixLogo: React.FC<NtixLogoProps> = ({
  variant = 'color',
  className = '',
  size = 'md',
}) => {
  return (
    <OmazifyLogo
      variant={variant === 'white' ? 'white' : 'container'}
      className={className}
      size={size}
    />
  );
};

export default NtixLogo;
