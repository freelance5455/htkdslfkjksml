import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, Link as LinkIcon, Sparkles, RefreshCw, X } from 'lucide-react';
import { SAMPLE_PRESETS } from '../data/presets';
import { SamplePreset } from '../types';

interface ImageUploaderProps {
  imagePreview: string | null;
  onImageSelected: (base64Data: string, mimeType: string, preset?: SamplePreset) => void;
  onClearImage: () => void;
  isAnalyzing: boolean;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  imagePreview,
  onImageSelected,
  onClearImage,
  isAnalyzing,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [urlInput, setUrlInput] = useState('');
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [urlLoading, setUrlLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    setErrorMessage(null);
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please select a valid image file (PNG, JPG, WebP).');
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      setErrorMessage('Image size is too large (max 20MB).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        onImageSelected(result, file.type);
      }
    };
    reader.onerror = () => {
      setErrorMessage('Failed to read image file.');
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;

    setUrlLoading(true);
    setErrorMessage(null);

    try {
      // Fetch image from URL and convert to Base64
      const response = await fetch(urlInput.trim());
      if (!response.ok) throw new Error('Could not fetch image from the provided URL.');
      const blob = await response.blob();
      if (!blob.type.startsWith('image/')) {
        throw new Error('The URL did not return a valid image format.');
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        onImageSelected(base64, blob.type);
        setUrlLoading(false);
        setShowUrlInput(false);
        setUrlInput('');
      };
      reader.readAsDataURL(blob);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load image from URL.');
      setUrlLoading(false);
    }
  };

  const handleSelectPreset = async (preset: SamplePreset) => {
    setErrorMessage(null);
    setUrlLoading(true);

    try {
      const response = await fetch(preset.imageUrl);
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        onImageSelected(base64, blob.type, preset);
        setUrlLoading(false);
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      // Fallback: provide direct URL
      onImageSelected(preset.imageUrl, 'image/jpeg', preset);
      setUrlLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* If Image is selected */}
      {imagePreview ? (
        <div className="relative group rounded-2xl overflow-hidden border border-stone-800 bg-stone-900/60 shadow-xl transition-all">
          <div className="relative aspect-[16/10] sm:aspect-[21/9] w-full overflow-hidden bg-stone-950 flex items-center justify-center">
            <img
              src={imagePreview}
              alt="Source scene for story ghostwriting"
              className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
            />
            {/* Subtle gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-transparent pointer-events-none" />

            {/* In-analysis pulsing badge */}
            {isAnalyzing && (
              <div className="absolute inset-0 bg-stone-950/70 backdrop-blur-sm flex flex-col items-center justify-center gap-3 z-20">
                <div className="relative">
                  <div className="w-14 h-14 rounded-full border-2 border-amber-500/30 border-t-amber-400 animate-spin" />
                  <Sparkles className="w-6 h-6 text-amber-400 absolute inset-0 m-auto animate-pulse" />
                </div>
                <div className="text-center space-y-1">
                  <p className="font-display font-medium text-amber-200 tracking-wide text-sm sm:text-base">
                    Probing Visual Tension & Lore
                  </p>
                  <p className="text-xs text-stone-400 font-sans">
                    Analyzing mood, sensory cues, and atmospheric lighting...
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Action overlay buttons */}
          <div className="absolute top-3 right-3 flex items-center gap-2 z-10">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isAnalyzing}
              className="px-3 py-1.5 rounded-lg bg-stone-900/90 hover:bg-stone-800 text-stone-200 text-xs font-medium border border-stone-700/80 backdrop-blur-md shadow-lg flex items-center gap-1.5 transition-all hover:scale-105 disabled:opacity-50"
            >
              <RefreshCw className="w-3.5 h-3.5 text-stone-400" />
              <span>Change Image</span>
            </button>

            <button
              onClick={onClearImage}
              disabled={isAnalyzing}
              className="p-1.5 rounded-lg bg-stone-900/90 hover:bg-red-950/60 text-stone-300 hover:text-red-300 text-xs border border-stone-700/80 backdrop-blur-md shadow-lg transition-all disabled:opacity-50"
              title="Remove image"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Upload Area */
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative border-2 border-dashed rounded-2xl p-6 sm:p-10 transition-all text-center flex flex-col items-center justify-center gap-4 ${
            isDragging
              ? 'border-amber-400 bg-amber-500/10 shadow-2xl shadow-amber-500/20 scale-[1.01]'
              : 'border-stone-800 hover:border-stone-700 bg-stone-900/40 hover:bg-stone-900/60'
          }`}
        >
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/10 via-stone-800 to-stone-900 border border-stone-700/80 flex items-center justify-center text-amber-400 shadow-inner">
            <Upload className="w-7 h-7" />
          </div>

          <div className="max-w-md space-y-1.5">
            <h3 className="font-display font-semibold text-stone-100 text-lg tracking-wide">
              Cast a Scene into the Ghostwriter's Eye
            </h3>
            <p className="text-xs sm:text-sm text-stone-400 leading-relaxed">
              Upload any evocative photo, concept art, landscape, or interior. Gemini will dissect its atmosphere and write the opening chapter.
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs sm:text-sm font-semibold shadow-lg shadow-amber-500/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              <ImageIcon className="w-4 h-4" />
              <span>Browse Image File</span>
            </button>

            <button
              onClick={() => setShowUrlInput(!showUrlInput)}
              className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs sm:text-sm font-medium border border-stone-700 transition-all hover:scale-105 flex items-center gap-1.5"
            >
              <LinkIcon className="w-3.5 h-3.5 text-stone-400" />
              <span>Paste Image URL</span>
            </button>
          </div>

          {/* URL Form Drawer */}
          {showUrlInput && (
            <form onSubmit={handleUrlSubmit} className="w-full max-w-md mt-2 flex gap-2">
              <input
                type="url"
                placeholder="https://images.unsplash.com/photo-..."
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                className="flex-1 px-3.5 py-2 rounded-xl bg-stone-950 border border-stone-700 text-xs text-stone-200 placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
              />
              <button
                type="submit"
                disabled={urlLoading || !urlInput.trim()}
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-amber-600 hover:text-white text-xs font-medium text-stone-200 border border-stone-700 transition-colors disabled:opacity-50"
              >
                {urlLoading ? 'Fetching...' : 'Load'}
              </button>
            </form>
          )}

          <p className="text-[11px] text-stone-500">
            Supports PNG, JPEG, WebP, GIF up to 20MB. Drag and drop anywhere on this card.
          </p>
        </div>
      )}

      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        accept="image/png,image/jpeg,image/webp,image/gif"
        className="hidden"
      />

      {/* Error Message */}
      {errorMessage && (
        <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-xs text-center">
          {errorMessage}
        </div>
      )}

      {/* Presets Gallery (shown when no image selected or as inspiration chips) */}
      {!imagePreview && (
        <div className="space-y-2.5 pt-2">
          <div className="flex items-center justify-between text-xs text-stone-400">
            <span className="flex items-center gap-1 font-medium text-stone-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Or test with curated inspiration scenes:
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {SAMPLE_PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleSelectPreset(preset)}
                disabled={urlLoading || isAnalyzing}
                className="group relative rounded-xl overflow-hidden border border-stone-800 hover:border-amber-500/60 bg-stone-900/60 text-left transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-amber-950/30 disabled:opacity-50"
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-stone-950 relative">
                  <img
                    src={preset.imageUrl}
                    alt={preset.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />
                </div>
                <div className="p-2.5 space-y-0.5">
                  <p className="font-display text-xs font-semibold text-stone-200 group-hover:text-amber-300 line-clamp-1">
                    {preset.title}
                  </p>
                  <p className="text-[10px] text-stone-400 line-clamp-1">{preset.genre}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
