import * as THREE from 'three';
import { PieceType, PieceColor } from '../../types/chess';
import { PieceMaterials } from './materials';

/**
 * Creates soft contact shadow disk at the base of each piece
 */
function createContactShadow(): THREE.Mesh {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 30);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
  grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.25)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);

  const tex = new THREE.CanvasTexture(canvas);
  const geo = new THREE.PlaneGeometry(0.85, 0.85);
  const mat = new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    depthWrite: false,
    opacity: 0.7,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.005;
  mesh.renderOrder = 1;
  return mesh;
}

/**
 * Helper to build lathe profiles
 */
function createLatheMesh(points: [number, number][], material: THREE.Material): THREE.Mesh {
  const vPoints = points.map(([r, y]) => new THREE.Vector2(r, y));
  const geometry = new THREE.LatheGeometry(vPoints, 32);
  const mesh = new THREE.Mesh(geometry, material);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

/**
 * 1. Pawn: 4 distinct parts (Pedestal lathe, neck collar torus, head sphere, contact shadow)
 */
export function createPawnMesh(color: PieceColor, materials: PieceMaterials): THREE.Group {
  const group = new THREE.Group();
  const mainMat = color === 'w' ? materials.whiteMain : materials.blackMain;
  const accentMat = color === 'w' ? materials.whiteAccent : materials.blackAccent;

  // Base and tapered body
  const bodyPoints: [number, number][] = [
    [0.0, 0.0],
    [0.34, 0.0],
    [0.34, 0.06],
    [0.30, 0.10],
    [0.26, 0.14],
    [0.22, 0.24],
    [0.17, 0.44],
    [0.14, 0.60],
    [0.18, 0.66],
    [0.12, 0.70],
    [0.0, 0.70],
  ];
  group.add(createLatheMesh(bodyPoints, mainMat));

  // Accent Collar Ring
  const collarGeo = new THREE.TorusGeometry(0.16, 0.025, 12, 24);
  const collar = new THREE.Mesh(collarGeo, accentMat);
  collar.rotation.x = Math.PI / 2;
  collar.position.y = 0.66;
  collar.castShadow = true;
  group.add(collar);

  // Spherical Head
  const headGeo = new THREE.SphereGeometry(0.17, 24, 16);
  const head = new THREE.Mesh(headGeo, mainMat);
  head.position.y = 0.84;
  head.castShadow = true;
  group.add(head);

  group.add(createContactShadow());
  return group;
}

/**
 * 2. Rook: 5 distinct parts (Flared base, fluted shaft, crenelated battlement ring, inner floor, contact shadow)
 */
export function createRookMesh(color: PieceColor, materials: PieceMaterials): THREE.Group {
  const group = new THREE.Group();
  const mainMat = color === 'w' ? materials.whiteMain : materials.blackMain;
  const accentMat = color === 'w' ? materials.whiteAccent : materials.blackAccent;

  // Base and cylindrical shaft
  const bodyPoints: [number, number][] = [
    [0.0, 0.0],
    [0.38, 0.0],
    [0.38, 0.08],
    [0.32, 0.14],
    [0.27, 0.22],
    [0.24, 0.40],
    [0.23, 0.72],
    [0.27, 0.82],
    [0.31, 0.92],
    [0.28, 0.94],
    [0.0, 0.94],
  ];
  group.add(createLatheMesh(bodyPoints, mainMat));

  // Waist accent ring
  const waistGeo = new THREE.TorusGeometry(0.25, 0.025, 12, 24);
  const waist = new THREE.Mesh(waistGeo, accentMat);
  waist.rotation.x = Math.PI / 2;
  waist.position.y = 0.82;
  waist.castShadow = true;
  group.add(waist);

  // Castellated battlements (4 merlons)
  const merlonCount = 4;
  for (let i = 0; i < merlonCount; i++) {
    const angle = (i * Math.PI * 2) / merlonCount + Math.PI / 4;
    const merlonGeo = new THREE.BoxGeometry(0.12, 0.16, 0.10);
    const merlon = new THREE.Mesh(merlonGeo, mainMat);
    merlon.position.set(Math.cos(angle) * 0.25, 1.02, Math.sin(angle) * 0.25);
    merlon.rotation.y = -angle;
    merlon.castShadow = true;
    group.add(merlon);
  }

  // Inner roof recess
  const roofGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.04, 16);
  const roof = new THREE.Mesh(roofGeo, accentMat);
  roof.position.y = 0.94;
  group.add(roof);

  group.add(createContactShadow());
  return group;
}

/**
 * 3. Knight: 6 distinct parts (Lathe base, sloped neck, sculpted horse head with muzzle, ears, bridle accent, contact shadow)
 */
export function createKnightMesh(color: PieceColor, materials: PieceMaterials): THREE.Group {
  const group = new THREE.Group();
  const mainMat = color === 'w' ? materials.whiteMain : materials.blackMain;
  const accentMat = color === 'w' ? materials.whiteAccent : materials.blackAccent;

  // Base pedestal
  const basePoints: [number, number][] = [
    [0.0, 0.0],
    [0.38, 0.0],
    [0.38, 0.08],
    [0.33, 0.14],
    [0.28, 0.22],
    [0.26, 0.32],
    [0.24, 0.36],
    [0.0, 0.36],
  ];
  group.add(createLatheMesh(basePoints, mainMat));

  // Sculpted horse silhouette via ExtrudeGeometry
  const shape = new THREE.Shape();
  shape.moveTo(0.0, 0.0);
  shape.lineTo(0.18, 0.0);
  shape.bezierCurveTo(0.24, 0.2, 0.30, 0.45, 0.28, 0.65); // arched snout
  shape.bezierCurveTo(0.26, 0.72, 0.18, 0.75, 0.10, 0.72); // muzzle tip
  shape.lineTo(0.08, 0.62); // chin
  shape.bezierCurveTo(0.02, 0.52, -0.05, 0.45, -0.12, 0.42); // jaw
  shape.bezierCurveTo(-0.16, 0.65, -0.12, 0.78, -0.08, 0.85); // ear top
  shape.lineTo(-0.14, 0.83); // ear back
  shape.bezierCurveTo(-0.24, 0.65, -0.26, 0.35, -0.22, 0.15); // arched mane back
  shape.lineTo(-0.20, 0.0);
  shape.closePath();

  const extrudeSettings: THREE.ExtrudeGeometryOptions = {
    steps: 1,
    depth: 0.22,
    bevelEnabled: true,
    bevelThickness: 0.04,
    bevelSize: 0.03,
    bevelSegments: 4,
  };

  const knightGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
  knightGeo.center();
  const knightBody = new THREE.Mesh(knightGeo, mainMat);
  knightBody.position.set(0, 0.82, 0);
  // Default facing opponent
  knightBody.rotation.y = color === 'w' ? 0 : Math.PI;
  knightBody.castShadow = true;
  group.add(knightBody);

  // Muzzle accent band
  const muzzleGeo = new THREE.CylinderGeometry(0.08, 0.09, 0.08, 12);
  const muzzle = new THREE.Mesh(muzzleGeo, accentMat);
  muzzle.position.set(color === 'w' ? 0.18 : -0.18, 0.95, 0);
  muzzle.rotation.z = Math.PI / 4;
  muzzle.castShadow = true;
  group.add(muzzle);

  group.add(createContactShadow());
  return group;
}

/**
 * 4. Bishop: 5 distinct parts (Tiered base, fluted stem, teardrop miter head, apex finial ball, contact shadow)
 */
export function createBishopMesh(color: PieceColor, materials: PieceMaterials): THREE.Group {
  const group = new THREE.Group();
  const mainMat = color === 'w' ? materials.whiteMain : materials.blackMain;
  const accentMat = color === 'w' ? materials.whiteAccent : materials.blackAccent;

  // Base and waist
  const bodyPoints: [number, number][] = [
    [0.0, 0.0],
    [0.37, 0.0],
    [0.37, 0.08],
    [0.32, 0.14],
    [0.26, 0.22],
    [0.20, 0.44],
    [0.17, 0.68],
    [0.22, 0.74],
    [0.18, 0.80],
    [0.0, 0.80],
  ];
  group.add(createLatheMesh(bodyPoints, mainMat));

  // Accent collar
  const collarGeo = new THREE.TorusGeometry(0.20, 0.025, 12, 24);
  const collar = new THREE.Mesh(collarGeo, accentMat);
  collar.rotation.x = Math.PI / 2;
  collar.position.y = 0.74;
  collar.castShadow = true;
  group.add(collar);

  // Teardrop Miter Head
  const miterPoints: [number, number][] = [
    [0.0, 0.80],
    [0.16, 0.82],
    [0.24, 0.94],
    [0.22, 1.10],
    [0.14, 1.22],
    [0.05, 1.28],
    [0.0, 1.30],
  ];
  const miter = createLatheMesh(miterPoints, mainMat);
  group.add(miter);

  // Slit cut visual indicator (dark recessed sliver)
  const slitGeo = new THREE.BoxGeometry(0.04, 0.22, 0.28);
  const slitMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
  const slit = new THREE.Mesh(slitGeo, slitMat);
  slit.position.set(0.06, 1.05, 0);
  slit.rotation.z = Math.PI / 6;
  group.add(slit);

  // Top Finial Ball
  const finialGeo = new THREE.SphereGeometry(0.06, 16, 12);
  const finial = new THREE.Mesh(finialGeo, accentMat);
  finial.position.y = 1.35;
  finial.castShadow = true;
  group.add(finial);

  group.add(createContactShadow());
  return group;
}

/**
 * 5. Queen: 6 distinct parts (Wide base, ornate waist, flared coronet, jewel rim spheres, central orb, contact shadow)
 */
export function createQueenMesh(color: PieceColor, materials: PieceMaterials): THREE.Group {
  const group = new THREE.Group();
  const mainMat = color === 'w' ? materials.whiteMain : materials.blackMain;
  const accentMat = color === 'w' ? materials.whiteAccent : materials.blackAccent;

  // Stately body
  const bodyPoints: [number, number][] = [
    [0.0, 0.0],
    [0.40, 0.0],
    [0.40, 0.08],
    [0.34, 0.16],
    [0.28, 0.26],
    [0.22, 0.50],
    [0.18, 0.76],
    [0.25, 0.84],
    [0.20, 0.92],
    [0.28, 1.12],
    [0.32, 1.26],
    [0.24, 1.28],
    [0.0, 1.28],
  ];
  group.add(createLatheMesh(bodyPoints, mainMat));

  // Royal waist band
  const waistGeo = new THREE.TorusGeometry(0.24, 0.03, 12, 28);
  const waist = new THREE.Mesh(waistGeo, accentMat);
  waist.rotation.x = Math.PI / 2;
  waist.position.y = 0.84;
  waist.castShadow = true;
  group.add(waist);

  // Crown coronet jewels (8 mini spheres around the rim)
  const pointCount = 8;
  const crownRadius = 0.31;
  for (let i = 0; i < pointCount; i++) {
    const angle = (i * Math.PI * 2) / pointCount;
    const jewelGeo = new THREE.SphereGeometry(0.035, 12, 10);
    const jewel = new THREE.Mesh(jewelGeo, accentMat);
    jewel.position.set(Math.cos(angle) * crownRadius, 1.28, Math.sin(angle) * crownRadius);
    jewel.castShadow = true;
    group.add(jewel);
  }

  // Apex royal finial orb
  const orbGeo = new THREE.SphereGeometry(0.085, 20, 16);
  const orb = new THREE.Mesh(orbGeo, accentMat);
  orb.position.y = 1.36;
  orb.castShadow = true;
  group.add(orb);

  group.add(createContactShadow());
  return group;
}

/**
 * 6. King: 7 distinct parts (Broad base, stately body, imperial mantle, royal dome, gold cross finial, accent rings, contact shadow)
 */
export function createKingMesh(color: PieceColor, materials: PieceMaterials): THREE.Group {
  const group = new THREE.Group();
  const mainMat = color === 'w' ? materials.whiteMain : materials.blackMain;
  const accentMat = color === 'w' ? materials.whiteAccent : materials.blackAccent;

  // Regal tiered base and body
  const bodyPoints: [number, number][] = [
    [0.0, 0.0],
    [0.42, 0.0],
    [0.42, 0.09],
    [0.36, 0.17],
    [0.30, 0.28],
    [0.24, 0.54],
    [0.20, 0.80],
    [0.28, 0.90],
    [0.23, 0.98],
    [0.30, 1.20],
    [0.33, 1.34],
    [0.28, 1.40],
    [0.0, 1.40],
  ];
  group.add(createLatheMesh(bodyPoints, mainMat));

  // Double accent rings
  const ringGeo1 = new THREE.TorusGeometry(0.26, 0.03, 12, 28);
  const ring1 = new THREE.Mesh(ringGeo1, accentMat);
  ring1.rotation.x = Math.PI / 2;
  ring1.position.y = 0.90;
  ring1.castShadow = true;
  group.add(ring1);

  // Arched imperial dome
  const domeGeo = new THREE.SphereGeometry(0.22, 20, 16, 0, Math.PI * 2, 0, Math.PI / 2);
  const dome = new THREE.Mesh(domeGeo, mainMat);
  dome.position.y = 1.38;
  dome.castShadow = true;
  group.add(dome);

  // Royal Cross Finial
  const crossGroup = new THREE.Group();
  // Vertical stem
  const vBarGeo = new THREE.BoxGeometry(0.045, 0.22, 0.045);
  const vBar = new THREE.Mesh(vBarGeo, accentMat);
  vBar.position.y = 1.54;
  vBar.castShadow = true;
  crossGroup.add(vBar);

  // Horizontal arms
  const hBarGeo = new THREE.BoxGeometry(0.16, 0.045, 0.045);
  const hBar = new THREE.Mesh(hBarGeo, accentMat);
  hBar.position.y = 1.57;
  hBar.castShadow = true;
  crossGroup.add(hBar);

  group.add(crossGroup);
  group.add(createContactShadow());
  return group;
}

/**
 * Master Factory to spawn piece 3D groups
 */
export function createPieceMesh(
  type: PieceType,
  color: PieceColor,
  materials: PieceMaterials
): THREE.Group {
  switch (type) {
    case 'p':
      return createPawnMesh(color, materials);
    case 'r':
      return createRookMesh(color, materials);
    case 'n':
      return createKnightMesh(color, materials);
    case 'b':
      return createBishopMesh(color, materials);
    case 'q':
      return createQueenMesh(color, materials);
    case 'k':
      return createKingMesh(color, materials);
  }
}
