import * as THREE from 'three';
import { BoardStyle, PieceStyle } from '../../types/chess';

export interface BoardMaterials {
  lightSquare: THREE.Material;
  darkSquare: THREE.Material;
  frame: THREE.Material;
  trim: THREE.Material;
}

export interface PieceMaterials {
  whiteMain: THREE.Material;
  whiteAccent: THREE.Material;
  blackMain: THREE.Material;
  blackAccent: THREE.Material;
}

/**
 * Creates high-fidelity procedural canvas textures for wood grain, marble veins, and glass frost.
 * Zero external asset requests, zero 404s.
 */
function createProceduralWoodTexture(isDark: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base wood tone
  ctx.fillStyle = isDark ? '#3D2516' : '#C7A779';
  ctx.fillRect(0, 0, 512, 512);

  // Concentric wood ring layers
  ctx.lineWidth = 1.5;
  const ringCount = 35;
  for (let i = 0; i < ringCount; i++) {
    ctx.strokeStyle = isDark
      ? `rgba(32, 17, 8, ${0.12 + Math.random() * 0.15})`
      : `rgba(148, 110, 68, ${0.12 + Math.random() * 0.18})`;
    ctx.beginPath();
    const cx = 256 + Math.sin(i * 0.4) * 40;
    const cy = 256 + Math.cos(i * 0.3) * 60;
    ctx.ellipse(cx, cy, 30 + i * 14, 20 + i * 9, 0.4, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Grain streaks
  for (let y = 0; y < 512; y += 4) {
    ctx.fillStyle = isDark ? 'rgba(20, 10, 5, 0.08)' : 'rgba(120, 85, 45, 0.08)';
    ctx.fillRect(0, y + (Math.random() - 0.5) * 3, 512, 1.5);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

function createProceduralMarbleTexture(isDark: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base marble stone
  ctx.fillStyle = isDark ? '#14171E' : '#EAECEF';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle cloud noise
  for (let i = 0; i < 40; i++) {
    const rad = 60 + Math.random() * 140;
    const grad = ctx.createRadialGradient(
      Math.random() * 512, Math.random() * 512, 10,
      Math.random() * 512, Math.random() * 512, rad
    );
    if (isDark) {
      grad.addColorStop(0, 'rgba(38, 48, 65, 0.25)');
      grad.addColorStop(1, 'rgba(20, 23, 30, 0)');
    } else {
      grad.addColorStop(0, 'rgba(215, 222, 230, 0.35)');
      grad.addColorStop(1, 'rgba(240, 243, 246, 0)');
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);
  }

  // Fine serpentine veins
  ctx.lineWidth = 1.2;
  for (let v = 0; v < 8; v++) {
    ctx.strokeStyle = isDark ? 'rgba(0, 210, 255, 0.25)' : 'rgba(90, 105, 120, 0.3)';
    ctx.beginPath();
    let x = Math.random() * 512;
    let y = 0;
    ctx.moveTo(x, y);
    while (y < 512) {
      x += (Math.random() - 0.5) * 45;
      y += 18 + Math.random() * 25;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

function createProceduralFuturisticTexture(isDark: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Dark metallic base
  ctx.fillStyle = isDark ? '#0A0E17' : '#141E30';
  ctx.fillRect(0, 0, 512, 512);

  // Carbon weave grid
  ctx.strokeStyle = isDark ? 'rgba(0, 240, 255, 0.06)' : 'rgba(0, 210, 255, 0.12)';
  ctx.lineWidth = 1;
  const step = 16;
  for (let x = 0; x <= 512; x += step) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 512);
    ctx.stroke();
  }
  for (let y = 0; y <= 512; y += step) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  // Glowing circuit line traces - electric cyan and subtle neon
  ctx.strokeStyle = isDark ? 'rgba(0, 210, 255, 0.35)' : 'rgba(56, 189, 248, 0.35)';
  ctx.lineWidth = 2.0;
  ctx.beginPath();
  ctx.moveTo(32, 32);
  ctx.lineTo(128, 32);
  ctx.lineTo(160, 64);
  ctx.lineTo(320, 64);
  ctx.stroke();

  // Corner nodes
  ctx.fillStyle = '#00D2FF';
  ctx.beginPath();
  ctx.arc(32, 32, 4, 0, Math.PI * 2);
  ctx.arc(320, 64, 3.5, 0, Math.PI * 2);
  ctx.arc(480, 480, 4, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function createBoardMaterials(style: BoardStyle): BoardMaterials {
  if (style === 'futuristic') {
    const lightTech = createProceduralFuturisticTexture(false);
    const darkTech = createProceduralFuturisticTexture(true);

    return {
      lightSquare: new THREE.MeshPhysicalMaterial({
        map: lightTech,
        roughness: 0.15,
        metalness: 0.85,
        clearcoat: 0.9,
        clearcoatRoughness: 0.1,
      }),
      darkSquare: new THREE.MeshPhysicalMaterial({
        map: darkTech,
        roughness: 0.2,
        metalness: 0.9,
        clearcoat: 0.8,
        clearcoatRoughness: 0.15,
      }),
      frame: new THREE.MeshPhysicalMaterial({
        color: 0x05070C,
        roughness: 0.3,
        metalness: 0.95,
        clearcoat: 0.6,
      }),
      trim: new THREE.MeshPhysicalMaterial({
        color: 0x00F0FF,
        emissive: 0x004455,
        roughness: 0.1,
        metalness: 0.9,
      }),
    };
  }

  if (style === 'wooden') {
    const lightWood = createProceduralWoodTexture(false);
    const darkWood = createProceduralWoodTexture(true);

    return {
      lightSquare: new THREE.MeshPhysicalMaterial({
        map: lightWood,
        roughness: 0.35,
        metalness: 0.05,
        clearcoat: 0.3,
        clearcoatRoughness: 0.2,
      }),
      darkSquare: new THREE.MeshPhysicalMaterial({
        map: darkWood,
        roughness: 0.38,
        metalness: 0.08,
        clearcoat: 0.3,
        clearcoatRoughness: 0.2,
      }),
      frame: new THREE.MeshPhysicalMaterial({
        color: 0x1A110B,
        roughness: 0.45,
        metalness: 0.15,
        clearcoat: 0.4,
      }),
      trim: new THREE.MeshPhysicalMaterial({
        color: 0x3D2817, // Warm deep walnut trim
        roughness: 0.35,
        metalness: 0.25,
      }),
    };
  }

  if (style === 'marble') {
    const lightMarble = createProceduralMarbleTexture(false);
    const darkMarble = createProceduralMarbleTexture(true);

    return {
      lightSquare: new THREE.MeshPhysicalMaterial({
        map: lightMarble,
        roughness: 0.18,
        metalness: 0.1,
        clearcoat: 0.8,
        clearcoatRoughness: 0.1,
      }),
      darkSquare: new THREE.MeshPhysicalMaterial({
        map: darkMarble,
        roughness: 0.18,
        metalness: 0.15,
        clearcoat: 0.8,
        clearcoatRoughness: 0.1,
      }),
      frame: new THREE.MeshPhysicalMaterial({
        color: 0x0D111A,
        roughness: 0.25,
        metalness: 0.4,
        clearcoat: 0.7,
      }),
      trim: new THREE.MeshPhysicalMaterial({
        color: 0x00D2FF, // Electric blue neon trim
        roughness: 0.1,
        metalness: 0.9,
      }),
    };
  }

  if (style === 'glass') {
    return {
      lightSquare: new THREE.MeshPhysicalMaterial({
        color: 0xDDF3FF,
        roughness: 0.1,
        metalness: 0.1,
        transmission: 0.65,
        thickness: 0.8,
        ior: 1.5,
        transparent: true,
        opacity: 0.88,
      }),
      darkSquare: new THREE.MeshPhysicalMaterial({
        color: 0x0B2138,
        roughness: 0.12,
        metalness: 0.3,
        transmission: 0.5,
        thickness: 0.8,
        ior: 1.5,
        transparent: true,
        opacity: 0.92,
      }),
      frame: new THREE.MeshPhysicalMaterial({
        color: 0x070B14,
        roughness: 0.2,
        metalness: 0.6,
      }),
      trim: new THREE.MeshPhysicalMaterial({
        color: 0x38BDF8,
        emissive: 0x0C3559,
        roughness: 0.15,
        metalness: 0.8,
      }),
    };
  }

  // Default Classic (Warm Cream & Dark Navy/Mahogany)
  return {
    lightSquare: new THREE.MeshPhysicalMaterial({
      color: 0xE8D5B5,
      roughness: 0.28,
      metalness: 0.05,
      clearcoat: 0.35,
    }),
    darkSquare: new THREE.MeshPhysicalMaterial({
      color: 0x302117,
      roughness: 0.32,
      metalness: 0.08,
      clearcoat: 0.35,
    }),
    frame: new THREE.MeshPhysicalMaterial({
      color: 0x140E0A,
      roughness: 0.4,
      metalness: 0.2,
      clearcoat: 0.5,
    }),
    trim: new THREE.MeshPhysicalMaterial({
      color: 0xD4AF37, // Royal gold
      roughness: 0.22,
      metalness: 0.8,
    }),
  };
}

export function createPieceMaterials(style: PieceStyle): PieceMaterials {
  if (style === 'metal') {
    // Brushed Gold vs Polished Titanium
    return {
      whiteMain: new THREE.MeshPhysicalMaterial({
        color: 0xFFDE7B,
        roughness: 0.15,
        metalness: 0.92,
        clearcoat: 0.6,
      }),
      whiteAccent: new THREE.MeshPhysicalMaterial({
        color: 0xFFF0B8,
        roughness: 0.1,
        metalness: 0.95,
      }),
      blackMain: new THREE.MeshPhysicalMaterial({
        color: 0x242833,
        roughness: 0.2,
        metalness: 0.88,
        clearcoat: 0.5,
      }),
      blackAccent: new THREE.MeshPhysicalMaterial({
        color: 0x00D2FF,
        roughness: 0.1,
        metalness: 0.9,
      }),
    };
  }

  if (style === 'fantasy') {
    // Royal Ivory-Gold vs Dark Obsidian-Crimson
    return {
      whiteMain: new THREE.MeshPhysicalMaterial({
        color: 0xFDFBF7,
        roughness: 0.2,
        metalness: 0.1,
        clearcoat: 0.7,
      }),
      whiteAccent: new THREE.MeshPhysicalMaterial({
        color: 0xE6B343,
        roughness: 0.15,
        metalness: 0.85,
      }),
      blackMain: new THREE.MeshPhysicalMaterial({
        color: 0x15121E,
        roughness: 0.22,
        metalness: 0.3,
        clearcoat: 0.7,
      }),
      blackAccent: new THREE.MeshPhysicalMaterial({
        color: 0x9333EA,
        roughness: 0.18,
        metalness: 0.7,
      }),
    };
  }

  if (style === 'modern') {
    // Minimalist Matte White vs Sleek Satin Anthracite
    return {
      whiteMain: new THREE.MeshPhysicalMaterial({
        color: 0xEEEEF2,
        roughness: 0.3,
        metalness: 0.1,
      }),
      whiteAccent: new THREE.MeshPhysicalMaterial({
        color: 0x38BDF8,
        roughness: 0.2,
        metalness: 0.5,
      }),
      blackMain: new THREE.MeshPhysicalMaterial({
        color: 0x181920,
        roughness: 0.32,
        metalness: 0.2,
      }),
      blackAccent: new THREE.MeshPhysicalMaterial({
        color: 0x64748B,
        roughness: 0.2,
        metalness: 0.6,
      }),
    };
  }

  // Classic Handcrafted Staunton
  return {
    whiteMain: new THREE.MeshPhysicalMaterial({
      color: 0xF2ECE1,
      roughness: 0.25,
      metalness: 0.08,
      clearcoat: 0.45,
      clearcoatRoughness: 0.2,
    }),
    whiteAccent: new THREE.MeshPhysicalMaterial({
      color: 0xDEB887,
      roughness: 0.3,
      metalness: 0.15,
    }),
    blackMain: new THREE.MeshPhysicalMaterial({
      color: 0x1F1A17,
      roughness: 0.28,
      metalness: 0.2,
      clearcoat: 0.45,
      clearcoatRoughness: 0.2,
    }),
    blackAccent: new THREE.MeshPhysicalMaterial({
      color: 0x4A3728,
      roughness: 0.35,
      metalness: 0.15,
    }),
  };
}
