import React, { useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Chess, Square } from 'chess.js';
import { BoardStyle, PieceStyle, PieceColor, PieceType } from '../../types/chess';
import { createBoardMaterials, createPieceMaterials, BoardMaterials, PieceMaterials } from './materials';
import { createPieceMesh } from './pieceGeometries';
import { squareToWorld, worldToSquare, SQUARE_SIZE, isLightSquare } from '../../services/chessCoordinates';

export interface ChessSceneProps {
  game: Chess;
  boardStyle: BoardStyle;
  pieceStyle: PieceStyle;
  playerPerspective: 'w' | 'b';
  viewMode?: '3d' | 'top_down';
  selectedSquare: Square | null;
  legalMoves: string[];
  lastMove: { from: string; to: string } | null;
  hintMove: { from: string; to: string } | null;
  showCoordinates?: boolean;
  interactive: boolean;
  onSquareClick: (square: Square) => void;
  onMoveAttempt?: (from: Square, to: Square) => void;
  cameraResetTrigger?: number;
}

interface PieceObject {
  id: string;
  square: Square;
  type: PieceType;
  color: PieceColor;
  group: THREE.Group;
  currentX: number;
  currentZ: number;
  targetX: number;
  targetZ: number;
  isMoving: boolean;
  moveProgress: number;
}

interface FadingPiece {
  group: THREE.Group;
  progress: number;
}

export const ChessScene: React.FC<ChessSceneProps> = ({
  game,
  boardStyle,
  pieceStyle,
  playerPerspective,
  viewMode = '3d',
  selectedSquare,
  legalMoves,
  lastMove,
  hintMove,
  showCoordinates = true,
  interactive,
  onSquareClick,
  onMoveAttempt,
  cameraResetTrigger,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const boardRootRef = useRef<THREE.Group | null>(null);
  const piecesMapRef = useRef<Map<string, PieceObject>>(new Map());
  const fadingPiecesRef = useRef<FadingPiece[]>([]);
  const boardTilesGroupRef = useRef<THREE.Group | null>(null);
  const highlightsGroupRef = useRef<THREE.Group | null>(null);
  const hintArrowGroupRef = useRef<THREE.Group | null>(null);
  const coordinatesGroupRef = useRef<THREE.Group | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Drag and drop state
  const isDraggingRef = useRef(false);
  const draggedPieceRef = useRef<PieceObject | null>(null);
  const dragPlaneRef = useRef(new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.45));
  const pointerStartPosRef = useRef({ x: 0, y: 0 });
  const hasDraggedFarRef = useRef(false);
  const startHitSquareRef = useRef<Square | null>(null);

  // Materials cache
  const boardMatsRef = useRef<BoardMaterials | null>(null);
  const pieceMatsRef = useRef<PieceMaterials | null>(null);

  // Raycaster helpers
  const raycaster = useRef(new THREE.Raycaster());
  const mouse = useRef(new THREE.Vector2());

  // 1. Initialize Scene & Renderer
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070B13);
    scene.fog = new THREE.FogExp2(0x070B13, 0.032);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 80);
    cameraRef.current = camera;

    // Camera initial position
    if (viewMode === 'top_down') {
      camera.position.set(0, 11.5, 0.01);
    } else {
      camera.position.set(0, 9.4, 8.4);
    }
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // Studio Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio Lighting Rig
    const keyLight = new THREE.DirectionalLight(0xFFF7EA, 2.7);
    keyLight.position.set(5.5, 12.5, 6.5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 24;
    keyLight.shadow.camera.left = -5.5;
    keyLight.shadow.camera.right = 5.5;
    keyLight.shadow.camera.top = 5.5;
    keyLight.shadow.camera.bottom = -5.5;
    keyLight.shadow.bias = -0.0003;
    keyLight.shadow.normalBias = 0.015;
    scene.add(keyLight);

    const fillLight = new THREE.HemisphereLight(0x3B82F6, 0x0F172A, 1.15);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0x00D2FF, 0.9);
    rimLight.position.set(-6, 8, -6);
    scene.add(rimLight);

    // OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.08;
    controls.minDistance = 4.5;
    controls.maxDistance = 14;
    controls.touches = {
      ONE: THREE.TOUCH.ROTATE,
      TWO: THREE.TOUCH.DOLLY_PAN,
    };
    controlsRef.current = controls;

    // Board Root Container Group (Rotated 180° for Black perspective)
    const boardRoot = new THREE.Group();
    scene.add(boardRoot);
    boardRootRef.current = boardRoot;

    // Subgroups inside boardRoot
    const boardTilesGroup = new THREE.Group();
    boardRoot.add(boardTilesGroup);
    boardTilesGroupRef.current = boardTilesGroup;

    const highlightsGroup = new THREE.Group();
    boardRoot.add(highlightsGroup);
    highlightsGroupRef.current = highlightsGroup;

    const hintArrowGroup = new THREE.Group();
    boardRoot.add(hintArrowGroup);
    hintArrowGroupRef.current = hintArrowGroup;

    const coordinatesGroup = new THREE.Group();
    boardRoot.add(coordinatesGroup);
    coordinatesGroupRef.current = coordinatesGroup;

    // Render loop
    let lastTime = performance.now();
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      const now = performance.now();
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      controls.update();

      // Animate piece movement arcs
      piecesMapRef.current.forEach((p) => {
        if (p.isMoving) {
          p.moveProgress = Math.min(1, p.moveProgress + dt * 4.8);
          const t = p.moveProgress;
          const ease = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

          p.group.position.x = THREE.MathUtils.lerp(p.currentX, p.targetX, ease);
          p.group.position.z = THREE.MathUtils.lerp(p.currentZ, p.targetZ, ease);
          p.group.position.y = Math.sin(t * Math.PI) * 0.72;

          if (p.moveProgress >= 1) {
            p.isMoving = false;
            p.currentX = p.targetX;
            p.currentZ = p.targetZ;
            p.group.position.set(p.targetX, 0, p.targetZ);
          }
        }
      });

      // Animate captured pieces sinking and fading
      const remainingFading: FadingPiece[] = [];
      fadingPiecesRef.current.forEach((fade) => {
        fade.progress += dt * 3.2;
        fade.group.rotation.x += dt * 4.0;
        fade.group.position.y -= dt * 1.6;
        fade.group.scale.multiplyScalar(0.95);

        if (fade.progress < 1.0) {
          remainingFading.push(fade);
        } else {
          boardRoot.remove(fade.group);
        }
      });
      fadingPiecesRef.current = remainingFading;

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // 2. Synchronize Board Perspective (0° for White, 180° for Black)
  useEffect(() => {
    if (!boardRootRef.current) return;
    const isBlack = playerPerspective === 'b';
    boardRootRef.current.rotation.y = isBlack ? Math.PI : 0;
  }, [playerPerspective]);

  // 3. Reset Camera when triggered or on viewMode change
  useEffect(() => {
    if (!cameraRef.current || !controlsRef.current) return;
    const camera = cameraRef.current;
    const controls = controlsRef.current;

    if (viewMode === 'top_down') {
      camera.position.set(0, 11.5, 0.01);
    } else {
      camera.position.set(0, 9.4, 8.4);
    }
    camera.lookAt(0, 0, 0);
    controls.target.set(0, 0, 0);
    controls.update();
  }, [viewMode, cameraResetTrigger]);

  // 4. Build Exact 8x8 Board Geometry with Zero Gaps and Zero Yellow Lines
  useEffect(() => {
    if (!boardTilesGroupRef.current) return;
    const group = boardTilesGroupRef.current;
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    const bMats = createBoardMaterials(boardStyle);
    boardMatsRef.current = bMats;

    // Sub-base Plinth beneath the board
    const plinthGeo = new THREE.BoxGeometry(9.3, 0.45, 9.3);
    const plinth = new THREE.Mesh(plinthGeo, bMats.frame);
    plinth.position.y = -0.275;
    plinth.receiveShadow = true;
    group.add(plinth);

    // Outer Perimeter Frame (Rim) - surrounds the 8x8 board from x=4.0 to 4.65
    const outerFrameGeo = new THREE.BoxGeometry(9.1, 0.12, 9.1);
    const outerFrame = new THREE.Mesh(outerFrameGeo, bMats.trim);
    outerFrame.position.y = -0.06;
    outerFrame.receiveShadow = true;
    group.add(outerFrame);

    // Inner Solid Bed (Dark slate underneath tiles to prevent any light bleed)
    const bedGeo = new THREE.BoxGeometry(8.04, 0.05, 8.04);
    const bedMat = new THREE.MeshBasicMaterial({ color: 0x070B13 });
    const bed = new THREE.Mesh(bedGeo, bedMat);
    bed.position.y = -0.075;
    group.add(bed);

    // Exactly 64 contiguous squares with width 1.0 x depth 1.0 (Zero gap, zero bleed)
    const tileGeo = new THREE.BoxGeometry(1.0, 0.1, 1.0);
    for (let rank = 0; rank < 8; rank++) {
      for (let file = 0; file < 8; file++) {
        // Standard chess: a1 is dark square: (file + rank) % 2 === 1 is light
        const isLight = (file + rank) % 2 === 1;
        const mat = isLight ? bMats.lightSquare : bMats.darkSquare;
        const tile = new THREE.Mesh(tileGeo, mat);
        tile.position.set(
          (file - 3.5) * SQUARE_SIZE,
          -0.05,
          -(rank - 3.5) * SQUARE_SIZE
        );
        tile.receiveShadow = true;
        const fileChar = String.fromCharCode(97 + file);
        const rankChar = (rank + 1).toString();
        const sq = `${fileChar}${rankChar}` as Square;
        tile.userData = { square: sq };
        group.add(tile);
      }
    }
  }, [boardStyle]);

  // 5. Build 3D Board Edge Coordinates (A-H, 1-8)
  useEffect(() => {
    if (!coordinatesGroupRef.current) return;
    const group = coordinatesGroupRef.current;
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    if (!showCoordinates) return;

    // Helper to render text billboard texture
    const createTextCanvas = (text: string) => {
      const canvas = document.createElement('canvas');
      canvas.width = 64;
      canvas.height = 64;
      const ctx = canvas.getContext('2d')!;
      ctx.fillStyle = '#94A3B8';
      ctx.font = 'bold 36px Outfit, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, 32, 32);

      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      const mat = new THREE.MeshBasicMaterial({
        map: tex,
        transparent: true,
        depthWrite: false,
      });
      const geo = new THREE.PlaneGeometry(0.45, 0.45);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.rotation.x = -Math.PI / 2;
      return mesh;
    };

    // Rank numbers 1-8 along White's left edge (x = -4.26)
    for (let rank = 0; rank < 8; rank++) {
      const label = createTextCanvas((rank + 1).toString());
      label.position.set(-4.26, 0.01, -(rank - 3.5) * SQUARE_SIZE);
      group.add(label);
    }

    // File letters A-H along White's front edge (z = 4.26)
    for (let file = 0; file < 8; file++) {
      const char = String.fromCharCode(65 + file);
      const label = createTextCanvas(char);
      label.position.set((file - 3.5) * SQUARE_SIZE, 0.01, 4.26);
      group.add(label);
    }
  }, [showCoordinates]);

  // 6. Synchronize 3D Pieces from Authoritative Game State
  useEffect(() => {
    if (!boardRootRef.current) return;
    const boardRoot = boardRootRef.current;
    const pMats = createPieceMaterials(pieceStyle);
    pieceMatsRef.current = pMats;

    const board = game.board();
    const currentPiecesMap = piecesMapRef.current;
    const nextPiecesMap = new Map<string, PieceObject>();

    for (let r = 0; r < 8; r++) {
      for (let f = 0; f < 8; f++) {
        const piece = board[r][f];
        if (!piece) continue;

        const sq = `${String.fromCharCode(97 + f)}${8 - r}` as Square;
        const targetPos = squareToWorld(sq);
        const uniqueId = `${piece.color}-${piece.type}-${sq}`;

        // Check if piece already exists nearby
        let existingPiece: PieceObject | null = null;
        for (const [key, pObj] of currentPiecesMap.entries()) {
          if (pObj.type === piece.type && pObj.color === piece.color && !nextPiecesMap.has(key)) {
            // If at same square or moving here
            if (pObj.square === sq) {
              existingPiece = pObj;
              break;
            }
          }
        }

        // If not at exact square, check for piece moved from another square
        if (!existingPiece) {
          for (const [key, pObj] of currentPiecesMap.entries()) {
            if (pObj.type === piece.type && pObj.color === piece.color && !nextPiecesMap.has(key)) {
              existingPiece = pObj;
              break;
            }
          }
        }

        if (existingPiece) {
          existingPiece.square = sq;
          if (
            Math.abs(existingPiece.currentX - targetPos.x) > 0.01 ||
            Math.abs(existingPiece.currentZ - targetPos.z) > 0.01
          ) {
            existingPiece.targetX = targetPos.x;
            existingPiece.targetZ = targetPos.z;
            existingPiece.isMoving = true;
            existingPiece.moveProgress = 0;
          } else {
            existingPiece.group.position.set(targetPos.x, 0, targetPos.z);
          }
          nextPiecesMap.set(uniqueId, existingPiece);
        } else {
          // Spawn new piece
          const pieceGroup = createPieceMesh(piece.type, piece.color, pMats);
          pieceGroup.position.set(targetPos.x, 0, targetPos.z);
          boardRoot.add(pieceGroup);

          const newObj: PieceObject = {
            id: uniqueId,
            square: sq,
            type: piece.type,
            color: piece.color,
            group: pieceGroup,
            currentX: targetPos.x,
            currentZ: targetPos.z,
            targetX: targetPos.x,
            targetZ: targetPos.z,
            isMoving: false,
            moveProgress: 1,
          };
          nextPiecesMap.set(uniqueId, newObj);
        }
      }
    }

    // Capture animation for despawned pieces
    currentPiecesMap.forEach((pObj, key) => {
      if (!nextPiecesMap.has(key)) {
        fadingPiecesRef.current.push({
          group: pObj.group,
          progress: 0,
        });
      }
    });

    piecesMapRef.current = nextPiecesMap;
  }, [game, pieceStyle]);

  // 7. Update Board Highlights (Clean cyan, red, gold without yellow lines or Z-fighting)
  useEffect(() => {
    if (!highlightsGroupRef.current) return;
    const group = highlightsGroupRef.current;
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    // A. Last move indicators (Soft cyan/blue fill)
    if (lastMove) {
      [lastMove.from, lastMove.to].forEach((sqStr) => {
        const sq = sqStr as Square;
        const pos = squareToWorld(sq);
        const geo = new THREE.PlaneGeometry(0.98, 0.98);
        const mat = new THREE.MeshBasicMaterial({
          color: 0x0284C7,
          transparent: true,
          opacity: 0.32,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -1,
        });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.rotation.x = -Math.PI / 2;
        mesh.position.set(pos.x, 0.008, pos.z);
        group.add(mesh);
      });
    }

    // B. Selected square highlight (Electric cyan glow ring)
    if (selectedSquare) {
      const pos = squareToWorld(selectedSquare);
      const ringGeo = new THREE.RingGeometry(0.32, 0.46, 32);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x00D2FF,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(pos.x, 0.014, pos.z);
      group.add(ring);

      const fillGeo = new THREE.PlaneGeometry(0.98, 0.98);
      const fillMat = new THREE.MeshBasicMaterial({
        color: 0x00D2FF,
        transparent: true,
        opacity: 0.25,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
      });
      const fill = new THREE.Mesh(fillGeo, fillMat);
      fill.rotation.x = -Math.PI / 2;
      fill.position.set(pos.x, 0.012, pos.z);
      group.add(fill);
    }

    // C. Legal moves indicators
    legalMoves.forEach((toSquareStr) => {
      const toSq = toSquareStr as Square;
      const pos = squareToWorld(toSq);
      const isCapture = !!game.get(toSq);

      if (isCapture) {
        const ringGeo = new THREE.RingGeometry(0.38, 0.46, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0xEF4444,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.88,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -2,
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(pos.x, 0.015, pos.z);
        group.add(ring);
      } else {
        const dotGeo = new THREE.CircleGeometry(0.16, 24);
        const dotMat = new THREE.MeshBasicMaterial({
          color: 0x38BDF8,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.85,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -2,
        });
        const dot = new THREE.Mesh(dotGeo, dotMat);
        dot.rotation.x = -Math.PI / 2;
        dot.position.set(pos.x, 0.015, pos.z);
        group.add(dot);
      }
    });

    // D. Checked King Danger Aura
    if (game.inCheck()) {
      const turn = game.turn();
      const board = game.board();
      for (let r = 0; r < 8; r++) {
        for (let f = 0; f < 8; f++) {
          const piece = board[r][f];
          if (piece && piece.type === 'k' && piece.color === turn) {
            const kingSq = `${String.fromCharCode(97 + f)}${8 - r}` as Square;
            const pos = squareToWorld(kingSq);
            const dangerGeo = new THREE.CircleGeometry(0.48, 32);
            const dangerMat = new THREE.MeshBasicMaterial({
              color: 0xDC2626,
              side: THREE.DoubleSide,
              transparent: true,
              opacity: 0.7,
              depthWrite: false,
              polygonOffset: true,
              polygonOffsetFactor: -1,
            });
            const danger = new THREE.Mesh(dangerGeo, dangerMat);
            danger.rotation.x = -Math.PI / 2;
            danger.position.set(pos.x, 0.01, pos.z);
            group.add(danger);
          }
        }
      }
    }
  }, [selectedSquare, legalMoves, lastMove, game]);

  // 8. 3D Hint Arrow Overlay
  useEffect(() => {
    if (!hintArrowGroupRef.current) return;
    const group = hintArrowGroupRef.current;
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    if (!hintMove) return;

    const fromPos = squareToWorld(hintMove.from as Square);
    const toPos = squareToWorld(hintMove.to as Square);

    const dir = new THREE.Vector3(toPos.x - fromPos.x, 0, toPos.z - fromPos.z);
    const length = dir.length();
    dir.normalize();

    const cylinderGeo = new THREE.CylinderGeometry(0.06, 0.06, length - 0.4, 16);
    const arrowMat = new THREE.MeshStandardMaterial({
      color: 0x00D2FF,
      emissive: 0x0088CC,
      roughness: 0.2,
      metalness: 0.8,
    });
    const cylinder = new THREE.Mesh(cylinderGeo, arrowMat);

    const midX = (fromPos.x + toPos.x) / 2;
    const midZ = (fromPos.z + toPos.z) / 2;
    cylinder.position.set(midX, 0.25, midZ);

    const axis = new THREE.Vector3(0, 1, 0);
    cylinder.quaternion.setFromUnitVectors(axis, dir);
    cylinder.rotateX(Math.PI / 2);
    group.add(cylinder);

    const coneGeo = new THREE.ConeGeometry(0.18, 0.4, 16);
    const cone = new THREE.Mesh(coneGeo, arrowMat);
    cone.position.set(toPos.x, 0.25, toPos.z);
    cone.quaternion.setFromUnitVectors(axis, dir);
    cone.rotateX(Math.PI / 2);
    group.add(cone);
  }, [hintMove]);

  // 9. Input & Drag-and-Drop Handling with Immediate Piece Snapback Protection
  const handlePointerDown = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (!interactive || !containerRef.current || !cameraRef.current || !boardTilesGroupRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      mouse.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      pointerStartPosRef.current = { x: event.clientX, y: event.clientY };
      hasDraggedFarRef.current = false;

      raycaster.current.setFromCamera(mouse.current, cameraRef.current);
      const intersects = raycaster.current.intersectObjects(boardTilesGroupRef.current.children, false);

      if (intersects.length > 0) {
        const hitSquare = intersects[0].object.userData?.square as Square | undefined;
        if (hitSquare) {
          startHitSquareRef.current = hitSquare;
          const pieceOnSquare = game.get(hitSquare);

          // If clicking a piece of current player's turn, initiate drag
          if (pieceOnSquare && pieceOnSquare.color === game.turn()) {
            let foundP: PieceObject | null = null;
            for (const p of piecesMapRef.current.values()) {
              if (p.square === hitSquare) {
                foundP = p;
                break;
              }
            }

            if (foundP) {
              isDraggingRef.current = true;
              draggedPieceRef.current = foundP;
              foundP.group.position.y = 0.45;
              if (controlsRef.current) {
                controlsRef.current.enabled = false;
              }
            }
          }
        }
      }
    },
    [interactive, game]
  );

  const handlePointerMove = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (!isDraggingRef.current || !draggedPieceRef.current || !cameraRef.current || !containerRef.current || !boardRootRef.current) return;

      const dx = Math.abs(event.clientX - pointerStartPosRef.current.x);
      const dy = Math.abs(event.clientY - pointerStartPosRef.current.y);
      if (dx > 6 || dy > 6) {
        hasDraggedFarRef.current = true;
      }

      const rect = containerRef.current.getBoundingClientRect();
      mouse.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.current.setFromCamera(mouse.current, cameraRef.current);
      const intersectionPoint = new THREE.Vector3();
      if (raycaster.current.ray.intersectPlane(dragPlaneRef.current, intersectionPoint)) {
        // Convert world coordinate to boardRoot local coordinates
        const localPoint = boardRootRef.current.worldToLocal(intersectionPoint.clone());
        draggedPieceRef.current.group.position.x = localPoint.x;
        draggedPieceRef.current.group.position.z = localPoint.z;
      }
    },
    []
  );

  const handlePointerUp = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (controlsRef.current) {
        controlsRef.current.enabled = true;
      }

      const pObj = draggedPieceRef.current;
      const wasDraggingFar = hasDraggedFarRef.current;
      const startSquare = startHitSquareRef.current;

      // Always reset drag state
      isDraggingRef.current = false;
      draggedPieceRef.current = null;
      hasDraggedFarRef.current = false;
      startHitSquareRef.current = null;

      // CRITICAL FIX: ALWAYS snap the piece mesh back to its canonical square first!
      if (pObj) {
        pObj.group.position.set(pObj.currentX, 0, pObj.currentZ);
      }

      if (!containerRef.current || !cameraRef.current || !boardTilesGroupRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      mouse.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.current.setFromCamera(mouse.current, cameraRef.current);
      const intersects = raycaster.current.intersectObjects(boardTilesGroupRef.current.children, false);

      if (intersects.length > 0) {
        const destSquare = intersects[0].object.userData?.square as Square | undefined;

        if (destSquare) {
          // If the player dragged piece to another square
          if (wasDraggingFar && pObj && destSquare !== pObj.square) {
            if (onMoveAttempt) {
              onMoveAttempt(pObj.square, destSquare);
            } else {
              onSquareClick(destSquare);
            }
            return;
          }

          // Otherwise, it was a tap / click on destSquare
          onSquareClick(destSquare);
        }
      } else if (!wasDraggingFar && startSquare) {
        onSquareClick(startSquare);
      }
    },
    [onSquareClick, onMoveAttempt]
  );

  const handlePointerCancel = useCallback(() => {
    if (controlsRef.current) {
      controlsRef.current.enabled = true;
    }
    if (draggedPieceRef.current) {
      draggedPieceRef.current.group.position.set(
        draggedPieceRef.current.currentX,
        0,
        draggedPieceRef.current.currentZ
      );
    }
    isDraggingRef.current = false;
    draggedPieceRef.current = null;
    hasDraggedFarRef.current = false;
    startHitSquareRef.current = null;
  }, []);

  return (
    <div
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      onPointerLeave={handlePointerCancel}
      className="relative w-full h-full cursor-pointer touch-none select-none overflow-hidden"
    />
  );
};
