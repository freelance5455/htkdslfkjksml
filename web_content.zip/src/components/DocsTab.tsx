import type { ReactNode } from "react";
import { Card, Chip, SectionTitle } from "./ui";
import { fmtBytes } from "../lib/modelManager";

function Sec({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <SectionTitle>{title}</SectionTitle>
      <Card className="space-y-2.5 p-4 text-xs leading-relaxed text-mist-300">{children}</Card>
    </div>
  );
}

function Row({ k, children }: { k: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-[110px_1fr] gap-2 border-b border-ink-800 pb-2 last:border-0 last:pb-0">
      <span className="font-semibold text-mist-500">{k}</span>
      <span className="text-mist-300">{children}</span>
    </div>
  );
}

const CHECKLIST = [
  "Select a local video on the phone (Player → Choose video).",
  "Play it — verify video + audio render (codec must be supported by the browser or the installed FFmpeg core).",
  "Download the speech model (Models → Whisper Tiny/Base) — progress bar shows real bytes.",
  "Download the translation model (Models → M2M100 or NLLB-600M).",
  "Process an English video (Generate → English → Generate). Watch all four stages report real counts.",
  "Confirm the result is Urdu script (اردو) — not transliteration.",
  "Repeat with one more source language (e.g., Arabic or Hindi) to test a second direction.",
  "Verify timestamp sync: play the video and check cues appear when the matching words are spoken.",
  "Verify RTL: Urdu cues render right-to-left in Nastaliq; punctuation (۔ ! ?) in the correct place.",
  "Export the SRT and VTT files; open them in any subtitle editor to verify format.",
  "Close the app entirely and reopen it.",
  "Switch the phone to airplane mode.",
  "Open the same video again — playback must work (stored file in Library, or re-select the file).",
  "Saved Urdu subtitles must auto-load with zero network use.",
  "Generate a NEW video offline: all stages must complete (models run from cache).",
  "Tests tab → run ASR + MT offline tests: both must report “0 external network requests”.",
  "Long video (≥ 30 min): note how slow it is and whether memory limits are hit; the UI warns above 45 min.",
  "Tests tab → “Model files persist”: cached files must still be listed after the restart.",
];

export default function DocsTab() {
  return (
    <div className="space-y-5">
      <Sec title="What this app is">
        <p>
          A mobile-first, offline-first web app: it plays local video files and generates{" "}
          <b className="text-mist-100">Urdu subtitles from the spoken audio</b> entirely on-device.
          The pipeline is:
        </p>
        <div className="rounded-lg bg-ink-850 p-3 font-mono text-[11px] leading-relaxed text-jade-300">
          video file → mono 16 kHz audio → Whisper (30 s windows, word timestamps) → readable
          segments → M2M100 / NLLB (→ urd_Arab) → synced Urdu SRT/VTT → library + player
        </div>
        <p>
          Nothing is sent to any cloud API. The only network traffic is the one-time download of
          models from <b>huggingface.co</b> (official checkpoints) and the FFmpeg core from the
          official npm CDN. After setup, all inference runs locally; the Tests tab can prove it.
        </p>
      </Sec>

      <Sec title="First-time setup (online)">
        <ol className="list-decimal space-y-1.5 pl-5">
          <li>Open <b>Models</b>. Install a Whisper model — <b>Tiny (~{fmtBytes(68 * 1048576)})</b> for weak phones, <b>Base (~{fmtBytes(135 * 1048576)})</b> recommended.</li>
          <li>Install the <b>Urdu translation model</b> — M2M100 418M (~{fmtBytes(940 * 1048576)}) is the smallest real option; NLLB-600M (~1 GB) is higher quality and non-commercial.</li>
          <li>Optionally install the <b>FFmpeg media engine</b> (~{fmtBytes(33 * 1048576)}) for MKV/MOV/Opus files. MP4/MP3/WAV/OGG/FLAC usually work without it.</li>
          <li>Pick a video in <b>Player</b>, then <b>Generate</b>: choose the spoken language, start. Cues appear in the player and are saved to the Library.</li>
        </ol>
        <p>
          From then on, everything works <b>offline</b>: models live in browser Cache Storage,
          subtitle sets and (optionally) video files in IndexedDB.
        </p>
      </Sec>

      <Sec title="Verified models & sources">
        <Row k="Whisper Tiny">
          <a className="text-jade-300 underline" href="https://huggingface.co/Xenova/whisper-tiny" target="_blank" rel="noreferrer">Xenova/whisper-tiny</a> · int8 ≈ 68 MB (encoder 8.6 + decoder 30.5 + decoder-with-past 29.2 MB) · CC-BY-4.0 · runs on 2 GB+ RAM
        </Row>
        <Row k="Whisper Base">
          <a className="text-jade-300 underline" href="https://huggingface.co/Xenova/whisper-base" target="_blank" rel="noreferrer">Xenova/whisper-base</a> · int8 ≈ 135 MB · CC-BY-4.0 · recommended
        </Row>
        <Row k="Whisper Small">
          <a className="text-jade-300 underline" href="https://huggingface.co/Xenova/whisper-small" target="_blank" rel="noreferrer">Xenova/whisper-small</a> · int8 ≈ 280 MB · CC-BY-4.0 · 4 GB+ RAM
        </Row>
        <Row k="M2M100">
          <a className="text-jade-300 underline" href="https://huggingface.co/Xenova/m2m100_418M" target="_blank" rel="noreferrer">Xenova/m2m100_418M</a> · int8 ≈ 940 MB · MIT · 41 languages → Urdu · 6 GB RAM recommended
        </Row>
        <Row k="NLLB-600M">
          <a className="text-jade-300 underline" href="https://huggingface.co/Xenova/nllb-200-distilled-600M" target="_blank" rel="noreferrer">Xenova/nllb-200-distilled-600M</a> · int8 ≈ 1 GB · <Chip tone="rust">CC-BY-NC non-commercial</Chip> · 8 GB RAM recommended
        </Row>
        <Row k="FFmpeg core">
          <a className="text-jade-300 underline" href="https://www.npmjs.com/package/@ffmpeg/core" target="_blank" rel="noreferrer">@ffmpeg/core 0.12.6 (unpkg)</a> · 33 MB · LGPL · single-threaded WASM, no SharedArrayBuffer needed
        </Row>
        <Row k="Runtime">
          <a className="text-jade-300 underline" href="https://github.com/huggingface/transformers.js" target="_blank" rel="noreferrer">@huggingface/transformers v3 (transformers.js)</a> + onnxruntime-web (bundled) — Whisper does <b>transcription</b> only; it does not translate. Urdu output always comes from the dedicated MT model.
        </Row>
        <p className="text-[11px] text-mist-500">
          All checkpoints verified to exist on huggingface.co with ONNX int8 weights at build time
          (API file listings). No small English→Urdu ONNX model exists yet — verified by searching
          the Hub; the APK path below uses the ~10 MB ctranslate2 en-ur checkpoint instead.
        </p>
      </Sec>

      <Sec title="Model installation & storage">
        <p>
          “Download & install” fetches each file with byte-level progress from the official
          repository and then <b>loads the graph into the ONNX runtime</b> — a successful load is
          the integrity check. Files persist in Cache Storage; retries skip files already cached
          (file-level resume). “Remove” deletes the cached files and frees storage. The Models tab
          shows real cached byte counts, device RAM, and warns when a model is likely too large for
          the device or storage is low.
        </p>
        <p>
          Browser storage is not guaranteed permanent: clearing site data removes models
          (re-downloadable) and library entries (keep SRT exports as backup).
        </p>
      </Sec>

      <Sec title="Testing offline (18-point acceptance checklist)">
        <ol className="list-decimal space-y-1 pl-5">
          {CHECKLIST.map((c, i) => (
            <li key={i}>{c}</li>
          ))}
        </ol>
        <p>
          The <b>Tests</b> tab runs the technical half automatically (real WASM/cache/audio checks,
          real model inference with a network-request spy, RTL + font check, SRT round-trip,
          cache persistence) and prints actual pass/fail with details — no simulated results.
        </p>
      </Sec>

      <Sec title="Known limitations (honest)">
        <ul className="list-disc space-y-1.5 pl-5">
          <li>
            <b>Urdu MT is heavy.</b> No small ONNX en→Ur model exists; M2M100 int8 (~0.94 GB
            download, ~1.5 GB RAM) is the smallest real option. On phones with &lt; 6 GB RAM it can
            be slow or crash — the app warns in advance and recovers cleanly.
          </li>
          <li>
            <b>Long videos:</b> audio is held as 16 kHz mono PCM (~32 KB/s of video) and processed
            in 30 s windows. 10 min ≈ 19 MB, 1 h ≈ 115 MB — expect memory pressure past ~45–60 min
            on phones.
          </li>
          <li>
            <b>Auto language:</b> Whisper auto-detects the speech, but the MT source tag is then
            inferred from the script (Cyrillic→ru, Devanagari→hi, Arabic→ur/ar by character
            profile, CJK→zh/ja, Bengali→bn, Latin→en). Pick the language explicitly for best MT
            results.
          </li>
          <li>
            <b>Formats/codecs:</b> playback and decoding depend on the browser + FFmpeg core
            (H.264/VP9/Opus well supported; AV1/AC3 varies). Unsupported files produce a clear
            error, not fake success.
          </li>
          <li>
            <b>First run needs internet</b> for model downloads — that part is explicitly online.
            All processing afterwards is local.
          </li>
          <li>Whisper word timestamps can degrade with heavy overlap/noise; segments then fall back to Whisper's own segment boundaries.</li>
          <li>NLLB-600M is <b>non-commercial</b> licensed; M2M100 and Whisper are permissive (MIT / CC-BY-4.0).</li>
        </ul>
      </Sec>

      <Sec title="Preparing the Android APK">
        <ol className="list-decimal space-y-1.5 pl-5">
          <li>
            <b>Quick wrap (works):</b> Capacitor or TWA pointing at this app's build. Models stay
            in the browser cache; the app behaves exactly as in Chrome. Verify every feature
            offline — wrapping does not magically make anything offline.
          </li>
          <li>
            <b>Production (recommended):</b> a native Android app reusing this project's pipeline,
            subtitle and storage modules (they are framework-agnostic TypeScript):
          </li>
        </ol>
        <ul className="list-disc space-y-1.5 pl-10">
          <li>
            ASR: <b>whisper.cpp</b> (tiny/base ggml) — 1–5× faster than WASM, 50–100 MB RAM-class
            models.
          </li>
          <li>
            Urdu MT: <b>ctranslate2</b> with{" "}
            <a className="text-jade-300 underline" href="https://huggingface.co/manancode/opus-mt-en-ur-ctranslate2-android" target="_blank" rel="noreferrer">
              manancode/opus-mt-en-ur-ctranslate2-android
            </a>{" "}
            (int8 OPUS-MT en→Urdu, ≈ 10 MB) — the small Urdu model the web cannot host — or NLLB
            via TFLite/ONNX for other languages.
          </li>
          <li>File access & model storage via native APIs (SAF / app-private dir), persistent by design.</li>
        </ul>
      </Sec>

      <Sec title="Current test status (no fake green)">
        <p>
          Verified during development: all five model checkpoints exist with ONNX int8 weights
          (Hugging Face API file listings, sizes above), ffmpeg core source, pipeline code paths,
          SRT/VTT/ASS parser round-trips, build. <b>Not yet executed:</b> on-device tests — those
          require your phone: run the <b>Tests</b> tab (technical) and the 18-point checklist
          (video-dependent) after first model install, and treat their printed results as the
          acceptance report.
        </p>
        <div className="flex flex-wrap gap-1.5">
          <Chip tone="moss">checkpoints verified</Chip>
          <Chip tone="moss">parsers tested in code</Chip>
          <Chip tone="brass">device tests: run on your phone</Chip>
        </div>
      </Sec>
    </div>
  );
}
