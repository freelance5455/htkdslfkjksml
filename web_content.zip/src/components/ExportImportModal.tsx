import React, { useState, useRef } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import {
  FileText,
  FileSpreadsheet,
  Download,
  Upload,
  RefreshCw,
  X,
  CheckCircle2,
  AlertTriangle,
  Database,
  Printer,
  ShieldCheck,
  ListOrdered
} from 'lucide-react';
import { PrintableLogbook, ReportType } from './PrintableLogbook';

interface ExportImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportImportModal: React.FC<ExportImportModalProps> = ({ isOpen, onClose }) => {
  const {
    downloadCSV,
    importFromCSV,
    downloadJSON,
    importFromJSON,
    resetToDefaultData,
    climbs
  } = useClimbing();

  const [activeTab, setActiveTab] = useState<'export' | 'import' | 'backup'>('export');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [showPrintable, setShowPrintable] = useState(false);
  const [reportTypeToPrint, setReportTypeToPrint] = useState<ReportType>('dossier');
  const [csvTextInput, setCsvTextInput] = useState('');

  const csvFileInputRef = useRef<HTMLInputElement>(null);
  const jsonFileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleOpenReport = (type: ReportType) => {
    setReportTypeToPrint(type);
    setShowPrintable(true);
  };

  const handleFileUploadCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result as string;
      if (text) {
        const result = importFromCSV(text);
        if (result.success) {
          setFeedback({ type: 'success', message: result.message });
        } else {
          setFeedback({ type: 'error', message: result.message });
        }
      }
    };
    reader.onerror = () => {
      setFeedback({ type: 'error', message: 'Failed to read CSV file from disk.' });
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleManualCSVImport = () => {
    if (!csvTextInput.trim()) {
      setFeedback({ type: 'error', message: 'Please paste CSV content into the text area.' });
      return;
    }
    const result = importFromCSV(csvTextInput);
    if (result.success) {
      setFeedback({ type: 'success', message: result.message });
      setCsvTextInput('');
    } else {
      setFeedback({ type: 'error', message: result.message });
    }
  };

  const handleFileUploadJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result as string;
      if (text) {
        const result = importFromJSON(text);
        if (result.success) {
          setFeedback({ type: 'success', message: result.message });
        } else {
          setFeedback({ type: 'error', message: result.message });
        }
      }
    };
    reader.onerror = () => {
      setFeedback({ type: 'error', message: 'Failed to read JSON backup file.' });
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleReset = () => {
    if (confirm('Reset logbook data to blank default state?')) {
      resetToDefaultData();
      setFeedback({ type: 'success', message: 'Logbook reset to clean blank state.' });
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
        <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full max-w-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
          {/* Header */}
          <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-orange-600 dark:text-orange-400" />
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">PDF Reports & Logbook Backup</h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Feedback alert */}
          {feedback && (
            <div
              className={`px-4 sm:px-6 py-2.5 border-b text-xs font-medium flex items-center justify-between ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                  : 'bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-300 border-red-200 dark:border-red-800'
              }`}
            >
              <div className="flex items-center gap-2">
                {feedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                )}
                <span>{feedback.message}</span>
              </div>
              <button
                type="button"
                onClick={() => setFeedback(null)}
                className="text-xs underline cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Tabs */}
          <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 px-4 sm:px-6 pt-2.5 gap-2 overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => setActiveTab('export')}
              className={`pb-2 px-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'export'
                  ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              PDF Reports & CSV
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('import')}
              className={`pb-2 px-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'import'
                  ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Import CSV
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('backup')}
              className={`pb-2 px-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'backup'
                  ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              JSON Backup
            </button>
          </div>

          {/* Body Content */}
          <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 text-slate-800 dark:text-slate-200 text-xs">
            {/* EXPORT TAB */}
            {activeTab === 'export' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                    Official PDF Logbook Reports
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {/* Report 1: Dossier */}
                    <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between gap-3">
                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                          <ShieldCheck className="w-4 h-4 text-orange-600 dark:text-orange-400 shrink-0" />
                          <span className="truncate">Candidate Summary Dossier</span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          Progress, active level sign-off, endorsement box
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleOpenReport('dossier')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs shrink-0 cursor-pointer"
                      >
                        PDF
                      </button>
                    </div>

                    {/* Report 2: Climbs Ledger */}
                    <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between gap-3">
                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                          <ListOrdered className="w-4 h-4 text-orange-600 dark:text-orange-400 shrink-0" />
                          <span className="truncate">Climbs Log Ledger</span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          All {climbs.length} ascents, grades, angles & notes
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleOpenReport('climbs')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs shrink-0 cursor-pointer"
                      >
                        PDF
                      </button>
                    </div>

                    {/* Report 3: Checklist */}
                    <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between gap-3">
                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                          <FileText className="w-4 h-4 text-orange-600 dark:text-orange-400 shrink-0" />
                          <span className="truncate">NICAS Syllabus Checklist</span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          All 5 levels safety, equipment & technique matrix
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleOpenReport('checklist')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs shrink-0 cursor-pointer"
                      >
                        PDF
                      </button>
                    </div>

                    {/* Report 4: Master */}
                    <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between gap-3">
                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                          <Printer className="w-4 h-4 text-orange-600 dark:text-orange-400 shrink-0" />
                          <span className="truncate">All-In-One Master Portfolio</span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          Complete multi-page official candidate record
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleOpenReport('master')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs shrink-0 cursor-pointer"
                      >
                        PDF
                      </button>
                    </div>
                  </div>
                </div>

                {/* CSV Download */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                    Spreadsheet CSV Export
                  </h3>
                  <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                        <FileSpreadsheet className="w-4 h-4 text-orange-600 dark:text-orange-400 shrink-0" />
                        <span>Download .CSV Logbook</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        Tabular spreadsheet of all climbs for Excel or Google Sheets
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={downloadCSV}
                      className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 dark:hover:bg-slate-600 rounded-lg shadow-xs shrink-0 cursor-pointer"
                    >
                      Download CSV
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* IMPORT TAB */}
            {activeTab === 'import' && (
              <div className="space-y-4">
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Import climbs from an existing CSV logbook spreadsheet.
                </p>

                {/* File Upload */}
                <div className="p-4 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-center space-y-2">
                  <Upload className="w-6 h-6 text-orange-600 dark:text-orange-400 mx-auto" />
                  <span className="text-xs font-bold text-slate-900 dark:text-white block">Choose a .CSV File</span>
                  <input
                    type="file"
                    ref={csvFileInputRef}
                    accept=".csv,text/csv"
                    onChange={handleFileUploadCSV}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => csvFileInputRef.current?.click()}
                    className="px-3.5 py-1.5 text-xs font-semibold text-orange-700 dark:text-orange-300 bg-white dark:bg-slate-800 border border-orange-200 dark:border-orange-800 hover:bg-orange-50 dark:hover:bg-slate-700 rounded-lg shadow-xs cursor-pointer"
                  >
                    Select File
                  </button>
                </div>

                {/* Paste Area */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Or Paste CSV Plaintext:</label>
                  <textarea
                    rows={3}
                    placeholder="Date,Route Name,Style,Grade,Wall Angle,Outcome,Climbing Centre,Attempts,Notes"
                    value={csvTextInput}
                    onChange={e => setCsvTextInput(e.target.value)}
                    className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={handleManualCSVImport}
                      className="px-3.5 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs cursor-pointer"
                    >
                      Import Text
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* FULL BACKUP TAB */}
            {activeTab === 'backup' && (
              <div className="space-y-4">
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Export or restore a complete JSON backup including candidate profile, clubs, checklist sign-offs, and climbs.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">Download Full JSON Backup</h4>
                    <button
                      type="button"
                      onClick={downloadJSON}
                      className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Save Backup File</span>
                    </button>
                  </div>

                  <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">Restore from JSON File</h4>
                    <input
                      type="file"
                      ref={jsonFileInputRef}
                      accept=".json,application/json"
                      onChange={handleFileUploadJSON}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => jsonFileInputRef.current?.click()}
                      className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg shadow-xs cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Restore Backup</span>
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-xl border border-red-200 dark:border-red-900 bg-red-50/40 dark:bg-red-950/20 flex items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-red-900 dark:text-red-300 block">Clear Logbook Data</span>
                    <p className="text-[10px] text-red-700 dark:text-red-400">Wipes all stored climbs back to blank.</p>
                  </div>
                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-2.5 py-1 text-xs font-semibold text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-900/40 bg-white dark:bg-slate-800 border border-red-300 dark:border-red-800 rounded-lg shrink-0 cursor-pointer"
                  >
                    Reset
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-4 sm:px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 flex items-center justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xs text-xs cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      </div>

      {/* Printable PDF Preview Dialog */}
      <PrintableLogbook
        isOpen={showPrintable}
        onClose={() => setShowPrintable(false)}
        defaultReport={reportTypeToPrint}
      />
    </>
  );
};
