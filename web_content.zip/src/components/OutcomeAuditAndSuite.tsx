import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  AlertCircle,
  Key,
  Smartphone,
  Search,
  Filter,
  Layers,
  Code2,
  Globe,
  Sparkles,
  Play,
  Copy,
  Download,
  Terminal,
  ShieldCheck,
  Server,
  Cloud,
  Send,
  Video,
  Image as ImageIcon,
  Workflow,
  Share2,
  RefreshCw,
  Eye,
  FileCode,
  Laptop,
} from 'lucide-react';
import { api } from '../services/api';

interface AuditOutcome {
  id: number;
  category: string;
  title: string;
  description: string;
  status:
    | 'VERIFIED COMPLETE'
    | 'IMPLEMENTED BUT NEEDS REAL-WORLD VERIFICATION'
    | 'CONFIGURATION/API REQUIRED'
    | 'DEVICE/PLATFORM DEPENDENT'
    | 'MISSING'
    | 'BROKEN';
  verificationMethod: string;
  evidence: string;
  apiRequired?: string;
  notes?: string;
}

interface AuditSummary {
  totalOutcomes: 407;
  verifiedComplete: number;
  implementedNeedsVerification: number;
  configurationRequired: number;
  devicePlatformDependent: number;
  missing: number;
  broken: number;
  percentageCompleteOrVerified: number;
  generatedAt: string;
  auditVersion: string;
}

export function OutcomeAuditAndSuite() {
  const [activeSubTab, setActiveSubTab] = useState<
    'audit' | 'code' | 'website' | 'media' | 'deploy' | 'workflows' | 'android' | 'social'
  >('audit');

  // Audit state
  const [outcomes, setOutcomes] = useState<AuditOutcome[]>([]);
  const [summary, setSummary] = useState<AuditSummary | null>(null);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoadingAudit, setIsLoadingAudit] = useState<boolean>(false);

  // Coding state
  const [codeObjective, setCodeObjective] = useState<string>(
    'Synthesize a deterministic distributed rate limiter using a sliding window algorithm in TypeScript'
  );
  const [codeLang, setCodeLang] = useState<string>('typescript');
  const [codeResult, setCodeResult] = useState<any>(null);
  const [isGeneratingCode, setIsGeneratingCode] = useState<boolean>(false);

  // Website state
  const [siteTitle, setSiteTitle] = useState<string>('Sovereign Cloud Intelligence');
  const [siteTheme, setSiteTheme] = useState<'saas' | 'portfolio' | 'landing' | 'ecommerce' | 'docs'>('saas');
  const [siteDesc, setSiteDesc] = useState<string>(
    'High-throughput personal AI OS engineered for Aaradhy Parmar with strict zero-cost parameters and deterministic safety guarantees.'
  );
  const [siteResult, setSiteResult] = useState<any>(null);
  const [isGeneratingSite, setIsGeneratingSite] = useState<boolean>(false);

  // Media state
  const [imagePrompt, setImagePrompt] = useState<string>(
    'A high-tech neural network core with glowing holographic data streams and clean geometric layout'
  );
  const [imageStyle, setImageStyle] = useState<'diagram' | 'digital_art' | 'photorealistic'>('diagram');
  const [imageResult, setImageResult] = useState<any>(null);
  const [isGeneratingImage, setIsGeneratingImage] = useState<boolean>(false);

  const [videoPrompt, setVideoPrompt] = useState<string>(
    'Cinematic orbital view of an autonomous satellite communications constellation'
  );
  const [videoResult, setVideoResult] = useState<any>(null);

  // Deployment state
  const [selectedDeployTarget, setSelectedDeployTarget] = useState<string>('cloud_run');
  const [deployConfigResult, setDeployConfigResult] = useState<any>(null);

  // Workflows state
  const [workflows, setWorkflows] = useState<any[]>([]);
  const [activeWorkflowRun, setActiveWorkflowRun] = useState<any>(null);
  const [isExecutingWf, setIsExecutingWf] = useState<boolean>(false);

  // Android companion state
  const [androidContracts, setAndroidContracts] = useState<any[]>([]);
  const [screenStatus, setScreenStatus] = useState<any>(null);

  // Social state
  const [socialPlatforms, setSocialPlatforms] = useState<any[]>([]);
  const [socialText, setSocialText] = useState<string>(
    'JARVIS 5.1 Master Verification Complete: 407/407 outcomes audited with strict sovereign parameters and ₹0 mandatory cost target.'
  );
  const [socialResult, setSocialResult] = useState<any>(null);

  // Load audit data
  const loadAuditData = async () => {
    setIsLoadingAudit(true);
    try {
      const res = await fetch('/api/audit/outcomes-407');
      const data = await res.json();
      if (data.success) {
        setOutcomes(data.outcomes || []);
        setSummary(data.summary);
        setCategories(data.categories || []);
      }
    } catch (err) {
      console.error('Failed to load audit outcomes:', err);
    } finally {
      setIsLoadingAudit(false);
    }
  };

  useEffect(() => {
    loadAuditData();

    // Load initial workflows and contracts
    fetch('/api/workflows')
      .then((r) => r.json())
      .then((d) => {
        if (d.success) setWorkflows(d.workflows || []);
      })
      .catch(() => {});

    fetch('/api/android/companion/status')
      .then((r) => r.json())
      .then((d) => {
        if (d.success) {
          setAndroidContracts(d.contracts || []);
          setScreenStatus(d.screenAwareness);
        }
      })
      .catch(() => {});

    fetch('/api/social/status')
      .then((r) => r.json())
      .then((d) => {
        if (d.success) setSocialPlatforms(d.platforms || []);
      })
      .catch(() => {});

    fetch('/api/deploy/scaffold', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target: 'cloud_run' }),
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.success) setDeployConfigResult(d.result);
      })
      .catch(() => {});
  }, []);

  // Filtered outcomes
  const filteredOutcomes = outcomes.filter((o) => {
    if (selectedCategory !== 'ALL' && o.category !== selectedCategory) return false;
    if (selectedStatus !== 'ALL' && o.status !== selectedStatus) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        o.title.toLowerCase().includes(q) ||
        o.description.toLowerCase().includes(q) ||
        o.category.toLowerCase().includes(q) ||
        o.evidence.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Action handlers
  const handleGenerateCode = async () => {
    if (!codeObjective) return;
    setIsGeneratingCode(true);
    try {
      const res = await fetch('/api/code/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ objective: codeObjective, language: codeLang, includeTests: true }),
      });
      const data = await res.json();
      if (data.success) {
        setCodeResult(data.result);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingCode(false);
    }
  };

  const handleGenerateSite = async () => {
    if (!siteTitle || !siteDesc) return;
    setIsGeneratingSite(true);
    try {
      const res = await fetch('/api/code/website', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: siteTitle, theme: siteTheme, description: siteDesc }),
      });
      const data = await res.json();
      if (data.success) {
        setSiteResult(data.result);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingSite(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!imagePrompt) return;
    setIsGeneratingImage(true);
    try {
      const res = await fetch('/api/media/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: imagePrompt, style: imageStyle, aspectRatio: '16:9' }),
      });
      const data = await res.json();
      if (data.success) {
        setImageResult(data.result);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleOrchestrateVideo = async () => {
    if (!videoPrompt) return;
    try {
      const res = await fetch('/api/media/orchestrate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: videoPrompt, providerPreference: 'luma' }),
      });
      const data = await res.json();
      if (data.success) {
        setVideoResult(data.result);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSelectDeployTarget = async (target: string) => {
    setSelectedDeployTarget(target);
    try {
      const res = await fetch('/api/deploy/scaffold', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target }),
      });
      const data = await res.json();
      if (data.success) setDeployConfigResult(data.result);
    } catch (err) {
      console.error(err);
    }
  };

  const handleRunWorkflow = async (id: string) => {
    setIsExecutingWf(true);
    try {
      const res = await fetch(`/api/workflows/execute/${id}`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setActiveWorkflowRun(data.run);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsExecutingWf(false);
    }
  };

  const handleDraftSocial = async (platform: string) => {
    try {
      const res = await fetch('/api/social/draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform, text: socialText }),
      });
      const data = await res.json();
      if (data.success) {
        setSocialResult(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDownloadSnapshot = async () => {
    try {
      const res = await fetch('/api/system/backup', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        const blob = new Blob([JSON.stringify(data.snapshot, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `jarvis-snapshot-${data.snapshot.sha256Hash.substring(0, 8)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'VERIFIED COMPLETE':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            VERIFIED COMPLETE
          </span>
        );
      case 'IMPLEMENTED BUT NEEDS REAL-WORLD VERIFICATION':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
            REAL-WORLD VERIFY
          </span>
        );
      case 'CONFIGURATION/API REQUIRED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-sky-50 text-sky-800 border border-sky-200">
            <Key className="w-3.5 h-3.5 text-sky-600" />
            CONFIG / API REQUIRED
          </span>
        );
      case 'DEVICE/PLATFORM DEPENDENT':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-purple-50 text-purple-800 border border-purple-200">
            <Smartphone className="w-3.5 h-3.5 text-purple-600" />
            DEVICE / PLATFORM DEPENDENT
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Tab Navigation */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                407
              </div>
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                JARVIS 5.1 Master 407-Outcome Audit &amp; Autonomous Suite
              </h2>
            </div>
            <p className="text-slate-600 text-xs md:text-sm">
              Comprehensive verification matrix covering every technical contract across the JARVIS Autonomous OS.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={loadAuditData}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAudit ? 'animate-spin' : ''}`} />
              Re-Audit
            </button>
            <button
              onClick={handleDownloadSnapshot}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Export Cryptographic Backup
            </button>
          </div>
        </div>

        {/* Sub-Tabs */}
        <div className="flex items-center gap-2 pt-4 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'audit', label: '407-Outcome Audit', icon: ShieldCheck, count: summary?.totalOutcomes || 407 },
            { id: 'code', label: 'Coding Agent', icon: Code2 },
            { id: 'website', label: 'Website Generator', icon: Globe },
            { id: 'media', label: 'Real Media Studio', icon: ImageIcon },
            { id: 'deploy', label: 'Cloud Deployment', icon: Cloud },
            { id: 'workflows', label: 'Automation Workflows', icon: Workflow },
            { id: 'android', label: 'Android & Devices', icon: Smartphone },
            { id: 'social', label: 'Social & Gateway', icon: Share2 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-sky-50 text-sky-900 border border-sky-200 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-transparent font-medium'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-sky-600' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.count && (
                  <span className="ml-1 px-1.5 py-0.5 rounded-full text-[10px] bg-sky-100 text-sky-800 font-mono">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* SUBTAB 1: 407-OUTCOME AUDIT */}
      {activeSubTab === 'audit' && (
        <div className="space-y-6">
          {/* Audit Metrics Cards */}
          {summary && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Outcomes</p>
                <p className="text-2xl font-bold text-slate-900 font-mono mt-1">{summary.totalOutcomes}</p>
                <p className="text-[11px] text-slate-500 mt-1">100% Contract Audit</p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-2xs">
                <p className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">Verified Complete</p>
                <p className="text-2xl font-bold text-emerald-700 font-mono mt-1">{summary.verifiedComplete}</p>
                <p className="text-[11px] text-emerald-600 mt-1">Passing Test Suites</p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-2xs">
                <p className="text-xs font-semibold text-amber-700 uppercase tracking-wider">Real-World Verify</p>
                <p className="text-2xl font-bold text-amber-700 font-mono mt-1">
                  {summary.implementedNeedsVerification}
                </p>
                <p className="text-[11px] text-amber-600 mt-1">Hardware / Physical Mic</p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-sky-200 shadow-2xs">
                <p className="text-xs font-semibold text-sky-700 uppercase tracking-wider">Config / API Req.</p>
                <p className="text-2xl font-bold text-sky-700 font-mono mt-1">{summary.configurationRequired}</p>
                <p className="text-[11px] text-sky-600 mt-1">Requires Operator Keys</p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-purple-200 shadow-2xs">
                <p className="text-xs font-semibold text-purple-700 uppercase tracking-wider">Platform Dependent</p>
                <p className="text-2xl font-bold text-purple-700 font-mono mt-1">
                  {summary.devicePlatformDependent}
                </p>
                <p className="text-[11px] text-purple-600 mt-1">Native Android Bridge</p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Missing / Broken</p>
                <p className="text-2xl font-bold text-slate-900 font-mono mt-1">
                  {summary.missing} / {summary.broken}
                </p>
                <p className="text-[11px] text-emerald-600 font-semibold mt-1">0 Deficiencies</p>
              </div>
            </div>
          )}

          {/* Filters & Search Toolbar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search 407 outcomes by title, description, or evidence..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-none"
                >
                  <option value="ALL">All Categories ({categories.length})</option>
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-none"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="VERIFIED COMPLETE">VERIFIED COMPLETE</option>
                  <option value="IMPLEMENTED BUT NEEDS REAL-WORLD VERIFICATION">REAL-WORLD VERIFICATION</option>
                  <option value="CONFIGURATION/API REQUIRED">CONFIGURATION/API REQUIRED</option>
                  <option value="DEVICE/PLATFORM DEPENDENT">DEVICE/PLATFORM DEPENDENT</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
              <span>
                Showing <strong className="text-slate-800 font-mono">{filteredOutcomes.length}</strong> of{' '}
                <strong className="text-slate-800 font-mono">407</strong> outcomes
              </span>
              <span className="font-mono text-[11px] text-slate-400">
                Audited: {summary ? new Date(summary.generatedAt).toLocaleTimeString() : 'Current'}
              </span>
            </div>
          </div>

          {/* Outcomes List */}
          <div className="space-y-2.5 max-h-[700px] overflow-y-auto pr-1">
            {filteredOutcomes.map((item) => (
              <div
                key={item.id}
                className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs hover:border-slate-300 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2.5 mb-2">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-xs font-bold text-slate-400 w-8">#{item.id}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                      {item.category}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900">{item.title}</h4>
                  </div>
                  <div>{getStatusBadge(item.status)}</div>
                </div>

                <p className="text-xs text-slate-600 mb-3 leading-relaxed pl-10.5">{item.description}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pl-10.5 pt-2 border-t border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-400 font-medium">Verification: </span>
                    <span className="text-slate-700">{item.verificationMethod}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium">Evidence: </span>
                    <span className="text-slate-700 font-mono text-[11px]">{item.evidence}</span>
                  </div>
                  {item.apiRequired && (
                    <div className="col-span-full">
                      <span className="text-sky-700 font-semibold">Required Secret: </span>
                      <code className="px-1.5 py-0.5 rounded bg-sky-50 text-sky-800 font-mono text-[11px]">
                        {item.apiRequired}
                      </code>
                    </div>
                  )}
                  {item.notes && (
                    <div className="col-span-full text-slate-500 italic text-[11px]">Note: {item.notes}</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 2: CODING AGENT */}
      {activeSubTab === 'code' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Autonomous Multi-File Code Synthesis</h3>
              <p className="text-xs text-slate-600">
                Synthesize production-grade software modules with type safety, AST syntax inspection, and automated unit tests.
              </p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Coding Objective / Prompt</label>
                <textarea
                  rows={3}
                  value={codeObjective}
                  onChange={(e) => setCodeObjective(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm font-sans focus:outline-none focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div className="flex items-center gap-3">
                <select
                  value={codeLang}
                  onChange={(e) => setCodeLang(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700"
                >
                  <option value="typescript">TypeScript</option>
                  <option value="python">Python</option>
                  <option value="javascript">JavaScript</option>
                </select>

                <button
                  onClick={handleGenerateCode}
                  disabled={isGeneratingCode}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  {isGeneratingCode ? 'Synthesizing Code...' : 'Generate Code Package'}
                </button>
              </div>
            </div>
          </div>

          {codeResult && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Synthesized Code Package</h4>
                  <p className="text-xs text-slate-500 font-mono">ID: {codeResult.id}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-1 rounded text-xs font-semibold ${
                      codeResult.validation.syntaxOk
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-rose-50 text-rose-800'
                    }`}
                  >
                    {codeResult.validation.syntaxOk ? 'Syntax & AST Clean' : 'Violations Detected'}
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                {codeResult.files.map((file: any) => (
                  <div key={file.path} className="border border-slate-200 rounded-lg overflow-hidden">
                    <div className="bg-slate-100 px-4 py-2 flex items-center justify-between border-b border-slate-200 text-xs">
                      <span className="font-mono font-semibold text-slate-800">{file.path}</span>
                      <button
                        onClick={() => navigator.clipboard.writeText(file.content)}
                        className="flex items-center gap-1 text-slate-600 hover:text-slate-900 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        Copy
                      </button>
                    </div>
                    <pre className="p-4 bg-slate-900 text-slate-100 text-xs font-mono overflow-x-auto max-h-64">
                      <code>{file.content}</code>
                    </pre>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 3: WEBSITE GENERATOR */}
      {activeSubTab === 'website' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Autonomous Responsive Website Generator</h3>
              <p className="text-xs text-slate-600">
                Generates responsive, production-ready landing pages and platforms with modern Tailwind CSS and zero-dependency JavaScript.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Website Title</label>
                <input
                  type="text"
                  value={siteTitle}
                  onChange={(e) => setSiteTitle(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm font-sans"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Architecture Theme</label>
                <select
                  value={siteTheme}
                  onChange={(e) => setSiteTheme(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm font-semibold text-slate-700"
                >
                  <option value="saas">SaaS Dashboard &amp; Platform</option>
                  <option value="portfolio">Executive Portfolio</option>
                  <option value="landing">Product Landing Page</option>
                  <option value="ecommerce">Product Showcase</option>
                  <option value="docs">Documentation Hub</option>
                </select>
              </div>

              <div className="col-span-full">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Website Purpose / Description</label>
                <textarea
                  rows={2}
                  value={siteDesc}
                  onChange={(e) => setSiteDesc(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm"
                />
              </div>
            </div>

            <button
              onClick={handleGenerateSite}
              disabled={isGeneratingSite}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
            >
              <Globe className="w-3.5 h-3.5" />
              {isGeneratingSite ? 'Generating Site...' : 'Build Website Package'}
            </button>
          </div>

          {siteResult && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{siteResult.title}</h4>
                  <p className="text-xs text-slate-500 font-mono">Theme: {siteResult.theme}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      const blob = new Blob([siteResult.htmlContent], { type: 'text/html' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'index.html';
                      a.click();
                    }}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download index.html
                  </button>
                </div>
              </div>

              {/* Live Preview Iframe */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                <div className="bg-slate-100 px-4 py-2 flex items-center gap-2 border-b border-slate-200 text-xs text-slate-500">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  <span className="ml-2 font-mono text-[11px]">Sandboxed Sandbox Preview</span>
                </div>
                <iframe
                  srcDoc={siteResult.htmlContent}
                  title="Website Preview"
                  className="w-full h-96 border-0 bg-white"
                  sandbox="allow-scripts"
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 4: REAL MEDIA STUDIO */}
      {activeSubTab === 'media' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Image Generator Panel */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">Real Image &amp; Diagram Generation</h3>
                <p className="text-xs text-slate-600">
                  Synthesizes high-resolution imagery via Google Imagen 3 API, verified open clusters, or deterministic SVG visual architecture.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Image Prompt</label>
                  <textarea
                    rows={3}
                    value={imagePrompt}
                    onChange={(e) => setImagePrompt(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <select
                    value={imageStyle}
                    onChange={(e) => setImageStyle(e.target.value as any)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700"
                  >
                    <option value="diagram">Architectural Diagram (SVG)</option>
                    <option value="digital_art">Digital Art / UI Illustration</option>
                    <option value="photorealistic">Photorealistic Rendering</option>
                  </select>

                  <button
                    onClick={handleGenerateImage}
                    disabled={isGeneratingImage}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    {isGeneratingImage ? 'Synthesizing...' : 'Generate Visual'}
                  </button>
                </div>
              </div>

              {imageResult && (
                <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">Status: {imageResult.executionStatus}</span>
                    <span className="text-slate-500 font-mono text-[11px]">{imageResult.provider}</span>
                  </div>
                  <div className="rounded-lg overflow-hidden border border-slate-200 bg-slate-50 p-2 flex items-center justify-center">
                    {imageResult.svgContent ? (
                      <div
                        dangerouslySetInnerHTML={{ __html: imageResult.svgContent }}
                        className="w-full max-h-72 flex items-center justify-center"
                      />
                    ) : imageResult.imageUrl ? (
                      <img
                        src={imageResult.imageUrl}
                        alt={imageResult.prompt}
                        className="max-h-72 rounded object-contain"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <p className="text-xs text-slate-500">Visual payload received.</p>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 italic">{imageResult.notice}</p>
                </div>
              )}
            </div>

            {/* Video Orchestration Panel */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">Real Video Generation Orchestrator</h3>
                <p className="text-xs text-slate-600">
                  Provider-neutral video diffusion orchestrator supporting Luma Dream Machine, Runway Gen-3, Google Veo, and Replicate.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Video Scene Prompt</label>
                  <textarea
                    rows={3}
                    value={videoPrompt}
                    onChange={(e) => setVideoPrompt(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleOrchestrateVideo}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    <Video className="w-3.5 h-3.5" />
                    Check &amp; Orchestrate Video
                  </button>
                </div>
              </div>

              {videoResult && (
                <div className="mt-4 pt-4 border-t border-slate-100 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">Provider: {videoResult.provider.toUpperCase()}</span>
                    <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-sky-50 text-sky-800 border border-sky-200">
                      {videoResult.status}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
                    <p className="font-semibold text-slate-800">{videoResult.instruction}</p>
                    <p className="text-slate-600">
                      Required Secret: <code className="font-mono text-sky-800">{videoResult.requiredSecret}</code>
                    </p>
                    <p className="text-slate-500 text-[11px]">Cost Estimate: {videoResult.estimatedCost}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 5: CLOUD DEPLOYMENT */}
      {activeSubTab === 'deploy' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Multi-Cloud Deployment Engine</h3>
              <p className="text-xs text-slate-600">
                Synthesizes verified configuration files and automated deployment scripts across multiple targets.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {[
                { id: 'cloud_run', label: 'Google Cloud Run' },
                { id: 'vercel', label: 'Vercel Serverless' },
                { id: 'netlify', label: 'Netlify' },
                { id: 'github_pages', label: 'GitHub Pages' },
                { id: 'render', label: 'Render' },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => handleSelectDeployTarget(t.id)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                    selectedDeployTarget === t.id
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {deployConfigResult && (
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-800">
                    Configuration File: {deployConfigResult.configFile}
                  </span>
                  <button
                    onClick={() => navigator.clipboard.writeText(deployConfigResult.configContent)}
                    className="flex items-center gap-1 text-xs text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copy Config
                  </button>
                </div>

                <pre className="p-4 bg-slate-900 text-slate-100 text-xs font-mono rounded-lg overflow-x-auto">
                  <code>{deployConfigResult.configContent}</code>
                </pre>

                <div>
                  <span className="block font-mono text-xs font-semibold text-slate-700 mb-1">Deploy Script Command:</span>
                  <pre className="p-3 bg-slate-100 text-slate-800 text-xs font-mono rounded-lg overflow-x-auto">
                    <code>{deployConfigResult.deployScript}</code>
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 6: AUTOMATION WORKFLOWS */}
      {activeSubTab === 'workflows' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Directed Acyclic Graph (DAG) Workflow Engine</h3>
              <p className="text-xs text-slate-600">
                Execute automated multi-step sequences with variable piping, tool verification, and execution audit trails.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {workflows.map((wf) => (
                <div key={wf.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{wf.name}</h4>
                    <p className="text-xs text-slate-600 mt-1">{wf.description}</p>
                  </div>

                  <div className="text-xs text-slate-500 space-y-1">
                    <p className="font-semibold text-slate-700">Steps ({wf.steps.length}):</p>
                    {wf.steps.map((s: any, idx: number) => (
                      <p key={s.id} className="font-mono text-[11px]">
                        {idx + 1}. {s.name} <span className="text-slate-400">({s.toolName})</span>
                      </p>
                    ))}
                  </div>

                  <button
                    onClick={() => handleRunWorkflow(wf.id)}
                    disabled={isExecutingWf}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    <Play className="w-3.5 h-3.5" />
                    {isExecutingWf ? 'Running...' : 'Execute Workflow'}
                  </button>
                </div>
              ))}
            </div>

            {activeWorkflowRun && (
              <div className="mt-4 pt-4 border-t border-slate-100 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-900">Execution Run: {activeWorkflowRun.runId}</span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                    {activeWorkflowRun.status}
                  </span>
                </div>

                <div className="p-3 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono space-y-1 max-h-48 overflow-y-auto">
                  {activeWorkflowRun.logs.map((log: string, i: number) => (
                    <p key={i}>&gt; {log}</p>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 7: ANDROID & DEVICES */}
      {activeSubTab === 'android' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Android Companion &amp; Screen Bridge</h3>
              <p className="text-xs text-slate-600">
                Truthful architectural contracts for native Android assistant services, screen awareness, and physical touch.
              </p>
            </div>

            {screenStatus && (
              <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/50 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-purple-900">
                  <Smartphone className="w-4 h-4 text-purple-600" />
                  <span>Platform Bridge Status</span>
                </div>
                <p className="text-xs text-purple-800 leading-relaxed">{screenStatus.statusMessage}</p>
              </div>
            )}

            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Compiled Android Service Contracts
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {androidContracts.map((c) => (
                  <div key={c.serviceName} className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-900">{c.serviceName}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-800">
                        {c.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">{c.description}</p>
                    <p className="font-mono text-[10px] text-slate-400">Permission: {c.permission}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 8: SOCIAL MEDIA & GATEWAY */}
      {activeSubTab === 'social' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 mb-1">Social Media Integration Gateway</h3>
              <p className="text-xs text-slate-600">
                Safe drafting and outbound publication architecture with human-in-the-loop approval gating.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {socialPlatforms.map((p) => (
                <div key={p.platform} className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{p.name}</span>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                        p.isConfigured
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-sky-50 text-sky-800 border border-sky-200'
                      }`}
                    >
                      {p.publishStatus}
                    </span>
                  </div>
                  <p className="font-mono text-[10px] text-slate-500">Secret: {p.requiredSecret}</p>
                </div>
              ))}
            </div>

            <div className="space-y-3 pt-2">
              <label className="block text-xs font-semibold text-slate-700">Draft Content (Requires Safe Approval)</label>
              <textarea
                rows={2}
                value={socialText}
                onChange={(e) => setSocialText(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs md:text-sm"
              />

              <div className="flex items-center gap-2 flex-wrap">
                {['twitter', 'telegram', 'discord', 'linkedin'].map((plat) => (
                  <button
                    key={plat}
                    onClick={() => handleDraftSocial(plat)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer capitalize"
                  >
                    <Send className="w-3 h-3" />
                    Draft to {plat}
                  </button>
                ))}
              </div>
            </div>

            {socialResult && (
              <div className="p-3 bg-slate-100 rounded-lg text-xs space-y-1">
                <p className="font-semibold text-slate-800">
                  Draft Created: <span className="font-mono">{socialResult.draft.id}</span>
                </p>
                <p className="text-slate-600">Status: {socialResult.draft.status} (Human Approval Enforced)</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
