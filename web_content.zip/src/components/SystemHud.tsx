import React, { useState, useEffect } from 'react';
import { Battery, BatteryCharging, Wifi, WifiOff, Settings, Code, Download, Shield } from 'lucide-react';
import { AUTHOR_INFO } from '../data/config';
import { deviceService, BatteryInfo } from '../services/deviceService';
import { groqService } from '../services/groqService';

interface SystemHudProps {
  onOpenSettings: () => void;
  onOpenCodeViewer: () => void;
  onDownloadZip: () => void;
  activeKeyIndex: number;
}

export const SystemHud: React.FC<SystemHudProps> = ({
  onOpenSettings,
  onOpenCodeViewer,
  onDownloadZip,
  activeKeyIndex,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [battery, setBattery] = useState<BatteryInfo | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(true);

  useEffect(() => {
    // Soat
    const updateTime = () => {
      const d = new Date();
      setTimeStr(d.toTimeString().split(' ')[0]);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);

    // Batareya
    deviceService.getBatteryInfo().then((info) => {
      if (info) setBattery(info);
    });

    // Tarmoq
    if (typeof navigator !== 'undefined') {
      setIsOnline(navigator.onLine);
      const handleOnline = () => setIsOnline(true);
      const handleOffline = () => setIsOnline(false);
      window.addEventListener('online', handleOnline);
      window.addEventListener('offline', handleOffline);
      return () => {
        clearInterval(interval);
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
      };
    }

    return () => clearInterval(interval);
  }, []);

  return (
    <header className="flex items-center justify-between px-4 py-3 border-b border-cyan-500/20 bg-slate-950/80 backdrop-blur-md shrink-0">
      {/* 1. Brend va Dasturchi */}
      <div className="flex items-center gap-2.5">
        <div className="relative flex items-center justify-center">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee] animate-pulse" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-base tracking-widest text-cyan-400">
              JARVIS
            </span>
            <span className="text-[10px] font-mono text-cyan-600 border border-cyan-500/30 px-1 rounded">
              {AUTHOR_INFO.version}
            </span>
          </div>
          <p className="text-[10px] text-slate-400">
            Dasturchi: <span className="text-cyan-300 font-medium">{AUTHOR_INFO.name}</span>
          </p>
        </div>
      </div>

      {/* 2. Tizim ko'rsatkichlari va boshqaruv */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Soat */}
        <div className="hidden sm:flex items-center gap-1 font-mono text-xs text-cyan-300 bg-slate-900/60 px-2 py-1 rounded border border-slate-800">
          <span>{timeStr || '00:00:00'}</span>
        </div>

        {/* Batareya */}
        {battery !== null && (
          <div className="flex items-center gap-1 font-mono text-xs text-slate-300 bg-slate-900/60 px-2 py-1 rounded border border-slate-800">
            {battery.charging ? (
              <BatteryCharging className="w-3.5 h-3.5 text-cyan-400" />
            ) : (
              <Battery className="w-3.5 h-3.5 text-slate-400" />
            )}
            <span>{battery.level}%</span>
          </div>
        )}

        {/* Tarmoq */}
        <div className="flex items-center gap-1 font-mono text-xs text-slate-300 bg-slate-900/60 px-2 py-1 rounded border border-slate-800">
          {isOnline ? (
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <WifiOff className="w-3.5 h-3.5 text-rose-400" />
          )}
          <span className="hidden md:inline">{isOnline ? 'Online' : 'Offline'}</span>
        </div>

        {/* Faol Kalit */}
        <div className="flex items-center gap-1 font-mono text-xs text-cyan-300 bg-cyan-950/40 px-2 py-1 rounded border border-cyan-500/30">
          <span>Kalit: #{activeKeyIndex + 1}</span>
        </div>

        {/* Tugmalar */}
        <div className="flex items-center gap-1 border-l border-slate-800 pl-2">
          <button
            onClick={onDownloadZip}
            className="p-1.5 text-cyan-400 hover:text-cyan-200 hover:bg-slate-800/80 rounded transition-colors"
            title="APK uchun ZIP yuklab olish"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenCodeViewer}
            className="p-1.5 text-cyan-400 hover:text-cyan-200 hover:bg-slate-800/80 rounded transition-colors"
            title="Manba kodlarini ko'rish (server.py, index.html)"
          >
            <Code className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSettings}
            className="p-1.5 text-cyan-400 hover:text-cyan-200 hover:bg-slate-800/80 rounded transition-colors"
            title="Sozlamalar"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
