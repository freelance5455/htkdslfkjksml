import React, { useState } from 'react';
import { X, Download, Smartphone, CheckCircle2, ShieldCheck, Terminal, FolderArchive, RefreshCw } from 'lucide-react';

interface ExportProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportProjectModal: React.FC<ExportProjectModalProps> = ({ isOpen, onClose }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = () => {
    setIsDownloading(true);
    // Trigger direct backend stream download
    const link = document.createElement('a');
    link.href = '/api/export/download-zip';
    link.setAttribute('download', 'Angola_Connect_Full_Source_Android_Ready.zip');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setIsDownloading(false);
      setDownloadSuccess(true);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 sm:p-8 text-slate-100 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-600 via-amber-500 to-amber-400 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20 text-2xl">
            🇦🇴
          </div>
          <div>
            <h2 className="text-xl font-bold text-white font-display">
              Exportar Projeto Completo & Estrutura Android APK
            </h2>
            <p className="text-xs text-amber-400 font-medium">
              Angola Connect — Conectando Angola ao mundo
            </p>
          </div>
        </div>

        {/* Overview Box */}
        <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl mb-6 space-y-2">
          <p className="text-xs text-slate-300 leading-relaxed">
            Este pacote contém <strong>100% do código-fonte</strong> do Angola Connect: frontend React, backend Express com WebSockets e WebRTC, banco de dados JSON persistente com dados reais de Angola, e a <strong>estrutura Android completa nativa</strong> pronta para compilar o ficheiro APK no Android Studio.
          </p>
        </div>

        {/* Android Configuration Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl space-y-2">
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <Smartphone className="w-4 h-4" />
              <span>Configuração Android</span>
            </div>
            <ul className="text-xs space-y-1.5 text-slate-300">
              <li>• <strong>App Name</strong>: Angola Connect</li>
              <li>• <strong>Package</strong>: <code className="text-amber-400 font-mono text-[11px]">ao.connect.angolaconnect</code></li>
              <li>• <strong>Version</strong>: v1.0.0 (versionCode 1)</li>
              <li>• <strong>Framework</strong>: Capacitor / Android Native</li>
              <li>• <strong>Theme</strong>: Dark / Light adaptável</li>
            </ul>
          </div>

          <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Permissões Incluídas no Manifest</span>
            </div>
            <ul className="text-xs space-y-1.5 text-slate-300">
              <li>• <code className="text-emerald-400 text-[11px]">CAMERA</code> (Vídeo & Stories)</li>
              <li>• <code className="text-emerald-400 text-[11px]">RECORD_AUDIO</code> (Voz & Áudios)</li>
              <li>• <code className="text-emerald-400 text-[11px]">INTERNET</code> & <code className="text-emerald-400 text-[11px]">ACCESS_NETWORK_STATE</code></li>
              <li>• <code className="text-emerald-400 text-[11px]">READ_MEDIA_IMAGES / VIDEO</code></li>
              <li>• <code className="text-emerald-400 text-[11px]">POST_NOTIFICATIONS</code></li>
            </ul>
          </div>
        </div>

        {/* Steps to Compile */}
        <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl mb-6">
          <h4 className="text-xs font-bold text-white mb-2 flex items-center gap-1.5">
            <Terminal className="w-4 h-4 text-amber-400" />
            <span>Como Gerar o APK a partir do Ficheiro ZIP:</span>
          </h4>
          <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside leading-relaxed">
            <li>Extraia o arquivo ZIP para uma pasta no seu computador.</li>
            <li>No terminal, execute: <code className="text-amber-400 bg-slate-900 px-1 py-0.5 rounded font-mono">npm install</code> e depois <code className="text-amber-400 bg-slate-900 px-1 py-0.5 rounded font-mono">npm run build</code>.</li>
            <li>Abra a pasta <code className="text-amber-400 bg-slate-900 px-1 py-0.5 rounded font-mono">android</code> no <strong>Android Studio</strong>.</li>
            <li>Acesse o menu: <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.</li>
            <li>O seu APK estará pronto em <code className="text-slate-400 font-mono text-[11px]">android/app/build/outputs/apk/</code> para instalar em qualquer telemóvel Android!</li>
          </ol>
        </div>

        {/* Action Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-800">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <FolderArchive className="w-4 h-4 text-amber-400" />
            <span>Tamanho estimado: ~8 MB (ZIP comprimido)</span>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={isDownloading}
            className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-red-600 via-amber-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-slate-950 font-extrabold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {isDownloading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                <span>A preparar e a transferir ZIP...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Descarregar Código-Fonte Completo (ZIP)</span>
              </>
            )}
          </button>
        </div>

        {downloadSuccess && (
          <div className="mt-3 p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>O ficheiro ZIP foi transferido com sucesso para a pasta de descargas!</span>
          </div>
        )}

      </div>
    </div>
  );
};
