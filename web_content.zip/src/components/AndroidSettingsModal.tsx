import React, { useState } from 'react';
import {
  X,
  Smartphone,
  ExternalLink,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  ShieldAlert,
  Info,
  Terminal,
} from 'lucide-react';
import { DevicePermissionItem } from '../utils/devicePermissions';

interface AndroidSettingsModalProps {
  permission: DevicePermissionItem | null;
  isOpen: boolean;
  onClose: () => void;
  onGrant: (permissionId: string) => void;
  onDeny: (permissionId: string) => void;
}

export const AndroidSettingsModal: React.FC<AndroidSettingsModalProps> = ({
  permission,
  isOpen,
  onClose,
  onGrant,
  onDeny,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !permission) return null;

  const handleCopyAdb = () => {
    navigator.clipboard.writeText(permission.adbCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div
        className="relative w-full max-w-lg bg-[#0D1322] border border-cyan-500/40 rounded-2xl shadow-2xl shadow-cyan-950/60 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-[#0A0E17]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-cyan-400 tracking-wider font-semibold uppercase">
                Android System Intent Dispatcher
              </div>
              <h2 className="text-sm font-bold text-white tracking-wide">
                {permission.name}
              </h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Target Android Screen info */}
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                Target Settings Screen
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                {permission.androidApiLevel}
              </span>
            </div>
            <p className="text-white font-medium text-sm flex items-center gap-1.5">
              <ExternalLink className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>{permission.settingsActionLabel}</span>
            </p>
            <div className="p-2 bg-[#060910] rounded border border-slate-800 font-mono text-[11px] text-cyan-300 break-all select-all">
              Intent(Settings.{permission.settingsAction})
            </div>
          </div>

          {/* Why Needed & Security Notice */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-slate-300 font-semibold text-xs">
              <Info className="w-4 h-4 text-cyan-400" />
              <span>Functional Purpose</span>
            </div>
            <p className="text-slate-300 leading-relaxed bg-slate-900/40 p-3 rounded-lg border border-slate-800/80">
              {permission.whyNeeded}
            </p>
          </div>

          {/* Graceful Fallback & Non-Crashing Guarantee */}
          <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1.5">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold font-mono text-[11px]">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>NON-CRASH RESILIENT GUARANTEE</span>
            </div>
            <p className="text-emerald-200/90 text-[11px] leading-relaxed">
              {permission.gracefulFallback}
            </p>
          </div>

          {/* ADB Terminal command for real device testing */}
          <div className="p-3 rounded-xl bg-[#060911] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 uppercase">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>Physical Device / ADB Command</span>
              </div>
              <button
                type="button"
                onClick={handleCopyAdb}
                className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'COPIED' : 'COPY ADB'}</span>
              </button>
            </div>
            <pre className="p-2 rounded bg-black/60 border border-slate-800 text-[10px] font-mono text-cyan-400 overflow-x-auto select-all">
              {permission.adbCommand}
            </pre>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-[#0A0E17] flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <div className="text-[10px] text-slate-400 font-mono">
            Simulate real user response:
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              id="btn-simulate-deny"
              onClick={() => {
                onDeny(permission.id);
                onClose();
              }}
              className="flex-1 sm:flex-none px-3.5 py-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/40 text-rose-300 font-mono font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>SIMULATE DENY</span>
            </button>

            <button
              type="button"
              id="btn-simulate-grant"
              onClick={() => {
                onGrant(permission.id);
                onClose();
              }}
              className="flex-1 sm:flex-none px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-cyan-500/30 active:scale-95"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>GRANT IN SETTINGS</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
