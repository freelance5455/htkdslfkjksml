import React from 'react';
import type { MainTab } from '../types';
import { cyberAudio } from '../audio';

interface BottomNavigationProps {
  activeTab: MainTab;
  onChangeTab: (tab: MainTab) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  onChangeTab,
}) => {
  const handleSelect = (tab: MainTab) => {
    cyberAudio.playClick();
    onChangeTab(tab);
  };

  return (
    <div
      id="bottom-tab-navigation"
      className="bg-[#02070d] border-t border-cyan-950/80 px-2 pt-2 pb-3 grid grid-cols-4 gap-1.5 shrink-0 z-40 select-none shadow-[0_-8px_25px_rgba(0,0,0,0.9)] max-w-md mx-auto w-full"
    >
      {/* 1. SMALL BIG HACK (WIN GO) */}
      <button
        onClick={() => handleSelect('wingo')}
        className={`relative flex flex-col items-center justify-between p-1.5 rounded-2xl transition-all duration-300 outline-none cursor-pointer overflow-hidden min-h-[86px] ${
          activeTab === 'wingo'
            ? 'border-[2px] border-[#00e5ff] shadow-[0_0_20px_rgba(0,229,255,0.6),inset_0_0_12px_rgba(0,229,255,0.25)] scale-[1.02] bg-gradient-to-b from-[#06182c] via-[#04101e] to-[#020810]'
            : 'border border-[#00e5ff]/40 hover:border-[#00e5ff]/70 bg-gradient-to-b from-[#04101f]/90 to-[#020810]/95 opacity-85 hover:opacity-100'
        }`}
      >
        <div className="relative z-10 w-full flex items-center justify-center pt-0.5 h-[42px]">
          <svg viewBox="0 0 100 80" className="w-full h-full max-h-[42px] drop-shadow-[0_4px_10px_rgba(0,0,0,0.8)]">
            <defs>
              <linearGradient id="small_cube_grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="50%" stopColor="#0284c7" />
                <stop offset="100%" stopColor="#0369a1" />
              </linearGradient>
              <linearGradient id="big_cube_grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#4ade80" />
                <stop offset="50%" stopColor="#16a34a" />
                <stop offset="100%" stopColor="#15803d" />
              </linearGradient>
              <linearGradient id="arrow_profit_grad" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#86efac" />
                <stop offset="50%" stopColor="#22c55e" />
                <stop offset="100%" stopColor="#4ade80" />
              </linearGradient>
            </defs>
            <g transform="translate(10, 10) rotate(-6 20 20)">
              <rect x="0" y="0" width="34" height="32" rx="6" fill="url(#small_cube_grad)" stroke="#7dd3fc" strokeWidth="1.2" />
              <rect x="2" y="2" width="30" height="8" rx="3" fill="#bae6fd" opacity="0.3" />
              <text x="17" y="20" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="900" fontFamily="sans-serif">
                SMALL
              </text>
            </g>
            <g transform="translate(48, 14) rotate(4 20 20)">
              <rect x="0" y="0" width="34" height="32" rx="6" fill="url(#big_cube_grad)" stroke="#86efac" strokeWidth="1.2" />
              <rect x="2" y="2" width="30" height="8" rx="3" fill="#bbf7d0" opacity="0.3" />
              <text x="17" y="20" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="900" fontFamily="sans-serif">
                BIG
              </text>
            </g>
            <path d="M 12 62 Q 35 60 52 48 Q 65 38 78 28" fill="none" stroke="url(#arrow_profit_grad)" strokeWidth="3.5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="relative z-10 w-full flex flex-col items-center justify-center text-center mt-1">
          <span className="text-[9px] font-black text-white tracking-wider leading-none">SMALL BIG</span>
          <span className="text-[11px] font-black text-[#00e5ff] tracking-widest leading-tight">HACK</span>
        </div>
        <div className="relative z-10 w-full h-[5px] flex items-center justify-center mt-0.5 overflow-hidden">
          <div className="w-12 h-2.5 rounded-full border border-[#00e5ff]/80 bg-[#00e5ff]/20 shadow-[0_0_8px_#00e5ff]" />
        </div>
      </button>

      {/* 2. REGISTRATION LINK (PLAY GAME) */}
      <button
        onClick={() => handleSelect('play_game')}
        className={`relative flex flex-col items-center justify-between p-1.5 rounded-2xl transition-all duration-300 outline-none cursor-pointer overflow-hidden min-h-[86px] ${
          activeTab === 'play_game'
            ? 'border-[2px] border-[#d946ef] shadow-[0_0_20px_rgba(217,70,239,0.6),inset_0_0_12px_rgba(217,70,239,0.25)] scale-[1.02] bg-gradient-to-b from-[#24082e] via-[#16051c] to-[#0a020d]'
            : 'border border-[#d946ef]/40 hover:border-[#d946ef]/70 bg-gradient-to-b from-[#1a0622]/90 to-[#0a020d]/95 opacity-85 hover:opacity-100'
        }`}
      >
        <div className="relative z-10 w-full flex items-center justify-center pt-0.5 h-[42px]">
          <svg viewBox="0 0 100 80" className="w-full h-full max-h-[42px] drop-shadow-[0_4px_10px_rgba(0,0,0,0.8)]">
            <defs>
              <linearGradient id="chain_ring1" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="30%" stopColor="#f472b6" />
                <stop offset="70%" stopColor="#c084fc" />
                <stop offset="100%" stopColor="#7e22ce" />
              </linearGradient>
            </defs>
            <g transform="translate(20, 10) rotate(-45 30 30)">
              <rect x="5" y="14" width="50" height="22" rx="11" fill="none" stroke="url(#chain_ring1)" strokeWidth="6" />
            </g>
            <circle cx="50" cy="40" r="3" fill="#ffffff" filter="drop-shadow(0 0 6px #e879f9)" />
          </svg>
        </div>
        <div className="relative z-10 w-full flex flex-col items-center justify-center text-center mt-1">
          <span className="text-[8.5px] font-black text-white tracking-wider leading-none">REGISTRATION</span>
          <span className="text-[11px] font-black text-[#e879f9] tracking-widest leading-tight">LINK</span>
        </div>
        <div className="relative z-10 w-full h-[5px] flex items-center justify-center mt-0.5 overflow-hidden">
          <div className="w-12 h-2.5 rounded-full border border-[#d946ef]/80 bg-[#d946ef]/20 shadow-[0_0_8px_#d946ef]" />
        </div>
      </button>

      {/* 3. NUMBER SHOT HACK (VTRX) */}
      <button
        onClick={() => handleSelect('vtrx')}
        className={`relative flex flex-col items-center justify-between p-1.5 rounded-2xl transition-all duration-300 outline-none cursor-pointer overflow-hidden min-h-[86px] ${
          activeTab === 'vtrx'
            ? 'border-[2px] border-[#eab308] shadow-[0_0_20px_rgba(234,179,8,0.6),inset_0_0_12px_rgba(234,179,8,0.25)] scale-[1.02] bg-gradient-to-b from-[#2a1a04] via-[#1a0f02] to-[#0a0601]'
            : 'border border-[#eab308]/40 hover:border-[#eab308]/70 bg-gradient-to-b from-[#1c1203]/90 to-[#0a0601]/95 opacity-85 hover:opacity-100'
        }`}
      >
        <div className="relative z-10 w-full flex items-center justify-center pt-0.5 h-[42px]">
          <svg viewBox="0 0 100 80" className="w-full h-full max-h-[42px] drop-shadow-[0_4px_10px_rgba(0,0,0,0.8)]">
            <defs>
              <linearGradient id="gold_target_grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="50%" stopColor="#eab308" />
                <stop offset="100%" stopColor="#b45309" />
              </linearGradient>
            </defs>
            <circle cx="50" cy="40" r="22" fill="none" stroke="url(#gold_target_grad)" strokeWidth="3" />
            <circle cx="50" cy="40" r="12" fill="none" stroke="#facc15" strokeWidth="2" />
            <circle cx="50" cy="40" r="4.5" fill="#ef4444" stroke="#ffffff" strokeWidth="1.2" />
            <line x1="50" y1="10" x2="50" y2="18" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="50" y1="62" x2="50" y2="70" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="relative z-10 w-full flex flex-col items-center justify-center text-center mt-1">
          <span className="text-[8.5px] font-black text-white tracking-wider leading-none">NUMBER SHOT</span>
          <span className="text-[11px] font-black text-[#fbbf24] tracking-widest leading-tight">HACK</span>
        </div>
        <div className="relative z-10 w-full h-[5px] flex items-center justify-center mt-0.5 overflow-hidden">
          <div className="w-12 h-2.5 rounded-full border border-[#eab308]/80 bg-[#eab308]/20 shadow-[0_0_8px_#eab308]" />
        </div>
      </button>

      {/* 4. 7-STEP MATRIX */}
      <button
        onClick={() => handleSelect('seven_step')}
        className={`relative flex flex-col items-center justify-between p-1.5 rounded-2xl transition-all duration-300 outline-none cursor-pointer overflow-hidden min-h-[86px] ${
          activeTab === 'seven_step'
            ? 'border-[2px] border-[#00e5ff] shadow-[0_0_20px_rgba(0,229,255,0.6),inset_0_0_12px_rgba(0,229,255,0.25)] scale-[1.02] bg-gradient-to-b from-[#06182c] via-[#04101e] to-[#020810]'
            : 'border border-[#00e5ff]/40 hover:border-[#00e5ff]/70 bg-gradient-to-b from-[#04101f]/90 to-[#020810]/95 opacity-85 hover:opacity-100'
        }`}
      >
        <div className="relative z-10 w-full flex items-center justify-center pt-0.5 h-[42px]">
          <svg viewBox="0 0 100 80" className="w-full h-full max-h-[42px] drop-shadow-[0_4px_10px_rgba(0,0,0,0.8)]">
            <defs>
              <linearGradient id="stair_top_grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#bae6fd" />
                <stop offset="60%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#0284c7" />
              </linearGradient>
            </defs>
            <polygon points="20,52 38,52 38,68 20,68" fill="#0284c7" stroke="#00e5ff" strokeWidth="1.2" />
            <polygon points="38,36 56,36 56,52 38,52" fill="#0284c7" stroke="#00e5ff" strokeWidth="1.2" />
            <polygon points="56,20 74,20 74,36 56,36" fill="#0284c7" stroke="#00e5ff" strokeWidth="1.2" />
            <circle cx="68" cy="12" r="2.5" fill="#ffffff" filter="drop-shadow(0 0 5px #00e5ff)" />
          </svg>
        </div>
        <div className="relative z-10 w-full flex flex-col items-center justify-center text-center mt-1">
          <span className="text-[9px] font-black text-white tracking-wider leading-none">7 STEP</span>
          <span className="text-[11px] font-black text-[#00e5ff] tracking-widest leading-tight">MATRIX</span>
        </div>
        <div className="relative z-10 w-full h-[5px] flex items-center justify-center mt-0.5 overflow-hidden">
          <div className="w-12 h-2.5 rounded-full border border-[#00e5ff]/80 bg-[#00e5ff]/20 shadow-[0_0_8px_#00e5ff]" />
        </div>
      </button>
    </div>
  );
};
export default BottomNavigation;
