import React from 'react';
import { Home, FileText, Video, Info, PlusSquare } from 'lucide-react';

export type TabType = 'home' | 'notes' | 'video' | 'follow' | 'more';

interface BottomNavigationProps {
  currentTab: TabType;
  onChangeTab: (tab: TabType) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentTab,
  onChangeTab,
}) => {
  const tabs = [
    { id: 'home' as TabType, label: 'होम', icon: Home },
    { id: 'notes' as TabType, label: 'नोट्स', icon: FileText },
    { id: 'video' as TabType, label: 'वीडियो', icon: Video },
    { id: 'follow' as TabType, label: 'फॉलो', icon: Info },
    { id: 'more' as TabType, label: 'अन्य', icon: PlusSquare },
  ];

  return (
    <nav
      aria-label="मुख्य नेविगेशन"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]"
    >
      <div className="max-w-md mx-auto grid grid-cols-5 h-16 items-center px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onChangeTab(tab.id)}
              className="flex flex-col items-center justify-center py-1 transition-all group cursor-pointer focus:outline-none"
            >
              {/* Active pill shape container matching Android / screenshot style */}
              <div
                className={`flex items-center justify-center transition-all duration-200 ${
                  isActive
                    ? 'w-14 h-7 rounded-full bg-[#e0f2fe] text-[#00838f]'
                    : 'w-10 h-7 rounded-full text-slate-500 group-hover:text-slate-800'
                }`}
              >
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'scale-105 stroke-[2.4]' : 'stroke-[1.8]'
                  }`}
                />
              </div>

              {/* Label */}
              <span
                className={`text-[11px] font-medium tracking-tight mt-0.5 font-devanagari transition-colors ${
                  isActive
                    ? 'text-slate-900 font-bold'
                    : 'text-slate-500 group-hover:text-slate-700'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
