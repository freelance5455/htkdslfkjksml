import React, { useState, useEffect } from 'react';
import { Expense, PaymentMethod } from '../types/business';
import { StorageService } from '../db/storage';
import { ArrowLeft, Plus, Receipt, Trash2, Calendar, DollarSign, X } from 'lucide-react';

interface ExpenseManagementProps {
  lang: 'bn' | 'en';
  onBack: () => void;
}

const EXPENSE_CATEGORIES = [
  'দোকান ভাড়া (Shop Rent)',
  'বিদ্যুৎ ও ইউটিলিটি বিল (Electricity Bill)',
  'কর্মচারী বেতন (Staff Salary)',
  'যাতায়াত ও পরিবহন (Transportation)',
  'নাস্তা ও আপ্যায়ন (Food & Tea)',
  'মেরামত ও যন্ত্রপাতি (Tools & Equipment)',
  'অন্যান্য খরচ (Other Expenses)',
];

export const ExpenseManagement: React.FC<ExpenseManagementProps> = ({
  lang,
  onBack,
}) => {
  const [expenses, setExpenses] = useState<Expense[]>(StorageService.getExpenses());
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [category, setCategory] = useState(EXPENSE_CATEGORIES[0]);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'bKash' | 'Nagad' | 'Bank'>('Cash');
  const [note, setNote] = useState('');
  const [deleteCandidate, setDeleteCandidate] = useState<Expense | null>(null);

  const refreshExpenses = () => {
    setExpenses(StorageService.getExpenses());
  };

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) return;

    StorageService.addExpense({
      category,
      description: description.trim() || category,
      amount: numAmount,
      paymentMethod,
      note: note.trim() || undefined,
    });

    setShowAddModal(false);
    setDescription('');
    setAmount('');
    setNote('');
    refreshExpenses();
  };

  const handleDelete = () => {
    if (deleteCandidate) {
      StorageService.deleteExpense(deleteCandidate.id);
      setDeleteCandidate(null);
      refreshExpenses();
    }
  };

  const totalExpenseAmount = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <Receipt className="w-5 h-5 text-slate-700" />
                <span>{lang === 'bn' ? 'ব্যবসায়িক খরচ পরিচালনা (Expenses)' : 'Expense Management'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn' ? `সর্বমোট খরচ: ৳${totalExpenseAmount.toLocaleString()}` : `Total Expenses: ৳${totalExpenseAmount.toLocaleString()}`}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'bn' ? 'নতুন খরচ এন্ট্রি' : 'Add Expense'}</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-3">
        {expenses.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 max-w-md mx-auto shadow-xs">
            <Receipt className="w-12 h-12 mx-auto text-slate-300 mb-2" />
            <h4 className="font-bold text-slate-800 text-sm">কোন খরচ রেকর্ড নেই</h4>
            <p className="text-xs text-slate-500 mt-1">দোকানের দৈনন্দিন খরচ যোগ করতে উপরের বোতাম চাপুন।</p>
          </div>
        ) : (
          expenses.map((e) => (
            <div
              key={e.id}
              className="p-4 rounded-2xl bg-white border border-slate-200 flex items-center justify-between gap-3 text-xs shadow-2xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold shrink-0">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <span className="font-bold text-slate-900 text-sm block">{e.description}</span>
                  <div className="flex items-center gap-2 text-slate-400 text-[11px] mt-0.5">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-semibold">{e.category}</span>
                    <span>• {e.date} ({e.time})</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <span className="text-base font-black text-rose-600">
                    -৳{e.amount.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500 block font-semibold">{e.paymentMethod}</span>
                </div>
                <button
                  onClick={() => setDeleteCandidate(e)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Expense Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-slate-900">নতুন খরচ যোগ করুন</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddExpense} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">খরচের ক্যাটাগরি *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
                >
                  {EXPENSE_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">বিবরণ *</label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="যেমন: সেপ্টেম্বর মাসের দোকান ভাড়া"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">টাকার পরিমাণ (৳) *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="5000"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">পরিশোধের মাধ্যম</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as 'Cash' | 'bKash' | 'Nagad' | 'Bank')}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
                >
                  <option value="Cash">Cash</option>
                  <option value="bKash">bKash</option>
                  <option value="Nagad">Nagad</option>
                  <option value="Bank">Bank</option>
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 font-bold text-xs"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs shadow-md"
                >
                  খরচ সংরক্ষণ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 text-center border border-slate-100">
            <h3 className="font-bold text-slate-900 text-base mb-2">খরচ রেকর্ড মুছে ফেলতে চান?</h3>
            <p className="text-xs text-slate-500 mb-5">{deleteCandidate.description} (৳{deleteCandidate.amount})</p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteCandidate(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                বাতিল
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 py-2.5 rounded-xl bg-red-600 text-white font-bold text-xs"
              >
                মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
