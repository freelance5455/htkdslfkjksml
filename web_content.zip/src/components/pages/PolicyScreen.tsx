import React, { useState } from 'react';
import { ArrowLeft, FileText, Lock, Truck, RotateCcw, Sparkles } from 'lucide-react';
import { OmazifyLogo } from '../common/OmazifyLogo';

interface PolicyScreenProps {
  initialPolicy?: string;
  onBack: () => void;
}

export const PolicyScreen: React.FC<PolicyScreenProps> = ({
  initialPolicy = 'terms',
  onBack,
}) => {
  const [activePolicy, setActivePolicy] = useState(initialPolicy);

  const policies = [
    { id: 'terms', label: 'Terms & Conditions', icon: FileText },
    { id: 'privacy', label: 'Privacy Policy', icon: Lock },
    { id: 'shipping', label: 'Shipping Policy', icon: Truck },
    { id: 'return_refund', label: 'Returns & Refunds', icon: RotateCcw },
    { id: 'about', label: 'About OMAZIFY', icon: Sparkles },
  ];

  return (
    <div className="w-full min-h-screen bg-slate-50/70 pb-24 flex flex-col">
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#EAEAEA] px-4 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight">
            Policies & Information
          </h1>
        </div>
        <OmazifyLogo size="sm" />
      </div>

      <div className="bg-white border-b border-[#EAEAEA] px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {policies.map((p) => {
          const isSelected = activePolicy === p.id;
          return (
            <button
              key={p.id}
              onClick={() => setActivePolicy(p.id)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#000000] text-[#FFD400] shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-[#FAFAFA] hover:text-black'
              }`}
            >
              {p.label}
            </button>
          );
        })}
      </div>

      <div className="max-w-3xl mx-auto w-full px-4 py-5 flex-1">
        <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-7 shadow-2xs space-y-4">
          {activePolicy === 'terms' && (
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 border-b border-slate-100 pb-2">
                Terms & Conditions
              </h2>
              <p>
                Welcome to <strong>OMAZIFY</strong>. By browsing, downloading, or placing an order through the OMAZIFY platform, you agree to comply with and be bound by the following terms and conditions.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">1. Ordering & Cash on Delivery</h3>
              <p>
                All orders placed on OMAZIFY are subject to product availability and delivery confirmation. For orders chosen with Cash on Delivery (COD), the full amount printed on the invoice must be paid to the courier executive upon receipt of goods.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">2. Pricing & Descriptions</h3>
              <p>
                We strive for absolute accuracy in pricing and product listings. In the rare event of a typographical error, OMAZIFY reserves the right to cancel or verify the order before dispatch.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">3. Customer Conduct</h3>
              <p>
                Users agree not to misuse platform services, submit fraudulent orders, or tamper with application infrastructure.
              </p>
            </div>
          )}

          {activePolicy === 'privacy' && (
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 border-b border-slate-100 pb-2">
                Privacy Policy
              </h2>
              <p>
                At <strong>OMAZIFY</strong>, we take your personal data privacy seriously. This policy describes how we collect, store, and safeguard your details.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">1. Information We Collect</h3>
              <p>
                We collect your name, shipping address, mobile phone number, and email address solely for fulfilling orders, dispatch notifications, and customer service.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">2. Zero Sale of Personal Data</h3>
              <p>
                We never sell, rent, or trade your personal information to third-party marketing companies. Data is shared exclusively with trusted logistics partners to complete physical delivery.
              </p>
            </div>
          )}

          {activePolicy === 'shipping' && (
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 border-b border-slate-100 pb-2">
                Shipping & Delivery Policy
              </h2>
              <p>
                OMAZIFY ships to 19,000+ PIN codes across India through premier courier networks.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">1. Dispatch & Timelines</h3>
              <p>
                Orders are packed and dispatched within 24 hours of placement. Standard transit time is 2 to 4 business days for major Indian cities, and 3 to 6 days for remote areas.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">2. Free Shipping</h3>
              <p>
                All orders on OMAZIFY qualify for complimentary free shipping and zero additional Cash on Delivery handling charges.
              </p>
            </div>
          )}

          {activePolicy === 'return_refund' && (
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 border-b border-slate-100 pb-2">
                Returns & Refund Policy
              </h2>
              <p>
                We stand 100% behind the quality of every product sold on OMAZIFY.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">1. 7-Day Hassle-Free Returns</h3>
              <p>
                You may request a return or exchange within 7 days of parcel delivery if the size doesn't fit, or if the product arrives damaged or incorrect.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">2. Doorstep Pickup</h3>
              <p>
                Our courier partner will pick up the item directly from your doorstep at zero cost. Once picked up, exchanges are dispatched immediately or refunds processed.
              </p>
            </div>
          )}

          {activePolicy === 'about' && (
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 border-b border-slate-100 pb-2">
                About OMAZIFY
              </h2>
              <p>
                <strong>OMAZIFY</strong> is India's fast-growing mobile shopping destination curated for fashion, premium footwear, modern bags, luxury timepieces, and lifestyle essentials.
              </p>
              <h3 className="font-extrabold text-slate-900 text-sm">Our Mission</h3>
              <p>
                To provide high-quality, verified products at fair prices with the convenience of Cash on Delivery, rapid doorstep delivery, and exceptional customer care.
              </p>
              <p className="pt-2 text-black font-semibold font-extrabold">
                Shop Smart • Live Better with OMAZIFY.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
