import React, { useState, useEffect } from 'react';
import { PageProfile } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { Bookmark, Plus, Check, MapPin, Eye, TrendingUp, BarChart2 } from 'lucide-react';
import { CreatePageModal } from './CreatePageModal';

export const PagesView: React.FC = () => {
  const { currentUser } = useAuth();
  const [pages, setPages] = useState<PageProfile[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const loadPages = async () => {
    try {
      setIsLoading(true);
      const res = await api.getPages({ userId: currentUser?.id });
      setPages(res.pages || []);
    } catch (err) {
      console.error('Erro ao carregar páginas:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadPages();
  }, [currentUser?.id]);

  const handleFollowToggle = async (page: PageProfile) => {
    if (!currentUser) return;
    try {
      await api.togglePageFollow(page.id, currentUser.id);
      loadPages();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white font-display flex items-center gap-2">
            <Bookmark className="w-6 h-6 text-purple-400" />
            <span>Páginas de Empresas & Criadores</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Siga marcas nacionais, ateliês de moda, artistas musicais e empresas inovadoras em Angola.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-purple-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Criar Nova Página</span>
        </button>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="p-12 text-center text-slate-500 text-xs">A carregar páginas...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pages.map((page) => {
            const isFollowing = page.isFollowing;
            const isOwner = currentUser?.id === page.ownerId;

            return (
              <div
                key={page.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between transition-all"
              >
                <div>
                  {/* Cover */}
                  <div className="relative h-28 w-full bg-slate-950 overflow-hidden">
                    <img
                      src={page.coverImage || '/src/assets/images/luanda_skyline_banner_1793388059121.jpg'}
                      alt={page.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                    <span className="absolute top-2.5 right-2.5 px-2.5 py-0.5 bg-slate-950/80 backdrop-blur-md rounded-md text-[10px] font-semibold text-purple-300 border border-purple-500/30">
                      {page.category}
                    </span>
                  </div>

                  {/* Body */}
                  <div className="p-5 pt-0 relative">
                    <div className="flex items-end justify-between -mt-6 mb-3">
                      <img
                        src={page.avatar || '/src/assets/images/angola_samakaka_fashion_1793388060870.jpg'}
                        alt={page.name}
                        className="w-14 h-14 rounded-2xl object-cover ring-4 ring-slate-900 bg-slate-800"
                      />
                      <span className="text-xs text-amber-400 font-semibold flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        {page.province}
                      </span>
                    </div>

                    <h3 className="font-bold text-base text-white font-display mb-0.5">{page.name}</h3>
                    <p className="text-xs text-slate-400 font-mono mb-2">@{page.handle}</p>
                    <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{page.description}</p>

                    {/* Metrics if owner or follower */}
                    <div className="grid grid-cols-3 gap-2 mt-4 p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-center">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Seguidores</span>
                        <span className="text-xs font-bold text-white font-mono">{page.followersCount}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Alcance</span>
                        <span className="text-xs font-bold text-emerald-400 font-mono">{page.metrics.reach.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Engajamento</span>
                        <span className="text-xs font-bold text-amber-400 font-mono">{page.metrics.engagementRate}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="p-5 pt-0">
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
                    {isOwner ? (
                      <span className="text-xs text-amber-400 font-semibold flex items-center gap-1">
                        <BarChart2 className="w-4 h-4" />
                        <span>Sua Página Oficial</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => handleFollowToggle(page)}
                        className={`w-full py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                          isFollowing
                            ? 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                            : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md'
                        }`}
                      >
                        {isFollowing ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>A Seguir</span>
                          </>
                        ) : (
                          <span>Seguir Página</span>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Modal */}
      <CreatePageModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreated={loadPages}
      />

    </div>
  );
};
