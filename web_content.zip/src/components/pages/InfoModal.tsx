import React, { useState } from 'react';
import { X, Scale, Clock } from 'lucide-react';

interface InfoModalProps {
  title: string | null;
  onClose: () => void;
  onStartShopping?: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ title, onClose }) => {
  const [lang, setLang] = useState<'en' | 'hi'>('en');

  if (!title) return null;

  const renderGrievanceOfficerBlock = () => (
    <div className="mt-6 p-4 rounded-2xl bg-[#FAFAFA] border border-[#EAEAEA] space-y-2.5 text-xs text-slate-700">
      <div className="flex items-center gap-2 text-[#3B0764] font-bold text-xs uppercase tracking-wide">
        <Scale className="w-4 h-4 text-black font-semibold flex-shrink-0" />
        <span>
          {lang === 'hi'
            ? 'शिकायत निवारण अधिकारी विवरण (उपभोक्ता संरक्षण ई-कॉमर्स नियम, 2020)'
            : 'Statutory Grievance Officer Details (Consumer Protection E-Commerce Rules, 2020)'}
        </span>
      </div>
      <p className="text-[11px] text-slate-600 leading-relaxed">
        {lang === 'hi'
          ? 'उपभोक्ता संरक्षण (ई-कॉमर्स) नियम, 2020 के नियम 5(9) के अनुपालन में नामित शिकायत अधिकारी का विवरण:'
          : 'In accordance with Rule 5(9) of the Consumer Protection (E-Commerce) Rules, 2020, designated Grievance Officer details are published below:'}
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] bg-white p-3 rounded-xl border border-[#EAEAEA]">
        <div>
          <p className="font-semibold text-slate-800">
            {lang === 'hi' ? 'पदनाम:' : 'Designation:'}{' '}
            <span className="font-normal text-slate-600">Grievance & Redressal Officer</span>
          </p>
          <p className="font-semibold text-slate-800 mt-1">
            {lang === 'hi' ? 'ईमेल:' : 'Official Email:'}{' '}
            <a href="mailto:grievance@omazify.com" className="text-black font-semibold underline font-medium">grievance@omazify.com</a>
          </p>
        </div>
        <div className="border-t sm:border-t-0 sm:border-l sm:pl-3 border-slate-100 pt-1.5 sm:pt-0">
          <p className="font-semibold text-black flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-black font-semibold" />
            <span>{lang === 'hi' ? 'समय-सीमा (SLA):' : 'Timelines (SLA):'}</span>
          </p>
          <p className="text-slate-600 mt-0.5">
            <strong>{lang === 'hi' ? 'पावती:' : 'Acknowledgment:'}</strong>{' '}
            {lang === 'hi' ? '48 घंटे के भीतर' : 'Within 48 hours'}
          </p>
          <p className="text-slate-600 mt-0.5">
            <strong>{lang === 'hi' ? 'निवारण:' : 'Resolution:'}</strong>{' '}
            {lang === 'hi' ? '15 दिनों के भीतर' : 'Within 15 days of receipt'}
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl p-5 sm:p-7 overflow-hidden my-auto animate-in zoom-in-95 border border-[#EAEAEA]">
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <h3 className="text-base sm:text-lg font-bold text-slate-900 capitalize flex items-center gap-2">
              <span>{title}</span>
            </h3>
          </div>
          <div className="flex items-center gap-2.5">
            <div className="flex items-center rounded-full bg-slate-100 p-0.5 border border-slate-200">
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold cursor-pointer transition-colors ${
                  lang === 'en'
                    ? 'bg-[#000000] text-[#FFD400] shadow-xs'
                    : 'text-slate-600 hover:text-black'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLang('hi')}
                className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold cursor-pointer transition-colors ${
                  lang === 'hi'
                    ? 'bg-[#000000] text-[#FFD400] shadow-xs'
                    : 'text-slate-600 hover:text-black'
                }`}
              >
                हिन्दी
              </button>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="space-y-3 text-xs sm:text-sm text-slate-600 leading-relaxed max-h-[68vh] overflow-y-auto pr-1">
          <p>
            Welcome to <strong>OMAZIFY</strong>. All orders are processed with Free Cash on Delivery across India.
          </p>
          <p>
            For support or orders inquiries, contact us at <a href="mailto:support@omazify.com" className="text-black font-semibold underline font-medium">support@omazify.com</a>.
          </p>
          {renderGrievanceOfficerBlock()}
        </div>

        <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-400">
            © 2026 OMAZIFY. All rights reserved.
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#FFD400] hover:bg-[#FFC800] text-black font-black text-xs rounded-full shadow-xs cursor-pointer transition-colors"
          >
            {lang === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
