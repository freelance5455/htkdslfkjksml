/* ============================================
   plix_ai studio — Modal component
   ============================================ */

import React, { useEffect, useCallback } from 'react';
import { IconX } from './Icons';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  width?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  showClose?: boolean;
}

const widths = {
  sm: 'max-w-md',
  md: 'max-w-lg',
  lg: 'max-w-2xl',
  xl: 'max-w-4xl',
  full: 'max-w-6xl',
};

export default function Modal({ open, onClose, title, subtitle, children, width = 'md', showClose = true }: ModalProps) {
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
  }, [onClose]);

  useEffect(() => {
    if (open) {
      document.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [open, handleKeyDown]);

  if (!open) return null;

  return (
    <>
      <div className="modal-backdrop" onClick={onClose} aria-hidden="true" />
      <div
        className={`modal-content ${widths[width]} w-full mx-4`}
        role="dialog"
        aria-modal="true"
        aria-label={title || 'Dialog'}
      >
        <div className="surface-1 border border-subtle rounded-xl shadow-lg overflow-hidden">
          {(title || showClose) && (
            <div className="flex items-start justify-between px-6 pt-5 pb-0">
              <div>
                {title && <h2 className="text-lg font-semibold text-stone-100">{title}</h2>}
                {subtitle && <p className="text-sm text-stone-400 mt-0.5">{subtitle}</p>}
              </div>
              {showClose && (
                <button
                  onClick={onClose}
                  className="btn btn-ghost btn-sm -mt-1 -mr-1"
                  aria-label="Close dialog"
                >
                  <IconX size={16} />
                </button>
              )}
            </div>
          )}
          <div className="px-6 py-4 max-h-[70vh] overflow-y-auto">
            {children}
          </div>
        </div>
      </div>
    </>
  );
}