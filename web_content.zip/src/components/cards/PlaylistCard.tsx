import React from 'react';
import { Playlist } from '../../types/music';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { Play } from 'lucide-react';

interface PlaylistCardProps {
  playlist: Playlist;
  onClick?: () => void;
}

export const PlaylistCard: React.FC<PlaylistCardProps> = ({ playlist, onClick }) => {
  const { songs, playSong, setSelectedPlaylistId } = useMusic();

  const playlistSongs = songs.filter((s) => playlist.songIds.includes(s.id));

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      setSelectedPlaylistId(playlist.id);
    }
  };

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (playlistSongs.length > 0) {
      playSong(playlistSongs[0], playlistSongs);
    }
  };

  return (
    <div
      onClick={handleClick}
      className="group relative flex flex-col p-2.5 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.05] hover:border-white/10 transition-all duration-200 cursor-pointer shrink-0 w-36 sm:w-44 select-none"
    >
      <div className="relative aspect-square w-full rounded-2xl overflow-hidden shadow-lg">
        <CoverArt
          artKey={playlist.cover}
          title={playlist.title}
          artist={playlist.creator}
          colorTheme={playlist.colorTheme}
          size="lg"
          className="w-full h-full"
        />

        <button
          onClick={handlePlay}
          className="absolute bottom-2.5 right-2.5 w-9 h-9 rounded-full bg-purple-600 text-white shadow-xl flex items-center justify-center opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200"
          aria-label="Play playlist"
        >
          <Play className="w-4 h-4 fill-white ml-0.5" />
        </button>
      </div>

      <div className="mt-2.5 px-0.5">
        <p className="font-semibold text-xs sm:text-sm text-slate-100 truncate group-hover:text-purple-300 transition-colors">
          {playlist.title}
        </p>
        <p className="text-[11px] text-slate-400 truncate mt-0.5">
          {playlist.description || `${playlist.songIds.length} tracks`}
        </p>
      </div>
    </div>
  );
};
