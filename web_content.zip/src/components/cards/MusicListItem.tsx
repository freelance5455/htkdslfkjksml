import React, { useState } from 'react';
import { Song } from '../../types/music';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { EqualizerAnimation } from '../common/EqualizerAnimation';
import { AddToPlaylistModal } from '../modals/AddToPlaylistModal';
import { ShareModal } from '../modals/ShareModal';
import {
  Play,
  Pause,
  Heart,
  MoreVertical,
  ArrowDownToLine,
  ListPlus,
  Share2,
  Check
} from 'lucide-react';

interface MusicListItemProps {
  song: Song;
  rank?: number;
  showRank?: boolean;
  contextQueue?: Song[];
}

export const MusicListItem: React.FC<MusicListItemProps> = ({
  song,
  rank,
  showRank = false,
  contextQueue
}) => {
  const {
    currentSong,
    isPlaying,
    playSong,
    togglePlayPause,
    likedSongIds,
    toggleLikeSong,
    downloadedSongIds,
    toggleDownloadSong,
    addToQueueNext
  } = useMusic();

  const [showMenu, setShowMenu] = useState(false);
  const [showPlaylistModal, setShowPlaylistModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  const isCurrent = currentSong?.id === song.id;
  const isLiked = likedSongIds.includes(song.id);
  const isDownloaded = downloadedSongIds.includes(song.id);

  const handleRowClick = () => {
    if (isCurrent) {
      togglePlayPause();
    } else {
      playSong(song, contextQueue);
    }
  };

  return (
    <div
      onClick={handleRowClick}
      className={`group relative flex items-center justify-between p-2.5 rounded-2xl transition-all duration-150 cursor-pointer select-none ${
        isCurrent
          ? 'bg-purple-900/20 border border-purple-500/20 shadow-sm'
          : 'hover:bg-white/[0.04] border border-transparent'
      }`}
    >
      {/* Left: Rank + Art + Details */}
      <div className="flex items-center gap-3 min-w-0 flex-1 pr-2">
        {showRank && (
          <span
            className={`w-6 text-center text-xs font-mono font-bold shrink-0 ${
              rank === 1
                ? 'text-amber-400'
                : rank === 2
                ? 'text-slate-300'
                : rank === 3
                ? 'text-amber-600'
                : 'text-slate-500'
            }`}
          >
            {rank ? String(rank).padStart(2, '0') : ''}
          </span>
        )}

        <div className="relative shrink-0">
          <CoverArt
            artKey={song.albumArt}
            title={song.title}
            artist={song.artist}
            colorTheme={song.colorTheme}
            size="md"
            className="w-11 h-11 rounded-xl"
          />
          {isCurrent && isPlaying ? (
            <div className="absolute inset-0 bg-black/50 rounded-xl flex items-center justify-center">
              <EqualizerAnimation isPlaying={isPlaying} barsCount={3} height={12} color="bg-purple-400" />
            </div>
          ) : (
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 rounded-xl flex items-center justify-center transition-opacity">
              <Play className="w-4 h-4 fill-white text-white ml-0.5" />
            </div>
          )}
        </div>

        <div className="min-w-0 flex-1">
          <p
            className={`font-semibold text-xs sm:text-sm truncate ${
              isCurrent ? 'text-purple-300' : 'text-slate-100 group-hover:text-purple-200'
            }`}
          >
            {song.title}
          </p>
          <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
            <span className="truncate">{song.artist}</span>
            <span className="text-slate-600">·</span>
            <span className="shrink-0">{song.genre}</span>
          </div>
        </div>
      </div>

      {/* Right: Duration + Like + More Options */}
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-xs font-mono text-slate-400 hidden sm:inline">
          {song.duration}
        </span>

        {/* Like */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleLikeSong(song.id);
          }}
          className="p-1.5 rounded-lg text-slate-400 hover:text-pink-500 hover:bg-white/10 transition-colors"
          aria-label={isLiked ? 'Unlike' : 'Like'}
        >
          <Heart
            className={`w-4 h-4 ${
              isLiked ? 'fill-pink-500 text-pink-500' : ''
            }`}
          />
        </button>

        {/* More Options Button */}
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="More options"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {/* Context menu popup */}
          {showMenu && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowMenu(false);
                }}
              />
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 mt-1 w-48 rounded-2xl glass-panel p-1.5 shadow-2xl z-50 text-xs font-medium text-slate-200 animate-in fade-in zoom-in-95"
              >
                <button
                  onClick={() => {
                    addToQueueNext(song);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-white/10 text-left transition-colors"
                >
                  <ListPlus className="w-4 h-4 text-purple-400" />
                  <span>Play Next in Queue</span>
                </button>

                <button
                  onClick={() => {
                    setShowPlaylistModal(true);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-white/10 text-left transition-colors"
                >
                  <ListPlus className="w-4 h-4 text-purple-400" />
                  <span>Add to Playlist...</span>
                </button>

                <button
                  onClick={() => {
                    toggleDownloadSong(song.id);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-white/10 text-left transition-colors"
                >
                  {isDownloaded ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Downloaded</span>
                    </>
                  ) : (
                    <>
                      <ArrowDownToLine className="w-4 h-4 text-purple-400" />
                      <span>Download Offline</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    setShowShareModal(true);
                    setShowMenu(false);
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-white/10 text-left transition-colors"
                >
                  <Share2 className="w-4 h-4 text-purple-400" />
                  <span>Share Song</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Embedded Modals */}
      <AddToPlaylistModal
        song={song}
        isOpen={showPlaylistModal}
        onClose={() => setShowPlaylistModal(false)}
      />

      <ShareModal
        song={song}
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
      />
    </div>
  );
};
