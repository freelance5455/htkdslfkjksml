import React from 'react';
import { Artist } from '../../types/music';
import { CoverArt } from '../common/CoverArt';
import { useMusic } from '../../context/MusicContext';
import { Check } from 'lucide-react';

interface ArtistCardProps {
  artist: Artist;
  onClick?: () => void;
}

export const ArtistCard: React.FC<ArtistCardProps> = ({ artist, onClick }) => {
  const { setSelectedArtistId } = useMusic();

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      setSelectedArtistId(artist.id);
    }
  };

  return (
    <div
      onClick={handleClick}
      className="group flex flex-col items-center p-3 rounded-2xl bg-white/[0.02] hover:bg-white/[0.06] border border-white/[0.04] hover:border-white/10 transition-all duration-200 cursor-pointer shrink-0 w-32 sm:w-36 text-center select-none"
    >
      <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden shadow-xl mb-2.5 group-hover:scale-105 transition-transform duration-300">
        <CoverArt
          artKey={artist.image}
          title={artist.name}
          artist={artist.name}
          colorTheme={artist.colorTheme}
          size="lg"
          type="artist"
          className="w-full h-full"
        />
        {artist.verified && (
          <div className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center ring-2 ring-[#0b0c10]">
            <Check className="w-3 h-3 stroke-[3]" />
          </div>
        )}
      </div>

      <p className="font-semibold text-xs sm:text-sm text-slate-100 truncate w-full group-hover:text-purple-300 transition-colors">
        {artist.name}
      </p>
      <span className="text-[11px] text-slate-400 mt-0.5">
        {artist.followers} fans
      </span>
    </div>
  );
};
