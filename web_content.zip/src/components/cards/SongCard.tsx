import React from 'react';
import { Song } from '../../types/music';
import { useMusic } from '../../context/MusicContext';
import { CoverArt } from '../common/CoverArt';
import { Play, Pause, Heart } from 'lucide-react';
import { EqualizerAnimation } from '../common/EqualizerAnimation';

interface SongCardProps {
  song: Song;
  contextQueue?: Song[];
  size?: 'md' | 'lg' | 'wide';
}

export const SongCard: React.FC<SongCardProps> = ({
  song,
  contextQueue,
  size = 'md'
}) => {
  const { currentSong, isPlaying, playSong, togglePlayPause, likedSongIds, toggleLikeSong } = useMusic();

  const isCurrent = currentSong?.id === song.id;
  const isLiked = likedSongIds.includes(song.id);

  const handlePlayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCurrent) {
      togglePlayPause();
    } else {
      playSong(song, contextQueue);
    }
  };

  if (size === 'wide') {
    return (
      <div
        onClick={() => playSong(song, contextQueue)}
        className="group relative flex items-center gap-3.5 p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.06] hover:border-white/10 transition-all duration-200 cursor-pointer shrink-0 w-72 sm:w-80 shadow-md"
      >
        <div className="relative shrink-0">
          <CoverArt
            artKey={song.albumArt}
            title={song.title}
            artist={song.artist}
            colorTheme={song.colorTheme}
            size="md"
            className="w-14 h-14 rounded-xl"
          />
          <button
            onClick={handlePlayClick}
            className="absolute inset-0 bg-black/40 group-hover:opacity-100 opacity-0 rounded-xl flex items-center justify-center transition-opacity"
            aria-label="Play song"
          >
            {isCurrent && isPlaying ? (
              <Pause className="w-5 h-5 text-white fill-white" />
            ) : (
              <Play className="w-5 h-5 text-white fill-white ml-0.5" />
            )}
          </button>
        </div>

        <div className="min-w-0 flex-1">
          <p className="font-semibold text-xs sm:text-sm text-slate-100 truncate group-hover:text-purple-300 transition-colors">
            {song.title}
          </p>
          <p className="text-[11px] text-slate-400 truncate mt-0.5">{song.artist}</p>
          <div className="flex items-center gap-1.5 mt-1 text-[10px] text-slate-500">
            <span>{song.duration}</span>
            <span>·</span>
            <span>{song.genre}</span>
          </div>
        </div>

        {isCurrent && isPlaying && (
          <div className="shrink-0 pr-1">
            <EqualizerAnimation isPlaying={isPlaying} barsCount={3} height={14} color="bg-purple-400" />
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      onClick={() => playSong(song, contextQueue)}
      className="group relative flex flex-col p-2.5 rounded-2xl bg-white/[0.03] hover:bg-white/[0.07] border border-white/[0.05] hover:border-white/10 transition-all duration-200 cursor-pointer shrink-0 w-36 sm:w-44 select-none"
    >
      <div className="relative aspect-square w-full rounded-2xl overflow-hidden shadow-lg">
        <CoverArt
          artKey={song.albumArt}
          title={song.title}
          artist={song.artist}
          colorTheme={song.colorTheme}
          size="lg"
          className="w-full h-full"
        />

        {/* Play button hover overlay */}
        <button
          onClick={handlePlayClick}
          className={`absolute bottom-2.5 right-2.5 w-9 h-9 rounded-full bg-purple-600 text-white shadow-xl flex items-center justify-center transition-all duration-200 ${
            isCurrent
              ? 'opacity-100 scale-100'
              : 'opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0'
          }`}
          aria-label={isCurrent && isPlaying ? 'Pause' : 'Play'}
        >
          {isCurrent && isPlaying ? (
            <Pause className="w-4 h-4 fill-white" />
          ) : (
            <Play className="w-4 h-4 fill-white ml-0.5" />
          )}
        </button>

        {/* Like quick action */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleLikeSong(song.id);
          }}
          className="absolute top-2 right-2 p-1.5 rounded-full bg-black/40 backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <Heart
            className={`w-3.5 h-3.5 ${
              isLiked ? 'fill-pink-500 text-pink-500' : 'text-white'
            }`}
          />
        </button>

        {isCurrent && isPlaying && (
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md flex items-center gap-1">
            <EqualizerAnimation isPlaying={isPlaying} barsCount={3} height={10} color="bg-purple-400" />
          </div>
        )}
      </div>

      <div className="mt-2.5 px-0.5">
        <p className="font-semibold text-xs sm:text-sm text-slate-100 truncate group-hover:text-purple-300 transition-colors">
          {song.title}
        </p>
        <p className="text-[11px] text-slate-400 truncate mt-0.5">
          {song.artist}
        </p>
      </div>
    </div>
  );
};
