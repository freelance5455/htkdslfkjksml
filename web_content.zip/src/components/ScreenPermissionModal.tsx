import React from 'react';
import { Monitor, Shield, CheckCircle2, Lock, AlertCircle, X, Sparkles, Mic } from 'lucide-react';
import { SupportedLanguage } from '../types/assistant';

interface ScreenPermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGrantPermission: () => void;
  language: SupportedLanguage;
}

export const ScreenPermissionModal: React.FC<ScreenPermissionModalProps> = ({
  isOpen,
  onClose,
  onGrantPermission,
  language,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-[#0a1224] via-[#070b16] to-[#0d071a] border-2 border-cyan-400/60 p-6 md:p-8 shadow-2xl shadow-cyan-500/20 space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Security Holographic Badge */}
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-cyan-950 border border-cyan-400/80 flex items-center justify-center text-cyan-300 shadow-lg shadow-cyan-500/30">
            <Monitor className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40">
                SECURITY CLEARANCE LEVEL 1
              </span>
            </div>
            <h3 className="text-xl font-orbitron font-extrabold text-white mt-1">
              {language === 'bn' ? 'ডিসপ্লে ওভারভিউ পারমিশন রিকোয়েস্ট' : 'DISPLAY OVERVIEW AUTHORIZATION'}
            </h3>
          </div>
        </div>

        {/* Description & Transparency Box */}
        <div className="p-4 rounded-2xl bg-slate-950/90 border border-cyan-900/50 space-y-3">
          <p className="text-sm text-slate-200 leading-relaxed font-sans">
            {language === 'bn'
              ? 'রুবেল বস এআই আপনার স্ক্রিন লাইভ দেখার এবং আপনার ভয়েস কমান্ড অনুযায়ী কাজ সম্পন্ন করার অনুমতি চাইছে।'
              : 'Rubel Boss AI Assistant requests authorization to observe your live display stream and execute actions by voice.'}
          </p>

          <div className="space-y-2 text-xs font-sans text-slate-300">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                {language === 'bn'
                  ? 'আপনি মুখে যা বলবেন (যেমন: ফেসবুক পোস্ট, কোড ফিক্স, লেখা পড়া, এরর সমাধান), এআই স্ক্রিন দেখে তা করবে।'
                  : 'Whatever you command by voice (Facebook posting, code fixing, reading text), the AI will analyze and perform.'}
              </span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                {language === 'bn'
                  ? 'আপনার কোনো ডাটা বা স্ক্রিন কারও কাছে পাঠানো হয় না; সম্পূর্ণ ব্যক্তিগত ও সুরক্ষিত থাকে।'
                  : 'Private & secure: screen frames are strictly processed for your real-time commands.'}
              </span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                {language === 'bn'
                  ? 'আপনি যেকোনো সময় এক ক্লিকে স্ক্রিন লিঙ্ক বন্ধ করতে পারবেন।'
                  : 'You can disconnect display access instantly at any moment.'}
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl text-xs font-mono-tech text-slate-400 hover:text-white transition-colors"
          >
            {language === 'bn' ? 'বাতিল' : 'Cancel'}
          </button>

          <button
            onClick={() => {
              onClose();
              onGrantPermission();
            }}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-fuchsia-500 hover:from-cyan-400 text-slate-950 font-orbitron font-extrabold text-xs tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/30"
          >
            <Sparkles className="w-4 h-4" />
            <span>{language === 'bn' ? 'অনুমতি দিন (GRANT ACCESS)' : 'GRANT PERMISSION'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
