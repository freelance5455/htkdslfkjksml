import React, { useState } from 'react';
import { 
  X, 
  Flame, 
  CheckCircle2, 
  Gift, 
  Sparkles, 
  Clock, 
  Check, 
  Lock,
  Calendar,
  Zap,
  Crown
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface DailyStreakModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckinClaimed?: (coins: number) => void;
}

const STREAK_DAYS_CONFIG = [
  { day: 1, coins: 15, isMega: false },
  { day: 2, coins: 25, isMega: false },
  { day: 3, coins: 35, isMega: false },
  { day: 4, coins: 50, isMega: false },
  { day: 5, coins: 65, isMega: false },
  { day: 6, coins: 80, isMega: false },
  { day: 7, coins: 150, isMega: true },
];

export const DailyStreakModal: React.FC<DailyStreakModalProps> = ({
  isOpen,
  onClose,
  onCheckinClaimed
}) => {
  const { 
    currentUser, 
    membershipPlans, 
    claimDailyCheckin, 
    hasClaimedDailyToday, 
    language 
  } = useApp();

  const [claimMessage, setClaimMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentStreak = currentUser?.checkinStreak || 3;
  const isClaimedToday = hasClaimedDailyToday();
  const currentPlan = currentUser
    ? membershipPlans.find(p => p.id === currentUser.membershipTier) || membershipPlans[0]
    : membershipPlans[0];

  // Modulo 7 cycle
  const currentCycleDay = ((currentStreak - (isClaimedToday ? 1 : 0)) % 7) + 1;

  const handleClaim = () => {
    const result = claimDailyCheckin();
    setClaimMessage(result.message);

    if (result.success) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.65 },
      });
      if (onCheckinClaimed) {
        onCheckinClaimed(result.coins);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1 pr-6">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
              <Flame className="w-3 h-3 fill-current text-amber-400" />
              <span>Daily Streak Bonus</span>
            </span>
            <span className="text-xs font-black text-emerald-400">
              {currentPlan.rewardMultiplier}x Tier Multiplier
            </span>
          </div>

          <h2 className="text-lg font-black text-white">
            {currentStreak} Days Active Streak!
          </h2>
          <p className="text-xs text-slate-400">
            Check in every day without breaking your streak to unlock the Day 7 Mega Bonus Chest (+150 Coins).
          </p>
        </div>

        {/* 7-Day Streak Calendar Grid */}
        <div className="grid grid-cols-4 gap-2 pt-1">
          {STREAK_DAYS_CONFIG.map((item, idx) => {
            const dayNum = item.day;
            const isCompleted = isClaimedToday 
              ? dayNum <= (currentStreak % 7 === 0 ? 7 : currentStreak % 7)
              : dayNum < (currentStreak % 7 === 0 ? 7 : currentStreak % 7) + 1;
            const isTodayReady = !isClaimedToday && dayNum === currentCycleDay;
            const isFuture = !isCompleted && !isTodayReady;

            const isDay7 = item.isMega;

            return (
              <div
                key={dayNum}
                className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-between gap-1 relative ${
                  isDay7 ? 'col-span-2' : ''
                } ${
                  isTodayReady
                    ? 'bg-amber-500/20 border-amber-500 shadow-md shadow-amber-500/20 scale-102'
                    : isCompleted
                    ? 'bg-slate-950 border-emerald-500/40 text-emerald-400'
                    : 'bg-slate-950/80 border-slate-800 text-slate-400'
                }`}
              >
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                  Day {dayNum}
                </span>

                <div className="my-1">
                  {isCompleted ? (
                    <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                      <Check className="w-4 h-4" />
                    </div>
                  ) : isDay7 ? (
                    <Gift className={`w-8 h-8 mx-auto ${isTodayReady ? 'text-amber-400 animate-bounce' : 'text-slate-500'}`} />
                  ) : (
                    <Flame className={`w-6 h-6 mx-auto ${isTodayReady ? 'text-amber-400 fill-current' : 'text-slate-600'}`} />
                  )}
                </div>

                <div>
                  <span className={`text-xs font-black block ${
                    isTodayReady ? 'text-amber-400' : isCompleted ? 'text-emerald-400' : 'text-slate-300'
                  }`}>
                    +{item.coins}
                  </span>
                  <span className="text-[9px] text-slate-500 block">Coins</span>
                </div>

                {isTodayReady && (
                  <span className="absolute -top-1.5 -right-1 px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[8px] animate-pulse">
                    TODAY
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Claim feedback */}
        {claimMessage && (
          <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{claimMessage}</span>
          </div>
        )}

        {/* Action Button */}
        <div>
          {isClaimedToday ? (
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-1">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>Today's Streak Bonus Claimed!</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Come back tomorrow to continue your streak and unlock Day {currentCycleDay + 1} rewards.
              </p>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleClaim}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:opacity-95 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Claim Day {currentCycleDay} Bonus (+{STREAK_DAYS_CONFIG[currentCycleDay - 1]?.coins || 25} Coins)</span>
            </button>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-850 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span>Resets daily at 00:00 UTC</span>
          </span>
          <span className="font-bold text-slate-300">Streak: {currentStreak} Days</span>
        </div>

      </div>
    </div>
  );
};
