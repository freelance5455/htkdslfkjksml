import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, X, ArrowRight } from 'lucide-react';
import { playChimeSound } from '../utils/notifications';
import { getKoreanMotivationalQuote } from '../utils/tracker';

interface DailyCelebrationModalProps {
  isOpen: boolean;
  dayNumber: number;
  streak: number;
  onClose: () => void;
}

export const DailyCelebrationModal: React.FC<DailyCelebrationModalProps> = ({
  isOpen,
  dayNumber,
  streak,
  onClose,
}) => {
  useEffect(() => {
    if (isOpen) {
      playChimeSound('celebration');

      // Trigger multi-angle confetti blast
      const end = Date.now() + 1500;
      const colors = ['#8B5CF6', '#3B82F6', '#EC4899', '#10B981', '#F59E0B'];

      const frame = () => {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors,
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors,
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const quote = getKoreanMotivationalQuote(dayNumber);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm rounded-3xl bg-white dark:bg-[#13151B] border border-purple-100 dark:border-purple-900/40 p-6 shadow-2xl shadow-purple-900/20 text-center">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Close celebration modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Icon & Badge */}
        <div className="mx-auto w-16 h-16 rounded-3xl bg-gradient-to-tr from-purple-500 to-blue-500 flex items-center justify-center text-white shadow-lg shadow-purple-500/25 mb-4">
          <Trophy className="w-8 h-8" />
        </div>

        <div className="text-xs font-semibold tracking-wider uppercase text-purple-600 dark:text-purple-400 mb-1">
          Day {dayNumber} of 90 Complete
        </div>

        {/* Exact message requested */}
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white mb-2">
          Day completed! You're one step closer to your goal.
        </h2>

        <p className="text-xs text-slate-500 dark:text-slate-400 mb-5">
          All daily workouts, skincare, diet, hydration, and grooming habits checked off. Your current streak is <strong className="text-purple-600 dark:text-purple-400">{streak} days</strong>!
        </p>

        {/* Korean wisdom card */}
        <div className="rounded-2xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-800/40 p-3.5 mb-5 text-left">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-purple-700 dark:text-purple-300 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{quote.principle}</span>
          </div>
          <p className="text-xs text-slate-700 dark:text-slate-300 italic mb-1.5">
            "{quote.quote}"
          </p>
          <span className="text-[11px] text-slate-400 dark:text-slate-500 block text-right">
            — {quote.author}
          </span>
        </div>

        {/* Primary CTA */}
        <button
          onClick={onClose}
          className="w-full py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 active:scale-[0.98] text-white text-xs font-semibold transition-all shadow-md shadow-purple-600/20 flex items-center justify-center gap-1.5"
        >
          <span>Continue Journey</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
