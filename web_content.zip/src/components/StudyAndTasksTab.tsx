import type React from 'react';
import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Plus,
  Pencil,
  Trash2,
  BookOpen,
  X,
  Check,
  Play,
  Pause,
  RotateCcw,
  Coffee,
  Flame,
  Volume2,
  Bell,
  BellRing,
  BellOff,
} from 'lucide-react';
import type {
  Subject,
  ColorTheme,
  TaskItem,
  PomodoroSettings,
  StudyAlarm,
} from '../types';
import { BUILTIN_RINGTONES, playCompletionChime } from '../lib/sound';
import { celebrateTaskDone } from '../lib/confetti';
import { InteractiveCard, TactileButton } from './InteractiveButton';
import { TaskConfettiBurst } from './TaskConfettiBurst';
import { AlarmModal } from './AlarmModal';

interface StudyAndTasksTabProps {
  subjects: Subject[];
  onAddSubject: (subject: Omit<Subject, 'id' | 'updatedAt'>) => void;
  onUpdateSubject: (id: string, patch: Partial<Subject>) => void;
  onDeleteSubject: (id: string) => void;
  tasks: TaskItem[];
  pomodoroSettings: PomodoroSettings;
  onUpdatePomodoroSettings: (settings: PomodoroSettings) => void;
  onAddTask: (task: Omit<TaskItem, 'id' | 'createdAt'>) => void;
  onUpdateTask: (id: string, patch: Partial<TaskItem>) => void;
  onDeleteTask: (id: string) => void;
  onTaskCompletedStep: () => void;
  onPomodoroStudyComplete: () => void;
  alarms: StudyAlarm[];
  onSaveAlarm: (
    data: Omit<StudyAlarm, 'id' | 'createdAt'>,
    editingId?: string
  ) => void;
  onToggleAlarm: (id: string) => void;
  onDeleteAlarm: (id: string) => void;
}

const COLOR_STYLES: Record<
  ColorTheme,
  {
    name: string;
    softBg: string;
    iconText: string;
    btn: string;
  }
> = {
  purple: {
    name: 'بنفسجي',
    softBg: 'bg-violet-50 dark:bg-violet-950/60',
    iconText: 'text-violet-700 dark:text-violet-300',
    btn: 'bg-violet-600 hover:bg-violet-700',
  },
  blue: {
    name: 'أزرق',
    softBg: 'bg-blue-50 dark:bg-blue-950/60',
    iconText: 'text-blue-700 dark:text-blue-300',
    btn: 'bg-blue-600 hover:bg-blue-700',
  },
  orange: {
    name: 'برتقالي',
    softBg: 'bg-orange-50 dark:bg-orange-950/60',
    iconText: 'text-orange-700 dark:text-orange-300',
    btn: 'bg-orange-500 hover:bg-orange-600',
  },
  emerald: {
    name: 'أخضر',
    softBg: 'bg-emerald-50 dark:bg-emerald-950/60',
    iconText: 'text-emerald-700 dark:text-emerald-300',
    btn: 'bg-emerald-600 hover:bg-emerald-700',
  },
  rose: {
    name: 'وردي',
    softBg: 'bg-rose-50 dark:bg-rose-950/60',
    iconText: 'text-rose-700 dark:text-rose-300',
    btn: 'bg-rose-500 hover:bg-rose-600',
  },
};

const COLOR_OPTIONS: ColorTheme[] = ['purple', 'blue', 'orange', 'emerald', 'rose'];

function getRepeatLabel(repeat: StudyAlarm['repeat']): string {
  if (repeat === 'daily') return 'كل يوم';
  if (repeat === 'study_days') return 'أيام الدراسة بس';
  return 'مرة واحدة';
}

function getRingtoneLabel(alarm: StudyAlarm): string {
  if (alarm.ringtoneType === 'custom' && alarm.customAudioName) {
    return alarm.customAudioName;
  }
  return (
    BUILTIN_RINGTONES.find((r) => r.id === alarm.builtinRingtoneId)?.name ||
    'نغمة هادية للمذاكرة'
  );
}

export function StudyAndTasksTab({
  subjects,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject,
  tasks,
  pomodoroSettings,
  onUpdatePomodoroSettings,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onTaskCompletedStep,
  onPomodoroStudyComplete,
  alarms,
  onSaveAlarm,
  onToggleAlarm,
  onDeleteAlarm,
}: StudyAndTasksTabProps) {
  // Subject modal state
  const [subjModalOpen, setSubjModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [subjName, setSubjName] = useState('');
  const [subjTeacher, setSubjTeacher] = useState('');
  const [subjColor, setSubjColor] = useState<ColorTheme>('purple');

  // Pomodoro state
  const [mode, setMode] = useState<'study' | 'break'>('study');
  const [isRunning, setIsRunning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(pomodoroSettings.studyMinutes * 60);
  const [timerNotice, setTimerNotice] = useState<string | null>(null);

  // Task modal & celebration state
  const [taskFilter, setTaskFilter] = useState<'all' | 'active' | 'done'>('all');
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskSubjectName, setTaskSubjectName] = useState('');
  const [taskPriority, setTaskPriority] = useState<'normal' | 'high'>('normal');
  const [celebratingTasks, setCelebratingTasks] = useState<Record<string, number>>({});

  // Alarm modal & button animation state
  const [alarmModalOpen, setAlarmModalOpen] = useState(false);
  const [editingAlarm, setEditingAlarm] = useState<StudyAlarm | null>(null);
  const [alarmDefaultTitle, setAlarmDefaultTitle] = useState('منبه مذاكرة عام');
  const [alarmTaskId, setAlarmTaskId] = useState<string | undefined>(undefined);
  const [addSubjectSuccessKey, setAddSubjectSuccessKey] = useState<number | null>(null);
  const [addTaskSuccessKey, setAddTaskSuccessKey] = useState<number | null>(null);
  const [alarmShakeKey, setAlarmShakeKey] = useState<number>(0);

  const hasActiveAlarm = alarms.some((a) => a.enabled);

  const totalSeconds =
    (mode === 'study' ? pomodoroSettings.studyMinutes : pomodoroSettings.breakMinutes) * 60;
  const progressRatio = totalSeconds > 0 ? (totalSeconds - secondsLeft) / totalSeconds : 0;

  const prevSettings = useRef(pomodoroSettings);
  useEffect(() => {
    if (
      prevSettings.current.studyMinutes !== pomodoroSettings.studyMinutes ||
      prevSettings.current.breakMinutes !== pomodoroSettings.breakMinutes
    ) {
      prevSettings.current = pomodoroSettings;
      if (!isRunning) {
        setSecondsLeft(
          (mode === 'study' ? pomodoroSettings.studyMinutes : pomodoroSettings.breakMinutes) * 60
        );
      }
    }
  }, [pomodoroSettings, isRunning, mode]);

  useEffect(() => {
    if (!isRunning) return;
    const interval = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(interval);
          setIsRunning(false);
          playCompletionChime();
          if (mode === 'study') {
            setTimerNotice('أحسنت! انتهت جلسة المذاكرة، حان وقت الاستراحة.');
            celebrateTaskDone();
            onPomodoroStudyComplete();
            setMode('break');
            return pomodoroSettings.breakMinutes * 60;
          } else {
            setTimerNotice('انتهت الاستراحة! هيا نبدأ جلسة تركيز جديدة.');
            setMode('study');
            return pomodoroSettings.studyMinutes * 60;
          }
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isRunning, mode, pomodoroSettings, onPomodoroStudyComplete]);

  const handleModeSwitch = (nextMode: 'study' | 'break') => {
    setIsRunning(false);
    setTimerNotice(null);
    setMode(nextMode);
    setSecondsLeft(
      (nextMode === 'study' ? pomodoroSettings.studyMinutes : pomodoroSettings.breakMinutes) * 60
    );
  };

  const handleResetTimer = () => {
    setIsRunning(false);
    setTimerNotice(null);
    setSecondsLeft(
      (mode === 'study' ? pomodoroSettings.studyMinutes : pomodoroSettings.breakMinutes) * 60
    );
  };

  const handleTimeChange = (field: 'studyMinutes' | 'breakMinutes', rawVal: string) => {
    const num = Math.max(1, Math.min(120, Number(rawVal) || 1));
    onUpdatePomodoroSettings({
      ...pomodoroSettings,
      [field]: num,
    });
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  const openCreateSubjModal = () => {
    setEditingSubject(null);
    setSubjName('');
    setSubjTeacher('');
    setSubjColor('purple');
    setSubjModalOpen(true);
  };

  const openEditSubjModal = (subj: Subject) => {
    setEditingSubject(subj);
    setSubjName(subj.name);
    setSubjTeacher(subj.teacher || '');
    setSubjColor(subj.color);
    setSubjModalOpen(true);
  };

  const handleSaveSubject = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = subjName.trim();
    if (!trimmed) return;
    if (editingSubject) {
      onUpdateSubject(editingSubject.id, {
        name: trimmed,
        teacher: subjTeacher.trim(),
        color: subjColor,
      });
    } else {
      onAddSubject({
        name: trimmed,
        teacher: subjTeacher.trim(),
        progress: 0,
        color: subjColor,
      });
    }
    setAddSubjectSuccessKey(Date.now());
    setSubjModalOpen(false);
  };

  const toggleTaskDone = (task: TaskItem, event?: React.MouseEvent<HTMLButtonElement>) => {
    const nextDone = !task.done;
    onUpdateTask(task.id, { done: nextDone });
    if (nextDone) {
      const burstId = Date.now();
      setCelebratingTasks((prev) => ({ ...prev, [task.id]: burstId }));
      window.setTimeout(() => {
        setCelebratingTasks((prev) => {
          if (prev[task.id] !== burstId) return prev;
          const next = { ...prev };
          delete next[task.id];
          return next;
        });
      }, 900);

      if (event?.currentTarget) {
        const rect = event.currentTarget.getBoundingClientRect();
        celebrateTaskDone({
          x: (rect.left + rect.width / 2) / window.innerWidth,
          y: (rect.top + rect.height / 2) / window.innerHeight,
        });
      } else {
        celebrateTaskDone();
      }
      onTaskCompletedStep();
    }
  };

  const openCreateTaskModal = () => {
    setEditingTask(null);
    setTaskTitle('');
    setTaskSubjectName('');
    setTaskPriority('normal');
    setTaskModalOpen(true);
  };

  const openEditTaskModal = (task: TaskItem) => {
    setEditingTask(task);
    setTaskTitle(task.title);
    setTaskSubjectName(task.subjectName || '');
    setTaskPriority(task.priority);
    setTaskModalOpen(true);
  };

  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = taskTitle.trim();
    if (!trimmed) return;
    if (editingTask) {
      onUpdateTask(editingTask.id, {
        title: trimmed,
        subjectName: taskSubjectName.trim(),
        priority: taskPriority,
      });
    } else {
      onAddTask({
        title: trimmed,
        subjectName: taskSubjectName.trim(),
        done: false,
        priority: taskPriority,
      });
    }
    setAddTaskSuccessKey(Date.now());
    setTaskModalOpen(false);
  };

  const openGeneralAlarmModal = () => {
    setEditingAlarm(null);
    setAlarmDefaultTitle('منبه مذاكرة عام');
    setAlarmTaskId(undefined);
    setAlarmModalOpen(true);
  };

  const openTaskAlarmModal = (task: TaskItem) => {
    const existing = alarms.find((a) => a.taskId === task.id);
    if (existing) {
      setEditingAlarm(existing);
      setAlarmDefaultTitle(existing.title);
      setAlarmTaskId(task.id);
    } else {
      setEditingAlarm(null);
      setAlarmDefaultTitle(task.title);
      setAlarmTaskId(task.id);
    }
    setAlarmModalOpen(true);
  };

  const openEditExistingAlarm = (alarm: StudyAlarm) => {
    setEditingAlarm(alarm);
    setAlarmDefaultTitle(alarm.title);
    setAlarmTaskId(alarm.taskId);
    setAlarmModalOpen(true);
  };

  const filteredTasks = tasks.filter((t) => {
    if (taskFilter === 'active') return !t.done;
    if (taskFilter === 'done') return t.done;
    return true;
  });

  const doneCount = tasks.filter((t) => t.done).length;
  const activeTasksCount = tasks.length - doneCount;
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progressRatio);

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Section 1: Compact Subjects Bar & 2-Column Mobile Grid */}
      <section className="space-y-2.5 sm:space-y-3.5">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3 sm:p-4 flex items-center justify-between gap-3 shadow-xs">
          <div className="min-w-0">
            <h1 className="font-display text-base sm:text-xl font-extrabold text-slate-900 dark:text-white leading-snug">
              موادي ومهامي
            </h1>
            <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
              المواد: {subjects.length}
            </p>
          </div>

          <TactileButton
            type="button"
            successTrigger={addSubjectSuccessKey}
            onClick={openCreateSubjModal}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 sm:px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs sm:text-sm min-h-[40px] whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة مادة</span>
          </TactileButton>
        </div>

        {/* Subjects Grid — 2 Compact Cards Per Row on Mobile */}
        {subjects.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 px-4 py-4 text-center">
            <p className="text-slate-600 dark:text-slate-300 text-xs sm:text-sm font-medium">
              لسه مضفتش مواد ضيف أول مادة وابدأ
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
            <AnimatePresence>
              {subjects.map((subject) => {
                const theme = COLOR_STYLES[subject.color] || COLOR_STYLES.purple;
                return (
                  <InteractiveCard
                    key={subject.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.94 }}
                    className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-2.5 sm:p-3.5 flex flex-col justify-between gap-2 shadow-xs hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between gap-1.5">
                      <div
                        className={`w-8 h-8 rounded-xl ${theme.softBg} ${theme.iconText} flex items-center justify-center shrink-0`}
                      >
                        <BookOpen className="w-4 h-4" />
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <TactileButton
                          type="button"
                          onClick={() => openEditSubjModal(subject)}
                          aria-label={`تعديل ${subject.name}`}
                          className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </TactileButton>
                        <TactileButton
                          type="button"
                          onClick={() => onDeleteSubject(subject.id)}
                          aria-label={`حذف ${subject.name}`}
                          className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </TactileButton>
                      </div>
                    </div>

                    <div className="min-w-0">
                      <h3 className="font-display text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                        {subject.name}
                      </h3>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        {subject.teacher ? subject.teacher : 'مادة دراسية'}
                      </p>
                    </div>
                  </InteractiveCard>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </section>

      {/* Section 2: Compact Pomodoro + Tasks & Alarms */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-start">
        {/* Compact Pomodoro Timer Panel */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3.5 sm:p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                مؤقت بومودورو
              </h2>
              <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400">
                يعمل بدون إنترنت ويزيد تقدمك
              </p>
            </div>
            <TactileButton
              type="button"
              onClick={() => playCompletionChime()}
              title="اختبار صوت التنبيه"
              aria-label="اختبار صوت التنبيه"
              className="min-w-[36px] min-h-[36px] rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center"
            >
              <Volume2 className="w-4 h-4" />
            </TactileButton>
          </div>

          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <TactileButton
              type="button"
              onClick={() => handleModeSwitch('study')}
              className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 min-h-[36px] ${
                mode === 'study'
                  ? 'bg-violet-600 text-white'
                  : 'bg-transparent shadow-none text-slate-600 dark:text-slate-300'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>مذاكرة</span>
            </TactileButton>
            <TactileButton
              type="button"
              onClick={() => handleModeSwitch('break')}
              className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 min-h-[36px] ${
                mode === 'break'
                  ? 'bg-orange-500 text-white'
                  : 'bg-transparent shadow-none text-slate-600 dark:text-slate-300'
              }`}
            >
              <Coffee className="w-3.5 h-3.5" />
              <span>استراحة</span>
            </TactileButton>
          </div>

          <div className="flex justify-center">
            <div className="relative w-32 h-32 sm:w-36 sm:h-36 flex items-center justify-center">
              {/* Rotating active dashed ring when Pomodoro timer runs */}
              <motion.svg
                className="absolute inset-0 w-full h-full pointer-events-none"
                viewBox="0 0 160 160"
                animate={isRunning ? { rotate: 360 } : { rotate: 0 }}
                transition={
                  isRunning
                    ? { repeat: Infinity, duration: 8, ease: 'linear' }
                    : { duration: 0.25 }
                }
              >
                <circle
                  cx="80"
                  cy="80"
                  r="74"
                  fill="none"
                  stroke={mode === 'study' ? '#A78BFA' : '#FB923C'}
                  strokeWidth="2.5"
                  strokeDasharray="8 10"
                  strokeLinecap="round"
                  opacity={isRunning ? 0.65 : 0.2}
                />
              </motion.svg>

              <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
                <circle
                  cx="80"
                  cy="80"
                  r={radius}
                  fill="none"
                  className="stroke-slate-100 dark:stroke-slate-800"
                  strokeWidth="10"
                />
                <motion.circle
                  cx="80"
                  cy="80"
                  r={radius}
                  fill="none"
                  stroke={mode === 'study' ? '#7C3AED' : '#F97316'}
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  animate={{ strokeDashoffset }}
                  transition={{ duration: 0.25, ease: 'easeOut' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="font-mono-num text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
                  {formatTime(secondsLeft)}
                </span>
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-0.5">
                  {mode === 'study' ? 'وقت التركيز' : 'وقت الراحة'}
                </span>
              </div>
            </div>
          </div>

          {timerNotice && (
            <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold text-center">
              {timerNotice}
            </div>
          )}

          <div className="flex items-center gap-2">
            <TactileButton
              type="button"
              onClick={() => {
                setTimerNotice(null);
                setIsRunning((r) => !r);
              }}
              className={`flex-1 py-2 px-4 rounded-xl text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 min-h-[40px] ${
                mode === 'study'
                  ? 'bg-violet-600 hover:bg-violet-700'
                  : 'bg-orange-500 hover:bg-orange-600'
              }`}
            >
              <AnimatePresence mode="wait" initial={false}>
                {isRunning ? (
                  <motion.span
                    key="pause"
                    initial={{ opacity: 0, scale: 0.85, y: 4 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.85, y: -4 }}
                    transition={{ duration: 0.18 }}
                    className="inline-flex items-center gap-1.5"
                  >
                    <Pause className="w-4 h-4" />
                    <span>إيقاف مؤقت</span>
                  </motion.span>
                ) : (
                  <motion.span
                    key="start"
                    initial={{ opacity: 0, scale: 0.85, y: 4 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.85, y: -4 }}
                    transition={{ duration: 0.18 }}
                    className="inline-flex items-center gap-1.5"
                  >
                    <Play className="w-4 h-4" />
                    <span>ابدأ</span>
                  </motion.span>
                )}
              </AnimatePresence>
            </TactileButton>

            <TactileButton
              type="button"
              onClick={handleResetTimer}
              aria-label="إعادة ضبط المؤقت"
              className="min-w-[40px] min-h-[40px] px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold flex items-center justify-center"
            >
              <RotateCcw className="w-4 h-4" />
            </TactileButton>
          </div>

          <div className="grid grid-cols-2 gap-2.5 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                مدة المذاكرة (د)
              </label>
              <input
                type="number"
                min={1}
                max={120}
                value={pomodoroSettings.studyMinutes}
                onChange={(e) => handleTimeChange('studyMinutes', e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono-num text-center text-xs sm:text-sm font-bold text-slate-900 dark:text-white focus:border-violet-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                مدة الاستراحة (د)
              </label>
              <input
                type="number"
                min={1}
                max={60}
                value={pomodoroSettings.breakMinutes}
                onChange={(e) => handleTimeChange('breakMinutes', e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono-num text-center text-xs sm:text-sm font-bold text-slate-900 dark:text-white focus:border-orange-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Tasks & Alarms Panel */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3.5 sm:p-5 shadow-xs space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2.5">
              <div>
                <h2 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  مهام المذاكرة
                </h2>
                <p className="text-xs sm:text-sm font-bold text-violet-700 dark:text-violet-400 tabular-nums mt-0.5">
                  مهامي ({activeTasksCount})
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <TactileButton
                  type="button"
                  onClick={openGeneralAlarmModal}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-200 font-bold text-xs min-h-[38px] whitespace-nowrap"
                >
                  <span className="relative inline-flex items-center justify-center">
                    <motion.span
                      key={alarmShakeKey}
                      animate={
                        hasActiveAlarm
                          ? { rotate: [0, -16, 16, -12, 12, 0] }
                          : { rotate: 0 }
                      }
                      transition={{
                        duration: 0.45,
                        repeat: hasActiveAlarm ? Infinity : 0,
                        repeatDelay: 3.2,
                      }}
                      className="inline-flex"
                    >
                      {hasActiveAlarm ? (
                        <BellRing className="w-3.5 h-3.5" />
                      ) : (
                        <Bell className="w-3.5 h-3.5" />
                      )}
                    </motion.span>
                    {hasActiveAlarm && (
                      <span
                        aria-hidden="true"
                        className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-amber-50 dark:ring-amber-950"
                      />
                    )}
                  </span>
                  <span>منبه عام</span>
                </TactileButton>

                <TactileButton
                  type="button"
                  successTrigger={addTaskSuccessKey}
                  onClick={openCreateTaskModal}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs min-h-[38px] whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة مهمة</span>
                </TactileButton>
              </div>
            </div>

            <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'active', label: 'قيد التنفيذ' },
                { id: 'done', label: 'مكتملة' },
              ].map((item) => (
                <TactileButton
                  key={item.id}
                  type="button"
                  onClick={() => setTaskFilter(item.id as 'all' | 'active' | 'done')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold min-h-[34px] whitespace-nowrap ${
                    taskFilter === item.id
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white'
                      : 'bg-transparent shadow-none text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {item.label}
                </TactileButton>
              ))}
            </div>

            {filteredTasks.length === 0 ? (
              <div className="py-5 text-center border border-dashed border-slate-200 dark:border-slate-700 rounded-2xl">
                <p className="text-slate-600 dark:text-slate-400 text-xs font-medium mb-1.5">
                  {tasks.length === 0
                    ? 'لسه مضفتش مهمات'
                    : 'لا توجد مهام في هذه القائمة حالياً'}
                </p>
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={openCreateTaskModal}
                  className="text-blue-600 dark:text-blue-400 text-xs font-bold hover:underline cursor-pointer active:shadow-none"
                >
                  أضف مهمة جديدة الآن
                </motion.button>
              </div>
            ) : (
              <div className="space-y-2">
                <AnimatePresence>
                  {filteredTasks.map((task) => {
                    const taskAlarm = alarms.find((a) => a.taskId === task.id && a.enabled);
                    return (
                      <InteractiveCard
                        key={task.id}
                        layout
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className={`p-2.5 sm:p-3 rounded-xl border transition-colors flex items-center justify-between gap-2 ${
                          task.done
                            ? 'bg-slate-50 dark:bg-slate-800/50 border-slate-200/70 dark:border-slate-800'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-600'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1">
                          <div className="relative shrink-0">
                            <TaskConfettiBurst burstKey={celebratingTasks[task.id] ?? null} />
                            <TactileButton
                              type="button"
                              onClick={(e) => toggleTaskDone(task, e)}
                              aria-label={
                                task.done ? 'إلغاء إكمال المهمة' : 'تحديد المهمة كمكتملة'
                              }
                              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center shrink-0 ${
                                task.done
                                  ? 'bg-emerald-500 border-emerald-500 text-white'
                                  : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800'
                              }`}
                            >
                              {task.done && <Check className="w-4 h-4 stroke-[3]" />}
                            </TactileButton>
                          </div>

                          <div className="min-w-0 flex-1">
                            <p
                              className={`font-bold text-xs sm:text-sm truncate ${
                                task.done
                                  ? 'line-through text-slate-400 dark:text-slate-500'
                                  : 'text-slate-900 dark:text-white'
                              }`}
                            >
                              {task.title}
                            </p>
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                              {task.subjectName && <span>{task.subjectName}</span>}
                              {task.subjectName && task.priority === 'high' && (
                                <span aria-hidden="true">·</span>
                              )}
                              {task.priority === 'high' && (
                                <span className="text-orange-600 dark:text-orange-400 font-bold">
                                  أولوية عالية
                                </span>
                              )}
                              {taskAlarm && (
                                <>
                                  {(task.subjectName || task.priority === 'high') && (
                                    <span aria-hidden="true">·</span>
                                  )}
                                  <span className="text-amber-600 dark:text-amber-400 font-bold font-mono-num">
                                    {taskAlarm.time}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <TactileButton
                            type="button"
                            onClick={() => openTaskAlarmModal(task)}
                            title="منبه"
                            aria-label={`منبه ${task.title}`}
                            className={`h-8 px-2 rounded-lg flex items-center justify-center gap-1 text-[11px] font-bold ${
                              taskAlarm
                                ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                                : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-400'
                            }`}
                          >
                            <span className="relative inline-flex items-center justify-center">
                              <motion.span
                                animate={
                                  taskAlarm
                                    ? { rotate: [0, -15, 15, -10, 10, 0] }
                                    : { rotate: 0 }
                                }
                                transition={{
                                  duration: 0.45,
                                  repeat: taskAlarm ? Infinity : 0,
                                  repeatDelay: 3.5,
                                }}
                                className="inline-flex"
                              >
                                {taskAlarm ? (
                                  <BellRing className="w-3.5 h-3.5" />
                                ) : (
                                  <Bell className="w-3.5 h-3.5" />
                                )}
                              </motion.span>
                              {taskAlarm && (
                                <span
                                  aria-hidden="true"
                                  className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 ring-1 ring-amber-100 dark:ring-amber-950"
                                />
                              )}
                            </span>
                            <span className="hidden sm:inline">منبه</span>
                          </TactileButton>

                          <TactileButton
                            type="button"
                            onClick={() => openEditTaskModal(task)}
                            aria-label={`تعديل ${task.title}`}
                            className="w-8 h-8 rounded-lg flex items-center justify-center bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </TactileButton>

                          <TactileButton
                            type="button"
                            onClick={() => onDeleteTask(task.id)}
                            aria-label={`حذف ${task.title}`}
                            className="w-8 h-8 rounded-lg flex items-center justify-center bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </TactileButton>
                        </div>
                      </InteractiveCard>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>

          {/* Saved Alarms List: "منبهاتي" */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3.5 sm:p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <BellRing className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <h2 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  منبهاتي ({alarms.length})
                </h2>
              </div>
              <TactileButton
                type="button"
                onClick={openGeneralAlarmModal}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-amber-950 text-slate-700 dark:text-slate-200 text-xs font-bold min-h-[34px]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة منبه</span>
              </TactileButton>
            </div>

            {alarms.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400 py-2">
                لم تضف أي منبهات بعد — اضغط على «منبه» بجانب أي مهمة أو «منبه عام».
              </p>
            ) : (
              <div className="space-y-2">
                {alarms.map((alarm) => (
                  <div
                    key={alarm.id}
                    className={`p-2.5 sm:p-3 rounded-xl border flex items-center justify-between gap-2 transition-colors ${
                      alarm.enabled
                        ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200/80 dark:border-amber-800/60'
                        : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200/70 dark:border-slate-800 opacity-75'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono-num text-sm sm:text-base font-extrabold text-amber-700 dark:text-amber-300 shrink-0">
                          {alarm.time}
                        </span>
                        <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate">
                          {alarm.title}
                        </p>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-mono-num">{alarm.date}</span>
                        <span aria-hidden="true">·</span>
                        <span>{getRepeatLabel(alarm.repeat)}</span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate max-w-[140px]">{getRingtoneLabel(alarm)}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <TactileButton
                        type="button"
                        onClick={() => onToggleAlarm(alarm.id)}
                        aria-label={alarm.enabled ? 'إيقاف المنبه' : 'تفعيل المنبه'}
                        title={alarm.enabled ? 'مفعل (اضغط للإيقاف)' : 'مقفل (اضغط للتشغيل)'}
                        className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          alarm.enabled
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {alarm.enabled ? (
                          <BellRing className="w-3.5 h-3.5" />
                        ) : (
                          <BellOff className="w-3.5 h-3.5" />
                        )}
                      </TactileButton>

                      <TactileButton
                        type="button"
                        onClick={() => openEditExistingAlarm(alarm)}
                        aria-label={`تعديل منبه ${alarm.title}`}
                        className="w-8 h-8 rounded-lg flex items-center justify-center bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </TactileButton>

                      <TactileButton
                        type="button"
                        onClick={() => onDeleteAlarm(alarm.id)}
                        aria-label={`حذف منبه ${alarm.title}`}
                        className="w-8 h-8 rounded-lg flex items-center justify-center bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </TactileButton>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Subject Modal */}
      <AnimatePresence>
        {subjModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 12 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-7 shadow-xl"
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                  {editingSubject ? 'تعديل المادة' : 'إضافة مادة'}
                </h2>
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSubjModalOpen(false)}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer active:shadow-none"
                >
                  <X className="w-5 h-5" />
                </motion.button>
              </div>

              <form onSubmit={handleSaveSubject} className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    اسم المادة
                  </label>
                  <input
                    type="text"
                    required
                    value={subjName}
                    onChange={(e) => setSubjName(e.target.value)}
                    placeholder="مثال: الكيمياء العضوية"
                    className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-violet-500 outline-none text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    وصف صغير (اختياري)
                  </label>
                  <input
                    type="text"
                    value={subjTeacher}
                    onChange={(e) => setSubjTeacher(e.target.value)}
                    placeholder="مثال: الوحدة الأولى والثانية"
                    className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-violet-500 outline-none text-sm"
                  />
                </div>

                <div>
                  <span className="block text-sm font-bold text-slate-700 dark:text-slate-200 mb-2">
                    لون البطاقة
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {COLOR_OPTIONS.map((c) => {
                      const st = COLOR_STYLES[c];
                      const selected = subjColor === c;
                      return (
                        <TactileButton
                          key={c}
                          type="button"
                          onClick={() => setSubjColor(c)}
                          className={`px-3.5 py-2 rounded-xl text-xs font-bold min-h-[40px] flex items-center gap-1.5 ${
                            selected
                              ? `${st.btn} text-white`
                              : `${st.softBg} ${st.iconText}`
                          }`}
                        >
                          {selected && <Check className="w-3.5 h-3.5" />}
                          <span>{st.name}</span>
                        </TactileButton>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-2">
                  <TactileButton
                    type="button"
                    onClick={() => setSubjModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-sm font-bold min-h-[42px]"
                  >
                    إلغاء
                  </TactileButton>
                  <TactileButton
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-sm font-bold min-h-[42px]"
                  >
                    حفظ المادة
                  </TactileButton>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Task Modal */}
      <AnimatePresence>
        {taskModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 12 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-7 shadow-xl"
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                  {editingTask ? 'تعديل المهمة' : 'إضافة مهمة جديدة'}
                </h2>
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setTaskModalOpen(false)}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer active:shadow-none"
                >
                  <X className="w-5 h-5" />
                </motion.button>
              </div>

              <form onSubmit={handleSaveTask} className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    عنوان المهمة
                  </label>
                  <input
                    type="text"
                    required
                    value={taskTitle}
                    onChange={(e) => setTaskTitle(e.target.value)}
                    placeholder="مثال: حل 10 مسائل في التفاضل"
                    className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-blue-500 outline-none text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    المادة المرتبطة (اختياري)
                  </label>
                  <input
                    type="text"
                    list="subject-suggestions"
                    value={taskSubjectName}
                    onChange={(e) => setTaskSubjectName(e.target.value)}
                    placeholder="اختر أو اكتب اسم المادة"
                    className="w-full px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-blue-500 outline-none text-sm"
                  />
                  <datalist id="subject-suggestions">
                    {subjects.map((s) => (
                      <option key={s.id} value={s.name} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <span className="block text-sm font-bold text-slate-700 dark:text-slate-200 mb-1.5">
                    الأولوية
                  </span>
                  <div className="grid grid-cols-2 gap-2.5">
                    <TactileButton
                      type="button"
                      onClick={() => setTaskPriority('normal')}
                      className={`py-2.5 rounded-xl font-bold text-xs sm:text-sm min-h-[42px] ${
                        taskPriority === 'normal'
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      عادية
                    </TactileButton>
                    <TactileButton
                      type="button"
                      onClick={() => setTaskPriority('high')}
                      className={`py-2.5 rounded-xl font-bold text-xs sm:text-sm min-h-[42px] ${
                        taskPriority === 'high'
                          ? 'bg-orange-500 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      أولوية عالية
                    </TactileButton>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-2">
                  <TactileButton
                    type="button"
                    onClick={() => setTaskModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-sm font-bold min-h-[42px]"
                  >
                    إلغاء
                  </TactileButton>
                  <TactileButton
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold min-h-[42px]"
                  >
                    حفظ المهمة
                  </TactileButton>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Alarm Setup / Edit Modal */}
      <AlarmModal
        open={alarmModalOpen}
        onClose={() => setAlarmModalOpen(false)}
        editingAlarm={editingAlarm}
        defaultTitle={alarmDefaultTitle}
        taskId={alarmTaskId}
        onSave={(data) => {
          onSaveAlarm(data, editingAlarm?.id);
          setAlarmShakeKey((k) => k + 1);
        }}
      />
    </div>
  );
}
