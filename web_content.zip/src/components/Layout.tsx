import React, { useState } from 'react';
import {
  BarChart3,
  Boxes,
  DatabaseBackup,
  Factory,
  FileClock,
  Home,
  LayoutDashboard,
  Menu,
  Settings,
  Sliders,
  Trash2,
  Wallet,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { NavSection } from '../types';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { state, activeSection, navigate, tr, themeTokens, toasts, dismissToast } = useApp();
  const [drawerOpen, setDrawerOpen] = useState(false);

  const isMobileMode = state.settings.viewMode === 'mobile';
  const vis = state.settings.builtInModuleVisibility;

  const navItems: { id: NavSection; label: string; icon: React.ReactNode; visible?: boolean }[] = [
    { id: 'dashboard', label: tr('nav_dashboard'), icon: <LayoutDashboard className="h-4 w-4 shrink-0" />, visible: true },
    { id: 'home', label: tr('nav_home'), icon: <Home className="h-4 w-4 shrink-0" />, visible: vis.home },
    { id: 'factory', label: tr('nav_factory'), icon: <Factory className="h-4 w-4 shrink-0" />, visible: vis.factory },
    { id: 'personal', label: tr('nav_personal'), icon: <Wallet className="h-4 w-4 shrink-0" />, visible: vis.personal },
    { id: 'reports', label: tr('nav_reports'), icon: <BarChart3 className="h-4 w-4 shrink-0" />, visible: true },
    { id: 'settings', label: tr('nav_settings'), icon: <Settings className="h-4 w-4 shrink-0" />, visible: true },
    { id: 'dynamic_settings', label: tr('nav_dynamic_settings'), icon: <Sliders className="h-4 w-4 shrink-0" />, visible: true },
    { id: 'backup', label: tr('nav_backup'), icon: <DatabaseBackup className="h-4 w-4 shrink-0" />, visible: true },
    { id: 'recycle_bin', label: tr('nav_recycle_bin'), icon: <Trash2 className="h-4 w-4 shrink-0" />, visible: true },
    { id: 'audit_log', label: tr('nav_audit_log'), icon: <FileClock className="h-4 w-4 shrink-0" />, visible: true },
  ];

  const activeCustomModules = state.customModules
    .filter((m) => m.visible && !m.archived)
    .sort((a, b) => a.order - b.order);

  const handleSelectNav = (id: NavSection) => {
    navigate(id);
    setDrawerOpen(false);
  };

  const currentSectionTitle = (() => {
    const found = navItems.find((n) => n.id === activeSection);
    if (found) return found.label;
    if (activeSection.startsWith('custom:')) {
      const modId = activeSection.slice(7);
      return state.customModules.find((m) => m.id === modId)?.name || 'Custom Module';
    }
    return state.settings.appName;
  })();

  const renderSidebarNav = () => (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-4 py-5 border-b border-white/10">
        <div
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg font-bold text-sm tracking-tight text-white ${themeTokens.brandBadgeBg}`}
          aria-hidden="true"
        >
          SU
        </div>
        <div className="min-w-0">
          <div className="text-base font-bold text-white truncate leading-tight">
            {state.settings.appName}
          </div>
          <div className="text-[11px] text-slate-300 leading-snug mt-0.5">
            {state.settings.appSubtitle}
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1" aria-label="Main navigation">
        {navItems
          .filter((item) => item.visible !== false)
          .map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectNav(item.id)}
                className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? themeTokens.sidebarActive
                    : `${themeTokens.sidebarText} ${themeTokens.sidebarHover}`
                }`}
              >
                {item.icon}
                <span className="truncate">{item.label}</span>
                {item.id === 'recycle_bin' && state.recycleBin.length > 0 && (
                  <span className="ms-auto text-xs font-mono tabular-nums opacity-80">
                    {state.recycleBin.length}
                  </span>
                )}
              </button>
            );
          })}

        {activeCustomModules.length > 0 && (
          <div className="pt-4 mt-4 border-t border-white/10">
            <div className="px-3 pb-2 text-xs font-medium text-slate-400">
              {tr('nav_custom_modules')}
            </div>
            <div className="space-y-1">
              {activeCustomModules.map((mod) => {
                const targetId: NavSection = `custom:${mod.id}`;
                const isActive = activeSection === targetId;
                return (
                  <button
                    key={mod.id}
                    type="button"
                    onClick={() => handleSelectNav(targetId)}
                    className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                      isActive
                        ? themeTokens.sidebarActive
                        : `${themeTokens.sidebarText} ${themeTokens.sidebarHover}`
                    }`}
                  >
                    <Boxes className="h-4 w-4 shrink-0" />
                    <span className="truncate">{mod.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </nav>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Mobile / Drawer overlay */}
      {drawerOpen && (
        <div className="fixed inset-0 z-40 flex no-print">
          <div
            className="fixed inset-0 bg-slate-900/50"
            onClick={() => setDrawerOpen(false)}
            aria-hidden="true"
          />
          <aside className={`relative z-50 w-68 max-w-[82vw] ${themeTokens.sidebarBg} shadow-xl`}>
            <button
              type="button"
              onClick={() => setDrawerOpen(false)}
              aria-label="Close navigation menu"
              className="absolute top-4 end-3 rounded-lg p-1.5 text-slate-300 hover:bg-white/10 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
            {renderSidebarNav()}
          </aside>
        </div>
      )}

      <div className={`flex flex-1 min-h-screen ${isMobileMode ? 'justify-center bg-slate-200/70' : ''}`}>
        {/* Desktop Persistent Sidebar */}
        {!isMobileMode && (
          <aside
            className={`hidden lg:flex lg:w-64 lg:shrink-0 lg:flex-col sticky top-0 h-screen ${themeTokens.sidebarBg} no-print`}
          >
            {renderSidebarNav()}
          </aside>
        )}

        {/* Main Viewport */}
        <div
          className={`flex-1 flex flex-col min-w-0 ${
            isMobileMode ? 'w-full max-w-[430px] bg-slate-50 shadow-sm min-h-screen border-x border-slate-200' : ''
          }`}
        >
          {/* Top Header */}
          <header className="sticky top-0 z-30 flex items-center justify-between gap-4 bg-white border-b border-slate-200 px-4 sm:px-6 h-14 no-print">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setDrawerOpen(true)}
                aria-label="Open navigation menu"
                className={`${isMobileMode ? 'inline-flex' : 'inline-flex lg:hidden'} items-center justify-center rounded-lg p-2 text-slate-700 hover:bg-slate-100`}
              >
                <Menu className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() => navigate('dashboard')}
                className={`${isMobileMode ? 'flex' : 'flex lg:hidden'} items-center gap-2 min-w-0`}
              >
                <span
                  className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-xs font-bold text-white ${themeTokens.brandBadgeBg}`}
                >
                  SU
                </span>
                <span className="text-sm font-bold text-slate-900 truncate">
                  {state.settings.appName}
                </span>
              </button>
              <div className={`${isMobileMode ? 'hidden' : 'hidden lg:flex'} items-center gap-2 text-sm`}>
                <span className="font-semibold text-slate-900">{currentSectionTitle}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {activeSection !== 'dashboard' && (
                <button
                  type="button"
                  onClick={() => navigate('dashboard')}
                  className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                >
                  {tr('nav_dashboard')}
                </button>
              )}
              <button
                type="button"
                onClick={() => navigate('backup')}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium text-white whitespace-nowrap shrink-0 ${themeTokens.accentBg} ${themeTokens.accentHover}`}
              >
                {tr('nav_backup')}
              </button>
            </div>
          </header>

          {/* Main Content */}
          <main className={`flex-1 min-w-0 ${isMobileMode ? 'p-3.5 pb-8' : 'p-4 sm:p-6 lg:p-8 max-w-[1360px] w-full mx-auto'}`}>
            {children}
          </main>
        </div>
      </div>

      {/* Toast Notifications */}
      {toasts.length > 0 && (
        <div
          className="fixed bottom-4 end-4 z-50 flex flex-col gap-2 max-w-sm no-print"
          aria-live="polite"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`flex items-center justify-between gap-3 rounded-lg border px-4 py-3 text-sm font-medium shadow-md ${
                toast.type === 'error'
                  ? 'bg-red-50 border-red-200 text-red-800'
                  : toast.type === 'info'
                    ? 'bg-slate-800 border-slate-700 text-white'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}
            >
              <span>{toast.text}</span>
              <button
                type="button"
                onClick={() => dismissToast(toast.id)}
                aria-label="Dismiss notification"
                className="opacity-70 hover:opacity-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
