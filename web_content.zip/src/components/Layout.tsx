import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  BarChart3, BookOpenCheck, CalendarRange, ClipboardList, Database, GraduationCap,
  LayoutDashboard, Library, LogOut, Menu, MessageCircleQuestion, Moon, Repeat2, Settings, Sun, X,
} from 'lucide-react';
import { useAuth, useTheme } from '../lib/auth';
import { cn, initials } from '../lib/utils';
import { Badge, IconButton } from './ui';
import { EXAM_SHORT } from '../lib/utils';

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/teacher', label: 'AI Teacher', icon: GraduationCap },
  { to: '/doubts', label: 'Doubt Solver', icon: MessageCircleQuestion },
  { to: '/planner', label: 'Study Planner', icon: CalendarRange },
  { to: '/resources', label: 'My Resources', icon: Library },
  { to: '/tests', label: 'Test Centre', icon: ClipboardList },
  { to: '/bank', label: 'Question Bank', icon: Database },
  { to: '/revision', label: 'Revision Centre', icon: Repeat2 },
  { to: '/analytics', label: 'Performance', icon: BarChart3 },
  { to: '/profile', label: 'Profile & Settings', icon: Settings },
];

const TITLES: Record<string, { title: string; subtitle: string }> = {
  '/dashboard': { title: 'Dashboard', subtitle: 'Your preparation at a glance' },
  '/teacher': { title: 'AI Teacher', subtitle: 'Learn any chapter at your level' },
  '/doubts': { title: 'Doubt Solver', subtitle: 'Concepts first, answers second' },
  '/planner': { title: 'Study Planner', subtitle: 'A timetable that fits your real day' },
  '/resources': { title: 'My Resources', subtitle: 'Your books, notes and papers — searchable' },
  '/tests': { title: 'Test Centre', subtitle: 'Generate, attempt and review papers' },
  '/bank': { title: 'Question Bank', subtitle: 'Practice by chapter, difficulty and source' },
  '/revision': { title: 'Revision Centre', subtitle: 'Spaced repetition and mistake review' },
  '/analytics': { title: 'Performance Analytics', subtitle: 'Evidence from your own attempts' },
  '/profile': { title: 'Profile & Settings', subtitle: 'Your academic profile and preferences' },
};

export function AppLayout() {
  const { profile, user, logout, aiEnabled } = useAuth();
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => setOpen(false), [location.pathname]);

  const meta = TITLES[location.pathname] ??
    (location.pathname.startsWith('/tests') || location.pathname.startsWith('/attempts')
      ? { title: 'Test Centre', subtitle: 'Timed practice and detailed review' }
      : { title: 'EduMentor AI', subtitle: '' });

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[260px_1fr]">
      {/* sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 w-[260px] border-r border-line bg-surface/95 backdrop-blur transition-transform lg:static lg:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="flex h-full flex-col p-4">
          <div className="mb-6 flex items-center justify-between px-1">
            <NavLink to="/dashboard" className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand/15 text-brand ring-1 ring-inset ring-brand/30">
                <BookOpenCheck size={19} />
              </span>
              <span>
                <span className="block font-display text-[15px] font-extrabold leading-tight tracking-tight text-ink">EduMentor AI</span>
                <span className="block text-[10px] font-medium uppercase tracking-[0.14em] text-muted">Academic mentor</span>
              </span>
            </NavLink>
            <IconButton label="Close menu" className="lg:hidden" onClick={() => setOpen(false)}><X size={18} /></IconButton>
          </div>

          <nav className="flex-1 space-y-1 overflow-y-auto scroll-thin">
            {NAV.map(({ to, label, icon: Icon }) => (
              <NavLink key={to} to={to} className={({ isActive }) => cn('navlink', isActive && 'navlink-active')}>
                <Icon size={17} />
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="mt-4 space-y-3 rounded-xl border border-line bg-elevated/50 p-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-muted">Target</span>
              <Badge tone="brand">{EXAM_SHORT[profile?.exam ?? ''] ?? 'Not set'}</Badge>
            </div>
            {profile?.examDate && (
              <p className="text-xs text-muted">
                Exam on <span className="font-semibold text-ink">{new Date(profile.examDate + 'T00:00:00Z').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' })}</span>
              </p>
            )}
            <div className="flex items-center gap-2 border-t border-line pt-2.5">
              <span className={cn('h-2 w-2 rounded-full', aiEnabled ? 'bg-ok' : 'bg-warn')} />
              <span className="text-[11px] text-muted">{aiEnabled ? 'AI connected' : 'AI key not set'}</span>
            </div>
          </div>
        </div>
      </aside>

      {open && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setOpen(false)} aria-hidden />}

      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-20 border-b border-line bg-bg/80 backdrop-blur">
          <div className="flex items-center gap-3 px-4 py-3.5 sm:px-6">
            <IconButton label="Open menu" className="lg:hidden" onClick={() => setOpen(true)}><Menu size={20} /></IconButton>
            <div className="min-w-0 flex-1">
              <h1 className="truncate font-display text-lg font-bold tracking-tight text-ink sm:text-xl">{meta.title}</h1>
              {meta.subtitle && <p className="hidden truncate text-xs text-muted sm:block">{meta.subtitle}</p>}
            </div>
            <IconButton label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'} onClick={toggle}>
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </IconButton>
            <button
              onClick={() => navigate('/profile')}
              className="flex items-center gap-2 rounded-xl border border-line bg-elevated/60 py-1.5 pl-1.5 pr-3 text-left transition hover:border-brand/40"
              title="Profile and settings"
            >
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-brand/15 text-[11px] font-bold text-brand">
                {initials(user?.name ?? 'S')}
              </span>
              <span className="hidden text-xs font-semibold text-ink sm:block">{user?.name?.split(' ')[0] ?? 'Student'}</span>
            </button>
          </div>
        </header>

        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8 pb-20 lg:pb-6">
          <div className="mx-auto w-full max-w-7xl animate-fade-up">
            <Outlet />
          </div>
        </main>

        {/* Mobile Bottom Navigation Bar */}
        <nav className="fixed bottom-0 inset-x-0 z-30 flex items-center justify-around border-t border-line bg-surface/95 backdrop-blur py-1.5 px-2 lg:hidden">
          {[
            { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { to: '/teacher', label: 'Teacher', icon: GraduationCap },
            { to: '/planner', label: 'Planner', icon: CalendarRange },
            { to: '/tests', label: 'Tests', icon: ClipboardList },
            { to: '/bank', label: 'Bank', icon: Database },
          ].map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                cn(
                  'flex flex-col items-center justify-center gap-0.5 py-1 px-2.5 rounded-xl text-[10px] font-medium transition',
                  isActive ? 'text-brand font-bold' : 'text-muted hover:text-ink',
                )
              }
            >
              <Icon size={19} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <footer className="hidden lg:block border-t border-line px-6 py-4 text-center text-[11px] text-muted">
          EduMentor AI · Progress shown here comes from your own saved activity. AI guidance can be wrong — verify with your textbook.
        </footer>
      </div>
    </div>
  );
}
