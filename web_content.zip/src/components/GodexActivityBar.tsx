/**
 * GODEX Phase 0 - Left Activity Bar
 * Vertical navigation rail with top & bottom system tabs
 */

import React from 'react';
import { 
  FolderTree, 
  Search, 
  Layers, 
  Database, 
  GitBranch, 
  ShieldCheck, 
  Settings, 
  Cpu,
  Bot,
  LayoutDashboard,
  Code2,
  Terminal,
  Activity,
  Compass,
  Package
} from 'lucide-react';
import { SidebarViewId, WorkspaceViewMode } from '../types';

interface GodexActivityBarProps {
  activeSidebarView: SidebarViewId | null;
  onToggleSidebarView: (view: SidebarViewId) => void;
  activeWorkspaceView: WorkspaceViewMode;
  onSelectWorkspaceView: (view: WorkspaceViewMode) => void;
  onOpenSettings: () => void;
}

export const GodexActivityBar: React.FC<GodexActivityBarProps> = ({
  activeSidebarView,
  onToggleSidebarView,
  activeWorkspaceView,
  onSelectWorkspaceView,
  onOpenSettings
}) => {
  const topNavItems: Array<{ id: SidebarViewId; icon: React.ReactNode; label: string; shortcut: string }> = [
    { id: 'mission-control', icon: <Compass className="w-4 h-4 text-indigo-400" />, label: 'Mission Control', shortcut: '⌘ 1' },
    { id: 'explorer', icon: <FolderTree className="w-4 h-4" />, label: 'Project Explorer', shortcut: '⌘ B' },
    { id: 'search', icon: <Search className="w-4 h-4" />, label: 'Search in Workspace', shortcut: '⌘ Shift F' },
    { id: 'symbols', icon: <Compass className="w-4 h-4" />, label: 'Symbols Navigator', shortcut: '⌘ Shift O' },
    { id: 'dependencies', icon: <Package className="w-4 h-4" />, label: 'Dependencies', shortcut: '⌘ Shift D' },
    { id: 'architecture', icon: <Layers className="w-4 h-4" />, label: 'Architecture Intelligence', shortcut: '⌘ 4' },
    { id: 'memory', icon: <Database className="w-4 h-4" />, label: 'Project Memory Vault', shortcut: '⌘ 5' },
    { id: 'git', icon: <GitBranch className="w-4 h-4" />, label: 'Git & Version Snapshots', shortcut: '⌘ 6' },
    { id: 'verification', icon: <ShieldCheck className="w-4 h-4" />, label: 'Verification Matrix', shortcut: '⌘ Shift V' },
  ];

  return (
    <aside className="w-12 h-full bg-[#07080B] border-r border-[#171C26] flex flex-col justify-between items-center py-2 shrink-0 select-none z-20">
      {/* Top Section: GODEX Brand + Nav buttons */}
      <div className="flex flex-col items-center gap-1.5 w-full">
        {/* Brand Icon / Home button */}
        <button
          onClick={() => onSelectWorkspaceView('dashboard')}
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all mb-2 ${
            activeWorkspaceView === 'dashboard'
              ? 'bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white shadow-md shadow-cyan-950/80 ring-1 ring-cyan-400/50'
              : 'bg-[#10141F] hover:bg-[#161C2A] text-cyan-400 border border-[#1E2536]'
          }`}
          title="GODEX Dashboard (Home)"
        >
          <Bot className="w-4 h-4" />
        </button>

        <div className="w-5 h-px bg-[#181E2C] my-1" />

        {/* Primary Sidebar Panels */}
        {topNavItems.map((item) => {
          const isActive = activeSidebarView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onToggleSidebarView(item.id)}
              className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors relative group ${
                isActive
                  ? 'bg-[#141A26] text-cyan-300 border border-cyan-500/40 shadow-xs shadow-cyan-950/40'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0F131C]'
              }`}
              title={`${item.label} (${item.shortcut})`}
            >
              {item.icon}
              {isActive && (
                <span className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-r bg-cyan-400" />
              )}
              {/* Tooltip on hover */}
              <div className="absolute left-full ml-2 px-2 py-1 bg-[#0E121A] border border-[#222B3D] text-white text-[11px] font-sans rounded shadow-lg whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50">
                <span className="font-medium">{item.label}</span>
                <span className="ml-2 text-[9px] font-mono text-neutral-400">{item.shortcut}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Bottom Section: Settings & Quick Status */}
      <div className="flex flex-col items-center gap-1.5 w-full">
        <div className="w-5 h-px bg-[#181E2C] my-1" />

        <button
          onClick={onOpenSettings}
          className="w-9 h-9 rounded-lg flex items-center justify-center text-neutral-400 hover:text-cyan-300 hover:bg-[#0F131C] transition-colors relative group"
          title="Settings & Model Configuration"
        >
          <Settings className="w-4 h-4" />
          <div className="absolute left-full ml-2 px-2 py-1 bg-[#0E121A] border border-[#222B3D] text-white text-[11px] font-sans rounded shadow-lg whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50">
            <span>Settings</span>
          </div>
        </button>
      </div>
    </aside>
  );
};
