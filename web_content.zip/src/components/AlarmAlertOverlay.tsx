import { AnimatePresence, motion } from 'motion/react';
import { BellRing, BookOpen, Clock } from 'lucide-react';
import type { StudyAlarm } from '../types';
import { TactileButton } from './InteractiveButton';

interface AlarmAlertOverlayProps {
  alarm: StudyAlarm | null;
  onStartStudy: (alarm: StudyAlarm) => void;
  onSnoozeTenMinutes: (alarm: StudyAlarm) => void;
}

export function AlarmAlertOverlay({
  alarm,
  onStartStudy,
  onSnoozeTenMinutes,
}: AlarmAlertOverlayProps) {
  return (
    <AnimatePresence>
      {alarm && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-4"
          role="alertdialog"
          aria-modal="true"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 18 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 12 }}
            className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border-2 border-violet-500/70 p-6 sm:p-8 shadow-2xl text-center space-y-5"
          >
            <motion.div
              animate={{ rotate: [0, -14, 14, -10, 10, 0], scale: [1, 1.08, 1] }}
              transition={{ repeat: Infinity, duration: 1.4, ease: 'easeInOut' }}
              className="w-20 h-20 mx-auto rounded-3xl bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300 flex items-center justify-center"
            >
              <BellRing className="w-10 h-10" />
            </motion.div>

            <div className="space-y-1.5">
              <p className="text-xs sm:text-sm font-bold text-violet-600 dark:text-violet-400">
                منبه المذاكرة الآن · <span className="font-mono-num">{alarm.time}</span>
              </p>
              <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white break-words">
                {alarm.title}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                حان وقت التركيز وإنجاز مهمتك الدراسية!
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <TactileButton
                type="button"
                onClick={() => onStartStudy(alarm)}
                className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 min-h-[48px]"
              >
                <BookOpen className="w-4 h-4" />
                <span>ابدأ المذاكرة</span>
              </TactileButton>

              <TactileButton
                type="button"
                onClick={() => onSnoozeTenMinutes(alarm)}
                className="w-full py-3 px-4 rounded-2xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm flex items-center justify-center gap-2 min-h-[48px]"
              >
                <Clock className="w-4 h-4" />
                <span>تأجيل 10 دقائق</span>
              </TactileButton>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
