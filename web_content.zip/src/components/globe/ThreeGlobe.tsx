import { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface ThreeGlobeProps {
  interactive?: boolean;
  onSelectCity?: (cityName: string) => void;
  className?: string;
}

export function ThreeGlobe({ onSelectCity, className = '' }: ThreeGlobeProps) {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Dimensions
    const width = container.clientWidth || 360;
    const height = container.clientHeight || 360;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 210;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
    } catch {
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Globe Group
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // 1. Core Sphere (Dark Navy)
    const sphereGeo = new THREE.SphereGeometry(60, 48, 48);
    const sphereMat = new THREE.MeshBasicMaterial({
      color: 0x070e24,
      transparent: true,
      opacity: 0.85,
    });
    const coreSphere = new THREE.Mesh(sphereGeo, sphereMat);
    globeGroup.add(coreSphere);

    // 2. Wireframe / Latitude Longitude Grid (Electric Blue)
    const wireGeo = new THREE.SphereGeometry(60.2, 24, 24);
    const wireMat = new THREE.MeshBasicMaterial({
      color: 0x0066ff,
      wireframe: true,
      transparent: true,
      opacity: 0.22,
    });
    const wireSphere = new THREE.Mesh(wireGeo, wireMat);
    globeGroup.add(wireSphere);

    // 3. Atmosphere Glow Outer Sphere
    const atmosGeo = new THREE.SphereGeometry(64, 32, 32);
    const atmosMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      transparent: true,
      opacity: 0.08,
      side: THREE.BackSide,
    });
    const atmosSphere = new THREE.Mesh(atmosGeo, atmosMat);
    globeGroup.add(atmosSphere);

    // Helper: Convert Lat/Long to 3D Vector
    const latLongToVector3 = (lat: number, lon: number, radius: number): THREE.Vector3 => {
      const phi = (90 - lat) * (Math.PI / 180);
      const theta = (lon + 180) * (Math.PI / 180);
      const x = -(radius * Math.sin(phi) * Math.cos(theta));
      const z = radius * Math.sin(phi) * Math.sin(theta);
      const y = radius * Math.cos(phi);
      return new THREE.Vector3(x, y, z);
    };

    // 4. Dot Matrix Continents (Distributed Points representing World Lands)
    const dotCoords: [number, number][] = [
      // North Africa / Algeria (Algiers)
      [36.75, 3.05], [35.69, -0.63], [32.0, 3.0], [28.0, 2.0], [24.0, 5.0], [30.0, 9.0],
      // Mediterranean / Southern Europe
      [41.0, 28.97], // Istanbul
      [48.85, 2.35], // Paris
      [41.9, 12.5],  // Rome
      [40.4, -3.7],  // Madrid
      [37.9, 23.7],  // Athens
      // Middle East & Gulf
      [25.2, 55.27], // Dubai
      [21.4, 39.8],  // Mecca
      [24.7, 46.6],  // Riyadh
      [25.3, 51.5],  // Doha
      [23.6, 58.5],  // Muscat
      [30.0, 31.2],  // Cairo
      // Asia
      [3.13, 101.68], // Kuala Lumpur
      [1.35, 103.8],  // Singapore
      [13.7, 100.5],  // Bangkok
      [35.6, 139.7],  // Tokyo
      [40.18, 44.51], // Yerevan (Armenia)
      // Americas
      [40.7, -74.0],  // New York
      [25.7, -80.2],  // Miami
      [-23.5, -46.6], // Sao Paulo
      // Africa
      [-1.29, 36.8],  // Nairobi
      [-33.9, 18.4],  // Cape Town
      [6.5, 3.3],     // Lagos
      [14.7, -17.4],  // Dakar
    ];

    // Add extra random land points around key continents
    const allPoints: THREE.Vector3[] = [];
    dotCoords.forEach(([lat, lon]) => {
      allPoints.push(latLongToVector3(lat, lon, 60.8));
      // Add cluster dots around major hubs
      for (let i = 0; i < 4; i++) {
        const offsetLat = lat + (Math.random() - 0.5) * 6;
        const offsetLon = lon + (Math.random() - 0.5) * 6;
        allPoints.push(latLongToVector3(offsetLat, offsetLon, 60.8));
      }
    });

    const pointsGeo = new THREE.BufferGeometry().setFromPoints(allPoints);
    const pointsMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 2.2,
      transparent: true,
      opacity: 0.9,
    });
    const pointsMesh = new THREE.Points(pointsGeo, pointsMat);
    globeGroup.add(pointsMesh);

    // 5. Featured Destination Pins
    const hubs = [
      { name: 'الجزائر (ALG)', lat: 36.75, lon: 3.05, color: 0x00f0ff },
      { name: 'إسطنبول (IST)', lat: 41.0, lon: 28.97, color: 0x38bdf8 },
      { name: 'باريس (CDG)', lat: 48.85, lon: 2.35, color: 0x60a5fa },
      { name: 'دبي (DXB)', lat: 25.2, lon: 55.27, color: 0x00f0ff },
      { name: 'مكة المكرمة', lat: 21.4, lon: 39.8, color: 0x34d399 },
    ];

    hubs.forEach((hub) => {
      const pos = latLongToVector3(hub.lat, hub.lon, 61.2);
      // Pin dot
      const pinGeo = new THREE.SphereGeometry(1.4, 16, 16);
      const pinMat = new THREE.MeshBasicMaterial({ color: hub.color });
      const pin = new THREE.Mesh(pinGeo, pinMat);
      pin.position.copy(pos);
      globeGroup.add(pin);

      // Pulse ring around pin
      const ringGeo = new THREE.RingGeometry(1.8, 2.6, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: hub.color,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.position.copy(pos);
      ring.lookAt(new THREE.Vector3(0, 0, 0));
      globeGroup.add(ring);
    });

    // 6. Glowing Flight Arcs (ALG -> IST, ALG -> CDG, ALG -> DXB)
    const routes = [
      { from: [36.75, 3.05], to: [41.0, 28.97], color: 0x00f0ff }, // Algiers to Istanbul
      { from: [36.75, 3.05], to: [48.85, 2.35], color: 0x38bdf8 },  // Algiers to Paris
      { from: [36.75, 3.05], to: [25.2, 55.27], color: 0x0066ff }, // Algiers to Dubai
    ];

    routes.forEach((route) => {
      const v1 = latLongToVector3(route.from[0], route.from[1], 61);
      const v2 = latLongToVector3(route.to[0], route.to[1], 61);

      // Mid point raised outward
      const mid = v1.clone().add(v2).multiplyScalar(0.5);
      const distance = v1.distanceTo(v2);
      mid.normalize().multiplyScalar(61 + distance * 0.35);

      const curve = new THREE.QuadraticBezierCurve3(v1, mid, v2);
      const curvePoints = curve.getPoints(50);
      const curveGeo = new THREE.BufferGeometry().setFromPoints(curvePoints);
      const curveMat = new THREE.LineBasicMaterial({
        color: route.color,
        transparent: true,
        opacity: 0.65,
        linewidth: 2,
      });
      const arcLine = new THREE.Line(curveGeo, curveMat);
      globeGroup.add(arcLine);
    });

    // Default orientation facing Algiers & Mediterranean
    globeGroup.rotation.y = 1.2;
    globeGroup.rotation.x = 0.25;

    // Animation & Touch Interaction
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let autoRotate = true;
    let animationFrameId: number;

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      isDragging = true;
      autoRotate = false;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      prevMouseX = clientX;
      prevMouseY = clientY;
    };

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      const deltaX = clientX - prevMouseX;
      const deltaY = clientY - prevMouseY;
      globeGroup.rotation.y += deltaX * 0.005;
      globeGroup.rotation.x += deltaY * 0.005;
      prevMouseX = clientX;
      prevMouseY = clientY;
    };

    const handlePointerUp = () => {
      isDragging = false;
      setTimeout(() => {
        autoRotate = true;
      }, 3000);
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('mousedown', handlePointerDown);
    domElement.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    domElement.addEventListener('touchstart', handlePointerDown, { passive: true });
    domElement.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('touchend', handlePointerUp);

    // Render loop
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (autoRotate) {
        globeGroup.rotation.y += 0.0025;
      }
      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      domElement.removeEventListener('mousedown', handlePointerDown);
      domElement.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      domElement.removeEventListener('touchstart', handlePointerDown);
      domElement.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
      window.removeEventListener('resize', handleResize);

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      sphereGeo.dispose();
      sphereMat.dispose();
      wireGeo.dispose();
      wireMat.dispose();
      atmosGeo.dispose();
      atmosMat.dispose();
      pointsGeo.dispose();
      pointsMat.dispose();
    };
  }, [onSelectCity]);

  return (
    <div
      ref={mountRef}
      className={`relative w-full h-[260px] md:h-[300px] flex items-center justify-center cursor-grab active:cursor-grabbing select-none ${className}`}
      data-testid="three-globe"
      aria-label="3D Interactive Globe for TAKI-GO"
    >
      {/* Soft Ambient Backdrop Light */}
      <div className="absolute inset-0 bg-radial from-cyan-500/10 via-transparent to-transparent pointer-events-none rounded-full blur-2xl" />
    </div>
  );
}
