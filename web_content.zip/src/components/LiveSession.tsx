import React, { useEffect, useRef, useState } from 'react';
import { X, Mic, MicOff, Bot, User, Camera, CameraOff } from 'lucide-react';
import { streamChatResponse, ChatMessage } from '../services/gemini';
import { cn } from '../utils/cn';

interface LiveSessionProps {
  isOpen: boolean;
  onClose: () => void;
}

type Voice = 'Kore' | 'Puck'; // Female | Male

export function LiveSession({ isOpen, onClose }: LiveSessionProps) {
  const [status, setStatus] = useState<'idle' | 'connected' | 'speaking' | 'thinking' | 'error'>('idle');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState<Voice>('Kore');
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [cameraPermissionDenied, setCameraPermissionDenied] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string>('');
  const [aiSpeech, setAiSpeech] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);

  const recognitionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoStreamRef = useRef<MediaStream | null>(null);
  const isMutedRef = useRef(isMuted);
  const statusRef = useRef(status);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    statusRef.current = status;
  }, [status]);

  useEffect(() => {
    if (!isOpen) {
      stopSession();
    } else {
      setPermissionDenied(false);
      setErrorMessage(null);
      setTranscript('');
      setAiSpeech('');
      setChatHistory([]);
    }
    return () => stopSession();
  }, [isOpen]);

  const speakText = (text: string) => {
    if (!('speechSynthesis' in window) || isMutedRef.current) return;
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'hi-IN';
    utterance.rate = 1.0;
    utterance.pitch = selectedVoice === 'Kore' ? 1.1 : 0.9;

    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => 
      selectedVoice === 'Kore' 
        ? (v.name.includes('Female') || v.name.includes('Google हिन्दी') || v.lang.includes('hi') || v.lang.includes('en-IN'))
        : (v.name.includes('Male') || v.name.includes('David') || v.lang.includes('hi') || v.lang.includes('en-IN'))
    );
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onstart = () => {
      setStatus('speaking');
    };

    utterance.onend = () => {
      setStatus('connected');
    };

    utterance.onerror = () => {
      setStatus('connected');
    };

    window.speechSynthesis.speak(utterance);
  };

  const handleUserQuery = async (userText: string) => {
    if (!userText.trim() || statusRef.current === 'thinking') return;
    setStatus('thinking');
    setAiSpeech('');

    let imagePayload: string[] | undefined = undefined;
    if (isVideoOn && videoRef.current && canvasRef.current) {
      try {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          canvasRef.current.width = videoRef.current.videoWidth || 640;
          canvasRef.current.height = videoRef.current.videoHeight || 480;
          ctx.drawImage(videoRef.current, 0, 0);
          const frame = canvasRef.current.toDataURL('image/jpeg', 0.6);
          imagePayload = [frame];
        }
      } catch (err) {
        console.warn("Could not grab camera frame:", err);
      }
    }

    try {
      const persona = selectedVoice === 'Kore' ? 'Female' : 'Male';
      const stream = streamChatResponse(chatHistory, userText, imagePayload, 'gemini-3.1-flash-lite', persona);
      let accumulated = '';

      for await (const chunk of stream) {
        if (chunk.error) {
          throw new Error(chunk.error);
        }
        accumulated += chunk.text || '';
        setAiSpeech(accumulated);
      }

      setChatHistory(prev => [
        ...prev, 
        { role: 'user', content: userText, images: imagePayload }, 
        { role: 'model', content: accumulated }
      ]);
      speakText(accumulated);
    } catch (err: any) {
      console.error("Live session query error:", err);
      setStatus('connected');
      setAiSpeech("Maaf kijiye, main abhi sun nahi paayi. Kripya dubara kahiye.");
    }
  };

  const startSession = async () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorMessage("Voice recognition is not supported in this browser. Please use the microphone in chat.");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Stop the test mic stream
      stream.getTracks().forEach(t => t.stop());

      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'hi-IN';

      recognition.onresult = (event: any) => {
        if (isMutedRef.current || statusRef.current === 'thinking' || statusRef.current === 'speaking') {
          return;
        }

        let currentTranscript = '';
        let isFinal = false;

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const trans = event.results[i][0].transcript;
          currentTranscript += trans;
          if (event.results[i].isFinal) {
            isFinal = true;
          }
        }

        setTranscript(currentTranscript);

        if (isFinal && currentTranscript.trim().length > 1) {
          handleUserQuery(currentTranscript.trim());
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
          setPermissionDenied(true);
        } else if (event.error !== 'no-speech') {
          console.warn("Speech recognition error:", event.error);
        }
      };

      recognition.onend = () => {
        if (statusRef.current !== 'idle') {
          try {
            recognition.start();
          } catch (_) {}
        }
      };

      recognition.start();
      recognitionRef.current = recognition;
      setStatus('connected');
      if (!isVideoOn) {
        toggleVideo();
      }
      speakText(selectedVoice === 'Kore' ? "Namaste! Main India GPT hoon. Kahiye, main aapki kya madad kar sakti hoon?" : "Namaste! Main India GPT hoon. Kahiye, kya madad karoon?");
    } catch (err: any) {
      if (err.name === 'NotAllowedError' || err.message?.includes('Permission')) {
        setPermissionDenied(true);
      } else {
        setErrorMessage("Microphone access failed. Please check permissions.");
      }
    }
  };

  const stopSession = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (_) {}
      recognitionRef.current = null;
    }
    if (videoStreamRef.current) {
      videoStreamRef.current.getTracks().forEach(t => t.stop());
      videoStreamRef.current = null;
    }
    setIsVideoOn(false);
    setStatus('idle');
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (!isMuted && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  };

  const toggleVideo = async () => {
    if (isVideoOn) {
      if (videoStreamRef.current) {
        videoStreamRef.current.getTracks().forEach(t => t.stop());
        videoStreamRef.current = null;
      }
      setIsVideoOn(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: { ideal: 'environment' } } 
        });
        videoStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setIsVideoOn(true);
        setCameraPermissionDenied(false);
      } catch (err: any) {
        console.warn("Camera access state in LiveSession:", err?.message || err);
        setCameraPermissionDenied(true);
      }
    }
  };

  if (!isOpen) return null;

  if (errorMessage) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm animate-fade-in">
        <div className="w-full max-w-md bg-slate-900 rounded-3xl p-8 shadow-2xl border border-slate-800 flex flex-col items-center text-center relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-slate-800"
          >
            <X size={24} />
          </button>
          
          <div className="w-16 h-16 bg-red-500/20 text-red-500 rounded-full flex items-center justify-center mb-4">
            <MicOff size={32} />
          </div>
          
          <h2 className="text-xl font-bold text-white mb-2">Connection Notice</h2>
          <p className="text-slate-400 mb-6 text-sm">
            {errorMessage}
          </p>
          
          <div className="flex gap-3">
            <button 
              onClick={onClose}
              className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
            >
              Close
            </button>
            <button 
              onClick={() => {
                setErrorMessage(null);
                startSession();
              }}
              className="px-6 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors font-medium"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (permissionDenied) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm animate-fade-in">
        <div className="w-full max-w-md bg-slate-900 rounded-3xl p-8 shadow-2xl border border-slate-800 flex flex-col items-center text-center relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-slate-800"
          >
            <X size={24} />
          </button>
          
          <div className="w-16 h-16 bg-red-500/20 text-red-500 rounded-full flex items-center justify-center mb-4">
            <MicOff size={32} />
          </div>
          
          <h2 className="text-xl font-bold text-white mb-2">Microphone Access Denied</h2>
          <p className="text-slate-400 mb-4 text-sm">
            Microphone access is required for real-time voice conversation.
          </p>
          <div className="bg-slate-800/50 rounded-xl p-4 mb-6 text-left w-full">
            <p className="text-xs text-slate-300 font-semibold mb-2 uppercase tracking-wider">How to fix:</p>
            <ol className="text-xs text-slate-400 space-y-2 list-decimal pl-4">
              <li>Click the <b>Lock</b> or <b>Settings</b> icon in your browser address bar.</li>
              <li>Allow <b>Microphone</b> access.</li>
              <li>Click <b>Retry</b> below.</li>
            </ol>
          </div>
          
          <div className="flex gap-3 w-full">
            <button 
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors font-medium"
            >
              Close
            </button>
            <button 
              onClick={() => {
                setPermissionDenied(false);
                startSession();
              }}
              className="flex-1 px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-xl transition-colors font-bold shadow-lg shadow-orange-900/20"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (cameraPermissionDenied) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm animate-fade-in">
        <div className="w-full max-w-md bg-slate-900 rounded-3xl p-8 shadow-2xl border border-slate-800 flex flex-col items-center text-center relative">
          <button 
            onClick={() => setCameraPermissionDenied(false)}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-slate-800"
          >
            <X size={24} />
          </button>
          
          <div className="w-16 h-16 bg-red-500/20 text-red-500 rounded-full flex items-center justify-center mb-4">
            <CameraOff size={32} />
          </div>
          
          <h2 className="text-xl font-bold text-white mb-2">Camera Access Denied</h2>
          <p className="text-slate-400 mb-4 text-sm">
            Please allow camera access in browser settings to share your video feed with India GPT.
          </p>
          
          <div className="flex gap-3 w-full">
            <button 
              onClick={() => setCameraPermissionDenied(false)}
              className="flex-1 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors font-medium"
            >
              Cancel
            </button>
            <button 
              onClick={() => {
                setCameraPermissionDenied(false);
                toggleVideo();
              }}
              className="flex-1 px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-xl transition-colors font-bold shadow-lg shadow-orange-900/20"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (status === 'idle' && !permissionDenied) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm animate-fade-in">
        <div className="w-full max-w-md bg-slate-900 rounded-3xl p-8 shadow-2xl border border-slate-800 flex flex-col items-center text-center relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-slate-800"
          >
            <X size={24} />
          </button>
          
          <div className="w-24 h-24 bg-gradient-to-br from-orange-500 to-pink-600 rounded-full flex items-center justify-center mb-6 shadow-lg animate-pulse">
            <Mic size={48} className="text-white" />
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-2">Start Voice Session</h2>
          <p className="text-slate-400 mb-8 max-w-xs text-sm">
            Talk naturally in Hindi or English. Select your assistant's voice persona below.
          </p>

          {/* Voice Selection */}
          <div className="grid grid-cols-2 gap-3 w-full mb-8">
            <button
              onClick={() => setSelectedVoice('Kore')}
              className={cn(
                "flex flex-col items-center gap-2 p-3 rounded-xl border transition-all",
                selectedVoice === 'Kore' 
                  ? "bg-slate-800 border-orange-500 text-white shadow-md ring-1 ring-orange-500" 
                  : "bg-slate-800/50 border-transparent text-slate-400 hover:bg-slate-800"
              )}
            >
              <Bot size={24} className={selectedVoice === 'Kore' ? "text-orange-500" : "text-slate-500"} />
              <span className="text-sm font-medium">Female Persona</span>
            </button>
            <button
              onClick={() => setSelectedVoice('Puck')}
              className={cn(
                "flex flex-col items-center gap-2 p-3 rounded-xl border transition-all",
                selectedVoice === 'Puck' 
                  ? "bg-slate-800 border-orange-500 text-white shadow-md ring-1 ring-orange-500" 
                  : "bg-slate-800/50 border-transparent text-slate-400 hover:bg-slate-800"
              )}
            >
              <User size={24} className={selectedVoice === 'Puck' ? "text-orange-500" : "text-slate-500"} />
              <span className="text-sm font-medium">Male Persona</span>
            </button>
          </div>
          
          <button 
            onClick={startSession}
            className="w-full py-4 bg-white text-slate-900 font-bold rounded-2xl hover:bg-slate-200 transition-transform hover:scale-[1.02] shadow-xl flex items-center justify-center gap-2 text-lg cursor-pointer"
          >
            <Mic size={24} />
            Start Conversation
          </button>
          
          <p className="mt-4 text-xs text-slate-500">
            Uses your browser's microphone with instant Hinglish AI replies
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-800 flex flex-col items-center relative overflow-hidden h-[540px] justify-between">
        
        {/* Header */}
        <div className="w-full flex justify-between items-start z-10">
           <div className="flex items-center gap-2">
              <div className={cn(
                "w-2.5 h-2.5 rounded-full animate-pulse", 
                status === 'speaking' ? "bg-orange-500" : status === 'thinking' ? "bg-yellow-400" : "bg-green-500"
              )} />
              <span className="text-xs font-medium text-slate-300 uppercase tracking-wider">
                {status === 'speaking' ? 'GPT Speaking...' : status === 'thinking' ? 'Thinking...' : 'Listening...'}
              </span>
           </div>
           <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white transition-colors rounded-full hover:bg-slate-800 cursor-pointer"
          >
            <X size={24} />
          </button>
        </div>

        {/* Main Visualizer / Video */}
        <div className="flex-1 flex flex-col items-center justify-center w-full relative my-4">
          <video ref={videoRef} autoPlay playsInline muted className="hidden" />
          <canvas ref={canvasRef} className="hidden" />

          {isVideoOn ? (
             <div className="absolute inset-0 w-full h-full flex items-center justify-center rounded-2xl overflow-hidden bg-black border border-slate-700">
                <video 
                  ref={(ref) => {
                    if (ref && videoStreamRef.current) {
                      ref.srcObject = videoStreamRef.current;
                    }
                  }}
                  autoPlay 
                  playsInline 
                  muted 
                  className="w-full h-full object-cover" 
                />
             </div>
          ) : (
            <div className="relative w-56 h-56 flex items-center justify-center">
              {status === 'speaking' && (
                <>
                  <div className="absolute inset-0 bg-orange-500/20 rounded-full animate-ping" style={{ animationDuration: '2.5s' }} />
                  <div className="absolute inset-6 bg-pink-500/20 rounded-full animate-ping" style={{ animationDuration: '1.8s', animationDelay: '0.4s' }} />
                </>
              )}
              
              <div className={cn(
                "w-36 h-36 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 z-10 relative overflow-hidden",
                status === 'speaking' ? "bg-gradient-to-br from-orange-500 to-pink-600 scale-105" : "bg-slate-800 border border-slate-700",
                isMuted && "grayscale opacity-50 scale-95"
              )}>
                <div className="text-white z-10 flex flex-col items-center gap-2">
                   {isMuted ? (
                     <MicOff size={36} />
                   ) : (
                     <div className="flex items-center gap-1.5 h-10">
                       {[1, 2, 3, 4, 5].map(i => (
                         <div 
                           key={i} 
                           className="w-1.5 bg-white rounded-full transition-all duration-150 animate-pulse"
                           style={{ 
                             height: status === 'speaking' 
                               ? `${30 + (i % 3) * 25}%` 
                               : status === 'thinking'
                               ? `${20 + (i % 2) * 20}%`
                               : '25%',
                             animationDelay: `${i * 100}ms`
                           }}
                         />
                       ))}
                     </div>
                   )}
                </div>
              </div>
            </div>
          )}
          
          <div className="text-center mt-3 z-10 px-4 max-w-sm">
             <h3 className="text-white font-semibold text-base">India GPT</h3>
             <p className="text-slate-300 text-xs mt-1 min-h-[32px] line-clamp-2 italic">
               {status === 'speaking' 
                 ? aiSpeech 
                 : transcript 
                 ? `"${transcript}"` 
                 : isMuted 
                 ? "Microphone is muted" 
                 : isVideoOn 
                 ? "Watching and listening..." 
                 : "Say something in Hindi or English..."}
             </p>
          </div>
        </div>

        {/* Controls */}
        <div className="w-full flex items-center justify-center gap-6 pb-2 z-10">
          <button
            onClick={toggleMute}
            className={cn(
              "w-12 h-12 flex items-center justify-center rounded-full transition-all shadow-lg border-2 cursor-pointer",
              isMuted 
                ? "bg-white text-slate-900 border-white hover:bg-slate-200" 
                : "bg-slate-800/90 text-white border-slate-600 hover:bg-slate-700"
            )}
            title={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
          </button>

          <button
            onClick={onClose}
            className="w-14 h-14 flex items-center justify-center rounded-full bg-red-500 text-white hover:bg-red-600 shadow-lg transition-transform hover:scale-105 border-2 border-red-500 cursor-pointer"
            title="End Call"
          >
            <X size={28} />
          </button>

          <button
            onClick={toggleVideo}
            className={cn(
              "w-12 h-12 flex items-center justify-center rounded-full transition-all shadow-lg border-2 cursor-pointer",
              isVideoOn 
                ? "bg-white text-slate-900 border-white hover:bg-slate-200" 
                : "bg-slate-800/90 text-white border-slate-600 hover:bg-slate-700"
            )}
            title={isVideoOn ? "Turn Camera Off" : "Turn Camera On"}
          >
            {isVideoOn ? <CameraOff size={20} /> : <Camera size={20} />}
          </button>
        </div>
      </div>
    </div>
  );
}
