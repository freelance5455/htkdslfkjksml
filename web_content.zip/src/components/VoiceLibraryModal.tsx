import React, { useState, useEffect } from "react";
import { X, Search, Volume2, Check, Loader2 } from "lucide-react";
import { VoiceItem } from "../types";
import { fetchVoices } from "../lib/api";

interface VoiceLibraryModalProps {
  isOpen: boolean;
  selectedVoiceId: string;
  onSelectVoice: (voice: VoiceItem) => void;
  onClose: () => void;
}

export const VoiceLibraryModal: React.FC<VoiceLibraryModalProps> = ({
  isOpen,
  selectedVoiceId,
  onSelectVoice,
  onClose,
}) => {
  const [voices, setVoices] = useState<VoiceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState<string>("All");
  const [previewingVoiceId, setPreviewingVoiceId] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    let isMounted = true;
    setLoading(true);

    fetchVoices()
      .then((data) => {
        if (isMounted) {
          setVoices(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error("Error loading voices:", err);
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // Extract unique languages
  const languages = ["All", ...Array.from(new Set(voices.map((v) => v.language)))];

  // Filter voices
  const filteredVoices = voices.filter((voice) => {
    const matchesLang = selectedLanguage === "All" || voice.language === selectedLanguage;
    const matchesSearch =
      voice.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voice.style.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voice.language.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voice.accent.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesLang && matchesSearch;
  });

  const handlePreviewVoice = (voice: VoiceItem) => {
    setPreviewingVoiceId(voice.id);
    // Synthetic tone preview or speech synthesis if supported
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(
        `Hello, I am ${voice.name}. This is a preview of my voice in VEW AI Studio.`
      );
      utterance.rate = 1.0;
      utterance.onend = () => setPreviewingVoiceId(null);
      utterance.onerror = () => setPreviewingVoiceId(null);
      window.speechSynthesis.speak(utterance);
    } else {
      setTimeout(() => setPreviewingVoiceId(null), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Voice Library</h3>
            <p className="text-xs text-slate-400">Select studio voice model ({voices.length} available)</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Language Filter */}
        <div className="p-4 border-b border-slate-800/80 space-y-3 bg-slate-900/50">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search voices, styles, languages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-800/80 border border-slate-700/80 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Language filter pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {languages.map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLanguage(lang)}
                className={`px-3 py-1 rounded-full text-xs whitespace-nowrap transition-all ${
                  selectedLanguage === lang
                    ? "bg-blue-600 text-white font-semibold shadow-sm"
                    : "bg-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Voice Cards List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center space-y-2 text-slate-400">
              <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
              <span className="text-xs">Loading available voices...</span>
            </div>
          ) : filteredVoices.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              No voices found matching your search.
            </div>
          ) : (
            filteredVoices.map((voice) => {
              const isSelected = selectedVoiceId === voice.id;
              const isPreviewing = previewingVoiceId === voice.id;

              return (
                <div
                  key={voice.id}
                  className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                    isSelected
                      ? "bg-blue-950/40 border-blue-500/60 shadow-md shadow-blue-500/10"
                      : "bg-slate-800/60 hover:bg-slate-800 border-slate-700/70"
                  }`}
                >
                  <div className="space-y-1 flex-1 pr-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-semibold text-white">{voice.name}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-700 text-slate-300 font-medium">
                        {voice.language}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400">
                        {voice.gender}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">{voice.style}</p>
                    <p className="text-[11px] text-slate-500">{voice.accent}</p>
                  </div>

                  {/* Actions: Preview & Select */}
                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <button
                      type="button"
                      onClick={() => handlePreviewVoice(voice)}
                      title="Preview Voice"
                      className={`p-2 rounded-xl text-xs transition-colors flex items-center gap-1 ${
                        isPreviewing
                          ? "bg-indigo-600 text-white animate-pulse"
                          : "bg-slate-700/80 hover:bg-slate-700 text-slate-300"
                      }`}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onSelectVoice(voice);
                        onClose();
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all ${
                        isSelected
                          ? "bg-emerald-600 text-white"
                          : "bg-blue-600 hover:bg-blue-500 text-white active:scale-95"
                      }`}
                    >
                      {isSelected ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> Selected
                        </>
                      ) : (
                        "Select"
                      )}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-900/80 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
