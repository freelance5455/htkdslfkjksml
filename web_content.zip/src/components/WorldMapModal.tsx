import React, { useEffect, useRef, useState } from 'react';
import { Compass, MapPin, Plus, Trash2, X, ZoomIn, ZoomOut } from 'lucide-react';
import { QUESTS } from '../game/data/entities';
import { DiscoveredLocation, MapMarker, QuestProgress } from '../game/types';
import { BIOMES, getBiomeIdAt, getWorldHeight, WATER_LEVEL } from '../game/world/biomes';
import { CHUNK_SIZE } from '../game/world/chunkManager';

interface WorldMapModalProps {
  open: boolean;
  seed: number;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  discoveredChunks: string[];
  discoveredLocations: DiscoveredLocation[];
  mapMarkers: MapMarker[];
  quests: Record<string, QuestProgress>;
  onClose: () => void;
  onAddMarker: (x: number, z: number, labelAr: string, colorHex: string) => void;
  onRemoveMarker: (id: string) => void;
}

const CANVAS_W = 540;
const CANVAS_H = 380;

const PIN_COLORS = [
  { label: 'ذهبي', hex: '#fbbf24' },
  { label: 'أحمر', hex: '#f43f5e' },
  { label: 'سماوي', hex: '#38bdf8' },
  { label: 'أخضر', hex: '#34d399' },
];

export const WorldMapModal: React.FC<WorldMapModalProps> = ({
  open,
  seed,
  playerX,
  playerZ,
  playerYaw,
  discoveredChunks,
  discoveredLocations,
  mapMarkers,
  quests,
  onClose,
  onAddMarker,
  onRemoveMarker,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [zoom, setZoom] = useState(1.25); // px per meter
  const [center, setCenter] = useState<{ x: number; z: number }>({ x: playerX, z: playerZ });
  const [pinMode, setPinMode] = useState(false);
  const [pinLabel, setPinLabel] = useState('علامة استكشاف');
  const [pinColor, setPinColor] = useState(PIN_COLORS[0].hex);
  const dragRef = useRef<{ active: boolean; lastX: number; lastY: number; moved: boolean }>({
    active: false,
    lastX: 0,
    lastY: 0,
    moved: false,
  });

  useEffect(() => {
    if (open) {
      setCenter({ x: playerX, z: playerZ });
    }
  }, [open, playerX, playerZ]);

  useEffect(() => {
    if (!open) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#070d19';
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    const discoveredSet = new Set(discoveredChunks);
    const stepPx = 4;
    const halfW = CANVAS_W / 2;
    const halfH = CANVAS_H / 2;

    // Render explored terrain only (true Fog of War)
    for (let py = 0; py < CANVAS_H; py += stepPx) {
      for (let px = 0; px < CANVAS_W; px += stepPx) {
        const wx = center.x + (px - halfW) / zoom;
        const wz = center.z + (py - halfH) / zoom;
        const cx = Math.floor(wx / CHUNK_SIZE + 0.5);
        const cz = Math.floor(wz / CHUNK_SIZE + 0.5);
        if (!discoveredSet.has(`${cx},${cz}`)) continue;

        const h = getWorldHeight(wx, wz, seed);
        if (h < WATER_LEVEL) {
          ctx.fillStyle = '#1e6e9e';
        } else {
          const b = BIOMES[getBiomeIdAt(wx, wz, seed)];
          ctx.fillStyle = `#${b.groundHex.toString(16).padStart(6, '0')}`;
        }
        ctx.fillRect(px, py, stepPx, stepPx);
      }
    }

    // Subtle chunk grid over explored area
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.08)';
    ctx.lineWidth = 1;
    for (const key of discoveredChunks) {
      const [cxStr, czStr] = key.split(',');
      const cx = Number(cxStr);
      const cz = Number(czStr);
      const wx = (cx - 0.5) * CHUNK_SIZE;
      const wz = (cz - 0.5) * CHUNK_SIZE;
      const sx = halfW + (wx - center.x) * zoom;
      const sy = halfH + (wz - center.z) * zoom;
      const sizePx = CHUNK_SIZE * zoom;
      ctx.strokeRect(sx, sy, sizePx, sizePx);
    }

    // Draw Discovered Locations only
    for (const loc of discoveredLocations) {
      const sx = halfW + (loc.x - center.x) * zoom;
      const sy = halfH + (loc.z - center.z) * zoom;
      if (sx < -20 || sx > CANVAS_W + 20 || sy < -20 || sy > CANVAS_H + 20) continue;

      const color =
        loc.kind === 'village'
          ? '#fbbf24'
          : loc.kind === 'castle'
            ? '#a855f7'
            : loc.kind === 'ruin'
              ? '#e2e8f0'
              : loc.kind === 'cave'
                ? '#38bdf8'
                : '#f43f5e';

      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(sx, sy, 5.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.6;
      ctx.stroke();

      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(loc.nameAr, sx, sy - 9);
    }

    // Draw Custom Map Markers
    for (const m of mapMarkers) {
      const sx = halfW + (m.x - center.x) * zoom;
      const sy = halfH + (m.z - center.z) * zoom;
      if (sx < -20 || sx > CANVAS_W + 20 || sy < -20 || sy > CANVAS_H + 20) continue;
      ctx.fillStyle = m.colorHex;
      ctx.beginPath();
      ctx.moveTo(sx, sy - 8);
      ctx.lineTo(sx + 6, sy + 2);
      ctx.lineTo(sx, sy + 7);
      ctx.lineTo(sx - 6, sy + 2);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1.4;
      ctx.stroke();

      ctx.fillStyle = '#fde68a';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(m.labelAr, sx, sy - 11);
    }

    // Draw Player Arrow
    const px = halfW + (playerX - center.x) * zoom;
    const py = halfH + (playerZ - center.z) * zoom;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(-playerYaw);
    ctx.fillStyle = '#fef08a';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(6.5, 6);
    ctx.lineTo(0, 3);
    ctx.lineTo(-6.5, 6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }, [open, seed, playerX, playerZ, playerYaw, zoom, center, discoveredChunks, discoveredLocations, mapMarkers]);

  if (!open) return null;

  const activeQuests = QUESTS.filter((q) => quests[q.id]?.accepted && !quests[q.id]?.claimed);

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-3 sm:p-5"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="hud-scroll flex max-h-[92vh] w-full max-w-4xl flex-col overflow-y-auto rounded-2xl border border-amber-500/35 bg-slate-900 text-slate-100 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <Compass className="h-5 w-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-amber-100">خريطة عالم إيثيريا</h2>
              <p className="text-[11px] text-slate-400">
                تظهر المناطق التي استكشفتها فقط • اسحب لتحريك الخريطة أو انقر لوضع علامة
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-300 hover:bg-slate-700"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 p-4 lg:grid-cols-3">
          {/* Interactive Map Canvas */}
          <div className="flex flex-col gap-2.5 lg:col-span-2">
            <div className="relative overflow-hidden rounded-xl border border-slate-700 bg-slate-950">
              <canvas
                ref={canvasRef}
                width={CANVAS_W}
                height={CANVAS_H}
                className={`w-full select-none touch-none ${pinMode ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'}`}
                onPointerDown={(e) => {
                  dragRef.current = { active: true, lastX: e.clientX, lastY: e.clientY, moved: false };
                }}
                onPointerMove={(e) => {
                  if (!dragRef.current.active) return;
                  const dx = e.clientX - dragRef.current.lastX;
                  const dy = e.clientY - dragRef.current.lastY;
                  if (Math.hypot(dx, dy) > 4) dragRef.current.moved = true;
                  dragRef.current.lastX = e.clientX;
                  dragRef.current.lastY = e.clientY;
                  const rect = e.currentTarget.getBoundingClientRect();
                  const scaleX = CANVAS_W / Math.max(1, rect.width);
                  const scaleY = CANVAS_H / Math.max(1, rect.height);
                  setCenter((prev) => ({
                    x: prev.x - (dx * scaleX) / zoom,
                    z: prev.z - (dy * scaleY) / zoom,
                  }));
                }}
                onPointerUp={(e) => {
                  const wasMoved = dragRef.current.moved;
                  dragRef.current.active = false;
                  if (!wasMoved && pinMode) {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const px = ((e.clientX - rect.left) / Math.max(1, rect.width)) * CANVAS_W;
                    const py = ((e.clientY - rect.top) / Math.max(1, rect.height)) * CANVAS_H;
                    const wx = center.x + (px - CANVAS_W / 2) / zoom;
                    const wz = center.z + (py - CANVAS_H / 2) / zoom;
                    onAddMarker(wx, wz, pinLabel.trim() || 'علامة', pinColor);
                    setPinMode(false);
                  }
                }}
                onPointerLeave={() => {
                  dragRef.current.active = false;
                }}
              />

              {/* Zoom + Recenter Controls */}
              <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.min(3.0, z + 0.35))}
                  className="rounded-lg border border-slate-700 bg-slate-900/90 p-1.5 text-slate-200 hover:bg-slate-800"
                  title="تكبير"
                >
                  <ZoomIn className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.max(0.45, z - 0.35))}
                  className="rounded-lg border border-slate-700 bg-slate-900/90 p-1.5 text-slate-200 hover:bg-slate-800"
                  title="تصغير"
                >
                  <ZoomOut className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setCenter({ x: playerX, z: playerZ })}
                  className="rounded-lg border border-amber-500/40 bg-slate-900/90 px-2.5 py-1.5 text-[11px] font-bold text-amber-200 hover:bg-slate-800"
                >
                  موقعي
                </button>
              </div>
            </div>

            {/* Pin Tool Bar */}
            <div className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-800 bg-slate-950/60 p-2.5 text-xs">
              <button
                type="button"
                onClick={() => setPinMode((v) => !v)}
                className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 font-bold transition ${
                  pinMode
                    ? 'border-amber-400 bg-amber-500/25 text-amber-100'
                    : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Plus className="h-3.5 w-3.5" />
                {pinMode ? 'انقر على الخريطة لوضع العلامة' : 'إضافة علامة مخصصة'}
              </button>
              <input
                type="text"
                value={pinLabel}
                onChange={(e) => setPinLabel(e.target.value)}
                maxLength={22}
                placeholder="اسم العلامة..."
                className="flex-1 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1.5 text-xs text-slate-100"
              />
              <div className="flex items-center gap-1">
                {PIN_COLORS.map((c) => (
                  <button
                    key={c.hex}
                    type="button"
                    onClick={() => setPinColor(c.hex)}
                    className={`h-5 w-5 rounded-full border-2 ${pinColor === c.hex ? 'border-white scale-110' : 'border-slate-700'}`}
                    style={{ backgroundColor: c.hex }}
                    title={c.label}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Right Sidebar: Legend, Discovered Locations, Markers, Quests */}
          <div className="flex flex-col gap-3 text-xs">
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className="mb-2 font-bold text-amber-300">المعالم المكتشفة ({discoveredLocations.length})</div>
              <div className="max-h-36 space-y-1.5 overflow-y-auto">
                {discoveredLocations.map((loc) => (
                  <button
                    key={loc.id}
                    type="button"
                    onClick={() => setCenter({ x: loc.x, z: loc.z })}
                    className="flex w-full items-center justify-between rounded-lg border border-slate-800 bg-slate-900/70 px-2.5 py-1.5 text-right hover:border-amber-500/40"
                  >
                    <span className="font-semibold text-slate-100">{loc.nameAr}</span>
                    <span className="font-mono text-[10px] text-slate-400" dir="ltr">
                      {loc.x}, {loc.z}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className="mb-2 flex items-center gap-1.5 font-bold text-sky-300">
                <MapPin className="h-3.5 w-3.5" />
                <span>العلامات المخصصة ({mapMarkers.length})</span>
              </div>
              {mapMarkers.length === 0 ? (
                <div className="text-[11px] text-slate-500">لا توجد علامات مخصصة بعد.</div>
              ) : (
                <div className="max-h-28 space-y-1 overflow-y-auto">
                  {mapMarkers.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900/70 px-2.5 py-1"
                    >
                      <button
                        type="button"
                        onClick={() => setCenter({ x: m.x, z: m.z })}
                        className="flex items-center gap-1.5 text-right"
                      >
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: m.colorHex }} />
                        <span>{m.labelAr}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveMarker(m.id)}
                        className="text-rose-400 hover:text-rose-300"
                        title="حذف العلامة"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className="mb-1.5 font-bold text-emerald-300">المهام الجارية ({activeQuests.length})</div>
              {activeQuests.length === 0 ? (
                <div className="text-[11px] text-slate-500">تحدث مع الحكيم أوريون في القرية لقبول مهام.</div>
              ) : (
                <div className="space-y-1.5">
                  {activeQuests.map((q) => {
                    const prog = quests[q.id];
                    return (
                      <div key={q.id} className="rounded-lg border border-slate-800 bg-slate-900/70 p-2">
                        <div className="font-bold text-slate-100">{q.titleAr}</div>
                        <div className="text-[10px] text-slate-400">
                          التقدم: {prog.progress} / {q.targetCount}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-2.5 text-[10px] text-slate-400">
              المناطق المكتشفة: {discoveredChunks.length} قطاع • إحداثياتك: ({playerX}, {playerZ})
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
