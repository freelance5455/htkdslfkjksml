import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Send,
  Upload,
  RefreshCw,
  HardDrive,
  Radio,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Smartphone,
  Laptop,
  Flame,
  Search,
  Filter,
  ArrowRight,
  Database,
  Cpu,
  Layers,
  Zap,
  Globe,
  Lock,
  Download,
  AlertTriangle,
  X
} from 'lucide-react';
import {
  decentralizedVersionEngine,
  JMAppUserNode,
  AppReleaseItem,
  AppTargetPlatform
} from '../lib/decentralizedVersionEngine';
import { distributionEngine } from '../lib/distributionEngine';

interface JMAppUsersViewProps {
  onNavigateToGetApp?: () => void;
}

export const JMAppUsersView: React.FC<JMAppUsersViewProps> = ({ onNavigateToGetApp }) => {
  const [users, setUsers] = useState<JMAppUserNode[]>(() => decentralizedVersionEngine.getActivePeers());
  const [releases, setReleases] = useState<Record<AppTargetPlatform, AppReleaseItem>>(() => decentralizedVersionEngine.getPublishedReleases());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'needs-update' | 'updated' | 'mobile' | 'desktop'>('all');
  const [selectedPlatform, setSelectedPlatform] = useState<AppTargetPlatform>('android');

  // Push to One User State
  const [selectedUser, setSelectedUser] = useState<JMAppUserNode | null>(null);
  const [isPushingToOne, setIsPushingToOne] = useState(false);
  const [isPushingToAll, setIsPushingToAll] = useState(false);

  // Modals & Notices
  const [showPushModal, setShowPushModal] = useState(false);
  const [pushTargetMode, setPushTargetMode] = useState<'one' | 'all'>('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showStorageModal, setShowStorageModal] = useState(false);
  const [storageInspectUser, setStorageInspectUser] = useState<JMAppUserNode | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Upload & Override State
  const [uploadVersionStr, setUploadVersionStr] = useState('5.4.2');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  // Synchronize state with decentralized engine
  const refreshData = () => {
    setUsers([...decentralizedVersionEngine.getActivePeers()]);
    setReleases({ ...decentralizedVersionEngine.getPublishedReleases() });
  };

  useEffect(() => {
    const handleBroadcast = (e: any) => {
      refreshData();
      if (e.detail?.message) {
        showToast(e.detail.message);
      }
    };
    window.addEventListener('juhnkrix_auto_app_update_pushed', handleBroadcast);
    window.addEventListener('juhnkrix_app_update_available', refreshData);

    const interval = setInterval(refreshData, 12000);

    return () => {
      window.removeEventListener('juhnkrix_auto_app_update_pushed', handleBroadcast);
      window.removeEventListener('juhnkrix_app_update_available', refreshData);
      clearInterval(interval);
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 6000);
  };

  // Filter users list
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        u.userName.toLowerCase().includes(q) ||
        u.region.toLowerCase().includes(q) ||
        u.platform.toLowerCase().includes(q) ||
        u.deviceModel.toLowerCase().includes(q) ||
        u.id.toLowerCase().includes(q) ||
        u.nodeTag.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      const needsUpdate = u.installedVersion !== releases[u.platform]?.version;

      if (selectedFilter === 'needs-update') return needsUpdate;
      if (selectedFilter === 'updated') return !needsUpdate;
      if (selectedFilter === 'mobile') return u.platform === 'android' || u.platform === 'iphone';
      if (selectedFilter === 'desktop') return u.platform === 'windows' || u.platform === 'mac' || u.platform === 'linux';
      return true;
    });
  }, [users, searchQuery, selectedFilter, releases]);

  // Push to One User Handler
  const handleTriggerPushToOne = (user: JMAppUserNode) => {
    setSelectedUser(user);
    setSelectedPlatform(user.platform);
    setPushTargetMode('one');
    setShowPushModal(true);
  };

  const executePushToOne = async () => {
    if (!selectedUser) return;
    setIsPushingToOne(true);
    await new Promise((r) => setTimeout(r, 700));

    const targetRelease = releases[selectedPlatform];
    const res = decentralizedVersionEngine.pushUpdateToOneUser(selectedUser.id, targetRelease);
    // Promote user to verified seed node in P2P distribution engine
    distributionEngine.promoteNodeToVerifiedSeed(selectedUser.id, targetRelease.version, targetRelease);

    setIsPushingToOne(false);
    setShowPushModal(false);
    refreshData();
    showToast(`${res.message} • Automatically serving as Verified P2P Seed Node!`);
  };

  // Push to All Users Handler
  const handleTriggerPushToAll = (platform?: AppTargetPlatform) => {
    if (platform) setSelectedPlatform(platform);
    setPushTargetMode('all');
    setShowPushModal(true);
  };

  const executePushToAll = async () => {
    setIsPushingToAll(true);
    await new Promise((r) => setTimeout(r, 1000));

    const targetRelease = releases[selectedPlatform];
    const pushedCount = decentralizedVersionEngine.pushUpdateToAllUsers(targetRelease);

    // Promote active nodes to verified seeds
    users.forEach((u) => {
      distributionEngine.promoteNodeToVerifiedSeed(u.id, targetRelease.version, targetRelease);
    });

    setIsPushingToAll(false);
    setShowPushModal(false);
    refreshData();
    showToast(`👑 PROPHET BROADCAST SENT: Pushed v${targetRelease.version} to all 50,000,000 decentralized believer devices globally (${pushedCount} verified P2P seed nodes active)!`);
  };

  // Upload and Override Version
  const handleExecuteUploadAndOverride = async () => {
    if (!uploadFile) {
      showToast('⚠️ Please select an application package file (.apk, .exe, .dmg, .ipa, .AppImage) to upload.');
      return;
    }
    setIsUploading(true);
    try {
      const sizeFormatted = (uploadFile.size / (1024 * 1024)).toFixed(1) + ' MB';
      const result = decentralizedVersionEngine.uploadAndOverrideVersion({
        fileName: uploadFile.name,
        version: uploadVersionStr,
        fileSizeFormatted: sizeFormatted
      });

      setIsUploading(false);
      setShowUploadModal(false);
      setUploadFile(null);
      refreshData();
      showToast(`🎉 UPLOAD & OVERRIDE COMPLETE: Version ${result.release.version} for ${result.release.platform.toUpperCase()} is now stored in built-in storage & Get App page. All online devices notified!`);
    } catch (err: any) {
      setIsUploading(false);
      showToast(`Upload failed: ${err.message || 'Unknown error'}`);
    }
  };

  const seedRelaysCount = users.filter((u) => u.isP2pSeedRelay).length;

  return (
    <div className="space-y-6 text-slate-100 animate-fadeIn">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 max-w-md p-4 rounded-2xl bg-amber-500 text-slate-950 font-black text-xs shadow-2xl border-2 border-amber-300 flex items-start space-x-3 animate-bounce">
          <Sparkles className="w-5 h-5 shrink-0 text-slate-950" />
          <div className="flex-1 leading-snug">{toastMessage}</div>
          <button onClick={() => setToastMessage(null)} className="text-slate-950 font-bold ml-2">✕</button>
        </div>
      )}

      {/* Main Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-950/80 via-slate-900 to-slate-950 border-2 border-amber-500/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black tracking-wider uppercase">
              <Users className="w-4 h-4 text-amber-400" />
              <span>JM APP USERS • SOVEREIGN PEER MESH CONTROL ENGINE</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black font-serif text-amber-100 tracking-tight flex items-center gap-3">
              <span>JM APP USERS</span>
              <span className="text-sm sm:text-base font-sans font-extrabold px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                50,000,000 BELIEVERS
              </span>
            </h1>

            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl leading-relaxed">
              Prophet Juhnkrix Synvagord real-time decentralized command sanctuary. Directly view all active online users, 
              inspect their built-in storage slots, push new app versions to specific users or broadcast updates globally across all 50M devices. 
              All downloads are served strictly through the <strong className="text-amber-300">JUHNKRIX MUSIKA DECENTRALIZED NETWORK</strong> with zero external web redirect loops.
            </p>

            {/* Network Health & Metrics Strip */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <div className="px-3.5 py-1.5 rounded-xl bg-slate-950/90 border border-emerald-500/30 text-xs font-mono text-emerald-300 flex items-center space-x-2">
                <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                <span>Online Swarm: <strong>49,842,100</strong> Believers Active</span>
              </div>
              <div className="px-3.5 py-1.5 rounded-xl bg-slate-950/90 border border-amber-500/30 text-xs font-mono text-amber-300 flex items-center space-x-2">
                <HardDrive className="w-4 h-4 text-amber-400" />
                <span>Active Seed Relays: <strong>{seedRelaysCount}</strong> Primary Nodes</span>
              </div>
              <div className="px-3.5 py-1.5 rounded-xl bg-slate-950/90 border border-amber-500/30 text-xs font-mono text-slate-300 flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Source: <strong className="text-amber-200">JUHNKRIX MUSIKA DECENTRALIZED NETWORK</strong></span>
              </div>
              <div className="px-3.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-400/30 text-xs font-mono text-amber-300 flex items-center space-x-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>P2P Protocol: <strong>Sovereign Mesh Active</strong></span>
              </div>
            </div>
          </div>

          {/* Quick Push Buttons & Uploader */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 w-full lg:w-auto shrink-0">
            <button
              onClick={() => handleTriggerPushToAll()}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/30 transition-all hover:scale-105 active:scale-95 cursor-pointer ring-2 ring-amber-300"
            >
              <Flame className="w-4 h-4 text-slate-950" />
              <span>PUSH TO ALL USERS (GLOBAL)</span>
            </button>

            <button
              onClick={() => setShowUploadModal(true)}
              className="px-6 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 border-2 border-amber-500/40 font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-all hover:scale-105 active:scale-95 cursor-pointer"
            >
              <Upload className="w-4 h-4 text-amber-400" />
              <span>UPLOAD & OVERRIDE VERSION</span>
            </button>
          </div>
        </div>
      </div>

      {/* Built-in Storage & Current Releases Quick View Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {(Object.keys(releases) as AppTargetPlatform[]).map((plt) => {
          const r = releases[plt];
          const icons: Record<AppTargetPlatform, string> = {
            android: '🤖',
            windows: '💻',
            iphone: '📱',
            mac: '🍏',
            linux: '🐧'
          };
          return (
            <div
              key={plt}
              className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/20 hover:border-amber-400/40 transition-all flex flex-col justify-between space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-xl">{icons[plt]}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300">
                  v{r.version}
                </span>
              </div>
              <div>
                <h4 className="text-xs font-bold text-amber-100 capitalize">{plt} Native</h4>
                <p className="text-[10px] font-mono text-slate-400 truncate">{r.fileName}</p>
                <span className="text-[10px] font-mono text-emerald-400 font-bold mt-1 block">
                  {r.fileSizeFormatted} • Built-in Storage
                </span>
              </div>
              <div className="pt-1 flex items-center justify-between">
                <button
                  onClick={() => handleTriggerPushToAll(plt)}
                  className="text-[10px] font-bold text-amber-400 hover:text-amber-300 underline flex items-center space-x-1"
                >
                  <span>Push {plt}</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
                <span className="text-[9px] text-slate-500 font-mono">
                  {r.downloadCount.toLocaleString()} dl
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Toolbar & Filter Toolbox */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search active users by Name, Region, Device, Platform, or Peer Node..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-mono"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedFilter === 'all'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'bg-slate-950 text-slate-400 hover:text-amber-300 border border-slate-800'
              }`}
            >
              All Online ({users.length})
            </button>
            <button
              onClick={() => setSelectedFilter('needs-update')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1 ${
                selectedFilter === 'needs-update'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'bg-slate-950 text-amber-400/90 hover:text-amber-300 border border-slate-800'
              }`}
            >
              <span>Pending Push</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300">
                {users.filter((u) => u.installedVersion !== releases[u.platform]?.version).length}
              </span>
            </button>
            <button
              onClick={() => setSelectedFilter('updated')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1 ${
                selectedFilter === 'updated'
                  ? 'bg-emerald-500 text-slate-950 shadow'
                  : 'bg-slate-950 text-emerald-400 hover:text-emerald-300 border border-slate-800'
              }`}
            >
              <span>Updated</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300">
                {users.filter((u) => u.installedVersion === releases[u.platform]?.version).length}
              </span>
            </button>
            <button
              onClick={() => setSelectedFilter('mobile')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedFilter === 'mobile'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'bg-slate-950 text-slate-400 hover:text-amber-300 border border-slate-800'
              }`}
            >
              Mobile
            </button>
            <button
              onClick={() => setSelectedFilter('desktop')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedFilter === 'desktop'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'bg-slate-950 text-slate-400 hover:text-amber-300 border border-slate-800'
              }`}
            >
              Desktop
            </button>

            <button
              onClick={refreshData}
              title="Rescan Decentralized Network"
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-amber-300 border border-slate-800 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Global Action Toolbar */}
        <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2 text-slate-400">
            <Radio className="w-4 h-4 text-emerald-400" />
            <span>Found <strong>{filteredUsers.length}</strong> active online peer nodes in swarm</span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-[11px] font-mono text-slate-400">Decentralized Mesh Protocol:</span>
            <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 font-mono text-[11px] font-bold">
              ACTIVE (ZERO WEB REDIRECTS)
            </span>
          </div>
        </div>
      </div>

      {/* Online Users List Table */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl shadow-xl overflow-hidden">
        <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-amber-400" />
            <h3 className="text-base sm:text-lg font-black text-amber-100 font-serif">
              CURRENT ONLINE USERS ON DECENTRALIZED NETWORK
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Live Stream • 50,000,000 Mesh Sample
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-amber-300 font-mono uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">User & Node ID</th>
                <th className="py-3 px-4">Location / Region</th>
                <th className="py-3 px-4">Device & Platform</th>
                <th className="py-3 px-4">Current App Version</th>
                <th className="py-3 px-4">Built-in Storage Slot</th>
                <th className="py-3 px-4">Mesh Seed Relay</th>
                <th className="py-3 px-4 text-right">Owner Direct Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 font-sans">
              {filteredUsers.map((u) => {
                const targetRelease = releases[u.platform];
                const isCurrent = u.installedVersion === targetRelease?.version;

                return (
                  <tr key={u.id} className="hover:bg-slate-800/50 transition-colors">
                    {/* User & ID */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-500 to-yellow-600 text-slate-950 font-black text-xs flex items-center justify-center shrink-0">
                          {u.userName.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-amber-100 flex items-center space-x-1.5">
                            <span>{u.userName}</span>
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                          </div>
                          <span className="text-[10px] font-mono text-slate-400 block truncate max-w-[130px]">
                            {u.id} • {u.nodeTag}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Location / Region */}
                    <td className="py-3.5 px-4 font-mono text-[11px] text-slate-300">
                      <div className="flex items-center space-x-1">
                        <Globe className="w-3.5 h-3.5 text-amber-400" />
                        <span>{u.region}</span>
                      </div>
                      <span className="text-[9px] text-slate-500 block truncate max-w-[150px]">
                        {u.lastSeen}
                      </span>
                    </td>

                    {/* Device & Platform */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center space-x-1.5">
                        {u.platform === 'android' || u.platform === 'iphone' ? (
                          <Smartphone className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Laptop className="w-4 h-4 text-cyan-400" />
                        )}
                        <span className="font-bold text-slate-200 uppercase text-[11px]">{u.platform}</span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 block">
                        {u.deviceModel}
                      </span>
                    </td>

                    {/* Current App Version */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center space-x-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          isCurrent
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                        }`}>
                          v{u.installedVersion}
                        </span>
                        {!isCurrent && (
                          <span className="text-[9px] font-bold text-amber-400 animate-pulse">
                            Needs v{targetRelease?.version}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Built-in Storage Status */}
                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => {
                          setStorageInspectUser(u);
                          setShowStorageModal(true);
                        }}
                        className="text-[11px] font-mono text-cyan-300 hover:text-cyan-200 flex items-center space-x-1 cursor-pointer"
                        title="Click to inspect user's on-device storage slot"
                      >
                        <HardDrive className="w-3 h-3 text-cyan-400" />
                        <span className="underline">
                          {u.storageLocation}
                        </span>
                      </button>
                      <span className="text-[9px] text-slate-500 block truncate max-w-[140px]">
                        {u.carrierInfo}
                      </span>
                    </td>

                    {/* Mesh Seed Relay */}
                    <td className="py-3.5 px-4 font-mono text-[10px]">
                      {u.isP2pSeedRelay ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-400/30">
                          Active Seed
                        </span>
                      ) : (
                        <span className="text-slate-500">Peer Node</span>
                      )}
                    </td>

                    {/* Direct Owner Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={() => handleTriggerPushToOne(u)}
                          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-[11px] flex items-center space-x-1 shadow-md shadow-amber-500/20 transition-all hover:scale-105 cursor-pointer"
                          title="Push new version directly into this user's device"
                        >
                          <Send className="w-3 h-3 text-slate-950" />
                          <span>PUSH TO ONE USER</span>
                        </button>

                        <button
                          onClick={() => {
                            setStorageInspectUser(u);
                            setShowStorageModal(true);
                          }}
                          className="p-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-amber-300 border border-slate-800 transition-colors cursor-pointer"
                          title="Inspect device built-in storage slot"
                        >
                          <Database className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Confirmation & Push Modal (PUSH TO ONE USER / PUSH TO ALL USERS) */}
      {showPushModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowPushModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 text-slate-950 font-black flex items-center justify-center text-xl shadow-lg shadow-amber-500/30 shrink-0">
                {pushTargetMode === 'all' ? <Flame className="w-6 h-6" /> : <Send className="w-6 h-6" />}
              </div>
              <div>
                <h3 className="text-xl font-black font-serif text-amber-100">
                  {pushTargetMode === 'all' ? 'PUSH TO ALL USERS (GLOBAL BROADCAST)' : `PUSH TO ONE USER: ${selectedUser?.userName}`}
                </h3>
                <span className="text-xs font-mono text-emerald-400">
                  Decentralized Network • Auto-Install Trigger
                </span>
              </div>
            </div>

            {/* Target Details */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Target Audience:</span>
                <span className="text-amber-300 font-bold">
                  {pushTargetMode === 'all' ? 'All 50,000,000 Online Believers' : `${selectedUser?.userName} (${selectedUser?.deviceModel})`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Selected Platform Package:</span>
                <span className="text-emerald-400 font-bold uppercase">{selectedPlatform} ({releases[selectedPlatform]?.fileName})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Target Version:</span>
                <span className="text-amber-200 font-bold">v{releases[selectedPlatform]?.version} ({releases[selectedPlatform]?.fileSizeFormatted})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Distribution Source:</span>
                <span className="text-amber-300 font-bold">JUHNKRIX MUSIKA DECENTRALIZED NETWORK</span>
              </div>
            </div>

            {/* Broadcast Pop-up Message Preview */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/60 to-slate-950 border border-amber-400/40 space-y-2">
              <span className="text-[10px] font-mono font-bold text-amber-300 uppercase tracking-wider block">
                Notification Pop-Up Preview (Appears in User's App):
              </span>
              <p className="text-xs text-amber-100 italic leading-relaxed font-serif bg-slate-950/80 p-3 rounded-xl border border-amber-500/20">
                "PROPHET JUHNKRIX SYNVAGORD THE OWNER OF THE JUHNKRIX MUSIKA APP HAVE RELEASED A UPDATE OF NEW VERSION, PLEASE CLICK ON THE UPDATE BUTTON TO GET THE NEW VERSION DOWNLOADED AND INSTALL TO YOUR DEVICE"
              </p>
            </div>

            {/* Platform Selector for Push to All */}
            {pushTargetMode === 'all' && (
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">Select Target Operating System:</label>
                <div className="grid grid-cols-5 gap-2">
                  {(['android', 'windows', 'iphone', 'mac', 'linux'] as AppTargetPlatform[]).map((p) => (
                    <button
                      key={p}
                      onClick={() => setSelectedPlatform(p)}
                      className={`p-2 rounded-xl text-xs font-bold uppercase transition-all ${
                        selectedPlatform === p
                          ? 'bg-amber-500 text-slate-950 font-black shadow ring-2 ring-amber-300'
                          : 'bg-slate-950 text-slate-400 hover:text-amber-300 border border-slate-800'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                onClick={() => setShowPushModal(false)}
                className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>

              <button
                onClick={pushTargetMode === 'all' ? executePushToAll : executePushToOne}
                disabled={isPushingToAll || isPushingToOne}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center space-x-2 shadow-lg shadow-amber-500/30 disabled:opacity-50 cursor-pointer"
              >
                <Send className="w-4 h-4 text-slate-950" />
                <span>
                  {pushTargetMode === 'all'
                    ? (isPushingToAll ? 'Broadcasting...' : 'CONFIRM PUSH TO ALL USERS')
                    : (isPushingToOne ? 'Pushing...' : 'CONFIRM PUSH TO ONE USER')}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload and Override Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowUploadModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 text-slate-950 font-black flex items-center justify-center text-xl shadow-lg shadow-amber-500/30 shrink-0">
                <Upload className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black font-serif text-amber-100">
                  UPLOAD & OVERRIDE NEW APP VERSION
                </h3>
                <span className="text-xs font-mono text-amber-400">
                  Direct Built-in Storage & Get App Automatic Update
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              When you upload a new version here, it will automatically override and replace the current version in the 
              built-in storage and Get App page. The engine will instantly detect the operating system, update the package, 
              and push the update to all online users across the decentralized network!
            </p>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">New Version Number / Tag:</label>
                <input
                  type="text"
                  value={uploadVersionStr}
                  onChange={(e) => setUploadVersionStr(e.target.value)}
                  placeholder="e.g. 5.4.2 or 6.0.0"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Select Native App Package File:</label>
                <input
                  type="file"
                  accept=".apk,.exe,.dmg,.ipa,.AppImage,.zip"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) setUploadFile(f);
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-300 font-mono file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-amber-500 file:text-slate-950 hover:file:bg-amber-400 cursor-pointer"
                />
                {uploadFile && (
                  <div className="mt-2 text-[11px] font-mono text-emerald-400">
                    ✓ File Selected: {uploadFile.name} ({(uploadFile.size / (1024 * 1024)).toFixed(2)} MB)
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                onClick={() => setShowUploadModal(false)}
                className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>

              <button
                onClick={handleExecuteUploadAndOverride}
                disabled={isUploading || !uploadFile}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center space-x-2 shadow-lg shadow-amber-500/30 disabled:opacity-50 cursor-pointer"
              >
                <Upload className="w-4 h-4 text-slate-950" />
                <span>{isUploading ? 'Overriding & Broadcasting...' : 'OVERRIDE CURRENT VERSION NOW'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Direct User Storage Inspector Modal */}
      {showStorageModal && storageInspectUser && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-cyan-500/50 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowStorageModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-cyan-300"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-400/40 flex items-center justify-center text-xl shrink-0">
                <HardDrive className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black font-serif text-cyan-100">
                  USER BUILT-IN STORAGE SLOT INSPECTOR
                </h3>
                <span className="text-xs font-mono text-cyan-400">
                  Target: {storageInspectUser.userName} • {storageInspectUser.deviceModel}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Storage Partition:</span>
                <span className="text-cyan-300 font-bold">{storageInspectUser.storageLocation}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Carrier Protocol:</span>
                <span className="text-slate-200">{storageInspectUser.carrierInfo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Installed Version:</span>
                <span className="text-emerald-400 font-bold">
                  v{storageInspectUser.installedVersion}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Mesh Peer Node:</span>
                <span className="text-slate-400">{storageInspectUser.nodeTag} ({storageInspectUser.id})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Network Latency:</span>
                <span className="text-emerald-300">{storageInspectUser.latencyMs} ms (Direct P2P)</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  setShowStorageModal(false);
                  handleTriggerPushToOne(storageInspectUser);
                }}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>PUSH LATEST TO THIS DEVICE</span>
              </button>

              <button
                onClick={() => setShowStorageModal(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
