import React, { useState, useEffect } from "react";
import {
  X,
  Lock,
  Unlock,
  KeyRound,
  FileText,
  CheckSquare,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Youtube,
  FolderKanban,
  Check,
  RefreshCw,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Download,
  ShieldCheck,
  Layers,
  Palette
} from "lucide-react";
import { ColorNoteItem, decryptColorNoteBackupApi, isColorNoteFile } from "../utils/colorNoteParser";
import { SectionItem, ThemeAccent } from "../types";
import { THEME_ACCENTS } from "../utils/theme";
import { batchCategorizeNotesWithAI } from "../utils/categorizer";

interface ColorNoteImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  fileData?: {
    name: string;
    size: number;
    base64: string;
  } | null;
  sections: SectionItem[];
  themeAccent: ThemeAccent;
  onImportNotes: (
    newNotes: Array<{
      title: string;
      content: string;
      category: string;
      tags: string[];
      pinned: boolean;
      favorite: boolean;
      tasks: any[];
      color?: string;
      createdAt?: string;
      updatedAt?: string;
      isVault?: boolean;
    }>
  ) => void;
}

export const ColorNoteImportModal: React.FC<ColorNoteImportModalProps> = ({
  isOpen,
  onClose,
  fileData,
  sections,
  themeAccent,
  onImportNotes,
}) => {
  const [password, setPassword] = useState<string>("0000");
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isDecrypting, setIsDecrypting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [decryptedNotes, setDecryptedNotes] = useState<ColorNoteItem[]>([]);
  const [selectedNoteIds, setSelectedNoteIds] = useState<Set<string>>(new Set());
  const [targetCategory, setTargetCategory] = useState<string>("ColorNote Notları");
  const [showFallbackGuide, setShowFallbackGuide] = useState<boolean>(false);
  const [enableAICategorize, setEnableAICategorize] = useState<boolean>(true);
  const [isAICategorizing, setIsAICategorizing] = useState<boolean>(false);
  const [aiProgressText, setAiProgressText] = useState<string>("");

  const themeDef = THEME_ACCENTS[themeAccent] || THEME_ACCENTS.teal;

  // Automatically attempt decryption with "0000" on first open
  useEffect(() => {
    if (isOpen && fileData && fileData.base64 && decryptedNotes.length === 0) {
      handleDecrypt("0000");
    }
  }, [isOpen, fileData]);

  if (!isOpen || !fileData) return null;

  const handleDecrypt = async (pwdToUse?: string) => {
    const pwd = pwdToUse !== undefined ? pwdToUse : password;
    setIsDecrypting(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const result = await decryptColorNoteBackupApi(fileData.base64, pwd);
      if (result.success && result.notes && result.notes.length > 0) {
        setDecryptedNotes(result.notes);
        // Select all by default
        setSelectedNoteIds(new Set(result.notes.map((n) => n.id)));
        setSuccessMessage(`✓ ${result.notes.length} adet ColorNote notu başarıyla çözüldü!`);
        setShowFallbackGuide(false);
      } else {
        setErrorMessage(
          result.message ||
            "Şifre çözülemedi. ColorNote yedeğiniz özel bir ana parola (Master Password) ile korunuyor olabilir."
        );
        setShowFallbackGuide(true);
      }
    } catch (err: any) {
      setErrorMessage(err.message || "Bağlantı hatası oluştu.");
      setShowFallbackGuide(true);
    } finally {
      setIsDecrypting(false);
    }
  };

  const handleToggleSelectNote = (id: string) => {
    const next = new Set(selectedNoteIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedNoteIds(next);
  };

  const handleSelectAll = () => {
    if (selectedNoteIds.size === decryptedNotes.length) {
      setSelectedNoteIds(new Set());
    } else {
      setSelectedNoteIds(new Set(decryptedNotes.map((n) => n.id)));
    }
  };

  const handleExecuteImport = async () => {
    const notesToImport = decryptedNotes.filter((n) => selectedNoteIds.has(n.id));
    if (notesToImport.length === 0) return;

    const mapped = notesToImport.map((n) => {
      let formattedContent = n.content;
      if (n.isChecklist && n.tasks && n.tasks.length > 0) {
        const taskLines = n.tasks.map((t) => `- [${t.completed ? "x" : " "}] ${t.text}`).join("\n");
        if (!formattedContent.includes("- [ ]") && !formattedContent.includes("- [x]")) {
          formattedContent = `${formattedContent ? formattedContent + "\n\n" : ""}### Yapılacaklar Listesi:\n${taskLines}`;
        }
      }

      return {
        id: n.id,
        title: n.title,
        content: formattedContent,
        category: targetCategory || "ColorNote Notları",
        tags: n.tags || [],
        pinned: false,
        favorite: false,
        tasks: n.tasks || [],
        color: n.themeColor,
        createdAt: n.createdDate || new Date().toISOString(),
        updatedAt: n.modifiedDate || new Date().toISOString(),
        isVault: Boolean(n.isLocked),
      };
    });

    if (enableAICategorize) {
      setIsAICategorizing(true);
      setAiProgressText(`Yapay Zeka (Semantik Analiz) ${mapped.length} adet notu analiz ediyor...`);

      try {
        const existingCatNames = sections.map((s) => s.name);
        const { updatedNotes: aiProcessed } = await batchCategorizeNotesWithAI(
          mapped as any,
          existingCatNames,
          (processed, total) => {
            setAiProgressText(`Semantik Derin Analiz: ${processed}/${total} not kategorilendi...`);
          }
        );

        onImportNotes(aiProcessed as any);
        setSuccessMessage(`✓ ${mapped.length} adet not yapay zeka semantik kategorizasyonu ile aktarıldı!`);
      } catch (err) {
        console.warn("AI Batch Categorization during import failed, keeping original mapped notes", err);
        onImportNotes(mapped as any);
        setSuccessMessage(`✓ ${mapped.length} adet not çalışma alanınıza aktarıldı!`);
      } finally {
        setIsAICategorizing(false);
      }
    } else {
      onImportNotes(mapped as any);
      setSuccessMessage(`✓ ${mapped.length} adet not çalışma alanınıza aktarıldı!`);
    }

    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/15 dark:bg-amber-400/20 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold text-2xl border border-amber-300 dark:border-amber-700/60 shadow-xs">
              📂
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  Yedek Dosyası Geri Yükleme (.BIN / .IDX / .DOC)
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-200 dark:border-amber-800 font-mono">
                  Şifreli SQLite / ColorNote Restore
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Uygulama dışarıdan yüklenen yedek dosyasını metin olarak açmaz; içindeki şifreli SQLite veritabanını çözerek tüm notları bağımsız kartlar halinde ana ekranınıza geri yükler.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          
          {/* File Status Card */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850/70 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 flex items-center justify-center font-mono text-xs font-bold">
                .BIN
              </div>
              <div>
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {fileData.name}
                </div>
                <div className="text-[11px] text-slate-400 flex items-center gap-2">
                  <span>Boyut: {(fileData.size / 1024).toFixed(1)} KB</span>
                  <span>•</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> NOTE Başlığı Tespit Edildi
                  </span>
                </div>
              </div>
            </div>

            {/* Decrypt Status Badge */}
            <div className="flex items-center gap-2">
              {decryptedNotes.length > 0 ? (
                <span className="flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  <Unlock className="w-3.5 h-3.5" /> Şifre Çözüldü ({decryptedNotes.length} Not)
                </span>
              ) : (
                <span className="flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-xl bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                  <Lock className="w-3.5 h-3.5" /> AES-128 Şifreli
                </span>
              )}
            </div>
          </div>

          {/* Password Input & Decrypt Trigger */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-amber-500" />
                  ColorNote Yedek Parolası (Master Password)
                </label>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Otomatik ColorNote yedeklerinde varsayılan parola <span className="font-mono font-bold text-amber-600 dark:text-amber-400">"0000"</span>'dır.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="0000"
                    className="w-36 text-xs font-mono px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 text-[10px]"
                  >
                    {showPassword ? "Gizle" : "Göster"}
                  </button>
                </div>

                <button
                  onClick={() => handleDecrypt()}
                  disabled={isDecrypting}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white shadow-md transition-all active:scale-95 ${
                    isDecrypting ? "bg-slate-400 cursor-not-allowed" : "bg-amber-600 hover:bg-amber-700"
                  }`}
                >
                  {isDecrypting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Çözülüyor...</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Şifreyi Çöz</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Error message */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2 animate-in fade-in">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-500" />
                <div>
                  <div className="font-bold">Şifreleme Çözülemedi</div>
                  <div>{errorMessage}</div>
                </div>
              </div>
            )}

            {/* Success message */}
            {successMessage && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-500" />
                <span className="font-bold">{successMessage}</span>
              </div>
            )}
          </div>

          {/* Fallback Guide Accordion */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50/60 dark:bg-slate-850/40">
            <button
              onClick={() => setShowFallbackGuide(!showFallbackGuide)}
              className="w-full px-4 py-3 flex items-center justify-between text-left text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-amber-500" />
                <span>ColorNote Alternatif Dışa Aktarma Yöntemi (Şifresiz Metin / HTML)</span>
              </div>
              {showFallbackGuide ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showFallbackGuide && (
              <div className="p-4 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 space-y-2.5 bg-white dark:bg-slate-900/60">
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  ColorNote master parolanızı hatırlamıyorsanız veya dosya kilitliyse şu adımları izleyin:
                </p>
                <ol className="list-decimal list-inside space-y-1.5 pl-1">
                  <li>
                    Telefonunuzda <strong>ColorNote</strong> uygulamasını açın.
                  </li>
                  <li>
                    Sol üst köşedeki menüden <strong>Ayarlar &gt; Yedekleme</strong> kısmına girin.
                  </li>
                  <li>
                    Aktarmak istediğiniz notları açıp <strong>Paylaş / Dışa Aktar (Export as Text/HTML)</strong> seçeneğini seçin.
                  </li>
                  <li>
                    Oluşan metin veya html dosyasını doğrudan NoteFlow Belge Merkezi'ne sürükleyip bırakın.
                  </li>
                </ol>
              </div>
            )}
          </div>

          {/* Decrypted Notes List */}
          {decryptedNotes.length > 0 && (
            <div className="space-y-4">
              {/* Batch Actions & Destination Selector */}
              <div className="flex flex-col gap-3 p-3.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/50">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={handleSelectAll}
                      className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition-colors"
                    >
                      {selectedNoteIds.size === decryptedNotes.length ? "Seçimi Kaldır" : "Tümünü Seç"} ({selectedNoteIds.size}/{decryptedNotes.length})
                    </button>

                    <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
                      <span className="font-semibold">Varsayılan Kategori:</span>
                      <input
                        type="text"
                        value={targetCategory}
                        onChange={(e) => setTargetCategory(e.target.value)}
                        placeholder="Kategori adı"
                        className="text-xs px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 w-32"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-amber-900 dark:text-amber-200 bg-amber-100/80 dark:bg-amber-900/60 px-3 py-1.5 rounded-xl border border-amber-300 dark:border-amber-700/80 select-none hover:bg-amber-200/80 transition-colors">
                      <input
                        type="checkbox"
                        checked={enableAICategorize}
                        onChange={(e) => setEnableAICategorize(e.target.checked)}
                        className="rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                      />
                      <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                      <span>Yapay Zeka (Semantik Analiz) ile Otomatik Kategorile</span>
                    </label>

                    <button
                      onClick={handleExecuteImport}
                      disabled={selectedNoteIds.size === 0 || isAICategorizing}
                      className={`flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold text-white shadow-md active:scale-95 transition-all ${
                        selectedNoteIds.size === 0 || isAICategorizing
                          ? "bg-slate-400 cursor-not-allowed"
                          : `bg-gradient-to-r ${themeDef.gradient}`
                      }`}
                    >
                      {isAICategorizing ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-white" />
                          <span>Analiz Ediliyor...</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Seçili Notları İçe Aktar ({selectedNoteIds.size})</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {isAICategorizing && (
                  <div className="p-2.5 rounded-xl bg-amber-100/80 dark:bg-amber-900/40 border border-amber-300 dark:border-amber-700 text-xs text-amber-900 dark:text-amber-200 flex items-center gap-2.5 animate-pulse">
                    <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                    <span className="font-medium">{aiProgressText}</span>
                  </div>
                )}
              </div>

              {/* Notes 3-Column Grid Preview (ColorNote Style) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto pr-1">
                {decryptedNotes.map((note) => {
                  const isSelected = selectedNoteIds.has(note.id);
                  const colorClassMap: Record<string, { bg: string; border: string; strip: string }> = {
                    amber: { bg: "bg-amber-50/60 dark:bg-amber-950/30", border: "border-amber-300 dark:border-amber-700/60", strip: "bg-amber-400" },
                    blue: { bg: "bg-blue-50/60 dark:bg-blue-950/30", border: "border-blue-300 dark:border-blue-700/60", strip: "bg-blue-500" },
                    rose: { bg: "bg-rose-50/60 dark:bg-rose-950/30", border: "border-rose-300 dark:border-rose-700/60", strip: "bg-rose-500" },
                    emerald: { bg: "bg-emerald-50/60 dark:bg-emerald-950/30", border: "border-emerald-300 dark:border-emerald-700/60", strip: "bg-emerald-500" },
                    purple: { bg: "bg-purple-50/60 dark:bg-purple-950/30", border: "border-purple-300 dark:border-purple-700/60", strip: "bg-purple-500" },
                    teal: { bg: "bg-teal-50/60 dark:bg-teal-950/30", border: "border-teal-300 dark:border-teal-700/60", strip: "bg-teal-500" },
                    slate: { bg: "bg-slate-50 dark:bg-slate-850", border: "border-slate-300 dark:border-slate-700", strip: "bg-slate-400" },
                  };
                  const styling = colorClassMap[note.themeColor] || colorClassMap.amber;

                  return (
                    <div
                      key={note.id}
                      onClick={() => handleToggleSelectNote(note.id)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between overflow-hidden shadow-xs hover:shadow-md select-none ${
                        isSelected
                          ? `${styling.bg} ring-2 ring-amber-500 border-amber-500`
                          : `${styling.bg} ${styling.border} opacity-80 hover:opacity-100`
                      }`}
                    >
                      {/* Top Color Strip */}
                      <div className={`absolute top-0 left-0 right-0 h-1.5 ${styling.strip}`} />

                      {/* Card Header */}
                      <div className="pt-1">
                        <div className="flex items-start justify-between gap-1.5 mb-1.5">
                          <div className="flex items-center gap-1.5 min-w-0 flex-1">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="rounded text-amber-600 focus:ring-amber-500 cursor-pointer shrink-0"
                            />
                            <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                              {note.title}
                            </h4>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {note.isLocked && (
                              <span title="Kilitli / Şifreli Not" className="text-rose-500">
                                <Lock className="w-3 h-3" />
                              </span>
                            )}
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-white/70 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700">
                              {note.colorName}
                            </span>
                          </div>
                        </div>

                        {/* Content Preview */}
                        {note.isLocked ? (
                          <div className="py-3 px-2 bg-black/5 dark:bg-white/5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center my-1">
                            <Lock className="w-4 h-4 text-slate-400 mx-auto mb-1" />
                            <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">Şifreli / Kilitli İçerik</span>
                          </div>
                        ) : (
                          <div className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-3 mb-2 font-sans whitespace-pre-line leading-relaxed">
                            {note.content || "(İçerik boş)"}
                          </div>
                        )}

                        {/* Interactive Task Preview if checklist */}
                        {!note.isLocked && note.isChecklist && note.tasks.length > 0 && (
                          <div className="mb-2 p-1.5 rounded-xl bg-white/60 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 space-y-0.5">
                            {note.tasks.slice(0, 2).map((task, tIdx) => (
                              <div key={tIdx} className="flex items-center gap-1.5 text-[10px]">
                                <span className={task.completed ? "text-emerald-500 font-bold" : "text-slate-400"}>
                                  {task.completed ? "☑" : "☐"}
                                </span>
                                <span className={`truncate ${task.completed ? "line-through text-slate-400" : "text-slate-700 dark:text-slate-300"}`}>
                                  {task.text}
                                </span>
                              </div>
                            ))}
                            {note.tasks.length > 2 && (
                              <div className="text-[9px] text-slate-400 font-medium pl-1">
                                +{note.tasks.length - 2} görev daha
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Footer Info */}
                      <div className="text-[9px] text-slate-400 pt-1.5 border-t border-slate-200/50 dark:border-slate-700/50 flex items-center justify-between">
                        <span>{new Date(note.modifiedDate || note.createdDate).toLocaleDateString("tr-TR")}</span>
                        <span className={`font-semibold ${isSelected ? "text-amber-600 dark:text-amber-400" : "text-slate-400"}`}>
                          {isSelected ? "✓ Seçildi" : "Pasif"}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/90 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <span>ColorNote .BIN Ingestion &amp; Decryption Pipeline</span>
            <span>•</span>
            <span>PBKDF2 / EVP_BytesToKey + AES-128</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
