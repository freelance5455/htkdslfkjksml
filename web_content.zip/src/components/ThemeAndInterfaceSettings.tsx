import React, { useState } from "react";
import {
  Palette,
  Check,
  Sun,
  Moon,
  Sparkles,
  Layers,
  Shield,
  ShieldCheck,
  LayoutGrid,
  User,
  Cloud,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  StickyNote,
  Sliders,
  Send,
  Mail,
  Edit3,
  Lock,
  KeyRound,
  Eye,
  EyeOff,
  Copy,
  Download,
  AlertTriangle,
  RefreshCw,
  Search,
  CheckCircle2,
  Zap,
  Plus,
  Mic,
  SlidersHorizontal,
  PenTool,
  Wrench,
  Compass,
} from "lucide-react";
import { NoteFlowThemeStyle, NOTE_FLOW_THEME_TOKENS } from "../utils/themeTokens";
import { RadialMenuSettings } from "./RadialMenuSettings";
import { MenuSectionsManager } from "./MenuSectionsManager";
import { CanvasThemeSelector } from "./CanvasThemeSelector";
import { DisplaySettingsView } from "./DisplaySettingsView";
import { NavigationSettingsView } from "./NavigationSettingsView";
import { TroubleshootingCenter } from "./TroubleshootingCenter";
import {
  MinimalistCard,
  TerminalLogCard,
  CyberpunkGlowCard,
  MindMapNodeWidget,
  EnterprisePKMDashboard,
} from "./ThemeCardComponents";
import { ActiveTab, ThemeAccent, UIThemeStyle, UserProfile, SyncedNoteRecord, Note, VaultMetadata } from "../types";
import { THEME_ACCENTS, UI_THEME_STYLE_CONFIGS } from "../utils/theme";
import { useGlobalState } from "../context/GlobalContext";
import { MNEMONIC_WORDS } from "../utils/crypto";

interface ThemeOptionItem {
  id: NoteFlowThemeStyle;
  name: string;
  subtitle: string;
  description: string;
  badge: string;
  colorPreview: string;
}

const THEME_OPTIONS: ThemeOptionItem[] = [
  {
    id: NoteFlowThemeStyle.Minimalist,
    name: "Minimalist",
    subtitle: "Yüksek Okunabilirlik & Sade Görünüm",
    description: "Temiz kartlar, yumuşak mikro-gölgeler, dengeli tipografi ve düşük zihinsel yük.",
    badge: "Varsayılan",
    colorPreview: "from-teal-500 to-emerald-500",
  },
  {
    id: NoteFlowThemeStyle.Terminal,
    name: "Terminal",
    subtitle: "Koyu Konsol & Kod Odaklı Düzen",
    description: "Yazılımcılar için monospaced fontlar, koyu konsol ortamı ve renkli log akış etiketleri.",
    badge: "Developer",
    colorPreview: "from-emerald-600 to-green-400",
  },
  {
    id: NoteFlowThemeStyle.CyberpunkGlow,
    name: "Siberpunk Glow",
    subtitle: "Neon Işıma & Yüksek Enerjili Siber Estetik",
    description: "Sabitlenmiş notlar etrafında canlı siyan/mor neon halkalar sunan enerjik koyu tema.",
    badge: "Cyberpunk",
    colorPreview: "from-cyan-500 via-purple-500 to-rose-500",
  },
  {
    id: NoteFlowThemeStyle.MindMap,
    name: "Zihin Haritası",
    subtitle: "Ağ Bağlantılı Düğümler & Görsel Tuval",
    description: "Görsel ilişki haritası, bağlantılı bilgi düğümleri ve tuval düzeni.",
    badge: "Visual Canvas",
    colorPreview: "from-indigo-500 to-purple-600",
  },
  {
    id: NoteFlowThemeStyle.EnterprisePKM,
    name: "Enterprise PKM",
    subtitle: "Kurumsal Bilgi Yönetimi & Denetimli Arşiv",
    description: "Sol zaman çizelgesi, orta proje kartları ve sağ güvenlik kontrol panelli düzen.",
    badge: "Enterprise",
    colorPreview: "from-blue-600 to-slate-800",
  },
  {
    id: NoteFlowThemeStyle.CircadianPKM,
    name: "Sirkadiyen Stratejik PKM",
    subtitle: "12:00 Gündüz & 22:00 Gece İkili Modu",
    description: "Sıcak parşömen & obsidiyen yüzeyli, kırmızı & fuşya neon ışıma kartlı, dairesel eylem diskli yeni stil.",
    badge: "Circadian Dual",
    colorPreview: "from-[#E0533C] via-[#E11D48] to-[#15161A]",
  },
];

export interface ThemeAndInterfaceSettingsProps {
  profile?: UserProfile;
  onUpdateProfile?: (updated: UserProfile) => void;
  syncLogs?: SyncedNoteRecord[];
  onAddSyncLog?: (log: Omit<SyncedNoteRecord, "id">) => void;
  onClearSyncLogs?: () => void;
  notes?: Note[];
  vaultRecord?: VaultMetadata | null;
  setVaultRecord?: (record: VaultMetadata | null) => void;
  vaultNotes?: Note[];
  isVaultUnlocked?: boolean;
  onOpenVault?: () => void;
  themeAccent?: ThemeAccent;
  onChangeThemeAccent?: (accent: ThemeAccent) => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
  uiThemeStyle?: UIThemeStyle;
  onChangeUiThemeStyle?: (style: UIThemeStyle) => void;
  menuOrder?: ActiveTab[];
  onUpdateMenuOrder?: (order: ActiveTab[]) => void;
}

export const ThemeAndInterfaceSettings: React.FC<ThemeAndInterfaceSettingsProps> = ({
  syncLogs = [],
  notes = [],
  vaultRecord,
  vaultNotes = [],
  isVaultUnlocked = false,
  onOpenVault,
}) => {
  // UNIFIED GLOBAL CONTEXT (Single Source of Truth)
  const {
    state,
    setDarkMode,
    toggleDarkMode,
    setThemeAccent,
    setUiThemeStyle,
    setNoteFlowTheme,
    updateMenuOrder,
    resetMenuOrder,
    updateProfile,
  } = useGlobalState();

  const [activeTab, setActiveTab] = useState<
    "themes" | "display" | "navigation" | "canvas" | "menu_order" | "radial" | "troubleshoot" | "all"
  >("themes");

  const [saveToast, setSaveToast] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setSaveToast(msg);
    setTimeout(() => setSaveToast(null), 3200);
  };

  const handleSelectTheme = (theme: NoteFlowThemeStyle) => {
    setNoteFlowTheme(theme);
    if (theme === NoteFlowThemeStyle.CircadianPKM) {
      setUiThemeStyle("circadian_pkm");
    } else {
      setUiThemeStyle(theme.toLowerCase() as UIThemeStyle);
    }
    showNotification(`Tema '${theme}' olarak uygulandı.`);
  };

  const handleAccentChange = (accent: ThemeAccent) => {
    setThemeAccent(accent);
    showNotification(`Vurgu rengi '${THEME_ACCENTS[accent]?.name || accent}' olarak güncellendi.`);
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {saveToast && (
        <div className="p-3 sm:p-4 rounded-2xl bg-teal-600 text-white flex items-center justify-between shadow-xl animate-in slide-in-from-top-2 duration-200 z-50">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{saveToast}</span>
          </div>
          <button
            onClick={() => setSaveToast(null)}
            className="p-1 hover:bg-teal-700 rounded-lg text-teal-100 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* TOP HEADER: Unified Theme & Appearance Hub */}
      <div className="rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800">
        <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white px-5 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-teal-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 border border-teal-400/30 text-teal-300 flex items-center justify-center shrink-0 shadow-xs">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-black tracking-wide text-white uppercase flex items-center gap-1.5">
                  <span>TEMA, ARAYÜZ & SİSTEM AYARLARI</span>
                </h2>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-teal-400/20 text-teal-300 border border-teal-400/40">
                  Global State Sync
                </span>
              </div>
              <p className="text-[11px] text-teal-200/80">
                Tek Doğruluk Kaynağı ile Çakışmasız ve Anında Uygulanan Tasarım Motoru
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleDarkMode}
              className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer border border-white/10"
              title="Koyu / Açık Mod Değiştir"
            >
              {state.darkMode ? <Sun className="w-3.5 h-3.5 text-amber-300" /> : <Moon className="w-3.5 h-3.5 text-teal-300" />}
              <span>{state.darkMode ? "Açık Mod" : "Koyu Mod"}</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation Strip */}
        <div className="p-2.5 bg-slate-100 dark:bg-slate-800/80 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {[
            { id: "themes", label: "Temalar & Stiller", icon: Palette, badge: "6 Tema" },
            { id: "display", label: "Ekran & Ölçek", icon: SlidersHorizontal, badge: "%75-%175" },
            { id: "navigation", label: "Navigasyon & Dok", icon: Compass, badge: "Dinamik" },
            { id: "canvas", label: "Yazı Tahtası (Kanvas)", icon: PenTool, badge: "ColorNote" },
            { id: "menu_order", label: "Menü Sıralaması", icon: LayoutGrid, badge: `${state.menuOrder.length}` },
            { id: "radial", label: "Radyal Yelpaze", icon: RotateCcw, badge: "5 Stil" },
            { id: "troubleshoot", label: "Sorun Çözme Merkezi", icon: Wrench, badge: "Auto-Heal" },
            { id: "all", label: "Tümünü Göster", icon: Sparkles, badge: "Geniş" },
          ].map((tab) => {
            const isSel = activeTab === tab.id;
            const IconComp = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isSel
                    ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700"
                    : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-700/50"
                }`}
              >
                <IconComp className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-slate-200/60 dark:bg-slate-700/60 opacity-80">
                  {tab.badge}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. THEMES & ACCENTS GALLERY                                               */}
      {/* ========================================================================= */}
      {(activeTab === "themes" || activeTab === "all") && (
        <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Palette className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                <span>Uygulama Temaları & Canlı Tasarım Kartları</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                NoteFlow'un yüksek performanslı, zihinsel yükü azaltan 6 özel tema mimarisini seçin.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950 px-3 py-1.5 rounded-xl border border-teal-200 dark:border-teal-800">
              Aktif: {state.noteFlowTheme}
            </span>
          </div>

          {/* Theme Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {THEME_OPTIONS.map((theme) => {
              const isSelected = state.noteFlowTheme === theme.id;
              return (
                <div
                  key={theme.id}
                  onClick={() => handleSelectTheme(theme.id)}
                  className={`p-4.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 shadow-xs ${
                    isSelected
                      ? "border-teal-500 bg-teal-50/40 dark:bg-teal-950/20 ring-2 ring-teal-500/20 shadow-md"
                      : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900"
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className={`w-8 h-8 rounded-xl bg-gradient-to-r ${theme.colorPreview} shadow-xs`} />
                      <span
                        className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full ${
                          isSelected
                            ? "bg-teal-600 text-white"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                        }`}
                      >
                        {theme.badge}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-sm font-black text-slate-900 dark:text-white">{theme.name}</h4>
                      <p className="text-xs font-semibold text-teal-600 dark:text-teal-400">{theme.subtitle}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                        {theme.description}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectTheme(theme.id);
                    }}
                    className={`w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      isSelected
                        ? "bg-teal-600 text-white shadow-xs"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                    }`}
                  >
                    {isSelected ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : null}
                    <span>{isSelected ? "Aktif Tema" : "Temayı Uygula"}</span>
                  </button>
                </div>
              );
            })}
          </div>

          {/* Accent Colors */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Vurgu Rengi Paleti
              </h4>
              <span className="text-xs font-bold text-teal-600 dark:text-teal-400">
                {THEME_ACCENTS[state.themeAccent]?.name || state.themeAccent}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2">
              {(Object.keys(THEME_ACCENTS) as ThemeAccent[]).map((accKey) => {
                const acc = THEME_ACCENTS[accKey];
                const isAccSelected = state.themeAccent === accKey;
                return (
                  <button
                    key={accKey}
                    type="button"
                    onClick={() => handleAccentChange(accKey)}
                    className={`flex items-center gap-2 p-2 rounded-xl border transition-all cursor-pointer ${
                      isAccSelected
                        ? "border-teal-500 bg-teal-50/70 dark:bg-teal-950/60 ring-1 ring-teal-500/30 font-bold"
                        : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                    }`}
                  >
                    <div
                      className="w-4 h-4 rounded-full shrink-0 shadow-2xs"
                      style={{ backgroundColor: acc.preview }}
                    />
                    <span className="text-[11px] truncate">{acc.name.split(" ")[0]}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. DISPLAY SETTINGS VIEW (CATEGORICAL RESPONSIVE SCALING)                 */}
      {/* ========================================================================= */}
      {(activeTab === "display" || activeTab === "all") && (
        <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-300">
          <DisplaySettingsView onNotify={showNotification} />
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2.5 DYNAMIC NAVIGATION BAR & DOCK SETTINGS                                */}
      {/* ========================================================================= */}
      {(activeTab === "navigation" || activeTab === "all") && (
        <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-300">
          <NavigationSettingsView onNotify={showNotification} />
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. CANVAS & COLORNOTE RULED PAPER THEMES                                  */}
      {/* ========================================================================= */}
      {(activeTab === "canvas" || activeTab === "all") && (
        <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-300">
          <CanvasThemeSelector />
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. MENU ORDERING MANAGER                                                  */}
      {/* ========================================================================= */}
      {(activeTab === "menu_order" || activeTab === "all") && (
        <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
          <MenuSectionsManager
            menuOrder={state.menuOrder}
            onUpdateMenuOrder={updateMenuOrder}
            themeAccent={state.themeAccent}
          />
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. RADIAL MENU SETTINGS                                                   */}
      {/* ========================================================================= */}
      {(activeTab === "radial" || activeTab === "all") && (
        <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-300">
          <RadialMenuSettings />
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. TROUBLESHOOTING CENTER (SORUN ÇÖZME MERKEZİ)                           */}
      {/* ========================================================================= */}
      {(activeTab === "troubleshoot" || activeTab === "all") && (
        <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm transition-all duration-300">
          <TroubleshootingCenter onNotify={showNotification} />
        </div>
      )}
    </div>
  );
};
