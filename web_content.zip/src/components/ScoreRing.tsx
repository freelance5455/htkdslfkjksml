import { useCaliber } from "@/lib/store";

export function ScoreRing({ score }: { score: number }) {
  const { dict } = useCaliber();
  const r = 54;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;
  const tone = score >= 75 ? "text-ok" : score >= 50 ? "text-accent" : "text-primary";

  return (
    <div className="relative mx-auto grid size-36 place-items-center">
      <span className="pulse-ring absolute inset-3 rounded-full bg-primary/20" aria-hidden />
      <svg viewBox="0 0 128 128" className="size-36 -rotate-90" aria-hidden>
        <circle cx="64" cy="64" r={r} fill="none" stroke="currentColor" className="text-surface-2" strokeWidth="8" />
        <circle
          cx="64"
          cy="64"
          r={r}
          fill="none"
          stroke="currentColor"
          className={tone}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <div className={`font-display text-4xl font-semibold leading-none tabular-nums ${tone}`}>{score}</div>
          <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-muted">{dict.score}</div>
        </div>
      </div>
    </div>
  );
}
