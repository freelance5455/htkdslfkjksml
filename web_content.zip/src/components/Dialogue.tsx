import { useCallback, useEffect, useRef, useState } from "react";
import type { Palette } from "../game/types";
import { Portrait } from "./Portrait";

export interface DialogueChoiceView {
  text: string;
  disabled?: boolean;
  hint?: string;
}

export interface DialogueState {
  mode: "mission" | "chat";
  nodeId?: string;
  npcId: string;
  npcName: string;
  npcTitle?: string;
  title?: string;
  portrait: Palette & { crown?: boolean; hood?: boolean };
  lines: string[];
  choices?: DialogueChoiceView[];
  awaiting?: boolean;
}

export function Dialogue({
  d,
  onChoose,
  onContinue,
  onClose,
}: {
  d: DialogueState;
  onChoose: (i: number) => void;
  onContinue: () => void;
  onClose: () => void;
}) {
  const full = d.lines.join("\n\n");
  const [typed, setTyped] = useState(0);
  const done = typed >= full.length;
  const fullRef = useRef(full);
  fullRef.current = full;

  useEffect(() => {
    setTyped(0);
    let i = 0;
    const id = window.setInterval(() => {
      i += 3;
      if (i >= fullRef.current.length) {
        i = fullRef.current.length;
        window.clearInterval(id);
      }
      setTyped((prev) => Math.max(prev, i));
    }, 10);
    return () => window.clearInterval(id);
  }, [full]);

  const skip = useCallback(() => {
    setTyped(fullRef.current.length);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!done) {
        if (e.key === " " || e.key === "Enter") {
          e.preventDefault();
          skip();
        }
        return;
      }
      if (e.key >= "1" && e.key <= "9") {
        const idx = Number(e.key) - 1;
        if (d.choices && d.choices[idx] && !d.choices[idx].disabled) onChoose(idx);
      } else if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        if (d.awaiting) onContinue();
        else if (d.choices && d.choices.length === 0) onContinue();
      } else if (e.key === "Escape") {
        if (d.awaiting) onContinue();
        else onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [d, done, onChoose, onContinue, onClose, skip]);

  const shown = full.slice(0, typed);
  const parts = shown.split("\n\n");

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-40 flex justify-center px-2 pb-2 sm:px-4 sm:pb-4">
      <div className="panel pop pointer-events-auto w-full max-w-3xl">
        <div className="flex gap-3 p-3">
          <Portrait palette={d.portrait} size={72} crown={d.portrait.crown} hood={d.portrait.hood} className="hidden shrink-0 sm:block" />
          <div className="min-w-0 flex-1">
            <div className="mb-1 flex flex-wrap items-baseline gap-x-2">
              <span className="text-[14px] font-semibold text-[#f7e3a8]">{d.npcName}</span>
              {d.npcTitle && <span className="text-[11px] italic text-[#9d8fb0]">{d.npcTitle}</span>}
              {d.title && (
                <span className="mono ml-auto text-[10px] uppercase tracking-widest text-[#e8c06a]">{d.title}</span>
              )}
            </div>
            <div
              onClick={() => !done && skip()}
              className="max-h-[26vh] min-h-[52px] cursor-pointer overflow-y-auto whitespace-pre-wrap text-[14px] leading-relaxed text-[#ecdcb8]"
            >
              {parts.map((p, i) => (
                <p key={i} className={i > 0 ? "mt-2" : ""}>
                  {p}
                </p>
              ))}
              {!done && <span className="blink gold">▌</span>}
            </div>

            {done && d.awaiting && (
              <button className="btn btn-primary mt-3 w-full py-2" onClick={onContinue} autoFocus>
                Continuar [Espaço]
              </button>
            )}

            {done && !d.awaiting && d.choices && d.choices.length > 0 && (
              <div className="mt-3 flex flex-col gap-1.5">
                {d.choices.map((c, i) => (
                  <button
                    key={i}
                    disabled={c.disabled}
                    onClick={() => onChoose(i)}
                    className={`group flex items-start gap-2 border px-3 py-2 text-left text-[13px] leading-snug transition ${
                      c.disabled
                        ? "cursor-not-allowed border-[#33283f] bg-[#191322] text-[#6f6380]"
                        : "border-[#4a3a5e] bg-[#241a33] text-[#ecdcb8] hover:border-[#e8c06a] hover:bg-[#33244a] hover:text-[#f7e3a8]"
                    }`}
                  >
                    <span className="mono text-[11px] text-[#e8c06a]">{i + 1}.</span>
                    <span className="flex-1">
                      {c.text}
                      {c.hint && <span className="block text-[11px] italic text-[#8d7fa3]">{c.hint}</span>}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
