import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Search,
  ArrowLeft,
  UserCheck,
  Copy,
  Check,
  Calendar,
  MapPin,
  Clock,
  Sparkles,
  Users,
  KeyRound,
  RefreshCw,
  Hash,
} from 'lucide-react';
import { TicketValidationResult } from '../context/AppContext';
import { SearchBar } from './ui/SearchBar';
import { PurchasedTicket } from '../types';
import { firebaseService } from '../services/firebaseService';

export const ScannerPage: React.FC = () => {
  const {
    tickets,
    events,
    validateTicket,
    checkInTicket,
    showToast,
    formatKsh,
    setCurrentPage,
    stewardScannerEventId,
    setStewardScannerEventId,
    setSelectedDashboardEventId,
  } = useApp();

  const [inputCode, setInputCode] = useState('');
  const [validationResult, setValidationResult] = useState<TicketValidationResult | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [rosterSearch, setRosterSearch] = useState('');
  const [rosterFilter, setRosterFilter] = useState<'all' | 'pending' | 'admitted'>('all');
  const [stewardName, setStewardName] = useState('Gate Steward');

  // Read eventId from URL hash if loaded directly from steward share link
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const hash = window.location.hash;
      const match = hash.match(/eventId=([^&]+)/);
      if (match && match[1]) {
        setStewardScannerEventId(match[1]);
      }
    }
  }, [setStewardScannerEventId]);

  // Current event context if gate is locked to a specific event
  const targetEvent = stewardScannerEventId
    ? events.find((e) => e.id === stewardScannerEventId) || null
    : null;

  // Filter tickets for this event
  const eventTickets = useMemo(() => {
    if (targetEvent) {
      return tickets.filter((t) => t.eventId === targetEvent.id);
    }
    return tickets;
  }, [tickets, targetEvent]);

  // Roster metrics
  const totalGuests = eventTickets.reduce((acc, t) => acc + (t.quantity || 1), 0);
  const admittedGuests = eventTickets
    .filter((t) => t.status === 'used')
    .reduce((acc, t) => acc + (t.quantity || 1), 0);
  const pendingGuests = Math.max(0, totalGuests - admittedGuests);

  // Filtered guest roster
  const filteredRoster = useMemo(() => {
    return eventTickets.filter((t) => {
      if (rosterFilter === 'pending' && t.status === 'used') return false;
      if (rosterFilter === 'admitted' && t.status !== 'used') return false;
      if (!rosterSearch.trim()) return true;
      const q = rosterSearch.toLowerCase().trim();
      return (
        t.holderName.toLowerCase().includes(q) ||
        t.ticketCode.toLowerCase().includes(q) ||
        t.orderNumber.toLowerCase().includes(q) ||
        (t.holderPhone && t.holderPhone.includes(q))
      );
    });
  }, [eventTickets, rosterFilter, rosterSearch]);

  const handleManualLookup = async (codeToLookup?: string) => {
    const code = (codeToLookup || inputCode).trim();
    if (!code) {
      showToast('Please enter an alphanumeric ticket code or order reference');
      return;
    }

    setIsVerifying(true);

    // 1. Check local sync state first
    let result = validateTicket(code, targetEvent?.id);

    // 2. If not found locally, query Cloud Firestore directly
    if (result.status === 'invalid') {
      try {
        const cloudTicket = await firebaseService.findTicketByCodeOrRef(code, targetEvent?.id);
        if (cloudTicket) {
          if (cloudTicket.status === 'used') {
            result = {
              status: 'already_used',
              ticket: cloudTicket,
              message: `Ticket was already admitted at ${cloudTicket.checkedInAt || 'earlier today'} by ${cloudTicket.admittedBy || 'Gate'}.`,
            };
          } else {
            result = {
              status: 'valid',
              ticket: cloudTicket,
              message: 'Verified authentic ticket pass. Ready for manual gate admission.',
            };
          }
        }
      } catch (e) {
        // Fallback to local result
      }
    }

    setValidationResult(result);
    setIsVerifying(false);
  };

  const handleAdmitGuest = async (ticket: PurchasedTicket) => {
    setIsVerifying(true);
    const ok = await checkInTicket(ticket.ticketId, stewardName);
    setIsVerifying(false);

    if (ok) {
      showToast(`Admitted ${ticket.holderName} (${ticket.quantity} guests)`);
      // Update validation state to admitted
      const updatedTicket = { ...ticket, status: 'used' as const, checkedInAt: 'Just now', admittedBy: stewardName };
      setValidationResult({
        status: 'already_used',
        ticket: updatedTicket,
        message: `Successfully checked in by ${stewardName}. Turnstile opened.`,
      });
    }
  };

  const handleCopyStewardLink = () => {
    if (!targetEvent) return;
    const url = `${window.location.origin}${window.location.pathname}#scanner?eventId=${targetEvent.id}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    showToast('Manual Steward Portal link copied to clipboard!');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="min-h-screen bg-[#090a0d] pt-24 pb-28 text-[#f4f4f6] transition-colors">
      <div className="max-w-5xl mx-auto px-6 space-y-6">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1f2229]">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (targetEvent) {
                  setSelectedDashboardEventId(targetEvent.id);
                }
                setCurrentPage('dashboard');
              }}
              className="w-9 h-9 rounded-full border border-[#1f2229] bg-[#111317] hover:bg-[#17191f] flex items-center justify-center text-[#9496a1] hover:text-[#f4f4f6] transition-colors cursor-pointer"
              title="Return to Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                  {targetEvent ? 'Stationed Event Gate' : 'Universal Turnstile Portal'}
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-0.5">
                Manual Gate Verification & Admission
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {targetEvent && (
              <button
                onClick={handleCopyStewardLink}
                className="px-3.5 py-1.5 rounded-full border border-[#1f2229] bg-[#111317] text-[#9496a1] hover:text-[#f4f4f6] text-xs font-semibold hover:bg-[#17191f] transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied' : 'Share Steward Link'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Stationed Event Notice */}
        {targetEvent ? (
          <div className="p-4 rounded-2xl bg-[#111317] border border-[#1f2229] flex items-center justify-between gap-4 shadow-sm">
            <div className="flex items-center gap-3">
              <img
                src={targetEvent.image}
                alt={targetEvent.title}
                className="w-12 h-12 rounded-xl object-cover border border-[#1f2229]"
              />
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-400 block">
                  Stationed Venue Gate
                </span>
                <span className="text-sm font-bold text-white block">
                  {targetEvent.title}
                </span>
                <span className="text-xs text-[#9496a1]">
                  {targetEvent.venue} · {targetEvent.city} ({targetEvent.date})
                </span>
              </div>
            </div>

            <button
              onClick={() => setStewardScannerEventId(null)}
              className="text-xs text-[#9496a1] hover:text-white underline cursor-pointer"
            >
              Verify All Events
            </button>
          </div>
        ) : null}

        {/* Live Attendance Metric Cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-4 rounded-2xl bg-[#111317] border border-[#1f2229] text-center">
            <span className="text-[10px] uppercase font-bold text-[#646875] block">Total Registered</span>
            <span className="text-xl sm:text-2xl font-black text-white">{totalGuests}</span>
          </div>

          <div className="p-4 rounded-2xl bg-[#111317] border border-emerald-500/20 text-center">
            <span className="text-[10px] uppercase font-bold text-emerald-400 block">Admitted at Gate</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-400">{admittedGuests}</span>
          </div>

          <div className="p-4 rounded-2xl bg-[#111317] border border-[#1f2229] text-center">
            <span className="text-[10px] uppercase font-bold text-amber-400 block">Pending Check-In</span>
            <span className="text-xl sm:text-2xl font-black text-amber-400">{pendingGuests}</span>
          </div>
        </div>

        {/* Manual Verification Form & Result Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Manual Code Lookup & Admission */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-6 rounded-3xl bg-[#111317] border border-[#1f2229] shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#9496a1] flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-emerald-400" />
                  <span>Manual Code Verification</span>
                </span>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-[#646875]">Steward:</span>
                  <input
                    type="text"
                    value={stewardName}
                    onChange={(e) => setStewardName(e.target.value)}
                    className="px-2 py-0.5 rounded-md bg-[#17191f] border border-[#1f2229] text-[11px] font-semibold text-white focus:outline-none w-28"
                    placeholder="Gate Steward"
                  />
                </div>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleManualLookup();
                }}
                className="space-y-3"
              >
                <div className="relative">
                  <input
                    type="text"
                    value={inputCode}
                    onChange={(e) => setInputCode(e.target.value)}
                    placeholder="Enter pass code (e.g. AUR-TK-883921 or order #)"
                    className="w-full h-12 pl-11 pr-4 rounded-2xl bg-[#17191f] border border-[#1f2229] text-sm font-mono font-bold text-white placeholder:text-[#646875] focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500/60 uppercase"
                  />
                  <Hash className="absolute left-3.5 top-3.5 w-5 h-5 text-[#646875]" />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    disabled={isVerifying}
                    className="flex-1 h-11 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-98 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
                  >
                    {isVerifying ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Verifying in Cloud...</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4" />
                        <span>Verify & Lookup Code</span>
                      </>
                    )}
                  </button>

                  {inputCode && (
                    <button
                      type="button"
                      onClick={() => {
                        setInputCode('');
                        setValidationResult(null);
                      }}
                      className="h-11 px-3 rounded-xl border border-[#1f2229] bg-[#17191f] text-xs text-[#9496a1] hover:text-white"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </form>

              {/* Verification Result Card */}
              {validationResult && (
                <div className="pt-2 animate-in fade-in duration-200">
                  {validationResult.status === 'valid' && validationResult.ticket && (
                    <div className="p-5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                          <CheckCircle2 className="w-6 h-6" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 block">
                            Authentic Pass Verified
                          </span>
                          <h4 className="text-base font-bold text-white truncate">
                            {validationResult.ticket.holderName}
                          </h4>
                          <span className="text-xs text-neutral-300">
                            {validationResult.ticket.eventTitle} · {validationResult.ticket.quantity} Guest{validationResult.ticket.quantity > 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs p-3 rounded-xl bg-[#090a0d] border border-emerald-500/20 font-mono">
                        <div>
                          <span className="text-[10px] text-[#646875] block">Code</span>
                          <span className="text-emerald-400 font-bold">{validationResult.ticket.ticketCode}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-[#646875] block">Tier</span>
                          <span className="text-white">{validationResult.ticket.groupTierName || 'Standard Admission'}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleAdmitGuest(validationResult.ticket!)}
                        disabled={isVerifying}
                        className="w-full h-11 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-98 transition-all"
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>Authorize & Admit Entry ({validationResult.ticket.quantity} Wristbands)</span>
                      </button>
                    </div>
                  )}

                  {validationResult.status === 'already_used' && validationResult.ticket && (
                    <div className="p-5 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                          <AlertTriangle className="w-6 h-6" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block">
                            Already Admitted Pass
                          </span>
                          <h4 className="text-base font-bold text-white truncate">
                            {validationResult.ticket.holderName}
                          </h4>
                          <p className="text-xs text-amber-300/90 mt-0.5">
                            {validationResult.message}
                          </p>
                        </div>
                      </div>

                      <div className="text-xs font-mono text-[#9496a1] p-3 rounded-xl bg-[#090a0d] border border-[#1f2229]">
                        Pass Code: <strong className="text-white">{validationResult.ticket.ticketCode}</strong>
                      </div>
                    </div>
                  )}

                  {validationResult.status === 'invalid' && (
                    <div className="p-5 rounded-2xl bg-red-950/30 border border-red-500/30 flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                        <XCircle className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold tracking-wider text-red-400 block">
                          Invalid Ticket Code
                        </span>
                        <h4 className="text-sm font-bold text-white mt-0.5">
                          Code Not Found in Central System
                        </h4>
                        <p className="text-xs text-red-300/80 mt-1">
                          No active pass was found matching "{inputCode}". Verify spelling or look up by attendee name.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Live Attendee Guest Roster & 1-Click Admit */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-6 rounded-3xl bg-[#111317] border border-[#1f2229] shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#9496a1] flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-400" />
                  <span>Gate Guest Roster</span>
                </span>

                {/* Filter Pills */}
                <div className="inline-flex items-center p-0.5 bg-[#17191f] rounded-full border border-[#1f2229]">
                  {(['all', 'pending', 'admitted'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setRosterFilter(filter)}
                      className={`px-2.5 py-1 text-[11px] font-semibold rounded-full capitalize transition-colors cursor-pointer ${
                        rosterFilter === filter
                          ? 'bg-emerald-500 text-white font-bold'
                          : 'text-[#9496a1] hover:text-white'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              {/* Roster Search */}
              <div className="relative">
                <input
                  type="text"
                  value={rosterSearch}
                  onChange={(e) => setRosterSearch(e.target.value)}
                  placeholder="Filter by name, phone, or code..."
                  className="w-full h-10 pl-9 pr-3 rounded-xl bg-[#17191f] border border-[#1f2229] text-xs text-white placeholder:text-[#646875] focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
                <Search className="absolute left-3 top-3 w-4 h-4 text-[#646875]" />
              </div>

              {/* Attendees List */}
              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                {filteredRoster.length === 0 ? (
                  <div className="py-10 text-center text-xs text-[#646875] space-y-1">
                    <Users className="w-6 h-6 mx-auto opacity-30 mb-2" />
                    <p className="font-semibold text-[#9496a1]">No attendees match filter</p>
                    <p className="text-[11px]">Attendees will appear here once booked.</p>
                  </div>
                ) : (
                  filteredRoster.map((t) => {
                    const isAdmitted = t.status === 'used';
                    return (
                      <div
                        key={t.ticketId}
                        className="p-3 rounded-2xl bg-[#17191f] border border-[#1f2229] flex items-center justify-between gap-3 hover:border-emerald-500/30 transition-colors"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-white truncate">
                              {t.holderName}
                            </span>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#090a0d] text-emerald-400 border border-[#1f2229]">
                              {t.ticketCode}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-[#9496a1] mt-0.5">
                            <span>{t.groupTierName || 'Standard'} ({t.quantity} pax)</span>
                            <span>·</span>
                            <span>{t.holderPhone || t.date}</span>
                          </div>
                        </div>

                        <div>
                          {isAdmitted ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#646875] bg-[#090a0d] px-2.5 py-1 rounded-full border border-[#1f2229]">
                              <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                              <span>Admitted</span>
                            </span>
                          ) : (
                            <button
                              onClick={() => {
                                setInputCode(t.ticketCode);
                                handleAdmitGuest(t);
                              }}
                              className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold active:scale-95 transition-all cursor-pointer flex items-center gap-1 shadow-xs"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                              <span>Admit</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
