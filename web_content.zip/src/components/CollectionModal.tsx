import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Coins, Check, Video, Sparkles } from 'lucide-react';
import { ARROW_SKINS } from '../game/collectionData';
import { CollectionItem, PlayerStats, Language } from '../types';
import { getTranslations } from '../services/i18n';
import { TILE_COLOR_CONFIGS } from './ArrowTile';
import { BannerAd } from './BannerAd';

interface CollectionModalProps {
  stats: PlayerStats;
  language?: Language;
  onEquipSkin: (skinId: string) => void;
  onBuyItem: (item: CollectionItem) => void;
  onWatchAdForCoins?: () => void;
  onBack: () => void;
}

export const CollectionModal: React.FC<CollectionModalProps> = ({
  stats,
  language = 'en',
  onEquipSkin,
  onBuyItem,
  onWatchAdForCoins,
  onBack,
}) => {
  const t = getTranslations(language);

  const isUnlocked = (item: CollectionItem) => {
    return (stats.unlockedSkins || []).includes(item.id) || item.cost === 0 || item.id === 'black';
  };

  const isEquipped = (item: CollectionItem) => {
    return (stats.equippedArrowSkin || 'black') === item.id;
  };

  const handleAction = (item: CollectionItem) => {
    if (isUnlocked(item)) {
      onEquipSkin(item.id);
    } else {
      if (stats.coins >= item.cost) {
        onBuyItem(item);
      }
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-50 dark:bg-slate-900 select-none overflow-hidden justify-between">
      {/* Top Header with Android Safe Area Inset */}
      <div 
        className="px-5 pb-3 flex items-center justify-between border-b border-slate-200/80 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md shrink-0"
        style={{ paddingTop: 'max(1rem, env(safe-area-inset-top, 0px))' }}
      >
        <button
          id="btn-collection-back"
          type="button"
          onClick={onBack}
          aria-label="Back to Menu"
          className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200 active:scale-95 transition border border-slate-200 dark:border-slate-700"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center">
          <h2 className="text-lg font-black text-slate-800 dark:text-white tracking-tight uppercase">
            {t.shop}
          </h2>
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
            {t.shopSubtitle}
          </span>
        </div>

        {/* Coins Pill */}
        <div className="h-9 px-3 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 flex items-center gap-1.5 shadow-sm">
          <Coins className="w-4 h-4 text-amber-500 fill-amber-400" />
          <span className="text-xs font-black text-amber-900 dark:text-amber-200">
            {stats.coins}
          </span>
        </div>
      </div>

      {/* Optional Rewarded Ad Bonus Bar for Coins */}
      {onWatchAdForCoins && (
        <div className="px-5 py-2 bg-gradient-to-r from-amber-500/10 via-sky-500/10 to-indigo-500/10 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Need more coins?
            </span>
          </div>
          <button
            id="btn-shop-rewarded-coins"
            type="button"
            onClick={onWatchAdForCoins}
            className="h-7 px-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] flex items-center gap-1.5 shadow-sm active:scale-95 transition"
          >
            <Video className="w-3 h-3" />
            <span>+100 Coins (Ad)</span>
          </button>
        </div>
      )}

      {/* Main Grid of Cosmetic Styles */}
      <div className="flex-1 overflow-y-auto p-4 max-w-md mx-auto w-full">
        <div className="grid grid-cols-2 gap-3 pb-2">
          {ARROW_SKINS.map((item) => {
            const unlocked = isUnlocked(item);
            const equipped = isEquipped(item);
            const canAfford = stats.coins >= item.cost;

            return (
              <motion.div
                key={item.id}
                id={`shop-item-${item.id}`}
                whileHover={{ y: -2 }}
                className={`p-3 rounded-2xl border flex flex-col justify-between transition-all bg-white dark:bg-slate-800/90 shadow-sm relative ${
                  equipped
                    ? 'border-sky-500 ring-2 ring-sky-500/30 dark:border-sky-400'
                    : unlocked
                    ? 'border-slate-200 dark:border-slate-700'
                    : 'border-slate-200/80 dark:border-slate-800'
                }`}
              >
                {/* Visual Swatch Preview Box */}
                <div className="w-full h-16 rounded-xl relative flex items-center justify-center overflow-hidden mb-2 bg-slate-950/80 border border-slate-700/60 shadow-inner">
                  {/* Miniature compact square tile preview */}
                  {(() => {
                    const cfg = TILE_COLOR_CONFIGS[item.id] || TILE_COLOR_CONFIGS.black;
                    return (
                      <div
                        className="w-9 h-9 rounded-[6px] relative flex items-center justify-center shadow-md transition-transform"
                        style={{
                          background: cfg.tileBg,
                          borderTop: `1px solid ${cfg.tileTopHighlight}`,
                          borderLeft: `1px solid ${cfg.tileTopHighlight}`,
                          borderRight: `1px solid ${cfg.tileBottomLip}`,
                          borderBottom: `2.5px solid ${cfg.tileBottomLip}`,
                          boxShadow: `0 2px 5px rgba(0,0,0,0.35), 0 0 0 0.5px ${cfg.tileBorder}`,
                        }}
                      >
                        <div
                          className="absolute top-0 left-0 right-0 h-1/3 pointer-events-none rounded-t-[5px]"
                          style={{
                            background:
                              'linear-gradient(180deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 100%)',
                          }}
                        />
                        <svg
                          viewBox="0 0 100 100"
                          className="w-[70%] h-[70%] overflow-visible pointer-events-none"
                          style={{
                            filter: `drop-shadow(0 1px 2px ${cfg.arrowShadow})`,
                          }}
                        >
                          <path
                            d="M 50,15 L 85,50 L 64,50 L 64,81 C 64,84 61,86 58,86 L 42,86 C 39,86 36,84 36,81 L 36,50 L 15,50 Z"
                            fill={cfg.arrowFill}
                            stroke={cfg.arrowStroke}
                            strokeWidth="2.5"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    );
                  })()}

                  {/* Special Item Badges */}
                  {item.id === 'rainbow' && (
                    <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-gradient-to-r from-rose-500 via-amber-500 to-violet-500 text-white font-black text-[8px] uppercase tracking-wider shadow-sm">
                      RAINBOW
                    </span>
                  )}
                  {item.id === 'design_match' && (
                    <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-gradient-to-r from-indigo-500 to-pink-500 text-white font-black text-[8px] uppercase tracking-wider shadow-sm">
                      DESIGN MATCH
                    </span>
                  )}

                  {equipped && (
                    <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-sky-500 text-white font-black text-[9px] uppercase tracking-wider flex items-center gap-0.5 shadow-sm">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                      {t.equipped}
                    </span>
                  )}
                  {!equipped && unlocked && (
                    <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-black text-[8px] uppercase tracking-wider">
                      {t.owned}
                    </span>
                  )}
                </div>

                {/* Name & Short Description */}
                <div className="flex flex-col text-left mb-3">
                  <span className="text-sm font-black text-slate-800 dark:text-white capitalize">
                    {item.name}
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1">
                    {item.description}
                  </span>
                </div>

                {/* State Button: BUY → OWNED → EQUIP */}
                <div>
                  {equipped ? (
                    <button
                      type="button"
                      disabled
                      className="w-full h-9 rounded-xl bg-sky-500/15 text-sky-600 dark:text-sky-400 font-bold text-xs flex items-center justify-center gap-1 cursor-default border border-sky-500/30"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{t.equipped}</span>
                    </button>
                  ) : unlocked ? (
                    <button
                      type="button"
                      id={`btn-equip-${item.id}`}
                      onClick={() => handleAction(item)}
                      className="w-full h-9 rounded-xl bg-sky-50 hover:bg-sky-500 hover:text-white dark:bg-slate-700/80 text-sky-600 dark:text-sky-300 border border-sky-300 dark:border-slate-600 font-black text-xs flex items-center justify-center gap-1 active:scale-95 transition"
                    >
                      <span>{t.equip}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      id={`btn-buy-${item.id}`}
                      onClick={() => handleAction(item)}
                      disabled={!canAfford}
                      className={`w-full h-9 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition ${
                        canAfford
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-sm'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5 fill-current" />
                      <span>{item.cost === 0 ? 'FREE' : `BUY ${item.cost}`}</span>
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Real AdMob Horizontal Banner Ad docked at absolute bottom */}
      <BannerAd />
    </div>
  );
};
